#include "stdafx.h"
#include "skimconf.h"
#include "keymap.h"

/*========================================================================
 *	Registry-related definitions
 */
#define	REGINFO_KANAMODEWHENOPEN		TEXT("KanaModeWhenOpen")
#define	REGINFO_ECHO					TEXT("Echo")
#define	REGINFO_AUTOINSERTPAREN			TEXT("AutoInsertParen")
#define	REGINFO_COMPOSITIONAUTOSHIFT	TEXT("CompTextAutoShift")
#define	REGINFO_DELETEIMPLIESKAKUTEI	TEXT("DeleteImpliesKakutei")
#define	REGINFO_DATEAD					TEXT("DateAd")
#define	REGINFO_NUMBERSTYLE				TEXT("NumberStyle")
#define	REGINFO_BRACKETPARENS			TEXT("CustomBracketParens")
#define	REGINFO_KUTOUTENTYPE			TEXT("KutoutenType")
#define	REGINFO_KUTOUTENS				TEXT("CustomKutoutens")
#define	REGINFO_KAKUTEIEARLY			TEXT("KakuteiEarly")
#define	REGINFO_OKURICHARALISTTYPE		TEXT("OkuriCharAlistType")
#define	REGINFO_OKURICHARALIST			TEXT("OkuriCharAlist")

/*========================================================================
 *	Definitions
 */
enum {
	REGKEYTYPE_UNKNOWN	= -1,
	REGKEYTYPE_BOOL		= 0,
	REGKEYTYPE_INT,
} ;

enum {
	BRACKETPARENTP_NONE	= 0,
	BRACKETPARENTP_DEFAULT,
	BRACKETPARENTP_USERDEFINED,
} ;

enum {
	OKURICHARTP_NONE	= 0,
	OKURICHARTP_DEFAULT,
	OKURICHARTP_USERDEFINED,
} ;

enum {
	KUTOUTEN_TYPE_JP	= 0,
	KUTOUTEN_TYPE_EN,
	KUTOUTEN_TYPE_CUSTOM,
} ;

#define	SIZE_LBRACKET		32
#define	SIZE_RBRACKET		SIZE_LBRACKET
#define	SIZE_KUTEN			32
#define	SIZE_TOUTEN			SIZE_KUTEN
#define	BUFSIZE_STRPAIR		32

/*========================================================================
 *	structures
 */
struct TStringPairNode {
	TCHAR					m_bufLeft  [BUFSIZE_STRPAIR] ;
	TCHAR					m_bufRight [BUFSIZE_STRPAIR] ;
	struct TStringPairNode*	m_pPrev ;
	struct TStringPairNode*	m_pNext ;
} ;

struct TEditKutoutenListArg {
	struct TStringPairNode*	m_plstKutouten ;
} ;

struct TEditBracketParenListArg {
	struct TStringPairNode*	m_plstBracketParen ;
} ;

struct TEditOkuriCharAlistArg {
	struct TStringPairNode*	m_plstOkuriCharPair ;
} ;

/*========================================================================
 *	prototypes
 */
static	INT_PTR				dlgGeneric_iOnInitDialog		(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgGeneric_iOnCommand			(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgGeneric_iOnNotify			(HWND, WPARAM, LPARAM) ;
static	void				dlgGeneric_vSyncControls		(HWND) ;
static	void				dlgGeneric_vEditBracket			(HWND) ;
static	void				dlgGeneric_vEditKutouten		(HWND) ;
static	void				dlgGeneric_vEditOkuriCharAlist	(HWND) ;
static	INT_PTR	CALLBACK	dlgEditBracketListProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditKutoutenListProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditOkuriCharAlistProc		(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL				dlgGeneric_bLoadRegistrySetting		(void) ;
static	BOOL				dlgGeneric_bSaveSettingToRegistry	(void) ;
static	void				dlgGeneric_vLoadDefaultSetting		(void) ;	
static	struct TStringPairNode*	dlgGeneric_pDecodeStringPairList	(LPCTSTR) ;
static	LPWSTR				dlgGeneric_pEncodeStringPairList	(struct TStringPairNode*, int*) ;

static	struct TStringPairNode*		pCreateStringPair			(LPCTSTR, LPCTSTR) ;
static	struct TStringPairNode*		pCopyStringPairList			(struct TStringPairNode*) ;
static	void						vDestroyStringPairList		(struct TStringPairNode**) ;
static	struct TStringPairNode*		pFindStringPair				(struct TStringPairNode*, LPCTSTR) ;
static	void						vInsertStringPair			(struct TStringPairNode**, struct TStringPairNode*) ;

static	struct TStringPairNode*		pCreateDefaultBracketParenList	(void) ;
static	struct TStringPairNode*		pCreateDefaultKutoutenList		(int) ;

#if 0
static	struct TStringPairNode*	pCreateBracketParen				(LPCTSTR, LPCTSTR) ;
static	struct TStringPairNode*	pCreateDefaultBracketParenList	(void) ;
static	struct TStringPairNode*	pCopyBracketParenList			(struct TStringPairNode*) ;
static	void						vDestroyBracketParenList		(struct TStringPairNode*) ;
static	struct TStringPairNode*	pFindBracketParen				(struct TStringPairNode*, LPCTSTR) ;
static	void						vInsertBracketParen				(struct TStringPairNode**, struct TStringPairNode*) ;

static	struct TStringPairNode*	pCreateKutoutenNode (LPCTSTR, LPCTSTR) ;
static	struct TStringPairNode*	pCopyKutoutenList	(struct TStringPairNode*) ;
static	struct TStringPairNode*	pCreateDefaultKutoutenList	(int) ;
static	void					vDestroyKutoutenList		(struct TStringPairNode*) ;
static	void					vInsertKutoutenLast	(struct TStringPairNode**, struct TStringPairNode*) ;
#endif

/*========================================================================
 *	global variables
 */
static	BOOL					_bKanaModeWhenOpen		= TRUE ;
static	BOOL					_bEcho					= TRUE ;
//static	BOOL					_bAutoInsertParen		= TRUE ;
static	BOOL					_bCompositionAutoShift	= TRUE ;
static	BOOL					_bDeleteImpliesKakutei	= TRUE ;
static	BOOL					_bKakuteiEarly			= TRUE ;
//static	BOOL					_bOkuriCharAlist		= FALSE ;

static	int						_bDateAd				= FALSE ;
static	int						_iNumberStyle			= 0 ;

static	int						_iKutoutenType			= KUTOUTEN_TYPE_JP ;
static	struct TStringPairNode*	_plstKutoutens			= NULL ;

static	int						_iBracketParenType		= BRACKETPARENTP_DEFAULT ;
static	struct TStringPairNode*	_plstBracketParens		= NULL ;
static	int						_iOkuriCharAlistType	= OKURICHARTP_DEFAULT ;
static	struct TStringPairNode*	_plstOkuriCharAlist		= NULL ;

static	BOOL					_bExistUserDefinedBracketParen		= FALSE ;
static	BOOL					_bExistUserDefinedOkuriCharAlist	= FALSE ;
static	BOOL					_bExistUserDefinedKutoutenList		= FALSE ;

static	HICON					_hiconArrowUp			= NULL ;
static	HICON					_hiconArrowDown			= NULL ;

/*========================================================================
 *	public functions
 */
INT_PTR	CALLBACK
DlgGenericProc (
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgGeneric_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgGeneric_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgGeneric_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgGeneric_iOnInitDialog (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	static	struct {
		LPCTSTR	m_strTitle ;
		int		m_nValue ;
	}	_srKutoutenList []	= {
		{	TEXT ("�u�B�v�u�A�v�������l�A�u�C�v�u�D�v�ƃg�O������"),	KUTOUTEN_TYPE_JP	},
		{	TEXT ("�u�C�v�u�D�v�������l�A�u�B�v�u�A�v�ƃg�O������"),	KUTOUTEN_TYPE_EN	},
	} ;
	PROPSHEETPAGE*	pPropPage	= (PROPSHEETPAGE*) lParam ;
	HWND			hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pPropPage->lParam) ;

	if (! dlgGeneric_bLoadRegistrySetting ()) 
		dlgGeneric_vLoadDefaultSetting () ;

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_KUTOUTEN) ;
	if (hwndControl != NULL) {
		int		i, nItem ;

		for (i = 0 ; i < ARRAYSIZE (_srKutoutenList) ; i ++) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) _srKutoutenList [i].m_strTitle) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) _srKutoutenList [i].m_nValue) ;
			}
		}
		if (_bExistUserDefinedKutoutenList) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) KUTOUTEN_TYPE_CUSTOM) ;
			}
		}
	}
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_BRACKETPAREN) ;
	if (hwndControl != NULL) {
		int		nItem ;
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("����")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) BRACKETPARENTP_NONE) ;
		}
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("�W��(�L��)")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) BRACKETPARENTP_DEFAULT) ;
		}
		if (_bExistUserDefinedBracketParen) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`(�L��)")) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) BRACKETPARENTP_USERDEFINED) ;
			}
		}
	}
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_OKURICHARALIST) ;
	if (hwndControl != NULL) {
		int		nItem ;
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("����")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) OKURICHARTP_NONE) ;
		}
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("�W��(�L��)")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) OKURICHARTP_DEFAULT) ;
		}
		if (_bExistUserDefinedOkuriCharAlist) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`(�L��)")) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) OKURICHARTP_USERDEFINED) ;
			}
		}
	}
	dlgGeneric_vSyncControls (hDlg) ;
	return	(INT_PTR) FALSE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgGeneric_iOnCommand (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_CHECK_KANA_MODE_WHEN_OPEN:
		_bKanaModeWhenOpen	= IsDlgButtonChecked (hDlg, IDC_CHECK_KANA_MODE_WHEN_OPEN) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_SKK_ECHO:
		_bEcho	= IsDlgButtonChecked (hDlg, IDC_CHECK_SKK_ECHO) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_COMPOSITION_AUTO_SHIFT:
		_bCompositionAutoShift	= IsDlgButtonChecked (hDlg, IDC_CHECK_COMPOSITION_AUTO_SHIFT) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_DELETE_IMPLIES_KAKUTEI:
		_bDeleteImpliesKakutei	= IsDlgButtonChecked (hDlg, IDC_CHECK_DELETE_IMPLIES_KAKUTEI) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_KAKUTEI_EARLY:
		_bKakuteiEarly		= IsDlgButtonChecked (hDlg, IDC_CHECK_KAKUTEI_EARLY) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_RADIO_DATE_SEIREKI:
	case	IDC_RADIO_DATE_GENGOU:
		if (woControl != (IDC_RADIO_DATE_SEIREKI + _bDateAd)) {
			_bDateAd	= (woControl == IDC_RADIO_DATE_GENGOU) ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
		}
		CheckRadioButton (hDlg, IDC_RADIO_DATE_SEIREKI, IDC_RADIO_DATE_GENGOU, woControl) ;
		return	(INT_PTR) 0 ;
	case	IDC_RADIO_NUMBER_HANEI:
	case	IDC_RADIO_NUMBER_ZENEI:
	case	IDC_RADIO_NUMBER_KANSUJI:
		if (woControl != (_iNumberStyle + IDC_RADIO_NUMBER_HANEI)) {
			_iNumberStyle	= woControl - IDC_RADIO_NUMBER_HANEI ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
		}
		CheckRadioButton (hDlg, IDC_RADIO_NUMBER_HANEI, IDC_RADIO_NUMBER_KANSUJI, woControl) ;
		return	(INT_PTR) 0 ;
	case	IDC_COMBO_OKURICHARALIST:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			int		nCurSel, nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (_iOkuriCharAlistType != nData) {
					_iOkuriCharAlistType	= nData ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
		}
		return	(INT_PTR) 0 ;
	case	IDC_COMBO_BRACKETPAREN:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			int		nCurSel, nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (_iBracketParenType != nData) {
					_iBracketParenType	= nData ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
		}
		return	(INT_PTR) 0 ;
	case	IDC_COMBO_KUTOUTEN:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			int		nCurSel, nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (_iKutoutenType != nData) {
					_iKutoutenType	= nData ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
		}
		return	(INT_PTR) 0 ;
	case	IDC_BUTTON_EDIT_BRACKET:
		dlgGeneric_vEditBracket (hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_BUTTON_EDIT_KUTOUTEN:
		dlgGeneric_vEditKutouten (hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_BUTTON_EDIT_OKURI_CHAR_ALIST:
		dlgGeneric_vEditOkuriCharAlist (hDlg) ;
		return	(INT_PTR) 0 ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
}

INT_PTR
dlgGeneric_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	LPNMHDR	pnmh		= (LPNMHDR) lParam ;

	if (pnmh == NULL)
		return	0 ;

	switch (pnmh->code) {
	case	PSN_APPLY:
		if (dlgGeneric_bSaveSettingToRegistry ())
			vUpdateTick () ;
		break ;
	case	PSN_RESET:
		{
			if (! dlgGeneric_bLoadRegistrySetting ()) 
				dlgGeneric_vLoadDefaultSetting () ;
			/* �X�V���ꂽ�ݒ�𔽉f����B*/
			dlgGeneric_vSyncControls (hDlg) ;
		}
		break ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgGeneric_vEditBracket (
	HWND			hDlg)
{
	HINSTANCE	hInst ;
	int			nResult ;
	struct TEditBracketParenListArg	arg ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_plstBracketParens != NULL) {
		arg.m_plstBracketParen	= pCopyStringPairList (_plstBracketParens) ;
	} else {
		arg.m_plstBracketParen	= pCreateDefaultBracketParenList () ;
	}
	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_BRACKETLIST), hDlg, dlgEditBracketListProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		vDestroyStringPairList (&arg.m_plstBracketParen) ;
		return ;
	}
	/* ���[�U��`�ɕ\����؂�ւ���B*/
	if (! _bExistUserDefinedBracketParen) {
		HWND	hwndControl ;
		int		nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_BRACKETPAREN) ;
		if (hwndControl != NULL) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) BRACKETPARENTP_USERDEFINED) ;
			}
		}
		_bExistUserDefinedBracketParen	= TRUE ;
	}
	_iBracketParenType	= BRACKETPARENTP_USERDEFINED ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_BRACKETPAREN,	_iBracketParenType) ;

	vDestroyStringPairList (&_plstBracketParens) ;
	_plstBracketParens	= arg.m_plstBracketParen ;
	PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return ;
}

void
dlgGeneric_vSyncControls (
	HWND			hDlg)
{
	CheckDlgButton (hDlg, IDC_CHECK_KANA_MODE_WHEN_OPEN,	_bKanaModeWhenOpen?		BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_SKK_ECHO,				_bEcho?					BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_COMPOSITION_AUTO_SHIFT,	_bCompositionAutoShift?	BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_DELETE_IMPLIES_KAKUTEI,	_bDeleteImpliesKakutei?	BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_KAKUTEI_EARLY,			_bKakuteiEarly?			BST_CHECKED : BST_UNCHECKED) ;

	CheckRadioButton (hDlg, IDC_RADIO_DATE_SEIREKI, IDC_RADIO_DATE_GENGOU, _bDateAd? IDC_RADIO_DATE_GENGOU : IDC_RADIO_DATE_SEIREKI) ;
	CheckRadioButton (hDlg, IDC_RADIO_NUMBER_HANEI, IDC_RADIO_NUMBER_KANSUJI, IDC_RADIO_NUMBER_HANEI + _iNumberStyle) ;

	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_BRACKETPAREN,	_iBracketParenType) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_OKURICHARALIST,	_iOkuriCharAlistType) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_KUTOUTEN,		_iKutoutenType) ;
	return ;
}

void
dlgGeneric_vEditKutouten (
	HWND			hDlg)
{
	HINSTANCE					hInst ;
	int							nResult ;
	struct TEditKutoutenListArg	arg ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_iKutoutenType == KUTOUTEN_TYPE_CUSTOM) {
		arg.m_plstKutouten	= pCopyStringPairList (_plstKutoutens) ;
	} else {
		arg.m_plstKutouten	= pCreateDefaultKutoutenList (_iKutoutenType) ;
	}

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_KUTOUTENLIST), hDlg, dlgEditKutoutenListProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		vDestroyStringPairList (&arg.m_plstKutouten) ;
		return ;
	}

	/* ������� custom type �ɂȂ�B*/
	vDestroyStringPairList (&_plstKutoutens) ;
	_plstKutoutens	= arg.m_plstKutouten ;
	_iKutoutenType	= KUTOUTEN_TYPE_CUSTOM ;

	/* ���[�U��`�ɕ\����؂�ւ���B*/
	if (! _bExistUserDefinedKutoutenList) {
		HWND	hwndControl ;
		int		nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_KUTOUTEN) ;
		if (hwndControl != NULL) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KUTOUTEN_TYPE_CUSTOM) ;
			}
		}
		_bExistUserDefinedKutoutenList	= TRUE ;
	}

	/* ComboBox �� Selection ��ύX���Ȃ���΁B*/
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_KUTOUTEN, _iKutoutenType) ;
	PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return ;
}

void
dlgGeneric_vEditOkuriCharAlist (
	HWND				hDlg)
{
	HINSTANCE						hInst ;
	int								nResult ;
	struct TEditOkuriCharAlistArg	arg ;

	memset (&arg, 0, sizeof (arg)) ;
	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_OKURICHARALIST), hDlg, dlgEditOkuriCharAlistProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		return ;
	}
	/* ���[�U��`�ɕ\����؂�ւ���B*/
	if (! _bExistUserDefinedOkuriCharAlist) {
		HWND	hwndControl ;
		int		nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_OKURICHARALIST) ;
		if (hwndControl != NULL) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) OKURICHARTP_USERDEFINED) ;
			}
		}
		_bExistUserDefinedOkuriCharAlist	= TRUE ;
	}
	_iOkuriCharAlistType	= OKURICHARTP_USERDEFINED ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_OKURICHARALIST,	_iOkuriCharAlistType) ;

	vDestroyStringPairList (&_plstOkuriCharAlist) ;
	_plstOkuriCharAlist	= arg.m_plstOkuriCharPair ;
	PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return ;
}

static	const struct {
	LPCTSTR		m_strKeyInfo ;
	int			m_iType ;
	void*		m_pvData ;
}	_srRegValues []	= {
	{	REGINFO_KANAMODEWHENOPEN,		REGKEYTYPE_BOOL,	&_bKanaModeWhenOpen,	},
	{	REGINFO_ECHO,					REGKEYTYPE_BOOL,	&_bEcho,	},
	{	REGINFO_COMPOSITIONAUTOSHIFT,	REGKEYTYPE_BOOL,	&_bCompositionAutoShift,	},
	{	REGINFO_DELETEIMPLIESKAKUTEI,	REGKEYTYPE_BOOL,	&_bDeleteImpliesKakutei,	},
	{	REGINFO_KAKUTEIEARLY,			REGKEYTYPE_BOOL,	&_bKakuteiEarly,	},
	{	REGINFO_DATEAD,					REGKEYTYPE_INT,		&_bDateAd,	},
	{	REGINFO_NUMBERSTYLE,			REGKEYTYPE_INT,		&_iNumberStyle,	},
	{	REGINFO_KUTOUTENTYPE,			REGKEYTYPE_INT,		&_iKutoutenType,	},
	{	REGINFO_AUTOINSERTPAREN,		REGKEYTYPE_INT,		&_iBracketParenType,	},
	{	REGINFO_OKURICHARALISTTYPE,		REGKEYTYPE_INT,		&_iOkuriCharAlistType,	},
} ;

BOOL
dlgGeneric_bLoadRegistrySetting (void)
{

	HKEY	hSubKey ;
	LONG 	lResult ;
	DWORD	dwType, cbData ;
	int		i ;
	LPTSTR	pwBracketParen		= NULL ;
	LPTSTR	pwKutoutens			= NULL ;
	LPTSTR	pwOkuriCharAlist	= NULL ;
	BOOL	bRetval				= FALSE ;

	_bExistUserDefinedOkuriCharAlist	= FALSE ;
	_bExistUserDefinedBracketParen		= FALSE ;
	_bExistUserDefinedKutoutenList		= FALSE ;


	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
		return	FALSE ;

	/*
	 */
	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_BRACKETPARENS, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwBracketParen	= (LPTSTR) MALLOC (cbData) ;
		if (pwBracketParen == NULL)
			goto	skip_error ;
		(void) RegQueryValueEx (hSubKey, REGINFO_BRACKETPARENS, NULL, &dwType, (BYTE*)pwBracketParen, &cbData) ;
	} else {
		_iBracketParenType		= BRACKETPARENTP_DEFAULT ;
	}
	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_KUTOUTENS, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwKutoutens	= (LPTSTR) MALLOC (cbData) ;
		if (pwKutoutens == NULL)
			goto	skip_error ;
		(void) RegQueryValueEx (hSubKey, REGINFO_KUTOUTENS, NULL, &dwType, (BYTE*)pwKutoutens, &cbData) ;
	} else {
		_iKutoutenType			= KUTOUTEN_TYPE_JP ;
	}
	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_OKURICHARALIST, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwOkuriCharAlist	= (LPTSTR) MALLOC (cbData) ;
		if (pwOkuriCharAlist == NULL)
			goto	skip_error ;
		(void) RegQueryValueEx (hSubKey, REGINFO_OKURICHARALIST, NULL, &dwType, (BYTE*)pwOkuriCharAlist, &cbData) ;
	} else {
		_iOkuriCharAlistType	= OKURICHARTP_DEFAULT ;
	}

	for (i = 0 ; i < ARRAYSIZE (_srRegValues) ; i ++) {
		DWORD	dwValue ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueEx (hSubKey, _srRegValues [i].m_strKeyInfo, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		switch (_srRegValues [i].m_iType) {
		case	REGKEYTYPE_BOOL:
			*(BOOL*)(_srRegValues [i].m_pvData)	= (dwValue != 0) ;
			break ;
		case	REGKEYTYPE_INT:
			*(int*)(_srRegValues [i].m_pvData)	= (int)dwValue ;
			break ;
		default:
			break ;
		}
	}
	bRetval	= TRUE ;

skip_error:
	RegCloseKey (hSubKey) ;

	/* BracketParen �� parse */
	if (bRetval && pwBracketParen != NULL) {
		struct TStringPairNode*	plstBracketParen ;

		plstBracketParen	= dlgGeneric_pDecodeStringPairList (pwBracketParen) ;
		if (plstBracketParen != NULL) {
			vDestroyStringPairList (&_plstBracketParens) ;
			_plstBracketParens	= plstBracketParen ;
			_bExistUserDefinedBracketParen	= TRUE ;
		} else {
			bRetval	= FALSE ;
		}
	}
	/* Kutouten �� parse */
	if (bRetval && pwKutoutens != NULL) {
		struct TStringPairNode*	plstKutouten ;

		plstKutouten	= dlgGeneric_pDecodeStringPairList (pwKutoutens) ;
		if (plstKutouten != NULL) {
			vDestroyStringPairList (&_plstKutoutens) ;
			_plstKutoutens	= plstKutouten ;
			_bExistUserDefinedKutoutenList	= TRUE ;
		} else {
			bRetval	= FALSE ;
		}
	}
	if (bRetval && pwOkuriCharAlist != NULL) {
		struct TStringPairNode*	plstOkuriCharAlist ;

		plstOkuriCharAlist	= dlgGeneric_pDecodeStringPairList (pwOkuriCharAlist) ;
		if (plstOkuriCharAlist != NULL) {
			vDestroyStringPairList (&_plstOkuriCharAlist) ;
			_plstOkuriCharAlist	= plstOkuriCharAlist ;
			_bExistUserDefinedOkuriCharAlist	= TRUE ;
		} else {
			bRetval	= FALSE ;
		}
	}
	FREE (pwBracketParen) ;
	FREE (pwKutoutens) ;
	FREE (pwOkuriCharAlist) ;
	return	bRetval ;
}

BOOL
dlgGeneric_bSaveSettingToRegistry (void)
{
	HKEY	hSubKey ;
	LPTSTR	pwBracketParens		= NULL ;
	LPTSTR	pwKutoutens			= NULL ;
	LPTSTR	pwOkuriCharAlist	= NULL ;
	int		nSizeBracketParens	= 0 ;
	int		nSizeKutoutens		= 0 ;
	int		nSizeOkuriCharAlist	= 0 ;
	int		i ;
	BOOL	bRetval			= FALSE ;

	if (_plstBracketParens != NULL) {
		pwBracketParens	= dlgGeneric_pEncodeStringPairList (_plstBracketParens, &nSizeBracketParens) ;
	}
	if (_plstKutoutens != NULL) {
		pwKutoutens	= dlgGeneric_pEncodeStringPairList (_plstKutoutens, &nSizeKutoutens) ;
	}
	if (_plstOkuriCharAlist != NULL) {
		pwOkuriCharAlist	= dlgGeneric_pEncodeStringPairList (_plstOkuriCharAlist, &nSizeOkuriCharAlist) ;
	}

	/*	���W�X�g���̃L�[���J���Ă�����Ԃ��ŏ��ɂ������c���̕��������̂��낤�B
	 */
	if (! bCreateRegistryKey (REGPATH_GENERIC, FALSE, &hSubKey)) 
		goto	error_exit ;

	for (i = 0 ; i < ARRAYSIZE (_srRegValues) ; i ++) {
		DWORD	dwValue ;
		switch (_srRegValues [i].m_iType) {
			case	REGKEYTYPE_BOOL:
				dwValue	= *(BOOL*)(_srRegValues [i].m_pvData) ;
				break ;
			case	REGKEYTYPE_INT:
				dwValue	= *(int*)(_srRegValues [i].m_pvData) ;
				break ;
			default:
				continue ;
		}
		if (RegSetValueEx (hSubKey, _srRegValues [i].m_strKeyInfo, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) 
			goto	error_exit ;
	}
	if (pwBracketParens != NULL && nSizeBracketParens > 0) {
		RegSetValueEx (hSubKey, REGINFO_BRACKETPARENS, 0, REG_MULTI_SZ, (BYTE*) pwBracketParens, sizeof (TCHAR) * nSizeBracketParens) ;
	}
	if (pwKutoutens != NULL && nSizeKutoutens > 0) {
		RegSetValueEx (hSubKey, REGINFO_KUTOUTENS, 0, REG_MULTI_SZ, (BYTE*) pwKutoutens, sizeof (TCHAR) * nSizeKutoutens) ;
	}
	if (pwOkuriCharAlist != NULL && nSizeOkuriCharAlist > 0) {
		RegSetValueEx (hSubKey, REGINFO_OKURICHARALIST, 0, REG_MULTI_SZ, (BYTE*) pwOkuriCharAlist, sizeof (TCHAR) * nSizeOkuriCharAlist) ;
	}

	RegCloseKey (hSubKey) ;
	bRetval	= TRUE ;

error_exit:
	FREE (pwOkuriCharAlist) ;
	FREE (pwBracketParens) ;
	FREE (pwKutoutens) ;
	return	bRetval ;
}

struct TStringPairNode*
dlgGeneric_pDecodeStringPairList (
	LPCTSTR			pwEncodedString)
{
	struct TStringPairNode*		plstStringPair ;
	struct TStringPairNode*		pNode ;
	LPCTSTR	pwSrc ;
	TCHAR	bufLeft [SIZE_LBRACKET], bufRight [SIZE_RBRACKET] ;
	BOOL	bTerminated ;

	plstStringPair	= NULL ;
	pwSrc			= pwEncodedString ;
	while (*pwSrc != TEXT ('\0')) {
		if (! bParseBSEncodedString (&pwSrc, bufLeft, ARRAYSIZE (bufLeft) - 1, &bTerminated) || bTerminated) {
			vDestroyStringPairList (&plstStringPair) ;
			break ;
		}
		bufLeft [ARRAYSIZE (bufLeft) - 1]	= TEXT ('\0') ;

		if (! bParseBSEncodedString (&pwSrc, bufRight, ARRAYSIZE (bufRight) - 1, &bTerminated) || ! bTerminated) {
			vDestroyStringPairList (&plstStringPair) ;
			break ;
		}
		bufRight [ARRAYSIZE (bufRight) - 1]	= TEXT ('\0') ;
		
		pNode	= pCreateStringPair (bufLeft, bufRight) ;
		if (pNode == NULL) {
			vDestroyStringPairList (&plstStringPair) ;
			break ;
		}
		vInsertStringPair (&plstStringPair, pNode) ;
		if (*pwSrc != TEXT ('\0'))
			break ;
		pwSrc	++ ;
	}
	return	plstStringPair ;
}


LPWSTR
dlgGeneric_pEncodeStringPairList (
	struct TStringPairNode*	plstStringPair,
	int*					pnSize)
{
	struct TStringPairNode*	pNode ;
	int						n, nSize, nSizeData ;
	LPTSTR					pwData	= NULL ;

	pNode	= plstStringPair ;
	nSize	= 0 ;
	while (pNode != NULL) {
		nSize	+= iCountBSEncodedString (pNode->m_bufLeft)  + 2 /* \\ \0 */ ;
		nSize	+= iCountBSEncodedString (pNode->m_bufRight) + 2 /* \\ \0 */ ;
		nSize	++ ;	/* NUL */
		pNode	= pNode->m_pNext ;
	}
	nSize	++ ;	/* NUL */

	pwData		= (LPTSTR) MALLOC (sizeof (TCHAR) * nSize) ;
	nSizeData	= 0 ;
	if (pwData != NULL) {
		LPTSTR	pwDest	= pwData ;

		pNode	= plstStringPair ;
		while (pNode != NULL) {
			n	= iBSEncodeString (pwDest, pNode->m_bufLeft) ;	
			pwDest	+= n ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
			n	= iBSEncodeString (pwDest, pNode->m_bufRight) ;
			pwDest	+= n ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
			*pwDest ++	= TEXT ('\0') ;
			pNode	= pNode->m_pNext ;
		}
		*pwDest ++	= TEXT ('\0') ;
		nSizeData	= pwDest - pwData ;
	}
	if (pnSize != NULL)
		*pnSize	= nSizeData ;
	return	pwData ;
}

void
dlgGeneric_vLoadDefaultSetting (void)
{
	_bKanaModeWhenOpen		= TRUE ;
	_bEcho					= TRUE ;
	_iBracketParenType		= BRACKETPARENTP_DEFAULT ;
	_bCompositionAutoShift	= TRUE ;
	_bDeleteImpliesKakutei	= TRUE ;
	_bKakuteiEarly			= TRUE ;
	_bDateAd				= FALSE ;
	_iNumberStyle			= 0 ;
	_iKutoutenType			= KUTOUTEN_TYPE_JP ;
	_iOkuriCharAlistType	= OKURICHARTP_DEFAULT ;

	vDestroyStringPairList (&_plstBracketParens) ;
	_plstBracketParens	= NULL ;
	vDestroyStringPairList (&_plstKutoutens) ;
	_plstKutoutens		= NULL ;
	vDestroyStringPairList (&_plstOkuriCharAlist) ;
	_plstOkuriCharAlist	= NULL ;

	_bExistUserDefinedOkuriCharAlist	= FALSE ;
	_bExistUserDefinedBracketParen		= FALSE ;
	_bExistUserDefinedKutoutenList		= FALSE ;
	return ;
}

/*========================================================================
 *	���ʂ̃y�A���X�g����B
 */
struct TStringPairNode*
pCreateStringPair (
	LPCTSTR		strLeftt,
	LPCTSTR		strRight)
{
	struct TStringPairNode*	pNode ;

	if (strLeftt == NULL)
		return	NULL ;
	strRight	= (strRight == NULL)? TEXT ("") : strRight ;

	pNode	= (struct TStringPairNode*) MALLOC (sizeof (struct TStringPairNode)) ;
	if (pNode == NULL)
		return	NULL ;

	lstrcpyn (pNode->m_bufLeft,  strLeftt, ARRAYSIZE (pNode->m_bufLeft)) ;
	lstrcpyn (pNode->m_bufRight, strRight, ARRAYSIZE (pNode->m_bufRight)) ;
	pNode->m_pNext	= pNode->m_pPrev	= NULL ;
	return	pNode ;
}

struct TStringPairNode*
pCreateDefaultBracketParenList (void)
{
	static struct {
		LPCTSTR		m_strLeft ;
		LPCTSTR		m_strRight ;
	}	_rBracketParens []	= {
		{ TEXT("�u"),	TEXT("�v") },	{ TEXT("�w"),	TEXT("�x") },
		{ TEXT("("),	TEXT(")")  },	{ TEXT("�i"),	TEXT("�j") }, 
		{ TEXT("{"),	TEXT("}")  },	{ TEXT("�o"),	TEXT("�p") },
		{ TEXT("�q"),	TEXT("�r") },	{ TEXT("�s"),	TEXT("�t") },
		{ TEXT("["),	TEXT("]")  },	{ TEXT("�m"),	TEXT("�n") },
		{ TEXT("�k"),	TEXT("�l") },	{ TEXT("�y"),	TEXT("�z") }, 
		{ TEXT("\""),	TEXT("\"") },	{ TEXT("�g"),	TEXT("�h") },
		{ TEXT("`"),	TEXT("'")  }, 
	} ;
	struct TStringPairNode*	pTop ;
	struct TStringPairNode*	pNode ;
	struct TStringPairNode*	pPrevNode ;
	int		i ;

	pTop	= pCreateStringPair (_rBracketParens [0].m_strLeft, _rBracketParens [0].m_strRight) ;
	if (pTop == NULL)
		return	NULL ;
	pPrevNode	= pTop ;
	for (i = 1 ; i < ARRAYSIZE (_rBracketParens) ; i ++) {
		pNode	= pCreateStringPair (_rBracketParens [i].m_strLeft, _rBracketParens [i].m_strRight) ;
		if (pNode == NULL) {
			vDestroyStringPairList (&pTop) ;
			return	NULL ;
		}
		pPrevNode->m_pNext	= pNode ;
		pNode->m_pPrev		= pPrevNode ;
		pPrevNode			= pNode ;
	}
	return	pTop ;
}

struct TStringPairNode*
pCopyStringPairList (
	struct TStringPairNode*	plstStringPair)
{
	struct TStringPairNode*	pSrc ;
	struct TStringPairNode*	pNode ;
	struct TStringPairNode*	pNewTop ;
	struct TStringPairNode*	pPrevNode ;

	if (plstStringPair == NULL)
		return	NULL ;

	pSrc	= plstStringPair ;
	pNewTop	= pCreateStringPair (pSrc->m_bufLeft, pSrc->m_bufRight) ;
	if (pNewTop == NULL)
		return	NULL ;
	pSrc		= pSrc->m_pNext ;
	pPrevNode	= pNewTop ;
	while (pSrc != NULL) {
		pNode	= pCreateStringPair (pSrc->m_bufLeft, pSrc->m_bufRight) ;
		if (pNode == NULL) {
			vDestroyStringPairList (&pNewTop) ;
			return	NULL ;
		}
		pPrevNode->m_pNext	= pNode ;
		pNode->m_pPrev		= pPrevNode ;
		pPrevNode			= pNode ;
		pSrc	= pSrc->m_pNext ;
	}
	return	pNewTop ;
}

void
vDestroyStringPairList (
	struct TStringPairNode**	pplstStringPair)
{
	struct TStringPairNode*	pNextNode ;
	struct TStringPairNode*	pNode ;

	if (pplstStringPair == NULL)
		return ;

	pNode	= *pplstStringPair ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		FREE (pNode) ;
		pNode		= pNextNode ;
	}
	*pplstStringPair	= NULL ;
	return ;
}

struct TStringPairNode*
pFindStringPair  (
	struct TStringPairNode*		plstStringPair,
	LPCTSTR						strLBracket)
{
	struct TStringPairNode*	pNode ;

	if (strLBracket == NULL || plstStringPair == NULL)
		return	NULL ;

	pNode	= plstStringPair ;
	while (pNode != NULL) {
		if (! lstrcmp (pNode->m_bufLeft, strLBracket))
			return	pNode ;
		pNode	= pNode->m_pNext ;
	}
	return	NULL ;
}

void
vInsertStringPair (
	struct TStringPairNode**	pplstStringPair,
	struct TStringPairNode*		pNewNode)
{
	struct TStringPairNode*		pTop ;
	struct TStringPairNode*		pNode ;

	if (pplstStringPair == NULL || pNewNode == NULL)
		return ;

	pTop	= *pplstStringPair ;
	if (pTop != NULL) {
		pNode		= pTop ;
		while (pNode->m_pNext != NULL && pNode != pNewNode) {
			pNode	= pNode->m_pNext ;
		}
		if (pNode == pNewNode)
			return ;
		pNode->m_pNext		= pNewNode ;
		pNewNode->m_pPrev	= pNode ;
		pNewNode->m_pNext	= NULL ;
	} else {
		*pplstStringPair	= pNewNode ;
		pNewNode->m_pPrev	= pNewNode->m_pNext	= NULL ;
	}
	return ;
}

struct TStringPairNode*
pCreateDefaultKutoutenList (
	int							iKutoutenType)
{
	struct TStringPairNode*		pTop ;
	struct TStringPairNode*		pNodeJP ;
	struct TStringPairNode*		pNodeEN ;

	pNodeEN	= pCreateStringPair (TEXT ("�C"), TEXT ("�D")) ;
	pNodeJP	= pCreateStringPair (TEXT ("�A"), TEXT ("�B")) ;
	if (pNodeEN == NULL || pNodeJP == NULL) {
		FREE (pNodeEN) ;
		FREE (pNodeJP) ;
		return	NULL ;
	}
	if (iKutoutenType == KUTOUTEN_TYPE_JP) {
		pTop				= pNodeJP ;
		pNodeJP->m_pNext	= pNodeEN ;
		pNodeEN->m_pPrev	= pNodeJP ;
	} else {
		pTop				= pNodeEN ;
		pNodeEN->m_pNext	= pNodeJP ;
		pNodeJP->m_pPrev	= pNodeEN ;
	}
	return	pTop ;
}

/*========================================================================
 *	for IDD_EDIT_BRACKETLIST
 */
static	INT_PTR		dlgEditBracketList_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgEditBracketList_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	BOOL		dlgEditBracketList_bEditBracket		(HWND, int) ;
static	BOOL		dlgEditBracketList_bRemoveBracket	(HWND) ;
static	INT_PTR		CALLBACK	dlgEditBracketProc		(HWND, UINT, WPARAM, LPARAM) ;


INT_PTR	CALLBACK
dlgEditBracketListProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		return	dlgEditBracketList_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditBracketList_iOnCommand (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditBracketList_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditBracketParenListArg*	pArg ;
	HWND	hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pArg	= (struct TEditBracketParenListArg*) lParam ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_BRACKET) ;
	if (hwndControl != NULL) {
		LV_COLUMN	lvColumn ;

		memset (&lvColumn, 0, sizeof (lvColumn)) ;

		ListView_DeleteAllItems (hwndControl) ;
		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;

		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.cx			= 48 ;
		lvColumn.pszText	= TEXT ("�J����") ;
		ListView_InsertColumn (hwndControl, 0, &lvColumn) ;
		lvColumn.pszText	= TEXT ("������") ;
		ListView_InsertColumn (hwndControl, 1, &lvColumn) ;
	}
	if (pArg != NULL && hwndControl != NULL) {
		LVITEM					lvi ;
		struct TStringPairNode*	pNode ;
		int						nCount, nItem ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
		nCount	= 0 ;
		pNode	= pArg->m_plstBracketParen ;
		while (pNode != NULL) {
			lvi.iItem		= nCount ;
			lvi.iSubItem	= 0 ;
			lvi.pszText		= pNode->m_bufLeft ;
			lvi.lParam		= (LPARAM) pNode ;
			nItem	= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufRight) ;
				nCount	++ ;
			}
			pNode	= pNode->m_pNext ;
		}
	}
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditBracketList_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	/*WORD	woNotification	= HIWORD (wParam) ;*/

	switch (woControl) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		dlgEditBracketList_bEditBracket (hDlg, woControl) ;
		break ;
	case	IDC_BUTTON_REMOVE:
		dlgEditBracketList_bRemoveBracket (hDlg) ;
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

BOOL
dlgEditBracketList_bEditBracket (
	HWND			hDlg,
	int				nControlId)
{
	struct TEditBracketParenListArg*	pArg ;
	struct TStringPairNode		arg ;
	struct TStringPairNode*		pNode			= NULL ;
	struct TStringPairNode*		pNodeOverride	= NULL ;
	HWND		hwndControl ;
	HINSTANCE	hInst ;

	pArg		= (struct TEditBracketParenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hInst		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_BRACKET) ;
	if (hwndControl == NULL)
		return	FALSE ;

	memset (&arg, 0, sizeof (arg)) ;
	if (nControlId == IDC_BUTTON_EDIT) {
		int		nCurSel ;

		nCurSel	= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel != -1) {
			LVITEM	lvi ;
			memset (&lvi, 0, sizeof (lvi)) ;
			lvi.iItem		= nCurSel ;
			lvi.iSubItem	= 0 ;
			lvi.mask		= LVIF_PARAM ;
			if (ListView_GetItem (hwndControl, &lvi)) {
				pNode	= (struct TStringPairNode*) lvi.lParam ;

				lstrcpyn (arg.m_bufLeft,  pNode->m_bufLeft,  ARRAYSIZE (arg.m_bufLeft)) ;
				lstrcpyn (arg.m_bufRight, pNode->m_bufRight, ARRAYSIZE (arg.m_bufRight)) ;
			}
		}
	}
	if (DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_BRACKET), hDlg, dlgEditBracketProc, (LPARAM) &arg) != IDOK) 
		return	TRUE ;
	if (arg.m_bufLeft [0] == TEXT ('\0')) {
		(void) MessageBox (hDlg, TEXT ("���ʂ��w�肳��Ă��܂���B"), TEXT ("�x��"), MB_OK) ;
		return	TRUE ;
	}

	/*	�ǉ��̏ꍇ�͉������Ȃ��Ă��ǂ����A�u�������̏ꍇ�ɂ� MessageBox �ŋ������߂�B�����L�[�� LBRACKET */
	pNodeOverride	= pFindStringPair  (pArg->m_plstBracketParen, arg.m_bufLeft) ;
	if (pNodeOverride != NULL) {
		/* �����ɓ������Ƃ������Ƃ́ALBRACKET �Ɋ��ɓ���������������� node �����݂���Ƃ������ƁB*/
		if (pNodeOverride != pNode) {
			TCHAR	bufText [256] ;
			int		n ;
			n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���Ɋ���``%s''�ɂ͕�����``%s''���Ή��t�����Ă��܂��B������``%s''�Œu�������܂����H"), pNodeOverride->m_bufLeft, pNodeOverride->m_bufRight, arg.m_bufRight) ;
			if (MessageBox (hDlg, bufText, TEXT ("�x��"), MB_YESNO) != IDYES)
				return	TRUE ;
			lstrcpyn (pNodeOverride->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNodeOverride->m_bufRight)) ;
		} else {
			lstrcpyn (pNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNode->m_bufRight)) ;
		}
		/* �\���� update ����B*/
	} else {
		/* pNode != NULL �Ȃ�ύX�B�ύX�Ƃ������Ƃł���΁A�ȑO�̃m�[�h��u�������Ȃ���΁B*/
		if (pNode != NULL) {
			lstrcpyn (pNode->m_bufLeft,  arg.m_bufLeft,  ARRAYSIZE (pNode->m_bufLeft)) ;
			lstrcpyn (pNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNode->m_bufRight)) ;
		} else {
			struct TStringPairNode*	pNewNode ;

			/* �������̂��Ȃ� => �ǉ�����B*/
			pNewNode	= pCreateStringPair (arg.m_bufLeft, arg.m_bufRight) ;
			if (pNewNode != NULL) {
				LVITEM	lvi ;
				int		nItem ;

				vInsertStringPair (&pArg->m_plstBracketParen, pNewNode) ;

				/* ListView �ɒǉ��B*/
				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.mask		= LVIF_TEXT | LVIF_PARAM ;
				lvi.iItem		= ListView_GetItemCount (hwndControl) ;
				lvi.iSubItem	= 0 ;
				lvi.pszText		= pNewNode->m_bufLeft ;
				nItem			= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					ListView_SetItemText (hwndControl, nItem, 1, pNewNode->m_bufRight) ;
				}
			}
		}
	}
	return	TRUE ;
}

BOOL
dlgEditBracketList_bRemoveBracket (
	HWND			hDlg)
{
	struct TEditBracketParenListArg*	pArg ;
	int		nCurSel, n ;
	LVITEM	lvi ;
	struct TStringPairNode*	pNode ;
	struct TStringPairNode*	pPrevNode ;
	struct TStringPairNode*	pNextNode ;
	HWND	hwndControl ;
	TCHAR	bufText [256] ;

	pArg		= (struct TEditBracketParenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_BRACKET) ;
	if (hwndControl == NULL)
		return	FALSE ;

	nCurSel	= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1) 
		return	FALSE ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	lvi.mask		= LVIF_PARAM ;
	if (! ListView_GetItem (hwndControl, &lvi)) 
		return	FALSE ;
	pNode		= (struct TStringPairNode*) lvi.lParam ;
	if (pNode == NULL)
		return	FALSE ;

	n			= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("``%s''��``%s''�̃y�A���폜���܂��B��낵���ł����H"), pNode->m_bufLeft, pNode->m_bufRight) ;
	bufText [n]	= TEXT ('\0') ;
	if (MessageBox (hDlg, bufText, TEXT ("���ʁA�����ʂ̍폜�m�F"), MB_YESNO) != IDYES) 
		return	TRUE ;

	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext	= pNextNode ;
	} else {
		pArg->m_plstBracketParen	= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pPrevNode ;
	}
	FREE (pNode) ;

	ListView_DeleteItem (hwndControl, nCurSel) ;
	return	TRUE ;
}

/*========================================================================
 *	for IDD_EDIT_BRACKET
 */
INT_PTR	CALLBACK
dlgEditBracketProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		{
			struct TStringPairNode*	pArg	= (struct TStringPairNode*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pArg) ;

			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_LBRACKET) ;
			if (hwndControl != NULL) 
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufLeft), (LPARAM) 0) ;
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_RBRACKET) ;
			if (hwndControl != NULL) 
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufRight), (LPARAM) 0) ;
			if (pArg != NULL) {
				SetDlgItemText (hDlg, IDC_EDIT_LBRACKET, pArg->m_bufLeft) ;
				SetDlgItemText (hDlg, IDC_EDIT_RBRACKET, pArg->m_bufRight) ;
			}
		}
		return	(INT_PTR) TRUE ;

	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			/*WORD	woNotification	= HIWORD (wParam) ;*/
			switch (woControl) {
			case	IDOK:
				{
					struct TStringPairNode*	pArg ;

					pArg	= (struct TStringPairNode*) GetWindowLongPtr (hDlg, DWLP_USER) ;
					if (pArg != NULL) {
						GetDlgItemText (hDlg, IDC_EDIT_LBRACKET, pArg->m_bufLeft, ARRAYSIZE (pArg->m_bufLeft)) ;
						GetDlgItemText (hDlg, IDC_EDIT_RBRACKET, pArg->m_bufRight, ARRAYSIZE (pArg->m_bufRight)) ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				break ;
			default:
				break ;
			}
		}
		return	(INT_PTR) 1 ;

	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*========================================================================
 *	for IDD_EDIT_KUTOUTENLIST
 */
static	INT_PTR		dlgEditKutoutenList_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgEditKutoutenList_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgEditKutoutenList_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	BOOL		dlgEditKutoutenList_bEditKutouten	(HWND, int) ;
static	BOOL		dlgEditKutoutenList_bChangeKutoutenOrder	(HWND, BOOL) ;
static	BOOL		dlgEditKutoutenList_bRemoveKutouten	(HWND) ;
static	void		dlgEditKutoutenList_vUpdateKutoutenItem	(HWND, int, struct TStringPairNode*) ;
static	INT_PTR	CALLBACK	dlgEditKutoutenProc			(HWND, UINT, WPARAM, LPARAM) ;


INT_PTR	CALLBACK
dlgEditKutoutenListProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		return	dlgEditKutoutenList_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditKutoutenList_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditKutoutenList_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}


INT_PTR
dlgEditKutoutenList_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditKutoutenListArg*	pArg ;
	HINSTANCE		hInst ;
	HWND			hwndControl, hwndButton ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	pArg		= (struct TEditKutoutenListArg*) lParam ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl != NULL) {
		LV_COLUMN			lvColumn;
		static	LPTSTR		rpText []	= { TEXT ("����"), TEXT ("�Ǔ_"), TEXT ("��_") } ;
		int					i ;

		ListView_DeleteAllItems (hwndControl) ;
		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;
		memset (&lvColumn, 0, sizeof (lvColumn)) ;
		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.cx			= 48 ;
		for (i = 0 ; i < ARRAYSIZE (rpText) ; i ++) {
			lvColumn.pszText	= rpText [i] ;
			ListView_InsertColumn (hwndControl, i, &lvColumn) ;
		}
	}
	if (pArg != NULL && hwndControl != NULL) {
		struct TStringPairNode*	pNode	= NULL ;
		LVITEM		lvi ;
		int			nItem, nCount ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM ;
		nCount		= 0 ;
		pNode		= pArg->m_plstKutouten ;
		while (pNode != NULL) {
			lvi.iItem		= nCount ;
			lvi.iSubItem	= 0 ;
			lvi.lParam		= (LPARAM) pNode ;
			nItem			= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				TCHAR	bufText [16] ;
				int		n ;
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d:"), nCount) ;
				bufText [n]	= TEXT ('\0') ;
				ListView_SetItemText (hwndControl, nItem, 0, bufText) ;
				ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufLeft) ;
				ListView_SetItemText (hwndControl, nItem, 2, pNode->m_bufRight) ;
			}
			nCount	++ ;
			pNode	= pNode->m_pNext ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWUP) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWUP), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowUp		= hIcon ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWDOWN) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWDOWN), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowDown	= hIcon ;
		}
	}
#if 1
	EnableDlgItem (hDlg, IDC_BUTTON_EDIT,		FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_DELETE,		FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,	FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,	FALSE) ;
#endif
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditKutoutenList_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	/*WORD	woNotification	= HIWORD (wParam) ;*/

	switch (woControl) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		dlgEditKutoutenList_bEditKutouten (hDlg, woControl) ;
		break ;

	case	IDC_BUTTON_DELETE:
		dlgEditKutoutenList_bRemoveKutouten (hDlg) ;
		break ;
	case	IDC_BUTTON_ARROWUP:
	case	IDC_BUTTON_ARROWDOWN:
		dlgEditKutoutenList_bChangeKutoutenOrder (hDlg, woControl == IDC_BUTTON_ARROWUP) ;
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditKutoutenList_iOnNotify (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_KUTOUTEN:
		{
			switch (pNMHDR->code) {
			case	NM_SETFOCUS:
			case	NM_CLICK:
			case	NM_RCLICK:
			case	LVN_ITEMCHANGED:
				{
					HWND	hwndControl ;
					int		nCurSel ;

					hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
					if (hwndControl == NULL)
						break ;
					nCurSel	= ListView_GetSelectionMark (hwndControl) ;
					EnableDlgItem (hDlg, IDC_BUTTON_EDIT,		(nCurSel != -1)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_DELETE,		(nCurSel != -1)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,	(nCurSel > 0)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,	(0 <= nCurSel && nCurSel < ListView_GetItemCount (hwndControl)-1)) ;
				}
				if (pNMHDR->code == NM_RCLICK) {
					/* �ǉ��A�ύX�A�폜�� Context ���j���[�̕\���B*/
					static struct TMENUITEM 	rmi []	= {
						{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ǉ�"), IDC_BUTTON_ADD, },
						{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ύX"), IDC_BUTTON_EDIT, },
						{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�폜"), IDC_BUTTON_DELETE, },
					} ;
					/*NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;*/
					int				iCode ;

					iCode	= iPopupMenu (hDlg, rmi, ARRAYSIZE (rmi)) ;
					switch (iCode) {
					case	IDC_BUTTON_ADD:
					case	IDC_BUTTON_EDIT:
						dlgEditKutoutenList_bEditKutouten (hDlg, iCode) ;
						break ;
					case	IDC_BUTTON_DELETE:
						dlgEditKutoutenList_bRemoveKutouten (hDlg) ;	
						break ;
					default:
						break ;
					}
				}
				break ;
			case	NM_KILLFOCUS:
			case	NM_DBLCLK:
				break ;
			default:
				break ;
			}
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 0 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
dlgEditKutoutenList_bEditKutouten (
	HWND			hDlg,
	int				nControlId)
{
	struct TEditKutoutenListArg*	pArg ;
	struct TStringPairNode	arg ;
	struct TStringPairNode*	pNode	= NULL ;
	HINSTANCE	hInst ;
	HWND		hwndControl ;
	int			nResult, nCurSel ;

	hInst		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pArg		= (struct TEditKutoutenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;

	nCurSel		= -1 ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl == NULL)
		return	FALSE ;

	memset (&arg, 0, sizeof (arg)) ;
	if (nControlId == IDC_BUTTON_EDIT) {
		LVITEM	lvi ;

		nCurSel	= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel != -1) {
			memset (&lvi, 0, sizeof (lvi)) ;
			lvi.iItem		= nCurSel ;
			lvi.iSubItem	= 0 ;
			lvi.mask		= LVIF_PARAM ;
			if (ListView_GetItem (hwndControl, &lvi)) {
				pNode	= (struct TStringPairNode*) lvi.lParam ;
				if (pNode != NULL) {
					lstrcpyn (arg.m_bufLeft,  pNode->m_bufLeft,  ARRAYSIZE (arg.m_bufLeft)) ;
					lstrcpyn (arg.m_bufRight, pNode->m_bufRight, ARRAYSIZE (arg.m_bufRight)) ;
				}
			}
		}
	}
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_KUTOUTEN), hDlg, dlgEditKutoutenProc, (LPARAM) &arg) ;
	if (nResult != IDOK)
		return	TRUE ;

	/* �ҏW�c�B*/
	if (pNode != NULL) {
		lstrcpyn (pNode->m_bufLeft,  arg.m_bufLeft,  ARRAYSIZE (pNode->m_bufLeft)) ;
		lstrcpyn (pNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNode->m_bufRight)) ;
		/* �\�����X�V����B*/
		dlgEditKutoutenList_vUpdateKutoutenItem (hwndControl, nCurSel, pNode) ;
	} else {
		struct TStringPairNode*	pNewNode ;
		LVITEM	lvi ;
		int		nItem ;

		/* �ǉ��B*/
		pNewNode	= pCreateStringPair (arg.m_bufLeft, arg.m_bufRight) ;
		if (pNewNode == NULL)
			return	FALSE ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask		= LVIF_PARAM ;
		lvi.iItem		= ListView_GetItemCount (hwndControl) ;
		lvi.iSubItem	= 0 ;
		lvi.lParam		= (LPARAM) pNewNode ;
		nItem		= ListView_InsertItem (hwndControl, &lvi) ;
		if (nItem == -1) {
			FREE (pNewNode) ;
			return	FALSE ;
		}
		vInsertStringPair (&pArg->m_plstKutouten, pNewNode) ;
		dlgEditKutoutenList_vUpdateKutoutenItem (hwndControl, nItem, pNewNode) ;
	}
	return	TRUE ;
}

BOOL
dlgEditKutoutenList_bChangeKutoutenOrder (
	HWND			hDlg,
	BOOL			bUp)
{
	struct TEditKutoutenListArg*	pArg ;
	HWND	hwndControl ;
	LVITEM	lvi ;
	int		nCurSel, nPrevItem, nItem ;
	struct TStringPairNode*	pPrevNode ;
	struct TStringPairNode*	pNode ;

	pArg		= (struct TEditKutoutenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl == NULL)
		return	FALSE ;
	nCurSel	= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1)
		return	FALSE ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	lvi.mask		= LVIF_PARAM ;
	if (! ListView_GetItem (hwndControl, &lvi))
		return	FALSE ;
	pNode			= (struct TStringPairNode*) lvi.lParam ;

	if (bUp) {
		pPrevNode	= pNode->m_pPrev ;
		if (pPrevNode == NULL)
			return	FALSE ;
		nPrevItem	= nCurSel - 1 ;
		nItem		= nCurSel ;
	} else {
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
		if (pNode == NULL)
			return	FALSE ;
		nPrevItem	= nCurSel ;
		nItem		= nCurSel + 1 ;
	}
	pNode->m_pPrev				= pPrevNode->m_pPrev ;
	if (pPrevNode->m_pPrev != NULL) {
		pPrevNode->m_pPrev->m_pNext	= pNode ;
	} else {
		/* ���X�g�̐擪�̌����B*/
		pArg->m_plstKutouten	= pNode ;
	}

	pPrevNode->m_pNext			= pNode->m_pNext ;
	if (pNode->m_pNext != NULL)
		pNode->m_pNext->m_pPrev		= pPrevNode ;

	pNode->m_pNext				= pPrevNode ;
	pPrevNode->m_pPrev			= pNode ;

	/* ListView �̍X�V�B*/
	lvi.mask		= LVIF_PARAM | LVIF_STATE ;
	lvi.iItem		= nItem ;
	lvi.lParam		= (LPARAM) pPrevNode ;
	lvi.state		= bUp? 0 : LVIS_SELECTED ;
	lvi.stateMask	= LVIS_SELECTED ;
	ListView_SetItem (hwndControl, &lvi) ;
	ListView_SetItemText (hwndControl, nItem, 1, pPrevNode->m_bufLeft) ;
	ListView_SetItemText (hwndControl, nItem, 2, pPrevNode->m_bufRight) ;
	lvi.iItem		= nPrevItem ;
	lvi.lParam		= (LPARAM) pNode ;
	lvi.state		= bUp? LVIS_SELECTED : 0 ;
	lvi.stateMask	= LVIS_SELECTED ;
	ListView_SetItem (hwndControl, &lvi) ;
	ListView_SetItemText (hwndControl, nPrevItem, 1, pNode->m_bufLeft) ;
	ListView_SetItemText (hwndControl, nPrevItem, 2, pNode->m_bufRight) ;

	nCurSel			= bUp? nPrevItem : nItem ;
	ListView_SetSelectionMark (hwndControl, nCurSel) ;
	ListView_Update (hwndControl, nPrevItem) ;
	ListView_Update (hwndControl, nItem) ;

	EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,	(nCurSel > 0)) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,	(0 <= nCurSel && nCurSel < ListView_GetItemCount (hwndControl)-1)) ;
	return	TRUE ;
}

BOOL
dlgEditKutoutenList_bRemoveKutouten	(
	HWND			hDlg)
{
	struct TEditKutoutenListArg*	pArg ;
	HWND	hwndControl ;
	TCHAR	bufText [256] ;
	int		nCurSel, n ;
	LVITEM	lvi ;
	struct TStringPairNode*	pNode ;
	struct TStringPairNode*	pNextNode ;
	struct TStringPairNode*	pPrevNode ;

	pArg		= (struct TEditKutoutenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl == NULL)
		return	FALSE ;
	nCurSel	= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1)
		return	FALSE ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	lvi.mask		= LVIF_PARAM ;
	if (! ListView_GetItem (hwndControl, &lvi)) 
		return	FALSE ;
	pNode			= (struct TStringPairNode*) lvi.lParam ;
	if (pNode == NULL)
		return	FALSE ;
	n				= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("��_�u%s�v�Ǔ_�u%s�v���폜���܂��B��낵���ł����H"), pNode->m_bufLeft, pNode->m_bufRight) ;
	bufText [n]		= TEXT ('\0') ;
	if (MessageBox (hDlg, bufText, TEXT ("��Ǔ_�̍폜�m�F"), MB_YESNO) != IDYES)
		return	TRUE ;

	pPrevNode		= pNode->m_pPrev ;
	pNextNode		= pNode->m_pNext ;
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext	= pNextNode ;
	} else {
		pArg->m_plstKutouten	= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pPrevNode ;
	}
	FREE (pNode) ;

	ListView_DeleteItem (hwndControl, nCurSel) ;

	/*	��Ǔ_�̔ԍ�[%d:]��ύX����B*/
	while (nCurSel < ListView_GetItemCount (hwndControl)) {
		lvi.iItem		= nCurSel ;
		lvi.iSubItem	= 0 ;
		lvi.mask		= LVIF_PARAM ;
		if (! ListView_GetItem (hwndControl, &lvi)) 
			break ;
		pNode	= (struct TStringPairNode*) lvi.lParam ;
		if (pNode != NULL)
			dlgEditKutoutenList_vUpdateKutoutenItem (hwndControl, nCurSel, pNode) ;
		nCurSel	++ ;
	}
	return	TRUE ;
}

void
dlgEditKutoutenList_vUpdateKutoutenItem (
	HWND					hwndControl,
	int						nItem,
	struct TStringPairNode*	pNode)
{
	TCHAR	bufText [16] ;
	int		n ;

	if (hwndControl == NULL || ! IsWindow (hwndControl) || pNode == NULL)
		return ;

	n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d:"), nItem) ;
	bufText [n]	= TEXT ('\0') ;
	ListView_SetItemText (hwndControl, nItem, 0, bufText) ;
	ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufLeft) ;
	ListView_SetItemText (hwndControl, nItem, 2, pNode->m_bufRight) ;
	return ;
}


INT_PTR	CALLBACK
dlgEditKutoutenProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		{
			struct TStringPairNode*	pArg	= (struct TStringPairNode*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_KUTEN) ;
			if (hwndControl != NULL) 
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufLeft), 0) ;
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_TOUTEN) ;
			if (hwndControl != NULL)
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufRight), 0) ;
			if (pArg != NULL) {
				SetDlgItemText (hDlg, IDC_EDIT_KUTEN,  pArg->m_bufLeft) ;
				SetDlgItemText (hDlg, IDC_EDIT_TOUTEN, pArg->m_bufRight) ;
			}
		}
		return	(INT_PTR) TRUE ;

	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			/*WORD	woNotification	= HIWORD (wParam) ;*/
			switch (woControl) {
			case	IDOK:
				{
					struct TStringPairNode*	pArg	= (struct TStringPairNode*) GetWindowLongPtr (hDlg, DWLP_USER) ;

					if (pArg != NULL) {
						GetDlgItemText (hDlg, IDC_EDIT_KUTEN,  pArg->m_bufLeft,  ARRAYSIZE (pArg->m_bufLeft)) ;
						GetDlgItemText (hDlg, IDC_EDIT_TOUTEN, pArg->m_bufRight, ARRAYSIZE (pArg->m_bufRight)) ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, woControl) ;
				break ;
			default:
				break ;
			}
		}
		return	(INT_PTR) 1 ;

	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*========================================================================
 *	private functions for IDD_EDIT_OKURICHARALIST
 */
static	INT_PTR	dlgEditOkuriCharAlist_iOnInitDialog (HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditOkuriCharAlist_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditOkuriCharAlist_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void	dlgEditOkuriCharAlist_vEditOkuriCharPair	(HWND, int) ;

static	INT_PTR	CALLBACK	dlgEditOkuriCharPairProc (HWND, UINT, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
dlgEditOkuriCharAlistProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		return	dlgEditOkuriCharAlist_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditOkuriCharAlist_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditOkuriCharAlist_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditOkuriCharAlist_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditOkuriCharAlistArg*	pArg	= (struct TEditOkuriCharAlistArg*) lParam ;
	HWND	hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_OKURICHARALIST) ;
	if (hwndControl != NULL) {
		LV_COLUMN	lvColumn ;

		memset (&lvColumn, 0, sizeof (lvColumn)) ;

		ListView_DeleteAllItems (hwndControl) ;
		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;

		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.cx			= 80 ;
		lvColumn.pszText	= TEXT ("�ǂݑւ���") ;
		ListView_InsertColumn (hwndControl, 0, &lvColumn) ;
		lvColumn.pszText	= TEXT ("�ǂݑւ���") ;
		ListView_InsertColumn (hwndControl, 1, &lvColumn) ;
	}
	if (hwndControl != NULL && pArg != NULL) {
		struct TStringPairNode*	pNode	= pArg->m_plstOkuriCharPair ;
		LVITEM	lvi ;
		int		nCount, nItem ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
		nCount		= 0 ;
		while (pNode != NULL) {
			lvi.iItem	= nCount ;
			lvi.pszText	= pNode->m_bufLeft ;
			lvi.lParam	= (LPARAM) pNode ;
			nItem		= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufRight) ;
				nCount	++ ;
			}
			pNode		= pNode->m_pNext ;
		}
	}
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditOkuriCharAlist_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	/*WORD	woNotification	= HIWORD (wParam) ;*/

	switch (woControl) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
	case	IDC_BUTTON_DELETE:
		dlgEditOkuriCharAlist_vEditOkuriCharPair (hDlg, woControl) ;
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditOkuriCharAlist_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_OKURICHARALIST:
		{
			switch (pNMHDR->code) {
			case	NM_SETFOCUS:
			case	NM_CLICK:
			case	NM_RCLICK:
			case	LVN_ITEMCHANGED:
				{
					HWND	hwndControl	= pNMHDR->hwndFrom ;
					int		nCurSel ;

					nCurSel	= ListView_GetSelectionMark (hwndControl) ;
					EnableDlgItem (hDlg, IDC_BUTTON_EDIT,		(nCurSel != -1)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_DELETE,		(nCurSel != -1)) ;
				}
			default:
				break ;
			}
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgEditOkuriCharAlist_vEditOkuriCharPair (
	HWND			hDlg,
	int				iControlId)
{
	struct TEditOkuriCharAlistArg*	pArg ;
	struct TStringPairNode	arg ;
	struct TStringPairNode*	pCurNode ;
	HWND			hwndControl ;
	LVITEM			lvi ;
	TCHAR			bufText [256] ;
	int				nText, nCurSel ;

	pArg		= (struct TEditOkuriCharAlistArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_OKURICHARALIST) ;
	if (hwndControl == NULL || pArg == NULL)
		return ;

	if (iControlId != IDC_BUTTON_ADD) {
		nCurSel		= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel == -1)
			return ;
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.iItem	= nCurSel ;
		lvi.mask	= LVIF_PARAM ;
		if (! ListView_GetItem (hwndControl, &lvi))
			return ;	/* error */
		pCurNode	= (struct TStringPairNode*) lvi.lParam ;
		if (pCurNode == NULL)
			return ;	/* error */
		lstrcpyn (arg.m_bufLeft,  pCurNode->m_bufLeft,  ARRAYSIZE (arg.m_bufLeft)) ;
		lstrcpyn (arg.m_bufRight, pCurNode->m_bufRight, ARRAYSIZE (arg.m_bufRight)) ;
	} else {
		nCurSel		= -1 ;
		arg.m_bufLeft [0]	= arg.m_bufRight [0]	= TEXT ('\0') ;
		pCurNode	= NULL ;
	}
	arg.m_pPrev			= arg.m_pNext			= NULL ;

	switch (iControlId) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		{
			HINSTANCE				hInst ;
			int						nResult ;
			struct TStringPairNode*	pNodeOverride ;

			hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
			nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_OKURICHARPAIR), hDlg, dlgEditOkuriCharPairProc, (LPARAM) &arg) ;
			if (nResult != IDOK)
				return ;
			if (arg.m_bufLeft [0] == TEXT ('\0') || arg.m_bufRight [0] == TEXT ('\0')) {
				(void) MessageBox (hDlg, TEXT ("���艼���ɋ󕶎�����w�肷�邱�Ƃ͂ł��܂���B"), TEXT ("�G���["), MB_OK) ;
				return ;
			}
			pNodeOverride	= pFindStringPair (pArg->m_plstOkuriCharPair, arg.m_bufLeft) ;
			if ((iControlId == IDC_BUTTON_ADD  && pNodeOverride != NULL) ||
				(iControlId == IDC_BUTTON_EDIT && pNodeOverride != NULL && pNodeOverride != pCurNode)) { 
				nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���艼�� ``%s'' �̓ǂݑւ��͊��� ``%s'' �ɐݒ肳��Ă��܂��B"), pNodeOverride->m_bufLeft, pNodeOverride->m_bufRight) ;
				bufText [nText]	= TEXT ('\0') ;
				(void) MessageBox (hDlg, bufText, TEXT ("�G���["), MB_OK) ;
				return ;
			}
			if (pNodeOverride == NULL) {
				struct TStringPairNode*	pNewNode ;
				int		nItem ;

				pNewNode	= pCreateStringPair (arg.m_bufLeft, arg.m_bufRight) ;
				if (pNewNode == NULL)
					return ;

				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.iItem	= ListView_GetItemCount (hwndControl) ;
				lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
				lvi.pszText	= pNewNode->m_bufLeft ;
				lvi.lParam	= (LPARAM) pNewNode ;
				nItem		= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					ListView_SetItemText (hwndControl, nItem, 1, pNewNode->m_bufRight) ;
					vInsertStringPair (&pArg->m_plstOkuriCharPair, pNewNode) ;
				} else {
					FREE (pNewNode) ;
				}
			} else {
				lstrcpyn (pCurNode->m_bufLeft,  arg.m_bufLeft,  ARRAYSIZE (pCurNode->m_bufLeft)) ;
				lstrcpyn (pCurNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pCurNode->m_bufRight)) ;
				ListView_SetItemText (hwndControl, nCurSel, 0, pCurNode->m_bufLeft) ;
				ListView_SetItemText (hwndControl, nCurSel, 1, pCurNode->m_bufRight) ;
			}
		}
		break ;
	case	IDC_BUTTON_DELETE:
		{
			struct TStringPairNode*	pPrevNode ;
			struct TStringPairNode*	pNextNode ;

			if (pCurNode == NULL)
				break ;

			nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���艼���̓ǂݑւ��K�� ``%s'' �� ``%s'' �Ƃ��ď�������A���폜���܂��B��낵���ł����H"), pCurNode->m_bufLeft, pCurNode->m_bufRight) ;
			bufText [nText]	= TEXT ('\0') ;
			if (MessageBox (hDlg, bufText, TEXT ("�m�F"), MB_YESNO) != IDYES)
				return ;

			pPrevNode	= pCurNode->m_pPrev ;
			pNextNode	= pCurNode->m_pNext ;
			if (pPrevNode == NULL) {
				pArg->m_plstOkuriCharPair	= pNextNode ;
			} else {
				pPrevNode->m_pNext			= pNextNode ;
			}
			if (pNextNode != NULL) {
				pNextNode->m_pPrev	= pCurNode->m_pPrev ;
			}
			FREE (pCurNode) ;
		}
		break ;
	default:
		break ;
	}
	return ;
}


INT_PTR	CALLBACK
dlgEditOkuriCharPairProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		{
			struct TStringPairNode*	pArg	= (struct TStringPairNode*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
			if (pArg != NULL) {
				SetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_SRC,  pArg->m_bufLeft) ;
				SetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_DEST, pArg->m_bufRight) ;
			}
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_OKURICHAR_SRC) ;
			if (hwndControl != NULL) {
				(void) SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufLeft), (LPARAM) 0) ;
			}
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_OKURICHAR_DEST) ;
			if (hwndControl != NULL) {
				(void) SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufRight), (LPARAM) 0) ;
			}
		}
		return	(INT_PTR) TRUE ;
	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			/*WORD	woNotification	= HIWORD (wParam) ;	*/
	
			switch (woControl) {
			case	IDOK:
				{
					struct TStringPairNode*	pArg ;
					
					pArg	= (struct TStringPairNode*) GetWindowLongPtr (hDlg, DWLP_USER) ;
					if (pArg != NULL) {
						GetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_SRC,  pArg->m_bufLeft,  ARRAYSIZE (pArg->m_bufLeft)) ;
						GetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_DEST, pArg->m_bufRight, ARRAYSIZE (pArg->m_bufRight)) ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				break ;
			default:
				break ;
			}
		}
		return	(INT_PTR) 1 ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}


