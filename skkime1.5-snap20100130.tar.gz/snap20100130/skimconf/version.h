#if !defined (version_h)
#define	version_h

#define	SKKIME_VERSION	TEXT("SKKIME1.5(build:20100130)")
#endif
