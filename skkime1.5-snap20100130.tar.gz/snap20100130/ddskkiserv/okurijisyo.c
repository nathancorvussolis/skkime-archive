#include "local.h"
#include <stdio.h>
#include <stdlib.h>
#include "jisyo.h"
#include "okurijisyo.h"
#include "localjisyo.h"

static	BOOL	okuriSearchJisyo_bSearch	(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
static	BOOL	okuriSearchJisyo_bDestroy	(SkkJisyo*) ;

static SkkJisyoFunc		sOkuriSearchJisyoProcTbl	= {
	okuriSearchJisyo_bSearch,
	NULL,
	NULL,
	NULL,
	NULL,
	okuriSearchJisyo_bDestroy,
	NULL,
} ;

SkkJisyo*
SkkOkuriSearchJisyo_Create (
	SkkJisyo*				pLocalJisyo)
{
	SkkJisyo*				pJisyo ;
	SkkOkuriSearchJisyo*	pOkuriJisyo ;

	pJisyo	= MALLOC (sizeof (SkkJisyo) + sizeof (SkkOkuriSearchJisyo)) ;
	if (pJisyo == NULL)
		return	NULL ;

	pOkuriJisyo	= (SkkOkuriSearchJisyo*) (pJisyo + 1) ;

	pJisyo->m_pVtbl				= &sOkuriSearchJisyoProcTbl ;
	pOkuriJisyo->m_pLocalJisyo	= pLocalJisyo ;
	return	pJisyo ;
}

BOOL
okuriSearchJisyo_bSearch (
	SkkJisyo*		pSkkJisyo,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	TVarbuffer*		pvbuf)
{
	SkkOkuriSearchJisyo*	pOkuriJisyo ;

	if (pSkkJisyo == NULL || nOkuriType != SEARCH_OKURI_AUTO)
		return	TRUE ;

	pOkuriJisyo	= (SkkOkuriSearchJisyo*) (pSkkJisyo + 1) ;
	if (pOkuriJisyo == NULL)
		return	TRUE ;

	return	SkkLocalJisyo_bOkuriSearch (pOkuriJisyo->m_pLocalJisyo, pKey, nKey, pOkurigana, nOkurigana, nOkuriType, pvbuf) ;
}


BOOL
okuriSearchJisyo_bDestroy (
	SkkJisyo*		pSkkJisyo)
{
	if (pSkkJisyo == NULL)
		return	TRUE ;
	FREE (pSkkJisyo) ;
	return	TRUE ;
}

