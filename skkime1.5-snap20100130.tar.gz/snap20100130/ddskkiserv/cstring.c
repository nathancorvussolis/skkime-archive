#include "cstring.h"
#include <assert.h>
#if defined (UNIT_TEST)
#include <stdio.h>
#include <string.h>
#endif

static	int		quoteCstringSub	(Char*, const Char*, int) ;
static	BOOL	needQuotep (const Char*, int, BOOL) ;

typedef struct tagCHARSTRPAIR {
	int			m_chara ;
	LPCTSTR		m_pString ;
}	CHARSTRPAIR ;

int
Cstrlen (
	register const Char* pCstring)
{
	register int		iLength ;

	assert (pCstring != NULL);

	iLength	= 0 ;
	while (!Char_IsNul (*pCstring)) {
		pCstring	++ ;
		iLength		++ ;
	}
	return	iLength ;
}

int
Cstrcmp (
	register const Char*	pCstring1,
	register const Char*	pCstring2)
{
	register int	iDifference ;

	assert (pCstring1 != NULL) ;
	assert (pCstring2 != NULL) ;

	while (iDifference = Char_Difference (*pCstring1, *pCstring2),
		   iDifference == 0 && !Char_IsNul (*pCstring1)) {
		pCstring1	++ ;
		pCstring2	++ ;
	}

	return	iDifference ;
}

int
Cstrncmp (
	register const Char*	pCstring1,
	register const Char*	pCstring2,
	register int			n)
{
	register int	iDifference ;

	assert (pCstring1 != NULL) ;
	assert (pCstring2 != NULL) ;

	iDifference	= 0 ;

	while (n > 0) {
		iDifference = Char_Difference (*pCstring1, *pCstring2) ;
		if (iDifference != 0 || Char_IsNul (*pCstring1))
			break ;
		pCstring1	++ ;
		pCstring2	++ ;
		n			-- ;
	}

	return	iDifference ;
}

int
Cstrnccmp (
	register const Char*	pCstring1,
	register const char*	pString2,
	register int			n)
{
	register int	iDifference ;

	assert (pCstring1 != NULL) ;
	assert (pString2  != NULL) ;

	iDifference	= 0 ;

	while (n > 0) {
		iDifference = Char_Difference (*pCstring1, Char_ToAscii (*pString2)) ;
		if (iDifference != 0 || Char_IsNul (*pCstring1))
			break ;
		pCstring1	++ ;
		pString2	++ ;
		n			-- ;
	}

	return	iDifference ;
}

Char*
Cstrcpy (
	register Char* 			pCdest,
	register const Char*	pCsrc)
{
	register Char*	pTop ;

	pTop	= pCdest ;
	while (!Char_IsNul (*pCsrc)) 
		*pCdest ++	= *pCsrc ++ ;
	*pCdest	= '\0' ;

	return	pTop ;
}

Char*
Cstrncpy (
	register Char*			pCdest,
	register const Char*	pCsrc,
	register int			n)
{
	register Char*	pTop ;

	pTop	= pCdest ;
	while (n > 0 && !Char_IsNul (*pCsrc)) {
		*pCdest	++	= *pCsrc ++ ;
		n -- ;
	}
	if (n > 0)
		*pCdest	= '\0' ;

	return	pTop ;
}

/*
 *	pDest	ANSI ��������i�[����o�b�t�@�B
 *	pCsrc	NUL �I�[���ꂽ C ������B
 *	n		ANSI ��������i�[����o�b�t�@�̑傫���B
 */
LPTSTR
cstrtostr (
	register LPTSTR			pDest,
	register const Char*	pCsrc,
	register int			n)
{
	register LPTSTR	pTop ;

	pTop	= pDest ;

	while (n > 0 && !Char_IsNul (*pCsrc)) {
		if (Char_IsAscii (*pCsrc)) {
			*pDest ++	= (TCHAR) *pCsrc ;
			n	-- ;
		}
		pCsrc	++ ;
	}
	if (n > 0)
		*pDest	= '\0' ;

	return	pTop ;
}

Char*
strtocstr (
	register Char*			pCdest,
	register LPCTSTR		pSrc,
	register int			n)
{
	register Char*	pTop ;

	pTop	= pCdest ;

	while (n > 0 && *pSrc != '\0') {
		*pCdest ++	= Char_MakeAscii (*pSrc) ;
		pSrc	++ ;
		n		-- ;
	}
	if (n > 0)
		*pCdest	= '\0' ;

	return	pTop ;
}

int
cmemcmp (
	register const Char*	pLeft,
	register int			nLeft,
	register const Char*	pRight,
	register int			nRight)
{
	register int	iDifference ;
	register int	nLoop	= (nLeft < nRight) ? nLeft : nRight ;

	assert (pLeft  != NULL || nLeft == 0) ;
	assert (pRight != NULL || nRight == 0) ;

	while (nLoop -- > 0) {
		iDifference = Char_Difference (*pLeft, *pRight) ;
		if (iDifference != 0)
			return	iDifference ;
		pLeft	++ ;
		pRight	++ ;
	}
	if (nLeft < nRight)
		return	*pRight ;
	if (nLeft > nRight)
		return	*pLeft ;		
	return	0 ;
}

int
cmemccmp (
	register const Char*	pLeft,
	register int			nLeft,
	register LPCTSTR		pRight,
	register int			nRight)
{
	register int	iDifference ;
	register int	nLoop	= (nLeft < nRight) ? nLeft : nRight ;

	assert (pLeft  != NULL || nLeft == 0) ;
	assert (pRight != NULL || nRight == 0) ;

	while (nLoop -- > 0) {
		iDifference = Char_DifferenceAscii (*pLeft, *pRight) ;
		if (iDifference != 0)
			return	iDifference ;
		pLeft	++ ;
		pRight	++ ;
	}
	if (nLeft < nRight)
		return	Char_MakeAscii (*pRight) ;
	if (nLeft > nRight)
		return	*pLeft ;		
	return	0 ;
}

BOOL	
catoi (
	register const Char*	pString,
	register int			nLength,
	register long* const	plRetval)
{
	register long	lSign, lValue ;

	while (nLength > 0 && (*pString == ' ' || *pString == '\t')) {
		pString	++ ;
		nLength	-- ;
	}
	if (!Char_IsDigitNum (*pString)) 
		return	FALSE ;

	lSign	= +1 ;
	if (*pString == '+') {
		pString	++ ;
		nLength	-- ;
	} else if (*pString == '-') {
		pString	++ ;
		nLength	-- ;
		lSign	= -1 ;
	}

	lValue	= 0 ;
	while (nLength > 0 && Char_IsDigitNum (*pString)) {
		lValue	= lValue * 10 + (*pString - '0') ;
		pString	++ ;
		nLength	-- ;
	}
	while (nLength > 0 && (*pString == ' ' || *pString == '\t')) {
		pString	++ ;
		nLength	-- ;
	}
	if (nLength != 0)
		return	FALSE ;

	*plRetval	= lSign * lValue ;
	return	TRUE ;
}

int
quoteCstring (
	register Char*			pDest,
	register const Char*	pSrc,
	register int			nSrc)
{
	const Char*	p ;
	const Char*	pSrcEnd	= pSrc + nSrc ;
	const Char*	pAnnotationBase ;
	int			nStartAnnotationPos ;
	int			nDestUsage	= 0 ;
	BOOL		bWordQuote ;
	BOOL		bAnnotationQuote ;

	/*	���͕����񂪋�Ȃ�ϊ��̕K�v�͂Ȃ��B*/
	if (pSrc == NULL || nSrc <= 0)
		return	0 ;

	/*	���߂����݂���ꍇ�ɂ́A���߂܂łƒ��߈ȑO�̂��ꂼ��� Quote ���K�v�ɂȂ�B*/
	nStartAnnotationPos	= nSrc ;
	p	= pSrc ;
	while (p < pSrcEnd) {
		if (Char_IsEqualAscii (*p, ';')) {
			nStartAnnotationPos	= p - pSrc ;
			break ;
		}
		p	++ ;
	}

	pAnnotationBase		= pSrc + nStartAnnotationPos + 1 ;
	bWordQuote			= needQuotep (pSrc, nStartAnnotationPos, FALSE) ;
	bAnnotationQuote	= nStartAnnotationPos < nSrc && needQuotep (pAnnotationBase, pSrcEnd - pAnnotationBase, TRUE) ;

	if (! bWordQuote && !bAnnotationQuote)
		return	0 ;
	if (bWordQuote) {
		nDestUsage	= quoteCstringSub (pDest, pSrc, nStartAnnotationPos) ;
	} else {
		if (pDest != NULL)
			Cstrncpy (pDest, pSrc, nStartAnnotationPos) ;
		nDestUsage	= nStartAnnotationPos ;
	}
	if (nStartAnnotationPos < nSrc) {
		if (pDest != NULL)
			pDest [nDestUsage]	= Char_MakeAscii (';') ;
		nDestUsage ++ ;
		if (bAnnotationQuote) {
			nDestUsage += quoteCstringSub ((pDest != NULL)? (pDest+nDestUsage) : NULL, pAnnotationBase, pSrcEnd - pAnnotationBase);
		} else {
			if (pDest != NULL)
				Cstrncpy (pDest+nDestUsage, pAnnotationBase, pSrcEnd - pAnnotationBase) ;
			nDestUsage	+= (pSrcEnd - pAnnotationBase) ;
		}
	}
	return	nDestUsage ;
}

/*
 * ���̂܂܎����o�^����Ă��܂��Ƃ܂����l�B��ϊ�����֐��B
 *----
 * �̃T�u�����ǁB
 */
int
quoteCstringSub (
	register Char*			pDest,
	register const Char*	pSrc,
	register int			nSrc)
{
	static const TCHAR		sstrConcat []	= TEXT ("(concat \"") ;
	static CHARSTRPAIR		srConvertPattern []	= {
		{ TEXT ('\r'),	TEXT ("\\r") },
		{ TEXT ('\n'),	TEXT ("\\n") },
		{ TEXT ('/'),	TEXT ("\\057") },
		{ TEXT ('\\'),	TEXT ("\\\\") },
		{ TEXT ('['),	TEXT ("\\133") },
		{ TEXT (']'),	TEXT ("\\135") },
		{ TEXT ('\"'),	TEXT ("\\\"") },
	} ;
	register CHARSTRPAIR*	pPattern ;
	register int			iBufSize, i, nLength ;

	iBufSize	= 0 ;
	if (pDest != NULL) {
		strtocstr (pDest, sstrConcat, ARRAYSIZE (sstrConcat)) ;
		pDest	+= ARRAYSIZE (sstrConcat) - 1 ;
	}
	iBufSize	+= ARRAYSIZE (sstrConcat) - 1 ;

	/* annotation �̊J�n�L���ł��� ';' �����t����܂ł̏����B*/
	while (nSrc > 0) {
		if (! Char_DifferenceAscii (*pSrc, ';')) {
			break ;
		}
		if (Char_IsAscii (*pSrc)) {
			pPattern	= srConvertPattern ;
			i			= ARRAYSIZE (srConvertPattern) ;
			while (i > 0){
				if (! Char_DifferenceAscii (*pSrc, pPattern->m_chara))
					break ;
				pPattern	++ ;
				i 			-- ;
			}
			if (i <= 0) {
				if (pDest != NULL)
					*pDest ++	= *pSrc ;
				iBufSize	++ ;
			} else {
				nLength		= lstrlen (pPattern->m_pString) ;
				if (pDest != NULL) {
					strtocstr (pDest, pPattern->m_pString, nLength) ;
					pDest	+= nLength ;
				}
				iBufSize	+= nLength ;
			}
		} else {
			if (pDest != NULL) 
				*pDest	++	= *pSrc ;
			iBufSize	++ ;
		}
		pSrc	++ ;
		nSrc	-- ;
	}
	if (pDest != NULL){
		*pDest ++	= '\"' ;
		*pDest ++	= ')' ;
	}
	iBufSize	+= 2 ;

	/* annotation �̊J�n�L���ł��� ';' �����t��������̏����B*/
	if (nSrc > 0) {
		if (pDest != NULL) 
			*pDest	++	= TEXT (';') ;
		iBufSize	++ ;
		pSrc		++ ;
		nSrc		-- ;

		while (nSrc > 0) {
			/* annotation �Ƃ��ēK���łȂ������͍폜�����B% encoding �ɂ��Ă��ǂ����c�B*/
			if (Char_DifferenceAscii (*pSrc, TEXT ('\r')) != 0 &&
				Char_DifferenceAscii (*pSrc, TEXT ('\n')) != 0) {
				if (! Char_DifferenceAscii (*pSrc, TEXT ('/'))) {
					if (pDest != NULL) 
						*pDest	++ = Char_Make (KCHARSET_JISX0208_1983, 0x213f /* '�^' */) ;
				} else {
					if (pDest != NULL) 
						*pDest	++	= *pSrc ;
				}
				iBufSize	++ ;
			}
			pSrc	++ ;
			nSrc	-- ;
		}
	}
	return	iBufSize ;
}

static	BOOL
needQuotep (
	const Char*				pSrc,
	int						nSrc,
	BOOL					bAnnotation)
{
	const Char*	pSrcEnd = pSrc + nSrc ;
	const Char*	p ;

	if (nSrc > 2 && 
		Char_IsEqualAscii (*pSrc, '(') &&
		Char_IsAlpha      (*(pSrc + 1)) &&
		Char_IsEqualAscii (*(pSrc + nSrc - 1), ')')) 
		return	FALSE ;

	p	= pSrc ;
	while (p < pSrcEnd) {
		/* quote ���Ȃ���΂Ȃ�Ȃ����������t�������ۂ�? */
		if (! Char_DifferenceAscii (*p, '/')  ||
			! Char_DifferenceAscii (*p, '\n') ||
			! Char_DifferenceAscii (*p, '\r')) 
			return	TRUE ;
		if (bAnnotation && 
			(! Char_DifferenceAscii (*pSrc, '[')  ||
			 ! Char_DifferenceAscii (*pSrc, ']')  ||
			 ! Char_DifferenceAscii (*pSrc, '\\'))) 
			return	TRUE ;
		p	++ ;
	}
	return	FALSE ;
}

#if defined (UNIT_TEST)
#if defined(MIXED_UNICODE_ANSI)
#define	Myprintf	wprintf
#define	Myfgets		fgetws
#else
#define	Myprintf	_tprintf
#define	Myfgets		_fgetts
#endif

int
_tmain (void)
{
	TCHAR			szBuffer     [256] ;
	Char			szWord       [256] ;
	Char			szQuotedWord [256] ;
	register int	n, nQuote ;

	setlocale (LC_ALL, "japanese") ;

	while (! feof (stdin)) {
		_tprintf (TEXT ("> ")) ;
		fflush (stdout) ;
		if (_fgetts (szBuffer, ARRAYSIZE (szBuffer), stdin) == NULL)
			break ;
		n	= lstrlen (szBuffer) ;
		if (n > 0 && szBuffer [n - 1] == TEXT ('\n')) {
			szBuffer [n - 1]	= TEXT ('\0') ;
			n	-- ;
		}
		if (n <= 0)
			continue ;
		(void) strtocstr (szWord, szBuffer, n) ;
		nQuote	= quoteCstring (NULL, szWord, n) ;
		if (0 < nQuote && nQuote < ARRAYSIZE (szQuotedWord)) {
			(void) quoteCstring (szQuotedWord, szWord, n) ;
			cstrtostr (szBuffer, szQuotedWord, nQuote) ;
			szBuffer [nQuote]	= TEXT ('\0') ;
			_tprintf (TEXT ("converted(%d): \"%s\"\n"), nQuote, szBuffer) ;
		} else {
			_tprintf (TEXT ("original(%d):  \"%s\"\n"), nQuote, szBuffer) ;
		}
	}
	return	0 ;
}

#endif

