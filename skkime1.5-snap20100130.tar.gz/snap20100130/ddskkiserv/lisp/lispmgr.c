/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "lispmgrp.h"
#include "cstring.h"

static	BOOL	lispMgr_initialize 				(TLispManager*) ;
static	BOOL	lispMgr_collectOtherGarbage		(TLispManager*, TLispEntity**) ;
static	BOOL	lispMgr_markEntityRecursively	(TLispManager*, TLispEntity*) ;
static	BOOL	lispMgr_registerEntityToList    (TLispManager*, TLispEntity**, TLispEntity*) ;
static	BOOL	lispMgr_Allocate				(TLispManager*, size_t, void*) ;

/*	inline functions */
static BOOL
lispMgr_markedEntityp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;

	return	(pEntity->m_iMarker == pLispMgr->m_iMarker)? TRUE : FALSE ;
}

static BOOL
lispMgr_markEntity (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;

	pEntity->m_iMarker	= pLispMgr->m_iMarker ;
	return	TRUE ;
}

static BOOL
lispMgr_unregisterEntityFromList (
	register TLispManager*	pLispMgr,
	register TLispEntity**	ppEntTop,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;

	if (pEntity->m_pLeft != NULL) {
		pEntity->m_pLeft->m_pRight	= pEntity->m_pRight ;
	} else {
		assert (pEntity == *ppEntTop) ;
		*ppEntTop	= pEntity->m_pRight ;
	}
	if (pEntity->m_pRight != NULL) 
		pEntity->m_pRight->m_pLeft	= pEntity->m_pLeft ;

	pEntity->m_pRight			= NULL ;
	pEntity->m_pLeft			= NULL ;

	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

/*	global functions */
BOOL
TLispMgr_Create (
	register TLispManager** const	ppLispMgr)
{
	register TLispManager*	pLispMgr ;
	register int			i ;
	
	assert (ppLispMgr != NULL) ;

	pLispMgr	= MALLOC (sizeof (TLispManager)) ;
	if (pLispMgr == NULL)
		return	FALSE ;

	for (i = 0 ; i < ARRAYSIZE (pLispMgr->m_apSymbolListTop) ; i ++)
		pLispMgr->m_apSymbolListTop [i]		= NULL ;
	for (i = 0 ; i < ARRAYSIZE (pLispMgr->m_apIntegerListTop) ; i ++)
		pLispMgr->m_apIntegerListTop [i]	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (pLispMgr->m_apSubrListTop) ; i ++)
		pLispMgr->m_apSubrListTop [i]		= NULL ;
	pLispMgr->m_pEntListNamedMutex	= NULL ;
	pLispMgr->m_pEntListNoNameMutex	= NULL ;
	pLispMgr->m_pEntMiscListTop		= NULL ;
	pLispMgr->m_pEntVoid			= NULL ;
	pLispMgr->m_pEntEmpty			= NULL ;
	for (i = 0 ; i < LISPMGR_SIZE_RESERVED ; i ++)
		pLispMgr->m_apEntReserved [i]	= NULL ;

	if (TFAILED (TVarbuffer_Initialize (&pLispMgr->m_vbufLocalSymbol, sizeof (TLispEntity*))))
		goto	error ;
	if (TFAILED (lispMgr_initialize (pLispMgr)))
		goto	error ;
	*ppLispMgr			= pLispMgr ;
	return	TRUE ;

  error:
	FREE (pLispMgr) ;
	return	FALSE ;
}

BOOL
TLispMgr_Destroy (
	register TLispManager*	pLispMgr)
{
	/*	�j���̎d��...*/
	return	FALSE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

/*	�Q�Ƃ���Ă��Ȃ� ENTITY ���������B*/
BOOL
lispMgr_CollectGarbage (
	register TLispManager*	pLispMgr)
{
	register TLispEntity*	pEntity ;
#if defined (DEBUG)
	register DWORD			dwStart	= GetTickCount () ;
#endif

	pLispMgr->m_iMarker	++ ;

	/*	ENTITY �̎Q�ƃJ�E���^�����ԂɌ��āA�N������Q�Ƃ���Ă��Ȃ����݂�
	 *	�������B
	 *	�������AVector �� Conscell �ɂ���ĎQ�Ƃ���Ă����͎Q�ƃJ�E���^
	 *	�ɓ����Ă��Ȃ��̂Œ��ӂ��邱�ƁB
	 *	�]���āAVector �� Conscell ��T���ĎQ�Ɛ�Ƀ}�[�N���Ă������Ƃ�
	 *	�K�v�ƂȂ�B
	 */
	pEntity	= pLispMgr->m_pEntMiscListTop ;
	while (pEntity != NULL) {
		if (pEntity->m_lReferCount > 0) 
			lispMgr_markEntityRecursively (pLispMgr, pEntity) ;
		pEntity	= pEntity->m_pRight ;
	}

	lispMgr_CollectIntegerGarbage (pLispMgr) ;
	/*	���O�t�� MUTEX �� GC �̑Ώۂɂ͌����ĂȂ�Ȃ��B������A���O�t��
	 *	MUTEX ���ǂ�ǂ�쐬�����ƁA���\�[�X�U���ŗ�����c�B���ӂ��邱
	 *	�ƁB*/
	lispMgr_collectOtherGarbage (pLispMgr, &pLispMgr->m_pEntListNoNameMutex) ;
	lispMgr_collectOtherGarbage (pLispMgr, &pLispMgr->m_pEntMiscListTop) ;

#if defined (DEBUG)
	fprintf (stderr, "GarbageCollect ... %ld ms\n", GetTickCount () - dwStart) ;
#endif
	return	TRUE ;
}

BOOL
lispMgr_UnregisterMisc (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (0 < pEntity->m_iType && pEntity->m_iType < MAX_LISPENTITY_TYPE &&
			pEntity->m_iType != LISPENTITY_INTEGER) ;

	return	lispMgr_unregisterEntityFromList (pLispMgr, &pLispMgr->m_pEntMiscListTop, pEntity) ;
}

BOOL
lispMgr_GetLocalSymbols (
	register TLispManager*		pLispMgr,
	register TLispEntity***		pppEntSymbol,
	register int*				pnEntSymbol)
{
	assert (pLispMgr     != NULL) ;
	assert (pppEntSymbol != NULL) ;
	assert (pnEntSymbol  != NULL) ;
	*pppEntSymbol	= TVarbuffer_GetBuffer (&pLispMgr->m_vbufLocalSymbol) ;
	*pnEntSymbol	= TVarbuffer_GetUsage  (&pLispMgr->m_vbufLocalSymbol) ;
	return	TRUE ;
}

BOOL
lispMgr_AddSymbolToLocalSymbols (
	register TLispManager*	pLispMgr,
	TLispEntity*			pEntSymbol)
{
	assert (pLispMgr   != NULL) ;
	assert (pEntSymbol != NULL) ;
	if (TFAILED (lispEntity_Symbolp (pLispMgr, pEntSymbol)))
		return	FALSE ;
	if (TFAILED (TVarbuffer_Add (&pLispMgr->m_vbufLocalSymbol, &pEntSymbol, 1)))
		return	FALSE ;
	lispEntity_AddRef (pLispMgr, pEntSymbol) ;
	return	TRUE ;
}

void
lispMgr_DestroyEntity (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	static void		(*srpDestroyFunc [])(TLispManager*, TLispEntity*)	= {
		NULL,						/* LISPENTITY_VECTOR */
		NULL,						/* LISPENTITY_STRING */
		NULL,						/* LISPENTITY_SYMBOL */
		lispMgr_DestroyMarker,		/* LISPENTITY_MARKER */
		lispMgr_DestroyBuffer,		/* LISPENTITY_BUFFER */
		NULL,						/* LISPENTITY_SUBR */
	} ;
	register int	nFunc ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;

	nFunc	= pEntity->m_iType - LISPENTITY_VECTOR ;
	if ((0 <= nFunc && nFunc < sizeof (srpDestroyFunc)) &&
		srpDestroyFunc [nFunc] != NULL)
		(srpDestroyFunc [nFunc])(pLispMgr, pEntity) ;
	FREE (pEntity) ;
	return ;
}

/*	����/�������ł����Ă� eq �̔���� nil ���Ԃ� entity ���Ȃ��B*/
BOOL
lispMgr_RegisterMisc (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;

	pEntity->m_pRight			= pLispMgr->m_pEntMiscListTop ;
	pEntity->m_pLeft			= NULL ;
	if (pLispMgr->m_pEntMiscListTop != NULL)
		pLispMgr->m_pEntMiscListTop->m_pLeft	= pEntity ;
	pLispMgr->m_pEntMiscListTop	= pEntity ;
	return	TRUE ;
}

BOOL
lispMgr_Allocate (
	register TLispManager*			pLispMgr,
	register size_t					nSize,
	register void*					pRetval)
{
	void*	pvMemory ;

	pvMemory	= MALLOC (nSize) ;
	if (pvMemory == NULL) {
#if defined (DEBUG)
		fprintf (stderr, "Garbage collecting ...") ;
		fflush (stderr) ;
#endif
		lispMgr_CollectGarbage (pLispMgr) ;
#if defined (DEBUG)
		fprintf (stderr, "done.\n") ;
#endif
		pvMemory	= MALLOC (nSize) ;
		if (pvMemory == NULL) 
			return	FALSE ;
	}
	*((void **)pRetval)	= pvMemory ;
	return	TRUE ;
}

void
lispMgr_Deallocate (
	register TLispManager*			pLispMgr,
	register void*					pvMemory)
{
	FREE (pvMemory) ;
	return ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispMgr_AllocateEntity (
	register TLispManager*			pLispMgr,
	register size_t					nSize,
	register TLispEntity** const	ppReturn)
{
	TLispEntity*	pEntity ;

	if (TFAILED (lispMgr_Allocate (pLispMgr, sizeof (TLispEntity) + nSize, &pEntity)))
		return	FALSE ;

	pEntity->m_iType		= LISPENTITY_BAD ;
	pEntity->m_lReferCount	= 0 ;	/* �쐬����͎Q�ƃJ�E���^�� 0�B*/
	pEntity->m_iMarker		= pLispMgr->m_iMarker - 1 ;
	pEntity->m_pLeft		= NULL ;
	pEntity->m_pRight		= NULL ;

	*ppReturn	= pEntity ;
	return	TRUE ;
}

BOOL
lispMgr_initialize (
	register TLispManager*	pLispMgr)
{
	/*	��X���������Ȃ��čςނ悤�ɓo�^���Ă����B*/
	static LPCTSTR	apReservedSymbols [LISPMGR_SIZE_RESERVED]	= {
		TEXT ("nil"),
		TEXT ("t"),
		TEXT ("-"),
		TEXT ("lambda"),
		TEXT ("macro"),
		TEXT ("&optional"),
		TEXT ("&rest"),
		TEXT ("keymap"),
		TEXT ("error"),
		TEXT ("exit"),
		TEXT ("quit"),
		TEXT ("quit-flag"),
		TEXT ("inhibit-quit"),
		TEXT ("features"),
		TEXT ("interactive"),
		TEXT ("this-command"),
		TEXT ("last-command"),
		TEXT ("unread-command-events"),
		TEXT ("pre-command-hook"),
		TEXT ("post-command-hook"),
		TEXT ("last-command-event"),
		TEXT ("unread-command-char"),
		TEXT ("global-map"),
		TEXT ("minibuffer-local-map"),
		TEXT ("minor-mode-map-alist"),
		TEXT ("wrong-type-argument"),
		TEXT ("buffer-file-name"),
		TEXT ("mode-line-format"),
		TEXT ("load-path"),
		TEXT ("kill-ring"),
		TEXT ("kill-region"),
		TEXT ("kill-ring-yank-pointer"),
		TEXT ("yank"),

		/*	for skk */
		TEXT ("skk-server-host"),
		TEXT ("skk-server-list"),
		TEXT ("skk-portnum"),
		TEXT ("skk-process-okuri-early"),
		TEXT ("j-henkan-key"),
		TEXT ("j-search-key"),
		TEXT ("j-okuri-ari"),
		TEXT ("j-henkan-okurigana"),
		TEXT ("j-henkan-okuri-strictly"),
	} ;
	/*	default �� buffer-local-symbol �Ƃ��ėp�ӂ����V���{���B
	 */
	static int	rnDefaultBufferSymbols []	= {
		LISPMGR_INDEX_BUFFER_FILE_NAME,
	} ;
	register LPCTSTR*		pPtr ;
	register int			i ;
	TLispEntity*			pEntity ;
	TLispEntity*			pEntVoid ;
	TLispEntity*			pEntEmpty ;

	pPtr	= apReservedSymbols ;
	for (i = 0 ; i < ARRAYSIZE (apReservedSymbols) ; i ++) {
		if (TFAILED (lispMgr_InternSymbolA (pLispMgr, *pPtr, lstrlen (*pPtr), &pEntity)))
			return	FALSE ;
		lispEntity_AddRef (pLispMgr, pEntity) ;
		pLispMgr->m_apEntReserved [i]	= pEntity ;
		pPtr	++ ;
	}
	if (TFAILED (lispMgr_CreateSymbolA (pLispMgr, TEXT ("void"), 4, &pEntVoid)))
		return	FALSE ;
	pEntVoid->m_iType		= LISPENTITY_VOID ;
	pLispMgr->m_pEntVoid	= pEntVoid ;
	lispEntity_AddRef (pLispMgr, pEntVoid) ;
	if (TFAILED (lispMgr_CreateSymbolA (pLispMgr, TEXT ("empty"), 4, &pEntEmpty)))
		return	FALSE ;
	pEntEmpty->m_iType		= LISPENTITY_EMPTY ;
	pLispMgr->m_pEntEmpty	= pEntEmpty ;

	/*	default �� buffer-local �ɂȂ� symbol ��o�^���Ă����B���݂̂Ƃ���A
	 *		buffer-file-name,
	 *	���������肵�Ă���B
	 */
	for (i = 0 ; i < ARRAYSIZE (rnDefaultBufferSymbols) ; i ++) {
		pEntity	= pLispMgr->m_apEntReserved [rnDefaultBufferSymbols [i]] ;
		lispMgr_AddSymbolToLocalSymbols (pLispMgr, pEntity) ;
	}
	return	TRUE ;
}

BOOL
lispMgr_collectOtherGarbage (
	register TLispManager*	pLispMgr,
	register TLispEntity**	ppEntTop)
{
	register TLispEntity*	pNextEntity ;
	register TLispEntity*	pEntity ;

	assert (pLispMgr != NULL) ;

	pEntity	= *ppEntTop ;
	while (pEntity != NULL) {
		pNextEntity	= pEntity->m_pRight ;
		if (pEntity->m_lReferCount == 0 &&
			pEntity->m_iMarker != pLispMgr->m_iMarker) {
			lispMgr_unregisterEntityFromList (pLispMgr, ppEntTop, pEntity) ;
			lispMgr_DestroyEntity (pLispMgr, pEntity) ;
		} else {
			pEntity->m_iMarker	= pLispMgr->m_iMarker ;
		}
		pEntity	= pNextEntity ;
	}
	return	TRUE ;
}


BOOL
lispMgr_markEntityRecursively (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	lispMgr_markEntity (pLispMgr, pEntity) ;
	
	switch (pEntity->m_iType) {
	case	LISPENTITY_CONSCELL:
	{
		TLispEntity*	pCar ;
		TLispEntity*	pCdr ;

		lispEntity_GetCar (pLispMgr, pEntity, &pCar) ;
		lispEntity_GetCdr (pLispMgr, pEntity, &pCdr) ;
		if (TFAILED (lispMgr_markedEntityp (pLispMgr, pCar)))
			lispMgr_markEntityRecursively (pLispMgr, pCar) ;
		if (TFAILED (lispMgr_markedEntityp (pLispMgr, pCdr)))
			lispMgr_markEntityRecursively (pLispMgr, pCdr) ;
		break ;
	}
		
	case	LISPENTITY_VECTOR:
	{
		TLispEntity**	ppElement ;
		int				nElement ;

		lispEntity_GetVectorValue (pLispMgr, pEntity, &ppElement, &nElement) ;
		while (nElement > 0) {
			if (TFAILED (lispMgr_markedEntityp (pLispMgr, *ppElement)))
				lispMgr_markEntityRecursively (pLispMgr, *ppElement) ;
			ppElement	++ ;
			nElement	-- ;
		}
		break ;
	}
		
	default:
		break ;
	}
	return	TRUE ;
}

#if defined (DEBUG)
void
lispMgr_CheckEntity (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	register TLispEntity*	pNode ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;

	fprintf (stderr, " Searching: Entity(%p),Count(%ld),Type(%d) ...",
			 pEntity, pEntity->m_lReferCount, pEntity->m_iType) ;

	switch (pEntity->m_iType) {
	case	LISPENTITY_INTEGER:
	case	LISPENTITY_SYMBOL:
		fprintf (stderr, "not check\n") ;
		break ;

	default:
		pNode	= pLispMgr->m_pEntMiscListTop ;
		while (pNode != NULL) {
			if (pNode == pEntity) {
				fprintf (stderr, "hit\n") ;
				//lispMgr_CheckMark (pLispMgr, pEntity) ;
				return ;
			}
			pNode	= pNode->m_pRight ;
		}
		fprintf (stderr, "miss\n") ;
		break ;
	}
	return ;
}

void
lispMgr_CheckMark (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	register TLispEntity*	pNode ;

	if (pEntity->m_iType != 2)
		return ;

	fprintf (stderr, "Target(%p): Mark = %d -> ", 
			 pEntity, pEntity->m_iMarker) ;
	pLispMgr->m_iMarker	++ ;
	pNode	= pLispMgr->m_pEntMiscListTop ;
	while (pNode != NULL) {
		if (pNode->m_lReferCount > 0) 
			lispMgr_markEntityRecursively (pLispMgr, pNode) ;
		pNode	= pNode->m_pRight ;
	}
	fprintf (stderr, "%d/%d\n",
			 pEntity->m_iMarker, pLispMgr->m_iMarker) ;
	return ;
}
#endif

