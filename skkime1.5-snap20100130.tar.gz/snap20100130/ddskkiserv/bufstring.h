#if !defined (bufstring_h)
#define	bufstring_h

#include "local.h"
#include "Char.h"

struct tagBufStringMarker ;
struct tagBufStringNode ;
struct tagBufStringLeaf ;
struct tagBufString;

struct tagBufString {
	struct tagBufStringNode*	m_pRoot ;
	struct tagBufStringLeaf*	m_pHead ;
} ;

struct tagBufStringMarker {
	struct tagBufString*		m_pBufString ;
	struct tagBufStringLeaf*	m_pLeaf ;
	int							m_nPosition ;
	int							m_nOffset ;
} ;

typedef	struct tagBufStringMarker	TBufStringMarker ;
typedef struct tagBufString			TBufString ;


BOOL	TBufString_Initialize			(TBufString*) ;
BOOL	TBufString_Uninitialize			(TBufString*) ;
BOOL	TBufString_SolveMarker			(TBufString*, int, TBufStringMarker*) ;
int		TBufString_GetLength			(TBufString*) ;
BOOL	TBufStringMarker_InsertString	(TBufStringMarker*, const Char*, int) ;
BOOL	TBufStringMarker_InsertChar		(TBufStringMarker*, Char, int) ;
BOOL	TBufStringMarker_DeleteChar		(TBufStringMarker*, int) ;
BOOL	TBufStringMarker_Forward		(TBufStringMarker*, int) ;
BOOL	TBufStringMarker_Backward		(TBufStringMarker*, int) ;
int		TBufStringMarker_GetOffset		(TBufStringMarker*) ;
Char	TBufStringMarker_GetChar		(TBufStringMarker*) ;
void	TBufStringMarker_SetVoid		(TBufStringMarker*) ;
BOOL	TBufStringMarker_Voidp			(TBufStringMarker*) ;

#endif

