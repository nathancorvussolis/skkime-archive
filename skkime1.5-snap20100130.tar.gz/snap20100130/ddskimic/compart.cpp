//
// compart.cpp
//

#include "globals.h"
#include "skimic.h"
#include "editsess.h"
#include "skkimmgr.h"

class CKeyboardInputModeChangeSession : public CEditSessionBase
{
public:
    CKeyboardInputModeChangeSession (ITfContext *pContext, UINT uConversionMode, UINT uSentenseMode, BOOL bUpdate, CSkkImeMgr* pSkkIme) :
		CEditSessionBase(pContext)
	{
		_uConversionMode 	= uConversionMode ;
		_uSentenseMode		= uSentenseMode ;
		_bUpdate			= bUpdate ;
		m_pSkkIme			= pSkkIme ;
		return ;
	}
	
    // ITfEditSession
    STDMETHODIMP DoEditSession (TfEditCookie ec) ;
	
private:
    UINT		_uConversionMode ;
	UINT		_uSentenseMode ;
	BOOL		_bUpdate ;
	CSkkImeMgr*	m_pSkkIme ;
} ;


STDAPI
CSkkImeTextService::OnChange (
	REFGUID		rguidCompartment)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange (0x%lx)\n"), m_tfClientId));

	// nothing to do in this sample
	if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_OPENCLOSE)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_KEYBOARD_OPENCLOSE\n"))) ;
		/* Application ������ Keybaord �� Open/Close �����䂳�ꂽ�Ǝv���B*/
		_UpdateLangBarItem () ;
#if defined (TF_CONVERSIONMODE_NATIVE)
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION)) {
		unsigned int	uConversionMode ;

		/* ConversionMode �̕ύX���ʒm���ꂽ�B*/
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION\n"))) ;
		if (SUCCEEDED (_GetKeyboardInputModeConversion (&uConversionMode))) {
			ITfContext*		pContext ;

			if (SUCCEEDED (_GetFocusContext (&pContext))) {
				if (pContext != NULL) {
					CEditSessionBase*	pEditSession ;
					HRESULT				hrEaten ;

					pEditSession	= new CKeyboardInputModeChangeSession (pContext, uConversionMode, 0, FALSE, m_pSkkIme) ;
					if (pEditSession != NULL) {
						(void) pContext->RequestEditSession (m_tfClientId, pEditSession, TF_ES_SYNC | TF_ES_READWRITE, &hrEaten) ;
						pEditSession->Release () ;
					}
					pContext->Release () ;
				}
			}
		}
#endif
#if defined (TF_SENTENCEMODE_NONE)
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE)) {
		/* SentenseMode �̕ύX���ʒm���ꂽ�c���A����͎g���Ȃ��̂ňӖ��͂Ȃ��B*/
#endif
#if defined (not_work)
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_DISABLED)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_KEYBOARD_DISABLED\n"))) ;
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_EMPTYCONTEXT)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_EMPTYCONTEXT\n"))) ;
#endif
	}
    return	S_OK ;
}

/*========================================================================*
 */
/*EXTERN_C const GUID GUID_COMPARTMENT_KEYBOARD_OPENCLOSE;*/
/*EXTERN_C const GUID GUID_COMPARTMENT_KEYBOARD_DISABLED;*/

BOOL
CSkkImeTextService::_InitThreadCompartment (ITfThreadMgr* pThreadMgr)
{
	ITfCompartmentMgr*	pCompMgr	= NULL ;
    ITfCompartment*		pCompartment ;
	BOOL	fRet ;
	HRESULT	hr ;

	if (pThreadMgr == NULL)
		return	FALSE ;

	hr	= pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void**)&pCompMgr) ;
	if (FAILED (hr))
		return	FALSE ;

	fRet	= FALSE ;
#ifdef GUID_COMPARTMENT_KEYBOARD_OPENCLOSE
	if (pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &pCompartment) == S_OK) {
		VARIANT	var ;
		VariantInit(&var) ;
		hr		= pCompartment->GetValue (&var) ;
		if (hr == S_FALSE) {
			var.vt		= VT_I4;
			var.lVal	= _IsKeyboardOpen()? 1 : 0 ;
			pCompartment->SetValue(m_tfClientId, &var);
		}
		VariantClear(&var);

		fRet	= AdviseSink (pCompartment, (ITfCompartmentEventSink *)this, IID_ITfCompartmentEventSink, &m_dwCompKeyboardOpenCloseCookie) ;
		pCompartment->Release () ;
		if (! fRet) {
			m_dwCompKeyboardOpenCloseCookie	= TF_INVALID_COOKIE ;
		}
	}
#endif
#ifdef GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION
	if (pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION, &pCompartment) == S_OK) {
		VARIANT	var ;
		VariantInit(&var) ;
		hr		= pCompartment->GetValue (&var) ;
		if (hr == S_FALSE) {
			unsigned int uCMode ;
			var.vt		= VT_I4;
			hr			= m_pSkkIme->GetConversionMode(&uCMode);
			if (hr == S_OK) {
				var.lVal	= uCMode ;
				pCompartment->SetValue(m_tfClientId, &var);
			}
		}
		VariantClear(&var);

		fRet	= AdviseSink (pCompartment, (ITfCompartmentEventSink *)this, IID_ITfCompartmentEventSink, &m_dwCompKeyboardInputModeConversionCookie) ;
		pCompartment->Release () ;
		if (! fRet) {
			m_dwCompKeyboardInputModeConversionCookie	= TF_INVALID_COOKIE ;
		}
	}
#endif
#ifdef GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE
	if (pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE, &pCompartment) == S_OK) {
		VARIANT	var ;
		VariantInit(&var) ;
		hr		= pCompartment->GetValue (&var) ;
		if (hr == S_FALSE) {
			unsigned int uCMode ;
			var.vt		= VT_I4;
			var.lVal	= TF_SENTENCEMODE_NONE ;
			pCompartment->SetValue(m_tfClientId, &var);
		}
		VariantClear(&var);

		fRet	= AdviseSink (pCompartment, (ITfCompartmentEventSink *)this, IID_ITfCompartmentEventSink, &m_dwCompKeyboardInputModeSentenseCookie) ;
		pCompartment->Release () ;
		if (! fRet) {
			m_dwCompKeyboardInputModeSentenseCookie	= TF_INVALID_COOKIE ;
		}
	}
#endif
	pCompMgr->Release () ;
	return	TRUE ;
}

void
CSkkImeTextService::_UninitThreadCompartment (ITfThreadMgr* pThreadMgr)
{
	ITfCompartmentMgr*	pCompMgr	= NULL ;
    ITfCompartment*		pCompartment ;
	HRESULT	hr ;

	if (pThreadMgr == NULL)
		return ;

	hr	= pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void**)&pCompMgr) ;
	if (FAILED (hr))
		return ;

	if (m_dwCompKeyboardOpenCloseCookie != TF_INVALID_COOKIE &&
		pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &pCompartment) == S_OK) {
        UnadviseSink (pCompartment, &m_dwCompKeyboardOpenCloseCookie) ;
		pCompartment->Release () ;
		m_dwCompKeyboardOpenCloseCookie	= TF_INVALID_COOKIE ;
	}
#ifdef GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION
	if (m_dwCompKeyboardInputModeConversionCookie != TF_INVALID_COOKIE && 
		pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION, &pCompartment) == S_OK) {
        UnadviseSink (pCompartment, &m_dwCompKeyboardInputModeConversionCookie) ;
		pCompartment->Release () ;
		m_dwCompKeyboardInputModeConversionCookie	= TF_INVALID_COOKIE ;
	}
#endif
#ifdef GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE
	if (m_dwCompKeyboardInputModeSentenseCookie != TF_INVALID_COOKIE &&
		pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE, &pCompartment) == S_OK) {
        UnadviseSink (pCompartment, &m_dwCompKeyboardInputModeSentenseCookie) ;
		pCompartment->Release () ;
		m_dwCompKeyboardInputModeSentenseCookie	= TF_INVALID_COOKIE ;
	}
#endif
	pCompMgr->Release () ;
	return ;
}

BOOL
CSkkImeTextService::_IsKeyboardDisabled ()
{
    ITfDocumentMgr*		pDocMgrFocus	= NULL ;
	ITfContext*			pContext		= NULL ;
	HRESULT				hr ;
	BOOL				fDisabled	= FALSE ;
	VARIANT				var ;

	if (m_pThreadMgr == NULL) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_IsKeyboardDisabled (0x%lx): No thread manager\n"), m_tfClientId)) ;
		fDisabled	= TRUE ;
		goto	Exit ;
	}

	hr	= m_pThreadMgr->GetFocus (&pDocMgrFocus) ;
	if (FAILED (hr) || pDocMgrFocus == NULL) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_IsKeyboardDisabled (0x%lx): No focus document\n"), m_tfClientId)) ;
		fDisabled	= TRUE ;
		goto	Exit ;
	}

	hr	= pDocMgrFocus->GetTop (&pContext) ; 
	if (FAILED (hr) || pContext == NULL) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_IsKeyboardDisabled (0x%lx): No top context\n"), m_tfClientId)) ;
		fDisabled	= TRUE ;
        goto	Exit ;
	}

	if (SUCCEEDED (_GetContextCompartment (pContext, GUID_COMPARTMENT_KEYBOARD_DISABLED, &var))) {
		if (var.vt == VT_I4) {
			// Even VT_EMPTY, GetValue() can succeed
			fDisabled = (BOOL)var.lVal ;
			DEBUGPRINTF ((TEXT ("OpenClose (%d)\n"), (int)var.lVal)) ;
		}
		VariantClear (&var) ;
	}
	if (SUCCEEDED (_GetContextCompartment (pContext, GUID_COMPARTMENT_EMPTYCONTEXT, &var))) {
		if (var.vt == VT_I4) {
			// Even VT_EMPTY, GetValue() can succeed
			fDisabled = ! fDisabled? (BOOL)var.lVal : TRUE ;
			DEBUGPRINTF ((TEXT ("EmptyContext (%d)\n"), (int)var.lVal)) ;
		}
		VariantClear (&var) ;
	}
  Exit:
	if (pContext != NULL)
		pContext->Release () ;
    if (pDocMgrFocus != NULL)
        pDocMgrFocus->Release () ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_IsKeyboardDisabled (0x%lx, %d)\n"), m_tfClientId, fDisabled)) ;
	return	fDisabled ;
}

BOOL
CSkkImeTextService::_IsKeyboardOpen ()
{
#if 0
	VARIANT		var ;
	BOOL		fOpen	= FALSE ;

	if (FAILED (_GetThreadCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &var)))
		return	FALSE ;
	if (var.vt == VT_I4)
		fOpen	= (BOOL) var.lVal ;
	VariantClear (&var) ;
	return	fOpen ;
#else
	return	m_bFilter ;
#endif
}

HRESULT
CSkkImeTextService::_SetKeyboardOpen (
	BOOL			fOpen)
{
	VARIANT				var ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_SetKeyboardOpen (%d)\n"), fOpen)) ;
	m_bFilter	= fOpen ;
	var.vt		= VT_I4 ;
	var.lVal	= fOpen ;
	return	_SetThreadCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &var) ;
}

#if defined (TF_CONVERSIONMODE_NATIVE)
HRESULT
CSkkImeTextService::_GetKeyboardInputModeConversion (
	unsigned int*		piModeConversion)
{
	VARIANT			var ;
	HRESULT			hr ;

	hr	= _GetThreadCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION, &var) ;
	if (FAILED (hr))
		return	hr ;
	if (var.vt == VT_I4) {
		if (piModeConversion != NULL)
			*piModeConversion	= var.lVal ;
	} else {
		hr	= E_FAIL ;
	}
	VariantClear (&var) ;
	return	hr ;
}

HRESULT
CSkkImeTextService::_SetKeyboardInputModeConversion (
	unsigned int			iModeConversion)
{
	VARIANT				var ;

	var.vt		= VT_I4 ;
	var.lVal	= iModeConversion ;
	return	_SetThreadCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION, &var) ;
}
#endif

#if defined (TF_SENTENCEMODE_NONE)
HRESULT
CSkkImeTextService::_GetKeyboardInputModeSentence (unsigned int* piModeSentence) 
{
	VARIANT			var ;
	HRESULT			hr ;

	hr	= _GetThreadCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE, &var) ;
	if (FAILED (hr))
		return	hr ;
	if (var.vt == VT_I4) {
		if (piModeSentence != NULL)
			*piModeSentence	= var.lVal ;
	} else {
		hr	= E_FAIL ;
	}
	VariantClear (&var) ;
	return	hr ;
}

HRESULT
CSkkImeTextService::_SetKeyboardInputModeSentence (unsigned int iModeSentence) 
{
	VARIANT		var ;
	var.vt		= VT_I4 ;
	var.lVal	= iModeSentence ;
	return	_SetThreadCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE, &var) ;
}
#endif

HRESULT
CSkkImeTextService::_SetThreadCompartment (
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	if (m_pThreadMgr == NULL)
		return	E_FAIL ;

	hr	= m_pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->SetValue (m_tfClientId, pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

HRESULT
CSkkImeTextService::_GetThreadCompartment (
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	if (m_pThreadMgr == NULL)
		return	E_FAIL ;

	hr	= m_pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->GetValue (pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

HRESULT
CSkkImeTextService::_SetContextCompartment (
	ITfContext*	pContext,
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	hr	= pContext->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->SetValue (m_tfClientId, pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

HRESULT
CSkkImeTextService::_GetContextCompartment (
	ITfContext*	pContext,
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	hr	= pContext->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->GetValue (pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

#if defined (DEBUG) || defined (_DEBUG)
HRESULT
DumpCompartment (ITfCompartmentMgr* pMgr)
{
	IEnumGUID*	pEnum = NULL ;
	HRESULT		hr ;
	ULONG		uFetched ;
	GUID		elt ;

	if (pMgr == NULL)
		return	E_INVALIDARG ;

	hr	= pMgr->EnumCompartments (&pEnum) ;
	if (FAILED (hr))
		return	hr ;

	while (pEnum->Next (1, &elt, &uFetched) == S_OK && uFetched == 1) {
		DebugPrintf (TEXT ("GUID: %08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X"),
			elt.Data1, elt.Data2, elt.Data3, 
			elt.Data4[0], elt.Data4[1], elt.Data4[2], elt.Data4[3],
			elt.Data4[4], elt.Data4[5], elt.Data4[6], elt.Data4[7]) ;
		if (IsEqualGUID (elt, GUID_COMPARTMENT_KEYBOARD_DISABLED)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_KEYBOARD_DISABLED")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_KEYBOARD_OPENCLOSE)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_KEYBOARD_OPENCLOSE")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_HANDWRITING_OPENCLOSE)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_HANDWRITING_OPENCLOSE")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_SPEECH_DISABLED)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_SPEECH_DISABLED")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_SPEECH_OPENCLOSE)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_SPEECH_OPENCLOSE")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_SPEECH_GLOBALSTATE)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_SPEECH_GLOBALSTATE")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_PERSISTMENUENABLED)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_PERSISTMENUENABLED")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_EMPTYCONTEXT)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_EMPTYCONTEXT")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_TIPUISTATUS)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_TIPUISTATUS")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_TRANSITORYEXTENSION)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_TRANSITORYEXTENSION")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_TRANSITORYEXTENSION_DOCUMENTMANAGER)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_TRANSITORYEXTENSION_DOCUMENTMANAGER")) ;
		} else if (IsEqualGUID (elt, GUID_COMPARTMENT_TRANSITORYEXTENSION_PARENT)) {
			DebugPrintf (TEXT (" GUID_COMPARTMENT_TRANSITORYEXTENSION_PARENT")) ;
		}
		DebugPrintf (TEXT ("\n")) ;
	}
	pEnum->Release () ;
	return	S_OK ;
}
#endif

/*========================================================================
 *	class CKeyboardInputModeChangeSession
 */
STDAPI
CKeyboardInputModeChangeSession::DoEditSession (TfEditCookie ec) 
{
	if (m_pSkkIme == NULL || m_pContext == NULL)
		return	E_FAIL ;

	(void) m_pSkkIme->OnChangeInputModeSession (m_pContext, ec, _uConversionMode, _uSentenseMode, _bUpdate) ;
	return	S_OK ;
}

