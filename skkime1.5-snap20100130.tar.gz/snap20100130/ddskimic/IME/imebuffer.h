#pragma once

#include "dchar.h"
#include "TMarker.h"
#include "RuleTreeNode.h"
#include "ImeConfig.h"

#define	MAXCOMPLEN		(256)
#define	MAXPREFIXLEN	(MAXCOMPLEN)
#define	MAXBUFMARKER	(16)

enum {
	LFALSE					= 0,
	LOFF					= LFALSE,
	LTRUE,
	LON						= LTRUE,
	LACTIVE,

	MAXLEN_PREFIX			= 256,
	MAXLEN_HENKAN_KEY		= 256,
	MAXLEN_HENKAN_OKURIGANA	= 256,

	MAXLEN_KAKUTEI_MIDASI	= MAXLEN_HENKAN_KEY,
	MAXLEN_KAKUTEI_WORD		= MAXCOMPLEN,
} ;

class CImeDoc ;
class CSkkRuleTreeNode ;
class CTSearchSession ;
class CTMarker ;
class CTS4Mapping ;
class CTS4Candidate ;
class CImeBufferProperty ;
class CSkkRuleTreeNodeOutput ;

#include "RuleTreeIterator.h"

class CImeBuffer {
public:
	enum {
		MARKER_POINT	= 0,
		MARKER_BUFFERTOP,
		MARKER_BUFFEREND,
		MARKER_MARK,
		MARKER_SKK_PREVIOUS_POINT,
		MARKER_SKK_KANA_START_POINT,
		MARKER_SKK_HENKAN_START_POINT,
		MARKER_SKK_HENKAN_END_POINT,
		MARKER_SKK_OKURIGANA_START_POINT,
		MAX_RESERVED_MARKERS
	} ;
private:
	CImeDoc*			m_pDoc ;
	CImeBuffer*			m_pParent ;

	/*	common buffer-local-variables
	 */
	DCHAR				m_bufComp [MAXCOMPLEN] ;
	int					m_nbufComp ;

	CTMarker*			m_rpmkMarker [MAX_RESERVED_MARKERS] ;
	CTMarker			m_rMarker [MAXBUFMARKER] ;
	int					m_nMarker ;

	/*	skk �� buffer-local-variables
	 */
//	const CSkkRuleTreeNode*	m_pSkkCurrentRuleTree ;
	CSkkRuleTreeIterator	m_iteSkkRuleTree ;
	CTMarker*			m_pmkPoint ;
	CTMarker*			m_pmkSkkKanaStartPoint ;
	CTMarker*			m_pmkSkkPreviousPoint ;
	CTMarker*			m_pmkSkkHenkanStartPoint ;
	CTMarker*			m_pmkSkkHenkanEndPoint ;
	CTMarker*			m_pmkSkkOkuriganaStartPoint ;

	DCHAR				m_bufSkkPrefix [MAXLEN_PREFIX] ;
	int					m_nSkkPrefixLen ;
	DCHAR				m_bufSkkHenkanKey [MAXLEN_HENKAN_KEY] ;
	int					m_nSkkHenkanKeyLen ;

	int					m_bSkkModeInvoked ;

	/* ���͂̏�ԂɊւ��郂�[�h�B*/
	int					m_bSkkMode ;
	int					m_bSkkLatinMode ;
	int					m_bSkkJMode ;
	int					m_bSkkJisx0208LatinMode ;
	int					m_bSkkAbbrevMode ;
	int					m_bSkkJisx0201Mode ;
	int					m_bSkkJisx0201Roman ;
	int					m_bSkkKatakana ;

	/* �ϊ�����Ɋւ��郂�[�h�B*/
	int					m_bSkkHenkanMode ;
//	int					m_bSkkHenkanOkurigana ;
	int					m_bSkkKakuteiFlag ;
	int					m_bSkkAfterPrefix ;

	int					m_bSkkHenkanInMinibuffFlag ;
	int					m_iSkkHenkanCount ;
	int					m_bSkkExitShowCandidates ;

	DCHAR				m_bufSkkHenkanOkurigana [MAXLEN_HENKAN_OKURIGANA] ;
	int					m_nSkkHenkanOkuriganaLen ;
	DCHAR				m_bufSkkOkuriChar [MAXLEN_HENKAN_OKURIGANA] ;
	int					m_nSkkOkuriCharLen ;
	int					m_bSkkOkurigana ;
	int					m_iSkkOkuriIndexMin ;
	int					m_iSkkOkuriIndexMax ;

	/* �m�藚���Ɋւ��� member variable */
	DCHAR				m_bufKakuteiMidasi [MAXLEN_KAKUTEI_MIDASI] ;
	int					m_nKakuteiMidasiLen ;
	DCHAR				m_bufKakuteiWord [MAXLEN_KAKUTEI_WORD] ;
	int					m_nKakuteiWordLen ;

	/* �ϊ���⌟���Ɋւ��� skk-current-search-prog-list �����c�B*/
	CTSearchSession*	m_pSkkCurrentSearchProgSession ;
	CTSearchSession*	m_pSkkCompSession ;

	/* #4 �o�^�̎��ɗ��p����B*/
	CTS4Mapping*		m_plstSkkS4NumericMapping ;

	/* ��Ǔ_�B*/
	int					m_iSkkCurrentKutotenType ;

	/* */
	DCHAR				m_bufLatestShiftText [MAXCOMPLEN] ;
	int					m_nLatestShiftTextLen ;

	BOOL				m_bSkkHenkanShowCandidatesMode ;
	BOOL				m_bSkkInputByCodeOrMenuMode ;
	BOOL				m_bSkkInputByCodeOrMenu1Mode ;

	/*	next-line, previous-line �̂��߂ɗ��p����B���Anext-line �� previous-line
	 *	���{���ɕK�v�Ȃ̂��H�Ƃ����^��́c����B
	 */
	int					m_nLineOffset ;

	/*	buffer property
	 */	
	CImeBufferProperty*	m_plstProperty ;

public:
	CImeBuffer () ;
	CImeBuffer (CImeDoc* pDoc) ;
	virtual						~CImeBuffer () ;

	virtual	BOOL				bInit (LPCDSTR wstrMessage, int nMessageLen, BOOL bSkkModeOn) ;
	virtual	void				vUninit () ;
	virtual	BOOL				bClear (BOOL bFullClear = FALSE) ;
	virtual	void				vSetParent (CImeBuffer* pParent) ;
	virtual	CImeBuffer*			pGetParent () ;
	virtual	LPCDSTR				pBufferRawString (int* pnLength) const ;
	virtual	LPCDSTR				pBufferString (int* pnLength) const ;
	virtual	BOOL				bHavePrefixp () const ;
	virtual	BOOL				bSetConversionString (LPCDSTR pwText, int nTextLen, BOOL bConv) ;
	virtual	int					iGetConversionMode () ;
	virtual	BOOL				bSetConversionMode (int) ;
	virtual BOOL				bSetReconvertText (LPCDSTR wstrText, int nTextLen) ;
	virtual	BOOL				bQueryUpdateContext (int* pnShift, int* pnCursor, BOOL* pfContinue) ;
	virtual	BOOL				bUpdateContext () ;
	virtual	BOOL				bGetSelectedRegion (int* pnStart, int* pnEnd) ;
	virtual	BOOL				bGetConvertedRegion	(int* pnStart, int* pnEnd) ;
	virtual	int					iGetReadingText (LPDSTR, int, int, int*) ;
	virtual	BOOL				bGetMarker (int nMarker, CTMarker** ppMarker) ;
	virtual	BOOL				bForwardChar (int) ;
	virtual	BOOL				bBackwardChar (int) ;
	virtual	BOOL				bFollowingStringEqualp (LPCDSTR, int) ;
	virtual	int					iInsert (CTMarker*, LPCDSTR, int) ;
	virtual	int					iInsert (CTMarker*, LPCWSTR, int) ;
	virtual	int					iInsertByPosition (int, LPCDSTR, int) ;
	virtual	int					iInsertBeforeMarkers (CTMarker*, LPCDSTR, int) ;
	virtual	int					iInsertBeforeMarkersByPosition (int, LPCDSTR, int) ;
	virtual	int					iOverwriteByPosition (int, LPCDSTR, int) ;
	virtual	BOOL				bInsertAndInherit (LPCDSTR, int) ;
	virtual	BOOL				bInsertAndInherit (LPCWSTR, int) ;
	virtual	BOOL				bInsertBeforeMarkers (LPCDSTR, int) ;
	virtual	BOOL				bDeleteRegion (int, int) ;
	virtual	BOOL				bDeleteBackwardChar (int nChar) ;
	virtual	CTMarker*			pMakeMarker (BOOL) ;
	virtual	BOOL				bDeleteMarker (CTMarker*) ;
	virtual	BOOL				bSetMarker (CTMarker**, int, const CTMarker*) ;
	virtual	BOOL				bJModep () const ;
	virtual	BOOL				bLatinModep () const ;
	virtual	BOOL				bJisx0208LatinModep	() const ;
	virtual	BOOL				bAbbrevModep () const ;
	virtual	BOOL				bKatakanaModep () const ;
	virtual	BOOL				bJisx0201Modep () const ;
	virtual	BOOL				bJisx0201Romanp () const ;
	virtual	BOOL				bShowHenkanCandidatesModep () const ;
	virtual	BOOL				bInputByCodeOrMenuModep () const ;
	virtual	BOOL				bInputByCodeOrMenu1Modep () const ;
	virtual	int					iGetLineOffset () const ;
	virtual	void				vSetLineOffset (int) ;
	virtual	BOOL				bSetReadingProperty	(const CTMarker*, const CTMarker*, LPCDSTR, int) ;
	virtual	void				vCopyState (const CImeBuffer* pBuffer) ;

public:
	virtual	CTMarker*			pGetPointMarker () ;
	virtual int					iGetPoint () const ;
	virtual	BOOL				bEobp () const ;
	virtual	int					iGetPointMax () const ;
	virtual	int					iGetCharAt (int iPosition) const ;

//	virtual const CSkkRuleTreeNode*	pSkkGetSkkCurrentRuleTree () const ;
//	void						vSkkSetSkkCurrentRuleTree (const CSkkRuleTreeNode* pNode) ;
	virtual	CSkkRuleTreeIterator*	pSkkGetSkkRuleTreeIterator () ;

	virtual	BOOL				bSkkErasePrefix (BOOL bClean) ;
	virtual	BOOL				bSkkSetMarker (CTMarker** ppMarker, int iMarkerIndex, const CTMarker* pSource) ;
	virtual	BOOL				bSkkSetSkkPreviousPoint (const CTMarker* pSource) ;
	virtual BOOL				bSkkSetSkkPreviousPointToPoint () ;
	virtual BOOL				bSkkSetSkkHenkanEndPointToPoint () ;
	virtual	BOOL				bSkkSetSkkHenkanEndPoint (const CTMarker* pSource) ;
	virtual	BOOL				bSkkSetSkkKanaStartPointToPoint () ;
	virtual	BOOL				bSkkSetSkkHenkanStartPointToPoint () ;
	virtual	BOOL				bSkkSetSkkOkuriganaStartPointToPoint () ;
	virtual	CTMarker*			pSkkGetSkkPreviousPointMarker () ; 
	virtual int					iSkkGetSkkHenkanStartPoint () const ;
	virtual CTMarker*			pSkkGetSkkHenkanStartPointMarker () ;
	virtual	int					iSkkGetSkkHenkanEndPoint () const ;
	virtual	CTMarker*			pSkkGetSkkHenkanEndPointMarker () ;
	virtual	void				vSkkClearSkkHenkanEndPoint () ;
	virtual	CTMarker*			pSkkGetSkkKanaStartPointMarker () ;
	virtual	int					iSkkGetSkkKanaStartPoint () const ;
	virtual	void				vSkkClearSkkKanaStartPoint () ;
	virtual	int					iSkkGetSkkOkuriganaStartPoint () const ;
	virtual CTMarker*			pSkkGetSkkOkuriganaStartPointMarker () ;

	virtual	BOOL				bSkkGetSkkMode () const ;
	virtual	void				vSkkSetSkkMode (int iValue) ;
	virtual	BOOL				bSkkGetSkkModeInvoked () const ;
	virtual	void				vSkkSetSkkHenkanMode (int iValue) ;
	virtual int					bSkkGetSkkHenkanMode () const ;
	virtual	void				vSkkSetSkkOkurigana (int iValue) ;
	virtual int					bSkkGetSkkOkurigana () const ;
	virtual	void				vSkkSetSkkKatakana (int iValue) ;
	virtual	int					bSkkGetSkkKatakana () const ;
	virtual	BOOL				bSkkGetSkkAfterPrefix () const ;
	virtual	BOOL				bSkkGetSkkKakuteiFlag () const ;
	virtual void				vSkkSetSkkKakuteiFlag (BOOL bValue) ;

	virtual int					iSkkGetSkkHenkanCount () const ;
	virtual	void				vSkkSetSkkHenkanCount (int iCount) ;
	virtual	void				vSkkSetSkkHenkanKey (LPCDSTR pwString, int nLength) ;
	virtual	BOOL				bSkkAddSkkHenkanKey (LPCDSTR pwString, int nLength) ;
	virtual	LPCDSTR				pSkkGetSkkHenkanKey (int* pnLength) const ;
	virtual	int					iSkkGetSkkHenkanKeyLength () const ;
	virtual	void				vSkkSetSkkPrefix (LPCDSTR pwString, int nLength) ;
	virtual	BOOL				bSkkAddSkkPrefix (int iCH) ;
	virtual	LPCDSTR				pSkkGetSkkPrefix (int* pnLength) const ;
	virtual	BOOL				bSkkValidSkkOkuriHenkanKeyp () const ;
	virtual	BOOL				bSkkNormalizeHenkanKey (BOOL bAllowNewlinesSpacesAndTabs) ;
	virtual	void				vSkkSetSkkAfterPrefix (int iValue) ;
	virtual	BOOL				bSkkTestOhConversion () const ;
	virtual	void				vSkkSetSkkOkuriChar (LPCDSTR pwString, int nLength) ;
	virtual	LPCDSTR				pSkkGetSkkOkuriChar (int* pnLength) const ;
	virtual	int					iSkkGetSkkOkuriCharLength () const ;
	virtual	void				vSkkSetSkkHenkanOkurigana (LPCDSTR pwString, int nLength) ;
	virtual	LPCDSTR				pSkkGetSkkHenkanOkurigana (int* pnLength) const ;
	virtual	int					iSkkGetSkkHenkanOkuriganaLength () const ;
	virtual	void				vSkkSetSkkHenkanInMinibuffFlag (int iValue) ; 
	virtual	int					iSkkGetSkkHenkanInMinibuffFlag () const ;
	virtual	int					iSkkGetSkkOkuriIndexMin () const ;
	virtual	int					iSkkGetSkkOkuriIndexMax () const ;
	virtual	void				vSkkSetSkkAbbrevMode (int iValue) ;
	virtual	CTSearchSession*	pSkkGetSkkCurrentSearchProgSession () ;
	virtual	void				vSkkSetSkkCurrentSearchProgSession (CTSearchSession* pSession) ;
	virtual	CTS4Mapping*		pSkkGetSkkS4NumericMappingList () ;
	virtual void				vSkkSetSkkS4NumericMappingList (CTS4Mapping* pListTop) ;
	virtual	LPCDSTR				pSkkGetKakuteiMidasi (int* pnLength) const ;
	virtual	LPCDSTR				pSkkGetKakuteiWord (int* pnLength) const ;
	virtual	void				vSkkSetSkkHenkanShowCandidatesMode (BOOL bValue) ;
	virtual void				vSkkSetSkkInputByCodeOrMenuMode (BOOL bValue) ;
	virtual	void				vSkkSetSkkInputByCodeOrMenu1Mode (BOOL bValue) ;

	virtual	CTSearchSession*	pSkkGetSkkCurrentCompletionSession () ;
	virtual	void				vSkkSetSkkCurrentCompletionSession (CTSearchSession* pSession) ;

	/* */
	virtual	BOOL				bSkkInsertPrefix (LPCDSTR pwPrefix, int nPrefixLen) ;
	virtual	BOOL				bSkkModeInvoke () ;
	virtual	BOOL				bSkkJModeOn (int iSkkOkurigana) ;
	virtual	BOOL				bSkkModeOff () ;
	virtual	BOOL				bSkkLatinModeOn () ;
	virtual	BOOL				bSkkJisx0208LatinModeOn	() ;
	virtual	BOOL				bSkkAbbrevModeOn () ;
	virtual	BOOL				bSkkJisx0201ModeOn (BOOL bRoman) ;
	virtual	void				vSetSkkJisx0201Mode (int iValue) ;
	virtual	void				vSetSkkJisx0201Roman (int iValue) ;
	virtual void				vSkkClearOkurigana () ;
	virtual	BOOL				bSkkChangeMarkerToWhite	() ;
	virtual	BOOL				bSkkInsertNewWord (LPCDSTR pwString, int nStringLen) ;
	virtual	int					iSkkOkuriganaPrefix (LPCDSTR, int, LPDSTR, int) ;
	virtual	BOOL				bSkkDeleteOkuriMark () ;
	virtual	BOOL				bSkkUpdateKakuteiHistory (LPCDSTR pMidashi, int nMidasiLen, LPCDSTR pWord, int nWordLen) ;
	virtual	BOOL				bSkkKakuteiCleanupBuffer () ;
	virtual	BOOL				bSkkKakuteiInitialize (LPCDSTR, int) ;
	virtual	BOOL				bSkkNumUpdateJisyo () ;
	virtual	BOOL				bValidRegionp (int nStartPos, int nEndPos) ;
	virtual	int					iSkkGetSkkCurrentKutotenType () const ;
	virtual	void				vSkkSetSkkCurrentKutotenType (int iValue) ;
	virtual int					bSkkHenkanActivep () const ;

	virtual	BOOL				bInitializeHenkanCandidateList (int iPageStart) ;

private:
	BOOL	_bSkkModeExit				() ;
	BOOL	_bSkkChangeMarker			() ;
	BOOL	_bSkkInsertStr				(LPCDSTR, int) ;
	BOOL	_bSkkMode					(int) ;
	BOOL	_bSkkDeleteHenkanMarkers (BOOL) ;
	BOOL	_bCreateHenkanCandidateList (int iPageStart) ;

private:
	int		_iGetShiftCount () ;
	BOOL	_bRegisterProperty (CImeBufferProperty* pProperty) ;
	BOOL	_bUnregisterProperty (CImeBufferProperty* pProperty) ;
	void	_vClearProperty () ;
	void	_vUpdateProperty () ;
	void	_vCopyProperty (const CImeBufferProperty* pProperty) ;
} ;



