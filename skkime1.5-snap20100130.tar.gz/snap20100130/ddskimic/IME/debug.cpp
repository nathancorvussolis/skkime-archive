#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif

#define	DEBUGFILENAME	TEXT("skimic.log")

#if !defined (_snwscanf_s)
int
_snwscanf_s (
	LPCWSTR		string, 
	int			nLen,
	LPCWSTR		strFormat,
	...) 
{
	return	0 ;
}
#endif

void
DebugPrintf (
	LPCTSTR	strFormat,
	...)
{
	TCHAR	buf [2048] ;
	va_list	vl ;

	va_start (vl, strFormat) ;
	wvnsprintf (buf, sizeof (buf) / sizeof (buf [0]), strFormat, vl) ;
	va_end (vl) ;
	OutputDebugString (buf) ;
	return ;
}

void
vDebugPrintfToFile (
	LPCTSTR	strFormat,
	...)
{
	TCHAR	buf [2048] ;
	va_list	vl ;
	HANDLE	hFile		= INVALID_HANDLE_VALUE ;
	DWORD	dwWritten	= 0, dwFileName = 0 ;
	TCHAR	szPath [MAX_PATH + 1] ;
	int		n ;

	/*	�f�o�b�O���O�̏o�̓p�X��ݒ肷��B*/
	dwFileName	= GetTempPath (MAX_PATH, szBuffer) ;
	if (dwFileName <= 0 || dwFileName >= MAX_PATH)
		return ;
	szBuffer [dwFileName]	= TEXT ('\0') ;
	n	= wnsprintf (szPath, MAX_PATH, TEXT ("%s%s"), szBuffer, DEBUGFILENAME) ;
	if (n < 0 || n >= MAX_PATH)
		return ;
	szPath [n]	= TEXT ('\0') ;

	va_start (vl, strFormat) ;
	n	= wvnsprintf (buf, sizeof (buf) / sizeof (buf [0]), strFormat, vl) ;
	va_end (vl) ;
	if (n <= 0)
		return ;
	
	hFile	= CreateFile (szPath, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE) 
		return ;
	SetFilePointer (hFile, 0, NULL, FILE_END) ;
	(void) WriteFile (hFile, buf, nText * sizeof (TCHAR), &dwWritten, NULL) ;
	CloseHandle (hFile) ;
	return ;
}


