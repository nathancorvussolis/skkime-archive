/*	config.cpp
 *
 *	ITfFnConfigure implementation
 */
#include "globals.h"
#include <shlwapi.h>
#include "skimic.h"
#include "skkimmgr.h"
#include "IME\ImeConfig.h"

//	�䂾�B
#define	DISPLAYNAME_DESC	L"SKKIME1.5(Disp)"

#define	PROGRAMF_DIR		L"IME"
#define	SKKIMEProg_S_DIR	L"SKKIM15"
#define	SKKIMEConfigFile	L"skimconf.exe"

HRESULT
CSkkImeTextService::Show (
	HWND		hwndParent,
	LANGID		langid,
	REFGUID		rguidProfile)
{
	WCHAR					rszWindowsDir [MAX_PATH + 1] ;
	WCHAR					rszCmd [MAX_PATH + 1] ;
    STARTUPINFOW			si ;
    PROCESS_INFORMATION		pi ;
	int						nWindowsDir, n ;
	BOOL					fRetval ;
	
	/*	Secure Session �Ȃ�� Config �͎��s���Ă͂Ȃ�Ȃ��B*/
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
	if (m_dwActivateFlag & TF_TMAE_SECUREMODE)
		return	E_FAIL ;
#endif
	if (langid != SKKIME_LANGID)
		return	E_FAIL ;

	nWindowsDir	= GetWindowsDirectoryW (rszWindowsDir, MAX_PATH) ;
	n			= (nWindowsDir < MAX_PATH)? nWindowsDir : MAX_PATH ;
#if defined (_MSC_VER) && ( _MSC_VER >= 1400 )
	rszWindowsDir [n]	= L'\0' ;
	wnsprintfW (rszCmd, MYARRAYSIZE (rszCmd) - 1, L"%s\\" PROGRAMF_DIR L"\\" SKKIMEProg_S_DIR L"\\" SKKIMEConfigFile, rszWindowsDir) ;
	rszCmd [MYARRAYSIZE (rszCmd) - 1]	= L'\0' ;
#else
	wcsncpy (rszCmd, rszWindowsDir, n) ;
	rszCmd [n]	= L'\0' ;
	wcsncpy (rszCmd + n, L"\\" PROGRAMF_DIR L"\\" SKKIMEProg_S_DIR L"\\" SKKIMEConfigFile, MAX_PATH - n) ;
	rszCmd [MAX_PATH - 1]	= L'\0' ;
#endif

	ZeroMemory (&si, sizeof(si)) ;
	si.cb	= sizeof (si) ;

	/*	������ pipename ��n���\���ɖ߂��Ă݂�B(�����P�T�N�V���Q�S��(��))
	 *	Windows2000sp4 �� skkiserv �� connect ���s���錻�ۂ�������̂ŁB
	 *	�����͂����̏������낤���H 
	 *	���̂� skkiserv �� pipename ������ɍ���Ă����Ɨ\�z���Ă��鎞��
	 *	if (! CreateProcessW (rszCmd, L"", NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
	 *	�����B
	 */
	if (! CreateProcessW (rszCmd, L"", NULL, NULL, FALSE, 0, NULL, rszWindowsDir, &si, &pi)) {
		fRetval	= FALSE ;
	} else {
		/* �s�v�ɂȂ����n���h��������B*/
		CloseHandle (pi.hProcess) ;
		CloseHandle (pi.hThread) ;
		fRetval	= TRUE ;
	}
	return	fRetval? S_OK : E_FAIL ;

	UNREFERENCED_PARAMETER (hwndParent) ;
	UNREFERENCED_PARAMETER (rguidProfile) ;
}

STDAPI
CSkkImeTextService::GetDisplayName (
	BSTR*			pbstrName)
{
	if (pbstrName == NULL)
		return	E_INVALIDARG ;
	
	*pbstrName	= SysAllocString (DISPLAYNAME_DESC) ;
	return	(*pbstrName == NULL)? E_OUTOFMEMORY : S_OK ;
}

BOOL
CSkkImeTextService::_InitConfig ()
{
	if (m_pConfig == NULL) 
		m_pConfig	= CImeConfig::pCreateInstance () ;
	if (m_pConfig == NULL)
		return	FALSE ;
	m_pConfig->vUpdate () ;
	return	TRUE ;
}

