#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "TSearchSessionP.h"
#include "TCommuSession.h"
#include "TPacket.h"
#include "jstring.h"
#include "debug.h"

/*========================================================================
 *	structures
 */
struct CTS4NumIndex {
	int		m_nIndex ;	/* #4 pos */
	int		m_nPos ;	/* candidate pos */
	int		m_nLen ;	/* candidate length */
} ;

struct CTS4Candidate {
	int						m_nKeyIndex ;		/* S4 keyword */
	int						m_nResultIndex ;	/* S4 result */
	int						m_nResultLength ;	/* S4 result length */
	struct CTS4Candidate*	m_pNext ;
} ;

struct CTSearchSessionCandidate {
	int									m_nIndex ;
	struct CTSearchSessionCandidate*	m_pPrev ;	/* ���t������������ێ����� prev, next */
	struct CTSearchSessionCandidate*	m_pNext ;
	struct CTSearchSessionCandidate*	m_pLeft ;	/* hash table �� entry �Ƃ��� left, right */
	struct CTSearchSessionCandidate*	m_pRight ;
	struct CTSearchSessionCandidate*	m_pRef ;
	struct CTS4Candidate*				m_pRefS4 ;
} ;

/*========================================================================
 *	prototypes
 */
static	struct CTS4Candidate*				TS4Candidate_pCreate	(int, int, int) ;
static	struct CTS4Candidate*				TS4Candidate_pGetNext	(struct CTS4Candidate*) ;
static	void								TS4Candidate_vSetNext	(struct CTS4Candidate*, struct CTS4Candidate*) ;

static	int		TSearchSessionCandidate_iGetValue		(struct CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_vSetPrevious	(struct CTSearchSessionCandidate*, struct CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_vSetNext		(struct CTSearchSessionCandidate*, struct CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_vSetLink		(struct CTSearchSessionCandidate*, struct CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_vAddLink2		(struct CTSearchSessionCandidate*, struct CTS4Candidate*) ;
static	void	TSearchSessionCandidate_vSetRight		(struct CTSearchSessionCandidate*, struct CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_vSetLeft		(struct CTSearchSessionCandidate*, struct CTSearchSessionCandidate*) ;
static	struct CTSearchSessionCandidate*	TSearchSessionCandidate_pGetPrevious	(struct CTSearchSessionCandidate*) ;
static	struct CTSearchSessionCandidate*	TSearchSessionCandidate_pGetNext		(struct CTSearchSessionCandidate*) ;
static	struct CTSearchSessionCandidate*	TSearchSessionCandidate_pGetLink		(struct CTSearchSessionCandidate*) ;
static	struct CTSearchSessionCandidate*	TSearchSessionCandidate_pGetLeft		(struct CTSearchSessionCandidate*) ;
static	struct CTSearchSessionCandidate*	TSearchSessionCandidate_pGetRight		(struct CTSearchSessionCandidate*) ;
static	struct CTS4Candidate*				TSearchSessionCandidate_pGetLink2		(struct CTSearchSessionCandidate*) ;

static	void	TSearchSession_vInitialize			(struct CTSearchSession*) ;
static	void	TSearchSession_vInitializeWithKeyword	(struct CTSearchSession*, LPCDSTR, int) ;
static	BOOL	tSearchSession_bSearch				(struct CTSearchSession*) ;
static	BOOL	tSearchSession_bUpdateCandidateList	(struct CTSearchSession*, int) ;
static	struct CTSearchSessionCandidate*	tSearchSession_pCreateCandidate	(struct CTSearchSession*, int, int, BOOL*) ;
static	BOOL	tSearchSession_bInsertCandidateLast (struct CTSearchSession*, struct CTSearchSessionCandidate*) ;
static	struct CTSearchSessionCandidate*	tSearchSession_pGetCandidate	(struct CTSearchSession*, LPCDSTR, int) ;
static	BOOL	tSearchSession_bIsExistCandidatep	(struct CTSearchSession*, LPCDSTR, int) ;
static	BOOL	tSearchSession_bRegisterCandidate	(struct CTSearchSession*, struct CTSearchSessionCandidate*) ;
static	BOOL	tSearchSession_bCleanupHashTable	(struct CTSearchSession*) ;
static	BOOL	tSearchSession_bCleanupHashTableSub	(struct CTSearchSessionCandidate*) ;
static	BOOL	tSearchSession_bIsSeparateChar		(struct CTSearchSession*, int) ;
static	BOOL	tSearchSession_bInsertCandidateNext (struct CTSearchSession*, struct CTSearchSessionCandidate*, struct CTSearchSessionCandidate*) ;
static	BOOL	tSearchSession_bRemoveCandidate		(struct CTSearchSession*, struct CTSearchSessionCandidate*) ;
static	BOOL	tSearchSession_bMultipleNumConvert	(struct CTSearchSession*) ;
static	BOOL	tSearchSession_bNumConvert			(struct CTSearchSession*, struct CTSearchSessionCandidate*, LPCDSTR, const struct CTS4Mapping*, BOOL*) ;

static	BOOL	_bNumExp			(LPCDSTR strNum, int nNumLen, int nType, TVarbuffer*) ;
static	BOOL	_bNumJisx0208Latin	(LPCDSTR strNum, int nNumLen, TVarbuffer*) ;
static	BOOL	_bNumType2Kanji		(LPCDSTR strNum, int nNumLen, TVarbuffer*) ;
static	BOOL	_bNumType3Kanji		(LPCDSTR strNum, int nNumLen, TVarbuffer*) ;
static	BOOL	_bNumType5Kanji		(LPCDSTR strNum, int nNumLen, TVarbuffer*) ;
static	BOOL	_bNumType4Kanji		(LPCDSTR strNum, int nNumLen, TVarbuffer*) ;
static	BOOL	_bIntNump			(LPCDSTR strNum, int nNumLen) ;
static	BOOL	_bIntOrFloatNump	(LPCDSTR strNum, int nNumLen) ;

/*========================================================================
 *	static global variables
 */
static	LPCWSTR		_wstrNumericUnit [] = {
	L"��",	L"��",	L"��",	L"��",	L"��",	L"�R",	L"��",	L"�a",
	L"��",	L"��",	L"��",	L"��",	L"�P�͍�",	L"���m�_",
	L"�ߗR��",	L"�s�v�c",	L"���ʑ吔",
} ;

static	LPCWSTR		_wstrKanjiDigits = L"�Z���O�l�ܘZ������" ;

static	LPCWSTR		_wstrNumericUnitType5 [] = {
	L"��",	L"��",	L"��",	L"��",	L"��",	L"�R",	L"��",	L"�a",
	L"��",	L"��",	L"��",	L"��",	L"�P�͍�",	L"���m�_",
	L"�ߗR��",	L"�s�v�c",	L"���ʑ吔",
} ;

static	LPCWSTR		_wstrKanjiDigitsType5 = L"����Q�l�ޘZ������" ;


/*========================================================================
 */
struct CTS4Candidate*
TS4Candidate_pCreate (
	int				nKeyIndex,
	int				nResultIndex,
	int				nResultLength)
{
	struct CTS4Candidate*	pNode ;

	pNode	= (struct CTS4Candidate*) MALLOC (sizeof (struct CTS4Candidate)) ;
	if (pNode == NULL)
		return	NULL ;
	pNode->m_nKeyIndex		= nKeyIndex ;
	pNode->m_nResultIndex	= nResultIndex ;
	pNode->m_nResultLength	= nResultLength ;
	pNode->m_pNext			= NULL ;
	return	pNode ;
}

struct CTS4Candidate*
TS4Candidate_pGetNext (
	struct CTS4Candidate*		pNode)
{
	return	pNode->m_pNext ;
}

void
TS4Candidate_vSetNext (
	struct CTS4Candidate*		pNode,
	struct CTS4Candidate*		pNextNode)
{
	pNode->m_pNext	= pNextNode ;
	return ;
}

/*========================================================================
 */
struct CTSearchSessionCandidate*
TSearchSessionCandidate_pCreate (int nPosition)
{
	struct CTSearchSessionCandidate*	pCand ;

	pCand	= (struct CTSearchSessionCandidate*) MALLOC (sizeof (struct CTSearchSessionCandidate)) ;
	if (pCand == NULL)
		return	NULL ;
	pCand->m_nIndex	= nPosition ;
	pCand->m_pPrev	= NULL ;
	pCand->m_pNext	= NULL ;
	pCand->m_pLeft	= NULL ;
	pCand->m_pRight	= NULL ;
	pCand->m_pRef	= NULL ;
	pCand->m_pRefS4	= NULL ;
	return	pCand ;
}

void
TSearchSessionCandidate_vDestroy (
	struct CTSearchSessionCandidate*		pCandidate)
{
	if (pCandidate == NULL)
		return ;
	if (pCandidate->m_pRefS4 != NULL) {
		struct CTS4Candidate*	pNode ;
		struct CTS4Candidate*	pNextNode ;

		pNode		= pCandidate->m_pRefS4 ;
		while (pNode != NULL) {
			pNextNode	= TS4Candidate_pGetNext (pNode) ;
			FREE (pNode) ;
			pNode		= pNextNode ;
		}
		pCandidate->m_pRefS4	= NULL ;
	}
	FREE (pCandidate) ;
	return ;
}

int
TSearchSessionCandidate_iGetValue (
	struct CTSearchSessionCandidate*		pCandidate)
{
	return	pCandidate->m_nIndex ;
}

void
TSearchSessionCandidate_vSetPrevious (
	struct CTSearchSessionCandidate*		pNode,
	struct CTSearchSessionCandidate*		pPrevNode)
{
	pNode->m_pPrev	= pPrevNode ;
	return ;
}

void
TSearchSessionCandidate_vSetNext (
	struct CTSearchSessionCandidate*		pNode,
	struct CTSearchSessionCandidate*		pNextNode)
{
	pNode->m_pNext	= pNextNode ;
	return ;
}

void
TSearchSessionCandidate_vSetLink (
	struct CTSearchSessionCandidate*		pNode,
	struct CTSearchSessionCandidate*		pLinkNode)
{
	pNode->m_pRef	= pLinkNode ;
	return ;
}

void
TSearchSessionCandidate_vAddLink2 (
	struct CTSearchSessionCandidate*		pNode,
	struct CTS4Candidate*					pNodeToBeLinked)
{
	if (pNodeToBeLinked == NULL || pNode == NULL)
		return ;

	if (pNode->m_pRefS4 == NULL) {
		pNode->m_pRefS4	= pNodeToBeLinked ;
	} else {
		struct CTS4Candidate*	pPrevNode ;
		struct CTS4Candidate*	pNodeS4 ;

		pPrevNode	= NULL ;
		pNodeS4		= pNodeToBeLinked ;
		while (pNodeS4 != NULL) {
			pPrevNode	= pNodeS4 ;
			pNodeS4		= TS4Candidate_pGetNext (pNodeS4) ;
		}
		TS4Candidate_vSetNext (pPrevNode, pNode->m_pRefS4) ;
		pNode->m_pRefS4	= pNodeToBeLinked ;
	}
	return ;
}

void
TSearchSessionCandidate_vSetLeft (
	struct CTSearchSessionCandidate*		pNode,
	struct CTSearchSessionCandidate*		pLeftNode)
{
	pNode->m_pLeft	= pLeftNode ;
	return ;
}

void
TSearchSessionCandidate_vSetRight (
	struct CTSearchSessionCandidate*		pNode,
	struct CTSearchSessionCandidate*		pRightNode)
{
	pNode->m_pRight	= pRightNode ;
	return ;
}

struct CTSearchSessionCandidate*
TSearchSessionCandidate_pGetPrevious (
	struct CTSearchSessionCandidate*		pNode)
{
	return	pNode->m_pPrev ;
}

struct CTSearchSessionCandidate*
TSearchSessionCandidate_pGetNext (
	struct CTSearchSessionCandidate*		pNode)
{
	return	pNode->m_pNext ;
}

struct CTSearchSessionCandidate*
TSearchSessionCandidate_pGetLink (
	struct CTSearchSessionCandidate*		pNode)
{
	return	pNode->m_pRef ;
}

struct CTS4Candidate*
TSearchSessionCandidate_pGetLink2 (
	struct CTSearchSessionCandidate*		pNode)
{
	return	pNode->m_pRefS4 ;
}

struct CTSearchSessionCandidate*
TSearchSessionCandidate_pGetLeft (
	struct CTSearchSessionCandidate*		pNode)
{
	return	pNode->m_pLeft ;
}

struct CTSearchSessionCandidate*
TSearchSessionCandidate_pGetRight (
	struct CTSearchSessionCandidate*		pNode)
{
	return	pNode->m_pRight ;
}

/*========================================================================
 */
void
TSearchSession_vInitialize (
	struct CTSearchSession*		pSession)
{
	int		i ;

	pSession->m_pCurCandidate	= NULL ;
	pSession->m_pTopCandidate	= NULL ;
	pSession->m_pLastCandidate	= NULL ;

	/*	hash table �̒��g�����O�ɏ��������Ă����B*/
	for (i = 0 ; i < CANDIDATEHASHSIZE ; i ++)
		pSession->m_rpTblCandidate [i]	= NULL ;

	pSession->m_nwstrKeyword	= 0 ;
	pSession->m_nCandidate		= 0 ;
	pSession->m_nSearchCount	= 0 ;
	pSession->m_nParsePosition	= 0 ;
	pSession->m_rszNumericList [0] = pSession->m_rszNumericList [1] = L'\0' ;

	pSession->m_pSearchProc			= NULL ;
	pSession->m_pIsSeparatorpProc	= NULL ;
	pSession->m_pNumberpProc		= NULL ;

	(void) TVarbuffer_Init (&pSession->m_vbufCandidate, sizeof (DCHAR)) ;
	return ;
}

void
TSearchSession_vInitializeWithKeyword (
	struct CTSearchSession*		pSession,
	LPCDSTR						wstrKeyword,
	int							nKeyword)
{
	int		i ;

	/*	���[�ށA���̕������c�B�v���g�R���͍��͌��ߑł��ɂ��Ă������B*/
	pSession->m_nwstrKeyword	= 0 ;
	pSession->m_pCurCandidate	= NULL ;
	pSession->m_pTopCandidate	= NULL ;
	pSession->m_pLastCandidate	= NULL ;

	/*	hash table �̒��g�����O�ɏ��������Ă����B*/
	for (i = 0 ; i < CANDIDATEHASHSIZE ; i ++)
		pSession->m_rpTblCandidate [i]	= NULL ;

	nKeyword			= (nKeyword > MAXKEYWORDLEN)? MAXKEYWORDLEN : nKeyword ;
	if (nKeyword > 0)
		memcpy (pSession->m_rszKeyword, wstrKeyword, nKeyword * sizeof (DCHAR)) ;
	pSession->m_nwstrKeyword		= nKeyword ;
	pSession->m_nCandidate			= 0 ;
	pSession->m_nSearchCount		= 0 ;
	pSession->m_nParsePosition		= 0 ;
	pSession->m_rszNumericList [0] = pSession->m_rszNumericList [1] = L'\0' ;

	pSession->m_pSearchProc			= NULL ;
	pSession->m_pIsSeparatorpProc	= NULL ;
	pSession->m_pNumberpProc		= NULL ;
	(void) TVarbuffer_Init (&pSession->m_vbufCandidate, sizeof (DCHAR)) ;
	return ;
}

void
TSearchSession_vDestroy (
	struct CTSearchSession*		pSession)
{
	if (pSession == NULL)
		return ;

	pSession->m_pCurCandidate	= NULL ;
	pSession->m_pTopCandidate	= NULL ;
	pSession->m_pLastCandidate	= NULL ;
	tSearchSession_bCleanupHashTable (pSession) ;
	FREE (pSession) ;
	return ;
}

LPCDSTR
TSearchSession_pGetKeyword (
	struct CTSearchSession*		pSession,
	int*						pnWord)
{
	if (pnWord != NULL)
		*pnWord	= pSession->m_nwstrKeyword ;
	return	pSession->m_rszKeyword ;
}

LPCDSTR
TSearchSession_pGetCandidate (
	struct CTSearchSession*		pSession)
{
	register int		nPosition ;

	if (pSession->m_pCurCandidate == NULL) {
		/*	���肦�Ȃ���ԁB*/
		if (pSession->m_pTopCandidate != NULL)
			return	NULL ;

		/*	Session ���p�����Ă������́A������������B*/
		while (pSession->m_nSearchCount >= 0) {
			if (! tSearchSession_bSearch (pSession))
				return	NULL ;
			if (pSession->m_pTopCandidate != NULL)
				break ;
		}
		/*	�����͑S�Ď��s���Ă���B*/
		if (pSession->m_pTopCandidate == NULL)
			return	NULL ;
		pSession->m_pCurCandidate	= pSession->m_pTopCandidate ;
	}
	
	nPosition		= TSearchSessionCandidate_iGetValue (pSession->m_pCurCandidate) ;
	ASSERT (0 <= nPosition && nPosition < TVarbuffer_GetUsage (&pSession->m_vbufCandidate)) ;
	return	(LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + nPosition ;
}

LPCDSTR
TSearchSession_pGetReferCandidate (
	struct CTSearchSession*		pSession)
{
	struct CTSearchSessionCandidate*	pRef	= NULL ; 
	int				nPosition ;

	/*	���̏ꍇ�ɂ́A�u������������v�Ȃ�Ďꏟ�Ȃ��Ƃ͂��Ȃ��B
	 */
	if (pSession->m_pCurCandidate == NULL) 
		return	NULL ;

	pRef	= TSearchSessionCandidate_pGetLink (pSession->m_pCurCandidate) ;
	if (pRef == NULL)
		return	NULL ;

	nPosition		= TSearchSessionCandidate_iGetValue (pRef) ;
	ASSERT (0 <= nPosition && nPosition < TVarbuffer_GetUsage (&pSession->m_vbufCandidate)) ;
	return	(LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + nPosition ;
}

/*	#4 �̑Ή��������� InsertCandidate �������Ƃ�������Ƃ����s����邱�Ƃ��l������B
 *	����ɑΉ����Ȃ���΂Ȃ�Ȃ��B
 *	�Ή������鎞������΁A�Ȃ���������Ƃ��������󋵂����݂����� (#4 �o�^�A�V�������Ȃ��Ă�
 *	������Ƃ��v�����Ƃ��B�������A#4 ����������̌�⒆�ɏo������Ƃ������Ԃ́c���[�X�P�[�X
 *	����l����Ɩ��������Ȃ񂾂��ǁB)
 */
BOOL
TSearchSession_bInsertCandidate (
	struct CTSearchSession*		pSession,
	LPCDSTR						wstrCandidate,
	int							nstrCandidate)
{
	struct CTSearchSessionCandidate*	pEntry ;
	BOOL	fRetval ;

	if (nstrCandidate <= 0 || wstrCandidate == NULL)
		return	FALSE ;

	if (pSession->m_pCurCandidate == NULL && pSession->m_pTopCandidate != NULL) 
		return	FALSE ;
	
	if (! TVarbuffer_Add (&pSession->m_vbufCandidate, wstrCandidate, nstrCandidate) ||
		! TVarbuffer_Add (&pSession->m_vbufCandidate, L"", 1))
		return	FALSE ;

	pEntry	= tSearchSession_pCreateCandidate (pSession, pSession->m_nParsePosition, nstrCandidate, &fRetval) ;

	/*	���̃p�[�Y�ʒu�̓o�b�t�@�̍Ō�ɂȂ�Ǝv���B*/
	pSession->m_nParsePosition	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;

	/*	���[�ށB����͂܂����ȁB*/
	if (pEntry == NULL)
		return	fRetval ;

	if (pSession->m_pCurCandidate != NULL) {
		struct CTSearchSessionCandidate*	pNextEntry ;

		pNextEntry	= TSearchSessionCandidate_pGetNext (pSession->m_pCurCandidate) ;
		TSearchSessionCandidate_vSetNext (pSession->m_pCurCandidate, pEntry) ;
		if (pNextEntry != NULL) {
			TSearchSessionCandidate_vSetPrevious (pNextEntry, pEntry) ;
			TSearchSessionCandidate_vSetNext (pEntry, pNextEntry) ;
		} else {
			pSession->m_pLastCandidate	= pEntry ;
		}
		TSearchSessionCandidate_vSetPrevious (pEntry, pSession->m_pCurCandidate) ;
	} else {
		pSession->m_pTopCandidate	= pEntry ;
		pSession->m_pCurCandidate	= pEntry ;
		pSession->m_pLastCandidate	= pEntry ;
	}
	pSession->m_nCandidate	++ ;

	/*	�����Ȃ萔�l�o�^�����\��������̂ŁA���ӂ���B
	 */
	if (TSearchSession_bNumericp (pSession)) {
		BOOL	bConverted	= FALSE ;

		if (tSearchSession_bNumConvert (pSession, pEntry, pSession->m_rszNumericList, NULL, &bConverted) && bConverted) {
			tSearchSession_bRemoveCandidate (pSession, pEntry) ;
			/*(��)
			 *	Create �̃^�C�~���O�� pEntry �� register ����Ă���̂ŁADestroy ���Ă΂Ȃ��Ă�
			 *	Session �j���̃^�C�~���O�� Destroy �����s�����B
			 */
		}
	}
	return	TRUE ;
}

BOOL
TSearchSession_bInsertCandidateWithS4Mapping (
	struct CTSearchSession*		pSession,
	LPCDSTR						wstrCandidate,
	int							nstrCandidate,
	const struct CTS4Mapping*	plstS4Mapping)
{
	struct CTSearchSessionCandidate*	pEntry ;
	BOOL	fRetval ;

	if (plstS4Mapping == NULL)
		return	TSearchSession_bInsertCandidate (pSession, wstrCandidate, nstrCandidate) ;

	if (nstrCandidate <= 0 || wstrCandidate == NULL)
		return	FALSE ;

	if (pSession->m_pCurCandidate == NULL && pSession->m_pTopCandidate != NULL) 
		return	FALSE ;
	
	if (! TVarbuffer_Add (&pSession->m_vbufCandidate, wstrCandidate, nstrCandidate) ||
		! TVarbuffer_Add (&pSession->m_vbufCandidate, L"", 1))
		return	FALSE ;

	pEntry	= tSearchSession_pCreateCandidate (pSession, pSession->m_nParsePosition, nstrCandidate, &fRetval) ;

	/*	���̃p�[�Y�ʒu�̓o�b�t�@�̍Ō�ɂȂ�Ǝv���B*/
	pSession->m_nParsePosition	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;

	/*	���[�ށB����͂܂����ȁB*/
	if (pEntry == NULL)
		return	fRetval ;

	if (pSession->m_pCurCandidate != NULL) {
		struct CTSearchSessionCandidate*	pNextEntry ;

		pNextEntry	= TSearchSessionCandidate_pGetNext (pSession->m_pCurCandidate) ;
		TSearchSessionCandidate_vSetNext (pSession->m_pCurCandidate, pEntry) ;
		if (pNextEntry != NULL) {
			TSearchSessionCandidate_vSetPrevious (pNextEntry, pEntry) ;
			TSearchSessionCandidate_vSetNext (pEntry, pNextEntry) ;
		} else {
			pSession->m_pLastCandidate	= pEntry ;
		}
		TSearchSessionCandidate_vSetPrevious (pEntry, pSession->m_pCurCandidate) ;
	} else {
		pSession->m_pTopCandidate	= pEntry ;
		pSession->m_pCurCandidate	= pEntry ;
		pSession->m_pLastCandidate	= pEntry ;
	}
	pSession->m_nCandidate	++ ;

	/*	�����Ȃ萔�l�o�^�����\��������̂ŁA���ӂ���B
	 */
	if (TSearchSession_bNumericp (pSession)) {
		BOOL	bConverted	= FALSE ;

		if (tSearchSession_bNumConvert (pSession, pEntry, pSession->m_rszNumericList, plstS4Mapping, &bConverted) && bConverted) {
			tSearchSession_bRemoveCandidate (pSession, pEntry) ;
			/*(��)
			 *	Create �̃^�C�~���O�� pEntry �� register ����Ă���̂ŁADestroy ���Ă΂Ȃ��Ă�
			 *	Session �j���̃^�C�~���O�� Destroy �����s�����B
			 */
		}
	}
	return	TRUE ;
}

BOOL
TSearchSession_bRemoveCandidate (
	struct CTSearchSession*		pSession)
{
	return	tSearchSession_bRemoveCandidate (pSession, pSession->m_pCurCandidate) ;
}

BOOL
TSearchSession_bLinkCandidate (
	struct CTSearchSession*				pSession,
	struct CTSearchSessionCandidate*	pCandidate)
{
	if (pSession->m_pCurCandidate == NULL)
		return	FALSE ;
	TSearchSessionCandidate_vSetLink (pSession->m_pCurCandidate, pCandidate) ;
	return	TRUE ;
}

struct CTSearchSessionCandidate*
TSearchSession_pGetCurrentPoint (
	struct CTSearchSession*		pSession)
{
	return	pSession->m_pCurCandidate ;
}

int
TSearchSession_iGetNumberOfCandidate (
	struct CTSearchSession*		pSession,
	BOOL*						pfContinue)
{
	if (pfContinue != NULL)
		*pfContinue	= (pSession->m_nSearchCount >= 0) ;
	return	pSession->m_nCandidate ;
}

BOOL
TSearchSession_bNextCandidate (
	struct CTSearchSession*		pSession)
{
	struct CTSearchSessionCandidate*	pCandidate ;

	if (pSession->m_pCurCandidate == NULL)
		return	FALSE ;
	pCandidate		= TSearchSessionCandidate_pGetNext (pSession->m_pCurCandidate) ;
	if (pCandidate == NULL) {
		/*	Session ���p�����Ă������́A������������B*/
		while (pSession->m_nSearchCount >= 0) {
			if (! tSearchSession_bSearch (pSession))
				return	FALSE ;
			pCandidate	= TSearchSessionCandidate_pGetNext (pSession->m_pCurCandidate) ;
			if (pCandidate != NULL)
				break ;
		}
		if (pCandidate == NULL)
			return	FALSE ;
	}
	pSession->m_pCurCandidate	= pCandidate ;
	return	TRUE ;
}

BOOL
TSearchSession_bPreviousCandidate (
	struct CTSearchSession*		pSession)
{
	struct CTSearchSessionCandidate*	pCandidate ;

	if (pSession->m_pCurCandidate == NULL)
		return	FALSE ;
	pCandidate		= TSearchSessionCandidate_pGetPrevious (pSession->m_pCurCandidate) ;
	if (pCandidate == NULL)
		return	FALSE ;
	pSession->m_pCurCandidate	= pCandidate ;
	return	TRUE ;
}

BOOL
TSearchSession_bRewind (
	struct CTSearchSession*		pSession)
{
	pSession->m_pCurCandidate	= pSession->m_pTopCandidate ;
	return	TRUE ;
}

BOOL
TSearchSession_bNumericp (
	const struct CTSearchSession*		pSession)
{
	/* �����������K�v�B*/
	return	(pSession->m_pNumberpProc == NULL)? FALSE : (pSession->m_pNumberpProc)(pSession) ;
}

LPCDSTR
TSearchSession_pGetNumericList (
	const struct CTSearchSession*	pSession)
{
	if (pSession->m_pNumberpProc != NULL && (pSession->m_pNumberpProc)(pSession)) {
		return	pSession->m_rszNumericList ;
	} else {
		return	NULL ;
	}
}

struct CTS4Candidate*
TSearchSession_pGetNumericLink (
	struct CTSearchSession*		pSession)
{
	struct CTS4Candidate*	pRef	= NULL ; 

	/*	���̏ꍇ�ɂ́A�u������������v�Ȃ�Ďꏟ�Ȃ��Ƃ͂��Ȃ��B
	 */
	if (pSession->m_pCurCandidate == NULL) 
		return	NULL ;

	pRef	= TSearchSessionCandidate_pGetLink2 (pSession->m_pCurCandidate) ;
	if (pRef == NULL)
		return	NULL ;

	return	pRef ;
}

LPCDSTR
TSearchSession_pGetNumericKeyword (
	struct CTSearchSession*		pSession,
	struct CTS4Candidate*		pNumCand,
	int*						pnKeywordLen)
{
	LPCDSTR	pwKeyword ;

	if (pSession == NULL || pNumCand == NULL)
		return	NULL ;
	/* error check */
	if (pNumCand->m_nKeyIndex < 0 || pNumCand->m_nKeyIndex >= TVarbuffer_GetUsage (&pSession->m_vbufCandidate))
		return	NULL ;

	pwKeyword	= (LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + pNumCand->m_nKeyIndex ;
	if (pnKeywordLen != NULL)
		*pnKeywordLen	= dcslen (pwKeyword) ;
	return	pwKeyword ;
}

LPCDSTR
TSearchSession_pGetNumericResult (
	struct CTSearchSession*		pSession,
	struct CTS4Candidate*		pNumCand,
	int*						pnResultLen)
{
	if (pSession == NULL || pNumCand == NULL)
		return	NULL ;
	/* error check */
	if (pNumCand->m_nResultIndex < 0 || (pNumCand->m_nResultIndex + pNumCand->m_nResultLength) > TVarbuffer_GetUsage (&pSession->m_vbufCandidate))
		return	NULL ;
	if (pnResultLen != NULL)
		*pnResultLen	= pNumCand->m_nResultLength ;
	
	return	(LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + pNumCand->m_nResultIndex ;
}

struct CTS4Candidate*
TSearchSession_pGetNextNumericLink (
	struct CTSearchSession*		pSession,
	struct CTS4Candidate*		pNumCand)
{
	if (pSession == NULL || pNumCand == NULL)
		return	NULL ;
	return	TS4Candidate_pGetNext (pNumCand) ;
}

/*===============================================================
 */
BOOL
tSearchSession_bSearch (
	struct CTSearchSession*		pSession)
{
	return	(pSession == NULL || pSession->m_pSearchProc == NULL)? FALSE : (pSession->m_pSearchProc)(pSession) ;
}

BOOL
tSearchSession_bUpdateCandidateList (
	struct CTSearchSession*		pSession,
	int							nPosition)
{
	int		nEndPos, iSlashCheck, nCount, nPrevPos ;
	BOOL	fDoubleQuoteCheck ;
	LPDSTR	ptr ;
#if defined (DBG) || defined (DEBUG)
	int		nFound = 0 ;
#endif

	ptr					= (LPDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + nPosition ;
	nEndPos				= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
	fDoubleQuoteCheck	= FALSE ;
	nCount				= 0 ;
	iSlashCheck			= 0 ;
	if (nPosition == 0) {
		while (nPosition < nEndPos && ! tSearchSession_bIsSeparateChar (pSession, *ptr)) {
			ptr			++ ;
			nPosition	++ ;
		}
	}
	nPrevPos			= nPosition ;

	while (nPosition < nEndPos) {
		/* �_�u���N�E�H�[�g�𖳎�����_�������Ŋm�F����B*/
		if (iSlashCheck <= 0 && *ptr == L'\\')
			iSlashCheck	= 2 ;
		if (iSlashCheck <= 0) {
			switch (*ptr){
				/* Double Quote �̊Ԃ͗v���ӁB�o�b�N�X���b�V���̎��ł͂Ȃ��_�u
				 * ���N�E�H�[�g�Ɉ͂܂ꂽ�����͈�̕�����(�Ƃ��������Ƃ���
				 * ���������B���ɂ��̒��� slash �������Ă��Ă��������邱�Ƃɂ�
				 * ��B*/  
			case 0x22:
				if (!fDoubleQuoteCheck){
					/* �����_�u���N�E�H�[�g�̒��ɂȂ���΁A���������̕���
					 * �񂪊J�n�������ƂɂȂ�B*/
					fDoubleQuoteCheck	= TRUE ;
				} else {
					/* �����_�u���N�E�H�[�g�̒��Ń_�u���N�E�H�[�g�����t������c�B 
					 * ���R�A�_�u���N�E�H�[�g�̒��𔲂������ƂɂȂ�B*/
					fDoubleQuoteCheck 	= FALSE ;
				}
				/* �J�[�\���ʒu�̈ړ��B*/
				ptr			++ ;
				nPosition	++ ;
				nCount		++ ;
				continue ;
				
				/* ������̏I�[�����t���Ă��܂����ꍇ�̏����B*/
			case L'\n' :
			case L'\r' :
			case L'\0' :
				/* �������ɏI�[�����̓_�u���N�E�H�[�g�̒����낤�������낤����
				 * ���ł��Ȃ��c�B�����_�u���N�E�H�[�g�̒��ɓo�ꂵ����G���[��
				 * �O�̉��҂ł��Ȃ��B*/
				goto exit_loop ;

			default :
				/* �^�͌��ƌ��̊ԂɕK�����݂���B*/
				if (tSearchSession_bIsSeparateChar (pSession, *ptr)) {
					/* �_�u���N�E�H�[�g�̒��ɓo�ꂵ���̂ł���΁A�{���̋@�\�͖����B*/
					if (fDoubleQuoteCheck)
						break ;
				
					/* �����̈ʒu�̕����͏I�[�������č\���܂��B���F��؂�ȊO�ɖ�
					 * �����ĂȂ��̂�����B����Ȃ� NUL �����ł��\���B*/
					*ptr	= L'\0' ;
					/* �V�����m�[�h���������B*/
					if (nCount > 0 && nPrevPos < nPosition) {
						struct CTSearchSessionCandidate*	pNewEntry ;
						BOOL	bRetval ;

						/*	����(annotation) �����݂���\��������B�\���c�ł��邩
						 *	�ۂ��͒u���Ă����āA���̏����������Ȃ���΁B
						 */
						pNewEntry	= tSearchSession_pCreateCandidate (pSession, nPrevPos, nCount, &bRetval) ;
						if (pNewEntry != NULL)
							(void) tSearchSession_bInsertCandidateLast (pSession, pNewEntry) ;
#if defined (DBG) || defined (DEBUG)
						nFound ++ ;
#endif
					}
					/* �ꏊ�y�сA�|�C���^������₷�B*/
					ptr			++ ;
					nPosition	++ ;
					/* �O��(�܂荡�̏ꏊ)�A"/" �����t�����ꏊ�� pPos �ɋL������B*/
					nPrevPos	= nPosition ;
					nCount		= 0 ;
					continue ;
				} else {
					break ;
				}
			}
		}
		ptr			++ ;
		nPosition	++ ;
		nCount		++ ;
		if (iSlashCheck > 0)
			iSlashCheck	-- ;
	}
  exit_loop:
#if defined (DBG) || defined (DEBUG)
	DEBUGPRINTF ((TEXT ("_bUpdateCandidateList (found: %d)\n"), nFound)) ;
#endif
	return	nPrevPos ;
}

struct CTSearchSessionCandidate*
tSearchSession_pCreateCandidate (
	struct CTSearchSession*		pSession,
	int							nPosition,
	int							nCount,
	BOOL*						pfRetval)	/* ���ɑ��݂��Ă������ǂ����B*/
{
	struct CTSearchSessionCandidate*	pEntry ;
	LPCDSTR	wstring ;

	wstring	= (LPDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + nPosition ;
	if (tSearchSession_bIsExistCandidatep (pSession, wstring, nCount)) {
		if (pfRetval)
			*pfRetval	= TRUE ;
		return	NULL ;
	}
	pEntry	= TSearchSessionCandidate_pCreate (nPosition) ;
	if (pEntry == NULL) {
		if (pfRetval)
			*pfRetval	= FALSE ;
		return	NULL ;
	}
	if (! tSearchSession_bRegisterCandidate (pSession, pEntry)) {
		TSearchSessionCandidate_vDestroy (pEntry) ;
		if (pfRetval)
			*pfRetval	= FALSE ;
		return	NULL ;
	}
	if (pfRetval)
		*pfRetval	= FALSE ;
	return	pEntry ;
}

BOOL
tSearchSession_bInsertCandidateLast (
	struct CTSearchSession*				pSession,
	struct CTSearchSessionCandidate*	pEntry)
{
	if (pSession->m_pLastCandidate != NULL) 
		TSearchSessionCandidate_vSetNext (pSession->m_pLastCandidate, pEntry) ;
	if (pSession->m_pTopCandidate == NULL)
		pSession->m_pTopCandidate	= pEntry ;
	TSearchSessionCandidate_vSetPrevious (pEntry, pSession->m_pLastCandidate) ;
	pSession->m_pLastCandidate	= pEntry ;
	pSession->m_nCandidate	++ ;
	return	TRUE ;
}

struct CTSearchSessionCandidate*
tSearchSession_pGetCandidate (
	struct CTSearchSession*		pSession,
	LPCDSTR						dstring,
	int							nstring)
{
	struct CTSearchSessionCandidate*	pEntry ;
	int		nIndex, nPosition, nszBuffer, nCompare ;
	LPCDSTR	dszBuffer ;

	nIndex		= (unsigned int)*dstring * nstring % CANDIDATEHASHSIZE ;
	ASSERT (0 <= nIndex && nIndex < CANDIDATEHASHSIZE) ;
	pEntry		= pSession->m_rpTblCandidate [nIndex] ;
	if (pEntry == NULL)
		return	NULL ;
	dszBuffer	= (LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) ;
	nszBuffer	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
	while (pEntry != NULL) {
		nPosition	= TSearchSessionCandidate_iGetValue (pEntry) ;
		ASSERT (0 <= nPosition && nPosition < nszBuffer) ;
		nCompare	= dcsncmp (dstring, dszBuffer + nPosition, nstring) ;
		if (nCompare == 0) {
			if (*(dszBuffer + nPosition + nstring) == L'\0') 
				return	pEntry ;
			nCompare	= 1 ;
		}
		if (nCompare > 0) {
			pEntry	= TSearchSessionCandidate_pGetRight (pEntry) ;
		} else {
			pEntry	= TSearchSessionCandidate_pGetLeft (pEntry) ;
		}
	}
	return	NULL ;
}

BOOL
tSearchSession_bIsExistCandidatep (
	struct CTSearchSession*		pSession,
	LPCDSTR						dstring,
	int							nstring)
{
	struct CTSearchSessionCandidate*	pEntry ;
	int		nIndex, nPosition, nszBuffer, nCompare ;
	LPCDSTR	dszBuffer ;

	nIndex		= (unsigned int)*dstring * nstring % CANDIDATEHASHSIZE ;
	ASSERT (0 <= nIndex && nIndex < CANDIDATEHASHSIZE) ;
	pEntry		= pSession->m_rpTblCandidate [nIndex] ;
	if (pEntry == NULL)
		return	FALSE ;
	dszBuffer	= (LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) ;
	nszBuffer	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
	while (pEntry != NULL) {
		nPosition	= TSearchSessionCandidate_iGetValue (pEntry) ;
		ASSERT (0 <= nPosition && nPosition < nszBuffer) ;
		nCompare	= dcsncmp (dstring, dszBuffer + nPosition, nstring) ;
		if (nCompare == 0) {
			if (*(dszBuffer + nPosition + nstring) == L'\0') 
				return	TRUE ;
			nCompare	= 1 ;
		}
		if (nCompare > 0) {
			pEntry	= TSearchSessionCandidate_pGetRight (pEntry) ;
		} else {
			pEntry	= TSearchSessionCandidate_pGetLeft (pEntry) ;
		}
	}
	return	FALSE ;
}

BOOL
tSearchSession_bRegisterCandidate (
	struct CTSearchSession*				pSession,
	struct CTSearchSessionCandidate*	pNewEntry)
{
	struct CTSearchSessionCandidate*	pEntry ;
	int		nIndex, nPosition, nstring, nszBuffer, nCompare ;
	LPCDSTR	dszBuffer ;
	LPCDSTR	dstring ;

	dszBuffer	= (LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) ;
	nszBuffer	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
	dstring		= dszBuffer + TSearchSessionCandidate_iGetValue (pNewEntry) ;
	nstring		= dcslen (dstring) ;
	nIndex		= (unsigned int)*dstring * nstring % CANDIDATEHASHSIZE ;
	ASSERT (0 <= nIndex && nIndex < CANDIDATEHASHSIZE) ;
	pEntry		= pSession->m_rpTblCandidate [nIndex] ;
	if (pEntry == NULL) {
		pSession->m_rpTblCandidate [nIndex]	= pNewEntry ;
		return	TRUE ;
	}

	while (pEntry != NULL) {
		nPosition	= TSearchSessionCandidate_iGetValue (pEntry) ;
		ASSERT (0 <= nPosition && nPosition < nszBuffer) ;
		nCompare	= dcsncmp (dstring, dszBuffer + nPosition, nstring) ;
		if (nCompare == 0) {
			if (*(dszBuffer + nPosition + nstring) == L'\0') 
				return	TRUE ;
			nCompare	= 1 ;
		}
		if (nCompare > 0) {
			if (TSearchSessionCandidate_pGetRight (pEntry) == NULL) {
				TSearchSessionCandidate_vSetRight (pEntry, pNewEntry) ;
				return	TRUE ;
			}
			pEntry	= TSearchSessionCandidate_pGetRight (pEntry) ;
		} else {
			if (TSearchSessionCandidate_pGetLeft (pEntry) == NULL) {
				TSearchSessionCandidate_vSetLeft (pEntry, pNewEntry) ;
				return	TRUE ;
			}
			pEntry	= TSearchSessionCandidate_pGetLeft (pEntry) ;
		}
	}
	return	FALSE ;
}

BOOL
tSearchSession_bCleanupHashTable (
	struct CTSearchSession*		pSession)
{
	register int		i ;

	for (i = 0 ; i < CANDIDATEHASHSIZE ; i ++) {
		if (pSession->m_rpTblCandidate [i] != NULL)
			tSearchSession_bCleanupHashTableSub (pSession->m_rpTblCandidate [i]) ;
	}
	return	TRUE ;
}

BOOL
tSearchSession_bCleanupHashTableSub (
	struct CTSearchSessionCandidate*	pEntry)
{
	ASSERT (pEntry != NULL) ;

	if (TSearchSessionCandidate_pGetLeft (pEntry) != NULL) 
		tSearchSession_bCleanupHashTableSub (TSearchSessionCandidate_pGetLeft (pEntry)) ;
	if (TSearchSessionCandidate_pGetRight (pEntry) != NULL)
		tSearchSession_bCleanupHashTableSub (TSearchSessionCandidate_pGetRight (pEntry)) ;
	TSearchSessionCandidate_vDestroy (pEntry) ;
	return	TRUE ;
}

BOOL
tSearchSession_bIsSeparateChar (
	struct CTSearchSession*		pSession,
	int							nCH)
{
	return	(pSession->m_pIsSeparatorpProc != NULL)? (pSession->m_pIsSeparatorpProc)(pSession, nCH) : (nCH == L'/') ;
}

BOOL
tSearchSession_bInsertCandidateNext (
	struct CTSearchSession*				pSession,
	struct CTSearchSessionCandidate*	pNode,
	struct CTSearchSessionCandidate*	pNewNode)
{
	if (pNewNode == NULL)
		return	FALSE ;

	if (pNode == NULL) {
		TSearchSessionCandidate_vSetNext (pNewNode, pSession->m_pTopCandidate) ;
		TSearchSessionCandidate_vSetPrevious (pNewNode, NULL) ;
		if (pSession->m_pTopCandidate != NULL) {
			TSearchSessionCandidate_vSetPrevious (pSession->m_pTopCandidate, pNewNode) ;
			pSession->m_pTopCandidate	= pNewNode ;
		} else {
			pSession->m_pCurCandidate	= pNewNode ;
			pSession->m_pTopCandidate	= pNewNode ;
			pSession->m_pLastCandidate	= pNewNode ;
		}
	} else {
		struct CTSearchSessionCandidate*	pNextNode ;

		pNextNode	= TSearchSessionCandidate_pGetNext (pNode) ;
		TSearchSessionCandidate_vSetNext (pNode, pNewNode) ;
		TSearchSessionCandidate_vSetPrevious (pNewNode, pNode) ;
		TSearchSessionCandidate_vSetNext (pNewNode, pNextNode) ;
		if (pNextNode != NULL) {
			TSearchSessionCandidate_vSetPrevious (pNextNode, pNewNode) ;
		} else {
			/*if (m_pLastCandidate == pNode) */
			pSession->m_pLastCandidate	= pNewNode ;
		}
	}
	pSession->m_nCandidate	++ ;
	return	TRUE ;
}

BOOL
tSearchSession_bRemoveCandidate (
	struct CTSearchSession*				pSession,
	struct CTSearchSessionCandidate*	pEntry)
{
	struct CTSearchSessionCandidate*	pPrevEntry ;
	struct CTSearchSessionCandidate*	pNextEntry ;

	if (pEntry == NULL)
		return	FALSE ;

	pNextEntry	= TSearchSessionCandidate_pGetNext (pEntry) ;
	pPrevEntry	= TSearchSessionCandidate_pGetPrevious (pEntry) ;

	if (pPrevEntry != NULL) {
		TSearchSessionCandidate_vSetNext (pPrevEntry, pNextEntry) ;
	} else {
		pSession->m_pTopCandidate	= pNextEntry ;
	}
	if (pNextEntry != NULL) {
		TSearchSessionCandidate_vSetPrevious (pNextEntry, pPrevEntry) ;
	} else {
		pSession->m_pLastCandidate	= pPrevEntry ;
	}
	if (pEntry == pSession->m_pCurCandidate) {
		if (pNextEntry != NULL) {
			pSession->m_pCurCandidate	= pNextEntry ;
		} else {
			pSession->m_pCurCandidate	= pPrevEntry ;
		}
	}
#if defined (DBG) || defined (DEBUG)
	if (pSession->m_nCandidate <= 0) {
		DEBUGPRINTF ((TEXT ("Something wrong in RemoveCandiate (%d < 0)\n"), pSession->m_nCandidate)) ;
	}
#endif
	pSession->m_nCandidate	-- ;
	return	TRUE ;
}

BOOL
tSearchSession_bMultipleNumConvert (
	struct CTSearchSession*				pSession)
{
	struct CTSearchSessionCandidate*	pNode ;
	struct CTSearchSessionCandidate*	pNextNode ;
	BOOL						bConverted ;

	pNode	= pSession->m_pTopCandidate ;
	while (pNode != NULL) {
		pNextNode	= TSearchSessionCandidate_pGetNext (pNode) ;
		/* �����ł��� Candidate �� num-convert ����B*/
		bConverted	= FALSE ;
		if (tSearchSession_bNumConvert (pSession, pNode, pSession->m_rszNumericList, NULL, &bConverted) && bConverted) {
			tSearchSession_bRemoveCandidate (pSession, pNode) ;
		}
		pNode		= pNextNode ;
	}
	return	TRUE ;
}

BOOL
tSearchSession_bNumConvert (
	struct CTSearchSession*				pSession,
	struct CTSearchSessionCandidate*	pEntry,
	LPCDSTR								wstrNumList,
	const struct CTS4Mapping*			plstS4Mapping,
	BOOL*								pbConverted)
{
	TVarbuffer		vbuf ;			/* CVarbuffer < CVarbuffer < DCHAR, 16 >*, 16 >	vbuf ; */
	TVarbuffer		vbufPos ;		/* CVarbuffer < int, 16 >	vbufPos ; */
	TVarbuffer		vbufS4Index ;	/* CVarbuffer < int, 16 >	vbufCount ; */
	TVarbuffer		vbufDest ;		/* CVarbuffer < DCHAR, 16 >	vbufDest ; */
	TVarbuffer		vbufNumIndex ;	/* CVarbuffer < int, 16 >	vbufNumIndex ; */
	TVarbuffer*		pvbuf ;
	TVarbuffer**	ppvbuf ;
	LPCDSTR		dstrSrc ;
	int			nSrcLen ;
	LPCDSTR		pSrc, pSrcEnd, pNum ;
	int			i, nNumIndex ;
	int*		pnNumIndex ;
	const struct CTS4Mapping*	pS4Node ;
	BOOL		bRetval		= FALSE ;
	BOOL		bConverted	= FALSE ;
	const DCHAR	c_Zero []	= { 0, 0 } ;

	if (pEntry == NULL)
		return	FALSE ;
	if (! TVarbuffer_Init (&vbuf,			sizeof (TVarbuffer*))			||
		! TVarbuffer_Init (&vbufPos,		sizeof (int))					||
		! TVarbuffer_Init (&vbufDest,		sizeof (DCHAR))					||
		! TVarbuffer_Init (&vbufS4Index,	sizeof (struct CTS4NumIndex))	||
		! TVarbuffer_Init (&vbufNumIndex,	sizeof (int)))
		return	FALSE ;

	dstrSrc	= (LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + TSearchSessionCandidate_iGetValue (pEntry) ;
	nSrcLen	= dcslen (dstrSrc) ;

	pSrc		= dstrSrc ;
	pSrcEnd		= dstrSrc + nSrcLen ;
	pNum		= wstrNumList ;
	nNumIndex	= 0 ;
	pS4Node		= plstS4Mapping ;

	while (pSrc < pSrcEnd) {
		if (*pSrc == L'#') {
			pSrc	++ ;
			if (pSrc < pSrcEnd && L'0' <= *pSrc && *pSrc <= L'9') {
				int		nNumType ;

				/* number ��W�J����B*/
				nNumType	= *pSrc - L'0';
				/* ������ #4 �ϊ��������ꍇ�ɂ͓�����1�ɂȂ�Ȃ��B*/
				if (*pNum != L'\0') {
					int		nNumLen ;

					nNumLen	= dcslen (pNum) ;
					pvbuf	= (TVarbuffer*) MALLOC (sizeof (TVarbuffer)) ;
					if (pvbuf == NULL)
						goto	exit_func ;
					if (! TVarbuffer_Init (pvbuf, sizeof (DCHAR))) {
						TVarbuffer_Uninit (pvbuf) ;
						FREE (pvbuf) ;
						goto	exit_func ;
					}
					/*	#4 �̓W�J���@�������ɗ^�����Ă���ꍇ�ɂ́A���������s���Ȃ��B
					 */
					if (nNumType == 4				&& 
						pS4Node != NULL				&& 
						pS4Node->m_nResultLen > 0	&&
						!dcsncmp (pNum, pS4Node->m_pwKeyword, nNumLen) &&
						pS4Node->m_pwKeyword [nNumLen] == L'\0') {
						if (! TVarbuffer_Add (pvbuf, pS4Node->m_pwResult, pS4Node->m_nResultLen) ||
							! TVarbuffer_Add (pvbuf, c_Zero, 2)) {
							TVarbuffer_Uninit (pvbuf) ;
							FREE (pvbuf) ;
							goto	exit_func ;
						}
					} else {
						if (! _bNumExp (pNum, nNumLen, nNumType, pvbuf)) {
							TVarbuffer_Uninit (pvbuf) ;
							FREE (pvbuf) ;
							goto	exit_func ;
						}
					}
					if (nNumType == 4 && 
						pS4Node != NULL) {
						pS4Node	= pS4Node->m_pNext ;
					}
					if (! TVarbuffer_Add (&vbuf, &pvbuf, 1)) {
						TVarbuffer_Uninit (pvbuf) ;
						FREE (pvbuf) ;
						goto	exit_func ;
					}
					pNum	+= nNumLen + 1 ;
					nNumIndex	++ ;
				}
			}
		} 
		pSrc	++ ;
	}
	if (TVarbuffer_GetUsage (&vbuf) <= 0) {
		*pbConverted	= FALSE ;
		goto	exit_func ;
	}

	if (! TVarbuffer_Require (&vbufNumIndex, nNumIndex))
		goto	exit_func ;
	pnNumIndex	= (int*) TVarbuffer_GetBuffer (&vbufNumIndex) ;
	pNum		= wstrNumList ;
	for (i = 0 ; i < nNumIndex ; i ++) {
		if (pNum == NULL || *pNum == L'\0') {
			pnNumIndex [i]	= -1 ;
		} else {
			int		nNumLen, nPosition ;
			nNumLen			= dcslen (pNum) ;
			nPosition		= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
			if (! TVarbuffer_Add (&pSession->m_vbufCandidate, pNum, nNumLen + 1))
				goto	exit_func ;
			pnNumIndex [i]	= nPosition ;
			pNum	+= nNumLen + 1 ;
		}
	}

	bRetval	= TRUE ;

	/* ���̗񋓕������������o���ăe�X�g���������c�B�����ɂ��邩�ȁB*/
	{
		int*			pPosTop ;
		int*			pPosEnd ;
		int*			pPos, nCount ;
		TVarbuffer**	ppvbufTop ;

		if (! TVarbuffer_Require (&vbufPos, TVarbuffer_GetUsage (&vbuf)))
			goto	exit_func ;

		pPosTop	= (int*) TVarbuffer_GetBuffer (&vbufPos) ;
		pPosEnd	= pPosTop + TVarbuffer_GetUsage (&vbufPos) ;
		pPos	= pPosTop ;
		while (pPos < pPosEnd)
			*pPos ++	= 0 ;
		ppvbufTop	= (TVarbuffer**) TVarbuffer_GetBuffer (&vbuf) ;

		for ( ; ; ) {
			pSrc		= dstrSrc ;
//			pSrcEnd		= dstrSrc + nSrcLen ;
			TVarbuffer_Clear (&vbufDest) ;
			TVarbuffer_Clear (&vbufS4Index) ;
			pPos		= pPosTop ;
			ppvbuf		= ppvbufTop ;

			/*	���l��W�J���邽�߂ɁA�I���W�i���̕ϊ����ʂ��X�L��������B
			 *
			 *	wstrNumList:	nul �ŋ�؂�ꂽ���l�̃��X�g�B�I���W�i���̕ϊ����ʂ�
			 *					���߂鎞�ɐ؂�o����Ă���B
			 *					``123\0456\0\0'' �̂悤�Ȋ����B 
			 *	pSrc:			�I���W�i���̕ϊ�����
			 *					�Ⴆ�΁ApSrc �ɂ� ``��#2��#4'' �̂悤�ɓ����Ă���B
			 *	*ppvbuf:		�X�̐��l�̓W�J���ʂ������Ă���B
			 *					��� wstrNumList �̗Ⴞ�ƁA
			 *					ppvbuf [0] -> 123 �̓W�J���� (by #2)
			 *					ppvbuf [1] -> 456 �̓W�J���� (by #4)
			 *	pDest:			#2 �� #4 �� *ppvbuf �̒��̌��Œu�����������ʂ�����B
			 *					``��123��S�T�U'' �Ƃ��B
			 */
			while (pSrc < pSrcEnd) {
				LPCDSTR	pSrcBack ;

				pSrcBack	= pSrc ;
				while (pSrc < pSrcEnd && *pSrc != L'#') 
					pSrc	++ ;
				if (pSrcBack < pSrc) {
					if (! TVarbuffer_Add (&vbufDest, pSrcBack, pSrc - pSrcBack)) 
						goto	exit_func ;
				}
				if (pSrc < pSrcEnd && *pSrc == L'#') {
					pSrc	++ ;
					if (pSrc < pSrcEnd && L'0' <= *pSrc && *pSrc <= L'9') {
						if (pPos < pPosEnd) {
							LPCDSTR	pNum ;
							int		nNum, nPos ;

							pNum	= (LPCDSTR) TVarbuffer_GetBuffer (*ppvbuf) ;
							nNum	= TVarbuffer_GetUsage (*ppvbuf) ;
							nPos	= *pPos ;
							if (nNum <= 0 || *(pNum + nPos) == L'\0') {
								/* Empty */
							} else {
								int		n ;

								/*	������ #4 ���������A#4 �ɂ���ĉ��ɕϊ����ꂽ�̂���
								 *	���ʂ�@�����ޕK�v������B�ށA���ʎ��̂� pDest �ɓ���
								 *	�����S�Ȍ`�œ��邩�͕�����Ȃ�����A�ۑ����Ă���������
								 *	�ǂ����H
								 *	���[�ށB
								 *
								 *	struct {
								 *		int		m_nResultPos ;
								 *		int		m_nResultLen ;
								 *	}
								 */
								n	= dcslen (pNum + nPos) ;
								if (*pSrc == L'4') {
									struct CTS4NumIndex	s4n ;
									s4n.m_nIndex	= pnNumIndex [ppvbuf - ppvbufTop] ;
									s4n.m_nPos		= TVarbuffer_GetUsage (&vbufDest) ;
									s4n.m_nLen		= n ;
									if (! TVarbuffer_Add (&vbufS4Index, &s4n, 1)) {
										/* out of memory */
										goto	exit_func ;
									}
								}
								if (! TVarbuffer_Add (&vbufDest, pNum + nPos, n)) {
									/* out of memory */
									goto	exit_func ;
								}
							}
							pPos	++ ;
							ppvbuf	++ ;
						}
						pSrc ++ ;
					}
				}
			}

			/* separator �� nul �������K�v�B*/
			nCount		= TVarbuffer_GetUsage (&vbufDest) ;
			/* Session �� Add */
			if (nCount > 0) {
				struct CTSearchSessionCandidate*	pNewEntry ;
				LPCDSTR	pWord ;
				int		nWordLen ;
				BOOL	bRetval ;
				int		nPosition ;

				if (! TVarbuffer_Add (&vbufDest, c_Zero, 1)) 
					goto	exit_func ;

				nPosition	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
				pWord		= (LPCDSTR) TVarbuffer_GetBuffer (&vbufDest) ;
				nWordLen	= TVarbuffer_GetUsage  (&vbufDest) ;

				/* pNewEntry �͐��l�ϊ��̌��ʁF``��3'' �̂悤�ȁB*/
				pNewEntry	= tSearchSession_pGetCandidate (pSession, pWord, nWordLen - 1) ;
				if (pNewEntry == NULL) {
					if (! TVarbuffer_Add (&pSession->m_vbufCandidate, pWord, nWordLen)) {
						/* ������ error �� critical */
						goto	exit_func ;
					}
					/* nPosition ���� pDest - wbuf �����������o�^����Ă���B*/
					pNewEntry	= tSearchSession_pCreateCandidate (pSession, nPosition, nWordLen, &bRetval) ;
					if (bRetval || pNewEntry == NULL) 
						goto	exit_func ;
					if (! tSearchSession_bInsertCandidateNext (pSession, pEntry, pNewEntry)) {
						TSearchSessionCandidate_vDestroy (pNewEntry) ;
						goto	exit_func ;
					}
					/* link �̐�ɐ����W�J���ꂽ���ʂ������Ă���B*/
					TSearchSessionCandidate_vSetLink (pNewEntry, pEntry) ;
				}
				bConverted	= TRUE ;

				{
					struct CTS4NumIndex*	pS4Index ;
					struct CTS4Candidate*	pNode ;
					struct CTS4Candidate*	pTop	= NULL ;
					int						nS4Indices, nBase ;

					pS4Index	= (struct CTS4NumIndex*) TVarbuffer_GetBuffer (&vbufS4Index) ;
					nS4Indices	= TVarbuffer_GetUsage (&vbufS4Index) ;
					nBase		= TSearchSessionCandidate_iGetValue (pNewEntry) ;
					while (nS4Indices > 0) {
						if (pS4Index->m_nIndex >= 0) {
#if defined (DEBUG) || defined (_DEBUG)
							{
								DCHAR	buf1 [256], buf2 [256] ;
								LPCDSTR	ptr ;
								int		n ;
								ptr	= (LPCDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) ;
								wcsncpy_s (buf1, ARRAYSIZE (buf1), ptr + pS4Index->m_nIndex, ARRAYSIZE (buf1) - 1) ;
								buf1 [ARRAYSIZE (buf1) - 1]	= L'\0' ;
								n	= MIN (pS4Index->m_nLen, ARRAYSIZE (buf2) - 1) ;
								wcsncpy_s (buf2, ARRAYSIZE (buf2), ptr + nBase + pS4Index->m_nPos, n) ;
								buf2 [n]	= L'\0' ;
								DebugPrintf (TEXT ("#4 �ǉ�: �P��: \"%s\"(pos:%d) ����:\"%s\" (pos:%d, len:%d)\n"), buf1, pS4Index->m_nIndex, buf2, pS4Index->m_nPos + nBase, pS4Index->m_nLen) ;
							}
#endif
							pNode	= TS4Candidate_pCreate (pS4Index->m_nIndex, nBase + pS4Index->m_nPos, pS4Index->m_nLen) ; 
							if (pTop != NULL) {
								TS4Candidate_vSetNext (pTop, pNode) ;
							} else {
								pTop	= pNode ;
							}
						}
						pS4Index	++ ;
						nS4Indices	-- ;
					}
					/* ����͒ǉ��ɂȂ�B*/
					TSearchSessionCandidate_vAddLink2 (pNewEntry, pTop) ;
				}
			}

			/* ���ɑ��鏈���B*/
			pPos		= pPosTop ;
			ppvbuf		= (TVarbuffer**) TVarbuffer_GetBuffer (&vbuf) ;
			while (pPos < pPosEnd) {
				LPCDSTR	pNum ;
				int		nNum, nPos ;
				pNum	= (LPCDSTR) TVarbuffer_GetBuffer (*ppvbuf) ;
				nNum	= TVarbuffer_GetUsage (*ppvbuf) ;
				nPos	= *pPos ;
				if (nNum <= 0 || *(pNum + nPos) == L'\0') {
					*pPos	= 0 ;
					/* continue */
				} else {
					int		nLen, nNewPos ;

					nLen	= dcslen (pNum + nPos) ;
					nNewPos	= nPos + nLen + 1 ;
					if (nNewPos >= nNum || *(pNum + nNewPos) == L'\0') {
						*pPos	= 0 ;
						/* continue */
					} else {
						*pPos	= nNewPos ;
						break ;
					}
				}
				pPos	++ ;
				ppvbuf	++ ;
			}
			if (pPos >= pPosEnd)
				break ;
		}
	}
	*pbConverted	= bConverted ;

exit_func:
	ppvbuf	= (TVarbuffer**) TVarbuffer_GetBuffer (&vbuf) ;
	for (i = 0 ; i < TVarbuffer_GetUsage (&vbuf) ; i ++) {
		if (ppvbuf [i] != NULL) {
			TVarbuffer_Uninit (ppvbuf [i]) ;
			FREE (ppvbuf [i]) ;
			ppvbuf [i]	= NULL ;
		}
	}
	TVarbuffer_Uninit (&vbuf) ;
	TVarbuffer_Uninit (&vbufDest) ;
	TVarbuffer_Uninit (&vbufS4Index) ;
	TVarbuffer_Uninit (&vbufNumIndex) ;
	return	bRetval ;
}

/*
(defun skk-num-exp (num type)
  "ascii ���� (string) �� NUM �� TYPE �ɏ]���ϊ����A�ϊ���̕������Ԃ��B
TYPE �͉��L�̒ʂ�B
0 -> ���ϊ�
1 -> �S�p�����֕ϊ�
2 -> �������֕ϊ� (�ʎ��Ȃ�)
3 -> �������֕ϊ� (�ʎ�������)
4 -> ���̐������̂��̂��L�[�ɂ��Ď������Č���
5 -> ������ (��`�ȂǂŎg�p���镶�����g�p) �֕ϊ� (�ʎ�������)
9 -> �����Ŏg�p���鐔�� (\"�R�l\" �Ȃ�) �ɕϊ�"
  (save-match-data
    (let ((fun (cdr (assq type skk-num-type-alist))))
      (when fun
	(funcall fun num)))))
	*/
BOOL
_bNumExp (
	LPCDSTR						strNum,
	int							nNumLen,
	int							nType,
	TVarbuffer*					pvbuf)
{
	switch (nType) {
	case	0:
		if (TVarbuffer_Add (pvbuf, strNum, nNumLen) && TVarbuffer_Add (pvbuf, L"\0", 1))
			return	TRUE ;
		return	FALSE ;
	case	1:
		return	_bNumJisx0208Latin (strNum, nNumLen, pvbuf) ;
	case	2:
		return	_bNumType2Kanji (strNum, nNumLen, pvbuf) ;
	case	3:
		return	_bNumType3Kanji (strNum, nNumLen, pvbuf) ;
	case	4:	/* ����̓e�X�g�ł��Ȃ��B*/
		return	_bNumType4Kanji (strNum, nNumLen, pvbuf) ;
	case	5:
		return	_bNumType5Kanji (strNum, nNumLen, pvbuf) ;
	case	9:
	default:
		break ;
	}
	return	TRUE ;
}

/*
(defun skk-num-jisx0208-latin (num)
  "ascii ������ NUM ��S�p�����̕�����ɕϊ����A�ϊ���̕������Ԃ��B
�Ⴆ�� \"45\" �� \"�S�T\" �ɕϊ�����B"
  (let ((candidate
	 (mapconcat (function
		     (lambda (c)
		       (skk-num-get-suuji c skk-num-alist-type1)))
		    num "")))
    (unless (string= candidate "")
      candidate)))*/
BOOL
_bNumJisx0208Latin (
	LPCDSTR			strNum,
	int				nNumLen,
	TVarbuffer*		pvbuf)
{
	/* ���� mapping table �� customize �������l�����邩������Ȃ��B���ӁB*/
	static LPCWSTR	strMapTable	= L"�O�P�Q�R�S�T�U�V�W�X" ;
	const DCHAR		c_Zero		= 0 ;
	LPCDSTR		pSrc,  pSrcEnd ;
	DCHAR		wch ;

	if (! _bIntOrFloatNump (strNum, nNumLen))
		return	TRUE ;

	pSrc		= strNum ;
	pSrcEnd		= strNum + nNumLen ;
	while (pSrc < pSrcEnd) {
		if (L'0' <= *pSrc && *pSrc <= L'9') {
			wch	= (DCHAR) *(strMapTable + (*pSrc - L'0')) ;
		} else if (L'.' == *pSrc) {
			wch	= (DCHAR) L'�D' ;
		} else {
			wch	= *pSrc ;
		}
		if (! TVarbuffer_Add (pvbuf, &wch, 1))
			return	FALSE ;
		pSrc	++ ;
	}
	/* NUL NUL �ŏI�����邱�ƁB*/
	return	TVarbuffer_Add (pvbuf, &c_Zero, 1) ;
}

/*
(defun skk-num-type2-kanji (num)
  "ascii ���� NUM ���������̕�����ɕϊ����A�ϊ���̕������Ԃ��B
�Ⴆ�΁A\"45\" �� \"�l��\" �ɕϊ�����B"
  (save-match-data
    (when (skk-num-int-p num)
      (let ((candidate
	     (mapconcat (function
			 (lambda (c)
			   (skk-num-get-suuji
			    c
			    skk-num-alist-type2)))
			num "")))
	(unless (string= candidate "")
	  candidate))))) */
BOOL
_bNumType2Kanji (
	LPCDSTR						strNum,
	int							nNumLen,
	TVarbuffer*					pvbuf)
{
	/* ���� mapping table �� customize �������l�����邩������Ȃ��B���ӁB*/
	static LPCWSTR	strMapTable	= L"�Z���O�l�ܘZ������" ;
	const DCHAR		c_Zero		= 0 ;
	LPCDSTR		pSrc,  pSrcEnd ;
	DCHAR		wch ;

	if (! _bIntNump (strNum, nNumLen))
		return	TRUE ;

	pSrc		= strNum ;
	pSrcEnd		= strNum + nNumLen ;
	while (pSrc < pSrcEnd) {
		if (L'0' <= *pSrc && *pSrc <= L'9') {
			wch	= *(strMapTable + (*pSrc - L'0')) ;
		} else {
			wch	= *pSrc ;
		}
		if (! TVarbuffer_Add (pvbuf, &wch, 1))
			return	FALSE ;
		pSrc	++ ;
	}

	/* NUL NUL �ŏI�����邱�ƁB*/
	return	TVarbuffer_Add (pvbuf, &c_Zero, 1) ;
}

/*
(defun skk-num-type3-kanji (num)
  "ascii ���� NUM ���������̕�����ɕϊ��� (�ʎ�������)�A�ϊ���̕������
�Ԃ��B�Ⴆ�� \"1021\" �� \"���\��\" �ɕϊ�����B"
  (save-match-data
    (when (skk-num-int-p num)
      ;; �����_���܂܂Ȃ���
      (skk-num-to-kanji num 'type3))))
	  */
BOOL
_bNumType3Kanji (
	LPCDSTR						strNum,
	int							nNumLen,
	TVarbuffer*					pvbuf)
{
	LPCDSTR		pSrc,  pSrcEnd ;
	LPDSTR		pDest, pDestEnd ;
	DCHAR		wbuf [256] ;
	const DCHAR		c_Zero		= 0 ;

	if (! _bIntNump (strNum, nNumLen))
		return	TRUE ;

	/* �疳�ʑ吔�܂ł͕\������B*/
	if (nNumLen >= sizeof (_wstrNumericUnit) / sizeof (_wstrNumericUnit [0]) * 4)
		return	TRUE ;

	pSrc		= strNum ;
	pSrcEnd		= strNum + nNumLen ;
	pDest		= wbuf ;
	pDestEnd	= wbuf + ARRAYSIZE (wbuf) ;

	if (nNumLen == 1 && *strNum == L'0') {
		if (pDest < pDestEnd)
			*pDest ++	= _wstrKanjiDigits [0] ;
	} else {
		int		nDigitNumber, nLength ;
		BOOL	fSilent ;

		nLength			= nNumLen ;
		nDigitNumber	= ((nLength - 1) / 4) - 1 ;
		/* �傫�߂��鐔�ł����H */
		if (nLength < 17){
			fSilent	= TRUE ;
			nLength	= nNumLen ;
			while (pSrc < pSrcEnd && pDest < pDestEnd) {
				if (L'1' < *pSrc || (*pSrc != L'0' && (nLength % 4) == 1)) {
					vCopyStringNW (&pDest, pDestEnd, &_wstrKanjiDigits [*pSrc - L'0'], 1) ;
				} 
				if (*pSrc != L'0'){
					if (nLength % 4 == 2){
						vCopyStringW (&pDest, pDestEnd, L"�\") ;
					} else if (nLength % 4 == 3){
						vCopyStringW (&pDest, pDestEnd, L"�S") ;
					} else if (nLength % 4 == 0){
						vCopyStringW (&pDest, pDestEnd, L"��") ;
					}
					fSilent	= FALSE ;
				}
				/* �ʂ�����B*/
				if (!fSilent || *pSrc != L'0'){
					int		nDigitNumber	= nLength - 1 ;

					if (nDigitNumber % 4 == 0){
						nDigitNumber	= nDigitNumber / 4 - 1 ;
						if (nDigitNumber >= 0){
							vCopyStringW (&pDest, pDestEnd, _wstrNumericUnit [nDigitNumber]) ;
							fSilent	= TRUE ;
						}
					}
				}
				nLength	-- ;
				pSrc	++ ;
			}
		}
		/* ``�疜'' �Ƃ����\�������݂���΁A``��疜'' �ɕϊ�����Bresult ��ǂݒ����Ă̑���͔��������������c�B*/
		pSrc	= wbuf ;
		pSrcEnd	= pDest ;
		nLength	= pSrcEnd - pSrc ;
		while (pSrc < pSrcEnd) {
			if (*pSrc == L'��' && (pSrc + 1) < pSrcEnd && *(pSrc + 1) == L'��') {
				int		nPosition, nMove ;

				if (pSrc > wbuf) {
					LPCWSTR	pCheck ;

					pCheck	= _wstrKanjiDigits + 1 ;
					while (*pCheck != L'\0' && *pCheck != *(pSrc - 1))
						pCheck	++ ;
					if (*pCheck != L'\0') {
						break ;
					}
				} 

				/* �擪�� ``��'' ��ǉ�����K�v������B*/
				nPosition	= pSrc - wbuf ;
				if (nLength >= ARRAYSIZE (wbuf)) {
					nMove	= ARRAYSIZE (wbuf) - nPosition - 1 ;
				} else {
					nMove	= nLength - nPosition ;
					pDest	++ ;
				}
//				printf ("position = %d, move = %d\n", nPosition, nMove) ;
				if (nMove > 0)
					memmove (wbuf + nPosition + 1, wbuf + nPosition, nMove * sizeof (DCHAR)) ;
				wbuf [nPosition]	= L'��' ;
				break ;
			}
			pSrc	++ ;
		}
	}
	if (! TVarbuffer_Add (pvbuf, wbuf, pDest - wbuf))
		return	FALSE ;

	/* NUL NUL �ŏI�����邱�ƁB*/
	return	TVarbuffer_Add (pvbuf, &c_Zero, 1) ;
}


/*
(defconst skk-num-alist-type5
  '((ju . "�E") (hyaku . "�S") (sen . "�")
    (man . "��") (oku . "��") (cho . "��") (kei . "��")
    (?0 . "��") (?1 . "��") (?2 . "��") (?3 . "�Q")
    (?4 . "�l") (?5 . "��") (?6 . "�Z") (?7 . "��")
    (?8 . "��") (?9 . "��") (?\  . ""))
	*/
BOOL
_bNumType5Kanji (
	LPCDSTR						strNum,
	int							nNumLen,
	TVarbuffer*					pvbuf)
{
	LPCDSTR		pSrc,  pSrcEnd ;
	DCHAR		dch ;
	const DCHAR	c_Zero	= 0 ;

	/* [0-9]* �łȂ���΃G���[�B*/
	if (! _bIntNump (strNum, nNumLen))
		return	TRUE ;

	/* �疳�ʑ吔�܂ł͕\������B*/
	if (nNumLen >= sizeof (_wstrNumericUnit) / sizeof (_wstrNumericUnit [0]) * 4)
		return	TRUE ;

	pSrc		= strNum ;
	pSrcEnd		= strNum + nNumLen ;

	if (nNumLen == 1 && *strNum == L'0') {
		DCHAR	dch	= _wstrKanjiDigitsType5 [0] ;
		if (! TVarbuffer_Add (pvbuf, &dch, 1))
			return	FALSE ;
	} else {
		int		nDigitNumber, nLength ;
		BOOL	fSilent ;

		nLength			= nNumLen ;
		nDigitNumber	= ((nLength - 1) / 4) - 1 ;
		/* �傫�߂��鐔�ł����H */
		if (nLength < 17){
			fSilent	= TRUE ;
			nLength	= nNumLen ;
			while (pSrc < pSrcEnd) {
				if (L'1' < *pSrc || (*pSrc != L'0' && (nLength % 4) == 1)) {
					dch	= _wstrKanjiDigitsType5 [*pSrc - L'0'] ;
					if (! TVarbuffer_Add (pvbuf, &dch, 1))
						return	FALSE ;
				} 
				if (*pSrc != L'0'){
					if (nLength % 4 == 2){
						dch	= L'�E' ;
						if (! TVarbuffer_Add (pvbuf, &dch, 1))
							return	FALSE ;
					} else if (nLength % 4 == 3){
						dch	= L'�S' ;
						if (! TVarbuffer_Add (pvbuf, &dch, 1))
							return	FALSE ;
					} else if (nLength % 4 == 0){
						dch	= L'�' ;
						if (! TVarbuffer_Add (pvbuf, &dch, 1))
							return	FALSE ;
					}
					fSilent	= FALSE ;
				}
				/* �ʂ�����B*/
				if (!fSilent || *pSrc != L'0'){
					int		nDigitNumber	= nLength - 1 ;

					if (nDigitNumber % 4 == 0){
						nDigitNumber	= nDigitNumber / 4 - 1 ;
						if (nDigitNumber >= 0){
							LPCWSTR	wstrDigit	= _wstrNumericUnitType5 [nDigitNumber] ;
							int		nDigitWLen	= lstrlenW (wstrDigit) ;
							int		nPos, n ;
							LPDSTR	pdDest ;

							n		= wcstodcs (NULL, 0, wstrDigit, nDigitWLen) ;
							nPos	= TVarbuffer_GetUsage (pvbuf) ;
							if (! TVarbuffer_Require (pvbuf, n))
								return	FALSE ;
							pdDest	= (LPDSTR) TVarbuffer_GetBuffer (pvbuf) + nPos ;
							(void) wcstodcs (pdDest, n, wstrDigit, nDigitWLen) ;
							fSilent	= TRUE ;
						}
					}
				}
				nLength	-- ;
				pSrc	++ ;
			}
		}
	}
	/* NUL NUL �ŏI�����邱�ƁB*/
	return	TVarbuffer_Add (pvbuf, &c_Zero, 1) ;
}

BOOL
_bNumType4Kanji (
	LPCDSTR						strNum,
	int							nNumLen,
	TVarbuffer*					pvbuf)
{
	struct CTSearchSession*	pSession ;
	LPCDSTR				dstrResult ;
	BOOL				bRetval ;
	const DCHAR	c_Zero	= 0 ;

	/*	#4 �ϊ��̒��� #4 �ϊ����܂܂�Ă��āA����loop �ɂȂ�Ȃ��悤��
	 *	numeric-conversion �͒�~����B
	 */
	pSession	= THenkanSession_pCreate (strNum, nNumLen, SEARCH_OKURI_NASHI, FALSE, FALSE) ;
	if (pSession == NULL)
		return	FALSE ;

	bRetval	= TRUE ;
	do {
		/* �ŏ��� Candidate �͂����Ȃ� GetCandidate �ł����́H */
		dstrResult	= TSearchSession_pGetCandidate (pSession) ;
		if (dstrResult == NULL)
			break ;
		if (! TVarbuffer_Add (pvbuf, dstrResult, dcslen (dstrResult)) ||
			! TVarbuffer_Add (pvbuf, &c_Zero, 1)) {
			bRetval	= FALSE ;
			goto	exit_func ;
		}
	} while (TSearchSession_bNextCandidate (pSession)) ;

	if (! TVarbuffer_Add (pvbuf, &c_Zero, 1))
		bRetval	= FALSE ;

exit_func:
	TSearchSession_vDestroy (pSession) ;
	return	bRetval ;
}

BOOL
_bIntNump (
	LPCDSTR		strNum,
	int			nNumLen)
{
	while (nNumLen > 0) {
		if (! (L'0' <= *strNum && *strNum <= L'9'))
			return	FALSE ;
		strNum	++ ;
		nNumLen	-- ;
	}
	return	TRUE ;
}

BOOL
_bIntOrFloatNump (
	LPCDSTR		strNum,
	int			nNumLen)
{
	while (nNumLen > 0) {
		if (! (L'0' <= *strNum && *strNum <= L'9') && *strNum != L'.')
			return	FALSE ;
		strNum	++ ;
		nNumLen	-- ;
	}
	return	TRUE ;
}

/*========================================================================
 *	���艼���Ȃ��̒ʏ�ϊ� Session
 */
static	BOOL	tHenkanSession_bNumericp	(const struct CTSearchSession*) ;
static	BOOL	tHenkanSession_bSearch		(struct CTSearchSession*) ;

struct CTSearchSession*
THenkanSession_pCreate (
	LPCDSTR				wstrKeyword,
	int					nKeyword,
	int					iSearchType,
	BOOL				bNumericConversion,
	BOOL				bNumericFloat) 
{
	struct CTHenkanSession*	pSession ;
	BOOL					bCurrentlyNumericConverting	= FALSE ;

	pSession	= (struct CTHenkanSession*) MALLOC (sizeof (struct CTHenkanSession)) ;
	if (pSession == NULL)
		return	NULL ;
	TSearchSession_vInitialize (&pSession->m_Session) ;

	if (bNumericConversion) {
		pSession->m_Session.m_nwstrKeyword	= iSkkNumComputeHenkanKey (wstrKeyword, nKeyword, pSession->m_Session.m_rszKeyword, ARRAYSIZE (pSession->m_Session.m_rszKeyword), pSession->m_Session.m_rszNumericList, ARRAYSIZE (pSession->m_Session.m_rszNumericList), bNumericFloat) ;
		pSession->m_bNumericFloat			= bNumericFloat ;

		/* ���ۂɐ��l�ϊ������s���Ă��邩�ǂ����� AutoOkuriProcess �ɉe����^����B*/
		if (pSession->m_Session.m_nwstrKeyword != nKeyword || dcsncmp (wstrKeyword, pSession->m_Session.m_rszKeyword, nKeyword) != 0) {
			bCurrentlyNumericConverting	= TRUE ;

			if (iSearchType == SEARCH_OKURI_AUTO)
				iSearchType	= SEARCH_OKURI_NASHI ;
		}
	} else {
		nKeyword		= (nKeyword > ARRAYSIZE (pSession->m_Session.m_rszKeyword))? ARRAYSIZE (pSession->m_Session.m_rszKeyword) : nKeyword ;
		dcsncpy (pSession->m_Session.m_rszKeyword, wstrKeyword, nKeyword) ;
		pSession->m_Session.m_nwstrKeyword	= nKeyword ;
		pSession->m_bNumericFloat			= FALSE ;
	}
	pSession->m_bNumericConversion			= bCurrentlyNumericConverting ;

	iSearchType	= (iSearchType != SEARCH_OKURI_AUTO && iSearchType != SEARCH_OKURI_NASHI)? SEARCH_OKURI_NASHI : iSearchType ;
	pSession->m_iSearchType					= iSearchType ;

	pSession->m_Session.m_pSearchProc		= tHenkanSession_bSearch ;
	pSession->m_Session.m_pNumberpProc		= tHenkanSession_bNumericp ;
	return	(struct CTSearchSession*) pSession ;
}

BOOL
tHenkanSession_bNumericp (
	const struct CTSearchSession*		pSession)
{
	const struct CTHenkanSession*		pHenkanSession	= (const struct CTHenkanSession*) pSession ;

	return	(pHenkanSession->m_bNumericConversion && pSession->m_rszNumericList [0] != L'\0') ;
}

/*	original �̓����͈�x search ����ƁA���̓x�� filter ���Ăяo����
 *	num-convert ���Ă���A���B
 */

BOOL
tHenkanSession_bSearch (
	struct CTSearchSession*		pSession)
{
	struct CTHenkanSession*		pHenkanSession	= (struct CTHenkanSession*) pSession ;
	struct CTPacket		packet ;
	HANDLE				hPipe ;
	BOOL				fResult	= FALSE ;
	WORD				woTotalResult ;
	int					nMajor, nMinor, nSize, nRecv ;
	LPCWSTR				strResult ;
	int					nResult ;
	int					nNext	= -1 ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader  (&packet, SKKISERV_PROTO_SEARCH_EX, pHenkanSession->m_iSearchType)		||
		! TPacket_bAddCard32  (&packet, pSession->m_nSearchCount)		||
		! TPacket_bAddDString (&packet, pSession->m_rszKeyword, pSession->m_nwstrKeyword)	||
		! TPacket_bAddString  (&packet, NULL,        0)					||
		! TPacket_bSetLength  (&packet)									||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	DEBUGPRINTF ((TEXT ("_bSearch (): 1\n"))) ;
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	DEBUGPRINTF ((TEXT ("_bSearch (Major:%d, Minor:%d): 2\n"), nMajor, nMinor)) ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_SEARCH_REPLY)
		goto	exit_func ;
	if (! TPacket_bGetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &woTotalResult))
		goto	exit_func ;
	
	if ((int)(woTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;
	
	strResult	= (LPCWSTR)(TPacket_pGetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	nResult		= (nResult > woTotalResult)? woTotalResult : nResult ;
	DEBUGPRINTF ((TEXT ("_bSearch (result=%d,lastchar:0x%x): 5\n"), nResult, (nResult > 0)? strResult [nResult - 1] : 0)) ;

	if (woTotalResult > 0) {
		int		nPosition	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
		LPDSTR	pdDest ;
		int		nNeed ;

		nNeed	= wcstodcs_n (NULL, 0, strResult, nResult) ;
		if (! TVarbuffer_Require (&pSession->m_vbufCandidate, nNeed))
			goto	exit_func ;
		pdDest	= (LPDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + nPosition ;
		(void) wcstodcs_n (pdDest, nNeed, strResult, nResult) ;

		pSession->m_nParsePosition	= tSearchSession_bUpdateCandidateList (pSession, nPosition) ;
	}
	DEBUGPRINTF ((TEXT ("_bSearch (pos=%d, top:%p, cur:%p): 6\n"), pSession->m_nParsePosition, pSession->m_pTopCandidate, pSession->m_pCurCandidate)) ;
	fResult		= TRUE ;
	nNext		= (signed char)nMinor ;
	if (0 <= nNext && nNext <= pSession->m_nSearchCount)
		nNext	= -1 ;
	
	/* �����Œǉ����ꂽ���̐��l�W�J�����s����B*/
	if (pHenkanSession->m_bNumericConversion) 
		tSearchSession_bMultipleNumConvert (pSession) ;

  exit_func:
	/* session �̏I���́c���͈�񌟍������Ȃ��̂ŁA�����ŏI���B*/
	pSession->m_nSearchCount	= nNext ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fResult ;
}

/*===============================================================
 */
static	BOOL	tOkuriHenkanSession_bSearch		(struct CTSearchSession*) ;

struct CTSearchSession*
TOkuriHenkanSession_pCreate	(
	LPCDSTR			wstrKeyword,
	int				nKeywordLen,
	LPCDSTR			wstrOkuriChar,
	int				nOkuriCharLen,
	int				iSearchType,
	BOOL			bNumericConversion,
	BOOL			bNumericFloat)
{
	struct CTOkuriHenkanSession*	pOkuriSession ;
	struct CTSearchSession*			pSession ;

	pOkuriSession	= (struct CTOkuriHenkanSession*) MALLOC (sizeof (struct CTOkuriHenkanSession)) ;
	if (pOkuriSession == NULL)
		return	NULL ;
	pSession		= &pOkuriSession->m_Session ;

	TSearchSession_vInitializeWithKeyword (pSession, wstrKeyword, nKeywordLen) ;
	if (bNumericConversion) {
		pSession->m_nwstrKeyword		= iSkkNumComputeHenkanKey (wstrKeyword, nKeywordLen, pSession->m_rszKeyword, ARRAYSIZE (pSession->m_rszKeyword), pSession->m_rszNumericList, ARRAYSIZE (pSession->m_rszNumericList), bNumericFloat) ;
		pOkuriSession->m_bNumericFloat	= bNumericFloat ;
	} else {
		int			nKeyword ;
		nKeyword		= (nKeywordLen > ARRAYSIZE (pSession->m_rszKeyword))? ARRAYSIZE (pSession->m_rszKeyword) : nKeywordLen ;
		memcpy (pSession->m_rszKeyword, wstrKeyword, nKeyword * sizeof (DCHAR)) ;
		pSession->m_nwstrKeyword		= nKeyword ;
		pOkuriSession->m_bNumericFloat	= FALSE ;
	}
	pOkuriSession->m_bNumericConversion	= bNumericConversion ;

	if (nOkuriCharLen > 0) {
		nOkuriCharLen	= (nOkuriCharLen > ARRAYSIZE (pOkuriSession->m_rszOkuriChar))? ARRAYSIZE (pOkuriSession->m_rszOkuriChar) : nOkuriCharLen ;
		memcpy (pOkuriSession->m_rszOkuriChar, wstrOkuriChar, nOkuriCharLen * sizeof (DCHAR)) ;
		pOkuriSession->m_nOkuriCharLen	= nOkuriCharLen ;
		pOkuriSession->m_iSearchType	= (iSearchType != SEARCH_OKURI_NASHI && iSearchType != SEARCH_OKURI_AUTO)? iSearchType : SEARCH_OKURI_ARI ;
	} else {
		pOkuriSession->m_nOkuriCharLen	= 0 ;
		pOkuriSession->m_iSearchType	= SEARCH_OKURI_ARI ;
	}

	pSession->m_pSearchProc			= tOkuriHenkanSession_bSearch ;

	return	(struct CTSearchSession*) pOkuriSession ;
}

BOOL
tOkuriHenkanSession_bSearch (
	struct CTSearchSession*		pSession)
{
	struct CTOkuriHenkanSession*	pOkuriSession	= (struct CTOkuriHenkanSession*) pSession ;
	struct CTPacket		packet ;
	HANDLE				hPipe ;
	BOOL				fResult	= FALSE ;
	WORD				woTotalResult ;
	int					nMajor, nMinor, nSize, nRecv ;
	LPCWSTR				strResult ;
	int					nResult ;
	int					nNext	= -1 ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader  (&packet, SKKISERV_PROTO_SEARCH_EX, pOkuriSession->m_iSearchType)	||
		! TPacket_bAddCard32  (&packet, pSession->m_nSearchCount)								||
		! TPacket_bAddDString (&packet, pSession->m_rszKeyword,	pSession->m_nwstrKeyword)		||
		! TPacket_bAddDString (&packet, pOkuriSession->m_rszOkuriChar, pOkuriSession->m_nOkuriCharLen)	||
		! TPacket_bSetLength  (&packet)	||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	DEBUGPRINTF ((TEXT ("_bSearch (Major:%d, Minor:%d): 2\n"), nMajor, nMinor)) ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_SEARCH_REPLY)
		goto	exit_func ;
	if (! TPacket_bGetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &woTotalResult))
		goto	exit_func ;
	
	if ((int)(woTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;
	
	strResult	=  (LPCWSTR)(TPacket_pGetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	nResult		= (nResult > woTotalResult)? woTotalResult : nResult ;
	if (woTotalResult > 0) {
		int		nPosition	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
		LPDSTR	pdDest ;
		int		nNeed ;

		nNeed	= wcstodcs_n (NULL, 0, strResult, nResult) ;
		if (! TVarbuffer_Require (&pSession->m_vbufCandidate, nNeed))
			goto	exit_func ;
		pdDest	= (LPDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + nPosition ;
		(void) wcstodcs_n (pdDest, nNeed, strResult, nResult) ;

		pSession->m_nParsePosition	= tSearchSession_bUpdateCandidateList (pSession, nPosition) ;
	}
	fResult		= TRUE ;
	nNext		= (signed char)nMinor ;
	if (0 <= nNext && nNext <= pSession->m_nSearchCount)
		nNext	= -1 ;
	
  exit_func:
	/* session �̏I���́c���͈�񌟍������Ȃ��̂ŁA�����ŏI���B*/
	pSession->m_nSearchCount	= nNext ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fResult ;
}

/*===============================================================
 */
static	BOOL	tCompletionSession_bSearch			(struct CTSearchSession*) ;
static	BOOL	tCompletionSession_bIsSeparateChar	(struct CTSearchSession*, int) ;


struct CTSearchSession*
TCompletionSession_pCreate	(
	LPCDSTR			wstrKeyword,
	int				nKeywordLen)
{
	struct CTCompletionSession*	pCompSession ;
	struct CTSearchSession*		pSession ;

	pCompSession	= (struct CTCompletionSession*) MALLOC (sizeof (struct CTCompletionSession)) ;
	if (pCompSession == NULL)
		return	NULL ;

	pSession		= &pCompSession->m_Session ;
	TSearchSession_vInitializeWithKeyword (pSession, wstrKeyword, nKeywordLen) ;

	pSession->m_pSearchProc			= tCompletionSession_bSearch ;
	pSession->m_pIsSeparatorpProc	= tCompletionSession_bIsSeparateChar ;

	return	(struct CTSearchSession*) pCompSession ;
}

BOOL
tCompletionSession_bSearch (
	struct CTSearchSession*	pSession)
{
	struct CTPacket		packet ;
	HANDLE				hPipe ;
	BOOL				fResult	= FALSE ;
	WORD				woTotalResult ;
	int					nMajor, nMinor, nSize, nRecv ;
	LPCWSTR				strResult ;
	int					nResult ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! TPacket_bSetHeader (&packet, SKKISERV_PROTO_COMPLETION, 1) ||
		! TPacket_bAddDString (&packet, pSession->m_rszKeyword, pSession->m_nwstrKeyword) ||
		! TPacket_bSetLength (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_COMPLETION_REPLY)
		goto	exit_func ;
	if (! TPacket_bGetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &woTotalResult))
		goto	exit_func ;
	
	if ((int)(woTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;
	
	strResult	= (LPCWSTR)(TPacket_pGetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	nResult		= (nResult > woTotalResult)? woTotalResult : nResult ;
	if (woTotalResult > 0) {
		int		nPosition	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
		LPDSTR	pdDest ;
		int		nNeed ;

		nNeed	= wcstodcs_n (NULL, 0, strResult, nResult) ;
		if (! TVarbuffer_Require (&pSession->m_vbufCandidate, nNeed))
			goto	exit_func ;
		pdDest	= (LPDSTR) TVarbuffer_GetBuffer (&pSession->m_vbufCandidate) + nPosition ;
		(void) wcstodcs_n (pdDest, nNeed, strResult, nResult) ;
		pSession->m_nParsePosition	= tSearchSession_bUpdateCandidateList (pSession, nPosition) ;
	}
	fResult			= TRUE ;
	
  exit_func:
	/* session �̏I���́c���͈�񌟍������Ȃ��̂ŁA�����ŏI���B*/
	pSession->m_nSearchCount	= -1 ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fResult ;
}

BOOL
tCompletionSession_bIsSeparateChar (
	struct CTSearchSession*	pSession,
	int						wch)
{
	return	(wch == L' ') ;
}

/*===============================================================
 */
static	BOOL	tKakuteiHIstoryCompletionSession_bSearch			(struct CTSearchSession*) ;
static	BOOL	tKakuteiHistoryCompletionSession_bIsSeparateChar	(struct CTSearchSession*, int) ;

struct CTSearchSession*
TKakuteiHistoryCompletionSession_pCreate (void)
{
	struct CTCompletionSession*	pCompSession ;
	struct CTSearchSession*		pSession ;

	pCompSession	= (struct CTCompletionSession*) MALLOC (sizeof (struct CTCompletionSession)) ;
	if (pCompSession == NULL)
		return	NULL ;

	pSession		= &pCompSession->m_Session ;
	/* �������[�h�͂Ȃ��B*/
	TSearchSession_vInitialize (pSession) ;

	pSession->m_pSearchProc			= tKakuteiHIstoryCompletionSession_bSearch ;
	pSession->m_pIsSeparatorpProc	= tKakuteiHistoryCompletionSession_bIsSeparateChar ;

	return	(struct CTSearchSession*) pCompSession ;
}

BOOL
tKakuteiHIstoryCompletionSession_bSearch (
	struct CTSearchSession*	pSession)
{
	struct CTPacket		packet ;
	HANDLE				hPipe ;
	BOOL				fResult	= FALSE ;
	WORD				woTotalResult ;
	int					nMajor, nMinor, nSize, nRecv ;
	LPCDSTR				strResult ;
	int					nResult ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! TPacket_bSetHeader (&packet, SKKISERV_PROTO_GETKAKUTEIHISTORY, 1) ||
		! TPacket_bSetLength (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_GETKAKUTEIHISTORY_REPLY)
		goto	exit_func ;
	if (! TPacket_bGetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &woTotalResult))
		goto	exit_func ;
	
	if ((int)(woTotalResult * sizeof (DCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;
	
	strResult	= (LPCDSTR)(TPacket_pGetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (DCHAR) ;
	nResult		= (nResult > woTotalResult)? woTotalResult : nResult ;
	if (woTotalResult > 0) {
		int		nPosition	= TVarbuffer_GetUsage (&pSession->m_vbufCandidate) ;
		if (! TVarbuffer_Add (&pSession->m_vbufCandidate, strResult, nResult))
			goto	exit_func ;
		pSession->m_nParsePosition	= tSearchSession_bUpdateCandidateList (pSession, nPosition) ;
	}
	fResult			= TRUE ;
	
  exit_func:
	/* session �̏I���́c���͈�񌟍������Ȃ��̂ŁA�����ŏI���B*/
	pSession->m_nSearchCount	= -1 ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fResult ;
}

BOOL
tKakuteiHistoryCompletionSession_bIsSeparateChar (
	struct CTSearchSession*	pSession,
	int						wch)
{
	return	(wch == L' ') ;
}

/*===============================================================
 */
struct CTS4Mapping*
TS4Mapping_pCreate (
	LPCDSTR		pdKeyword,
	LPCDSTR		pdResult,
	int			nResultLen)
{
	struct CTS4Mapping*	pNode ;
	int		nSize, nKeywordLen ;
	LPDSTR	pdDest, pdDestEnd ;

	/*	keyword �͋�ł����Ă͂Ȃ�Ȃ��B���ʂ���ł��邱�Ƃ͔F�߂邪�B
	 */
	if (pdKeyword == NULL)	/* error */
		return	NULL ;
	nKeywordLen	= dcslen (pdKeyword) ;
	if (nKeywordLen <= 0)
		return	NULL ;

	nSize		= (nResultLen + 1 + nKeywordLen + 1) * sizeof (DCHAR) + sizeof (struct CTS4Mapping) ;
	pNode		= (struct CTS4Mapping*) MALLOC (nSize) ;
	if (pNode == NULL) 
		return	NULL ;

	pdDest		= (LPDSTR) (pNode + 1) ;
	pdDestEnd	= pdDest + nResultLen + nKeywordLen + 1 ;

	pNode->m_pwKeyword	= pdDest ;
	vCopyString (&pdDest, pdDestEnd, pdKeyword) ;
	*pdDest ++	= L'\0' ;
	if (nResultLen > 0) {
		pNode->m_pwResult	= pdDest ;
		vCopyStringN (&pdDest, pdDestEnd, pdResult, nResultLen) ;
		*pdDest ++	= L'\0' ;
		pNode->m_nResultLen	= nResultLen ;
	} else {
		pNode->m_pwResult	= NULL ;	/* ���̏ꍇ�͎����� lookup �Ɋ��҂���B*/
		pNode->m_nResultLen	= 0 ;
	}
	pNode->m_pNext		= NULL ;
	return	pNode ;
}

/*	#4 �̑Ή����X�g�͒����Ȃ�Ȃ��Ɖ��肵�Ă���̂� ok �Ƃ���B
 */
BOOL
TS4Mapping_bInsertLast (
	struct CTS4Mapping**	plstTop,
	struct CTS4Mapping*		pNewNode)
{
	struct CTS4Mapping*	pNode ;
	struct CTS4Mapping*	pPrevNode ;

	if (plstTop == NULL || pNewNode == NULL)
		return	FALSE ;

	pNode		= *plstTop ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
	}
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext	= pNode ;
	} else {
		*plstTop	= pNewNode ;
	}
	return	TRUE ;
}

void
TS4Mapping_vClearList (
	struct CTS4Mapping*		plstTop)
{
	struct CTS4Mapping*		pNode ;
	struct CTS4Mapping*		pNextNode ;

	pNode	= plstTop ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		FREE (pNode) ;
		pNode		= pNextNode ;
	}
	return ;
}




