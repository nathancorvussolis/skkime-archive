/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * tstring.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_5.h"

/*
 *
 *	lmemset ()
 *
 */
void	PASCAL
lmemset (LPBYTE lp, BYTE b, UINT cnt)
{
	register UINT	i ;
	register BYTE	bt = b ;
	for (i = 0 ; i < cnt ; i++)
		*lp ++ = bt;
	return ;
}

void	PASCAL
Myltoa (LPMYSTR lp, long lValue)
{
	long	lMaxDigit, lDigit ;
	long	ll ;

	if (lValue < 0){
		*lp	++	= MYTEXT ('-') ;
		lValue	= lValue * (-1) ;
	}
	if (lValue != 0){
		ll	= lValue ;
		for (lMaxDigit = 0 ; ll != 0 ; lMaxDigit ++)
			ll	= ll / 10 ;
		for (lDigit = 0 ; lDigit < lMaxDigit ; lDigit ++){
			lp [lMaxDigit - lDigit - 1]	= (MYCHAR)(MYTEXT ('0') + lValue % 10) ;
			lValue						= lValue / 10 ;
		}
		lp [lMaxDigit] = MYTEXT ('\0') ;
	} else {
		*lp	++ = MYTEXT ('0') ;
		*lp	++ = MYTEXT ('\0') ;
	}
	return ;
}

void	PASCAL
Myltoax (LPMYSTR lp, long lValue)
{
	int	iDigit ;
	if (!lp)
		return ;
	iDigit	= (lValue >> 28) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 24) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 20) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 16) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 12) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >>  8) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >>  4) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >>  0) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	*lp		= MYTEXT ('\0') ;
	return ;
}

long	PASCAL
Myatol (LPMYSTR lpString)
{
	long	lValue ;
	long	lSign ;

	lValue	= 0 ;
	if (!lpString || !*lpString)
		return	lValue ;
	if (*lpString == MYTEXT ('+')){
		lSign	= 1 ;
		lpString	++ ;
	} else if (*lpString == MYTEXT ('-')){
		lSign	= -1 ;
		lpString	++ ;
	} else {
		lSign	= 1 ;
	}
	while (*lpString && MYTEXT ('0') <= *lpString && *lpString <= MYTEXT ('9')){
		lValue	= lValue * 10 + (*lpString - MYTEXT ('0')) ;
		lpString	++ ;
	}
	return	lSign * lValue ;
}

LPMYSTR	PASCAL
Myctime (LPSYSTEMTIME lpsystime)
{
	static	MYCHAR	ctimebuf [25] ;
	static	LPMYSTR	ctimeWeekTbl []	= {
		MYTEXT ("Sun"),	MYTEXT ("Mon"),	MYTEXT ("Tue"),	MYTEXT ("Wed"),
		MYTEXT ("Thr"),	MYTEXT ("Fri"),	MYTEXT ("Sat"),
	} ;
	static	LPMYSTR	ctimeMonthTbl []	= {
		MYTEXT ("Jan"),	MYTEXT ("Feb"),	MYTEXT ("Mar"),	MYTEXT ("Apr"),
		MYTEXT ("May"),	MYTEXT ("Jun"),	MYTEXT ("Jul"),	MYTEXT ("Aug"),
		MYTEXT ("Sep"),	MYTEXT ("Oct"),	MYTEXT ("Nov"),	MYTEXT ("Dec"),
	} ;
	ctimebuf [0]	= MYTEXT ('\0') ;
	Mylstrcat (ctimebuf, ctimeWeekTbl [lpsystime->wDayOfWeek]) ;
	Mylstrcat (ctimebuf, MYTEXT (" ")) ;
	Mylstrcat (ctimebuf, ctimeMonthTbl [lpsystime->wMonth - 1]) ;
	Mylstrcat (ctimebuf, MYTEXT (" ")) ;
	ctimebuf [8]	= (lpsystime->wDay / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [9]	= lpsystime->wDay % 10 + MYTEXT ('0') ;
	ctimebuf [10]	= MYTEXT (' ') ;
	ctimebuf [11]	= (lpsystime->wHour / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [12]	= lpsystime->wHour % 10 + MYTEXT ('0') ;
	ctimebuf [13]	= MYTEXT (':') ;
	ctimebuf [14]	= (lpsystime->wMinute / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [15]	= lpsystime->wMinute % 10 + MYTEXT ('0') ;
	ctimebuf [16]	= MYTEXT (':') ;
	ctimebuf [17]	= (lpsystime->wSecond / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [18]	= lpsystime->wSecond % 10 + MYTEXT ('0') ;
	ctimebuf [19]	= MYTEXT (' ') ;
	ctimebuf [20]	= (lpsystime->wYear / 1000) % 10 + MYTEXT ('0') ;
	ctimebuf [21]	= (lpsystime->wYear /  100) % 10 + MYTEXT ('0') ;
	ctimebuf [22]	= (lpsystime->wYear /   10) % 10 + MYTEXT ('0') ;
	ctimebuf [23]	=  lpsystime->wYear         % 10 + MYTEXT ('0') ;
	ctimebuf [24]	= MYTEXT ('\0') ;
	return	(LPMYSTR)ctimebuf ;
}

#if defined (UNICODE)
int	PASCAL	MylstrcmpW (
	register LPCWSTR	lp0,
	register LPCWSTR	lp1)
{
	while(*lp0 && *lp1 && (*lp0 == *lp1)) {
		lp0++;
		lp1++;
	}
	return (*lp0 - *lp1);
}

int PASCAL
MylstrncmpW (
	register LPCWSTR	lp0,
	register LPCWSTR	lp1, 
	register int		iNum)
{
	while(iNum > 0 && *lp0 && *lp1 && (*lp0 == *lp1)){
		lp0 ++ ;
		lp1 ++ ;
		iNum -- ;
	}
	return (iNum > 0)? (*lp0 - *lp1) : 0 ;
}

int	PASCAL
MylstrcpyW (LPWSTR lp0, LPCWSTR lp1)
{
	int n	= 0 ;

	while(*lp1){
		*lp0	= *lp1 ;
		lp0 ++ ;
		lp1 ++ ;
		n ++ ;
	}
	*lp0	= *lp1 ;
	return	n ;
}

int	PASCAL
MylstrncpyW (
	register LPWSTR		lp0,
	register LPCWSTR	lp1,
	register int		iNum)
{
	int	iN	= iNum ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

int	PASCAL
MylstrcatW (LPWSTR lp0, LPCWSTR lp1)
{
	int n	= 0 ;
	while (*lp0)
		lp0 ++ ;
	while(*lp1){
		*lp0	= *lp1 ;
		lp0 ++ ;
		lp1 ++ ;
		n ++ ;
	}
	*lp0	= *lp1 ;
	return	n ;
}

int	PASCAL
MylstrncatW (LPWSTR lp0, LPCWSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (*lp0)
		lp0	++ ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

LPWSTR PASCAL
MyCharPrevW(LPWSTR lpStart, LPWSTR lpCur)
{
	LPWSTR lpRet = lpStart;
	if (lpCur > lpStart)
		lpRet = lpCur - 1;

	return lpRet;
}

LPWSTR
PASCAL MyCharNextW(LPWSTR lp)
{
	return lp++;
}

LPWSTR
PASCAL MylstrcpynW(LPWSTR lp0, LPWSTR lp1, int nCount)
{
	int	n ;
	for (n = 0 ; *lp1 && n < nCount - 1; *lp0++ = *lp1++, n++)
		;
	*lp0 = L'\0' ;
	return	lp0 ;
}

#else	/* defined (UNICODE) */

int PASCAL MylstrncmpA (LPMYSTR lp0, LPMYSTR lp1, int iNum)
{
	while(iNum > 0 && *lp0 && *lp1 && (*lp0 == *lp1)){
		lp0 ++ ;
		lp1 ++ ;
		iNum -- ;
	}
	return (iNum > 0)? (*lp0 - *lp1) : 0 ;
}

int	PASCAL	MylstrncpyA (LPMYSTR lp0, LPMYSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

int	PASCAL	MylstrncatA (LPMYSTR lp0, LPMYSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (*lp0)
		lp0	++ ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

#endif

void	PASCAL
Mysnprintf (
	LPTSTR		lpBuffer,
	int			nBuffer,
	LPCTSTR		lpFormat,
	...)
{
	register LPCTSTR	pSrc ;
	register LPTSTR		pDest ;
	register int		nDest ;
	TCHAR				szBuffer [128] ;
	va_list				vl ;

	if (nBuffer <= 0 || lpBuffer == NULL)
		return ;

	va_start (vl, lpFormat) ;

	pSrc	= lpFormat ;
	pDest	= lpBuffer ;
	nDest	= nBuffer - 1 ;
	while (nDest > 0 && *pSrc != TEXT ('\0')) {
		switch (*pSrc) {
			register LPCTSTR	pString ;
			register int		nString, nCopy ;

			/*	% �̏����B*/
		case	TEXT ('%'):
			pSrc	++ ;
			switch (*pSrc) {
			case	TEXT ('s'):
			{
				pString	= va_arg (vl, LPCTSTR) ;
				goto	common_copy ;
			}
			case	TEXT ('u'):
			{
				register unsigned int	uNumber	= va_arg (vl, unsigned int) ;

				/*	wsprintf �� CRT �֐��ł͂��邪�A
				 *	mainCRTStartup ���� _main ���Q�Ƃ���悤�Ȗ�����
				 *	���Ȃ��B*/
				wsprintf (szBuffer, TEXT ("%u"), uNumber) ;
				pString	= szBuffer ;
				goto	common_copy ;
			}
			case	TEXT ('d'):
			{
				register int		nNumber	= va_arg (vl, int) ;

				wsprintf (szBuffer, TEXT ("%d"), nNumber) ;
				pString	= szBuffer ;
				goto	common_copy ;
			}
			common_copy:
			nString	= lstrlen (pString) ;
			nCopy	= (nDest < nString)? nDest : nString ;
			memcpy (pDest, pString, nCopy * sizeof (TCHAR)) ;
			pDest	+= nCopy ;
			nDest	-= nCopy ;
			pSrc	++ ;
			break ;

			case	TEXT ('%'):
			{
				*pDest	++	= TEXT ('%') ;
				nDest	-- ;
				pSrc	++ ;
				break ;
			}
			default:
				if (*pSrc != TEXT ('\0'))
					pSrc	++ ;
				break ;
			}
			break ;
			
		default:
			*pDest ++	= *pSrc ++ ;
			nDest -- ;
			break ;
		}
	}
	va_end (vl) ;

	*pDest	= TEXT ('\0') ;
	return ;
}

