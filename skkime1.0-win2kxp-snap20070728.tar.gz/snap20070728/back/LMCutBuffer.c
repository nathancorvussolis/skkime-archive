#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDocP.h"
#include "ImeBuffer.h"
#include "TMarker.h"
#include "lmstate.h"
#include "TCutBufferSession.h"

/*======================================================================== kill-ring-save
 */
static	int		LM_bKillRingSave_Exit (struct CImeDoc*) ;

int
LM_bKillRingSave (
	struct CImeDoc*				pDoc)
{
	if (! ImeDoc_bCall (pDoc, LM_bKillRegion, LM_bKillRingSave_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bKillRingSave_Exit (
	struct CImeDoc*				pDoc)
{
	if (! ImeDoc_vJump (pDoc, LM_bYank))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

/*======================================================================== kill-region
 */
int
LM_bKillRegion (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	struct TMarker*		pmkTop ;
	struct TMarker*		pmkMark ;
	WCHAR		rszBuffer [MAXPREFIXLEN] ;
	int			nLastCmd, nStart, nEnd, nBufferTop, nBufferEnd ;
	BOOL		fAppend ;
	LPCWSTR		pwSrc, pwText ;
	LPWSTR		pwDest ;
	int			nSrc, nDest, nText ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;	

	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_MARK, &pmkMark)   || pmkMark   == NULL) {
		ImeDoc_bSetMessage (pDoc, L"The mark is not set now") ;
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= TMarker_iGetPosition (pmkTop) ;
	} else {
		nBufferTop	= 0 ;
	}

	nStart	= TMarker_iGetPosition (pmkPoint) ;
	nEnd	= TMarker_iGetPosition (pmkMark) ;
	if (nStart > nEnd) {
		int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	if (nStart == nEnd) 
		goto	exit_func ;		/* nothing to do */

	nBufferEnd	= TMarker_iGetPosition (pmkEnd) ;
	if (nStart < nBufferTop || nEnd > nBufferEnd) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	nLastCmd	= ImeDoc_iGetLastCommand (pDoc) ;
	fAppend		= (nLastCmd == NFUNC_KILL_REGION)? TRUE : FALSE ;

	/*	�����ŊO�E�����ɉ��s�R�[�h�� \n �������� 0x0D, 0x0A
	 *	�ɕϊ�����K�v������B
	 */
	pwText	= ImeBuffer_pBufferRawString (pCurBuffer, &nText) ;
	pwSrc	= pwText + nStart ;
	nSrc	= nEnd - nStart ;
	pwDest	= rszBuffer ;
	nDest	= ARRAYSIZE (rszBuffer) ;
	while (nSrc > 0 && nDest > 0) {
		if (*pSrc == L'\n') {
			/*	0x0D, 0x0A �Ƒ�������̂łȂ����
			 *	1����������Ȃ����Ƃɂ���B*/
			if (nDest > 1) {
				*pDest ++	= 0x0D ;					
				*pDest ++	= 0x0A ;
				nDest  -= 2 ;
			}
		} else {
			*pDest ++	= *pSrc ;
			nDest -- ;
		}
		pSrc ++ ;
		nSrc -- ;
	}
	if (! TCutBufferSession_bSet (rszBuffer, pDest - rszBuffer, fAppend) ||
		! ImeBuffer_bDeleteRegion (pCurBuffer, nStart, nEnd)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
exit_func:
	ImeDoc_vSetThisCommand (pDoc, NFUNC_KILL_REGION) ;
	return	LMR_RETURN ;
}

/*======================================================================== yank
 */
int
LM_bYank (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	WCHAR	rszBuffer [MAXPREFIXLEN] ;
	LPWSTR	wptr, wptrStart ;
	int		n ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	n	= TCutBufferSession_iGet (rszBuffer, ARRAYSIZE (rszBuffer)) ;
	if (n > 0) {
		wptr	= rszBuffer ;
		while (n > 0) {
			wptrStart	= wptr ;
			while (n > 0 && *wptr != 0x0D) {
				wptr	++ ;
				n		-- ;
			}
			if (! ImeBuffer_bInsertAndInherit (pCurBuffer, wptrStart, wptr - wptrStart)) {
				ImeDoc_vSetSignalError (pDoc) ;
				return	LMR_RETURN ;
			}

			/*	�O�E�Ƃ̃C���^�[�t�F�[�X�ł��邱�̕����ŉ��s�R�[�h��
			 *	0x0D, 0x0A �Ƃ��Ă���ė���\��������B
			 */
			if (*wptr == 0x0D) {
				if (n > 1 && *(wptr + 1) == 0x0A) {
					while (n > 1 && *wptr == 0x0D && *(wptr + 1) == 0x0A) {
						if (! ImeBuffer_bInsertAndInherit (pCurBuffer, L"\n", 1)) {
							ImeDoc_vSetSignalError (pDoc) ;
							return	LMR_RETURN ;
						}
						wptr	+= 2 ;
						n		-= 2 ;
					}
				} else {
					/*	0x0D �����̏o���͂��̂܂ܒʂ��B
					 */
					if (! ImeBuffer_bInsertAndInherit (pCurBuffer, wptr, 1)) {
						ImeDoc_vSetSignalError (pDoc) ;
						return	LMR_RETURN ;
					}
					wptr	++ ;
					n		-- ;
				}
			}
		}
	}
	return	LMR_RETURN ;
}


