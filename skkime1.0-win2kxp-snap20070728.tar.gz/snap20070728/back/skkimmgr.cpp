#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "uistatus.h"
#include "IME\ImeDoc.h"

#define	REGPATH_GENERIC					TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\Generic")
#define	REGPATH_ALWAYS_OPEN_KANAMODE	TEXT("always-open-kana-mode")

CSkkImeMgr::CSkkImeMgr (CSkkImeTextService* pTSF)
{
	_pTSF		= pTSF ;
	_pTSF->AddRef () ;
	_pDoc		= NULL ;
	_pUIStatus	= NULL ;
	return ;
}

CSkkImeMgr::~CSkkImeMgr ()
{
	if (_pDoc != NULL) {
		delete	_pDoc ;
		_pDoc	= NULL ;
	}
	if (_pUIStatus != NULL) {
		delete	_pUIStatus ;
		_pUIStatus	= NULL ;
	}
	_pTSF->Release () ;
	_pTSF	= NULL ;
	return ;
}

BOOL
CSkkImeMgr::_Init ()
{
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_Init ()\n"))) ;

	_pDoc	= new CImeDoc () ;
	if (_pDoc == NULL)
		return	FALSE ;
	return	_pDoc->Init () ;
}

void
CSkkImeMgr::_Uninit ()
{
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_Uninit ()\n"))) ;

	if (_pDoc != NULL) {
		delete	_pDoc ;
		_pDoc	= NULL ;
	}
	return ;
}

/*	�L�[�}�b�v�ɏ]���̂��؂��B
 *	�L�[��D�����ǂ����́A
 *		1. �t�H�[�J�X�� Top Buffer �ɑ��݂��邩�ۂ� 
 *			Yes -> 2. �̃`�F�b�N��
 *			No  -> �L�[��D��
 *		2. �����v���t�B�N�X�����邩
 *			Yes -> �L�[��D�� (���̌�A�L�[��Ԃ���������Ȃ���)
 *			No  -> 3. �̃`�F�b�N��
 *		3. �L�[�}�b�v������ (SKK/����/�J�i�̃��[�h�Ɉˑ����邪)
 *			�L�[�̓J�[�\���̈ړ��Ɋւ�����̂ł����āA�ҏW���̃e�L�X�g�𑀍삷��
 *			���̂ł͂Ȃ����H
 *			Yes -> �L�[���v���Z�X���Ȃ��B
 *			No  -> �L�[��D���B
 */
int
CSkkImeMgr::QueryProcessKey (
	register WPARAM			wParam,		/* [in] */
	register LPARAM			lParam)		/* [in] */
{
	BOOL	fEaten = FALSE, fToggleIME = FALSE ;

	/*	Control �̂݁AShift �݂̂͒D��Ȃ��B*/
	if (wParam == VK_CONTROL || wParam == VK_SHIFT || wParam == VK_MENU)
		return	SKKIME_NOT_PROCESS_KEY ;

	if (_pDoc->QueryToggleIMEKeyEvent (wParam, lParam, &fToggleIME) && fToggleIME) 
		return	SKKIME_PROCESS_KEY_TOGGLEIME ;

	/*	���̑���ɂ��Ă͔Y�ݒ��B���̑���͎󂯎��ׂ����H
	 *
	 *	 if (_pTSF->_IsComposing () || _IsDuringConversion ()) 
	 *	return	TRUE ;
	 */
	if (_pTSF->_IsComposing ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::QueryProcessKey: Composing -> PROCESS_KEY\n"))) ;
		return	SKKIME_PROCESS_KEY ;
	}

	if (! _pDoc->QueryFilterKeyEvent (wParam, lParam, &fEaten))
		return	SKKIME_NOT_PROCESS_KEY ;
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::QueryProcessKey: Composing -> QueryFilter (%d)\n"), fEaten)) ;
	return	fEaten? SKKIME_PROCESS_KEY : SKKIME_NOT_PROCESS_KEY ;
}

/*	DoEditSession �̒�����Ăяo�����B
 */
HRESULT
CSkkImeMgr::OnEditSession (
	register ITfContext*	pContext,	/* [in] edit context */
	register TfEditCookie	ec,			/* [in] edit cookie */
	register WPARAM			wParam,		/* [in] virtual keycode */
	register LPARAM			lParam,		/* [in] */
	register BOOL*			pfEaten)	/* [out] Is this key event eaten? */
{
	int		nCMode ;
	BOOL	fToggleIME	= FALSE ;
	HRESULT	hr			= S_OK ;

	if (! _pDoc->QueryToggleIMEKeyEvent (wParam, lParam, &fToggleIME))
		fToggleIME	= FALSE ;
	if (fToggleIME) {
		BOOL	fOpen	= _pTSF->_IsKeyboardOpen () ;
		_pTSF->_SetKeyboardOpen (fOpen? FALSE : TRUE) ;
		if (fOpen) {
			register BOOL	fComposing ;
			ITfComposition*	pComposition ;

			fComposing	= _pTSF->_IsComposing (&pComposition) ;
			if (fComposing) {
				_pTSF->_TerminateCompositionInContext (pContext) ;
			}
			if (_pDoc != NULL)
				_pDoc->Clear () ;
		}
		*pfEaten	= TRUE ;
		return	S_OK ;
	}

	/*	filter �����O�̕ϊ����[�h���L�����Ă����B
	 */
	nCMode	= _pDoc->GetConversionMode () ;
	if (! _pDoc->FilterKeyEvent (wParam, lParam, pfEaten))
		return	S_FALSE ;

#if defined (DEBUG)
	if (pfEaten != NULL)
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::OnEditSession (Eaten:%d)\n"), (int)*pfEaten)) ;
#endif
	if (! _UpdateCompose (pContext, ec)) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose failed.\n"))) ;
		hr	= E_FAIL ;
	}
	if (! _UpdateDisplayAttribute (pContext, ec)) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateDisplayAttribute failed.\n"))) ;
		hr	= E_FAIL ;
	}

	/*	�ϊ����[�h���X�V����Ă���΁ALangBar �ɔ��f������B
	 */
	if (nCMode != _pDoc->GetConversionMode ()) 
		_pTSF->_UpdateLangBarItem (c_guidConversionModeItemButton) ;
	if (! _UpdateStatusWindow (pContext, ec)) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateStatusWindow failed.\n"))) ;
		hr	= E_FAIL ;
	}
	return	hr ;
}

BOOL
CSkkImeMgr::OnClearSession (
	register TfEditCookie		ec,
	register ITfComposition*	pComposition)
{
	register BOOL	fRetval ;
	ITfRange*		pRange ;
	
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnClearSession ()\n"))) ;

	if (pComposition != NULL &&
		pComposition->GetRange (&pRange) == S_OK) {
		fRetval	= pRange->SetText (ec, 0, L"", 0) == S_OK ;
		pRange->Release () ;
		pRange	= NULL ;
	}
	if (_pDoc != NULL) {
		/*	���̏��������ł� oh �̓�����Ԃ�ێ��ł��Ȃ��̂ŌӖ������ɂ���
		 *	�Ȃ�Ȃ��B�����A"IME ON","COMPOSITION TEXT���Ȃ�" ��Ԃŕs�ӂ�
		 *	OnClearSession ���Ăяo����āA���̓��[�h���ω����Ă��܂��悤��
		 *	��Ԃ�����邱�Ƃ͂ł���B
		 */
		int	nMode	= _pDoc->GetConversionMode () ;
		_pDoc->Clear () ;
		_pDoc->SetConversionMode (nMode) ;
	}
	if (_pUIStatus != NULL)
		_pUIStatus->_Close () ;
	return	TRUE ;
}

BOOL
CSkkImeMgr::OnReconvertSession (
	register ITfContext*	pContext,	/* [in] edit context */
	register TfEditCookie	ec,			/* [in] edit cookie */
	register LPCWSTR		wstrText)
{
	int		nCMode ;

	if (_pDoc == NULL || _pTSF->_IsKeyboardDisabled ())
		return	FALSE ;

	nCMode	= _pDoc->GetConversionMode () ;
	_pDoc->SetReconvertText (wstrText, lstrlenW (wstrText)) ;
	_UpdateCompose (pContext, ec) ;
	_UpdateDisplayAttribute (pContext, ec) ;
	if (nCMode != _pDoc->GetConversionMode ()) 
		_pTSF->_UpdateLangBarItem (c_guidConversionModeItemButton) ;

	if (! _pTSF->_IsKeyboardOpen ()) {
		_pTSF->_SetKeyboardOpen (TRUE) ;
	}
	_UpdateStatusWindow (pContext, ec) ;
	return	TRUE ;
}

CImeDoc*
CSkkImeMgr::GetDocument ()
{
	return		_pDoc ;
}

/*	�ݒ�t�@�C����ǂݒ�������B*/
BOOL
CSkkImeMgr::UpdateConfig ()
{
	if (_pDoc == NULL)
		return	FALSE ;
	_pDoc->UpdateConfig () ;
	return	TRUE ;
}

void
CSkkImeMgr::OnSetFocus (
	BOOL			fFocus)
{
	if (fFocus) {
		if (_pDoc != NULL)
			_pDoc->UpdateConfig () ;
	}
	if (_pUIStatus != NULL)
		_pUIStatus->_Popup (fFocus) ;
	return ;
}

BOOL
CSkkImeMgr::OnKeyboardOpen (
	BOOL			fOpen)
{
	HKEY			hSubKey ;
	register LONG	lResult ;
	DWORD	dwType, dwValue, cbData ;

	if (fOpen) {
		/*	Keyboard �� open �ɂȂ������Ɂu���ȁv���[�h�ɖ߂��ݒ肪�L�����ǂ���
		 *	������B
		 */
		if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
			return	FALSE ;
		
		cbData	= sizeof (dwValue) ;
		lResult	= RegQueryValueEx (hSubKey, REGPATH_ALWAYS_OPEN_KANAMODE, NULL, &dwType, (LPBYTE)&dwValue, &cbData) ;
		RegCloseKey (hSubKey) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			return	FALSE ;
		if (dwValue) {
			if (_pDoc == NULL)
				return	FALSE ;
			if (_pDoc->GetConversionMode () != IMECMODE_HIRAGANA)
				_pDoc->SetConversionMode (IMECMODE_HIRAGANA) ;
		}
	} else {
		if (_pUIStatus != NULL)
			_pUIStatus->_Close () ;
		if (_pDoc != NULL) {
			int	nMode	= _pDoc->GetConversionMode () ;
			_pDoc->Clear () ;
			_pDoc->SetConversionMode (nMode) ;
		}
	}
	return	TRUE ;
}

/*========================================================================*
 */
BOOL
CSkkImeMgr::_UpdateCompose (
	register ITfContext*	pContext,
	register TfEditCookie	ec)
{
    TF_SELECTION		tfSelection ;
	ULONG				cFetched ;
	ITfComposition*		pComposition ;
	WCHAR				wszPText [512] ;	/* ���[��Amagic number ��... */
	WCHAR				wszReadingText [512] ;
	register LPCWSTR	wstrPText ;
	register LPWSTR		wpDest ;
	int					nPText, nRawShift, nRawCursor ;
	int					nReadingShift, nReadingText ;
	register int		n, nShift, nCursor, nDest ;
	LONG				cch ;
	ITfRange*			pRange		= NULL ;
	ITfRange*			pNewRange	= NULL ;
	ITfProperty*		pProp 		= NULL ;
	ITfProperty*		pPropAttr	= NULL ;
	BOOL				fComposing ;
	BOOL				fRetval		= FALSE ;
	BOOL				fContinue ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose ()\n"))) ;

    if (pContext->GetSelection (ec, TF_DEFAULT_SELECTION, 1, &tfSelection, &cFetched) != S_OK ||
		cFetched != 1)
        return	FALSE ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 1\n"))) ;

	fComposing	= _pTSF->_IsComposing (&pComposition) ;
	wstrPText	= _pDoc->GetPreeditText (&nPText) ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 2\n"))) ;

	/*	Composition String ����ŁAMinibuffer ���L���łȂ��ꍇ�ɂ�
	 *	Composition ���I�����Ĕ�����B
	 *
	 *	if (nPText <= 0 __&& ! _pDoc->IsStatusActivep ()__) {
	 *	����A�Ȃ�� status activep �� comment out�H Wed Oct 29 23:26:43 2003
	 */
	if (nPText <= 0 && ! _pDoc->IsStatusActivep ()) {
		if (fComposing) 
			_pTSF->_TerminateCompositionInContext (pContext) ;
		fRetval	= TRUE ;
		goto	Exit ;
	}
	if (! fComposing) {
		if (! _pTSF->_StartComposition (pContext))
			goto	Exit ;
		(void) _pTSF->_IsComposing (&pComposition) ;
	}

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 3\n"))) ;

	/*	Composition �̃e�L�X�g�̑���B
	 */
	if (pComposition == NULL || pComposition->GetRange (&pRange) != S_OK || pRange == NULL) 
		goto	Exit ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 4\n"))) ;

	/*	attribute ���� clear ���Ă����B*/
    if (SUCCEEDED (pContext->GetProperty (GUID_PROP_ATTRIBUTE, &pPropAttr) && pPropAttr != NULL)) {
		pPropAttr->Clear (ec, pRange) ;
		pPropAttr->Release () ;
	}

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 5\n"))) ;
#if defined (buggy_code_using_prop_reading) || 1
	if (SUCCEEDED (pContext->GetProperty (GUID_PROP_READING, &pProp) && pProp != NULL)) {
		pProp->Clear (ec, pRange) ;
	} else {
		pProp	= NULL ;
	}
#endif

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 6\n"))) ;

	/*	Composition �̃e�L�X�g�̓��A�m�肳�����̂̑���B
	 *	StartRange ���ړ����āA�ړ��ŊO�ꂽ�͈͂ɂ�����̂��m��
	 *	�����Ǝv���B
	 */
	if (! _pDoc->QueryUpdateContext (&nRawShift, &nRawCursor, &fContinue)) 
		goto	Exit ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 7\n"))) ;

	nReadingShift	= nRawShift ;
	nReadingText	= _pDoc->GetReadingText (wszReadingText, NELEMENTS (wszReadingText) - 1, &nReadingShift) ;
	wszReadingText [nReadingText]	= L'\0' ;
#if defined (DEBUG) || defined (DBG)
	OutputDebugStringW (wszReadingText) ;
#endif

	if (nPText <= 0 && _pDoc->IsStatusActivep ()) {
		/*	Fri Oct 31 23:26:15 2003
		 *		���Ȃ茵�������������A�����ǉ�����B���̐S�́A
		 *		j-input-by-code-or-menu �������s������Ԃł́A
		 *		composition �����݂��Ȃ��Ǝv���āAterminate composition
		 *		���Ă΂�Ă��Ȃ����߁B
		 */
		/*	Wed Aug 31 09:45:03 2005
		 *		�c��芸�����ēx�폜�B���̎��̈Ӑ}�͖Y��Ă��܂��Ă���c
		 */
		if (pRange->SetText (ec, 0, L" ", 1) != S_OK) 
			goto	Exit ;
		nShift		= 0 ;
		nCursor		= 0 ;
	} else {
		/*	�n���ꂽ�e�L�X�g�̒��Ɋ܂܂����s�R�[�h�̖�����������
		 *	����΂Ȃ�Ȃ��BL'\n' �� 0x0D, 0x0A �ւƓW�J����Ɠ�����
		 *	�J�[�\���ʒu���C������K�v������B
		 */
		wpDest		= wszPText ;
		nDest		= NELEMENTS (wszPText) ;
		nShift		= nRawShift ;
		nCursor		= nRawCursor ;
		for (n = 0 ; n < nPText ; n ++) {
			if (n == nRawShift) 
				nShift	= wpDest - wszPText ;
			if (n == nRawCursor) 
				nCursor	= wpDest - wszPText ;
			if (*wstrPText == L'\n') {
				*wpDest ++	= 0x0D ;
				nDest -- ;
#if 0
				/*	0x0D, 0x0A �ɒ����̂͗ǂ��Ȃ��炵���B
				 *	Outlook2000 �͖��Ȃ����AInternet Explorer6
				 *	�Ŗ�肪�����B
				 */
				if (nDest > 1) {
					*wpDest ++	= 0x0D ;
					*wpDest ++	= 0x0A ;
					nDest -= 2 ;
				}
#endif
			} else {
				*wpDest ++	= *wstrPText ;
				nDest -- ;
			}
			wstrPText	++ ;
		}
		if (pRange->SetText (ec, 0, wszPText, wpDest - wszPText) != S_OK) 
			goto	Exit ;
	}

	if (! _pDoc->UpdateContext ())
		goto	Exit ;

	DEBUGPRINTF ((TEXT ("nShift = %d/%d, nCursor = %d/%d, fContinute = %d\n"),
				  nShift, nRawShift, nCursor, nRawCursor, fContinue)) ;

	if (pRange->ShiftStart (ec, nShift, &cch, NULL) != S_OK)
		goto	Exit ;
	if (pComposition->ShiftStart (ec, pRange) != S_OK ||
		pComposition->ShiftEnd   (ec, pRange) != S_OK)
		goto	Exit ;

	tfSelection.range->ShiftStartToRange (ec, pRange, TF_ANCHOR_START) ;
	tfSelection.range->Collapse (ec, TF_ANCHOR_START) ;
	tfSelection.range->ShiftStart (ec, nCursor, &cch, NULL) ;
	pContext->SetSelection (ec, 1, &tfSelection) ;

#if defined (buggy_code_using_prop_reading) || 1
	if (pProp != NULL && nReadingText > nReadingShift) {
		VARIANT		var ;
		HRESULT		hr ;

		VariantInit (&var) ;
		var.vt		= VT_BSTR ;
		var.bstrVal	= SysAllocString (wszReadingText + nReadingShift) ;
		hr	= pProp->SetValue (ec, pRange, &var) ;
		if (FAILED (hr)) {
#if defined (DEBUG) || defined (DBG)
			LPVOID lpMsgBuf	= NULL ;
			FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER |
				FORMAT_MESSAGE_FROM_SYSTEM |
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				hr,
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // ����̌���
				(LPTSTR) &lpMsgBuf,
				0,
				NULL) ;
			if (lpMsgBuf != NULL)
				OutputDebugString ((LPCTSTR)lpMsgBuf) ;
			LocalFree (lpMsgBuf) ;
			DEBUGPRINTF ((TEXT ("pProp->SetValue() failed (0x%lx)\n"), (DWORD)hr)) ;
			if (hr == E_INVALIDARG) {
				DEBUGPRINTF ((TEXT ("E_INVALIDARG\n"))) ;
			}
#endif
		}
		VariantClear (&var) ;
	}
#endif
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 8\n"))) ;
	if (! fContinue)
		_pTSF->_TerminateComposition (ec) ;
	fRetval	= TRUE ;

  Exit:
	if (pProp != NULL)
		pProp->Release () ;
	if (pRange != NULL)
		pRange->Release () ;
	tfSelection.range->Release () ;
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - leave(%d)\n"), fRetval)) ;
	return	fRetval ;
}

HRESULT
CSkkImeMgr::_UpdateDisplayAttribute (
	register ITfContext*	pContext,
	register TfEditCookie	ec)
{
	ITfComposition*			pComposition ;
	ITfRange*				pRange			= NULL ;
	ITfRange*				pRangeC			= NULL ;
	BOOL					fComposing, fConverted ;
	int						nBegin, nEnd ;
	HRESULT					hr	= E_FAIL ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateDisplayAttribute ()\n"))) ;


	fComposing	= _pTSF->_IsComposing (&pComposition) ;
	if (! fComposing)
		goto	Exit ;
	if ((hr = pComposition->GetRange (&pRange)) != S_OK) 
		goto	Exit ;

	fConverted	= _pDoc->GetConvertedRegion (&nBegin, &nEnd) ;
	pRangeC		= NULL ;
	if (fConverted && nBegin < nEnd && nEnd > 0) {
		LONG	cch ;
		if (FAILED (pRange->Clone (&pRangeC)))
			goto	Exit ;
		if (FAILED (pRangeC->ShiftStart (ec, nBegin, &cch, NULL)) ||
			FAILED (pRangeC->Collapse (ec, TF_ANCHOR_START)) ||
			FAILED (pRangeC->ShiftEnd (ec, nEnd - nBegin, &cch, NULL)))
			goto	Exit ;
	}
	if (pRangeC != NULL) {
		hr	= _pTSF->_SetCompositionDisplayAttributes (ec, pRange, pRangeC) ;
	} else {
		hr	= S_FALSE ;
	}
  Exit:
	if (pRange != NULL)
		pRange->Release () ;
	if (pRangeC != NULL)
		pRangeC->Release () ;
    return	hr ;
}

BOOL
CSkkImeMgr::_UpdateStatusWindow (
	register ITfContext*	pContext,
	register TfEditCookie	ec)
{
	int					nLength ;
	BOOL				bComposing ;
	ITfComposition*		pComposition	= NULL ;

	if (_pTSF == NULL || _pDoc == NULL)
		return	FALSE ;

	if (_pUIStatus == NULL) {
		_pUIStatus	= new CUIStatus (_pTSF, this) ;
		if (_pUIStatus == NULL)
			return	FALSE ;
	}

	/*	Wed Aug 31 09:50:02 2005
	 *		Composing �łȂ���Ԃ� UIStatus �� Popup ����ƁA�e�L�X�g��ҏW���ĂȂ���Ԃ�
	 *		Popup ���c���Ă��܂��̂ł��܂�ǂ��Ȃ� (design �I�ɂ��AITfRange �̒l�I�ɂ�)�B
	 */
	bComposing	= _pTSF->_IsComposing (&pComposition) ;
	_pDoc->GetStatusText (&nLength) ;
	if (bComposing && (nLength > 0 || _pDoc->IsStatusActivep ())) {
		if (! _pUIStatus->_IsActivep (pContext)) {
			ITfRange*			pRange			= NULL ;

			if (bComposing && pComposition != NULL)
				(void) pComposition->GetRange (&pRange) ;
			_pUIStatus->_Open (pContext, pRange) ;
			if (pRange != NULL)
				pRange->Release () ;
		}
		_pUIStatus->_Update () ;
	} else {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateStatusWindow -> _CloseWindow (composing:%d,length:%d)\n"), bComposing, nLength)) ;
		_pUIStatus->_Close () ;
	}
	return	TRUE ;
}

HRESULT
CSkkImeMgr::_QueryFocus (
	register ITfContext*	pContext,
	register TfEditCookie	ec)
{
    ITfRange*		pRangeComposition ;
    TF_SELECTION	tfSelection ;
	HRESULT			hr	= S_OK ;
	ULONG			cFetched ;
	BOOL			fCovered ;
	ITfComposition*	pComposition ;

//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (1) \n"))) ;

	if (! _pTSF->_IsComposing (&pComposition))
		return	S_OK ;

//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (2) \n"))) ;

    if (pContext->GetSelection (ec, TF_DEFAULT_SELECTION, 1, &tfSelection, &cFetched) != S_OK ||
		cFetched != 1)
        return	S_FALSE ;
	
//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus(%p) -- (3) \n"), pComposition)) ;

    if (pComposition->GetRange (&pRangeComposition) == S_OK) {
        fCovered	= IsRangeCovered (ec, tfSelection.range, pRangeComposition) ;
        pRangeComposition->Release () ;
		
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (4) \n"))) ;
        if (!fCovered) {
            hr	= S_FALSE; // don't eat the key, it's outside our composition
            goto	Exit ;
        }
    }
//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (5) \n"))) ;
 Exit:
//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (6) \n"))) ;
    tfSelection.range->Release () ;
	return	hr ;
}

/*========================================================================*
 */
BOOL
CSkkImeTextService::_InitSkkImeMgr ()
{
    BOOL		fThreadfocus ;
    ITfSource*	pSource	= NULL ;

	_pSkkIme	= new CSkkImeMgr (this) ;
	if (_pSkkIme == NULL)
		return	FALSE ;

	if (! _pSkkIme->_Init ())
		goto	ExitError ;

    // we also need a thread focus sink

    if (_pThreadMgr->QueryInterface(IID_ITfSource, (void **)&pSource) != S_OK) {
        pSource	= NULL ;
        goto	ExitError ;
    }

    if (pSource->AdviseSink(IID_ITfThreadFocusSink, (ITfThreadFocusSink *)this, &_dwThreadFocusSinkCookie) != S_OK) {
        // make sure we don't try to Unadvise _dwThreadFocusSinkCookie later
        _dwThreadFocusSinkCookie	= TF_INVALID_COOKIE ;
        goto	ExitError ;
    }

    pSource->Release () ;

    // we may need to display the snoop window right now
    // our thread focus sink won't be called until something changes,
    // so we need to check the current state.

    if (_pThreadMgr->IsThreadFocus(&fThreadfocus) == S_OK && fThreadfocus) {
        OnSetThreadFocus () ;
    }

    return	TRUE ;

ExitError:
    SafeRelease(pSource);
    _UninitSkkImeMgr () ;
    return FALSE;
}

void
CSkkImeTextService::_UninitSkkImeMgr ()
{
    ITfSource*	pSource ;

    if (_pSkkIme != NULL) {
        _pSkkIme->_Uninit () ;
		delete	_pSkkIme ;
		_pSkkIme	= NULL ;
    }
    if (_dwThreadFocusSinkCookie != TF_INVALID_COOKIE) {
		if (_pThreadMgr != NULL) {
			if (_pThreadMgr->QueryInterface(IID_ITfSource, (void **)&pSource) == S_OK) {
				pSource->UnadviseSink(_dwThreadFocusSinkCookie);
				pSource->Release();
			}
		}
        _dwThreadFocusSinkCookie = TF_INVALID_COOKIE;
    }
	return ;
}

