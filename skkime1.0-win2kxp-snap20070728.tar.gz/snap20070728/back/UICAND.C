/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * UICAND.C
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "commctrl.h"
#include "immdev.h"
#include "skki1_0.h"
#include "skksubs.h"

typedef struct tagTEXTREGION {
	DWORD		m_nCandidate ;
	int			m_nOffset ;
	int			m_nLength ;
}	TEXTREGION, *PTEXTREGION ;

/*
 *	�v���g�^�C�v�錾�B
 */
static	BOOL	PASCAL	UICand_moveDefault (HWND, LPINPUTCONTEXT, LPUIEXTRA) ;
static	BOOL	PASCAL	UICand_moveExclude (HWND, LPINPUTCONTEXT, LPUIEXTRA) ;
static	BOOL	PASCAL	UICand_movePosition (HWND, LPINPUTCONTEXT, LPUIEXTRA) ;
static	BOOL	PASCAL	UICand_paint (HWND, HDC, HIMC, LPRECT) ;
static	BOOL	PASCAL	UICand_paintCandList (HWND, HDC, LPCANDIDATELIST, LPRECT) ;
static	BOOL	PASCAL	UICand_paintCodeList (HWND, HDC, LPCANDIDATELIST, LPRECT) ;
static	BOOL	PASCAL	UICand_paintCode1List (HWND, HDC, LPCANDIDATELIST, LPRECT) ;
static	void	PASCAL	UICand_relayEventToTooltip (HWND, UINT) ;
static	HWND	PASCAL	UICand_createToolTip (HWND) ;
static	BOOL	PASCAL	uiCand_adjustSize (HWND, LPINPUTCONTEXT, LPSIZE) ;
static	int		PASCAL	uiCand_getCandText (LPTSTR, int, PTEXTREGION, LPCANDIDATELIST) ;
static	BOOL	PASCAL	UICand_configureToolTip (HWND, LPINPUTCONTEXT) ;

/*
 *	---- �֐��̒�` ---- ��������---- �֐��̒�` ---- ��������----
 */

/*
 *	Candidate Window �� WINDOWPROC�B
 *(�R�����g)
 *	Candidate Window ����Window Message�͂��̊֐��ɑ����ė��܂��̂ŁA
 *	Window Message �ɑΉ������������s���܂��B���̊֐����̂� Window
 *	Message �̐U�蕪�������ł����ǁB
 *(����)
 *	hWnd	Window Message ���󂯎���� Composition Window �� Handle
 *	message	Window Message
 *	wParam	Window Message �̈�������1
 *	lParam	Window Message �̈�������2
 *(����)
 *	Candidate Window �͕ϊ���⃊�X�g��\������̂Ɏg�� Window �ł��B
 */
LRESULT	CALLBACK
UICand_WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	register HWND		hUIWnd ;
	register HGLOBAL	hUICandInfo ;

	DEBUGPRINTF ((TEXT ("Message:%d, WPARAM: 0x%lx, LPARAM: 0x%0lx\n"), message, wParam, lParam)) ;

	switch (message){
	case WM_PAINT:
		UICand_Paint (hWnd) ;
		break ;

	case	WM_SETCURSOR:
		if (HIWORD(lParam) == WM_LBUTTONDOWN ||
			HIWORD(lParam) == WM_RBUTTONDOWN) {
			DragUI (hWnd, message, wParam, lParam) ;
		} else {
			if (skkime_IsShowAnnotation ())
				UICand_relayEventToTooltip (hWnd, WM_SETCURSOR) ;
		}
		break ;

	case	WM_MOUSEMOVE:
		DragUI (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_LBUTTONUP:
	case	WM_RBUTTONUP:
		DragUI (hWnd, message, wParam, lParam) ;
		SetWindowLong (hWnd, FIGWL_UICAND_MOUSE, 0L) ;
		break ;

	case WM_MOVE:
		hUIWnd	= (HWND)GetWindowLongPtr (hWnd, FIGWL_UICAND_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_CANDMOVE, wParam, lParam) ;
		break;

	default:
		if (!MyIsIMEMessage (message))
			return DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	0L ;
}

/*************************************************************************
 *	CreateCandWindow
 *		���\���ɗp���� Window ���쐬����֐��B
 *************************************************************************/
void	PASCAL
UICand_Create (
	register HWND				hUIWnd,
	register LPUIEXTRA			lpUIExtra,
	register LPINPUTCONTEXT		lpIMC)
{
	HINSTANCE			hInstance ;
	POINT				pt ;
	register HGLOBAL	hUICandInfo ;

	DEBUGPRINTFEX (99, (TEXT ("UICand_Create (hwnd:%lx)\n"), (DWORD)hUIWnd)) ;

	if (UICand_GetPosFromCompWnd (lpUIExtra, &pt)){
		lpUIExtra->uiCand.pt.x	= pt.x ;
		lpUIExtra->uiCand.pt.y	= pt.y ;
	}
	hInstance	= (HINSTANCE)GetWindowLongPtr (hUIWnd, GWLP_HINSTANCE) ;

	if (!IsWindow (lpUIExtra->uiCand.hWnd)){
		HWND	hwndUICand ;
		hwndUICand	= CreateWindowEx (WS_EX_WINDOWEDGE,
								(LPTSTR)szCandClassName, NULL,
								WS_COMPDEFAULT | WS_DLGFRAME,
								lpUIExtra->uiCand.pt.x,
								lpUIExtra->uiCand.pt.y,
								1, 1,
								hUIWnd, NULL, hInstance, NULL) ;
		lpUIExtra->uiCand.hWnd	= hwndUICand ;
		SetWindowLongPtr (hwndUICand, FIGWL_UICAND_TOOLTIP, (LONG_PTR) NULL) ;
	}
	SetWindowLongPtr (lpUIExtra->uiCand.hWnd, FIGWL_UICAND_SVRWND,  (LONG_PTR) hUIWnd) ;
	ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
	lpUIExtra->uiCand.bShow	= FALSE ;

	SetWindowLong    (lpUIExtra->uiCand.hWnd, FIGWL_UICAND_MOUSE,   0L) ;
	return ;
}

/*************************************************************************
 *	UICand_Paint
 *		�ϊ����\�� Window ���ĕ`�悷��B
 *************************************************************************/
void	PASCAL	UICand_Paint (HWND hCandWnd)
{
	PAINTSTRUCT		ps ;
	HIMC			hIMC ;
	HBRUSH			hbr ;
	HDC				hDC ;
	RECT			rc ;
	register HWND	hSvrWnd ;
	HBRUSH 			hBrushParent ;
	HDC				hPDC ;

	GetClientRect (hCandWnd, &rc) ;
	hDC				= BeginPaint (hCandWnd, &ps) ;

	/* ���\��������U�e Window �̔w�i�F�œh��Ԃ��B*/
	hPDC			= GetDC (GetParent (hCandWnd)) ;
	hBrushParent	= CreateSolidBrush (GetBkColor (hPDC)) ;
	hbr				= SelectObject (hDC, hBrushParent) ;
	PatBlt (hDC, 0, 0, rc.right - rc.left, rc.bottom - rc.top, PATCOPY) ;
	SelectObject (hDC, hbr) ;
	DeleteObject (hBrushParent) ;
	ReleaseDC (GetParent (hCandWnd), hPDC) ;
	SetTextColor (hDC, RGB (0, 0, 0)) ;
	SetBkMode (hDC, TRANSPARENT) ;

	/* ���ꗗ��\������B*/
	hSvrWnd			= (HWND)GetWindowLongPtr (hCandWnd, FIGWL_UICAND_SVRWND) ;
	hIMC			= (HIMC)GetWindowLongPtr (hSvrWnd, IMMGWLP_IMC) ;
	UICand_paint (hCandWnd, hDC, hIMC, &rc) ;
	EndPaint (hCandWnd, &ps) ;
	return ;
}

/*************************************************************************
 *	UICand_Hide
 *		���\�������\����Ԃɂ���B
 *************************************************************************/
void	PASCAL
UICand_Hide (
	register LPUIEXTRA		lpUIExtra)
{
	RECT	rc ;

	DEBUGPRINTFEX (99, (TEXT ("UICand_Hide ()\n"))) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, (LPRECT)&rc);
		lpUIExtra->uiCand.pt.x	= rc.left ;
		lpUIExtra->uiCand.pt.y	= rc.top ;
		MoveWindow (lpUIExtra->uiCand.hWnd, -1 , -1 , 0 , 0, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		lpUIExtra->uiCand.bShow	= FALSE ;

#if 1
		{
			HWND	hwndTT	= (HWND) GetWindowLongPtr (lpUIExtra->uiCand.hWnd, FIGWL_UICAND_TOOLTIP) ;
			if (hwndTT != NULL && IsWindow (hwndTT)) {
				SetWindowLongPtr (lpUIExtra->uiCand.hWnd, FIGWL_UICAND_TOOLTIP, (LONG_PTR)0) ;
				DestroyWindow (hwndTT) ;
			}
		}
#endif
	}
	return ;
}

/*************************************************************************
 *	UICand_Move
 *		���\����������̈ʒu�Ɉړ�������B�ǂ̈ʒu���͕ϊ��N���C�A���g��
 *		�w������B
 *************************************************************************/
void	PASCAL
UICand_Move (
	register HWND			hUIWnd,
	register LPINPUTCONTEXT	lpIMC,
	register LPUIEXTRA		lpUIExtra,
	register BOOL			fForceComp)
{
	POINT			pt ;
	CANDIDATEFORM	caf ;

	if (! (lpUIExtra->dwShowStyle & ISC_SHOWUIALLCANDIDATEWINDOW))
		return ;

	DEBUGPRINTF ((TEXT ("UICand_Move (index:%d, style:%d)\n"), 
		(int)lpIMC->cfCandForm [0].dwIndex, (int) lpIMC->cfCandForm [0].dwStyle)) ;

	if (fForceComp){
		if (UICand_GetPosFromCompForm (lpIMC, lpUIExtra, &pt)){
			caf.dwIndex			= 0 ;
			caf.dwStyle			= CFS_CANDIDATEPOS ;
			caf.ptCurrentPos.x	= pt.x ;
			caf.ptCurrentPos.y	= pt.y ;
			ImmSetCandidateWindow (lpUIExtra->hIMC, &caf) ;
		}
		return ;
	}
	if (lpIMC->cfCandForm [0].dwIndex == -1){
		UICand_moveDefault (hUIWnd, lpIMC, lpUIExtra) ;
		return ;
	}
	if (! IsCandidate (lpIMC))
		return ;

	if (lpIMC->cfCandForm [0].dwStyle == CFS_EXCLUDE){
		UICand_moveExclude (hUIWnd, lpIMC, lpUIExtra) ;
	}  else if (lpIMC->cfCandForm[0].dwStyle == CFS_CANDIDATEPOS){
		UICand_movePosition (hUIWnd, lpIMC, lpUIExtra) ;
	}
	if (IsWindow (lpUIExtra->uiCand.hWnd) && skkime_IsShowAnnotation ())
		UICand_configureToolTip (lpUIExtra->uiCand.hWnd, lpIMC) ;
	return ;
}

/*************************************************************************
 *	MoveCandWindow
 *		���\�����̓K�؂ȑ傫���𓾂�B
 *************************************************************************/
BOOL	PASCAL
uiCand_adjustSize (
	HWND			hwnd,
	LPINPUTCONTEXT	lpIMC,
	LPSIZE			lpSize)
{
	HWND			hSvrWnd ;
	HDC				hDC			= NULL ;
	HFONT			hOldFont ;
	LPCANDIDATEINFO	lpCandInfo	= NULL ;
	LPCANDIDATELIST	lpCandList	= NULL ;
	TEXTMETRIC		tm ;
	int				nDefaultWidth, nDefaultHeight, nFrameWidth, nFrameHeight ;

	if (lpIMC == NULL)
		return	FALSE ;

	hDC			= GetDC (hwnd) ;
	if (!hDC)
		return	FALSE ;

	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (lpCandInfo == NULL)
		goto	exit_func_1 ;

	hOldFont	= CheckNativeCharset (hDC) ;
	GetTextMetrics (hDC, &tm) ;

	nFrameWidth		= GetSystemMetrics (SM_CXDLGFRAME) * 2 ;
	nFrameHeight	= GetSystemMetrics (SM_CYDLGFRAME) * 2 ;
	nDefaultWidth	= tm.tmAveCharWidth * DEFAULT_MINIBUF_CHARWIDTH + nFrameWidth ;
	nDefaultHeight	= tm.tmHeight + nFrameHeight ;

	lpCandList	= (LPCANDIDATELIST)((LPSTR)lpCandInfo  + lpCandInfo->dwOffset[0]) ;
	switch (lpCandList->dwPageSize) {
	case	JINPUTBYCODEORMENU1_PAGESIZE:
	case	JINPUTBYCODEORMENU_PAGESIZE:
		if (lpSize){
			if (lpSize->cx < nDefaultWidth)
				lpSize->cx	= nDefaultWidth ;
			lpSize->cy	= nDefaultHeight ;
		}
		break ;
	case	7:
	default:
		{
			TCHAR	bufText [1024] ;
			int		nText, nWidth, nHeight ;
			SIZE	sz ;

			nText	= uiCand_getCandText (bufText, NELEMENTS (bufText), NULL, lpCandList) ;
			if (nText > 0) {
				GetTextExtentPoint32 (hDC, bufText, nText, &sz) ;
				nWidth	= (lpSize != NULL && nDefaultWidth < lpSize->cx)? lpSize->cx : nDefaultWidth ;
				if ((sz.cx + nFrameWidth) > nWidth) {
					int	n	= nWidth - nFrameWidth ;
					nHeight	= (sz.cx + n - 1) / n * sz.cy + nFrameHeight ;
				} else {
					nHeight	= sz.cy + nFrameHeight ;
				}
				nHeight	= (nHeight < nDefaultHeight)? nDefaultHeight : nHeight ;
			} else {
				nWidth	= nDefaultWidth ;
				nHeight	= nDefaultHeight ;
			}
			if (lpSize) {
				if (lpSize->cx < nWidth)
					lpSize->cx	= nWidth ;
				lpSize->cy	= nHeight ;
			}
		}
		break ;
	}
	DeleteObject (SelectObject (hDC, hOldFont)) ;
exit_func_1:
	if (lpCandInfo != NULL)
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
	if (hDC != NULL)
		ReleaseDC (hwnd, hDC) ;
	return	TRUE ;
}

/*************************************************************************
 *	GetCansPosFromCompWnd ()
 *		���\������ Composition Window �ɂ�����Ȃ��悤�Ȉʒu�𓾂�B
 *		���\���������R�Ȉʒu�ɔz�u�ł���Ηǂ��̂����A����c����������
 *		���ȍ��ɂ͂Ȃ��Ă��Ȃ��B�Œ�ʒu�B
 *		������AComposition Window ���B���Ă��܂��ƂƂĂ����f�B
 *************************************************************************/
BOOL	PASCAL
UICand_GetPosFromCompWnd (
	LPUIEXTRA		lpUIExtra,
	LPPOINT			lppt)
{
	RECT rc ;

	if (lpUIExtra->dwCompStyle){
		if (lpUIExtra->uiComp [0].bShow){
			GetWindowRect (lpUIExtra->uiComp[0].hWnd, &rc) ;
			lppt->x	= rc.left ;
			lppt->y	= rc.bottom + 1 ;
			return	TRUE ;
		}
	} else {
		if (lpUIExtra->uiDefComp.bShow){
			GetWindowRect (lpUIExtra->uiDefComp.hWnd, &rc) ;
			lppt->x	= rc.left ;
			lppt->y	= rc.bottom + 1 ;
			return	TRUE ;
		}
	}
	return	FALSE ;
}

BOOL	PASCAL
UICand_GetPosFromCompForm (
	register LPINPUTCONTEXT	lpIMC,
	register LPUIEXTRA		lpUIExtra,
	register LPPOINT		lppt)
{
	TEXTMETRIC	tm ;
	if (lpUIExtra->dwCompStyle){
		if (lpIMC && lpIMC->fdwInit & INIT_COMPFORM){
			GetCompFontMetrics (lpUIExtra, &tm) ;
			if (!lpUIExtra->bVertical){
				lppt->x	= lpIMC->cfCompForm.ptCurrentPos.x ;
				lppt->y	= lpIMC->cfCompForm.ptCurrentPos.y + tm.tmHeight ;
			} else {
				lppt->x	= lpIMC->cfCompForm.ptCurrentPos.x ;
				lppt->y	= lpIMC->cfCompForm.ptCurrentPos.y + tm.tmMaxCharWidth ;
			}
			return	TRUE ;
		}
	} else {
		if (UICand_GetPosFromCompWnd (lpUIExtra, lppt)){
			ScreenToClient (lpIMC->hWnd, lppt) ;
			return	TRUE ;
		}
	}
	return	FALSE ;
}

/*========================================================================
 *	private functions
 */
BOOL	PASCAL
UICand_moveDefault (
	register HWND				hUIWnd,
	register LPINPUTCONTEXT		lpIMC,
	register LPUIEXTRA			lpUIExtra)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	POINT	pt ;
	SIZE	sizeCandWnd ;

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, (LPRECT)&rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom = 0 ;
	}
	if (! UICand_GetPosFromCompWnd (lpUIExtra, &pt)){
		pt.x = pt.y = 0 ;
	}
	/* ��⑋�̑傫�����v�Z����B*/
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;
	sizeCandWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom - rc.top + 2 * GetSystemMetrics (SM_CYEDGE) ;
	uiCand_adjustSize (hUIWnd, lpIMC, &sizeCandWnd) ;

	lpUIExtra->uiCand.pt.x	= pt.x ;
	lpUIExtra->uiCand.pt.y	= pt.y ;

	MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
	ShowWindow (lpUIExtra->uiCand.hWnd, SW_SHOWNOACTIVATE) ;
	lpUIExtra->uiCand.bShow	= TRUE ;
	InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x,(WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL
UICand_moveExclude (
	register HWND			hUIWnd,
	register LPINPUTCONTEXT	lpIMC,
	register LPUIEXTRA		lpUIExtra)
{
	RECT	rc ;
	RECT	rcWork ;
	RECT	rcExclude ;
	RECT	rcUIWnd ;
	POINT	pt ;
	SIZE	sizeCandWnd ;

	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetClientRect (lpUIExtra->uiCand.hWnd, &rc) ;
	} else {
		rc.left	= rc.top	= rc.bottom	= rc.right	= 0 ;
	}
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;

	/* ��⑋��\�����Ă͂����Ȃ��̈�𓾂�B*/
	pt.x	= lpIMC->cfCandForm [0].rcArea.left ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.top ;
	MyClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.left		= pt.x ;
	rcExclude.top		= pt.y ;
	pt.x	= lpIMC->cfCandForm [0].rcArea.right ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.bottom ;
	MyClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.right		= pt.x ;
	rcExclude.bottom	= pt.y ;

	/* ��⑋�̈ʒu�Ƒ傫�������肷��B*/
	sizeCandWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom - rc.top + 2 * GetSystemMetrics (SM_CYEDGE) ;
	uiCand_adjustSize (hUIWnd, lpIMC, &sizeCandWnd) ;

	pt.x	= 0 ;
	pt.y	= rcUIWnd.bottom - rcUIWnd.top ;
	MyClientToScreen (lpIMC->hWnd, &pt) ;

	/* Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B*/
	if ((pt.x + sizeCandWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - sizeCandWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + sizeCandWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - sizeCandWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	/* Window ���w�肵���̈�ɂ������Ă��Ȃ����ǂ����`�F�b�N����B*/
	if (IsCrossRectangle (&pt, &sizeCandWnd, &rcExclude)){
		pt.y	= rcExclude.bottom ;
		if ((pt.y + sizeCandWnd.cy) > rcWork.bottom)
			pt.y	= rcExclude.top - sizeCandWnd.cy ;
	}

	/* �ǂ��ړ������悤�Ƃ����̂���\������B*/
	DEBUGPRINTF ((TEXT ("UICand_moveExclude (%d, %d)/(%d, %d)-(%d,%d)\n"),
				  (int)pt.x, (int)pt.y,
				  rcExclude.left,
				  rcExclude.top,
				  rcExclude.right,
				  rcExclude.bottom)) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, &rc) ;
		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd,SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiCand.bShow	= TRUE ;
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL
UICand_movePosition (
	register HWND			hUIWnd,
	register LPINPUTCONTEXT	lpIMC, 
	register LPUIEXTRA		lpUIExtra)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	RECT	rcWork ;
	SIZE	sizeCandWnd ;
	POINT	pt ;

#if 0
	if (IsWindow (lpIMC->hWnd)) {
		WINDOWINFO	wi ;
		wi.cbSize	= sizeof (WINDOWINFO) ;
		if (GetWindowInfo (lpIMC->hWnd, &wi)) {
			DEBUGPRINTF ((TEXT ("Window(%d,%d-%d,%d),Client(%d,%d-%d,%d),Border(%d,%d)\n"),
				wi.rcWindow.left, wi.rcWindow.top, wi.rcWindow.right, wi.rcWindow.bottom,
				wi.rcClient.left, wi.rcClient.top, wi.rcClient.right, wi.rcClient.bottom,
				wi.cxWindowBorders, wi.cyWindowBorders)) ;
		}
	}
#endif
#if 0
	if (IsWindow (hUIWnd)) {
		RECT	rcC, rcW ;
		GetWindowRect (hUIWnd, &rcW) ;
		GetClientRect (hUIWnd, &rcC) ;
		DEBUGPRINTF ((TEXT ("UICand_movePosition (hUIWnd(0x%x):%d, %d)\n"), 
			(unsigned int) hUIWnd,
			(rcW.right  - rcW.left) - (rcC.right  - rcC.left),
			(rcW.bottom - rcW.top)  - (rcC.bottom - rcC.top))) ;
		GetWindowRect (lpIMC->hWnd, &rcW) ;
		GetClientRect (lpIMC->hWnd, &rcC) ;
		DEBUGPRINTF ((TEXT ("UICand_movePosition (lpIMC->hWnd(0x%x):%d, %d)\n"), 
			(unsigned int) lpIMC->hWnd,
			(rcW.right  - rcW.left) - (rcC.right  - rcC.left),
			(rcW.bottom - rcW.top)  - (rcC.bottom - rcC.top))) ;
	}
#endif
	pt.x	= lpIMC->cfCandForm[0].ptCurrentPos.x ;
	pt.y	= lpIMC->cfCandForm[0].ptCurrentPos.y ;
	MyClientToScreen (lpIMC->hWnd, &pt) ;

	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, &rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom	= 0 ;
	}

	/*	Window ����ʊO�ɏo�����Ƃ��Ӑ}���Ă��邩�H 
	 *
	 *	�ǂ�����ʊO���w�肷�邱�ƂŁA��\�����Ӑ}���Ă���
	 *	�A�v���P�[�V���������݂���悤���B
	 * (��)
	 *	PSO
	 */
	if ((pt.x + 1) >= rcWork.right && (pt.y + 1) >= rcWork.bottom) {
		/*	���̏ꍇ�ɂ͉�ʊO�ɏo�����Ƃ��Ӑ}���Ă���Ɣ��f����B*/
		if (IsWindow (lpUIExtra->uiCand.hWnd))
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		lpUIExtra->uiCand.bShow	= FALSE ;
		return	TRUE ;
	}

	/* ��⑋�̑傫�����v�Z����B*/
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;
	sizeCandWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom - rc.top + 2 * GetSystemMetrics (SM_CYEDGE) ;
	uiCand_adjustSize (hUIWnd, lpIMC, &sizeCandWnd) ;

	/*	Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B
	 */
	if ((pt.x + sizeCandWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - sizeCandWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + sizeCandWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - sizeCandWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	/* �ǂ��ړ������悤�Ƃ����̂���\������B*/
	DEBUGPRINTF ((TEXT ("UICand_movePosition (%d, %d)/(%d, %d)/(%dx%d)\n"),
				  (int)pt.x, (int)pt.y,
				  (int)lpIMC->cfCandForm [0].ptCurrentPos.x,
				  (int)lpIMC->cfCandForm [0].ptCurrentPos.y,
				  rcWork.right, rcWork.bottom)) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd, SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiCand.bShow	= TRUE ;
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL
UICand_paint (
	register HWND		hWnd,
	register HDC		hDC,
	register HIMC		hIMC,
	register LPRECT		prcDraw)
{
	register LPINPUTCONTEXT		lpIMC ;
	register LPCANDIDATEINFO	lpCandInfo ;
	register LPCANDIDATELIST	lpCandList ;
	register HFONT	hOldFont ;

	if (hIMC == NULL)
		return	FALSE ;

	lpIMC		= ImmLockIMC (hIMC) ;
	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (lpCandInfo == NULL)
		goto	exit_func_1 ;

	hOldFont	= CheckNativeCharset (hDC) ;
	lpCandList	= (LPCANDIDATELIST)((LPSTR)lpCandInfo  + lpCandInfo->dwOffset[0]) ;
	switch (lpCandList->dwPageSize) {
	case	JINPUTBYCODEORMENU1_PAGESIZE:
		UICand_paintCode1List (hWnd, hDC, lpCandList, prcDraw) ;
		break ;
	case	JINPUTBYCODEORMENU_PAGESIZE:
		UICand_paintCodeList (hWnd, hDC, lpCandList, prcDraw) ;
		break ;
	case	7:
	default:
		UICand_paintCandList (hWnd, hDC, lpCandList, prcDraw) ;
		break ;
	}
	ImmUnlockIMCC (lpIMC->hCandInfo) ;

	/*	�m�ۂ��Ă��� GDI ���\�[�X�̉���B
	 */
	if (hOldFont) 
		DeleteObject(SelectObject(hDC, hOldFont));
 exit_func_1:
	ImmUnlockIMC (hIMC) ;
	return	TRUE ;
}

BOOL	PASCAL
UICand_paintCandList (
	register HWND				hWnd,
	register HDC				hDC,
	register LPCANDIDATELIST	pCandList,
	register LPRECT				prcDraw)
{
	HBRUSH				hULBrush = NULL, hOldBrush = NULL ;
	HBITMAP				hbmUL = NULL ;
	int					nULHeight, nPageSize, nText ;
	COLORREF			colUL ;
	SIZE				sz ;
	TCHAR				bufText [1024] ;
	TEXTREGION			bufAnnot [32] ;
	PTEXTREGION			pbufAnnot ;

	hULBrush	= GetImeLineBrush (hWnd, MYCOLOR_TEXTAUTO, MYLINE_THIN_DITHER, &colUL, &hbmUL, &nULHeight) ;
	if (hULBrush)
		hOldBrush	= SelectObject (hDC, hULBrush) ;

	pbufAnnot	= (pCandList->dwPageSize >= NELEMENTS (bufAnnot))? NULL : bufAnnot ;
	nPageSize	= (pbufAnnot == NULL)? 0 : pCandList->dwPageSize ;
	memset (bufAnnot, 0, sizeof (bufAnnot)) ;
	nText		= uiCand_getCandText (bufText, NELEMENTS (bufText), pbufAnnot, pCandList) ;
	if (nText > 0) {
		int		nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPTSTR		pText ;
		PTEXTREGION	pAnnot ;
		TEXTMETRIC	tm ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= prcDraw->top ;
		pText		= bufText ;
		nTextPos	= 0 ;

		while (y < prcDraw->bottom && 0 < nText) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= prcDraw->left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32 (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) > prcDraw->right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			/* ���̍s�ɂ� nChar �����\������B*/
			MyTextOut (hDC, x, y, pText, nChar) ;
			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
			x	+= sz.cx ;

			/* �܂�Ԃ�������\������B*/
			if (nChar < nText) {
				SIZE	szBackslash ;
				MyTextOut (hDC, x, y, MYTEXT ("\\"), 1) ;
				MyGetTextExtentPoint (hDC, MYTEXT ("\\"), 1, &szBackslash) ;
				x	+= szBackslash.cx ;
			}

#define	IsTextRegionCrossp(text1,ntext1,text2,ntext2)	(!((((text1)+(ntext1))<=(text2)||(text1)>=((text2)+(ntext2)))))
			for (nAnnot = 0 ; nAnnot < nPageSize ; nAnnot ++) {
				int	nOffset, nLength ;

				pAnnot	= &bufAnnot [nAnnot] ;
				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32 (hDC, pText, nOffset, &sz) ;
					nAnnotX	= prcDraw->left + sz.cx ;
				} else {
					nAnnotX	= prcDraw->left ;
				}
				GetTextExtentPoint32 (hDC, pText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				if (hULBrush) 
					PatBlt (hDC, nAnnotX, y + nDY - nULHeight, nAnnotWidth, nULHeight, PATCOPY) ;
			}
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
	}

	if (hULBrush) {
		(void) SelectObject (hDC, hOldBrush) ;
		DeleteObject (hULBrush) ;
	}
	if (hbmUL)
		DeleteObject (hbmUL) ;
	return	TRUE ;
}

BOOL	PASCAL
UICand_paintCodeList (
	register HWND				hWnd,
	register HDC				hDC,
	register LPCANDIDATELIST	pCandList,
	register LPRECT				prcDraw)
{
	MYCHAR		szCandKey [3]	= { 0, TEXT (':'), TEXT ('\0') } ;
	const BYTE*	pCandKeyTbl ;

	/*	Key 1 �ɕt�� ``X:'' ��2�����ASeparator �̋󔒂� 1 �����A
	 *	���̕\���� 1 �` 2 �����A
	 *	����āANELEMENTS (pCandidateKey) * (2 + 1 + 1) �܂��� (2 + 1 + 2)
	 *	���������B
	 */
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	MYCHAR	szBuffer [NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 * (2 + 1 + 1)] ;
#else
	MYCHAR	szBuffer [NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 * (2 + 1 + 2)] ;
#endif
	register LPMYSTR	pDest, pSrc ;
	register DWORD		nIndex, iCount, nCandLen ;

	pDest	= szBuffer ;
	nIndex	= pCandList->dwPageStart ;
	if (nIndex >= pCandList->dwCount)
		nIndex	= 0 ;
	pCandKeyTbl	= skkime_GetJInputByCodeOrMenuKeys1 () ;

	DEBUGPRINTFEX (99, (TEXT ("PageStart(%d), Count(%d)\n"), (int)pCandList->dwPageStart, (int) pCandList->dwPageSize)) ;
	iCount	= 0 ;
	while (iCount < pCandList->dwPageSize && iCount < NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) {
		szCandKey [0]	= (MYCHAR)*(pCandKeyTbl + iCount) ;
		iCount	++ ;
		Mylstrcpy (pDest, szCandKey) ;
		pDest		+= 2 ;	/* ����� Unicode/��Unicode ��킸�����B*/
		pSrc		= (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset [nIndex]) ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		nCandLen	= 1 ;
#else
		nCandLen	= 2 ;
#endif
		Mylstrcpy (pDest, pSrc) ;
		pDest		+= nCandLen ;
		*pDest ++	= MYTEXT (' ') ;

		nIndex ++ ;
		if (nIndex >= pCandList->dwCount)
			nIndex	= 0 ;
	}
	MyTextOut (hDC, 0, 0, szBuffer, pDest - szBuffer) ;
	return	TRUE ;
}

BOOL	PASCAL
UICand_paintCode1List (
	register HWND				hWnd,
	register HDC				hDC,
	register LPCANDIDATELIST	pCandList,
	register LPRECT				prcDraw)
{
	MYCHAR	szCandKey [3]	= { 0, TEXT (':'), TEXT ('\0') } ;
	const BYTE*	pCandKeyTbl ;

	/*	Key 1 �ɕt�� ``X:'' ��2�����ASeparator �̋󔒂� 1 �����A
	 *	���̕\���� 1 �` 2 �����A
	 *	����āANELEMENTS (pCandidateKey) * (2 + 1 + 1) �܂��� (2 + 1 + 2)
	 *	���������B
	 */
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	MYCHAR	szBuffer [NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 * (2 + 1 + 1)] ;
#else
	MYCHAR	szBuffer [NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 * (2 + 1 + 2)] ;
#endif
	register LPMYSTR	pDest, pSrc ;
	register DWORD		nIndex, iCount, nCandLen ;

	pDest	= szBuffer ;
	iCount	= 0 ;
	nIndex	= pCandList->dwPageStart ;
	if (nIndex >= pCandList->dwCount)
		nIndex	= 0 ;

	pCandKeyTbl	= skkime_GetJInputByCodeOrMenuKeys2 () ;
	DEBUGPRINTFEX (99, (TEXT ("PageStart(%d), Count(%d)\n"),
						(int)pCandList->dwPageStart, (int) pCandList->dwPageSize)) ;
	while (iCount < pCandList->dwPageSize && iCount < NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) {
		szCandKey [0]	= (MYCHAR) *(pCandKeyTbl + iCount) ;
		iCount	++ ;
		Mylstrcpy (pDest, szCandKey) ;
		pDest		+= 2 ;	/* ����� Unicode/��Unicode ��킸�����B*/
		pSrc		= (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset [nIndex]) ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		nCandLen	= 1 ;
#else
		nCandLen	= 2 ;
#endif
		Mylstrcpy (pDest, pSrc) ;
		pDest		+= nCandLen ;
		*pDest ++	= MYTEXT (' ') ;

		nIndex ++ ;
		if (nIndex >= pCandList->dwCount)
			nIndex	= 0 ;
	}
	MyTextOut (hDC, 0, 0, szBuffer, pDest - szBuffer) ;
	return	TRUE ;
}

int	PASCAL
uiCand_getCandText (
	register LPTSTR				strDest,
	register int				nDest,
	register PTEXTREGION		pText,
	register LPCANDIDATELIST	pCandList)
{
	register LPTSTR	pDest		= strDest ;
	register DWORD	i, iCount ;
	TCHAR		ch ;
	const BYTE*	pCandKeyTbl ;

	iCount		= 0 ;
	i			= pCandList->dwPageStart ;
	pCandKeyTbl	= skkime_GetJHenkanShowCandidateKeys () ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPMYSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		Mylstrncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < (pCandList->dwPageStart + pCandList->dwPageSize) && i < pCandList->dwCount && iCount < NUM_JHENKAN_SHOW_CANDIDATE_KEYS && nDest > 0) {
		LPMYSTR		lpstr ;
		int			nIndex, nCandLen ;

		ch			= (TCHAR)*(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, TEXT (":"), 1) ;

		lpstr		=  (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset[i]) ;
		nCandLen	= Mylstrlen (lpstr) ;
		nIndex		= SKKHasWordAnnotation (lpstr, nCandLen) ;
		if (nIndex > 0) 
			nCandLen	= nIndex ;

		/*	���� annotation �����݂���ꍇ�B*/
		if (pText != NULL) {
			if (nDest > 0 && nIndex > 0) {
				pText->m_nCandidate	= i ;
				pText->m_nOffset	= pDest - strDest ;
				pText->m_nLength	= (nDest < nCandLen)? nDest : nCandLen ;
			} else {
				pText->m_nCandidate	= 0 ;
				pText->m_nOffset	= 0 ;
				pText->m_nLength	= 0 ;
			}
			pText	++ ;
		}
		SAFE_COPY (pDest, nDest, lpstr, nCandLen) ;
		SAFE_COPY (pDest, nDest, TEXT (" "), 1) ;
		iCount	++ ;
		i		++ ;
	}
	if (nDest > 0) {
		MYCHAR	buffer [32] ;
		Mylstrcpy (buffer, MYTEXT (" [�c�� ")) ;
		Myltoa    (buffer + Mylstrlen (buffer), pCandList->dwCount - i) ;
		Mylstrcat (buffer, MYTEXT ("]")) ;
		SAFE_COPY (pDest, nDest, buffer, Mylstrlen (buffer)) ;
	}
	return	(pDest - strDest) ;
}

HWND	PASCAL
UICand_createToolTip (
	register HWND		hWnd)
{
	register HWND			hSvrWnd, hwndTT ;
	register HINSTANCE		hInstance ;

	hSvrWnd			= (HWND)GetWindowLongPtr (hWnd, FIGWL_UICAND_SVRWND) ;
	hInstance		= (HINSTANCE)GetWindowLongPtr (hSvrWnd, GWLP_HINSTANCE) ;

    hwndTT	= CreateWindowEx (WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL, WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP | WS_DISABLED,		
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hWnd, NULL, hInstance, NULL) ;
	if (hwndTT == NULL) 
		return	NULL ;

//    SetWindowPos (hwndTT, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE) ;
	ShowWindow (hwndTT, SW_SHOWNOACTIVATE) ;
	return	hwndTT ;
}


void	PASCAL
UICand_relayEventToTooltip (
	HWND		hWnd,
	UINT		uMessage)
{
	HWND			hwndTT ;
	MSG				msg ;
	POINT			pt ;

	hwndTT	= (HWND) GetWindowLongPtr (hWnd, FIGWL_UICAND_TOOLTIP) ;
	if (! IsWindow (hwndTT) || ! GetCursorPos (&pt))
		return ;

	switch (uMessage) {
		case	WM_SETCURSOR:
			{
				msg.hwnd	= hWnd ;
				msg.message	= WM_MOUSEMOVE ;
				msg.pt.x	= pt.x ;
				msg.pt.y	= pt.y ;
				ScreenToClient (hWnd, &pt) ;
				msg.lParam	= MAKELPARAM (pt.x, pt.y) ;
				msg.wParam	= 0 ;
				msg.time	= GetTickCount () ;
				(void) SendMessage (hwndTT, (UINT) TTM_RELAYEVENT, (WPARAM) 0, (LPARAM) &msg) ;
				break ;
			}
		default:
			break ;
	}
	return ;
}

BOOL	PASCAL
UICand_configureToolTip (
	register HWND				hWnd,
	register LPINPUTCONTEXT		lpIMC)
{
	register HWND			hSvrWnd, hwndTT ;
	register HINSTANCE		hInstance ;
	LPCANDIDATEINFO			pCandInfo	= NULL ;
	LPCANDIDATELIST			pCandList	= NULL ;
	HFONT					hOldFont	= NULL ;
	HDC						hDC			= NULL ;
	RECT					rcDraw ;
	int						nPageSize, nText, nTools ;
	SIZE					sz ;
	TCHAR					bufText [1024] ;
	TEXTREGION				bufAnnot [32] ;
	PTEXTREGION				pbufAnnot ;
	UINT_PTR				uid ;
	TOOLINFO				ti ;

	if (lpIMC == NULL || ! IsWindow (hWnd))
		return	FALSE ;

	hSvrWnd		= (HWND)GetWindowLongPtr (hWnd, FIGWL_UICAND_SVRWND) ;
	hInstance	= (HINSTANCE)GetWindowLongPtr (hSvrWnd, GWLP_HINSTANCE) ;

	hDC			= GetDC (hWnd) ;
	if (!hDC)
		return	FALSE ;

	pCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (pCandInfo == NULL)
		goto	exit_func_1 ;

	hOldFont	= CheckNativeCharset (hDC) ;
	GetClientRect (hWnd, &rcDraw) ;
	pCandList	= (LPCANDIDATELIST)((LPSTR)pCandInfo  + pCandInfo->dwOffset[0]) ;

	hwndTT		= (HWND) GetWindowLongPtr (hWnd, FIGWL_UICAND_TOOLTIP) ;
	if (hwndTT != NULL && IsWindow (hwndTT)) {
		DestroyWindow (hwndTT) ;
	}
	hwndTT	= UICand_createToolTip (hWnd) ;
	SetWindowLongPtr (hWnd, FIGWL_UICAND_TOOLTIP, (LONG_PTR) hwndTT) ;
	if (hwndTT == NULL || ! IsWindow (hwndTT)) 
		goto	exit_func_1 ;

	/*	�܂��S�Ă� TOOL ���폜����B*/
	ti.cbSize		= sizeof (TOOLINFO) ;
	ti.uFlags		= 0 ;
	ti.hwnd			= hWnd ;
	ti.hinst		= hInstance ;
	nTools			= SendMessage(hwndTT, TTM_GETTOOLCOUNT, (WPARAM)0, (LPARAM)0) ;	
	for (uid = 0 ; uid < (UINT) nTools ; uid ++) {
		ti.uId			= uid ;
		SendMessage(hwndTT, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti) ;	
	}

	/*	TOOL ��ǉ�����B*/
	pbufAnnot	= (pCandList->dwPageSize >= NELEMENTS (bufAnnot))? NULL : bufAnnot ;
	nPageSize	= (pbufAnnot == NULL)? 0 : pCandList->dwPageSize ;
	memset (bufAnnot, 0, sizeof (bufAnnot)) ;
	nText		= uiCand_getCandText (bufText, NELEMENTS (bufText), pbufAnnot, pCandList) ;
	if (nText > 0) {
		int			nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPTSTR		pText ;
		PTEXTREGION	pAnnot ;
		TEXTMETRIC	tm ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= rcDraw.top ;
		pText		= bufText ;
		nTextPos	= 0 ;
		uid			= 0 ;

		while (y < rcDraw.bottom && 0 < nText) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= rcDraw.left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32 (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) > rcDraw.right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;

			/* ���̍s�� hit ����BTEXTREGION �𗘗p����B*/
			for (nAnnot = 0 ; nAnnot < nPageSize ; nAnnot ++) {
				LPMYSTR		lpstr ;
				int			nOffset, nLength, nIndex, nCandLen ;

				pAnnot	= &bufAnnot [nAnnot] ;
				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32 (hDC, pText, nOffset, &sz) ;
					nAnnotX	= rcDraw.left + sz.cx ;
				} else {
					nAnnotX	= rcDraw.left ;
				}
				GetTextExtentPoint32 (hDC, pText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				/* �O�̂��߂Ɍ�₪���݂��邩�`�F�b�N����B*/
				if (pAnnot->m_nCandidate >= pCandList->dwCount)
					continue ;

				lpstr		=  (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset[pAnnot->m_nCandidate]) ;
				nCandLen	= Mylstrlen (lpstr) ;
				nIndex		= SKKHasWordAnnotation (lpstr, nCandLen) ;
				if (nIndex <= 0 || (nIndex + 1) >= nCandLen) {
					/* �����ρB*/
					continue ;
				}

				ti.cbSize		= sizeof (TOOLINFO) ;
				ti.uFlags		= 0 ;
				ti.hwnd			= hWnd ;
				ti.hinst		= hInstance ;
				ti.uId			= uid ;
				ti.lpszText		= lpstr + nIndex + 1 ;
				ti.rect.left	= nAnnotX ;
				ti.rect.top		= y ;
				ti.rect.right	= nAnnotX + nAnnotWidth ;
				ti.rect.bottom	= y + nDY ;
#if defined (DBG)
				if (! SendMessage(hwndTT, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti)) {
					DWORD	dw	= GetLastError () ;
					DebugPrintf (TEXT ("SendMessage(hwndTT, TTM_ADDTOOL) failed (0x%x/%d).\n"), dw, dw) ;
				}
#else
				SendMessage(hwndTT, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti) ;
#endif
				uid	++ ;
			}
			x			+= sz.cx ;
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
	}

exit_func_1:
	if (pCandInfo != NULL)
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
	if (hDC != NULL) {
		if (hOldFont) 
			DeleteObject (SelectObject (hDC, hOldFont)) ;
		ReleaseDC (hWnd, hDC) ;
	}
	return	TRUE ;
}

