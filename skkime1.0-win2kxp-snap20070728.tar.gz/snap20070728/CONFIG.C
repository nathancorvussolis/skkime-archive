/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "shlwapi.h"
#include "stddef.h"
#include "skki1_0.h"
#include "resource.h"
#include "tmalloc.h"
#include "common\confcommon.h"
#include "common\confdefaults.h"

/*========================================================================
 *	Prototypes
 */
#if !defined (NO_TOUCH_REGISTRY)
static	void	skkime_updateGenericConfig (void) ;
static	void	skkime_updateCandidateKeys (void) ;
static	void	skkime_updateColorFace (void) ;
static	BOOL	skkime_initializeGenericConfig (TINYMEMMGR*, MYGENERICCONFIG*) ;
static	BOOL	skkime_initializeCandidateSelectKeyConfig (TINYMEMMGR*, MYCANDSELKEY*) ;
static	BOOL	skkime_initializeColorConfig (TINYMEMMGR*, MYCOLORFACESET*) ;
static	BOOL	regQueryDword (HKEY, LPCTSTR, DWORD*) ;
#endif

/*========================================================================
 *	static global variables ;
 */
static	BOOL	fSkkImeGenericConfigInitialized	= FALSE ;
static	BOOL	fSkkImeCandidateKeyInitialized	= FALSE ;
static	BOOL	fSkkImeColorFaceInitialized		= FALSE ;

static	BOOL	fSkkImeShowAnnotation ;
static	BOOL	fSkkImeHideToolbar ;
static	BOOL	fSkkImeAlwaysOpenKanaMode ;
static	MYCOLORFACESET	srSkkImeColorFaceSet [MAX_SKKIME_COLORFACE] ;
static	BYTE	rbySkkImeJHenkanShowCandidateKeys [NUM_JHENKAN_SHOW_CANDIDATE_KEYS] ;
static	BYTE	rbySkkImeJInputByCodeOrMenuKeys1 [NUM_JINPUT_BY_CODE_OR_MENU_KEYS1] ;
static	BYTE	rbySkkImeJInputByCodeOrMenuKeys2 [NUM_JINPUT_BY_CODE_OR_MENU_KEYS2] ;

#if !defined (NO_TOUCH_REGISTRY)
/*	���W�X�g����G��Ȃ��悤�ɂ���e�X�g�Ɏg�� default �̐ݒ�B
 *	UserEnv ���̃`�F�b�N�B���ASun Jul 20 01:09:53 2003 ��
 *	�e�X�g�������ʁAIE ���N��������� MSIME �ł���������c�B
 *	�����茳�̊��ɂ܂����Ƃ��낪����炵���B
 *	���ꂢ�ȃe�X�g����p�ӂ���K�v������悤���B
 */
static	BYTE	srDefaultJHenkanShowCandidateKeys []	= {
	'a', 's', 'd', 'f', 'j', 'k', 'l'
} ;
static	BYTE	srDefaultJInputByCodeOrMenuKeys1 []		= {
	'a', 's', 'd', 'f', 'g', 'h', 'q', 'w', 'e', 'r', 't', 'y'
} ;
static	BYTE	srDefaultJInputByCodeOrMenuKeys2 []		= {
	'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'q', 'w', 'e', 'r', 't', 'y', 'u'
} ;
#endif

extern	const DEFGENERICSETTING		srSkkimeConfigDefGenericTbl [] ;
extern	const MYCOLORFACESET		srSkkImeDefaultColorFace	[] ;

/*************************************************************************
 *	ImeConfigure
 *		ImeConfigure �֐��� IME �ɑ΂��ĕ⑫�I�ȏ���v�����邽�߂Ɏg��
 *		Dialog Box ��񋟂���H
 *	BOOL
 *		ImeConfigure(
 *		HKL hKL,
 *		HWND hWnd,
 *		DWORD dwMode,
 *		LPVOID lpData
 *		)
 *	Parameters
 *		hKL
 *			���� IME �̓��͌���̃n���h���B
 *		hWnd
 *			�e Window �̃n���h���B
 *		dwMode
 *			Dialog �̃��[�h�B�ȉ��̂悤�ȃt���O���^������B
 *			IME_CONFIG_GENERAL			��� configuration �̂��߂� Dialog
 *			IME_CONFIG_REGWORD			�P��o�^�̂��߂� Dialog
 *			IME_CONFIG_SELECTDICTIONARY	IME �����I���̂��߂� Dialog
 *		lpData
 *			VOID �^�̃|�C���^�B���� dwMode == IME_CONFIG_REGISTERWORD �Ȃ�A
 *			REGISTERWORD �\���̂ւ̃|�C���^�ƂȂ�B�����Ȃ��Ζ��������B
 *			initial string ���^�����Ȃ�������AIME_CONFIG_REGISTER ���[�h
 *			�ł����Ă��ANULL �ł����Ă��܂�Ȃ��B
 *		Return Values
 *			���̊֐�������������ATRUE�B�����Ȃ��� FALSE�B
 *	Comments
 *		IME �͎��̂悤�ȋ[���R�[�h�ł����� lpData ���`�F�b�N����B
 *
 *	if (dwmode != IME_CONFIG_REGISTERWORD){
 *		// Does original execution
 *	} else if (IsBadReadPtr(lpdata, sizeof(REGISTERWORD))==FALSE){
 *		if (IsBadStringPtr(PREGISTERWORD(lpdata)->lpReading, (UINT)-1)==FALSE){
 *			// Set the reading string to word registering dialogbox
 *		}
 *		if (IsBadStringPtr(PREGISTERWORD(lpdata)->lpWord, (UINT)-1)==FALSE){
 *			// Set the word string to word registering dialogbox
 *		}
 *	}
 *************************************************************************/
BOOL	WINAPI
ImeConfigure (HKL hKL, HWND hWnd, DWORD dwMode, LPVOID lpData)
{
	WCHAR					rszWindowsDir [MAX_PATH + 1] ;
	WCHAR					rszCmd [MAX_PATH + 1] ;
    STARTUPINFOW			si ;
    PROCESS_INFORMATION		pi ;
	int						nWindowsDir, n ;
	BOOL					fRetval ;

	/*	Secure Session �Ȃ�� Config �͎��s���Ă͂Ȃ�Ȃ��B*/
	if (g_bSkkImeSecure)
		return	FALSE ;

	if (dwMode != IME_CONFIG_REGISTERWORD) {
		nWindowsDir	= GetWindowsDirectoryW (rszWindowsDir, NELEMENTS (rszWindowsDir) - 1) ;
		rszWindowsDir [nWindowsDir]		= L'\0' ;
		n			= wnsprintf (rszCmd, NELEMENTS (rszCmd) - 1, L"%s" L"\\" PROGRAMF_DIR L"\\" SKKIMEProg_S_DIR L"\\" SKKIMEConfigProg, rszWindowsDir) ;
		rszCmd [n]	= L'\0' ;

		ZeroMemory (&si, sizeof(si)) ;
		si.cb	= sizeof (si) ;
		if (! CreateProcessW (rszCmd, L"", NULL, NULL, FALSE, 0, NULL, rszWindowsDir, &si, &pi)) {
			fRetval	= FALSE ;
		} else {
			/* �҂��Ȃ��B(void) WaitForSingleObject (pi.hProcess, INFINITE) ;*/
			/* �s�v�ɂȂ����n���h��������B*/
			CloseHandle (pi.hProcess) ;
			CloseHandle (pi.hThread) ;
			fRetval	= TRUE ;
		}
	} else {
		/* �P��o�^�̃_�C�A���O����������Ăяo����悤�ɂ��Ȃ���΁c�B*/
		fRetval	= FALSE ;
	}
	return	fRetval ;
}

/*========================================================================*
 */
void	PASCAL
skkime_InvalidateConfig (
	register HIMC	hIMC,
	register BOOL	fDocUpdate)
{
	register LPINPUTCONTEXT		lpIMC ;
	register LPMYCOMPSTR		lpMyCompStr ;
	register TINYMEMMGR*		pMemMgr ;
	MYGENERICCONFIG				gconf ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL)
		return ;
	if (ImmGetIMCCSize (lpIMC->hCompStr) >= sizeof (MYCOMPSTR) && fDocUpdate) {
		lpMyCompStr		= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr != NULL) {
			ImeDoc_UpdateConfig (&lpMyCompStr->_Doc) ;
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
	}
	fSkkImeGenericConfigInitialized	= FALSE ;
	fSkkImeCandidateKeyInitialized	= FALSE ;
	fSkkImeColorFaceInitialized		= FALSE ;
	ImmUnlockIMC (hIMC) ;
	return ;
}

BOOL
skkime_IsShowAnnotation (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	if (! fSkkImeGenericConfigInitialized) 
		skkime_updateGenericConfig () ;
	return	fSkkImeShowAnnotation ;
#else
	return	FALSE ;
#endif
}

BOOL
skkime_IsAlwaysOpenKanaMode (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	if (! fSkkImeGenericConfigInitialized) 
		skkime_updateGenericConfig () ;
	return	fSkkImeAlwaysOpenKanaMode ;
#else
	return	TRUE ;
#endif
}

BOOL
skkime_IsEnableGameMode (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	register BOOL	fEnableGameMode	= FALSE ;
	DWORD			dwValue ;
	
	if (GetRegDwordValue (NULL, TEXT(REGKEY_ENABLEGAMEMODE), &dwValue)) 
		fEnableGameMode	= (BOOL) dwValue ;
	return	fEnableGameMode ;
#else
	return	FALSE ;
#endif
}

BOOL
skkime_IsHideToolbar (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	DWORD	dwValue	;
#if !defined (NO_TSF)
	if (bTSF_IsTSFEnabled ()) 
		return	TRUE ;
#endif
	if (GetRegDwordValue (TEXT ("\\Window"), TEXT(REGKEY_HIDETOOLBAR), &dwValue))
		return	(dwValue != 0) ;
	return	FALSE ;
#else
	return	TRUE ;
#endif
}

const BYTE*
skkime_GetJHenkanShowCandidateKeys (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	if (! fSkkImeCandidateKeyInitialized) 
		skkime_updateCandidateKeys () ;
	return	rbySkkImeJHenkanShowCandidateKeys ;
#else
	return	srDefaultJHenkanShowCandidateKeys ;
#endif
}

const BYTE*
skkime_GetJInputByCodeOrMenuKeys1 (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	if (! fSkkImeCandidateKeyInitialized) 
		skkime_updateCandidateKeys () ;
	return	rbySkkImeJInputByCodeOrMenuKeys1 ;
#else
	return	srDefaultJInputByCodeOrMenuKeys1 ;
#endif
}

const BYTE*
skkime_GetJInputByCodeOrMenuKeys2 (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	if (! fSkkImeCandidateKeyInitialized) 
		skkime_updateCandidateKeys () ;
	return	rbySkkImeJInputByCodeOrMenuKeys2 ;
#else
	return	srDefaultJInputByCodeOrMenuKeys2 ;
#endif
}

const MYCOLORFACESET*
skkime_GetColorFaceSet (void)
{
#if !defined (NO_TOUCH_REGISTRY)
	if (! fSkkImeColorFaceInitialized) 
		skkime_updateColorFace () ;
	return	srSkkImeColorFaceSet ;
#else
	return	srSkkImeDefaultColorFace ;
#endif
}

/*========================================================================*
 */
#if !defined (NO_TOUCH_REGISTRY)
void
skkime_updateGenericConfig (void)
{
	TINYMEMMGR			memMgr ;
	void*				pvHeapArea ;
	MYGENERICCONFIG		gconf ;

	pvHeapArea	= HeapAlloc (GetProcessHeap (), 0, SKKIME_SHAREMEMSIZE) ;
	if (pvHeapArea == NULL)
		return ;
	TinyMalloc_Initialize (&memMgr, pvHeapArea, SKKIME_SHAREMEMSIZE) ;
	skkime_initializeGenericConfig	(&memMgr, &gconf) ;
	fSkkImeShowAnnotation		= (gconf.m_nShowAnnotation != 0) ;
	fSkkImeAlwaysOpenKanaMode	= (gconf.m_nAlwaysOpenKanaMode != 0) ;
	TinyMalloc_Uninitialize (&memMgr) ;
	HeapFree (GetProcessHeap (), 0, pvHeapArea) ;
	fSkkImeGenericConfigInitialized	= TRUE ;
	return ;
}

void
skkime_updateCandidateKeys (void)
{
	TINYMEMMGR		memMgr ;
	void*			pvHeapArea ;
	MYCANDSELKEY	candsel ;

	pvHeapArea	= HeapAlloc (GetProcessHeap (), 0, SKKIME_SHAREMEMSIZE) ;
	if (pvHeapArea == NULL)
		return ;
	TinyMalloc_Initialize (&memMgr, pvHeapArea, SKKIME_SHAREMEMSIZE) ;
	skkime_initializeCandidateSelectKeyConfig	(&memMgr, &candsel) ;
	memcpy (rbySkkImeJHenkanShowCandidateKeys, candsel._JHenkanShowCandidateKeys, NUM_JHENKAN_SHOW_CANDIDATE_KEYS) ;
	memcpy (rbySkkImeJInputByCodeOrMenuKeys1, candsel._JInputByCodeOrMenuKeys1, NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) ;
	memcpy (rbySkkImeJInputByCodeOrMenuKeys2, candsel._JInputByCodeOrMenuKeys2, NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) ;
	TinyMalloc_Uninitialize (&memMgr) ;
	HeapFree (GetProcessHeap (), 0, pvHeapArea) ;
	fSkkImeCandidateKeyInitialized	= TRUE ;
	return ;
}

void
skkime_updateColorFace (void)
{
	TINYMEMMGR		memMgr ;
	void*			pvHeapArea ;

	pvHeapArea	= HeapAlloc (GetProcessHeap (), 0, SKKIME_SHAREMEMSIZE) ;
	if (pvHeapArea == NULL)
		return ;
	TinyMalloc_Initialize (&memMgr, pvHeapArea, SKKIME_SHAREMEMSIZE) ;
	skkime_initializeColorConfig (&memMgr, srSkkImeColorFaceSet) ;
	TinyMalloc_Uninitialize (&memMgr) ;
	HeapFree (GetProcessHeap (), 0, pvHeapArea) ;
	fSkkImeColorFaceInitialized	= TRUE ;
	return ;
}

BOOL
skkime_initializeGenericConfig (
	TINYMEMMGR*			pMemMgr,
	MYGENERICCONFIG*	pArg)
{
	LPBYTE				lpTop	= (LPBYTE)pArg ;
	HKEY				hSubKey ;
	int		i ;

	if (pMemMgr == NULL || pArg == NULL)
		return	FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwValue ;

		for (i = 0 ; i < NELEMENTS (g_rDefintionOfGenericConfig) ; i ++) {
			if (! regQueryDword (hSubKey, g_rDefintionOfGenericConfig [i].m_strPath, &dwValue)) {
				dwValue	= g_rDefintionOfGenericConfig [i].m_nDefault ;
			}
			*((int *)(lpTop + g_rDefintionOfGenericConfig [i].m_nOffset))	= (int) dwValue ;
		}
		RegCloseKey (hSubKey) ;
	} else {
		for (i = 0 ; i < NELEMENTS (g_rDefintionOfGenericConfig) ; i ++) 
			*((int *)(lpTop + g_rDefintionOfGenericConfig [i].m_nOffset))	= g_rDefintionOfGenericConfig [i].m_nDefault ;
	}
	return	TRUE ;

	UNREFERENCED_PARAMETER (pMemMgr) ;
}


BOOL
skkime_initializeCandidateSelectKeyConfig (
	TINYMEMMGR*			pMemMgr,
	MYCANDSELKEY*		pArg)
{
	HKEY	hSubKey ;
	BOOL	fInitJHenkanShowCandidateKeys	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys1	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys2	= FALSE ;
	DWORD	dwType, cbData ;

	if (pMemMgr == NULL || pArg == NULL)
		return	FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JHENKAN_SHOW_CANDIDATE_KEYS) {
			cbData	= NUM_JHENKAN_SHOW_CANDIDATE_KEYS ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, pArg->_JHenkanShowCandidateKeys, &cbData) ;
			fInitJHenkanShowCandidateKeys	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, pArg->_JInputByCodeOrMenuKeys1, &cbData) ;
			fInitJInputByCodeOrMenuKeys1	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, pArg->_JInputByCodeOrMenuKeys2, &cbData) ;
			fInitJInputByCodeOrMenuKeys2	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! fInitJHenkanShowCandidateKeys)
		memcpy (pArg->_JHenkanShowCandidateKeys, srDefaultJHenkanShowCandidateKeys, NUM_JHENKAN_SHOW_CANDIDATE_KEYS) ;
	if (! fInitJInputByCodeOrMenuKeys1)
		memcpy (pArg->_JInputByCodeOrMenuKeys1, srDefaultJInputByCodeOrMenuKeys1, NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) ;
	if (! fInitJInputByCodeOrMenuKeys2)
		memcpy (pArg->_JInputByCodeOrMenuKeys2, srDefaultJInputByCodeOrMenuKeys2, NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) ;
	return	TRUE ;

	UNREFERENCED_PARAMETER (pMemMgr) ;
}

BOOL
skkime_initializeColorConfig (
	TINYMEMMGR*		pMemMgr,
	MYCOLORFACESET*	pColorFaceSet)
{
	HKEY			hSubKey ;
	BYTE			rbyStyle [MAX_SKKIME_COLORFACE * 4] ;
	BOOL	fInitialized	= FALSE ;

	if (pMemMgr == NULL || pColorFaceSet == NULL)
		return	FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_COLORFACE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;
		
		/*	j-map ���̏����B*/
		cbData	= sizeof (rbyStyle) ;
		if (RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, rbyStyle, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == sizeof (rbyStyle)) {
			const MYCOLORFACESET*	pDefault	= g_rDefinitionOfDefaultColorFace ;
			MYCOLORFACESET*			pColor		= pColorFaceSet ;
			LPBYTE					pByte		= rbyStyle ;
			int						i ;

			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < MAX_SKKIME_COLORFACE ; i ++) {
				pColor->m_nTextColor		= IsValidColor		(*pByte)? *pByte : pDefault->m_nTextColor ;			pByte	++ ;
				pColor->m_nBackColor		= IsValidColor		(*pByte)? *pByte : pDefault->m_nBackColor ;			pByte	++ ;
				pColor->m_nUnderLineColor	= IsValidColor		(*pByte)? *pByte : pDefault->m_nUnderLineColor ;	pByte	++ ;
				pColor->m_nUnderLineType	= IsValidLineType	(*pByte)? *pByte : pDefault->m_nUnderLineType ;		pByte	++ ;
				pColor		++ ;
				pDefault	++ ;
			}
			fInitialized	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! fInitialized)
		memcpy (pColorFaceSet, g_rDefinitionOfDefaultColorFace, sizeof (MYCOLORFACESET) * NELEMENTS (g_rDefinitionOfDefaultColorFace)) ;
	return	TRUE ;
}

BOOL
regQueryDword (
	HKEY		hSubKey,
	LPCTSTR		strPath,
	DWORD*		pdwRetval)
{
	register LONG	lResult ;
	DWORD	dwType, dwValue, cbData ;

	cbData	= sizeof (dwValue) ;
	lResult	= RegQueryValueEx (hSubKey, strPath, NULL, &dwType, (LPBYTE)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		return	FALSE ;

	*pdwRetval	= dwValue ;
	return	TRUE ;
}

#endif

