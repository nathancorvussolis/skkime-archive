#if !defined (TAssocRuleP_h)
#define	TAssocRuleP_h

#include "TAssocRule.h"

struct tagCTAssocRule {
	LPWSTR		_wstrState ;
	LPWSTR		_wstrNext ;
	LPWSTR		_wstrKatakana ;
	LPWSTR		_wstrHiragana ;
} ;

#endif

