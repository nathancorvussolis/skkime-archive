#if !defined (TAssocRule_h)
#define	TAssocRule_h

struct tagCTAssocRule ;
typedef struct tagCTAssocRule	CTAssocRule ;

CTAssocRule*	TAssocRule_Create	(LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR) ;
void			TAssocRule_Destroy	(CTAssocRule*) ;
LPCWSTR			TAssocRule_GetState (CTAssocRule*) ;
LPCWSTR			TAssocRule_GetNext	(CTAssocRule*) ;
LPCWSTR			TAssocRule_GetOutput(CTAssocRule*, BOOL) ;

#endif

