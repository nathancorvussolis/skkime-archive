#if ! defined (ImeBufferP_h)
#define	ImeBufferP_h

#include "ImeBuffer.h"

enum {
	MARKER_POINT	= 0,
	MARKER_EDIT_TOP,
	MARKER_MARK,
	MARKER_J_KANA_STARTPOINT,
	MARKER_J_HENKAN_STARTPOINT,
	MARKER_J_HENKAN_ENDPOINT,
	MARKER_J_OKURIGANA_STARTPOINT,
	MARKER_J_READING_STARTPOINT,
	MARKER_J_READING_ENDPOINT,
	MAX_RESERVED_MARKERS
} ;

struct tagCImeDoc ;
struct tagCTHenkanSession ;

struct tagCImeBuffer {
	struct tagCImeDoc*	_pDoc ;

	WCHAR		_bufComp [MAXCOMPLEN] ;
	int			_nbufComp ;
	WCHAR		_bufJPrefix [MAXPREFIXLEN] ;
	int			_nbufJPrefix ;
	WCHAR		_bufJHenkanKey [MAXPREFIXLEN] ;
	int			_nbufJHenkanKey ;
	WCHAR		_bufJHenkanKey2 [MAXPREFIXLEN] ;
	int			_nbufJHenkanKey2 ;
	WCHAR		_bufJSearchKey [MAXPREFIXLEN] ;
	int			_nbufJSearchKey ;
	WCHAR		_bufJHenkanOkurigana [MAXPREFIXLEN] ;
	int			_nbufJHenkanOkurigana ;
	WCHAR		_bufJNumList [MAXPREFIXLEN] ;
	int			_nbufJNumList ;
	/*	�ꎞ�I�ɕϊ����ʂ�ۑ�����̂ɗp������o�b�t�@�B*/
	WCHAR		_bufJHenkanResult [MAXPREFIXLEN] ;
	int			_nbufJHenkanResult ;

	/*	�ϊ����ʂ̓ǂ݉�����ۊǂ��Ă����o�b�t�@�B
	 *---
	 *	�ҏW���̃e�L�X�g�̓��A_pmkJReadingStartPoint �� 
	 *	_pmkJReadingEndPoint �ɋ��܂�镔���� 
	 *	_bufJReadingText �ɒu���������āA���ꂪ���ʂ̓ǂ�
	 *	�����ƂȂ�B*/
	WCHAR		_bufJReadingText [MAXPREFIXLEN] ;
	int			_nbufJReadingText ;

	BOOL		_fJMode ;
	BOOL		_fJisx0201 ;
	BOOL		_fJKatakana ;
	BOOL		_fJZenkaku ;
	BOOL		_fJOkurigana ;
	BOOL		_fJHenkanActive ;
	BOOL		_fJHenkanOn ;
	BOOL		_fJAbbrev ;
	int			_nJHenkanCount ;
	int			_nJOkuriIndexMin ;
	int			_nJOkuriIndexMax ;
	int			_nJOkuriAri ;
	WCHAR		_wchOkuriChar ;

	int			_nJInputCode1 ;
	int			_nJInputCode2 ;
	int			_nJInputByCodeOrMenuJumpDefault ;

	CTMarker*	_pmkPoint ;
	CTMarker*	_pmkEditTop ;
	CTMarker*	_pmkMark ;
	CTMarker*	_pmkJKanaStartPoint ;
	CTMarker*	_pmkJHenkanStartPoint ;
	CTMarker*	_pmkJHenkanEndPoint ;
	CTMarker*	_pmkJOkuriganaStartPoint ;
	CTMarker*	_pmkRegionStart ;
	CTMarker*	_pmkRegionEnd ;
	CTMarker*	_pmkJReadingStartPoint ;	/* ��̓ǂ݉����o�b�t�@�ƑΉ��B*/
	CTMarker*	_pmkJReadingEndPoint ;		/* ��̓ǂ݉����o�b�t�@�ƑΉ��B*/
	CTMarker	_rMarker [MAXBUFMARKER] ;
	int			_nMarker ;

	struct tagCTHenkanSession*	_pHenkanSession ;
	CTRecursiveEditSession*		_pRecursiveEditSession ;
	CTRecursiveEditSession		_RecursiveEditSession ;

	BOOL		(*_pFilterProc)(struct tagCImeBuffer*) ;
} ;

#endif

