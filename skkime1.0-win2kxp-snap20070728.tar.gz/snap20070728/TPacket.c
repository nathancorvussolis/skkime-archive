#include "local.h"
#include "common\TProtocol.h"
#include "TPacket.h"

/*	4�o�C�g���E�ɑ�����B*/
#define	PACKET_ALIGN	(4)
#define	PADNUM(x)		((PACKET_ALIGN - ((x) & (PACKET_ALIGN - 1))) & (PACKET_ALIGN - 1))

void
TPacket_Initialize (
	register CTPacket*		pPacket)
{
	pPacket->m_nUsage			= 0 ;
	return ;
}

BOOL
TPacket_SetHeader (
	register CTPacket*		pPacket,
	register int			nMajor,
	register int			nMinor)
{
	pPacket->m_rbyBuffer [0]	= (BYTE) nMajor ;
	pPacket->m_rbyBuffer [1]	= (BYTE) nMinor ;
	pPacket->m_rbyBuffer [2]	= 0 ;
	pPacket->m_rbyBuffer [3]	= 0 ;
	pPacket->m_nUsage			= 4 ;
	return	TRUE ;
}

BOOL
TPacket_AddPad (
	register CTPacket*		pPacket)
{
	register int	nPad ;

	nPad	= PADNUM(pPacket->m_nUsage) ;
	if ((pPacket->m_nUsage + nPad) > PACKETBUFSIZE)
		return	FALSE ;

	pPacket->m_nUsage	+= nPad ;
	return	TRUE ;
}

BOOL
TPacket_AddCard32 (
	register CTPacket*		pPacket,
	register DWORD			dwDATA)
{
	BYTE	rbyCH [4] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= (BYTE)(dwDATA >>  0) ;
	rbyCH [1]	= (BYTE)(dwDATA >>  8) ;
	rbyCH [2]	= (BYTE)(dwDATA >> 16) ;
	rbyCH [3]	= (BYTE)(dwDATA >> 24) ;
	return	TPacket_AddByte (pPacket, rbyCH, 4) ;
}

BOOL
TPacket_AddCard16 (
	register CTPacket*		pPacket,
	register WORD			woDATA)
{
	BYTE	rbyCH [2] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= (BYTE)(woDATA >>  0) ;
	rbyCH [1]	= (BYTE)(woDATA >>  8) ;
	return	TPacket_AddByte (pPacket, rbyCH, 2) ;
}

BOOL
TPacket_AddCard8 (
	register CTPacket*		pPacket,
	register BYTE			byDATA)
{
	BYTE	rbyCH [1] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= byDATA ;
	return	TPacket_AddByte (pPacket, rbyCH, 1) ;
}

BOOL
TPacket_SetLength (
	register CTPacket*		pPacket)
{
	register BYTE*	ptr ;
	register int	nPacket ;

	nPacket	= pPacket->m_nUsage ;
	if (nPacket < SKKISERV_PROTO_HEADER_SIZE ||
		nPacket > PACKETBUFSIZE)
		return	FALSE ;

	ptr		= pPacket->m_rbyBuffer + 2 ;
	*ptr ++	= (BYTE)(nPacket >> 0) ;
	*ptr ++	= (BYTE)(nPacket >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_SetCard16 (
	register CTPacket*		pPacket,
	register int			nPos,
	register WORD			dwVALUE)
{
	register BYTE*	ptr ;

	if (nPos < 0 || nPos >= pPacket->m_nUsage)
		return	FALSE ;

	ptr		= pPacket->m_rbyBuffer + nPos ;
	*ptr ++	= (BYTE)(dwVALUE >> 0) ;
	*ptr ++	= (BYTE)(dwVALUE >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_GetCard16 (
	register CTPacket*		pPacket,
	register int			nPosition,
	register WORD*			pwResult)
{
	register WORD	wValue ;

	if (nPosition < 0 || nPosition >= pPacket->m_nUsage)
		return	FALSE ;

	wValue	=  (WORD)pPacket->m_rbyBuffer [nPosition + 0] ;
	wValue	|= ((WORD)pPacket->m_rbyBuffer [nPosition + 1] << 8) ;
	*pwResult	= wValue ;
	return	TRUE ;
}

BOOL
TPacket_AddString (
	register CTPacket*		pPacket,
	register LPCWSTR		pString,
	register int			nString)
{
	register int	nPos, nPad, nStringByteLen, nResultLength ;

	nPos			= pPacket->m_nUsage ;
	nStringByteLen	= nString * sizeof (WCHAR) ;
	nPad			= PADNUM(nPos + 2 + nStringByteLen) ;
	nResultLength	= nPos + 2 + nStringByteLen + nPad ;
	if (nResultLength > PACKETBUFSIZE)
		return	FALSE ;

	if (nString > 0)
		memcpy (&pPacket->m_rbyBuffer [nPos + 2], pString, nStringByteLen) ;

	pPacket->m_nUsage	= nResultLength ;
	TPacket_SetCard16 (pPacket, nPos, (WORD)nString) ;
	return	TRUE ;
}

BOOL
TPacket_AddByte (
	register CTPacket*		pPacket,
	register LPBYTE			pData,
	register int			nData)
{
	if ((pPacket->m_nUsage + nData) > PACKETBUFSIZE)
		return	FALSE ;
	memcpy (pPacket->m_rbyBuffer + pPacket->m_nUsage, pData, nData) ;
	pPacket->m_nUsage	+= nData ;
	return	TRUE ;
}

BOOL
TPacket_Send (
	register HANDLE			hPipe,
	register CTPacket*		pPacket)
{
	register LPBYTE		ptr ;
	register int		nptr ;

	ptr		= pPacket->m_rbyBuffer ;
	nptr	= pPacket->m_nUsage ;
	while (nptr > 0) {
		DWORD	dwWrite ;
		if (!WriteFile (hPipe, ptr, nptr, &dwWrite, NULL)) 
			return	FALSE ;
		ptr		+= dwWrite ;
		nptr	-= dwWrite ;
	}
	FlushFileBuffers (hPipe) ; 
	return	TRUE ;
}

BOOL
TPacket_GetHeader (
	register CTPacket*		pPacket,
	register int*			pnMajor,
	register int*			pnMinor,
	register int*			pnSize)
{
	if (pPacket->m_nUsage < SKKISERV_PROTO_HEADER_SIZE)
		return	FALSE ;

	if (pnMajor != NULL)
		*pnMajor	= pPacket->m_rbyBuffer [0] ;

	if (pnMinor != NULL)
		*pnMinor	= pPacket->m_rbyBuffer [1] ;

	if (pnSize != NULL) {
		register WORD	wSize ;
		wSize		= pPacket->m_rbyBuffer [3] ;
		wSize		= (WORD)((wSize << 8) | (WORD)pPacket->m_rbyBuffer [2]) ;
		*pnSize		= (int) wSize ;
	}
	return	TRUE ;
}

BOOL
TPacket_Recv (
	register HANDLE			hPipe,
	register CTPacket*		pPacket)
{
	DWORD	dwRead ;

	if (! ReadFile (hPipe, pPacket->m_rbyBuffer, PACKETBUFSIZE, &dwRead, NULL)) 
		return	FALSE ;
	pPacket->m_nUsage	= dwRead ;
	return	TRUE ;
}

BYTE*
TPacket_GetData (
	register CTPacket*		pPacket)
{
	ASSERT (pPacket != NULL) ;
	return	pPacket->m_rbyBuffer ;
}

int
TPacket_GetSize (
	register CTPacket*		pPacket)
{
	ASSERT (pPacket != NULL) ;
	return	pPacket->m_nUsage ;
}

void
TPacket_SetSize (
	register CTPacket*		pPacket,
	register int			nSize)
{
	ASSERT (pPacket != NULL) ;
	pPacket->m_nUsage	= nSize ;
	return ;
}




