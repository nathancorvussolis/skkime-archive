/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * DIC.C
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "ImeDoc.h"
#include "skkui.h"
#include "vksub.h"

/*
 *
 *	  MakeGuideLine()
 *
 *	  Update the transrate key buffer.
 *
 */
BOOL PASCAL
MakeGuideLine (HIMC hIMC, DWORD dwID)
{
	LPINPUTCONTEXT	lpIMC ;
	LPGUIDELINE		lpGuideLine ;
	TRANSMSG		GnMsg ;
	DWORD			dwSize	= sizeof(GUIDELINE) + (MAXGLCHAR + sizeof(MYCHAR)) * 2 * sizeof(MYCHAR) ;
	LPMYSTR			lpStr ;
#if defined (MIXED_UNICODE_ANSI)
	char			szBuf [MAXGLCHAR + 1] ;
#endif

	lpIMC				= ImmLockIMC (hIMC) ;
	lpIMC->hGuideLine	= ImmReSizeIMCC (lpIMC->hGuideLine, dwSize) ;
	lpGuideLine			= (LPGUIDELINE)ImmLockIMCC (lpIMC->hGuideLine) ;

	lpGuideLine->dwSize			= dwSize ;
	lpGuideLine->dwLevel		= g_glTable [dwID].dwLevel ;
	lpGuideLine->dwIndex		= g_glTable [dwID].dwIndex ;
	lpGuideLine->dwStrOffset	= sizeof (GUIDELINE) ;
	lpStr = (LPMYSTR)(((LPSTR)lpGuideLine) + lpGuideLine->dwStrOffset);
#if defined (MIXED_UNICODE_ANSI)
	LoadString (hInst, glTable[dwID].dwStrID, szBuf, MAXGLCHAR) ;
	MultiByteToWideChar (CP_ACP, 0, szBuf, -1, lpStr, MAXGLCHAR) ;
#else
	LoadString (g_hInst, g_glTable[dwID].dwStrID, lpStr, MAXGLCHAR) ;
#endif
	lpGuideLine->dwStrLen	= Mylstrlen (lpStr) ;

	if (g_glTable[dwID].dwPrivateID){
		lpGuideLine->dwPrivateOffset = sizeof(GUIDELINE) + (MAXGLCHAR + 1) * sizeof(MYCHAR);
		lpStr = (LPMYSTR)(((LPSTR)lpGuideLine) + lpGuideLine->dwPrivateOffset);
#if defined (MIXED_UNICODE_ANSI)
		LoadString (g_hInst, g_glTable[dwID].dwStrID, szBuf, MAXGLCHAR) ;
		MultiByteToWideChar (CP_ACP, 0, szBuf, -1, lpStr, MAXGLCHAR) ;
#else
		LoadString (g_hInst, g_glTable[dwID].dwStrID,lpStr, MAXGLCHAR) ;
#endif
		lpGuideLine->dwPrivateSize = Mylstrlen(lpStr) * sizeof(MYCHAR);
	} else {
		lpGuideLine->dwPrivateOffset	= 0L ;
		lpGuideLine->dwPrivateSize		= 0L ;
	}

	GnMsg.message	= WM_IME_NOTIFY ;
	GnMsg.wParam	= IMN_GUIDELINE ;
	GnMsg.lParam	= 0 ;
	GenerateMessage (hIMC, lpIMC, g_lpCurTransKey,(LPTRANSMSG)&GnMsg) ;

	ImmUnlockIMCC (lpIMC->hGuideLine) ;
	ImmUnlockIMC (hIMC) ;

	return	TRUE ;
}

BOOL PASCAL
MakeInfoGuideLine (
	HIMC		hIMC,
	LPCMYSTR	pstrGuide,
	int			nstrGuide,
	int			nCursorPos)
{
	LPINPUTCONTEXT	lpIMC ;
	LPGUIDELINE		lpGuideLine ;
	TRANSMSG		GnMsg ;
	DWORD			dwSize	= sizeof(GUIDELINE) + (MAXGLCHAR + sizeof(MYCHAR)) * 2 * sizeof(MYCHAR) ;
	LPMYSTR			lpStr ;
#if defined (MIXED_UNICODE_ANSI)
	char			szBuf [MAXGLCHAR + 1] ;
#endif

	lpIMC				= ImmLockIMC (hIMC) ;
	if (lpIMC != NULL) {
		if (0 <= nCursorPos && nCursorPos <= nstrGuide)
			dwSize	+= sizeof (MYCHAR) ;

		lpIMC->hGuideLine	= ImmReSizeIMCC (lpIMC->hGuideLine, dwSize) ;
		lpGuideLine			= (LPGUIDELINE)ImmLockIMCC (lpIMC->hGuideLine) ;
		if (lpGuideLine != NULL) {
			lpGuideLine->dwSize			= dwSize ;
			lpGuideLine->dwLevel		= GL_LEVEL_INFORMATION ;
			lpGuideLine->dwIndex		= GL_ID_UNKNOWN ;
			lpGuideLine->dwStrOffset	= sizeof (GUIDELINE) ;

			lpStr		= (LPMYSTR)(((LPSTR)lpGuideLine) + lpGuideLine->dwStrOffset) ;
			nstrGuide	= (nstrGuide > MAXGLCHAR)? MAXGLCHAR : nstrGuide ;
	#if defined (MIXED_UNICODE_ANSI)
			MultiByteToWideChar (CP_ACP, 0, pstrGuide, nstrGuide, lpStr, MAXGLCHAR) ;
	#else
			if (nstrGuide > 0) {
				if (0 <= nCursorPos && nCursorPos <= nstrGuide) {
					if (nCursorPos > 0)
						memcpy (lpStr, pstrGuide, nCursorPos * sizeof (MYCHAR)) ;
					*(lpStr + nCursorPos)	= MYTEXT ('|') ;
					if (nCursorPos < nstrGuide)
						memcpy (lpStr + nCursorPos + 1, pstrGuide + nCursorPos, (nstrGuide - nCursorPos) * sizeof (MYCHAR)) ;
					nstrGuide	++ ;
				} else {
					memcpy (lpStr, pstrGuide, nstrGuide * sizeof (MYCHAR)) ;
				}
			} else if (nstrGuide == 0 && nCursorPos == 0) {
				*(lpStr + nstrGuide)	= MYTEXT ('|') ;
				nstrGuide	++ ;
			}
			*(lpStr + nstrGuide)	= MYTEXT ('\0') ;
	#endif
			lpGuideLine->dwStrLen			= Mylstrlen (lpStr) ;
			DEBUGPRINTFEX (99, (TEXT ("MakeInfoGuideLine (%d)\n"), (int)lpGuideLine->dwStrLen)) ;

			lpGuideLine->dwPrivateOffset	= 0L ;
			lpGuideLine->dwPrivateSize		= 0L ;

			GnMsg.message	= WM_IME_NOTIFY ;
			GnMsg.wParam	= IMN_GUIDELINE ;
			GnMsg.lParam	= 0 ;
			GenerateMessage (hIMC, lpIMC, g_lpCurTransKey,(LPTRANSMSG)&GnMsg) ;

			ImmUnlockIMCC (lpIMC->hGuideLine) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	return	TRUE ;
}

/*
 *
 *	  GenerateMessage()
 *
 *	  Update the transrate key buffer.
 *
 */
BOOL PASCAL
GenerateMessage (
	register HIMC			hIMC,
	register LPINPUTCONTEXT	lpIMC,
	register LPTRANSMSGLIST	lpTransBuf,
	register LPTRANSMSG		lpGeneMsg)
{
	DEBUGPRINTF ((TEXT ("GenerateMessage (hIMC:%lx, msg:%d, w:%lx, l:%lx)\n"), (DWORD) hIMC, lpGeneMsg->message, lpGeneMsg->wParam, lpGeneMsg->lParam)) ;

	if (lpTransBuf)
		return	GenerateMessageToTransKey (lpTransBuf, lpGeneMsg) ;

	if (IsWindow (lpIMC->hWnd)){
		LPTRANSMSG	lpTransMsg ;
		lpIMC->hMsgBuf	= ImmReSizeIMCC (lpIMC->hMsgBuf, sizeof(TRANSMSG) * (lpIMC->dwNumMsgBuf + 1)) ;
		if (!lpIMC->hMsgBuf)
			return	FALSE ;

		lpTransMsg		= (LPTRANSMSG)ImmLockIMCC (lpIMC->hMsgBuf) ;
		if (!lpTransMsg)
			return	FALSE ;

        lpTransMsg [lpIMC->dwNumMsgBuf]	= *lpGeneMsg ;
        ImmUnlockIMCC (lpIMC->hMsgBuf) ;
        lpIMC->dwNumMsgBuf	++ ;

		ImmGenerateMessage (hIMC) ;
	}
	return	TRUE ;
}

