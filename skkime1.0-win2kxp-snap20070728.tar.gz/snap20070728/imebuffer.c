#include "local.h"
#include "ImeBufferP.h"
#include "ImeDoc.h"
#include "TRomaKanaTable.h"
#include "TAssocRule.h"
#include "TServerSession.h"
#include "jstring.h"
#if !defined (UNITTEST)
#include "skkui.h"
#include "skksubs.h"
#endif
#include "varbuffer.h"
#include "common\confcommon.h"

#if defined (_WIN64)
#pragma warning ( disable : 4244)
#endif

#define	COUNTHENKANSHOWCHANGE	(4)
#define	NUMHENKANSHOWCANDIDATES	(7)

static	BOOL		imeBuffer_NormalFilter (CImeBuffer*) ;
static	BOOL		imeBuffer_JKanaInputFilter (CImeBuffer*) ;
static	BOOL		imeBuffer_JHenkanShowCandidatesFilter (CImeBuffer*) ;
static	BOOL		imeBuffer_JInputByCodeOrMenuJumpFilter (CImeBuffer*) ;
static	BOOL		imeBuffer_JInputByCodeOrMenu1Filter (CImeBuffer*) ;

static	BOOL		imeBuffer_ExecuteCommand (CImeBuffer*, int) ;
static	BOOL		imeBuffer_JKanaInputModeOn (CImeBuffer*) ;
static	BOOL		imeBuffer_JKanaInput (CImeBuffer*) ;
static	BOOL		imeBuffer_JToggleKana (CImeBuffer*) ;
static	BOOL		imeBuffer_JToggleJisx0201 (CImeBuffer*) ;
static	BOOL		imeBuffer_JSetHenkanPoint (CImeBuffer*) ;
static	BOOL		imeBuffer_JSetHenkanPointSubr (CImeBuffer*) ;
static	BOOL		imeBuffer_JStartHenkan (CImeBuffer*) ;
static	BOOL		imeBuffer_JSelfInsert (CImeBuffer*) ;
static	BOOL		imeBuffer_JZenkakuInsert (CImeBuffer*) ;
static	BOOL		imeBuffer_JModeOff (CImeBuffer*) ;
static	BOOL		imeBuffer_JZenkakuEiji (CImeBuffer*) ;
static	BOOL		imeBuffer_JAbbrevInput (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertA (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertI (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertU (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertE (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertComma (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertPeriod (CImeBuffer*) ;
static	BOOL		imeBuffer_JNewline (CImeBuffer*) ;
static	BOOL		imeBuffer_JKeyboardQuit (CImeBuffer*) ;
static	BOOL		imeBuffer_JDeleteBackwardChar (CImeBuffer*, int) ;
static	BOOL		imeBuffer_Newline (CImeBuffer*) ;
static	BOOL		imeBuffer_BackwardChar (CImeBuffer*) ;
static	BOOL		imeBuffer_ForwardChar (CImeBuffer*) ;
static	BOOL		imeBuffer_DeleteBackwardChar (CImeBuffer*, int) ;
static	BOOL		imeBuffer_SelfInsertCharacter (CImeBuffer*) ;
static	BOOL		imeBuffer_TransposeChars (CImeBuffer*) ;
static	BOOL		imeBuffer_EndOfLine (CImeBuffer*) ;
static	BOOL		imeBuffer_BeginningOfLine (CImeBuffer*) ;
static	BOOL		imeBuffer_SetMarkCommand (CImeBuffer*) ;
static	BOOL		imeBuffer_KillLine (CImeBuffer*) ;
static	BOOL		imeBuffer_KillRegion (CImeBuffer*, int, int) ;
static	BOOL		imeBuffer_JDeleteRegion (CImeBuffer*, int, int) ;
static	BOOL		imeBuffer_JKillRingSave (CImeBuffer*) ;
static	BOOL		imeBuffer_Yank (CImeBuffer*) ;
static	BOOL		imeBuffer_AbortRecursiveEdit (CImeBuffer*) ;
static	BOOL		imeBuffer_ExitMinibuffer (CImeBuffer*) ;
static	BOOL		imeBuffer_MouseDragRegion (CImeBuffer*) ;
static	BOOL		imeBuffer_OpenCandidate (CImeBuffer*) ;
static	BOOL		imeBuffer_RevertText (CImeBuffer*) ;
static	BOOL		imeBuffer_CompleteText (CImeBuffer*) ;

static	BOOL		imeBuffer_JTryCompletion (CImeBuffer*) ;
static	BOOL		imeBuffer_JAbbrevComma (CImeBuffer*) ;
static	BOOL		imeBuffer_JAbbrevPeriod (CImeBuffer*) ;
static	BOOL		imeBuffer_JKakutei (CImeBuffer*) ;
static	BOOL		imeBuffer_JCompletion (CImeBuffer*, BOOL) ;
static	BOOL		imeBuffer_JPreviousCompletion (CImeBuffer*) ;
static	BOOL		imeBuffer_JPurgeFromJisyo (CImeBuffer*) ;
static	BOOL		imeBuffer_JHenkan (CImeBuffer*) ;
static	BOOL		imeBuffer_JSetOkurigana (CImeBuffer*) ;
static	BOOL		imeBuffer_JNextCandidate (CImeBuffer*) ;
static	BOOL		imeBuffer_JPreviousCandidate (CImeBuffer*) ;
static	BOOL		imeBuffer_JToday (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsert (CImeBuffer*, CTRomaKanaTable*) ;
static	BOOL		imeBuffer_JErasePrefix (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertO (CImeBuffer*) ;
static	BOOL		imeBuffer_JInsertPrefix (CImeBuffer*, LPCWSTR, int) ;
static	BOOL		imeBuffer_JInsertStr (CImeBuffer*, LPCWSTR, int) ;
static	BOOL		imeBuffer_JEmulateOriginalMap (CImeBuffer*) ;
static	int			imeBuffer_JComputeNumericHenkanKey (CImeBuffer*, LPWSTR, int) ;
static	int			imeBuffer_JNumericConvert (CImeBuffer*, LPWSTR, int, LPCWSTR, int) ;
static	BOOL		imeBuffer_JInsertWord (CImeBuffer*, int, LPCWSTR, int) ;
static	BOOL		imeBuffer_JChangeMarker (CImeBuffer*) ;
static	BOOL		imeBuffer_JChangeMarkerToWhite (CImeBuffer*) ;
static	BOOL		imeBuffer_JHenkanInMinibuff (CImeBuffer*) ;
static	BOOL		imeBuffer_ShowJHenkanCandidates (CImeBuffer*) ;
#if !defined (UNITTEST)
static	BOOL		imeBuffer_CreateJHenkanCandidateList (CImeBuffer*, int) ;
#endif

static	int			imeBuffer_CharAfter (CImeBuffer*, int) ;
static	BOOL		imeBuffer_SetMarker (CImeBuffer*, CTMarker**, int, const CTMarker*) ;
static	BOOL		imeBuffer_DeleteRegion (CImeBuffer*, int, int) ;
static	BOOL		imeBuffer_Insert (CImeBuffer*, LPCWSTR, int nwstr) ;
static	int			imeBuffer_InsertEx (CImeBuffer*, int, LPCWSTR wstr, int) ;
static	BOOL		imeBuffer_DeleteChar (CImeBuffer*, int) ;
static	BOOL		imeBuffer_DeleteCharEx (CImeBuffer*, int, int) ;
static	int			imeBuffer_BufferSubstring (CImeBuffer*, int, int, LPCWSTR*) ;
static	CTMarker*	imeBuffer_MakeMarker (CImeBuffer*, BOOL) ;
static	BOOL		imeBuffer_DeleteMarker (CImeBuffer*, CTMarker*) ;

static	BOOL		imeBuffer_QueryProcessFunction (int) ;

static	BOOL		imeBuffer_JKatakanaHenkan (CImeBuffer*) ;
static	BOOL		imeBuffer_JHiraganaHenkan (CImeBuffer*) ;
static	BOOL		imeBuffer_JHankanaHenkan (CImeBuffer*) ;
static	BOOL		imeBuffer_JZenkanaHenkan (CImeBuffer*) ;
static	BOOL		imeBuffer_JZenkakuHenkan (CImeBuffer*) ;
static	BOOL		imeBuffer_JKatakanaRegion (CImeBuffer*, int, int, BOOL) ;
static	BOOL		imeBuffer_JHiraganaRegion (CImeBuffer*, int, int) ;
static	BOOL		imeBuffer_JHankanaRegion (CImeBuffer*, int, int) ;
static	BOOL		imeBuffer_JZenkanaRegion (CImeBuffer*, int, int, BOOL) ;
static	BOOL		imeBuffer_JZenkakuRegion (CImeBuffer*, int, int) ;

static	BOOL		imeBuffer_JUpdateJisyo (CImeBuffer*, LPCWSTR, int, BOOL) ;
static	BOOL		imeBuffer_JSharp4UpdateJisyo	(CImeBuffer*, BOOL) ;
static	int			imeBuffer_GetShiftCount (CImeBuffer*) ;

static	BOOL		imeBuffer_JInputByCodeOrMenu (CImeBuffer*) ;
static	BOOL		imeBuffer_JInputByCodeOrMenu0Start (CImeBuffer*, int, int) ;
static	BOOL		imeBuffer_JInputByCodeOrMenuJumpStart (CImeBuffer*, int) ;
static	BOOL		imeBuffer_JInputByCodeOrMenu1Start (CImeBuffer*, int, int) ;
static	BOOL		imeBuffer_ShowJInputByCodeOrMenuJump (CImeBuffer*, int) ;
static	BOOL		imeBuffer_ShowJInputByCodeOrMenu1 (CImeBuffer*, int, int) ;

static	BOOL		THenkanInMinibuffSession_OnExit (CTRecursiveEditSession*, CImeBuffer*, LPCWSTR, int) ;
static	BOOL		THenkanInMinibuffSession_OnAbort (CTRecursiveEditSession*, CImeBuffer*) ;
static	BOOL		TSharp4HenkanInMinibuffSession_OnExit (CTRecursiveEditSession*, CImeBuffer*, LPCWSTR, int) ;
static	BOOL		TSharp4HenkanInMinibuffSession_OnAbort (CTRecursiveEditSession*, CImeBuffer*) ;
static	BOOL		JInputByCodeOrMenuSession_OnExit (CTRecursiveEditSession*, CImeBuffer*, LPCWSTR, int) ;
static	BOOL		JInputByCodeOrMenuSession_OnAbort (CTRecursiveEditSession*, CImeBuffer*) ;
static	BOOL		JPurgeSession_OnExit (CTRecursiveEditSession*, CImeBuffer*, LPCWSTR,int) ;
static	BOOL		JPurgeSession_OnAbort (CTRecursiveEditSession*, CImeBuffer*) ;

/*static LPCWSTR		_wstrJInputByCodeMenuKeys1	= L"asdfghqwerty" ;
  static LPCWSTR		_wstrJInputByCodeMenuKeys2	= L"asdfghjklqwertyu" ;*/
static const int	_rnJInputByCodeOrMenuJumpLowordTbl []	= { 177, 193, 209, 225, 241 } ;
static const int	_nJCodeN1Min	= 161 ;
static const int	_nJCodeN1Max	= 244 ;
static const int	_nJCodeN2Min	= 161 ;
static const int	_nJCodeN2Max	= 254 ;
static const int	_nJCodeNull		= 128 ;

CImeBuffer*
ImeBuffer_Create (
	register CImeDoc*	pDoc)
{
	register CImeBuffer*	pBuffer ;

	ASSERT (pDoc != NULL) ;

	pBuffer	= (CImeBuffer*)MALLOC (sizeof (CImeBuffer)) ;
	if (pBuffer == NULL)
		return	NULL ;

	ImeBuffer_Init (pBuffer) ;
	pBuffer->_pDoc	= pDoc ;
	return	pBuffer ;
}

BOOL
ImeBuffer_Init (
	CImeBuffer*		pBuffer)
{
	static BOOL		rfMarkerCursor []	= {
		TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE
	} ;
	register int	i ;

	pBuffer->_nbufComp					= 0 ;
	pBuffer->_nbufJPrefix				= 0 ;
	pBuffer->_nbufJHenkanKey			= 0 ;
	pBuffer->_nbufJHenkanKey2			= 0 ;
	pBuffer->_nbufJSearchKey			= 0 ;
	pBuffer->_nbufJHenkanOkurigana		= 0 ;
	pBuffer->_nbufJHenkanResult			= 0 ;
	pBuffer->_nbufJReadingText			= 0 ;
	pBuffer->_fJMode					= TRUE ;
	pBuffer->_fJZenkaku					= FALSE ;
	pBuffer->_fJisx0201					= FALSE ;
	pBuffer->_fJKatakana				= FALSE ;
	pBuffer->_fJOkurigana				= FALSE ;
	pBuffer->_fJHenkanActive			= FALSE ;
	pBuffer->_fJHenkanOn				= FALSE ;
	pBuffer->_fJAbbrev					= FALSE ;
	pBuffer->_nJOkuriIndexMin			= 0 ;
	pBuffer->_nJOkuriIndexMax			= 0 ;
	pBuffer->_wchOkuriChar				= L'\0' ;
	pBuffer->_pmkPoint					= NULL ;
	pBuffer->_pmkEditTop				= NULL ;
	pBuffer->_pmkMark					= NULL ;
	pBuffer->_pmkJKanaStartPoint		= NULL ;
	pBuffer->_pmkJHenkanStartPoint		= NULL ;
	pBuffer->_pmkJHenkanEndPoint		= NULL ;
	pBuffer->_pmkJOkuriganaStartPoint	= NULL ;
	pBuffer->_pmkJReadingStartPoint		= NULL ;
	pBuffer->_pmkJReadingEndPoint		= NULL ;
	pBuffer->_nMarker					= 0 ;
	pBuffer->_pHenkanSession			= NULL ;
	pBuffer->_pRecursiveEditSession		= NULL ;
	pBuffer->_pFilterProc				= imeBuffer_NormalFilter ;

	pBuffer->_nJInputByCodeOrMenuJumpDefault	= _nJCodeN1Min ;
	/*	�}�[�J�̏��������s���B*/
	for (i = 0 ; i < MAX_RESERVED_MARKERS ; i ++) 
		TMarker_Init (&pBuffer->_rMarker [i], rfMarkerCursor [i]) ;
	pBuffer->_nMarker	= MAX_RESERVED_MARKERS ;
	/*	�K�{�}�[�J�ł���|�C���g(�J�[�\��)���쐬����B*/
	pBuffer->_pmkPoint	= pBuffer->_rMarker + MARKER_POINT ;
	return	TRUE ;
}

BOOL
ImeBuffer_InitEx (
	CImeBuffer*				pBuffer,
	register LPCWSTR		wstrMessage,
	register int			nstrMessage,
	register CTRecursiveEditSession*	pSession)
{
	if (! ImeBuffer_Init (pBuffer))
		return	FALSE ;
	if (nstrMessage > 0) {
		pBuffer->_pmkEditTop	= pBuffer->_rMarker + MARKER_EDIT_TOP ;
		imeBuffer_Insert (pBuffer, wstrMessage, nstrMessage) ;
		TMarker_SetPosition (pBuffer->_pmkEditTop, pBuffer->_pmkPoint) ;
	}
	pBuffer->_pRecursiveEditSession	= pSession ;
	return	TRUE ;
}

void
ImeBuffer_Uninit (
	CImeBuffer*			pBuffer)
{
	pBuffer->_nbufComp					= 0 ;
	pBuffer->_nbufJPrefix				= 0 ;
	pBuffer->_nbufJHenkanKey			= 0 ;
	pBuffer->_nbufJHenkanKey2			= 0 ;
	pBuffer->_nbufJSearchKey			= 0 ;
	pBuffer->_nbufJHenkanOkurigana		= 0 ;
	pBuffer->_nbufJHenkanResult			= 0 ;
	pBuffer->_nbufJReadingText			= 0 ;
	pBuffer->_fJMode					= TRUE ;
	pBuffer->_fJZenkaku					= FALSE ;
	pBuffer->_fJisx0201					= FALSE ;
	pBuffer->_fJKatakana				= FALSE ;
	pBuffer->_fJOkurigana				= FALSE ;
	pBuffer->_fJHenkanActive			= FALSE ;
	pBuffer->_fJHenkanOn				= FALSE ;
	pBuffer->_fJAbbrev					= FALSE ;
	pBuffer->_nJOkuriIndexMin			= 0 ;
	pBuffer->_nJOkuriIndexMax			= 0 ;
	pBuffer->_wchOkuriChar				= L'\0' ;
	pBuffer->_pmkPoint					= NULL ;
	pBuffer->_pmkEditTop				= NULL ;
	pBuffer->_pmkMark					= NULL ;
	pBuffer->_pmkJKanaStartPoint		= NULL ;
	pBuffer->_pmkJHenkanStartPoint		= NULL ;
	pBuffer->_pmkJHenkanEndPoint		= NULL ;
	pBuffer->_pmkJOkuriganaStartPoint	= NULL ;
	pBuffer->_pmkJReadingStartPoint		= NULL ;
	pBuffer->_pmkJReadingEndPoint		= NULL ;
	pBuffer->_nMarker					= 0 ;

	if (pBuffer->_pHenkanSession != NULL) {
		/*	session �Ɋւ�� resource �̉���B*/
		THenkanSession_Uninit (pBuffer->_pHenkanSession) ;
		pBuffer->_pHenkanSession		= NULL ;
	}
	pBuffer->_pRecursiveEditSession		= NULL ;
	pBuffer->_pFilterProc				= NULL ;
	return ;
}

BOOL
ImeBuffer_Clear (
	CImeBuffer*		pBuffer)
{
	ImeBuffer_Uninit (pBuffer) ;
	return	ImeBuffer_Init (pBuffer) ;
}

CImeDoc*
ImeBuffer_GetDocument (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	return	pBuffer->_pDoc ;
}

BOOL
ImeBuffer_QueryFilterKeyEvent (
	CImeBuffer*				pBuffer,
	register WCHAR			wch,
	register BOOL*			pfFiltered)
{
	int						nFuncNo ;

	ASSERT (pfFiltered != NULL) ;

	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_QueryFilterKeyEvent (Buf:%p, ch:0x%x)\n"), pBuffer, wch)) ;

	/*	�ϊ������H �������͒��Ȃ̂��H process ���邩
	 *	�ǂ����͂���Ɉˑ�����B
	 */
	if (pBuffer->_pFilterProc != imeBuffer_NormalFilter) {
		/*	NormalFilter �ɂ��Ȃ��Ƃ������Ƃ́A�܂��L�[�͐H�ׂ���B
		 *	(����prefix �̓��͓r���̉\���Ƃ�)
		 */
		*pfFiltered	= TRUE ;
		return	TRUE ;
	}
	/*	�ϊ����쒆�Ƃ������Ƃ͋��炭�� key �� filter ���锤�B
	 *	���A�ϊ�������S�ď������ꂽ��Ԃł͂ǂ��Ȃ�̂��H�͋C�ɂȂ�B
	 */
	if (pBuffer->_nbufComp > 0 ||
		pBuffer->_fJHenkanOn ||
		pBuffer->_fJHenkanActive) {
		*pfFiltered	= TRUE ;
		return	TRUE ;
	}
		
	/*	�������͒��ł��ϊ����ł��Ȃ�(�܂�e�L�X�g��
	 *	���ɂ��ҏW���ĂȂ��^�����ȏ��)�Ȃ�Akey ��
	 *	filter ���邩�ǂ����́Akey �Ɋ��蓖�Ă��Ă���
	 *	function �Ɉˑ�����B
	 */
	if (! ImeDoc_LookupKeymap (pBuffer->_pDoc, wch, &nFuncNo))
		return	FALSE ;
	
	if (nFuncNo == FUNCNO_J_NEWLINE) {
		/*	DoEditSession �� Eaten = FALSE �ɂ��Ă� 
		 *	application �� key �� handle ���Ă���Ȃ��c�B
		 *	���O�� handle ���邵�Ȃ��� guess ����K�v��
		 *	����悤���B
		 */
		if (pBuffer->_nbufComp > 0 ||
			pBuffer->_nbufJPrefix > 0 ||
			! pBuffer->_fJMode ||
			pBuffer->_fJHenkanOn ||
			pBuffer->_pRecursiveEditSession != NULL) {
			*pfFiltered	= TRUE ;
		} else {
			*pfFiltered	= FALSE ;
		}
	} else {
		*pfFiltered	= imeBuffer_QueryProcessFunction (nFuncNo) ;
	}
	return	TRUE ;
}

BOOL
ImeBuffer_QueryToggleIMEKeyEvent (
	CImeBuffer*				pBuffer,
	register WCHAR			wch,
	register BOOL*			pfFiltered)
{
	int						nFuncNo ;

	ASSERT (pfFiltered != NULL) ;

	/*	�ǂ�ȏ�Ԃł� Toggle �ł���悤�ɂ���ׂ����H
	 */
	if (! ImeDoc_LookupKeymap (pBuffer->_pDoc, wch, &nFuncNo))
		return	FALSE ;

	*pfFiltered	= (nFuncNo == FUNCNO_TOGGLE_IME) ;
	return	TRUE ;
}

BOOL
ImeBuffer_FilterKeyEvent (
	CImeBuffer*		pBuffer)
{
	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_FilterKeyEvent (Buf:%p)\n"), pBuffer)) ;

	return	(pBuffer->_pFilterProc)(pBuffer) ;
}

LPCWSTR
ImeBuffer_GetText (
	CImeBuffer*		pBuffer,
	int*			pnLength)
{
	ASSERT (pnLength != NULL) ;
	*pnLength	= pBuffer->_nbufComp ;
	return	pBuffer->_bufComp ;
}

int
ImeBuffer_GetCursorPosition (
	CImeBuffer*		pBuffer) 
{
	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;
	return	TMarker_GetPosition (pBuffer->_pmkPoint) ;
}

int
ImeBuffer_GetReadingText (
	CImeBuffer*		pBuffer,
	LPWSTR			wpDest,
	int				nDest,
	int*			pnRawPos)	/* [in/out] */
{
	register LPWSTR	ptr ;
	register int	nptr, nPos ;
	int		nReadingStart, nReadingEnd ;
	int		nHenkanStart, nHenkanEnd, nOkuriPos ;
	int		nKanaStart, nKanaEnd ;
	BOOL	fSetReadingPos ;
	int		nReadingPos, nRawPos ; 

	ASSERT (pBuffer != NULL) ;

	/*	�ނނށB�l�����ׂ��_�͎��̒ʂ�F
	 *		- kana-prefix �����݂��邩�H (_nbufJPrefix > 0) ���݂���Ȃ�A
	 *		  _pmkKanaStartPoint ���� _pmkPoint �܂ł̓R�s�[���Ȃ��B
	 *		- �ϊ������H �ϊ����Ȃ�΁A_pmkJHenkanStartPoit - 1 ����
	 *		  _pmkJHenkanEndPoint �܂ł� _bufJHenkanKey �Œu��������
	 *		  �R�s�[����B
	 *		- �ϊ����悤�Ƃ��Ă���(��
	 */
#define	SAFE_GET_MARKER_POSITION(pMarker)	(((pMarker) != NULL)? TMarker_GetPosition ((pMarker)) : -1)
	nReadingStart	= SAFE_GET_MARKER_POSITION (pBuffer->_pmkJReadingStartPoint) ;
	nReadingEnd		= SAFE_GET_MARKER_POSITION (pBuffer->_pmkJReadingEndPoint) ;
	if (pBuffer->_fJHenkanOn) {
		nHenkanStart	= SAFE_GET_MARKER_POSITION (pBuffer->_pmkJHenkanStartPoint) ;
		if (pBuffer->_fJHenkanActive) {
			nHenkanEnd	= SAFE_GET_MARKER_POSITION (pBuffer->_pmkJHenkanEndPoint) ;
		} else {
			nHenkanEnd	= -1 ;
		}
	} else {
		nHenkanStart	= nHenkanEnd	= -1 ;
	}
	if (pBuffer->_nbufJPrefix > 0) {
		nKanaStart	= SAFE_GET_MARKER_POSITION (pBuffer->_pmkJKanaStartPoint) ;
		nKanaEnd	= SAFE_GET_MARKER_POSITION (pBuffer->_pmkPoint) ;
	} else {
		nKanaStart	= nKanaEnd	= -1 ;
	}
	if (pBuffer->_fJOkurigana) {
		nOkuriPos	= SAFE_GET_MARKER_POSITION (pBuffer->_pmkJOkuriganaStartPoint) ;
	} else {
		nOkuriPos	= -1 ;
	}
#undef	SAFE_GET_MARKER_POSITION

#define	SAFE_PTR_WRITE_AND_INC(pDest,nDest,pSrc,nSrc)	do {	\
	register int	nCOPY	= ((nDest) < (nSrc))? (nDest) : (nSrc) ;	\
	register int	nCOPYED ;	\
	nCOPYED = JPhoneticStrcpy ((pDest), (pSrc), nCOPY) ;	\
	(pDest)	+= nCOPYED ;	\
	(nDest)	-= nCOPYED ;	\
}	while (0)

	ptr				= wpDest ;
	nptr			= nDest ;
	nPos			= 0 ;
	nRawPos			= (pnRawPos != NULL)? *pnRawPos : 0 ;
	fSetReadingPos	= FALSE ;
	nReadingPos		= 0 ;
	while (nPos < pBuffer->_nbufComp) {
		if (! fSetReadingPos && nRawPos <= nPos) {
			nReadingPos		= ptr - wpDest ;
			fSetReadingPos	= TRUE ;
		}
		if (/*pBuffer->_fHenkanActive &&*/ nPos == (nHenkanStart - 1)) {
			if (pBuffer->_bufComp [nPos] != L'��' &&
				pBuffer->_bufComp [nPos] != L'��') {
				SAFE_PTR_WRITE_AND_INC (ptr, nptr, pBuffer->_bufComp + nPos, 1) ;
			}
			nPos	++ ;
		} else if (nPos == nOkuriPos) {
			if (pBuffer->_bufComp [nPos] != L'*') {
				SAFE_PTR_WRITE_AND_INC (ptr, nptr, pBuffer->_bufComp + nPos, 1) ;
			}
			nPos	++ ;
		} else if (/*pBuffer->_fHenkanOn &&*/ nHenkanStart <= nPos && nPos < nHenkanEnd) {
			int	n	= pBuffer->_nbufJHenkanKey ;
			if (pBuffer->_nbufJHenkanKey2 > 0)
				n	-- ;
			SAFE_PTR_WRITE_AND_INC (ptr, nptr, pBuffer->_bufJHenkanKey, n) ;
			nPos	= nHenkanEnd ;
		} else if (/*pBuffer->_nbufJPrefix > 0 &&*/ nKanaStart <= nPos && nPos < nKanaEnd) {
			/*	�����v���t�B�N�X�͓ǂ݉����ɂ͓���Ȃ��B*/
			nPos	= nKanaEnd ;
		} else if (nReadingStart <= nPos && nPos < nReadingEnd) {
			SAFE_PTR_WRITE_AND_INC (ptr, nptr, pBuffer->_bufJReadingText, pBuffer->_nbufJReadingText) ;
			nPos	= nReadingEnd ;
		} else {
			SAFE_PTR_WRITE_AND_INC (ptr, nptr, pBuffer->_bufComp + nPos, 1) ;
			nPos	++ ;
		}
	}
#undef	SAFE_PTR_WRITE_AND_INC
	if (! fSetReadingPos && nRawPos <= nPos) {
		nReadingPos		= ptr - wpDest ;
		fSetReadingPos	= TRUE ;
	}
	if (pnRawPos != NULL)
		*pnRawPos	= nReadingPos ;
	return	(ptr - wpDest) ;
}

int
ImeBuffer_SetConversionMode (
	CImeBuffer*		pBuffer,
	register int	nMode)
{
	/*	�ċA���[�h�ł�������A���ꃂ�[�h(j-read-char �҂��Ƃ�)
	 *	�ł���ꍇ�ɂ͖����B
	 */
	if (pBuffer->_pRecursiveEditSession != NULL)
		return	FALSE ;
	if (pBuffer->_pFilterProc != imeBuffer_NormalFilter)
		return	FALSE ;

	switch (nMode) {
	case	IMECMODE_ZENKAKU:
		imeBuffer_JZenkakuEiji (pBuffer) ;
		break ;
	case	IMECMODE_ASCII:
		imeBuffer_JModeOff (pBuffer) ;
		break ;
	case	IMECMODE_KATAKANA:
		imeBuffer_JKakutei (pBuffer) ;
		if (pBuffer->_fJisx0201)
			imeBuffer_JToggleJisx0201 (pBuffer) ;
		if (! pBuffer->_fJKatakana)
			imeBuffer_JToggleKana (pBuffer) ;
		break ;
	case	IMECMODE_HIRAGANA:
		imeBuffer_JKakutei (pBuffer) ;
		if (pBuffer->_fJisx0201)
			imeBuffer_JToggleJisx0201 (pBuffer) ;
		if (pBuffer->_fJKatakana)
			imeBuffer_JToggleKana (pBuffer) ;
		break ;
	case	IMECMODE_HANKANA:
		imeBuffer_JKakutei (pBuffer) ;
		if (! pBuffer->_fJisx0201) 
			imeBuffer_JToggleJisx0201 (pBuffer) ;
		break ;
	default:
		break ;
	}
	return	TRUE ;
}

int
ImeBuffer_GetConversionMode (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJMode) {
		return	pBuffer->_fJZenkaku? IMECMODE_ZENKAKU : IMECMODE_ASCII ;
	} else {
		if (pBuffer->_fJisx0201)
			return	IMECMODE_HANKANA ;
		return	pBuffer->_fJKatakana? IMECMODE_KATAKANA : IMECMODE_HIRAGANA ;
	}
}

int
ImeBuffer_GetKeymap (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJMode) {
		return	pBuffer->_fJZenkaku? IMEKEYMAP_ZENKAKU : IMEKEYMAP_ASCII ;
	} else if (pBuffer->_fJAbbrev && ! pBuffer->_fJHenkanActive) {
		return	IMEKEYMAP_ABBREV ;
	} else {
		return	IMEKEYMAP_JMODE ;
	}
}

BOOL
ImeBuffer_QueryUpdateContext (
	CImeBuffer*			pBuffer,
	register int*		pnShift,
	register int*		pnCursor,
	register BOOL*		pfContinue)
{
	register int	nCursor, nShift ;

	ASSERT (pBuffer != NULL) ;

	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_QueryUpdateContext (buf:%p)\n"), pBuffer)) ;
	nCursor	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	nShift	= imeBuffer_GetShiftCount (pBuffer) ;
	if (! pBuffer->_fJMode) {
		/*	�������[�h�łȂ��ꍇ�B�V�t�g����̂̓J�[�\���ʒu�܂ŁB*/
		*pnShift	= nShift ;
		*pnCursor	= 0 ;	/* �V�t�g��̃J�[�\���ʒu�B*/
		*pfContinue	= (pBuffer->_pFilterProc != imeBuffer_NormalFilter && pBuffer->_pFilterProc != imeBuffer_JKanaInputFilter) || (nShift < pBuffer->_nbufComp) ;
	} else {
		*pnShift	= nShift ;
		*pnCursor	= nCursor - nShift ;

		/*	modified Fri Sep 02 11:17:12 2005
		 *		PSO ... �̃R�����g�̈Ӗ���Y��Ă���c�BGUIDE Window ������� CANCEL ��
		 *		�A�ł��铮��ɂ��Ă��낤���H
#if 0
#if 0
		// PSO
		*pfContinue	= pBuffer->_fJHenkanOn || (nShift < pBuffer->_nbufComp) || ImeBuffer_IsJInputByCodeOrMenuModep (pBuffer) || (pBuffer->_nbufJPrefix > 0) ;
#else
		*pfContinue	= pBuffer->_fJHenkanOn || (nShift < pBuffer->_nbufComp) || ImeBuffer_IsJInputByCodeOrMenuModep (pBuffer) ;
#endif
#endif
		 */
		*pfContinue	= (pBuffer->_pFilterProc != imeBuffer_NormalFilter && pBuffer->_pFilterProc != imeBuffer_JKanaInputFilter) || pBuffer->_fJHenkanOn || (nShift < pBuffer->_nbufComp) ;
	}
	return	TRUE ;
}

BOOL
ImeBuffer_UpdateContext (
	CImeBuffer*			pBuffer)
{
	int		nShift, nCursor ;
	BOOL	fContinue ;

	ASSERT (pBuffer != NULL) ;

	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_UpdateContext (Buf:%p)\n"), pBuffer)) ;

	if (! ImeBuffer_QueryUpdateContext (pBuffer, &nShift, &nCursor, &fContinue))
		return	FALSE ;
	imeBuffer_DeleteRegion (pBuffer, 0, nShift) ;
	return	TRUE ;
}

BOOL
ImeBuffer_GetSelectedRegion (
	register CImeBuffer*	pBuffer,
	register int*			pnStart,
	register int*			pnEnd)
{
	int		nPoint, nMark, nCmd ;

	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_pmkMark == NULL)
		return	FALSE ;
	nCmd	= ImeDoc_GetLastCommand (pBuffer->_pDoc) ;
	if (nCmd != FUNCNO_MOUSE_DRAG_REGION && nCmd != FUNCNO_MOUSE_DRAG_REGION_END)
		return	FALSE ;

	nPoint	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	nMark	= TMarker_GetPosition (pBuffer->_pmkMark) ;
	if (pnStart != NULL)
		*pnStart	= (nPoint < nMark)? nPoint : nMark ;
	if (pnEnd != NULL)
		*pnEnd		= (nPoint < nMark)? nMark  : nPoint ;
	return	TRUE ;
}

BOOL
ImeBuffer_SetConversionString (
	register CImeBuffer*	pBuffer,
	register LPCWSTR		wstrText,
	register int			nText)
{
	if (wstrText == NULL || pBuffer == NULL || nText <= 0)
		return	FALSE ;

	nText	= (nText > (MAXCOMPLEN - 1))? (MAXCOMPLEN - 1) : nText ;
	ImeBuffer_Clear (pBuffer) ;
	imeBuffer_JSetHenkanPointSubr (pBuffer) ;
	imeBuffer_Insert (pBuffer, wstrText, nText) ;
	return	TRUE ;
}

BOOL
ImeBuffer_GetConvertedRegion (
	register CImeBuffer*	pBuffer,
	register int*			pnStart,
	register int*			pnEnd)
{
	if (! pBuffer->_fJHenkanOn || ! pBuffer->_fJHenkanActive)
		return	FALSE ;
	if (pBuffer->_pmkJHenkanStartPoint == NULL ||
		pBuffer->_pmkJHenkanEndPoint   == NULL)
		return	FALSE ;
	if (pnStart != NULL)
		*pnStart	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) ;
	if (pnEnd != NULL)
		*pnEnd		= TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint) ;
	return	TRUE ;
}

BOOL
ImeBuffer_IsJHenkanShowCandidateModep (
	register CImeBuffer*	pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	return	(pBuffer->_pFilterProc == imeBuffer_JHenkanShowCandidatesFilter) ;
}

BOOL
ImeBuffer_IsJInputByCodeOrMenuModep (
	register CImeBuffer*	pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	return	
		pBuffer->_pFilterProc == imeBuffer_JInputByCodeOrMenuJumpFilter ||
		pBuffer->_pFilterProc == imeBuffer_JInputByCodeOrMenu1Filter ;
}

#if !defined (UNITTEST)
BOOL
ImeBuffer_RevertText (
	register CImeBuffer*	pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	return	imeBuffer_RevertText (pBuffer) ;
}

BOOL
ImeBuffer_CompleteText (
	register CImeBuffer*	pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	return	imeBuffer_CompleteText (pBuffer) ;
}
#endif

BOOL
ImeBuffer_IsStatusActivep (
	register CImeBuffer*	pBuffer)
{
	return	! (pBuffer->_pFilterProc == imeBuffer_NormalFilter || pBuffer->_pFilterProc == imeBuffer_JKanaInputFilter) ;
}

/*========================================================================*
 */

/*	�����ł͑f���� keymap ������B
 *
 *	���ۂ� Filter ���ꂽ�ꍇ�ɂ� *pfFiltered = TRUE �ƂȂ�B
 */
BOOL
imeBuffer_NormalFilter (
	CImeBuffer*			pBuffer)
{
	register WCHAR			wch ;
	int						nFuncNo ;

	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_NormalFilter (Buf:%p)\n"), pBuffer)) ;

	wch	= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;

	/*	�L�[�� filter ����邩�ǂ����� topbuffer �̏�ԂɈˑ�����B
	 *
	 *	Composition ���J�n����Ă�����A�m���B�����łȂ�������A
	 *	�󋵂Ɉˑ��B
	 */
	if (! ImeDoc_LookupKeymap (pBuffer->_pDoc, wch, &nFuncNo))
		return	FALSE ;

	imeBuffer_ExecuteCommand (pBuffer, nFuncNo) ;
	return	TRUE ;
}

BOOL
imeBuffer_JKanaInputFilter (
	CImeBuffer*		pBuffer)
{
	WCHAR					chKana ;
	WCHAR					bufPrefix [MAXPREFIXLEN] ;
	register int			nbufPrefix ;
	register CTAssocRule*	pNext ;
	register LPCWSTR		pwstrOutput		= NULL ;
	register LPCWSTR		pwstrNewPrefix	= NULL ;
	WCHAR					chRChar ;
	register BOOL			fCont			= TRUE ;

	static int				srCharTypeVector []	= {
		0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 4, 4, 4,
		4, 0, 4, 4, 4, 4, 4, 4, 0, 4, 4, 0, 0, 0, 0, 0,
		0, 3, 1, 1, 1, 3, 1, 1, 1, 3, 1, 1, 0, 1, 2, 3,
		1, 0, 1, 1, 1, 3, 1, 1, 2, 1, 1, 0, 0, 0, 0, 5,

		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* LEFT, UP, DOWN, RIGHT, INSERT */
		5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* DELETE, BACK, TAB, HOME, SPACE */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* ESC, KANJI, HELP, F1, F2 */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* F3, F4, F5, F6, F7 */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* F8, F9, F10, F11, F12 */
		0, 0, 0, 0, 0, 0, /* CLEAR, RETURN */
	} ;

	chKana		= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	
	/*	�����ɗ����i�K�Ŋm���ɃL�[�� filter ����Ă���B
	 *	���p���ꂸ�ɑf�ʂ�͂��肦�Ȃ��B
	 */
	if (chKana == 0x07) {
		/*	(signal 'quit nil)
		 *
		 *	filter �����Ƃ͏��������̂́A�����̕������������
		 *	�ǂ��Ȃ񂾂낤�H�Ƃ��B
		 */
		if (pBuffer->_nbufJPrefix == 1 && pBuffer->_bufJPrefix [0] == L'o') {
#if 1
			/* ``o'' �̉e���������Ȃ��̂̓o�O����Ȃ��̂��H (Tue Mar 09 11:39:51 2004)
			 */
			pBuffer->_nbufJPrefix			= 0 ;
#endif
			imeBuffer_JKeyboardQuit (pBuffer) ;
		} else {
			pBuffer->_nbufJPrefix			= 0 ;
			imeBuffer_JErasePrefix (pBuffer) ;
			pBuffer->_pmkJKanaStartPoint	= NULL ;
		}
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
		return	TRUE ;
	}
	if (pBuffer->_fJHenkanOn && ! pBuffer->_fJHenkanActive && 
		TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) == (TMarker_GetPosition (pBuffer->_pmkPoint) - 1) &&
		L'A' <= chKana && chKana <= L'Z') {
		chRChar	= (WCHAR)(chKana + L'a' - L'A') ;
	} else {
		chRChar	= chKana ;
	}

	memcpy (bufPrefix, pBuffer->_bufJPrefix, sizeof (WCHAR) * pBuffer->_nbufJPrefix) ;
	nbufPrefix	= pBuffer->_nbufJPrefix ;
	bufPrefix [nbufPrefix ++]	= chRChar ;

	/*	assoc-rule �̏����B
	 */
	pNext		= ImeDoc_JAssocRule (pBuffer->_pDoc, bufPrefix, nbufPrefix) ;
	if (pNext != NULL) {
		pwstrNewPrefix	= TAssocRule_GetNext (pNext) ;
		pwstrOutput		= TAssocRule_GetOutput (pNext, pBuffer->_fJKatakana) ;
		imeBuffer_JErasePrefix (pBuffer) ;
		if (pwstrOutput != NULL) {
			imeBuffer_JInsertStr (pBuffer, pwstrOutput, lstrlenW (pwstrOutput)) ;
			if (pBuffer->_fJOkurigana) 
				imeBuffer_JSetOkurigana (pBuffer) ;
		}
		if (pwstrNewPrefix != NULL && *pwstrNewPrefix != L'\0') {
			int		nNewPrefixLen ;
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
			nNewPrefixLen	= lstrlenW (pwstrNewPrefix) ;
			nNewPrefixLen	= (nNewPrefixLen > MAXPREFIXLEN)? MAXPREFIXLEN : nNewPrefixLen ;
			imeBuffer_JInsertPrefix (pBuffer, pwstrNewPrefix, nNewPrefixLen) ;
			memcpy (pBuffer->_bufJPrefix, pwstrNewPrefix, sizeof (WCHAR) * nNewPrefixLen) ;
			pBuffer->_nbufJPrefix	= nNewPrefixLen ;
		} else {
			fCont					= FALSE ;
			pBuffer->_nbufJPrefix	= 0 ;
		}
		goto	exit_function ;
	}

#define	LOOKUP_CHARTYPEVECTOR(ch)	((0 <= (ch) && (ch) < NELEMENTS(srCharTypeVector))? srCharTypeVector[(ch)] : 0)

	/*	``n'' �̏����B
	 */
	if (pBuffer->_nbufJPrefix == 1 && pBuffer->_bufJPrefix [0] == L'n') {
		if (LOOKUP_CHARTYPEVECTOR (chRChar) == 3) {
			imeBuffer_JErasePrefix (pBuffer) ;
			fCont			= FALSE ;
			ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chRChar) ;
		} else if (chRChar == L'y') {
			pBuffer->_nbufJPrefix	= nbufPrefix ;
			memcpy (pBuffer->_bufJPrefix, bufPrefix, nbufPrefix * sizeof (WCHAR)) ;
			imeBuffer_JInsertPrefix (pBuffer, L"y", 1) ;
		} else if (pBuffer->_fJOkurigana && chRChar == L' ') {
			ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, L'n') ;
		} else {
			imeBuffer_JErasePrefix (pBuffer) ;
			imeBuffer_JInsertStr (pBuffer, pBuffer->_fJKatakana? L"��" : L"��", 1) ;
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
			pBuffer->_nbufJPrefix	= 0 ;
			fCont					= FALSE ;
			ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chRChar) ;
		}
		goto	exit_function ;
	}

	/*	``o'' �̏����B
	 */
	if (pBuffer->_nbufJPrefix == 1 && pBuffer->_bufJPrefix [0] == L'o') {
		if (chRChar == L'h') {
			pBuffer->_nbufJPrefix	= nbufPrefix ;
			memcpy (pBuffer->_bufJPrefix, bufPrefix, nbufPrefix * sizeof (WCHAR)) ;
			imeBuffer_JInsertPrefix (pBuffer, L"h", 1) ;
		} else {
			imeBuffer_JErasePrefix (pBuffer) ;
			fCont					= FALSE ;
			pBuffer->_nbufJPrefix	= 0 ;
			ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chKana) ;
		}
		goto	exit_function ;
	}

	/*	``oh'' �̏����B
	 */
	if (pBuffer->_nbufJPrefix == 2 &&
		pBuffer->_bufJPrefix [0] == L'o' && 
		pBuffer->_bufJPrefix [1] == L'h') {
		if (LOOKUP_CHARTYPEVECTOR (chRChar) == 3) {
			fCont						= FALSE ;
			imeBuffer_JErasePrefix (pBuffer) ;
			pBuffer->_nbufJPrefix		= 1 ;
			pBuffer->_bufJPrefix [0]	= L'h' ;
			ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chRChar) ;
		} else {
			imeBuffer_JErasePrefix (pBuffer) ;
			imeBuffer_JInsertStr (pBuffer, pBuffer->_fJKatakana? L"�I" : L"��", 1) ;
			fCont			= FALSE ;
			pBuffer->_nbufJPrefix	= 0 ;
			ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chRChar) ;
		}
		goto	exit_function ;
	}

	/*	``��'' �̏����B
	 */
	if (pBuffer->_nbufJPrefix == 1 && pBuffer->_bufJPrefix [0] == chRChar && 
		LOOKUP_CHARTYPEVECTOR (chRChar) == 1) {
		imeBuffer_JErasePrefix (pBuffer) ;
		imeBuffer_JInsertStr (pBuffer, pBuffer->_fJKatakana? L"�b" : L"��", 1) ;
		imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
		imeBuffer_JInsertPrefix (pBuffer, &chRChar, 1) ;
	} else if (ImeDoc_IsValidPrefixp (pBuffer->_pDoc, bufPrefix, nbufPrefix)) {
		/* [BEGIN] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
		imeBuffer_JErasePrefix (pBuffer) ;
		/* [END] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
		pBuffer->_nbufJPrefix	= nbufPrefix ;
		memcpy (pBuffer->_bufJPrefix, bufPrefix, nbufPrefix * sizeof (WCHAR)) ;
		/* [BEGIN] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
		imeBuffer_JInsertPrefix (pBuffer, bufPrefix, nbufPrefix) ;
		/* [END] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
	} else if (LOOKUP_CHARTYPEVECTOR (chRChar) == 3) {
		fCont	= FALSE ;
		imeBuffer_JErasePrefix (pBuffer) ;
		ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chRChar) ;
	} else if (LOOKUP_CHARTYPEVECTOR (chRChar) == 4) {
		register int	ch	= ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
		imeBuffer_JErasePrefix (pBuffer) ;
		ImeDoc_SetLastCommandChar (pBuffer->_pDoc, chRChar) ;
		imeBuffer_JSetHenkanPoint (pBuffer) ;
		ImeDoc_SetLastCommandChar (pBuffer->_pDoc, ch) ;
	} else if (LOOKUP_CHARTYPEVECTOR (chRChar) == 5) {
		fCont	= FALSE ;
		if (pBuffer->_fJOkurigana &&
			imeBuffer_CharAfter (pBuffer, TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint)) == L'*') {
			imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint), TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) + 1) ;
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkJOkuriganaStartPoint) ;
			pBuffer->_fJOkurigana	= FALSE ;
		}
		if (pBuffer->_nbufJPrefix > 0) 
			imeBuffer_JErasePrefix (pBuffer) ;
		pBuffer->_nbufJPrefix	= 0 ;
	} else {
		fCont	= FALSE ;
		imeBuffer_JErasePrefix (pBuffer) ;
		pBuffer->_pmkJKanaStartPoint	= NULL ;
		pBuffer->_nbufJPrefix			= 0 ;
		ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chRChar) ;
	}
#undef	LOOKUP_CHARTYPEVECTOR

  exit_function:
	if (! fCont) 
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
	return	TRUE ;
}

/*	�����̓���� skimic �Ɠ����Ƃ����킯�ɂ͂����Ȃ��B
 *	�Ƃ������Atop ���ǂ�������肩�B
 *	top �łȂ���΁A�����͕K�v�c�B
 */
BOOL
imeBuffer_JHenkanShowCandidatesFilter (
	CImeBuffer*		pBuffer)
{
	register WCHAR			wch ;
	register const BYTE*	bptr ;
	register LPCWSTR		wstrResult ;
	register int			nCount, nCandidate ;
#if !defined (UNITTEST)
	register TVarbuffer*		pvbufCandInfo ;
	register LPMYCAND			pMyCand ;
	register LPCANDIDATEINFO	pCandInfo ;
	register LPCANDIDATELIST	pCandidateList ;
#endif
	register BOOL		fShow	= TRUE ;
	register BOOL		fRetval	= TRUE ;

#if !defined (UNITTEST)
	pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pBuffer->_pDoc) ;
	if (pvbufCandInfo == NULL || TVarbuffer_GetUsage (pvbufCandInfo) < sizeof (MYCAND))
		return	FALSE ;
	pMyCand			= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo		= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandidateList	= (LPCANDIDATELIST)&(pMyCand->cl) ;
#endif
	wch		= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	bptr	= ImeDoc_GetJHenkanShowCandidateKeys (pBuffer->_pDoc) ;
	nCount	= 0 ;
	while (nCount < NUM_JHENKAN_SHOW_CANDIDATE_KEYS && wch != (WCHAR)*bptr) {
		nCount	++ ;
		bptr	++ ;
	}
	if (nCount < NUM_JHENKAN_SHOW_CANDIDATE_KEYS) {
		register CTMarker*	pMkKanaStartPoint	= NULL ;
		register CTMarker*	pMkOkuriStartPoint	= NULL ;
		register CTMarker*	pMkHenkanEndPoint	= NULL ;
		register int		i ;

		for (i = 0 ; i < nCount ; i ++) {
			if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) {
				while (i -- > 0) 
					THenkanSession_PreviousCandidate (pBuffer->_pHenkanSession) ;
				goto	exit_func ;
			}
		}
		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;

		if (pBuffer->_pmkJKanaStartPoint != NULL) {
			pMkKanaStartPoint	= imeBuffer_MakeMarker (pBuffer, TRUE) ;
			TMarker_SetPosition (pMkKanaStartPoint, pBuffer->_pmkJKanaStartPoint) ;
		}
		if (pBuffer->_pmkJOkuriganaStartPoint != NULL) {
			pMkOkuriStartPoint	= imeBuffer_MakeMarker (pBuffer, TRUE) ;
			TMarker_SetPosition (pMkOkuriStartPoint, pBuffer->_pmkJOkuriganaStartPoint) ;
		}
		pMkHenkanEndPoint	= imeBuffer_MakeMarker (pBuffer, TRUE) ;
		imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
		TMarker_SetPosition (pMkHenkanEndPoint, pBuffer->_pmkJHenkanStartPoint) ;
		/*	�ϊ����ʂ�}������B*/
		imeBuffer_JInsertWord (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), wstrResult, lstrlenW (wstrResult)) ;
		TMarker_SetPosition (pBuffer->_pmkJHenkanEndPoint, pMkHenkanEndPoint) ;
		imeBuffer_DeleteMarker (pBuffer, pMkHenkanEndPoint) ;
		if (pMkOkuriStartPoint != NULL) {
			TMarker_SetPosition (pBuffer->_pmkJOkuriganaStartPoint, pMkOkuriStartPoint) ;
			imeBuffer_DeleteMarker (pBuffer, pMkOkuriStartPoint) ;
		}
		if (pMkKanaStartPoint != NULL) {
			TMarker_SetPosition (pBuffer->_pmkJKanaStartPoint, pMkKanaStartPoint) ;
			imeBuffer_DeleteMarker (pBuffer, pMkKanaStartPoint) ;
		}
		imeBuffer_JKakutei (pBuffer) ;
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
#if !defined (UNITTEST)
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
		TVarbuffer_Clear (pvbufCandInfo) ;
#endif
		return	TRUE ;
	}

	switch (wch) {
#if !defined (UNITTEST)
	case	WCH_SELECTCANDIDATESTR:
	{
		DWORD	dwSelect	= (DWORD) ImeDoc_GetLastKeyData (pBuffer->_pDoc) ;

		if (dwSelect < pCandidateList->dwPageStart) {
			while (dwSelect < pCandidateList->dwPageStart) {
				imeBuffer_JPreviousCandidate (pBuffer) ;
				if (pBuffer->_nJHenkanCount <= COUNTHENKANSHOWCHANGE) {
					pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
					ImeDoc_ClearMessage (pBuffer->_pDoc) ;
					ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
					TVarbuffer_Clear (pvbufCandInfo) ;
					fShow	= FALSE ;
					goto	exit_func_1 ;
				}
				pCandidateList->dwPageStart	-= NUMHENKANSHOWCANDIDATES ;
			}
			pCandidateList->dwSelection	= dwSelect ;
		} else if (dwSelect >= (pCandidateList->dwPageStart + NUMHENKANSHOWCANDIDATES)) {
			while (dwSelect >= (pCandidateList->dwPageStart + NUMHENKANSHOWCANDIDATES)) {
				nCount	= NUMHENKANSHOWCANDIDATES ;
				/*	���ɐi�߂邾���B*/
				while (nCount -- > 0) {
					pBuffer->_nJHenkanCount	++ ;
					pCandidateList->dwPageStart	++ ;
					if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession))
						break ;
				}
				if (nCount > 0)
					break ;
			}
			if (pCandidateList->dwPageStart <= dwSelect &&
				dwSelect < (pCandidateList->dwPageStart + NUMHENKANSHOWCANDIDATES)) {
				pCandidateList->dwSelection	= dwSelect ;
			} else {
				pCandidateList->dwSelection	= pCandidateList->dwPageStart ;
			}
		} else {
			pCandidateList->dwSelection	= dwSelect ;
		}
		pBuffer->_nJHenkanCount		= (int) pCandidateList->dwSelection + 1 ;

		/*	����������� refine ����K�v�����邩������Ȃ��B*/
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
		/*DEBUGPRINTFEX (99, (TEXT ("Select=%d, PageStart=%d\n"),
							(int) pCandidateList->dwSelection,
							(int) pCandidateList->dwPageStart)) ;*/
		break ;
	}
	case	WCH_SETCANDIDATEPAGESTART:
	{
		register int	nPageStart, i ;

		nPageStart	= (int) ImeDoc_GetLastKeyData (pBuffer->_pDoc) ;
		DEBUGPRINTFEX (99, (TEXT ("PageStart = %d\n"), nPageStart)) ;
		if (nPageStart < 0)
			break ;
		THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
		for (i = 0 ; i < nPageStart ; i ++)
			if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession))
				break ;
		pCandidateList->dwPageStart	= nPageStart ;
		pCandidateList->dwSelection	= nPageStart ;
		pBuffer->_nJHenkanCount		= (int) pCandidateList->dwSelection + 1 ;
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
		break ;
	}
#endif
	default:
	{
		int	nFuncNo ;

		if (! ImeDoc_LookupKeymap (pBuffer->_pDoc, wch, &nFuncNo))
			break ;

		/*	space, x, C-g �͂��ꂼ��� key-bind ����ސ�����悤�ɕύX����B
		 */
		switch (nFuncNo) {
		case	FUNCNO_J_PREVIOUS_CANDIDATE:
			/*	ClearMessage �� JPreviousCandidate �̑O�Ɉړ��B
			 *	pBuffer->_pFilterProc = imeBuffer_NormalFilter ����B
			 *	(Tue Feb 15 11:49:48 2005)
			 */
			ImeDoc_ClearMessage (pBuffer->_pDoc) ;
#if defined (DEBUG) || defined (DBG)
			if (! imeBuffer_JPreviousCandidate (pBuffer)) {
				DEBUGPRINTFEX (99, (TEXT ("(line:%d) imeBuffer_JPreviousCandidate failed.\n"), __LINE__)) ;
			}
#else
			imeBuffer_JPreviousCandidate (pBuffer) ;
#endif
			if (pBuffer->_nJHenkanCount <= COUNTHENKANSHOWCHANGE) {
				pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
#if !defined (UNITTEST)
				ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
				TVarbuffer_Clear (pvbufCandInfo) ;
#endif
				fShow	= FALSE ;
				goto	exit_func_1 ;
			}
			/*	�܂����̃��[�h�͌p������B*/
#if !defined (UNITTEST)
			pCandidateList->dwPageStart	-= NUMHENKANSHOWCANDIDATES ;
			pCandidateList->dwSelection	-= NUMHENKANSHOWCANDIDATES ;
			ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
			break ;

		case	FUNCNO_J_START_HENKAN:
			/* nCandidate �͗납�琔���Ă̐��B*/
			nCandidate	= THenkanSession_GetNumberOfCandidate (pBuffer->_pHenkanSession, NULL) ;
			/* _nJHenkanCount �͍ŏ��̌����P�Ɛ�����B*/
			/*	���\�����Ă�����̐擪�� _nJHenkanCount �� nCandidate ���Ɍ����΁A
			 *	_nJHenkanCount - 1 �ł���B
			 *	���� NUMHENKANSHOWCANDIDATES �Ȃ̂ŁA
			 *	_nJHenkanCount - 1 + NUMHENKANSHOWCANDIDATES >= nCandidate �Ȃ��
			 *	�I������B
			 */
			if ((pBuffer->_nJHenkanCount - 1 + NUMHENKANSHOWCANDIDATES) >= nCandidate &&
				! ImeDoc_DisableMinibufferp (pBuffer->_pDoc)) {
				/*	�ċA�o�^�ɓ���B*/
				ImeDoc_ClearMessage (pBuffer->_pDoc) ;
				fRetval	= imeBuffer_JHenkanInMinibuff (pBuffer) ;
#if !defined (UNITTEST)
				ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
				TVarbuffer_Clear (pvbufCandInfo) ;
#endif
				fShow	= FALSE ;
				goto	exit_func_1 ;
			} else {
				nCount	= NUMHENKANSHOWCANDIDATES ;
				/*	���ɐi�߂邾���B*/
				while (nCount -- > 0) {
					pBuffer->_nJHenkanCount	++ ;
#if !defined (UNITTEST)
					pCandidateList->dwPageStart	++ ;
					pCandidateList->dwSelection	++ ;
#endif
					if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) {
						ASSERT (ImeDoc_DisableMinibufferp (pBuffer->_pDoc)) ;
						THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
#if !defined (UNITTEST)
						pCandidateList->dwPageStart	= 0 ;
						pCandidateList->dwSelection	= 0 ;
#endif
						pBuffer->_nJHenkanCount		= 1 ;
						break ;
					}
				}
#if !defined (UNITTEST)
				/*	����������� refine ����K�v�����邩������Ȃ��B*/
				ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
			}
			break ;

		case	FUNCNO_J_KEYBOARD_QUIT:
			goto	j_keyboard_quit ;

		default:
			{
				WCHAR	bufText [256] ;
				int		nText ;

				if (wch > 0x20 && wch != 0x7F) {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"`%c' is not valid here!", wch) ;
				} else {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"0x%02x is not valid here!", wch) ;
				}
				ImeDoc_SetMessageN (pBuffer->_pDoc, bufText, nText) ;
			}
			break ;
		}
		break ;
	}
	/*case	0x07: keyboad-quit ���Ȃ��Ȃ�ƁA�͂܂�H */
	case	WCH_CLOSECANDIDATE:
	  j_keyboard_quit:
		THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
		pBuffer->_nJHenkanCount	= 1 ;
		imeBuffer_JPreviousCandidate (pBuffer) ;
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
#if !defined (UNITTEST)
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
		TVarbuffer_Clear (pvbufCandInfo) ;
#endif
		fShow	= FALSE ;
		goto	exit_func_1 ;
	}

  exit_func_1:
  exit_func:
	if (fShow)
		imeBuffer_ShowJHenkanCandidates (pBuffer) ;
	return	fRetval ;
}

BOOL
imeBuffer_JInputByCodeOrMenuJumpFilter (
	register CImeBuffer*	pBuffer)
{
	register WCHAR			wch	= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	register int			i, iNOrg ;
	register const BYTE*	bptr ;
#if !defined (UNITTEST)
	register TVarbuffer*		pvbufCandInfo ;
	register LPMYCAND			pMyCand ;
	register LPCANDIDATEINFO	pCandInfo ;
	register LPCANDIDATELIST	pCandidateList ;
#endif

	iNOrg	= pBuffer->_nJInputCode1 ;

	bptr	= ImeDoc_GetJInputByCodeOrMenuKeys1 (pBuffer->_pDoc) ;
	for (i = 0 ; i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ; i ++) {
		if (wch == (WCHAR)*(bptr + i)) {
			if (i >= 6) {
				pBuffer->_nJInputCode1	++ ;
				if (pBuffer->_nJInputCode1 > _nJCodeN1Max)
					pBuffer->_nJInputCode1	= _nJCodeN1Min ;
				i	= i - 6 - 1 ;
			} else {
				i	-- ;
			}
			pBuffer->_nJInputByCodeOrMenuJumpDefault	= pBuffer->_nJInputCode1 ;
			return	imeBuffer_JInputByCodeOrMenu1Start (pBuffer, pBuffer->_nJInputCode1, (i < 0)? _nJCodeN1Min : _rnJInputByCodeOrMenuJumpLowordTbl [i]) ;
		}
	}

#if !defined (UNITTEST)
	pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pBuffer->_pDoc) ;
	if (pvbufCandInfo == NULL || TVarbuffer_GetUsage (pvbufCandInfo) < sizeof (MYCAND))
		return	FALSE ;
	pMyCand			= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo		= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandidateList	= (LPCANDIDATELIST)&(pMyCand->cl) ;
#endif
	switch (wch) {
#if !defined (UNITTEST)
	case	WCH_SELECTCANDIDATESTR:
	case	WCH_SETCANDIDATEPAGESTART:
		break ;
#endif
	default:
	{
		WCHAR	bufText [256] ;
		int		nFuncNo ;

		if (! ImeDoc_LookupKeymap (pBuffer->_pDoc, wch, &nFuncNo))
			break ;

		switch (nFuncNo) {
		case	FUNCNO_J_PREVIOUS_CANDIDATE:
			pBuffer->_nJInputCode1 	-= 2 ;
			if (pBuffer->_nJInputCode1 < _nJCodeN1Min) 
				pBuffer->_nJInputCode1	= _nJCodeN1Max ;
#if !defined (UNITTEST)
			if (pBuffer->_nJInputCode1 < _nJCodeN1Min || 
				pBuffer->_nJInputCode1 > _nJCodeN1Max) {
				pCandidateList->dwPageStart	= 0 ;
			} else {
				pCandidateList->dwPageStart	= (pBuffer->_nJInputCode1 - _nJCodeN1Min) * (JINPUTBYCODEORMENU_PAGESIZE / 2) ;
			}
			pCandidateList->dwSelection	= pCandidateList->dwPageStart ;
			ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
			break ;

		case	FUNCNO_J_START_HENKAN:
			pBuffer->_nJInputCode1	+= 2 ;
			if (pBuffer->_nJInputCode1 > _nJCodeN1Max) 
				pBuffer->_nJInputCode1	= pBuffer->_nJInputCode1 - _nJCodeN1Max + _nJCodeN1Min - 1 ;
#if !defined (UNITTEST)
			if (pBuffer->_nJInputCode1 < _nJCodeN1Min || 
				pBuffer->_nJInputCode1 > _nJCodeN1Max) {
				pCandidateList->dwPageStart	= 0 ;
			} else {
				pCandidateList->dwPageStart	= (pBuffer->_nJInputCode1 - _nJCodeN1Min) * (JINPUTBYCODEORMENU_PAGESIZE / 2) ;
			}
			pCandidateList->dwSelection	= pCandidateList->dwPageStart ;
			ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
			break ;

		case	FUNCNO_J_KEYBOARD_QUIT:
			goto	j_keyboard_quit ;

		default:
			{
				int		nText ;

#if !defined (UNITTEST)
				if (wch == 63) {
					LPMYSTR	pwCode ;
					int		nText ;

					if (pCandidateList->dwPageStart < pCandidateList->dwCount) {
						pwCode	= (LPMYSTR)((LPSTR)pCandidateList + pCandidateList->dwOffset [pCandidateList->dwPageStart]) ;
						nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"�w%s�x EUC: %02x%02x (%3d,%3d), JIS: %02x%02x (%3d,%3d)",
							pwCode,
							iNOrg,			_nJCodeN1Min,		iNOrg,			_nJCodeN1Min,
							iNOrg - 128,	_nJCodeN1Min - 128,	iNOrg - 128,	_nJCodeN1Min - 128) ;

						ImeDoc_SetMessageN (pBuffer->_pDoc, bufText, nText) ;
					}
					break ;
				}
#endif
				if (wch > 0x20 && wch != 0x7F) {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"`%c' is not valid here!", wch) ;
				} else {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"0x%02x is not valid here!", wch) ;
				}
				ImeDoc_SetMessageN (pBuffer->_pDoc, bufText, nText) ;
			}
			break ;
		}
		break ;
	}
	case	WCH_CLOSECANDIDATE:
j_keyboard_quit:
#if !defined (UNITTEST)
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
		TVarbuffer_Clear (pvbufCandInfo) ;
#endif
		ImeDoc_ClearMessage (pBuffer->_pDoc) ;
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
		goto	exit_func ;
	}
#if defined (UNITTEST)
	imeBuffer_ShowJInputByCodeOrMenuJump (pBuffer, pBuffer->_nJInputCode1) ;
#endif
  exit_func:
	return	TRUE ;
}

BOOL
imeBuffer_JInputByCodeOrMenu1Filter (
	register CImeBuffer*	pBuffer)
{
	register WCHAR		wch	= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	register const BYTE*	bptr ;
	WCHAR				wchResult ;
	register int		i, n1, n2, iN1Org, iN2Org ;
#if !defined (UNITTEST)
	register TVarbuffer*		pvbufCandInfo ;
	register LPMYCAND			pMyCand ;
	register LPCANDIDATEINFO	pCandInfo ;
	register LPCANDIDATELIST	pCandidateList ;
#endif

#if !defined (UNITTEST)
	pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pBuffer->_pDoc) ;
	if (pvbufCandInfo == NULL || TVarbuffer_GetUsage (pvbufCandInfo) < sizeof (MYCAND))
		return	FALSE ;
	pMyCand			= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo		= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandidateList	= (LPCANDIDATELIST)&(pMyCand->cl) ;
#endif

	n1		= pBuffer->_nJInputCode1 ;
	n2		= pBuffer->_nJInputCode2 ;
	iN1Org	= n1 ;
	iN2Org	= n2 ;
	bptr	= ImeDoc_GetJInputByCodeOrMenuKeys2 (pBuffer->_pDoc) ;
	for (i = 0 ; i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 ; i ++) {
		if (wch == (WCHAR)*(bptr + i)) {
			wchResult	= JCharToUnicode ((WORD)((n1 << 8) | n2)) ;
			imeBuffer_Insert (pBuffer, (wchResult != 0)? &wchResult : L" ", 1) ;
			pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
#if !defined (UNITTEST)
			ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
			TVarbuffer_Clear (pvbufCandInfo) ;
#endif
			ImeDoc_ClearMessage (pBuffer->_pDoc) ;
			return	TRUE ;
		}
		n2	++ ;
		if (n2 > _nJCodeN2Max) {
			n2	= _nJCodeN2Min ;
			n1	++ ;
			if (n1 > _nJCodeN1Max) 
				n1	= _nJCodeN1Min ;
		}
	}

	switch (wch) {
#if !defined (UNITTEST)
	case	WCH_SELECTCANDIDATESTR:
	case	WCH_SETCANDIDATEPAGESTART:
		/*	�܂��R�[�h���Ȃ��B*/
		break ;
#endif
	case	L'>':	/* '<' �� '>' ������ function �Ɋ��蓖�Ă邩����B*/
		n2	= pBuffer->_nJInputCode2 ;
		n2	++ ;
		if (n2 > _nJCodeN2Max) {
			n2	= _nJCodeN2Min ;
			n1	++ ;
			if (n1 > _nJCodeN1Max) 
				n1	= _nJCodeN1Min ;
		}
#if !defined (UNITTEST)
		pCandidateList->dwPageStart	= (n1 - _nJCodeN1Min) * (_nJCodeN2Max - _nJCodeN2Min + 1) + (n2 - _nJCodeN2Min) ;
		pCandidateList->dwSelection	= pCandidateList->dwPageStart ;
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
		break ;

	case	L'<':
		n2	= pBuffer->_nJInputCode2 - 1 ;
		if (n2 < _nJCodeN2Min) {
			n2	= _nJCodeN2Max ;
			n1	-- ;
			if (n1 < _nJCodeN1Min)
				n1	= _nJCodeN1Max ;
		}
#if !defined (UNITTEST)
		pCandidateList->dwPageStart	= (n1 - _nJCodeN1Min) * (_nJCodeN2Max - _nJCodeN2Min + 1) + (n2 - _nJCodeN2Min) ;
		pCandidateList->dwSelection	= pCandidateList->dwPageStart ;
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
		break ;

	default:
	{
		int		nFuncNo ;

		if (! ImeDoc_LookupKeymap (pBuffer->_pDoc, wch, &nFuncNo))
			break ;

		switch (nFuncNo) {
		case	FUNCNO_J_PREVIOUS_CANDIDATE:
			n2	-= 31 ;
			if (n2 < _nJCodeN2Min) {
				n2	+= 94 ;
				n1	-- ;
				if (n1 < _nJCodeN1Min)
					n1	= _nJCodeN1Max ;
			}
#if !defined (UNITTEST)
			pCandidateList->dwPageStart	= (n1 - _nJCodeN1Min) * (_nJCodeN2Max - _nJCodeN2Min + 1) + (n2 - _nJCodeN2Min) ;
			pCandidateList->dwSelection	= pCandidateList->dwPageStart ;
			ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
			break ;

		case	FUNCNO_J_START_HENKAN:
			n2	++ ;
			if (n2 > _nJCodeN2Max) {
				n2	= _nJCodeN2Min ;
				n1	++ ;
				if (n1 > _nJCodeN1Max) 
					n1	= _nJCodeN1Min ;
			}
#if !defined (UNITTEST)
			pCandidateList->dwPageStart	= (n1 - _nJCodeN1Min) * (_nJCodeN2Max - _nJCodeN2Min + 1) + (n2 - _nJCodeN2Min) ;
			pCandidateList->dwSelection	= pCandidateList->dwPageStart ;
			ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_UPDATE_CANDIDATELIST) ;
#endif
			break ;

		case	FUNCNO_J_KEYBOARD_QUIT:
			goto	j_keyboard_quit ;

		default:
			{
				WCHAR	bufText [256] ;
				int		nText ;

#if !defined (UNITTEST)
				if (wch == 63) {
					LPMYSTR	pwCode ;
					int		nText ;

					if (pCandidateList->dwPageStart < pCandidateList->dwCount) {
						pwCode	= (LPMYSTR)((LPSTR)pCandidateList + pCandidateList->dwOffset [pCandidateList->dwPageStart]) ;
						nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"�w%s�x EUC: %02x%02x (%3d,%3d), JIS: %02x%02x (%3d,%3d)",
							pwCode,
							iN1Org,			iN2Org,			iN1Org,			iN2Org,
							iN1Org - 128,	iN2Org - 128,	iN1Org - 128,	iN2Org - 128) ;

						ImeDoc_SetMessageN (pBuffer->_pDoc, bufText, nText) ;
					}
					break ;
				}
#endif
				if (wch > 0x20 && wch != 0x7F) {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"`%c' is not valid here!", wch) ;
				} else {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"0x%02x is not valid here!", wch) ;
				}
				ImeDoc_SetMessageN (pBuffer->_pDoc, bufText, nText) ;
			}
			break ;
		}
		break ;
	}
	case	WCH_CLOSECANDIDATE:
j_keyboard_quit:
		ImeDoc_ClearMessage (pBuffer->_pDoc) ;
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
#if !defined (UNITTEST)
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
		TVarbuffer_Clear (pvbufCandInfo) ;
#endif
		goto	exit_func ;
	}
	pBuffer->_nJInputCode1	= n1 ;
	pBuffer->_nJInputCode2	= n2 ;
#if defined (UNITTEST)
	imeBuffer_ShowJInputByCodeOrMenu1 (pBuffer, n1, n2) ;
#endif
  exit_func:
	return	TRUE ;
}

BOOL
imeBuffer_ExecuteCommand (
	register CImeBuffer*	pBuffer,
	register int			nFuncNo)
{
	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_ExecuteCommand (buf:%p, cmd:%d)\n"), pBuffer, nFuncNo)) ;

	/*	�֐��ɂ���ď�����ύX����B
	 */
	ImeDoc_SetThisCommand (pBuffer->_pDoc, nFuncNo) ;

	switch (nFuncNo) {
	case	FUNCNO_J_KANAINPUT_MODE_ON:
		imeBuffer_JKanaInputModeOn (pBuffer) ;
		break ;
	case	FUNCNO_J_INSERT_A:
		imeBuffer_JInsertA (pBuffer) ;
		break ;
	case	FUNCNO_J_INSERT_I:
		imeBuffer_JInsertI (pBuffer) ;
		break ;
	case	FUNCNO_J_INSERT_U:
		imeBuffer_JInsertU (pBuffer) ;
		break ;
	case	FUNCNO_J_INSERT_E:
		imeBuffer_JInsertE (pBuffer) ;
		break ;
	case	FUNCNO_J_KANA_INPUT:
		imeBuffer_JKanaInput (pBuffer) ;
		break ;
	case	FUNCNO_J_BACKWARD_CHAR:
	case	FUNCNO_J_LEFT_ARROW:
		imeBuffer_BackwardChar (pBuffer) ;
		break ;
	case	FUNCNO_J_FORWARD_CHAR:
	case	FUNCNO_J_RIGHT_ARROW:
		imeBuffer_ForwardChar (pBuffer) ;
		break ;
	case	FUNCNO_J_KEYBOARD_QUIT:
		imeBuffer_JKeyboardQuit (pBuffer) ;
		break ;
	case	FUNCNO_J_START_HENKAN:
		imeBuffer_JStartHenkan (pBuffer) ;
		break ;
	case	FUNCNO_J_SET_HENKAN_POINT:
		imeBuffer_JSetHenkanPoint (pBuffer) ;
		break ;
	case	FUNCNO_J_SET_HENKAN_POINT_SUBR:
		imeBuffer_JSetHenkanPointSubr (pBuffer) ;
		break ;
	case	FUNCNO_J_PREVIOUS_CANDIDATE:
		imeBuffer_JPreviousCandidate (pBuffer) ;
		break ;
	case	FUNCNO_J_NEWLINE:
		imeBuffer_JNewline (pBuffer) ;
		break ;
	case	FUNCNO_J_TRY_COMPLETION:
		imeBuffer_JTryCompletion (pBuffer) ;
		break ;
	case	FUNCNO_J_INSERT_PERIOD:
		imeBuffer_JInsertPeriod (pBuffer) ;
		break ;
	case	FUNCNO_J_INSERT_COMMA:
		imeBuffer_JInsertComma (pBuffer) ;
		break ;
	case	FUNCNO_J_SELF_INSERT:
		imeBuffer_JSelfInsert (pBuffer) ;
		break ;
	case	FUNCNO_J_INPUT_BY_CODE_OR_MENU:
		imeBuffer_JInputByCodeOrMenu (pBuffer) ;
		break ;
	case	FUNCNO_J_ABBREV_INPUT:
		imeBuffer_JAbbrevInput (pBuffer) ;
		break ;
	case	FUNCNO_J_ABBREV_PERIOD:
		imeBuffer_JAbbrevPeriod (pBuffer) ;
		break ;
	case	FUNCNO_J_ABBREV_COMMA:
		imeBuffer_JAbbrevComma (pBuffer) ;
		break ;
	case	FUNCNO_J_TOGGLE_KANA:
		imeBuffer_JToggleKana (pBuffer) ;
		break ;
	case	FUNCNO_J_ZENKAKU_EIJI:
		imeBuffer_JZenkakuEiji (pBuffer) ;
		break ;
	case	FUNCNO_J_ZENKAKU_INSERT:
		imeBuffer_JZenkakuInsert (pBuffer) ;
		break ;
	case	FUNCNO_J_PURGE_FROM_JISYO:
		imeBuffer_JPurgeFromJisyo (pBuffer) ;
		break ;
	case	FUNCNO_J_MODE_OFF:
		imeBuffer_JModeOff (pBuffer) ;
		break ;
	case	FUNCNO_J_DELETE_CHAR:
		imeBuffer_DeleteChar (pBuffer, 1) ;
		break ;
	case	FUNCNO_J_DELETE_BACKWARD_CHAR:
		imeBuffer_JDeleteBackwardChar (pBuffer, 1) ;
		break ;
	case	FUNCNO_J_TODAY:
		imeBuffer_JToday (pBuffer) ;
		break ;
	case	FUNCNO_J_KILL_LINE:
		imeBuffer_KillLine (pBuffer) ;
		break ;
	case	FUNCNO_J_KILL_REGION:
		imeBuffer_KillRegion (pBuffer, -1, -1) ;
		break ;
	case	FUNCNO_J_DELETE_REGION:
		imeBuffer_JDeleteRegion (pBuffer, -1, -1) ;
		break ;
	case	FUNCNO_J_KILL_RING_SAVE:
		imeBuffer_JKillRingSave (pBuffer) ;
		break ;
	case	FUNCNO_J_YANK:
		imeBuffer_Yank (pBuffer) ;
		break ;
	case	FUNCNO_J_BEGINNING_OF_LINE:
		imeBuffer_BeginningOfLine (pBuffer) ;
		break ;
	case	FUNCNO_J_END_OF_LINE:
		imeBuffer_EndOfLine (pBuffer) ;
		break ;
	case	FUNCNO_J_TRANSPOSE_CHARS:
		imeBuffer_TransposeChars (pBuffer) ;
		break ;
	case	FUNCNO_J_SET_MARK_COMMAND:
		imeBuffer_SetMarkCommand (pBuffer) ;
		break ;
	case	FUNCNO_J_ZENKAKU_HENKAN:
		imeBuffer_JZenkakuHenkan (pBuffer) ;
		break ;
	case	FUNCNO_SELF_INSERT_CHARACTER:
		imeBuffer_SelfInsertCharacter (pBuffer) ;
		break ;
	case	FUNCNO_MOUSE_DRAG_REGION:
		imeBuffer_MouseDragRegion (pBuffer) ;
		break ;
	case	FUNCNO_OPENCANDIDATE:
		imeBuffer_OpenCandidate (pBuffer) ;
		break ;
	case	FUNCNO_J_TOGGLE_JISX0201:
		imeBuffer_JToggleJisx0201 (pBuffer) ;
		break ;
	case	FUNCNO_NEWLINE:
		imeBuffer_Newline (pBuffer) ;
		break ;
	case	FUNCNO_SAVEUSERJISYO:
		if (SynchronizeLocalJisyo ())
			ImeDoc_SetMessage (pBuffer->_pDoc, L"Saving skkime-jisyo ... done") ;
		break ;
#if !defined (UNITTEST)
	case	FUNCNO_TOGGLE_IME:
		break ;
#endif
	default:
		break ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JKanaInputModeOn (
	CImeBuffer*		pBuffer)
{
	BOOL	fOffKatakana ;

	ASSERT (pBuffer != NULL) ;

	fOffKatakana	= !pBuffer->_fJHenkanOn && !pBuffer->_fJMode ;
	imeBuffer_JKakutei (pBuffer) ;
	if (fOffKatakana) {
		pBuffer->_fJKatakana	= FALSE ;
		pBuffer->_fJisx0201		= FALSE ;
	}
	return	TRUE ;
}

/*	skk8.6 �� source code ����Ă������Bskk10.62a �̍\���� C ��
 *	�Ă������͓̂���B�s�\�ł͂Ȃ����c�B
 *
 *	���������Ɩ{�̂� 10.62a �x�[�X�ɂ���K�v�����邵�A���̕ύX
 *	�͌�ɂ��邱�Ƃɂ��悤�B
 */
BOOL
imeBuffer_JKanaInput (
	CImeBuffer*		pBuffer)
{
	register CImeDoc*	pDoc	= pBuffer->_pDoc ;
	register WCHAR		chKana ;
	register BOOL		fApply ;
	register int		n ;

	chKana		= (WCHAR) ImeDoc_GetLastCommandChar (pDoc) ;

	if (ImeDoc_IsJKakuteiEarlyp (pBuffer->_pDoc) && pBuffer->_fJHenkanActive)
		imeBuffer_JKakutei (pBuffer) ;

	/*	last-command-char �����B�O��̍Ō�̓��͂� last-command-char
	 *	�ł���B�ŁA�������ȁB
	 */
	/*	�O��̍Ō�̓��͕����� ?o �Ȃ�A
	 */
	fApply	= FALSE ;
	if (ImeDoc_GetLastCommandChar (pBuffer->_pDoc) == L'o') {
		n	= pBuffer->_nbufJPrefix ;
		if (n < MAXPREFIXLEN) {
			pBuffer->_bufJPrefix [n ++]	= chKana ;
			fApply	= (ImeDoc_JAssocRule (pBuffer->_pDoc, pBuffer->_bufJPrefix, n) == NULL) ;
		} else {
			fApply	= TRUE ;
		}
	}
	if (fApply) {
		imeBuffer_JInsertO (pBuffer) ;
		pBuffer->_bufJPrefix [0]	= chKana ;
		pBuffer->_nbufJPrefix		= 1 ;
		imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
	} else {
		pBuffer->_bufJPrefix [0]	= chKana ;
		pBuffer->_nbufJPrefix		= 1 ;
		imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
		imeBuffer_JInsertPrefix (pBuffer, pBuffer->_bufJPrefix, pBuffer->_nbufJPrefix) ;
	} 

	/*	�L�[�̃t�B���^�[������ύX����B*/
	pBuffer->_pFilterProc	= imeBuffer_JKanaInputFilter ;
	return	TRUE ;
}

BOOL
imeBuffer_JToggleKana (
	CImeBuffer*		pBuffer)
{
	if (pBuffer->_fJHenkanOn && !pBuffer->_fJHenkanActive) {
		if (! pBuffer->_fJKatakana) {
			imeBuffer_JKatakanaHenkan (pBuffer) ;
		} else {
			imeBuffer_JHiraganaHenkan (pBuffer) ;
		}
	} else {
		imeBuffer_JKakutei (pBuffer) ;
		pBuffer->_fJKatakana	= ! pBuffer->_fJKatakana ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JToggleJisx0201 (
	CImeBuffer*		pBuffer)
{
	/*	�������[�h�łȂ���΁A�@�\���Ȃ��B*/
	if (! pBuffer->_fJMode)
		return	TRUE ;

	if (pBuffer->_fJHenkanOn && !pBuffer->_fJHenkanActive) {
		if (! pBuffer->_fJisx0201) {
			imeBuffer_JHankanaHenkan (pBuffer) ;
		} else {
			imeBuffer_JZenkanaHenkan (pBuffer) ;
		}
	} else {
		imeBuffer_JKakutei (pBuffer) ;
		pBuffer->_fJisx0201	= ! pBuffer->_fJisx0201 ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JSetHenkanPoint (
	CImeBuffer*		pBuffer)
{
	register WCHAR	chKana ;
	register BOOL	fNormal ;
	WCHAR			chLastChar ;
	register BOOL	fSokuon ;
	register BOOL	fHenkanActive ;

	chKana			= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	fNormal			= (L'A' <= chKana && chKana <= L'Z') ;
	chLastChar		= (WCHAR) (fNormal? (chKana - L'A' + L'a') : chKana) ;
	fSokuon			= (pBuffer->_nbufJPrefix == 1 && pBuffer->_bufJPrefix [0] == chLastChar && chLastChar != L'o') ;
	fHenkanActive	= pBuffer->_fJHenkanActive ;
	if (! pBuffer->_fJHenkanOn || pBuffer->_fJHenkanActive) {
		if (fNormal) {
			imeBuffer_JSetHenkanPointSubr (pBuffer) ;
		} else {
			if (pBuffer->_fJHenkanOn)
				imeBuffer_JSetHenkanPointSubr (pBuffer) ;
			if (fHenkanActive) {
				/*	j-emulate-original-map */
				//_JEmulateOriginalMap () ;
				imeBuffer_SelfInsertCharacter (pBuffer) ;
			} else {
				imeBuffer_JSelfInsert (pBuffer) ;
			}
		}
	} else {
		LPCWSTR		pwstr ;
		int			nwstr ;
		int			p1 ;

		if (fNormal) {
			p1	= imeBuffer_CharAfter (pBuffer, TMarker_GetPosition (pBuffer->_pmkPoint) - 1) ;
			if (! pBuffer->_fJOkurigana && 
				!( TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) != TMarker_GetPosition (pBuffer->_pmkPoint) && 
				   (p1 == L'?' || p1 == L'<' || p1 == L'>') ||
				   (L'0' <= p1 && p1 <= L'9') || 
				   (L'�O' <= p1 && p1 <= L'�X'))) {
				if (ImeDoc_IsSkkProcessOkuriEarlyp (pBuffer->_pDoc)) {
					imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
					nwstr	= imeBuffer_BufferSubstring (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), fSokuon? TMarker_GetPosition (pBuffer->_pmkJKanaStartPoint) : TMarker_GetPosition (pBuffer->_pmkPoint), &pwstr) ;
					memcpy (pBuffer->_bufJHenkanKey, pwstr, nwstr * sizeof (WCHAR)) ;
					pBuffer->_nbufJHenkanKey	= nwstr ;
					if (pBuffer->_nbufJHenkanKey < NELEMENTS (pBuffer->_bufJHenkanKey)) {
						if (fSokuon)
							pBuffer->_bufJHenkanKey [pBuffer->_nbufJHenkanKey ++]	= pBuffer->_fJKatakana? L'�b' : L'��' ;
					}
					if (pBuffer->_nbufJHenkanKey < NELEMENTS (pBuffer->_bufJHenkanKey)) 
						pBuffer->_bufJHenkanKey [pBuffer->_nbufJHenkanKey ++]	= chLastChar ;
					
					if (fSokuon) {
						imeBuffer_JErasePrefix (pBuffer) ;
						imeBuffer_JInsertStr (pBuffer, pBuffer->_fJKatakana? L"�b" : L"��", 1) ;
					}
					imeBuffer_Insert (pBuffer, L" ", 1) ;
					pBuffer->_nbufJPrefix	= 0 ;
					imeBuffer_JHenkan (pBuffer) ;
					imeBuffer_DeleteBackwardChar (pBuffer, fSokuon? 2 : 1) ;
					imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
				} else {
					if (TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) == TMarker_GetPosition (pBuffer->_pmkPoint)) {
					} else {
						if (fSokuon) {
							imeBuffer_JErasePrefix (pBuffer) ;
							imeBuffer_JInsertStr (pBuffer, pBuffer->_fJKatakana ? L"�b" : L"��", 1) ;
							pBuffer->_nbufJPrefix	= 0 ;
						}
						imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJOkuriganaStartPoint, MARKER_J_OKURIGANA_STARTPOINT, pBuffer->_pmkPoint) ;
						imeBuffer_Insert (pBuffer, L"*", 1) ;
						imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
						/*	JInsert �� okuri-char ���ēx�m�F��������ŁA"IwakU" �� "IwaKu" �Ƃ��邩�c�H
						 */
						pBuffer->_wchOkuriChar	= chLastChar ;
						pBuffer->_fJOkurigana	= TRUE ;
					}
				}
			}
		} else {
			imeBuffer_Insert (pBuffer, &chLastChar, 1) ;
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
			nwstr	= imeBuffer_BufferSubstring (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkPoint), &pwstr) ;
			memcpy (pBuffer->_bufJHenkanKey, pwstr, nwstr * sizeof (WCHAR)) ;
			pBuffer->_nbufJHenkanKey	= nwstr ;
			memcpy (pBuffer->_bufJSearchKey, pwstr, nwstr * sizeof (WCHAR)) ;
			pBuffer->_nbufJSearchKey	= nwstr ;
			pBuffer->_nbufJPrefix	= 0 ;
			imeBuffer_JHenkan (pBuffer) ;
		}
	}
	if (fNormal)
		ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, chLastChar) ;
	return	TRUE ;
}

BOOL
imeBuffer_JStartHenkan (
	CImeBuffer*		pBuffer)
{
	if (pBuffer->_fJHenkanOn) {
		pBuffer->_fJMode	= TRUE ;
		if (pBuffer->_fJHenkanActive) {
			imeBuffer_JNextCandidate (pBuffer) ;
		} else {
			LPCWSTR				pwstr ;
			register int		nwstr ;

			if (pBuffer->_nbufJPrefix > 0)
				return	FALSE ;
			if (TMarker_GetPosition (pBuffer->_pmkPoint) < TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint))
				return	FALSE ;

			/*	�ށAnewline ���܂�ł��邩�ǂ����̔���c���B�܂��A�����
			 *	skip ���悤�B
			 */
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;

			nwstr	= imeBuffer_BufferSubstring (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint), &pwstr) ;
			pBuffer->_nbufJHenkanKey	= JHenkanCopy (pBuffer->_bufJHenkanKey, pwstr, nwstr) ;
			pBuffer->_nbufJSearchKey	= imeBuffer_JComputeNumericHenkanKey (pBuffer, pBuffer->_bufJSearchKey, MAXCOMPLEN) ;
			imeBuffer_JHenkan (pBuffer) ;
		}
	} else {
		imeBuffer_JSelfInsert (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JSetHenkanPointSubr (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;

	if (pBuffer->_fJHenkanOn)
		imeBuffer_JKakutei (pBuffer) ;
	if (pBuffer->_nbufJPrefix > 0)
		imeBuffer_JErasePrefix (pBuffer) ;
	imeBuffer_Insert (pBuffer, L"��", 1) ;
	if (pBuffer->_nbufJPrefix > 0) {
		imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, pBuffer->_pmkPoint) ;
		imeBuffer_Insert (pBuffer, pBuffer->_bufJPrefix, pBuffer->_nbufJPrefix) ;
	}
	pBuffer->_fJHenkanOn	= TRUE ;
	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanStartPoint, MARKER_J_HENKAN_STARTPOINT, pBuffer->_pmkPoint) ;
	return	TRUE ;
}

BOOL
imeBuffer_JSelfInsert (
	CImeBuffer*		pBuffer)
{
	WCHAR				wch	;
	register LPCWSTR	wstrWord ;
	int					nstrWord ;

	ASSERT (pBuffer != NULL) ;

	wch			= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	/*	sub-special character �� self-insert �ł��Ȃ��B����͉��z�I�� character 
	 *	�ŁA���̂��Ȃ�����B*/
	if (wch >= SIZE_MYKEYMAP)
		return	FALSE ;

	wstrWord	= ImeDoc_GetSkkInputVector (pBuffer->_pDoc, wch, &nstrWord) ;
	if (nstrWord <= 0) {
		//_JEmulateOriginalMap () ;
		imeBuffer_SelfInsertCharacter (pBuffer) ;
	} else {
		imeBuffer_JInsertStr (pBuffer, wstrWord, nstrWord) ;
	}
	if (pBuffer->_fJHenkanActive)
		imeBuffer_JKakutei (pBuffer) ;
	return	TRUE ;
}

BOOL
imeBuffer_JZenkakuInsert (
	CImeBuffer*		pBuffer)
{
	WCHAR				wch	;
	register LPCWSTR	wstrWord ;
	int					nstrWord ;

	ASSERT (pBuffer != NULL) ;

	wch			= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	wstrWord	= ImeDoc_GetSkkZenkakuVector (pBuffer->_pDoc, wch, &nstrWord) ;
	if (nstrWord <= 0)
		return	TRUE ;
	return	imeBuffer_JInsertStr (pBuffer, wstrWord, nstrWord) ;
}

BOOL
imeBuffer_JModeOff (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	imeBuffer_JKakutei (pBuffer) ;
	pBuffer->_fJMode		= FALSE ;
	pBuffer->_nbufJPrefix	= 0 ;
	pBuffer->_fJZenkaku		= FALSE ;
	pBuffer->_fJAbbrev		= FALSE ;
	return	TRUE ;
}

BOOL
imeBuffer_JZenkakuEiji (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	imeBuffer_JKakutei (pBuffer) ;
	pBuffer->_fJMode		= FALSE ;
	pBuffer->_nbufJPrefix	= 0 ;
	pBuffer->_fJZenkaku		= TRUE ;
	pBuffer->_fJAbbrev		= FALSE ;
	return	TRUE ;
}

BOOL
imeBuffer_JAbbrevInput (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_fJHenkanOn && !pBuffer->_fJHenkanActive)
		return	FALSE ;
	imeBuffer_JKakutei (pBuffer) ;
	imeBuffer_JSetHenkanPointSubr (pBuffer) ;
	pBuffer->_fJAbbrev	= TRUE ;
	return	TRUE ;
}

BOOL
imeBuffer_JInsertA (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	imeBuffer_JInsert (pBuffer, ImeDoc_GetRomaKana (pBuffer->_pDoc, L'a')) ;
	return	TRUE ;
}

BOOL
imeBuffer_JInsertI (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	imeBuffer_JInsert (pBuffer, ImeDoc_GetRomaKana (pBuffer->_pDoc, L'i')) ;
	return	TRUE ;
}

BOOL
imeBuffer_JInsertU (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	imeBuffer_JInsert (pBuffer, ImeDoc_GetRomaKana (pBuffer->_pDoc, L'u')) ;
	return	TRUE ;
}

BOOL
imeBuffer_JInsertE (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	imeBuffer_JInsert (pBuffer, ImeDoc_GetRomaKana (pBuffer->_pDoc, L'e')) ;
	return	TRUE ;
}

BOOL
imeBuffer_JInsertComma (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (ImeDoc_GetLastCommand (pBuffer->_pDoc) == FUNCNO_J_COMPLETION) {
		imeBuffer_JPreviousCompletion (pBuffer) ;
	} else {
		imeBuffer_JSelfInsert (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JInsertPeriod (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (ImeDoc_GetLastCommand (pBuffer->_pDoc) == FUNCNO_J_COMPLETION) {
		ImeDoc_SetThisCommand (pBuffer->_pDoc, FUNCNO_J_COMPLETION) ;
		imeBuffer_JCompletion (pBuffer, FALSE) ;
	} else {
		imeBuffer_JSelfInsert (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JTryCompletion (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_fJHenkanOn && !pBuffer->_fJHenkanActive) {
		/*	 */
		ImeDoc_SetThisCommand (pBuffer->_pDoc, FUNCNO_J_COMPLETION) ;
		imeBuffer_JCompletion (pBuffer, ImeDoc_IsSkkDabbrevLikeCompletion (pBuffer->_pDoc) || ImeDoc_GetLastCommand (pBuffer->_pDoc) != FUNCNO_J_COMPLETION) ;
	} else {
		imeBuffer_SelfInsertCharacter (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JAbbrevPeriod (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (ImeDoc_GetLastCommand (pBuffer->_pDoc) == FUNCNO_J_COMPLETION) {
		ImeDoc_SetThisCommand (pBuffer->_pDoc, FUNCNO_J_COMPLETION) ;
		imeBuffer_JCompletion (pBuffer, FALSE) ;
	} else {
		//_JEmulateOriginalMap () ;
		imeBuffer_SelfInsertCharacter (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JAbbrevComma (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (ImeDoc_GetLastCommand (pBuffer->_pDoc) == FUNCNO_J_COMPLETION) {
		imeBuffer_JPreviousCompletion (pBuffer) ;
	} else {
		//_JEmulateOriginalMap () ;
		imeBuffer_SelfInsertCharacter (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JNewline (
	CImeBuffer*		pBuffer)
{
	register BOOL	fNoNL ;
	register BOOL	fJHenkanOn ;

	ASSERT (pBuffer != NULL) ;

	/*
	 */
	fNoNL		= ImeDoc_IsSkkEggLikeNewlinep (pBuffer->_pDoc) && pBuffer->_fJHenkanOn ;
	fJHenkanOn	= pBuffer->_fJHenkanOn ;

	DEBUGPRINTFEX (100, (TEXT("CImeBuffer::_JNewline() : last-char = 0x%x, no-nl = %d\n"), 
						 (int) ImeDoc_GetLastCommandChar (pBuffer->_pDoc), (int) fNoNL)) ;

	if (pBuffer->_pRecursiveEditSession != NULL) {
		imeBuffer_JKakutei (pBuffer) ;
		if (! fNoNL || ! fJHenkanOn)
			return	imeBuffer_ExitMinibuffer (pBuffer) ;
	} else {
		/*	ASCII, �S�p���[�h�Ȃ�m��͂��Ȃ��B*/
		if (pBuffer->_fJMode)
			imeBuffer_JKakutei (pBuffer) ;
		if (! fNoNL) {
			/*	top buffer �Ȃ� newline �� process ���Ȃ��A
			 *	�� top buffer �Ȃ� unused-event �� newline ��������B*/
			DEBUGPRINTFEX (100, (TEXT("CImeBuffer::_JNewline() -> EmulateOriginalMap()\n"))) ;
			imeBuffer_JEmulateOriginalMap (pBuffer) ;
		}
	}
	return	TRUE ;
}

BOOL
imeBuffer_JKeyboardQuit (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

#if 0
	/*	������ enable ���ƁA�����[�h�̎��� minibuffer �ҏW���Ă���ƁA�L�����Z�����悤
	 *	�Ƃ��� C-g ���������u�Ԃ� minibuffer ���甲���Ă��܂��B
	 */
	if (pBuffer->_nbufJHenkanKey == 0) {
		/*	minibuffer �ϊ����Ȃ�e�̏����ւƐ����߂��B*/
		/*	�����āA�e���� keyboard-quit ����B*/
		if (pBuffer->_pRecursiveEditSession != NULL) 
			return	imeBuffer_AbortRecursiveEdit (pBuffer) ;
	}
#endif
	if (pBuffer->_fJHenkanActive) {
		if (ImeDoc_IsSkkDeleteOkuriWhenQuitp (pBuffer->_pDoc) && pBuffer->_nJOkuriAri) {
			register CTMarker*	pMarker	= imeBuffer_MakeMarker (pBuffer, TRUE) ;
			TMarker_SetPosition (pMarker, pBuffer->_pmkPoint) ;
			pBuffer->_nJHenkanCount	= 1 ;
			imeBuffer_JPreviousCandidate (pBuffer) ;
			imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pMarker), TMarker_GetPosition (pBuffer->_pmkPoint)) ;
			imeBuffer_DeleteMarker (pBuffer, pMarker) ;
		} else {
			pBuffer->_nJHenkanCount	= 1 ;
			imeBuffer_JPreviousCandidate (pBuffer) ;
		}
	} else {
		if (pBuffer->_fJHenkanOn) {
			if (TMarker_GetPosition (pBuffer->_pmkPoint) > TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint))
				imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint)) ;
			imeBuffer_JKakutei (pBuffer) ;
		} else {
			/*	minibuffer �ϊ����Ȃ�e�̏����ւƐ����߂��B*/
			if (pBuffer->_pRecursiveEditSession != NULL) {
				return	imeBuffer_AbortRecursiveEdit (pBuffer) ;
			} else {
				ImeBuffer_Clear (pBuffer) ;
			}
		}
	}
	return	TRUE ;
}

BOOL
imeBuffer_JDeleteBackwardChar (
	CImeBuffer*		pBuffer,
	int				nCount)
{
	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_fJOkurigana) {
		pBuffer->_fJOkurigana	= FALSE ;
		if (pBuffer->_pmkJOkuriganaStartPoint != NULL) {
			register int	nOkuriPos ;
			nOkuriPos		= TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) ;
			if (pBuffer->_nbufComp > nOkuriPos && pBuffer->_bufComp [nOkuriPos] == L'*') {
				imeBuffer_DeleteRegion (pBuffer, nOkuriPos, nOkuriPos + 1) ;
			}
		}
	}
	if (pBuffer->_fJHenkanOn && TMarker_GetPosition (pBuffer->_pmkPoint) == TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint)) {
		pBuffer->_nJHenkanCount	= 0 ;
		imeBuffer_JKakutei (pBuffer) ;
	} else {
		register int	p ;

		if (pBuffer->_fJHenkanActive) {
			ASSERT (pBuffer->_pmkJHenkanEndPoint != NULL) ;
			p	= TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint) ;
			if (! ImeDoc_IsSkkDeleteImpliesKakuteip (pBuffer->_pDoc) && p == TMarker_GetPosition (pBuffer->_pmkPoint)) {
				imeBuffer_JPreviousCandidate (pBuffer) ;
			} else {
				imeBuffer_DeleteBackwardChar (pBuffer, nCount) ;
				/* skk10.62a �y�� ddskk ���� <= �ɕύX�B(Fri Feb 17 12:28:22 2006) */
				if (TMarker_GetPosition (pBuffer->_pmkPoint) <= p)
					imeBuffer_JKakutei (pBuffer) ;
			}
		} else {
			if (pBuffer->_pRecursiveEditSession != NULL) {
				imeBuffer_DeleteBackwardChar (pBuffer, nCount) ;
			} else {
				// _JEmulateOriginalMap () ;
				if (TMarker_GetPosition (pBuffer->_pmkPoint) > 0) {
					imeBuffer_DeleteBackwardChar (pBuffer, nCount) ;
				} else {
					imeBuffer_JEmulateOriginalMap (pBuffer) ;
				}
			}
		}
	}
	return	TRUE ;
}

/*========================================================================
 */
BOOL
imeBuffer_Newline (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_pRecursiveEditSession != NULL) {
		return	imeBuffer_ExitMinibuffer (pBuffer) ;
	} else {
		imeBuffer_JEmulateOriginalMap (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_BackwardChar (
	CImeBuffer*		pBuffer)
{
	register int	nTop ;
	
	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;

	nTop	= (pBuffer->_pmkEditTop == NULL)? 0 : TMarker_GetPosition (pBuffer->_pmkEditTop) ;
	if (TMarker_GetPosition (pBuffer->_pmkPoint) > nTop)
		TMarker_Backward (pBuffer->_pmkPoint, 1) ;
	return	TRUE ;
}

BOOL
imeBuffer_ForwardChar (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;

	if (TMarker_GetPosition (pBuffer->_pmkPoint) < pBuffer->_nbufComp)
		TMarker_Forward (pBuffer->_pmkPoint, 1) ;
	return	TRUE ;
}

BOOL
imeBuffer_DeleteBackwardChar (
	CImeBuffer*			pBuffer,
	register int		nDelete)
{
	register int	nTop ;

	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;

	nTop	= (pBuffer->_pmkEditTop == NULL)? 0 : TMarker_GetPosition (pBuffer->_pmkEditTop) ;
	if (TMarker_GetPosition (pBuffer->_pmkPoint) > nTop)
		return	imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkPoint) - nDelete, TMarker_GetPosition (pBuffer->_pmkPoint)) ;
	return	FALSE ;
}

BOOL
imeBuffer_SelfInsertCharacter (
	CImeBuffer*			pBuffer)
{
	WCHAR		wch	= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;

	/*[����]
	 *	printable �łȂ����̂� insert ���Ȃ����Ƃɂ���
	 *��
	 *	emacs �ɂ͂���Ȑ����͂Ȃ����B
	 */
	if (0x20 <= wch && wch < 0x7F)
		return	imeBuffer_Insert (pBuffer, &wch, 1) ;
	return	FALSE ;
}

BOOL
imeBuffer_TransposeChars (
	CImeBuffer*			pBuffer)
{
	register int	nPoint ;
	WCHAR			wch ;

	ASSERT (pBuffer != NULL) ;

	nPoint	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	
	if (nPoint >= pBuffer->_nbufComp || nPoint < 1) 
		return	FALSE ;

	wch	= pBuffer->_bufComp [nPoint - 1] ;
	imeBuffer_DeleteRegion (pBuffer, nPoint - 1, nPoint) ;
	imeBuffer_ForwardChar (pBuffer) ;
	imeBuffer_Insert (pBuffer, &wch, 1) ;
	return	TRUE ;
}

BOOL
imeBuffer_EndOfLine (
	CImeBuffer*			pBuffer)
{
	register int	nPoint ;

	ASSERT (pBuffer != NULL) ;

	nPoint	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	while (nPoint < pBuffer->_nbufComp) {
		if (pBuffer->_bufComp [nPoint] == L'\n') 
			break ;
		nPoint	++ ;
	}
	return	TMarker_Forward (pBuffer->_pmkPoint, nPoint - TMarker_GetPosition (pBuffer->_pmkPoint)) ;
}

BOOL
imeBuffer_BeginningOfLine (
	CImeBuffer*			pBuffer)
{
	register int	nTop, nPoint ;

	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;

	nTop	= (pBuffer->_pmkEditTop == NULL)? 0 : TMarker_GetPosition (pBuffer->_pmkEditTop) ;
	nPoint	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	if (nPoint > nTop) {
		nPoint	-- ;
		while (nPoint > nTop) {
			if (pBuffer->_bufComp [nPoint] == L'\n') {
				nPoint	++ ;
				break ;
			}
			nPoint	-- ;
		}
		TMarker_Backward (pBuffer->_pmkPoint, TMarker_GetPosition (pBuffer->_pmkPoint) - nPoint) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_SetMarkCommand (
	CImeBuffer*			pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	ImeDoc_SetMessage (pBuffer->_pDoc, L"Mark set") ;
	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkMark, MARKER_MARK, pBuffer->_pmkPoint) ;
	return	TRUE ;
}

/*��	�ҏW���̃e�L�X�g�ɉ��s������\��������̂Œ��ӂ���
 *		���ƁB
 */
BOOL
imeBuffer_KillLine (
	CImeBuffer*			pBuffer)
{
	register int	nPoint, nLast ;

	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;

	nPoint	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	if (pBuffer->_bufComp [nPoint] == L'\n') {
		nLast	= nPoint + 1 ;
	} else {
		imeBuffer_EndOfLine (pBuffer) ;
		nLast	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	}
	return	imeBuffer_KillRegion (pBuffer, nPoint, nLast) ;
}

BOOL
imeBuffer_KillRegion (
	CImeBuffer*			pBuffer,
	register int		nStart,
	register int		nEnd)
{
	register int		nLastCmd ;
	register BOOL		fAppend ;
	WCHAR				rszBuffer [MAXPREFIXLEN] ;
	register LPCWSTR	pSrc ;
	register LPWSTR		pDest ;
	register int		nSrc, nDest ;

	if (nStart < 0 || nEnd < 0) {
		if (pBuffer->_pmkMark == NULL) {
			ImeDoc_SetMessage (pBuffer->_pDoc, L"The mark is not set now") ;
			return	TRUE ;
		}
		nStart		= TMarker_GetPosition (pBuffer->_pmkPoint) ;
		nEnd		= TMarker_GetPosition (pBuffer->_pmkMark) ;
	}
	if (nStart > nEnd) {
		register int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	if (nStart == nEnd || nStart < 0 || nEnd > pBuffer->_nbufComp)
		return	FALSE ;

	nLastCmd	= ImeDoc_GetLastCommand (pBuffer->_pDoc) ;
	fAppend		= (nLastCmd == FUNCNO_J_KILL_REGION)? TRUE : FALSE ;

	/*	�����ŊO�E�����ɉ��s�R�[�h�� \n �������� 0x0D, 0x0A
	 *	�ɕϊ�����K�v������B
	 */
	pSrc	= pBuffer->_bufComp + nStart ;
	nSrc	= nEnd - nStart ;
	pDest	= rszBuffer ;
	nDest	= NELEMENTS (rszBuffer) ;
	while (nSrc > 0 && nDest > 0) {
		if (*pSrc == L'\n') {
			/*	0x0D, 0x0A �Ƒ�������̂łȂ����
			 *	1����������Ȃ����Ƃɂ���B*/
			if (nDest > 1) {
				*pDest ++	= 0x0D ;					
				*pDest ++	= 0x0A ;
				nDest  -= 2 ;
			}
		} else {
			*pDest ++	= *pSrc ;
			nDest -- ;
		}
		pSrc ++ ;
		nSrc -- ;
	}
	SetCutBuffer (rszBuffer, pDest - rszBuffer, fAppend) ;
	imeBuffer_DeleteRegion (pBuffer, nStart, nEnd) ;
	ImeDoc_SetThisCommand (pBuffer->_pDoc, FUNCNO_J_KILL_REGION) ;
	return	TRUE ;
}

BOOL
imeBuffer_JDeleteRegion (
	CImeBuffer*			pBuffer,
	register int		nStart,
	register int		nEnd)
{
	if (nStart < 0 || nEnd < 0) {
		if (pBuffer->_pmkMark == NULL) {
			ImeDoc_SetMessage (pBuffer->_pDoc, L"The mark is not set now") ;
			return	TRUE ;
		}
		nStart		= TMarker_GetPosition (pBuffer->_pmkPoint) ;
		nEnd		= TMarker_GetPosition (pBuffer->_pmkMark) ;
	}
	if (nStart > nEnd) {
		register int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	if (nStart == nEnd || nStart < 0 || nEnd > pBuffer->_nbufComp)
		return	FALSE ;

	imeBuffer_DeleteRegion (pBuffer, nStart, nEnd) ;
	ImeDoc_SetThisCommand (pBuffer->_pDoc, FUNCNO_J_DELETE_REGION) ;
	return	TRUE ;
}

BOOL
imeBuffer_JKillRingSave (
	CImeBuffer*			pBuffer)
{
	if (! imeBuffer_KillRegion (pBuffer, -1, -1) ||
		! imeBuffer_Yank (pBuffer))
		return	FALSE ;
	return	TRUE ;
}

BOOL
imeBuffer_Yank (
	CImeBuffer*			pBuffer)
{
	WCHAR				rszBuffer [MAXPREFIXLEN] ;
	register LPWSTR		wptr, wptrStart ;
	register int		n ;

	n	= GetCutBuffer (rszBuffer, MAXPREFIXLEN) ;
	if (n > 0) {
		wptr	= rszBuffer ;
		while (n > 0) {
			wptrStart	= wptr ;
			while (n > 0 && *wptr != 0x0D) {
				wptr	++ ;
				n		-- ;
			}
			imeBuffer_Insert (pBuffer, wptrStart, wptr - wptrStart) ;

			/*	�O�E�Ƃ̃C���^�[�t�F�[�X�ł��邱�̕����ŉ��s�R�[�h��
			 *	0x0D, 0x0A �Ƃ��Ă���ė���\��������B
			 */
			if (*wptr == 0x0D) {
				if (n > 1 && *(wptr + 1) == 0x0A) {
					while (n > 1 && *wptr == 0x0D && *(wptr + 1) == 0x0A) {
						imeBuffer_Insert (pBuffer, L"\n", 1) ;
						wptr	+= 2 ;
						n		-= 2 ;
					}
				} else {
					/*	0x0D �����̏o���͂��̂܂ܒʂ��B
					 */
					imeBuffer_Insert (pBuffer, wptr, 1) ;
					wptr	++ ;
					n		-- ;
				}
			}
		}
	}
	return	TRUE ;
}

BOOL
imeBuffer_AbortRecursiveEdit (
	CImeBuffer*			pBuffer)
{
	if (pBuffer->_pRecursiveEditSession == NULL)
		return	FALSE ;
	TRecursiveEditSession_Abort (pBuffer->_pRecursiveEditSession, pBuffer) ;
	return	TRUE ;
}

BOOL
imeBuffer_ExitMinibuffer (
	CImeBuffer*			pBuffer)
{
	register LPCWSTR	wstrMessage ;
	register int		nPos, nstrMessage ;

	if (pBuffer->_pRecursiveEditSession == NULL)
		return	FALSE ;

	nPos		= (pBuffer->_pmkEditTop != NULL)? TMarker_GetPosition (pBuffer->_pmkEditTop) : 0 ;
	nstrMessage	= pBuffer->_nbufComp - nPos ;
	wstrMessage	= pBuffer->_bufComp + nPos ;
	TRecursiveEditSession_Exit (pBuffer->_pRecursiveEditSession, pBuffer, wstrMessage, nstrMessage) ;
	return	TRUE ;
}

BOOL
imeBuffer_MouseDragRegion (
	CImeBuffer*			pBuffer)
{
	WCHAR			wch ;
	LPARAM			lParam ;
	register int	nPos, nCount, nLastCmd ;
	BOOL			fEnd ;

	wch		= (WCHAR) ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
	if (wch != WCH_LBUTTON && wch != WCH_RBUTTON)
		return	FALSE ;

	lParam	= ImeDoc_GetLastKeyData (pBuffer->_pDoc) ;
	nPos	= (short)lParam & 0x7FFFFFFFL ;
	fEnd	= (lParam & 0x80000000L) != 0 ;

	/*	�擪�́u�I�v��ǂݔ�΂��Ȃ��Ƃ����Ȃ��̂ŁB�ށA�ł��A���ꂾ�Ɓc�߂�Ȃ��ꏊ��
	 *	�������獢��Ȃ����ȁH
	 */
	if (ImeDoc_RecursiveEditp (pBuffer->_pDoc) && ImeDoc_HaveMessagep (pBuffer->_pDoc))
		nPos	-- ;

	/*	�J�[�\�����w�肳�ꂽ�ʒu�ւƈړ�������B*/
	imeBuffer_BeginningOfLine (pBuffer) ;
	nPos	= (nPos > pBuffer->_nbufComp)? pBuffer->_nbufComp : nPos ;
	nCount	= nPos - TMarker_GetPosition (pBuffer->_pmkPoint) ;
	while (nCount -- > 0) 
		imeBuffer_ForwardChar (pBuffer) ;

	nLastCmd	= ImeDoc_GetLastCommand (pBuffer->_pDoc) ;
	if (nLastCmd != FUNCNO_MOUSE_DRAG_REGION ||
		pBuffer->_pmkMark == NULL) {
		/*	�}�[�N���J�[�\���ʒu�ɐݒ肷��B*/
		imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkMark, MARKER_MARK, pBuffer->_pmkPoint) ;
	}
	if (fEnd) 
		ImeDoc_SetThisCommand (pBuffer->_pDoc, FUNCNO_MOUSE_DRAG_REGION_END) ;
	return	TRUE ;
}

#if !defined (UNITTEST)
BOOL
imeBuffer_OpenCandidate (
	CImeBuffer*			pBuffer)
{
	register int	nCount, i ;

	if (! pBuffer->_fJHenkanOn || ! pBuffer->_fJHenkanActive)
		return	FALSE ;
	if (pBuffer->_pHenkanSession == NULL)
		return	FALSE ;

	/*	���������ɂ���Ď����𓯎��Ɍ������Ȃ��@�\�́A���̏ꍇ�ɂ�
	 *	���O����Ă��܂��B
	 */
	nCount	= pBuffer->_nJHenkanCount - 1 ;
	while (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession))
		break ;
	THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
	for (i = 0 ; i < nCount ; i ++)
		if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession))
			break ;

	pBuffer->_pFilterProc	= imeBuffer_JHenkanShowCandidatesFilter ;
	return	imeBuffer_CreateJHenkanCandidateList (pBuffer, (nCount < 0)? 0 : nCount) ;
}

BOOL
imeBuffer_RevertText (
	CImeBuffer*			pBuffer)
{
	CImeDoc*	pDoc	= pBuffer->_pDoc ;

	DEBUGPRINTFEX (99, (TEXT ("imeBuffer_RevertText (buf:%p)\n"), pBuffer)) ;

	if (pBuffer->_pFilterProc == imeBuffer_JHenkanShowCandidatesFilter) {
#if !defined (UNITTEST)
		TVarbuffer*	pvbufCandInfo ;
#endif
		THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
		pBuffer->_nJHenkanCount	= 1 ;
		imeBuffer_JPreviousCandidate (pBuffer) ;
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
#if !defined (UNITTEST)
		pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pDoc) ;
		if (pvbufCandInfo != NULL)
			TVarbuffer_Clear (pvbufCandInfo) ;
		ImeDoc_ClearMessage (pDoc) ;
#endif
	}

	/*	�����c���� buffer �� minibuffer �ϊ��̒��ɂ���̂Ȃ�A
	 *	�ċA��S��������K�v������B
	 */
	if (pBuffer->_pRecursiveEditSession != NULL) {
		do {
			TRecursiveEditSession_Abort (pBuffer->_pRecursiveEditSession, pBuffer) ;
			pBuffer	= ImeDoc_GetCurrentBuffer (pDoc) ;
		}	while (pBuffer->_pRecursiveEditSession != NULL) ;
	}
	if (pBuffer->_fJHenkanActive)
		imeBuffer_JKeyboardQuit (pBuffer) ;

#if 1
	pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
#endif
	return	TRUE ;
}

BOOL
imeBuffer_CompleteText (
	CImeBuffer*		pBuffer)
{
	CImeDoc*	pDoc	= pBuffer->_pDoc ;
	BOOL		fJMode, fJZenkaku, fJisx0201, fJKatakana ;

	if (pBuffer->_pFilterProc == imeBuffer_JHenkanShowCandidatesFilter) {
#if !defined (UNITTEST)
		TVarbuffer*	pvbufCandInfo ;
#endif
		THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
		pBuffer->_nJHenkanCount	= 1 ;
		imeBuffer_JPreviousCandidate (pBuffer) ;
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
		ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CLOSE_CANDIDATELIST) ;
#if !defined (UNITTEST)
		pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pDoc) ;
		if (pvbufCandInfo != NULL)
			TVarbuffer_Clear (pvbufCandInfo) ;
		ImeDoc_ClearMessage (pDoc) ;
#endif
	}

	/*	�����c���� buffer �� minibuffer �ϊ��̒��ɂ���̂Ȃ�A
	 *	�ċA��S��������K�v������B
	 */
	if (pBuffer->_pRecursiveEditSession != NULL) {
		do {
			TRecursiveEditSession_Abort (pBuffer->_pRecursiveEditSession, pBuffer) ;
			pBuffer	= ImeDoc_GetCurrentBuffer (pDoc) ;
		}	while (pBuffer->_pRecursiveEditSession != NULL) ;
	}

	/*	�m�肷��B�������A�ϊ����[�h�͈ێ�����B
	 */
	fJMode		= pBuffer->_fJMode ;
	fJZenkaku	= pBuffer->_fJZenkaku ;
	fJisx0201	= pBuffer->_fJisx0201 ;
	fJKatakana	= pBuffer->_fJKatakana ;
	imeBuffer_JKakutei (pBuffer) ;
	pBuffer->_fJMode	= fJMode ;
	pBuffer->_fJZenkaku	= fJZenkaku ;
	pBuffer->_fJisx0201	= fJisx0201 ;
	pBuffer->_fJKatakana= fJKatakana ;	
	return	TRUE ;
}
#endif

/*========================================================================
 */
BOOL
imeBuffer_JKakutei (
	CImeBuffer*			pBuffer)
{
	register int	nPos ;

	ASSERT (pBuffer != NULL) ;

	pBuffer->_fJMode		= TRUE ;
	pBuffer->_fJZenkaku		= FALSE ;
	pBuffer->_fJAbbrev		= FALSE ;
	pBuffer->_nbufJPrefix	= 0 ;
	if (pBuffer->_fJHenkanOn) {
		if (pBuffer->_fJHenkanActive &&
			pBuffer->_nJHenkanCount > 0 &&
			pBuffer->_pHenkanSession != NULL) {
			register LPCWSTR	wstrResult ;

			wstrResult	= THenkanSession_GetReferCandidate (pBuffer->_pHenkanSession) ;
			DEBUGPRINTFEX (103, (TEXT ("JKakutei (refer-> \"%s\"\n"), wstrResult? wstrResult : L"")) ;
			if (wstrResult != NULL) {
				/*	�ށA����� #4 �ϊ�����Ă���B#4 �̏�Ԃ̂�o�^����B*/
				imeBuffer_JUpdateJisyo (pBuffer, wstrResult, lstrlenW (wstrResult), TRUE) ;
				/*	���� #4 �ɑ������镔����o�^���Ȃ���΂Ȃ�Ȃ��c�B*/
				imeBuffer_JSharp4UpdateJisyo (pBuffer, TRUE) ;
			} else {
				wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
				if (wstrResult != NULL) 
					imeBuffer_JUpdateJisyo (pBuffer, wstrResult, lstrlenW (wstrResult), TRUE) ;
			}
			/*	�ǂ݉����ƕϊ����ʂ̑Ή���������B*/
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJReadingStartPoint, MARKER_J_READING_STARTPOINT, pBuffer->_pmkJHenkanStartPoint) ;
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJReadingEndPoint, MARKER_J_READING_ENDPOINT, pBuffer->_pmkJHenkanEndPoint) ;
			/*	�ǂݕ������ݒ肷��B*/
			pBuffer->_nbufJReadingText	= pBuffer->_nbufJHenkanKey ;
			if (pBuffer->_nbufJHenkanKey2 > 0)
				pBuffer->_nbufJReadingText	-- ;
			if (pBuffer->_nbufJReadingText > 0)
				memcpy (pBuffer->_bufJReadingText, pBuffer->_bufJHenkanKey, pBuffer->_nbufJReadingText * sizeof (WCHAR)) ;
		}
		nPos	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) - 1 ;
		if (pBuffer->_fJHenkanActive) {
			if (0 <= nPos && nPos < pBuffer->_nbufComp &&
				pBuffer->_bufComp [nPos] == L'��') 
				imeBuffer_DeleteCharEx (pBuffer, nPos, 1) ;
		} else {
			if (0 <= nPos && nPos < pBuffer->_nbufComp &&
				pBuffer->_bufComp [nPos] == L'��') 
				imeBuffer_DeleteCharEx (pBuffer, nPos, 1) ;
		}
		if (pBuffer->_fJOkurigana) {
			nPos	= TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) ;
			if (0 <= nPos && nPos < pBuffer->_nbufComp &&
				pBuffer->_bufComp [nPos] == L'*') 
				imeBuffer_DeleteCharEx (pBuffer, nPos, 1) ;
		}
		pBuffer->_fJAbbrev		= FALSE ;
	}
	if (pBuffer->_pHenkanSession != NULL) {
		THenkanSession_Uninit (pBuffer->_pHenkanSession) ;
		pBuffer->_pHenkanSession	= NULL ;
	}
	pBuffer->_fJHenkanActive		= FALSE ;
	pBuffer->_fJHenkanOn			= FALSE ;
	pBuffer->_nJHenkanCount			= 0 ;
	pBuffer->_fJOkurigana			= FALSE ;
	pBuffer->_wchOkuriChar			= 0 ;
	pBuffer->_nbufJHenkanKey		= 0 ;
	pBuffer->_nbufJHenkanKey2		= 0 ;
	pBuffer->_nbufJHenkanOkurigana	= 0 ;
	/* j-henkan-vector, j-henkan-count */
	pBuffer->_nbufJSearchKey		= 0 ;
	pBuffer->_nJOkuriIndexMin		= 0 ;
	pBuffer->_nJOkuriIndexMax		= 0 ;
	/* j-num-list */
	pBuffer->_nbufJNumList			= 0 ;
	return	TRUE ;
}

BOOL
imeBuffer_JCompletion (
	CImeBuffer*			pBuffer,
	register BOOL		fFirst)
{
	LPCWSTR				wstrCompWord ;
	int					nstrCompWord ;
	register LPCWSTR	wstrResult ;
	register LPWSTR		pDest ;
	register int		nDest, n ;

	ASSERT (pBuffer != NULL) ;

	if (fFirst) {
		if (pBuffer->_pHenkanSession != NULL) {
			THenkanSession_Uninit (pBuffer->_pHenkanSession) ;
			pBuffer->_pHenkanSession	= NULL ;
		}
		nstrCompWord	= imeBuffer_BufferSubstring (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkPoint), &wstrCompWord) ;
		if (nstrCompWord <= 0) {
			ImeDoc_SetMessage (pBuffer->_pDoc, L"Cannot complete an empty string!") ;
			return	TRUE ;
		}
		pBuffer->_pHenkanSession	= TCompletionSession_Init (wstrCompWord, nstrCompWord) ;
		if (pBuffer->_pHenkanSession == NULL)
			return	FALSE ;
		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
	} else {
		if (pBuffer->_pHenkanSession == NULL)
			return	FALSE ;
		if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) {
			wstrResult	= NULL ;
		} else {
			wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
		}
		wstrCompWord	= THenkanSession_GetKeyword (pBuffer->_pHenkanSession, &nstrCompWord) ;
	}
	if (wstrResult == NULL) {
		WCHAR	bufMsg [MAXCOMPLEN] ;

		pDest	= bufMsg ;
		nDest	= NELEMENTS (bufMsg) ;
		n		= wnsprintfW (pDest, nDest - 1, L"No %s compleitions for \"", fFirst? L"" : L"more") ;
		pDest	+= n ;
		nDest	-= n ;
		n		= (nDest < nstrCompWord)? nDest : nstrCompWord ;
		memcpy (pDest, wstrCompWord, n * sizeof (WCHAR)) ;
		pDest	+= n ;
		nDest	-= n ;
		if (nDest > 0) {
			*pDest ++	= L'\"' ;
			nDest	-- ;
		}
		ImeDoc_SetMessageN (pBuffer->_pDoc, bufMsg, pDest - bufMsg) ;
	} else {
		imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkPoint)) ;
		imeBuffer_Insert (pBuffer, wstrResult, lstrlenW (wstrResult)) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JPreviousCompletion (
	CImeBuffer*		pBuffer)
{
	register LPCWSTR	wstrResult ;

	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_pHenkanSession == NULL)
		return	FALSE ;

	if (! THenkanSession_PreviousCandidate (pBuffer->_pHenkanSession)) {
		wstrResult	= NULL ;
	} else {
		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
	}
	if (wstrResult == NULL) {
		ImeDoc_SetMessage (pBuffer->_pDoc, L"No more previous completions.") ;
	} else {
		ASSERT (pBuffer->_pmkJHenkanStartPoint != NULL) ;
		imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkPoint)) ;
		imeBuffer_Insert (pBuffer, wstrResult, lstrlenW (wstrResult)) ;
	}
	ImeDoc_SetThisCommand (pBuffer->_pDoc, FUNCNO_J_COMPLETION) ;
	return	TRUE ;
}

BOOL
imeBuffer_JPurgeFromJisyo (
	CImeBuffer*		pBuffer)
{
	WCHAR			rszPurgeMessage [256] ;
	register LPWSTR	wptr ;
	register int	nptr, n ;

	ASSERT (pBuffer != NULL) ;

	/*	minibuffer ���������� purge �͎��s�ł��Ȃ��Bor �ⓚ���p�� purge
	 *	�̂����ꂩ�Ȃ̂����u���͎��s�ł��Ȃ��v�ɓ|���Ă����B
	 */
	if (ImeDoc_DisableMinibufferp (pBuffer->_pDoc))
		return	TRUE ;

	if (pBuffer->_fJHenkanActive && pBuffer->_nbufJHenkanKey > 0) {
		register CImeBuffer*	pChildBuffer ;
		register LPCWSTR	wstrHenkanKey ;
		register int		nstrHenkanKey ;
		register LPCWSTR	wstrResult ;
		register int		nstrResult ;
		WCHAR				wszBuffer [MAXCOMPLEN] ;

		if (pBuffer->_pHenkanSession == NULL)
			return	FALSE ;
		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
		if (wstrResult == NULL)
			return	FALSE ;

		if (ImeDoc_IsSkkKatakanaHiraganaHenkanp (pBuffer->_pDoc)) {
			if (pBuffer->_fJOkurigana) {
				nstrHenkanKey	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufJHenkanKey, pBuffer->_nbufJHenkanKey) ;
			} else {
				nstrHenkanKey	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufJSearchKey, pBuffer->_nbufJSearchKey) ;
			}
			wstrHenkanKey	= wszBuffer ;
		} else {
			if (pBuffer->_fJOkurigana) {
				wstrHenkanKey	= pBuffer->_bufJHenkanKey ;
				nstrHenkanKey	= pBuffer->_nbufJHenkanKey ;
			} else {
				wstrHenkanKey	= pBuffer->_bufJSearchKey ;
				nstrHenkanKey	= pBuffer->_nbufJSearchKey ;
			}
		}

		wptr	= rszPurgeMessage ;
		nptr	= NELEMENTS (rszPurgeMessage) ;
		lstrcpyW (wptr, L"Really Purge \"") ;
		n		= lstrlenW (wptr) ;
		wptr	+= n ;
		nptr	-= n ;
		n		= (nptr < nstrHenkanKey)? nptr : nstrHenkanKey ;
		lstrncpyW (wptr, wstrHenkanKey, n) ;
		wptr	+= n ;
		nptr	-= n ;
		if (nptr > 0) {
			*wptr ++ = L' ' ;
			nptr	-- ;
		}
		if (nptr > 0) {
			*wptr ++ = L'/' ;
			nptr	-- ;
		}
		nstrResult	= lstrlenW (wstrResult) ;
		n			= (nptr < nstrResult)? nptr : nstrResult ;
		if (nptr > 0) {
			lstrncpyW (wptr, wstrResult, n) ;
			wptr	+= n ;
			nptr	-= n ;
		}
		if (nptr > 0) 
			lstrncpyW (wptr, L"/\"?(yes or no)", nptr) ;
		rszPurgeMessage [NELEMENTS (rszPurgeMessage) - 1]	= L'\0' ;

		/*	minibuffer �𗘗p���� yes �� no ������͂�����B
		 *	���̌��ʂ̏����� CJPurgeSession ���S���B*/
		TRecursiveEditSession_Init (&pBuffer->_RecursiveEditSession, pBuffer, JPurgeSession_OnExit, JPurgeSession_OnAbort) ;
		if (! ImeDoc_ReadFromMinibuffer (pBuffer->_pDoc, rszPurgeMessage, lstrlenW (rszPurgeMessage), &pBuffer->_RecursiveEditSession))
			return	FALSE ;
		/*	minibuffer �ł͉������͂̃f�t�H���g�������Ă����B*/
		pChildBuffer	= ImeDoc_GetCurrentBuffer (pBuffer->_pDoc) ;
		if (pChildBuffer == NULL)
			return	FALSE ;
		return	imeBuffer_JModeOff (pChildBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JHenkan (
	CImeBuffer*		pBuffer)
{
	register LPCWSTR	wstrResult	= NULL ;

	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_nbufJHenkanKey == 0) {
		imeBuffer_JKakutei (pBuffer) ;
		return	TRUE ;
	}

	/*	save-excursion �ɂ���Ď���Ă���̈�B
	 *	==> point, mark, current buffer �������B
	 */
	if (! pBuffer->_fJHenkanActive) {
		imeBuffer_JChangeMarker (pBuffer) ;
		pBuffer->_fJHenkanActive	= TRUE ;

		if (pBuffer->_pHenkanSession != NULL) {
			THenkanSession_Uninit (pBuffer->_pHenkanSession) ;
			pBuffer->_pHenkanSession	= NULL ;
		}
		if (ImeDoc_IsSkkKatakanaHiraganaHenkanp (pBuffer->_pDoc)) {
			WCHAR	wszBuffer [MAXCOMPLEN] ;
			int		n ;

			if (pBuffer->_fJOkurigana) {
				n	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufJHenkanKey, pBuffer->_nbufJHenkanKey) ;
				pBuffer->_pHenkanSession	= TOkuriHenkanSession_Init (wszBuffer, n) ;
			} else {
				n	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufJSearchKey, pBuffer->_nbufJSearchKey) ;
				pBuffer->_pHenkanSession	= THenkanSession_Init (wszBuffer, n) ;
			}
		} else {
			if (pBuffer->_fJOkurigana) {
				pBuffer->_pHenkanSession	= TOkuriHenkanSession_Init (pBuffer->_bufJHenkanKey, pBuffer->_nbufJHenkanKey) ;
			} else {
				pBuffer->_pHenkanSession	= THenkanSession_Init (pBuffer->_bufJSearchKey, pBuffer->_nbufJSearchKey) ;
			}
		}
		if (pBuffer->_pHenkanSession == NULL)
			return	FALSE ;
		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
		pBuffer->_nJHenkanCount	= (wstrResult != NULL)? 1 : 0 ;
	} else {
		if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) {
			wstrResult	= NULL ;
		} else {
			wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
			pBuffer->_nJHenkanCount	++ ;
		}
	}
	if (wstrResult != NULL) {
		if (pBuffer->_nJHenkanCount > COUNTHENKANSHOWCHANGE) {
			imeBuffer_ShowJHenkanCandidates (pBuffer) ;
			pBuffer->_pFilterProc	= imeBuffer_JHenkanShowCandidatesFilter ;
			return	TRUE ;
		}
	}
	if (wstrResult == NULL) {
		if (! ImeDoc_DisableMinibufferp (pBuffer->_pDoc)) {
			/*	�ċA�ϊ����s���B*/
			imeBuffer_JHenkanInMinibuff (pBuffer) ;
			return	TRUE ;
		} else {
			/*	1�ł���₪�o�Ă����̂Ȃ�A�ŏ��ɖ߂��B*/
			if (THenkanSession_GetNumberOfCandidate (pBuffer->_pHenkanSession, NULL) > 0) {
				THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
				wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
				pBuffer->_nJHenkanCount	= (wstrResult != NULL)? 1 : 0 ;
			}
		}
	}
	if (wstrResult != NULL) {
		register CTMarker*	pMkKanaStartPoint	= NULL ;
		register CTMarker*	pMkOkuriStartPoint	= NULL ;
		register CTMarker*	pMkHenkanEndPoint	= NULL ;

		if (pBuffer->_pmkJKanaStartPoint != NULL) {
			pMkKanaStartPoint	= imeBuffer_MakeMarker (pBuffer, TRUE) ;
			TMarker_SetPosition (pMkKanaStartPoint, pBuffer->_pmkJKanaStartPoint) ;
		}
		if (pBuffer->_pmkJOkuriganaStartPoint != NULL) {
			pMkOkuriStartPoint	= imeBuffer_MakeMarker (pBuffer, TRUE) ;
			TMarker_SetPosition (pMkOkuriStartPoint, pBuffer->_pmkJOkuriganaStartPoint) ;
		}
		pMkHenkanEndPoint	= imeBuffer_MakeMarker (pBuffer, TRUE) ;
		imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
		TMarker_SetPosition (pMkHenkanEndPoint, pBuffer->_pmkJHenkanStartPoint) ;
		imeBuffer_JInsertWord (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), wstrResult, lstrlenW (wstrResult)) ;
		TMarker_SetPosition (pBuffer->_pmkJHenkanEndPoint, pMkHenkanEndPoint) ;
		imeBuffer_DeleteMarker (pBuffer, pMkHenkanEndPoint) ;
		if (pMkOkuriStartPoint != NULL) {
			TMarker_SetPosition (pBuffer->_pmkJOkuriganaStartPoint, pMkOkuriStartPoint) ;
			imeBuffer_DeleteMarker (pBuffer, pMkOkuriStartPoint) ;
		}
		if (pMkKanaStartPoint != NULL) {
			TMarker_SetPosition (pBuffer->_pmkJKanaStartPoint, pMkKanaStartPoint) ;
			imeBuffer_DeleteMarker (pBuffer, pMkKanaStartPoint) ;
		}
	}
	return	TRUE ;
}

BOOL
imeBuffer_JSetOkurigana (
	CImeBuffer*		pBuffer)
{
	register int	nOkuriPos, n, nHenkanStartPoint, nHenkanEndPoint ;

	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkJOkuriganaStartPoint != NULL) ;
	ASSERT (pBuffer->_pmkJHenkanStartPoint != NULL) ;

	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkJOkuriganaStartPoint) ;
	nOkuriPos	= TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) ;
	if (0 <= nOkuriPos && nOkuriPos < pBuffer->_nbufComp && 
		pBuffer->_bufComp [nOkuriPos] != L'*') {
		imeBuffer_Insert (pBuffer, L"*", 1) ;
		nOkuriPos	= TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) ;
	}

	nHenkanStartPoint	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) ;
	nHenkanEndPoint		= TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint) ;
	n					= nHenkanEndPoint - nHenkanStartPoint ;
	if (n >= 0) {
		pBuffer->_nbufJHenkanKey2	= JHenkanCopy (pBuffer->_bufJHenkanKey2, pBuffer->_bufComp + nHenkanStartPoint, n) ;
		pBuffer->_bufJHenkanKey2 [pBuffer->_nbufJHenkanKey2 ++]	= L'*' ;
		pBuffer->_nbufJHenkanKey	= JHenkanCopy (pBuffer->_bufJHenkanKey, pBuffer->_bufComp + nHenkanStartPoint, n) ;
		pBuffer->_bufJHenkanKey [pBuffer->_nbufJHenkanKey ++]	= pBuffer->_wchOkuriChar ;
	} else {
		pBuffer->_nbufJHenkanKey2	= 0 ;	/* �c�G���[���H */
	}
	n	= TMarker_GetPosition (pBuffer->_pmkPoint) - nOkuriPos - 1 ;
	if (n >= 0) {
		memcpy (pBuffer->_bufJHenkanOkurigana, pBuffer->_bufComp + nOkuriPos + 1,  n * sizeof (WCHAR)) ;
		pBuffer->_nbufJHenkanOkurigana	= n ;

		n	= ((pBuffer->_nbufJHenkanKey2 + n) > MAXCOMPLEN)? (MAXCOMPLEN - pBuffer->_nbufJHenkanKey2) : n ;
		memcpy (pBuffer->_bufJHenkanKey2 + pBuffer->_nbufJHenkanKey2, pBuffer->_bufJHenkanOkurigana, n * sizeof (WCHAR)) ;
		pBuffer->_nbufJHenkanKey2	+= n ;
	} else {
		pBuffer->_nbufJHenkanOkurigana	= 0 ;
	}
	pBuffer->_nbufJPrefix	= 0 ;
	pBuffer->_wchOkuriChar	= L'\0' ;
	imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint), TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) + 1) ;
	imeBuffer_JHenkan (pBuffer) ;
	pBuffer->_fJOkurigana	= FALSE ;
	return	TRUE ;
}

BOOL
imeBuffer_JNextCandidate (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJHenkanActive)
		return	FALSE ;
	if (pBuffer->_pHenkanSession == NULL)
		return	FALSE ;
	return	imeBuffer_JHenkan (pBuffer) ;
}

BOOL
imeBuffer_JPreviousCandidate (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_fJHenkanActive && pBuffer->_nbufJHenkanKey > 0) {
		if (pBuffer->_nJHenkanCount <= 1) {
			register CTMarker*	pMarker ;

			pBuffer->_fJHenkanActive		= FALSE ;
			pBuffer->_nJHenkanCount			= 0 ;
			pBuffer->_nJOkuriIndexMin		= 0 ;
			pBuffer->_nJOkuriIndexMax		= 0 ;
			pBuffer->_fJOkurigana			= FALSE ;
			pBuffer->_nbufJHenkanOkurigana	= 0 ;
			pBuffer->_nbufJHenkanKey2		= 0 ;
			if (pBuffer->_pHenkanSession != NULL) {
				THenkanSession_Uninit (pBuffer->_pHenkanSession) ;
				pBuffer->_pHenkanSession	= NULL ;
			}
			imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
			pMarker		= imeBuffer_MakeMarker (pBuffer, TRUE) ;
			if (pMarker != NULL)
				TMarker_SetPosition (pMarker, pBuffer->_pmkPoint) ;
			TMarker_SetPosition (pBuffer->_pmkPoint, pBuffer->_pmkJHenkanEndPoint) ;
			if (! pBuffer->_fJAbbrev &&
				pBuffer->_nbufJHenkanKey > 0 &&
				L'a' <= pBuffer->_bufJHenkanKey [pBuffer->_nbufJHenkanKey - 1] &&
				pBuffer->_bufJHenkanKey [pBuffer->_nbufJHenkanKey - 1] <= L'z') {
				pBuffer->_nbufJHenkanKey	-- ;
			}
			imeBuffer_Insert (pBuffer, pBuffer->_bufJHenkanKey, pBuffer->_nbufJHenkanKey) ;
			imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
			imeBuffer_JChangeMarkerToWhite (pBuffer) ;
			if (pMarker != NULL) {
				TMarker_SetPosition (pBuffer->_pmkPoint, pMarker) ;
				imeBuffer_DeleteMarker (pBuffer, pMarker) ;
			}
		} else {
			register LPCWSTR	wstrResult ;
			register int		nstrResult ;
			register int		nCount ;
			
			nCount	= (pBuffer->_nJHenkanCount < (NUMHENKANSHOWCANDIDATES + 1))? 1 : NUMHENKANSHOWCANDIDATES ;
			while (nCount -- > 0) {
				if (! THenkanSession_PreviousCandidate (pBuffer->_pHenkanSession)) {
					DEBUGPRINTFEX (99, (TEXT ("(line:%d) THenkanSession_PreviousCandidate failed. nCount(%d), _nJHenkanCount(%d)\n"), __LINE__, nCount, pBuffer->_nJHenkanCount)) ;
					return	FALSE ;
				}
				pBuffer->_nJHenkanCount	-- ;
			}
			if (pBuffer->_nJHenkanCount > COUNTHENKANSHOWCHANGE)
				return	TRUE ;
			wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
			if (wstrResult == NULL)
				return	FALSE ;
			imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
			nstrResult	= lstrlenW (wstrResult) ;
			if (nstrResult > 0) 
				imeBuffer_JInsertWord (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), wstrResult, nstrResult) ;
		}
	} else {
		imeBuffer_JKanaInput (pBuffer) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JToday (
	CImeBuffer*		pBuffer)
{
	WCHAR	rszBuffer [64] ;
	int		n, nDateAd, nNumberStyle ;

	ASSERT (pBuffer != NULL) ;

	nDateAd			= ImeDoc_GetSkkDateAd (pBuffer->_pDoc) ;
	nNumberStyle	= ImeDoc_GetSkkNumberStyle (pBuffer->_pDoc) ;
	n	= JDateString (rszBuffer, NELEMENTS (rszBuffer), nDateAd, nNumberStyle) ;
	return	imeBuffer_Insert (pBuffer, rszBuffer, n) ;
}

BOOL
imeBuffer_JInsert (
	CImeBuffer*		pBuffer,
	register CTRomaKanaTable*	pTable)
{
	register const CTRomaKanaTableEntry*	pEntry ;
	register LPCWSTR	wstr ;

	ASSERT (pBuffer != NULL) ;

	pEntry	= TRomaKanaTable_Lookup (pTable, pBuffer->_bufJPrefix, pBuffer->_nbufJPrefix) ;
	if (pEntry == NULL) {
		/* [BEGIN] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
		/*	���艼���̊J�n�ʒu�ɂ� ``*'' ������BPrefix �͏����Ă���̂ŁA
		 *		����*
		 *	�̌`�ɂȂ�B
		 */
		if (pBuffer->_fJOkurigana && 
			pBuffer->_pmkJOkuriganaStartPoint != NULL &&
			pBuffer->_pmkJKanaStartPoint != NULL &&
			(TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) + 1) == TMarker_GetPosition (pBuffer->_pmkJKanaStartPoint)) {
			/*	Prefix + LastCommandChar �̕ϊ��Ɏ��s���Ă���̂ŁA
			 *	okuri-char �� prefix �̒��ł͂Ȃ� last-command-char ��
			 *	���ɂ���Ɛ�������B
			 */
			pBuffer->_wchOkuriChar	= ImeDoc_GetLastCommandChar (pBuffer->_pDoc) ;
		}
		/* [END] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
		pBuffer->_nbufJPrefix	= 0 ;
		/*	���[�ށA���̃R�[�h�͔��˂���댯�����邪�c�B*/
		ImeDoc_SetUnreadCommandChar (pBuffer->_pDoc, ImeDoc_GetLastCommandChar (pBuffer->_pDoc)) ;
		return	TRUE ;

		/* [BEGIN] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
	} else {
		if (pBuffer->_fJOkurigana && pBuffer->_pmkJOkuriganaStartPoint != NULL &&
			pBuffer->_nbufJPrefix > 0 &&
			pBuffer->_pmkJKanaStartPoint != NULL &&
			(TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) + 1) == TMarker_GetPosition (pBuffer->_pmkJKanaStartPoint)) {
			/*	Prefix �̒��ɂ������Ɖ��肷��B�����A���̕���p���ǂ߂Ȃ��̂Łc
			 *	�e�X�g���K�v���B
			 */
			pBuffer->_wchOkuriChar	= pBuffer->_bufJPrefix [0] ;
		}
		/* [END] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
	}
	/* j-kakutei-early ���� j-henkan-active �Ȃ� j-kakutei */
	if (ImeDoc_IsJKakuteiEarlyp (pBuffer->_pDoc) && pBuffer->_fJHenkanActive)
		imeBuffer_JKakutei (pBuffer) ;

	wstr	= pBuffer->_fJKatakana? TRomaKanaTableEntry_GetKatakana (pEntry) : TRomaKanaTableEntry_GetHiragana (pEntry) ;
	imeBuffer_JInsertStr (pBuffer, wstr, lstrlenW (wstr)) ;
	if (pBuffer->_fJOkurigana) {
		imeBuffer_JSetOkurigana (pBuffer) ;
	} else {
		pBuffer->_nbufJPrefix	= 0 ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JInsertO (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	imeBuffer_JInsert (pBuffer, ImeDoc_GetRomaKana (pBuffer->_pDoc, L'o')) ;
	return	TRUE ;
}

BOOL
imeBuffer_JErasePrefix (
	CImeBuffer*		pBuffer)
{
	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkJKanaStartPoint != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;
	imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJKanaStartPoint), TMarker_GetPosition (pBuffer->_pmkPoint)) ;
	return	TRUE ;
}

BOOL
imeBuffer_JInsertPrefix (
	CImeBuffer*			pBuffer,
	register LPCWSTR	wstr,
	register int		nwstr)
{
	ASSERT (pBuffer != NULL) ;

	return	imeBuffer_Insert (pBuffer, wstr, nwstr) ;
}

BOOL
imeBuffer_JInsertStr (
	CImeBuffer*			pBuffer,
	register LPCWSTR	wstr,
	register int		nwstr)
{
	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_fJisx0201) {
		WCHAR		wszBuf [16] ;
		int			n ;
		
		while (nwstr > 0) {
			n	= JZenkana2Hankana (wszBuf, NELEMENTS (wszBuf), wstr, 1) ;
			if (! imeBuffer_Insert (pBuffer, wszBuf, n))
				return	FALSE ;
			wstr	++ ;
			nwstr	-- ;
		}
		return	TRUE ;
	}
	return	imeBuffer_Insert (pBuffer, wstr, nwstr) ;
}

BOOL
imeBuffer_JEmulateOriginalMap (
	CImeBuffer*			pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (pBuffer->_pRecursiveEditSession != NULL) 
		return	FALSE ;

	if (pBuffer->_nbufComp > imeBuffer_GetShiftCount (pBuffer))
		return	FALSE ;

	return	ImeDoc_UnprocessChar (pBuffer->_pDoc, ImeDoc_GetLastCommandChar (pBuffer->_pDoc)) ;
}

int
imeBuffer_JComputeNumericHenkanKey (
	CImeBuffer*			pBuffer,
	register LPWSTR 	wszBuffer,
	register int		nszBuffer)
{
	register LPCWSTR	wptr ;
	register int		nwptr ;
	register LPWSTR		pDest, pNum ;
	register int		nDest, nNum ;

	ASSERT (pBuffer != NULL) ;

	if (! ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc)) {
		register int		n ;

		n	= (nszBuffer < pBuffer->_nbufJHenkanKey)? nszBuffer : pBuffer->_nbufJHenkanKey ;
		memcpy (wszBuffer, pBuffer->_bufJHenkanKey, n * sizeof (WCHAR)) ;
		pBuffer->_nbufJNumList	= 0 ;
		return	n ;
	}

	wptr	= pBuffer->_bufJHenkanKey ;
	nwptr	= pBuffer->_nbufJHenkanKey ;
	pDest	= wszBuffer ;
	nDest	= nszBuffer ;
	pNum	= pBuffer->_bufJNumList ;
	nNum	= NELEMENTS (pBuffer->_bufJNumList) ;
	while (nwptr > 0) {
		while (nwptr > 0 &&
			   nDest > 0 &&
			   ! (L'0'  <= *wptr && *wptr <= L'9') &&
			   ! (L'�O' <= *wptr && *wptr <= L'�X')) {
			*pDest	++	= *wptr	++ ;
			nDest	-- ;
			nwptr	-- ;
		}
		if (nwptr > 0 &&
			((L'0'  <= *wptr && *wptr <= L'9') ||
			 (L'�O' <= *wptr && *wptr <= L'�X'))) {
			while (nwptr > 0 &&
				   ((L'0'  <= *wptr && *wptr <= L'9') ||
					(L'�O' <= *wptr && *wptr <= L'�X'))) {
				if (nNum > 0) {
					register WCHAR	wch = *wptr ;
					*pNum	++	= (L'0' <= wch && wch <= L'9')? wch : (wch - L'�O' + L'0') ;
					nNum	-- ;
				}
				wptr	++ ;
				nwptr	-- ;
			}
			if (nNum > 0) {
				*pNum	++	= L'\0' ;
				nNum	-- ;
			}
			if (nDest > 0) {
				*pDest	++	= L'#' ;
				nDest	-- ;
			}
		}
	}
	pBuffer->_nbufJNumList	= pNum - pBuffer->_bufJNumList ;
	return	(pDest - wszBuffer) ;
}

BOOL
imeBuffer_JInsertWord (
	CImeBuffer*			pBuffer,
	register int		nPosition,
	register LPCWSTR	wstrWord,
	register int		nstrWord)
{
	WCHAR	wszBuffer [MAXPREFIXLEN] ;
	WCHAR	wszLispEval [MAXPREFIXLEN] ;
	LPCWSTR	pNote	= NULL ;
	int		nNote	= 0 ;

	/*	���l�ϊ��B*/
	if (ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc) &&
		pBuffer->_nbufJNumList > 0) {
		nstrWord	= imeBuffer_JNumericConvert (pBuffer, wszBuffer, NELEMENTS (wszBuffer), wstrWord, nstrWord) ;
		wstrWord	= wszBuffer ;
	}

	/*	���߂����݂��邩�ǂ������`�F�b�N����B*/
	if (ImeDoc_IsSkkShowAnnotationp (pBuffer->_pDoc)) {
		int	nIndex	= SKKHasWordAnnotation (wstrWord, nstrWord) ;
		if (nIndex > 0) {
			if (! ImeDoc_IsStatusActivep (pBuffer->_pDoc)) {
				/*	�ċA���͒��� annotation �͔ς킵���������Ǝv���̂ŁAcancel����B
				 */
				pNote		= wstrWord + nIndex + 1 ;
				nNote		= nstrWord - nIndex - 1 ;
			}
			/*	���߂̈ʒu�����͑}�����Ȃ��B*/
			nstrWord	= nIndex ;
		}
	} else {
		pNote	= NULL ;
		nNote	= 0 ;
	}

	/*	lisp �ϊ� */
	if (nstrWord > 0 && wstrWord [0] == L'(' && wstrWord [nstrWord - 1] == L')') {
		if (ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc))
			TSetJNumList (pBuffer->_bufJNumList, pBuffer->_nbufJNumList) ;
		if (TLispEval (wstrWord, nstrWord, wszLispEval, MAXPREFIXLEN - 1)) {
			wszLispEval [MAXPREFIXLEN - 1]	= L'\0' ;
			wstrWord	= wszLispEval ;
			nstrWord	= lstrlenW (wstrWord) ;
		}
	}
	if (pNote != NULL && nNote > 0) 
		ImeDoc_SetMessageN (pBuffer->_pDoc, pNote, nNote) ;

	imeBuffer_InsertEx (pBuffer, nPosition, wstrWord, nstrWord) ;
	return	TRUE ;
}

/*	#4 �ϊ��̎����̂��߂ɋ���ɂȂ����c�B
 */
int
imeBuffer_JNumericConvert (
	CImeBuffer*			pBuffer,
	register LPWSTR		wstrDest,
	register int		nwstrDest,
	register LPCWSTR	wstrSource,
	register int		nwstrSource)
{
	WCHAR				wszBuffer [MAXPREFIXLEN] ;
	TVarbuffer			vbufHenkanSession ;
	LPCWSTR				pNum ;
	int					nNum, nwstrDestBak, n, nwsrc, nwdest ;
	int					nHenkanSession, nOrgHenkanSession, nInsert ;
	CTHenkanSession**	ppHenkanSession ;
	CTHenkanSession**	ppOrgHenkanSession ;
	LPWSTR				pwdest ;
	LPCWSTR				pwsrc ;
	BOOL				fFirst	= TRUE ;
	int					nRetval	= 0 ;
	CTSearchSessionCandidate*	pSharp4Point	= NULL ;

	TVarbuffer_Init (&vbufHenkanSession, sizeof (CTHenkanSession*)) ;

	pNum	= pBuffer->_bufJNumList ;
	nNum	= pBuffer->_nbufJNumList ;
	pwsrc	= wstrSource ;
	nwsrc	= nwstrSource ;
	while (nwsrc > 0) {
		if (*pwsrc == L'#') {
			CTHenkanSession*	pHenkanSession ;

			pwsrc	++ ;
			nwsrc	-- ;
			if (nwsrc > 0 && *pwsrc == L'4') {
				pHenkanSession	= THenkanSession_Init (pNum, nNum) ;
				if (! TVarbuffer_Add (&vbufHenkanSession, &pHenkanSession, 1)) {
					/*	�G���[�����B*/
					if (pHenkanSession != NULL) 
						THenkanSession_Uninit (pHenkanSession) ;
					goto	error ;
				}
			}
			pwsrc	++ ;
			nwsrc	-- ;
			while (nNum > 0 && *pNum != L'\0') {
				pNum	++ ;
				nNum	-- ;
			}
			if (nNum > 0 && *pNum == L'\0') {
				pNum	++ ;
				nNum	-- ;
			}
		}
		pwsrc	++ ;
		nwsrc	-- ;
	}

	ppOrgHenkanSession	= (CTHenkanSession **)TVarbuffer_GetBuffer (&vbufHenkanSession) ;
	nOrgHenkanSession	= TVarbuffer_GetUsage  (&vbufHenkanSession) ;
	pSharp4Point		= THenkanSession_GetCurrentPoint (pBuffer->_pHenkanSession) ;
	nInsert				= 0 ;
	DEBUGPRINTFEX (103, (TEXT ("nOrgHenkanSession (%d)\n"), nOrgHenkanSession)) ;
#if defined (DEBUG) || defined (DBG)
	n	= NELEMENTS (wszBuffer) - 1 ;
	n	= (n < nwstrSource)? n : nwstrSource ;
	lstrncpyW (wszBuffer, wstrSource, n) ;
	wszBuffer [n]	= L'\0' ;
	DEBUGPRINTFEX (103, (TEXT ("source -> \"%s\"(%d)\n"), wszBuffer, nwstrSource)) ;
#endif
	for ( ; ; ) {
		ppHenkanSession	= ppOrgHenkanSession ;
		nHenkanSession	= nOrgHenkanSession ;

		pwsrc	= wstrSource ;
		nwsrc	= nwstrSource ;
		pwdest	= wszBuffer ;
		nwdest	= NELEMENTS (wszBuffer) - 1 ;
		pNum	= pBuffer->_bufJNumList ;
		nNum	= pBuffer->_nbufJNumList ;

		while (nwsrc > 0 && nwdest > 0) {
			if (*pwsrc == L'#') {
				pwsrc	++ ;
				nwsrc	-- ;
				if (nwsrc <= 0)
					break ;
				if (*pwsrc == L'4') {
					LPCWSTR	wstrResult ;

					n	= 0 ;
					if (nHenkanSession > 0) {
						if (*ppHenkanSession != NULL) {
							wstrResult	= THenkanSession_GetCandidate (*ppHenkanSession) ;
						} else {
							wstrResult	= NULL ;
						}
						ppHenkanSession	++ ;
						nHenkanSession	-- ;
						n	= (wstrResult != NULL)? lstrlenW (wstrResult) : 0 ;
						n	= (n > nwdest)? nwdest : n ;
						if (n > 0) {
							/*	# �𖳌���(���ɕϊ�)���ăR�s�[����B
							 *	# �̍ċA�I�ȓW�J�������ƁA�܂��ԈႢ�Ȃ����������s������
							 *	���낤�B���̑΍�B
							 */
							JNoNumCopy (pwdest, wstrResult, n) ;
						}
						DEBUGPRINTFEX (103, (TEXT ("(JNumConv) #4 -> %d\n"), n)) ;
					}
					JNumSkip (&pNum, &nNum) ;
				} else {
					n	= JNumExp (pwdest, nwdest, *pwsrc, &pNum, &nNum) ;
				}
				pwsrc	++ ;
				nwsrc	-- ;
				pwdest	+= n ;
				nwdest	-= n ;
			} else {
				*pwdest	++	= *pwsrc ++ ;
				nwdest	-- ;
				nwsrc	-- ;
			}
		}

		n	= pwdest - wszBuffer ;
		wszBuffer [n]	= L'\0' ;
#if defined (DEBUG) || defined (DBG)
		DEBUGPRINTFEX (103, (TEXT ("(JNumConv) Result = \"%s\"\n"), wszBuffer)) ;
#endif
		/*	�����1���A�o���オ��B*/
		if (fFirst) {
			nRetval	= (n < nwstrDest)? n : nwstrDest ;
			lstrncpyW (wstrDest, wszBuffer, nRetval) ;
			fFirst	= FALSE ;
		}

		/*	���̌���ǉ����Ȃ��Ƃ����Ȃ��B*/
		if (nOrgHenkanSession > 0) {
			/*	n+1 �� nul �������܂߂邽�߁A�ł���B*/
			if (THenkanSession_InsertCandidate (pBuffer->_pHenkanSession, wszBuffer, n + 1)) {
				DEBUGPRINTFEX (103, (TEXT ("Insert \"%s\"(%d) succeeded\n"), wszBuffer, n)) ;
				nInsert	++ ;
				if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) {
					DEBUGPRINTFEX (103, (TEXT ("Something wrong in JNumericConversion \n"))) ;
				} else {
					THenkanSession_LinkCandidate (pBuffer->_pHenkanSession, pSharp4Point) ;
				}
#if defined (DEBUG) || defined (DBG)
			} else {
				DEBUGPRINTFEX (103, (TEXT ("Insert \"%s\"(%d) failed\n"), wszBuffer, n)) ;
#endif
			}
		}

		/*	������1���̌��ɑ����Ă݂Ă���B*/
		ppHenkanSession	= ppOrgHenkanSession ;
		nHenkanSession	= nOrgHenkanSession ;
		while (nHenkanSession > 0) {
			if (THenkanSession_NextCandidate (*ppHenkanSession))
				break ;
			THenkanSession_Rewind (*ppHenkanSession ++) ;
			nHenkanSession	-- ;
		}
		if (nHenkanSession <= 0)
			break ;
	}
	DEBUGPRINTFEX (103, (TEXT ("Total Insert (%d)\n"), nInsert)) ;
	if (nInsert > 0) {
		while (nInsert > 0) {
			THenkanSession_PreviousCandidate (pBuffer->_pHenkanSession) ;
			nInsert	-- ;
		}
		THenkanSession_RemoveCandidate (pBuffer->_pHenkanSession) ;
	}

  error:
	/*	��������B*/
	nHenkanSession	= TVarbuffer_GetUsage  (&vbufHenkanSession) ;
	ppHenkanSession	= (CTHenkanSession**) TVarbuffer_GetBuffer (&vbufHenkanSession) ;
	while (nHenkanSession -- > 0) {
		if (*ppHenkanSession != NULL) {
			THenkanSession_Uninit (*ppHenkanSession) ;
			*ppHenkanSession	= NULL ;
		}
		ppHenkanSession	++ ;
	}
	TVarbuffer_Uninit (&vbufHenkanSession) ;
	return	nRetval ;
}

BOOL
imeBuffer_JChangeMarker (
	CImeBuffer*			pBuffer)
{
	register int	nPos ;

	if (pBuffer->_pmkJHenkanStartPoint == NULL)
		return	FALSE ;
	nPos	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) - 1 ;
	if (nPos < 0 || nPos >= pBuffer->_nbufComp)
		return	FALSE ;
	if (pBuffer->_bufComp [nPos] == L'��') {
		pBuffer->_bufComp [nPos]	= L'��' ;
	} else {
		imeBuffer_JKakutei (pBuffer) ;
		/*	It seems that you have deleted ��. */
		ImeDoc_SetMessage (pBuffer->_pDoc, L"It seems that you have deleted ��.") ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JChangeMarkerToWhite (
	CImeBuffer*			pBuffer)
{
	register int	nPos ;

	if (pBuffer->_pmkJHenkanStartPoint == NULL)
		return	FALSE ;
	nPos	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) - 1 ;
	if (nPos < 0 || nPos >= pBuffer->_nbufComp)
		return	FALSE ;
	if (pBuffer->_bufComp [nPos] == L'��') {
		pBuffer->_bufComp [nPos]	= L'��' ;
	} else {
		TMarker_SetPosition (pBuffer->_pmkPoint, pBuffer->_pmkJHenkanStartPoint) ;
		imeBuffer_Insert (pBuffer, L"��", 1) ;
		TMarker_SetPosition (pBuffer->_pmkJHenkanStartPoint, pBuffer->_pmkPoint) ;
		/*	It seems that you have deleted ��. */
		ImeDoc_SetMessage (pBuffer->_pDoc, L"It seems that you have deleted ��.") ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JHenkanInMinibuff (
	CImeBuffer*			pBuffer)
{
	WCHAR				rszBuffer [MAXCOMPLEN] ;
	register LPCWSTR	pSrc ;
	register int		nSrc ;

	/*	j-num-list �́A�܂��Ȃ��B(not implemented yet) */
	if (pBuffer->_nbufJNumList > 0) {
		pSrc	= pBuffer->_bufJSearchKey ;
		nSrc	= (pBuffer->_nbufJSearchKey < MAXCOMPLEN)? pBuffer->_nbufJSearchKey : MAXCOMPLEN ;
	} else {
		if (pBuffer->_nbufJHenkanKey2 > 0) {
			pSrc	= pBuffer->_bufJHenkanKey2 ;
			nSrc	= (pBuffer->_nbufJHenkanKey2 < MAXCOMPLEN)? pBuffer->_nbufJHenkanKey2 : MAXCOMPLEN ;
		} else {
			pSrc	= pBuffer->_bufJHenkanKey ;
			nSrc	= (pBuffer->_nbufJHenkanKey < MAXCOMPLEN)? pBuffer->_nbufJHenkanKey : MAXCOMPLEN ;
		}
	}
	memcpy (rszBuffer, pSrc, sizeof (WCHAR) * nSrc) ;
	if (nSrc < MAXCOMPLEN)
		rszBuffer [nSrc ++]	= L' ' ;

	TRecursiveEditSession_Init (&pBuffer->_RecursiveEditSession, pBuffer, THenkanInMinibuffSession_OnExit, THenkanInMinibuffSession_OnAbort) ;
	return	ImeDoc_ReadFromMinibuffer (pBuffer->_pDoc, rszBuffer, nSrc, &pBuffer->_RecursiveEditSession) ;
}

BOOL
imeBuffer_ShowJHenkanCandidates (
	CImeBuffer*		pBuffer)
{
#if defined (UNITTEST)
	LPCWSTR		wstrJHenkanShowCandidatesKeys	= L"asdfjkl" ;
	WCHAR		wszMessage [MAXCOMPLEN] ;
	WCHAR		wszBuffer  [MAXCOMPLEN] ;
	register WCHAR*		wptr ;
	register LPCWSTR	wstrResult ;
	register int		nHCount, nwptr, nstrResult, nCopy, nCandidate, nShow ;
	BOOL				fContinue ;

	imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
	wptr		= wszMessage ;
	nwptr		= MAXCOMPLEN ;
	nShow		= 0 ;
	for (nHCount = 0 ; nHCount < NUMHENKANSHOWCANDIDATES ; nHCount ++) {
		if (nwptr > 0) {
			*wptr ++	= *wstrJHenkanShowCandidatesKeys ++ ;
			nwptr -- ;
		}
		if (nwptr > 0) {
			*wptr ++	= L':' ;
			nwptr -- ;
		}
		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
		if (wstrResult != NULL) {
			nShow	++ ;
			nstrResult	= lstrlenW (wstrResult) ;
			if (ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc) &&
				pBuffer->_nbufJNumList > 0) 
				nstrResult	= imeBuffer_JNumericConvert (pBuffer, wszBuffer, NELEMENTS (wszBuffer), wstrResult, nstrResult) ;
			nCopy		= (nstrResult < nwptr)? nstrResult : nwptr ;
			if (nCopy > 0) {
				memcpy (wptr, wstrResult, sizeof (WCHAR) * nCopy) ;
				wptr		+= nCopy ;
				nwptr		-= nCopy ;
			}
			if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) {
				if (nwptr > 0) {
					*wptr ++	= L' ' ;
					nwptr -- ;
				}
				break ;
			}
		}
		if (nwptr > 0) {
			*wptr ++	= L' ' ;
			nwptr -- ;
		}
	}

	nCandidate	= THenkanSession_GetNumberOfCandidate (pBuffer->_pHenkanSession, &fContinue) ;
	if (nwptr > 0) {
		register int	n ;

		n	= wnsprintfW (wptr, nwptr, L"[�c�� %d%s]", nCandidate - (pBuffer->_nJHenkanCount + nShow) + 1, fContinue? L"+" : L"") ;
		nwptr	-= n ;
		ImeDoc_SetMessageN (pBuffer->_pDoc, wszMessage, MAXCOMPLEN - nwptr) ;
	} else {
		ImeDoc_SetMessageN (pBuffer->_pDoc, wszMessage, MAXCOMPLEN) ;
	}
	/*	���߂��B*/
	while (nHCount -- > 0)
		THenkanSession_PreviousCandidate (pBuffer->_pHenkanSession) ;
#else
	register TVarbuffer*		pvbufCandInfo ;
	register LPMYCAND			pMyCand ;
	register LPCANDIDATEINFO	pCandInfo ;
	register LPCANDIDATELIST	pCandList ;
	register BOOL				fNeedReconstruct ;
	register int				nCandidate, nCount ;
	BOOL						fContinue ;

	/*	Candidate-List ��D�悵���̂ŁA���̑���͕s�v�ł͂Ȃ����Ǝv���B
	ImeDoc_ClearMessage (pBuffer->_pDoc) ;
	*/

	pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pBuffer->_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	if (TVarbuffer_GetUsage (pvbufCandInfo) <= sizeof (MYCAND)) {
		nCount	= pBuffer->_nJHenkanCount - 1 ;
		fNeedReconstruct	= TRUE ;
		goto	exit_func ;
	}
	pMyCand		= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	if (pMyCand == NULL) {
		fNeedReconstruct	= FALSE ;
		goto	exit_func ;
	}
	pCandInfo	= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandList	= (LPCANDIDATELIST)&(pMyCand->cl) ;
	if (pCandInfo->dwCount == 0 || (int)pCandList->dwCount < pBuffer->_nJHenkanCount) {
		nCount	= pBuffer->_nJHenkanCount - 1 ;
		fNeedReconstruct	= TRUE ;
		goto	exit_func ;
	}
	fNeedReconstruct	= FALSE ;
	if (pCandList->dwCount <= pCandList->dwPageStart) {
		nCandidate	= THenkanSession_GetNumberOfCandidate (pBuffer->_pHenkanSession, &fContinue) ;
		if (pCandList->dwCount < (DWORD)nCandidate) {
			/*	CandidateList ���č\������K�v������B*/
			fNeedReconstruct	= TRUE ;
			nCount				= pCandList->dwPageStart ;
		} else {
			/*	�ԈႢ�Ȃ��G���[�B*/
		}
	} else {
		/*	���̏ꍇ�ɂ͓��ɉ���������K�v�͂Ȃ��B*/
	}
  exit_func:
	if (fNeedReconstruct) 
		return	imeBuffer_CreateJHenkanCandidateList (pBuffer, nCount) ;
#endif
	return	TRUE ;
}

#if !defined (UNITTEST)
BOOL
imeBuffer_CreateJHenkanCandidateList (
	register CImeBuffer*		pBuffer,
	register int				nPageStart)
{
	register TVarbuffer*		pvbufCandInfo ;
	register LPCANDIDATEINFO	pCandInfo ;
	register LPMYCAND			pMyCand ;
	register LPCANDIDATELIST	pCandList ;
	register DWORD*				pCandidateOffset ;
	register LPMYSTR			pCandidateStr ;
	register LPCWSTR	wstrResult ;
	register int		nCandidate, nNeedLength, nHCount, i, nstrResult, nRealCand ;
	BOOL				fContinue ;
	WCHAR				wszBuffer  [MAXCOMPLEN] ;
	DWORD				dwSize ;

	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_CreateJHenkanCandidateList (Buf:%p, s:%d)\n"), pBuffer, nPageStart)) ;

	/*	�K�v�ȃ������T�C�Y�����߂�B*/
	imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;

	/*	�S�Ă̎������������āA����S����x�Ɉ����o����悤�ɂ��Ă����B*/
	nNeedLength	= 0 ;
	for (nHCount = 0 ; nHCount < NUMHENKANSHOWCANDIDATES ; nHCount ++) {
		if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) 
			break ;
	}
	while (nHCount -- > 0)
		THenkanSession_PreviousCandidate (pBuffer->_pHenkanSession) ;

	nCandidate	= THenkanSession_GetNumberOfCandidate (pBuffer->_pHenkanSession, &fContinue) ;
	nRealCand	= 0 ;
	THenkanSession_Rewind (pBuffer->_pHenkanSession) ;

	/*	#4 expand �����݂��邽�߁A���ۂ̌��̐��͎����̕Ԃ������̐��Ƃ͈�v���Ȃ��B
	 */
	for ( ; ; ) {
		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
		if (wstrResult != NULL) {
			nstrResult	= lstrlenW (wstrResult) ;
			if (ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc) &&
				pBuffer->_nbufJNumList > 0) 
				nstrResult	= imeBuffer_JNumericConvert (pBuffer, wszBuffer, NELEMENTS (wszBuffer), wstrResult, nstrResult) ;
			nNeedLength	+= nstrResult + 1 ;
			nRealCand	++ ;
		}
		if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession))
			break ;
	}
	/*	#4 expand ���l������
	 */
	nCandidate	= THenkanSession_GetNumberOfCandidate (pBuffer->_pHenkanSession, &fContinue)  ;
	if (nCandidate <= 0) 
		return	FALSE ;
	THenkanSession_Rewind (pBuffer->_pHenkanSession) ;

	DEBUGPRINTFEX (99, (TEXT ("nCand = %d, nRealCand = %d, nPageStart=%d\n"),
						nCandidate, nRealCand, nPageStart)) ;

	dwSize	= sizeof (MYCAND) + sizeof (DWORD) * nCandidate + sizeof (MYCHAR) * nNeedLength ;

	pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pBuffer->_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	TVarbuffer_Clear (pvbufCandInfo) ;
	if (! TVarbuffer_Require (pvbufCandInfo, dwSize))
		return	FALSE ;

	pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandInfo->dwSize		= dwSize ;
	pCandInfo->dwCount		= 1 ;
	pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
	pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
	pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * nCandidate + sizeof (MYCHAR) * nNeedLength ;
	pCandList->dwStyle		= IME_CAND_READ ;
	pCandList->dwCount		= (DWORD)nCandidate ;
	pCandList->dwPageSize	= (nCandidate < MAX_SKKCANDPAGESIZE)? nCandidate : MAX_SKKCANDPAGESIZE ;
	pCandList->dwSelection	= nPageStart ;
	pCandList->dwPageStart	= nPageStart ;

	pCandidateStr			= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * nCandidate) ;
	pCandidateOffset		= pCandList->dwOffset ;

	for (i = 0 ; i < nCandidate ; i ++) {
		*pCandidateOffset	= (DWORD)((LPSTR)pCandidateStr - (LPSTR)pCandList) ;

		wstrResult	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
		if (wstrResult != NULL) {
			nstrResult	= lstrlenW (wstrResult) ;
			if (ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc) &&
				pBuffer->_nbufJNumList > 0) {
				nstrResult	= imeBuffer_JNumericConvert (pBuffer, wszBuffer, NELEMENTS (wszBuffer), wstrResult, nstrResult) ;
				wstrResult	= wszBuffer ;
			}
			DEBUGPRINTFEX (103, (TEXT ("candidate (%d) -> \"%s\"(%d)\n"), i, wstrResult, nstrResult)) ;
			/*lstrncpyW (pCandidateStr, wstrResult, nstrResult) ;*/
			memcpy (pCandidateStr, wstrResult, sizeof (WCHAR) * nstrResult) ;
			pCandidateStr [nstrResult]	= L'\0' ;
			pCandidateStr	+= nstrResult + 1 ;
			pCandidateOffset	++ ;
		}
		THenkanSession_NextCandidate (pBuffer->_pHenkanSession) ;
	}

	/*	���ʒu��߂��BSequential �Ȃ̂��h�����B*/
	THenkanSession_Rewind (pBuffer->_pHenkanSession) ;
	for (i = 0 ; i < nPageStart ; i ++) 
		if (! THenkanSession_NextCandidate (pBuffer->_pHenkanSession)) 
			break ;
	ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CREATE_CANDIDATELIST) ;
	return	TRUE ;
}
#endif

/*========================================================================*
 */
BOOL
imeBuffer_JInputByCodeOrMenu (
	register CImeBuffer*		pBuffer)
{
	static const WCHAR		rwszMenu []	= L"JIS or EUC code (00nn or CR for Jump Menu): " ;
	register CImeBuffer*	pChildBuffer ;

	DEBUGPRINTFEX (99, (TEXT ("imeBuffer_JInputByCodeOrMenu (buffer:%p)\n"), pBuffer)) ;

	if (ImeDoc_DisableMinibufferp (pBuffer->_pDoc)) {
		imeBuffer_JInputByCodeOrMenu0Start (pBuffer, _nJCodeNull, 128) ;
		return	TRUE ;
	}

	/*	�ċA�o�^��ʂŕ����R�[�h�̓��͂������B*/
	TRecursiveEditSession_Init (&pBuffer->_RecursiveEditSession, pBuffer, JInputByCodeOrMenuSession_OnExit, JInputByCodeOrMenuSession_OnAbort) ;
	if (! ImeDoc_ReadFromMinibuffer (pBuffer->_pDoc, rwszMenu, NELEMENTS (rwszMenu) - 1, &pBuffer->_RecursiveEditSession))
		return	FALSE ;
	/*	minibuffer �ł͉������͂̃f�t�H���g�������Ă����B*/
	pChildBuffer	= ImeDoc_GetCurrentBuffer (pBuffer->_pDoc) ;
	if (pChildBuffer == NULL)
		return	FALSE ;
	return	imeBuffer_JModeOff (pChildBuffer) ;
}

BOOL
imeBuffer_JInputByCodeOrMenu0Start (
	register CImeBuffer*		pBuffer,
	register int				n1,
	register int				n2)
{
	if (n1 == _nJCodeNull) {
		imeBuffer_JInputByCodeOrMenuJumpStart (pBuffer, n2) ;
	} else {
		imeBuffer_JInputByCodeOrMenu1Start (pBuffer, n1, n2) ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_JInputByCodeOrMenuJumpStart (
	register CImeBuffer*		pBuffer,
	register int				n)
{
	if (n < _nJCodeN1Min)
		n	= pBuffer->_nJInputByCodeOrMenuJumpDefault ;

	imeBuffer_ShowJInputByCodeOrMenuJump (pBuffer, n) ;
	pBuffer->_nJInputCode1	= n ;
	pBuffer->_pFilterProc	= imeBuffer_JInputByCodeOrMenuJumpFilter ;
	return	TRUE ;
}

BOOL
imeBuffer_JInputByCodeOrMenu1Start (
	register CImeBuffer*		pBuffer,
	register int				n1,
	register int				n2)
{
	imeBuffer_ShowJInputByCodeOrMenu1 (pBuffer, n1, n2) ;
	pBuffer->_nJInputCode1		= n1 ;
	pBuffer->_nJInputCode2		= n2 ;
	pBuffer->_pFilterProc		= imeBuffer_JInputByCodeOrMenu1Filter ;
	return	TRUE ;
}

BOOL
imeBuffer_ShowJInputByCodeOrMenuJump (
	register CImeBuffer*		pBuffer,
	register int				n)
{
#if defined (UNITTEST)
	register WORD		wch, wchBase, c ;
	register WCHAR*		wptr ;
	WCHAR		wszBuffer [48] ;	/* 12 * 3 = 36 + 1 ����Ώ\���B*/
	register int		i ;

	wptr		= wszBuffer ;
	wchBase		= (WORD)((n & 0x00FF) << 8) ;
	*wptr ++	= _wstrJInputByCodeMenuKeys1 [0] ;
	wch			= JCharToUnicode (wchBase | pBuffer->_nJCodeN1Min) ;
	*wptr ++	= (wch != 0)? wch : L' ' ;
	*wptr ++	= L' ' ;
	for (i = 0 ; i < 5 ; i ++) {
		*wptr ++	= _wstrJInputByCodeMenuKeys1 [i + 1] ;
		wch	= JCharToUnicode ((WORD)(wchBase | _rnJInputByCodeOrMenuJumpLowordTbl [i])) ;
		*wptr ++	= (wch != 0)? wch : L' ' ;
		*wptr ++	= L' ' ;
	}
	n			++ ;
	n			= (n <= pBuffer->_nJCodeN1Max)? n : pBuffer->_nJCodeN1Min ;
	wchBase		= (WORD)((n & 0x00FF) << 8) ;
	*wptr ++	= _wstrJInputByCodeMenuKeys1 [i + 6] ;
	wch			= JCharToUnicode (wchBase | pBuffer->_nJCodeN1Min) ;
	*wptr ++	= (wch != 0)? wch : L' ' ;
	*wptr ++	= L' ' ;
	for (i = 0 ; i < 5 ; i ++) {
		*wptr ++	= _wstrJInputByCodeMenuKeys1 [i + 7] ;
		wch	= JCharToUnicode ((WORD)(wchBase | _rnJInputByCodeOrMenuJumpLowordTbl [i])) ;
		*wptr ++	= (wch != 0)? wch : L' ' ;
		*wptr ++	= L' ' ;
	}
	return	ImeDoc_SetMessageN (pBuffer->_pDoc, wszBuffer, wptr - wszBuffer) ;
#else
	register TVarbuffer*		pvbufCandInfo ;
	register LPMYCAND			pMyCand ;
	register LPCANDIDATEINFO	pCandInfo ;
	register LPCANDIDATELIST	pCandList ;
	register LPMYSTR			pDest ;
	register DWORD*				pOffset ;
	register DWORD				dwSize ;
	register WORD				woChara, woCode, woStart ;
	register int 				i, nNumOfCand ;

	/*	min, max ���܂�ŁA���ꂼ��� 6 ���A�ƁB*/
	nNumOfCand		= (_nJCodeN1Max - _nJCodeN1Min + 1) * 6 ;
	dwSize			= sizeof (MYCAND) + sizeof (DWORD) * nNumOfCand + sizeof (WCHAR) * 2 * nNumOfCand ;
	pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pBuffer->_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	TVarbuffer_Clear (pvbufCandInfo) ;
	if (! TVarbuffer_Require (pvbufCandInfo, dwSize))
		return	FALSE ;

	/* ��⃊�X�g�\���̂��m�ۂ��A����������B*/
	pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandInfo->dwSize		= dwSize ;
	pCandInfo->dwCount		= 1 ;
	pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
	pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
	pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumOfCand + sizeof (WCHAR) * 2 * nNumOfCand ;
	pCandList->dwStyle		= IME_CAND_CODE ;	/* ���[�ށA�܂��ACODE �ł������B*/
	pCandList->dwCount		= (DWORD) nNumOfCand ;
	pCandList->dwPageSize	= JINPUTBYCODEORMENU_PAGESIZE ;

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pDest		= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumOfCand) ;
	pOffset		= pCandList->dwOffset ;

	woCode		= (WORD)_nJCodeN1Min ;
	do {
		/* ���j���[������B*/
		for (i = 0 ; i < JINPUTBYCODEORMENU_PAGESIZE / 2 ; i ++){
			*pOffset	= (DWORD)((LPSTR)pDest - (LPSTR)pCandList) ;
			woChara		= woCode << 8 ;
			woChara		|= (i > 0)? _rnJInputByCodeOrMenuJumpLowordTbl [i - 1] : _nJCodeN1Min ;
			/* j_char_jis_to_unicode */
			woChara		= JCharToUnicode (woChara) ;
			if (!woChara)	/* �ϊ��ł��Ȃ����͋󔒁B*/
				woChara	= MYTEXT (' ') ;
			*pDest	++	= (MYCHAR)woChara ;
			*pDest ++	= MYTEXT ('\0') ;
			pOffset	++ ;
		}
		woCode ++ ;
		/* �������͈͓��ɂ��邩�ǂ����𔻒f����B*/
		if (woCode > _nJCodeN1Max)
			woCode	= (WORD)_nJCodeN1Min ;
	}	while (woCode != (WORD)_nJCodeN1Min) ;
	
	woCode		= (WORD)(n & 0x00FF) ;
	if (woCode < _nJCodeN1Min || woCode > _nJCodeN1Max)
		woCode	= (WORD)_nJCodeN1Min ;

	pCandList->dwPageStart	= (woCode - (WORD)_nJCodeN1Min) * (JINPUTBYCODEORMENU_PAGESIZE / 2) ;
	pCandList->dwSelection	= pCandList->dwPageStart ;

	ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CREATE_CANDIDATELIST) ;
	return	TRUE ;
#endif
}

BOOL
imeBuffer_ShowJInputByCodeOrMenu1 (
	register CImeBuffer*		pBuffer,
	register int				n1,
	register int				n2)
{
#if defined (UNITTEST)
	register int	i ;
	WCHAR			wszBuffer [48 + 1] ;	/* 16 * 3 = 48 ����Ώ\���B*/
	WCHAR			wch ;
	register WCHAR*	wptr ;

	wptr	= wszBuffer ;
	for (i = 0 ; i < 16 ; i ++) {
		*wptr ++	= _wstrJInputByCodeMenuKeys2 [i] ;
		wch			= JCharToUnicode ((WORD)((n1 << 8) | n2)) ;
		*wptr ++	= (wch != 0)? wch : L' ' ;
		*wptr ++	= L' ' ;
		n2			= ((n2 + 1) <= _nJCodeN2Max)? (n2 + 1) : _nJCodeN2Min ;
		if (n2 == pBuffer->_nJCodeN2Min) 
			n1		= ((n1 + 1) <= _nJCodeN1Max)? (n1 + 1) : _nJCodeN1Min ;
	}
	return	ImeDoc_SetMessageN (pBuffer->_pDoc, wszBuffer, wptr - wszBuffer) ;
#else
	register TVarbuffer*		pvbufCandInfo ;
	register LPMYCAND			pMyCand ;
	register LPCANDIDATEINFO	pCandInfo ;
	register LPCANDIDATELIST	pCandList ;
	register LPMYSTR			pDest ;
	register DWORD*				pOffset ;
	register DWORD				dwSize ;
	register WORD				woChara ;
	register int				nNumOfCand, i, nCount1, nCount2 ;

	/*	���Ƃ��������Ȑ����ȁB*/
	nNumOfCand	= (_nJCodeN2Max - _nJCodeN2Min + 1) * (_nJCodeN1Max - _nJCodeN1Min + 1) ;
	dwSize		= sizeof (MYCAND) + sizeof (DWORD) * nNumOfCand + sizeof (WCHAR) * 2 * nNumOfCand ;

	pvbufCandInfo	= ImeDoc_GetCandidateInfoBuffer (pBuffer->_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	TVarbuffer_Clear (pvbufCandInfo) ;
	if (! TVarbuffer_Require (pvbufCandInfo, dwSize))
		return	FALSE ;

	/* ��⃊�X�g�\���̂��m�ۂ��A����������B*/
	pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandInfo->dwSize		= dwSize ;
	pCandInfo->dwCount		= 1 ;
	pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
	pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
	pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumOfCand + sizeof (MYCHAR) * 2 * nNumOfCand ;
	pCandList->dwStyle		= IME_CAND_CODE ;	/* ���[�ށA�܂��ACODE �ł������B*/
	pCandList->dwCount		= (DWORD) nNumOfCand ;
	pCandList->dwPageSize	= JINPUTBYCODEORMENU1_PAGESIZE ;	/* 1�y�[�W��16�܂ŕ��ׂ���A�ƁB*/

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pDest		= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumOfCand) ;
	pOffset		= pCandList->dwOffset ;

	nCount1		= _nJCodeN1Min ;
	nCount2		= _nJCodeN2Min ;
	do {
		*pOffset	= (DWORD)((LPSTR)pDest - (LPSTR)pCandList) ;
		/* JISX0208-1983 �����W���Ɋ܂܂�镶���� UNICODE �ɕ���������B*/
		woChara		= JCharToUnicode ((WORD)((nCount1 << 8) | nCount2)) ;
		if (!woChara)
			woChara	= MYTEXT (' ') ;
		*pDest	++	= woChara ;
		*pDest	++	= MYTEXT ('\0') ;
		
		nCount2		++ ;
		if (nCount2 > _nJCodeN2Max)
			nCount2	= _nJCodeN2Min ;
		if (nCount2 == _nJCodeN2Min) {
			nCount1 ++ ;
			if (nCount1 > _nJCodeN1Max)
				nCount1	= _nJCodeN1Min ;
		}	
		pOffset	++ ;
	}	while (! (nCount1 == _nJCodeN1Min && nCount2 == _nJCodeN2Min)) ;

	if (n1 > _nJCodeN1Max || n1 < _nJCodeN1Min)
		n1	= _nJCodeN1Min ;
	if (n2 > _nJCodeN2Max || n2 < _nJCodeN2Min)
		n2	= _nJCodeN2Min ;

	pCandList->dwPageStart	= (n1 - _nJCodeN1Min) * (_nJCodeN2Max - _nJCodeN2Min + 1) + (n2 - _nJCodeN2Min) ;
	pCandList->dwSelection	= pCandList->dwPageStart ;

	ImeDoc_SetUpdateFlag (pBuffer->_pDoc, SKKUI_CREATE_CANDIDATELIST) ;
	return	TRUE ;
#endif
}

/*========================================================================
 */
int
imeBuffer_CharAfter (
	CImeBuffer*		pBuffer,
	register int	nPosition)
{
	if (nPosition < 0 || nPosition >= pBuffer->_nbufComp)
		return	-1 ;
	return	pBuffer->_bufComp [nPosition] ;
}

BOOL
imeBuffer_SetMarker (
	CImeBuffer*					pBuffer,
	register CTMarker**			ppMarker,
	register int				nMarkerIndex,
	register const CTMarker*	pSource)
{
	ASSERT (pBuffer != NULL) ;
	ASSERT (ppMarker != NULL) ;
	ASSERT (0 <= nMarkerIndex && nMarkerIndex < MAXBUFMARKER) ;

	if (*ppMarker == NULL) 
		*ppMarker	= &pBuffer->_rMarker [nMarkerIndex] ;
	TMarker_SetPosition (*ppMarker, pSource) ;
	return	TRUE ;
}

BOOL
imeBuffer_DeleteRegion (
	CImeBuffer*				pBuffer,
	register int			nStartPoint,
	register int			nEndPoint)
{
	register int	nMove, i ;

	ASSERT (pBuffer != NULL) ;

	if (nStartPoint > nEndPoint) {
		register int	nTmp ;
		nTmp		= nStartPoint ;
		nStartPoint	= nEndPoint ;
		nEndPoint	= nTmp ;
	}

	nMove	= nEndPoint - nStartPoint ;
	if (nMove == 0)
		return	TRUE ;

	/*	�s���ȗ̈�̍폜�͎̂Ă�B
	 */
	if (nStartPoint < 0 || nEndPoint > MAXCOMPLEN)
		return	FALSE ;

	if (pBuffer->_nbufComp > nEndPoint) 
		memmove (pBuffer->_bufComp + nStartPoint, pBuffer->_bufComp + nEndPoint, sizeof (WCHAR) * (pBuffer->_nbufComp - nEndPoint)) ;
	pBuffer->_nbufComp	-= (nEndPoint - nStartPoint) ;

	/*	�����Ń}�[�J�̈ړ�������B
	 */
	for (i = 0 ; i < pBuffer->_nMarker ; i ++) {
		if (nStartPoint < TMarker_GetPosition (&pBuffer->_rMarker [i])) {
			if (TMarker_GetPosition (&pBuffer->_rMarker [i]) < nEndPoint) {
				TMarker_Backward (&pBuffer->_rMarker [i], TMarker_GetPosition (&pBuffer->_rMarker [i]) - nStartPoint) ;
			} else {
				TMarker_Backward (&pBuffer->_rMarker [i], nMove) ;
			}
		}
	}
	return	TRUE ;
}

BOOL
imeBuffer_Insert (
	CImeBuffer*			pBuffer,
	register LPCWSTR	wstr,
	register int		nwstr)
{
	ASSERT (pBuffer != NULL) ;
	ASSERT (pBuffer->_pmkPoint != NULL) ;

	imeBuffer_InsertEx (pBuffer, TMarker_GetPosition (pBuffer->_pmkPoint), wstr, nwstr) ;
	return	TRUE ;
}

int
imeBuffer_InsertEx (
	register CImeBuffer*	pBuffer,
	register int			nPosition,
	register LPCWSTR		wstr,
	register int			nwstr)
{
	register int	i ;

	if (nPosition < 0 || nPosition >= MAXCOMPLEN || nwstr <= 0)
		return	0 ;
	if ((pBuffer->_nbufComp + nwstr) > MAXCOMPLEN)
		nwstr	= MAXCOMPLEN - pBuffer->_nbufComp ;
	if ((nPosition + nwstr) > MAXCOMPLEN) 
		nwstr	= MAXCOMPLEN - nPosition ;
	if (nwstr <= 0)
		return	0 ;
	if ((nPosition + nwstr) < MAXCOMPLEN && nPosition < pBuffer->_nbufComp) 
		memmove (pBuffer->_bufComp + nPosition + nwstr, pBuffer->_bufComp + nPosition, sizeof (WCHAR) * (pBuffer->_nbufComp - nPosition)) ;
	memmove (pBuffer->_bufComp + nPosition, wstr, sizeof (WCHAR) * nwstr) ;

	/*	�}�[�J�̈ړ��B
	 */
	pBuffer->_nbufComp	+= nwstr ;
	for (i = 0 ; i < pBuffer->_nMarker ; i ++) {
		register int	nMarkerPos	= TMarker_GetPosition (&pBuffer->_rMarker [i]) ;
		if ((nPosition < nMarkerPos ||
			 (nPosition ==  nMarkerPos &&
			  TMarker_IsCursor (&pBuffer->_rMarker [i]))) &&
			nMarkerPos < pBuffer->_nbufComp)
			TMarker_Forward (&pBuffer->_rMarker [i], nwstr) ;
	}
	return	nwstr ;
}

BOOL
imeBuffer_DeleteChar (
	CImeBuffer*			pBuffer,
	register int		nDelete)
{
	ASSERT (pBuffer != NULL) ;

	return	imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkPoint), TMarker_GetPosition (pBuffer->_pmkPoint) + nDelete) ;
}

BOOL
imeBuffer_DeleteCharEx (
	CImeBuffer*			pBuffer,
	register int		nPosition,
	register int		nDelete)
{
	return	imeBuffer_DeleteRegion (pBuffer, nPosition, nPosition + nDelete) ;
}

int
imeBuffer_BufferSubstring (
	CImeBuffer*			pBuffer,
	register int		nStartPoint,
	register int		nEndPoint,
	register LPCWSTR*	ppDest)
{
	register int	nRealStart	= (nStartPoint < nEndPoint)? nStartPoint : nEndPoint ;
	register int	nRealEnd	= (nStartPoint < nEndPoint)? nEndPoint   : nStartPoint ;

	*ppDest	= pBuffer->_bufComp + nRealStart ;
	return	nRealEnd - nRealStart ;
}

CTMarker*
imeBuffer_MakeMarker (
	CImeBuffer*			pBuffer,
	register BOOL		fCursor)
{
	register CTMarker*	pMarker ;
	register int		nMarker ;

	ASSERT (pBuffer != NULL) ;

	/*	�\�񂳂�Ă���}�[�J�̎����猟�����J�n����B
	 */
	pMarker	= pBuffer->_rMarker + MAX_RESERVED_MARKERS ;
	nMarker	= pBuffer->_nMarker - MAX_RESERVED_MARKERS ;
	while (nMarker -- > 0) {
		if (! TMarker_IsValidp (pMarker))
			break ;
		pMarker	++ ;
	}

	/*	���݂̃}�[�J�̒��ɋ�(���ԂƂ������H)���Ȃ�
	 *	�̂ŐV�����m�ہB
	 */
	if (nMarker <= 0) {
		if (pBuffer->_nMarker >= MAXBUFMARKER) 
			return	FALSE ;
		pMarker	= pBuffer->_rMarker + pBuffer->_nMarker ;
		pBuffer->_nMarker	++ ;
	}
	TMarker_Init (pMarker, fCursor) ;
	return	pMarker ;
}

BOOL
imeBuffer_DeleteMarker (
	CImeBuffer*			pBuffer,
	register CTMarker*	pMarker)
{
	register CTMarker*	pmkLast ;

	ASSERT (pBuffer != NULL) ;
	ASSERT (pMarker != NULL) ;
	ASSERT (pBuffer->_rMarker <= pMarker && pMarker < (pBuffer->_rMarker + MAXBUFMARKER)) ;

	pmkLast	= pBuffer->_rMarker + pBuffer->_nMarker ;
	if (pmkLast == pMarker) 
		pBuffer->_nMarker	-- ;
	TMarker_Invalidate (pMarker) ;
	return	TRUE ;
}

/*	fOpen: IME ���J����Ă��邩�����Ă��邩�B
 */
BOOL
imeBuffer_QueryProcessFunction (
	register int			nFuncNo)
{
	/*	���̃e�[�u���͊J����Ă��鎞�̏����p�B
	 */
	static const BOOL		srfProcessTbl [NUM_FUNCTIONS]	= {
		TRUE,	//  FUNCNO_SELF_INSERT_CHARACTER,
		TRUE,	//  FUNCNO_J_SELF_INSERT,
		TRUE,	//  FUNCNO_J_ZENKAKU_INSERT, 
		TRUE,	//  FUNCNO_J_DISPLAY_CODE_FOR_CHAR_AT_POINT,
		TRUE,	//	FUNCNO_J_SET_HENKAN_POINT,
		TRUE,	//	FUNCNO_J_SET_HENKAN_POINT_SUBR,
		TRUE,	//	FUNCNO_J_INSERT_A,
		TRUE,	//	FUNCNO_J_INSERT_E,
		TRUE,	//	FUNCNO_J_INSERT_I,
		TRUE,	//	FUNCNO_J_INSERT_O,
		TRUE,	//	FUNCNO_J_INSERT_U,
		TRUE,	//	FUNCNO_J_KANA_INPUT,
		TRUE,	//	FUNCNO_J_START_HENKAN,
		TRUE,	//	FUNCNO_J_INSERT_COMMA,
		TRUE,	//	FUNCNO_J_INSERT_PERIOD,
		TRUE,	//	FUNCNO_J_PURGE_FROM_JISYO,
		TRUE,	//	FUNCNO_J_INPUT_BY_CODE_OR_MENU,
		TRUE,	//	FUNCNO_J_MODE_OFF,
		TRUE,	//	FUNCNO_J_TOGGLE_KANA,
		TRUE,	//	FUNCNO_J_PREVIOUS_CANDIDATE,
		TRUE,	//	FUNCNO_J_KAKUTEI,
		TRUE,	//	FUNCNO_J_ABBREV_INPUT,
		TRUE,	//	FUNCNO_J_ABBREV_PERIOD,
		TRUE,	//	FUNCNO_J_ABBREV_COMMA,
		TRUE,	//	FUNCNO_J_ZENKAKU_EIJI,
		TRUE,	//	FUNCNO_J_ZENKAKU_HENKAN,
		TRUE,	//	FUNCNO_J_TODAY,
		TRUE,	//	FUNCNO_J_MODE_OFF_AND_SELF_INSERT,
		TRUE,	//	FUNCNO_J_KANAINPUT_MODE_ON,
		TRUE,	//	FUNCNO_J_NEWLINE,
		FALSE,	//	FUNCNO_J_SET_MARK_COMMAND,
		FALSE,	//	FUNCNO_J_FORWARD_CHAR,
		FALSE,	//	FUNCNO_J_BACKWARD_CHAR,
		FALSE,	//	FUNCNO_J_DELETE_CHAR,
		FALSE,	//	FUNCNO_J_DELETE_BACKWARD_CHAR,
		FALSE,	//	FUNCNO_J_TRY_COMPLETION,
		FALSE,	//	FUNCNO_J_END_OF_LINE,
		FALSE,	//	FUNCNO_J_BEGINNING_OF_LINE,
		FALSE,	//	FUNCNO_J_KILL_LINE,
		FALSE,	//	FUNCNO_J_YANK,
		FALSE,	//	FUNCNO_J_KILL_REGION,
		FALSE,	//	FUNCNO_J_KILL_RING_SAVE,
		FALSE,	//	FUNCNO_J_EXCHANGE_POINT_AND_MARK,
		FALSE,	//	FUNCNO_J_PREVIOUS_LINE,
		FALSE,	//	FUNCNO_J_NEXT_LINE,
		FALSE,	//	FUNCNO_J_TRANSPOSE_CHARS,
		FALSE,	//	FUNCNO_J_REDRAW,
		FALSE,	//	FUNCNO_J_PREFIX_CHAR,
		FALSE,	//	FUNCNO_J_DELETE_REGION,
		FALSE,	//	FUNCNO_J_SENDBACK_KEY,
		FALSE,	//	FUNCNO_J_KEYBOARD_QUIT,
		TRUE,	//	FUNCNO_J_TOGGLE_JISX0201,
		TRUE,	//	FUNCNO_NOT_MODIFIED,
		FALSE,	//	FUNCNO_J_FORWARD_WORD,
		FALSE,	//	FUNCNO_J_BACKWARD_WORD,
		FALSE,	//	FUNCNO_J_UPCASE_WORD,
		FALSE,	//	FUNCNO_J_DOWNCASE_WORD,
		FALSE,	//	FUNCNO_J_CAPITALIZE_WORD,
		TRUE,	//	FUNCNO_TOGGLE_IME,
		FALSE,	//	FUNCNO_J_LEFT_ARROW,
		FALSE,	//	FUNCNO_J_UP_ARROW,
		FALSE,	//	FUNCNO_J_RIGHT_ARROW,
		FALSE,	//	FUNCNO_J_DOWN_ARROW,
		FALSE,	//	FUNCNO_INVALID_CHAR,
		TRUE,	//	FUNCNO_SAVEUSERJISYO,	�����܂ł� SELECTABLE_FUNCTION
		FALSE,	//	FUNCNO_NEWLINE,
		FALSE,	//	FUNCNO_J_COMPLETION,
		FALSE,	//	FUNCNO_MOUSE_DRAG_REGION,
		FALSE,	//	FUNCNO_MOUSE_DRAG_REGION_END,
		FALSE,	//	FUNCNO_OPENCANDIDATE,
		FALSE,	//	FUNCNO_REVERTTEXT,
		FALSE,	//	FUNCNO_COMPELETETEXT,
	} ;
	if (nFuncNo < 0 || nFuncNo >= NELEMENTS (srfProcessTbl))
		return	FALSE ;

	return	srfProcessTbl [nFuncNo] ;
}

/*========================================================================*
 */
BOOL
imeBuffer_JKatakanaHenkan (
	CImeBuffer*		pBuffer)
{
	register int	i, nStart, nEnd ;

	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJHenkanOn) 
		return	imeBuffer_JEmulateOriginalMap (pBuffer) ;
	if (pBuffer->_fJHenkanActive || pBuffer->_fJKatakana)
		return	TRUE ;
	pBuffer->_fJMode		= TRUE ;
	if (pBuffer->_nbufJPrefix > 0)
		return	FALSE ;
	nStart	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) ;
	nEnd	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	if (nEnd < nStart) 
		return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (pBuffer->_bufComp [i] == L'\n') 
			return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan key may not contain a new line character.") ;
	}
	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
	imeBuffer_JKatakanaRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint), TRUE) ;
	imeBuffer_JKakutei (pBuffer) ;
	return	TRUE ;
}

BOOL
imeBuffer_JHiraganaHenkan (
	CImeBuffer*		pBuffer)
{
	register int	i, nStart, nEnd ;

	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJHenkanOn) 
		return	imeBuffer_JEmulateOriginalMap (pBuffer) ;
	if (pBuffer->_fJHenkanActive || !pBuffer->_fJKatakana)
		return	TRUE ;
	pBuffer->_fJMode		= TRUE ;
	if (pBuffer->_nbufJPrefix > 0)
		return	FALSE ;
	nStart	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) ;
	nEnd	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	if (nEnd < nStart) 
		return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (pBuffer->_bufComp [i] == L'\n') 
			return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan key may not contain a new line character.") ;
	}
	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
	imeBuffer_JHiraganaRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
	imeBuffer_JKakutei (pBuffer) ;
	return	TRUE ;
}

BOOL
imeBuffer_JHankanaHenkan (
	CImeBuffer*		pBuffer)
{
	register int	i, nStart, nEnd ;

	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJHenkanOn) 
		return	imeBuffer_JEmulateOriginalMap (pBuffer) ;
	if (pBuffer->_fJHenkanActive || pBuffer->_fJisx0201)
		return	TRUE ;
	pBuffer->_fJMode		= TRUE ;
	if (pBuffer->_nbufJPrefix > 0)
		return	FALSE ;
	nStart	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) ;
	nEnd	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	if (nEnd < nStart) 
		return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (pBuffer->_bufComp [i] == L'\n') 
			return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan key may not contain a new line character.") ;
	}
	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
	imeBuffer_JHankanaRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
	imeBuffer_JKakutei (pBuffer) ;
	return	TRUE ;
}

BOOL
imeBuffer_JZenkanaHenkan (
	CImeBuffer*		pBuffer)
{
	register int	i, nStart, nEnd ;

	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJHenkanOn) 
		return	imeBuffer_JEmulateOriginalMap (pBuffer) ;
	if (pBuffer->_fJHenkanActive || ! pBuffer->_fJisx0201)
		return	TRUE ;
	pBuffer->_fJMode		= TRUE ;
	if (pBuffer->_nbufJPrefix > 0)
		return	FALSE ;
	nStart	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) ;
	nEnd	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	if (nEnd < nStart) 
		return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (pBuffer->_bufComp [i] == L'\n' || pBuffer->_bufComp [i] == L'\r') 
			return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan key may not contain a new line character.") ;
	}
	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
	imeBuffer_JZenkanaRegion (pBuffer, nStart, nEnd, pBuffer->_fJKatakana) ;
	imeBuffer_JKakutei (pBuffer) ;
	return	TRUE ;
}

BOOL
imeBuffer_JZenkakuHenkan (
	CImeBuffer*		pBuffer)
{
	register int	n, nStart, nEnd ;

	ASSERT (pBuffer != NULL) ;

	if (! pBuffer->_fJHenkanOn) 
		return	imeBuffer_JEmulateOriginalMap (pBuffer) ;
	if (pBuffer->_fJHenkanActive)
		return	TRUE ;
	pBuffer->_fJMode	= TRUE ;
	if (pBuffer->_nbufJPrefix > 0)
		return	FALSE ;
	nStart	= TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) ;
	nEnd	= TMarker_GetPosition (pBuffer->_pmkPoint) ;
	if (nEnd < nStart) 
		return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan end point must be after henkan start point.") ;
	for (n = nStart ; n < nEnd ; n ++) {
		if (pBuffer->_bufComp [n] == L'\n' || pBuffer->_bufComp [n] == L'\r') 
			return	ImeDoc_SetMessage (pBuffer->_pDoc, L"Henkan key may not contain a new line character.") ;
	}
	imeBuffer_SetMarker (pBuffer, &pBuffer->_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, pBuffer->_pmkPoint) ;
	imeBuffer_JZenkakuRegion (pBuffer, nStart, nEnd) ;
	imeBuffer_JKakutei (pBuffer) ;
	return	TRUE ;
}

BOOL
imeBuffer_JKatakanaRegion (
	CImeBuffer*		pBuffer,
	register int	nStartPoint,
	register int	nEndPoint,
	register BOOL	fVContract)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > pBuffer->_nbufComp)
		return	FALSE ;

	n	= JHiragana2Katakana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufComp + nStartPoint, nEndPoint - nStartPoint, fVContract) ;
	imeBuffer_DeleteRegion (pBuffer, nStartPoint, nEndPoint) ;
	imeBuffer_InsertEx (pBuffer, nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
imeBuffer_JHiraganaRegion (
	CImeBuffer*		pBuffer,
	register int	nStartPoint,
	register int	nEndPoint)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > pBuffer->_nbufComp)
		return	FALSE ;

	n	= JKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	imeBuffer_DeleteRegion (pBuffer, nStartPoint, nEndPoint) ;
	imeBuffer_InsertEx (pBuffer, nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
imeBuffer_JHankanaRegion (
	CImeBuffer*		pBuffer,
	register int	nStartPoint,
	register int	nEndPoint)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > pBuffer->_nbufComp)
		return	FALSE ;

	n	= JZenkana2Hankana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	imeBuffer_DeleteRegion (pBuffer, nStartPoint, nEndPoint) ;
	imeBuffer_InsertEx (pBuffer, nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
imeBuffer_JZenkanaRegion (
	CImeBuffer*		pBuffer,
	register int	nStartPoint,
	register int	nEndPoint,
	register BOOL	fKatakana)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > pBuffer->_nbufComp)
		return	FALSE ;

	if (fKatakana) {
		n	= JHankana2Katakana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	} else {
		n	= JHankana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	}
	imeBuffer_DeleteRegion (pBuffer, nStartPoint, nEndPoint) ;
	imeBuffer_InsertEx (pBuffer, nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
imeBuffer_JZenkakuRegion (
	CImeBuffer*		pBuffer,
	register int	nStartPoint,
	register int	nEndPoint)
{
	WCHAR		wszBuffer [MAXCOMPLEN] ;
	register WCHAR*		pwsrc ;
	register WCHAR*		pwdest ;
	register int		nwdest, nwsrc, n ;
	LPCWSTR		wstrWord ;
	int			nstrWord ;

	if (nStartPoint < 0 || nEndPoint < nStartPoint || nEndPoint > pBuffer->_nbufComp)
		return	FALSE ;

	pwsrc	= pBuffer->_bufComp + nStartPoint ;
	nwsrc	= nEndPoint - nStartPoint ;
	pwdest	= wszBuffer ;
	nwdest	= NELEMENTS (wszBuffer) ;

	while (nwsrc > 0 && nwdest > 0) {
		if (0x20 <= *pwsrc && *pwsrc <= 0x7E) {
			wstrWord	= ImeDoc_GetSkkZenkakuVector (pBuffer->_pDoc, *pwsrc, &nstrWord) ;
			if (nstrWord > 0) {
				n	= (nstrWord < nwdest)? nstrWord : nwdest ;
				memcpy (pwdest, wstrWord, nstrWord * sizeof (WCHAR)) ;
				pwdest	+= n ;
				nwdest	-= n ;
			} else {
				*pwdest	++ = *pwsrc + (TEXT('�`') - TEXT('A')) ;
				nwdest -- ;
			}
		}
		pwsrc	++ ;
		nwsrc	-- ;
	}
	imeBuffer_DeleteRegion (pBuffer, nStartPoint, nEndPoint) ;
	imeBuffer_InsertEx (pBuffer, nStartPoint, wszBuffer, pwdest - wszBuffer) ;
	return	TRUE ;
}   

BOOL
imeBuffer_JUpdateJisyo (
	CImeBuffer*			pBuffer,
	register LPCWSTR	wstrResult,
	register int		nstrResult,
	register BOOL		fRecord)
{
	register LPCWSTR	wstrHenkanKey ;
	register int		nstrHenkanKey ;
	register BOOL		fRetval ;
	register BOOL		fOkuriAri	= FALSE ;
	WCHAR				wszBuffer [MAXCOMPLEN] ;
	
#if defined (DEBUG) || defined (DBG)
	int					n ;
	n	= (nstrResult < (MAXCOMPLEN - 1))? nstrResult : (MAXCOMPLEN - 1) ;
	lstrncpyW (wszBuffer, wstrResult, n) ;
	wszBuffer [n]	= L'\0' ;
	DEBUGPRINTFEX (103, (TEXT ("JUpdateJisyo (buffer:%p, result:\"%s\"(%d), record:%d)\n"), 
						 pBuffer, wszBuffer, fRecord)) ;
#endif

	/*	���艼���ϊ����ǂ����̔��f�B*/
	if (pBuffer->_nbufJHenkanKey > 0) {
		WCHAR	ch	= pBuffer->_bufJHenkanKey [pBuffer->_nbufJHenkanKey - 1] ;
		if (pBuffer->_bufJHenkanKey [0] > 127 && L'a' <= ch && ch <= L'z')
			fOkuriAri	= TRUE ;
	}
	/*	�Љ����ϊ��𕽉����ϊ��Ƃ��Ĉ����ꍇ�ɂ́A�o�^��폜�̎��ɂ�
	 *	���ӂ𕥂�Ȃ���΂Ȃ�Ȃ��B
	 */
	if (ImeDoc_IsSkkKatakanaHiraganaHenkanp (pBuffer->_pDoc)) {
		if (fOkuriAri) {
			nstrHenkanKey	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufJHenkanKey, pBuffer->_nbufJHenkanKey) ;
		} else {
			nstrHenkanKey	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), pBuffer->_bufJSearchKey, pBuffer->_nbufJSearchKey) ;
		}
		wstrHenkanKey	= wszBuffer ;
	} else {
		if (fOkuriAri) {
			wstrHenkanKey	= pBuffer->_bufJHenkanKey ;
			nstrHenkanKey	= pBuffer->_nbufJHenkanKey ;
		} else {
			wstrHenkanKey	= pBuffer->_bufJSearchKey ;
			nstrHenkanKey	= pBuffer->_nbufJSearchKey ;
		}
	}
	if (fRecord) {
		fRetval	= RecordCandidate (wstrHenkanKey, nstrHenkanKey, wstrResult, nstrResult, fOkuriAri) ;
	} else {
		fRetval	= PurgeCandidate (wstrHenkanKey, nstrHenkanKey, wstrResult, nstrResult, fOkuriAri) ;
	}
	return	fRetval ;
}

/*	�u#4�v�����ۂɉ��ɕϊ����ꂽ���𒲂ׂāA��������[�U�����ɓo�^����B�Ⴆ�΁A
 *	�u#4�v���ϊ�����āu/�P/��/�v�ɕϊ�����āA�u�P�v�Ŋm�肵���Ƃ���ƁA
 *	�u1 /�P/�v�̃G���g�������[�U�����ɍ쐬����B
 */
BOOL
imeBuffer_JSharp4UpdateJisyo (
	CImeBuffer*			pBuffer,
	BOOL				fRecord)
{
	LPCWSTR	wpNoConv, wpConv, pNum ;
	int		nNum ;
	WCHAR	wszBuffer [MAXCOMPLEN] ;

	DEBUGPRINTFEX (103, (TEXT ("imeBuffer_JSharp4UpdateJisyo (%p)\n"), pBuffer)) ;

	if (! ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc))
		return	FALSE ;

	/*	�����炪�u#4�v�Łu�Č����v����L�[���[�h��������������T���̂�
	 *	�K�v�B*/
	pNum	= pBuffer->_bufJNumList ;
	nNum	= pBuffer->_nbufJNumList ;

	/*	�����炪�ϊ��O�̕�����B*/
	wpNoConv	= THenkanSession_GetReferCandidate (pBuffer->_pHenkanSession) ;
	/*	�����炪�ϊ���̕�����B*/
	wpConv	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;

	DEBUGPRINTFEX (103, (TEXT ("Conv(\"%s\"), NoConv(\"%s\")\n"), 
						 (wpConv?   wpConv : L""),
						 (wpNoConv? wpNoConv : L""))) ;
	if (wpNoConv == NULL || wpConv == NULL)
		return	FALSE ;

	/*	pNum       -> /1/2/3/4/5// (���ۂ� separator �� NUL ����)
	 *	wstrNoConv -> ��#1��#2��#3��#4��#1
	 *	wstrConv   -> ��1���Q���O���l��5
	 *	���̒�����A(4 #4 �l) �̃y�A�𔭌�����B 
	 *
	 *	���� #4 �ϊ��̌��ʂ͔C�ӂ��Ƃ������Ƃ��B�P���ɕ��������X�L�b�v�ł�
	 *	�ς܂Ȃ����낤�B
	 */
	for ( ; ; ) {
		/*	�����ϊ��̂Ƃ�������O����΁A���҂͈�v���Ă��锤�B*/
		while (*wpNoConv == *wpConv && *wpNoConv != L'#') {
			if (*wpNoConv == L'\0')
				goto	exit ;
			wpNoConv	++ ;
			wpConv		++ ;
		}
		/*	�ϊ����ʂ� # �͉����ɒu���������Ă��锤�B*/
		if (*wpNoConv == L'#') {
			int		nCmd ;

			wpNoConv	++ ;
			if (*wpNoConv == L'\0') {
				/*	������ # �ł����Ȃ������ꍇ�ɂ́A�����𔲂���B*/
				goto	exit ;
			}

			nCmd	= *wpNoConv ++ ;
			/*	�A������ #? �͑S�ăX�L�b�v����B�ŏ��� #? �������L���B*/
			while (*wpNoConv == L'#' &&
				   L'0' <= *(wpNoConv + 1) && *(wpNoConv + 1) <= L'9') {
				wpNoConv	+= 2 ;
			}

			/*	#4 �ϊ��̎������v���ӁB*/
			if (*wpNoConv != L'4') {
				LPCWSTR	wpStart	= wpConv ;

				/*	�C�ӂ̕����� #4 �ϊ��̌��ʁA�o������\��������B
				 *	�Ƃ������Ƃ́A�����ɉ����������̂��𔻒f���邱�Ƃ�
				 *	�s�\���A���Ȃ莞�Ԃ�������B
				 *	�����͍ő��v�̖@���ōs���B��ԍŌ�� NoConv ��
				 *	``4'' �ɑ��������� Conv �ɏo�������ꏊ��Ó��ł�
				 *	��Ɣ��f����B
				 */
				wpStart	= wpConv ;
				for ( ; ; ) {
					LPCWSTR	wptrL, wptrR ;

					while (*wpNoConv != *wpConv && *wpConv != L'\0') 
						wpConv	++ ;
					/*	�Ō�܂Ō������Ă��܂����B*/
					if (*wpConv == L'\0')
						break ;

					/*	wpConv �� wpNoConv ����v�����B�ǂ̈ʂ������
					 *	��v���Ă���̂��m�F����B*/
					wptrL	= wpNoConv ;
					wptrR	= wpConv ;
					if (*wptrL == *wptrR) {
						while (*wptrL == *wptrR && *wptrL != L'\0') {
							wptrL	++ ;
							wptrR	++ ;
						}
						/*	���̒i�K�Łu�ǂ̕����v�ňႤ�Əo���̂���������
						 *	���҂��قȂ���̂��w�������R���A``#'' �Ȃ�c
						 *	�����܂ł͈�v�����ƌ���B
						 *	#4 �ϊ��̌��ʂ� # �͓��삵�Ȃ��悤�ɒ@��������
						 *	����̂ŁA�\���ڈ��Ƃ��ē������c�B
						 */
						if (*wptrL == L'#') {
							break ;
						}
						if (*wptrL == L'\0' && *wptrR == L'\0') 
							break ;
					}
				}
				/*	wpStart ���� wpConv ���w���ʒu�܂ł��A#4 �ϊ��̌��ʂ���
				 *	��������B*/
				if (nNum > 0 && *pNum != L'\0') {
#if defined (DBG) || defined (DEBUG)
					int	n	= wpConv - wpStart ;
					if (n > (NELEMENTS (wszBuffer) - 1))
						n	= NELEMENTS (wszBuffer) - 1 ;
					lstrncpyW (wszBuffer, wpStart, n) ;
					wszBuffer [n]	= L'\0' ;
					DEBUGPRINTFEX (103, (TEXT ("#4 record \"%s\" -> \"%s\"\n"), pNum, wszBuffer)) ;
#endif
					if (fRecord) {
						if (! RecordCandidate (pNum, lstrlenW (pNum), wpStart, wpConv - wpStart, FALSE))
							goto	exit ;
					} else {
						if (! PurgeCandidate (pNum, lstrlenW (pNum), wpStart, wpConv - wpStart, FALSE))
							goto	exit ;
					}
					JNumSkip (&pNum, &nNum) ;
				}
			} else {
				/*	���̏ꍇ�ɂ͏����ɐ��l�����X�L�b�v����Ηǂ��B
				 *	���A�ǂ̒��x�X�L�b�v����Ηǂ��̂��́A���Ȃ�
				 *	����B
				 *	���ǁA�ēx expand ���Ă݂āA���̕�����������
				 *	skip ����̂����E�B
				 */
				int	n	= JNumExp (wszBuffer, NELEMENTS (wszBuffer), nCmd, &pNum, &nNum) ;
				while (*wpConv != L'\0' && n -- > 0)
					wpConv	++ ;
			}
		} else {
			/*	���̎��Ԃ͓�B# �������ė��҂��s��v�Ƃ͂ǂ��������Ƃ��낤�H
			 */
			DEBUGPRINTFEX (103, (TEXT ("\"%s\" != \"%s\"\n"), wpNoConv, wpConv)) ;
			goto	exit ;
		}
	}
  exit:
	return	TRUE ;
}

int
imeBuffer_GetShiftCount (
	CImeBuffer*			pBuffer)
{
	register int	nCursor, nShift ;
	register int	nKanaStartPoint, nHenkanStartPoint, nHenkanEndPoint ;
	register int	nOkuriStartPoint ;

	nCursor	= TMarker_GetPosition (pBuffer->_pmkPoint) ;

	if (! pBuffer->_fJMode) 
		return	nCursor ;

	nKanaStartPoint		= (pBuffer->_nbufJPrefix > 0 &&
						   pBuffer->_pmkJKanaStartPoint != NULL)?
		TMarker_GetPosition (pBuffer->_pmkJKanaStartPoint) : MAXCOMPLEN ;
	nHenkanStartPoint	= (pBuffer->_fJHenkanOn      &&
						   pBuffer->_pmkJHenkanStartPoint != NULL)?
		TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint) - 1 : MAXCOMPLEN ;
	nHenkanEndPoint		= (pBuffer->_fJHenkanActive  &&
						   pBuffer->_pmkJHenkanEndPoint != NULL)?
		TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint) : MAXCOMPLEN ;
	nOkuriStartPoint	= (pBuffer->_fJOkurigana     &&
						   pBuffer->_pmkJOkuriganaStartPoint != NULL)?
		TMarker_GetPosition (pBuffer->_pmkJOkuriganaStartPoint) : MAXCOMPLEN ;
	
	nShift	= nCursor ;
	nShift	= (nShift > nKanaStartPoint)?   nKanaStartPoint :   nShift ;
	nShift	= (nShift > nHenkanStartPoint)? nHenkanStartPoint : nShift ;
	nShift	= (nShift > nHenkanEndPoint)?   nHenkanEndPoint :   nShift ;
	nShift	= (nShift > nOkuriStartPoint)?  nOkuriStartPoint :  nShift ;
	return	nShift ;
}

/*========================================================================*
 */
BOOL
THenkanInMinibuffSession_OnExit (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer,
	register LPCWSTR		wstrResult,
	register int			nstrResult)
{
	register CImeBuffer*	pBuffer	= pSession->_pBuffer ;
	register CTMarker*		pMarker ;
	register int			nJPrefix ;
	LPCWSTR					wptr ;
	int						nwptr ;
	BOOL					fSharp4	= FALSE ;

	/*	�O�ɂ������Ă���󔒂͍폜����B
	 */
	while (nstrResult > 0 && *wstrResult == L' ') {
		wstrResult	++ ;
		nstrResult	-- ;
	}

	/*	���ɂ������Ă���󔒂͍폜����B
	 */
	wptr	= wstrResult + nstrResult - 1 ;
	nwptr	= nstrResult ;
	while (nwptr > 0 && *wptr == L' ') {
		wptr	-- ;
		nwptr	-- ;
	}
	nstrResult	= nwptr ;

	if (nstrResult <= 0) {
		/*	�������͂��ꂸ�Ɍ��ʂ��Ԃ��ꂽ�ꍇ�B*/
		if (pBuffer->_nJHenkanCount <= 0) {
			pBuffer->_fJHenkanActive	= FALSE ;
			pBuffer->_nbufJHenkanKey2	= 0 ;
			pMarker		= imeBuffer_MakeMarker (pBuffer, FALSE) ;
			if (pMarker != NULL) {
				TMarker_SetPosition (pMarker, pBuffer->_pmkJHenkanStartPoint) ;
				imeBuffer_JChangeMarkerToWhite (pBuffer) ;
				TMarker_SetPosition (pBuffer->_pmkJHenkanStartPoint, pMarker) ;
				imeBuffer_DeleteMarker (pBuffer, pMarker) ;
			}
			/*	���̈ʒu���ƁA���Ƃ��� j-henkan-show-candidates-mode ��
			 *	�Ȃ��C�͂��邯��ǔO�̂��߂� imeBuffer_NormalFilter ��
			 *	���Ă����B
			 */
			pBuffer->_pFilterProc	= (pBuffer->_pFilterProc != imeBuffer_JKanaInputFilter)? imeBuffer_NormalFilter : pBuffer->_pFilterProc ;
		} else if (pBuffer->_nJHenkanCount > 4) {
			imeBuffer_ShowJHenkanCandidates (pBuffer) ;
		}
	} else {
		/*	#4 �ϊ����܂ތ���o�^�����Ƃ���΁A���� #4 ���ɑ΂���o�^
		 *	���K�v�ɂȂ�B
		 *	pBuffer ���� number-list �ɍ���̕ϊ����ʂł���AwstrResult
		 *	���� #4 ���`�F�b�N���c�B
		 */
		if (pBuffer->_nbufJNumList > 0 &&
			ImeDoc_IsSkkUseNumericConversionp (pBuffer->_pDoc) &&
			JSharp4Stringp (wstrResult, nstrResult)) {
			LPCWSTR	pNum ;
			LPWSTR	wpDest ;
			int		nDest, nNum, n ;

			/*	��̊m��� number-list ���N���A����Ă��܂��̂ŗv���ӁB
			 *	�����ŕۑ�����B
			 */
			wptr	= wstrResult ;
			nwptr	= nstrResult ;
			pNum	= pBuffer->_bufJNumList ;
			nNum	= pBuffer->_nbufJNumList ;
			wpDest	= pCurBuffer->_bufJNumList ;
			nDest	= NELEMENTS (pCurBuffer->_bufJNumList) - 2 ;
			while (nwptr > 0 && nDest > 0) {
				if (*wptr == L'#') {
					wptr  ++ ;
					nwptr -- ;
					/*	#4 �ɑ�������ꏊ�ɂ����A�����o���B*/
					if (nwptr > 0 && *wptr == L'4') {
						n	= lstrlenW (pNum) ;
						n	= (n < nDest)? n : nDest ;
						lstrncpyW (wpDest, pNum, n) ;
						wpDest	+=	n ;
						nDest	-=  n ;
						*wpDest ++	= L'\0' ;
						nDest	-- ;
					}
					JNumSkip (&pNum, &nNum) ;
				}
				wptr	++ ;
				nwptr	-- ;
			}
			/*	NUL NUL �ŏI�[����Ȃ��Ƃ����Ȃ��̂����c�o�b�t�@��
			 *	���ӂ�ĂȂ����ǂ������ӂ���B
			 */
			n	= wpDest - pCurBuffer->_bufJNumList ;
			if (n < NELEMENTS (pCurBuffer->_bufJNumList)) {
				*wpDest	= L'\0' ;
				n	++ ;
			}
			pCurBuffer->_nbufJNumList	= n ;

			if (pCurBuffer->_nbufJNumList > 0 &&
				pCurBuffer->_bufJNumList [0] != L'\0') {
				WCHAR	wszBuffer [MAXCOMPLEN] ;
				int		n ;

				/*	�ϊ����ʂ��L�����Ă����B*/
				pBuffer->_nbufJHenkanResult	= (nstrResult < MAXPREFIXLEN)? nstrResult : MAXPREFIXLEN ;
				memcpy (pBuffer->_bufJHenkanResult, wstrResult, pBuffer->_nbufJHenkanResult * sizeof (WCHAR)) ;

				ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;

				/*	���[��Anumber-list �������̒N�ɋL�������Ă����ׂ��Ȃ̂�
				 *	���̈����������߂���B
				 *	�܂��Aparent buffer �ɋL�������Ă����ׂ����낤���c�B
				 */
				n	= wnsprintfW (wszBuffer, MAXCOMPLEN, L"%s ", pCurBuffer->_bufJNumList) ;

				TRecursiveEditSession_Init (&pBuffer->_RecursiveEditSession, pBuffer, TSharp4HenkanInMinibuffSession_OnExit, TSharp4HenkanInMinibuffSession_OnAbort) ;
				if (ImeDoc_ReadFromMinibuffer (pBuffer->_pDoc, wszBuffer, n, &pBuffer->_RecursiveEditSession)) {
					CImeBuffer*	pNewBuffer	= ImeDoc_GetCurrentBuffer (pBuffer->_pDoc) ;
					if (pNewBuffer != NULL) {
						memcpy (pNewBuffer->_bufJNumList, pCurBuffer->_bufJNumList, sizeof (WCHAR) * pCurBuffer->_nbufJNumList) ;
						pNewBuffer->_nbufJNumList	= pCurBuffer->_nbufJNumList ;
					}
				}
				return	TRUE ;
			}
		}

		imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
		imeBuffer_JInsertWord (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), wstrResult, nstrResult) ;

		/*	
		 */
		imeBuffer_JUpdateJisyo (pBuffer, wstrResult, nstrResult, TRUE) ;

		nJPrefix		= pBuffer->_nbufJPrefix ;
		pBuffer->_nJHenkanCount	= 0 ;

		/*	JKakutei ���Ă΂��� number-list ���N���A����Ă��܂��̂ŁA
		 *	#4 �ϊ��̏ꍇ�ɂ͒��ӂ��K�v�B
		 */
		imeBuffer_JKakutei (pBuffer) ;

		pBuffer->_nbufJPrefix	= nJPrefix ;
		/*	ImeDoc_ExitMinibuffer �ł� j-henkan-show-candidates-mode 
		 *	�𔲂��Ȃ��B�e�̃o�b�t�@�����̏�Ԃ̂܂܂ɂ���c���ێ�����
		 *	���܂��̂ŁA������ NormalFilter �ɖ߂��B
		 */
		pBuffer->_pFilterProc	= (pBuffer->_pFilterProc != imeBuffer_JKanaInputFilter)? imeBuffer_NormalFilter : pBuffer->_pFilterProc ;
	}
	ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;

	/*	#4 �ϊ��̏ꍇ�ɂ́A�����Őe�o�b�t�@�ɖ߂��Ă��܂��킯�ɂ͂���
	 *	�Ȃ��B
	 */
	return	TRUE ;
	UNREFERENCED_PARAMETER (pCurBuffer) ;
}
	
BOOL
THenkanInMinibuffSession_OnAbort (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer)
{
	ASSERT (pSession != NULL) ;
	ASSERT (pSession->_pExitProc != NULL) ;
	return	(pSession->_pExitProc)(pSession, pCurBuffer, NULL, 0) ;
}

/*	#4 �o�^�� Exit ���I�����ꂽ�ꍇ�̏����B
 */
BOOL
TSharp4HenkanInMinibuffSession_OnExit (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer,
	register LPCWSTR		wstrResult,
	register int			nstrResult)
{
	register CImeBuffer*	pBuffer	= pSession->_pBuffer ;
	LPCWSTR					wptr, pNum ;
	int						nwptr, nNum ;

	/*	�O�ɂ������Ă���󔒂͍폜����B
	 */
	while (nstrResult > 0 && *wstrResult == L' ') {
		wstrResult	++ ;
		nstrResult	-- ;
	}

	/*	���ɂ������Ă���󔒂͍폜����B
	 */
	wptr	= wstrResult + nstrResult - 1 ;
	nwptr	= nstrResult ;
	while (nwptr > 0 && *wptr == L' ') {
		wptr	-- ;
		nwptr	-- ;
	}
	nstrResult	= nwptr ;

	pNum	= pBuffer->_bufJNumList ;
	nNum	= pBuffer->_nbufJNumList ;
	if (nstrResult > 0 && nNum > 0) {
		/*	���ɑ΂���o�^���ƌ����Ɓc����� pBuffer �� number-list ��
		 *	�]���B
		 */
		if (! RecordCandidate (pNum, lstrlenW (pNum), wstrResult, nstrResult, FALSE)) {
			/*	�G���[�� abort �����̏����ɂ��邩�B
			 */
			pNum	= NULL ;
			nNum	= 0 ;
		} else {
			JNumSkip (&pNum, &nNum) ;
		}
	} else {
		/*	���̏ꍇ�̓X�L�b�v�̏����ɂȂ�B*/
		JNumSkip (&pNum, &nNum) ;
	}
	/*	���� fiterproc �̏C���͕s�v�̔��B
	 *	pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
	 */
	ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;

	if (nNum > 0 && *pNum != L'\0') {
		WCHAR	wszBuffer [MAXCOMPLEN] ;
		int		n ;
		
		/*	������̃R�s�[�̗����c (;_;) */
		memmove (pBuffer->_bufJNumList, pNum, nNum * sizeof (WCHAR)) ;
		pBuffer->_nbufJNumList	= nNum ;

		/*	�ēx�A�o�^�ɓ���B
		 */
		n	= wnsprintfW (wszBuffer, MAXCOMPLEN, L"%s ", pBuffer->_bufJNumList) ;
		TRecursiveEditSession_Init (&pBuffer->_RecursiveEditSession, pBuffer, TSharp4HenkanInMinibuffSession_OnExit, TSharp4HenkanInMinibuffSession_OnAbort) ;
		return	ImeDoc_ReadFromMinibuffer (pBuffer->_pDoc, wszBuffer, n, &pBuffer->_RecursiveEditSession) ;
	} else {
		int	nJPrefix ;

		imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
		imeBuffer_JInsertWord (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), pBuffer->_bufJHenkanResult, pBuffer->_nbufJHenkanResult) ;

		/*	
		 */
		imeBuffer_JUpdateJisyo (pBuffer, pBuffer->_bufJHenkanResult, pBuffer->_nbufJHenkanResult, TRUE) ;

		nJPrefix		= pBuffer->_nbufJPrefix ;
		pBuffer->_nJHenkanCount	= 0 ;

		/*	JKakutei ���Ă΂��� number-list ���N���A����Ă��܂��̂ŁA
		 *	#4 �ϊ��̏ꍇ�ɂ͒��ӂ��K�v�B
		 */
		imeBuffer_JKakutei (pBuffer) ;

		pBuffer->_nbufJPrefix	= nJPrefix ;
		/*	ImeDoc_ExitMinibuffer �ł� j-henkan-show-candidates-mode 
		 *	�𔲂��Ȃ��B�e�̃o�b�t�@�����̏�Ԃ̂܂܂ɂ���c���ێ�����
		 *	���܂��̂ŁA������ NormalFilter �ɖ߂��B
		 */
		pBuffer->_pFilterProc		= imeBuffer_NormalFilter ;
		pBuffer->_nbufJHenkanResult	= 0 ;
		pBuffer->_nbufJNumList		= 0 ;
	}
	return	TRUE ;
}

BOOL
TSharp4HenkanInMinibuffSession_OnAbort (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer)
{
	register CImeBuffer*	pBuffer	= pSession->_pBuffer ;
	CTMarker*	pMarker ;

	/*	�������͂��ꂸ�Ɍ��ʂ��Ԃ��ꂽ�ꍇ�B*/
	if (pBuffer->_nJHenkanCount <= 0) {
		pBuffer->_fJHenkanActive	= FALSE ;
		pBuffer->_nbufJHenkanKey2	= 0 ;
		pMarker		= imeBuffer_MakeMarker (pBuffer, FALSE) ;
		if (pMarker != NULL) {
			TMarker_SetPosition (pMarker, pBuffer->_pmkJHenkanStartPoint) ;
			imeBuffer_JChangeMarkerToWhite (pBuffer) ;
			TMarker_SetPosition (pBuffer->_pmkJHenkanStartPoint, pMarker) ;
			imeBuffer_DeleteMarker (pBuffer, pMarker) ;
		}
		/*	���̈ʒu���ƁA���Ƃ��� j-henkan-show-candidates-mode ��
		 *	�Ȃ��C�͂��邯��ǔO�̂��߂� imeBuffer_NormalFilter ��
		 *	���Ă����B
		 */
		pBuffer->_pFilterProc	= imeBuffer_NormalFilter ;
	} else if (pBuffer->_nJHenkanCount > 4) {
		imeBuffer_ShowJHenkanCandidates (pBuffer) ;
	}
	ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;
	return	TRUE ;
}

BOOL
JInputByCodeOrMenuSession_OnExit (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer,
	register LPCWSTR		wstrResult,
	register int			nstrResult)
{
	register CImeBuffer*	pBuffer	= pSession->_pBuffer ;
	register int	n1, n2 ;

	n1	= n2	= 128 ;
	if (nstrResult > 0) {
		if (nstrResult >= 1) 
			n1	+= 16 * Hex2Int (*wstrResult) ;
		if (nstrResult >= 2)
			n1	+= Hex2Int (*(wstrResult + 1)) ;
		if (nstrResult >= 3)
			n2	+= 16 * Hex2Int (*(wstrResult + 2)) ;
		if (nstrResult >= 4)
			n2	+= Hex2Int (*(wstrResult + 3)) ;
	}
	if (n1 > 160) {
		WCHAR	wch		= JCharToUnicode ((WORD)((n1 << 8) | n2)) ;
		imeBuffer_Insert (pBuffer, &wch, 1) ;
	} else {
		imeBuffer_JInputByCodeOrMenu0Start (pBuffer, n1, n2) ;
	}
	ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pCurBuffer) ;
}

BOOL
JInputByCodeOrMenuSession_OnAbort (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer)
{
	register CImeBuffer*	pBuffer	= pSession->_pBuffer ;

	ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pCurBuffer) ;
}

BOOL
JPurgeSession_OnExit (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer,
	register LPCWSTR		wstrResult,
	register int			nstrResult)
{
	register CImeBuffer*	pBuffer	= pSession->_pBuffer ;
	register LPCWSTR		wstrCandidate ;
	register int	nTop ;

	if (nstrResult == 3 && ! lstrncmpW (wstrResult, L"yes", nstrResult)) {
		/*	�폜����B*/
		ASSERT (pBuffer->_pHenkanSession != NULL) ;

		wstrCandidate	= THenkanSession_GetReferCandidate (pBuffer->_pHenkanSession) ;
		if (wstrCandidate == NULL) {
			wstrCandidate	= THenkanSession_GetCandidate (pBuffer->_pHenkanSession) ;
		} else {
			/*	���l�ϊ���������B*/
			imeBuffer_JSharp4UpdateJisyo (pBuffer, FALSE) ;
		}
		imeBuffer_JUpdateJisyo (pBuffer, wstrCandidate, lstrlenW (wstrCandidate), FALSE) ;
		imeBuffer_DeleteRegion (pBuffer, TMarker_GetPosition (pBuffer->_pmkJHenkanStartPoint), TMarker_GetPosition (pBuffer->_pmkJHenkanEndPoint)) ;
		imeBuffer_JChangeMarkerToWhite (pBuffer) ;
		pBuffer->_fJHenkanActive	= FALSE ;
		imeBuffer_JKakutei (pBuffer) ;
		ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;
		return	TRUE ;
	}
	if (nstrResult == 2 && ! lstrncmpW (wstrResult, L"no", nstrResult)) {
		/*	�폜���Ȃ��B*/
		ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;
		return	TRUE ;
	}
	if (pCurBuffer != NULL) {
		/*	���[�ɓ��͂��Ă��镶������폜���Čp������B*/
		nTop	= (pCurBuffer->_pmkEditTop == NULL)? 0 : TMarker_GetPosition (pCurBuffer->_pmkEditTop) ;
		imeBuffer_DeleteRegion (pCurBuffer, nTop, pCurBuffer->_nbufComp) ;
	}
	return	FALSE ;	/* ���̏ꍇ�͌p������B*/
}

BOOL
JPurgeSession_OnAbort (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pCurBuffer)
{
	register CImeBuffer*	pBuffer	= pSession->_pBuffer ;

	ImeDoc_ExitMinibuffer (pBuffer->_pDoc, pBuffer) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pCurBuffer) ;
}

