#if !defined (TRecursiveEditSession_h)
#define	TRecursiveEditSession_h

struct tagCImeBuffer ;

typedef struct tagCTRecursiveEditSession {
	struct tagCImeBuffer*	_pBuffer ;
	BOOL					(*_pExitProc)(struct tagCTRecursiveEditSession*, struct tagCImeBuffer*, LPCWSTR, int) ;
	BOOL					(*_pAbortProc)(struct tagCTRecursiveEditSession*, struct tagCImeBuffer*) ;
}	CTRecursiveEditSession ;

/* */
BOOL	TRecursiveEditSession_Init (CTRecursiveEditSession*, struct tagCImeBuffer*, BOOL (*)(CTRecursiveEditSession*, struct tagCImeBuffer*, LPCWSTR, int), BOOL (*)(CTRecursiveEditSession*, struct tagCImeBuffer*)) ;
BOOL	TRecursiveEditSession_Exit  (CTRecursiveEditSession*, struct tagCImeBuffer*, LPCWSTR, int) ;
BOOL	TRecursiveEditSession_Abort (CTRecursiveEditSession*, struct tagCImeBuffer*) ;

#endif

