#if !defined (ImeDocP_h)
#define	ImeDocP_h

#include "ImeDoc.h"
#include "ImeBuffer.h"
#include "TRomaKanaTable.h"
#include "TAssocRule.h"
#include "varbuffer.h"

struct tagCImeBuffer ;

struct tagCImeDoc {
	struct tagCImeBuffer*	_rpBuffer [MAXIMEBUFFER] ;
	int						_nBuffer ;
	struct tagCImeBuffer*	_rpUnusedBuffer [MAXIMEBUFFER] ;
	int						_nUnusedBuffer ;
	struct tagCImeBuffer*	_pCurBuffer ;

	WCHAR					_bufUnreadEvent [MAXUNREADEVENT] ;
	int						_nbufUnreadEvent ;
	WCHAR					_wchLastCommandChar ;
	WPARAM					_wKeyEvent ;
#if !defined (UNITTEST)
	LPARAM					_lKeyData ;
	CONST BYTE*				_pbKeyState ;
#endif

	WCHAR					_bufMessage [MSGBUFSIZE] ;
	int						_nbufMessage ;
	WCHAR					_bufMessage2 [MAXCOMPLEN+2] ;

	int						_nThisCommand ;
	int						_nLastCommand ;
	BOOL					_fFilter ;

	CTRomaKanaTable*		_rpRomaKanaTable [5] ;
	CTAssocRule**			_rpAssocRule ;
	int						_nAssocRule ;
	LPWSTR					_rstrInputVector [INPUTVECTORSIZE] ;
	LPWSTR					_rstrZenkakuVector [INPUTVECTORSIZE] ;
	LPWSTR					_pstrPrefixList ;
	const BYTE*				_pbyJMap ;
	const BYTE*				_pbyAbbrevMap ;
	BYTE					_rbyJMap [SIZE_IMEDOC_KEYMAP] ;
	BYTE					_rbyAbbrevMap [SIZE_IMEDOC_KEYMAP] ;
	int						_rnGenericConfig [NUMGENERICCONFIG] ;

	/*	CANDINFO �̌��\���p�� Minibuffer ���b�Z�[�W(or�ċA)�p�B
	 */
	TVarbuffer				_vbufCandInfo ;
	TVarbuffer				_vbufMessage ;

#if defined (UNITTEST)
	BYTE					_JHenkanShowCandidateKeys [NUM_JHENKAN_SHOW_CANDIDATE_KEYS] ;
	BYTE					_JInputByCodeOrMenuKeys1 [NUM_JINPUT_BY_CODE_OR_MENU_KEYS1] ;
	BYTE					_JInputByCodeOrMenuKeys2 [NUM_JINPUT_BY_CODE_OR_MENU_KEYS2] ;
#endif
	BOOL					_fKeymapInitialized ;
	BOOL					_fAssocRuleInitialized ;
	BOOL					_fRomaKanaTableInitialized ;
	BOOL					_fGenericConfigInitialized ;
	BOOL					_fSkkInputVectorInitialized ;
	BOOL					_fSkkZenkakuVectorInitialized ;
	BOOL					_fPrefixListInitialized	;
#if ! defined (UNITTEST)
	DWORD					_dwUpdateFlag ;
#endif

} ;

#endif

