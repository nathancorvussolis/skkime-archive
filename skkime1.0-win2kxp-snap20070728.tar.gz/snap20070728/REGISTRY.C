/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * registry.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "common\confcommon.h"

/*
 *	���W�X�g���̒l�𓾂�֐��B
 *-----
 *	DWORD
 */
BOOL	PASCAL
GetRegDwordValue (
	register LPCTSTR		lpszSubDir,
	register LPCTSTR		lpszFlag,
	register LPDWORD		lpDwValue)
{
	HKEY	hKey ;
	DWORD	dwRegType, dwData, dwDataSize, dwRet ;
	TCHAR	szRegInfoPath [MAX_PATH] ;

	dwData		= 0 ;
	dwDataSize	= sizeof (DWORD) ;
	/* ���W�X�g���̌����p�X��ݒ肷��B*/
	lstrcpy (szRegInfoPath, REGPATH_SKKIME_BASE) ;
	if (lpszSubDir)
		lstrcat (szRegInfoPath, lpszSubDir) ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, szRegInfoPath, 0, KEY_READ, &hKey) != ERROR_SUCCESS)
		return	FALSE ;
	dwRet	= RegQueryValueEx (hKey, lpszFlag, NULL, &dwRegType, (LPBYTE)&dwData, &dwDataSize) ;
	RegCloseKey (hKey) ;
	if (dwRegType != REG_DWORD)
		return	FALSE ;
	if (dwRet == ERROR_SUCCESS && lpDwValue)
		*lpDwValue	= dwData ;
	return	(dwRet == ERROR_SUCCESS) ;
}

long	PASCAL
GetRegStringValue (
	register LPCTSTR		lpszSubDir,
	register LPCTSTR		lpszFlag,
	register LPTSTR			lpString)
{
	HKEY	hKey ;
	DWORD	dwRegType, dwData, dwDataSize, dwRet ;
	TCHAR	szRegInfoPath [MAX_PATH] ;
	dwData		= 0 ;
	/* ���W�X�g���̌����p�X��ݒ肷��B*/
	lstrcpy (szRegInfoPath, REGPATH_SKKIME_BASE) ;
	if (lpszSubDir)
		lstrcat (szRegInfoPath, lpszSubDir) ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, szRegInfoPath, 0, KEY_READ, &hKey) != ERROR_SUCCESS)
		return	-1 ;
	dwRet	= RegQueryValueEx (hKey, lpszFlag, NULL, &dwRegType, (LPBYTE)lpString, &dwDataSize) ;
	RegCloseKey (hKey) ;
	if (dwRet != ERROR_SUCCESS || dwRegType != REG_SZ)
		return	-1 ;
	return	(long)dwDataSize ;
}

BOOL	PASCAL
SetRegDwordValue (
	register LPCTSTR		lpszSubDir, 
	register LPCTSTR		lpszFlag,
	DWORD					dwValue)
{
	HKEY	hKey ;
	DWORD	dwDisposition ;
	DWORD	dwDataSize, dwRet ;
	TCHAR	szRegInfoPath [MAX_PATH] ;

	/* ���W�X�g���̃p�X��ݒ肷��B*/
	lstrcpy (szRegInfoPath, REGPATH_SKKIME_BASE) ;
	if (lpszSubDir)
		lstrcat (szRegInfoPath, lpszSubDir) ;

	/* ���W�X�g�����J���B������΍쐬����B*/
	if (RegCreateKeyEx (HKEY_CURRENT_USER, szRegInfoPath, 0, 0, REG_OPTION_NON_VOLATILE, KEY_WRITE, 0, &hKey, &dwDisposition) != ERROR_SUCCESS)
		return	FALSE ;

	/* �l��ݒ肷��B*/
	dwRet = RegSetValueEx (hKey, lpszFlag, 0, REG_DWORD, (CONST BYTE *)&dwValue, sizeof(DWORD)) ;
	RegCloseKey (hKey) ;
	return	(dwRet == ERROR_SUCCESS) ;
}

BOOL	PASCAL
SetRegStringValue (
	register LPCTSTR		lpszSubDir,
	register LPCTSTR		lpszFlag,
	register LPTSTR			lpString)
{
	HKEY	hKey ;
	DWORD	dwDisposition ;
	DWORD	dwDataSize, dwRet ;
	TCHAR	szRegInfoPath [MAX_PATH] ;
	/* ���W�X�g���̃p�X��ݒ肷��B*/
	lstrcpy (szRegInfoPath, REGPATH_SKKIME_BASE) ;
	if (lpszSubDir)
		lstrcat (szRegInfoPath, lpszSubDir) ;
	/* ���W�X�g�����J���B������΍쐬����B*/
	if (RegCreateKeyEx (HKEY_CURRENT_USER, szRegInfoPath, 0, 0, REG_OPTION_NON_VOLATILE, KEY_WRITE, 0, &hKey, &dwDisposition) != ERROR_SUCCESS)
		return	FALSE ;
	/* �l��ݒ肷��B*/
	dwRet	= RegSetValueEx (hKey, lpszFlag, 0, REG_SZ, (CONST BYTE *)lpString, lstrlen (lpString) * sizeof (TCHAR)) ;
	RegCloseKey (hKey) ;
	return	(dwRet == ERROR_SUCCESS) ;
}



