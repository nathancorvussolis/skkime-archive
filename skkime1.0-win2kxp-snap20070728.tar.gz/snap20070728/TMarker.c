#include "local.h"
#include "TMarker.h"

BOOL
TMarker_Init (
	CTMarker*		pMarker,
	BOOL			fCursor)
{
	ASSERT (pMarker != NULL) ;
	pMarker->_iPosition	= 0 ;
	pMarker->_fCursor	= fCursor ;
	pMarker->_fValid	= TRUE ;
	return	TRUE ;
}

int
TMarker_GetPosition (
	CTMarker*		pMarker)
{
	ASSERT (pMarker != NULL) ;
	if (! pMarker->_fValid)	/* ������ marker ����ʒu�͂Ƃ�Ȃ��B*/
		return	-1 ;
	return	pMarker->_iPosition ;
}

BOOL
TMarker_Forward (
	CTMarker*		pMarker,
	int				n)
{
	register int	nPos ;

	ASSERT (pMarker != NULL) ;
	if (! pMarker->_fValid)
		return	FALSE ;
	nPos				= pMarker->_iPosition + n ;
	pMarker->_iPosition = (nPos > 0)? nPos : 0 ;
	return	TRUE ;
}

BOOL
TMarker_Backward (
	CTMarker*		pMarker,
	int				n)
{
	register int	nPos ;

	ASSERT (pMarker != NULL) ;
	if (! pMarker->_fValid)
		return	FALSE ;
	nPos				= pMarker->_iPosition - n ;
	pMarker->_iPosition = (nPos > 0)? nPos : 0 ;
	return	TRUE ;
}

BOOL
TMarker_IsCursor (
	CTMarker*		pMarker)
{
	ASSERT (pMarker != NULL) ;
	return	pMarker->_fCursor ;
}

BOOL
TMarker_IsValidp (
	CTMarker*		pMarker)
{
	ASSERT (pMarker != NULL) ;
	return	pMarker->_fValid ;
}

BOOL
TMarker_SetPosition (
	CTMarker*		pMarker,
	const CTMarker*	pMarkerSrc)
{
	ASSERT (pMarker    != NULL) ;
	ASSERT (pMarkerSrc != NULL) ;

	if (! pMarker->_fValid || ! pMarkerSrc->_fValid)
		return	FALSE ;
	pMarker->_iPosition	= pMarkerSrc->_iPosition ;
	return	TRUE ;
}

void
TMarker_Invalidate (
	CTMarker*		pMarker)
{
	ASSERT (pMarker != NULL) ;
	pMarker->_fValid	= FALSE ;
	return ;
}




