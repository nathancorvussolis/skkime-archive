/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * input.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"

/*
 *	ToAsciiEx ����Ăяo����� WM_KEYDOWN �̏����֐��B
 *	SKKKeyDownHandler �֏����������n���B
 */
BOOL	PASCAL
IMEKeydownHandler (
	register HIMC	hIMC,
	register WPARAM	wParam,
	register LPARAM	lParam,
	register LPBYTE	lpbKeyState,
	register BOOL	fOpen)
{
	SKKKeyDownHandler (hIMC, wParam, lParam, lpbKeyState, fOpen) ;
	return	TRUE ;
}

/*
 *	ToAsciiEx ����Ăяo����� WM_KEYUP �̏����֐��B
 *	SKKKeyUpHandler �֏����������n���B
 */
BOOL	PASCAL
IMEKeyupHandler (
	register HIMC	hIMC,
	register WPARAM	wParam,
	register LPARAM	lParam,
	register LPBYTE	lpbKeyState,
	register BOOL	fOpen)
{
	register BOOL	fRetval ;

	fRetval	= SKKKeyUpHandler (hIMC, wParam, lParam, lpbKeyState, fOpen) ;
	return	fRetval ;
}

