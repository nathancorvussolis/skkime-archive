/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * uinotify.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "skksubs.h" 

static	LRESULT	PASCAL	OnImcGetCandidatePos 	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcGetCompositionFont	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcGetCompositionWindow	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcGetStatusWindowPos	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcSetCandidatePos	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcSetStatusWindowPos	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcSetCompositionFont	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcSetCompositionWindow	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcCloseStatusWindow	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImcOpenStatusWindow	(HIMC, HWND, UINT, WPARAM, LPARAM) ;

/*************************************************************************
 *	WM_IME_CONTROL
 *------------------------------------------------------------------------
 *(�R�����g)
 *	WM_IME_CONTROL �́c�B

#define IMC_GETCANDIDATEPOS             0x0007
#define IMC_SETCANDIDATEPOS             0x0008
#define IMC_GETCOMPOSITIONFONT          0x0009
#define IMC_SETCOMPOSITIONFONT          0x000A
#define IMC_GETCOMPOSITIONWINDOW        0x000B
#define IMC_SETCOMPOSITIONWINDOW        0x000C
#define IMC_GETSTATUSWINDOWPOS          0x000F
#define IMC_SETSTATUSWINDOWPOS          0x0010
#define IMC_CLOSESTATUSWINDOW           0x0021
#define IMC_OPENSTATUSWINDOW            0x0022

 *************************************************************************/
LONG	PASCAL
OnImeControl (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		message,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	static	LRESULT	(PASCAL *rpImcFunctionTable [])(HIMC, HWND, UINT, WPARAM, LPARAM) = {
		NULL,						NULL,
		NULL,						NULL,
		NULL,						NULL,
		NULL,						OnImcGetCandidatePos,
		OnImcSetCandidatePos,		OnImcGetCompositionFont,
		OnImcSetCompositionFont,	OnImcGetCompositionWindow,
		OnImcSetCompositionWindow,	NULL,
		NULL,						OnImcGetStatusWindowPos,
		OnImcSetStatusWindowPos,	NULL,
		NULL,						NULL,
		NULL,						NULL,
		NULL,						NULL,
		NULL,						NULL,
		NULL,						NULL,
		NULL,						NULL,
		NULL,						NULL,
		NULL,						OnImcCloseStatusWindow,
		OnImcOpenStatusWindow,		
	} ;
	LONG	lResult ;
	int		nCommand	= (int) wParam ;

	if (nCommand < 0 ||
		nCommand >= NELEMENTS (rpImcFunctionTable) ||
		rpImcFunctionTable [nCommand] == NULL) {
		return	1L ;	/* �����łȂ���΁A��Z��Ԃ��B*/
	}
	DEBUGPRINTFEX (106, (MYTEXT ("[enter] OnImeControl (w:0x%lx, l:0x%lx)\n"), wParam, lParam)) ;
	lResult	= (rpImcFunctionTable [nCommand])(hUICurIMC, hWnd, message, wParam, lParam) ;
	DEBUGPRINTFEX (106, (MYTEXT ("[enter] OnImeControl (w:0x%lx, l:0x%lx) : Elapse(%d)\n"), wParam, lParam)) ;
	return	lResult ;
}

LRESULT	PASCAL
OnImcGetCandidatePos (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	LPINPUTCONTEXT	lpIMC ;

	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;

	/* SKKIME98 has only one candidate list. */
	*(LPCANDIDATEFORM)lParam	= lpIMC->cfCandForm [0] ; 
	ImmUnlockIMC (hUICurIMC) ;
	return	0L ;
}

LRESULT	PASCAL
OnImcGetCompositionFont (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	LPINPUTCONTEXT	lpIMC ;
	LPLOGFONT		lpLogFont ;

	lpLogFont	= (LPLOGFONT) lParam ;
	if (! lpLogFont)
		return	1L ;

	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;
	*lpLogFont	= lpIMC->lfFont.W ;
	ImmUnlockIMC (hUICurIMC) ;
	return	0L ;
}

LRESULT	PASCAL
OnImcGetCompositionWindow (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONFORM	lpCOMPOSITIONFORM ;

	lpCOMPOSITIONFORM	= (LPCOMPOSITIONFORM) lParam ;
	if (! lpCOMPOSITIONFORM)
		return	1L ;

	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;

	*lpCOMPOSITIONFORM	= lpIMC->cfCompForm ;
	ImmUnlockIMC (hUICurIMC) ;
	return	0L ;
}

LRESULT	PASCAL
OnImcGetStatusWindowPos (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	LPINPUTCONTEXT	lpIMC ;
	POINTS			pt ;

	pt.x	= -1 ;
	pt.y	= -1 ;
	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (lpIMC) {
		HGLOBAL		hUIExtra ;
		LPUIEXTRA	lpUIExtra ;

		hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		if (IsWindow (lpUIExtra->uiStatus.hWnd)) {
			pt.x	= (SHORT) lpUIExtra->uiStatus.pt.x ;
			pt.y	= (SHORT) lpUIExtra->uiStatus.pt.y ;
		}
		GlobalUnlock (hUIExtra) ;
	}
	ImmUnlockIMC (hUICurIMC) ;
	return	((WORD)pt.x | ((DWORD)((WORD)pt.y) << 16)) ;
}

LRESULT	PASCAL
OnImcSetCandidatePos (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	/*	The UI window does not receive this message. */
	return	1L ;
}

LRESULT	PASCAL
OnImcSetStatusWindowPos (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	LRESULT			lRetval	= 1L ;
	LPINPUTCONTEXT	lpIMC ;
	HGLOBAL			hUIExtra ;
	LPUIEXTRA		lpUIExtra ;
	POINTS			ptsPT ;

	ptsPT.x	= (SHORT) LOWORD (lParam) ;
	ptsPT.y	= (SHORT) HIWORD (lParam) ;
	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;

	hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
	lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra);
	UIStatus_Move (lpUIExtra, &ptsPT) ;
	GlobalUnlock (hUIExtra) ;
	ImmUnlockIMC (hUICurIMC) ;
	return	lRetval ;
}

LRESULT	PASCAL
OnImcSetCompositionFont (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	/*	The UI window does not receive this message. */
	return	1L ;
}

LRESULT	PASCAL
OnImcSetCompositionWindow (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	/*	The UI window does not receive this message. */
	return	1L ;
}

LRESULT	PASCAL
OnImcCloseStatusWindow (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	/*	what to do? */
	return	1L ;
}

LRESULT	PASCAL
OnImcOpenStatusWindow (
	register HIMC		hUICurIMC,
	register HWND		hWnd,
	register UINT		uMessage,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	/*	what to do? */
	return	1L ;
}


