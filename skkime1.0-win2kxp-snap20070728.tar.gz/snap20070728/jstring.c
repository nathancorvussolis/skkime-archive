#include "local.h"
#include "jstring.h"

static	LPCWSTR		_wstrKanjiNumber	= L"�Z���O�l�ܘZ������" ;
static	LPCWSTR		_wstrNumericUnit [] = {
	L"��",	L"��",	L"��",	L"��",	L"��",	L"�R",	L"��",	L"�a",
	L"��",	L"��",	L"��",	L"��",	L"�P�͍�",	L"���m�_",
	L"�ߗR��",	L"�s�v�c",	L"���ʑ吔",
} ;

/*	JISX0208 �Љ������� JISX0201 �Љ����ւ̕ϊ��e�[�u���B
 */
static	struct {
	LPCWSTR	_wstrSource ;
	LPCWSTR	_wstrDest ;
}	_rHanZenConvTbl []	= {
		{ L"�B", L"�" }, { L"�u", L"�" }, { L"�v", L"�" }, { L"�A", L"�" },
		{ L"�E", L"�" }, { L"��", L"�" }, { L"�@", L"�" }, { L"�B", L"�" },
		{ L"�D", L"�" }, { L"�F", L"�" }, { L"�H", L"�" }, { L"��", L"�" },
		{ L"��", L"�" }, { L"��", L"�" }, { L"�b", L"�" }, { L"�[", L"�" },
		{ L"�A", L"�" }, { L"�C", L"�" }, { L"�E", L"�" }, { L"�G", L"�" },
		{ L"�I", L"�" }, { L"�J", L"�" }, { L"�L", L"�" }, { L"�N", L"�" },
		{ L"�P", L"�" }, { L"�R", L"�" }, { L"�T", L"�" }, { L"�V", L"�" },
		{ L"�X", L"�" }, { L"�Z", L"�" }, { L"�\", L"�" }, { L"�^", L"�" },
		{ L"�`", L"�" }, { L"�c", L"�" }, { L"�e", L"�" }, { L"�g", L"�" },
		{ L"�i", L"�" }, { L"�j", L"�" }, { L"�k", L"�" }, { L"�l", L"�" },
		{ L"�m", L"�" }, { L"�n", L"�" }, { L"�q", L"�" }, { L"�t", L"�" },
		{ L"�w", L"�" }, { L"�z", L"�" }, { L"�}", L"�" }, { L"�~", L"�" },
		{ L"��", L"�" }, { L"��", L"�" }, { L"��", L"�" }, { L"��", L"�" },
		{ L"��", L"�" }, { L"��", L"�" }, { L"��", L"�" }, { L"��", L"�" },
		{ L"��", L"�" }, { L"��", L"�" }, { L"��", L"�" }, { L"��", L"�" },
		{ L"��", L"�" }, { L"�J", L"�" }, { L"�K", L"�" },	
		{ L"�K", L"��" }, { L"�M", L"��" }, { L"�O", L"��" }, { L"�Q", L"��" },
		{ L"�S", L"��" }, { L"�U", L"��" }, { L"�W", L"��" }, { L"�Y", L"��" },
		{ L"�[", L"��" }, { L"�]", L"��" }, { L"�_", L"��" }, { L"�a", L"��" },
		{ L"�d", L"��" }, { L"�f", L"��" }, { L"�h", L"��" }, { L"�o", L"��" },
		{ L"�r", L"��" }, { L"�u", L"��" }, { L"�x", L"��" }, { L"�{", L"��" },	
		{ L"��", L"��" },
		{ L"�p", L"��" }, { L"�s", L"��" }, { L"�v", L"��" }, { L"�y", L"��" },
		{ L"�|", L"��" },	
	} ;



WORD
JisCharToSjisChar (
	register WORD	woChara)
{
	register WORD	n1, n2 ;

	n1		= (((woChara >> 8) + 1) >> 1) + 0x70 ;
	n1		= ((n1 >= 0xA0)? n1 + 0x40 : n1) ;
	n2		= (woChara & 0x00FF) + ((woChara & 0x0100)? 0x1F : 0x7D) ;
	n2		= ((n2 >= 0x7F)? n2 + 1 : n2) ;
	return	((n1 & 0x00FF) << 8) | (n2 & 0x00FF) ;
}

WCHAR
JCharToUnicode (
	register WORD	woChara)
{
	register WORD	woSjisChara ;
	char			rchSjis [2] ;
	wchar_t			wChara ;

	if (woChara < 128)
		return	(wchar_t) woChara ;

	woSjisChara	= JisCharToSjisChar(woChara & 0x7F7F) ;
	rchSjis [0]	= (BYTE)(woSjisChara >> 8) ;
	rchSjis [1]	= (BYTE)(woSjisChara >> 0) ;
	if (! MultiByteToWideChar (CP_OEMCP, MB_ERR_INVALID_CHARS | MB_PRECOMPOSED,
							   rchSjis, 2, &wChara, 1))
		return	0 ;
	return	wChara ;
}

int
Hex2Int (
	register WORD		wch)
{
	if (L'0' <= wch && wch <= L'9') 
		return	wch - L'0' ;
	if (L'a' <= wch && wch <= L'f') 
		return	wch - L'a' + 10 ;
	if (L'A' <= wch && wch <= L'F') 
		return	wch - L'A' + 10 ;
	return	0 ;
}

int
JHiragana2Katakana (
	register LPWSTR		wstrDest,
	register int		nstrDest,
	register LPCWSTR	wstrSource,
	register int		nstrSource,
	register BOOL		fVContract)
{
	int		nDestBak	= nstrDest ;

	while (nstrSource > 0 && nstrDest > 0) {
		if (L'��' <= *wstrSource && *wstrSource <= L'��') {
			if (fVContract && nstrSource > 1 && 
				*(wstrSource + 0) == L'��' &&
				*(wstrSource + 1) == L'�J') {
				*wstrDest ++	= L'��' ;
				nstrDest -- ;
				wstrSource ++ ;
				nstrSource -- ;
			} else {
				*wstrDest ++	= *wstrSource - L'��' + L'�A' ;
				nstrDest -- ;
			}
			wstrSource ++ ;
			nstrSource -- ;
		} else {
			*wstrDest ++	= *wstrSource ++ ;
			nstrDest   -- ;
			nstrSource -- ;
		}
	}
	return	(nDestBak - nstrDest) ;
}

int
JKatakana2Hiragana (
	register LPWSTR		wstrDest,
	register int		nstrDest,
	register LPCWSTR	wstrSource,
	register int		nstrSource)
{
	int		nDestBak	= nstrDest ;

	while (nstrSource > 0 && nstrDest > 0) {
		if (*wstrSource == L'��') {
			*wstrDest ++	= L'��' ;
			nstrDest -- ;
			if (nstrDest > 0) {
				*wstrDest ++	= L'�J' ;
				nstrDest -- ;
			}
		} else if (L'�@' <= *wstrSource && *wstrSource <= L'��') {
			*wstrDest ++	= *wstrSource ++ - L'�A' + L'��' ;
			nstrSource -- ;
			nstrDest -- ;
		} else {
			*wstrDest ++	= *wstrSource ++ ;
			nstrDest   -- ;
			nstrSource -- ;
		}
	}
	return	(nDestBak - nstrDest) ;
}

int
JZenkana2Hankana (
	register LPWSTR		wstrDest,
	register int		nstrDest,
	register LPCWSTR	wstrSource,
	register int		nstrSource)
{
	int		nDestBak	= nstrDest ;
	register int	i ;
	register WCHAR	wch ;

	while (nstrSource > 0 && nstrDest > 0) {
		if ((L'��' <= *wstrSource && *wstrSource <= L'��') ||
			(*wstrSource == L'��' || *wstrSource == L'��' ||
			 *wstrSource == L'��')) {
			wch	= *wstrSource + L'�A' - L'��' ;
		} else if ((L'�@' <= *wstrSource && *wstrSource <= L'��') ||
				   (*wstrSource == L'��' || *wstrSource == L'��' ||
					*wstrSource == L'��' || *wstrSource == L'�J' ||
					*wstrSource == L'�K' ||	*wstrSource == L'�B' ||
					*wstrSource == L'�u' || *wstrSource == L'�v' ||
					*wstrSource == L'�A' ||	*wstrSource == L'�E' ||
					*wstrSource == L'�[' || *wstrSource == L'��')) {
			wch	= *wstrSource ;
		} else {
			/* normal insert */
			*wstrDest ++	= *wstrSource ++ ;
			nstrDest   -- ;
			nstrSource -- ;
			continue ;
		}
		for (i = 0 ; i < NELEMENTS (_rHanZenConvTbl) ; i ++) {
			if (*(_rHanZenConvTbl [i]._wstrSource) == wch) {
				register LPCWSTR	wptr	= _rHanZenConvTbl [i]._wstrDest ;
				while (*wptr != L'\0' && nstrDest > 0) {
					*wstrDest ++	= *wptr ++ ;
					nstrDest -- ;
				}
				wstrSource	++ ;
				nstrSource	-- ;
				break ;
			}
		}
		if (i >= NELEMENTS (_rHanZenConvTbl)) {
			*wstrDest ++	= *wstrSource ++ ;
			nstrDest   -- ;
			nstrSource -- ;
		}
	}
	return	(nDestBak - nstrDest) ;
}

int
JZenHanKatakana2Hiragana (
	register LPWSTR		wstrDest,
	register int		nstrDest,
	register LPCWSTR	wstrSource,
	register int		nstrSource)
{
	int		nDestBak	= nstrDest ;
	register int	i, n ;

	while (nstrSource > 0 && nstrDest > 0) {
		if (*wstrSource == L'��') {
			*wstrDest ++	= L'��' ;
			nstrDest -- ;
			if (nstrDest > 0) {
				*wstrDest ++	= L'�J' ;
				nstrDest -- ;
			}
			wstrSource	++ ;
			nstrSource	-- ;
		} else if (L'�@' <= *wstrSource && *wstrSource <= L'��') {
			*wstrDest	++	= *wstrSource - L'�A' + L'��' ;
			nstrDest	-- ;
			wstrSource	++ ;
			nstrSource	-- ;
		} else {
			for (i = 0 ; i < NELEMENTS (_rHanZenConvTbl) ; i ++) {
				n	= lstrlenW (_rHanZenConvTbl [i]._wstrDest) ;
				if (nstrSource >= n &&
					! Mylstrncmp (_rHanZenConvTbl [i]._wstrDest, wstrSource, n)) {
					register LPCWSTR	wptr	= _rHanZenConvTbl [i]._wstrSource ;

					while (*wptr != L'\0' && nstrDest > 0) {
						if (*wptr == L'��') {
							*wstrDest ++	= L'��' ;
							nstrDest -- ;
							if (nstrDest > 0) {
								*wstrDest ++	= L'�J' ;
								nstrDest -- ;
							}
						} else if (L'�@' <= *wptr && *wptr <= L'��') {
							*wstrDest	++	= *wptr - L'�A' + L'��' ;
							nstrDest	-- ;
						} else {
							*wstrDest ++	= *wptr ;
							nstrDest -- ;
						}
						wptr	++ ;
					}
					wstrSource	+= n ;
					nstrSource	-= n ;
					break ;
				}
			}
			if (i >= NELEMENTS (_rHanZenConvTbl)) {
				*wstrDest ++	= *wstrSource ++ ;
				nstrDest   -- ;
				nstrSource -- ;
			}
		}
	}
	return	(nDestBak - nstrDest) ;
}

int
JHankana2Hiragana (
	register LPWSTR		wstrDest,
	register int		nstrDest,
	register LPCWSTR	wstrSource,
	register int		nstrSource)
{
	int		nDestBak	= nstrDest ;
	register int	i, n ;

	while (nstrSource > 0 && nstrDest > 0) {
		for (i = 0 ; i < NELEMENTS (_rHanZenConvTbl) ; i ++) {
			n	= lstrlenW (_rHanZenConvTbl [i]._wstrDest) ;
			if (nstrSource >= n &&
				! Mylstrncmp (_rHanZenConvTbl [i]._wstrDest, wstrSource, n)) {
				register LPCWSTR	wptr	= _rHanZenConvTbl [i]._wstrSource ;

				while (*wptr != L'\0' && nstrDest > 0) {
					if (*wptr == L'��') {
						*wstrDest ++	= L'��' ;
						nstrDest -- ;
						if (nstrDest > 0) {
							*wstrDest ++	= L'�J' ;
							nstrDest -- ;
						}
					} else if (L'�@' <= *wptr && *wptr <= L'��') {
						*wstrDest	++	= *wptr - L'�A' + L'��' ;
						nstrDest	-- ;
					} else {
						*wstrDest ++	= *wptr ;
						nstrDest -- ;
					}
					wptr	++ ;
				}
				wstrSource	+= n ;
				nstrSource	-= n ;
				break ;
			}
		}
		if (i >= NELEMENTS (_rHanZenConvTbl)) {
			*wstrDest ++	= *wstrSource ++ ;
			nstrDest   -- ;
			nstrSource -- ;
		}
	}
	return	(nDestBak - nstrDest) ;
}

int
JHankana2Katakana (
	register LPWSTR		wstrDest,
	register int		nstrDest,
	register LPCWSTR	wstrSource,
	register int		nstrSource)
{
	int		nDestBak	= nstrDest ;
	register int	i, n ;

	while (nstrSource > 0 && nstrDest > 0) {
		for (i = 0 ; i < NELEMENTS (_rHanZenConvTbl) ; i ++) {
			n	= lstrlenW (_rHanZenConvTbl [i]._wstrDest) ;
			if (nstrSource >= n &&
				! Mylstrncmp (_rHanZenConvTbl [i]._wstrDest, wstrSource, n)) {
				register LPCWSTR	wptr	= _rHanZenConvTbl [i]._wstrSource ;

				while (*wptr != L'\0' && nstrDest > 0) {
					*wstrDest ++	= *wptr ++ ;
					nstrDest -- ;
				}
				wstrSource	+= n ;
				nstrSource	-= n ;
				break ;
			}
		}
		if (i >= NELEMENTS (_rHanZenConvTbl)) {
			*wstrDest ++	= *wstrSource ++ ;
			nstrDest   -- ;
			nstrSource -- ;
		}
	}
	return	(nDestBak - nstrDest) ;
}

int
JNumExp (
	register LPWSTR		wpDest,
	register int		nDest,
	register int		nCmd,
	register LPCWSTR*	ppNum,
	register int*		pnNum)
{
	ASSERT (ppNum != NULL) ;
	ASSERT (pnNum != NULL) ;

	/*	#4 �ϊ��͂����ł͎��s�ł��Ȃ��B*/
	switch (nCmd) {
	case	L'1':
		return	JZenkakuNumStr (wpDest, nDest, ppNum, pnNum) ;
	case	L'2':
		return	JKanjiNumStr (wpDest, nDest, ppNum, pnNum) ;
	case	L'3':
		return	JKanjiNumStr2 (wpDest, nDest, ppNum, pnNum) ;
	case	L'9':
		return	JShogiNumStr (wpDest, nDest, ppNum, pnNum) ;
	case	L'0':
		return	JIdentityNumStr (wpDest, nDest, ppNum, pnNum) ;
	default:
		return	JNumSkip (ppNum, pnNum) ;
	}
}

/*	���������X�L�b�v����B
 */
int
JNumSkip (
	register LPCWSTR*	ppNum,
	register int*		pnNum)
{
	register LPCWSTR	pNum ;
	register int		nNum ;

	pNum	= *ppNum ;
	nNum	= *pnNum ;
	while (nNum > 0 && *pNum != L'\0') {
		pNum	++ ;
			nNum	-- ;
	}
	if (nNum > 0 && *pNum == L'\0') {
			pNum	++ ;
			nNum	-- ;
	}
	*ppNum	= pNum ;
	*pnNum	= nNum ;
	return	0 ;
}

int
JIdentityNumStr (
	register LPWSTR		wpDest,
	register int		nDest,
	register LPCWSTR*	ppNum,
	register int*		pnNum)
{
	register LPCWSTR	pNum ;
	register int		nNum ;
	register int		n ;

	pNum	= *ppNum ;
	nNum	= *pnNum ;
	n		= nDest ;
	while (nNum > 0 && *pNum != L'\0') {
		if (nDest > 0) {
			*wpDest ++	= *pNum ;
			nDest -- ;
		}
		pNum	++ ;
		nNum	-- ;
	}
	if (nNum > 0 && *pNum == L'\0') {
		pNum	++ ;
		nNum	-- ;
	}
	*ppNum	= pNum ;
	*pnNum	= nNum ;
	return	(n - nDest) ;
}

int
JZenkakuNumStr (
	register LPWSTR		wpDest,
	register int		nDest,
	register LPCWSTR*	ppNum,
	register int*		pnNum)
{
	register LPCWSTR	pNum ;
	register int		nNum ;
	register int		n ;

	pNum	= *ppNum ;
	nNum	= *pnNum ;
	n		= nDest ;
	while (nNum > 0 && *pNum != L'\0') {
		if (nDest > 0) {
			*wpDest ++	= (WCHAR)(L'�O' + (*pNum - L'0')) ;
			nDest -- ;
		}
		pNum	++ ;
		nNum	-- ;
	}
	if (nNum > 0 && *pNum == L'\0') {
		pNum	++ ;
		nNum	-- ;
	}
	*ppNum	= pNum ;
	*pnNum	= nNum ;
	return	(n - nDest) ;
}

int
JKanjiNumStr (
	register LPWSTR		wpDest,
	register int		nDest,
	register LPCWSTR*	ppNum,
	register int*		pnNum)
{
	register LPCWSTR	pNum ;
	register int		nNum ;
	register int		nIndex, n ;

	ASSERT (ppNum != NULL) ;
	ASSERT (pnNum != NULL) ;

	pNum	= *ppNum ;
	nNum	= *pnNum ;
	n		= nDest ;
	while (nNum > 0 && *pNum != L'\0') {
		if (nDest > 0) {
			nIndex		= *pNum - L'0' ;
			if (0 <= nIndex && nIndex <= 9) {
				*wpDest ++	= _wstrKanjiNumber [nIndex] ;
				nDest -- ;
			}
		}
		pNum	++ ;
		nNum	-- ;
	}
	if (nNum > 0 && *pNum == L'\0') {
		pNum	++ ;
		nNum	-- ;
	}
	*ppNum	= pNum ;
	*pnNum	= nNum ;
	return	(n - nDest) ;
}

int
JKanjiNumStr2 (
	register LPWSTR		pDest,
	register int		nDest,
	register LPCWSTR*	ppNum,
	register int*		pnNum)
{
	register LPCWSTR	pNum ;
	register int		nNum ;
	register int		n, nLength, nDigitNumber, nDestBak ;
	register BOOL		fSilent ;

	ASSERT (ppNum != NULL) ;
	ASSERT (pnNum != NULL) ;

	nDestBak	= nDest ;
	pNum		= *ppNum ;
	nNum		= *pnNum ;
	nLength		= 0 ;
	while (nNum > 0 && *pNum != L'\0') {
		pNum	++ ;
		nLength	++ ;
		nNum	-- ;
	}
	pNum		= *ppNum ;
	nNum		= *pnNum ;
	while (nNum > 0 && *pNum == L'0') {
		pNum	++ ;
		nNum	-- ;
	}
	if (nLength == 0) {
		if (nDest > 0) {
			*pDest	++	= L'�Z' ;
			nDest -- ;
		}
	} else {
		nDigitNumber	= ((nLength - 1) / 4) - 1 ;
		/* �傫�߂��鐔�ł����H */
		if (nDigitNumber < 17){
			fSilent	= TRUE ;
			while (nLength > 0){
				if (*pNum > L'1' || (*pNum != L'0' && (nLength % 4) == 1)){
					if (nDest > 0) {
						*pDest		++	= _wstrKanjiNumber [*pNum - L'0'] ;
						nDest		-- ;
					} else {
						nDest		= 0 ;
						break ;
					}
				}
				if (*pNum != L'0'){
					/* �\�A�S�A��̈ʂɈ�ł��Z�łȂ����̂�����΁A�ق��Ă��� *
					 * ���c�B�����ŁA�ق��Ă��Ȃ����Ă̂́A���Ƃ����Ƃ��\����   *
					 * ����ĈӖ��B���Ȃ݂ɁA��̈ʂ̎����Z�łȂ�������A���Ƃ� *
					 * �ƕ\���������Ȃ񂾂���c�˂��B*/
					if (nLength % 4 == 2){
						if (nDest > 0) {
							*pDest		++	= L'�\' ;
							nDest		-- ;
						} else {
							nDest		= 0 ;
							break ;
						}
					} else if (nLength % 4 == 3){
						if (nDest > 0) {
							*pDest		++	= L'�S' ;
							nDest		-- ;
						} else {
							nDest		= 0; 
							break ;
						}
					} else if (nLength % 4 == 0){
						if (nDest > 0) {
							*pDest		++	= L'��' ;
							nDest		-- ;
						} else {
							nDest		= 0; 
							break ;
						}
					}
					fSilent	= FALSE ;
				}
				if (!fSilent || *pNum != L'0'){
					nDigitNumber	= nLength - 1 ;
					if (nDigitNumber % 4 == 0){
						nDigitNumber	= nDigitNumber / 4 - 1 ;
						if (nDigitNumber >= 0){
							n		= wcslen (_wstrNumericUnit [nDigitNumber]) ;
							n		= (n < nDest)? n : nDest ;
							wcsncpy (pDest, _wstrNumericUnit [nDigitNumber], n) ;
							nDest	-= n ;
							if (nDest <= 0)
								break ;
							/* �\��������ق邱�Ƃɂ���B*/
							fSilent	= TRUE ;
						}
					}
				}
				nLength	-- ;
				pNum	++ ;
			}
		}
	}
	while (nNum > 0 && *pNum != L'\0') {
		pNum	++ ;
		nLength	++ ;
		nNum	-- ;
	}
	if (nNum > 0 && *pNum == L'\0') {
		pNum	++ ;
		nNum	-- ;
	}
	*ppNum	= pNum ;
	*pnNum	= nNum ;
	return	(nDestBak - nDest) ;
}

int
JShogiNumStr (
	register LPWSTR		pDest,
	register int		nDest,
	register LPCWSTR*	ppNum,
	register int*		pnNum)
{
	register LPCWSTR	pNum ;
	register int		nNum ;
	register int		n ;

	ASSERT (ppNum != NULL) ;
	ASSERT (pnNum != NULL) ;

	n		= nDest ;
	pNum	= *ppNum ;
	nNum	= *pnNum ;
	if (nNum > 0 && *pNum != L'\0' && nDest > 0) {
		*pDest	++	= (WCHAR) (L'�O' + (*pNum - L'0')) ;
		nDest	-- ;
		pNum	++ ;
		nNum	-- ;
	}
	if (nNum > 0 && *pNum != L'\0' && nDest > 0) {
		*pDest	++	= _wstrKanjiNumber [*pNum - L'0'] ;
		nDest	-- ;
		pNum	++ ;
		nNum	-- ;
	}
	while (nNum > 0 && *pNum != L'\0') {
		pNum	++ ;
		nNum	-- ;
	}
	if (nNum > 0 && *pNum == L'\0') {
		pNum	++ ;
		nNum	-- ;
	}
	*ppNum	= pNum ;
	*pnNum	= nNum ;
	return	(n - nDest) ;
}

int
JDateString (
	register LPWSTR		wstrDest,
	register int		nDest,
	register int		nDateAd,
	register int		nNumberStyle)
{
	WCHAR		rszBuffer [32] ;
	/*	�N������ 32 �����g�����Ƃ͂Ȃ��Ǝv�����O�̂��߂ɁB
	 *	����Łc�����Ă���Ԃɂ��ӂ�邱�Ƃ͂Ȃ����낤�B
	 *	(�N�����ς�����肷��Ƃ܂��������H) */
	WCHAR		rszYear [32], rszMonth [32], rszDay [32] ;
	LPCWSTR		pYear, pBuffer, pNengo ;
	SYSTEMTIME	ltime ;
	int			iYear, nBuffer, n ;

	ASSERT (wstrDest != NULL) ;
	ASSERT (nDest > 0) ;

	/* 1970/1/1����̌o�ߎ����𓾂�B*/
	GetLocalTime (&ltime) ;

	/* ����N�̉����������j���ł��邩�𓾂�B*/
	iYear	= ltime.wYear ;
	pNengo	= L"" ;
	if (!nDateAd){
		/* �N�������߂�B*/
		if (iYear <= 1867){
			pNengo	= L"����" ;
		} else if (iYear < 1911){
			iYear	-= 1867 ;
			pNengo	= L"����" ;
		} else if (iYear < 1925){
			iYear	 -= 1911 ;
			pNengo	= L"�吳" ;
		} else if (iYear < 1988 ){
			iYear	-= 1925 ;
			pNengo	= L"���a" ;
		} else {
			iYear	-= 1988 ;
			pNengo	= L"����" ;
		}
	}
	if (iYear == 1 && nDateAd){
		pYear		= L"��" ;
	} else {
		wnsprintfW (rszBuffer, NELEMENTS (rszBuffer) - 1, L"%d", iYear) ;
		rszBuffer [NELEMENTS (rszBuffer) - 1]	= L'\0' ;
		pBuffer	= rszBuffer ;
		nBuffer	= lstrlenW (rszBuffer) ;
		/* �N��W�J����B*/
		n	= JNumExp (rszYear, NELEMENTS (rszYear) - 1, nNumberStyle + L'0', &pBuffer, &nBuffer) ;
		rszYear [n]	= L'\0' ;
		pYear		= rszYear ;
	}

	wnsprintfW (rszBuffer, NELEMENTS (rszBuffer) - 1, L"%d", ltime.wMonth) ;
	rszBuffer [NELEMENTS (rszBuffer) - 1]	= L'\0' ;
	pBuffer	= rszBuffer ;
	nBuffer	= lstrlenW (rszBuffer) ;
	n	= JNumExp (rszMonth, NELEMENTS (rszMonth) - 1, nNumberStyle + L'0', &pBuffer, &nBuffer) ;
	rszMonth [n]	= L'\0' ;

	wnsprintfW (rszBuffer, NELEMENTS (rszBuffer) - 1, L"%d", ltime.wDay) ;
	rszBuffer [NELEMENTS (rszBuffer) - 1]	= L'\0' ;
	pBuffer	= rszBuffer ;
	nBuffer	= lstrlenW (rszBuffer) ;
	/* �N��W�J����B*/
	n	= JNumExp (rszDay, NELEMENTS (rszDay) - 1, nNumberStyle + L'0', &pBuffer, &nBuffer) ;
	rszDay [n]	= L'\0' ;
	
	wnsprintfW (wstrDest, nDest - 1, L"%s%s�N%s��%s��(%c)", pNengo, pYear, rszMonth, rszDay, L"�����ΐ��؋��y"[ltime.wDayOfWeek]) ;
	wstrDest [nDest - 1]	= L'\0' ;
	return	lstrlenW (wstrDest) ;
}

int
JHenkanCopy (
	register LPWSTR		pDest,
	register LPCWSTR	pSrc,
	register int		nCount)
{
	register int	n ;

	n	= 0 ;
	while (nCount > 0 && *pSrc != L' ') {
		if (nCount > 1 && *pSrc == 0x0D && *(pSrc + 1) == 0x0A) {
			pSrc	+= 2 ;
			nCount	-= 2 ;
		} else if (*pSrc == L'\n') {
			pSrc	++ ;
			nCount	-- ;
		} else {
			*pDest ++	= *pSrc ++ ;
			n 		++ ;
			nCount	-- ;
		}
	}
	return	n ;
}

int
lstrncpyW (
	register LPWSTR		pDest,
	register LPCWSTR	pSrc,
	register int		n)
{
	register int	ch	= -1 ;

	DEBUGPRINTFEX (99, (TEXT ("lstrncpyW (d:%p, s:%p, n:%d)\n"), pDest, pSrc, n)) ;

	while (n -- > 0 && ch != L'\0') 
		ch = *pSrc, *pDest ++ = *pSrc ++ ;
	return	n ;
}

int
lstrncmpW (
	register LPCWSTR	pLeft,
	register LPCWSTR	pRight,
	register int		n)
{
	register int	nDiff	= 0 ;

	while (n > 0) {
		nDiff	= *pLeft - *pRight ;
		if (nDiff != 0)
			return	nDiff ;
		if (*pLeft == L'\0')
			break ;
		pLeft	++ ;
		pRight	++ ;
		n		-- ;
	}
	return	nDiff ;
}

int
wmemindex (
	register LPCWSTR	pLeft,
	register LPCWSTR	pRight,
	register int		n)
{
	int	n_back	= n ;

	while (n > 0 && *pLeft == *pRight) {
		n		-- ;
		pLeft	++ ;
		pRight	++ ;
	}
	return	n_back - n ;
}

/*	�w�肳�ꂽ�������̕�����̒����� #4 �Ƃ����������܂܂��
 *	���`�F�b�N����B���āA�Ȃ� str �Ȃ񂽂���g���΍ς݂���
 *	�ȋC�z���ȁc�B
 */
BOOL
JSharp4Stringp (
	register LPCWSTR	wpString,
	register int		nString)
{
	while (nString > 0) {
		if (*wpString == L'#') {
			wpString	++ ;
			nString		-- ;
			if (nString > 0 && *wpString == L'4')
				return	TRUE ;
		}
		wpString	++ ;
		nString		-- ;
	}
	return	FALSE ;
}

int
JNoNumCopy (
	register LPWSTR		wpDest,
	register LPCWSTR	wpSrc,
	register int		n)
{
	register WCHAR	ch ;
	register int	nBack	= n ;

	while (n > 0 && (ch = *wpSrc) != L'\0') {
		*wpDest	= (ch != L'#')? ch : L'��' ;
		wpDest	++ ;
		wpSrc	++ ;
		n		-- ;
	}
	return	(nBack - n) ;
}

int
JPhoneticStrcpy (
	register LPWSTR		wpDest,
	register LPCWSTR	wpSrc,
	register int		n)
{
	register WCHAR	wch ;
	LPWSTR			wpDestBak	= wpDest ;

	while (n -- > 0) {
		wch	= *wpSrc ++ ;
		/*	�������������R�s�[����B*/
		if ((L'��' <= wch && wch <= L'��') ||
			(L'�@' <= wch && wch <= L'��') ||
			wch == L'�J' || wch == L'�K'   ||
			(L'�'  <= wch && wch <= L'�')) {
			*wpDest	++	= wch ;
		}
	}
	return	(wpDest - wpDestBak) ;
}

