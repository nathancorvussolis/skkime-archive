#if !defined (version_h)
#define	version_h

#define	SKKIME_VERSION	TEXT("SKKIME1.0(build:20070728)")
#endif
