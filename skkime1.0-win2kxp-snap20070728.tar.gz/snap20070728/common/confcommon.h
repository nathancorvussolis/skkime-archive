#pragma once

#define	SKKISERVER_PIPE_BASENAME	TEXT ("\\\\.\\pipe\\skkiserv_pipe")
#define	SKKISERVER_PIPE_BASENAMEW	L"\\\\.\\pipe\\skkiserv_pipe"
#define	PROGRAMF_DIR				L"IME"
#define	SKKIMEProg_S_DIR			L"SKKIM10"
#define	SKKIMEServerFile			L"skkiserv.exe"
#define	SKKIMEConfigProg			L"skimconf.exe"


#define	REGPATH_SKKIME_BASE						TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0")
#define	REGPATH_GENERIC							REGPATH_SKKIME_BASE TEXT("\\Generic")
#define	REGPATH_ALWAYS_OPEN_KANAMODE			TEXT("always-open-kana-mode")
#define	REGPATH_EGG_LIKE_NEWLINE				TEXT("egg-like-newline")
#define	REGPATH_DELETE_IMPLIES_KAKUTEI			TEXT("delete-implies-kakutei")
#define	REGPATH_USE_NUMERIC_CONVERSION			TEXT("use-numeric-conversion")
#define	REGPATH_DABBREV_LIKE_COMPLETION			TEXT("dabbrev-like-completion")
#define	REGPATH_KATAKANA_HIRAGANA_HENKAN		TEXT("katakana-hiragana-henkan")
#define	REGPATH_NUMERIC_STYLE					TEXT("numeric-style")
#define	REGPATH_DATE_AD							TEXT("date-ad")
#define	REGPATH_SHOW_ANNOTATION					TEXT("show-annotation")
#define	REGPATH_KAKUTEI_EARLY					TEXT("kakutei-early")
#define	REGPATH_PROCESS_OKURI_EARLY				TEXT("process-okuri-early")
#define	REGPATH_DELETE_OKURI_WHEN_QUIT			TEXT("delete-okuri-when-quit")

#define	REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS	TEXT("j-henkan-show-candidate-keys")
#define	REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1	TEXT("j-input-by-code-or-menu-keys1")
#define	REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2	TEXT("j-input-by-code-or-menu-keys2")

#define	REGPATH_COLORFACE						REGPATH_SKKIME_BASE TEXT("\\ColorFace")
#define	REGSUBKEY_COLORFACE						TEXT("style")
#define	REGPATH_CICERO							REGPATH_SKKIME_BASE TEXT("\\CICERO")

#define	REGKEY_SHOWKEYBRDICON					TEXT("ShowKeyboardIcon")
#define	REGKEY_SHOWIMEICON						TEXT("ShowInputMethodIcon")
#define	REGKEY_SHOWINPUTMODEICON				TEXT("ShowInputModeIcon")

#define	REGPATHW_SKKIME_BASE					L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0"
#define	REGPATHW_GENERIC						REGPATHW_SKKIME_BASE L"\\Generic"
#define	REGPATHW_EGG_LIKE_NEWLINE				L"egg-like-newline"
#define	REGPATHW_DELETE_IMPLIES_KAKUTEI			L"delete-implies-kakutei"
#define	REGPATHW_USE_NUMERIC_CONVERSION			L"use-numeric-conversion"
#define	REGPATHW_DABBREV_LIKE_COMPLETION		L"dabbrev-like-completion"
#define	REGPATHW_KATAKANA_HIRAGANA_HENKAN		L"katakana-hiragana-henkan"
#define	REGPATHW_NUMERIC_STYLE					L"numeric-style"
#define	REGPATHW_DATE_AD						L"date-ad"
#define	REGPATHW_SHOW_ANNOTATION				L"show-annotation"
#define	REGPATHW_KAKUTEI_EARLY					L"kakutei-early"
#define	REGPATHW_PROCESS_OKURI_EARLY			L"process-okuri-early"
#define	REGPATHW_DELETE_OKURI_WHEN_QUIT			L"delete-okuri-when-quit"

#define	REGPATHW_KEYMAP							REGPATHW_SKKIME_BASE L"\\Keymap"
#define	REGSUBKEYW_JMAP							L"j-map"
#define	REGSUBKEYW_JABBREVMAP					L"j-abbrev-map"

#define	REGPATHW_ROMAKANARULELIST				REGPATHW_SKKIME_BASE L"\\RomaKanaRuleList"
#define	REGPATHW_PREFIXLIST						REGPATHW_SKKIME_BASE L"\\PrefixList"
#define	REGPATHW_INPUTVECTOR					REGPATHW_SKKIME_BASE L"\\InputVector"
#define	REGPATHW_ZENKAKUVECTOR					REGPATHW_SKKIME_BASE L"\\ZenkakuVector"

#define	SKKSERV_DEFAULT_PORTNUM					(1178)
#define	MAX_INPUTVECTOR							(128)
#define	MAX_SKKIME_COLORFACE					(2)
#define	NUM_SHOWKEYICON							(3)

#define	NUM_JHENKAN_SHOW_CANDIDATE_KEYS			(7)
#define	NUM_JINPUT_BY_CODE_OR_MENU_KEYS1		(12)
#define	NUM_JINPUT_BY_CODE_OR_MENU_KEYS2		(16)

#define	JINPUTBYCODEORMENU_PAGESIZE				(NUM_JINPUT_BY_CODE_OR_MENU_KEYS1)
#define	JINPUTBYCODEORMENU1_PAGESIZE			(NUM_JINPUT_BY_CODE_OR_MENU_KEYS2)

#define	IsValidColor(nColor)					((0 <= (nColor) && (nColor) < MAX_MYCOLOR)? TRUE : FALSE)
#define	IsValidLineType(nLineStyle)				((0 <= (nLineStyle) && (nLineStyle) < MAX_MYLINE)? TRUE : FALSE)

enum {
	MYCOLOR_TEXTAUTO	= 0,	MYCOLOR_BACKAUTO,
	MYCOLOR_BLACK,				MYCOLOR_DARKRED,
	MYCOLOR_DARKGREEN,			MYCOLOR_DARKYELLOW,
	MYCOLOR_DARKBLUE,			MYCOLOR_DARKPURPLE,
	MYCOLOR_DARKLIGHTBLUE,		MYCOLOR_DARKGRAY,
	MYCOLOR_LIGHTGRAY,			MYCOLOR_RED,
	MYCOLOR_GREEN,				MYCOLOR_YELLOW,
	MYCOLOR_BLUE,				MYCOLOR_PURPLE,
	MYCOLOR_LIGHTBLUE,			MYCOLOR_WHITE,
	MYCOLOR_SYSTEM,
	MYCOLOR_BTNFACE		= MYCOLOR_SYSTEM,
	MYCOLOR_BTNTEXT,			MYCOLOR_ACTIVEBORDER,
	MYCOLOR_ACTIVECAPTION,		MYCOLOR_CAPTIONTEXT,
	MYCOLOR_APPWORKSPACE,		MYCOLOR_WINDOW,
	MYCOLOR_WINDOWTEXT,			MYCOLOR_DESKTOP,
	MYCOLOR_INFOBK,				MYCOLOR_INFOTEXT,
	MYCOLOR_MSGBOXTEXT,			MYCOLOR_MENU,
	MYCOLOR_MENUTEXT,			MYCOLOR_HIGHLIGHTTEXT,
	MYCOLOR_HIGHLIGHT,			MYCOLOR_INACTIVEBORDER,
	MYCOLOR_INACTIVECAPTION,	MYCOLOR_INACTIVECAPTIONTEXT,
	MAX_MYCOLOR,
} ;

enum {
	MYLINE_NO	= 0,	MYLINE_SOLID,		MYLINE_DOTTED,
	MYLINE_THICK_SOLID,	MYLINE_THIN_DITHER,	MYLINE_THICK_DITHER,
	MAX_MYLINE,
} ;

enum {
	MYCOLORFACE_INDEX_MIHENKANMOJIRETSU	= 0,
	MYCOLORFACE_INDEX_HENKANMOJIRETSU	= 1,
} ;

typedef struct tagMYGENERICCONFIG {
	int				m_nAlwaysOpenKanaMode ;
	int				m_nEggLikeNewline ;
	int				m_nDeleteImpliesKakutei ;
	int				m_nUseNumericConversion ;
	int				m_nDabbrevLikeCompletion ;
	int				m_nKatakanaHiraganaHenkan ;
	int				m_nNumberStyle ;
	int				m_nDateAd ;
	int				m_nShowAnnotation ;
	int				m_nKakuteiEarly ;
	int				m_nProcessOkuriEarly ;
	int				m_nDeleteOkuriWhenQuit ;
}	MYGENERICCONFIG ;

#if !defined (NO_TSF)
typedef struct tagCICEROCONFIG {
	HWND			m_hwndEdit ;
	int				m_nEditingItem ;
	int				m_nEditingSubItem ;
	int				m_nEditTrue ;
	BOOL			m_rfShowLangBarIcon [NUM_SHOWKEYICON] ;
}	CICEROCONFIG ;
#endif

typedef struct tagMYCANDSELKEY {
	BYTE	_JHenkanShowCandidateKeys [NUM_JHENKAN_SHOW_CANDIDATE_KEYS] ;
	BYTE	_JInputByCodeOrMenuKeys1  [NUM_JINPUT_BY_CODE_OR_MENU_KEYS1] ;
	BYTE	_JInputByCodeOrMenuKeys2  [NUM_JINPUT_BY_CODE_OR_MENU_KEYS2] ;
}	MYCANDSELKEY ;

typedef struct tagDEFGENERICSETTING {
	LPCTSTR			m_strPath ;
	int				m_nDefault ;
	int				m_nOffset ;
}	DEFGENERICSETTING ;


typedef struct tagMYCOLORFACESET {
	int				m_nTextColor ;
	int				m_nBackColor ;
	int				m_nUnderLineColor ;
	int				m_nUnderLineType ;
}	MYCOLORFACESET ;

