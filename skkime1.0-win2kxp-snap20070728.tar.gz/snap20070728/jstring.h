#if !defined (jstring_h)

#if defined (__cplusplus)
extern "C" {
#endif
WORD	JisCharToSjisChar	(WORD) ;
WCHAR	JCharToUnicode	(WORD) ;
int		Hex2Int			(WORD) ;
int		JHiragana2Katakana	(LPWSTR, int, LPCWSTR, int, BOOL) ;
int		JKatakana2Hiragana	(LPWSTR, int, LPCWSTR, int) ;
int		JZenkana2Hankana	(LPWSTR, int, LPCWSTR, int) ;
int		JZenHanKatakana2Hiragana	(LPWSTR, int, LPCWSTR, int) ;
int		JHankana2Hiragana	(LPWSTR, int, LPCWSTR, int) ;
int		JHankana2Katakana	(LPWSTR, int, LPCWSTR, int) ;
int		JNumExp			(LPWSTR, int, int, LPCWSTR*, int*) ;
int		JNumSkip		(LPCWSTR*, int*) ;
int		JIdentityNumStr	(LPWSTR, int, LPCWSTR*, int*) ;
int		JZenkakuNumStr	(LPWSTR, int, LPCWSTR*, int*) ;
int		JKanjiNumStr	(LPWSTR, int, LPCWSTR*, int*) ;
int		JKanjiNumStr2	(LPWSTR, int, LPCWSTR*, int*) ;
int		JShogiNumStr	(LPWSTR, int, LPCWSTR*, int*) ;
int		JDateString		(LPWSTR, int, int, int) ;
int		JHenkanCopy		(LPWSTR, LPCWSTR, int) ;
int		lstrncpyW		(LPWSTR, LPCWSTR, int) ;
int		lstrncmpW		(LPCWSTR, LPCWSTR, int) ;
int		wmemindex		(LPCWSTR, LPCWSTR, int) ;
BOOL	JSharp4Stringp	(LPCWSTR, int) ;
int		JNoNumCopy		(LPWSTR, LPCWSTR, int) ;
int		JPhoneticStrcpy (LPWSTR, LPCWSTR, int) ;
#if defined (__cplusplus)
}
#endif

#endif


