#if !defined (tinymalloc_h)
#define	tinymalloc_h

struct tagTINYMEMBLOCK ;

typedef struct tagTINYMEMMGR {
	struct tagTINYMEMBLOCK*	m_lstAllocBlock ;
	struct tagTINYMEMBLOCK*	m_lstFreeBlock ;
#if defined (DEBUG_TINYMALLOC)
	void*			m_pvMemoryArea ;
	size_t			m_nMemoryArea ;
#endif
}	TINYMEMMGR ;


BOOL	TinyMalloc_Initialize	(TINYMEMMGR*, void*, size_t) ;
void	TinyMalloc_Uninitialize	(TINYMEMMGR*) ;
void*	TinyMalloc_Malloc		(TINYMEMMGR*, size_t) ;
BOOL	TinyMalloc_Free			(TINYMEMMGR*, void*) ;

#endif


