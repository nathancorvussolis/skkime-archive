#if !defined (mylocale_h)
#define	mylocale_h

/*	MIXED UNICODE AND ANSI */
#define	MYTEXT(x)			L ## x
typedef LPWSTR				LPMYSTR ;
typedef	LPCWSTR				LPCMYSTR ;
typedef wchar_t				MYCHAR ;

#define	MyRegCreateKeyEx(a,b,c,d,e,f,g,h,i)	RegCreateKeyExW((a),(b),(c),(d),(e),(f),(g),(h),(i))
#define	MyRegOpenKeyEx(a,b,c,d,e)			RegOpenKeyExW((a),(b),(c),(d),(e))
#define	MyRegEnumValue(a,b,c,d,e,f,g,h)		RegEnumValueW((a),(b),(c),(d),(e),(f),(g),(h))
#define	MyRegQueryValueEx(a,b,c,d,e,f)		RegQueryValueExW((a),(b),(c),(d),(e),(f))
#define	MyRegSetValueEx(a,b,c,d,e,f)		RegSetValueExW((a),(b),(c),(d),(e),(f))
#define	MyRegDeleteValue(a,b)				RegDeleteValueW((a),(b))
#define	MyRegCloseKey(a)					RegCloseKey((a))

#define	Mywsprintf							wsprintfW
#define	Mywvsprintf(a,b,c)					wvsprintfW((a),(b),(c))
#define	Mylstrlen(a)						lstrlenW((a))
#define	Mylstrcpy(a,b)						lstrcpyW((a),(b))
#define	Mylstrcpyn(a,b,c)					lstrcpynW((a),(b),(c))
#define	Mylstrcmp(a,b)						lstrcmpW((a),(b))
#define	Mylstrcmpn(a,b,c)					lstrcmpnW((a),(b),(c))
#define	MyExpandEnvironmentStrings(a,b,c)	ExpandEnvironmentStringsW((a),(b),(c))

#define	MySendMessage(a,b,c,d)				SendMessageW((a),(b),(c),(d))
#define	MyOutputDebugString(a)				OutputDebugStringW((a))
#define	MyDialogBoxParam(a,b,c,d,e)			DialogBoxParamW((a),(b),(c),(d),(e))
#define	MySetWindowText(a,b)				SetWindowTextW((a),(b))
#define	MyGetWindowText(a,b,c)				GetWindowTextW((a),(b),(c))
#define	MyGetDlgItemText(a,b,c,d)			GetDlgItemTextW((a),(b),(c),(d))

#define	MYLV_COLUMN							LV_COLUMNW
#define	MYLVITEM							LVITEMW
#define	MYLVFINDINFO						LVFINDINFOW

#define	MyListView_GetItem(hwnd,pitem)		\
	(BOOL)MySendMessage((hwnd),LVM_GETITEMW,0,(LPARAM)(MYLVITEM*)(pitem))
#define	MyListView_SetItem(hwnd,pitem)		\
	(BOOL)MySendMessage((hwnd),LVM_SETITEMW,0,(LPARAM)(const MYLVITEM*)(pitem))
#define	MyListView_InsertItem(hwnd,pitem)	\
	(int)MySendMessage((hwnd),LVM_INSERTITEMW,0,(LPARAM)(const MYLVITEM*)(pitem))
#define	MyListView_DeleteItem(hwnd,i)		\
	(BOOL)MySendMessage((hwnd),LVM_DELETEITEM,(WPARAM)(int)(i),0L)
#define	MyListView_DeleteAllItems(hwnd)		\
	(BOOL)MySendMessage((hwnd),LVM_DELETEALLITEMS,0,0L)
#define	MyListView_FindItem(hwnd,iStart,plvfi)	\
	(int)MySendMessage((hwnd),LVM_FINDITEMW,(WPARAM)(int)(iStart), (LPARAM)(const MYLVFINDINFO*)(plvfi))
#define	MyListView_SetItemPosition(hwndLV,i,x,y)	\
	(BOOL)MySendMessage((hwndLV),LVM_SETITEMPOSITION,(WPARAM)(int)(i),MAKELPARAM((x), (y)))
#define	MyListView_GetItemPosition(hwndLV,i,ppt)	\
	(BOOL)MySendMessage((hwndLV),LVM_GETITEMPOSITION,(WPARAM)(int)(i),(LPARAM)(POINT *)(ppt))
#define	MyListView_GetStringWidth(hwnd,psz)	\
	(int)MySendMessage((hwnd), LVM_GETSTRINGWIDTHW, 0, (LPARAM)(LPCMYSTR)(psz))
#define	MyListView_HitTest(hwndLV,pinfo)	\
	(int)MySendMessage((hwndLV),LVM_HITTEST, 0, (LPARAM)(LV_HITTESTINFO *)(pinfo))
#define	MyListVew_GetColumn(hwnd,iCol,pcol)	\
	(BOOL)MySendMessage((hwnd),LVM_GETCOLUMNW,(WPARAM)(int)(iCol),(LPARAM)(MYLV_COLUMN *)(pcol))
#define	MyListView_SetColumn(hwnd,iCol,pcol)	\
	(BOOL)MySendMessage((hwnd),LVM_SETCOLUMNW,(WPARAM)(int)(iCol),(LPARAM)(const MYLV_COLUMN*)(pcol))
#define	MyListView_InsertColumn(hwnd,iCol,pcol)	\
	(int)MySendMessage((hwnd),LVM_INSERTCOLUMNW,(WPARAM)(int)(iCol),(LPARAM)(const MYLV_COLUMN*)(pcol))
#define	MyListView_GetColumnWidth(hwnd,iCol)	\
	(int)MySendMessage((hwnd),LVM_GETCOLUMNWIDTH,(WPARAM)(int)(iCol), 0)
#define	MyListView_SetColumnWidth(hwnd,iCol,cx)	\
	(BOOL)MySendMessage((hwnd),LVM_SETCOLUMNWIDTH,(WPARAM)(int)(iCol), MAKELPARAM((cx),0))
#define	MyListView_CreateDragImage(hwnd,i,lpptUpLeft)	\
	(HIMAGELIST)MySendMessage((hwnd), LVM_CREATEDRAGIMAGE, (WPARAM)(int)(i), (LPARAM)(LPPOINT)(lpptUpLeft))
#define	MyListView_Update(hwndLV,i)	\
	(BOOL)MySendMessage((hwndLV), LVM_UPDATE, (WPARAM)(i), 0L)
#define	MyListView_SetItemState(hwnd,i,data,mask)	{	\
	MYLVITEM	mylvi ;	\
	mylvi.stateMask	= (mask) ;	\
	mylvi.state		= (data) ;	\
	MySendMessage((hwnd), LVM_SETITEMSTATE, (WPARAM)(i), (LPARAM)(MYLVITEM *)&mylvi) ;	\
}
#define	MyListView_GetItemText(hwndLV,i,iSubItem_,pszText_,cchTextMax_)	{\
		MYLVITEM	mylvi ;	\
		mylvi.iSubItem		= (iSubItem_) ;	\
		mylvi.cchTextMax	= (cchTextMax_) ;	\
		mylvi.pszText		= (pszText_) ;	\
		MySendMessage((hwndLV),LVM_GETITEMTEXTW,(WPARAM)(i),(LPARAM)(MYLVITEM *)&mylvi) ;	\
	}
#define	MyListView_SetItemText(hwndLV,i,iSubItem_,pszText_)	{	\
		MYLVITEM	mylvi ;	\
		mylvi.iSubItem	= (iSubItem_) ;	\
		mylvi.pszText	= (pszText_) ;	\
		MySendMessage ((hwndLV), LVM_SETITEMTEXTW, (WPARAM)(i), (LPARAM)(MYLVITEM*)&mylvi) ; \
	}
#define	MyListView_SetItemCount(hwndLV,cItems)	\
	MySendMessage((hwndLV), LVM_SETITEMCOUNT, (WPARAM)(cItems), 0)
#define	MyListView_SortItems(hwndLV,_pfnCompare,_lPrm)	\
	(BOOL)MySendMessage((hwndLV),LVM_SORTITEMS,(WPARAM)(LPARAM)(_lPrm),(LPARAM)(PFNLVCOMPARE)(_pfnCompare))
#define	MyListView_SetExtendedListViewStyle(hwndLV,dw)	\
	(DWORD)MySendMessage((hwndLV),LVM_SETEXTENDEDLISTVIEWSTYLE,0,(dw))
#define	MyListView_SetExtendedListViewStyleEx(hwndLV,dwMask,dw)	\
	(DWORD)MySendMessage((hwndLV),LVM_SETEXTENDEDLISTVIEWSTYLE,(dwMask),(dw))
#define	MyListView_GetSelectionMark(hwnd)	\
	(int)MySendMessage((hwnd),LVM_GETSELECTIONMARK,0,0)
#define	MyListView_SetSelectionMark(hwnd,i)	\
	(int)MySendMessage((hwnd),LVM_SETSELECTIONMARK,0,(LPARAM)(i))
#define	MyListView_GetItemCount(hwnd) \
	(int)MySendMessage((hwnd),LVM_GETITEMCOUNT, 0, 0L)

#endif

