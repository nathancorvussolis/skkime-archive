#if !defined (NO_TSF)
/*	LanguageBar �́u���̓��[�h�v�{�^�����i��B
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
extern "C" {
#include "skki1_0.h"
#include "resource.h"
}
#include "common\msctf_.h"
#include "tsf.h"

#define LANGBAR_ITEM_DESC	L"���̓��[�h" // max 32 chars! �ށA�ő�32�����������B

#define	SKKIME_LANGBARITEMSINK_COOKIE	0x0fab0faa

enum {
	MENU_ITEM_INDEX_CANCEL		= -1,
	MENU_ITEM_INDEX_HIRAGANA	= 0,
	MENU_ITEM_INDEX_KATAKANA,
	MENU_ITEM_INDEX_ZENEI,
	MENU_ITEM_INDEX_HANKATA,
	MENU_ITEM_INDEX_ASCII,
	MENU_ITEM_INDEX_DIRECT
} ;

class	CLangBarItemCModeButton ;

typedef struct {
	const WCHAR*	pchDesc ;
	void	(*pfnHandler)(CLangBarItemCModeButton*) ;
}	TSFLBMENUINFO ;

/*	CModeItemButton: Conversion Mode Language Bar Item Button
 */
class	CLangBarItemCModeButton : public ITfLangBarItemButton,
						   public ITfSource
{
public:
	CLangBarItemCModeButton () ;
	CLangBarItemCModeButton (HIMC hIMC) ;
	~CLangBarItemCModeButton () ;

	// IUnknown
	STDMETHODIMP	QueryInterface (REFIID riid, void **ppvObj) ;
	STDMETHODIMP_(ULONG)	AddRef (void) ;
	STDMETHODIMP_(ULONG)	Release (void) ;
	
	// ITfLangBarItem
	STDMETHODIMP	GetInfo (TF_LANGBARITEMINFO *pInfo) ;
	STDMETHODIMP	GetStatus (DWORD *pdwStatus) ;
	STDMETHODIMP	Show (BOOL fShow) ;
	STDMETHODIMP	GetTooltipString (BSTR *pbstrToolTip) ;
	
	// ITfLangBarItemButton
	STDMETHODIMP	OnClick (TfLBIClick click, POINT pt, const RECT *prcArea) ;
	STDMETHODIMP	InitMenu (ITfMenu *pMenu) ;
	STDMETHODIMP	OnMenuSelect (UINT wID) ;
	STDMETHODIMP	GetIcon (HICON *phIcon) ;
	STDMETHODIMP	GetText (BSTR *pbstrText) ;

	// ITfSource
	STDMETHODIMP	AdviseSink(REFIID riid, IUnknown *punk, DWORD *pdwCookie);
	STDMETHODIMP	UnadviseSink(DWORD dwCookie);

	STDMETHODIMP	Update () ;
	STDMETHODIMP	SetActiveContext	(HIMC hIMC) ;

private:
	void		_Menu_ToCMode		(DWORD fdwConversion) ;
	int			_GetConversionMode	() ;

	static	void	_Menu_ToHiragana(CLangBarItemCModeButton* pThis) ;
	static	void	_Menu_ToZenkata	(CLangBarItemCModeButton* pThis) ;
	static	void	_Menu_ToZenei	(CLangBarItemCModeButton* pThis) ;
	static	void	_Menu_ToHankata	(CLangBarItemCModeButton* pThis) ;
	static	void	_Menu_ToHanei	(CLangBarItemCModeButton* pThis) ;
	static	void	_Menu_ToDirect	(CLangBarItemCModeButton* pThis) ;

private:
	ITfLangBarItemSink*		_pLangBarItemSink ;
	TF_LANGBARITEMINFO		_tfLangBarItemInfo ;
	LONG					_cRef ;

	HIMC					_hIMC ;
	BOOL					_bShow ;

	static	const TSFLBMENUINFO	c_rgMenuItems [] ;
} ;

const TSFLBMENUINFO	CLangBarItemCModeButton::c_rgMenuItems []	= {
	{ L"�Ђ炪��",		CLangBarItemCModeButton::_Menu_ToHiragana },
	{ L"�S�p�J�^�J�i",	CLangBarItemCModeButton::_Menu_ToZenkata },
	{ L"�S�p�p��",		CLangBarItemCModeButton::_Menu_ToZenei },
	{ L"���p�J�^�J�i",	CLangBarItemCModeButton::_Menu_ToHankata },
	{ L"���p�p��",		CLangBarItemCModeButton::_Menu_ToHanei },
	{ L"���ړ���",		CLangBarItemCModeButton::_Menu_ToDirect },
	{ NULL,				NULL },
	{ L"�L�����Z��",	NULL }
} ;

/*
 */
CLangBarItemCModeButton::CLangBarItemCModeButton ()
{
	//DllAddRef () ;
	_tfLangBarItemInfo.clsidService	= c_clsidSkkImeTextService ;
	//_tfLangBarItemInfo.clsidService	= CLSID_NULL ;
	_tfLangBarItemInfo.guidItem		= c_guidItemButtonCMode ;
	_tfLangBarItemInfo.dwStyle		= TF_LBI_STYLE_BTN_MENU | TF_LBI_STYLE_TEXTCOLORICON | TF_LBI_STYLE_SHOWNINTRAY ;
	_tfLangBarItemInfo.ulSort		= 2 ;
	SafeStringCopy (_tfLangBarItemInfo.szDescription, NELEMENTS (_tfLangBarItemInfo.szDescription), LANGBAR_ITEM_DESC) ;
	_pLangBarItemSink	= NULL ;
	_cRef				= 1 ;
	_hIMC				= NULL ;
	_bShow				= TRUE ;
	return ;
}

CLangBarItemCModeButton::CLangBarItemCModeButton (HIMC hIMC)
{
	//DllAddRef () ;
	_tfLangBarItemInfo.clsidService	= c_clsidSkkImeTextService ;
	//_tfLangBarItemInfo.clsidService	= CLSID_NULL ;
	_tfLangBarItemInfo.guidItem		= c_guidItemButtonCMode ;
	_tfLangBarItemInfo.dwStyle		= TF_LBI_STYLE_BTN_MENU | TF_LBI_STYLE_TEXTCOLORICON | TF_LBI_STYLE_SHOWNINTRAY ;
	_tfLangBarItemInfo.ulSort		= 2 ;
	SafeStringCopy (_tfLangBarItemInfo.szDescription, NELEMENTS (_tfLangBarItemInfo.szDescription), LANGBAR_ITEM_DESC) ;
	_pLangBarItemSink	= NULL ;
	_cRef				= 1 ;
	_hIMC				= hIMC ;
	_bShow				= TRUE ;
	return ;
}
CLangBarItemCModeButton::~CLangBarItemCModeButton ()
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemCModeButton::~CLangBarItemCModeButton (this:%p)\n"), this)) ;
	//DllRelease () ;
	return ;
}

STDAPI
CLangBarItemCModeButton::QueryInterface (
	REFIID			riid,
	void**			ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfLangBarItem) ||
		IsEqualIID (riid, IID_ITfLangBarItemButton)) {
		*ppvObj	= (ITfLangBarItemButton *)this ;
	} else if (IsEqualIID (riid, IID_ITfSource)) {
		*ppvObj	= (ITfSource *)this ;
	}
	if (*ppvObj != NULL) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CLangBarItemCModeButton::AddRef ()
{
	return	++ _cRef ;
}

STDAPI_(ULONG)
CLangBarItemCModeButton::Release ()
{
	LONG	cr	= -- _cRef ;

	if (_cRef == 0) {
		delete	this ;
	}
	return	cr ;
}

STDAPI
CLangBarItemCModeButton::GetInfo (
	TF_LANGBARITEMINFO*		pInfo)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemCModeButton::GetInfo (this:%p)\n"), this)) ;

	if (pInfo == NULL)
		return	E_INVALIDARG ;

	*pInfo	= _tfLangBarItemInfo ;
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::Show (
	BOOL					bShow)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemCModeButton::Show (BOOL:%d)\n"), bShow)) ;
	if (_bShow != bShow) {
		if (_pLangBarItemSink == NULL)
			return	CONNECT_E_NOCONNECTION ;

		_bShow	= bShow ;
		_pLangBarItemSink->OnUpdate (TF_LBI_STATUS) ;
	}
    return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::GetStatus (
	DWORD*					pdwStatus)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemCModeButton::Show (DWORD*:%d)\n"), pdwStatus)) ;

	if (pdwStatus == NULL)
		return	E_INVALIDARG ;

	*pdwStatus	= ((_hIMC != NULL)? 0 : TF_LBI_STATUS_DISABLED) | (_bShow? 0 : TF_LBI_STATUS_HIDDEN) ;
	return	S_OK ;
}

/*	Button �� tooltip ��Ԃ��B�Ԃ��l�� SysAllocString �ɂ����
 *	�m�ۂ����̈�ɏ������K�v������B����� SysFreeString ��
 *	��̂́A�Ăяo�������̐ӔC�ł���B
 */
STDAPI
CLangBarItemCModeButton::GetTooltipString (
	BSTR*					pbstrToolTip)
{
	if (pbstrToolTip == NULL)
		return	E_INVALIDARG ;

	*pbstrToolTip	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrToolTip == NULL)? E_OUTOFMEMORY : S_OK ;
}

/*	ITfLangBarItemButton::OnClick
 *
 *	���� method �̓��[�U������o�[�� TF_LBI_STYLE_BTN_BUTTON �܂�
 *	�� TF_LBI_STYLE_BTN_TOGGLE �X�^�C���������Ă���{�^���̏�Ń}
 *	�E�X���N���b�N�������ɌĂяo�����B
 *	�����{�^�� item �� TF_LBI_STYLE_BTN_BUTTON �X�^�C���������Ȃ�
 *	�̂Ȃ�A���� method �g���Ȃ��B
 *(*)
 *	���̏󋵂ł͓��ɉ�������K�v�͂Ȃ��̂ŁAS_OK �𑦕Ԃ��B
 */
STDAPI
CLangBarItemCModeButton::OnClick (
	TfLBIClick				click,
	POINT					pt,
	const RECT*				prcArea)
{
	return	S_OK ;
}

/*	ITfLangBarItemButton::InitMenu
 *
 *	���� method �� TF_LBI_STYLE_BTN_MENU �X�^�C��������������o�[�̃{�^��
 *	������o�[���{�^���ɑ΂��ĕ\������ menu item ��ǉ����ėL���ɂ��邽��
 *	�ɌĂяo�����B
 */
STDAPI
CLangBarItemCModeButton::InitMenu (
	ITfMenu*				pMenu)
{
	register int		i, nCMode ;
	register DWORD		dwFlag ;
	register LPCWSTR	wstrDesc ;
	register ULONG		nstrDesc ;

	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemCModeButton::InitMenu (ITfMenu:%p)\n"), pMenu)) ;

	if (pMenu == NULL)
		return	E_INVALIDARG ;

	if (_hIMC != NULL) {
		/*	�Ƃ����킯�Ń{�^���������ꂽ���ɕ\������郁�j���[��
		 *	�o�^���s���B
		 */
		nCMode	= _GetConversionMode () ;
		for (i = 0 ; i < NELEMENTS (c_rgMenuItems) ; i ++) {
			wstrDesc		= c_rgMenuItems [i].pchDesc ;
			if (wstrDesc != NULL) {
				nstrDesc	= wcslen (wstrDesc) ;
				dwFlag		= (i == nCMode)? TF_LBMENUF_CHECKED : 0 ;
			} else {
				nstrDesc	= 0 ;
				dwFlag		= TF_LBMENUF_SEPARATOR ;
			}
			pMenu->AddMenuItem (i, dwFlag, NULL, NULL, wstrDesc, nstrDesc, NULL) ;
		}
	}
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::OnMenuSelect (
	UINT					wID)
{
	if (wID >= NELEMENTS (c_rgMenuItems))
		return	E_FAIL ;

	/*	NULL �̏ꍇ�� Cancel ���Ǝv�����Ƃɂ���B*/
	if (c_rgMenuItems [wID].pfnHandler != NULL) {
		c_rgMenuItems [wID].pfnHandler (this) ;
		if (_pLangBarItemSink != NULL)
			_pLangBarItemSink->OnUpdate (TF_LBI_ICON) ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::GetIcon (
	HICON*					phIcon)
{
	HICON		hIcon ;
	DWORD		dwConversion, dwSentence ;
	LPCTSTR		str	= NULL ;

	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemCModeButton::GetIcon(%p)\n"), phIcon)) ;

	if (phIcon == NULL)
		return	E_INVALIDARG ;

	if (_hIMC == NULL) 
		goto	Skip ;

	if (ImmGetOpenStatus (_hIMC)) {
		DWORD	dwConversion, dwSentence ;

		if (ImmGetConversionStatus (_hIMC, &dwConversion, &dwSentence)) {
			if (dwConversion & IME_CMODE_FULLSHAPE){
				if (!(dwConversion & IME_CMODE_LANGUAGE)){
					str	= TEXT ("INDICICONF") ;
				} else if ((dwConversion & IME_CMODE_LANGUAGE) == IME_CMODE_NATIVE){
					str	= TEXT ("INDICICONC") ;
				} else {
					str	= TEXT ("INDICICOND") ;
				}
			} else {
				if (dwConversion & IME_CMODE_NATIVE){
					str	= TEXT ("INDICICONE") ;
				} else {
					str	= TEXT ("INDICICONB") ;
				}
			}
		}
	} else {
		str	= TEXT ("INDICICONG") ;
	}
Skip:
	if (str == NULL) {
		str	= TEXT ("INDICICONC") ;
	}

	hIcon	=(HICON)LoadImage (g_hInst, str, IMAGE_ICON, 16, 16, LR_SHARED);
	*phIcon	= hIcon ;
    return (hIcon != NULL) ? S_OK : E_FAIL ;
}

STDAPI
CLangBarItemCModeButton::GetText (
	BSTR*			pbstrText)
{
	if (pbstrText == NULL)
		return	E_INVALIDARG ;

	*pbstrText	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrText == NULL)? E_OUTOFMEMORY : S_OK ;
}

STDAPI
CLangBarItemCModeButton::AdviseSink (
	REFIID			riid,
	IUnknown*		punk,
	DWORD*			pdwCookie)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemCModeButton::AdviseSink (this:%p)\n"), this)) ;

    if (!IsEqualIID (IID_ITfLangBarItemSink, riid)) {
		DEBUGPRINTFEX (100, (TEXT ("CONNECT_E_CANNOTCONNECT\n"))) ;
		return	CONNECT_E_CANNOTCONNECT ;
	}

    if (_pLangBarItemSink != NULL) {
		DEBUGPRINTFEX (100, (TEXT ("CONNECT_E_ADVISELIMIT\n"))) ;
        return	CONNECT_E_ADVISELIMIT ;
	}

    if (punk->QueryInterface (IID_ITfLangBarItemSink, (void **)&_pLangBarItemSink) != S_OK) {
		DEBUGPRINTFEX (100, (TEXT ("E_NOINTERFACE\n"))) ;
        _pLangBarItemSink	= NULL ;
        return	E_NOINTERFACE ;
    }

    *pdwCookie	= SKKIME_LANGBARITEMSINK_COOKIE ;
    return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::UnadviseSink (
	DWORD			dwCookie)
{
    if (dwCookie != SKKIME_LANGBARITEMSINK_COOKIE)
        return	CONNECT_E_NOCONNECTION ;

    if (_pLangBarItemSink == NULL)
        return	CONNECT_E_NOCONNECTION ;

    _pLangBarItemSink->Release () ;
    _pLangBarItemSink	= NULL ;

    return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::Update ()
{
	DWORD	dwUpdate, dwStatus ;

	if (_pLangBarItemSink == NULL)
		return	CONNECT_E_NOCONNECTION ;

	_pLangBarItemSink->OnUpdate (TF_LBI_ICON | TF_LBI_STATUS) ;
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::SetActiveContext (HIMC hIMC)
{
	_hIMC	= hIMC ;
	return	Update () ;
}

/*========================================================================*
 *	public function interface
 */
BOOL
bButtonCMode_Create (
	HIMC				hIMC,
	ITfLangBarItem** 	ppLangBarItem)
{
	if (ppLangBarItem == NULL)
		return	FALSE ;
	*ppLangBarItem	= new CLangBarItemCModeButton (hIMC) ;
	return	(*ppLangBarItem != NULL) ;
}

HRESULT
hrButtonCMode_Update (
	ITfLangBarItem*		pItem)
{
	CLangBarItemCModeButton*	pButtonCMode ;

	if (pItem == NULL)
		return	E_INVALIDARG ;

	pButtonCMode	= (CLangBarItemCModeButton*) pItem ;
	return	pButtonCMode->Update () ;
}

HRESULT
hrButtonCMode_SetActiveContext (
	ITfLangBarItem*		pItem,
	HIMC				hIMC)
{
	CLangBarItemCModeButton*	pButtonCMode ;

	if (pItem == NULL)
		return	E_INVALIDARG ;

	pButtonCMode	= (CLangBarItemCModeButton*) pItem ;
	return	pButtonCMode->SetActiveContext (hIMC) ;
}

/*========================================================================*
 *	private functions
 */
void
CLangBarItemCModeButton::_Menu_ToCMode (
	register DWORD		fdwConversion)
{
	if (! _hIMC)
		return ;

	if (! ImmGetOpenStatus (_hIMC)) 
		ImmSetOpenStatus (_hIMC, TRUE) ;
	ImmSetConversionStatus (_hIMC, fdwConversion, 0) ;
	return ;
}

int
CLangBarItemCModeButton::_GetConversionMode ()
{
	DWORD	dwConversion, dwSentense ;

	if (! _hIMC)
		return	MENU_ITEM_INDEX_DIRECT ;

	if (! ImmGetOpenStatus (_hIMC)) 
		return	MENU_ITEM_INDEX_DIRECT ;

	if (! ImmGetConversionStatus (_hIMC, &dwConversion, &dwSentense))
		return	MENU_ITEM_INDEX_CANCEL ;

	if (dwConversion & IME_CMODE_FULLSHAPE){
		if (!(dwConversion & IME_CMODE_LANGUAGE)){
			return	MENU_ITEM_INDEX_ZENEI ;
		} else if ((dwConversion & IME_CMODE_LANGUAGE) == IME_CMODE_NATIVE){
			return	MENU_ITEM_INDEX_HIRAGANA ;
		} else {
			return	MENU_ITEM_INDEX_KATAKANA ;
		}
	} else {
		if (dwConversion & IME_CMODE_NATIVE){
			return	MENU_ITEM_INDEX_HANKATA ;
		} else {
			return	MENU_ITEM_INDEX_ASCII ;
		}
	}
}

/*================================================================
 *	static methods
 */
void
CLangBarItemCModeButton::_Menu_ToHiragana (CLangBarItemCModeButton* pThis)
{
	pThis->_Menu_ToCMode (IME_CMODE_JAPANESE | IME_CMODE_FULLSHAPE) ;
}

void
CLangBarItemCModeButton::_Menu_ToZenkata  (CLangBarItemCModeButton* pThis)
{
	pThis->_Menu_ToCMode (IME_CMODE_JAPANESE | IME_CMODE_KATAKANA | IME_CMODE_FULLSHAPE) ;
}

void
CLangBarItemCModeButton::_Menu_ToZenei    (CLangBarItemCModeButton* pThis)
{
	pThis->_Menu_ToCMode (IME_CMODE_FULLSHAPE) ;
}

void
CLangBarItemCModeButton::_Menu_ToHankata  (CLangBarItemCModeButton* pThis)
{
	pThis->_Menu_ToCMode (IME_CMODE_LANGUAGE | IME_CMODE_NATIVE) ;
}

void
CLangBarItemCModeButton::_Menu_ToHanei    (CLangBarItemCModeButton* pThis)
{
	pThis->_Menu_ToCMode (0) ;
}

void
CLangBarItemCModeButton::_Menu_ToDirect   (CLangBarItemCModeButton* pThis)
{
	if (! pThis->_hIMC)
		return ;
	ImmSetOpenStatus (pThis->_hIMC, FALSE) ;
	return ;
}


#endif

