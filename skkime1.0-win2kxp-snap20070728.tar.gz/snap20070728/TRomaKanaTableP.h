#if !defined (TRomaKanaTableP_h)
#define	TRomaKanaTableP_h

#include "TRomaKanaTable.h"

#define	NUM_ROMAKANATABLEENTRY	5

struct tagCTRomaKanaTableEntry {
	LPCWSTR		_wstrPrefix ;
	LPCWSTR		_wstrHiragana ;
	LPCWSTR		_wstrKatakana ;
} ;

struct tagCTRomaKanaTable {
	int						_nEntries ;
	CTRomaKanaTableEntry*	_pEntries ;
} ;

#endif


