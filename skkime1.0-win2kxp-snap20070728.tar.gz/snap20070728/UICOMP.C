/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * UICOMP.C
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "skkui.h"
#include "common\confcommon.h"

static	void	PASCAL	UIComp_move (HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
static	void	PASCAL	UIComp_moveHorz (HWND, LPUIEXTRA, LPINPUTCONTEXT, LPCOMPOSITIONSTRING, RECT*, POINT*) ;
static	void	PASCAL	UIComp_moveVert (HWND, LPUIEXTRA, LPINPUTCONTEXT, LPCOMPOSITIONSTRING, RECT*, POINT*) ;
static	void	PASCAL	UIComp_moveDefault (HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
static	void	PASCAL	UIComp_paint (HWND, HDC, HFONT, LPINPUTCONTEXT, LPCOMPOSITIONSTRING) ;
static	void	PASCAL	UIComp_paintSub (HWND, HDC, HFONT, LPINPUTCONTEXT, LPCOMPOSITIONSTRING, LONG, LONG) ;
static	void	PASCAL	UIComp_drawTextOneLine (HWND, HDC, LPMYSTR, LPBYTE, int, int, BOOL) ;
static	int		PASCAL	NumCharInDX (HDC, LPMYSTR, int, int, BOOL FAR*) ;
static	int		PASCAL	NumCharInDY (HDC, LPMYSTR, int, int, BOOL FAR*) ;
static	void	PASCAL	AddRect (LPRECT, LPRECT) ;
static	BOOL	PASCAL	IsValidRect (LPRECT) ;

/*************************************************************************
 *	Composition Window �� WINDOWPROC�B
 *(�R�����g)
 *	Composition Window ����Window Message�͂��̊֐��ɑ����ė��܂��̂ŁA
 *	Window Message �ɑΉ������������s���܂��B���̊֐����̂� Window
 *	Message �̐U�蕪�������ł����ǁB
 *(����)
 *	hWnd	Window Message ���󂯎���� Composition Window �� Handle
 *	message	Window Message
 *	wParam	Window Message �̈�������1
 *	lParam	Window Message �̈�������2
 *************************************************************************/
LRESULT	CALLBACK
UIComp_WndProc (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND	hUIWnd ;

	switch (message){
	case	WM_PAINT:
		UIComp_Paint (hWnd) ;
		break ;

	case	WM_SETCURSOR:
	case	WM_MOUSEMOVE:
	case	WM_LBUTTONUP:
	case	WM_RBUTTONUP:
		if ((message == WM_SETCURSOR) &&
			(HIWORD(lParam) != WM_LBUTTONDOWN) &&
			(HIWORD(lParam) != WM_RBUTTONDOWN)) 
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_MOVE:
		hUIWnd = (HWND)GetWindowLongPtr (hWnd, FIGWL_UICOMP_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_DEFCOMPMOVE, wParam, lParam) ;
		break ;

	case	WM_ERASEBKGND:
		return	1 ;

	default:
		if (!MyIsIMEMessage(message))
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return 0;
}

/*
 *	IME �����͒��̕������\������ۂɗ��p���� Composition Window ���쐬��
 *	��֐��B
 */
void	PASCAL
UIComp_Create (
	HWND				hUIWnd,
	LPUIEXTRA			lpUIExtra,
	LPINPUTCONTEXT		lpIMC)
{
	int			i ;
	RECT		rc ;
	HINSTANCE	hInstance ;

	lpUIExtra->dwCompStyle	= lpIMC->cfCompForm.dwStyle ;
	/*
	 *	hInst �� hUIWnd �� INSTANCE ���قȂ�\��������̂ŁA������
	 *	hUIWnd �� INSTANCE ����蒼���B
	 */
	hInstance				= (HINSTANCE)GetWindowLongPtr (hUIWnd, GWLP_HINSTANCE) ;
	/*
	 *	Composition Window ���쐬����B�쐬�Ɠ����Ɉʒu����t�H���g
	 *	�������������Ă܂��B
	 */
	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (!IsWindow (lpUIExtra->uiComp[i].hWnd)) {
			/* hInst �Ɨ^����ꂽ hUIWnd �� hInstance �̒l���قȂ�? */
			lpUIExtra->uiComp[i].hWnd = 
				CreateWindowEx (0,
							 (LPTSTR)g_szCompStrClassName, NULL,
							 WS_COMPNODEFAULT,
							 0, 0, 1, 1,
							 hUIWnd, NULL, hInstance, NULL) ;
		}
		lpUIExtra->uiComp[i].rc.left	= 0 ;
		lpUIExtra->uiComp[i].rc.top		= 0 ;
		lpUIExtra->uiComp[i].rc.right	= 1 ;
		lpUIExtra->uiComp[i].rc.bottom	= 1 ;
		SetWindowLongPtr (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_FONT,		(LONG_PTR)lpUIExtra->hFont) ;
		SetWindowLongPtr (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_SVRWND,		(LONG_PTR)hUIWnd) ;
		SetWindowLong    (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_PREVCURSOR,	(LONG)0) ;
		ShowWindow   (lpUIExtra->uiComp [i].hWnd, SW_HIDE) ;
		lpUIExtra->uiComp[i].bShow	= FALSE ;
	}
	if (lpUIExtra->uiDefComp.pt.x == -1){
		GetWindowRect (lpIMC->hWnd, &rc) ;
		lpUIExtra->uiDefComp.pt.x	= rc.left ;
		lpUIExtra->uiDefComp.pt.y	= rc.bottom + 1 ;
	}
	/* Root Window Style �̏ꍇ�� Window ���쐬����B*/
	if (!IsWindow (lpUIExtra->uiDefComp.hWnd)){
		lpUIExtra->uiDefComp.hWnd = 
			CreateWindowEx (WS_EX_WINDOWEDGE,
							(LPTSTR) g_szCompStrClassName, NULL,
							WS_COMPDEFAULT | WS_DLGFRAME,
							lpUIExtra->uiDefComp.pt.x,
							lpUIExtra->uiDefComp.pt.y,
							1, 1,
							hUIWnd, NULL, hInstance, NULL) ;
		SetClassLongPtr (lpUIExtra->uiDefComp.hWnd, GCLP_HBRBACKGROUND, (LONG_PTR) (COLOR_WINDOW + 1)) ;
	}
	//SetWindowLong (lpUIExtra->uiDefComp.hWnd, FIGWL_UICOMP_FONT,(DWORD)lpUIExtra->hFont) ;
	SetWindowLongPtr (lpUIExtra->uiDefComp.hWnd, FIGWL_UICOMP_SVRWND,		(LONG_PTR)hUIWnd) ;
	SetWindowLong    (lpUIExtra->uiDefComp.hWnd, FIGWL_UICOMP_PREVCURSOR, 	(LONG)0) ;
	ShowWindow (lpUIExtra->uiDefComp.hWnd, SW_HIDE) ;
	lpUIExtra->uiDefComp.bShow	= FALSE ;
	return ;
}

void	PASCAL
UIComp_Move (
	HWND				hUIWnd,
	LPUIEXTRA			lpUIExtra,
	LPINPUTCONTEXT		lpIMC)
{
	DEBUGPRINTFEX (99, (MYTEXT ("UIComp_Move (hwnd:%x, style:%lx)\n"),
						hUIWnd, lpIMC->cfCompForm.dwStyle)) ;
	
	lpUIExtra->dwCompStyle	= lpIMC->cfCompForm.dwStyle ;
	if (! (lpUIExtra->dwShowStyle & ISC_SHOWUICOMPOSITIONWINDOW))
		return ;
	if (lpIMC->cfCompForm.dwStyle){
		UIComp_move (hUIWnd, lpUIExtra, lpIMC) ;
	} else {
		UIComp_moveDefault (hUIWnd, lpUIExtra, lpIMC) ;
	}
	return ;
}

void	PASCAL
UIComp_Paint (
	HWND 					hCompWnd)
{
	PAINTSTRUCT			ps ;
	HIMC				hIMC ;
	LPINPUTCONTEXT 		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	HDC					hDC ;
	RECT				rc ;
	HFONT				hFont		= (HFONT)NULL ;
	HFONT				hOldFont	= (HFONT)NULL ;
	HWND				hSvrWnd ;

	hDC	= BeginPaint (hCompWnd, &ps) ;
	if (hFont = (HFONT)GetWindowLongPtr (hCompWnd, FIGWL_UICOMP_FONT))
		hOldFont = SelectObject (hDC, hFont) ;

	hSvrWnd = (HWND)GetWindowLongPtr (hCompWnd, FIGWL_UICOMP_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,  IMMGWLP_IMC) ;
	if (hIMC){
		lpIMC		= ImmLockIMC (hIMC) ;
		lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpCompStr){
			if (lpCompStr->dwSize > sizeof (COMPOSITIONSTRING)){
				UIComp_paint (hCompWnd, hDC, hFont, lpIMC, lpCompStr) ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	if (hFont && hOldFont)
		SelectObject (hDC, hOldFont) ;
	EndPaint (hCompWnd, &ps) ;
	return ;
}

void PASCAL
UIComp_Hide (
	LPUIEXTRA		lpUIExtra)
{
	int	i ;
	RECT			rc ;

	DEBUGPRINTFEX (99, (MYTEXT ("UIComp_Hide (LPUIEXTRA:%p)\n"), lpUIExtra)) ;

	if (IsWindow (lpUIExtra->uiDefComp.hWnd)){
		if (!lpUIExtra->dwCompStyle)
			GetWindowRect (lpUIExtra->uiDefComp.hWnd, (LPRECT)&rc) ;

		ShowWindow(lpUIExtra->uiDefComp.hWnd, SW_HIDE) ;
		lpUIExtra->uiDefComp.bShow	= FALSE  ;
	}
	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (IsWindow (lpUIExtra->uiComp[i].hWnd)){
			ShowWindow(lpUIExtra->uiComp[i].hWnd, SW_HIDE) ;
			lpUIExtra->uiComp[i].bShow	= FALSE ;
		}
	}
	return ;
}

void	PASCAL
UIComp_SetFont (LPUIEXTRA lpUIExtra)
{
	int i ;
	for (i = 0 ; i < MAXCOMPWND ; i++)
		if (IsWindow (lpUIExtra->uiComp[i].hWnd))
			SetWindowLongPtr (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_FONT, (LONG_PTR)lpUIExtra->hFont) ;
	return ;
}

/*========================================================================*
 *	private functions
 */
void	PASCAL
UIComp_move  (
	HWND				hUIWnd,
	LPUIEXTRA			lpUIExtra,
	LPINPUTCONTEXT		lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;
	POINT				ptSrc ;
	RECT				rcSrc ;
	int					dx ;
	int					dy ;
	int					num ;
	int					curx ;
	int					cury ;

	ptSrc		= lpIMC->cfCompForm.ptCurrentPos ;

	/*
	 * Lock the COMPOSITIONSTRING structure.
	 */
	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (!lpCompStr)
		return ;

	/*	If there is no composition string, don't display anything.
	 */
	if ((lpCompStr->dwSize <= sizeof(COMPOSITIONSTRING)) ||
		(lpCompStr->dwCompStrLen == 0)){
		ImmUnlockIMCC (lpIMC->hCompStr) ;
		UIComp_Hide (lpUIExtra) ;
		return ;
	}

	/*	Set the rectangle for the composition string.
	 */
	if (lpIMC->cfCompForm.dwStyle & CFS_RECT){
		rcSrc	= lpIMC->cfCompForm.rcArea ;
		DEBUGPRINTF ((MYTEXT ("CompForm.dwStyle (CFS_RECT): Rect(%d, %d, %d, %d)\n"),
					  rcSrc.left, rcSrc.top, rcSrc.right, rcSrc.bottom)) ;
	}

	/*	CFS_RECT �ł����������l�������Ă���Ƃ͌���Ȃ��B(0,0,0,0) �Ƃ������������Ȓl��
	 *	�����Ă��邱�Ƃ͔��ɍl������B�傫�����Ԉ���Ă��� (�[���ȉ�) �Ȃ�A���̐���
	 *	�͖�������B
	 */
	if (! (lpIMC->cfCompForm.dwStyle & CFS_RECT) || 
		(rcSrc.right  - rcSrc.left) <= 0 ||
		(rcSrc.bottom - rcSrc.top)  <= 0) {
		DEBUGPRINTF ((TEXT("TargetWindow visible = %d\n"), IsWindowVisible (lpIMC->hWnd))) ;
#if 0
		if (IsWindowVisible (lpIMC->hWnd)) {
			GetClientRect (lpIMC->hWnd, (LPRECT)&rcSrc) ;
		} else {
			if (IsWindow (lpUIExtra->uiDefComp.hWnd)){
				ShowWindow (lpUIExtra->uiDefComp.hWnd, SW_HIDE) ;
				lpUIExtra->uiDefComp.bShow	= FALSE ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
			return ;
		}
#else
		GetClientRect (lpIMC->hWnd, (LPRECT)&rcSrc) ;
#endif
	}
	
	ClientToScreen (lpIMC->hWnd, &ptSrc) ;
	ClientToScreen (lpIMC->hWnd, (LPPOINT)&rcSrc.left) ;
	ClientToScreen (lpIMC->hWnd, (LPPOINT)&rcSrc.right) ;
	DEBUGPRINTF ((TEXT("ptSrc(%d, %d), rcSrc(%d, %d, %d, %d)\n"), ptSrc.x, ptSrc.y, rcSrc.left, rcSrc.top, rcSrc.right, rcSrc.bottom)) ;

	/*
	 * Check the start position.
	 */
	if (!PtInRect ((LPRECT)&rcSrc, ptSrc)){
		DEBUGPRINTF ((TEXT("Point(%d, %d) not in Rect(%d, %d, %d, %d)\n"), ptSrc.x, ptSrc.y, rcSrc.left, rcSrc.top, rcSrc.right, rcSrc.bottom)) ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
		return ;
	}

	/*
	 * Hide the default composition window.
	 */
	if (IsWindow (lpUIExtra->uiDefComp.hWnd)){
		ShowWindow (lpUIExtra->uiDefComp.hWnd, SW_HIDE) ;
		lpUIExtra->uiDefComp.bShow	= FALSE ;
	}
	if (!lpUIExtra->bVertical){
		UIComp_moveHorz (hUIWnd, lpUIExtra, lpIMC, lpCompStr, &rcSrc, &ptSrc) ;
	} else  {
		UIComp_moveVert (hUIWnd, lpUIExtra, lpIMC, lpCompStr, &rcSrc, &ptSrc) ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return ;
}

void	PASCAL
UIComp_moveHorz (
	HWND					hUIWnd,
	LPUIEXTRA				lpUIExtra,
	LPINPUTCONTEXT			lpIMC,
	LPCOMPOSITIONSTRING	lpCompStr,
	RECT*					pRcSrc,
	POINT*					pPtSrc)
{
	LPMYSTR	lpt ;
	LPMYSTR	lpstr ;
	HDC		hDC ;
	HFONT		hFont		= (HFONT)NULL ;
	HFONT		hOldFont 	= (HFONT)NULL ;
	RECT		oldrc ;
	RECT		irc ;
	SIZE		sz ;
	SIZE		isz ;
	int	 		i, num, numT, dx, curx, cury, iLength, iPosition, iPrevCursor ;
	int			iCursor, iDeltaPoint ;
	BOOL		fNeedNext, fNewline, fCursorMove ;

	lpt 		= GETLPCOMPSTR (lpCompStr) ;
	lpstr		= lpt ;
	iLength		= lpCompStr->dwCompStrLen ;
	iDeltaPoint	= lpCompStr->dwDeltaStart ;
	iCursor		= lpCompStr->dwCursorPos ;
	fNeedNext	= FALSE ;
	iPosition	= 0 ;

	dx			= pRcSrc->right - pPtSrc->x ;
	curx		= pPtSrc->x ;
	cury		= pPtSrc->y ;

	/*
	 * Set the composition string to each composition window.
	 * The composition windows that are given the compostion string
	 * will be moved and shown.
	 */
	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (!IsWindow (lpUIExtra->uiComp [i].hWnd))
			continue ;
		iPrevCursor	= (int)GetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_PREVCURSOR) ;
		fCursorMove	= (iPrevCursor != iCursor && (((LPMYCOMPSTR)lpCompStr)->dwUpdateFlag & SKKUI_UPDATE_CURSOR)) ;

		hDC	= GetDC (lpUIExtra->uiComp [i].hWnd) ;

		if (hFont = (HFONT)GetWindowLongPtr (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_FONT))
			hOldFont = SelectObject (hDC, hFont) ;

		sz.cy	= 0 ;
		oldrc	= lpUIExtra->uiComp [i].rc ;

		num		= NumCharInDX (hDC, lpt, iLength, dx, &fNewline) ;
		DEBUGPRINTF ((MYTEXT ("UIComp_moveHorz (i:%d, num:%d, len:%d, dx:%d, newline:%d, point(%d, %d), cur:%d\n"), i, num, iLength, dx, fNewline, curx, cury, iCursor)) ;
		if (num > 0){
			numT	= num ;
			if (fNewline){
				/* DOS ���s�R�[�h�� 0x0D 0x0A �Ȃ̂ŁA2 �������J�E���g�����炷�B*/
				numT		-= 2 ;
				fNeedNext	= TRUE ;
			} else {
				fNeedNext	= FALSE ;
			}
			if (numT > 0){
				/* ���s�����ł͂Ȃ����炩�̕������\�������ꍇ�B*/
				MyGetTextExtentPoint (hDC, lpt, numT, &sz) ;
			} else {
				/* ���s�����̍s�������ꍇ�B*/
				MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
				sz.cx		= UI_CURSORWIDTH ;
				numT		= 0 ;
			}
			lpUIExtra->uiComp[i].rc.left	= curx ;
			lpUIExtra->uiComp[i].rc.top	 	= cury ;
			lpUIExtra->uiComp[i].rc.right   = sz.cx ;
			lpUIExtra->uiComp[i].rc.bottom  = sz.cy ;
			SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_COMPSTARTSTR, (LONG)(lpt - lpstr)) ;
			SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_COMPSTARTNUM, (LONG)numT) ;
			MoveWindow (lpUIExtra->uiComp [i].hWnd, curx, cury, sz.cx, sz.cy, TRUE) ;
			ShowWindow (lpUIExtra->uiComp [i].hWnd, SW_SHOWNOACTIVATE) ;
			lpUIExtra->uiComp [i].bShow		= TRUE ;
			DEBUGPRINTF ((MYTEXT ("UIComp_moveHorz (num:%d, Point(%d, %d), Size(%d, %d))\n"), i, curx, cury, sz.cx, sz.cy)) ;

			/*	�X�V�̈���v�Z����B
			 */
			irc.top		= 0 ;
			irc.bottom	= sz.cy ;
			if (iDeltaPoint <= iPosition){
				irc.left	= 0 ;
				irc.right	= sz.cx ;
			} else if (iDeltaPoint <= (iPosition + num)){
				MyGetTextExtentPoint (hDC, lpt, iDeltaPoint - iPosition, &isz) ;
				irc.left	= isz.cx ;
				irc.right	= sz.cx ;
			} else {
				irc.left	= irc.right	= 0 ;
			}
			if (fCursorMove){
				RECT	rc ;

				if (iPosition <= iPrevCursor && iPrevCursor <= (iPosition + num)) {
					MyGetTextExtentPoint (hDC, lpt, iPrevCursor - iPosition, &isz) ;
					if (iPrevCursor == (iPosition + num)) {
						rc.left		= isz.cx - UI_CURSORWIDTH ;
						rc.right	= isz.cx ;
					} else {
						rc.left		= isz.cx ;
						rc.right	= isz.cx + UI_CURSORWIDTH ;
					}
					rc.top		= 0 ;
					rc.bottom	= sz.cy ;
					AddRect (&irc, &rc) ;
				}
				if (iPosition <= iCursor && iCursor <= (iPosition + num)) {
					MyGetTextExtentPoint (hDC, lpt, iCursor - iPosition, &isz) ;
					if (iCursor == (iPosition + num)) {
						rc.left		= isz.cx - UI_CURSORWIDTH ;
						rc.right	= isz.cx ;
					} else {
						rc.left		= isz.cx ;
						rc.right	= isz.cx + UI_CURSORWIDTH ;
					}
					rc.top		= 0 ;
					rc.bottom	= sz.cy ;
					AddRect (&irc, &rc) ;
				}
			}
			DEBUGPRINTF ((MYTEXT ("Delta = %d, iPrevCursor = %d, iCursor = %d, iPosition = %d, RECT (%d, %d, %d, %d)"), iDeltaPoint, iPrevCursor, iCursor, iPosition, irc.left, irc.top, irc.right, irc.bottom)) ;
			if (IsValidRect (&irc))
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, &irc, FALSE) ;
			lpt			+= num ;
			iLength 	-= num ;
		} else {
			MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
			if (fNeedNext && (int)lpCompStr->dwCompStrLen == iCursor){
				lpUIExtra->uiComp [i].rc.left	= curx ;
				lpUIExtra->uiComp [i].rc.top 	= cury ;
				lpUIExtra->uiComp [i].rc.right	= UI_CURSORWIDTH ;
				lpUIExtra->uiComp [i].rc.bottom	= sz.cy ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTSTR, (LONG)lpCompStr->dwCompStrLen) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTNUM, (LONG)0L) ;
				MoveWindow (lpUIExtra->uiComp[i].hWnd, curx, cury, UI_CURSORWIDTH, sz.cy, TRUE) ;
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_SHOWNOACTIVATE) ;
				lpUIExtra->uiComp [i].bShow		= TRUE ;
				fNeedNext						= FALSE ;
				DEBUGPRINTF ((TEXT ("[1]Mu... Invalidate Entire Window?\n"))) ;
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, NULL, FALSE) ;
			} else {
				lpUIExtra->uiComp[i].rc.left	= 0 ;
				lpUIExtra->uiComp[i].rc.top	 	= 0 ;
				lpUIExtra->uiComp[i].rc.right   = 0 ;
				lpUIExtra->uiComp[i].rc.bottom  = 0 ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTSTR, (LONG)0L) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTNUM, (LONG)0L) ;
				ShowWindow (lpUIExtra->uiComp [i].hWnd, SW_HIDE) ;
				lpUIExtra->uiComp[i].bShow		= FALSE ;
			}
			sz.cx	= 0 ;
		}
		dx		= pRcSrc->right - pRcSrc->left ;
		curx	= pRcSrc->left ;
		cury	+= sz.cy ;

		if (hOldFont)
			SelectObject (hDC, hOldFont) ;
		ReleaseDC (lpUIExtra->uiComp [i].hWnd, hDC) ;
		SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_PREVCURSOR, (LONG)iCursor) ;
		iPosition	+= num ;
	}
	return ;
}

void	PASCAL
UIComp_moveVert (
	HWND					hUIWnd,
	LPUIEXTRA				lpUIExtra,
	LPINPUTCONTEXT			lpIMC,
	LPCOMPOSITIONSTRING	lpCompStr,
	RECT*					pRcSrc,
	POINT*					pPtSrc)
{
	LPMYSTR	lpt ;
	LPMYSTR	lpstr ;
	HDC		hDC ;
	HFONT		hFont		= NULL ;
	HFONT		hOldFont 	= NULL ;
	RECT		oldrc ;
	RECT		irc ;
	SIZE		sz ;
	SIZE		isz ;
	int	 		i, num, numT, dy, curx, cury ;
	LONG		iCursor, iDeltaPoint, iLength, iPosition, iPrevCursor ;
	BOOL		fNeedNext, fNewline, fCursorMove ;

	lpt 		= GETLPCOMPSTR (lpCompStr) ;
	lpstr		= lpt ;
	iLength		= lpCompStr->dwCompStrLen ;
	iDeltaPoint	= lpCompStr->dwDeltaStart ;
	iCursor		= lpCompStr->dwCursorPos ;

	dy 			= pRcSrc->bottom - pPtSrc->y ;
	curx 		= pPtSrc->x ;
	cury 		= pPtSrc->y ;
	iPosition	= 0 ;

	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (!IsWindow(lpUIExtra->uiComp[i].hWnd))
			continue ;

		iPrevCursor	= GetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_PREVCURSOR) ;
		fCursorMove	= (iPrevCursor != iCursor && (((LPMYCOMPSTR)lpCompStr)->dwUpdateFlag & SKKUI_UPDATE_CURSOR)) ;

		hDC = GetDC (lpUIExtra->uiComp [i].hWnd) ;

		if (hFont = (HFONT)GetWindowLongPtr (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_FONT))
			hOldFont = SelectObject (hDC, hFont) ;

		sz.cy	= 0 ;
		num		= NumCharInDY (hDC, lpt, iLength, dy, &fNewline) ;
		if (num){
			numT	= num ;
			if (fNewline){
				numT		-= 2 ;
				fNeedNext	= TRUE ;
			} else {
				fNeedNext	= FALSE ;
			}
			if (numT > 0){
				MyGetTextExtentPoint (hDC, lpt, num, &sz) ;
			} else {
				MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
				sz.cx	= UI_CURSORWIDTH ;
				numT	= 0 ;
			}
			lpUIExtra->uiComp[i].rc.left	= curx - sz.cy ;
			lpUIExtra->uiComp[i].rc.top		= cury ;
			lpUIExtra->uiComp[i].rc.right	= sz.cy ;
			lpUIExtra->uiComp[i].rc.bottom	= sz.cx ;
			SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTSTR, (LONG)(lpt - lpstr));
			SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTNUM, (LONG)numT) ;
			MoveWindow (lpUIExtra->uiComp[i].hWnd, curx - sz.cy, cury, sz.cy, sz.cx, TRUE) ;
			ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_SHOWNOACTIVATE) ;
			lpUIExtra->uiComp[i].bShow		= TRUE ;

			/*
			 *	�X�V�̈���v�Z����B
			 */
			irc.left	= 0 ;
			irc.right	= sz.cy ;
			irc.top		= sz.cx ;
			irc.bottom	= 0 ;
			if (iDeltaPoint <= iPosition){
				irc.top		= 0 ;
				irc.bottom	= sz.cx ;
			} else if (iDeltaPoint <= (iPosition + num)){
				MyGetTextExtentPoint (hDC, lpt, iDeltaPoint - iPosition, &isz) ;
				irc.top		= isz.cx ;
				irc.bottom	= sz.cx ;
			}
			if (fCursorMove){
				if (iPosition <= iPrevCursor && iPrevCursor <= (iPosition + num)){
					MyGetTextExtentPoint (hDC, lpt, iPrevCursor - iPosition, &isz) ;
					if (isz.cx < irc.top)
						irc.top	= isz.cx ;
					if (irc.bottom < (isz.cx + UI_CURSORWIDTH))
						irc.bottom	= isz.cx + UI_CURSORWIDTH ;
				}
				if (iPosition <= iCursor && iCursor <= (iPosition + num)){
					MyGetTextExtentPoint (hDC, lpt, iCursor - iPosition, &isz) ;
					if (isz.cx < irc.top)
						irc.top	= isz.cx ;
					if (irc.bottom < (isz.cx + UI_CURSORWIDTH))
						irc.bottom	= isz.cx + UI_CURSORWIDTH ;
				}
			}
			if (irc.top < irc.bottom)
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, &irc, FALSE) ;

			lpt		+= num ;
			iLength	-= num ;
		} else {
			MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
			sz.cx	= 1 ;
			if (fNeedNext && (int)lpCompStr->dwCompStrLen == iCursor){
				lpUIExtra->uiComp[i].rc.left	= curx - sz.cy ;
				lpUIExtra->uiComp[i].rc.top	 	= cury ;
				lpUIExtra->uiComp[i].rc.right   = sz.cy ;
				lpUIExtra->uiComp[i].rc.bottom  = sz.cx ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTSTR, (LONG)lpCompStr->dwCompStrLen) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTNUM, (LONG)0L) ;
				MoveWindow (lpUIExtra->uiComp[i].hWnd, curx - sz.cy, cury, sz.cy, sz.cx, TRUE) ;
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_SHOWNOACTIVATE) ;
				lpUIExtra->uiComp[i].bShow		= TRUE ;
				fNeedNext						= FALSE ;
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, NULL, FALSE) ;
			} else {
				lpUIExtra->uiComp[i].rc.left	= 0 ;
				lpUIExtra->uiComp[i].rc.top		= 0 ;
				lpUIExtra->uiComp[i].rc.right   = 0 ;
				lpUIExtra->uiComp[i].rc.bottom	= 0 ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTSTR, (LONG)0L) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_UICOMP_COMPSTARTNUM, (LONG)0L) ;
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_HIDE) ;
				lpUIExtra->uiComp[i].bShow		= FALSE ;
			}
			sz.cx	= 0 ;
		}

		dy		= pRcSrc->bottom - pRcSrc->top ;
		cury	= pRcSrc->top ;
		curx	-= sz.cy ;

		if (hOldFont)
			SelectObject (hDC, hOldFont) ;
		ReleaseDC (lpUIExtra->uiComp [i].hWnd, hDC) ;
		SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_UICOMP_PREVCURSOR, (LONG)iCursor) ;
		iPosition	+= num ;
	}
	return ;
}

void	PASCAL
UIComp_moveDefault (
	HWND				hUIWnd,
	LPUIEXTRA			lpUIExtra,
	LPINPUTCONTEXT		lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;
	HDC					hDC ;
	LPMYSTR				lpstr ;
	RECT				rc ;
	SIZE				sz ;
	int					width, height ;
	int					i, nstr ;

	DEBUGPRINTFEX (99, (MYTEXT ("UIComp_moveDefault (hwnd:%x)\n"), hUIWnd)) ;

	/*
	 * When the style is DEFAULT, show the default composition window.
	 */
	width	= 0 ;
	height	= 0 ;
	nstr	= 0 ;
	if (IsWindow (lpUIExtra->uiDefComp.hWnd)){
		for (i = 0 ; i < MAXCOMPWND ; i++){
			if (IsWindow (lpUIExtra->uiComp[i].hWnd)){
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_HIDE) ;
				lpUIExtra->uiComp[i].bShow	= FALSE;
			}
		}
		hDC			= GetDC (lpUIExtra->uiDefComp.hWnd) ;
		lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpCompStr){
			if ((lpCompStr->dwSize > sizeof (COMPOSITIONSTRING)) &&
				(lpCompStr->dwCompStrLen > 0)){
				lpstr	= GETLPCOMPSTR(lpCompStr) ;
				nstr	= lpCompStr->dwCompStrLen ;
				MyGetTextExtentPoint (hDC, lpstr, nstr, &sz) ;
				width	= sz.cx ;
				height	= sz.cy ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ReleaseDC (lpUIExtra->uiDefComp.hWnd, hDC) ;
		
		GetWindowRect (lpUIExtra->uiDefComp.hWnd, &rc) ;
		lpUIExtra->uiDefComp.pt.x	= rc.left ;
		lpUIExtra->uiDefComp.pt.y	= rc.top ;
		MoveWindow (lpUIExtra->uiDefComp.hWnd,
					rc.left,
					rc.top,
					width  + 2 * GetSystemMetrics (SM_CXEDGE),
					height + 2 * GetSystemMetrics (SM_CYEDGE),
					TRUE) ;

		DEBUGPRINTFEX (99, (MYTEXT ("UIComp_moveDefault (%d,%d,%d,%d\n"), rc.left, rc.top, width, height)) ;

		if (width > 0 && height > 0){
			ShowWindow (lpUIExtra->uiDefComp.hWnd, SW_SHOWNOACTIVATE) ;
			lpUIExtra->uiDefComp.bShow	= TRUE ;
			InvalidateRect (lpUIExtra->uiDefComp.hWnd, NULL, FALSE) ;
		}
		SetWindowLong (lpUIExtra->uiDefComp.hWnd, FIGWL_UICOMP_COMPSTARTSTR, 0L) ;
		SetWindowLong (lpUIExtra->uiDefComp.hWnd, FIGWL_UICOMP_COMPSTARTNUM, (LONG)nstr) ;
	}
	return ;
}

void	PASCAL
UIComp_paint (
	HWND					hCompWnd,
	HDC					hDC,
	HFONT					hFont,
	LPINPUTCONTEXT			lpIMC,
	LPCOMPOSITIONSTRING	lpCompStr)
{
	LONG		lstart ;
	LONG		num ;
	lstart		= (LONG)GetWindowLong (hCompWnd, FIGWL_UICOMP_COMPSTARTSTR) ;
	num			= (LONG)GetWindowLong (hCompWnd, FIGWL_UICOMP_COMPSTARTNUM) ;
	UIComp_paintSub (hCompWnd, hDC, hFont, lpIMC, lpCompStr, lstart, num) ;
	return ;
}

void	PASCAL
UIComp_paintSub (
	HWND					hCompWnd,
	HDC					hDC,
	HFONT					hFont,
	LPINPUTCONTEXT			lpIMC,
	LPCOMPOSITIONSTRING	lpCompStr,
	LONG					lstart,
	LONG					num)
{
	LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR)lpCompStr ;
	LPMYSTR		lpstr ;
	LPBYTE			lpattr ;
	BOOL			fVert = FALSE, fCurExist ;
	int			iCursorPos ;
	HDC			hPDC ;
	long			lCursor, lTotalLen ;
	RECT					rc ;

	if (lpCompStr->dwCompStrLen <= 0)
		return ;

	DEBUGPRINTFEX (99, (MYTEXT ("UIComp_paintSub (hwnd:%x, start:%d, num:%d)\n"), hCompWnd, lstart, num)) ;

#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	if (hFont)
		fVert = (lpIMC->lfFont.W.lfEscapement == 2700) ;
#else
	if (hFont)
		fVert = (lpIMC->lfFont.A.lfEscapement == 2700) ;
#endif

	SetBkMode (hDC, TRANSPARENT) ;

	lpstr		= GETLPCOMPSTR (lpCompStr) ;
	lpattr		= GETLPCOMPATTR (lpCompStr) ;
	lCursor		= (LONG)lpCompStr->dwCursorPos ;
	lTotalLen	= (LONG)lpCompStr->dwCompStrLen ;
	fCurExist	= ! ImeDoc_IsStatusActivep (&lpMyCompStr->_Doc) ;

	if (lpIMC->cfCompForm.dwStyle){
		/*	�eWindow �̔w�i�F�����o���B
		 *	�eWindow �̔w�i�F = Composition Window �̔w�i�F�B
		 */
		hPDC = GetDC (GetParent (hCompWnd)) ;
		SetBkColor (hDC, GetBkColor(hPDC)) ;
		SetBkMode (hDC, OPAQUE) ;

		if (!num &&
			(DWORD)lstart == lpCompStr->dwCursorPos &&
			fCurExist) {
			GetClientRect (hCompWnd, &rc) ;
			MoveToEx (hDC, rc.left, rc.top, NULL) ;
			LineTo   (hDC, rc.left, rc.bottom) ;
		} else {
			if (!num || ((lstart + num) > lTotalLen)) {
				ReleaseDC (GetParent (hCompWnd), hPDC) ;
				return ;
			}
			lpstr		+= lstart ;
			lpattr		+= lstart ;
			if (fCurExist &&
				(lCursor < (lstart + num) || (lstart + num) == lTotalLen)) {
				iCursorPos	= lpCompStr->dwCursorPos - lstart ;
			} else {
				iCursorPos	= -1 ;
			}
			UIComp_drawTextOneLine (hCompWnd, hDC, lpstr, lpattr, num, iCursorPos, fVert) ;
		}
		ReleaseDC (GetParent (hCompWnd), hPDC) ;
	} else {
		/*	�ށA�����ɗ������� default window �`�悩�H */
		SetBkMode  (hDC, OPAQUE) ;
		iCursorPos	= (fCurExist)? lpCompStr->dwCursorPos : -1 ;
		UIComp_drawTextOneLine (hCompWnd, hDC, lpstr, lpattr, num, iCursorPos, fVert) ;
	}

	/*	��щz�����̂Ȃ�[���N���A���Ă����B���̓��삪�������̂���
	 *	������Ȃ����A�c���Ă���Ƃ܂������ƂɂȂ邩������Ȃ��Ǝv����
	 *	�̂ŁB*/
	return ;
}

/*
 *	�e�L�X�g����s�\������֐��B
 *(����)
 *	hCompWnd		�e�L�X�g��\������ Window �� Handle
 *	hDC				hCompWnd �� Device Context Handle
 */
void	PASCAL
UIComp_drawTextOneLine (
	HWND		hCompWnd,
	HDC		hDC,
	LPMYSTR	lpstr,
	LPBYTE		lpattr,
	int		num, 
	int		iCursorPos,
	BOOL		fVert)
{
	LPMYSTR 			lpStart	;
	LPMYSTR 			lpEnd ;
	COLORREF			colForeMihenkan, colBackMihenkan ;
	COLORREF			colForeHenkan, colBackHenkan ;
	COLORREF					colLineMihenkan, colLineHenkan ;
	HBRUSH						hbrMihenkan, hbrHenkan ;
	HBITMAP						hbmLineMihenkan, hbmLineHenkan ;
	int							nWidthMihenkan, nWidthHenkan ;
	const MYCOLORFACESET*		pColorFaceSet ;
	const MYCOLORFACESET*		pColor ;
	COLORREF			colTextBack, colBkBack ;
	int				x,y ;
	int				nLineX, nLineY, nLineWidth, nLineHeight ;
	RECT						rc ;
	int				cnt ;
	BYTE				bAttr ;
	SIZE						sz ;
	RECT						invRect ;

	if (num <= 0)
		return ;

	lpStart				= lpstr ;
	lpEnd				= lpstr + num - 1 ;

	/*	�\���F�̐ݒ�B
	 */
	pColorFaceSet		= skkime_GetColorFaceSet () ;
	pColor				= pColorFaceSet + MYCOLORFACE_INDEX_MIHENKANMOJIRETSU ;
	colForeMihenkan		= GetImeColor (hCompWnd, pColor->m_nTextColor) ;
	colBackMihenkan		= GetImeColor (hCompWnd, pColor->m_nBackColor) ;
	hbrMihenkan			= GetImeLineBrush (hCompWnd, pColor->m_nUnderLineColor, pColor->m_nUnderLineType, &colLineMihenkan, &hbmLineMihenkan, &nWidthMihenkan) ;
	pColor				= pColorFaceSet + MYCOLORFACE_INDEX_HENKANMOJIRETSU ;
	colForeHenkan		= GetImeColor (hCompWnd, pColor->m_nTextColor) ;
	colBackHenkan		= GetImeColor (hCompWnd, pColor->m_nBackColor) ;
	hbrHenkan			= GetImeLineBrush (hCompWnd, pColor->m_nUnderLineColor, pColor->m_nUnderLineType, &colLineHenkan, &hbmLineHenkan, &nWidthHenkan) ;

	/*
	 *	�\���̈�̑傫���𓾂�B
	 */
	GetClientRect (hCompWnd, &rc) ;

	if (!fVert){
		/*
		 *	�����̏ꍇ�̏����B
		 *-----
		 *	�����̏ꍇ(ESCAPEMENT==0)�̏ꍇ�ɂ́A�����͍�����E�ցA�ォ�牺��
		 *	�Ɨ����B���̂��߂ɁAWindow �̍���[���珑���o���Ȃ���΂Ȃ�Ȃ��B
		 */
		x = 0 ;
		y = 0 ;
	} else {
		/*
		 *	�c�����̏ꍇ�̏���
		 *-----
		 *	�c�����̏ꍇ(ESCAPEMENT==2700)�̏ꍇ�ɂ́A�����͏ォ�牺�ցA�E���獶��
		 *	�Ɨ����B���̂��߂ɁAWindow �̉E��[���珑���o���Ȃ���΂Ȃ�Ȃ��B
		 */
		x = rc.right ;
		y = 0 ;
	}

	while (lpstr <= lpEnd){
		cnt		= 0 ;
		bAttr	= *lpattr ;
		while ((bAttr == *lpattr) && (cnt < num)) {
			lpattr		++ ;
			cnt			++ ;
		}
		switch (bAttr){
		case ATTR_TARGET_CONVERTED:
			colTextBack	= SetTextColor (hDC, colForeHenkan) ;
			colBkBack	= SetBkColor   (hDC, colBackHenkan) ;
			MyTextOut (hDC, x, y, lpstr, cnt) ;

			/*	�����������K�v������ꍇ�̏����B*/
			if (nWidthHenkan > 0 && hbrHenkan != NULL) {
				HBRUSH	hOldBrush ;

				MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
				SetTextColor (hDC, colLineHenkan) ;
				if (!fVert){
					nLineX			= x ;
					nLineY			= y + sz.cy - nWidthHenkan ;
					nLineWidth		= sz.cx ;
					nLineHeight		= nWidthHenkan ;
				} else {
					nLineX			= x + sz.cy - nWidthHenkan ;
					nLineY			= y ;
					nLineWidth		= nWidthHenkan ;
					nLineHeight		= sz.cx ;
				}
				hOldBrush	= SelectObject (hDC, hbrHenkan) ;
				PatBlt (hDC, nLineX, nLineY, nLineWidth, nLineHeight, PATCOPY) ;
				(void) SelectObject (hDC, hOldBrush) ;
			}
			(void) SetTextColor (hDC, colTextBack) ;
			(void) SetBkColor   (hDC, colBkBack) ;
			break ;

		case ATTR_INPUT:
		case ATTR_TARGET_NOTCONVERTED:
			colTextBack	= SetTextColor (hDC, colForeMihenkan) ;
			colBkBack	= SetBkColor   (hDC, colBackMihenkan) ;
			MyTextOut (hDC, x, y, lpstr, cnt) ;
			/*	�����������K�v������ꍇ�̏����B*/
			if (nWidthMihenkan > 0 && hbrMihenkan != NULL) {
				HBRUSH	hOldBrush ;

				MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
				SetTextColor (hDC, colLineMihenkan) ;
				if (!fVert){
					nLineX			= x ;
					nLineY			= y + sz.cy - nWidthMihenkan ;
					nLineWidth		= sz.cx ;
					nLineHeight		= nWidthMihenkan ;
				} else {
					nLineX			= x + sz.cy - nWidthMihenkan ;
					nLineY			= y ;
					nLineWidth		= nWidthMihenkan ;
					nLineHeight		= sz.cx ;
				}
				hOldBrush	= SelectObject (hDC, hbrMihenkan) ;
				PatBlt (hDC, nLineX, nLineY, nLineWidth, nLineHeight, PATCOPY) ;
				(void) SelectObject (hDC, hOldBrush) ;
			}
			(void) SetTextColor (hDC, colTextBack) ;
			(void) SetBkColor   (hDC, colBkBack) ;
			break ;

		case ATTR_CONVERTED:
		default:
			MyTextOut (hDC, x, y, lpstr, cnt) ;
			break ;
		}
		if (0 <= iCursorPos && iCursorPos < cnt){
			if (iCursorPos > 0){
				MyGetTextExtentPoint (hDC, lpstr, iCursorPos, &sz) ;
				/*
				 *	�������̏ꍇ�ɂ́AGetTextExtentPoint32 �̕Ԃ��l sz ��
				 *	sz.cx	�\���̈�̉����B
				 *	sz.cy	�\���̈�̏c���B
				 *	���������邪�A�c�����̏ꍇ�ɂ́c
				 *	sz.cx	�\���̈�̏c���B(�������A�E�ɂł͂Ȃ����ɐ�߂�)
				 *	sz.cy	�\���̈�̉����B
				 *	�� cx, cy �̉��߂��t�ɂȂ�B����́AlfEscapement == 2700
				 *	�̉e���ł���B
				 */
				if (!fVert){
					invRect.left	= x + sz.cx ;
					invRect.right	= x + sz.cx + UI_CURSORWIDTH ;
					invRect.top		= y ;
					invRect.bottom	= y + sz.cy ;
				} else {
					invRect.left	= x ;
					invRect.right	= x - sz.cy ;
					invRect.top		= y + sz.cx ;
					invRect.bottom	= y + sz.cx + UI_CURSORWIDTH ;
				}
				MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
			} else {
				MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
				if (!fVert){
					invRect.left	= x ;
					invRect.right	= x + UI_CURSORWIDTH ;
					invRect.top		= y ;
					invRect.bottom	= y + sz.cy ;
				} else {
					invRect.left	= x ;
					invRect.right	= x - sz.cy ;
					invRect.top		= y ;
					invRect.bottom	= y + UI_CURSORWIDTH ;
				}
			}
			DEBUGPRINTF ((TEXT ("UICOMP:DrawCursor(a) (%d, %d, %d, %d)\n"),
						  invRect.left, invRect.top, invRect.right, invRect.bottom)) ;
			InvertRect (hDC, &invRect) ;
		} else {
			MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
		}
		lpstr		+= cnt ;
		iCursorPos	-= cnt ;
		num			-= cnt ;
		if (!fVert){
			x += sz.cx ;
		} else {
			y += sz.cx ;
		}
	}
	/* �J�[�\����\������ׂ����ۂ��B*/
	if (iCursorPos == 0){
		if (!fVert){
			invRect.left	= x - UI_CURSORWIDTH ;
			invRect.right	= x ;
			invRect.top		= y ;
			invRect.bottom	= y + sz.cy ;
		} else {
			invRect.left	= x ;
			invRect.right	= x - sz.cy ;
			invRect.top		= y - UI_CURSORWIDTH ;
			invRect.bottom	= y ;
		}
		DEBUGPRINTF ((TEXT ("UICOMP:DrawCursor(b) (%d, %d, %d, %d)\n"),
					  invRect.left, invRect.top, invRect.right, invRect.bottom)) ;
		InvertRect (hDC, &invRect) ;
	}

	/*	�s�v�ɂȂ����I�u�W�F�N�g���������B*/
	if (hbrMihenkan) 
		DeleteObject (hbrMihenkan) ;
	if (hbmLineMihenkan)
		DeleteObject (hbmLineMihenkan) ;
	if (hbrHenkan)
		DeleteObject (hbrHenkan) ;
	if (hbmLineHenkan)
		DeleteObject (hbmLineHenkan) ;
	return ;
}

/*
 *	Window �ɕ\���\�ȕ����̐������肷��֐��B
 *(����)
 *	hDC			Handle Device Context
 *	lp			��ʂɕ\��������������
 *	iLength		������̒���
 *	dx			Window �̉����B
 *(���l)
 *	���s�Ɉ˂炸��ʂŐ܂�Ԃ����s�����ɂ́Abackslash ��\�����������H
 */
int	PASCAL
NumCharInDX (
	HDC		hDC,
	LPMYSTR	lp,
	int		iLength,
	int		dx,
	BOOL FAR*	lpfNewline)
{
	SIZE		sz;
	BOOL		fNewline ;
	int width	= 0 ;
	int num		= 0 ;
	int numT	= 0 ;

	if (!*lp){
		if (lpfNewline)
			*lpfNewline	= FALSE ;
		return 0 ;
	}
	fNewline	= FALSE ;
	while ((width < dx) && numT < iLength && *(lp + numT)){
		/* DOS ���s�R�[�h�����t�����ꍇ�̏����B*/
		if ((numT + 1) < iLength &&
			(*(lp + numT) == MYTEXT ('\n') && *(lp + numT + 1) == MYTEXT ('\r')) ||
			(*(lp + numT) == MYTEXT ('\r') && *(lp + numT + 1) == MYTEXT ('\n'))){
			fNewline	= TRUE ;
			numT		+= 2 ;
			break ;
		}
		num = numT ;

		/*
		 *	Unicode �̏ꍇ�ɂ� LeadByte ���l���Ȃ��ėǂ����c ShiftJIS
		 *	�̏ꍇ�ɂ� 1 �o�C�g������ 2 �o�C�g�����ɂ���ď����𕪂��Ȃ�
		 *	�Ƃ����Ȃ��B
		 */
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		numT ++ ;
		GetTextExtentPoint32W (hDC, lp, numT, &sz) ;
#else
		if (IsDBCSLeadByte (*(lp + numT))){
			numT += 2 ;
		} else {
			numT ++ ;
		}		
		GetTextExtentPoint32 (hDC, lp, numT, &sz) ;
#endif
		width	= sz.cx ;
	}

	if (width < dx)
		num		= numT ;
	if (lpfNewline)
		*lpfNewline	= fNewline ;

	return	num ;
}

int	PASCAL
NumCharInDY (
	HDC			hDC,
	LPMYSTR		lp,
	int			iLength,
	int			dy,
	BOOL FAR*		lpfNewline)
{
	SIZE	sz ;
	BOOL	fNewline ;
	int		width = 0 ;
	int		num ;
	int 	numT = 0 ;

	if (!*lp){
		if (lpfNewline)
			*lpfNewline	= FALSE ;
		return 0 ;
	}
	fNewline	= FALSE ;

	while ((width < dy) && numT < iLength && *(lp + numT)){
		/* DOS ���s�R�[�h�����t�����ꍇ�̏����B*/
		if ((numT + 1) < iLength &&
			(*(lp + numT) == MYTEXT ('\n') && *(lp + numT + 1) == MYTEXT ('\r')) ||
			(*(lp + numT) == MYTEXT ('\r') && *(lp + numT + 1) == MYTEXT ('\n'))){
			fNewline	= TRUE ;
			numT		+= 2 ;
			break ;
		}
		num		= numT ;

#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		numT	++ ;
		GetTextExtentPoint32W (hDC, lp, numT, &sz) ;
#else
		if (IsDBCSLeadByte(*(lp + numT))){
			numT	+= 2 ;
		} else {
			numT	++ ;
		}
		GetTextExtentPoint32 (hDC, lp, numT, &sz) ;
#endif
		width	= sz.cx ;
	}
	if (width < dy)
		num		= numT ;
	if (lpfNewline)
		*lpfNewline	= fNewline ;

	return	num ;
}

void	PASCAL
AddRect (
	LPRECT	lpDest,
	LPRECT	lpSrc)
{
	/*	NOP */
	if (!IsValidRect (lpSrc))
		return ;
	if (lpDest != NULL && !IsValidRect (lpDest)) {
		*lpDest	= *lpSrc ;
		return ;
	}
	lpDest->left	= (lpSrc->left   < lpDest->left)?   lpSrc->left   : lpDest->left ;
	lpDest->top		= (lpSrc->top    < lpDest->top)?    lpSrc->top    : lpDest->top ;
	lpDest->right	= (lpSrc->right  > lpDest->right)?  lpSrc->right  : lpDest->right ;
	lpDest->bottom	= (lpSrc->bottom > lpDest->bottom)? lpSrc->bottom : lpDest->bottom ;
	return ;
}

BOOL	PASCAL
IsValidRect (
	LPRECT	pRect)
{
	return	(pRect == NULL ||
			 pRect->right  <= pRect->left ||
			 pRect->bottom <= pRect->top)? FALSE : TRUE ;
}

