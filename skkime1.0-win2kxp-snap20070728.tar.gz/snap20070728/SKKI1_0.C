/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * skki1_0.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "charset.h"
#include "resource.h"
#include "immsec.h"
#include "commctrl.h"
#include "TServerSession.h"

#if !defined (dont_use_word2000) && !defined (TARGET_WIN2K)
/*	imjp81k.dll �� module�B���ۂɂ͕ʂ� version �̂��̂����邱�Ƃ��K�v���H
 */
#define	MSIME_MODULEPATH	TEXT ("C:\\WINDOWS\\system32\\imjp81k.dll")

static	void	LoadMsImeLibrary (HINSTANCE) ;

static	HMODULE	shMSIME	= NULL ;
#endif

/*
 *	DLLEntry ()
 */
BOOL	WINAPI
DllMain (
	HINSTANCE		hInstDLL,
	DWORD			dwFunction,
	LPVOID			lpNot)
{
	DWORD	dwValue ;

	switch (dwFunction){
	case DLL_PROCESS_ATTACH:

		DEBUGPRINTFEX (99, (TEXT ("SKKIME: DLLEntry: DLL_PROCESS_ATTACH\n"))) ;
		g_hInst		= hInstDLL ;
		IMERegisterClass (g_hInst) ;
		TServerSession_ClassInit () ;

#if !defined (dont_use_word2000) && !defined (TARGET_WIN2K)
		/*	Word2000 �΍�B���炭�� Word2000 �̕��͍Z���c�[�����ˑ����Ă���ł��낤
		 *	imjp81k.dll �� load ����B
		 */
		LoadMsImeLibrary (g_hInst) ;
#endif
#if !defined (NO_TSF)
		bTSF_InitLanguageBar () ;
#endif
#if 1
		{
			INITCOMMONCONTROLSEX	icc ;
			icc.dwSize	= sizeof (icc) ;
			icc.dwICC	= ICC_BAR_CLASSES ;
			InitCommonControlsEx (&icc) ;
		}
#endif
		break ;

	case DLL_PROCESS_DETACH:
		DEBUGPRINTFEX (99, (TEXT ("SKKIME: DLLEntry: DLL_PROCESS_DETACH\n"))) ;
		UnregisterClass (g_szUIClassName,			g_hInst) ;
		UnregisterClass (g_szCompStrClassName,		g_hInst) ;
		UnregisterClass (g_szMinibufClassName,		g_hInst) ;
		UnregisterClass (g_szCandClassName,			g_hInst) ;
		UnregisterClass (g_szStatusClassName,		g_hInst) ;
		UnregisterClass (g_szCandAnnotClassName,	g_hInst) ;
#if !defined (NO_TSF)
		vTSF_UninitLanguageBar () ;
#endif
		/*	Word2000 �΍�B���� IME �̏I���܂� imjp81k.dll �̉����x��������B
		 *	�uSleep (100) �̂��܂��Ȃ��v�͓����ĂȂ��ƑʖڂȂ悤���B���̐��l��
		 *	����ŗǂ��̂� (> 100 �̕K�v�͂��邩�H) �͕s���B
		 *
		 *	�������A����� process �̏I�����x���Ȃ��Ă��܂��c�B
		 */
#if !defined (dont_use_word2000) && !defined (TARGET_WIN2K)
		if (shMSIME != NULL) {
			Sleep (100) ;
			FreeLibrary (shMSIME) ;
			shMSIME	= NULL ;
		}
#endif
		break ;

	case DLL_THREAD_ATTACH:
		DEBUGPRINTFEX (99, (TEXT ("SKKIME: DLLEntry: DLL_THREAD_ATTACH\n"))) ;
		break ;

	case DLL_THREAD_DETACH:
		DEBUGPRINTFEX (99, (TEXT ("SKKIME: DLLEntry: DLL_THREAD_DETACH\n"))) ;
		break ;
	}
	return	TRUE ;
}

#if !defined (dont_use_word2000) && !defined (TARGET_WIN2K)
/*	MSIME �� module �� LoadLibrary ����B
 */
void
LoadMsImeLibrary (HINSTANCE hInstDLL)
{
	HMODULE	hModule ;

	if (shMSIME != NULL || hInstDLL == NULL)
		return ;
	//hModule	= LoadLibraryEx (MSIME_MODULEPATH, NULL, DONT_RESOLVE_DLL_REFERENCES) ;
	hModule	= LoadLibrary (MSIME_MODULEPATH) ;
	if (hModule != NULL) 
		shMSIME	= hModule ;
	return ;
}
#endif


