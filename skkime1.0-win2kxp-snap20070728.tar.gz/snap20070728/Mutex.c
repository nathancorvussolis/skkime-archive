#include <windows.h>
#include <tchar.h>
#include "immdev.h"
#include "skki1_0.h"
#include "immsec.h"

HANDLE	PASCAL
skkimeCreateMutex (
	register LPCTSTR		pMutexName)
{
	register PSECURITY_ATTRIBUTES	psa ;
	register HANDLE					hMutex ;

	DEBUGPRINTFEX (99, (MYTEXT ("skkimeCreateMutex ()\n"))) ;

	//psa		= CreateSecurityAttributes () ;
	psa		= NULL ;
	hMutex	= CreateMutex (psa, FALSE, pMutexName) ;
	if (psa != NULL)
		FreeSecurityAttributes (psa) ;
	return	hMutex ;
}

