/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * Data.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "immdev.h"
#define _NO_EXTERN_
#include "skki1_0.h"
#include "stddef.h"
#include "resource.h"

/*========================================================================
 *	�v���Z�X���ɓƗ��ȃf�[�^�B
 *========================================================================*/
HINSTANCE   	g_hInst ;
HKL				g_hMyKL					= 0 ;

/* for Translat */
LPTRANSMSGLIST	g_lpCurTransKey			= NULL ;
UINT    		g_uNumTransKey ;
BOOL    		g_bOverTransKey			= FALSE ;

BOOL			g_bSkkImeSecure			= FALSE ;

#if defined (MIXED_UNICODE_ANSI)
/*	Mixed Unicode and Ansi */
WCHAR		g_wszUIClassName[]			= L"SKKIME1.0MUI" ;
char		g_szUIClassName[]			= "SKKIME1.0MUI" ;
char		g_szCompStrClassName[]		= "SKKIME1.0MCompStr" ;
char		g_szMinibufClassName[]		= "SKKIME1.0MMinibuf" ;
char		g_szCandClassName[]			= "SKKIME1.0MCand" ;
char		g_szCandAnnotClassName[]	= "SKKIME1.0MAnnot" ;
char		g_szStatusClassName[]		= "SKKIME1.0MStatus" ;
char		g_szGuideClassName[]		= "SKKIME1.0MGuide" ;
#else	/* defined (MIXED_UNICODE_ANSI) */
#if defined (UNICODE)
/*	UNICODE */
TCHAR		g_szUIClassName[]			= TEXT ("SKKIME1.0UUI") ;
TCHAR		g_szCompStrClassName[]		= TEXT ("SKKIME1.0UCompStr") ;
TCHAR		g_szMinibufClassName[]		= TEXT ("SKKIME1.0UMinibuf") ;
TCHAR		g_szCandClassName[]			= TEXT ("SKKIME1.0UCand") ;
TCHAR		g_szCandAnnotClassName[]	= TEXT ("SKKIME1.0UAnnot") ;
TCHAR		g_szStatusClassName[]		= TEXT ("SKKIME1.0UStatus") ;
TCHAR		g_szGuideClassName[]		= TEXT ("SKKIME1.0UGuide") ;
#else	/* defined (UNICODE) */
/*	ANSI */
char		g_szUIClassName[]			= "SKKIME1.0UI" ;
char		g_szCompStrClassName[]		= "SKKIME1.0CompStr" ;
char		g_szMinibufClassName[]		= "SKKIME1.0Minibuf" ;
char		g_g_szCandClassName[]		= "SKKIME1.0Cand" ;
char		g_szCandAnnotClassName[]	= "SKKIME1.0CandAnnot" ;
char		g_szStatusClassName[]		= "SKKIME1.0Status" ;
char		g_szGuideClassName[]		= "SKKIME1.0Guide" ;
#endif	/* defined (UNICODE) */
#endif	/* defined (MIXED_UNICODE_ANSI) */


MYGUIDELINE	g_glTable []	= {
	{GL_LEVEL_ERROR,   GL_ID_NODICTIONARY, IDS_GL_NODICTIONARY, 0},
	{GL_LEVEL_WARNING, GL_ID_TYPINGERROR,  IDS_GL_TYPINGERROR, 0},
	{GL_LEVEL_WARNING, GL_ID_PRIVATE_FIRST,IDS_GL_TESTGUIDELINESTR, IDS_GL_TESTGUIDELINEPRIVATE}
} ;

#include "common\confcommon.h"
#include "common\confdefaults.h"

#pragma data_seg(".shared")
POINT		g_ptUIStatus				= { -1, -1 } ;
#pragma data_seg()

