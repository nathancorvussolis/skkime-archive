#include "local.h"
#include "TAssocRuleP.h"

CTAssocRule*
TAssocRule_Create (
	register LPCWSTR		strState,
	register LPCWSTR		strNext,
	register LPCWSTR		strKatakana,
	register LPCWSTR		strHiragana)
{
	register CTAssocRule*	pRule ;
	register LPWSTR			wptr ;
	register int	nSize, nState, nNext, nKata, nHira ;

	nSize	= sizeof (CTAssocRule) ;
	nState	= (strState    != NULL)? lstrlenW (strState)    + 1 : 0 ;
	nNext	= (strNext     != NULL)? lstrlenW (strNext)     + 1 : 0 ;
	nKata	= (strKatakana != NULL)? lstrlenW (strKatakana) + 1 : 0 ;
	nHira	= (strHiragana != NULL)? lstrlenW (strHiragana) + 1 : 0 ;
	pRule	= MALLOC (nSize + (nState + nNext + nKata + nHira) * sizeof (WCHAR)) ;
	if (pRule == NULL)
		return	NULL ;

	wptr				= (LPWSTR)(pRule + 1) ;
	if (strState != NULL) {
		lstrcpyW (wptr, strState) ;
		pRule->_wstrState	= wptr ;
		wptr				+= nState ;
	} else {
		pRule->_wstrState	= NULL ;
	}
	if (strNext != NULL) {
		lstrcpyW (wptr, strNext) ;
		pRule->_wstrNext	= wptr ;
		wptr				+= nNext ;
	} else {
		pRule->_wstrNext	= NULL ;
	}
	if (strKatakana != NULL) {
		lstrcpyW (wptr, strKatakana) ;
		pRule->_wstrKatakana= wptr ;
		wptr				+= nKata ;
	} else {
		pRule->_wstrKatakana= NULL ;
	}
	if (strHiragana != NULL) {
		lstrcpyW (wptr, strHiragana) ;
		pRule->_wstrHiragana= wptr ;
	} else {
		pRule->_wstrHiragana= NULL ;
	}
	return	pRule ;
}

void
TAssocRule_Destroy (
	register CTAssocRule*	pRule)
{
	if (pRule != NULL)
		FREE (pRule) ;
	return ;
}

LPCWSTR
TAssocRule_GetState (
	register CTAssocRule*	pRule)
{
	ASSERT (pRule != NULL) ;
	return	pRule->_wstrState ;
}

LPCWSTR
TAssocRule_GetNext (
	register CTAssocRule*	pRule)
{
	ASSERT (pRule != NULL) ;
	return	pRule->_wstrNext ;
}

LPCWSTR
TAssocRule_GetOutput (
	register CTAssocRule*	pRule,
	register BOOL			fKatakana)
{
	ASSERT (pRule != NULL) ;
	return	(fKatakana)? pRule->_wstrKatakana : pRule->_wstrHiragana ;
}

