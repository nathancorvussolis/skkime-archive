#if !defined (ImeBuffer_h)
#define	ImeBuffer_h

#include "TMarker.h"
#include "TRecursiveEditSession.h"

#define	MAXCOMPLEN		(256)
#define	MAXPREFIXLEN	(MAXCOMPLEN)
#define	MAXBUFMARKER	(16)

struct tagCImeDoc ;
struct tagCImeBuffer ;
typedef struct tagCImeBuffer	CImeBuffer ;

CImeBuffer*	ImeBuffer_Create	(struct tagCImeDoc*) ;
BOOL		ImeBuffer_Init		(CImeBuffer*) ;
BOOL		ImeBuffer_InitEx	(CImeBuffer*, LPCWSTR, int, CTRecursiveEditSession*) ;
void		ImeBuffer_Uninit	(CImeBuffer*) ;
BOOL		ImeBuffer_Clear		(CImeBuffer*) ;

struct tagCImeDoc*	ImeBuffer_GetDocument	(CImeBuffer*) ;
BOOL		ImeBuffer_QueryFilterKeyEvent	(CImeBuffer*, WCHAR, BOOL*) ;
BOOL		ImeBuffer_QueryToggleIMEKeyEvent(CImeBuffer*, WCHAR, BOOL*) ;
BOOL		ImeBuffer_FilterKeyEvent		(CImeBuffer*) ;
LPCWSTR		ImeBuffer_GetText				(CImeBuffer*, int*) ;
int			ImeBuffer_GetCursorPosition		(CImeBuffer*) ;
int			ImeBuffer_GetReadingText		(CImeBuffer*, LPWSTR, int, int*) ;
BOOL		ImeBuffer_SetConversionMode		(CImeBuffer*, int) ;
int			ImeBuffer_GetConversionMode		(CImeBuffer*) ;
int			ImeBuffer_GetKeymap				(CImeBuffer*) ;
BOOL		ImeBuffer_QueryUpdateContext	(CImeBuffer*, int*, int*, BOOL*) ;
BOOL		ImeBuffer_UpdateContext			(CImeBuffer*) ;
BOOL		ImeBuffer_GetSelectedRegion		(CImeBuffer*, int*, int*) ;
BOOL		ImeBuffer_SetConversionString	(CImeBuffer*, LPCWSTR, int) ;
BOOL		ImeBuffer_GetConvertedRegion	(CImeBuffer*, int*, int*) ;
BOOL		ImeBuffer_IsJHenkanShowCandidateModep	(CImeBuffer*) ;
BOOL		ImeBuffer_IsJInputByCodeOrMenuModep		(CImeBuffer*) ;
BOOL		ImeBuffer_RevertText			(CImeBuffer*) ;
BOOL		ImeBuffer_CompleteText			(CImeBuffer*) ;
BOOL		ImeBuffer_IsStatusActivep		(CImeBuffer*) ;

#endif

