/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * skksubs.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "immdev.h"
#include "skki1_0.h"
#include "skkui.h"
#include "skksubs.h"
#include "resource.h"

static	void	PASCAL	skkFlushTextSub (HIMC) ;
static	BOOL			skkFilterSpecialChar (HIMC, LPINPUTCONTEXT, int) ;

BOOL	PASCAL
SKKInitPrivate (LPINPUTCONTEXT lpIMC)
{
	LPMYPRIVATE		lpMyPrivate ;
	DWORD			dwSize ;

	dwSize					= sizeof (MYPRIVATE) ;
	lpIMC->hPrivate			= ImmReSizeIMCC (lpIMC->hPrivate, dwSize) ;
	lpMyPrivate				= (LPMYPRIVATE)ImmLockIMCC (lpIMC->hPrivate) ;
	lpMyPrivate->m_dwSize	= dwSize ;
	ImmUnlockIMCC (lpIMC->hPrivate) ;
	return	TRUE ;
}

BOOL	PASCAL
SKKClearPrivate (LPINPUTCONTEXT lpIMC)
{
	return	TRUE ;
}

BOOL	PASCAL
SKKIsInitPrivate (LPINPUTCONTEXT lpIMC)
{
	LPMYPRIVATE	lpMyPrivate ;
	DWORD		dwSize ;
	BOOL		fRetvalue ;

	dwSize	= ImmGetIMCCSize (lpIMC->hPrivate) ;
	if (dwSize < sizeof (MYPRIVATE))
		return	FALSE ;
	lpMyPrivate	= (LPMYPRIVATE)ImmLockIMCC (lpIMC->hPrivate) ;
	fRetvalue	= (lpMyPrivate->m_dwSize == dwSize) ;
	ImmUnlockIMCC (lpIMC->hPrivate) ;
	return	fRetvalue ;
}

BOOL	PASCAL
SKKIsCompStr (HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPMYCOMPSTR			lpMyCompStr ;
	BOOL				fRet ;
	int					nPreedit, nStatus ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR)){
		ImmUnlockIMC (hIMC) ;
		return	FALSE ;
	}

	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	ImeDoc_GetPreeditText (&lpMyCompStr->_Doc, &nPreedit) ;
	ImeDoc_GetStatusText  (&lpMyCompStr->_Doc, &nStatus) ;
	fRet		= (nStatus > 0 || nPreedit > 0) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	ImmUnlockIMC (hIMC) ;
	return	fRet ;
}

BOOL
PASCAL	SKKIsConvertedCompStr (HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPMYCOMPSTR			lpMyCompStr ;
	BOOL				fRet	= FALSE ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR)){
		ImmUnlockIMC (hIMC) ;
		return	FALSE ;
	}
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr != NULL) {
		fRet	= ImeDoc_GetConvertedRegion (&lpMyCompStr->_Doc, NULL, NULL) ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
	ImmUnlockIMC (hIMC) ;
	return	fRet ;
}

BOOL	PASCAL
SKKSetConversionMode (
	register HIMC			hIMC,
	register DWORD			fdwConversion)
{
	register LPINPUTCONTEXT	lpIMC ;
	register LPMYCOMPSTR	lpMyCompStr ;
	register int			nMode ;
	register BOOL			f	= FALSE ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
		goto	exit_func ;

	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL)
		goto	exit_func ;

	if (fdwConversion & IME_CMODE_JAPANESE){
		if (!(fdwConversion & IME_CMODE_FULLSHAPE)){
			nMode	= IMECMODE_HANKANA ;
		} else {
			nMode	= (fdwConversion & IME_CMODE_KATAKANA)? IMECMODE_KATAKANA : IMECMODE_HIRAGANA ;
		}
	} else {
		nMode	= (fdwConversion & IME_CMODE_FULLSHAPE)? IMECMODE_ZENKAKU : IMECMODE_ASCII ;
	}
	f	= ImeDoc_SetConversionMode (&lpMyCompStr->_Doc, nMode) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
  exit_func:
	ImmUnlockIMC (hIMC) ;
	return	f ;
}

DWORD	PASCAL
SKKGetConversionMode (
	register HIMC			hIMC)
{
	DWORD			fdwConversion ;
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR		lpMyCompStr ;
	CImeDoc*		pDoc ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	0L ;

	fdwConversion	= 0L ;
	lpMyCompStr		= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		goto	exit_func ;

	pDoc	= &lpMyCompStr->_Doc ;
	switch (ImeDoc_GetConversionMode (pDoc)) {
	case	IMECMODE_HIRAGANA:
		fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_FULLSHAPE ;
		break ;
	case	IMECMODE_KATAKANA:
		fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_FULLSHAPE | IME_CMODE_KATAKANA ;
		break ;
	case	IMECMODE_ZENKAKU:
		fdwConversion	= IME_CMODE_ALPHANUMERIC | IME_CMODE_FULLSHAPE ;
		break ;
	case	IMECMODE_HANKANA:
		fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_KATAKANA ;
		break ;
	case	IMECMODE_ASCII:
		fdwConversion	= IME_CMODE_ALPHANUMERIC ;
		break ;
	default:
		fdwConversion	= 0 ;
		break ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
  exit_func:
	ImmUnlockIMC (hIMC) ;
	return	fdwConversion ;
}

BOOL	PASCAL
SKKUpdateConversionMode (
	register HIMC		hIMC)
{
	register int					nCmd ;
	register LPINPUTCONTEXT			lpIMC ;
	register LPCOMPOSITIONSTRING	lpCompStr ;
	register CImeDoc*				pDoc ;
	register BOOL					fOpen ;
	register int					nMode	= -1 ;

	nCmd	= GetConversionMode (hIMC) ;
	if (nCmd == IDM_CMODE_TO_DIRECTINPUT)
		return	TRUE ;

	fOpen	= ImmGetOpenStatus (hIMC) ;
	if (!fOpen)
		ImmSetOpenStatus (hIMC, TRUE) ;

	lpIMC 	= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL)
		return	FALSE ;

	SKKConversionStart (hIMC, lpIMC) ;
	lpCompStr		= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	pDoc			= &(((LPMYCOMPSTR)lpCompStr)->_Doc) ;
	switch (nCmd) {
	case	IDM_CMODE_TO_ASCII:
		nMode	= IMECMODE_ASCII ;
		break ;
	case	IDM_CMODE_TO_ROMANHIRA:
		nMode	= IMECMODE_HIRAGANA ;
		break ;
	case	IDM_CMODE_TO_ROMANKATA:
		nMode	= IMECMODE_KATAKANA ;
		break ;
	case	IDM_CMODE_TO_ZENEI:
		nMode	= IMECMODE_ZENKAKU ;
		break ;
	case	IDM_CMODE_TO_JISX0201KANA:
		nMode	= IMECMODE_HANKANA ;
		break ;
	default:
		break ;
	}
	if (0 <= nMode) {
		ImeDoc_SetConversionMode (pDoc, nMode) ;
		SKKUpdateComposition (hIMC, lpIMC, lpCompStr, TRUE) ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	ImmUnlockIMC (hIMC) ;
	return	(0 <= nMode) ;
}

BOOL	PASCAL
SKKNotifyChangeConversionMode (
	register HIMC			hIMC)
{
	LPINPUTCONTEXT	lpIMC ;
	DWORD			fdwConversion ;
	TRANSMSG		GnMsg ;

	fdwConversion	= SKKGetConversionMode (hIMC) ;
	lpIMC			= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	0L ;

	if (lpIMC->fdwConversion != fdwConversion){
		/*	���̃��b�Z�[�W�͒��ŕ��ĂȂ���΂Ȃ�Ȃ��B�̂ŁA
		 *	PRIVATE �ɂ���B*/
		lpIMC->fdwConversion	= fdwConversion ;
		GnMsg.message			= WM_IME_NOTIFY ;
		GnMsg.wParam			= IMN_SETCONVERSIONMODE ;
		GnMsg.lParam			= 0 ;
		GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
	}
	ImmUnlockIMC (hIMC) ;
	return	TRUE ;	
}

/*	���߂� Annotation ��ێ����Ă��邩�ǂ����𔻒肷��B
 *	Annotation �͎��̌`���� Word �̒��ɑ��݂���B
 *
 *		�P��;Annotation
 *
 *	``;'' ����ؕ����ł���B
 */
int		PASCAL
SKKHasWordAnnotation (
	register LPCMYSTR			pWord,
	register int				nWord)
{
	register LPCMYSTR	ptr ;

	if (pWord == NULL || nWord <= 0)
		return	-1 ;

	ptr	= pWord ;
	while (nWord > 0 && *ptr != MYTEXT ('\0')) {
		if (*ptr == MYTEXT (';'))
			return	(ptr - pWord) ;
		nWord	-- ;
		ptr		++ ;
	}
	return	-1 ;	/* Not found */
}

/*
BOOL	PASCAL
SKKRecursiveEditEnablep (
	register LPCOMPOSITIONSTRING	lpCompStr)
{
	register LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR) lpCompStr ;
	register BOOL			fRetval ;

	if (lpCompStr == NULL)
		return	FALSE ;
	switch (skkinput_recursive_edit) {
	case	RECURSIVE_EDIT_UICAND_IS_ENABLE:
		fRetval	= (lpMyCompStr->dwShowStyle & ISC_SHOWUICANDIDATEWINDOW) != 0 ;
		break ;
	case	RECURSIVE_EDIT_UICOMP_IS_ENABLE:
		fRetval	= (lpMyCompStr->dwShowStyle & ISC_SHOWUICOMPOSITIONWINDOW) != 0 ;
		break ;
	case	RECURSIVE_EDIT_BOTH_ENABLE:
		fRetval	= ((lpMyCompStr->dwShowStyle & ISC_SHOWUICANDIDATEWINDOW)   != 0 &&
				   (lpMyCompStr->dwShowStyle & ISC_SHOWUICOMPOSITIONWINDOW) != 0) ;
		break ;
	case	RECURSIVE_EDIT_NEVER:
		fRetval	= FALSE ;
		break ;
	default:
	case	RECURSIVE_EDIT_ALWAYS:
		fRetval	= TRUE ;
		break ;
	}
	return	fRetval ;
}
*/

BOOL
SKKSetReconvertStr	(
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC, 
	register LPCOMPOSITIONSTRING	lpCompStr,
	register LPRECONVERTSTRING		pRStr,
	register BOOL					f) 
{
	register LPMYCOMPSTR	lpMyCompStr ;
	register CImeDoc*		pDoc ;
	register LPMYSTR		pText ;
	register int			nText ;
	BOOL					fEaten, fRetval ;

	lpMyCompStr		= (LPMYCOMPSTR)lpCompStr ;
	pDoc	= &lpMyCompStr->_Doc ;
	pText	= (LPMYSTR)((LPBYTE)pRStr + pRStr->dwStrOffset + pRStr->dwCompStrOffset) ;
	nText	= pRStr->dwCompStrLen ;
	fRetval	= ImeDoc_SetConversionString (pDoc, pText, nText) ;
	SKKUpdateComposition (hIMC, lpIMC, lpCompStr, TRUE) ;
	return	fRetval ;
}

BOOL
SKKConvertString (
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC)
{
	return	skkFilterSpecialChar (hIMC, lpIMC, MYVK_CONVERT) ;
}

BOOL
SKKOpenCandidate (
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC)
{
	return	skkFilterSpecialChar (hIMC, lpIMC, MYVK_OPENCANDIDATE) ;
}

BOOL
SKKCompleteString	(
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;
	LPMYCOMPSTR			lpMyCompStr ;
	BOOL				fEaten, fRetval ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
		return	FALSE ;

	lpCompStr		= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpCompStr == NULL) 
		return	FALSE ;

	lpMyCompStr		= (LPMYCOMPSTR) lpCompStr ;
	if (lpCompStr->dwCompStrLen > 0 ||
		lpMyCompStr->_fComposing) {
		fRetval	= ImeDoc_CompleteText (&lpMyCompStr->_Doc) ;
		SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	fRetval ;
}

BOOL
SKKRevertString (
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC)
{
	LPMYCOMPSTR		lpMyCompStr ;
	BOOL			fEaten, fRetval ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
		return	FALSE ;

	lpMyCompStr		= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		return	FALSE ;

	fRetval	= ImeDoc_RevertText (&lpMyCompStr->_Doc) ;
	SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	fRetval ;
}

BOOL
SKKSelectCandidateStr (
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC,
	register int					nIndex)
{
	LPMYCOMPSTR		lpMyCompStr ;
	CImeDoc*		pDoc ;
	BOOL			fEaten ;

	lpMyCompStr		= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		return	FALSE ;

	pDoc	= &lpMyCompStr->_Doc ;
	ImeDoc_FilterKeyEvent (pDoc, MYVK_SELECTCANDIDATESTR, nIndex, NULL, &fEaten) ;
	SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	TRUE ;
}

BOOL
SKKSetCandidatePageStart (
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC,
	register int					nIndex)
{
	LPMYCOMPSTR		lpMyCompStr ;
	CImeDoc*		pDoc ;
	BOOL			fEaten ;

	lpMyCompStr		= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		return	FALSE ;

	pDoc	= &lpMyCompStr->_Doc ;
	ImeDoc_FilterKeyEvent (pDoc, MYVK_SETCANDIDATEPAGESTART, nIndex, NULL, &fEaten) ;
	SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	TRUE ;
}

/*
 *	���ݓ��͂���Ă��� Composition String ���t���b�V������֐��B
 */
void	PASCAL
SKKFlushText (HIMC hIMC)
{
#if defined (not_imp)
	if (!SKKIsCompStr (hIMC))
		return ;
#endif
	skkFlushTextSub (hIMC) ;
	return ;
}

void	PASCAL
SKKCloseText (HIMC hIMC)
{
	register LPINPUTCONTEXT		lpIMC ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return ;
	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR)){
		ImmUnlockIMC (hIMC) ;
		return ;
	}
	ImmUnlockIMC (hIMC) ;
	skkFlushTextSub (hIMC) ;
	return ;
}

/*========================================================================*
 */
void	PASCAL
skkFlushTextSub (
	register HIMC	hIMC)
{
	register LPINPUTCONTEXT			lpIMC ;
	register LPCOMPOSITIONSTRING	lpCompStr ;
	register LPCANDIDATEINFO		lpCandInfo ;
	TRANSMSG			GnMsg ;
	BOOL				fComposing	= FALSE ;

	DEBUGPRINTF ((TEXT ("SKKFlushText: (%ld)\n"), hIMC)) ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL)
		return ;

	if (IsCandidate (lpIMC)){
		lpCandInfo		= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
		ClearCandidate (lpCandInfo) ;
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
		GnMsg.message	= WM_IME_NOTIFY ;
		GnMsg.wParam	= IMN_CLOSECANDIDATE ;
		GnMsg.lParam	= 1 ;
		GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
	}

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC(lpIMC->hCompStr) ;
	if (lpCompStr){
		register LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR)lpCompStr ;
		int						nLength ;
		int						nCMode ;
		DWORD					dwCompStrLen ;

		if (lpMyCompStr->dwMinibufStrLen > 0){
			DEBUGPRINTF ((TEXT ("SKKFlushText: (%ld) -> MakeInfoGuideLine (0)\n"), hIMC)) ;
			MakeInfoGuideLine (hIMC, NULL, 0, -1) ;
			lpMyCompStr->dwMinibufStrLen	= 0 ;
			lpMyCompStr->dwMinibufCurPos	= -1 ;
		}

		fComposing		= lpMyCompStr->_fComposing ;
		dwCompStrLen	= lpCompStr->dwCompStrLen ;
		InitCompStr (lpCompStr, CLR_RESULT_AND_UNDET) ;

		/*	conversion mode �͈ێ�����B*/
		nCMode	= ImeDoc_GetConversionMode (&lpMyCompStr->_Doc) ;
		ImeDoc_Clear (&lpMyCompStr->_Doc) ;
		ImeDoc_SetConversionMode (&lpMyCompStr->_Doc, nCMode) ;

		lpCompStr->dwCompStrLen			= 0 ;
		lpCompStr->dwCursorPos			= 0 ;
		lpCompStr->dwDeltaStart			= 0 ;
		lpCompStr->dwCompReadStrLen		= 0 ;
		lpCompStr->dwCompClauseLen		= 0 ;
		lpCompStr->dwCompReadClauseLen	= 0 ;
		lpCompStr->dwResultStrLen		= 0 ;
		lpCompStr->dwResultClauseLen	= 0 ;
		lpCompStr->dwResultReadClauseLen= 0 ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;

		if (dwCompStrLen  > 0) {
			GnMsg.message	= WM_IME_COMPOSITION ;
			GnMsg.wParam	= 0 ;
			GnMsg.lParam	= GCS_COMPALL | GCS_CURSORPOS | GCS_DELTASTART ;
			GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
		}
	}
	if (fComposing) {
		GnMsg.message	= WM_IME_ENDCOMPOSITION ;
		GnMsg.wParam	= 0 ;
		GnMsg.lParam	= 0 ;
		GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
	}
	ImmUnlockIMC (hIMC) ;
	return ;
}

BOOL
skkFilterSpecialChar (
	register HIMC					hIMC,
	register LPINPUTCONTEXT			lpIMC,
	register int					nSpecialChar)
{
	LPMYCOMPSTR		lpMyCompStr ;
	CImeDoc*		pDoc ;
	BOOL			fEaten ;

	lpMyCompStr		= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		return	FALSE ;

	pDoc	= &lpMyCompStr->_Doc ;
	ImeDoc_FilterKeyEvent (pDoc, nSpecialChar, 0, NULL, &fEaten) ;
	SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	TRUE ;
}

