/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * uiminibuf.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "resource.h"
#include "skksubs.h"
#include "skkui.h"

/*
 *	�v���g�^�C�v�錾�B
 */
static	void	PASCAL	UIMinibuf_paint (HWND) ;
static	BOOL	PASCAL	UIMinibuf_drag (HWND, UINT) ;
static	BOOL	PASCAL	UIMinibuf_handleContextMenu (HWND, HIMC) ;
static	int		PASCAL	UIMinibuf_popupMenu (HWND, HIMC) ;
static	DWORD	PASCAL	UIMinibuf_getCursorPos (HDC, HIMC, LPPOINT) ;
static	BOOL	PASCAL	UIMinibuf_invalidate (LPUIEXTRA, LPINPUTCONTEXT) ;
static	void	PASCAL	uiMinibuf_moveDefault (HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
#if defined (does_not_work_well)
static	void	PASCAL	uiMinibuf_moveExclude (HWND, LPUIEXTRA, LPINPUTCONTEXT, CANDIDATEFORM*) ;
static	void	PASCAL	uiMinibuf_movePosition (HWND, LPUIEXTRA, LPINPUTCONTEXT, CANDIDATEFORM*) ;
#endif
static	BOOL	PASCAL	uiMinibuf_adjustWindowSize (HWND, LPINPUTCONTEXT, LPSIZE) ;

/*
 *	--- �������� �֐��̒�` --- �������� �֐��̒�` --- �������� �֐��̒�` ---
 */

LRESULT	CALLBACK
UIMinibuf_WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND	hUIWnd ;

	switch (message){
	case WM_CREATE:
		SetWindowLong (hWnd, FIGWL_UIMINIBUF_MOUSE, 0L) ;
		break ;

	case WM_PAINT:
		UIMinibuf_paint (hWnd) ;
		break;

	case WM_SETCURSOR:
		UIMinibuf_drag (hWnd, HIWORD (lParam)) ;
		break ;

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MOUSEMOVE:
	case WM_NCMOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		UIMinibuf_drag (hWnd, message) ;
		break ;

	case WM_MOVE:
		hUIWnd	= (HWND)GetWindowLongPtr (hWnd, FIGWL_UIMINIBUF_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_CANDMOVE, wParam, lParam) ;
		break;

	default:
		if (!MyIsIMEMessage (message))
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	0L ;
}

void	PASCAL
UIMinibuf_Create (
	register HWND				hUIWnd,
	register LPUIEXTRA			lpUIExtra,
	register LPINPUTCONTEXT		lpIMC)
{
	register LPCOMPOSITIONSTRING	lpCompStr ;
	POINT							pt ;
	register HINSTANCE				hInstance ;

	if (lpUIExtra->uiGuide.rc.left == -1) {
		RECT	rc ;
		GetWindowRect (lpIMC->hWnd, &rc) ;
		lpUIExtra->uiGuide.rc.left	= rc.left;
		lpUIExtra->uiGuide.rc.top	= rc.bottom;
	}
	hInstance	= (HINSTANCE)GetWindowLongPtr (hUIWnd, GWLP_HINSTANCE) ;
	if (!IsWindow (lpUIExtra->uiGuide.hWnd)){
		HDC			hdcIC ;
		TEXTMETRIC	tm ;
		int			dx, dy ;
		RECT		rcWork ;

		/*	Window �̑傫���� guess ����B
		 */
		hdcIC	= CreateIC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
		GetTextMetrics (hdcIC, &tm) ;
		dx	= tm.tmAveCharWidth * DEFAULT_MINIBUF_CHARWIDTH ;
		dy 	= tm.tmHeight + tm.tmExternalLeading ;
		DeleteDC (hdcIC) ;

		lpUIExtra->uiGuide.rc.right		= dx + 2 * GetSystemMetrics(SM_CXBORDER)
			+ 2 * GetSystemMetrics(SM_CXEDGE) ;
		lpUIExtra->uiGuide.rc.bottom	= dy + 2 * GetSystemMetrics(SM_CYBORDER)
			+ 2 * GetSystemMetrics(SM_CYEDGE) ;

		/*	�\���ʒu�A�\���T�C�Y���� Window ����ʊO�ɏo�Ȃ����ǂ�����
		 *	�`�F�b�N����B
		 */
		SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
		if ((lpUIExtra->uiGuide.rc.left + lpUIExtra->uiGuide.rc.right) > rcWork.right) {
			lpUIExtra->uiGuide.rc.left	= rcWork.right - lpUIExtra->uiGuide.rc.right ;
			if (lpUIExtra->uiGuide.rc.left < 0) {
				lpUIExtra->uiGuide.rc.left	= 0 ;
				lpUIExtra->uiGuide.rc.right	= rcWork.right ;
			}
		}
		if ((lpUIExtra->uiGuide.rc.top + lpUIExtra->uiGuide.rc.bottom) > rcWork.bottom) {
			lpUIExtra->uiGuide.rc.top	= rcWork.bottom - lpUIExtra->uiGuide.rc.bottom ;
			if (lpUIExtra->uiGuide.rc.top < 0)
				lpUIExtra->uiGuide.rc.top	= 0 ;
		}
		lpUIExtra->uiGuide.hWnd = 
			CreateWindowEx (WS_EX_WINDOWEDGE,
							(LPTSTR)g_szGuideClassName, NULL,
							WS_COMPDEFAULT | WS_DLGFRAME,
							lpUIExtra->uiGuide.rc.left,
							lpUIExtra->uiGuide.rc.top,
							lpUIExtra->uiGuide.rc.right,
							lpUIExtra->uiGuide.rc.bottom,
							hUIWnd, NULL, hInstance, NULL) ;
	}
	SetWindowLongPtr (lpUIExtra->uiGuide.hWnd, FIGWL_UIMINIBUF_SVRWND, 		(LONG_PTR)hUIWnd) ;
	SetWindowLong    (lpUIExtra->uiGuide.hWnd, FIGWL_UIMINIBUF_PREVCURSOR,	(LONG)0L) ;
	ShowWindow (lpUIExtra->uiGuide.hWnd, SW_HIDE) ;
	lpUIExtra->uiGuide.bShow	= FALSE ;

	DEBUGPRINTFEX (99, (TEXT ("UIMinibuf_Create (x:%d, y:%d, w:%d, h:%d)\n"),
						lpUIExtra->uiGuide.rc.left,
						lpUIExtra->uiGuide.rc.top,
						lpUIExtra->uiGuide.rc.right,
						lpUIExtra->uiGuide.rc.bottom)) ;
	return ;
}

void	PASCAL
UIMinibuf_Hide (LPUIEXTRA lpUIExtra)
{
	if (IsWindow (lpUIExtra->uiGuide.hWnd)){
		ShowWindow (lpUIExtra->uiGuide.hWnd, SW_HIDE) ;
		lpUIExtra->uiGuide.bShow	= FALSE ;
	}
	return ;
}

void	PASCAL
UIMinibuf_NotifyComposition (
	register HWND				hUIWnd,
	register LPUIEXTRA			lpUIExtra,
	register LPINPUTCONTEXT		lpIMC)
{
	RECT	rc ;
	SIZE	sz ;

	if (! IsWindow (lpUIExtra->uiGuide.hWnd))
		return ;
	if (! (lpUIExtra->dwShowStyle & ISC_SHOWUIGUIDELINE))
		return ;

	GetWindowRect (lpUIExtra->uiGuide.hWnd, &rc) ;
	sz.cx	= rc.right  - rc.left ;
	sz.cy	= rc.bottom - rc.top ;
	/*	Window �̃T�C�Y��ύX����K�v�����邩�ǂ����`�F�b�N����B*/
	if (uiMinibuf_adjustWindowSize (hUIWnd, lpIMC, &sz)) {
		if (sz.cx != (rc.right - rc.left) || sz.cy != (rc.bottom - rc.top)) {
			DEBUGPRINTFEX (99, (TEXT ("uiMinibuf_adjustWindowSize (%d!=%d or %d!=%d)\n"), 
				sz.cx, (rc.right - rc.left), sz.cy, (rc.bottom - rc.top))) ;
			UIMinibuf_Move (hUIWnd, lpUIExtra, lpIMC) ;
		}
	}
	InvalidateRect (lpUIExtra->uiGuide.hWnd, NULL, FALSE) ;
	return ;
}

void	PASCAL
UIMinibuf_Move (
	register HWND				hUIWnd,
	register LPUIEXTRA			lpUIExtra,
	register LPINPUTCONTEXT		lpIMC)
{
	CANDIDATEFORM	acf ;

	if (! (lpUIExtra->dwShowStyle & ISC_SHOWUIGUIDELINE))
		return ;

#if defined (does_not_work_well)
	/*	Office2003 �Ŏ����Ă݂��Ƃ���ACaret ���ړ����Ă� Exclude �̏�񂪍X�V����Ȃ��B
	 *	���炩�̎�i(�Ȃ����AOpenCandidate/CloseCandidate �̐������Ăяo���Ȃ��ɂ́A���p
	 *	�ł��Ȃ��悤���B(Mon Nov 14 21:16:31 2005)
	 *	���̂Ƃ���̓R�����g�A�E�g����B
	 */
	if ((lpUIExtra->dwShowStyle & ISC_SHOWUIALLCANDIDATEWINDOW) != 0 &&
		lpUIExtra->hIMC != NULL) {
		if (ImmRequestMessage (lpUIExtra->hIMC, IMR_CANDIDATEWINDOW, (LPARAM)&acf) != 0) {
			if (acf.dwIndex != -1 ){
				if (acf.dwStyle == CFS_EXCLUDE){
					uiMinibuf_moveExclude (hUIWnd, lpUIExtra, lpIMC, &acf) ;
				}  else if (acf.dwStyle == CFS_CANDIDATEPOS){
					uiMinibuf_movePosition (hUIWnd, lpUIExtra, lpIMC, &acf) ;
				}
				return ;
			}
		}
	}
#endif
	uiMinibuf_moveDefault (hUIWnd, lpUIExtra, lpIMC) ;
	return ;
}

/*========================================================================
 *	private functions
 */
/*
 *	Minibuffer Window �� WM_PAINT ���b�Z�[�W����������֐��B
 *-----
 */
void	PASCAL
UIMinibuf_paint (
	register HWND	hMinibufWnd)
{
	PAINTSTRUCT		ps ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR		lpMyCompStr ;
	HBRUSH			hbr, hBrushParent ;
	HDC				hDC, hPDC ;
	HFONT			hOldFont ;
	RECT			rc ;
	HWND			hSvrWnd ;
	int				nRegionStart, nRegionEnd ;
	int				x, y, nDY, nText, nTextPos ;
	LPMYSTR			pText ;
	long			lLength, lCursorPos, lPrevCursorPos ;
	BOOL			fRegionSelected ;
	DWORD			dwLevel, dwSize ;
	TEXTMETRIC		tm ;
	TCHAR			bufGuide [MAXGLCHAR] ;

	hDC		= BeginPaint (hMinibufWnd, &ps) ;
	hSvrWnd	= (HWND)GetWindowLongPtr (hMinibufWnd,	FIGWL_UIMINIBUF_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,		IMMGWLP_IMC) ;
	if (! hIMC)
		goto	exit_func ;

	dwLevel	= ImmGetGuideLine (hIMC, GGL_LEVEL, NULL, 0) ;
	if (! dwLevel)
		goto	exit_func ;
	dwSize	= ImmGetGuideLine (hIMC, GGL_STRING, NULL, 0) ;
	if (dwSize <= 0)
		goto	exit_func ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (! lpIMC)
		goto	exit_func ;

	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr){
		lCursorPos		= (long) lpMyCompStr->dwMinibufCurPos ;
		fRegionSelected	= (lCursorPos >= 0)? ImeDoc_GetSelectedRegion (&lpMyCompStr->_Doc, &nRegionStart, &nRegionEnd) : FALSE ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	} else {
		lCursorPos		= -1 ;
		fRegionSelected	= FALSE ;
	}
	ImmUnlockIMC (hIMC) ;

	if (dwSize >= (sizeof (bufGuide) - sizeof (TCHAR)))
		dwSize	= sizeof (bufGuide) - sizeof (TCHAR) ;

	dwSize	= ImmGetGuideLine (hIMC, GGL_STRING, bufGuide, dwSize) ;
	lLength	= dwSize / sizeof (TCHAR) ;
	hOldFont= CheckNativeCharset (hDC) ;

	if (0 <= lCursorPos && lCursorPos < lLength) {
		if (bufGuide [lCursorPos] == MYTEXT ('|')) {
			memmove (bufGuide + lCursorPos, bufGuide + lCursorPos + 1, (lLength - lCursorPos - 1) * sizeof (MYCHAR)) ;
			lLength	-- ;
		}
	}

	/* Minibuffer Window �̑傫���𓾂�B*/
	GetClientRect (hMinibufWnd, &rc) ;
		
	/* �eWindow �̔w�i�F�𓾂�B*/
	hPDC 			= GetDC (GetParent (hMinibufWnd)) ;
	hBrushParent	= CreateSolidBrush (GetBkColor (hPDC)) ;
	lPrevCursorPos	= GetWindowLong (hMinibufWnd, FIGWL_UIMINIBUF_PREVCURSOR) ;

	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	SetBkMode (hDC, OPAQUE) ;
	SetBkColor (hDC, GetBkColor (hPDC)) ;
	SetTextColor (hDC, RGB (0, 0, 0)) ;

	pText		= bufGuide ;
	nText		= lLength ;
	nTextPos	= 0 ;
	y			= rc.top ;
	while (y < rc.bottom && 0 < nText) {
		int		nChar ;
		SIZE	sz ;

		x	= rc.left ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
			if ((x + sz.cx) >= rc.right) 
				break ;
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;
		if (nTextPos <= lPrevCursorPos && lPrevCursorPos <= (nTextPos + nChar)){
			MyGetTextExtentPoint (hDC, pText, lPrevCursorPos - nTextPos, &sz) ;
			hbr		= SelectObject (hDC, hBrushParent) ;
			PatBlt (hDC, rc.left + sz.cx, y, UI_CURSORWIDTH, y + nDY, PATCOPY) ;
			(void) SelectObject (hDC, hbr) ;
		}
		if (fRegionSelected && !(nRegionEnd <= nTextPos || (nTextPos + nChar) <= nRegionStart)) {
			int	nStart, nEnd ;

			if (nTextPos < nRegionStart) {
				MyTextOut (hDC, x, y, pText, nRegionStart - nTextPos) ;
				MyGetTextExtentPoint (hDC, pText, nRegionStart - nTextPos, &sz) ;
				x	+= sz.cx ;
			}
			nStart	= (nRegionStart < nTextPos)? nTextPos : nRegionStart ;
			nEnd	= (nRegionEnd   >= (nTextPos + nChar))? (nTextPos + nChar) : nRegionEnd ;
			if (nStart < nEnd) {
				SetBkColor (hDC, RGB (192, 192, 224)) ;
				MyTextOut (hDC, x, rc.top, bufGuide + nStart, nEnd - nStart) ;
				MyGetTextExtentPoint (hDC, bufGuide + nStart, nEnd - nStart, &sz) ;
				SetBkColor (hDC, GetBkColor (hPDC)) ;
				x	+= sz.cx ;
			}
			if (nEnd < (nTextPos + nChar)) {
				MyTextOut (hDC, x, rc.top, bufGuide + nEnd, nTextPos + nChar - nEnd) ;
				MyGetTextExtentPoint (hDC, bufGuide + nEnd, nTextPos + nChar - nEnd, &sz) ;
				x	+= sz.cx ;
			}
		} else {
			/* �e�L�X�g��\������B*/
			MyTextOut (hDC, x, y, pText, nChar) ;
			MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
		}
		if (nChar < nText) {
			/*	�܂�Ԃ��L����\������B*/
			MyTextOut (hDC, x, y, MYTEXT ("\\"), 1) ;
			MyGetTextExtentPoint (hDC, MYTEXT ("\\"), 1, &sz) ;
			x	+= sz.cx ;
		}
		PatBlt (hDC, x, y, rc.right - x, nDY, PATCOPY) ;

		/* �K�v�Ȃ�J�[�\����\������B*/
		if (nTextPos <= lCursorPos && lCursorPos <= (nTextPos + nChar)){
			RECT			invRect ;

			if (lCursorPos > nTextPos) {
				MyGetTextExtentPoint (hDC, pText, lCursorPos - nTextPos, &sz) ;
				invRect.left	= rc.left + sz.cx ;
				invRect.right	= rc.left + sz.cx + UI_CURSORWIDTH ;
			} else {
				invRect.left	= rc.left ;
				invRect.right	= rc.left + UI_CURSORWIDTH ;
			}
			invRect.top		= y ;
			invRect.bottom	= y + nDY ;
			InvertRect (hDC, &invRect) ;
		}
		pText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		y			+= nDY ;
	}

	DeleteObject (hBrushParent) ;
	SetWindowLong (hMinibufWnd, FIGWL_UIMINIBUF_PREVCURSOR, lCursorPos) ;
	ReleaseDC (GetParent (hMinibufWnd), hPDC) ;

	if (hOldFont) 
		DeleteObject(SelectObject(hDC, hOldFont));

  exit_func:
	EndPaint (hMinibufWnd, &ps) ;
	return ;
}

BOOL	PASCAL
UIMinibuf_drag (
	register HWND	hWnd,
	register UINT	uMessage)
{
	HWND			hSvrWnd ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR		lpMyCompStr ;
	HDC				hDC ;
	POINT			pos ;
	DWORD			dwCursor ;
	DWORD			dwButtonPressed ;
	SIZE			sz ;

	dwButtonPressed	= (DWORD)GetWindowLong (hWnd, FIGWL_UIMINIBUF_MOUSE) ;
	/*
	 * �}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 * �ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (uMessage != WM_RBUTTONDOWN && uMessage != WM_RBUTTONUP &&
		uMessage != WM_LBUTTONDOWN && !dwButtonPressed)
		return	TRUE ;
	GetCursorPos (&pos) ;
	if (!ScreenToClient (hWnd, &pos))
		return	FALSE ;
	hDC		= GetDC (hWnd) ;
	if (!hDC)
		return	FALSE ;

	hSvrWnd	= (HWND)GetWindowLongPtr (hWnd,		FIGWL_UIMINIBUF_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,	IMMGWLP_IMC) ;
	if (hIMC && uMessage != WM_RBUTTONUP && uMessage != WM_RBUTTONDOWN){
		int	nDummy ;

		lpIMC		= ImmLockIMC (hIMC) ;
		/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr && ImeDoc_GetStatusCursor (&lpMyCompStr->_Doc, &nDummy)){
			BOOL	fRedraw, fEaten ;

			dwCursor	= UIMinibuf_getCursorPos (hDC, hIMC, &pos) ;
			/* �̈�I���J�n�ʒu���L������B*/
			switch (uMessage){
			case	WM_LBUTTONDOWN:
				fRedraw	= (dwCursor != lpMyCompStr->dwMinibufCurPos) ;
				ImeDoc_FilterKeyEvent (&lpMyCompStr->_Doc, MYVK_LBUTTON, dwCursor, NULL, &fEaten) ;
				SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
				if (fRedraw)
					InvalidateRect (hWnd, NULL, FALSE) ;
				break ;

			case	WM_LBUTTONUP:
				dwCursor	|= 0x80000000L ;
				/*	fall-through */
			case	WM_MOUSEMOVE:
			case	WM_NCMOUSEMOVE:
				if (dwButtonPressed){
					fRedraw	= (dwCursor != lpMyCompStr->dwMinibufCurPos) ;
					ImeDoc_FilterKeyEvent (&lpMyCompStr->_Doc, MYVK_LBUTTON, dwCursor, NULL, &fEaten) ;
					SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
					if (fRedraw)
						InvalidateRect (hWnd, NULL, FALSE) ;
				}
				break ;
			default:
				break ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	ReleaseDC (hWnd, hDC) ;
	if (uMessage == WM_LBUTTONDOWN){
		SetWindowLong (hWnd, FIGWL_UIMINIBUF_MOUSE, (LONG)1L) ;
		SetCapture (hWnd) ;
	}
	if (uMessage == WM_LBUTTONUP || uMessage == WM_RBUTTONUP){
		SetWindowLong (hWnd, FIGWL_UIMINIBUF_MOUSE, (LONG)0L) ;
		ReleaseCapture () ;
		if (uMessage == WM_RBUTTONUP){
			UIMinibuf_handleContextMenu (hWnd, hIMC) ;
		}
	}
	return	TRUE ;
}

/*
 *	�~�j�o�b�t�@���ŉE�N���b�N���ꂽ���� Context Menu �̏������s���֐��B
 */
BOOL	PASCAL
UIMinibuf_handleContextMenu (
	register HWND		hwnd,
	register HIMC		hIMC)
{
	register LPINPUTCONTEXT		lpIMC ;
	register int				nCmd ;
	register unsigned int		uVK ;

	nCmd	= UIMinibuf_popupMenu (hwnd, hIMC) ;
	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	switch (nCmd){
	case	IDM_CUT:
		uVK	= MYVK_MENU1 ;
		break ;
	case	IDM_PASTE:
		uVK	= MYVK_MENU2 ;
		break ;
	case	IDM_COPY:
		uVK	= MYVK_MENU3 ;
		break ;
	case	IDM_DELETE:
		uVK	= MYVK_MENU4 ;
		break ;
	default:
		uVK	= 0 ;
		break ;
	}
	if (uVK != 0) {
		register LPMYCOMPSTR		lpMyCompStr ;

		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr != NULL){
			BOOL	fEaten ;

			ImeDoc_FilterKeyEvent (&lpMyCompStr->_Doc, uVK, 0, NULL, &fEaten) ;
			SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
	}
	ImmUnlockIMC (hIMC) ;
	return	TRUE ;
}

int		PASCAL
UIMinibuf_popupMenu (
	register HWND	hwnd,
	register HIMC	hIMC)
{
	register HMENU			hMenu ;
	register LPINPUTCONTEXT	lpIMC ;
	register LPMYCOMPSTR	lpMyCompStr ;
	register int			nCmd ;
	POINT					pos ;
	register HCURSOR		hCursor ;

	hMenu		= 0 ;
	nCmd		= -1 ;
	GetCursorPos ((LPPOINT)&pos) ;
	lpIMC		= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	-1 ;
	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr){
		hMenu	= MyCreateClipboardMenu (lpMyCompStr) ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
	ImmUnlockIMC (hIMC) ;
	if (hMenu){
		/* ���j���[��\�����āA�I��������B*/
		hCursor	= SetCursor (LoadCursor (NULL, IDC_ARROW)) ;
		nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, pos.x, pos.y, 0, hwnd, NULL) ;
		DestroyMenu (hMenu) ;
		(void)SetCursor (hCursor) ;
	}
	return	nCmd ;
}

DWORD	PASCAL
UIMinibuf_getCursorPos (
	register HDC					hDC,
	register HIMC					hIMC,
	register LPPOINT				lppoint)
{
	DWORD			dwCursor	= (DWORD) -1 ;
	HGLOBAL			hGLStr ;
	LPMYSTR			lpstr ;
	DWORD			dwSize, dwLevel, dwLength ;
	LPINPUTCONTEXT	lpIMC ;
	long			lCurCursorPos	= -1 ;
	int				nItems ;
	SIZE			sz ;

	dwLevel	= ImmGetGuideLine (hIMC, GGL_LEVEL, NULL, 0) ;
	if (! dwLevel)
		goto	exit_func ;
	dwSize	= ImmGetGuideLine (hIMC, GGL_STRING, NULL, 0) ;
	if (dwSize <= 0)
		goto	exit_func ;

	hGLStr	= GlobalAlloc (GHND, dwSize + sizeof (MYCHAR)) ;
	if (hGLStr == NULL)
		goto	exit_func ;

	lpstr		= (LPMYSTR)GlobalLock (hGLStr) ;
	dwSize		= ImmGetGuideLine (hIMC, GGL_STRING, lpstr, dwSize) ;
	dwLength	= dwSize / sizeof (MYCHAR) ;

	lpIMC			= ImmLockIMC (hIMC) ;
	lCurCursorPos	= -1 ;
	if (lpIMC != NULL) {
		LPMYCOMPSTR		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr){
			lCurCursorPos	= (long) lpMyCompStr->dwMinibufCurPos ;
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	if (0 <= lCurCursorPos && lCurCursorPos < (long)dwLength) {
		if (lpstr [lCurCursorPos] == MYTEXT ('|')) {
			memmove (lpstr + lCurCursorPos, lpstr + lCurCursorPos + 1, (dwLength - lCurCursorPos - 1) * sizeof (MYCHAR)) ;
			dwLength	-- ;
		}
	}
	/* �V�����J�[�\���ʒu�����߂�B*/
	dwCursor	= 0 ;
	while (dwCursor < dwLength) {
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		MyGetTextExtentPoint (hDC, lpstr, dwCursor + 1, &sz) ;
		if (lppoint->x < sz.cx)
			break ;
		dwCursor	++ ;
#else
		if (IsDBCSLeadByte (lpstr [dwCursor])){
			nItems	= 2 ;
		} else {
			nItems	= 1 ;
		}
		MyGetTextExtentPoint (hDC, lpstr, dwCursor + nItems, &sz) ;
		if (lppoint->x < sz.cx)
			break ;
		dwCursor	+= nItems ;
#endif
	}
	GlobalUnlock (hGLStr) ;
	GlobalFree (hGLStr) ;

  exit_func:
	return	dwCursor ;
}

void	PASCAL
uiMinibuf_moveDefault (
	register HWND				hUIWnd,
	register LPUIEXTRA			lpUIExtra,
	register LPINPUTCONTEXT		lpIMC)
{
	RECT	rc, rcWork ;
	SIZE	szGuidWnd ;

	GetWindowRect (lpIMC->hWnd, &rc) ;
	lpUIExtra->uiGuide.rc.left	= rc.left;
	lpUIExtra->uiGuide.rc.top	= rc.bottom;

	szGuidWnd.cx	= lpUIExtra->uiGuide.rc.right ;
	szGuidWnd.cy	= lpUIExtra->uiGuide.rc.bottom ;
	if (uiMinibuf_adjustWindowSize (hUIWnd, lpIMC, &szGuidWnd)) {
		lpUIExtra->uiGuide.rc.right		= szGuidWnd.cx ;
		lpUIExtra->uiGuide.rc.bottom	= szGuidWnd.cy ;
	}

	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
	if ((lpUIExtra->uiGuide.rc.left + lpUIExtra->uiGuide.rc.right) > rcWork.right) {
		lpUIExtra->uiGuide.rc.left	= rcWork.right - lpUIExtra->uiGuide.rc.right ;
		if (lpUIExtra->uiGuide.rc.left < 0) {
			lpUIExtra->uiGuide.rc.left	= 0 ;
			lpUIExtra->uiGuide.rc.right	= rcWork.right ;
		}
	}
	if ((lpUIExtra->uiGuide.rc.top + lpUIExtra->uiGuide.rc.bottom) > rcWork.bottom) {
		lpUIExtra->uiGuide.rc.top	= rcWork.bottom - lpUIExtra->uiGuide.rc.bottom ;
		if (lpUIExtra->uiGuide.rc.top < 0)
			lpUIExtra->uiGuide.rc.top	= 0 ;
	}
	if (!IsWindow (lpUIExtra->uiGuide.hWnd))
		return ;

	MoveWindow (lpUIExtra->uiGuide.hWnd,
				lpUIExtra->uiGuide.rc.left,
				lpUIExtra->uiGuide.rc.top,
				lpUIExtra->uiGuide.rc.right,
				lpUIExtra->uiGuide.rc.bottom,
				TRUE) ;
	return ;
}

#if defined (does_not_work_well)
void	PASCAL
uiMinibuf_moveExclude (
	register HWND			hUIWnd,
	register LPUIEXTRA		lpUIExtra,
	register LPINPUTCONTEXT	lpIMC,
	register CANDIDATEFORM*	pCF)
{
	RECT	rc ;
	RECT	rcWork ;
	RECT	rcExclude ;
	RECT	rcUIWnd ;
	POINT	pt ;
	SIZE	szGuidWnd ;

	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;

	if (IsWindow(lpUIExtra->uiGuide.hWnd)){
		GetClientRect (lpUIExtra->uiGuide.hWnd, &rc) ;
	} else {
		rc.left	= rc.top	= rc.bottom	= rc.right	= 0 ;
	}

	/* ��⑋��\�����Ă͂����Ȃ��̈�𓾂�B*/
	pt.x	= pCF->rcArea.left ;
	pt.y	= pCF->rcArea.top ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.left		= pt.x ;
	rcExclude.top		= pt.y ;
	pt.x	= pCF->rcArea.right ;
	pt.y	= pCF->rcArea.bottom ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.right		= pt.x ;
	rcExclude.bottom	= pt.y ;

	/* ��⑋�̈ʒu�Ƒ傫�������肷��B*/
	GetClientRect (lpIMC->hWnd, &rcUIWnd) ;
	szGuidWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	szGuidWnd.cy	= rc.bottom - rc.top + 2 * GetSystemMetrics (SM_CYEDGE) ;
	uiMinibuf_adjustWindowSize (hUIWnd, lpIMC, &szGuidWnd) ;

	pt.x	= 0 ;
	pt.y	= szGuidWnd.cy ;
	ClientToScreen (lpIMC->hWnd, &pt) ;

	/* Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B*/
	if ((pt.x + szGuidWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - szGuidWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + szGuidWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - szGuidWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	/* Window ���w�肵���̈�ɂ������Ă��Ȃ����ǂ����`�F�b�N����B*/
	if (IsCrossRectangle (&pt, &szGuidWnd, &rcExclude)){
		pt.y	= rcExclude.bottom ;
		if ((pt.y + szGuidWnd.cy) > rcWork.bottom)
			pt.y	= rcExclude.top - szGuidWnd.cy ;
	}

	if (IsWindow (lpUIExtra->uiGuide.hWnd)){
		GetWindowRect (lpUIExtra->uiGuide.hWnd, &rc) ;
		MoveWindow (lpUIExtra->uiGuide.hWnd, pt.x, pt.y, szGuidWnd.cx, szGuidWnd.cy, TRUE) ;
	}
	return ;
}

void	PASCAL
uiMinibuf_movePosition (
	register HWND			hUIWnd,
	register LPUIEXTRA		lpUIExtra,
	register LPINPUTCONTEXT	lpIMC, 
	register CANDIDATEFORM*	pCF)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	RECT	rcWork ;
	SIZE	szGuidWnd ;
	POINT	pt ;

	pt.x	= pCF->ptCurrentPos.x ;
	pt.y	= pCF->ptCurrentPos.y ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
		
	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
	if (IsWindow (lpUIExtra->uiGuide.hWnd)) {
		GetWindowRect (lpUIExtra->uiGuide.hWnd, &rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom	= 0 ;
	}

	/*	Window ����ʊO�ɏo�����Ƃ��Ӑ}���Ă��邩�H 
	 *
	 *	�ǂ�����ʊO���w�肷�邱�ƂŁA��\�����Ӑ}���Ă���
	 *	�A�v���P�[�V���������݂���悤���B
	 * (��)
	 *	PSO
	 */
	if ((pt.x + 1) >= rcWork.right && (pt.y + 1) >= rcWork.bottom) {
		/*	���̏ꍇ�ɂ͉�ʊO�ɏo�����Ƃ��Ӑ}���Ă���Ɣ��f����B*/
		if (IsWindow (lpUIExtra->uiGuide.hWnd))
			ShowWindow (lpUIExtra->uiGuide.hWnd, SW_HIDE) ;
		return ;
	}

	/* ��⑋�̑傫�����v�Z����B*/
	GetClientRect (lpIMC->hWnd, &rcUIWnd) ;
	szGuidWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	szGuidWnd.cy	= rc.bottom - rc.top + 2 * GetSystemMetrics (SM_CYEDGE) ;
	uiMinibuf_adjustWindowSize (hUIWnd, lpIMC, &szGuidWnd) ;

	/*	Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B
	 */
	if ((pt.x + szGuidWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - szGuidWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + szGuidWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - szGuidWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	if (IsWindow (lpUIExtra->uiGuide.hWnd)){
		MoveWindow (lpUIExtra->uiGuide.hWnd, pt.x, pt.y, szGuidWnd.cx, szGuidWnd.cy, TRUE) ;
	}
	return ;
}
#endif

BOOL	PASCAL
uiMinibuf_adjustWindowSize (
	HWND			hwnd,
	LPINPUTCONTEXT	lpIMC,
	LPSIZE			lpSize)
{
	HDC				hDC ;
	HFONT			hOldFont ;
	HIMC			hIMC ;
	HWND			hSvrWnd ;
	SIZE			sz ;
	DWORD			dwLevel, dwSize ;
	int				nDefaultWidth, nDefaultHeight, nFrameWidth, nFrameHeight ;
	int				nWidth, nHeight ;
	TCHAR			bufGuide [MAXGLCHAR] ;
	TEXTMETRIC		tm ;

	hSvrWnd	= (HWND)GetWindowLongPtr (hwnd,		FIGWL_UIMINIBUF_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,	IMMGWLP_IMC) ;
	if (hIMC == NULL || lpIMC == NULL)
		return	FALSE ;

	hDC			= GetDC (hwnd) ;
	if (!hDC)
		return	FALSE ;

	hOldFont	= CheckNativeCharset (hDC) ;
	GetTextMetrics (hDC, &tm) ;

	nFrameWidth		= GetSystemMetrics (SM_CXDLGFRAME) * 2 ;
	nFrameHeight	= GetSystemMetrics (SM_CYDLGFRAME) * 2 ;
	nDefaultWidth	= tm.tmAveCharWidth * DEFAULT_MINIBUF_CHARWIDTH  + nFrameWidth ;
	nDefaultHeight	= tm.tmHeight + nFrameHeight ;

	nWidth	= nDefaultWidth ;
	nHeight	= nDefaultHeight ;

	dwLevel	= ImmGetGuideLine (hIMC, GGL_LEVEL, NULL, 0) ;
	if (dwLevel != 0) {
		dwSize	= ImmGetGuideLine (hIMC, GGL_STRING, NULL, 0) ;
		if (dwSize > 0) {
			LPMYCOMPSTR		lpMyCompStr	= NULL ;
			long			lCursorPos	= -1 ;
			long			lLength ;

			/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
			lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
			if (lpMyCompStr)
				lCursorPos		= (long) lpMyCompStr->dwMinibufCurPos ;

			if (dwSize >= sizeof (bufGuide)) 
				dwSize	= sizeof (bufGuide) - sizeof (TCHAR) ;
			dwSize		= ImmGetGuideLine (hIMC, GGL_STRING, bufGuide, dwSize) ;
			lLength		= dwSize / sizeof (TCHAR) ;
			hOldFont	= CheckNativeCharset (hDC) ;

			if (0 <= lCursorPos && lCursorPos < lLength) {
				if (bufGuide [lCursorPos] == MYTEXT ('|')) {
					memmove (bufGuide + lCursorPos, bufGuide + lCursorPos + 1, (lLength - lCursorPos - 1) * sizeof (MYCHAR)) ;
					lLength	-- ;
				}
			}
			if (lLength > 0) {
				LPCMYSTR	pText	= bufGuide ;
				int			nText	= lLength ;
				SIZE		sz ;

				nWidth	= (lpSize != NULL && nDefaultWidth < lpSize->cx)? lpSize->cx : nDefaultWidth ;
				nHeight	= 0 ;
				while (nText > 0) {
					int			nChar ;
					for (nChar = 1 ; nChar <= nText ; nChar ++) {
						MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
						/* FrameWidth �͕`��̈�Ɛ����Ă͂����Ȃ��̂ŊO���B*/
						if (sz.cx >= (nWidth - nFrameWidth)) 
							break ;
					}
					nChar	-- ;
					if (nChar <= 0)
						break ;
					nHeight	+= tm.tmHeight ;
					pText	+= nChar ;
					nText	-= nChar ;
				}
				nHeight	= (nHeight <= 0)? nDefaultHeight : (nHeight + nFrameHeight) ;
			}
		}
	}
	DeleteObject (SelectObject (hDC, hOldFont)) ;
	ReleaseDC (hwnd, hDC) ;
	if (lpSize) {
		DEBUGPRINTFEX (99, (TEXT ("uiMinibuf_adjustWindowSize (%dx%d <-> %dx%d)\n"), 
			lpSize->cx, lpSize->cy, nWidth, nHeight)) ;
		if (lpSize->cx < nWidth)
			lpSize->cx	= nWidth ;
		lpSize->cy	= nHeight ;
	}
	return	TRUE ;
}

