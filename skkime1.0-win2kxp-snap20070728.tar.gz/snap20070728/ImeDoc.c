#include "local.h"
#include "ImeDocP.h"
#include "ImeBuffer.h"
#include "jstring.h"
#if !defined (UNITTEST)
#include "skkui.h"
#endif
#include "common\confcommon.h"
#include "common\confdefaults.h"

/*========================================================================
 *	constant definitions
 */
#define	MAXASSOCRULE			(8192)
#define	MAX_REGVALUE_SIZE		(512)
#define	MAX_LENGTH_KANAPREFIX	(MAXCOMPLEN)
#define	MAX_PROCESS_UNREADEVENT	(128)

/*========================================================================
 *	prototypes
 */
static	BOOL		imeDoc_InitConfig			(CImeDoc*) ;
static	void		imeDoc_UninitConfig			(CImeDoc*) ;
static	BOOL		imeDoc_InitGenericConfig	(CImeDoc*) ;
static	BOOL		imeDoc_InitKeymap			(CImeDoc*) ;
static	BOOL		imeDoc_InitRomaKanaTable	(CImeDoc*) ;
static	BOOL		imeDoc_InitJAssocRule		(CImeDoc*) ;
static	BOOL		imeDoc_InitPrefixList		(CImeDoc*) ;
static	BOOL		imeDoc_InitInputVector		(CImeDoc*) ;
static	BOOL		imeDoc_InitZenkakuVector	(CImeDoc*) ;
static	BOOL		imeDoc_InitCandidateSelectKey	(CImeDoc*) ;
static	CImeBuffer*	imeDoc_CreateBuffer			(CImeDoc*, LPCWSTR, int, CTRecursiveEditSession*) ;
static	BOOL		imeDoc_DeleteUnusedBuffer	(CImeDoc*) ;
static	BOOL		imeDoc_InitBuffer			(CImeDoc*) ;
static	void		imeDoc_UninitBuffer			(CImeDoc*) ;
#if defined (UNITTEST)
static	WCHAR		_GetCharFromWPARAM			(WPARAM) ;
#else
static	WCHAR		_GetCharFromVKey			(CImeDoc*, UINT, LPARAM, CONST BYTE*) ;
#endif
static	BOOL		imeDoc_updateCandidateInfoForStatusText (CImeDoc*) ;

/*========================================================================
 *	static global variables
 */

/*========================================================================
 *	public functions
 */
BOOL
ImeDoc_Init (
	register CImeDoc*		pDoc)
{
	register int	i ;

	ASSERT (pDoc != NULL) ;

	pDoc->_nBuffer				= 0 ;
	pDoc->_nUnusedBuffer		= 0 ;
	pDoc->_pCurBuffer			= pDoc->_rpBuffer [0] ;
	pDoc->_nbufUnreadEvent		= 0 ;
	pDoc->_wchLastCommandChar	= L'\0' ;
	pDoc->_nbufMessage			= 0 ;
	pDoc->_nThisCommand			= FUNCNO_INVALID_CHAR ;
	pDoc->_nLastCommand			= FUNCNO_INVALID_CHAR ;
	pDoc->_fFilter				= FALSE ;
	for (i = 0 ; i < NELEMENTS (pDoc->_rpRomaKanaTable) ; i ++) 
		pDoc->_rpRomaKanaTable [i]	= NULL ;
	pDoc->_rpAssocRule			= NULL ;
	pDoc->_nAssocRule			= 0 ;

	for (i = 0 ; i < INPUTVECTORSIZE ; i ++) {
		pDoc->_rstrInputVector [i]		= NULL ;
		pDoc->_rstrZenkakuVector [i]	= NULL ;
	}
	pDoc->_pstrPrefixList		= NULL ;
	pDoc->_pbyJMap				= g_rDefinitionOfDefaultJMap ;
	pDoc->_pbyAbbrevMap			= g_rDefinitionOfDefaultAbbrevMap ;

	pDoc->_wKeyEvent			= 0 ;
	pDoc->_lKeyData				= 0 ;
	pDoc->_pbKeyState			= NULL ;

	TVarbuffer_Init (&pDoc->_vbufCandInfo, 1) ;
	TVarbuffer_Init (&pDoc->_vbufMessage, 1) ;

	pDoc->_fKeymapInitialized			= FALSE ;
	pDoc->_fAssocRuleInitialized		= FALSE ;
	pDoc->_fRomaKanaTableInitialized	= FALSE ;
	pDoc->_fGenericConfigInitialized	= FALSE ;
	pDoc->_fSkkInputVectorInitialized	= FALSE ;
	pDoc->_fSkkZenkakuVectorInitialized	= FALSE ;
	pDoc->_fPrefixListInitialized		= FALSE ;
	return	imeDoc_InitBuffer (pDoc) ;
	/*	on-demand �ŏ���������BUserEnv �΍�ɂȂ邩�H
	 *	return	imeDoc_InitConfig (pDoc) ;
	 */
}

void
ImeDoc_Clear (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (pDoc->_nBuffer > 0) ;

	imeDoc_UninitBuffer (pDoc) ;
	if (! imeDoc_InitBuffer (pDoc))
		return ;

	pDoc->_nbufMessage		= 0 ;
	pDoc->_nbufUnreadEvent	= 0 ;
	pDoc->_nThisCommand		= FUNCNO_INVALID_CHAR ;
	pDoc->_nLastCommand		= FUNCNO_INVALID_CHAR ;

	TVarbuffer_Clear (&pDoc->_vbufCandInfo) ;
	TVarbuffer_Clear (&pDoc->_vbufMessage) ;
	return ;
}

void
ImeDoc_Uninit (
	register CImeDoc*		pDoc)
{
	imeDoc_UninitBuffer (pDoc) ;
	imeDoc_UninitConfig (pDoc) ;
	TVarbuffer_Uninit (&pDoc->_vbufCandInfo) ;
	TVarbuffer_Uninit (&pDoc->_vbufMessage) ;
	return ;
}


/*	�܂� Query ����A����Ǝ��� Filter ���Ă΂��B���̍\����
 *	TextServiceFramework �ɍ��킹�Ă���B
 */
BOOL
ImeDoc_QueryFilterKeyEvent (
	register CImeDoc*		pDoc,
#if defined (UNITTEST)
	register WPARAM			wParam,
#else
	register UINT			uVKey,
	register LPARAM			lKeyData,
	register CONST LPBYTE	lpbKeyState,
#endif
	register BOOL*			pfEaten)
{
#if defined (UNITTEST)
	register WCHAR		wch	= _GetCharFromWPARAM (wParam) ;
#else
	register WCHAR		wch	= _GetCharFromVKey (pDoc, uVKey, lKeyData, lpbKeyState) ;
#endif

	ASSERT (pfEaten != NULL) ;

	if (wch == (WCHAR)-1) {
		*pfEaten	= FALSE ;
		return	TRUE ;
	}
	if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer) {
		*pfEaten	= TRUE ;
		return	TRUE ;
	}
	return	ImeBuffer_QueryFilterKeyEvent (ImeDoc_GetCurrentBuffer (pDoc), wch, pfEaten) ;
}

BOOL
ImeDoc_QueryToggleIMEKeyEvent (
	register CImeDoc*		pDoc,
#if defined (UNITTEST)
	register WPARAM			wParam,
#else
	register UINT			uVKey,
	register LPARAM			lKeyData,
	register CONST LPBYTE	lpbKeyState,
#endif
	register BOOL*			pfEaten)
{
#if defined (UNITTEST)
	register WCHAR		wch	= _GetCharFromWPARAM (wParam) ;
#else
	register WCHAR		wch	= _GetCharFromVKey (pDoc, uVKey, lKeyData, lpbKeyState) ;
#endif
	ASSERT (pfEaten != NULL) ;

	if (wch == (WCHAR)-1) {
		*pfEaten	= FALSE ;
		return	TRUE ;
	}
	return	ImeBuffer_QueryToggleIMEKeyEvent (ImeDoc_GetCurrentBuffer (pDoc), wch, pfEaten) ;
}

BOOL
ImeDoc_FilterKeyEvent (
	register CImeDoc*		pDoc,
#if defined (UNITTEST)
	register WPARAM			wParam,
#else
	register UINT			uVKey,
	register LPARAM			lKeyData,
	register CONST LPBYTE	lpbKeyState,
#endif
	register BOOL*			pfEaten)
{
	WCHAR		wchCurrentIn, wch ;
	BOOL		fEaten ;
#if !defined (UNITTEST)
	int			nConvMode ;
#endif
	int			nMaxProcess ;

	ASSERT (pfEaten != NULL) ;

	DEBUGPRINTFEX (99, (TEXT ("ImeDoc_FilterKeyEvent (doc:%p, key:0x%x, lkeydata:0x%x, keystate:%p)\n"), pDoc, uVKey, lKeyData, lpbKeyState)) ;

	/*	�܂����b�Z�[�W����������B*/
	ImeDoc_ClearMessage (pDoc) ;
#if !defined (UNITTEST)
	ImeDoc_ClearUpdateFlag (pDoc) ;
#endif

	/*	���񉟂��ꂽ�L�[�̏����B
	 */
#if defined (UNITTEST)
	pDoc->_wKeyEvent			= wParam ;
#else
	pDoc->_wKeyEvent			= uVKey ;
	pDoc->_lKeyData				= lKeyData ;
	pDoc->_pbKeyState			= lpbKeyState ;
#endif
	pDoc->_fFilter				= TRUE ;
#if defined (UNITTEST)
	wchCurrentIn				= _GetCharFromWPARAM (wParam) ;
#else
	wchCurrentIn				= _GetCharFromVKey (pDoc, uVKey, lKeyData, lpbKeyState) ;
#endif
	pDoc->_wchLastCommandChar	= wchCurrentIn ;
	if (pDoc->_wchLastCommandChar == (WCHAR) -1)
		return	TRUE ;

#if !defined (UNITTEST)
	nConvMode	= ImeBuffer_GetConversionMode (pDoc->_rpBuffer [0]) ;
#endif
	ImeBuffer_FilterKeyEvent (ImeDoc_GetCurrentBuffer (pDoc)) ;
	
	/*	�p�����ď������ׂ��C�x���g�͂��邩�H
	 */
	nMaxProcess	= MAX_PROCESS_UNREADEVENT ;
	while (nMaxProcess -- > 0 && pDoc->_nbufUnreadEvent > 0) {
		wch		= pDoc->_wchLastCommandChar = pDoc->_bufUnreadEvent [-- pDoc->_nbufUnreadEvent] ;
		if (pDoc->_pCurBuffer == pDoc->_rpBuffer [0]) {
			ImeBuffer_QueryFilterKeyEvent (ImeDoc_GetCurrentBuffer (pDoc), wch, &fEaten) ;
			if (! fEaten && pDoc->_nbufUnreadEvent <= 0) {
				if (wch == wchCurrentIn) 
					pDoc->_fFilter	= FALSE ;
				break ;
			}
		}
		ImeBuffer_FilterKeyEvent (ImeDoc_GetCurrentBuffer (pDoc)) ;
	}
	pDoc->_nbufUnreadEvent	= 0 ;
	imeDoc_DeleteUnusedBuffer (pDoc) ;
	pDoc->_nLastCommand	= pDoc->_nThisCommand ;

	/* status candidate �� update */
	imeDoc_updateCandidateInfoForStatusText (pDoc) ;

#if !defined (UNITTEST)
	if (nConvMode != ImeBuffer_GetConversionMode (pDoc->_rpBuffer [0]))
		pDoc->_dwUpdateFlag	|= SKKUI_UPDATE_CONVERSIONMODE ;
#endif
	*pfEaten		= pDoc->_fFilter ;
	return	TRUE ;
}

LPCWSTR
ImeDoc_GetPreeditText (
	register CImeDoc*		pDoc,
	register int*			pnLength)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;

	return	ImeBuffer_GetText (pDoc->_rpBuffer [0], pnLength) ;
}

BOOL
ImeDoc_GetPreeditCursor (
	register CImeDoc*		pDoc,
	register int*			pnCursor)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;
	ASSERT (pnCursor != NULL) ;

	*pnCursor	= ImeBuffer_GetCursorPosition (pDoc->_rpBuffer [0]) ;
	return	TRUE ;
}

#if !defined (UNITTEST)
LPMYCAND
ImeDoc_GetStatusText (
	register CImeDoc*		pDoc,
	register DWORD*			pdwSize)
{
	TVarbuffer*	pvbuf ;
	DWORD		dwSize ;

	if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer || pDoc->_nbufMessage > 0) {
		if (ImeBuffer_IsJHenkanShowCandidateModep (pDoc->_pCurBuffer) ||
			ImeBuffer_IsJInputByCodeOrMenuModep   (pDoc->_pCurBuffer)) {
			pvbuf	= &pDoc->_vbufCandInfo ;
		} else {
			pvbuf	= &pDoc->_vbufMessage ;
		}
	} else {
		if (ImeBuffer_IsJHenkanShowCandidateModep (pDoc->_pCurBuffer) ||
			ImeBuffer_IsJInputByCodeOrMenuModep   (pDoc->_pCurBuffer)) {
			pvbuf	= &pDoc->_vbufCandInfo ;
		} else {
			return	NULL ;
		}
	}
	dwSize		= TVarbuffer_GetUsage (pvbuf) ;
	if (dwSize <= sizeof (MYCAND))
		return	NULL ;
	*pdwSize	= dwSize ;
	return	(LPMYCAND) TVarbuffer_GetBuffer (pvbuf) ;
}

#else

LPCWSTR
ImeDoc_GetStatusText (
	register CImeDoc*		pDoc,
	register int*			pnLength)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;
	ASSERT (pnLength != NULL) ;

	/*	���b�Z�[�W�̏�����ς������������̂�������Ȃ��B�ċA�r���ł̃��b�Z�[�W��
	 *	�܂����낤�B�������͂���1�� Window ���o���ׂ��Ȃ̂��낤�B
	 */
#if 0
	if (pDoc->_nbufMessage > 0) {
		*pnLength	= pDoc->_nbufMessage ;
		return	pDoc->_bufMessage ;
	} else {
		if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer)
			return	ImeBuffer_GetText (pDoc->_pCurBuffer, pnLength) ;
	}
#else
	/*	�ċA�r���� Window �� Message Buffer �͊����Ă��܂��̂ŁA
	 *	�ċA��D�悷��B
	 */
	if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer) {
		LPCWSTR	pwText ;
		int		iLength ;

		/*	Message ���������ꍇ�ɂ͐擪�Ɂu�I�v��ǉ����������c�B
		 */
		pwText	= ImeBuffer_GetText (pDoc->_pCurBuffer, &iLength) ;
		if (pDoc->_nbufMessage > 0) {
			/*	���́u�I�v�̒ǉ��̂��߂� minibuffer text �� region �I��������Ă�
			 *	�܂��B
			 */
			if (iLength >= NELEMENTS (pDoc->_bufMessage2) - 1)
				iLength	= NELEMENTS (pDoc->_bufMessage2) - 1 ;
			memcpy (pDoc->_bufMessage2 + 1, pwText, iLength * sizeof (WCHAR)) ;
			pDoc->_bufMessage2 [0]	= L'�I' ;
			*pnLength	= iLength + 1 ;
			return	pDoc->_bufMessage2 ;
		} else {
			*pnLength	= iLength ;
			return	pwText ;
		}
	} else {
		if (pDoc->_nbufMessage > 0) {
			*pnLength	= pDoc->_nbufMessage ;
			return	pDoc->_bufMessage ;
		}
	}
#endif
	*pnLength	= 0 ;
	return	NULL ;
}
#endif

BOOL
ImeDoc_GetStatusCursor (
	register CImeDoc*		pDoc,
	register int*			pnCursor) 
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;
	ASSERT (pnCursor != NULL) ;

#if 0
	if (pDoc->_nbufMessage > 0)
		return	FALSE ;
	if (pDoc->_rpBuffer [0] == pDoc->_pCurBuffer)
		return	FALSE ;
	*pnCursor	= ImeBuffer_GetCursorPosition (pDoc->_pCurBuffer) ;
	return	TRUE ;
#else
	/*	�D�揇�ʂ̕ύX�ɔ����AMinibuffer �� Cursor ����̗D�揇�ʂ��ύX����B
	 *	�܂��ċA�ҏW����Ă��邩�ǂ����A����Ă��Ȃ���΁A�Ƃ���B
	 */
	if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer && ! ImeBuffer_IsStatusActivep (pDoc->_pCurBuffer)) {
		int		iCursor ;

		iCursor	= ImeBuffer_GetCursorPosition (pDoc->_pCurBuffer) ;
		if (pDoc->_nbufMessage > 0) {
			/*	�擪�́u�I�v�̒ǉ��̂��߂� minibuffer text �� region �I��������Ă�
			 *	�܂��B����āAiCursor + 1 ���Ȃ��Ƃ����Ȃ����O�ɏo���Ă��܂��킯�ɂ�
			 *	�����Ȃ��B
			 */
			iCursor	++ ;
		}
		*pnCursor	= iCursor ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
#endif
}

/*	�ǂ݉����ɂ��Ă̓o�b�t�@������𒼐ڕԂ��΍ςޘb�ł͂Ȃ��̂ŁA
 *	�o�b�t�@��n���� interface �ɂ���B
 *	�� ���[�ށA���܂蕡���̈قȂ����`���� interface ������͍̂D��
 *	�ł͂Ȃ����B
 */
int
ImeDoc_GetReadingText (
	register CImeDoc*		pDoc,
	register LPWSTR			wszDest,
	register int			nDest,
	register int*			pnPos)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;

	return	ImeBuffer_GetReadingText (pDoc->_rpBuffer [0], wszDest, nDest, pnPos) ;
}

BOOL
ImeDoc_SetConversionMode (
	register CImeDoc*		pDoc,
	register int			nMode)
{
	BOOL	f ;
#if !defined (UNITTEST)
	int		nConvMode ;
#endif
	if (pDoc->_rpBuffer [0] == NULL)
		return	FALSE ;
#if !defined (UNITTEST)
	nConvMode	= ImeBuffer_GetConversionMode (pDoc->_rpBuffer [0]) ;
#endif
	f	= ImeBuffer_SetConversionMode (pDoc->_rpBuffer [0], nMode) ;
#if !defined (UNITTEST)
	if (nConvMode != ImeBuffer_GetConversionMode (pDoc->_rpBuffer [0]))
		pDoc->_dwUpdateFlag	|= SKKUI_UPDATE_CONVERSIONMODE ;
#endif
	return	f ;
}

int
ImeDoc_GetConversionMode (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;
	return	ImeBuffer_GetConversionMode (pDoc->_rpBuffer [0]) ;
}

BOOL
ImeDoc_SetConversionString (
	register CImeDoc*		pDoc,
	register LPCWSTR		wstrText,
	register int			nText)
{
	ImeDoc_Clear (pDoc) ;
	return	ImeBuffer_SetConversionString (ImeDoc_GetCurrentBuffer (pDoc), wstrText, nText) ;
}

BOOL
ImeDoc_IsStatusActivep (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;
	return	(pDoc->_rpBuffer [0] != pDoc->_pCurBuffer || ImeBuffer_IsStatusActivep (pDoc->_rpBuffer [0])) ;
}

BOOL
ImeDoc_GetSelectedRegion (
	register CImeDoc*		pDoc,
	register int*			pnStartPos,
	register int*			pnEndPos)
{
	ASSERT (pDoc != NULL) ;
	
	return	ImeBuffer_GetSelectedRegion (ImeDoc_GetCurrentBuffer (pDoc), pnStartPos, pnEndPos) ;
}

BOOL
ImeDoc_QueryUpdateContext (
	register CImeDoc*		pDoc,
	register int*			pnShift,
	register int*			pnCursor,
	register BOOL*			pfContinue)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;
	ASSERT (pnShift    != NULL) ;
	ASSERT (pnCursor   != NULL) ;
	ASSERT (pfContinue != NULL) ;

	DEBUGPRINTFEX (99, (TEXT ("ImeDoc_QueryUpdateContext (Doc:%p)\n"), pDoc)) ;
	if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer) {
		*pnShift	= 0 ;
		*pnCursor	= ImeBuffer_GetCursorPosition (pDoc->_rpBuffer [0]) ;
		*pfContinue	= TRUE ;
		return	TRUE ;
	}
	return	ImeBuffer_QueryUpdateContext (pDoc->_rpBuffer [0], pnShift, pnCursor, pfContinue) ;
}

BOOL
ImeDoc_UpdateContext (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;

	if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer) 
		return	TRUE ;

	return	ImeBuffer_UpdateContext (pDoc->_rpBuffer [0]) ;
}

void
ImeDoc_UpdateConfig (
	register CImeDoc*		pDoc)
{
	imeDoc_UninitConfig (pDoc) ;
	return ;
}

#if !defined (UNITTEST)
void
ImeDoc_SetUpdateFlag (
	register CImeDoc*		pDoc,
	register unsigned int	uFlag)
{
	pDoc->_dwUpdateFlag	|= uFlag ;
	return ;
}

void
ImeDoc_ClearUpdateFlag (
	register CImeDoc*		pDoc)
{
	pDoc->_dwUpdateFlag	= 0 ;
	return ;
}

unsigned int
ImeDoc_GetUpdateFlag (
	register CImeDoc*		pDoc)
{
	return	pDoc->_dwUpdateFlag ;
}

BOOL
ImeDoc_RevertText (
	register CImeDoc*		pDoc)
{
	return	ImeBuffer_RevertText (ImeDoc_GetCurrentBuffer (pDoc)) ;
}

BOOL
ImeDoc_CompleteText (
	register CImeDoc*		pDoc)
{
	return	ImeBuffer_CompleteText (ImeDoc_GetCurrentBuffer (pDoc)) ;
}
#endif

BOOL
ImeDoc_GetConvertedRegion	(
	register CImeDoc*		pDoc, 
	register int*			pnStart,
	register int*			pnEnd)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;

	return	ImeBuffer_GetConvertedRegion (pDoc->_rpBuffer [0], pnStart, pnEnd) ;
}

BOOL
ImeDoc_IsJHenkanShowCandidateModep	(
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;

	return	ImeBuffer_IsJHenkanShowCandidateModep (ImeDoc_GetCurrentBuffer (pDoc)) ;
}

BOOL
ImeDoc_IsJInputByCodeOrMenuModep	(
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;

	return	ImeBuffer_IsJInputByCodeOrMenuModep (ImeDoc_GetCurrentBuffer (pDoc)) ;
}

BOOL
ImeDoc_DisableMinibufferp	(
	register CImeDoc*		pDoc)
{
#if defined (UNITTEST)
	HKEY	hKey ;
	DWORD	dwType, dwData, cbData, dwRet ;

	dwData	= 0 ;
	cbData	= sizeof (DWORD) ;
	/* ���W�X�g���̌����p�X��ݒ肷��B*/
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATHW_SKKIME_BASE, 0, KEY_READ, &hKey) != ERROR_SUCCESS)
		return	FALSE ;
	dwRet	= RegQueryValueEx (hKey, TEXT(REGKEY_ENABLEGAMEMODE), NULL, &dwType, (LPBYTE)&dwData, &cbData) ;
	RegCloseKey (hKey) ;
	if (dwType != REG_DWORD)
		return	FALSE ;
	if (dwRet == ERROR_SUCCESS)
		return	(cbData != 0) ;
	return	FALSE ;
#else
	return	skkime_IsEnableGameMode () ;
#endif
}


/*========================================================================*
 *	``library local'' public methods
 */
/*	keymap ���ꎩ�g�� buffer ���ꂼ��ɓƗ��ł��邪�AIme �Ƃ��ĕʂ� c++-mode
 *	�� buffer �ɓK�p����Ă���ȂǂƂ������Ƃ͂��肦�Ȃ��B
 *
 *	�䂦�ɋ��ʂ̂��̂Ƃ��āADocument �̒��Œ�`����B
 */
BOOL
ImeDoc_LookupKeymap (
	register CImeDoc*		pDoc,
	register int			wch,
	register int* 			pnFuncNo)
{
	register int	nKeymap, nFuncNo ;

	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;

	if (pDoc->_pCurBuffer == NULL || pnFuncNo == NULL)
		return	FALSE ;

	if (!(0 <= wch && wch < SIZE_IMEDOC_KEYMAP)) {
		*pnFuncNo	= FUNCNO_INVALID_CHAR ;
		return	TRUE ;
	}
	if (! pDoc->_fKeymapInitialized) {
		imeDoc_InitKeymap (pDoc) ;
		pDoc->_fKeymapInitialized	= TRUE ;
	}
	nKeymap	= ImeBuffer_GetKeymap (pDoc->_pCurBuffer) ;
	switch (nKeymap) {
	case	IMEKEYMAP_ASCII:
		if (0x20 <= wch && wch < 0x7F) {
			nFuncNo	= FUNCNO_SELF_INSERT_CHARACTER ;
		} else if (wch == 0x0D) {
			nFuncNo	= FUNCNO_NEWLINE ;
		} else {
			nFuncNo	= pDoc->_pbyJMap [wch] ;
		}
		break ;
	case	IMEKEYMAP_ZENKAKU:
		if (0x20 <= wch && wch < 0x7F) {
			nFuncNo	= FUNCNO_J_ZENKAKU_INSERT ;
		} else if (wch == 0x0D) {
			nFuncNo	= FUNCNO_NEWLINE ;
		} else {
			nFuncNo	= pDoc->_pbyJMap [wch] ;
		}
		break ;
	case	IMEKEYMAP_ABBREV:
		nFuncNo		= pDoc->_pbyAbbrevMap [wch] ;
		break ;
	case	IMEKEYMAP_JMODE:
	default:
		nFuncNo		= pDoc->_pbyJMap [wch] ;
		break ;
	}
	*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

BOOL
ImeDoc_SetUnreadCommandChar (
	register CImeDoc*		pDoc,
	register int			ch)
{
	ASSERT (pDoc != NULL) ;
	if (pDoc->_nbufUnreadEvent >= MAXUNREADEVENT)
		return	FALSE ;
	pDoc->_bufUnreadEvent [pDoc->_nbufUnreadEvent ++]	= (WCHAR) ch ;
	return	TRUE ;
}

BOOL
ImeDoc_SetLastCommandChar (
	register CImeDoc*		pDoc,
	register int			ch)
{
	ASSERT (pDoc != NULL) ;

	if (pDoc->_wchLastCommandChar != (WCHAR) ch) {
		pDoc->_wchLastCommandChar	= (WCHAR) ch ;
#if !defined (UNITTEST)
		pDoc->_lKeyData				= (LPARAM) 0 ;	/* clear */
#endif
	}
	return	TRUE ;
}

int
ImeDoc_GetLastCommandChar (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	return	pDoc->_wchLastCommandChar ;
}

#if !defined (UNITTEST)
LPARAM
ImeDoc_GetLastKeyData (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	return	pDoc->_lKeyData ;
}
#endif

BOOL
ImeDoc_SetThisCommand (
	register CImeDoc*		pDoc,
	register int			nFuncNo)
{
	ASSERT (pDoc != NULL) ;
	pDoc->_nThisCommand	= nFuncNo ;
	return	TRUE ;
}

int
ImeDoc_GetLastCommand (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	return	pDoc->_nLastCommand ;
}

BOOL
ImeDoc_UnprocessChar (
	register CImeDoc*		pDoc,
	register int			ch)
{
	ASSERT (pDoc != NULL) ;

	if (
		0 <= ch && ch < SIZE_MYKEYMAP &&	/* subspecial-key �� unprocess �ł��Ȃ��B*/
#if defined (UNITTEST)
		_GetCharFromWPARAM (pDoc->_wKeyEvent)
#else
		_GetCharFromVKey (pDoc, pDoc->_wKeyEvent, pDoc->_lKeyData, pDoc->_pbKeyState)
#endif
		== (WCHAR) ch) {
		DEBUGPRINTF ((TEXT ("CImeDoc::UnprocessChar (0x%x)\n"), (int)ch)) ;
		pDoc->_fFilter	= FALSE ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

/*	�b��B
 */
CTAssocRule*
ImeDoc_JAssocRule (
	register CImeDoc*		pDoc,
	register LPCWSTR		wstr,
	register int			nwstr)
{
	register CTAssocRule**	ppRule ;
	register int			n ;
	register LPCWSTR		wstrState ;

	ASSERT (pDoc != NULL) ;

	if (! pDoc->_fAssocRuleInitialized) {
		imeDoc_InitJAssocRule (pDoc) ;
		pDoc->_fAssocRuleInitialized	= TRUE ;
	}

	ppRule	= pDoc->_rpAssocRule ;
	n		= pDoc->_nAssocRule ;
	while (n -- > 0) {
		wstrState	= TAssocRule_GetState (*ppRule) ;
		if (! lstrncmpW (wstr, wstrState, nwstr) && 
			*(wstrState + nwstr) == L'\0')
			return	*ppRule ;	/* hit */
		ppRule	++ ;
	}
	return	NULL ;
}

CTRomaKanaTable*
ImeDoc_GetRomaKana (
	register CImeDoc*		pDoc,
	register int			ch)
{
	static const char		rchVowel[] = { 'a', 'i', 'u', 'e', 'o' } ;
	register const char*	pch ;
	
	if (! pDoc->_fRomaKanaTableInitialized) {
		imeDoc_InitRomaKanaTable (pDoc) ;
		pDoc->_fRomaKanaTableInitialized	= TRUE ;
	}
	pch	= (const char*)memchr (rchVowel, ch, NELEMENTS (rchVowel)) ;
	if (pch == NULL)
		return	NULL ;
	return	pDoc->_rpRomaKanaTable [pch - rchVowel] ;
}

BOOL
ImeDoc_IsSkkDeleteOkuriWhenQuitp (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_DELETE_OKURI_WHEN_QUIT] != 0 ;
}

BOOL
ImeDoc_IsSkkProcessOkuriEarlyp (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_PROCESS_OKURI_EARLY] != 0 ;
}

BOOL
ImeDoc_IsSkkKakuteiEarlyp (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_KAKUTEI_EARLY] != 0 ;
}

BOOL
ImeDoc_IsJKakuteiEarlyp (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	return	ImeDoc_IsSkkKakuteiEarlyp (pDoc) && ! ImeDoc_IsSkkProcessOkuriEarlyp (pDoc) ;
}

BOOL
ImeDoc_IsSkkEggLikeNewlinep (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_EGG_LIKE_NEWLINE] != 0 ;
}

BOOL
ImeDoc_IsSkkUseNumericConversionp (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_USE_NUMERIC_CONVERSION] != 0 ;
}

BOOL
ImeDoc_IsSkkDabbrevLikeCompletion (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_DABBREV_LIKE_COMPLETION] != 0 ;
}

BOOL
ImeDoc_IsSkkDeleteImpliesKakuteip (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_DELETE_IMPLIES_KAKUTEI] != 0 ;
}

BOOL
ImeDoc_IsSkkKatakanaHiraganaHenkanp	(
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_KATAKANA_HIRAGANA_HENKAN] != 0 ;
}

int
ImeDoc_GetSkkDateAd (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_DATE_AD] ;
}

int
ImeDoc_GetSkkNumberStyle (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_STYLE] ;
}

BOOL
ImeDoc_IsSkkShowAnnotationp (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	if (! pDoc->_fGenericConfigInitialized) {
		imeDoc_InitGenericConfig (pDoc) ;
		pDoc->_fGenericConfigInitialized	= TRUE ;
	}
	return	pDoc->_rnGenericConfig [GC_SHOW_ANNOTATION] ;
}

LPCWSTR
ImeDoc_GetSkkInputVector (
	register CImeDoc*		pDoc,
	register int			wch,
	register int*			pnWord) 
{
	register LPCWSTR	wstrRetval ;
	register int		nIndex ;

	ASSERT (pDoc != NULL) ;
	ASSERT (pnWord != NULL) ;

	if (! pDoc->_fSkkInputVectorInitialized) {
		imeDoc_InitInputVector (pDoc) ;
		pDoc->_fSkkInputVectorInitialized	= TRUE ;
	}

	nIndex	= (int) wch - 32 ;
	if (0 <= nIndex && nIndex < INPUTVECTORSIZE) {
		wstrRetval	= pDoc->_rstrInputVector [nIndex] ;
	} else {
		wstrRetval	= NULL ;
	}
	*pnWord	= (wstrRetval != NULL)? lstrlenW (wstrRetval) : 0 ;
	return	wstrRetval ;
}

LPCWSTR
ImeDoc_GetSkkZenkakuVector (
	register CImeDoc*		pDoc,
	register int			wch,
	register int*			pnWord)
{
	register LPCWSTR	wstrRetval ;
	register int		nIndex ;

	ASSERT (pDoc != NULL) ;
	ASSERT (pnWord != NULL) ;

	if (! pDoc->_fSkkZenkakuVectorInitialized) {
		imeDoc_InitZenkakuVector (pDoc) ;
		pDoc->_fSkkZenkakuVectorInitialized	= TRUE ;
	}
	nIndex	= (int) wch - 32 ;
	if (0 <= nIndex && nIndex < INPUTVECTORSIZE) {
		wstrRetval	= pDoc->_rstrZenkakuVector [nIndex] ;
	} else {
		wstrRetval	= NULL ;
	}
	*pnWord	= (wstrRetval != NULL)? lstrlenW (wstrRetval) : 0 ;
	return	wstrRetval ;
}

BOOL
ImeDoc_IsValidPrefixp (
	register CImeDoc*		pDoc,
	register LPCWSTR		wstr,
	register int			nwstr)
{
	ASSERT (pDoc != NULL) ;

	if (! pDoc->_fPrefixListInitialized) {
		imeDoc_InitPrefixList (pDoc) ;
		pDoc->_fPrefixListInitialized	= TRUE ;
	}
	if (pDoc->_pstrPrefixList == NULL) {
		register int		i ;

		for (i = 0 ; i < NELEMENTS (g_rDefinitionOfDefaultPrefixList) ; i ++) {
			if (! lstrncmpW (wstr, g_rDefinitionOfDefaultPrefixList [i], nwstr) &&
				*(g_rDefinitionOfDefaultPrefixList [i] + nwstr) == L'\0') 
				return	TRUE ;
		}
	} else {
		register LPCWSTR	wptr ;
		register int		n ;

		wptr	= pDoc->_pstrPrefixList ;
		while (n = lstrlenW (wptr), n > 0) {
			if (n == nwstr && ! lstrncmpW (wstr, wptr, nwstr))
				return	TRUE ;
			wptr	+= n + 1 ;
		}
	}
	return	FALSE ;
}

const BYTE*
ImeDoc_GetJHenkanShowCandidateKeys (
	register CImeDoc*		pDoc)
{
#if !defined (UNITTEST)
	return	skkime_GetJHenkanShowCandidateKeys () ;
#else
	return	pDoc->_JHenkanShowCandidateKeys ;
#endif
}

const BYTE*
ImeDoc_GetJInputByCodeOrMenuKeys1 (
	register CImeDoc*		pDoc)
{
#if !defined (UNITTEST)
	return	skkime_GetJInputByCodeOrMenuKeys1 () ;
#else
	return	pDoc->_JInputByCodeOrMenuKeys1 ;
#endif
}

const BYTE*
ImeDoc_GetJInputByCodeOrMenuKeys2 (
	register CImeDoc*		pDoc)
{
#if !defined (UNITTEST)
	return	skkime_GetJInputByCodeOrMenuKeys2 () ;
#else
	return	pDoc->_JInputByCodeOrMenuKeys2 ;
#endif
}

CImeBuffer*
ImeDoc_GetCurrentBuffer (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (pDoc->_pCurBuffer != NULL) ;

	DEBUGPRINTFEX (99, (TEXT ("ImeDoc_GetCurrentBuffer (doc:%p)\n"))) ;

	return	pDoc->_pCurBuffer ;
}

BOOL
ImeDoc_ReadFromMinibuffer (
	register CImeDoc*		pDoc,
	register LPCWSTR		wstrMessage,
	register int			nstrMessage,
	register CTRecursiveEditSession*	pSession)
{
	register CImeBuffer*	pBuffer ;

	ASSERT (pDoc != NULL) ;

	pBuffer	= imeDoc_CreateBuffer (pDoc, wstrMessage, nstrMessage, pSession) ;
	if (pBuffer == NULL) 
		return	FALSE ;
	pDoc->_pCurBuffer	= pBuffer ;
	return	TRUE ;
}

BOOL
ImeDoc_ExitMinibuffer (
	register CImeDoc*		pDoc,
	register CImeBuffer*	pDestBuffer)
{
	register CImeBuffer*	pSrcBuffer ;
	register int			i, nSrc, nDest ;

	ASSERT (pDoc != NULL) ;
	ASSERT (pDestBuffer != NULL) ;

	pSrcBuffer	= ImeDoc_GetCurrentBuffer (pDoc) ;
	if (pSrcBuffer == pDestBuffer)
		return	TRUE ;

	nSrc = nDest = -1 ;
	for (i = 0 ; i < pDoc->_nBuffer ; i ++) {
		if (pDoc->_rpBuffer [i] == pSrcBuffer) {
			nSrc	= i ;
			continue ;
		}
		if (pDoc->_rpBuffer [i] == pDestBuffer) {
			nDest	= i ;
			continue ;
		}
	}
	if (nSrc < 0 || nDest < 0)
		return	FALSE ;

	pDoc->_rpUnusedBuffer [pDoc->_nUnusedBuffer ++]	= pSrcBuffer ;
	pDoc->_rpBuffer [nSrc]	= NULL ;
	if (nSrc == (pDoc->_nBuffer - 1))
		pDoc->_nBuffer	-- ;
	pDoc->_pCurBuffer		= pDestBuffer ;
	return	TRUE ;
}

BOOL
ImeDoc_SetMessageN (
	register CImeDoc*		pDoc,
	register LPCWSTR		wstrMessage,
	register int			nstrMessage)
{
	TVarbuffer*	pvbufMessageInfo ;
	DWORD		dwSize ;

	ASSERT (pDoc != NULL) ;
	ASSERT (wstrMessage != NULL || nstrMessage == 0) ;

	pDoc->_nbufMessage	= (nstrMessage > MSGBUFSIZE)? MSGBUFSIZE : nstrMessage ;
	if (wstrMessage != NULL)
		memcpy (pDoc->_bufMessage, wstrMessage, pDoc->_nbufMessage * sizeof (WCHAR)) ;
	return	TRUE ;
}

BOOL
ImeDoc_SetMessage (
	register CImeDoc*		pDoc,
	register LPCWSTR		wstrMessage)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (wstrMessage != NULL) ;
	return	ImeDoc_SetMessageN (pDoc, wstrMessage, lstrlenW (wstrMessage)) ;
}

BOOL
ImeDoc_HaveMessagep (
	register CImeDoc*		pDoc)
{
	return	(pDoc->_nbufMessage > 0) ;
}

LPCWSTR
ImeDoc_GetMessage (
	register CImeDoc*		pDoc,
	register int*			piLength)
{
	ASSERT (pDoc != NULL) ;

	if (piLength != NULL)
		*piLength	= pDoc->_nbufMessage ;
	return	pDoc->_bufMessage ;
}

BOOL
ImeDoc_ClearMessage (
	register CImeDoc*		pDoc)
{
	pDoc->_nbufMessage		= 0 ;
	pDoc->_bufMessage2 [0]	= L'\0' ;
	return	TRUE ;
}

BOOL
ImeDoc_RecursiveEditp (
	register CImeDoc*		pDoc)
{
	return	(pDoc->_pCurBuffer != pDoc->_rpBuffer [0]) ;
}

TVarbuffer*
ImeDoc_GetCandidateInfoBuffer (
	register CImeDoc*			pDoc)
{
	return	&pDoc->_vbufCandInfo ;
}

TVarbuffer*
ImeDoc_GetMessageInfoBuffer (
	register CImeDoc*			pDoc)
{
	return	&pDoc->_vbufMessage ;
}

/*========================================================================
 *	private methods
 */
BOOL
imeDoc_InitConfig (
	register CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;

	if (! imeDoc_InitGenericConfig (pDoc) ||
		! imeDoc_InitKeymap (pDoc) ||
		! imeDoc_InitRomaKanaTable (pDoc) ||
		! imeDoc_InitJAssocRule (pDoc) ||
		! imeDoc_InitPrefixList (pDoc) ||
		! imeDoc_InitInputVector (pDoc) ||
		! imeDoc_InitZenkakuVector (pDoc) ||
		! imeDoc_InitCandidateSelectKey (pDoc)) {
		return	FALSE ;
	}
	return	TRUE ;
}

void
imeDoc_UninitConfig (
	register CImeDoc*		pDoc)
{
	register int	i ;

	ASSERT (pDoc != NULL) ;

	for (i = 0 ; i < INPUTVECTORSIZE ; i ++) {
		if (pDoc->_rstrZenkakuVector [i] != NULL) {
			FREE (pDoc->_rstrZenkakuVector [i]) ;
			pDoc->_rstrZenkakuVector [i]	= NULL ;
		}
		if (pDoc->_rstrInputVector [i] != NULL) {
			FREE (pDoc->_rstrInputVector [i]) ;
			pDoc->_rstrInputVector [i]	= NULL ;
		}
	}
	if (pDoc->_pstrPrefixList != NULL) {
		FREE (pDoc->_pstrPrefixList) ;
		pDoc->_pstrPrefixList	= NULL ;
	}
	for (i = 0 ; i < NELEMENTS (pDoc->_rpRomaKanaTable) ; i ++) {
		TRomaKanaTable_Destroy (pDoc->_rpRomaKanaTable [i]) ;
		pDoc->_rpRomaKanaTable [i]	= NULL ;
	}
	if (pDoc->_rpAssocRule != NULL) {
		for (i = 0 ; i < pDoc->_nAssocRule ; i ++) 
			TAssocRule_Destroy (pDoc->_rpAssocRule [i]) ;
		FREE (pDoc->_rpAssocRule) ;
		pDoc->_rpAssocRule	= NULL ;
		pDoc->_nAssocRule	= 0 ;
	}
	pDoc->_fKeymapInitialized			= FALSE ;
	pDoc->_fAssocRuleInitialized		= FALSE ;
	pDoc->_fRomaKanaTableInitialized	= FALSE ;
	pDoc->_fGenericConfigInitialized	= FALSE ;
	pDoc->_fSkkInputVectorInitialized	= FALSE ;
	pDoc->_fSkkZenkakuVectorInitialized	= FALSE ;
	pDoc->_fPrefixListInitialized		= FALSE ;
	return ;
}

BOOL
imeDoc_InitGenericConfig (
	register CImeDoc*		pDoc)
{
	static LPCWSTR		rwstrEntries [NUMGENERICCONFIG]	= {
		REGPATHW_EGG_LIKE_NEWLINE,			REGPATHW_DELETE_IMPLIES_KAKUTEI,
		REGPATHW_USE_NUMERIC_CONVERSION,		REGPATHW_DABBREV_LIKE_COMPLETION,
		REGPATHW_KATAKANA_HIRAGANA_HENKAN,	REGPATHW_NUMERIC_STYLE,
		REGPATHW_DATE_AD,					REGPATHW_SHOW_ANNOTATION,
		REGPATHW_KAKUTEI_EARLY,				REGPATHW_PROCESS_OKURI_EARLY,
		REGPATHW_DELETE_OKURI_WHEN_QUIT
	} ;
	static int			rnDefaultValues [NUMGENERICCONFIG]	= {
		TRUE,								TRUE,
		TRUE,								FALSE,
		TRUE,								0,
		0,									FALSE,
		TRUE,								FALSE,
		FALSE
	} ;
	register int	i ;
	HKEY			hSubKey ;
	LONG			lResult ;
	
#if !defined (NO_TOUCH_REGISTRY)
	lResult	= RegOpenKeyExW (HKEY_CURRENT_USER, REGPATHW_GENERIC, 0, KEY_READ, &hSubKey) ;
	if (lResult == ERROR_SUCCESS) {
		DWORD	dwType, dwValue, cbData ;
		
		for (i = 0 ; i < NELEMENTS (rwstrEntries) ; i ++) {
			cbData	= sizeof (dwValue) ;
			lResult	= RegQueryValueExW (hSubKey, rwstrEntries [i], NULL, &dwType, (LPBYTE)&dwValue, &cbData) ;
			if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
				pDoc->_rnGenericConfig [i]	= (int) dwValue ;
			} else {
				pDoc->_rnGenericConfig [i]	= rnDefaultValues [i] ;
			}
		}
		RegCloseKey (hSubKey) ;
		return	TRUE ;
	}
#endif
	for (i = 0 ; i < NELEMENTS (rwstrEntries) ; i ++) 
		pDoc->_rnGenericConfig [i]	= rnDefaultValues [i] ;
	return	TRUE ;
}

BOOL
imeDoc_InitKeymap (
	register CImeDoc*		pDoc)
{
	register BOOL	fFoundAbbrevMap, fFoundNormalMap ;
	register int	i ;
	HKEY	hSubKey ;
	BYTE	rbyKeyMap [SIZE_MYKEYMAP] ;

	fFoundNormalMap	= FALSE ;
	fFoundAbbrevMap	= FALSE ;

#if !defined (NO_TOUCH_REGISTRY)
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATHW_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;
		
		/*	j-map ���̏����B*/
		cbData	= sizeof (rbyKeyMap) ;
		if (RegQueryValueExW (hSubKey, REGSUBKEYW_JMAP, NULL, &dwType, rbyKeyMap, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY) {
			register int	nData	= (int) cbData ;
			
			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < nData && i < SIZE_MYKEYMAP ; i ++) {
				if (rbyKeyMap [i] >= NUM_FUNCTIONS) {
					pDoc->_rbyJMap [i]	= FUNCNO_INVALID_CHAR ;
				} else {
					pDoc->_rbyJMap [i]	= rbyKeyMap [i] ;
				}
			}
			for (i = SIZE_MYKEYMAP ; i < SIZE_IMEDOC_KEYMAP ; i ++)
				pDoc->_rbyJMap [i]	= g_rDefinitionOfDefaultJMap [i] ;
			fFoundNormalMap	= TRUE ;
		}
		/*	j-abbrev-map ���̏����B*/
		cbData	= sizeof (rbyKeyMap) ;
		if (RegQueryValueExW (hSubKey, REGSUBKEYW_JABBREVMAP, NULL, &dwType, rbyKeyMap, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY) {
			register int	nData	= (int) cbData ;
			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < nData && i < SIZE_MYKEYMAP ; i ++) {
				if (rbyKeyMap [i] >= NUM_FUNCTIONS) {
					pDoc->_rbyAbbrevMap [i]	= FUNCNO_INVALID_CHAR ;
				} else {
					pDoc->_rbyAbbrevMap [i]	= rbyKeyMap [i] ;
				}
			}
			for (i = SIZE_MYKEYMAP ; i < SIZE_IMEDOC_KEYMAP ; i ++)
				pDoc->_rbyAbbrevMap [i]	= g_rDefinitionOfDefaultAbbrevMap [i] ;
			fFoundAbbrevMap	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
#endif
	pDoc->_pbyJMap		= (fFoundNormalMap)? pDoc->_rbyJMap : g_rDefinitionOfDefaultJMap ;
	pDoc->_pbyAbbrevMap	= (fFoundAbbrevMap)? pDoc->_rbyAbbrevMap : g_rDefinitionOfDefaultAbbrevMap ;
	return	TRUE ;

}

BOOL
imeDoc_InitRomaKanaTable (
	register CImeDoc*		pDoc)
{
	register int	i ;

	for (i = 0 ; i < NELEMENTS (pDoc->_rpRomaKanaTable) ; i ++) {
		pDoc->_rpRomaKanaTable [i]	= TRomaKanaTable_Create (i) ;
		if (pDoc->_rpRomaKanaTable [i] == NULL)
			return	FALSE ;
	}
	return	TRUE ;
}

BOOL
imeDoc_InitJAssocRule (
	register CImeDoc*		pDoc)
{
	static	LPCWSTR		srDefaultAssocRule [][4] = {
		{	TEXT ("nn"),	NULL,	TEXT ("��"),	TEXT ("��") },
		{	TEXT ("n'"),	NULL,	TEXT ("��"),	TEXT ("��") },
	} ;
	register LPCWSTR		(*pSrc)[4] ;
	register int			nIndex, i ;
	HKEY			hSubKey ;
	WCHAR			szRegPathInfo [MAX_PATH] ;
	WCHAR			rbyData [MAX_REGVALUE_SIZE] ;
	DWORD			dwRegPathInfo, dwType, cbData ;
	register LONG	lResult ;
	register BOOL	fError	= FALSE ;

#if !defined (NO_TOUCH_REGISTRY)
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATHW_ROMAKANARULELIST, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		/*	���[�}�������ϊ��e�[�u�����o�^����Ă���̂Ȃ�c�B*/
		for (nIndex = 0 ; nIndex < MAXASSOCRULE ; nIndex ++) {
			register int		nStateLen, nNextLen, nHoutputLen, nKoutputLen ;
			
			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= NELEMENTS (rbyData) ;
			lResult	= RegEnumValueW (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			
			/*	szRegPathInfo = "nn" �̂悤�� szRegPathInfo ���u����ԁv�ɑ�������B
			 *	���R�� (�����, �����, �o��) �Ȃ̂ŁA����Ԃ������d�Ȃ邱�Ƃ͂���
			 *	�Ă͂Ȃ�Ȃ�����B
			 *	����Ԃ��u��v�͂��蓾��B
			 *
			 *	szRegPathInfo �� case �̋�ʂ��Ȃ��c�Bcase �̋�ʂ����邽�߂ɂ�
			 *	(�����) �̏��� MULTI_SZ �̒��Ɋ܂߂Ȃ���΂Ȃ�Ȃ��B
			 *	(Mon Jan 23 13:31:47 2006)
			 *	���Atraditional �Ȑݒ���ʂɎ����Ă���l�͂���������Ǝv����
			 *	�̂ŁA�����ǂ߂�悤�ɂ���B
			 */
			lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ)
				continue ;
			/*	Too big value. */
			if (cbData >= sizeof (rbyData))
				continue ;
			cbData		= sizeof (rbyData) ;
			(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE *)rbyData, &cbData) ;
			
			nKoutputLen	= 0 ;
			if (TEXT ('1') <= szRegPathInfo [0] && szRegPathInfo [0] <= TEXT ('9')) {
				nStateLen	= lstrlenW (rbyData) ;
				nNextLen	= (nStateLen   > 0)? lstrlenW (rbyData + nStateLen + 1) : 0 ;
				nHoutputLen	= (nNextLen    > 0)? lstrlenW (rbyData + nStateLen + 1 + nNextLen + 1) : 0 ;
				if (nStateLen <= 0 || nNextLen < 1 || nHoutputLen < 1) {
					fError	= TRUE ;
					break ;
				}
				/*	nKoutputLen == 0 �̏ꍇ�ɂ́A�]���� assoc rule �̉\��������B
				 *	�]���� (next, hira, kata) �� 3 ���������Acase ���l������
				 *	(now, next, hira, kata) �� 4 �g�ɂ����̂ŁB
				 */
				nKoutputLen	= (nHoutputLen > 0)? lstrlenW (rbyData + nStateLen + 1 + nNextLen + 1 + nHoutputLen + 1) : 0 ;
			}
			if (nKoutputLen <= 0) {
				nStateLen	= lstrlenW (szRegPathInfo) ;
				nNextLen	= lstrlenW (rbyData) ;
				nHoutputLen	= (nNextLen    > 0)? lstrlenW (rbyData + nNextLen + 1) : 0 ;
				nKoutputLen	= (nHoutputLen > 0)? lstrlenW (rbyData + nNextLen + 1 + nHoutputLen + 1) : 0 ;
			}
			if (nStateLen <= 0 || nNextLen < 1 || nHoutputLen < 1 || nKoutputLen < 1) {
				fError	= TRUE ;
				break ;
			}
		}
		pDoc->_nAssocRule	= nIndex ;
		pDoc->_rpAssocRule	= (CTAssocRule **)MALLOC (sizeof (CTAssocRule*) * pDoc->_nAssocRule) ;
		for (i = 0 ; i < nIndex ; i ++) {
			register LPCWSTR	wstrState, wstrNext, wstrHiragana, wstrKatakana ;
			
			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= sizeof (rbyData) ;
			lResult	= RegEnumValueW (hSubKey, (DWORD)i, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			
			/*	szRegPathInfo = "nn" �̂悤�� szRegPathInfo ���u����ԁv�ɑ�������B
			 *	���R�� (�����, �����, �o��) �Ȃ̂ŁA����Ԃ������d�Ȃ邱�Ƃ͂���
			 *	�Ă͂Ȃ�Ȃ�����B
			 *	����Ԃ��u��v�͂��蓾��B
			 */
			lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ)
				continue ;
			/*	Too big value. */
			if (cbData >= sizeof (rbyData)) 
				continue ;
			cbData		= sizeof (rbyData) ;
			(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE *)rbyData, &cbData) ;
			
			if (TEXT ('1') <= szRegPathInfo [0] && szRegPathInfo [0] <= TEXT ('9')) {
				wstrState		= rbyData ;
				wstrNext		= wstrState		+ lstrlenW (wstrState)		+ 1 ;
				wstrHiragana	= wstrNext		+ lstrlenW (wstrNext)		+ 1 ;
				wstrKatakana	= wstrHiragana	+ lstrlenW (wstrHiragana)	+ 1 ;
				if (*wstrKatakana == L'\0') {
					/* traditional �ȏ󋵂ł���Ɖ��߂���B*/
					wstrKatakana	= wstrHiragana ;
					wstrHiragana	= wstrNext ;
					wstrNext		= wstrState ;
					wstrState		= szRegPathInfo ;
				}
			} else {
				wstrState		= szRegPathInfo ;
				wstrNext		= rbyData ;
				wstrHiragana	= wstrNext		+ lstrlenW (wstrNext)		+ 1 ;
				wstrKatakana	= wstrHiragana	+ lstrlenW (wstrHiragana)	+ 1 ;
			}
			/* ���� (state) ����ʂ��������ǁc�B*/
			pDoc->_rpAssocRule [i]	= TAssocRule_Create (wstrState, wstrNext + 1, wstrKatakana + 1, wstrHiragana + 1) ;
		}
		RegCloseKey (hSubKey) ;
		return	! fError ;
	}
#endif	
	/*	����� default �̏������̂݁B��ł�����Ɛݒ��ǂނ悤�ɂ�
	 *	�Ȃ���΂Ȃ�Ȃ��B
	 */
	pDoc->_nAssocRule	= NELEMENTS (srDefaultAssocRule) ;
	pDoc->_rpAssocRule	= (CTAssocRule**)MALLOC (sizeof (CTAssocRule*) * pDoc->_nAssocRule) ;
	if (pDoc->_rpAssocRule == NULL) {
		pDoc->_nAssocRule	= 0 ;
		return	FALSE ;
	}
	pSrc	= srDefaultAssocRule ;
	for (i = 0 ; i < NELEMENTS (srDefaultAssocRule) ; i ++) {
		pDoc->_rpAssocRule [i]	= TAssocRule_Create ((*pSrc)[0], (*pSrc)[1], (*pSrc)[2], (*pSrc)[3]) ;
		pSrc ++ ;
	}
	return	TRUE ;
}

BOOL
imeDoc_InitPrefixList (
	register CImeDoc*		pDoc)
{
	HKEY						hSubKey ;
	register BOOL				fRetval	= TRUE ;
	WCHAR						rbyData [MAX_REGVALUE_SIZE] ;
	register int				nPrefix, nLength ;

	pDoc->_pstrPrefixList	= NULL ;
#if !defined (NO_TOUCH_REGISTRY)
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATHW_PREFIXLIST, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		register LONG		lResult ;
		register LPCWSTR	pPrefix ;
		DWORD				cbData, dwType ;
		
		lResult = RegQueryValueExW (hSubKey, NULL, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ || cbData >= sizeof (rbyData)) {
			fRetval	= FALSE ;
			goto	exit_regopen ;
		}
		
		/*	cbData �ɂ͕K�v�ʂ����ɓ����Ă���̂ŁA��������̂܂܎g���B*/
		cbData	= sizeof (rbyData) ;
		(void) RegQueryValueExW (hSubKey, NULL, NULL, NULL, (BYTE *)rbyData, &cbData) ;
		
		/*	parse ����B*/
		pPrefix	= rbyData ;
		nLength	= 0 ;
		while (nPrefix = wcslen (pPrefix), nPrefix > 0) {
			if (nPrefix < MAX_LENGTH_KANAPREFIX) {
				nLength		+= (nPrefix + 1) ;
				/*	pPrefix, nPrefix */
			}
			pPrefix			+= (nPrefix + 1) ;
		}
		pDoc->_pstrPrefixList	= (LPWSTR)MALLOC (sizeof (WCHAR) * (nLength + 1)) ;
		if (pDoc->_pstrPrefixList != NULL) {
			memcpy (pDoc->_pstrPrefixList, rbyData, nLength * sizeof (WCHAR)) ;
			pDoc->_pstrPrefixList [nLength]	= L'\0' ;
		} else {
			fRetval	= FALSE ;
		}
	  exit_regopen:
		RegCloseKey (hSubKey) ;
	}
#endif
	return	fRetval ;
}

BOOL
imeDoc_InitInputVector (
	register CImeDoc*		pDoc)
{
	static	const struct {
		WCHAR	_wch ;
		LPCWSTR	_wstr ;
	}	srSkkinputDefaultInputVector []	= {
		{ L'!',	L"�I", },	{ L',',	L"�A", },
		{ L'-',	L"�[", },	{ L'.',	L"�B", },
		{ L':',	L"�F", },	{ L';',	L"�G", },
		{ L'?',	L"�H", },	{ L'[',	L"�u", },
		{ L']',	L"�v", },
	} ;
	register int		nIndex, i ;
	register LPWSTR		pDest ;
	register LPCWSTR	wptr ;
	HKEY				hSubKey ;
	WCHAR				szRegPathInfo [MAX_PATH] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	long				lValue ;
	register LONG		lResult ;


	for (i = 0 ; i < INPUTVECTORSIZE ; i++)
		pDoc->_rstrInputVector [i]	= NULL ;

#if !defined (NO_TOUCH_REGISTRY)
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATHW_INPUTVECTOR, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		for (nIndex = 0 ; ; nIndex ++) {
			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= 0 ;
			lResult	= RegEnumValueW (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS)
				continue ;
			/* ���傷����f�[�^�͎̂Ă�B*/
			if (dwType != REG_SZ) 
				continue ;
			/* vector[����] = �f�[�^ �Ƃ������B������ SPACE �ȉ��͐ݒ肵�Ȃ��B*/
			lValue	= _wtol (szRegPathInfo) ;
			if (lValue < 32 || lValue >= (INPUTVECTORSIZE + 32))
				continue ;
			
			pDest	= (LPWSTR) MALLOC (cbData) ;
			if (pDest != NULL) {
				(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE*)pDest, &cbData) ;
				pDoc->_rstrInputVector [lValue - 32]	= pDest ;
			}
		}
		RegCloseKey (hSubKey) ;
		return	TRUE ;
	}
#endif
	for (i = 0 ; i < NELEMENTS (srSkkinputDefaultInputVector) ; i ++) {
		nIndex	= (int) srSkkinputDefaultInputVector [i]._wch - 32 ;
		ASSERT (0 <= nIndex && nIndex < INPUTVECTORSIZE) ;
		wptr	= srSkkinputDefaultInputVector [i]._wstr ;
		pDoc->_rstrInputVector [nIndex]	= (LPWSTR)MALLOC (sizeof (WCHAR) * (lstrlenW (wptr) + 1)) ;
		if (pDoc->_rstrInputVector [nIndex] != NULL)
			lstrcpyW (pDoc->_rstrInputVector [nIndex], wptr) ;
	}
	return	TRUE ;
}

BOOL
imeDoc_InitZenkakuVector (
	register CImeDoc*		pDoc)
{
	static	const struct {
		WCHAR		_wch ;
		LPCWSTR		_wstr ;
	}	srSkkinputDefaultZenkakuVector []	= {
		{ 0x20,	L"�@", },	{ 0x21,	L"�I", },	{ 0x22,	L"�h", },	{ 0x23,	L"��", },
		{ 0x24,	L"��", },	{ 0x25,	L"��", },	{ 0x26,	L"��", },	{ 0x27,	L"�f", },
		{ 0x28,	L"�i", },	{ 0x29,	L"�j", },	{ 0x2A,	L"��", },	{ 0x2B,	L"�{", },
		{ 0x2C,	L"�C", },	{ 0x2D,	L"�|", },	{ 0x2E,	L"�D", },	{ 0x2F,	L"�^", },
		{ 0x30,	L"�O", },	{ 0x31,	L"�P", },	{ 0x32,	L"�Q", },	{ 0x33,	L"�R", },
		{ 0x34, L"�S", },	{ 0x35,	L"�T", },	{ 0x36,	L"�U", },	{ 0x37,	L"�V", }, 
		{ 0x38, L"�W", },	{ 0x39,	L"�X", },	{ 0x3A,	L"�F", },	{ 0x3B,	L"�G", },
		{ 0x3C, L"��", },	{ 0x3D,	L"��", },	{ 0x3E,	L"��", },	{ 0x3F,	L"�H", },
		{ 0x40, L"��", },	{ 0x41,	L"�`", },	{ 0x42,	L"�a", },	{ 0x43,	L"�b", },
		{ 0x44, L"�c", },	{ 0x45,	L"�d", },	{ 0x46,	L"�e", },	{ 0x47,	L"�f", },
		{ 0x48, L"�g", },	{ 0x49,	L"�h", },	{ 0x4A,	L"�i", },	{ 0x4B,	L"�j", },
		{ 0x4C, L"�k", },	{ 0x4D,	L"�l", },	{ 0x4E,	L"�m", },	{ 0x4F,	L"�n", }, 
		{ 0x50, L"�o", },	{ 0x51,	L"�p", },	{ 0x52,	L"�q", },	{ 0x53,	L"�r", },
		{ 0x54, L"�s", },	{ 0x55,	L"�t", },	{ 0x56,	L"�u", },	{ 0x57,	L"�v", },  
		{ 0x58, L"�w", },	{ 0x59,	L"�x", },	{ 0x5A,	L"�y", },	{ 0x5B,	L"�m", },
		{ 0x5C, L"�_", },	{ 0x5D,	L"�n", },	{ 0x5E,	L"�O", },	{ 0x5F,	L"�Q", },  
		{ 0x60, L"�e", },	{ 0x61,	L"��", },	{ 0x62,	L"��", },	{ 0x63,	L"��", },
		{ 0x64, L"��", },	{ 0x65,	L"��", },	{ 0x66,	L"��", },	{ 0x67,	L"��", },  
		{ 0x68, L"��", },	{ 0x69,	L"��", },	{ 0x6A,	L"��", },	{ 0x6B,	L"��", },
		{ 0x6C, L"��", },	{ 0x6D,	L"��", },	{ 0x6E,	L"��", },	{ 0x6F,	L"��", },  
		{ 0x70, L"��", },	{ 0x71,	L"��", },	{ 0x72,	L"��", },	{ 0x73,	L"��", },
		{ 0x74, L"��", },	{ 0x75,	L"��", },	{ 0x76,	L"��", },	{ 0x77,	L"��", },  
		{ 0x78, L"��", },	{ 0x79,	L"��", },	{ 0x7A,	L"��", },	{ 0x7B,	L"�o", },
		{ 0x7C, L"�b", },	{ 0x7D,	L"�p", },	{ 0x7E,	L"�`", },
	} ;
	register int		nIndex, i ;
	register LPCWSTR	wptr ;
	HKEY				hSubKey ;
	WCHAR				szRegPathInfo [MAX_PATH] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	long				lValue ;
	register LONG		lResult ;
	register LPWSTR		pDest ;

	for (i = 0 ; i < INPUTVECTORSIZE ; i++)
		pDoc->_rstrZenkakuVector [i]	= NULL ;
	
#if !defined (NO_TOUCH_REGISTRY)
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATHW_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		for (nIndex = 0 ; ; nIndex ++) {
			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= 0 ;
			lResult	= RegEnumValueW (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS)
				continue ;
			/* ���傷����f�[�^�͎̂Ă�B*/
			if (dwType != REG_SZ) 
				continue ;
			/* vector[����] = �f�[�^ �Ƃ������B������ SPACE �ȉ��͐ݒ肵�Ȃ��B*/
			lValue	= _wtol (szRegPathInfo) ;
			if (lValue < 32 || lValue >= (INPUTVECTORSIZE + 32))
				continue ;
			
			pDest	= (LPWSTR)MALLOC (cbData) ;
			if (pDest != NULL) {
				(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE*)pDest, &cbData) ;
				pDoc->_rstrZenkakuVector [lValue - 32]	= pDest ;
			}
		}
		RegCloseKey (hSubKey) ;
		return	TRUE ;
	}
#endif
	for (i = 0 ; i < NELEMENTS (srSkkinputDefaultZenkakuVector) ; i ++) {
		nIndex	= (int) srSkkinputDefaultZenkakuVector [i]._wch - 32 ;
		ASSERT (0 <= nIndex && nIndex < INPUTVECTORSIZE) ;
		wptr	= srSkkinputDefaultZenkakuVector [i]._wstr ;
		pDoc->_rstrZenkakuVector [nIndex]	= (LPWSTR)MALLOC (sizeof (WCHAR) * (lstrlenW (wptr) + 1)) ;
		if (pDoc->_rstrZenkakuVector [nIndex] != NULL)
			lstrcpyW (pDoc->_rstrZenkakuVector [nIndex], wptr) ;
	}
	return	TRUE ;
}

BOOL
imeDoc_InitCandidateSelectKey (
	register CImeDoc*		pDoc)
{
#if defined (UNITTEST)
	static	BYTE	srDefaultJHenkanShowCandidateKeys []	= {
		'a', 's', 'd', 'f', 'j', 'k', 'l'
	} ;
	static	BYTE	srDefaultJInputByCodeOrMenuKeys1 []		= {
		'a', 's', 'd', 'f', 'g', 'h', 'q', 'w', 'e', 'r', 't', 'y'
	} ;
	static	BYTE	srDefaultJInputByCodeOrMenuKeys2 []		= {
		'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'q', 'w', 'e', 'r', 't', 'y', 'u'
	} ;
	HKEY	hSubKey ;
	BOOL	fInitJHenkanShowCandidateKeys	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys1	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys2	= FALSE ;
	DWORD	dwType, cbData ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATHW_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
				cbData == NUM_JHENKAN_SHOW_CANDIDATE_KEYS) {
			cbData	= NUM_JHENKAN_SHOW_CANDIDATE_KEYS ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, pDoc->_JHenkanShowCandidateKeys, &cbData) ;
			fInitJHenkanShowCandidateKeys	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, pDoc->_JInputByCodeOrMenuKeys1, &cbData) ;
			fInitJInputByCodeOrMenuKeys1	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, pDoc->_JInputByCodeOrMenuKeys2, &cbData) ;
			fInitJInputByCodeOrMenuKeys2	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! fInitJHenkanShowCandidateKeys)
		memcpy (pDoc->_JHenkanShowCandidateKeys, srDefaultJHenkanShowCandidateKeys, NUM_JHENKAN_SHOW_CANDIDATE_KEYS) ;
	if (! fInitJInputByCodeOrMenuKeys1)
		memcpy (pDoc->_JInputByCodeOrMenuKeys1, srDefaultJInputByCodeOrMenuKeys1, NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) ;
	if (! fInitJInputByCodeOrMenuKeys2)
		memcpy (pDoc->_JInputByCodeOrMenuKeys2, srDefaultJInputByCodeOrMenuKeys2, NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) ;
#endif
	return	TRUE ;
}

CImeBuffer*
imeDoc_CreateBuffer (
	register CImeDoc*		pDoc,
	register LPCWSTR		wstrMessage,
	register int			nstrMessage,
	register CTRecursiveEditSession*	pSession)
{
	register CImeBuffer*	pBuffer ;
	register int			nIndex ;
	register BOOL			fInc ;

	ASSERT (pDoc != NULL) ;

	/*	����ȏ�ċA�ł��Ȃ����H */
	if (pDoc->_nBuffer >= MAXIMEBUFFER) {
		for (nIndex = 0 ; nIndex < MAXIMEBUFFER ; nIndex ++)
			if (pDoc->_rpBuffer [nIndex] == NULL)
				break ;
		if (nIndex >= MAXIMEBUFFER)
			return	NULL ;
		fInc	= FALSE ;
	} else {
		nIndex	= pDoc->_nBuffer ;
		fInc	= TRUE ;
	}
	pBuffer	= ImeBuffer_Create (pDoc) ;
	if (pBuffer == NULL) 
		return	NULL ;
	if (! ImeBuffer_InitEx (pBuffer, wstrMessage, nstrMessage, pSession)) {
		FREE (pBuffer) ;
		return	NULL ;
	}
	pDoc->_rpBuffer [nIndex]	= pBuffer ;
	if (fInc)
		pDoc->_nBuffer	++ ;
	return	pBuffer ;
}

BOOL
imeDoc_DeleteUnusedBuffer (
	register CImeDoc*		pDoc)
{
	register int	i ;

	ASSERT (pDoc != NULL) ;

	for (i = 0 ; i < pDoc->_nUnusedBuffer ; i ++) {
		FREE (pDoc->_rpUnusedBuffer [i]) ;
		pDoc->_rpUnusedBuffer [i]	= NULL ;
	}
	pDoc->_nUnusedBuffer	= 0 ;
	for (i = pDoc->_nBuffer - 1 ; i >= 0 && pDoc->_rpBuffer [i] == NULL ; i --) 
		;
	pDoc->_nBuffer	= i + 1 ;
	return	TRUE ;
}

BOOL
imeDoc_InitBuffer (
	register CImeDoc*		pDoc)
{
	register CImeBuffer*	pBuffer ;

	pBuffer	= imeDoc_CreateBuffer (pDoc, NULL, 0, NULL) ;
	if (pBuffer == NULL)
		return	FALSE ;
	pDoc->_pCurBuffer	= pBuffer ;
	return	TRUE ;
}

void
imeDoc_UninitBuffer (
	register CImeDoc*		pDoc)
{
	register int	i ;

	/*	�o�b�t�@�����͏�����Ԃɖ߂��B
	 */
	for (i = 0 ; i < pDoc->_nBuffer ; i ++) {
		/*	session close �ɂ��Ă͂܂��������s�����Ă���ȁB*/
		ImeBuffer_Uninit (pDoc->_rpBuffer [i]) ;
		FREE (pDoc->_rpBuffer [i]) ;
		pDoc->_rpBuffer [i]	= NULL ;
	}
	for (i = 0 ; i < pDoc->_nUnusedBuffer ; i ++) {
		ImeBuffer_Uninit (pDoc->_rpUnusedBuffer [i]) ;
		FREE (pDoc->_rpUnusedBuffer [i]) ;
		pDoc->_rpUnusedBuffer [i]	= NULL ;
	}
	pDoc->_nBuffer = pDoc->_nUnusedBuffer = 0 ;
	return ;
}

/*	WPARAM ���� WCHAR ���쐬����BWCHAR �ɕϊ����邽�߂� WIN32API ��
 *	ToAscii �𗘗p���Ă���B
 *	ToAscii �ŕϊ��ł��Ȃ������ɑ΂��ẮA�ꕔ�� VK_XXX �������E����
 *	128 �ȏ�̃R�[�h�����蓖�Ă邱�ƂƂ��Ă���B
 */
WCHAR
_GetCharFromWPARAM (
	register WPARAM			wParam)
{
	static BYTE	byKeyState [256] = { 0 } ;
	static const BYTE	rVKKeyTbl []	= {
		VK_LEFT,	VK_UP,		VK_DOWN,	VK_RIGHT,	VK_INSERT,
		VK_DELETE,	VK_BACK,	VK_TAB,		VK_HOME,	VK_SPACE,
		VK_ESCAPE,	VK_KANJI,	VK_HELP,	VK_F1,		VK_F2,
		VK_F3,		VK_F4,		VK_F5,		VK_F6,		VK_F7,
		VK_F8,		VK_F9,		VK_F10,		VK_F11,		VK_F12,
		VK_CLEAR,	VK_RETURN,
	} ;
	static const WORD	rSubSpecialKeyTbl []	= {
		MYVK_LBUTTON,	MYVK_RBUTTON,	MYVK_MENU1,		MYVK_MENU2,
		MYVK_MENU3,		MYVK_MENU4,		MYVK_CONVERT,	MYVK_OPENCANDIDATE,
		MYVK_REVERT,	MYVK_COMPLETE,	MYVK_CLOSECANDIDATE,
		MYVK_SELECTCANDIDATESTR,		MYVK_CHANGECANDIDATELIST,
		MYVK_SETCANDIDATEPAGESIZE,		MYVK_SETCANDIDATEPAGESTART,
	} ;
	WORD		rwCH [2] ;

	/*	�܂��͌��݂� keyboard �����āA�ϊ��ł��Ȃ������ǂ������`�F�b�N
	 *	����B
	 */
	if (wParam < 0x100) {
		byKeyState [VK_CONTROL]	= (BYTE)((GetKeyState (VK_CONTROL) & 0x0800)? 0x80 : 0) ;
		byKeyState [VK_SHIFT]	= (BYTE)((GetKeyState (VK_SHIFT)   & 0x0800)? 0x80 : 0) ;
		rwCH [0]	= 0 ;

		if (ToAscii (wParam, 0x80000000, byKeyState, rwCH, 0) == 0) {
			register const BYTE*	ptr ;
			register int			nIndex ;
			
			/*	�E���ׂ������ł��邩�ǂ����̔���B�S�Ă� VK_XXX ������K�v
			 *	�͂Ȃ��B
			 */
			ptr	= (const BYTE*)memchr (rVKKeyTbl, wParam & 0x00FF, NELEMENTS (rVKKeyTbl)) ;
			if (ptr == NULL) 
				return	(WCHAR)-1 ;	/* invalid char */

			nIndex	= (ptr - rVKKeyTbl) * 3 ;
			if (byKeyState [VK_CONTROL] & 0x80) {
				nIndex	++ ;
			} else if (byKeyState [VK_SHIFT] & 0x80) {
				nIndex	+= 2 ;
			}
			return	(WCHAR)(128 + nIndex) ;
		}
		/*	keyboard �����ĕϊ��ł����ꍇ�̏����B
		 */
		if (rwCH [0] == TEXT(' ') && (byKeyState [VK_CONTROL] & 0x80))
			rwCH [0]	= 0 ;
		return	rwCH [0] ;
	} else {
		register int	i ;

		/*	subspecial key �� hit ����\��������B*/
		for (i = 0 ; i < NELEMENTS (rSubSpecialKeyTbl) ; i ++) {
			if (wParam == rSubSpecialKeyTbl [i])
				return	(WCHAR)(SIZE_MYKEYMAP + i) ;
		}
		return	(WCHAR)-1 ;
	}
}

WCHAR
_GetCharFromVKey (
	register CImeDoc*		pDoc,
	register UINT			vKey,
	register LPARAM			lKeyData,
	register CONST BYTE*	lpbKeyState)
{
	static const BYTE	rVKKeyTbl []	= {
		VK_LEFT,	VK_UP,		VK_DOWN,	VK_RIGHT,	VK_INSERT,
		VK_DELETE,	VK_BACK,	VK_TAB,		VK_HOME,	VK_SPACE,
		VK_ESCAPE,	VK_KANJI,	VK_HELP,	VK_F1,		VK_F2,
		VK_F3,		VK_F4,		VK_F5,		VK_F6,		VK_F7,
		VK_F8,		VK_F9,		VK_F10,		VK_F11,		VK_F12,
		VK_CLEAR,	VK_RETURN,
	} ;
	static const WORD	rSubSpecialKeyTbl []	= {
		MYVK_LBUTTON,	MYVK_RBUTTON,	MYVK_MENU1,		MYVK_MENU2,
		MYVK_MENU3,		MYVK_MENU4,		MYVK_CONVERT,	MYVK_OPENCANDIDATE,
		MYVK_REVERT,	MYVK_COMPLETE,	MYVK_CLOSECANDIDATE,
		MYVK_SELECTCANDIDATESTR,		MYVK_CHANGECANDIDATELIST,
		MYVK_SETCANDIDATEPAGESIZE,		MYVK_SETCANDIDATEPAGESTART,
	} ;

	if (vKey < 0x100) {
		WORD					rwCH [2] ;
		register const BYTE*	ptr ;
		register int			nIndex ;
		int						nFuncNo ;

		rwCH [0]	= 0 ;
		if (ToAscii (vKey, 0x80000000, lpbKeyState, rwCH, 0) == 0) {
			rwCH [0]	= (WCHAR)-1 ;
		} else {
			/*	keyboard �����ĕϊ��ł����ꍇ�̏����B
			 */
			if (rwCH [0] == TEXT(' ') && (lpbKeyState [VK_CONTROL] & 0x80))
				rwCH [0]	= 0 ;
		}
		/*	�E���ׂ������ł��邩�ǂ����̔���B�S�Ă� VK_XXX ������K�v
		 *	�͂Ȃ��B
		 */
		ptr	= (const BYTE*)memchr (rVKKeyTbl, vKey, NELEMENTS (rVKKeyTbl)) ;
		if (ptr == NULL) 
			return	rwCH [0] ;

		nIndex	= (ptr - rVKKeyTbl) * 3 ;
		if (lpbKeyState [VK_CONTROL] & 0x80) {
			nIndex	++ ;
		} else if (lpbKeyState [VK_SHIFT] & 0x80) {
			nIndex	+= 2 ;
		}
		/*	
		 */
		if (! ImeDoc_LookupKeymap (pDoc, (WCHAR)(128 + nIndex), &nFuncNo) ||
			nFuncNo == FUNCNO_INVALID_CHAR) {
			return	rwCH [0] ;
		}
		return	(WCHAR)(128 + nIndex) ;
	} else {
		register int	i ;

		/*	subspecial key �� hit ����\��������B*/
		for (i = 0 ; i < NELEMENTS (rSubSpecialKeyTbl) ; i ++) {
			if (vKey == rSubSpecialKeyTbl [i])
				return	(WCHAR)(SIZE_MYKEYMAP + i) ;
		}
		return	(WCHAR)-1 ;
	}
}

/*========================================================================
 */
BOOL
imeDoc_updateCandidateInfoForStatusText (
	register CImeDoc*		pDoc)
{
	TVarbuffer*		pvbufMessageInfo ;
	LPMYCAND		pMyCand ;
	LPCANDIDATEINFO	pCandInfo ;
	LPCANDIDATELIST	pCandList ;
	LPMYSTR			pCandidateStr ;
	DWORD*			pCandidateOffset ;
	int				nText ;
	DWORD			dwSize ;
	LPWSTR			pwDest ;

	ASSERT (pDoc != NULL && pDoc->_nBuffer > 0 && pDoc->_rpBuffer [0] != NULL) ;
	ASSERT (pnLength != NULL) ;
	ASSERT (pnCursor != NULL) ;

	pvbufMessageInfo	= ImeDoc_GetMessageInfoBuffer (pDoc) ;
	if (pvbufMessageInfo == NULL)
		return	FALSE ;

	dwSize	= sizeof (MYCAND) + sizeof (DWORD) * 1 ;
	if (pDoc->_rpBuffer [0] != pDoc->_pCurBuffer) {
		LPCWSTR	pwText ;
		int		iLength, iCursor ;

		/*	Message ���������ꍇ�ɂ͐擪�Ɂu�I�v��ǉ����������c�B
		 *	���ƁA���O�� StatusLine ���`��ł��Ȃ��ꍇ�ɁA�J�[�\�����Ӗ�����
		 *	���������Ă��������B``|'' �ŗǂ����B
		 */
		pwText	= ImeBuffer_GetText (pDoc->_pCurBuffer, &iLength) ;
		iCursor	= ImeBuffer_GetCursorPosition (pDoc->_pCurBuffer) ;

		if (pDoc->_nbufMessage > 0) {
			/*	���́u�I�v�̒ǉ��̂��߂� minibuffer text �� region �I��������Ă�
			 *	�܂��B
			 */
			nText	= iLength + 1/*``�I''�̕�*/ + 1/*``|''�̕�*/ + 1/*nul�̕�*/ ; 
		} else {
			nText	= iLength + 1/*``|''�̕�*/ + 1/*nul�̕�*/ ;  
		}
		dwSize	+= sizeof (MYCHAR) * nText ;
		TVarbuffer_Clear (pvbufMessageInfo) ;
		if (! TVarbuffer_Require (pvbufMessageInfo, dwSize))
			return	FALSE ;

		pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufMessageInfo) ;
		pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
		pCandInfo->dwSize		= dwSize ;
		pCandInfo->dwCount		= 1 ;
		pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
		pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
		pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * 1 + sizeof (MYCHAR) * nText ;
		pCandList->dwStyle		= IME_CAND_UNKNOWN ;
		pCandList->dwCount		= 1 ;
		pCandList->dwPageSize	= 1 ;
		pCandList->dwSelection	= 0 ;
		pCandList->dwPageStart	= 0 ;
		pCandidateStr			= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * 1) ;
		pCandidateOffset		= pCandList->dwOffset ;
		pCandidateOffset [0]	= (DWORD)((LPSTR)pCandidateStr - (LPSTR)pCandList) ;

		pwDest		= pCandidateStr ;
		if (pDoc->_nbufMessage > 0) {
			*pwDest ++	= L'�I' ;
		}
		if (0 < iCursor) {
			memcpy (pwDest, pwText, iCursor * sizeof (WCHAR)) ;
			pwDest	+= iCursor ;
		}
		*pwDest ++	= L'|' ;
		if (iCursor < iLength) {
			memcpy (pwDest, pwText + iCursor, (iLength - iCursor) * sizeof (WCHAR)) ;
			pwDest	+= (iLength - iCursor) ;
		}
		*pwDest = L'\0' ;
	} else {
		nText	= pDoc->_nbufMessage + 1 ;

		dwSize	+= sizeof (MYCHAR) * nText ;
		TVarbuffer_Clear (pvbufMessageInfo) ;
		if (! TVarbuffer_Require (pvbufMessageInfo, dwSize))
			return	FALSE ;

		pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufMessageInfo) ;
		pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
		pCandInfo->dwSize		= dwSize ;
		pCandInfo->dwCount		= 1 ;
		pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
		pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
		pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * 1 + sizeof (MYCHAR) * nText ;
		pCandList->dwStyle		= IME_CAND_UNKNOWN ;
		pCandList->dwCount		= 1 ;
		pCandList->dwPageSize	= 1 ;
		pCandList->dwSelection	= 0 ;
		pCandList->dwPageStart	= 0 ;
		pCandidateStr			= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * 1) ;
		pCandidateOffset		= pCandList->dwOffset ;
		pCandidateOffset [0]	= (DWORD)((LPSTR)pCandidateStr - (LPSTR)pCandList) ;

		memcpy (pCandidateStr, pDoc->_bufMessage, sizeof (WCHAR) * pDoc->_nbufMessage) ;
		pCandidateStr [pDoc->_nbufMessage]	= L'\0' ;
	}
	return	TRUE ;
}

