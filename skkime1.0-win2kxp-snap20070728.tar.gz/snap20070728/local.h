#pragma once

#if defined (UNITTEST)
#include <windows.h>
#include <wchar.h>
#include <tchar.h>
#include <assert.h>
#include <shlwapi.h>

#define	ASSERT(x)			assert((x))
#if !defined (NELEMENTS)
#define	NELEMENTS(array)	(sizeof (array) / sizeof (array[0]))
#endif
#if defined (DEBUG)
#include "debug.h"
#define	DEBUGPRINTF(arg)	DebugPrintf##arg
#define	DEBUGPRINTFW(arg)	DebugPrintfW##arg
#else
#define	DEBUGPRINTF(arg)	/*arg*/
#define	DEBUGPRINTFW(arg)	/*arg*/
#endif
#define	MALLOC(size)		malloc((size))
#define	FREE(ptr)			free((ptr))

#else

#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include <shlwapi.h>

#define	MALLOC(size)		HeapAlloc(GetProcessHeap(), 0, (size))
#define	FREE(ptr)			HeapFree(GetProcessHeap(), 0, (ptr))
#if !defined (NELEMENTS)
#define	NELEMENTS(array)	(sizeof (array) / sizeof (array[0]))
#endif
#endif



