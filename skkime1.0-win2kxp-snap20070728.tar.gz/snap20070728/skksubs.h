#if ! defined (skksubs_h)
#define	skksubs_h

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ImeBuffer.h"
#include "ImeDoc.h"

/* skksubs.c */
BOOL	PASCAL		SKKInitPrivate			(LPINPUTCONTEXT) ;
BOOL	PASCAL		SKKClearPrivate			(LPINPUTCONTEXT) ;
BOOL	PASCAL		SKKIsInitPrivate		(LPINPUTCONTEXT) ;
BOOL	PASCAL		SKKIsCompStr 			(HIMC) ;
BOOL	PASCAL		SKKSetConversionMode	(HIMC, DWORD) ;
DWORD	PASCAL		SKKGetConversionMode	(HIMC) ;
BOOL	PASCAL		SKKUpdateConversionMode	(HIMC) ;
void	PASCAL		SKKUpdateConfig			(HIMC, BOOL) ;
BOOL	PASCAL		SKKNotifyChangeConversionMode	(HIMC) ;
BOOL				SKKCompleteString		(HIMC, LPINPUTCONTEXT) ;
BOOL				SKKConvertString		(HIMC, LPINPUTCONTEXT) ;
BOOL				SKKRevertString			(HIMC, LPINPUTCONTEXT) ;
BOOL				SKKOpenCandidate		(HIMC, LPINPUTCONTEXT) ;
BOOL				SKKSelectCandidateStr	(HIMC, LPINPUTCONTEXT, int) ;
BOOL				SKKSetCandidatePageStart(HIMC, LPINPUTCONTEXT, int) ;
int					SKKHasWordAnnotation	(LPCMYSTR, int) ;
int					SKKSetCursorPosition	(LPINPUTCONTEXT, int) ;
int					SKKSetRegionStartPoint	(LPINPUTCONTEXT) ;
int					SKKSetRegionEndPoint	(LPINPUTCONTEXT) ;
BOOL				SKKSetReconvertStr		(HIMC, LPINPUTCONTEXT, LPCOMPOSITIONSTRING, LPRECONVERTSTRING, BOOL) ;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

