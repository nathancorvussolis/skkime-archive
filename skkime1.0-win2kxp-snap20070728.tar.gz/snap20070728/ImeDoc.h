#if !defined (ImeDoc_h)
#define	ImeDoc_h

#include "common\keymap.h"
#include "TAssocRule.h"
#include "TRomaKanaTable.h"
#include "TRecursiveEditSession.h"
#include "varbuffer.h"

#define	MAXIMEBUFFER		(8)
#define	MAXROMAKANATABLE	(5)
#define	MAXUNREADEVENT		(4)
#define	MSGBUFSIZE			(256)
#define	INPUTVECTORSIZE		(128-32)

enum {
	GC_EGG_LIKE_NEWLINE	= 0,
	GC_DELETE_IMPLIES_KAKUTEI,
	GC_USE_NUMERIC_CONVERSION,
	GC_DABBREV_LIKE_COMPLETION,
	GC_KATAKANA_HIRAGANA_HENKAN,
	GC_STYLE,
	GC_DATE_AD,
	GC_SHOW_ANNOTATION,
	GC_KAKUTEI_EARLY,
	GC_PROCESS_OKURI_EARLY,
	GC_DELETE_OKURI_WHEN_QUIT,
	NUMGENERICCONFIG
} ;

enum {
	IMECMODE_HIRAGANA	= 0,
	IMECMODE_KATAKANA,
	IMECMODE_ZENKAKU,
	IMECMODE_HANKANA,
	IMECMODE_ASCII,
	IMECMODE_OFF,
} ;

enum {
	IMEKEYMAP_JMODE		= 0,
	IMEKEYMAP_ASCII,
	IMEKEYMAP_ZENKAKU,
	IMEKEYMAP_ABBREV,
} ;

struct tagCImeBuffer ;
struct tagCImeDoc ;
typedef struct tagCImeDoc	CImeDoc ;
struct _tagMYCAND ;

BOOL				ImeDoc_Init				(CImeDoc*) ;
void				ImeDoc_Clear			(CImeDoc*) ;
void				ImeDoc_Uninit			(CImeDoc*) ;
#if defined (UNITTEST)
BOOL				ImeDoc_QueryFilterKeyEvent	(CImeDoc*, WPARAM, BOOL, BOOL*) ;
BOOL				ImeDoc_QueryToggleIMEKeyEvent	(CImeDoc*, WPARAM, BOOL, BOOL*) ;
BOOL				ImeDoc_FilterKeyEvent		(CImeDoc*, WPARAM, BOOL*) ;
#else
BOOL				ImeDoc_QueryFilterKeyEvent	(CImeDoc*, UINT, LPARAM, CONST LPBYTE, BOOL*) ;
BOOL				ImeDoc_QueryToggleIMEKeyEvent	(CImeDoc*, UINT, LPARAM, CONST LPBYTE, BOOL*) ;
BOOL				ImeDoc_FilterKeyEvent		(CImeDoc*, UINT, LPARAM, CONST LPBYTE, BOOL*) ;
#endif
LPCWSTR				ImeDoc_GetPreeditText	(CImeDoc*, int*) ;
BOOL				ImeDoc_GetPreeditCursor	(CImeDoc*, int*) ;
#if defined (UNITTEST)
LPCWSTR				ImeDoc_GetStatusText	(CImeDoc*, int*) ;
#else
struct _tagMYCAND*	ImeDoc_GetStatusText	(CImeDoc*, DWORD*) ;
#endif
BOOL				ImeDoc_GetStatusCursor	(CImeDoc*, int*) ;
int					ImeDoc_GetReadingText	(CImeDoc*, LPWSTR, int, int*) ;
BOOL				ImeDoc_SetConversionMode(CImeDoc*, int) ;
int					ImeDoc_GetConversionMode(CImeDoc*) ;
BOOL				ImeDoc_SetConversionString	(CImeDoc*, LPCWSTR, int) ;
BOOL				ImeDoc_IsStatusActivep	(CImeDoc*) ;
BOOL				ImeDoc_GetSelectedRegion	(CImeDoc*, int*, int*) ;
BOOL				ImeDoc_QueryUpdateContext	(CImeDoc*, int*, int*, BOOL*) ;
BOOL				ImeDoc_UpdateContext	(CImeDoc*) ;
void				ImeDoc_UpdateConfig		(CImeDoc*) ;
#if !defined (UNITTEST)
void				ImeDoc_SetUpdateFlag	(CImeDoc*, unsigned int) ;
void				ImeDoc_ClearUpdateFlag	(CImeDoc*) ;
unsigned int		ImeDoc_GetUpdateFlag	(CImeDoc*) ;
BOOL				ImeDoc_RevertText		(CImeDoc*) ;
BOOL				ImeDoc_CompleteText		(CImeDoc*) ;
#endif
BOOL				ImeDoc_GetConvertedRegion	(CImeDoc*, int*, int*) ;
BOOL				ImeDoc_IsJHenkanShowCandidateModep	(CImeDoc*) ;
BOOL				ImeDoc_IsJInputByCodeOrMenuModep		(CImeDoc*) ;
BOOL				ImeDoc_DisableMinibufferp	(CImeDoc*) ;

int					ImeDoc_LookupKeymap		(CImeDoc*, int, int*) ;
struct tagCImeBuffer*	ImeDoc_GetCurrentBuffer	(CImeDoc*) ;
BOOL				ImeDoc_UnprocessChar	(CImeDoc*, int) ;
BOOL				ImeDoc_SetUnreadCommandChar	(CImeDoc*, int) ;
int					ImeDoc_GetLastCommandChar	(CImeDoc*) ;
BOOL				ImeDoc_SetLastCommandChar	(CImeDoc*, int) ;
#if !defined (UNITTEST)
LPARAM				ImeDoc_GetLastKeyData	(CImeDoc*) ;
#endif
int					ImeDoc_GetLastCommand	(CImeDoc*) ;
BOOL				ImeDoc_SetThisCommand	(CImeDoc*, int) ;
BOOL				ImeDoc_ReadFromMinibuffer	(CImeDoc*, LPCWSTR, int, CTRecursiveEditSession*) ;
BOOL				ImeDoc_ExitMinibuffer	(CImeDoc*, struct tagCImeBuffer*) ;
CTAssocRule*		ImeDoc_JAssocRule		(CImeDoc*, LPCWSTR, int) ;
BOOL				ImeDoc_IsValidPrefixp	(CImeDoc*, LPCWSTR, int) ;
BOOL				ImeDoc_SetMessageN		(CImeDoc*, LPCWSTR, int) ;
BOOL				ImeDoc_SetMessage		(CImeDoc*, LPCWSTR) ;
LPCWSTR				ImeDoc_GetMessage		(CImeDoc*, int*) ;
BOOL				ImeDoc_ClearMessage		(CImeDoc*) ;
LPCWSTR				ImeDoc_GetSkkInputVector	(CImeDoc*, int, int*) ;
LPCWSTR				ImeDoc_GetSkkZenkakuVector	(CImeDoc*, int, int*) ;
CTRomaKanaTable*	ImeDoc_GetRomaKana		(CImeDoc*, int) ;
BOOL				ImeDoc_IsSkkDabbrevLikeCompletion	(CImeDoc*) ;
BOOL				ImeDoc_IsSkkEggLikeNewlinep			(CImeDoc*) ;
BOOL				ImeDoc_IsSkkDeleteOkuriWhenQuitp	(CImeDoc*) ;
BOOL				ImeDoc_IsSkkProcessOkuriEarlyp		(CImeDoc*) ;
BOOL				ImeDoc_IsSkkKakuteiEarlyp			(CImeDoc*) ;
BOOL				ImeDoc_IsJKakuteiEarlyp				(CImeDoc*) ;
BOOL				ImeDoc_IsSkkDeleteImpliesKakuteip	(CImeDoc*) ;
BOOL				ImeDoc_IsSkkKatakanaHiraganaHenkanp	(CImeDoc*) ;
int					ImeDoc_GetSkkDateAd			(CImeDoc*) ;
int					ImeDoc_GetSkkNumberStyle	(CImeDoc*) ;
BOOL				ImeDoc_IsSkkShowAnnotationp	(CImeDoc*) ;
BOOL				ImeDoc_IsSkkUseNumericConversionp	(CImeDoc*) ;
const BYTE*			ImeDoc_GetJHenkanShowCandidateKeys	(CImeDoc*) ;
const BYTE*			ImeDoc_GetJInputByCodeOrMenuKeys1	(CImeDoc*) ;
const BYTE*			ImeDoc_GetJInputByCodeOrMenuKeys2	(CImeDoc*) ;

BOOL				ImeDoc_HaveMessagep		(CImeDoc*) ;
BOOL				ImeDoc_RecursiveEditp	(CImeDoc*) ;

TVarbuffer*			ImeDoc_GetCandidateInfoBuffer	(CImeDoc*) ;
TVarbuffer*			ImeDoc_GetMessageInfoBuffer		(CImeDoc*) ;

#endif

