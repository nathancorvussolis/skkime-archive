#if !defined (TRomaKanaTable_h)
#define	TRomaKanaTable_h

typedef struct tagCTRomaKanaTableEntry	CTRomaKanaTableEntry ;
typedef struct tagCTRomaKanaTable		CTRomaKanaTable ;

CTRomaKanaTable*		TRomaKanaTable_Create	(int) ;
void		TRomaKanaTable_Destroy (CTRomaKanaTable*) ;
CTRomaKanaTableEntry*	TRomaKanaTable_Lookup	(CTRomaKanaTable*, LPCWSTR, int) ;

LPCWSTR		TRomaKanaTableEntry_GetPrefix	(const CTRomaKanaTableEntry*) ;
LPCWSTR		TRomaKanaTableEntry_GetKatakana	(const CTRomaKanaTableEntry*) ;
LPCWSTR		TRomaKanaTableEntry_GetHiragana	(const CTRomaKanaTableEntry*) ;

#endif

