/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * ui.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "skksubs.h" 

/*
 *	�v���g�^�C�v�錾�B
 */
static	void	PASCAL	ShowUIWindows (HWND, BOOL) ;
static	LRESULT	PASCAL	OnImeSetContext (HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	OnImeSelect (HIMC, HWND, UINT, WPARAM, LPARAM) ;
#ifdef DEBUG
static	void	PASCAL	DumpUIExtra (LPUIEXTRA) ;
#endif

#define CS_SKKIME	(CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS | CS_IME)

/*************************************************************************
 *
 * IMERegisterClass()
 *
 * This function is called by IMMInquire.
 *	Register the classes for the child windows.
 *	Create global GDI objects.
 *
 *************************************************************************/
BOOL	PASCAL	IMERegisterClass (HANDLE hInstance)
{
	WNDCLASSEX wc ;

	/*
	 * register class of UI window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME ;
	wc.lpfnWndProc		= SKKIMEWndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= sizeof (LONG_PTR) * 2 ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPTSTR)NULL ;
	wc.lpszClassName	= (LPTSTR)g_szUIClassName ;
	wc.hbrBackground	= NULL ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	/*
	 * register class of composition window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME ;
	wc.lpfnWndProc		= UIComp_WndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UICOMP_EXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPTSTR)NULL ;
	wc.lpszClassName	= (LPTSTR)g_szCompStrClassName ;
	wc.hbrBackground	= NULL ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	/*
	 * register class of candidate window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME ;
	wc.lpfnWndProc		= UICand_WndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UICAND_EXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPTSTR)NULL ;
	wc.lpszClassName	= (LPTSTR)g_szCandClassName ;
	wc.hbrBackground	= (HBRUSH) (COLOR_WINDOW + 1) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return FALSE;

	/*
	 * register class of candidate window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME ;
	wc.lpfnWndProc		= UIAnnot_WndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UIANNOT_EXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPTSTR)NULL ;
	wc.lpszClassName	= (LPTSTR)g_szCandAnnotClassName ;
	wc.hbrBackground	= GetStockObject (LTGRAY_BRUSH) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return FALSE;

	/*
	 * register class of status window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME ;
	wc.lpfnWndProc		= UIStatus_WndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UISTATE_EXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPTSTR)NULL ;
	wc.lpszClassName	= (LPTSTR)g_szStatusClassName ;
	wc.hbrBackground	= GetSysColorBrush (COLOR_3DFACE) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	/*
	 * register class of guideline window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME ;
	wc.lpfnWndProc		= UIMinibuf_WndProc ;
	wc.cbClsExtra	 	= 0 ;
	wc.cbWndExtra	 	= UIMINIBUF_EXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPTSTR)NULL ;
	wc.lpszClassName	= (LPTSTR)g_szGuideClassName ;
	wc.hbrBackground	= (HBRUSH) (COLOR_WINDOW + 1) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	return	TRUE ;
}

/*************************************************************************
 *
 * SKKIME98WndProc()
 *
 * IME UI window procedure
 *
 *************************************************************************/
LRESULT	CALLBACK
SKKIMEWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HIMC			hUICurIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPUIEXTRA		lpUIExtra ;
	HGLOBAL			hUIExtra ;
	LONG			lRet		= 0L ;
	int				i ;
	MYLOGFONT		lf ;

    hUICurIMC	= (HIMC)GetWindowLongPtr (hWnd, IMMGWLP_IMC) ;

	/*
	 * Even if there is no current UI. these messages should not be pass to 
	 * DefWindowProc().
	 */
	if (!hUICurIMC){
		/*DEBUGPRINTF ((TEXT ("SKKIMEWndProc (!hUICurIMC) --enter\n"))) ;*/
		switch (message){
		case WM_IME_STARTCOMPOSITION:
		case WM_IME_ENDCOMPOSITION:
		case WM_IME_COMPOSITION:
		case WM_IME_CONTROL:
		case WM_IME_COMPOSITIONFULL:
		case WM_IME_SELECT:
		case WM_IME_CHAR:
			return	0L ;
			/*	Status Window �𑀍삷�邽�߂ɂ� WM_IME_NOTIFY �������ł��Ȃ���΂Ȃ�Ȃ��B
			 *	���̃R�[�h�����ǉ����ꂽ�̂́A
		case WM_IME_NOTIFY:
			return	OnUINotifyCommand (hUICurIMC, hWnd, message, wParam, lParam) ;
			 *	��̓I�ɂǂ̑���(�A�v���P�[�V����)���Ӑ}���Ă̂��̂Ȃ̂��낤���H
			 *	���A�Ă� return 0L �ɂ��Ă݂�B
			 *	�Ⴆ�΁A�\�������� Status Window ���J���̂� hUICurIMC == NULL �̂�����
			 *	������Ȃ��Ɨ\�z���Ă݂�B�����Adrag&drop �̑���̕����͈Ⴄ�C������c
			 */
		case WM_IME_NOTIFY:
			return	0L ;
//			return	OnUINotifyCommand (hUICurIMC, hWnd, message, wParam, lParam) ;
		default:
			break ;
		}
		/*DEBUGPRINTF ((TEXT ("SKKIMEWndProc (!hUICurIMC) --leave\n"))) ;*/
	}

	switch (message){
	case WM_CREATE:
		/*
		 * Allocate UI's extra memory block.
		 */
		hUIExtra	= GlobalAlloc (GHND, sizeof(UIEXTRA)) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;

		/*
		 * Initialize the extra memory block.
		 */
		lpUIExtra->uiStatus.pt.x	= -1 ;
		lpUIExtra->uiStatus.pt.y	= -1 ;
		lpUIExtra->uiDefComp.pt.x	= -1 ;
		lpUIExtra->uiDefComp.pt.y	= -1 ;
		lpUIExtra->uiCand.pt.x		= -1 ;
		lpUIExtra->uiCand.pt.y		= -1 ;
		lpUIExtra->uiGuide.rc.left	= -1 ;
		lpUIExtra->uiGuide.rc.top	= -1 ;
		lpUIExtra->hFont			= (HFONT)NULL ;
		lpUIExtra->dwShowStyle		= ISC_SHOWUIALL ;
		GlobalUnlock (hUIExtra) ;
		SetWindowLongPtr (hWnd, IMMGWLP_PRIVATE, (LONG_PTR)hUIExtra) ;
		break ;

	case WM_IME_SETCONTEXT:
		lRet	= OnImeSetContext (hUICurIMC, hWnd, message, wParam, lParam) ;
		break ;

	case WM_IME_STARTCOMPOSITION:
		/*
		 * �ϊ��J�n�B
		 */
		hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpIMC		= ImmLockIMC (hUICurIMC) ;
		if (!lpUIExtra->hFont){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			lf	= lpIMC->lfFont.W ;
#else
			lf	= lpIMC->lfFont.A ;
#endif
			if (lf.lfEscapement == 2700){
				lpUIExtra->bVertical	= TRUE ;
			} else {
				lf.lfEscapement			= 0 ;
				lpUIExtra->bVertical	= FALSE ;
			}
			if (lf.lfCharSet != NATIVE_CHARSET) {
				lf.lfCharSet			= NATIVE_CHARSET ;
				lf.lfFaceName[0]		= TEXT ('\0') ;
			}
			lpUIExtra->hFont	= MyCreateFontIndirect ((LPMYLOGFONT)&lf) ;
			UIComp_SetFont (lpUIExtra) ;
		}
		UIComp_Create (hWnd, lpUIExtra, lpIMC) ;
		ImmUnlockIMC (hUICurIMC) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_IME_COMPOSITION:
		/*
		 * Update to display the composition string.
		 */
		lpIMC		= ImmLockIMC (hUICurIMC) ;
		hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		UIComp_Move (hWnd, lpUIExtra, lpIMC) ;
		UICand_Move (hWnd, lpIMC, lpUIExtra, TRUE) ;
		GlobalUnlock (hUIExtra) ;
		ImmUnlockIMC (hUICurIMC) ;
		break ;

	case WM_IME_ENDCOMPOSITION:
		/*
		 * Finish to display the composition string.
		 */
		hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		UIComp_Hide (lpUIExtra) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_IME_COMPOSITIONFULL:
		break ;

	case WM_IME_SELECT:
		lRet	= OnImeSelect (hUICurIMC, hWnd, message, wParam, lParam) ;
		break ;

	case WM_IME_CONTROL:
		lRet	= OnImeControl (hUICurIMC, hWnd, message, wParam, lParam) ;
		break ;

	case WM_IME_NOTIFY:
		lRet	= OnUINotifyCommand (hUICurIMC, hWnd, message, wParam, lParam) ;
		break ;

	case WM_DESTROY:
		lpIMC		= ImmLockIMC (hUICurIMC) ;
		SKKClearPrivate (lpIMC) ;
		ImmUnlockIMC (hUICurIMC) ;

		hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;

		if (IsWindow (lpUIExtra->uiStatus.hWnd))
			DestroyWindow (lpUIExtra->uiStatus.hWnd) ;

		if (IsWindow (lpUIExtra->uiCand.hWnd))
			DestroyWindow (lpUIExtra->uiCand.hWnd) ;

		if (IsWindow (lpUIExtra->uiDefComp.hWnd))
			DestroyWindow (lpUIExtra->uiDefComp.hWnd) ;

		for (i = 0 ; i < MAXCOMPWND ; i++){
			if (IsWindow(lpUIExtra->uiComp[i].hWnd))
				DestroyWindow(lpUIExtra->uiComp[i].hWnd) ;
		}
		if (IsWindow (lpUIExtra->uiGuide.hWnd))
			DestroyWindow (lpUIExtra->uiGuide.hWnd) ;

		if (lpUIExtra->hFont)
			DeleteObject (lpUIExtra->hFont) ;

		GlobalUnlock (hUIExtra) ;
		GlobalFree (hUIExtra) ;
		break ;

	case WM_UI_STATEHIDE:
		hUIExtra					= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra					= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		if (IsWindow (lpUIExtra->uiStatus.hWnd))
			ShowWindow (lpUIExtra->uiStatus.hWnd, SW_HIDE) ;
		lpUIExtra->uiStatus.bShow	= FALSE ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_STATEMOVE:
		hUIExtra					= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra					= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->uiStatus.pt.x	= (long)LOWORD(lParam) ;
		lpUIExtra->uiStatus.pt.y	= (long)HIWORD(lParam) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_DEFCOMPMOVE:
		//
		// Set the position of the composition window to UIExtra.
		// This message is sent by the composition window.
		//
		hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		if (!lpUIExtra->dwCompStyle){
			lpUIExtra->uiDefComp.pt.x = (long)LOWORD(lParam);
			lpUIExtra->uiDefComp.pt.y = (long)HIWORD(lParam);
		}
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_CANDMOVE:
		//
		// Set the position of the candidate window to UIExtra.
		// This message is sent by the candidate window.
		//
		hUIExtra				= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra				= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->uiCand.pt.x	= (long)LOWORD(lParam) ;
		lpUIExtra->uiCand.pt.y	= (long)HIWORD(lParam) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_GUIDEMOVE:
		//
		// Set the position of the status window to UIExtra.
		// This message is sent by the status window.
		//
		hUIExtra					= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra					= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->uiGuide.rc.left	= (long)LOWORD (lParam) ;
		lpUIExtra->uiGuide.rc.top	= (long)HIWORD (lParam) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	default:
		lRet	= DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	lRet ;
}

/*************************************************************************
 *	WM_IME_SETCONTEXT
 *------------------------------------------------------------------------
 *		WM_IME_SETCONTEXT ���b�Z�[�W�̓A�v���P�[�V�����E�B���h�E���A�N�e�B
 *		�u�ɂȂ낤�Ƃ��鎞�ɃA�v���P�[�V�����֑����܂��B�����A�v���P�[
 *		�V������ IME �E�B���h�E�������Ă��Ȃ���΁A�A�v���P�[�V�����͂���
 *		���b�Z�[�W�� DefWindowProc �ɓn���Ȃ���΂Ȃ�܂���B�����āA
 *		DefWindowProc �̕Ԃ�l��Ԃ��Ȃ���΂Ȃ�܂���B
 *		�����A�v���P�[�V������ IME �E�B���h�E�������Ă���΁A�A�v���P�[�V��
 *		���� ImmIsUIMessage ���Ă΂Ȃ���΂Ȃ�܂���B
 *
 *		WM_IME_SETCONTEXT �́A
 *			fSet		= (BOOL)wParam ;
 *			lISCBits	= lParam ;
 *		(�p�����[�^)
 *			fSet
 *				�A�v���P�[�V������Input Context ���A�N�e�B�u�ɂȂ鎞�� fSet
 *				�� TRUE�̒l�����܂��BFALSE �̎���Input Context �͔�A�N�e�B
 *				�u�ɂȂ�܂��B
 *			lISCBits
 *				���̃r�b�g�̑g�ݍ��킹����Ȃ�܂��B
 *				+-----------------------------------+--------------------------------
 *				|�l									|�Ӗ�
 *				|ISC_SHOWUICOMPOSITIONWINDOW		|Composition Window ��\�����܂��B
 *				|ISC_SHOWUIGUIDWINDOW				|Guide Window ��\�����܂��B
 *				|ISC_SHOWUICANDIDATEWINDOW			|Candidate Window Index 0 ��\�����܂��B
 *				|(ISC_SHOWUICANDIDATEWINDOW << 1)	|Candidate Window Index 1 ��\�����܂��B
 *				|(ISC_SHOWUICANDIDATEWINDOW << 2)	|Candidate Window Index 2 ��\�����܂��B
 *				|(ISC_SHOWUICANDIDATEWINDOW << 3)	|Candidate Window Index 3 ��\�����܂��B
 *		(�Ԃ�l)
 *			�Ԃ�l�� DefWindowProc �܂��� ImmIsUIMessage �̕Ԃ�l�ɂȂ��
 *			���B
 *		(�R�����g)
 *			�A�v���P�[�V������ DefWindowProc (���� ImmIsUIMessage)���Ăяo��
 *			����ŁAUI window �� WM_IME_SETCONTEXT ���󂯎��܂��B�����r�b
 *			�g�� ON �Ȃ�AUI window ��lParam �̃r�b�g�̏�Ԃɏ]����
 *			composition, guide, candidate window ��\�����Ȃ���΂Ȃ�܂���B
 *			�����A�v���P�[�V�������g�� composition window ��`���Ă���̂ł�
 *			����AUI window �� composition window ��\������K�v�͂���܂���B
 *			�A�v���P�[�V�����͂��̎� ISC_SHOWUICOMPOSITIONWINDOW �r�b�g���N��
 *			�A���Ă���ADefWindowProc �������� ImmIsUIMessage ���Ă΂Ȃ����
 *			�Ȃ�܂���B
 *************************************************************************/
LRESULT	PASCAL
OnImeSetContext (
	register HIMC		hUICurIMC,
	register HWND		hwnd,
	register UINT		uMsg,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	register LPINPUTCONTEXT			lpIMC ;
	register LPUIEXTRA				lpUIExtra ;
	register HGLOBAL				hUIExtra ;
	register LPINPUTCONTEXT			lpIMCT ;
	register LPCOMPOSITIONSTRING	lpCompStr ;
	register LPCANDIDATEINFO		lpCandInfo ;

	lpIMCT		= NULL ;
	hUIExtra	= (HGLOBAL)GetWindowLongPtr (hwnd, IMMGWLP_PRIVATE) ;
	lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
	if (wParam){
		lpUIExtra->hIMC			= hUICurIMC ;
		lpUIExtra->dwShowStyle	= lParam ;
		if (hUICurIMC){
			lpIMC	= ImmLockIMC (hUICurIMC) ;
			if (lpIMC){
				register LPMYCOMPSTR	lpMyCompStr ;

				lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
				lpMyCompStr	= (LPMYCOMPSTR) lpCompStr ;
				lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;

				/*	���݂� ShowStyle ���L�����Ă����B*/
				lpMyCompStr->dwShowStyle	= lParam ;

				if (IsWindow (lpUIExtra->uiCand.hWnd))
					UICand_Hide (lpUIExtra) ;
				if (lParam & ISC_SHOWUICANDIDATEWINDOW){
					if (lpCandInfo->dwCount){
						UICand_Create (hwnd, lpUIExtra, lpIMC) ;
						UICand_Move (hwnd, lpIMC, lpUIExtra, FALSE) ;
					}
				} else {
					UICand_Hide (lpUIExtra) ;
				}
				if (IsWindow (lpUIExtra->uiDefComp.hWnd))
					UIComp_Hide (lpUIExtra) ;
				if (lParam & ISC_SHOWUICOMPOSITIONWINDOW){
					if (lpCompStr->dwCompStrLen){
						UIComp_Create (hwnd, lpUIExtra, lpIMC) ;
						UIComp_Move (hwnd, lpUIExtra, lpIMC) ;
					}
				} else {
					UIComp_Hide (lpUIExtra) ;
				}
				if (lParam & ISC_SHOWUIGUIDELINE) {
					DWORD	dwLevel, dwSize = 0 ;
					if (ImmGetGuideLine (hUICurIMC, GGL_LEVEL, NULL, 0)){
						dwLevel	= ImmGetGuideLine (hUICurIMC, GGL_LEVEL, NULL, 0) ;
						if (dwLevel) 
							dwSize	= ImmGetGuideLine (hUICurIMC, GGL_STRING, NULL, 0) ;
					}
					if (dwSize > 0) {
						UIMinibuf_Create (hwnd, lpUIExtra, lpIMC) ;
#if !defined (needed)	/* ���̃R�[�h���Ȃ��������Ǖs�v���H */
						UIMinibuf_Move (hwnd, lpUIExtra, lpIMC) ;
#endif
						ShowWindow (lpUIExtra->uiGuide.hWnd, SW_SHOWNOACTIVATE) ;
						lpUIExtra->uiGuide.bShow	= TRUE ;
					} else {
						UIMinibuf_Hide (lpUIExtra) ;
					}
				} else {
					UIMinibuf_Hide (lpUIExtra) ;
				}
				ImmUnlockIMCC (lpIMC->hCompStr) ;
				ImmUnlockIMCC (lpIMC->hCandInfo) ;
			} else {
				UICand_Hide (lpUIExtra) ;
				UIComp_Hide (lpUIExtra) ;
			}
			ImmUnlockIMC (hUICurIMC) ;
		} else {
			UICand_Hide (lpUIExtra) ;
			UIComp_Hide (lpUIExtra) ;
			UIMinibuf_Hide (lpUIExtra) ;
		}
		if (IsWindow (lpUIExtra->uiStatus.hWnd) &&
			lpUIExtra->uiStatus.bShow &&
			! skkime_IsHideToolbar ()){
			UIStatus_Show (lpUIExtra) ;
		}
		UIStatus_Update (lpUIExtra) ;
	} else {
		lpUIExtra->dwShowStyle	= 0L ;
		UICand_Hide (lpUIExtra) ;
		UIComp_Hide (lpUIExtra) ;
		UIMinibuf_Hide (lpUIExtra) ;
		if (IsWindow (lpUIExtra->uiStatus.hWnd)) {
			ShowWindow (lpUIExtra->uiStatus.hWnd, SW_HIDE) ;
		}
	}
	UpdateIndicIcon (hUICurIMC) ;
	GlobalUnlock (hUIExtra) ;
	return	0L ;
}

/*************************************************************************
 *	WM_IME_SELECT
 *		WM_IME_SELECT ���b�Z�[�W�̓V�X�e���� current IME ��ύX���悤�Ƃ�
 *		�鎞�� UI window �ɑ����܂��B
 *	WM_IME_SELECT
 *		fSelect	= (BOOL)wParam ;
 *		hKL		= lParam ;
 *	(�p�����[�^)
 *		fSelect
 *			���� IME ���V�����I�������̂Ȃ� TRUE�B�����Ȃ��΁A����IME��
 *			�I������O�����̂Ȃ�FALSE�B
 *		hKL
 *			IME �� Input language handle
 *	(�Ԃ�l)
 *		�Ȃ�
 *	(�R�����g)
 *		�V�X�e��IME class �͂��̃��b�Z�[�W��V���� UI window ���������
 *		�Â� UI window ��j������̂Ɏg���܂��BDefWindowProc �͂��̃��b
 *		�Z�[�W���������Ă��̏��� default IME window �ɓn���܂��B
 *		default IME window �͂��̃��b�Z�[�W�� UI window �ɑ���܂��B
 *************************************************************************/
LRESULT	PASCAL
OnImeSelect (
	register HIMC		hUICurIMC,
	register HWND		hwnd,
	register UINT		uMsg,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	register LPINPUTCONTEXT	lpIMC ;
	register LPUIEXTRA		lpUIExtra ;
	register HGLOBAL		hUIExtra ;

	DEBUGPRINTFEX (99, (TEXT ("WM_IME_SELECT: fSelect:%d, hKL:%lx"),
						(BOOL) wParam, (DWORD)lParam)) ;

	if (wParam){
		hUIExtra		= (HGLOBAL)GetWindowLongPtr (hwnd, IMMGWLP_PRIVATE) ;
		lpUIExtra		= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->hIMC = hUICurIMC ;
		GlobalUnlock (hUIExtra) ;
	} else {
		ShowUIWindows (hwnd, FALSE) ; /* ? */
	}
	return	0L ;
}

/*************************************************************************
 *	Composition Font �̃��g���b�N�𓾂�֐��B
 *-----
 *(�R�����g)
 *************************************************************************/
BOOL	PASCAL
GetCompFontMetrics (
	register LPUIEXTRA		lpUIExtra,
	register LPTEXTMETRIC	lpTextMetric)
{
	register HDC	hIC ;
	register BOOL	fRetvalue	= FALSE ;

	/* Device Context ���쐬����B*/
	hIC = CreateIC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
	if (!hIC)
		return	FALSE ;
	if (lpUIExtra->hFont){
		HFONT	hOldFont ;
		hOldFont	= (HFONT)SelectObject (hIC, lpUIExtra->hFont) ;
		fRetvalue	= GetTextMetrics (hIC, lpTextMetric) ;
		(void)SelectObject (hIC, hOldFont) ;
	} else {
		if (GetCurrentObject (hIC, OBJ_FONT))
			fRetvalue	= GetTextMetrics (hIC, lpTextMetric) ;
	}
	DeleteDC (hIC) ;
	return	fRetvalue ;
}

/*************************************************************************
 *
 * DrawUIBorder()
 *
 * When draging the child window, this function draws the border.
 *
 *************************************************************************/
void	PASCAL	DrawUIBorder (LPRECT lprc)
{
	HDC	hDC ;
	int	sbx, sby ;

	hDC	= CreateDC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
	SelectObject (hDC, GetStockObject (GRAY_BRUSH)) ;
	sbx	= GetSystemMetrics (SM_CXBORDER) ;
	sby	= GetSystemMetrics (SM_CYBORDER) ;
	PatBlt (hDC, lprc->left, 
				 lprc->top, 
				 lprc->right - lprc->left-sbx, 
				 sby, PATINVERT );
	PatBlt (hDC, lprc->right - sbx, 
				 lprc->top, 
				 sbx, 
				 lprc->bottom - lprc->top-sby, PATINVERT );
	PatBlt (hDC, lprc->right, 
				 lprc->bottom-sby, 
				 -(lprc->right - lprc->left-sbx), 
				 sby, PATINVERT );
	PatBlt (hDC, lprc->left, 
				 lprc->bottom, 
				 sbx, 
				 -(lprc->bottom - lprc->top-sby), PATINVERT );
	DeleteDC (hDC) ;
	return ;
}

/*************************************************************************
 *
 *	DragUI(hWnd,message,wParam,lParam)
 *
 *	Handling mouse messages for the child windows.
 *
 *************************************************************************/
void	PASCAL	DragUI (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT			pt ;
	static	POINT	ptdif ;
	static	RECT	drc ;
	static	RECT	rc ;
	DWORD			dwT ;

	switch (message){
	case WM_SETCURSOR:
		if (HIWORD(lParam) == WM_LBUTTONDOWN || HIWORD(lParam) == WM_RBUTTONDOWN){
			GetCursorPos (&pt) ;
			SetCapture (hWnd) ;
			GetWindowRect (hWnd, &drc) ;
			ptdif.x		= pt.x - drc.left ;
			ptdif.y		= pt.y - drc.top ;
			rc			= drc ;
			rc.right	-= rc.left ;
			rc.bottom	-= rc.top ;
			SetWindowLong (hWnd, FIGWL_MOUSE, FIM_CAPUTURED) ;
		}
		break ;

	case WM_MOUSEMOVE:
		dwT	= GetWindowLong (hWnd, FIGWL_MOUSE) ;
		if (dwT & FIM_MOVED){
			DrawUIBorder (&drc) ;
			GetCursorPos (&pt) ;
			drc.left	= pt.x - ptdif.x ;
			drc.top		= pt.y - ptdif.y ;
			drc.right	= drc.left + rc.right ;
			drc.bottom	= drc.top + rc.bottom ;
			DrawUIBorder (&drc) ;
		} else if (dwT & FIM_CAPUTURED){
			DrawUIBorder (&drc) ;
			SetWindowLong (hWnd, FIGWL_MOUSE,dwT | FIM_MOVED) ;
		}
		break ;

	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		dwT = GetWindowLong (hWnd, FIGWL_MOUSE) ;

		if (dwT & FIM_CAPUTURED){
			ReleaseCapture () ;
			if (dwT & FIM_MOVED){
				DrawUIBorder (&drc) ;
				GetCursorPos (&pt) ;
				MoveWindow (hWnd, pt.x - ptdif.x, pt.y - ptdif.y, rc.right, rc.bottom, TRUE) ;
			}
		}
	default:
		break ;
	}
	return ;
}

/*************************************************************************
 *
 *	MyIsIMEMessage(message)
 *
 * Any UI window should not pass the IME messages to DefWindowProc. 
 *
 *************************************************************************/
BOOL PASCAL MyIsIMEMessage(UINT message)
{
	switch(message){
	case WM_IME_STARTCOMPOSITION:
	case WM_IME_ENDCOMPOSITION:
	case WM_IME_COMPOSITION:
	case WM_IME_NOTIFY:
	case WM_IME_SETCONTEXT:
	case WM_IME_CONTROL:
	case WM_IME_COMPOSITIONFULL:
	case WM_IME_SELECT:
	case WM_IME_CHAR:
		return	TRUE ;
	}
	return	FALSE ;
}

/*************************************************************************
 *
 *	ShowUIWindows (hWnd, fFlag)
 *
 *************************************************************************/
void	PASCAL	ShowUIWindows (HWND hWnd, BOOL fFlag)
{
	HGLOBAL		hUIExtra ;
	LPUIEXTRA	lpUIExtra ;
	int			nsw = fFlag ? SW_SHOWNOACTIVATE : SW_HIDE ;

	hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
	if (!hUIExtra)
		return ;

	lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
	if (!lpUIExtra)
		return ;

	if (IsWindow (lpUIExtra->uiStatus.hWnd)){
		HIMC	hIMC ;
		ShowWindow (lpUIExtra->uiStatus.hWnd, nsw) ;
		lpUIExtra->uiStatus.bShow	= fFlag ;
		hIMC	= (HIMC)GetWindowLongPtr (hWnd, IMMGWLP_IMC) ;
		UpdateIndicIcon (hIMC) ;
	}

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		ShowWindow (lpUIExtra->uiCand.hWnd, nsw) ;
		lpUIExtra->uiCand.bShow		= fFlag ;
	}

	if (IsWindow(lpUIExtra->uiDefComp.hWnd)){
		ShowWindow (lpUIExtra->uiDefComp.hWnd, nsw) ;
		lpUIExtra->uiDefComp.bShow	= fFlag ;
	}

	if (IsWindow(lpUIExtra->uiGuide.hWnd)){
		ShowWindow (lpUIExtra->uiGuide.hWnd, nsw) ;
		lpUIExtra->uiGuide.bShow	= fFlag ;
	}

	GlobalUnlock (hUIExtra) ;
	return ;
}

#ifdef DEBUG
void PASCAL DumpUIExtra(LPUIEXTRA lpUIExtra)
{
	TCHAR	szDev [80] ;
	int		i ;

	wsprintf ((LPTSTR)szDev, TEXT ("Status hWnd %lX  [%d,%d]\r\n"),
			  lpUIExtra->uiStatus.hWnd,
			  lpUIExtra->uiStatus.pt.x,
			  lpUIExtra->uiStatus.pt.y) ;
	OutputDebugString ((LPTSTR)szDev) ;

	wsprintf ((LPTSTR)szDev, TEXT ("Cand hWnd %lX  [%d,%d]\r\n"),
			  lpUIExtra->uiCand.hWnd,
			  lpUIExtra->uiCand.pt.x,
			  lpUIExtra->uiCand.pt.y) ;
	OutputDebugString ((LPTSTR)szDev) ;

	wsprintf ((LPTSTR)szDev, TEXT ("CompStyle hWnd %lX]\r\n"),
			  lpUIExtra->dwCompStyle);
	OutputDebugString ((LPTSTR)szDev) ;

	wsprintf ((LPTSTR)szDev, TEXT ("DefComp hWnd %lX  [%d,%d]\r\n"),
			  lpUIExtra->uiDefComp.hWnd,
			  lpUIExtra->uiDefComp.pt.x,
			  lpUIExtra->uiDefComp.pt.y) ;
	OutputDebugString ((LPTSTR)szDev) ;

	for (i = 0 ; i < 5 ; i++ ){
		wsprintf ((LPTSTR)szDev, TEXT ("Comp hWnd %lX  [%d,%d]-[%d,%d]\r\n"),
				  lpUIExtra->uiComp[i].hWnd,
				  lpUIExtra->uiComp[i].rc.left,
				  lpUIExtra->uiComp[i].rc.top,
				  lpUIExtra->uiComp[i].rc.right,
				  lpUIExtra->uiComp[i].rc.bottom) ;
		OutputDebugString ((LPTSTR)szDev) ;
	}
	return ;
}
#endif

