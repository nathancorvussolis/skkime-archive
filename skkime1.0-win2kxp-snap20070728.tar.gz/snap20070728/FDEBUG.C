/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * fdebug.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include <shlwapi.h>
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"

#define	DEBUGFILENAME	TEXT("skkime.log")

void	PASCAL
DebugPrintf (
	LPCTSTR		ptszFormat,
	...)
{
	TCHAR		szBuffer1 [512] ;
	TCHAR		szBuffer2 [512] ;
	va_list		vl ;
	int			n ;
	
	va_start (vl, ptszFormat) ;
	n	= wvnsprintf (szBuffer1, NELEMENTS (szBuffer1) - 1, ptszFormat, vl) ;
	va_end (vl) ;
	szBuffer1 [n]	= TEXT ('\0') ;
	n	= wnsprintf (szBuffer2, NELEMENTS (szBuffer2) - 1, TEXT ("[%d] %s"), GetTickCount (), szBuffer1) ;
	szBuffer2 [n]	= TEXT ('\0') ;
	OutputDebugString (szBuffer2) ;
	return ;
}

void	PASCAL
DebugPrintfToFile (
	LPCTSTR	ptszFormat,
	...)
{
	TCHAR	szBuffer [2048] ;
	va_list	vl ;
	HANDLE	hFile		= INVALID_HANDLE_VALUE ;
	DWORD	dwWritten	= 0, dwFileName = 0 ;
	TCHAR	szPath [MAX_PATH + 1] ;
	int		n ;
	
	/*	�f�o�b�O���O�̏o�̓p�X��ݒ肷��B*/
	dwFileName	= GetTempPath (MAX_PATH, szBuffer) ;
	if (dwFileName <= 0 || dwFileName >= MAX_PATH)
		return ;
	szBuffer [dwFileName]	= TEXT ('\0') ;
	n	= wnsprintf (szPath, MAX_PATH, TEXT ("%s%s"), szBuffer, DEBUGFILENAME) ;
	if (n < 0 || n >= MAX_PATH)
		return ;
	szPath [n]	= TEXT ('\0') ;

	/*	�o�͂��钆�g��ݒ肷��B*/
	va_start (vl, ptszFormat) ;
	n	= wvnsprintf (szBuffer, NELEMENTS (szBuffer), ptszFormat, vl) ;
	va_end (vl) ;
	if (n < 0)
		return ;

	/*	�t�@�C�����쐬����B*/
	hFile	= CreateFile (szPath, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE)
		return ;
	/*	�t�@�C���Ƀf�[�^��ǉ�����B*/
	/*	�G���[���������Ă����ɉ����ł��Ȃ��̂ŁA���̂܂ܗ����B*/
	SetFilePointer (hFile, 0, NULL, FILE_END) ;
	WriteFile (hFile, szBuffer, n * sizeof (TCHAR), &dwWritten, NULL) ;
	CloseHandle (hFile) ;
	return ;
}

void	DebugDump (
	LPCTSTR		strMessage,
	LPCTSTR		strString,
	int			nString)
{
	TCHAR	szBuffer [1024] ;
	TCHAR*	pDest ;
	int		n, nDest ;
	
	pDest	= szBuffer ;
	nDest	= NELEMENTS (szBuffer) - 1 ;
	if (strMessage != NULL) {
		n	= lstrlen (strMessage) ;
		n	= (n < nDest)? n : nDest ;
		memcpy (pDest, strMessage, n * sizeof (TCHAR)) ;
		nDest	-= n ;
		pDest	+= n ;
	}
	n	= (nString < nDest)? nString : nDest ;
	memcpy (pDest, strString, n * sizeof (TCHAR)) ;
	nDest	-= n ;
	pDest	+= n ;
	*pDest	= TEXT ('\0') ;
	OutputDebugString (szBuffer) ;
	return ;
}

void	DebugDumpRS (
	LPRECONVERTSTRING	lpRS)
{
    MYCHAR		szDev [80] ;
    LPMYSTR 	lpDump	= (LPMYSTR)((LPBYTE)lpRS + lpRS->dwStrOffset);
	
	Mylstrcpyn (szDev, lpDump, 80) ;
	szDev [79]	= MYTEXT ('\0') ;
    *(LPMYSTR)(lpDump + lpRS->dwStrLen) = MYTEXT('\0');
    OutputDebugString(TEXT("DumpRS\r\n"));
	DebugPrintf (TEXT("dwSize            %x\r\n"), lpRS->dwSize) ;
    DebugPrintf (TEXT("dwStrLen          %x\r\n"), lpRS->dwStrLen) ;
    DebugPrintf (TEXT("dwStrOffset       %x\r\n"), lpRS->dwStrOffset) ;
    DebugPrintf (TEXT("dwCompStrLen      %x\r\n"), lpRS->dwCompStrLen) ;
    DebugPrintf (TEXT("dwCompStrOffset   %x\r\n"), lpRS->dwCompStrOffset) ;
    DebugPrintf (TEXT("dwTargetStrLen    %x\r\n"), lpRS->dwTargetStrLen) ;
    DebugPrintf (TEXT("dwTargetStrOffset %x\r\n"), lpRS->dwTargetStrOffset) ;
	MyOutputDebugString (szDev) ;
    OutputDebugString(TEXT("--- \r\n"));
	return ;
}


