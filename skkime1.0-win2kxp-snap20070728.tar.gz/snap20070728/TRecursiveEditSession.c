#include "local.h"
#include "TRecursiveEditSession.h"
#include "ImeDoc.h"
#include "ImeBuffer.h"

BOOL
TRecursiveEditSession_Init (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pBuffer,
	BOOL (*pExitProc)(CTRecursiveEditSession*, struct tagCImeBuffer*, LPCWSTR, int),
	BOOL (*pAbortProc)(CTRecursiveEditSession*, struct tagCImeBuffer*))
{
	ASSERT (pSession != NULL) ;
	ASSERT (pBuffer != NULL) ;

	pSession->_pBuffer		= pBuffer ;
	pSession->_pExitProc	= pExitProc ;
	pSession->_pAbortProc	= pAbortProc ;
	return	TRUE ;
}

/*	$BJV$jCM$O(B ExitMinibuffer $B$7$?$+H]$+!#$7$?(B = TRUE/$B$7$F$J$$(B = FALSE
 *	callback $B$,Dj5A$5$l$F$J$$$J$i!"<+F0E*$K(B ExitMinibuffer $B$9$k!#(B
 */
BOOL
TRecursiveEditSession_Exit  (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pBuffer,
	register LPCWSTR		wstrResult,
	register int			nResult)
{
	ASSERT (pSession != NULL) ;
	ASSERT (pSession->_pBuffer != NULL) ;

	if (pSession->_pExitProc != NULL) 
		return	(pSession->_pExitProc)(pSession, pBuffer, wstrResult, nResult) ;
	
	ImeDoc_ExitMinibuffer (ImeBuffer_GetDocument (pSession->_pBuffer), pSession->_pBuffer) ;
	return	TRUE ;
}

/*	$BJV$jCM$O(B ExitMinibuffer $B$7$?$+H]$+!#$7$?(B = TRUE/$B$7$F$J$$(B = FALSE
 *	callback $B$,Dj5A$5$l$F$J$$$J$i!"<+F0E*$K(B ExitMinibuffer $B$9$k!#(B
 */
BOOL
TRecursiveEditSession_Abort (
	register CTRecursiveEditSession*	pSession,
	register CImeBuffer*	pBuffer)
{
	if (pSession->_pAbortProc != NULL)
		return	(pSession->_pAbortProc)(pSession, pBuffer) ;

	ImeDoc_ExitMinibuffer (ImeBuffer_GetDocument (pSession->_pBuffer), pSession->_pBuffer) ;
	return	TRUE ;
}




