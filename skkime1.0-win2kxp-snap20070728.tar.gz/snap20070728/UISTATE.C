/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * uistate.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "skksubs.h"
#include "skkui.h"
#include "resource.h"

enum {
	INDEX_STATUS_BMP_DI	= 0,
	INDEX_STATUS_BMP_KANA,
	INDEX_STATUS_BMP_KATA,
	INDEX_STATUS_BMP_ZENEI,
	INDEX_STATUS_BMP_ASCII,
	INDEX_STATUS_BMP_HANKANA,
	NUM_STATUS_BMP_MODES,

	INDEX_STATUS_BMP_LU		= NUM_STATUS_BMP_MODES,
	INDEX_STATUS_BMP_RB,
	INDEX_STATUS_BMP_RB2,
	INDEX_STATUS_BMP_LU2,
} ;

enum {
	NUM_HEIGHT_STATUS_BMP	= 10,
	NUM_WIDTH_STATUS_BMP	= 2,
} ;

/*	ONOFF.BMP �̕��ƍ����B*/
#define	UISTATE_ONOFFBMP_SRC_WIDTH	36
#define	UISTATE_ONOFFBMP_SRC_HEIGHT	100

/*
 *	�v���g�^�C�v�錾�B
 */
static	void	PASCAL	UIStatus_paint (HWND, HDC, DWORD) ;
static	void	PASCAL	UIStatus_onEraseBkGround (HWND, HDC) ;
static	void	PASCAL	UIStatus_onButton (HWND, UINT, WPARAM, LPARAM) ;
static	BOOL			UIStatus_onLeftMenu (HIMC, HWND) ;
static	BOOL			UIStatus_onRightMenu (HIMC, HWND) ; 
static	int				UIStatus_showLeftMenu (HIMC, HWND) ;
static	int				UIStatus_showRightMenu (HIMC, HWND) ;
static	BOOL			UIStatus_insertInputModeMenu (HIMC, HMENU, int FAR*) ;
static	HBITMAP			UIStatus_createCModeBitmap (HWND) ;
static	HBITMAP			UIStatus_createOnOffBitmap (HWND) ;
static	DWORD	PASCAL	UIStatus_checkPushedStatus (HWND, LPPOINT) ;
static	void	PASCAL	UIStatus_changeCursor (HWND) ;
static	DWORD			uiStatus_getStateToggleGameMode (void) ;

/*
 *	Global Functions
 */

/*
 *	Status Window �� WINDOWPROC�B
 *(�R�����g)
 *	Status Window ����Window Message�͂��̊֐��ɑ����ė��܂��̂ŁA
 *	Window Message �ɑΉ������������s���܂��B���̊֐����̂� Window
 *	Message �̐U�蕪�������ł����ǁB
 *(����)
 *	hWnd	Window Message ���󂯎���� Composition Window �� Handle
 *	message	Window Message
 *	wParam	Window Message �̈�������1
 *	lParam	Window Message �̈�������2
 */
LRESULT CALLBACK
UIStatus_WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT	ps ;
	HWND		hUIWnd ;
	HDC			hDC ;
	HBITMAP		hbmpStatus ;
	HIMC		hIMC ;

	switch (message){
	case	WM_UI_UPDATE:
		InvalidateRect (hWnd, NULL, FALSE) ;
		break ;

	case	WM_PAINT:
		hDC = BeginPaint (hWnd, &ps) ;
		UIStatus_paint (hWnd, hDC, 0) ;
		EndPaint (hWnd, &ps) ;
		break ;

	case	WM_ERASEBKGND:
		UIStatus_onEraseBkGround (hWnd, (HDC) wParam) ;
		break ;

	case	WM_MOUSEACTIVATE:
		return	MA_NOACTIVATE ;

	case	WM_NCMOUSEMOVE:
	case	WM_MOUSEMOVE:
	case	WM_LBUTTONUP:
	case	WM_RBUTTONUP:
	case	WM_LBUTTONDOWN:
	case	WM_RBUTTONDOWN:
	case	WM_SETCURSOR:
		UIStatus_onButton (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_MOVE:
		{
			RECT	rc ;

			if (GetWindowRect (hWnd, &rc)) {
				HANDLE	hMutex	= skkimeCreateMutex (SKKIME_MUTEX_NAME) ;
				if (hMutex != NULL) {
					DWORD	dw = WaitForSingleObject (hMutex, INFINITE) ;
					if (dw != WAIT_FAILED && dw != WAIT_TIMEOUT) {
						g_ptUIStatus.x	= rc.left ;
						g_ptUIStatus.y	= rc.top ;
						ReleaseMutex (hMutex) ;
					}
					CloseHandle (hMutex) ;
				}
			}
			hUIWnd = (HWND)GetWindowLongPtr (hWnd, FIGWL_UISTATE_SVRWND) ;
			if (IsWindow (hUIWnd))
				SendMessage (hUIWnd, WM_UI_STATEMOVE, wParam, lParam) ;
		}
		break ;

	case	WM_CREATE:
#ifdef STATUSWINDOW_LARGE
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_STATUSORGBMP,	(LONG_PTR)LoadBitmap (g_hInst, TEXT ("STATUSBMP"))) ;
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_CLOSEORGBMP,	(LONG_PTR)LoadBitmap (g_hInst, TEXT ("ONOFFBMP"))) ;
#else
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_STATUSORGBMP,	(LONG_PTR)LoadBitmap (g_hInst, TEXT ("STATUSSBMP"))) ;
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_CLOSEORGBMP,	(LONG_PTR)LoadBitmap (g_hInst, TEXT ("ONOFFSBMP"))) ;
#endif
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_STATUSBMP,	(LONG_PTR)UIStatus_createCModeBitmap (hWnd)) ;
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_CLOSEBMP,		(LONG_PTR)UIStatus_createOnOffBitmap (hWnd)) ;
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_CURSOR,		(LONG_PTR)0) ;
		SetWindowLong (hWnd, FIGWL_UISTATE_MOUSE,			0L) ;
		SetWindowLong (hWnd, FIGWL_UISTATE_PUSHSTATUS,		0L) ;
		SetWindowLong (hWnd, FIGWL_UISTATE_PREVCMODE,		0L) ;
		break ;

	case	WM_SYSCOLORCHANGE:
		hbmpStatus = (HBITMAP)GetWindowLongPtr (hWnd, FIGWL_UISTATE_STATUSBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		hbmpStatus = (HBITMAP)GetWindowLongPtr (hWnd, FIGWL_UISTATE_CLOSEBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_STATUSBMP,	(LONG_PTR)UIStatus_createCModeBitmap (hWnd)) ;
		SetWindowLongPtr (hWnd, FIGWL_UISTATE_CLOSEBMP,		(LONG_PTR)UIStatus_createOnOffBitmap (hWnd)) ;
		break ;

	case	WM_DESTROY:
#if 1
		hbmpStatus = (HBITMAP)GetWindowLongPtr (hWnd, FIGWL_UISTATE_STATUSORGBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		hbmpStatus = (HBITMAP)GetWindowLongPtr (hWnd, FIGWL_UISTATE_CLOSEORGBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
#endif
		hbmpStatus = (HBITMAP)GetWindowLongPtr (hWnd, FIGWL_UISTATE_STATUSBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		hbmpStatus = (HBITMAP)GetWindowLongPtr (hWnd, FIGWL_UISTATE_CLOSEBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		SetWindowLong (hWnd, FIGWL_UISTATE_MOUSE, 0L) ;
		SetWindowLong (hWnd, FIGWL_UISTATE_PUSHSTATUS, 0L) ;
		break ;

	case	WM_UI_HIDE:
		ShowWindow (hWnd, SW_HIDE) ;
		return	0 ;

	case	WM_SETTINGCHANGE:
		{
			HWND		hSvrWnd ;
			HGLOBAL		hUIExtra ;
			LPUIEXTRA	lpUIExtra ;

			hSvrWnd		= (HWND)GetWindowLongPtr (hWnd,	FIGWL_UISTATE_SVRWND) ;
			if (IsWindow (hSvrWnd)) {
				hUIExtra	= (HGLOBAL)GetWindowLongPtr (hSvrWnd, IMMGWLP_PRIVATE) ;
				if (hUIExtra != NULL) {
					lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
					if (lpUIExtra != NULL) {
						UIStatus_AdjustPosition (lpUIExtra) ;
						GlobalUnlock (hUIExtra) ;
					}
				}
			}
		}
		return	0 ;

	default:
		if (!MyIsIMEMessage(message))
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return 0 ;
}

void	PASCAL
UIStatus_Update (
	register LPUIEXTRA	lpUIExtra)
{
	if (IsWindow (lpUIExtra->uiStatus.hWnd))
		SendMessage (lpUIExtra->uiStatus.hWnd, WM_UI_UPDATE, 0, 0L) ;
	return ;
}

void	PASCAL
UIStatus_Show (
	register LPUIEXTRA		lpUIExtra)
{
	HANDLE	hMutex ;

	if (lpUIExtra == NULL || ! IsWindow (lpUIExtra->uiStatus.hWnd))
		return ;

	hMutex	= skkimeCreateMutex (SKKIME_MUTEX_NAME) ;
	if (hMutex != NULL) {
		DWORD	dw = WaitForSingleObject (hMutex, INFINITE) ;
		if (dw != WAIT_FAILED && dw != WAIT_TIMEOUT) {
			if (g_ptUIStatus.x != -1) {
				lpUIExtra->uiStatus.pt.x	= g_ptUIStatus.x ;
				lpUIExtra->uiStatus.pt.y	= g_ptUIStatus.y ;
			} 
			ReleaseMutex (hMutex) ;
		}
		CloseHandle (hMutex) ;
	}
	SetWindowPos (lpUIExtra->uiStatus.hWnd, HWND_TOP, lpUIExtra->uiStatus.pt.x, lpUIExtra->uiStatus.pt.y, 1, 1, 
			SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOSENDCHANGING | SWP_NOOWNERZORDER | SWP_SHOWWINDOW) ;
	return ;
}

void	PASCAL
UIStatus_Move (
	register LPUIEXTRA		lpUIExtra,
	register const POINTS*	pPT)
{
	RECT	rc ;

	if (! IsWindow (lpUIExtra->uiStatus.hWnd))
		return ;

	GetWindowRect (lpUIExtra->uiStatus.hWnd, &rc) ;
	MoveWindow (lpUIExtra->uiStatus.hWnd, pPT->x, pPT->y, rc.right - rc.left, rc.bottom - rc.top, FALSE) ;
	return ;
}

void
UIStatus_AdjustPosition (
	register LPUIEXTRA		lpUIExtra)
{
	RECT	rcWorkArea, rcWnd ;

	if (! IsWindow (lpUIExtra->uiStatus.hWnd))
		return ;

	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWorkArea, FALSE) ;
	if (GetWindowRect (lpUIExtra->uiStatus.hWnd, &rcWnd)) {
		POINT	pt ;
		pt.x	= rcWnd.left ;
		pt.y	= rcWnd.top ;
		if (rcWnd.left < rcWorkArea.left) 
			pt.x	= rcWorkArea.left ;
		if (rcWnd.right > rcWorkArea.right) 
			pt.x	= rcWorkArea.right - (rcWnd.right - rcWnd.left) ;
		if (rcWnd.top  < rcWorkArea.top)
			pt.y	= rcWorkArea.top ;
		if (rcWnd.bottom > rcWorkArea.bottom)
			pt.y	= rcWorkArea.bottom - (rcWnd.bottom - rcWnd.top) ;
		if (pt.x != rcWnd.left || pt.y != rcWnd.top) {
			MoveWindow (lpUIExtra->uiStatus.hWnd, pt.x, pt.y, rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top, TRUE) ;
			lpUIExtra->uiStatus.pt.x	= rcWnd.left ;
			lpUIExtra->uiStatus.pt.y	= rcWnd.top ;
		}
	}
	return ;
}

/*========================================================================*
 *	private  functions
 */
void	PASCAL
UIStatus_paint (
	register HWND		hStatusWnd,
	register HDC		hDC,
	register DWORD		dwPushedStatus)
{
	register HIMC			hIMC ;
	register LPINPUTCONTEXT	lpIMC ;
	register HDC			hMemDC ;
	register HBITMAP		hbmpOld ;
	register int			src_x, src_y ;
	register int			y ;
	register HWND			hSvrWnd ;
	POINT					pt ;
	register HBITMAP		hbmpStatus ;
	register HBRUSH			hOldBrush, hBrush ;

	hSvrWnd		= (HWND)GetWindowLongPtr (hStatusWnd,	FIGWL_UISTATE_SVRWND) ;
	hIMC		= (HIMC)GetWindowLongPtr (hSvrWnd,		IMMGWLP_IMC) ;

	if (hIMC){
		lpIMC	= ImmLockIMC (hIMC) ;
	} else {
		lpIMC	= NULL ;
	}
	hMemDC	= CreateCompatibleDC (hDC) ;

	GetCursorPos (&pt) ;
	ScreenToClient (hStatusWnd, &pt) ;
	if (hIMC){
		y		= BTYFromCmode (lpIMC) ;
	} else {
		y		= (int)GetWindowLong (hStatusWnd, FIGWL_UISTATE_PREVCMODE) ;
	}
	hbmpStatus	= (HBITMAP)GetWindowLongPtr (hStatusWnd, FIGWL_UISTATE_CLOSEBMP) ;
	hbmpOld		= (HBITMAP)SelectObject (hMemDC, hbmpStatus) ;
	if (hIMC){
		if (y == BTY_DIRECTINPUT){
			src_y	= 0 ;
		} else {
			src_y	= STATUSONOFF_BTNY ;
		}
		if (dwPushedStatus & PUSHED_STATUS_ONOFF){
			src_x	= STATUSONOFF_BTNX * 2 ;
		} else if (STATUSONOFF_X <= pt.x && pt.x < STATUSCMODE_X &&
				   STATUSONOFF_Y <= pt.y && pt.y < 10){
			src_x	= STATUSONOFF_BTNX * 1 ;
		} else {
			src_x	= 0 ;
		}
	}  else {
		src_x	= 0 ;
		src_y	= 0 ;
	}
	BitBlt (hDC, STATUSONOFF_X, STATUSONOFF_Y, STATUSONOFF_BTNX, STATUSONOFF_BTNY,
			hMemDC, src_x, src_y, SRCCOPY) ;
	SelectObject (hMemDC, hbmpOld) ;

	hbmpStatus	= (HBITMAP)GetWindowLongPtr (hStatusWnd, FIGWL_UISTATE_STATUSBMP) ;
	hbmpOld		= (HBITMAP)SelectObject (hMemDC, hbmpStatus) ;
	if (hIMC){
		if (dwPushedStatus & PUSHED_STATUS_MODE){
			src_x	= STATUSCMODE_BTNX * 2 ;
		} else if (STATUSCMODE_X <= pt.x && pt.x < STATUS_BTNX &&
				   STATUSCMODE_Y <= pt.y && pt.y < STATUS_BTNY){
			src_x	= STATUSCMODE_BTNX * 1 ;
		} else {
			src_x	= 0 ;
		}
	} else {
		src_x	= STATUSCMODE_BTNX * 3 ;
	}
	BitBlt (hDC, STATUSCMODE_X, STATUSCMODE_Y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hMemDC, src_x, y, SRCCOPY) ;
	SelectObject (hMemDC, hbmpOld) ;
	DeleteDC (hMemDC) ;
	if (hIMC){
		ImmUnlockIMC (hIMC) ;
		SetWindowLong (hStatusWnd, FIGWL_UISTATE_PREVCMODE, (LONG)y) ;
	}
	return ;
}

void	PASCAL
UIStatus_onEraseBkGround (
	register HWND		hStatusWnd,
	register HDC		hDC)
{
	register HDC			hMemDC ;
	register HBITMAP		hbmpOld ;
	register int			y ;
	register HWND			hSvrWnd ;
	register HBITMAP		hbmpStatus ;
	register HBRUSH			hOldBrush, hBrush ;

	hSvrWnd	= (HWND)GetWindowLongPtr (hStatusWnd,	FIGWL_UISTATE_SVRWND) ;
	hMemDC	= CreateCompatibleDC (hDC) ;

	hbmpStatus	= (HBITMAP)GetWindowLongPtr (hStatusWnd, FIGWL_UISTATE_CLOSEBMP) ;
	hbmpOld		= (HBITMAP)SelectObject (hMemDC, hbmpStatus) ;
	BitBlt (hDC, STATUSONOFF_X, STATUSONOFF_Y, STATUSONOFF_BTNX, STATUSONOFF_BTNY,
			hMemDC, 0, 0, SRCCOPY) ;
	SelectObject (hMemDC, hbmpOld) ;

	hbmpStatus	= (HBITMAP)GetWindowLongPtr (hStatusWnd, FIGWL_UISTATE_STATUSBMP) ;
	hbmpOld		= (HBITMAP)SelectObject (hMemDC, hbmpStatus) ;
	y			= (int)GetWindowLong (hStatusWnd, FIGWL_UISTATE_PREVCMODE) ;
	BitBlt (hDC, STATUSCMODE_X, STATUSCMODE_Y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hMemDC, STATUSCMODE_BTNX * 3, y, SRCCOPY) ;
	SelectObject (hMemDC, hbmpOld) ;
	DeleteDC (hMemDC) ;
	return ;
}

void	PASCAL
UIStatus_onButton (
	register HWND		hStatusWnd, 
	register UINT		message,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	POINT			pt ;
	HDC				hDC ;
	DWORD			dwMouse, dwPushedStatus, dwTemp, fdwConversion ;
	HIMC			hIMC ;
	HWND			hSvrWnd ;
	BOOL			fOpen ;
	HMENU			hMenu ;
	static	POINT	ptdif ;
	static	RECT	drc ;
	static	RECT	rc ;

	hDC	= GetDC (hStatusWnd) ;

	if (message == WM_SETCURSOR && (HWND) wParam == hStatusWnd)
		message	= HIWORD (lParam) ;

	switch (message){
	case WM_RBUTTONDOWN:
	case WM_LBUTTONDOWN:
		dwMouse			= GetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE) ;
		DEBUGPRINTFEX (104, (TEXT ("UIStatus_onButton (message:%d, dwMouse:0x%x)\n"), message, dwMouse)) ;
		if (!(dwMouse & FIM_FOCUS))
			break ;
		GetCursorPos (&pt) ;
		dwPushedStatus	= UIStatus_checkPushedStatus (hStatusWnd, &pt) ;
		GetWindowRect (hStatusWnd, &drc) ;
		ptdif.x			= pt.x - drc.left ;
		ptdif.y			= pt.y - drc.top ;
		rc				= drc ;
		rc.right		-= rc.left ;
		rc.bottom		-= rc.top ;
		SetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE,			dwMouse | FIM_CAPUTURED) ;
		SetWindowLong (hStatusWnd, FIGWL_UISTATE_PUSHSTATUS,	(DWORD)dwPushedStatus) ;
		UIStatus_paint (hStatusWnd, hDC, dwPushedStatus) ;
		break ;

	case	WM_NCMOUSEMOVE:
	case	WM_MOUSEMOVE:
	case	WM_SETCURSOR:
		dwMouse			= GetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE) ;
		dwPushedStatus	= (DWORD)GetWindowLong (hStatusWnd, FIGWL_UISTATE_PUSHSTATUS) ;
		DEBUGPRINTFEX (104, (TEXT ("UIStatus_onButton (message:%d, dwMouse:0x%x, Pushed:0x%x)\n"), message, dwMouse, dwPushedStatus)) ;
		if (dwPushedStatus){
			if (dwPushedStatus & PUSHED_STATUS_MOVE){
				if (dwMouse & FIM_MOVED){
					DrawUIBorder (&drc) ;
					GetCursorPos (&pt) ;
					drc.left	= pt.x - ptdif.x ;
					drc.top		= pt.y - ptdif.y ;
					drc.right	= drc.left + rc.right ;
					drc.bottom	= drc.top + rc.bottom ;
					DrawUIBorder (&drc) ;
				} else if (dwMouse & FIM_CAPUTURED){
					DrawUIBorder (&drc) ;
					SetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE, dwMouse | FIM_MOVED) ;
				}
			}
		} else {
			GetCursorPos (&pt) ;
			ScreenToClient (hStatusWnd, &pt) ;
			GetClientRect (hStatusWnd, &rc) ;
			if (pt.x < rc.left || pt.y < rc.top || pt.x >= rc.right || pt.y >= rc.bottom){
				if (dwMouse & FIM_FOCUS){
					/* Mouse Cursor �� Window �ɓ����ė����B*/
					ReleaseCapture () ;
					dwMouse	= dwMouse & ~FIM_FOCUS ;
					SetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE, dwMouse) ;
				}
			} else {
				if (!(dwMouse & FIM_FOCUS)){
					/* Mouse Cursor �� Window �ɓ����ė����B*/
					SetCapture (hStatusWnd) ;
					dwMouse	= dwMouse | FIM_FOCUS ;
					SetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE, dwMouse) ;
				}
			}
			UIStatus_changeCursor (hStatusWnd) ;
			UIStatus_paint (hStatusWnd, hDC, 0) ;
		}
		break ;

	case WM_RBUTTONUP:
		dwMouse	= GetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE) ;
		DEBUGPRINTFEX (104, (TEXT ("UIStatus_onButton (WM_RBUTTONUP, dwMouse:0x%x)\n"), dwMouse)) ;
		if (dwMouse & FIM_CAPUTURED){
			if (dwMouse & FIM_MOVED){
				DrawUIBorder (&drc) ;
				GetCursorPos (&pt) ;
				MoveWindow (hStatusWnd,
							pt.x - ptdif.x,
							pt.y - ptdif.y,
							rc.right,
							rc.bottom, TRUE) ;
			}
		}
		hSvrWnd	= (HWND)GetWindowLongPtr (hStatusWnd,	FIGWL_UISTATE_SVRWND) ;
		hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,		IMMGWLP_IMC) ;
		if (hIMC)
			UIStatus_onRightMenu (hIMC, hStatusWnd) ;
		UIStatus_paint (hStatusWnd, hDC, 0) ;
		SetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE, dwMouse & FIM_FOCUS) ;
		SetWindowLong (hStatusWnd, FIGWL_UISTATE_PUSHSTATUS, 0L) ;
		break ;

	case WM_LBUTTONUP:
		dwMouse	= GetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE) ;
		DEBUGPRINTFEX (104, (TEXT ("UIStatus_onButton (WM_LBUTTONUP, dwMouse:0x%x)\n"), dwMouse)) ;
		if (dwMouse & FIM_CAPUTURED){
			if (dwMouse & FIM_MOVED){
				DrawUIBorder (&drc) ;
				GetCursorPos (&pt) ;
				MoveWindow (hStatusWnd,
							pt.x - ptdif.x,
							pt.y - ptdif.y,
							rc.right,
							rc.bottom, TRUE) ;
			}
		}
		hSvrWnd	= (HWND)GetWindowLongPtr (hStatusWnd,	FIGWL_UISTATE_SVRWND) ;
		hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,		IMMGWLP_IMC) ;
		if (hIMC){
			GetCursorPos (&pt) ;
			dwPushedStatus	= GetWindowLong (hStatusWnd, FIGWL_UISTATE_PUSHSTATUS) ;
			dwPushedStatus	&= UIStatus_checkPushedStatus (hStatusWnd, &pt) ;
			if (dwPushedStatus & PUSHED_STATUS_MODE){
				UIStatus_onLeftMenu (hIMC, hStatusWnd) ;
			} else if (dwPushedStatus & PUSHED_STATUS_ONOFF){
				BOOL	fOpen	= ImmGetOpenStatus (hIMC) ;
				fOpen	= !fOpen ;
				ImmSetOpenStatus (hIMC, fOpen) ;
			}
		}
		UIStatus_paint (hStatusWnd, hDC, 0) ;
		SetWindowLong (hStatusWnd, FIGWL_UISTATE_MOUSE, dwMouse & FIM_FOCUS) ;
		SetWindowLong (hStatusWnd, FIGWL_UISTATE_PUSHSTATUS, 0L) ;
		break ;
	default:
		break ;
	}
	ReleaseDC (hStatusWnd, hDC) ;
	return ;
}

/*
 *	status window �����N���b�N���ꂽ���̃��j���[�������֐��B
 *-----
 *(�R�����g)
 *	UIStatus_showLeftMenu () ���Ăяo���� PopupMenu ��\������B
 *	UIStatus_showLeftMenu () �̕Ԃ�l�� PopupMenu �̂ǂ̍��ڂ��I������
 *	���̂�������A��������ē��̓��[�h�̐؂�ւ����s���B
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
BOOL
UIStatus_onLeftMenu (
	register HIMC		hIMC,
	register HWND		hwnd)
{
	register BOOL	fOpen ;
	register int	nCmd ;

	/* �|�b�v�A�b�v���j���[��\������B*/
	nCmd	= UIStatus_showLeftMenu (hIMC, hwnd) ;
	if (nCmd < 0 || nCmd == IDCANCEL)
		return	TRUE ;

	if (IDM_CMODE_TO_ASCII <= nCmd && nCmd <= IDM_CMODE_TO_ZENEI){
		ChangeConversionMode (hIMC, nCmd) ;
	} else if (nCmd == IDM_CMODE_TO_DIRECTINPUT){
		fOpen	= ImmGetOpenStatus (hIMC) ;
		if (fOpen)
			ImmSetOpenStatus (hIMC, FALSE) ;
	} else {
		return	FALSE ;
	}
	return	TRUE ;
}

/*
 *	status window ���E�N���b�N���ꂽ���̃��j���[�������֐��B
 *-----
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
BOOL
UIStatus_onRightMenu (
	register HIMC		hIMC,
	register HWND		hwnd)
{
	register HWND		hUIWnd ;
	register BOOL		fOpen ;
	register int		nCmd ;

	nCmd	= UIStatus_showRightMenu (hIMC, hwnd) ;
	if (nCmd < 0 || nCmd == IDCANCEL)
		return	TRUE ;
	switch (nCmd){
	case	IDM_SHOW_PROPERTY_WINDOW:
	{
		ImeConfigure (GetKeyboardLayout(0), 0, IME_CONFIG_GENERAL, 0) ;
		break ;
	}
	case	IDM_HIDE_TOOLBAR:
	{
		SetRegDwordValue (TEXT ("\\Window"), TEXT (REGKEY_HIDETOOLBAR), 1) ;
		hUIWnd	= (HWND)GetWindowLongPtr (hwnd, FIGWL_UISTATE_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_STATEHIDE, (WPARAM)0, (LPARAM)0) ;
		UpdateIndicIcon (hIMC) ;
		break ;
	}
	case	IDM_RECONVERT:
	{
		DWORD	dwSize	= (DWORD) MyImmRequestMessage (hIMC, IMR_RECONVERTSTRING, 0) ;
		if (dwSize) {
			register LPRECONVERTSTRING	lpRS ;

			lpRS			= (LPRECONVERTSTRING) GlobalAlloc (GPTR, dwSize) ;
			lpRS->dwSize	= dwSize ;
			if (dwSize = (DWORD) MyImmRequestMessage (hIMC, IMR_RECONVERTSTRING, (LPARAM) lpRS)) {
				register LPINPUTCONTEXT			lpIMC ;

				lpIMC	= ImmLockIMC (hIMC) ;
				if (lpIMC != NULL) {
					register LPCOMPOSITIONSTRING	lpCompStr ;
					if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
						goto	pass_1 ;
					/*	�ϊ����[�h�������I�ɉ������̓��[�h�ɐݒ肷��B*/
					lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
					if (lpCompStr != NULL) {
						if (! ImmGetOpenStatus (hIMC))
							ImmSetOpenStatus (hIMC, TRUE) ;
						SKKSetReconvertStr (hIMC, lpIMC, lpCompStr, lpRS, TRUE) ; // ?
						ImmUnlockIMCC (lpIMC->hCompStr) ;
					}
				pass_1:
					ImmUnlockIMC (hIMC) ;
				}
				MyImmRequestMessage(hIMC, IMR_CONFIRMRECONVERTSTRING, (LPARAM)lpRS);
			} else {
				GlobalFree((HANDLE)lpRS);
			}
		}
	}
	case	IDM_TOGGLEGAMEMODE:
	{
		SetRegDwordValue (NULL, TEXT(REGKEY_ENABLEGAMEMODE), !skkime_IsEnableGameMode ()) ;
		break ;
	}
	default:
		if (IDM_CMODE_TO_ASCII <= nCmd && nCmd <= IDM_CMODE_TO_ZENEI){
			ChangeConversionMode (hIMC, nCmd) ;
		} else if (nCmd == IDM_CMODE_TO_DIRECTINPUT){
			fOpen	= ImmGetOpenStatus (hIMC) ;
			if (fOpen)
				ImmSetOpenStatus (hIMC, FALSE) ;
		}
		break ;
	}
	return	TRUE ;
}

/*
 *	Status Window �����N���b�N�������̃��j���[���쐬�A���[�U�̑I�����ʂ𓾂�֐��B
 *----
 *(�R�����g)
 *	���j���[���쐬�Ƃ����̂́ACreatePopupMenu () ����Ƃ������ƂŁA
 *	���[�U�̑I�����ʂ𓾂�Ƃ����̂́ATrackPopupMenu () ���Ă��܂��Ƃ������ƁB
 *	���̊֐��� TrackPopupMenu �̕Ԃ�l��Ԃ��܂��B
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
int
UIStatus_showLeftMenu (
	register HIMC		hIMC,
	register HWND		hwnd)
{
	static	MYMENUITEMINFO	myLeftMenuItemInfoTbl []	= {
	  { MIIM_TYPE,	MFT_SEPARATOR, 0, NULL, },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0, IDCANCEL, TEXT ("�L�����Z��"), },
	} ;
	HMENU			hMenu ;
	POINT			pos ;
	int				nCmd ;
	MENUITEMINFO	menuItemInfo ;
	LPINPUTCONTEXT	lpIMC ;
	int				i ;
	int				iPosition ;

	GetCursorPos ((LPPOINT)&pos) ;

	/* �|�b�v�A�b�v���j���[���쐬����B*/
	hMenu	= CreatePopupMenu () ;
	if (!hMenu)
		return	-1 ;

	iPosition	= 0 ;
	UIStatus_insertInputModeMenu (hIMC, hMenu, &iPosition) ;
	/* �|�b�v�A�b�v���j���[�̍��ڂ�����������B*/
	for (i = 0 ; i < sizeof (myLeftMenuItemInfoTbl) / sizeof (MYMENUITEMINFO) ; i ++){
		int		nResult ;

		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= myLeftMenuItemInfoTbl [i].m_fMask ;
		menuItemInfo.fType			= myLeftMenuItemInfoTbl [i].m_fType ;
		menuItemInfo.wID			= myLeftMenuItemInfoTbl [i].m_wID ;
		if (menuItemInfo.fMask & MIIM_STATE)
			menuItemInfo.fState	= MFS_ENABLED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		//menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= myLeftMenuItemInfoTbl [i].m_dwTypeData ;
		if (!menuItemInfo.dwTypeData){
			menuItemInfo.cch		= 0 ;
		} else {
			menuItemInfo.cch		= lstrlen (menuItemInfo.dwTypeData) ;
		}
		nResult	= InsertMenuItem (hMenu, iPosition, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		if (nResult == 0 && (menuItemInfo.fMask & MIIM_STRING) != 0) {
			menuItemInfo.fMask	&= ~MIIM_STRING ;
			menuItemInfo.fMask	|= MIIM_TYPE ;
			menuItemInfo.fType	|= MFT_STRING ;
			nResult	= InsertMenuItem (hMenu, iPosition, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		}
		if (nResult != 0)
			iPosition	++ ;
	}
	/* �|�b�v�A�b�v���j���[��\�����A�I�����ʂ𓾂�B*/
	nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTALIGN | TPM_BOTTOMALIGN, pos.x, pos.y, 0, hwnd, NULL) ;
	DestroyMenu (hMenu) ;
	return	nCmd ;
}

/*
 *	Status Window ���E�N���b�N�������̃��j���[���쐬�A���[�U�̑I�����ʂ𓾂�֐��B
 *----
 *(�R�����g)
 *	UIStatus_showLeftMenu ���Q�Ƃ̂��ƁB
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
int
UIStatus_showRightMenu (
	register HIMC		hIMC,
	register HWND		hwnd)
{
	static	MYMENUITEMINFOEX	myRightMenuItemInfoTbl []	= {
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,				0,
		IDM_HIDE_TOOLBAR,			TEXT ("�^�X�N�o�[�ɓ����(&I)"),	NULL },
	  { MIIM_TYPE,										MFT_SEPARATOR,	
		0,							NULL,								NULL },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,				0,
		IDM_SHOW_PROPERTY_WINDOW,	TEXT ("�v���p�e�B(&R)"), 			NULL },
	  {	MIIM_STATE | MIIM_TYPE | MIIM_ID | MIIM_STRING,	MFT_RADIOCHECK,
		IDM_TOGGLEGAMEMODE,			TEXT ("�Q�[�����[�h(&G)"),			uiStatus_getStateToggleGameMode },
	  { MIIM_TYPE,										MFT_SEPARATOR,
		0,							NULL,								NULL },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,				0,
		IDM_RECONVERT,				TEXT ("�ĕϊ�(&C)"),				NULL },
	  { MIIM_TYPE,										MFT_SEPARATOR,	
		0,							NULL,								NULL },
	  { MIIM_STATE | MIIM_SUBMENU | MIIM_STRING,		0,
		0,							TEXT ("���̓��[�h(&N)"),			NULL },
	  { MIIM_TYPE,										MFT_SEPARATOR,	
		0,							NULL,								NULL },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,				0,
		IDCANCEL,					TEXT ("�L�����Z��"),				NULL },
	} ;
	register HMENU	hMenu ;
	register HMENU	hSubMenu ;
	register int	nCmd ;
	int				iMenuItem ;
	POINT			pos ;
	MENUITEMINFO	menuItemInfo ;

	GetCursorPos ((LPPOINT)&pos) ;
	hMenu		= CreatePopupMenu () ;
	if (!hMenu)
		return	-1 ;
	hSubMenu	= CreatePopupMenu () ;
	if (!hSubMenu){
		DestroyMenu (hMenu) ;
		return	-1 ;
	}
	iMenuItem	= 0 ;
	UIStatus_insertInputModeMenu (hIMC, hSubMenu, &iMenuItem) ;

	iMenuItem	= 0 ;
	while (iMenuItem < NELEMENTS (myRightMenuItemInfoTbl)) {
		int		nResult ;

		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= myRightMenuItemInfoTbl [iMenuItem].m_fMask ;
		menuItemInfo.fType			= myRightMenuItemInfoTbl [iMenuItem].m_fType ;
		menuItemInfo.wID			= myRightMenuItemInfoTbl [iMenuItem].m_wID ;
		menuItemInfo.fState			= (myRightMenuItemInfoTbl [iMenuItem].m_pGetStateProc != NULL)?  (myRightMenuItemInfoTbl [iMenuItem].m_pGetStateProc)() : 0 ;
		if (menuItemInfo.fMask & MIIM_STATE)
			menuItemInfo.fState		|= MFS_ENABLED ;
		menuItemInfo.hSubMenu		= (menuItemInfo.fMask & MIIM_SUBMENU)? hSubMenu : 0 ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		//menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= myRightMenuItemInfoTbl [iMenuItem].m_dwTypeData ;
		if (!menuItemInfo.dwTypeData){
			menuItemInfo.cch		= 0 ;
		} else {
			menuItemInfo.cch		= lstrlen (myRightMenuItemInfoTbl [iMenuItem].m_dwTypeData) ;
		}
		nResult	= InsertMenuItem (hMenu, iMenuItem, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		if (nResult == 0 && (menuItemInfo.fMask & MIIM_STRING) != 0) {
			/*	Windows2000 �� MIIM_STRING �̈������s���BMIIM_TYPE �������Ă���Ɠ����Ȃ��Ƃ�
			 *	�s�v�c�ȓ��������悤�Ɍ�����B
			 */
			menuItemInfo.fMask	&= ~MIIM_STRING ;
			menuItemInfo.fMask	|= MIIM_TYPE ;
			menuItemInfo.fType	|= MFT_STRING ;
			nResult	= InsertMenuItem (hMenu, iMenuItem, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		}
		if (nResult != 0)
			iMenuItem	++ ;
	}
	nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTALIGN | TPM_BOTTOMALIGN, pos.x, pos.y, 0, hwnd, NULL) ;
	DestroyMenu (hMenu) ;
	DestroyMenu (hSubMenu) ;
	return	nCmd ;
}

BOOL
UIStatus_insertInputModeMenu (
	register HIMC		hIMC,
	register HMENU		hMenu,
	register int FAR*	lpiPosition)
{
	static	MYMENUITEMINFO	myMenuItemInfoTbl []	= {
	  {	MIIM_STATE | MIIM_TYPE | MIIM_ID | MIIM_STRING,
		MFT_RADIOCHECK,
		IDM_CMODE_TO_ASCII,			TEXT ("�A�X�L�[(&S)"), },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID | MIIM_STRING,
		MFT_RADIOCHECK,
		IDM_CMODE_TO_ROMANHIRA,		TEXT ("���[�}��������(&H)"), },
	  {	MIIM_STATE | MIIM_TYPE | MIIM_ID | MIIM_STRING,
		MFT_RADIOCHECK,
		IDM_CMODE_TO_ROMANKATA,		TEXT ("���[�}���Љ���(&K)"), },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID | MIIM_STRING,
		MFT_RADIOCHECK,
		IDM_CMODE_TO_JISX0201KANA,	TEXT ("���p�Љ���(&A)"), },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID | MIIM_STRING,
		MFT_RADIOCHECK,
		IDM_CMODE_TO_ZENEI,			TEXT ("�S�p�p��(&E)"), },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID | MIIM_STRING,
		MFT_RADIOCHECK,
		IDM_CMODE_TO_DIRECTINPUT,	TEXT ("���ړ���(&C)"), },
	} ;
	static const int	myInputModeTbl[]	= { 5, 1, 2, 4, 0, 3, } ;
	register LPINPUTCONTEXT	lpIMC ;
	register int			iNum ;
	register int			i ;
	register int			iPosition ;
	MENUITEMINFO			menuItemInfo ;

	/* �����̐������`�F�b�N�B*/
	if (!hMenu || !lpiPosition)
		return	FALSE ;

	/* ���݂̓��̓��[�h�𓾂�B*/
	lpIMC	= (LPINPUTCONTEXT)ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	iNum	= myInputModeTbl [BTYFromCmode (lpIMC) / STATUS_BTNY] ;
	ImmUnlockIMC (hIMC) ;
	iPosition	= *lpiPosition ;
	/* ���j���[��ǉ�����B*/
	for (i = 0 ; i < sizeof (myMenuItemInfoTbl) / sizeof (MYMENUITEMINFO) ; i ++){
		int	nResult ;

		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= myMenuItemInfoTbl [i].m_fMask ;
		menuItemInfo.fType			= myMenuItemInfoTbl [i].m_fType ;
		menuItemInfo.wID			= myMenuItemInfoTbl [i].m_wID ;
		menuItemInfo.fState			= (i == iNum)? MFS_CHECKED : MFS_UNCHECKED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		//menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= myMenuItemInfoTbl [i].m_dwTypeData ;
		menuItemInfo.cch			= lstrlen (menuItemInfo.dwTypeData) ;

		nResult	= InsertMenuItem (hMenu, iPosition, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		if (nResult == 0 && (menuItemInfo.fMask & MIIM_STRING) != 0) {
			menuItemInfo.fMask	&= ~MIIM_STRING ;
			menuItemInfo.fMask	|= MIIM_TYPE ;
			menuItemInfo.fType	|= MFT_STRING ;
			nResult	= InsertMenuItem (hMenu, iPosition, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		}
		if (nResult != 0)
			iPosition	++ ;
	}
	*lpiPosition	= iPosition ;
	return	TRUE ;
}

/*
 *	�ϊ����[�h�̃r�b�g�}�b�v���쐬����֐��B
 *-----
 *(�R�����g)
 *	�ϊ����[�h = �������[�h�A���ړ��̓��[�h�Ȃ� ��\������̂Ɏg�� bitmap ��
 *	Resource ����ǂݍ��ށB
 *(����)
 *	HWND	hwnd		���̃r�b�g�}�b�v�𗘗p���� Window�B
 *
 *	���[�ށA�Ȃ�Ƃ��������Ȃ��������c�������K�v�A���B
 */
HBITMAP
UIStatus_createCModeBitmap (HWND hwnd)
{
	register HDC		hDC, hMemDC, hSrcMemDC, hOrgMemDC ;
	register HBRUSH		hbrushOld ;
	register HBITMAP	hbmpStatus, hbmpOld ;
	register HBITMAP	hbmpSrcOld,	hbmpSrc ;
	register HBITMAP	hbmpOrgOld, hbmpOrg ;
	register int		y, i ;

	hDC			= CreateDC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
	hbmpStatus	= CreateCompatibleBitmap (hDC, STATUSCMODE_BTNX * 4, STATUSCMODE_BTNY * NUM_STATUS_BMP_MODES) ;
	hMemDC		= CreateCompatibleDC (hDC) ;
	hbmpOld		= SelectObject (hMemDC, hbmpStatus) ;
	hbrushOld	= SelectObject (hMemDC, GetSysColorBrush (COLOR_3DFACE)) ;
	PatBlt (hMemDC, 0, 0, STATUSCMODE_BTNX * 4, STATUSCMODE_BTNY * NUM_STATUS_BMP_MODES, PATCOPY) ;
	SelectObject (hMemDC, hbrushOld) ;

	hbmpOrg		= (HBITMAP)GetWindowLongPtr (hwnd, FIGWL_UISTATE_STATUSORGBMP) ;
	hOrgMemDC	= CreateCompatibleDC (hDC) ;
	hbmpOrgOld	= SelectObject (hOrgMemDC, hbmpOrg) ;
	hbmpSrc		= CreateCompatibleBitmap (hDC, STATUSCMODE_BTNX * NUM_WIDTH_STATUS_BMP, STATUSCMODE_BTNY * NUM_HEIGHT_STATUS_BMP) ;
	hSrcMemDC	= CreateCompatibleDC (hDC) ;
	hbmpSrcOld	= SelectObject (hSrcMemDC, hbmpSrc) ;
	BitBlt (hSrcMemDC, 0,					0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * NUM_HEIGHT_STATUS_BMP, hOrgMemDC, 0, 0, SRCCOPY) ;
	BitBlt (hSrcMemDC, STATUSCMODE_BTNX,	0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * NUM_HEIGHT_STATUS_BMP, hOrgMemDC, 0, 0, NOTSRCCOPY) ;

	for (i = 0 ; i < NUM_STATUS_BMP_MODES ; i ++){
		BitBlt (hMemDC, STATUSCMODE_BTNX * i, 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * INDEX_STATUS_BMP_LU, hSrcMemDC, 0, 0, SRCAND) ;
	}
	for (y = 0 ; y < NUM_STATUS_BMP_MODES ; y ++){
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * INDEX_STATUS_BMP_LU, SRCINVERT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * INDEX_STATUS_BMP_RB, SRCINVERT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * INDEX_STATUS_BMP_RB2, SRCINVERT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * INDEX_STATUS_BMP_LU2, SRCINVERT) ;
	}

	/*	���̒i�K�ł� 0,1,6-9 �� temporary �̍�Ɨ̈�Ƃ��ė��p�����B
	 *	���ʂ́A0-5�ɍ쐬�����̂ŁA���̕���������Ȃ���΂Ȃ�Ȃ��B
	 */
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DLIGHT)) ;
	PatBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DSHADOW)) ;
	PatBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 1, STATUSCMODE_BTNX, STATUSCMODE_BTNY, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 6, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 0, SRCAND) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 7, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 1, SRCAND) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 8, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 0, SRCAND) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 9, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 1, SRCAND) ;
	for (y = 0 ; y < NUM_STATUS_BMP_MODES ; y ++){
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * 6, SRCPAINT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * 7, SRCPAINT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * 8, SRCPAINT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY, hSrcMemDC, 0, STATUSCMODE_BTNY * 9, SRCPAINT) ;
	}

	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_GRAYTEXT)) ;
	PatBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 6, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	BitBlt (hSrcMemDC, 0, 0, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * 6, hSrcMemDC, STATUSCMODE_BTNX, 0, SRCAND) ;
	BitBlt (hMemDC, STATUSCMODE_BTNX * 3, 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 6, hSrcMemDC, 0, 0, SRCPAINT) ;
	BitBlt (hMemDC, STATUSCMODE_BTNX * 3, 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 6, hOrgMemDC, STATUSCMODE_BTNX * 1, 0, SRCPAINT) ;
	SelectObject (hOrgMemDC, hbmpOrgOld) ;
	DeleteDC (hOrgMemDC) ;

	SelectObject (hSrcMemDC, hbmpSrcOld) ;
	DeleteDC (hSrcMemDC) ;
	DeleteObject (hbmpSrc) ;
	SelectObject (hMemDC, hbmpOld) ;
	DeleteDC (hMemDC) ;
	DeleteDC (hDC) ;
	return	hbmpStatus ;
}

HBITMAP
UIStatus_createOnOffBitmap (
	register HWND		hwnd)
{
	register HDC		hDC, hMemDC, hSrcMemDC, hOrgMemDC ;
	register HBRUSH		hbrushOld ;
	register HBITMAP	hbmpStatus, hbmpOld ;
	register HBITMAP	hbmpSrcOld,	hbmpSrc ;
	register HBITMAP	hbmpOrgOld, hbmpOrg ;

	hDC			= CreateDC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
	hbmpStatus	= CreateCompatibleBitmap (hDC, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2) ;
	hMemDC		= CreateCompatibleDC (hDC) ;
	hbmpOld		= SelectObject (hMemDC, hbmpStatus) ;
	hbrushOld	= SelectObject (hMemDC, GetSysColorBrush (COLOR_3DFACE)) ;
	PatBlt (hMemDC, 0, 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2, PATCOPY) ;
	SelectObject (hMemDC, hbrushOld) ;

	hbmpOrg		= (HBITMAP)GetWindowLongPtr (hwnd, FIGWL_UISTATE_CLOSEORGBMP) ;
	hOrgMemDC	= CreateCompatibleDC (hDC) ;
	hbmpOrgOld	= SelectObject (hOrgMemDC, hbmpOrg) ;
	hbmpSrc		= CreateCompatibleBitmap (hDC, UISTATE_ONOFFBMP_SRC_WIDTH, UISTATE_ONOFFBMP_SRC_HEIGHT) ;
	hSrcMemDC	= CreateCompatibleDC (hDC) ;
	hbmpSrcOld	= SelectObject (hSrcMemDC, hbmpSrc) ;
	BitBlt (hSrcMemDC, 0, 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 5, hOrgMemDC, 0, 0, SRCCOPY) ;
	SelectObject (hOrgMemDC, hbmpOrgOld) ;
	DeleteDC (hOrgMemDC) ;

	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 2, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 2, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 0, SRCPAINT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 1, SRCPAINT) ;
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DLIGHT)) ;
	PatBlt (hSrcMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DSHADOW)) ;
	PatBlt (hSrcMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 4, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 4, SRCINVERT) ;
	BitBlt (hSrcMemDC, 0, STATUSONOFF_BTNY * 3, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 0, SRCAND) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2, 
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCPAINT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, 
			hSrcMemDC, 0, STATUSONOFF_BTNY * 4, SRCPAINT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, 
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCPAINT) ;
	SelectObject (hSrcMemDC, hbmpSrcOld) ;
	DeleteObject (hbmpSrc) ;
	DeleteDC (hSrcMemDC) ;
	SelectObject (hMemDC, hbmpOld) ;
	DeleteDC (hMemDC) ;
	DeleteDC (hDC) ;
	return	hbmpStatus ;
}

/*
 *	Status Window ���N���b�N���ꂽ���ɂ��̏ꏊ�Ɋ��蓖�Ă�ꂽ�@�\�������𒲂ׂ�֐��B
 *----
 */
DWORD	PASCAL
UIStatus_checkPushedStatus (
	register HWND			hStatusWnd,
	register LPPOINT		lppt)
{
	POINT	pt ;
	RECT	rc ;

	if (lppt){
		pt	= *lppt ;
		ScreenToClient (hStatusWnd, &pt) ;
		GetClientRect  (hStatusWnd, &rc) ;
		if (!PtInRect (&rc, pt))
			return	0L ;
		if (pt.x < STATUSONOFF_BTNX){
			if (pt.y < 10){
				return	PUSHED_STATUS_ONOFF ;
			} else {
				return	PUSHED_STATUS_MOVE ;
			}
		}
		return	PUSHED_STATUS_MODE ;
	}
	return	0L ;
}

void	PASCAL
UIStatus_changeCursor (
	register HWND		hwnd)
{
	POINT	pt ;
	HCURSOR	hCursor ;
	BOOL	fIn ;
	RECT	rc ;

	/* �}�E�X�J�[�\���̈ʒu�𓾂�B*/
	GetCursorPos (&pt) ;
	GetWindowRect (hwnd, &rc) ;
	fIn	= PtInRect (&rc, pt) ;
	ScreenToClient (hwnd, &pt) ;

	hCursor	= (HCURSOR)GetWindowLongPtr (hwnd, FIGWL_UISTATE_CURSOR) ;
	/* �}�E�X�J�[�\���̈ʒu����J�[�\���̌`����ǂ̂悤�ɂ��邩���肷��B*/
	if (STATUSONOFF_X <= pt.x && pt.x < STATUSCMODE_X &&
		10            <= pt.y && pt.y < STATUSONOFF_BTNY){
		/* ���݂̃J�[�\����ۑ�����B��񂫂�B*/
		if (!hCursor)
			SetWindowLongPtr (hwnd, FIGWL_UISTATE_CURSOR, (LONG_PTR)GetCursor ()) ;
		/* �J�[�\���̌`���ύX����B*/
		(void)SetCursor (LoadCursor (NULL, IDC_SIZEALL)) ;
	} else {
		/* �ȑO�̃J�[�\���ɖ߂��B*/
		hCursor	= hCursor? hCursor : LoadCursor (NULL, IDC_ARROW) ;
		if (hCursor) 
			SetCursor (hCursor) ;
		SetWindowLongPtr (hwnd, FIGWL_UISTATE_CURSOR, (LONG_PTR)0) ;
	}
	return ;
}

DWORD
uiStatus_getStateToggleGameMode (void)
{
	return	skkime_IsEnableGameMode ()? MFS_CHECKED : MFS_UNCHECKED ;
}


