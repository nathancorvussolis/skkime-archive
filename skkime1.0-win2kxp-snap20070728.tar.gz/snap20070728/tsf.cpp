#if !defined (NO_TSF)
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
extern "C" {
#include "skki1_0.h"
#include "common\confcommon.h"
#include "resource.h"
}
#include "common\msctf_.h"
#include "tsf.h"

/*
#undef	DEBUGPRINTF
#undef	DEBUGPRINTFEX
#undef	DBG
#define	DBG	1
#define	DEBUGPRINTF(arg)			DebugPrintf##arg
#define	DEBUGPRINTFEX(level,arg)	DebugPrintf##arg
#define	TSF_MUTEX	1
*/

#define	NUM_LANGBAR_ITEM_BUTTON	(2)
#define	NUM_TSF_GETITEMS		(15)
#define	TSF_WAITTIME			(3 * 1000)

#define	REGPATH_CTF_PATH						TEXT("Software\\Microsoft\\CTF")
#define	REGKEY_CTF_DISABLE_THREAD_INPUT_MANAGER	TEXT("Disable Thread Input Manager")

typedef HRESULT (WINAPI *PTF_GETTHREADMGR)(ITfThreadMgr **pptim) ;

/*========================================================================
 *	prototypes
 */
static	ITfThreadMgr*		_QueryThreadMgr					(void) ;
static	ITfLangBarItemMgr*	_QueryLangBarItemMgr			(void) ;
static	BOOL				_IsCtfThreadInputManagerEnabled (void) ;
static	void				_DumpLangBarItem				(void) ;
static	BOOL				_showKeyboardIcon				(ITfLangBarItemMgr*, BOOL fShow) ;

/*========================================================================
 *	global variables
 */
static	HMODULE				g_hMSCTF			= NULL ;
static	TfClientId			g_tfClientID ;
static	BOOL				g_bInitTSF			= FALSE ;

// {830DE831-E04D-40bb-8683-1E179A5F1A4F}
/*
 *	���� class id �� skimic.dll �̗��p���Ă�����̂����A������g���Ă͂����Ȃ�
 *	�悤���B���ۂɎg�� class id �ɂ��Ắc
 *
const CLSID	c_clsidSkkImeTextService	= {
	0x830de831, 0xe04d, 0x40bb, { 0x86, 0x83, 0x1e, 0x17, 0x9a, 0x5f, 0x1a, 0x4f }
} ;
*/
/*	���� IME �Ƃ����{�^���Ɠ��� CLSID �ɐݒ肷��K�v������悤���BMS-IME2002 ��
 *	�������Q�Ƃ���ɁB
 */
const CLSID	c_clsidSkkImeTextService	= {
	0x77B34286, 0xED57, 0x45E2, { 0x97, 0x66, 0xD8, 0xC5, 0xFE, 0x3D, 0xFB, 0x2C }
} ;

// {930C0CDC-A91F-4d7c-B23A-67749D4EBFCD}
const GUID	c_guidSkkImeProfile = {
	0x930c0cdc, 0xa91f, 0x4d7c, { 0xb2, 0x3a, 0x67, 0x74, 0x9d, 0x4e, 0xbf, 0xcd }
} ;

// {D97B240A-2C61-4b9b-AECF-D5C3CFDDFCBB}
const GUID	c_guidItemButtonCMode = {
	0xd97b240a, 0x2c61, 0x4b9b, { 0xae, 0xcf, 0xd5, 0xc3, 0xcf, 0xdd, 0xfc, 0xbb }
} ;

// {68D148D7-E134-45ef-B596-C5EE7915F819}
const GUID	c_guidItemButtonIME	= {
	0x68d148d7, 0xe134, 0x45ef, { 0xb5, 0x96, 0xc5, 0xee, 0x79, 0x15, 0xf8, 0x19 }
} ;

static	const GUID	c_guidTsfItemButtonIME	= {
	0xeda78bbb, 0x65f7, 0x4a1b, { 0x95, 0x51, 0x30, 0x9d, 0x9f, 0xe6, 0x20, 0xc }
} ;

static	const GUID	c_guidTsfItemButtonCMode = {
	0x82fd14c8, 0xa99a, 0x4882, { 0xa6, 0xe5, 0x74, 0x93, 0xca, 0x67, 0x86, 0x6a }
} ;

/*	���� button �Ɍ����邪�Askimic.dll �Ɠ������̂��g���͔̂����Ȃ���΂Ȃ��
 *	���悤���B�����ɂ��Ă���̂��Ƃ�������ς����s�������c�B
 *
// {EDA78BBB-65F7-4a1b-9551-309D9FE6200C}
const GUID	c_guidItemButtonIME	= {
	0xeda78bbb, 0x65f7, 0x4a1b, { 0x95, 0x51, 0x30, 0x9d, 0x9f, 0xe6, 0x20, 0xc }
} ;
*/

/*	�L�[�{�[�h�{�^���� GUID�B���炭�͂��̒l�ň�ӂɌ��肷�锤�B
 */
const GUID	c_guidKeyboardItemButton	= {
	0x34745C63, 0xB2F0, 0x4784, { 0x8B, 0x67, 0x5E, 0x12, 0xC8, 0x70, 0x1A, 0x31 }
} ;

/*========================================================================
 *	functions
 */
BOOL	PASCAL
bTSF_InitLanguageBar (void)
{
	DEBUGPRINTF ((TEXT ("Enter::InitLanguageBar\n"))) ;

	/*	Logon ���ɂ� TSF �͌Ăяo���Ȃ��B*/
	if (g_bSkkImeSecure) 
		return	FALSE ;
	if (g_bInitTSF) 
		return	TRUE ;

	g_hMSCTF		= LoadLibrary (TEXT ("msctf.dll")) ;
	/*	LoadLibrary �̌��ʂ͌��Ȃ��B���s�����ꍇ���A���s�����Ƃ����󋵂ŏ������͊���
	 *	���� (TSF �͂����g��Ȃ��Ɛݒ�) �Ƃ���B
	 */
	g_bInitTSF	= TRUE ;
	return	TRUE ;
}

BOOL	PASCAL
bTSF_IsTSFEnabled (void)
{
	register BOOL		bRetval		= FALSE ;

	if (g_bSkkImeSecure) 
		return	FALSE ;

	if (g_bInitTSF) {
		if (g_hMSCTF != NULL) {
			bRetval	= _IsCtfThreadInputManagerEnabled () ;
		}
	} else {
		register HMODULE	hMSCTF ;

		hMSCTF	= LoadLibrary (TEXT ("msctf.dll")) ;
		if (hMSCTF != NULL) {
			FreeLibrary (hMSCTF) ;
			bRetval	= _IsCtfThreadInputManagerEnabled () ;
		}
	}
	return	bRetval ;
}

BOOL	PASCAL
bTSF_UpdateLanguageBarIfSelected (void)
{
	TCHAR	szFile [32] ;
	HKL		hKL ;

	hKL	= GetKeyboardLayout (0) ;
	ImmGetIMEFileName (hKL, szFile, sizeof (szFile) / sizeof (TCHAR)) ;
	if (!lstrcmpi (szFile, MyFileName)) 
		return	bTSF_UpdateLanguageBar () ;
	return	FALSE ;
}

BOOL	PASCAL
bTSF_UpdateLanguageBar (void)
{
	register ITfLangBarItemMgr*	pLangBarItemMgr			= NULL ;
	register ITfThreadMgr*		pThreadMgr ;
	register DWORD				dwValue ;
	register BOOL				fRetval	= FALSE ;
	register BOOL				fShowKeyboardIcon, fShowIMEIcon, fShowInputModeIcon ;
	register HANDLE				hMutex ;

	if (g_bSkkImeSecure)
		return	FALSE ;

	if (g_hMSCTF == NULL || ! _IsCtfThreadInputManagerEnabled ())
		goto	exit_func ;

	DEBUGPRINTFEX (106, (TEXT ("[enter] bTSF_UpdateLanguageBar ()\n"))) ;

	/*	���񃌃W�X�g�����Q�Ƃ���̂͐������̂��낤���H */
	fShowKeyboardIcon	= fShowIMEIcon	= fShowInputModeIcon	= TRUE ;
#if !defined (NO_TOUCH_REGISTRY)
	if (GetRegDwordValue (TEXT ("\\CICERO"), REGKEY_SHOWKEYBRDICON, &dwValue))
		fShowKeyboardIcon	= (BOOL) dwValue ;
	if (GetRegDwordValue (TEXT ("\\CICERO"), REGKEY_SHOWIMEICON, &dwValue))
		fShowIMEIcon		= (BOOL) dwValue ;
	if (GetRegDwordValue (TEXT ("\\CICERO"), REGKEY_SHOWINPUTMODEICON, &dwValue))
		fShowInputModeIcon	= (BOOL) dwValue ;
#endif
	pLangBarItemMgr	= _QueryLangBarItemMgr () ;
	if (pLangBarItemMgr != NULL) {
		ITfLangBarItem*		pItem ;
					
		if (g_bInitTSF) {
			__try {
				if (fShowInputModeIcon) {
					pItem	= NULL ;
					if (pLangBarItemMgr->GetItem (c_guidItemButtonCMode, &pItem) == S_OK && pItem != NULL) {
						hrButtonCMode_Update (pItem) ;
						pItem->Release () ;
					}
				}
				if (fShowIMEIcon) {
					pItem	= NULL ;
					if (pLangBarItemMgr->GetItem (c_guidItemButtonIME, &pItem) == S_OK && pItem != NULL) {
						hrButtonIME_Update (pItem) ;
						pItem->Release () ;
					}
				}
				_showKeyboardIcon (pLangBarItemMgr, fShowKeyboardIcon) ;
			} __finally {
				pLangBarItemMgr->Release () ;
			}
		}
	}
	DEBUGPRINTFEX (106, (TEXT ("[leave] bTSF_UpdateLanguageBar ()\n"))) ;
  exit_func:
	return	fRetval ;
}

/*	����o�[�ɃA�C�e����ǉ�/�폜����B
 */
void	PASCAL
vTSF_ActivateLanguageBar (
	HIMC		hIMC,
	BOOL		fSelect)
{
	register ITfLangBarItemMgr*	pLangBarItemMgr			= NULL ;
	register DWORD				dwValue ;
	register BOOL				fShowKeyboardIcon, fShowIMEIcon, fShowInputModeIcon ;

	if (g_bSkkImeSecure)
		return ;

	if (g_hMSCTF == NULL ||  ! _IsCtfThreadInputManagerEnabled ())
		goto	Exit_Func ;

	DEBUGPRINTFEX (106, (TEXT ("[enter] vTSF_ActivateLanguageBar (Select:%d)\n"), fSelect)) ;

	/*	���񃌃W�X�g�����Q�Ƃ���̂͐������̂��낤���H */
	fShowKeyboardIcon	= fShowIMEIcon	= fShowInputModeIcon	= TRUE ;
	if (fSelect) {
#if !defined (NO_TOUCH_REGISTRY)
		if (GetRegDwordValue (TEXT ("\\CICERO"), REGKEY_SHOWKEYBRDICON, &dwValue))
			fShowKeyboardIcon	= (BOOL) dwValue ;
		if (GetRegDwordValue (TEXT ("\\CICERO"), REGKEY_SHOWIMEICON, &dwValue))
			fShowIMEIcon		= (BOOL) dwValue ;
		if (GetRegDwordValue (TEXT ("\\CICERO"), REGKEY_SHOWINPUTMODEICON, &dwValue))
			fShowInputModeIcon	= (BOOL) dwValue ;
#endif
	}
	pLangBarItemMgr	= _QueryLangBarItemMgr () ;
	if (pLangBarItemMgr != NULL) {
		ITfLangBarItem*		pItem ;
		ITfLangBarItem*		pNewItem ;
		HRESULT				hrBtnIME = S_OK, hrBtnCMode = S_OK ;

		__try {
			pItem	= NULL ;
			if (pLangBarItemMgr->GetItem (c_guidItemButtonIME, &pItem) == S_OK && pItem != NULL) {
				if (! fShowIMEIcon || ! fSelect) {
#if defined (DBG)
					HRESULT	hr	= pLangBarItemMgr->RemoveItem (pItem) ;
					if (FAILED (hr)) {
						DebugPrintf (TEXT ("c_guidItemButtonIME remove failed. (0x%x)\n"), hr) ;
					} else {
						DebugPrintf (TEXT ("c_guidItemButtonIME was removed.\n")) ;
					}
					hrBtnIME	= hr ;
#else
					hrBtnIME	= pLangBarItemMgr->RemoveItem (pItem) ;
#endif
				}
				pItem->Release () ;
			} else {
#if defined (DBG)
				DebugPrintf (TEXT ("GetItem (c_guidItemButtonIME) ... ng (%d && %d)\n"), fShowIMEIcon, fSelect) ;
#endif
				if (fSelect) {
					if (fShowIMEIcon) {
						pNewItem	= NULL ;
						if (bButtonIME_Create (hIMC, &pNewItem) && pNewItem != NULL) {
#if defined (DBG)
							HRESULT	hr	= pLangBarItemMgr->AddItem (pNewItem) ;
							if (FAILED (hr)) {
								DebugPrintf (TEXT ("c_guidItemButtonIME add failed. (0x%x)\n"), hr) ;
							} else {
								DebugPrintf (TEXT ("c_guidItemButtonIME was added.\n")) ;
							}
							hrBtnIME	= hr ;
#else
							hrBtnIME	= pLangBarItemMgr->AddItem (pNewItem) ;
#endif
							pNewItem->Release () ;
						} else {
							hrBtnIME	= E_FAIL ;
						}
					}
					/*	������ TSF ���̃A�C�R�����폜���悤�Ƃ���ƁAIE ��(IE��IMM��TSF�̗�����
					 *	Activate�����̂�) �A�C�R�����S�������Ă��܂��\��������B
					 *	
					pItem	= NULL ;
					if (pLangBarItemMgr->GetItem (c_guidTsfItemButtonIME, &pItem) == S_OK && pItem != NULL) {
						(void) pLangBarItemMgr->RemoveItem (pItem) ;
						pItem->Release () ;
					}
					*/
				}
			}

			pItem	= NULL ;
			if (pLangBarItemMgr->GetItem (c_guidItemButtonCMode, &pItem) == S_OK && pItem != NULL) {
				if (! fShowInputModeIcon || ! fSelect) {
					hrBtnCMode	= pLangBarItemMgr->RemoveItem (pItem) ;
#if defined (DBG)
					DebugPrintf (TEXT ("c_guidItemButtonCMode was removed (hr:0x%x).\n"), hrBtnCMode) ;
#endif
				}
				pItem->Release () ;
			} else {
#if defined (DBG)
				DebugPrintf (TEXT ("GetItem (c_guidItemButtonCMode) ... ng (%d && %d)\n"), fShowIMEIcon, fSelect) ;
#endif
				if (fSelect) {
					if (fShowInputModeIcon) {
						pNewItem	= NULL ;
						if (bButtonCMode_Create (hIMC, &pNewItem) && pNewItem != NULL) {
							hrBtnCMode	= pLangBarItemMgr->AddItem (pNewItem) ;
#if defined (DBG)
							DebugPrintf (TEXT ("c_guidItemButtonCMode was added (hr:0x%x).\n"), hrBtnCMode) ;
#endif
							pNewItem->Release () ;
						} else {
							hrBtnCMode	= E_FAIL ;
						}
					}
					/*	������ TSF ���̃A�C�R�����폜���悤�Ƃ���ƁAIE ��(IE��IMM��TSF�̗�����
					 *	Activate�����̂�) �A�C�R�����S�������Ă��܂��\��������B
					pItem	= NULL ;
					if (pLangBarItemMgr->GetItem (c_guidTsfItemButtonCMode, &pItem) == S_OK && pItem != NULL) {
						(void) pLangBarItemMgr->RemoveItem (pItem) ;
						pItem->Release () ;
					}
					*/
				}
			}
			if (fSelect)
				_showKeyboardIcon (pLangBarItemMgr, fShowKeyboardIcon) ;
		} __finally {
			pLangBarItemMgr->Release () ;
		}
#if defined (DBG)
	} else {
		DebugPrintf (TEXT ("_QueryLangBarItemMgr failed.\n")) ;
#endif
	}
	DEBUGPRINTFEX (106, (TEXT ("[leave] vTSF_ActivateLanguageBar (Select:%d)\n"), fSelect)) ;
  Exit_Func:
	return ;
}

void	PASCAL
vTSF_SetActiveContext	(
	HIMC		hIMC)
{
	ITfLangBarItemMgr*	pLangBarItemMgr	= NULL ;

	if (g_bSkkImeSecure)
		return ;

	if (g_hMSCTF == NULL ||  ! _IsCtfThreadInputManagerEnabled ())
		goto	Exit_Func ;

	DEBUGPRINTFEX (106, (TEXT ("[enter] vTSF_SetActiveContext ()\n"))) ;

	pLangBarItemMgr	= _QueryLangBarItemMgr () ;
	if (pLangBarItemMgr != NULL) {
		ITfLangBarItem*		pItem ;

		__try {
			pItem	= NULL ;
			if (SUCCEEDED (pLangBarItemMgr->GetItem (c_guidItemButtonIME, &pItem)) && pItem != NULL) {
				hrButtonIME_SetActiveContext (pItem, hIMC) ;
				pItem->Release () ;
			}

			pItem	= NULL ;
			if (SUCCEEDED (pLangBarItemMgr->GetItem (c_guidItemButtonCMode, &pItem)) && pItem != NULL) {
				hrButtonCMode_SetActiveContext (pItem, hIMC) ;
				pItem->Release () ;
			}
		} __finally {
			pLangBarItemMgr->Release () ;
		}
	}
	DEBUGPRINTFEX (106, (TEXT ("[leave] vTSF_SetActiveContext ()\n"))) ;
Exit_Func:
	return ;
}

/*	�L�[�{�[�h�A�C�R��(����o�[��)�̕\��/��\����؂�ւ���֐��B
 *��
 *	Text Service Framework �Ɠ�������Ă���ꍇ�ɂ̓L�[�{�[�h�̃A�C�R����
 *	�\������邪�A�����łȂ��ꍇ�ɂ� IME ICON �����p�����悤�ł���B
 */
BOOL
bTSF_ShowKeyboardIcon (
	register BOOL				fShow)
{
	ITfLangBarItemMgr*	pLangBarItemMgr			= NULL ;
	BOOL				bRetval	;

	pLangBarItemMgr	= _QueryLangBarItemMgr () ;
	if (pLangBarItemMgr == NULL) 
		return	FALSE ;

	bRetval	= _showKeyboardIcon (pLangBarItemMgr, fShow) ;
	pLangBarItemMgr->Release () ;
	return	bRetval ;
}

void	PASCAL
vTSF_UninitLanguageBar (void)
{
	register ITfLangBarItemMgr*	pLangBarItemMgr			= NULL ;
	register int	i ;

	
	if (g_bSkkImeSecure) {
		return ;
	}
	if (g_hMSCTF != NULL) {
		FreeLibrary (g_hMSCTF) ;
		g_hMSCTF	= NULL ;
	}
	g_bInitTSF	= FALSE ;
	return ;
}

/*========================================================================
 */
ITfThreadMgr*
_QueryThreadMgr (void)
{
	PTF_CREATETHREADMGR	pfnCreateThreadMgr	= NULL ;
	ITfThreadMgr*		pThreadMgr			= NULL ;
	HRESULT				hr ;

	if (g_hMSCTF == NULL)
		return	NULL ;

	pfnCreateThreadMgr = (PTF_CREATETHREADMGR)GetProcAddress (g_hMSCTF, "TF_CreateThreadMgr") ;
	if(pfnCreateThreadMgr) {
		hr = (*pfnCreateThreadMgr)(&pThreadMgr) ;
		if (SUCCEEDED (hr) && pThreadMgr != NULL) 
			return	pThreadMgr ;
	}
	return	NULL ;
}

ITfLangBarItemMgr*
_QueryLangBarItemMgr (void)
{
	PTF_CREATELANGBARITEMMGR	pfnCreateLangBarItemMgr	= NULL ;
	ITfLangBarItemMgr*			pLangBarItemMgr			= NULL ;
	HRESULT				hr ;

	if (g_hMSCTF == NULL)
		return	NULL ;

	pfnCreateLangBarItemMgr	= (PTF_CREATELANGBARITEMMGR)GetProcAddress (g_hMSCTF, "TF_CreateLangBarItemMgr") ;
	if (pfnCreateLangBarItemMgr == NULL) 
		return	NULL ;

	hr = (*pfnCreateLangBarItemMgr)(&pLangBarItemMgr) ;
	if (SUCCEEDED (hr)) 
		return	pLangBarItemMgr ;
	return	NULL ;
}

HIMC
_GetCurrentHIMC (void)
{
	register HIMC	hIMC	= NULL ;

	register HWND	hwnd	= GetFocus () ;
	if (hwnd != NULL)
		hIMC	= ImmGetContext (hwnd) ;
	return	hIMC ;
}

BOOL
_showKeyboardIcon (
	register ITfLangBarItemMgr*	pLangBarItemMgr,
	register BOOL				fShow)
{
	ITfLangBarItem*					pItem ;

	if (SUCCEEDED (pLangBarItemMgr->GetItem (c_guidKeyboardItemButton, &pItem))) {
		if (fShow) {
			ITfSystemLangBarItem*			pSysItem ;
			ITfSystemDeviceTypeLangBarItem*	pSysDevItem ;

			if (SUCCEEDED (pItem->QueryInterface (IID_ITfSystemDeviceTypeLangBarItem, (void**)&pSysDevItem)) && pSysDevItem != NULL) {
				pSysDevItem->SetIconMode (0) ;
				pSysDevItem->Release () ;
			}
		}
		pItem->Show (fShow) ;
		pItem->Release () ;
	}
	return	TRUE ;
}

BOOL
_IsCtfThreadInputManagerEnabled (void)
{
	HKEY	hKey ;
	DWORD	dwRegType, dwData, dwDataSize, dwRet ;
	BOOL	bRetval ;

	bRetval		= TRUE ;
	dwData		= 0 ;
	dwDataSize	= sizeof (DWORD) ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_CTF_PATH, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
		dwRet	= RegQueryValueEx (hKey, REGKEY_CTF_DISABLE_THREAD_INPUT_MANAGER, NULL, &dwRegType, (LPBYTE)&dwData, &dwDataSize) ;
		RegCloseKey (hKey) ;
		if (dwRet == ERROR_SUCCESS && dwRegType == REG_DWORD)
			bRetval	= (dwData == 0) ;
	}
	return	bRetval ;
}

void
_DumpLangBarItem (void)
{
	register ITfLangBarItemMgr*	pLangBarItemMgr			= NULL ;
	ITfLangBarItem*			pItem ;
	IEnumTfLangBarItems*	pEnum ;

	pLangBarItemMgr	= _QueryLangBarItemMgr () ;
	if (pLangBarItemMgr == NULL) 
		return ;

	DebugPrintf (TEXT ("--[Enter: _DumpLangBarItem (%d)]--\n"), (int) GetTickCount ()) ; 
	if (SUCCEEDED (pLangBarItemMgr->EnumItems (&pEnum))) {
		ITfLangBarItem*	rpItems [16]	= { NULL } ;
		ULONG			cItems	= 0 ;
		if (SUCCEEDED (pEnum->Next (16, rpItems, &cItems))) {
			ULONG		i ;
			for (i = 0 ; i < cItems ; i ++) {
				TF_LANGBARITEMINFO	info ;
				if (SUCCEEDED (rpItems [i]->GetInfo (&info))) {
				    const BYTE*		pBytes	= (const BYTE *) &(info.guidItem) ;
					DebugPrintf (TEXT ("(%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x)\n"),
						pBytes [0], pBytes [1], pBytes [2], pBytes [3],
						pBytes [4], pBytes [5], pBytes [6], pBytes [7], 
						pBytes [8], pBytes [9], pBytes [10], pBytes [11],
						pBytes [12], pBytes [13], pBytes [14], pBytes [15]) ;
				}
			}
			for (i = 0 ; i < cItems ; i ++) {
				rpItems [i]->Release () ;
				rpItems [i]	= NULL ;
			}
		}
		pEnum->Release () ;
	}
	return ;
}

#endif

