#if !defined (TSearchSession_h)
#define	TSearchSession_h

#include "varbuffer.h"
#include "TCommuSession.h"

/*	MAXKEYWORDLEN �� COMPSIZELEN �ȏ�ł���K�v������B
 *	(���������͓��͂ł��Ȃ��Ǝv�����c�B)
 */
#define	MAXKEYWORDLEN		(256)

/*	���� 37 �͓��ɍ���������킯�ł͂Ȃ��Bperformance �𓾂邽�߂ɂ�
 *	�����ɂ�钲�����K�v���B*/
#define	CANDIDATEHASHSIZE	(37)

class CTSearchSessionCandidate ;
class CTPacket ;

class CTSearchSession : public CTCommunicateSession {
protected:
	WCHAR							_rszKeyword [MAXKEYWORDLEN] ;
	int								_nwstrKeyword ;

	CTSearchSessionCandidate*		_pCurCandidate ;
	CTSearchSessionCandidate*		_pTopCandidate ;
	CTSearchSessionCandidate*		_pLastCandidate ;
	/*	�P��̏d�Ȃ������邽�߂� hash table */
	CTSearchSessionCandidate*		_rpTblCandidate [CANDIDATEHASHSIZE] ;
	/*	�P��̗���܂Ƃ߂ĕێ����Ă���o�b�t�@�B*/
	CVarbuffer <WCHAR, 256>			_vbufCandidate ;
	int								_nCandidate ;
	int								_nSearchCount ;
	int								_nParsePosition ;

public:
	CTSearchSession (LPCWSTR wstrKeyword, int nKeyword) ;
	virtual			~CTSearchSession () ;
	
	virtual	LPCWSTR	GetKeyword (int* pnWord) ;
	virtual	LPCWSTR	GetCandidate () ;
	virtual	LPCWSTR	GetReferCandidate () ;
	virtual	BOOL	InsertCandidate (LPCWSTR wstring, int nstring) ;
	virtual	BOOL	RemoveCandidate () ;
	virtual	BOOL	LinkCandidate (CTSearchSessionCandidate*) ;
	virtual	CTSearchSessionCandidate*	GetCurrentPoint () ;
	virtual	int		GetNumberOfCandidate (BOOL* pfContinue) ;
	virtual	BOOL	NextCandidate () ;
	virtual	BOOL	PreviousCandidate () ;
	virtual	BOOL	Rewind () ;

protected:
	virtual	BOOL	_Search () = 0 ;

	virtual	BOOL	_UpdateCandidateList (int nPosition) ;
	virtual	CTSearchSessionCandidate*	_CreateCandidate (int nPosition, int nCount, BOOL* pfRetval) ;
	virtual	BOOL	_NewCandidate (int nPosition, int nCount) ;
	virtual	BOOL	_IsExistCandidatep (LPCWSTR wstring, int nstring) ;
	virtual	BOOL	_RegisterCandidate (CTSearchSessionCandidate* pNewEntry) ;
	virtual	BOOL	_CleanupHashTable () ;
	virtual	BOOL	_CleanupHashTableSub (CTSearchSessionCandidate* pEntry) ;
	virtual	BOOL	_IsSeparateChar (WCHAR wch) const ;
} ;

class CTHenkanSession : public CTSearchSession {
public:
	CTHenkanSession (LPCWSTR wstrKeyword, int nKeyword) : 
		CTSearchSession (wstrKeyword, nKeyword) {
		return ;
	}
	virtual			~CTHenkanSession () {
		return ;
	}

protected:
	virtual	BOOL	_Search () ;
} ;

class CTOkuriHenkanSession : public CTSearchSession {
public:
	CTOkuriHenkanSession (LPCWSTR wstrKeyword, int nKeyword) : 
		CTSearchSession (wstrKeyword, nKeyword) {
		return ;
	}
	virtual			~CTOkuriHenkanSession () {
		return ;
	}

protected:
	virtual	BOOL	_Search () ;
} ;

class CTCompletionSession : public CTSearchSession {
public:
	CTCompletionSession (LPCWSTR wstrKeyword, int nKeyword) : 
		CTSearchSession (wstrKeyword, nKeyword) {
		return ;
	}
	virtual			~CTCompletionSession () {
		return ;
	}

protected:
	virtual	BOOL	_Search () ;
	virtual	BOOL	_IsSeparateChar (WCHAR wch) const ;
} ;

#endif

