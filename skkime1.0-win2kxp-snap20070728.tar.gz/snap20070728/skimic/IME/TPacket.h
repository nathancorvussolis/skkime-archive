#if !defined (TPacket_h)
#define	TPacket_h

#include "TProtocol.h"

#define	MSGBUFSIZE						(2048)

#define	PACKET_ALIGN	(4)
#define	PADNUM(x)		((PACKET_ALIGN - ((x) & (PACKET_ALIGN - 1))) & (PACKET_ALIGN - 1))

class CTPacket {
private:
	BYTE			_rbyBuffer [MSGBUFSIZE] ;
	int				_nUsage ;

public:
	CTPacket () : _nUsage (0) {
	}
	virtual			~CTPacket () {
	}
	virtual	BOOL	SetHeader (int nMajor, int nMinor) {
		_rbyBuffer [0]	= (BYTE) nMajor ;
		_rbyBuffer [1]	= (BYTE) nMinor ;
		_rbyBuffer [2]	= 0 ;
		_rbyBuffer [3]	= 0 ;
		_nUsage			= 4 ;
		return	TRUE ;
	}
	virtual BOOL	AddPad () {
		register int	nPad	= PADNUM (_nUsage) ;

		if ((_nUsage + nPad) > MSGBUFSIZE)
			return	FALSE ;
		_nUsage	+= nPad ;
		return	TRUE ;
	}
	virtual	BOOL	AddCard32 (DWORD dwData) {
		register LPBYTE	pDest ;

		if ((_nUsage + 4) > MSGBUFSIZE)
			return	FALSE ;

		pDest		= _rbyBuffer + _nUsage ;
		*pDest ++	= (BYTE)(dwData >>  0) ;	_nUsage ++ ;
		*pDest ++	= (BYTE)(dwData >>  8) ;	_nUsage ++ ;
		*pDest ++	= (BYTE)(dwData >> 16) ;	_nUsage ++ ;
		*pDest ++	= (BYTE)(dwData >> 24) ;	_nUsage ++ ;
		return	TRUE ;
	}
	virtual BOOL	AddCard16 (WORD woData) {
		register LPBYTE	pDest ;

		if ((_nUsage + 2) > MSGBUFSIZE)
			return	FALSE ;

		pDest		= _rbyBuffer + _nUsage ;
		*pDest ++	= (BYTE)(woData >>  0) ;	_nUsage ++ ;
		*pDest ++	= (BYTE)(woData >>  8) ;	_nUsage ++ ;
		return	TRUE ;
	}
	virtual BOOL	AddCard8 (BYTE byData) {
		if ((_nUsage + 1) > MSGBUFSIZE)
			return	FALSE ;

		_rbyBuffer [_nUsage ++]	= byData ;
		return	TRUE ;
	}
	virtual	BOOL	SetLength () {
		register LPBYTE	pDest ;

		if (_nUsage < SKKISERV_PROTO_HEADER_SIZE || _nUsage > MSGBUFSIZE)
			return	FALSE ;

		pDest		= _rbyBuffer + 2 ;
		*pDest ++	= (BYTE) (_nUsage >> 0) ;
		*pDest ++	= (BYTE) (_nUsage >> 8) ;
		return	TRUE ;
	}
	virtual BOOL	SetCard16 (int nPosition, WORD woValue) {
		register LPBYTE	pDest ;

		if (nPosition < 0 || (nPosition + 2) > _nUsage)
			return	FALSE ;

		pDest		= _rbyBuffer + nPosition ;
		*pDest ++	= (BYTE) (woValue >> 0) ;
		*pDest ++	= (BYTE) (woValue >> 8) ;
		return	TRUE ;
	}
	virtual BOOL	GetCard16 (int nPosition, WORD* pwResult) {
		register WORD		woValue ;
		register LPCBYTE	pSrc ;

		ASSERT (pwResult != NULL) ;

		if (nPosition < 0 || (nPosition + 2) > _nUsage)
			return	FALSE ;

		pSrc		= _rbyBuffer + nPosition ;
		woValue		= (WORD) *pSrc ++ ;
		woValue		= woValue | ((WORD)*pSrc << 8) ;
		*pwResult	= woValue ;
		return	TRUE ;
	}
	virtual BOOL	AddString (LPCWSTR wstring, int nstring) {
		register int	nPos, nPad, nStringByteLen, nResultLength ;

		nPos			= _nUsage ;
		nStringByteLen	= nstring * sizeof (WCHAR) ;
		nPad			= PADNUM(nPos + 2 + nStringByteLen) ;
		nResultLength	= nPos + 2 + nStringByteLen + nPad ;
		if (nResultLength > MSGBUFSIZE)
			return	FALSE ;
		
		if (nstring > 0)
			memcpy (_rbyBuffer + nPos + 2, wstring, nStringByteLen) ;
		
		_nUsage			= nResultLength ;
		SetCard16 (nPos, (WORD)nstring) ;
		return	TRUE ;
	}
	virtual	BOOL	AddByte (LPCBYTE pByte, int nByte) {
		ASSERT (nByte >= 0) ;
		if ((_nUsage + nByte) > MSGBUFSIZE)
			return	FALSE ;
		memcpy (_rbyBuffer + _nUsage, pByte, nByte) ;
		_nUsage	+= nByte ;
		return	TRUE ;
	}
	virtual	BOOL	GetHeader (int* pnMajor, int* pnMinor, int* pnSize) {
		if (_nUsage < SKKISERV_PROTO_HEADER_SIZE)
			return	FALSE ;
		if (pnMajor != NULL)
			*pnMajor	= _rbyBuffer [0] ;
		if (pnMinor != NULL)
			*pnMinor	= _rbyBuffer [1] ;
		if (pnSize != NULL) {
			register WORD		woSIZE ;
			woSIZE		= _rbyBuffer [3] ;
			woSIZE		= (woSIZE << 8) | (WORD)_rbyBuffer [2] ;
			*pnSize		= (int) woSIZE ;
		}
		return	TRUE ;
	}
	virtual LPCBYTE		GetBody () const {
		return	_rbyBuffer + SKKISERV_PROTO_HEADER_SIZE ;
	}
	virtual LPBYTE		GetData () {
		return	_rbyBuffer ;
	}
	virtual LPCBYTE		GetData () const {
		return	_rbyBuffer ;
	}
	virtual int			GetSize () const {
		return	_nUsage ;
	}
	virtual void		SetSize (int nSize) {
		_nUsage	= nSize ;
		return ;
	}
	virtual void	Clear () {
		_nUsage		= 0 ;
		return ;
	}
} ;

#endif

