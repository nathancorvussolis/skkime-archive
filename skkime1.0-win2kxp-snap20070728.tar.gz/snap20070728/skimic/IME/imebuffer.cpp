#if !defined (UNITTEST)
#include "globals.h"
#else
#include "local.h"
#endif
#include "ImeBuffer.h"
#include "ImeDoc.h"
#include "TAssocRule.h"
#include "testkeymap.h"
#include "RomaKanaTable.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "TLispSession.h"
#include "TCutBuffer.h"
#include "ImeRecursiveEditSession.h"

#define	COUNTHENKANSHOWCHANGE	(4)
#define	NUMHENKANSHOWCANDIDATES	(NUM_JHENKAN_SHOW_CANDIDATE_KEYS)

CImeBuffer::CImeBuffer ()
{
	_pDoc						= NULL ;
	_nbufComp					= 0 ;
	_nbufJPrefix				= 0 ;
	_nbufJHenkanKey				= 0 ;
	_nbufJHenkanKey2			= 0 ;
	_nbufJSearchKey				= 0 ;
	_nbufJHenkanOkurigana		= 0 ;
	_nbufJNumList				= 0 ;
	_nbufJHenkanResult			= 0 ;
	_nbufJReadingText			= 0 ;

	//_fJMode						= TRUE ;
	_fJMode						= FALSE ;
	_fJZenkaku					= FALSE ;
	_fJKatakana					= FALSE ;
	_fJisx0201					= FALSE ;
	_fJAbbrev					= FALSE ;
	_fJOkurigana				= FALSE ;
	_fJHenkanActive				= FALSE ;
	_fJHenkanOn					= FALSE ;
	_nJOkuriIndexMin			= 0 ;
	_nJOkuriIndexMax			= 0 ;
	_wchOkuriChar				= L'\0' ;
	_pmkPoint					= NULL ;
	_pmkEditTop					= NULL ;
	_pmkMark					= NULL ;
	_pmkJKanaStartPoint			= NULL ;
	_pmkJHenkanStartPoint		= NULL ;
	_pmkJHenkanEndPoint			= NULL ;
	_pmkJOkuriganaStartPoint	= NULL ;
	_pmkJReadingStartPoint		= NULL ;
	_pmkJReadingEndPoint		= NULL ;
	_nMarker					= 0 ;
	_pHenkanSession				= NULL ;
	_pRecursiveEditSession		= NULL ;
	_pFilterFunc				= NULL ;
	return ;
}

CImeBuffer::CImeBuffer (CImeDoc *pDoc)
{
	_pDoc						= pDoc ;
	_nbufComp					= 0 ;
	_nbufJPrefix				= 0 ;
	_nbufJHenkanKey				= 0 ;
	_nbufJHenkanKey2			= 0 ;
	_nbufJSearchKey				= 0 ;
	_nbufJHenkanOkurigana		= 0 ;
	_nbufJNumList				= 0 ;
	_nbufJHenkanResult			= 0 ;
	_nbufJReadingText			= 0 ;
	//_fJMode						= TRUE ;
	_fJMode						= FALSE ;
	_fJZenkaku					= FALSE ;
	_fJisx0201					= FALSE ;
	_fJKatakana					= FALSE ;
	_fJOkurigana				= FALSE ;
	_fJHenkanActive				= FALSE ;
	_fJHenkanOn					= FALSE ;
	_fJAbbrev					= FALSE ;
	_nJOkuriIndexMin			= 0 ;
	_nJOkuriIndexMax			= 0 ;
	_wchOkuriChar				= L'\0' ;
	_pmkPoint					= NULL ;
	_pmkEditTop					= NULL ;
	_pmkMark					= NULL ;
	_pmkJKanaStartPoint			= NULL ;
	_pmkJHenkanStartPoint		= NULL ;
	_pmkJHenkanEndPoint			= NULL ;
	_pmkJOkuriganaStartPoint	= NULL ;
	_pmkJReadingStartPoint		= NULL ;
	_pmkJReadingEndPoint		= NULL ;
	_nMarker					= 0 ;
	_pHenkanSession				= NULL ;
	_pRecursiveEditSession		= NULL ;
	_pFilterFunc				= NULL ;
	return ;
}

CImeBuffer::~CImeBuffer ()
{
	if (_pHenkanSession != NULL)
		delete	_pHenkanSession ;
	if (_pRecursiveEditSession != NULL)
		delete	_pRecursiveEditSession ;
	return ;
}

BOOL
CImeBuffer::Init ()
{
	register int	i ;
	static bool		rfMarkerCursor []	= {
		true, false, false, false, false, true, false,
	} ;

	_nJInputByCodeOrMenuJumpDefault	= _nJCodeN1Min ;

	/*	�}�[�J�̏��������s���B*/
	for (i = 0 ; i < MAX_RESERVED_MARKERS ; i ++) 
		_rMarker [i].Initialize (rfMarkerCursor [i]) ;
	_nMarker	= MAX_RESERVED_MARKERS ;
	/*	�K�{�}�[�J�ł���|�C���g(�J�[�\��)���쐬����B*/
	_pmkPoint	= _rMarker + MARKER_POINT ;

	_pmkMark					= NULL ;
	_pmkJKanaStartPoint			= NULL ;
	_pmkJHenkanStartPoint		= NULL ;
	_pmkJHenkanEndPoint			= NULL ;
	_pmkJOkuriganaStartPoint	= NULL ;

	_fJMode		= TRUE ;
	_fJZenkaku	= FALSE ;
	_fJisx0201	= FALSE ;
	_fJKatakana	= FALSE ;

	_pFilterFunc	= _stNormalFilter ;
	return	TRUE ;
}

BOOL
CImeBuffer::Init (
	register LPCWSTR		wstrMessage,
	register int			nstrMessage,
	register CTImeRecursiveEditSession*	pSession)
{
	ASSERT (_pRecursiveEditSession == NULL) ;

	if (! Init ())
		return	FALSE ;
	if (nstrMessage > 0) {
		_pmkEditTop		= _rMarker + MARKER_EDIT_TOP ;
		_Insert (wstrMessage, nstrMessage) ;
		*_pmkEditTop	= *_pmkPoint ;
	}
	_pRecursiveEditSession	= pSession ;
	return	TRUE ;
}

void
CImeBuffer::Uninit ()
{
	if (_pHenkanSession != NULL)
		delete	_pHenkanSession ;
	if (_pRecursiveEditSession != NULL)
		delete	_pRecursiveEditSession ;

	_nbufComp					= 0 ;
	_nbufJPrefix				= 0 ;
	_nbufJHenkanKey				= 0 ;
	_nbufJHenkanKey2			= 0 ;
	_nbufJSearchKey				= 0 ;
	_nbufJHenkanOkurigana		= 0 ;
	_fJMode						= TRUE ;
	_fJZenkaku					= FALSE ;
	_fJisx0201					= FALSE ;
	_fJKatakana					= FALSE ;
	_fJOkurigana				= FALSE ;
	_fJHenkanActive				= FALSE ;
	_fJHenkanOn					= FALSE ;
	_fJAbbrev					= FALSE ;
	_nJOkuriIndexMin			= 0 ;
	_nJOkuriIndexMax			= 0 ;
	_wchOkuriChar				= L'\0' ;
	_pmkPoint					= NULL ;
	_pmkEditTop					= NULL ;
	_pmkMark					= NULL ;
	_pmkJKanaStartPoint			= NULL ;
	_pmkJHenkanStartPoint		= NULL ;
	_pmkJHenkanEndPoint			= NULL ;
	_pmkJOkuriganaStartPoint	= NULL ;
	_nMarker					= 0 ;
	_pHenkanSession				= NULL ;
	_pRecursiveEditSession		= NULL ;
	_pFilterFunc				= NULL ;
	return ;
}

/*	������Ԃɖ߂��B*/
BOOL
CImeBuffer::Clear ()
{
	Uninit () ;
	return	Init () ;
}

BOOL
CImeBuffer::QueryFilterKeyEvent (
	register WCHAR			wch,
	register BOOL*			pfFiltered)
{
	int						nFuncNo ;
	BOOL					fFilter ;

	ASSERT (pfFiltered != NULL) ;

	/*	�ϊ������H �������͒��Ȃ̂��H process ���邩
	 *	�ǂ����͂���Ɉˑ�����B
	 */
	if (_pFilterFunc != _stNormalFilter) {
		/*	NormalFilter �ɂ��Ȃ��Ƃ������Ƃ́A�܂��L�[�͐H�ׂ���B
		 *	(����prefix �̓��͓r���̉\���Ƃ�)
		 */
		*pfFiltered	= TRUE ;
		return	TRUE ;
	}
	/*	�ϊ����쒆�Ƃ������Ƃ͋��炭�� key �� filter ���锤�B
	 *	���A�ϊ�������S�ď������ꂽ��Ԃł͂ǂ��Ȃ�̂��H�͋C�ɂȂ�B
	 */
	if (_nbufComp > 0 || _fJHenkanOn || _fJHenkanActive) {
		*pfFiltered	= TRUE ;
		return	TRUE ;
	}

	/*	�������͒��ł��ϊ����ł��Ȃ�(�܂�e�L�X�g��
	 *	���ɂ��ҏW���ĂȂ��^�����ȏ��)�Ȃ�Akey ��
	 *	filter ���邩�ǂ����́Akey �Ɋ��蓖�Ă��Ă���
	 *	function �Ɉˑ�����B
	 */
	if (! _pDoc->LookupKeymap (wch, &nFuncNo))
		return	FALSE ;

	if (nFuncNo == FUNCNO_J_NEWLINE) {
		/*	DoEditSession �� Eaten = FALSE �ɂ��Ă� 
		 *	application �� key �� handle ���Ă���Ȃ��c�B
		 *	���O�� handle ���邵�Ȃ��� guess ����K�v��
		 *	����悤���B
		 */
		if (_nbufComp > 0 || _nbufJPrefix > 0 /*|| !_fJMode*/
			|| _fJHenkanOn || _pRecursiveEditSession != NULL) {
			*pfFiltered	= TRUE ;
		} else {
			*pfFiltered	= FALSE ;
		}
		return	TRUE ;
	}
	/*	���͂����̂܂ܕԂ����ꍇ�ɂ� Filter ���Ȃ��Ƃ������B��x context ��S�ċL������
	 *	���ɖ߂���Ƃ��s���B
	 */
	fFilter	= _QueryProcessFunction (nFuncNo) ;
	if (_nbufComp == 0					&& 
		!_fJHenkanOn					&& 
		!_fJHenkanActive				&& 
		_pRecursiveEditSession == NULL	&&
		_pHenkanSession == NULL			&& 
		(nFuncNo == FUNCNO_SELF_INSERT_CHARACTER	||
		 nFuncNo == FUNCNO_NEWLINE					||
		 nFuncNo == FUNCNO_J_SELF_INSERT			||
		 nFuncNo == FUNCNO_J_ZENKAKU_INSERT			|| 
		 nFuncNo == FUNCNO_J_INSERT_A				||
		 nFuncNo == FUNCNO_J_INSERT_E				||
		 nFuncNo == FUNCNO_J_INSERT_I				||
		 nFuncNo == FUNCNO_J_INSERT_O				||
		 nFuncNo == FUNCNO_J_INSERT_U				||
		 nFuncNo == FUNCNO_J_KANA_INPUT				||
		 nFuncNo == FUNCNO_J_START_HENKAN			||
		 nFuncNo == FUNCNO_J_INSERT_COMMA			||
		 nFuncNo == FUNCNO_J_INSERT_PERIOD			||
		 nFuncNo == FUNCNO_J_PREVIOUS_CANDIDATE)) {
		CImeBufferContext	context ;

		if (_PushContext (&context)) {
			_pDoc->SetLastCommandChar (wch) ;
			FilterKeyEvent () ;
			if (_nbufComp == 0 && nFuncNo == FUNCNO_NEWLINE) {
				fFilter	= FALSE ;
			} else {
				if (_nbufComp == 1 && wch == _bufComp [0]) {
					int		nShift, nCursor ;
					BOOL	fContinue ;
					if (QueryUpdateContext (&nShift, &nCursor, &fContinue) && nShift == 1 && !fContinue) {
						fFilter	= FALSE ;
					}
				}
			}
			_PopContext (&context) ;
		}
	}
	*pfFiltered	= fFilter ;
	return	TRUE ;
}

BOOL
CImeBuffer::QueryToggleIMEKeyEvent (
	register WCHAR			wch,
	register BOOL*			pfFiltered)
{
	int						nFuncNo ;

	ASSERT (pfFiltered != NULL) ;

#if 0
	/*	�ϊ������H �������͒��Ȃ̂��H process ���邩
	 *	�ǂ����͂���Ɉˑ�����B
	 */
	if (_pFilterFunc != _stNormalFilter) {
		/*	NormalFilter �ɂ��Ȃ��Ƃ������Ƃ́A�܂��L�[�͐H�ׂ���B
		 *	(����prefix �̓��͓r���̉\���Ƃ�)
		 */
		*pfFiltered	= FALSE ;
		return	TRUE ;
	}

	/*	�ϊ����쒆�Ƃ������Ƃ͋��炭�� key �� filter ���锤�B
	 *	���A�ϊ�������S�ď������ꂽ��Ԃł͂ǂ��Ȃ�̂��H�͋C�ɂȂ�B
	 */
	if (_nbufComp > 0 || _fJHenkanOn || _fJHenkanActive) {
		*pfFiltered	= FALSE ;
		return	TRUE ;
	}

	/*	�������͒��ł��ϊ����ł��Ȃ�(�܂�e�L�X�g��
	 *	���ɂ��ҏW���ĂȂ��^�����ȏ��)�Ȃ�Akey ��
	 *	filter ���邩�ǂ����́Akey �Ɋ��蓖�Ă��Ă���
	 *	function �Ɉˑ�����B
	 */
#endif

	/*	�ǂ̏�Ԃł����Ă��AToggle �ł���悤�ɏ�̏����� #if 0
	 *	�ň͂�ł݂�B
	 */
	if (! _pDoc->LookupKeymap (wch, &nFuncNo))
		return	FALSE ;

	*pfFiltered	= (nFuncNo == FUNCNO_TOGGLE_IME) ;
	return	TRUE ;
}

BOOL
CImeBuffer::FilterKeyEvent ()
{
	return	(_pFilterFunc)(this) ;
}

LPCWSTR
CImeBuffer::GetText (int* pnLength)
{
	ASSERT (pnLength != NULL) ;
	*pnLength	= _nbufComp ;
	return	_bufComp ;
}

int
CImeBuffer::GetCursorPosition () const
{
	ASSERT (_pmkPoint != NULL) ;
	return	_pmkPoint->GetPosition () ;
}

int
CImeBuffer::GetReadingText (
	LPWSTR			wpDest,
	int				nDest,
	int*			pnRawPos)	/* [in/out] */
{
	register LPWSTR	ptr ;
	register int	nptr, nPos ;
	int		nReadingStart, nReadingEnd ;
	int		nHenkanStart, nHenkanEnd, nOkuriPos ;
	int		nKanaStart, nKanaEnd ;
	BOOL	fSetReadingPos ;
	int		nReadingPos, nRawPos ; 

	/*	�ނނށB�l�����ׂ��_�͎��̒ʂ�F
	 *		- kana-prefix �����݂��邩�H (_nbufJPrefix > 0) ���݂���Ȃ�A
	 *		  _pmkKanaStartPoint ���� _pmkPoint �܂ł̓R�s�[���Ȃ��B
	 *		- �ϊ������H �ϊ����Ȃ�΁A_pmkJHenkanStartPoit - 1 ����
	 *		  _pmkJHenkanEndPoint �܂ł� _bufJHenkanKey �Œu��������
	 *		  �R�s�[����B
	 *		- �ϊ����悤�Ƃ��Ă���(��
	 */
#define	SAFE_GET_MARKER_POSITION(pMarker)	(((pMarker) != NULL)? (pMarker)->GetPosition () : -1)
	nReadingStart	= SAFE_GET_MARKER_POSITION (_pmkJReadingStartPoint) ;
	nReadingEnd		= SAFE_GET_MARKER_POSITION (_pmkJReadingEndPoint) ;
	if (_fJHenkanOn) {
		nHenkanStart	= SAFE_GET_MARKER_POSITION (_pmkJHenkanStartPoint) ;
		if (_fJHenkanActive) {
			nHenkanEnd	= SAFE_GET_MARKER_POSITION (_pmkJHenkanEndPoint) ;
		} else {
			nHenkanEnd	= -1 ;
		}
	} else {
		nHenkanStart	= nHenkanEnd	= -1 ;
	}
	if (_nbufJPrefix > 0) {
		nKanaStart	= SAFE_GET_MARKER_POSITION (_pmkJKanaStartPoint) ;
		nKanaEnd	= SAFE_GET_MARKER_POSITION (_pmkPoint) ;
	} else {
		nKanaStart	= nKanaEnd	= -1 ;
	}
	if (_fJOkurigana) {
		nOkuriPos	= SAFE_GET_MARKER_POSITION (_pmkJOkuriganaStartPoint) ;
	} else {
		nOkuriPos	= -1 ;
	}
#undef	SAFE_GET_MARKER_POSITION

#define	SAFE_PTR_WRITE_AND_INC(pDest,nDest,pSrc,nSrc)	do {	\
	register int	nCOPY	= ((nDest) < (nSrc))? (nDest) : (nSrc) ;	\
	register int	nCOPYED ;	\
	nCOPYED = JPhoneticStrcpy ((pDest), (pSrc), nCOPY) ;	\
	(pDest)	+= nCOPYED ;	\
	(nDest)	-= nCOPYED ;	\
}	while (0)

	ptr				= wpDest ;
	nptr			= nDest ;
	nPos			= 0 ;
	nRawPos			= (pnRawPos != NULL)? *pnRawPos : 0 ;
	fSetReadingPos	= FALSE ;
	nReadingPos		= 0 ;
	while (nPos < _nbufComp) {
		if (! fSetReadingPos && nRawPos <= nPos) {
			nReadingPos		= ptr - wpDest ;
			fSetReadingPos	= TRUE ;
		}
		if (/*_fHenkanActive &&*/ nPos == (nHenkanStart - 1)) {
			if (_bufComp [nPos] != L'��' &&
				_bufComp [nPos] != L'��') {
				SAFE_PTR_WRITE_AND_INC (ptr, nptr, _bufComp + nPos, 1) ;
			}
			nPos	++ ;
		} else if (nPos == nOkuriPos) {
			if (_bufComp [nPos] != L'*') {
				SAFE_PTR_WRITE_AND_INC (ptr, nptr, _bufComp + nPos, 1) ;
			}
			nPos	++ ;
		} else if (/*_fHenkanOn &&*/ nHenkanStart <= nPos && nPos < nHenkanEnd) {
			int	n	= _nbufJHenkanKey ;
			if (_nbufJHenkanKey2 > 0)
				n	-- ;
			SAFE_PTR_WRITE_AND_INC (ptr, nptr, _bufJHenkanKey, n) ;
			nPos	= nHenkanEnd ;
		} else if (/*_nbufJPrefix > 0 &&*/ nKanaStart <= nPos && nPos < nKanaEnd) {
			/*	�����v���t�B�N�X�͓ǂ݉����ɂ͓���Ȃ��B*/
			nPos	= nKanaEnd ;
		} else if (nReadingStart <= nPos && nPos < nReadingEnd) {
			SAFE_PTR_WRITE_AND_INC (ptr, nptr, _bufJReadingText, _nbufJReadingText) ;
			nPos	= nReadingEnd ;
		} else {
			SAFE_PTR_WRITE_AND_INC (ptr, nptr, _bufComp + nPos, 1) ;
			nPos	++ ;
		}
	}
#undef	SAFE_PTR_WRITE_AND_INC
	if (! fSetReadingPos && nRawPos <= nPos) {
		nReadingPos		= ptr - wpDest ;
		fSetReadingPos	= TRUE ;
	}
	if (pnRawPos != NULL)
		*pnRawPos	= nReadingPos ;
	return	(ptr - wpDest) ;
}

BOOL
CImeBuffer::GetConvertedRegion (
	int* 	pnBegin,
	int*	pnEnd)	const 
{
	if (! _fJHenkanActive || ! _fJHenkanOn)
		return	FALSE ;
	if (pnBegin != NULL)
		*pnBegin	= _pmkJHenkanStartPoint->GetPosition () ;
	if (pnEnd != NULL)
		*pnEnd		= _pmkJHenkanEndPoint->GetPosition () ;
	return	TRUE ;
}

BOOL
CImeBuffer::GetSelectedRegion (
	int* 	pnBegin,
	int*	pnEnd)	const 
{
	int		nCmd, nPoint, nMark ;

	if (_pmkMark == NULL)
		return	FALSE ;
	nCmd	= _pDoc->GetLastCommand () ;
	if (nCmd != FUNCNO_MOUSE_DRAG_REGION && nCmd != FUNCNO_MOUSE_DRAG_REGION_END)
		return	FALSE ;

	nPoint	= _pmkPoint->GetPosition () ;
	nMark	= _pmkMark->GetPosition () ;
	if (pnBegin != NULL)
		*pnBegin	= (nPoint < nMark)? nPoint : nMark ;
	if (pnEnd != NULL)
		*pnEnd		= (nPoint < nMark)? nMark  : nPoint ;
	return	TRUE ;
}

int
CImeBuffer::SetConversionMode (
	register int	nMode)
{
	/*	�ċA���[�h�ł�������A���ꃂ�[�h(j-read-char �҂��Ƃ�)
	 *	�ł���ꍇ�ɂ͖����B
	 */
	if (_pRecursiveEditSession != NULL)
		return	FALSE ;
	if (_pFilterFunc != _stNormalFilter)
		return	FALSE ;

	switch (nMode) {
	case	IMECMODE_ZENKAKU:
		_JZenkakuEiji () ;
		break ;
	case	IMECMODE_ASCII:
		_JModeOff () ;
		break ;
	case	IMECMODE_KATAKANA:
		_JKakutei () ;
		if (_fJisx0201)
			_JToggleJisx0201 () ;
		if (!_fJKatakana)
			_JToggleKana () ;
		break ;
	case	IMECMODE_HIRAGANA:
		_JKakutei () ;
		if (_fJisx0201)
			_JToggleJisx0201 () ;
		if (_fJKatakana)
			_JToggleKana () ;
		break ;
	case	IMECMODE_HANKANA:
		_JKakutei () ;
		if (! _fJisx0201)
			_JToggleJisx0201 () ;
		break ;
	default:
		break ;
	}
	return	TRUE ;
}

int
CImeBuffer::GetConversionMode () const
{
	if (!_fJMode) {
		return	_fJZenkaku? IMECMODE_ZENKAKU : IMECMODE_ASCII ;
	} else {
		if (_fJisx0201)
			return	IMECMODE_HANKANA ;
		return	_fJKatakana? IMECMODE_KATAKANA : IMECMODE_HIRAGANA ;
	}
}

int
CImeBuffer::GetKeymap () const
{
	if (!_fJMode) {
		return	_fJZenkaku? IMEKEYMAP_ZENKAKU : IMEKEYMAP_ASCII ;
	} else if (_fJAbbrev && !_fJHenkanActive) {
		return	IMEKEYMAP_ABBREV ;
	} else {
		return	IMEKEYMAP_JMODE ;
	}
}

BOOL
CImeBuffer::QueryUpdateContext (
	register int*		pnShift,
	register int*		pnCursor,
	register BOOL*		pfContinue)
{
	register int	nCursor, nShift ;

	nCursor	= _pmkPoint->GetPosition () ;
	nShift	= _GetShiftCount () ;
	if (!_fJMode) {
		/*	�������[�h�łȂ��ꍇ�B�V�t�g����̂̓J�[�\���ʒu�܂ŁB*/
		*pnShift	= nShift ;
		*pnCursor	= 0 ;	/* �V�t�g��̃J�[�\���ʒu�B*/
		*pfContinue	= (_pFilterFunc != _stNormalFilter && _pFilterFunc != _stJKanaInputFilter) || (nShift < _nbufComp) ;
//		*pfContinue	= (nShift < _nbufComp)? TRUE : FALSE ;
	} else {
		*pnShift	= nShift ;
		*pnCursor	= nCursor - nShift ;
		/*	composition text ����̏�Ԃ� IME ON �̏�Ԃ𑱂���� OnClearSession ���Ăяo����ċ����I��
		 *	��Ԃ������������\��������B(��: IE, Office) 
		 *	���̎��A���[�h���ω����Ă��܂��̂Ŕ��Ɉ�a�����o���邱�ƂɂȂ�B
		 */
		*pfContinue	= (_pFilterFunc != _stNormalFilter && _pFilterFunc != _stJKanaInputFilter) || _fJHenkanOn || (nShift < _nbufComp) ;
//		*pfContinue	= _fJHenkanOn || (nShift < _nbufComp) ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::UpdateContext ()
{
	int		nShift, nCursor ;
	BOOL	fContinue ;

	if (! QueryUpdateContext (&nShift, &nCursor, &fContinue))
		return	FALSE ;
	_DeleteRegion (0, nShift) ;
	return	TRUE ;
}

BOOL
CImeBuffer::SetReconvertText (
	register LPCWSTR		wstrTEXT,
	register int			nstrTEXT)
{
	if (nstrTEXT > 0 && wstrTEXT == NULL)
		return	FALSE ;

	Clear () ;
	_JKakutei () ;
	_JSetHenkanPointSubr () ;
	if (nstrTEXT > 0)
		_JInsertStr (wstrTEXT, nstrTEXT) ;
	return	TRUE ;
}

BOOL
CImeBuffer::IsStatusActivep () const
{
	return	! (_pFilterFunc == _stNormalFilter || _pFilterFunc == _stJKanaInputFilter) ;
}

/*========================================================================*
 */

/*	�����ł͑f���� keymap ������B
 *
 *	���ۂ� Filter ���ꂽ�ꍇ�ɂ� *pfFiltered = TRUE �ƂȂ�B
 */
BOOL
CImeBuffer::_NormalFilter ()
{
	register WCHAR			wch ;
	int						nFuncNo ;

	wch	= (WCHAR) _pDoc->GetLastCommandChar () ;

	/*	�L�[�� filter ����邩�ǂ����� topbuffer �̏�ԂɈˑ�����B
	 *
	 *	Composition ���J�n����Ă�����A�m���B�����łȂ�������A
	 *	�󋵂Ɉˑ��B
	 */
	if (! _pDoc->LookupKeymap (wch, &nFuncNo))
		return	FALSE ;

	_pDoc->SetThisCommand (nFuncNo) ;

	/*	�֐��ɂ���ď�����ύX����B
	 */
	switch (nFuncNo) {
	case	FUNCNO_J_KANAINPUT_MODE_ON:
		_JKakutei () ;
		break ;
	case	FUNCNO_J_INSERT_A:
		_JInsertA () ;
		break ;
	case	FUNCNO_J_INSERT_I:
		_JInsertI () ;
		break ;
	case	FUNCNO_J_INSERT_U:
		_JInsertU () ;
		break ;
	case	FUNCNO_J_INSERT_E:
		_JInsertE () ;
		break ;
	case	FUNCNO_J_KANA_INPUT:
		_JKanaInput () ;
		break ;
	case	FUNCNO_J_BACKWARD_CHAR:
		_BackwardChar () ;
		break ;
	case	FUNCNO_J_FORWARD_CHAR:
		_ForwardChar () ;
		break ;
	case	FUNCNO_J_KEYBOARD_QUIT:
		_JKeyboardQuit () ;
		break ;
	case	FUNCNO_J_START_HENKAN:
		_JStartHenkan () ;
		break ;
	case	FUNCNO_J_SET_HENKAN_POINT:
		_JSetHenkanPoint () ;
		break ;
	case	FUNCNO_J_SET_HENKAN_POINT_SUBR:
		_JSetHenkanPointSubr () ;
		break ;
	case	FUNCNO_J_PREVIOUS_CANDIDATE:
		_JPreviousCandidate () ;
		break ;
	case	FUNCNO_J_NEWLINE:
		_JNewline () ;
		break ;
	case	FUNCNO_J_TRY_COMPLETION:
		_JTryCompletion () ;
		break ;
	case	FUNCNO_J_INSERT_PERIOD:
		_JInsertPeriod () ;
		break ;
	case	FUNCNO_J_INSERT_COMMA:
		_JInsertComma () ;
		break ;
	case	FUNCNO_J_SELF_INSERT:
		_JSelfInsert () ;
		break ;
	case	FUNCNO_J_INPUT_BY_CODE_OR_MENU:
		_JInputByCodeOrMenu () ;
		break ;
	case	FUNCNO_J_ABBREV_INPUT:
		_JAbbrevInput () ;
		break ;
	case	FUNCNO_J_ABBREV_PERIOD:
		_JAbbrevPeriod () ;
		break ;
	case	FUNCNO_J_ABBREV_COMMA:
		_JAbbrevComma () ;
		break ;
	case	FUNCNO_J_TOGGLE_KANA:
		_JToggleKana () ;
		break ;
	case	FUNCNO_J_ZENKAKU_EIJI:
		_JZenkakuEiji () ;
		break ;
	case	FUNCNO_J_ZENKAKU_INSERT:
		_JZenkakuInsert () ;
		break ;
	case	FUNCNO_J_PURGE_FROM_JISYO:
		_JPurgeFromJisyo () ;
		break ;
	case	FUNCNO_J_MODE_OFF:
		_JModeOff () ;
		break ;
	case	FUNCNO_J_DELETE_CHAR:
		_DeleteChar (1) ;
		break ;
	case	FUNCNO_J_DELETE_BACKWARD_CHAR:
		_JDeleteBackwardChar (1) ;
		break ;
	case	FUNCNO_J_TODAY:
		_JToday () ;
		break ;
	case	FUNCNO_J_KILL_LINE:
		_KillLine () ;
		break ;
	case	FUNCNO_J_KILL_REGION:
		_KillRegion () ;
		break ;
	case	FUNCNO_J_KILL_RING_SAVE:
		_KillRingSave () ;
		break ;
	case	FUNCNO_J_YANK:
		_Yank () ;
		break ;
	case	FUNCNO_J_BEGINNING_OF_LINE:
		_BeginningOfLine () ;
		break ;
	case	FUNCNO_J_END_OF_LINE:
		_EndOfLine () ;
		break ;
	case	FUNCNO_J_TRANSPOSE_CHARS:
		_TransposeChars () ;
		break ;
	case	FUNCNO_SELF_INSERT_CHARACTER:
		_SelfInsertCharacter () ;
		break ;
	case	FUNCNO_J_ZENKAKU_HENKAN:
		_JZenkakuHenkan () ;
		break ;
	case	FUNCNO_J_TOGGLE_JISX0201:
		_JToggleJisx0201 () ;
		break ;
	case	FUNCNO_NEWLINE:
		_Newline () ;
		break ;
	case	FUNCNO_SAVEUSERJISYO:
		_SaveUserJisyo () ;
		break ;
	case	FUNCNO_MOUSE_DRAG_REGION:
		_MouseDragRegion () ;
		break ;
	case	FUNCNO_ABORT_MINIBUFFER:
	case	FUNCNO_EXIT_MINIBUFFER:
		break ;
	default:
		break ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JKanaInputFilter ()
{
	WCHAR						chKana ;
	WCHAR						bufPrefix [MAXPREFIXLEN] ;
	register int				nbufPrefix ;
	register const CTAssocRule*	pNext ;
	register LPCWSTR			pwstrOutput		= NULL ;
	register LPCWSTR			pwstrNewPrefix	= NULL ;
	register WCHAR				chRChar ;
	register BOOL				fCont			= TRUE ;

	static int				srCharTypeVector []	= {
		0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 4, 4, 4,
		4, 0, 4, 4, 4, 4, 4, 4, 0, 4, 4, 0, 0, 0, 0, 0,
		0, 3, 1, 1, 1, 3, 1, 1, 1, 3, 1, 1, 0, 1, 2, 3,
		1, 0, 1, 1, 1, 3, 1, 1, 2, 1, 1, 0, 0, 0, 0, 5,

		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* LEFT, UP, DOWN, RIGHT, INSERT */
		5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* DELETE, BACK, TAB, HOME, SPACE */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* ESC, KANJI, HELP, F1, F2 */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* F3, F4, F5, F6, F7 */
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* F8, F9, F10, F11, F12 */
		0, 0, 0, 0, 0, 0, /* CLEAR, RETURN */
	} ;

	chKana		= (WCHAR) _pDoc->GetLastCommandChar () ;
	
	/*	�����ɗ����i�K�Ŋm���ɃL�[�� filter ����Ă���B
	 *	���p���ꂸ�ɑf�ʂ�͂��肦�Ȃ��B
	 */
	if (chKana == 0x07) {
		/*	(signal 'quit nil)
		 *
		 *	filter �����Ƃ͏��������̂́A�����̕������������
		 *	�ǂ��Ȃ񂾂낤�H�Ƃ��B
		 */
		if (_nbufJPrefix == 1 && _bufJPrefix [0] == L'o') {
			_nbufJPrefix		= 0 ;
			_JKeyboardQuit () ;
		} else {
			_nbufJPrefix		= 0 ;
			_JErasePrefix () ;
			_pmkJKanaStartPoint	= NULL ;
		}
		_pFilterFunc	= _stNormalFilter ;
		return	TRUE ;
	}
	if (_fJHenkanOn && ! _fJHenkanActive && 
		*_pmkJHenkanStartPoint == (*_pmkPoint - 1) &&
		L'A' <= chKana && chKana <= L'Z') {
		chRChar	= (WCHAR)(chKana + L'a' - L'A') ;
	} else {
		chRChar	= chKana ;
	}
	memcpy (bufPrefix, _bufJPrefix, sizeof (WCHAR) * _nbufJPrefix) ;
	nbufPrefix	= _nbufJPrefix ;
	bufPrefix [nbufPrefix ++]	= chRChar ;

	/*	assoc-rule �̏����B
	 */
	pNext		= _pDoc->JAssocRule (bufPrefix, nbufPrefix) ;
	if (pNext != NULL) {
		pwstrNewPrefix	= pNext->GetNext () ;
		pwstrOutput		= pNext->GetOutput (_fJKatakana) ;
		_JErasePrefix () ;
		if (pwstrOutput != NULL) {
			_JInsertStr (pwstrOutput, wcslen (pwstrOutput)) ;
			if (_fJOkurigana) 
				_JSetOkurigana () ;
		}
		/*	NULL �łȂ��Ƃ������肾���ł͂܂������B*/
		if (pwstrNewPrefix != NULL && *pwstrNewPrefix != L'\0') {
			int		nNewPrefixLen ;

			_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
			nNewPrefixLen	= wcslen (pwstrNewPrefix) ;
			nNewPrefixLen	= (nNewPrefixLen > MAXPREFIXLEN)? MAXPREFIXLEN : nNewPrefixLen ;
			_JInsertPrefix (pwstrNewPrefix, nNewPrefixLen) ;
			memcpy (_bufJPrefix, pwstrNewPrefix, sizeof (WCHAR) * nNewPrefixLen) ;
			_nbufJPrefix	= nNewPrefixLen ;
		} else {
			fCont			= FALSE ;
			_nbufJPrefix	= 0 ;
		}
		goto	exit_function ;
	}

#define	LOOKUP_CHARTYPEVECTOR(ch)	((0 <= (ch) && (ch) < NELEMENTS(srCharTypeVector))? srCharTypeVector[(ch)] : 0)

	/*	``n'' �̏����B
	 */
	if (_nbufJPrefix == 1 && _bufJPrefix [0] == L'n') {
		if (LOOKUP_CHARTYPEVECTOR (chRChar) == 3) {
			_JErasePrefix () ;
			fCont			= FALSE ;
			_pDoc->SetUnreadCommandChar (chRChar) ;
		} else if (chRChar == L'y') {
			_nbufJPrefix	= nbufPrefix ;
			memcpy (_bufJPrefix, bufPrefix, nbufPrefix * sizeof (WCHAR)) ;
			_JInsertPrefix (L"y", 1) ;
		} else if (_fJOkurigana && chRChar == L' ') {
			_pDoc->SetUnreadCommandChar (L'n') ;
		} else {
			_JErasePrefix () ;
			_JInsertStr (_fJKatakana? L"��" : L"��", 1) ;
			_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
			_nbufJPrefix		= 0 ;
			fCont				= FALSE ;
			_pDoc->SetUnreadCommandChar (chRChar) ;
		}
		goto	exit_function ;
	}

	/*	``o'' �̏����B
	 */
	if (_nbufJPrefix == 1 && _bufJPrefix [0] == L'o') {
		if (chRChar == L'h') {
			_nbufJPrefix	= nbufPrefix ;
			memcpy (_bufJPrefix, bufPrefix, nbufPrefix * sizeof (WCHAR)) ;
			_JInsertPrefix (L"h", 1) ;
		} else {
			_JErasePrefix () ;
			fCont			= FALSE ;
			_nbufJPrefix	= 0 ;
			_pDoc->SetUnreadCommandChar (chKana) ;
		}
		goto	exit_function ;
	}

	/*	``oh'' �̏����B
	 */
	if (_nbufJPrefix == 2 && ! wcsncmp (_bufJPrefix, L"oh", 2)) {
		if (LOOKUP_CHARTYPEVECTOR (chRChar) == 3) {
			fCont			= FALSE ;
			_JErasePrefix () ;
			_nbufJPrefix	= 1 ;
			_bufJPrefix [0]	= L'h' ;
			_pDoc->SetUnreadCommandChar (chRChar) ;
		} else {
			_JErasePrefix () ;
			_JInsertStr (_fJKatakana? L"�I" : L"��", 1) ;
			fCont			= FALSE ;
			_nbufJPrefix	= 0 ;
			_pDoc->SetUnreadCommandChar (chRChar) ;
		}
		goto	exit_function ;
	}

	/*	``��'' �̏����B
	 */
	if (_nbufJPrefix == 1 && _bufJPrefix [0] == chRChar && 
		LOOKUP_CHARTYPEVECTOR (chRChar) == 1) {
		_JErasePrefix () ;
		_JInsertStr (_fJKatakana? L"�b" : L"��", 1) ;
		_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
		_JInsertPrefix (&chRChar, 1) ;
	} else if (_pDoc->IsValidPrefixp (bufPrefix, nbufPrefix)) {
		/* [BEGIN] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
		_JErasePrefix () ;
		/* [END] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
		_nbufJPrefix	= nbufPrefix ;
		memcpy (_bufJPrefix, bufPrefix, nbufPrefix * sizeof (WCHAR)) ;
		/* [BEGIN] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
		_JInsertPrefix (bufPrefix, nbufPrefix) ;
		/* [END] --- modified for "IwasH" -> "IwaSh" 2006/09/12 */
	} else if (LOOKUP_CHARTYPEVECTOR (chRChar) == 3) {
		fCont	= FALSE ;
		_JErasePrefix () ;
		_pDoc->SetUnreadCommandChar (chRChar) ;
	} else if (LOOKUP_CHARTYPEVECTOR (chRChar) == 4) {
		register int	ch	= _pDoc->GetLastCommandChar () ;
		_JErasePrefix () ;
		_pDoc->SetLastCommandChar (chRChar) ;
		_JSetHenkanPoint () ;
		_pDoc->SetLastCommandChar (ch) ;
	} else if (LOOKUP_CHARTYPEVECTOR (chRChar) == 5) {
		fCont	= FALSE ;
		if (_fJOkurigana && _CharAfter (*_pmkJOkuriganaStartPoint) == L'*') {
			_DeleteRegion (*_pmkJOkuriganaStartPoint, *_pmkJOkuriganaStartPoint + 1) ;
			_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkJOkuriganaStartPoint) ;
			_fJOkurigana		= FALSE ;
		}
		if (_nbufJPrefix > 0) 
			_JErasePrefix () ;
		_nbufJPrefix	= 0 ;
	} else {
		fCont	= FALSE ;
		_JErasePrefix () ;
		_pmkJKanaStartPoint	= NULL ;
		_nbufJPrefix		= 0 ;
		_pDoc->SetUnreadCommandChar (chRChar) ;
	}
#undef	LOOKUP_CHARTYPEVECTOR

  exit_function:
	if (! fCont) 
		_pFilterFunc	= _stNormalFilter ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JHenkanShowCandidatesFilter ()
{
	WCHAR			wch ;
	const BYTE*		bptr ;
	LPCWSTR			wstrResult ;
	int				nCount, nCandidate ;
	IMECANDIDATES*	pMyCand ;
	BOOL			fShow	= TRUE ;
	BOOL			fRetval	= TRUE ;

	pMyCand	= _pDoc->GetCandidateInfoBuffer () ;
	if (pMyCand == NULL || pMyCand->_iStyle != IMECANDSTYLE_READ)
		return	FALSE ;

	wch		= (WCHAR) _pDoc->GetLastCommandChar () ;
	nCount	= NUM_JHENKAN_SHOW_CANDIDATE_KEYS ;
	if (wch == WCH_FINALIZE_CANDIDATELIST) {
		UINT*	piPageIndex	= pMyCand->_vbufPageIndex.GetBuffer () ;
		UINT	iPageMax	= pMyCand->_vbufPageIndex.GetUsage () ;
		UINT	iPageStart ;

		if (pMyCand->_iCurrentPage < iPageMax) {
			nCount		= 0 ;
			iPageStart	= piPageIndex [pMyCand->_iCurrentPage] ;
			while ((iPageStart + nCount) < pMyCand->_iCount && nCount < NUM_JHENKAN_SHOW_CANDIDATE_KEYS)
				nCount	++ ;
		} 
	} else {
		bptr	= _pDoc->GetJHenkanShowCandidateKeys () ;
		nCount	= 0 ;
		while (nCount < NUM_JHENKAN_SHOW_CANDIDATE_KEYS && wch != (WCHAR)*bptr) {
			nCount	++ ;
			bptr	++ ;
		}
	}
	if (nCount < NUM_JHENKAN_SHOW_CANDIDATE_KEYS) {
		CTMarker*	pMkKanaStartPoint	= NULL ;
		CTMarker*	pMkOkuriStartPoint	= NULL ;
		CTMarker*	pMkHenkanEndPoint	= NULL ;
		int			i ;

		for (i = 0 ; i < nCount ; i ++) {
			if (! _pHenkanSession->NextCandidate ()) {
				while (i -- > 0) 
					_pHenkanSession->PreviousCandidate () ;
				goto	exit_func ;
			}
		}
		wstrResult	= _pHenkanSession->GetCandidate () ;

		if (_pmkJKanaStartPoint != NULL) {
			pMkKanaStartPoint	= _MakeMarker (TRUE) ;
			*pMkKanaStartPoint	= *_pmkJKanaStartPoint ;
		}
		if (_pmkJOkuriganaStartPoint != NULL) {
			pMkOkuriStartPoint	= _MakeMarker (TRUE) ;
			*pMkOkuriStartPoint	= *_pmkJOkuriganaStartPoint ;
		}
		pMkHenkanEndPoint	= _MakeMarker (TRUE) ;
		_DeleteRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint) ;
		*pMkHenkanEndPoint	= *_pmkJHenkanStartPoint ;
		_JInsertWord (_pmkJHenkanStartPoint->GetPosition (), wstrResult, wcslen (wstrResult)) ;
		*_pmkJHenkanEndPoint		= *pMkHenkanEndPoint ;
		_DeleteMarker (pMkHenkanEndPoint) ;
		if (pMkOkuriStartPoint != NULL) {
			*_pmkJOkuriganaStartPoint	= *pMkOkuriStartPoint ;
			_DeleteMarker (pMkOkuriStartPoint) ;
		}
		if (pMkKanaStartPoint != NULL) {
			*_pmkJKanaStartPoint		= *pMkKanaStartPoint ;
			_DeleteMarker (pMkKanaStartPoint) ;
		}
		_JKakutei () ;
		_pFilterFunc	= _stNormalFilter ;
		pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
		return	TRUE ;
	}

	switch (wch) {
		/*	���[�ށA����I�������̂Ȃ�A�����Ŋm��Ǝv���Ă��܂��̂ł͂Ȃ����낤���B
		 */
#if 0
	case	WCH_SELECTCANDIDATESTR:
	{
		UINT	iCurrentPage, iMaxPage ;
		int		iSelect	= (int) _pDoc->GetLastKeyData () ;

		iCurrentPage	= pMyCand->_iCurrentPage ;
		piPageIndex		= (UINT*) pMyCand->_vbufPageIndex.GetBuffer () ;
		iMaxPage		= pMyCand->_vbufPageIndex.GetUsage () ;
		if (iCurrentPage >= iMaxPage)
			return	FALSE ;
		if (iSelect < piPageIndex [iCurrentPage]) {
			while (0 < iCurrentPage && iSelect < piPageIndex [iCurrentPage]) {
				_JPreviousCandidate () ;
				if (_nJHenkanCount <= COUNTHENKANSHOWCHANGE) {
					_pFilterFunc	= _stNormalFilter ;
					_pDoc->ClearMessage () ;
					pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
					fShow	= FALSE ;
					goto	exit_func_1 ;
				}
				iCurrentPage	-- ;
			}
			pMyCand->_iSelection	= iSelect ;
			pMyCand->_iCurrentPage	= iCurrentPage ;
			pMyCand->_dwUpdate		|= IMECANDUPDATE_SELECTION | IMECANDUPDATE_CURRENT_PAGE ;
		} else if ((iCurrentPage + 1) < iMaxPage && iSelect >= piPageIndex [iCurrentPage + 1]) {
			while ((iCurrentPage + 1) < iMaxPage && iSelect >= piPageIndex [iCurrentPage + 1]) {
				nCount	= piPageIndex [iCurrentPage + 1] - piPageIndex [iCurrentPage] ;
				/*	���ɐi�߂邾���B*/
				while (nCount -- > 0) {
					_nJHenkanCount	++ ;
					if (! _pHenkanSession->NextCandidate ())
						break ;
				}
				if (nCount > 0)
					break ;
				iCurrentPage	++ ;
			}
			if ((((iCurrentPage + 1 < iMaxPage) && piPageIndex [iCurrentPage] <= iSelect && iSelect < piPageIndex [iCurrentPage + 1])) ||
				(iCurrentPage + 1 == iMaxPage  && piPageIndex [iCurrentPage] <= iSelect)) {
				pMyCand->_iSelection	= iSelect ;
				pMyCand->_iCurrentPage	= iCurrentPage ;
			} else {
				/* error? */
				pMyCand->_iCurrentPage	= iCurrentPage ;
				pMyCand->_iSelection	= piPageIndex [iCurrentPage] ;
			}
			pMyCand->_dwUpdate		|= IMECANDUPDATE_SELECTION | IMECANDUPDATE_CURRENT_PAGE ;
		} else {
			pMyCand->_iSelection	= iSelect ;
			pMyCand->_dwUpdate		|= IMECANDUPDATE_SELECTION ;
		}
		/* ���� _nJHenkanCount �̑���A�Ԉ���Ă��Ȃ����H */
		_nJHenkanCount		= (int) pMyCand->_iSelection + 1 ;

		/*	����������� refine ����K�v�����邩������Ȃ��B*/
		/*DEBUGPRINTFEX (99, (TEXT ("Select=%d, PageStart=%d\n"),
							(int) pMyCand->_iSelection,
							(int) pMyCand->_iPageStart)) ;*/
		break ;
	}
#endif
	default:
	{
		int	nFuncNo ;

		if (! _pDoc->LookupKeymap (wch, &nFuncNo))
			break ;

		/*	space, x, C-g �͂��ꂼ��� key-bind ����ސ�����悤�ɕύX����B
		 */
		switch (nFuncNo) {
		case	FUNCNO_J_PREVIOUS_CANDIDATE:
			{
				UINT	iMaxPage, iCurrentPage ;
				UINT*	piPageIndex ;

				/*	ClearMessage �� JPreviousCandidate �̑O�Ɉړ��B
				 *	_pFilterFunc = _stNormalFilter ����B
				 *	(Tue Feb 15 11:49:48 2005)
				 */
				_pDoc->ClearMessage () ;
				_JPreviousCandidate () ;
				if (_nJHenkanCount <= COUNTHENKANSHOWCHANGE) {
					_pFilterFunc	= _stNormalFilter ;
					pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
					fShow	= FALSE ;
					goto	exit_func_1 ;
				}
				/*	�܂����̃��[�h�͌p������B*/
				iCurrentPage	= pMyCand->_iCurrentPage ;
				if (iCurrentPage > 0) {
					UINT	iCurPageIndex, iSelection ;

					piPageIndex		= (UINT*) pMyCand->_vbufPageIndex.GetBuffer () ;
					iMaxPage		= pMyCand->_vbufPageIndex.GetUsage () ;
					iCurPageIndex	= piPageIndex [iCurrentPage] ;
					if (pMyCand->_iSelection < piPageIndex [iCurrentPage]) {
						iSelection	= 0 ; 
					} else {
						iSelection		= (pMyCand->_iSelection - piPageIndex [iCurrentPage]) ;
					}
					iCurrentPage	-- ;

					pMyCand->_iCurrentPage	= iCurrentPage ;
					pMyCand->_iSelection	= piPageIndex [iCurrentPage] + iSelection ;
					if (pMyCand->_iSelection >= iCurPageIndex) {
						pMyCand->_iSelection	= (piPageIndex [iCurrentPage] < iCurPageIndex)? (iCurPageIndex - 1) : piPageIndex [iCurrentPage] ;
					}
					pMyCand->_dwUpdate		|= IMECANDUPDATE_SELECTION | IMECANDUPDATE_CURRENT_PAGE ;
				}
			}
			break ;

		case	FUNCNO_J_START_HENKAN:
			{
				UINT	iCurrentPage, iMaxPage ;

				iCurrentPage	= pMyCand->_iCurrentPage ;
				iMaxPage		= pMyCand->_vbufPageIndex.GetUsage () ;
				DEBUGPRINTF ((TEXT ("NextCandidatePage: CurrentPage(%d), MaxPage(%d)\n"), iCurrentPage, iMaxPage)) ;

				if ((iCurrentPage + 1) >= iMaxPage) {
					/*	�ċA�o�^�ɓ���B*/
					_pDoc->ClearMessage () ;
					fRetval	= _JHenkanInMinibuff () ;
					pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
					fShow	= FALSE ;
					goto	exit_func_1 ;
				} else {
					UINT*	piPageIndex ;
					UINT	iPageIndex, iNextPageIndex ;

					piPageIndex		= (UINT*) pMyCand->_vbufPageIndex.GetBuffer () ;
					iPageIndex		= piPageIndex [iCurrentPage] ; 
					iNextPageIndex	= piPageIndex [iCurrentPage + 1] ;
					nCount			= iNextPageIndex - iPageIndex ;

					iCurrentPage	++ ;
					/*	���ɐi�߂邾���B*/
					while (nCount -- > 0) {
						_nJHenkanCount			++ ;
						pMyCand->_iSelection	++ ;

						if (! _pHenkanSession->NextCandidate ()) {
							/*ASSERT (_pDoc->DisableMinibufferp ()) ;*/
							_pHenkanSession->Rewind () ;
							pMyCand->_iSelection	= 0 ;
							_nJHenkanCount			= 1 ;
							iCurrentPage			= 0 ;
							break ;
						}
					}
					pMyCand->_iCurrentPage	= iCurrentPage ;

					/*	����������� refine ����K�v�����邩������Ȃ��B*/
					pMyCand->_dwUpdate		|= IMECANDUPDATE_SELECTION | IMECANDUPDATE_CURRENT_PAGE ;
				}
			}
			break ;

		case	FUNCNO_J_KEYBOARD_QUIT:
			goto	j_keyboard_quit ;

		default:
			{
				WCHAR	bufText [256] ;
				int		nText ;

				if (wch > 0x20 && wch != 0x7F) {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"`%c' is not valid here!", wch) ;
				} else {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"0x%02x is not valid here!", wch) ;
				}
				_pDoc->SetMessage (bufText, nText) ;
			}
			break ;
		}
		break ;
	}
	/*case	0x07: keyboad-quit ���Ȃ��Ȃ�ƁA�͂܂�H */
	case	WCH_ABORT_CANDIDATELIST:
	  j_keyboard_quit:
		_pHenkanSession->Rewind () ;
		_nJHenkanCount	= 1 ;
		_JPreviousCandidate () ;
		_pFilterFunc	= _stNormalFilter ;
		pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
		fShow	= FALSE ;
		goto	exit_func_1 ;
	}
  exit_func_1:
  exit_func:
	if (fShow)
		_ShowJHenkanCandidates () ;
	return	fRetval ;
}


/*	skk8.6 �� source code ����Ă������Bskk10.62a �̍\���� C ��
 *	�Ă������͓̂���B�s�\�ł͂Ȃ����c�B
 *
 *	���������Ɩ{�̂� 10.62a �x�[�X�ɂ���K�v�����邵�A���̕ύX
 *	�͌�ɂ��邱�Ƃɂ��悤�B
 */
BOOL
CImeBuffer::_JKanaInput ()
{
	register WCHAR	chKana ;
	register BOOL	fApply ;
	register int	n ;

	chKana		= (WCHAR) _pDoc->GetLastCommandChar () ;

	if (_pDoc->IsJKakuteiEarlyp () && _fJHenkanActive)
		_JKakutei () ;
	
	/*	last-command-char �����B�O��̍Ō�̓��͂� last-command-char
	 *	�ł���B�ŁA�������ȁB
	 */
	/*	�O��̍Ō�̓��͕����� ?o �Ȃ�A
	 */
	fApply	= FALSE ;
	if (_pDoc->GetLastCommandChar () == L'o') {
		n	= _nbufJPrefix ;
		if (n < MAXPREFIXLEN) {
			_bufJPrefix [n ++]	= chKana ;
			fApply	= (_pDoc->JAssocRule (_bufJPrefix, n) == NULL) ;
		} else {
			fApply	= TRUE ;
		}
	}
	if (fApply) {
		_JInsertO () ;
		_bufJPrefix [0]			= chKana ;
		_nbufJPrefix			= 1 ;
		_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
	} else {
		_bufJPrefix [0]			= chKana ;
		_nbufJPrefix			= 1 ;
		_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
		_JInsertPrefix (_bufJPrefix, _nbufJPrefix) ;
	} 

	/*	�L�[�̃t�B���^�[������ύX����B*/
	_pFilterFunc	= _stJKanaInputFilter ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JToggleKana ()
{
	if (_fJHenkanOn && !_fJHenkanActive) {
		if (! _fJKatakana) {
			_JKatakanaHenkan () ;
		} else {
			_JHiraganaHenkan () ;
		}
	} else {
		_JKakutei () ;
		_fJKatakana	= ! _fJKatakana ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JToggleJisx0201 ()
{
	if (_fJHenkanOn && ! _fJHenkanActive) {
		if (! _fJisx0201) {
			_JHankanaHenkan () ;
		} else {
			_JZenkanaHenkan () ;
		}
	} else {
		_JKakutei () ;
		_fJisx0201	= ! _fJisx0201 ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JSetHenkanPoint ()
{
	register WCHAR	chKana ;
	register BOOL	fNormal ;
	register WCHAR	chLastChar ;
	register BOOL	fSokuon ;
	register BOOL	fHenkanActive ;

	chKana			= (WCHAR) _pDoc->GetLastCommandChar () ;
	fNormal			= (L'A' <= chKana && chKana <= L'Z') ;
	chLastChar		= fNormal? (WCHAR)(chKana - L'A' + L'a') : chKana ;
	fSokuon			= (_nbufJPrefix == 1 && _bufJPrefix [0] == chLastChar && chLastChar != L'o') ;
	fHenkanActive	= _fJHenkanActive ;
	if (! _fJHenkanOn || _fJHenkanActive) {
		if (fNormal) {
			_JSetHenkanPointSubr () ;
		} else {
			if (_fJHenkanOn)
				_JSetHenkanPointSubr () ;
			if (fHenkanActive) {
				/*	j-emulate-original-map */
				//_JEmulateOriginalMap () ;
				_SelfInsertCharacter () ;
			} else {
				_JSelfInsert () ;
			}
		}
	} else {
		LPCWSTR		pwstr ;
		int			nwstr ;
		int			p1 ;

		if (fNormal) {
			p1	= _CharAfter (*_pmkPoint - 1) ;
			if (! _fJOkurigana && 
				!( *_pmkJHenkanStartPoint != *_pmkPoint && 
				   (p1 == L'?' || p1 == L'<' || p1 == L'>') ||
				   (L'0' <= p1 && p1 <= L'9') || 
				   (L'�O' <= p1 && p1 <= L'�X'))) {
				if (_pDoc->IsSkkProcessOkuriEarlyp ()) {
					_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
					nwstr	= _BufferSubstring (*_pmkJHenkanStartPoint, fSokuon? *_pmkJKanaStartPoint : *_pmkPoint, &pwstr) ;
					memcpy (_bufJHenkanKey, pwstr, nwstr * sizeof (WCHAR)) ;
					_nbufJHenkanKey	= nwstr ;
					if (_nbufJHenkanKey < NELEMENTS (_bufJHenkanKey)) {
						if (fSokuon)
							_bufJHenkanKey [_nbufJHenkanKey ++]	= _fJKatakana? L'�b' : L'��' ;
					}
					if (_nbufJHenkanKey < NELEMENTS (_bufJHenkanKey)) 
						_bufJHenkanKey [_nbufJHenkanKey ++]	= chLastChar ;
					
					if (fSokuon) {
						_JErasePrefix () ;
						_JInsertStr (_fJKatakana? L"�b" : L"��", 1) ;
					}
					_Insert (L" ", 1) ;
					_nbufJPrefix	= 0 ;
					_JHenkan () ;
					_DeleteBackwardChar (fSokuon? 2 : 1) ;
					_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
				} else {
					if (_pmkJHenkanStartPoint->GetPosition () == _pmkPoint->GetPosition ()) {
					} else {
						if (fSokuon) {
							_JErasePrefix () ;
							_JInsertStr (_fJKatakana ? L"�b" : L"��", 1) ;
							_nbufJPrefix	= 0 ;
						}
						_SetMarker (&_pmkJOkuriganaStartPoint, MARKER_J_OKURIGANA_STARTPOINT, _pmkPoint) ;
						_Insert (L"*", 1) ;
						_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
						_wchOkuriChar	= chLastChar ;
						_fJOkurigana	= TRUE ;
					}
				}
			}
		} else {
			_Insert (&chLastChar, 1) ;
			_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
			nwstr	= _BufferSubstring (*_pmkJHenkanStartPoint, *_pmkPoint, &pwstr) ;
			memcpy (_bufJHenkanKey, pwstr, nwstr * sizeof (WCHAR)) ;
			_nbufJHenkanKey	= nwstr ;
			memcpy (_bufJSearchKey, pwstr, nwstr * sizeof (WCHAR)) ;
			_nbufJSearchKey	= nwstr ;
			_nbufJPrefix	= 0 ;
			_JHenkan () ;
		}
	}
	if (fNormal)
		_pDoc->SetUnreadCommandChar (chLastChar) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JStartHenkan ()
{
	if (_fJHenkanOn) {
		_fJMode	= TRUE ;
		if (_fJHenkanActive) {
			_JNextCandidate () ;
		} else {
			LPCWSTR				pwstr ;
			register int		nwstr ;

			if (_nbufJPrefix > 0)
				return	FALSE ;
			if (*_pmkPoint < *_pmkJHenkanStartPoint)
				return	FALSE ;

			/*	�ށAnewline ���܂�ł��邩�ǂ����̔���c���B�܂��A�����
			 *	skip ���悤�B
			 */
			_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;

			nwstr	= _BufferSubstring (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint, &pwstr) ;
			_nbufJHenkanKey	= JHenkanCopy (_bufJHenkanKey, pwstr, nwstr) ;
			_nbufJSearchKey	= _JComputeNumericHenkanKey (_bufJSearchKey, MAXCOMPLEN) ;
			_JHenkan () ;
		}
	} else {
		_JSelfInsert () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JSetHenkanPointSubr ()
{
	ASSERT (_pmkPoint != NULL) ;

	if (_fJHenkanOn)
		_JKakutei () ;
	if (_nbufJPrefix > 0)
		_JErasePrefix () ;
	_Insert (L"��", 1) ;
	if (_nbufJPrefix > 0) {
		_SetMarker (&_pmkJKanaStartPoint, MARKER_J_KANA_STARTPOINT, _pmkPoint) ;
		_Insert (_bufJPrefix, _nbufJPrefix) ;
	}
	_fJHenkanOn	= TRUE ;
	_SetMarker (&_pmkJHenkanStartPoint, MARKER_J_HENKAN_STARTPOINT, _pmkPoint) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JSelfInsert ()
{
	WCHAR				wch	;
	register LPCWSTR	wstrWord ;
	int					nstrWord ;

	wch			= (WCHAR) _pDoc->GetLastCommandChar () ;
	wstrWord	= _pDoc->GetSkkInputVector (wch, &nstrWord) ;
	if (nstrWord <= 0) {
		//_JEmulateOriginalMap () ;
		_SelfInsertCharacter () ;
	} else {
		_JInsertStr (wstrWord, nstrWord) ;
	}
	if (_fJHenkanActive)
		_JKakutei () ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JZenkakuInsert ()
{
	WCHAR				wch	;
	register LPCWSTR	wstrWord ;
	int					nstrWord ;

	wch			= (WCHAR) _pDoc->GetLastCommandChar () ;
	wstrWord	= _pDoc->GetSkkZenkakuVector (wch, &nstrWord) ;
	if (nstrWord <= 0)
		return	TRUE ;
	return	_JInsertStr (wstrWord, nstrWord) ;
}

BOOL
CImeBuffer::_JModeOff ()
{
	_JKakutei () ;
	_fJMode			= FALSE ;
	_nbufJPrefix	= 0 ;
	_fJZenkaku		= FALSE ;
	_fJAbbrev		= FALSE ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JZenkakuEiji ()
{
	_JKakutei () ;
	_fJMode			= FALSE ;
	_nbufJPrefix	= 0 ;
	_fJZenkaku		= TRUE ;
	_fJAbbrev		= FALSE ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JAbbrevInput ()
{
	if (_fJHenkanOn && !_fJHenkanActive)
		return	FALSE ;
	_JKakutei () ;
	_JSetHenkanPointSubr () ;
	_fJAbbrev	= TRUE ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertA ()
{
	_JInsert (_pDoc->GetRomaKana (L'a')) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertI ()
{
	_JInsert (_pDoc->GetRomaKana (L'i')) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertU ()
{
	_JInsert (_pDoc->GetRomaKana (L'u')) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertE ()
{
	_JInsert (_pDoc->GetRomaKana (L'e')) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertComma ()
{
	if (_pDoc->GetLastCommand () == FUNCNO_J_COMPLETION) {
		_JPreviousCompletion () ;
	} else {
		_JSelfInsert () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertPeriod ()
{
	if (_pDoc->GetLastCommand () == FUNCNO_J_COMPLETION) {
		_pDoc->SetThisCommand (FUNCNO_J_COMPLETION) ;
		_JCompletion (FALSE) ;
	} else {
		_JSelfInsert () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JTryCompletion ()
{
	if (_fJHenkanOn && !_fJHenkanActive) {
		/*	 */
		_pDoc->SetThisCommand (FUNCNO_J_COMPLETION) ;
		_JCompletion (_pDoc->IsSkkDabbrevLikeCompletion () || _pDoc->GetLastCommand () != FUNCNO_J_COMPLETION) ;
	} else {
		_SelfInsertCharacter () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JAbbrevPeriod ()
{
	if (_pDoc->GetLastCommand () == FUNCNO_J_COMPLETION) {
		_pDoc->SetThisCommand (FUNCNO_J_COMPLETION) ;
		_JCompletion (FALSE) ;
	} else {
		//_JEmulateOriginalMap () ;
		_SelfInsertCharacter () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JAbbrevComma ()
{
	if (_pDoc->GetLastCommand () == FUNCNO_J_COMPLETION) {
		_JPreviousCompletion () ;
	} else {
		//_JEmulateOriginalMap () ;
		_SelfInsertCharacter () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JNewline ()
{
	register BOOL	fNoNL ;
	register BOOL	fJHenkanOn ;

	fNoNL		= _pDoc->IsSkkEggLikeNewlinep () && _fJHenkanOn ;
	fJHenkanOn	= _fJHenkanOn ;

	if (_pRecursiveEditSession != NULL) {
		_JKakutei () ;
		if (! fNoNL || ! fJHenkanOn)
			return	_ExitMinibuffer () ;
	} else {
		if (_fJMode)
			_JKakutei () ;
		if (! fNoNL) {
			/*	top buffer �Ȃ� newline �� process ���Ȃ��A
			 *	�� top buffer �Ȃ� unused-event �� newline ��������B*/
			DEBUGPRINTF ((TEXT("CImeBuffer::_JNewline() : last-char = 0x%x\n"), 
						  (int)_pDoc->GetLastCommandChar ())) ;
			_JEmulateOriginalMap () ;
		}
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JKeyboardQuit ()
{
#if 0
	/*	minibuffer �ϊ����́����[�h�������߂���H
	 */
	if (_nbufJHenkanKey == 0) {
		/*	minibuffer �ϊ����Ȃ�e�̏����ւƐ����߂��B*/
		/*	�����āA�e���� keyboard-quit ����B*/
		if (_pRecursiveEditSession != NULL) 
			return	_AbortRecursiveEdit () ;
	}
#endif
	if (_fJHenkanActive) {
		if (_pDoc->IsSkkDeleteOkuriWhenQuitp () && _nJOkuriAri) {
			register CTMarker*	pMarker	= _MakeMarker (true) ;
			*pMarker	= *_pmkPoint ;
			_nJHenkanCount	= 1 ;
			_JPreviousCandidate () ;
			_DeleteRegion (*pMarker, *_pmkPoint) ;
			_DeleteMarker (pMarker) ;
		} else {
			_nJHenkanCount	= 1 ;
			_JPreviousCandidate () ;
		}
	} else {
		if (_fJHenkanOn) {
			if (*_pmkPoint > *_pmkJHenkanStartPoint)
				_DeleteRegion (*_pmkPoint, *_pmkJHenkanStartPoint) ;
			_JKakutei () ;
		} else {
			/*	minibuffer �ϊ����Ȃ�e�̏����ւƐ����߂��B*/
			if (_pRecursiveEditSession != NULL) {
				return	_AbortRecursiveEdit () ;
			} else {
				Clear () ;
			}
		}
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JDeleteBackwardChar (
	int		nCount)
{
	if (_fJOkurigana) {
		_fJOkurigana	= FALSE ;
		if (_pmkJOkuriganaStartPoint != NULL) {
			register int	nOkuriPos ;
			nOkuriPos		= _pmkJOkuriganaStartPoint->GetPosition () ;
			if (_nbufComp > nOkuriPos && _bufComp [nOkuriPos] == L'*') {
				_DeleteRegion (nOkuriPos, nOkuriPos + 1) ;
			}
		}
	}
	if (_fJHenkanOn && *_pmkPoint == *_pmkJHenkanStartPoint) {
		_nJHenkanCount	= 0 ;
		_JKakutei () ;
	} else {
		register int	p ;

		if (_fJHenkanActive) {
			ASSERT (_pmkJHenkanEndPoint != NULL) ;
			p	= _pmkJHenkanEndPoint->GetPosition () ;
			if (! _pDoc->IsSkkDeleteImpliesKakuteip () && p == *_pmkPoint) {
				_JPreviousCandidate () ;
			} else {
				_DeleteBackwardChar (nCount) ;
				/* skk10.62a �y�� ddskk ���� <= �ɕύX�B(Fri Feb 17 12:28:22 2006) */
				if (_pmkPoint->GetPosition () <= p)
					_JKakutei () ;
			}
		} else {
			if (_pRecursiveEditSession != NULL) {
				_DeleteBackwardChar (nCount) ;
			} else {
				// _JEmulateOriginalMap () ;
				if (_pmkPoint->GetPosition () > 0) {
					_DeleteBackwardChar (nCount) ;
				} else {
					_JEmulateOriginalMap () ;
				}
			}
		}
	}
	return	TRUE ;
}

/*========================================================================
 */
BOOL
CImeBuffer::_Newline ()
{
	if (_pRecursiveEditSession != NULL) {
		return	_ExitMinibuffer () ;
	} else {
		_JEmulateOriginalMap () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_BackwardChar ()
{
	register int	nTop ;

	ASSERT (_pmkPoint != NULL) ;

	nTop	= (_pmkEditTop == NULL)? 0 : _pmkEditTop->GetPosition () ;
	if (_pmkPoint->GetPosition () > nTop)
		_pmkPoint->Backward (1) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_ForwardChar ()
{
	ASSERT (_pmkPoint != NULL) ;

	if (_pmkPoint->GetPosition () < _nbufComp)
		_pmkPoint->Forward (1) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_DeleteBackwardChar (
	register int		nDelete)
{
	register int	nTop ;

	ASSERT (_pmkPoint != NULL) ;

	nTop	= (_pmkEditTop == NULL)? 0 : _pmkEditTop->GetPosition () ;
	if (_pmkPoint->GetPosition () > nTop)
		return	_DeleteRegion (*_pmkPoint - nDelete, *_pmkPoint) ;
	return	FALSE ;
}

BOOL
CImeBuffer::_SelfInsertCharacter ()
{
	WCHAR		wch	= _pDoc->GetLastCommandChar () ;

	/*[����]
	 *	printable �łȂ����̂� insert ���Ȃ����Ƃɂ���
	 *��
	 *	emacs �ɂ͂���Ȑ����͂Ȃ����B
	 */
	if (0x20 <= wch && wch < 0x7F)
		return	_Insert (&wch, 1) ;
	return	FALSE ;
}

BOOL
CImeBuffer::_TransposeChars ()
{
	register int	nPoint ;
	WCHAR			wch ;

	nPoint	= _pmkPoint->GetPosition () ;

	if (nPoint >= _nbufComp || nPoint < 1) 
		return	FALSE ;

	wch	= _bufComp [nPoint - 1] ;
	_DeleteRegion (nPoint - 1, nPoint) ;
	_ForwardChar () ;
	_Insert (&wch, 1) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_EndOfLine ()
{
	register int	nPoint ;

	nPoint	= _pmkPoint->GetPosition () ;
	while (nPoint < _nbufComp) {
		if (_bufComp [nPoint] == L'\n') 
			break ;
		nPoint	++ ;
	}
	return	_pmkPoint->Forward (nPoint - _pmkPoint->GetPosition ()) ;
}

BOOL
CImeBuffer::_BeginningOfLine ()
{
	register int	nTop, nPoint ;

	ASSERT (_pmkPoint != NULL) ;

	nTop	= (_pmkEditTop == NULL)? 0 : _pmkEditTop->GetPosition () ;
	nPoint	= _pmkPoint->GetPosition () ;
	if (nPoint > nTop) {
		nPoint	-- ;
		while (nPoint > nTop) {
			if (_bufComp [nPoint] == L'\n') {
				nPoint	++ ;
				break ;
			}
			nPoint	-- ;
		}
		_pmkPoint->Backward (_pmkPoint->GetPosition () - nPoint) ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_SetMarkCommand ()
{
	_pDoc->SetMessage (L"Mark set") ;
	_SetMarker (&_pmkMark, MARKER_MARK, _pmkPoint) ;
	return	TRUE ;
}

/*��	�ҏW���̃e�L�X�g�ɉ��s������\��������̂Œ��ӂ���
 *		���ƁB
 */
BOOL
CImeBuffer::_KillLine ()
{
	register int	nPoint, nLast ;

	ASSERT (_pmkPoint != NULL) ;

	nPoint	= _pmkPoint->GetPosition () ;
	if (_bufComp [nPoint] == L'\n') {
		nLast	= nPoint + 1 ;
	} else {
		_EndOfLine () ;
		nLast	= _pmkPoint->GetPosition () ;
	}
	return	_KillRegion (nPoint, nLast) ;
}

BOOL
CImeBuffer::_KillRegion (
	register int		nStart,
	register int		nEnd)
{
	CTCutBufferSession*	pSession ;
	register int		nLastCmd ;
	register BOOL		fAppend ;
	WCHAR				rszBuffer [MAXPREFIXLEN] ;

	if (nStart < 0 || nEnd < 0) {
		if (_pmkMark == NULL) {
			_pDoc->SetMessage (L"The mark is not set now") ;
			return	TRUE ;
		}
		nStart		= _pmkPoint->GetPosition () ;
		nEnd		= _pmkMark->GetPosition () ;
	}
	if (nStart > nEnd) {
		register int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	if (nStart == nEnd || nStart < 0 || nEnd > _nbufComp)
		return	FALSE ;

	nLastCmd	= _pDoc->GetLastCommand () ;
	fAppend		= (nLastCmd == FUNCNO_J_KILL_REGION || nLastCmd == FUNCNO_J_KILL_RING_SAVE)? TRUE : FALSE ;
	pSession	= new CTCutBufferSession () ;
	if (pSession != NULL) {
		register LPCWSTR	pSrc ;
		register LPWSTR		pDest ;
		register int		nSrc, nDest ;

		/*	�����ŊO�E�����ɉ��s�R�[�h�� \n �������� 0x0D, 0x0A
		 *	�ɕϊ�����K�v������B
		 */
		pSrc	= _bufComp + nStart ;
		nSrc	= nEnd - nStart ;
		pDest	= rszBuffer ;
		nDest	= NELEMENTS (rszBuffer) ;
		while (nSrc > 0 && nDest > 0) {
			if (*pSrc == L'\n') {
				/*	0x0D, 0x0A �Ƒ�������̂łȂ����
				 *	1����������Ȃ����Ƃɂ���B*/
				if (nDest > 1) {
					*pDest ++	= 0x0D ;					
					*pDest ++	= 0x0A ;
					nDest  -= 2 ;
				}
			} else {
				*pDest ++	= *pSrc ;
				nDest -- ;
			}
			pSrc ++ ;
			nSrc -- ;
		}
		pSession->Set (rszBuffer, pDest - rszBuffer, fAppend) ;
		delete	pSession ;
	}
	_DeleteRegion (nStart, nEnd) ;
	_pDoc->SetThisCommand (FUNCNO_J_KILL_REGION) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_KillRingSave (
	register int		nStart,
	register int		nEnd)
{
	CTCutBufferSession*	pSession ;
	register int		nLastCmd ;
	register BOOL		fAppend ;
	WCHAR				rszBuffer [MAXPREFIXLEN] ;

	if (nStart < 0 || nEnd < 0) {
		if (_pmkMark == NULL) {
			_pDoc->SetMessage (L"The mark is not set now") ;
			return	TRUE ;
		}
		nStart		= _pmkPoint->GetPosition () ;
		nEnd		= _pmkMark->GetPosition () ;
	}
	if (nStart > nEnd) {
		register int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	if (nStart == nEnd || nStart < 0 || nEnd > _nbufComp)
		return	FALSE ;

	nLastCmd	= _pDoc->GetLastCommand () ;
	fAppend		= (nLastCmd == FUNCNO_J_KILL_REGION || nLastCmd == FUNCNO_J_KILL_RING_SAVE)? TRUE : FALSE ;
	pSession	= new CTCutBufferSession () ;
	if (pSession != NULL) {
		register LPCWSTR	pSrc ;
		register LPWSTR		pDest ;
		register int		nSrc, nDest ;

		/*	�����ŊO�E�����ɉ��s�R�[�h�� \n �������� 0x0D, 0x0A
		 *	�ɕϊ�����K�v������B
		 */
		pSrc	= _bufComp + nStart ;
		nSrc	= nEnd - nStart ;
		pDest	= rszBuffer ;
		nDest	= NELEMENTS (rszBuffer) ;
		while (nSrc > 0 && nDest > 0) {
			if (*pSrc == L'\n') {
				/*	0x0D, 0x0A �Ƒ�������̂łȂ����
				 *	1����������Ȃ����Ƃɂ���B*/
				if (nDest > 1) {
					*pDest ++	= 0x0D ;					
					*pDest ++	= 0x0A ;
					nDest  -= 2 ;
				}
			} else {
				*pDest ++	= *pSrc ;
				nDest -- ;
			}
			pSrc ++ ;
			nSrc -- ;
		}
		pSession->Set (rszBuffer, pDest - rszBuffer, fAppend) ;
		delete	pSession ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeBuffer::_Yank ()
{
	CTCutBufferSession*	pSession ;
	WCHAR				rszBuffer [MAXPREFIXLEN] ;
	register int		n ;

	pSession	= new CTCutBufferSession () ;
	if (pSession == NULL)
		return	FALSE ;
	n	= pSession->Get (rszBuffer, MAXPREFIXLEN) ;
	if (n > 0) {
		register LPWSTR	wptr, wptrStart ;

		wptr	= rszBuffer ;
		while (n > 0) {
			wptrStart	= wptr ;
			while (n > 0 && *wptr != 0x0D) {
				wptr	++ ;
				n		-- ;
			}
			_Insert (wptrStart, wptr - wptrStart) ;

			/*	�O�E�Ƃ̃C���^�[�t�F�[�X�ł��邱�̕����ŉ��s�R�[�h��
			 *	0x0D, 0x0A �Ƃ��Ă���ė���\��������B
			 */
			if (*wptr == 0x0D) {
				if (n > 1 && *(wptr + 1) == 0x0A) {
					while (n > 1 && *wptr == 0x0D && *(wptr + 1) == 0x0A) {
						_Insert (L"\n", 1) ;
						wptr	+= 2 ;
						n		-= 2 ;
					}
				} else {
					/*	0x0D �����̏o���͂��̂܂ܒʂ��B
					 */
					_Insert (wptr, 1) ;
					wptr	++ ;
					n		-- ;
				}
			}
		}
	}
	delete	pSession ;
	return	TRUE ;
}

BOOL
CImeBuffer::_AbortRecursiveEdit ()
{
	if (_pRecursiveEditSession == NULL)
		return	FALSE ;
	if (_pRecursiveEditSession->Abort (this)) {
		delete	_pRecursiveEditSession ;
		_pRecursiveEditSession	= NULL ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_ExitMinibuffer ()
{
	register LPCWSTR	wstrMessage ;
	register int		nPos, nstrMessage ;

	if (_pRecursiveEditSession == NULL)
		return	FALSE ;

	nPos		= (_pmkEditTop != NULL)? _pmkEditTop->GetPosition () : 0 ;
	nstrMessage	= _nbufComp - nPos ;
	wstrMessage	= _bufComp + nPos ;
	if (_pRecursiveEditSession->Exit (this, wstrMessage, nstrMessage)) {
		delete	_pRecursiveEditSession ;
		_pRecursiveEditSession	= NULL ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_MouseDragRegion ()
{
	WCHAR			wch ;
	LPARAM			lParam ;
	register int	nPos, nCount, nLastCmd ;
	BOOL			fEnd ;

	wch		= (WCHAR) _pDoc->GetLastCommandChar () ;
	if (wch != WCH_LBUTTON && wch != WCH_RBUTTON)
		return	FALSE ;

	lParam	= _pDoc->GetLastKeyData () ;
	nPos	= (short)lParam & 0x7FFFFFFFL ;
	fEnd	= (lParam & 0x80000000L) != 0 ;

	/*	�擪�́u�I�v��ǂݔ�΂��Ȃ��Ƃ����Ȃ��̂ŁB�ށA�ł��A���ꂾ�Ɓc�߂�Ȃ��ꏊ��
	 *	�������獢��Ȃ����ȁH
	 */
	if (_pDoc->RecursiveEditp () && _pDoc->HaveMessagep () && ! IsStatusActivep ())
		nPos	-- ;

	/*	�J�[�\�����w�肳�ꂽ�ʒu�ւƈړ�������B*/
	_BeginningOfLine () ;
	nPos	= (nPos > _nbufComp)? _nbufComp : nPos ;
	nCount	= nPos - _pmkPoint->GetPosition () ;
	while (nCount -- > 0) 
		_ForwardChar () ;

	nLastCmd	= _pDoc->GetLastCommand () ;
	if (nLastCmd != FUNCNO_MOUSE_DRAG_REGION || _pmkMark == NULL) {
		/*	�}�[�N���J�[�\���ʒu�ɐݒ肷��B*/
		_SetMarker (&_pmkMark, MARKER_MARK, _pmkPoint) ;
	}
	if (fEnd) 
		_pDoc->SetThisCommand (FUNCNO_MOUSE_DRAG_REGION_END) ;
	return	TRUE ;
}

/*========================================================================
 */
BOOL
CImeBuffer::_JKakutei ()
{
	register int	nPos ;

	_fJMode			= TRUE ;
	_fJZenkaku		= FALSE ;
	_fJAbbrev		= FALSE ;
	_nbufJPrefix	= 0 ;
	if (_fJHenkanOn) {
		if (_fJHenkanActive && _nJHenkanCount > 0 && _pHenkanSession != NULL) {
			register LPCWSTR	wstrResult ;

			wstrResult	= _pHenkanSession->GetReferCandidate () ;
			if (wstrResult != NULL) {
				_JUpdateJisyo (wstrResult, lstrlenW (wstrResult), new CTRecordSession ()) ;
				_JSharp4UpdateJisyo (TRUE) ;
			} else {
				wstrResult	= _pHenkanSession->GetCandidate () ;
				if (wstrResult != NULL) 
					_JUpdateJisyo (wstrResult, lstrlenW (wstrResult), new CTRecordSession ()) ;
			}
			/*	�ǂ݉����ƕϊ����ʂ̑Ή���������B*/
			_SetMarker (&_pmkJReadingStartPoint, MARKER_J_READING_STARTPOINT, _pmkJHenkanStartPoint) ;
			_SetMarker (&_pmkJReadingEndPoint, MARKER_J_READING_ENDPOINT, _pmkJHenkanEndPoint) ;
			/*	�ǂݕ������ݒ肷��B*/
			_nbufJReadingText	= _nbufJHenkanKey ;
			if (_nbufJHenkanKey2 > 0)
				_nbufJReadingText	-- ;
			if (_nbufJReadingText > 0)
				memcpy (_bufJReadingText, _bufJHenkanKey, _nbufJReadingText * sizeof (WCHAR)) ;
		}
		nPos	= *_pmkJHenkanStartPoint - 1 ;
		if (_fJHenkanActive) {
			if (0 <= nPos && nPos < _nbufComp && _bufComp [nPos] == L'��') 
				_DeleteCharEx (nPos, 1) ;
		} else {
			if (0 <= nPos && nPos < _nbufComp && _bufComp [nPos] == L'��') 
				_DeleteCharEx (nPos, 1) ;
		}
		if (_fJOkurigana) {
			nPos	= *_pmkJOkuriganaStartPoint ;
			if (0 <= nPos && nPos < _nbufComp && _bufComp [nPos] == L'*') 
				_DeleteCharEx (nPos, 1) ;
		}
		_fJAbbrev	= FALSE ;
	}
	if (_pHenkanSession != NULL) {
		delete	_pHenkanSession ;
		_pHenkanSession		= NULL ;
	}
	_fJHenkanActive			= FALSE ;
	_fJHenkanOn				= FALSE ;
	_nJHenkanCount			= 0 ;
	_fJOkurigana			= FALSE ;
	_wchOkuriChar			= 0 ;
	_nbufJHenkanKey			= 0 ;
	_nbufJHenkanKey2		= 0 ;
	_nbufJHenkanOkurigana	= 0 ;
	/* j-henkan-vector, j-henkan-count */
	_nbufJSearchKey			= 0 ;
	_nJOkuriIndexMin		= 0 ;
	_nJOkuriIndexMax		= 0 ;
	/* j-num-list */
	_nbufJNumList			= 0 ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JCompletion (
	register BOOL		fFirst)
{
	LPCWSTR				wstrCompWord ;
	int					nstrCompWord ;
	register LPCWSTR	wstrResult ;
	register LPWSTR		pDest ;
	register int		nDest, n ;

	if (fFirst) {
		if (_pHenkanSession != NULL) {
			delete	_pHenkanSession ;
			_pHenkanSession	= NULL ;
		}
		nstrCompWord	= _BufferSubstring (*_pmkJHenkanStartPoint, *_pmkPoint, &wstrCompWord) ;
		if (nstrCompWord <= 0) {
			_pDoc->SetMessage (L"Cannot complete an empty string!") ;
			return	TRUE ;
		}
		_pHenkanSession	= new CTCompletionSession (wstrCompWord, nstrCompWord) ;
		if (_pHenkanSession == NULL)
			return	FALSE ;
		wstrResult	= _pHenkanSession->GetCandidate () ;
	} else {
		if (_pHenkanSession == NULL)
			return	FALSE ;
		if (! _pHenkanSession->NextCandidate ()) {
			wstrResult	= NULL ;
		} else {
			wstrResult	= _pHenkanSession->GetCandidate () ;
		}
		wstrCompWord	= _pHenkanSession->GetKeyword (&nstrCompWord) ;
	}
	if (wstrResult == NULL) {
		WCHAR	bufMsg [MAXCOMPLEN] ;

		pDest	= bufMsg ;
		nDest	= NELEMENTS (bufMsg) ;
		n		= wnsprintfW (pDest, nDest - 1, L"No %s compleitions for \"", fFirst? L"" : L"more") ;
		pDest	+= n ;
		nDest	-= n ;
		n		= (nDest < nstrCompWord)? nDest : nstrCompWord ;
		memcpy (pDest, wstrCompWord, n * sizeof (WCHAR)) ;
		pDest	+= n ;
		nDest	-= n ;
		if (nDest > 0) {
			*pDest ++	= L'\"' ;
			nDest	-- ;
		}
		_pDoc->SetMessage (bufMsg, pDest - bufMsg) ;
	} else {
		_DeleteRegion (*_pmkJHenkanStartPoint, *_pmkPoint) ;
		_Insert (wstrResult, wcslen (wstrResult)) ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JPreviousCompletion ()
{
	register LPCWSTR	wstrResult ;

	if (_pHenkanSession == NULL)
		return	FALSE ;

	if (! _pHenkanSession->PreviousCandidate ()) {
		wstrResult	= NULL ;
	} else {
		wstrResult	= _pHenkanSession->GetCandidate () ;
	}
	if (wstrResult == NULL) {
		_pDoc->SetMessage (L"No more previous completions.") ;
	} else {
		ASSERT (_pmkJHenkanStartPoint != NULL) ;
		_DeleteRegion (*_pmkJHenkanStartPoint, *_pmkPoint) ;
		_Insert (wstrResult, wcslen (wstrResult)) ;
	}
	_pDoc->SetThisCommand (FUNCNO_J_COMPLETION) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JPurgeFromJisyo ()
{
	WCHAR			rszPurgeMessage [256] ;
	register LPWSTR	wptr ;
	register int	nptr, n ;

	if (_fJHenkanActive && _nbufJHenkanKey > 0) {
		register LPCWSTR	wstrHenkanKey ;
		register int		nstrHenkanKey ;
		register LPCWSTR	wstrResult ;
		register int		nstrResult ;

		if (_pHenkanSession == NULL)
			return	FALSE ;
		wstrResult	= _pHenkanSession->GetCandidate () ;
		if (wstrResult == NULL)
			return	FALSE ;

		if (_fJOkurigana) {
			wstrHenkanKey	= _bufJHenkanKey ;
			nstrHenkanKey	= _nbufJHenkanKey ;
		} else {
			wstrHenkanKey	= _bufJSearchKey ;
			nstrHenkanKey	= _nbufJSearchKey ;
		}
		wptr	= rszPurgeMessage ;
		nptr	= NELEMENTS (rszPurgeMessage) ;
		wcscpy (wptr, L"Really Purge \"") ;
		n		= wcslen (wptr) ;
		wptr	+= n ;
		nptr	-= n ;
		n		= (nptr < nstrHenkanKey)? nptr : nstrHenkanKey ;
		wcsncpy (wptr, wstrHenkanKey, n) ;
		wptr	+= n ;
		nptr	-= n ;
		if (nptr > 0) {
			*wptr ++ = L' ' ;
			nptr	-- ;
		}
		if (nptr > 0) {
			*wptr ++ = L'/' ;
			nptr	-- ;
		}
		nstrResult	= wcslen (wstrResult) ;
		n			= (nptr < nstrResult)? nptr : nstrResult ;
		if (nptr > 0) {
			wcsncpy (wptr, wstrResult, n) ;
			wptr	+= n ;
			nptr	-= n ;
		}
		if (nptr > 0) 
			wcsncpy (wptr, L"/\"?(yes or no)", nptr) ;
		rszPurgeMessage [NELEMENTS (rszPurgeMessage) - 1]	= L'\0' ;

		/*	minibuffer �𗘗p���� yes �� no ������͂�����B
		 *	���̌��ʂ̏����� CJPurgeSession ���S���B*/
		if (! _pDoc->ReadFromMinibuffer (rszPurgeMessage, wcslen (rszPurgeMessage), new CJPurgeSession (this)))
			return	FALSE ;
		/*	minibuffer �ł͉������͂̃f�t�H���g�������Ă����B*/
		return	_pDoc->GetCurrentBuffer ()->_JModeOff () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JHenkan ()
{
	register LPCWSTR	wstrResult	= NULL ;

	if (_nbufJHenkanKey == 0) {
		_JKakutei () ;
		return	TRUE ;
	}

	/*	save-excursion �ɂ���Ď���Ă���̈�B
	 *	==> point, mark, current buffer �������B
	 */
	if (! _fJHenkanActive) {
		_JChangeMarker () ;
		_fJHenkanActive	= TRUE ;

		if (_pHenkanSession != NULL) {
			delete	_pHenkanSession ;
			_pHenkanSession	= NULL ;
		}
		if (_pDoc->IsSkkKatakanaHiraganaHenkanp ()) {
			WCHAR	wszBuffer [MAXCOMPLEN] ;
			int		n ;

			if (_fJOkurigana) {
				n	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), _bufJHenkanKey, _nbufJHenkanKey) ;
				_pHenkanSession	= new CTOkuriHenkanSession (wszBuffer, n) ;
			} else {
				n	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), _bufJSearchKey, _nbufJSearchKey) ;
				_pHenkanSession	= new CTHenkanSession (wszBuffer, n) ;
			}
		} else {
			if (_fJOkurigana) {
				_pHenkanSession	= new CTOkuriHenkanSession (_bufJHenkanKey, _nbufJHenkanKey) ;
			} else {
				_pHenkanSession	= new CTHenkanSession (_bufJSearchKey, _nbufJSearchKey) ;
			}
		}
		if (_pHenkanSession == NULL)
			return	FALSE ;
		wstrResult		= _pHenkanSession->GetCandidate () ;
		_nJHenkanCount	= (wstrResult != NULL)? 1 : 0 ;
	} else {
		if (! _pHenkanSession->NextCandidate ()) {
			wstrResult	= NULL ;
		} else {
			wstrResult	= _pHenkanSession->GetCandidate () ;
			_nJHenkanCount	++ ;
		}
	}
	if (wstrResult != NULL) {
		if (_nJHenkanCount > COUNTHENKANSHOWCHANGE) {
			_ShowJHenkanCandidates () ;
			_pFilterFunc	= _stJHenkanShowCandidatesFilter ;
			return	TRUE ;
		}
	}
	if (wstrResult != NULL) {
		register CTMarker*	pMkKanaStartPoint	= NULL ;
		register CTMarker*	pMkOkuriStartPoint	= NULL ;
		register CTMarker*	pMkHenkanEndPoint	= NULL ;

		if (_pmkJKanaStartPoint != NULL) {
			pMkKanaStartPoint	= _MakeMarker (TRUE) ;
			*pMkKanaStartPoint	= *_pmkJKanaStartPoint ;
		}
		if (_pmkJOkuriganaStartPoint != NULL) {
			pMkOkuriStartPoint	= _MakeMarker (TRUE) ;
			*pMkOkuriStartPoint	= *_pmkJOkuriganaStartPoint ;
		}
		pMkHenkanEndPoint	= _MakeMarker (TRUE) ;
		_DeleteRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint) ;
		*pMkHenkanEndPoint	= *_pmkJHenkanStartPoint ;
		_JInsertWord (_pmkJHenkanStartPoint->GetPosition (), wstrResult, wcslen (wstrResult)) ;
		*_pmkJHenkanEndPoint		= *pMkHenkanEndPoint ;
		_DeleteMarker (pMkHenkanEndPoint) ;
		if (pMkOkuriStartPoint != NULL) {
			*_pmkJOkuriganaStartPoint	= *pMkOkuriStartPoint ;
			_DeleteMarker (pMkOkuriStartPoint) ;
		}
		if (pMkKanaStartPoint != NULL) {
			*_pmkJKanaStartPoint		= *pMkKanaStartPoint ;
			_DeleteMarker (pMkKanaStartPoint) ;
		}
	} else {
		/*	�ċA�ϊ����s���B*/
		_JHenkanInMinibuff () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JSetOkurigana ()
{
	register int	nOkuriPos, n, nHenkanStartPoint, nHenkanEndPoint ;

	ASSERT (_pmkJOkuriganaStartPoint != NULL) ;
	ASSERT (_pmkJHenkanStartPoint != NULL) ;

	_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkJOkuriganaStartPoint) ;
	nOkuriPos	= _pmkJOkuriganaStartPoint->GetPosition () ;
	if (0 <= nOkuriPos && nOkuriPos < _nbufComp && 
		_bufComp [nOkuriPos] != L'*') {
		_Insert (L"*", 1) ;
		nOkuriPos	= _pmkJOkuriganaStartPoint->GetPosition () ;
	}

	nHenkanStartPoint	= _pmkJHenkanStartPoint->GetPosition () ;
	nHenkanEndPoint		= _pmkJHenkanEndPoint->GetPosition () ;
	n					= nHenkanEndPoint - nHenkanStartPoint ;
	if (n >= 0) {
		_nbufJHenkanKey2	= JHenkanCopy (_bufJHenkanKey2, _bufComp + nHenkanStartPoint, n) ;
		_bufJHenkanKey2 [_nbufJHenkanKey2 ++]	= L'*' ;
		_nbufJHenkanKey		= JHenkanCopy (_bufJHenkanKey, _bufComp + nHenkanStartPoint, n) ;
		_bufJHenkanKey [_nbufJHenkanKey ++]	= _wchOkuriChar ;
	} else {
		_nbufJHenkanKey2	= 0 ;	/* �c�G���[���H */
	}
	n	= _pmkPoint->GetPosition () - nOkuriPos - 1 ;
	if (n >= 0) {
		memcpy (_bufJHenkanOkurigana, _bufComp + nOkuriPos + 1,  n * sizeof (WCHAR)) ;
		_nbufJHenkanOkurigana	= n ;

		n	= ((_nbufJHenkanKey2 + n) > MAXCOMPLEN)? (MAXCOMPLEN - _nbufJHenkanKey2) : n ;
		memcpy (_bufJHenkanKey2 + _nbufJHenkanKey2, _bufJHenkanOkurigana, n * sizeof (WCHAR)) ;
		_nbufJHenkanKey2	+= n ;
	} else {
		_nbufJHenkanOkurigana	= 0 ;
	}
	_nbufJPrefix	= 0 ;
	_wchOkuriChar	= L'\0' ;
	_DeleteRegion (*_pmkJOkuriganaStartPoint, *_pmkJOkuriganaStartPoint + 1) ;
	_JHenkan () ;
	_fJOkurigana	= FALSE ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JNextCandidate ()
{
	if (! _fJHenkanActive)
		return	FALSE ;
	if (_pHenkanSession == NULL)
		return	FALSE ;
	return	_JHenkan () ;
}

BOOL
CImeBuffer::_JPreviousCandidate ()
{
	if (_fJHenkanActive && _nbufJHenkanKey > 0) {
		if (_nJHenkanCount <= 1) {
			register CTMarker*	pMarker ;

			_fJHenkanActive			= FALSE ;
			_nJHenkanCount			= 0 ;
			_nJOkuriIndexMin		= 0 ;
			_nJOkuriIndexMax		= 0 ;
			_fJOkurigana			= FALSE ;
			_nbufJHenkanOkurigana	= 0 ;
			_nbufJHenkanKey2		= 0 ;
			if (_pHenkanSession != NULL) {
				delete	_pHenkanSession ;
				_pHenkanSession	= NULL ;
			}
			_DeleteRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint) ;
			pMarker		= _MakeMarker (TRUE) ;
			if (pMarker != NULL)
				*pMarker	= *_pmkPoint ;
			*_pmkPoint	= *_pmkJHenkanEndPoint ;
			if (! _fJAbbrev &&
				_nbufJHenkanKey > 0 &&
				L'a' <= _bufJHenkanKey [_nbufJHenkanKey - 1] &&
				_bufJHenkanKey [_nbufJHenkanKey - 1] <= L'z') {
				_nbufJHenkanKey	-- ;
			}
			_Insert (_bufJHenkanKey, _nbufJHenkanKey) ;
			_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
			_JChangeMarkerToWhite () ;
			if (pMarker != NULL) {
				*_pmkPoint	= *pMarker ;
				_DeleteMarker (pMarker) ;
			}
		} else {
			register LPCWSTR	wstrResult ;
			register int		nstrResult ;
			register int		nCount ;

			nCount	= (_nJHenkanCount < (NUMHENKANSHOWCANDIDATES + 1))? 1 : NUMHENKANSHOWCANDIDATES ;
			while (nCount -- > 0) {
				if (! _pHenkanSession->PreviousCandidate ())
					return	FALSE ;
				_nJHenkanCount	-- ;
			}
			if (_nJHenkanCount > COUNTHENKANSHOWCHANGE)
				return	TRUE ;
			wstrResult	= _pHenkanSession->GetCandidate () ;
			if (wstrResult == NULL)
				return	FALSE ;
			_DeleteRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint) ;
			nstrResult	= wcslen (wstrResult) ;
			if (nstrResult > 0) 
				_JInsertWord (_pmkJHenkanStartPoint->GetPosition (), wstrResult, nstrResult) ;
		}
	} else {
		_JKanaInput () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JToday ()
{
	WCHAR	rszBuffer [64] ;
	int		n, nDateAd, nNumberStyle ;

	nDateAd			= _pDoc->GetSkkDateAd () ;
	nNumberStyle	= _pDoc->GetSkkNumberStyle () ;
	n	= JDateString (rszBuffer, NELEMENTS (rszBuffer), nDateAd, nNumberStyle) ;
	return	_Insert (rszBuffer, n) ;
}

BOOL
CImeBuffer::_JInsert (
	register CTRomaKanaTable*	pTable)
{
	register const CTRomaKanaTableEntry*	pEntry ;
	register LPCWSTR	wstr ;

	pEntry	= pTable->Lookup (_bufJPrefix, _nbufJPrefix) ;
	if (pEntry == NULL) {
		/* [BEGIN] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
		if (_fJOkurigana &&
			_pmkJOkuriganaStartPoint != NULL &&
			_pmkJKanaStartPoint != NULL &&
			(_pmkJOkuriganaStartPoint->GetPosition () + 1) == _pmkJKanaStartPoint->GetPosition ()) {
			/*	Prefix + LastCommandChar �̕ϊ��Ɏ��s���Ă���̂ŁA
			 *	okuri-char �� prefix �̒��ł͂Ȃ� last-command-char ��
			 *	���ɂ���Ɛ�������B
			 */
			_wchOkuriChar	= _pDoc->GetLastCommandChar () ;
		}
		/* [END] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
		_nbufJPrefix	= 0 ;
		_pDoc->SetUnreadCommandChar (_pDoc->GetLastCommandChar ()) ;
		return	TRUE ;
		/* [BEGIN] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
	} else {
		if (_fJOkurigana &&
			_nbufJPrefix > 0 &&
			_pmkJOkuriganaStartPoint != NULL &&
			_pmkJKanaStartPoint != NULL &&
			(_pmkJOkuriganaStartPoint->GetPosition () + 1) == _pmkJKanaStartPoint->GetPosition ()) {
			/*	Prefix �̒��ɂ������Ɖ��肷��B�����A���̕���p���ǂ߂Ȃ��̂Łc
			 *	�e�X�g���K�v���B
			 */
			_wchOkuriChar	= _bufJPrefix [0] ;
		}
		/* [END] --- modified for "IwakU" -> "IwaKu" 2006/09/12 */
	}
	/* j-kakutei-early ���� j-henkan-active �Ȃ� j-kakutei */
	if (_pDoc->IsJKakuteiEarlyp () && _fJHenkanActive)
		_JKakutei () ;

	wstr	= _fJKatakana? pEntry->GetKatakana () : pEntry->GetHiragana () ;
	_JInsertStr (wstr, wcslen (wstr)) ;
	if (_fJOkurigana) {
		_JSetOkurigana () ;
	} else {
		_nbufJPrefix	= 0 ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertO ()
{
	_JInsert (_pDoc->GetRomaKana (L'o')) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JErasePrefix ()
{
	ASSERT (_pmkJKanaStartPoint != NULL) ;
	ASSERT (_pmkPoint != NULL) ;
	_DeleteRegion (*_pmkJKanaStartPoint, *_pmkPoint) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInsertPrefix (
	register LPCWSTR		wstr,
	register int			nwstr)
{
	return	_Insert (wstr, nwstr) ;
}

BOOL
CImeBuffer::_JInsertStr (
	register LPCWSTR		wstr,
	register int			nwstr)
{
	if (_fJisx0201) {
		WCHAR		wszBuf [16] ;
		int			n ;
		
		/*	JISX0201-KATAKANA �ɕϊ����� insert ����B
		 */
		while (nwstr > 0) {
			n	= JZenkana2Hankana (wszBuf, NELEMENTS (wszBuf), wstr, 1) ;
			if (! _Insert (wszBuf, n))
				return	FALSE ;
			wstr	++ ;
			nwstr	-- ;
		}
		return	TRUE ;
	}
	return	_Insert (wstr, nwstr) ;
}

BOOL
CImeBuffer::_JEmulateOriginalMap ()
{
	if (_pRecursiveEditSession != NULL) 
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("nShift(%d), nbufComp(%d)\n"), _GetShiftCount (), _nbufComp)) ;
	if (_nbufComp > _GetShiftCount ())
		return	FALSE ;

	return	_pDoc->UnprocessChar (_pDoc->GetLastCommandChar ()) ;
}

int
CImeBuffer::_JComputeNumericHenkanKey (
	register LPWSTR 		wszBuffer,
	register int			nszBuffer)
{
	register LPCWSTR	wptr ;
	register int		nwptr ;
	register LPWSTR		pDest, pNum ;
	register int		nDest, nNum ;

	if (! _pDoc->IsSkkUseNumericConversionp ()) {
		register int		n	= (nszBuffer < _nbufJHenkanKey)? nszBuffer : _nbufJHenkanKey ;

		memcpy (wszBuffer, _bufJHenkanKey, n * sizeof (WCHAR)) ;
		_nbufJNumList	= 0 ;
		return	n ;
	}

	wptr	= _bufJHenkanKey ;
	nwptr	= _nbufJHenkanKey ;
	pDest	= wszBuffer ;
	nDest	= nszBuffer ;
	pNum	= _bufJNumList ;
	nNum	= NELEMENTS (_bufJNumList) ;
	while (nwptr > 0) {
		while (nwptr > 0 &&
			   nDest > 0 &&
			   ! (L'0'  <= *wptr && *wptr <= L'9') &&
			   ! (L'�O' <= *wptr && *wptr <= L'�X')) {
			*pDest	++	= *wptr	++ ;
			nDest	-- ;
			nwptr	-- ;
		}
		if (nwptr > 0 &&
			((L'0'  <= *wptr && *wptr <= L'9') ||
			 (L'�O' <= *wptr && *wptr <= L'�X'))) {
			while (nwptr > 0 &&
				   ((L'0'  <= *wptr && *wptr <= L'9') ||
					(L'�O' <= *wptr && *wptr <= L'�X'))) {
				if (nNum > 0) {
					register WCHAR	wch = *wptr ;
					*pNum	++	= (L'0' <= wch && wch <= L'9')? wch : (wch - L'�O' + L'0') ;
					nNum	-- ;
				}
				wptr	++ ;
				nwptr	-- ;
			}
			if (nNum > 0) {
				*pNum	++	= L'\0' ;
				nNum	-- ;
			}
			if (nDest > 0) {
				*pDest	++	= L'#' ;
				nDest	-- ;
			}
		}
	}
	_nbufJNumList	= pNum - _bufJNumList ;
	return	(pDest - wszBuffer) ;
}

BOOL
CImeBuffer::_JInsertWord (
	register int		nPosition,
	register LPCWSTR	wstrWord,
	register int		nstrWord)
{
	WCHAR	wszBuffer [MAXPREFIXLEN] ;
	WCHAR	wszLispEval [MAXPREFIXLEN] ;
	LPCWSTR	pNote	= NULL ;
	int		nNote	= 0 ;

	/*	���l�ϊ��B*/
	if (_pDoc->IsSkkUseNumericConversionp () && _nbufJNumList > 0) {
		nstrWord	= _JNumericConvert (wszBuffer, NELEMENTS (wszBuffer), wstrWord, nstrWord) ;
		wstrWord	= wszBuffer ;
	}

	/*	���߂����݂��邩�ǂ������`�F�b�N����B*/
	if (_pDoc->IsSkkShowAnnotationp ()) {
		int	nIndex	= _HasWordAnnotationp (wstrWord, nstrWord) ;
		if (nIndex > 0) {
			/*	���߂̈ʒu�����͑}�����Ȃ��B*/
			if (! _pDoc->IsStatusActivep ()) {
				pNote		= wstrWord + nIndex + 1 ;
				nNote		= nstrWord - nIndex - 1 ;
			}
			nstrWord	= nIndex ;
		}
	}

	/*	lisp �ϊ� */
	if (nstrWord > 0 && wstrWord [0] == L'(' && wstrWord [nstrWord - 1] == L')') {
		register CTLispSession*	pSession	= new CTLispSession () ;

		if (pSession != NULL) {
			/*	j-num-list */
			if (_pDoc->IsSkkUseNumericConversionp ())
				pSession->SetJNumList (_bufJNumList, _nbufJNumList) ;
			/*	eval */
			if (pSession->Eval (wstrWord, nstrWord, wszLispEval, MAXPREFIXLEN - 1)) {
				wszLispEval [MAXPREFIXLEN - 1]	= L'\0' ;
				wstrWord	= wszLispEval ;
				nstrWord	= lstrlenW (wstrWord) ;
			}
			delete	pSession ;
		}
	}
	if (pNote != NULL && nNote > 0) 
		_pDoc->SetMessage (pNote, nNote) ;

	_InsertEx (nPosition, wstrWord, nstrWord) ;
	return	TRUE ;
}

int
CImeBuffer::_JNumericConvert (
	register LPWSTR		wstrDest,
	register int		nwstrDest,
	register LPCWSTR	wstrSource,
	register int		nwstrSource)
{
	CVarbuffer<CTHenkanSession*, 16>	vbufHenkanSession ;
	WCHAR				wszBuffer [MAXPREFIXLEN] ;
	LPCWSTR				pNum ;
	int					nNum, n, nwsrc, nwdest ;
	int					nHenkanSession, nOrgHenkanSession, nInsert ;
	CTHenkanSession**	ppHenkanSession ;
	CTHenkanSession**	ppOrgHenkanSession ;
	LPWSTR				pwdest ;
	LPCWSTR				pwsrc ;
	BOOL				fFirst	= TRUE ;
	int					nRetval	= 0 ;
	CTSearchSessionCandidate*	pSharp4Point	= NULL ;

	pNum	= _bufJNumList ;
	nNum	= _nbufJNumList ;
	pwsrc	= wstrSource ;
	nwsrc	= nwstrSource ;
	while (nwsrc > 0) {
		if (*pwsrc == L'#') {
			CTHenkanSession*	pHenkanSession ;

			pwsrc	++ ;
			nwsrc	-- ;
			if (nwsrc > 0 && *pwsrc == L'4') {
				pHenkanSession	= new CTHenkanSession (pNum, nNum) ;
				if (! vbufHenkanSession.Add (&pHenkanSession, 1)) {
					/*	�G���[�����B*/
					if (pHenkanSession != NULL) 
						delete	pHenkanSession ;
					goto	error ;
				}
			}
			pwsrc	++ ;
			nwsrc	-- ;
			while (nNum > 0 && *pNum != L'\0') {
				pNum	++ ;
				nNum	-- ;
			}
			if (nNum > 0 && *pNum == L'\0') {
				pNum	++ ;
				nNum	-- ;
			}
		}
		pwsrc	++ ;
		nwsrc	-- ;
	}

	ppOrgHenkanSession	= vbufHenkanSession.GetBuffer () ;
	nOrgHenkanSession	= vbufHenkanSession.GetUsage  () ;
	pSharp4Point		= _pHenkanSession->GetCurrentPoint () ;
	nInsert				= 0 ;
	DEBUGPRINTF ((TEXT ("nOrgHenkanSession (%d)\n"), nOrgHenkanSession)) ;
#if defined (DEBUG) || defined (DBG)
	n	= NELEMENTS (wszBuffer) - 1 ;
	n	= (n < nwstrSource)? n : nwstrSource ;
	lstrncpyW (wszBuffer, wstrSource, n) ;
	wszBuffer [n]	= L'\0' ;
	DEBUGPRINTF ((TEXT ("source -> \"%s\"(%d)\n"), wszBuffer, nwstrSource)) ;
#endif
	for ( ; ; ) {
		ppHenkanSession	= ppOrgHenkanSession ;
		nHenkanSession	= nOrgHenkanSession ;

		pwsrc	= wstrSource ;
		nwsrc	= nwstrSource ;
		pwdest	= wszBuffer ;
		nwdest	= NELEMENTS (wszBuffer) - 1 ;
		pNum	= _bufJNumList ;
		nNum	= _nbufJNumList ;

		while (nwsrc > 0 && nwdest > 0) {
			if (*pwsrc == L'#') {
				pwsrc	++ ;
				nwsrc	-- ;
				if (nwsrc <= 0)
					break ;
				if (*pwsrc == L'4') {
					LPCWSTR	wstrResult ;

					n	= 0 ;
					if (nHenkanSession > 0) {
						if (*ppHenkanSession != NULL) {
							wstrResult	= (*ppHenkanSession)->GetCandidate () ;
						} else {
							wstrResult	= NULL ;
						}
						ppHenkanSession	++ ;
						nHenkanSession	-- ;
						n	= (wstrResult != NULL)? lstrlenW (wstrResult) : 0 ;
						n	= (n > nwdest)? nwdest : n ;
						if (n > 0) {
							/*	# �𖳌���(���ɕϊ�)���ăR�s�[����B
							 *	# �̍ċA�I�ȓW�J�������ƁA�܂��ԈႢ�Ȃ����������s������
							 *	���낤�B���̑΍�B
							 */
							JNoNumCopy (pwdest, wstrResult, n) ;
						}
						DEBUGPRINTF ((TEXT ("(JNumConv) #4 -> %d\n"), n)) ;
					}
					JNumSkip (&pNum, &nNum) ;
				} else {
					n	= JNumExp (pwdest, nwdest, *pwsrc, &pNum, &nNum) ;
				}
				pwsrc	++ ;
				nwsrc	-- ;
				pwdest	+= n ;
				nwdest	-= n ;
			} else {
				*pwdest	++	= *pwsrc ++ ;
				nwdest	-- ;
				nwsrc	-- ;
			}
		}

		n	= pwdest - wszBuffer ;
		wszBuffer [n]	= L'\0' ;
#if defined (DEBUG) || defined (DBG)
		DEBUGPRINTF ((TEXT ("(JNumConv) Result = \"%s\"\n"), wszBuffer)) ;
#endif
		/*	�����1���A�o���オ��B*/
		if (fFirst) {
			nRetval	= (n < nwstrDest)? n : nwstrDest ;
			lstrncpyW (wstrDest, wszBuffer, nRetval) ;
			fFirst	= FALSE ;
		}

		/*	���̌���ǉ����Ȃ��Ƃ����Ȃ��B*/
		if (nOrgHenkanSession > 0) {
			/*	n+1 �� nul �������܂߂邽�߁A�ł���B*/
			if (_pHenkanSession->InsertCandidate (wszBuffer, n + 1)) {
				DEBUGPRINTF ((TEXT ("Insert \"%s\"(%d) succeeded\n"), wszBuffer, n)) ;
				nInsert	++ ;
				if (! _pHenkanSession->NextCandidate ()) {
					DEBUGPRINTF ((TEXT ("Something wrong in JNumericConversion \n"))) ;
				} else {
					_pHenkanSession->LinkCandidate (pSharp4Point) ;
				}
#if defined (DEBUG) || defined (DBG)
			} else {
				DEBUGPRINTF ((TEXT ("Insert \"%s\"(%d) failed\n"), wszBuffer, n)) ;
#endif
			}
		}

		/*	������1���̌��ɑ����Ă݂Ă���B*/
		ppHenkanSession	= ppOrgHenkanSession ;
		nHenkanSession	= nOrgHenkanSession ;
		while (nHenkanSession > 0) {
			if ((*ppHenkanSession)->NextCandidate ())
				break ;
			(*ppHenkanSession)->Rewind () ;
			ppHenkanSession ++ ;
			nHenkanSession	-- ;
		}
		if (nHenkanSession <= 0)
			break ;
	}
	DEBUGPRINTF ((TEXT ("Total Insert (%d)\n"), nInsert)) ;
	if (nInsert > 0) {
		while (nInsert > 0) {
			_pHenkanSession->PreviousCandidate () ;
			nInsert	-- ;
		}
		_pHenkanSession->RemoveCandidate () ;
	}
	
  error:
	/*	��������B*/
	nHenkanSession	= vbufHenkanSession.GetUsage  () ;
	ppHenkanSession	= vbufHenkanSession.GetBuffer () ;
	while (nHenkanSession -- > 0) {
		if (*ppHenkanSession != NULL) {
			delete	*ppHenkanSession ;
			*ppHenkanSession	= NULL ;
		}
		ppHenkanSession	++ ;
	}
	return	nRetval ;
}

BOOL
CImeBuffer::_JChangeMarker ()
{
	register int	nPos ;

	if (_pmkJHenkanStartPoint == NULL)
		return	FALSE ;
	nPos	= _pmkJHenkanStartPoint->GetPosition () - 1 ;
	if (nPos < 0 || nPos >= _nbufComp)
		return	FALSE ;
	if (_bufComp [nPos] == L'��') {
		_bufComp [nPos]	= L'��' ;
	} else {
		_JKakutei () ;
		/*	It seems that you have deleted ��. */
		_pDoc->SetMessage (L"It seems that you have deleted ��.") ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JChangeMarkerToWhite ()
{
	register int	nPos ;

	if (_pmkJHenkanStartPoint == NULL)
		return	FALSE ;
	nPos	= _pmkJHenkanStartPoint->GetPosition () - 1 ;
	if (nPos < 0 || nPos >= _nbufComp)
		return	FALSE ;
	if (_bufComp [nPos] == L'��') {
		_bufComp [nPos]	= L'��' ;
	} else {
		*_pmkPoint	= *_pmkJHenkanStartPoint ;
		_Insert (L"��", 1) ;
		*_pmkJHenkanStartPoint	= *_pmkPoint ;
		/*	It seems that you have deleted ��. */
		_pDoc->SetMessage (L"It seems that you have deleted ��.") ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JHenkanInMinibuff ()
{
	WCHAR				rszBuffer [MAXCOMPLEN] ;
	register LPCWSTR	pSrc ;
	register int		nSrc ;

	/*	j-num-list �́A�܂��Ȃ��B(not implemented yet) */
	if (_nbufJNumList > 0) {
		pSrc	= _bufJSearchKey ;
		nSrc	= (_nbufJSearchKey < MAXCOMPLEN)? _nbufJSearchKey : MAXCOMPLEN ;
	} else {
		if (_nbufJHenkanKey2 > 0) {
			pSrc	= _bufJHenkanKey2 ;
			nSrc	= (_nbufJHenkanKey2 < MAXCOMPLEN)? _nbufJHenkanKey2 : MAXCOMPLEN ;
		} else {
			pSrc	= _bufJHenkanKey ;
			nSrc	= (_nbufJHenkanKey < MAXCOMPLEN)? _nbufJHenkanKey : MAXCOMPLEN ;
		}
	}
	memcpy (rszBuffer, pSrc, sizeof (WCHAR) * nSrc) ;
	if (nSrc < MAXCOMPLEN)
		rszBuffer [nSrc ++]	= L' ' ;
	return	_pDoc->ReadFromMinibuffer (rszBuffer, nSrc, new CJHenkanInMinibuffSession (this)) ;
}

BOOL
CImeBuffer::_ShowJHenkanCandidates ()
{
	IMECANDIDATES*	pMyCand ;
	BOOL			fNeedReconstruct ;
	int				nCount ;

	/*	Candidate-List ��D�悵���̂ŁA���̑���͕s�v�ł͂Ȃ����Ǝv���B
	ImeDoc_ClearMessage (pBuffer->_pDoc) ;
	*/
	pMyCand	= _pDoc->GetCandidateInfoBuffer () ;
	if (pMyCand == NULL)
		return	FALSE ;

	if (pMyCand->_iStyle != IMECANDSTYLE_READ) {
		nCount				= _nJHenkanCount - 1 ;
		fNeedReconstruct	= TRUE ;
		goto	exit_func ;
	}
	if (pMyCand->_iCount == 0 || pMyCand->_iCount < _nJHenkanCount) {
		nCount				= _nJHenkanCount - 1 ;
		fNeedReconstruct	= TRUE ;
		goto	exit_func ;
	}
	fNeedReconstruct	= FALSE ;
#if 0
	if (pMyCand->_iCount <= pMyCand->_iPageStart) {
		nCandidate	= _pHenkanSession->GetNumberOfCandidate (&fContinue) ;
		if (pMyCand->_iCount < nCandidate) {
			/*	CandidateList ���č\������K�v������B*/
			fNeedReconstruct	= TRUE ;
			nCount				= pMyCand->_iPageStart ;
		} else {
			/*	�ԈႢ�Ȃ��G���[�B*/
		}
	} else {
		/*	���̏ꍇ�ɂ͓��ɉ���������K�v�͂Ȃ��B*/
	}
#endif
  exit_func:
	if (fNeedReconstruct) 
		return	_CreateJHenkanCandidateList (nCount) ;
	return	TRUE ;
}

/*========================================================================
 */
int
CImeBuffer::_CharAfter (
	register int			nPosition)
{
	if (nPosition < 0 || nPosition >= _nbufComp)
		return	-1 ;
	return	_bufComp [nPosition] ;
}

BOOL
CImeBuffer::_SetMarker (
	register CTMarker**			ppMarker,
	register int				nMarkerIndex,
	register const CTMarker*	pSource)
{
	ASSERT (ppMarker != NULL) ;
	ASSERT (0 <= nMarkerIndex && nMarkerIndex < MAXBUFMARKER) ;

	if (*ppMarker == NULL) 
		*ppMarker	= &_rMarker [nMarkerIndex] ;
	**ppMarker	= *pSource ;
	return	TRUE ;
}

BOOL
CImeBuffer::_DeleteRegion (
	register int			nStartPoint,
	register int			nEndPoint)
{
	register int	nMove, i ;

	if (nStartPoint > nEndPoint) {
		register int	nTmp ;
		nTmp		= nStartPoint ;
		nStartPoint	= nEndPoint ;
		nEndPoint	= nTmp ;
	}
	nStartPoint	= (nStartPoint < 0)? 0 : nStartPoint ;
	nEndPoint	= (nEndPoint   < 0)? 0 : nEndPoint ;
	nStartPoint	= (nStartPoint > _nbufComp)? _nbufComp : nStartPoint ;
	nEndPoint	= (nEndPoint   > _nbufComp)? _nbufComp : nEndPoint ;

	nMove	= nEndPoint - nStartPoint ;
	if (nMove == 0)
		return	TRUE ;

	/*	�s���ȗ̈�̍폜�͎̂Ă�B
	 */
	if (nStartPoint < 0 || nEndPoint > MAXCOMPLEN)
		return	FALSE ;

	if (_nbufComp > nEndPoint) 
		memmove (_bufComp + nStartPoint, _bufComp + nEndPoint, sizeof (WCHAR) * (_nbufComp - nEndPoint)) ;
	_nbufComp	-= (nEndPoint - nStartPoint) ;

	/*	�����Ń}�[�J�̈ړ�������B
	 */
	for (i = 0 ; i < _nMarker ; i ++) {
		if (nStartPoint < _rMarker [i]) {
			if (_rMarker [i] < nEndPoint) {
				_rMarker [i].Backward (_rMarker [i] - nStartPoint) ;
			} else {
				_rMarker [i].Backward (nMove) ;
			}
		}
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_Insert (
	register LPCWSTR		wstr,
	register int			nwstr)
{
	ASSERT (_pmkPoint != NULL) ;
	_InsertEx (_pmkPoint->GetPosition (), wstr, nwstr) ;
	return	TRUE ;
}

int
CImeBuffer::_InsertEx (
	register int			nPosition,
	register LPCWSTR		wstr,
	register int			nwstr)
{
	register int	i ;

	if (nPosition < 0 || nPosition >= MAXCOMPLEN || nwstr <= 0)
		return	0 ;
	if ((_nbufComp + nwstr) > MAXCOMPLEN)
		nwstr	= MAXCOMPLEN - _nbufComp ;
	if ((nPosition + nwstr) > MAXCOMPLEN) 
		nwstr	= MAXCOMPLEN - nPosition ;
	if (nwstr <= 0)
		return	0 ;
	if ((nPosition + nwstr) < MAXCOMPLEN && nPosition < _nbufComp) 
		memmove (_bufComp + nPosition + nwstr, _bufComp + nPosition, sizeof (WCHAR) * (_nbufComp - nPosition)) ;
	memmove (_bufComp + nPosition, wstr, sizeof (WCHAR) * nwstr) ;

	/*	�}�[�J�̈ړ��B
	 */
	_nbufComp	+= nwstr ;
	for (i = 0 ; i < _nMarker ; i ++) {
		if ((nPosition < _rMarker [i] ||
			 (nPosition == _rMarker [i] && _rMarker [i].IsCursor ())) &&
			_rMarker [i] < _nbufComp)
			_rMarker [i].Forward (nwstr) ;
	}
	return	nwstr ;
}

BOOL
CImeBuffer::_DeleteChar (
	register int		nDelete)
{
	return	_DeleteRegion (*_pmkPoint, *_pmkPoint + nDelete) ;
}

BOOL
CImeBuffer::_DeleteCharEx (
	register int		nPosition,
	register int		nDelete)
{
	return	_DeleteRegion (nPosition, nPosition + nDelete) ;
}

int
CImeBuffer::_BufferSubstring (
	register int		nStartPoint,
	register int		nEndPoint,
	register LPCWSTR*	ppDest)
{
	register int	nRealStart	= (nStartPoint < nEndPoint)? nStartPoint : nEndPoint ;
	register int	nRealEnd	= (nStartPoint < nEndPoint)? nEndPoint   : nStartPoint ;

	*ppDest	= _bufComp + nRealStart ;
	return	nRealEnd - nRealStart ;
}

CTMarker*
CImeBuffer::_MakeMarker (
	register bool			fCursor)
{
	register CTMarker*	pMarker ;
	register int		nMarker ;

	/*	�\�񂳂�Ă���}�[�J�̎����猟�����J�n����B
	 */
	pMarker	= _rMarker + MAX_RESERVED_MARKERS ;
	nMarker	= _nMarker - MAX_RESERVED_MARKERS ;
	while (nMarker -- > 0) {
		if (! pMarker->IsValidp ()) 
			break ;
		pMarker	++ ;
	}

	/*	���݂̃}�[�J�̒��ɋ�(���ԂƂ������H)���Ȃ�
	 *	�̂ŐV�����m�ہB
	 */
	if (nMarker <= 0) {
		if (_nMarker >= MAXBUFMARKER) 
			return	FALSE ;
		pMarker	= _rMarker + _nMarker ;
		_nMarker	++ ;
	}
	pMarker->Initialize (fCursor) ;
	return	pMarker ;
}

BOOL
CImeBuffer::_DeleteMarker (
	register CTMarker*		pMarker)
{
	register CTMarker*		pmkLast ;

	ASSERT (pMarker != NULL) ;
	ASSERT (_rMarker <= pMarker && pMarker < (_rMarker + MAXBUFMARKER)) ;

	pmkLast	= _rMarker + _nMarker ;
	if (pmkLast == pMarker) 
		_nMarker	-- ;
	pMarker->Invalidate () ;
	return	TRUE ;
}

BOOL
CImeBuffer::_QueryProcessFunction (
	register int			nFuncNo) const
{
	static const BOOL		srfProcessTbl [NUM_FUNCTIONS]	= {
		TRUE,	//  FUNCNO_SELF_INSERT_CHARACTER,
		TRUE,	//  FUNCNO_J_SELF_INSERT,
		TRUE,	//  FUNCNO_J_ZENKAKU_INSERT, 
		TRUE,	//  FUNCNO_J_DISPLAY_CODE_FOR_CHAR_AT_POINT,
		TRUE,	//	FUNCNO_J_SET_HENKAN_POINT,
		TRUE,	//	FUNCNO_J_SET_HENKAN_POINT_SUBR,
		TRUE,	//	FUNCNO_J_INSERT_A,
		TRUE,	//	FUNCNO_J_INSERT_E,
		TRUE,	//	FUNCNO_J_INSERT_I,
		TRUE,	//	FUNCNO_J_INSERT_O,
		TRUE,	//	FUNCNO_J_INSERT_U,
		TRUE,	//	FUNCNO_J_KANA_INPUT,
		TRUE,	//	FUNCNO_J_START_HENKAN,
		TRUE,	//	FUNCNO_J_INSERT_COMMA,
		TRUE,	//	FUNCNO_J_INSERT_PERIOD,
		TRUE,	//	FUNCNO_J_PURGE_FROM_JISYO,
		TRUE,	//	FUNCNO_J_INPUT_BY_CODE_OR_MENU,
		TRUE,	//	FUNCNO_J_MODE_OFF,
		TRUE,	//	FUNCNO_J_TOGGLE_KANA,
		TRUE,	//	FUNCNO_J_PREVIOUS_CANDIDATE,
		TRUE,	//	FUNCNO_J_KAKUTEI,
		TRUE,	//	FUNCNO_J_ABBREV_INPUT,
		TRUE,	//	FUNCNO_J_ABBREV_PERIOD,
		TRUE,	//	FUNCNO_J_ABBREV_COMMA,
		TRUE,	//	FUNCNO_J_ZENKAKU_EIJI,
		TRUE,	//	FUNCNO_J_ZENKAKU_HENKAN,
		TRUE,	//	FUNCNO_J_TODAY,
		TRUE,	//	FUNCNO_J_MODE_OFF_AND_SELF_INSERT,
		TRUE,	//	FUNCNO_J_KANAINPUT_MODE_ON,
		TRUE,	//	FUNCNO_J_NEWLINE,
		FALSE,	//	FUNCNO_J_SET_MARK_COMMAND,
		FALSE,	//	FUNCNO_J_FORWARD_CHAR,
		FALSE,	//	FUNCNO_J_BACKWARD_CHAR,
		FALSE,	//	FUNCNO_J_DELETE_CHAR,
		FALSE,	//	FUNCNO_J_DELETE_BACKWARD_CHAR,
		FALSE,	//	FUNCNO_J_TRY_COMPLETION,
		FALSE,	//	FUNCNO_J_END_OF_LINE,
		FALSE,	//	FUNCNO_J_BEGINNING_OF_LINE,
		FALSE,	//	FUNCNO_J_KILL_LINE,
		FALSE,	//	FUNCNO_J_YANK,
		FALSE,	//	FUNCNO_J_KILL_REGION,
		FALSE,	//	FUNCNO_J_KILL_RING_SAVE,
		FALSE,	//	FUNCNO_J_EXCHANGE_POINT_AND_MARK,
		FALSE,	//	FUNCNO_J_PREVIOUS_LINE,
		FALSE,	//	FUNCNO_J_NEXT_LINE,
		FALSE,	//	FUNCNO_J_TRANSPOSE_CHARS,
		FALSE,	//	FUNCNO_J_REDRAW,
		FALSE,	//	FUNCNO_J_PREFIX_CHAR,
		FALSE,	//	FUNCNO_J_DELETE_REGION,
		FALSE,	//	FUNCNO_J_SENDBACK_KEY,
		FALSE,	//	FUNCNO_J_KEYBOARD_QUIT,
		TRUE,	//	FUNCNO_J_TOGGLE_JISX0201,
		TRUE,	//	FUNCNO_NOT_MODIFIED,
		FALSE,	//	FUNCNO_J_FORWARD_WORD,
		FALSE,	//	FUNCNO_J_BACKWARD_WORD,
		FALSE,	//	FUNCNO_J_UPCASE_WORD,
		FALSE,	//	FUNCNO_J_DOWNCASE_WORD,
		FALSE,	//	FUNCNO_J_CAPITALIZE_WORD,
		TRUE,	//	FUNCNO_VC_TOGGLE_EGGNL,
		FALSE,	//	FUNCNO_J_LEFT_ARROW,
		FALSE,	//	FUNCNO_J_UP_ARROW,
		FALSE,	//	FUNCNO_J_RIGHT_ARROW,
		FALSE,	//	FUNCNO_J_DOWN_ARROW,
		FALSE,	//	FUNCNO_INVALID_CHAR,
		TRUE,	//	FUNCNO_SAVEUSERJISYO, 
		/*	SELECTABLE_FUNCTION �܂ł̕��т� SKKIME ���Ƌ��ʂłȂ���΂Ȃ�Ȃ��B
		 *	����� keymap �̐ݒ�� REGISTRY �o�R�ŋ��L���Ă��邽�߂ł���B
		 */
		TRUE,	//	FUNCNO_NEWLINE,
		TRUE,	//	FUNCNO_J_COMPLETION,
		TRUE,	//	FUNCNO_MOUSE_DRAG_REGION,
		TRUE,	//	FUNCNO_MOUSE_DRAG_REGION_END,
		TRUE,	//	FUNCNO_OPENCANDIDATE,
		TRUE,	//	FUNCNO_REVERTTEXT,
		TRUE,	//	FUNCNO_COMPELETETEXT,
		TRUE,	//	FUNCNO_ABORT_MINIBUFFER,
		TRUE,	//	FUNCNO_EXIT_MINIBUFFER,
		/*	SELECTABLE �łȂ��֐��͕K����������邱�Ƃ�ړI�ɃC�x���g�Ƃ��ē���
		 *	���Ă���̂ŁAFALSE �ɂ͂Ȃ�Ȃ��H
		 */
	} ;
	if (nFuncNo < 0 || nFuncNo >= NELEMENTS (srfProcessTbl))
		return	FALSE ;

	return	srfProcessTbl [nFuncNo] ;
}

/*========================================================================*
 */
BOOL
CImeBuffer::_JKatakanaHenkan ()
{
	register int	i, nStart, nEnd ;

	if (! _fJHenkanOn) 
		return	_JEmulateOriginalMap () ;
	if (_fJHenkanActive || _fJKatakana)
		return	TRUE ;
	_fJMode		= TRUE ;
	if (_nbufJPrefix > 0)
		return	FALSE ;
	nStart	= _pmkJHenkanStartPoint->GetPosition () ;
	nEnd	= _pmkPoint->GetPosition () ;
	if (nEnd < nStart) 
		return	_pDoc->SetMessage (L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (_bufComp [i] == L'\n') 
			return	_pDoc->SetMessage (L"Henkan key may not contain a new line character.") ;
	}
	_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
	_JKatakanaRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint, TRUE) ;
	_JKakutei () ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JKatakanaRegion (
	register int			nStartPoint,
	register int			nEndPoint,
	register BOOL			fVContract)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > _nbufComp)
		return	FALSE ;

	n	= JHiragana2Katakana (wszBuffer, NELEMENTS (wszBuffer), _bufComp + nStartPoint, nEndPoint - nStartPoint, fVContract) ;
	_DeleteRegion (nStartPoint, nEndPoint) ;
	_InsertEx (nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JHiraganaHenkan ()
{
	register int	i, nStart, nEnd ;

	if (! _fJHenkanOn) 
		return	_JEmulateOriginalMap () ;
	if (_fJHenkanActive || ! _fJKatakana)
		return	TRUE ;
	_fJMode		= TRUE ;
	if (_nbufJPrefix > 0)
		return	FALSE ;
	nStart	= _pmkJHenkanStartPoint->GetPosition () ;
	nEnd	= _pmkPoint->GetPosition () ;
	if (nEnd < nStart) 
		return	_pDoc->SetMessage (L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (_bufComp [i] == L'\n') 
			return	_pDoc->SetMessage (L"Henkan key may not contain a new line character.") ;
	}
	_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
	_JHiraganaRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint) ;
	_JKakutei () ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JHiraganaRegion (
	register int			nStartPoint,
	register int			nEndPoint)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > _nbufComp)
		return	FALSE ;

	n	= JKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), _bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	_DeleteRegion (nStartPoint, nEndPoint) ;
	_InsertEx (nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JHankanaHenkan ()
{
	register int	i, nStart, nEnd ;

	if (! _fJHenkanOn) 
		return	_JEmulateOriginalMap () ;

	if (_fJHenkanActive || _fJisx0201)
		return	TRUE ;

	_fJMode		= TRUE ;
	if (_nbufJPrefix > 0)
		return	FALSE ;

	nStart	= _pmkJHenkanStartPoint->GetPosition () ;
	nEnd	= _pmkPoint->GetPosition () ;
	if (nEnd < nStart) 
		return	_pDoc->SetMessage (L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (_bufComp [i] == L'\n') 
			return	_pDoc->SetMessage (L"Henkan key may not contain a new line character.") ;
	}
	_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
	_JHankanaRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint) ;
	_JKakutei () ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JHankanaRegion (
	register int	nStartPoint,
	register int	nEndPoint)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > _nbufComp)
		return	FALSE ;

	n	= JZenkana2Hankana (wszBuffer, NELEMENTS (wszBuffer), _bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	_DeleteRegion (nStartPoint, nEndPoint) ;
	_InsertEx (nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JZenkanaHenkan ()
{
	register int	i, nStart, nEnd ;

	if (! _fJHenkanOn) 
		return	_JEmulateOriginalMap () ;

	if (_fJHenkanActive || ! _fJisx0201)
		return	TRUE ;

	_fJMode		= TRUE ;
	if (_nbufJPrefix > 0)
		return	FALSE ;

	nStart	= _pmkJHenkanStartPoint->GetPosition () ;
	nEnd	= _pmkPoint->GetPosition () ;
	if (nEnd < nStart) 
		return	_pDoc->SetMessage (L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (_bufComp [i] == L'\n') 
			return	_pDoc->SetMessage (L"Henkan key may not contain a new line character.") ;
	}
	_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
	_JZenkanaRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint, _fJKatakana) ;
	_JKakutei () ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JZenkanaRegion (
	register int	nStartPoint,
	register int	nEndPoint,
	register BOOL	fKatakana)
{
	WCHAR			wszBuffer [MAXCOMPLEN] ;
	register int	n ;

	if (nStartPoint >= nEndPoint || nEndPoint > _nbufComp)
		return	FALSE ;

	if (fKatakana) {
		n	= JHankana2Katakana (wszBuffer, NELEMENTS (wszBuffer), _bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	} else {
		n	= JHankana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), _bufComp + nStartPoint, nEndPoint - nStartPoint) ;
	}
	_DeleteRegion (nStartPoint, nEndPoint) ;
	_InsertEx (nStartPoint, wszBuffer, n) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JZenkakuHenkan ()
{
	register int	i, nStart, nEnd ;

	if (! _fJHenkanOn) 
		return	_JEmulateOriginalMap () ;

	if (_fJHenkanActive)
		return	TRUE ;

	_fJMode		= TRUE ;
	if (_nbufJPrefix > 0)
		return	FALSE ;

	nStart	= _pmkJHenkanStartPoint->GetPosition () ;
	nEnd	= _pmkPoint->GetPosition () ;
	if (nEnd < nStart) 
		return	_pDoc->SetMessage (L"Henkan end point must be after henkan start point.") ;
	for (i = nStart ; i < nEnd ; i ++) {
		if (_bufComp [i] == L'\n') 
			return	_pDoc->SetMessage (L"Henkan key may not contain a new line character.") ;
	}
	_SetMarker (&_pmkJHenkanEndPoint, MARKER_J_HENKAN_ENDPOINT, _pmkPoint) ;
	_JZenkakuRegion (*_pmkJHenkanStartPoint, *_pmkJHenkanEndPoint) ;
	_JKakutei () ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JZenkakuRegion (
	register int	nStartPoint,
	register int	nEndPoint)
{
	WCHAR		wszBuffer [MAXCOMPLEN] ;
	register WCHAR*		pwsrc ;
	register WCHAR*		pwdest ;
	register int		nwdest, nwsrc, n ;
	LPCWSTR		wstrWord ;
	int			nstrWord ;

	if (nStartPoint < 0 || nEndPoint < nStartPoint || nEndPoint > _nbufComp)
		return	FALSE ;

	pwsrc	= _bufComp + nStartPoint ;
	nwsrc	= nEndPoint - nStartPoint ;
	pwdest	= wszBuffer ;
	nwdest	= NELEMENTS (wszBuffer) ;

	while (nwsrc > 0 && nwdest > 0) {
		if (0x20 <= *pwsrc && *pwsrc <= 0x7E) {
			wstrWord	= _pDoc->GetSkkZenkakuVector (*pwsrc, &nstrWord) ;
			if (nstrWord > 0) {
				n	= (nstrWord < nwdest)? nstrWord : nwdest ;
				memcpy (pwdest, wstrWord, nstrWord * sizeof (WCHAR)) ;
				pwdest	+= n ;
				nwdest	-= n ;
			} else {
				*pwdest	++ = *pwsrc + (L'�`' - L'A') ;
				nwdest -- ;
			}
		}
		pwsrc	++ ;
		nwsrc	-- ;
	}
	_DeleteRegion (nStartPoint, nEndPoint) ;
	_InsertEx (nStartPoint, wszBuffer, pwdest - wszBuffer) ;
	return	TRUE ;
}

/*========================================================================
 */
BOOL
CImeBuffer::_CreateJHenkanCandidateList (
	int					iPageStart)
{
	IMECANDIDATES*		pMyCand ;
	LPWSTR				pwCandidateStr, pwDest ;
	LPCWSTR				wstrResult ;
	int					nCandidate, nNeedLength, nHCount, i, nstrResult, nRealCand ;
	BOOL				fContinue ;
	WCHAR				wszBuffer  [MAXCOMPLEN] ;
	UINT*				piDestPageStart ;
	UINT*				piDestIndex ;
	UINT				nPages ;

	if (_pmkJHenkanStartPoint != NULL && _pmkJHenkanEndPoint != NULL)
		_DeleteRegion (_pmkJHenkanStartPoint->GetPosition (), _pmkJHenkanEndPoint->GetPosition ()) ;

	/*	�S�Ă̎������������āA����S����x�Ɉ����o����悤�ɂ��Ă����B*/
	nNeedLength	= 0 ;
	for (nHCount = 0 ; nHCount < NUMHENKANSHOWCANDIDATES ; nHCount ++) {
		if (! _pHenkanSession->NextCandidate ()) 
			break ;
	}
	while (nHCount -- > 0)
		_pHenkanSession->PreviousCandidate () ;

	nCandidate	= _pHenkanSession->GetNumberOfCandidate (&fContinue) ;
	nRealCand	= 0 ;
	_pHenkanSession->Rewind () ;

	/*	#4 expand �����݂��邽�߁A���ۂ̌��̐��͎����̕Ԃ������̐��Ƃ͈�v���Ȃ��B
	 */
	for ( ; ; ) {
		wstrResult	= _pHenkanSession->GetCandidate () ;
		if (wstrResult != NULL) {
			nstrResult	= lstrlenW (wstrResult) ;
			if (_pDoc->IsSkkUseNumericConversionp () && _nbufJNumList > 0) 
				nstrResult	= _JNumericConvert (wszBuffer, NELEMENTS (wszBuffer), wstrResult, nstrResult) ;
			nNeedLength	+= nstrResult + 1 ;
			nRealCand	++ ;
		}
		if (! _pHenkanSession->NextCandidate ())
			break ;
	}
	/*	#4 expand ���l������
	 */
	nCandidate	= _pHenkanSession->GetNumberOfCandidate (&fContinue)  ;
	if (nCandidate <= 0) 
		return	FALSE ;
	_pHenkanSession->Rewind () ;

	pMyCand			= _pDoc->GetCandidateInfoBuffer () ;
	if (pMyCand == NULL)
		return	FALSE ;

	nPages	= 1 + ((nCandidate - iPageStart) + NUM_JHENKAN_SHOW_CANDIDATE_KEYS - 1) / NUM_JHENKAN_SHOW_CANDIDATE_KEYS ;
	pMyCand->_vbufCandidate.Clear () ;
	pMyCand->_vbufCandidateIndex.Clear () ;
	pMyCand->_vbufPageIndex.Clear () ;
	if (! pMyCand->_vbufCandidate.Require (nNeedLength) ||
		! pMyCand->_vbufCandidateIndex.Require (nCandidate) || 
		! pMyCand->_vbufPageIndex.Require (nPages)) {
		pMyCand->_vbufCandidate.Clear () ;
		pMyCand->_vbufCandidateIndex.Clear () ;
		pMyCand->_vbufPageIndex.Clear () ;
		return	FALSE ;
	}
	pMyCand->_iStyle			= IMECANDSTYLE_READ ;
	pMyCand->_iCount			= nCandidate ;
	pMyCand->_iSelection		= iPageStart ;
	pMyCand->_iCurrentPage		= 1 ;
	DEBUGPRINTF ((TEXT ("CandidateList: Count(%d), PageStart(%d), MaxPage(%d)\n"), nCandidate, iPageStart, nPages)) ;

	piDestPageStart		= (UINT*) pMyCand->_vbufPageIndex.GetBuffer () ;
	*piDestPageStart ++	= iPageStart ;
	for (i = 1 ; i < nPages ; i ++) 
		*piDestPageStart ++	= iPageStart + (i - 1) * NUM_JHENKAN_SHOW_CANDIDATE_KEYS ;

	pwCandidateStr	= (LPWSTR) pMyCand->_vbufCandidate.GetBuffer () ;
	piDestIndex		= (UINT*) pMyCand->_vbufCandidateIndex.GetBuffer () ;
	pwDest			= pwCandidateStr ;
	for (i = 0 ; i < nCandidate ; i ++) {
		*piDestIndex	= (int)(pwDest - pwCandidateStr) ;

		wstrResult	= _pHenkanSession->GetCandidate () ;
		if (wstrResult != NULL) {
			nstrResult	= lstrlenW (wstrResult) ;
			if (_pDoc->IsSkkUseNumericConversionp () && _nbufJNumList > 0) {
				nstrResult	= _JNumericConvert (wszBuffer, NELEMENTS (wszBuffer), wstrResult, nstrResult) ;
				wstrResult	= wszBuffer ;
			}
			/*lstrncpyW (pCandidateStr, wstrResult, nstrResult) ;*/
			memcpy (pwDest, wstrResult, sizeof (WCHAR) * nstrResult) ;
			pwDest [nstrResult]	= L'\0' ;
			DEBUGPRINTFW ((L"CandidateList[%d]: \"%s\"\n", i, pwDest)) ;
			pwDest		+= nstrResult + 1 ;
			piDestIndex	++ ;
		}
		(void) _pHenkanSession->NextCandidate () ;
	}

	/*	���ʒu��߂��BSequential �Ȃ̂��h�����B*/
	_pHenkanSession->Rewind () ;
	for (i = 0 ; i < iPageStart ; i ++) 
		if (! _pHenkanSession->NextCandidate ()) 
			break ;
	return	TRUE ;
}

/*========================================================================
 */
BOOL
CImeBuffer::_JUpdateJisyo (
	register LPCWSTR				wstrResult,
	register int					nstrResult,
	register CTJisyoUpdateSession*	pUpdateSession)
{
	register LPCWSTR	wstrHenkanKey ;
	register int		nstrHenkanKey ;
	register BOOL		fRetval ;
	register BOOL		fOkuriAri	= FALSE ;
	WCHAR				wszBuffer [MAXCOMPLEN] ;
	
	if (pUpdateSession == NULL)
		return	FALSE ;

	/*	���艼���ϊ����ǂ����̔��f�B*/
	if (_nbufJHenkanKey > 0) {
		WCHAR	ch	= _bufJHenkanKey [_nbufJHenkanKey - 1] ;
		if (_bufJHenkanKey [0] > 127 && L'a' <= ch && ch <= L'z')
			fOkuriAri	= TRUE ;
	}
	/*	�Љ����ϊ��𕽉����ϊ��Ƃ��Ĉ����ꍇ�ɂ́A�o�^��폜�̎��ɂ�
	 *	���ӂ𕥂�Ȃ���΂Ȃ�Ȃ��B
	 */
	if (_pDoc->IsSkkKatakanaHiraganaHenkanp ()) {
		if (fOkuriAri) {
			nstrHenkanKey	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), _bufJHenkanKey, _nbufJHenkanKey) ;
		} else {
			nstrHenkanKey	= JZenHanKatakana2Hiragana (wszBuffer, NELEMENTS (wszBuffer), _bufJSearchKey, _nbufJSearchKey) ;
		}
		wstrHenkanKey	= wszBuffer ;
	} else {
		if (fOkuriAri) {
			wstrHenkanKey	= _bufJHenkanKey ;
			nstrHenkanKey	= _nbufJHenkanKey ;
		} else {
			wstrHenkanKey	= _bufJSearchKey ;
			nstrHenkanKey	= _nbufJSearchKey ;
		}
	}
	fRetval	= pUpdateSession->Update (wstrHenkanKey, nstrHenkanKey, wstrResult, nstrResult, fOkuriAri) ;
	delete	pUpdateSession ;
	return	fRetval ;
}

/*	�u#4�v�����ۂɉ��ɕϊ����ꂽ���𒲂ׂāA��������[�U�����ɓo�^����B�Ⴆ�΁A
 *	�u#4�v���ϊ�����āu/�P/��/�v�ɕϊ�����āA�u�P�v�Ŋm�肵���Ƃ���ƁA
 *	�u1 /�P/�v�̃G���g�������[�U�����ɍ쐬����B
 */
BOOL
CImeBuffer::_JSharp4UpdateJisyo (
	BOOL				fRecord)
{
	CTJisyoUpdateSession*	pUpdateSession	= NULL ;
	LPCWSTR	wpNoConv, wpConv, pNum ;
	int		nNum ;
	WCHAR	wszBuffer [MAXCOMPLEN] ;

	if (! _pDoc->IsSkkUseNumericConversionp ())
		return	FALSE ;

	/*	�����炪�u#4�v�Łu�Č����v����L�[���[�h��������������T���̂�
	 *	�K�v�B*/
	pNum	= _bufJNumList ;
	nNum	= _nbufJNumList ;

	/*	�����炪�ϊ��O�̕�����B*/
	wpNoConv	= _pHenkanSession->GetReferCandidate () ;
	/*	�����炪�ϊ���̕�����B*/
	wpConv		= _pHenkanSession->GetCandidate () ;

	DEBUGPRINTF ((TEXT ("Conv(\"%s\"), NoConv(\"%s\")\n"), 
				  (wpConv?   wpConv : L""),
				  (wpNoConv? wpNoConv : L""))) ;
	if (wpNoConv == NULL || wpConv == NULL)
		return	FALSE ;

	/*	pNum       -> /1/2/3/4/5// (���ۂ� separator �� NUL ����)
	 *	wstrNoConv -> ��#1��#2��#3��#4��#1
	 *	wstrConv   -> ��1���Q���O���l��5
	 *	���̒�����A(4 #4 �l) �̃y�A�𔭌�����B 
	 *
	 *	���� #4 �ϊ��̌��ʂ͔C�ӂ��Ƃ������Ƃ��B�P���ɕ��������X�L�b�v�ł�
	 *	�ς܂Ȃ����낤�B
	 */
	for ( ; ; ) {
		/*	�����ϊ��̂Ƃ�������O����΁A���҂͈�v���Ă��锤�B*/
		while (*wpNoConv == *wpConv && *wpNoConv != L'#') {
			if (*wpNoConv == L'\0')
				goto	exit ;
			wpNoConv	++ ;
			wpConv		++ ;
		}
		/*	�ϊ����ʂ� # �͉����ɒu���������Ă��锤�B*/
		if (*wpNoConv == L'#') {
			int		nCmd ;

			wpNoConv	++ ;
			if (*wpNoConv == L'\0') {
				/*	������ # �ł����Ȃ������ꍇ�ɂ́A�����𔲂���B*/
				goto	exit ;
			}

			nCmd	= *wpNoConv ++ ;
			/*	�A������ #? �͑S�ăX�L�b�v����B�ŏ��� #? �������L���B*/
			while (*wpNoConv == L'#' &&
				   L'0' <= *(wpNoConv + 1) && *(wpNoConv + 1) <= L'9') {
				wpNoConv	+= 2 ;
			}

			/*	#4 �ϊ��̎������v���ӁB*/
			if (*wpNoConv != L'4') {
				LPCWSTR	wpStart	= wpConv ;

				/*	�C�ӂ̕����� #4 �ϊ��̌��ʁA�o������\��������B
				 *	�Ƃ������Ƃ́A�����ɉ����������̂��𔻒f���邱�Ƃ�
				 *	�s�\���A���Ȃ莞�Ԃ�������B
				 *	�����͍ő��v�̖@���ōs���B��ԍŌ�� NoConv ��
				 *	``4'' �ɑ��������� Conv �ɏo�������ꏊ��Ó��ł�
				 *	��Ɣ��f����B
				 */
				wpStart	= wpConv ;
				for ( ; ; ) {
					LPCWSTR	wptrL, wptrR ;

					while (*wpNoConv != *wpConv && *wpConv != L'\0') 
						wpConv	++ ;
					/*	�Ō�܂Ō������Ă��܂����B*/
					if (*wpConv == L'\0')
						break ;

					/*	wpConv �� wpNoConv ����v�����B�ǂ̈ʂ������
					 *	��v���Ă���̂��m�F����B*/
					wptrL	= wpNoConv ;
					wptrR	= wpConv ;
					if (*wptrL == *wptrR) {
						while (*wptrL == *wptrR && *wptrL != L'\0') {
							wptrL	++ ;
							wptrR	++ ;
						}
						/*	���̒i�K�Łu�ǂ̕����v�ňႤ�Əo���̂���������
						 *	���҂��قȂ���̂��w�������R���A``#'' �Ȃ�c
						 *	�����܂ł͈�v�����ƌ���B
						 *	#4 �ϊ��̌��ʂ� # �͓��삵�Ȃ��悤�ɒ@��������
						 *	����̂ŁA�\���ڈ��Ƃ��ē������c�B
						 */
						if (*wptrL == L'#') {
							break ;
						}
						if (*wptrL == L'\0' && *wptrR == L'\0') 
							break ;
					}
				}
				/*	wpStart ���� wpConv ���w���ʒu�܂ł��A#4 �ϊ��̌��ʂ���
				 *	��������B*/
				if (nNum > 0 && *pNum != L'\0') {
#if defined (DBG) || defined (DEBUG)
					int	n	= wpConv - wpStart ;
					if (n > (NELEMENTS (wszBuffer) - 1))
						n	= NELEMENTS (wszBuffer) - 1 ;
					lstrncpyW (wszBuffer, wpStart, n) ;
					wszBuffer [n]	= L'\0' ;
					DEBUGPRINTF ((TEXT ("#4 record \"%s\" -> \"%s\"\n"), pNum, wszBuffer)) ;
#endif
					/*	���[�ށA����Z�b�V�������N�����K�v�͂���̂��H
					 */
					if (fRecord) {
						pUpdateSession	= new CTRecordSession () ;
					} else {
						pUpdateSession	= new CTPurgeSession () ;
					}
					if (pUpdateSession == NULL)
						goto	exit ;
					if (! pUpdateSession->Update (pNum, lstrlenW (pNum), wpStart, wpConv - wpStart, FALSE))
						goto	exit ;
					delete	pUpdateSession ;

					JNumSkip (&pNum, &nNum) ;
				}
			} else {
				/*	���̏ꍇ�ɂ͏����ɐ��l�����X�L�b�v����Ηǂ��B
				 *	���A�ǂ̒��x�X�L�b�v����Ηǂ��̂��́A���Ȃ�
				 *	����B
				 *	���ǁA�ēx expand ���Ă݂āA���̕�����������
				 *	skip ����̂����E�B
				 */
				int	n	= JNumExp (wszBuffer, NELEMENTS (wszBuffer), nCmd, &pNum, &nNum) ;
				while (*wpConv != L'\0' && n -- > 0)
					wpConv	++ ;
			}
		} else {
			/*	���̎��Ԃ͓�B# �������ė��҂��s��v�Ƃ͂ǂ��������Ƃ��낤�H
			 */
			DEBUGPRINTF ((TEXT ("\"%s\" != \"%s\"\n"), wpNoConv, wpConv)) ;
			goto	exit ;
		}
	}
  exit:
	return	TRUE ;
}

int
CImeBuffer::_GetShiftCount ()
{
	register int	nCursor, nShift ;
	register int	nKanaStartPoint, nHenkanStartPoint, nHenkanEndPoint ;
	register int	nOkuriStartPoint ;

	nCursor	= _pmkPoint->GetPosition () ;

	if (!_fJMode) 
		return	nCursor ;

	nKanaStartPoint		= (_nbufJPrefix > 0 && _pmkJKanaStartPoint      != NULL)?
		_pmkJKanaStartPoint->GetPosition () : MAXCOMPLEN ;
	nHenkanStartPoint	= (_fJHenkanOn      && _pmkJHenkanStartPoint    != NULL)?
		_pmkJHenkanStartPoint->GetPosition () - 1 : MAXCOMPLEN ;
	nHenkanEndPoint		= (_fJHenkanActive  && _pmkJHenkanEndPoint      != NULL)?
		_pmkJHenkanEndPoint->GetPosition () : MAXCOMPLEN ;
	nOkuriStartPoint	= (_fJOkurigana     && _pmkJOkuriganaStartPoint != NULL)?
		_pmkJOkuriganaStartPoint->GetPosition () : MAXCOMPLEN ;

	nShift	= nCursor ;
	nShift	= (nShift > nKanaStartPoint)?   nKanaStartPoint :   nShift ;
	nShift	= (nShift > nHenkanStartPoint)? nHenkanStartPoint : nShift ;
	nShift	= (nShift > nHenkanEndPoint)?   nHenkanEndPoint :   nShift ;
	nShift	= (nShift > nOkuriStartPoint)?  nOkuriStartPoint :  nShift ;
	return	nShift ;
}

int
CImeBuffer::_HasWordAnnotationp (
	register LPCWSTR	pWord,
	register int		nWord) const
{
	register LPCWSTR	ptr ;

	if (pWord == NULL || nWord <= 0)
		return	-1 ;

	ptr	= pWord ;
	while (nWord > 0 && *ptr != L'\0') {
		if (*ptr == L';')
			return	(ptr - pWord) ;
		nWord	-- ;
		ptr		++ ;
	}
	return	-1 ;	/* Not found */
}

BOOL
CImeBuffer::_SaveUserJisyo ()
{
	CTJisyoSaveSession*	pSession ;
	BOOL	bRetval ;

	pSession	= new CTJisyoSaveSession ;
	if (pSession == NULL)
		return	FALSE ;
	bRetval		= pSession->Synchronize () ;
	delete	pSession ;
	if (bRetval)
		_pDoc->SetMessage (L"Saving skkime-jisyo ... done") ;
	return	bRetval ;
}

BOOL
CImeBuffer::_PushContext (
	CImeBufferContext*		pContext)
{
	if (pContext == NULL ||  _pHenkanSession != NULL || _pRecursiveEditSession != NULL)
		return	FALSE ;

	pContext->_nLastCommandChar		= _pDoc->GetLastCommandChar () ;
	pContext->_nLastCommand			= _pDoc->GetLastCommand () ;
	pContext->_nThisCommand			= _pDoc->GetThisCommand () ;
	pContext->_lLastKeyData			= _pDoc->GetLastKeyData () ;

	memcpy (pContext->_bufComp,				_bufComp,				sizeof (WCHAR) * _nbufComp) ;
	memcpy (pContext->_bufJPrefix,			_bufJPrefix,			sizeof (WCHAR) * _nbufJPrefix) ;
	memcpy (pContext->_bufJHenkanKey,		_bufJHenkanKey,			sizeof (WCHAR) * _nbufJHenkanKey) ;
	memcpy (pContext->_bufJHenkanKey2,		_bufJHenkanKey2,		sizeof (WCHAR) * _nbufJHenkanKey2) ;
	memcpy (pContext->_bufJSearchKey,		_bufJSearchKey,			sizeof (WCHAR) * _nbufJSearchKey) ;
	memcpy (pContext->_bufJHenkanOkurigana,	_bufJHenkanOkurigana,	sizeof (WCHAR) * _nbufJHenkanOkurigana) ;
	memcpy (pContext->_bufJNumList,			_bufJNumList,			sizeof (WCHAR) * _nbufJNumList) ;
	memcpy (pContext->_bufJHenkanResult,	_bufJHenkanResult,		sizeof (WCHAR) * _nbufJHenkanResult) ;
	memcpy (pContext->_bufJReadingText,		_bufJReadingText,		sizeof (WCHAR) * _nbufJReadingText) ;
	pContext->_nbufComp				= _nbufComp ;
	pContext->_nbufJPrefix			= _nbufJPrefix ;
	pContext->_nbufJHenkanKey		= _nbufJHenkanKey ;
	pContext->_nbufJHenkanKey2		= _nbufJHenkanKey2 ;
	pContext->_nbufJSearchKey		= _nbufJSearchKey ;
	pContext->_nbufJHenkanOkurigana	= _nbufJHenkanOkurigana ;
	pContext->_nbufJNumList			= _nbufJNumList ;
	pContext->_nbufJHenkanResult	= _nbufJHenkanResult ;
	pContext->_nbufJReadingText		= _nbufJReadingText ;

	pContext->_fJMode				= _fJMode ;
	pContext->_fJisx0201			= _fJisx0201 ;
	pContext->_fJKatakana			= _fJKatakana ;
	pContext->_fJZenkaku			= _fJZenkaku ;
	pContext->_fJOkurigana			= _fJOkurigana ;
	pContext->_fJHenkanActive		= _fJHenkanActive ;
	pContext->_fJHenkanOn			= _fJHenkanOn ;
	pContext->_fJAbbrev				= _fJAbbrev ;
	pContext->_nJHenkanCount		= _nJHenkanCount ;
	pContext->_nJOkuriIndexMin		= _nJOkuriIndexMin ;
	pContext->_nJOkuriIndexMax		= _nJOkuriIndexMax ;
	pContext->_nJOkuriAri			= _nJOkuriAri ;
	pContext->_wchOkuriChar			= _wchOkuriChar ;

	pContext->_nJInputCode1			= _nJInputCode1 ;
	pContext->_nJInputCode2			= _nJInputCode2 ;
	pContext->_nJInputByCodeOrMenuJumpDefault	= _nJInputByCodeOrMenuJumpDefault ;

	pContext->_nmkPoint					= (_pmkPoint				!= NULL)? (_pmkPoint				- _rMarker) : -1 ;
	pContext->_nmkEditTop				= (_pmkEditTop				!= NULL)? (_pmkEditTop				- _rMarker) : -1 ;
	pContext->_nmkMark					= (_pmkMark					!= NULL)? (_pmkMark					- _rMarker) : -1 ;
	pContext->_nmkJKanaStartPoint		= (_pmkJKanaStartPoint		!= NULL)? (_pmkJKanaStartPoint		- _rMarker) : -1 ;
	pContext->_nmkJHenkanStartPoint		= (_pmkJHenkanStartPoint	!= NULL)? (_pmkJHenkanStartPoint	- _rMarker) : -1 ;
	pContext->_nmkJHenkanEndPoint		= (_pmkJHenkanEndPoint		!= NULL)? (_pmkJHenkanEndPoint		- _rMarker) : -1 ;
	pContext->_nmkJOkuriganaStartPoint	= (_pmkJOkuriganaStartPoint != NULL)? (_pmkJOkuriganaStartPoint	- _rMarker) : -1 ;
	pContext->_nmkJReadingStartPoint	= (_pmkJReadingStartPoint	!= NULL)? (_pmkJReadingStartPoint	- _rMarker) : -1 ;
	pContext->_nmkJReadingEndPoint		= (_pmkJReadingEndPoint		!= NULL)? (_pmkJReadingEndPoint		- _rMarker) : -1 ;
	memcpy (pContext->_rMarker, _rMarker, sizeof (CTMarker) * MAXBUFMARKER) ;
	pContext->_nMarker					= _nMarker ;

	pContext->_pFilterFunc			= _pFilterFunc ;
	return	TRUE ;
}

BOOL
CImeBuffer::_PopContext (
	CImeBufferContext*		pContext)
{
	if (pContext == NULL)
		return	FALSE ;

	_pDoc->SetLastCommandChar (pContext->_nLastCommandChar) ;
	_pDoc->SetLastCommand (pContext->_nLastCommand) ;
	_pDoc->SetThisCommand (pContext->_nThisCommand) ;
	_pDoc->SetLastKeyData (pContext->_lLastKeyData) ;

	memcpy (_bufComp,				pContext->_bufComp,				sizeof (WCHAR) * pContext->_nbufComp) ;
	memcpy (_bufJPrefix,			pContext->_bufJPrefix,			sizeof (WCHAR) * pContext->_nbufJPrefix) ;
	memcpy (_bufJHenkanKey,			pContext->_bufJHenkanKey,		sizeof (WCHAR) * pContext->_nbufJHenkanKey) ;
	memcpy (_bufJHenkanKey2,		pContext->_bufJHenkanKey2,		sizeof (WCHAR) * pContext->_nbufJHenkanKey2) ;
	memcpy (_bufJSearchKey,			pContext->_bufJSearchKey,		sizeof (WCHAR) * pContext->_nbufJSearchKey) ;
	memcpy (_bufJHenkanOkurigana,	pContext->_bufJHenkanOkurigana,	sizeof (WCHAR) * pContext->_nbufJHenkanOkurigana) ;
	memcpy (_bufJNumList,			pContext->_bufJNumList,			sizeof (WCHAR) * pContext->_nbufJNumList) ;
	memcpy (_bufJHenkanResult,		pContext->_bufJHenkanResult,	sizeof (WCHAR) * pContext->_nbufJHenkanResult) ;
	memcpy (_bufJReadingText,		pContext->_bufJReadingText,		sizeof (WCHAR) * pContext->_nbufJReadingText) ;
	_nbufComp				= pContext->_nbufComp ;
	_nbufJPrefix			= pContext->_nbufJPrefix ;
	_nbufJHenkanKey			= pContext->_nbufJHenkanKey ;
	_nbufJHenkanKey2		= pContext->_nbufJHenkanKey2 ;
	_nbufJSearchKey			= pContext->_nbufJSearchKey ;
	_nbufJHenkanOkurigana	= pContext->_nbufJHenkanOkurigana ;
	_nbufJNumList			= pContext->_nbufJNumList ;
	_nbufJHenkanResult		= pContext->_nbufJHenkanResult ;
	_nbufJReadingText		= pContext->_nbufJReadingText ;

	_fJMode				= pContext->_fJMode ;
	_fJisx0201			= pContext->_fJisx0201 ;
	_fJKatakana			= pContext->_fJKatakana ;
	_fJZenkaku			= pContext->_fJZenkaku ;
	_fJOkurigana		= pContext->_fJOkurigana ;
	_fJHenkanActive		= pContext->_fJHenkanActive ;
	_fJHenkanOn			= pContext->_fJHenkanOn ;
	_fJAbbrev			= pContext->_fJAbbrev ;
	_nJHenkanCount		= pContext->_nJHenkanCount ;
	_nJOkuriIndexMin	= pContext->_nJOkuriIndexMin ;
	_nJOkuriIndexMax	= pContext->_nJOkuriIndexMax ;
	_nJOkuriAri			= pContext->_nJOkuriAri ;
	_wchOkuriChar		= pContext->_wchOkuriChar ;

	_nJInputCode1			= pContext->_nJInputCode1 ;
	_nJInputCode2			= pContext->_nJInputCode2 ;
	_nJInputByCodeOrMenuJumpDefault	= pContext->_nJInputByCodeOrMenuJumpDefault ;

	_pmkPoint				= (pContext->_nmkPoint					< 0)? NULL : &_rMarker [pContext->_nmkPoint] ;
	_pmkEditTop				= (pContext->_nmkEditTop				< 0)? NULL : &_rMarker [pContext->_nmkEditTop] ;
	_pmkMark				= (pContext->_nmkMark					< 0)? NULL : &_rMarker [pContext->_nmkMark] ;
	_pmkJKanaStartPoint		= (pContext->_nmkJKanaStartPoint		< 0)? NULL : &_rMarker [pContext->_nmkJKanaStartPoint] ;
	_pmkJHenkanStartPoint	= (pContext->_nmkJHenkanStartPoint		< 0)? NULL : &_rMarker [pContext->_nmkJHenkanStartPoint] ;
	_pmkJHenkanEndPoint		= (pContext->_nmkJHenkanEndPoint		< 0)? NULL : &_rMarker [pContext->_nmkJHenkanEndPoint] ;
	_pmkJOkuriganaStartPoint= (pContext->_nmkJOkuriganaStartPoint	< 0)? NULL : &_rMarker [pContext->_nmkJOkuriganaStartPoint] ;
	_pmkJReadingStartPoint	= (pContext->_nmkJReadingStartPoint		< 0)? NULL : &_rMarker [pContext->_nmkJReadingStartPoint] ;
	_pmkJReadingEndPoint	= (pContext->_nmkJReadingEndPoint		< 0)? NULL : &_rMarker [pContext->_nmkJReadingEndPoint] ;
	memcpy (_rMarker, pContext->_rMarker, sizeof (CTMarker) * MAXBUFMARKER) ;
	_nMarker				= pContext->_nMarker ;

	_pFilterFunc			= pContext->_pFilterFunc ;
	return	TRUE ;
}

/*========================================================================*
 *	static private methods
 *---
 *	callback/function pointer �Ƃ��ė��p���邽�߂� static method �ɂȂ���
 *	����B���̂܂܂ł� this �����p�ł��Ȃ��̂ŁA���� pThis �̌`�Ŗ{���� 
 *	this ��^���Ă���B
 */
BOOL
CImeBuffer::_stNormalFilter (
	register CImeBuffer*	pThis)
{
	return	pThis->_NormalFilter () ;
}

BOOL
CImeBuffer::_stJKanaInputFilter (
	register CImeBuffer*	pThis)
{
	return	pThis->_JKanaInputFilter () ;
}

BOOL
CImeBuffer::_stJHenkanShowCandidatesFilter (
	register CImeBuffer*	pThis)
{
	return	pThis->_JHenkanShowCandidatesFilter () ;
}



	
