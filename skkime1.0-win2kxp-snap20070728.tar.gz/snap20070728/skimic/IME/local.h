#pragma once

#include <windows.h>
#include <shlwapi.h>
#include <wchar.h>
#include <tchar.h>
#include <assert.h>

#define	NELEMENTS(array)	(sizeof (array) / sizeof (array [0]))
#if !defined (ASSERT)
#define	ASSERT(x)			assert(x)
#endif

#if defined (DEBUG) || defined (DBG) || defined (_DEBUG)
void	DebugPrintf	(LPCTSTR strFormat,...) ;
void	DebugPrintfW(LPCWSTR strFormat,...) ;

#define	DEBUGPRINTF(text)	DebugPrintf##text
#define	DEBUGPRINTFW(text)	DebugPrintfW##text
#else
#define	DEBUGPRINTF(text)	/*text*/
#define	DEBUGPRINTFW(text)	/*text*/
#endif

