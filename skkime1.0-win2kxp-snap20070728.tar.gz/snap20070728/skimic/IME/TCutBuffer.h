#if !defined (TCutBufferSession_h)
#define	TCutBufferSession_h

#include "TCommuSession.h"

class CTCutBufferSession : public CTCommunicateSession {
public:
	virtual	BOOL	Set (LPCWSTR pSrc, int nSrc, BOOL fAppend) ;
	virtual	int		Get (LPWSTR pDest, int nDest) ;
} ;

#endif

