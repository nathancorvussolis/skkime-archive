#include "local.h"
#include "TCutBuffer.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
CTCutBufferSession::Set (
	register LPCWSTR	pSrc,
	register int		nSrc,
	register BOOL		fAppend)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor, nMinor, nSize ;
	register int		nRecv ;
	register BOOL		fRetval	= FALSE ;

	hPipe		= _OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE) 
		return	FALSE ;

	if (! packet.SetHeader (SKKISERV_PROTO_SETCUTBUFFER, fAppend) ||
		! packet.AddString (pSrc, nSrc) ||
		! packet.SetLength () ||
		! _Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! _Recv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= packet.GetSize () ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! packet.GetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;

	fRetval	= (nMajor == SKKISERV_PROTO_SETCUTBUFFER_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

int
CTCutBufferSession::Get (
	register LPWSTR		pDest,
	register int		nDest)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	register int		nBufferLeft	= nDest ;
	register LPCWSTR	pResult ;
	register int		nRecv, nResult ;
	int					nMajor, nMinor, nSize ;
	WORD				wTotalResult ;

	hPipe		= _OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE) 
		return	FALSE ;

	if (! packet.SetHeader  (SKKISERV_PROTO_GETCUTBUFFER, 0) ||
		! packet.SetLength  () ||
		! _Send (hPipe, &packet))
		goto	exit_func ;

	if (! _Recv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= packet.GetSize () ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! packet.GetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;

	if (nMajor != SKKISERV_PROTO_GETCUTBUFFER_REPLY ||
		! packet.GetCard16 (SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;

	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	pResult	= (LPCWSTR)(packet.GetData () + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult	= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	if (wTotalResult > 0) {
		register int		nTotalResult	= wTotalResult ;
		register int		nCopy ;
		register LPWSTR		ptr				= pDest ;

		/*	����擾�����ʂ͂ǂ�����ATotal Size �𒴂��邱�Ƃ͂����Ă�
		 *	�Ȃ�Ȃ����B
		 */
		if (nResult > nTotalResult)
			nResult		= nTotalResult ;

		nCopy			= (nResult < nBufferLeft)? nResult : nBufferLeft ;
		memcpy (ptr, pResult, nCopy * sizeof (WCHAR)) ;
		ptr				+= nCopy ;
		nTotalResult	-= nCopy ;
		nBufferLeft		-= nCopy ;
		while (nTotalResult > 0 && nBufferLeft > 0) {
			if (! _Recv (hPipe, &packet))
				break ;
			nRecv	= packet.GetSize () ;
			if (nRecv < 0)
				break ;
			pResult	= (LPCWSTR) packet.GetData () ;
			nResult	= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;
			nCopy			= (nResult < nBufferLeft)? nResult : nBufferLeft ;
			memcpy (ptr, pResult, nCopy * sizeof (WCHAR)) ;
			ptr				+= nCopy ;
			nTotalResult	-= nCopy ;
			nBufferLeft		-= nCopy ;
		}
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nDest - nBufferLeft) ;
}

