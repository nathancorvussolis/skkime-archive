#include "local.h"
#include "TJisyoUpdateSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
CTRecordSession::Update (
	register LPCWSTR	wstrHenkanKey,
	register int		nstrHenkanKey,
	register LPCWSTR	wstrResult,
	register int		nstrResult,
	register BOOL		fOkurigana)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= _OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.SetHeader (SKKISERV_PROTO_RECORD, fOkurigana) ||
		! packet.AddString (wstrHenkanKey, nstrHenkanKey) ||
		! packet.AddString (wstrResult, nstrResult) ||
		! packet.SetLength () ||
		! _Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! _Recv (hPipe, &packet) ||
		! packet.GetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.GetSize () ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_RECORD_REPLY) ;
}

BOOL
CTPurgeSession::Update (
	register LPCWSTR	wstrHenkanKey, 
	register int		nstrHenkanKey,
	register LPCWSTR	wstrResult,
	register int		nstrResult,
	register BOOL		fOkurigana)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= _OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.SetHeader (SKKISERV_PROTO_PURGE, fOkurigana) ||
		! packet.AddString (wstrHenkanKey, nstrHenkanKey) ||
		! packet.AddString (wstrResult, nstrResult) ||
		! packet.SetLength () ||
		! _Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! _Recv (hPipe, &packet) ||
		! packet.GetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.GetSize () ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_PURGE_REPLY) ;
} 

BOOL
CTJisyoSaveSession::Synchronize () 
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= _OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.SetHeader (SKKISERV_PROTO_SAVELOCALJISYO, 0) ||
		! packet.SetLength () ||
		! _Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! _Recv (hPipe, &packet) ||
		! packet.GetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.GetSize () ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_SAVELOCALJISYO_REPLY) ;
}


