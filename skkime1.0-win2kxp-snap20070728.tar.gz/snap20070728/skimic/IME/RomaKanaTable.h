#if !defined (TRomaKanaTable_h)
#define	TRomaKanaTable_h

class CTRomaKanaTableEntry {
public:
	CTRomaKanaTableEntry () {
		return ;
	}
	virtual			~CTRomaKanaTableEntry () {
		/*	nothing to do */
	}
	virtual BOOL	Init (LPCWSTR wstrPrefix, LPCWSTR wstrHiragana, LPCWSTR wstrKatakana) = 0 ;
	virtual BOOL	Init (LPCWSTR wstrTable [3]) = 0 ;
	virtual LPCWSTR	GetPrefix () const = 0 ;
	virtual LPCWSTR	GetKatakana () const = 0 ;
	virtual LPCWSTR	GetHiragana () const = 0 ;
} ;

class CTStaticRomaKanaTableEntry : public CTRomaKanaTableEntry {
private:
	LPCWSTR					_wstrPrefix ;
	LPCWSTR					_wstrHiragana ;
	LPCWSTR					_wstrKatakana ;

public:
	CTStaticRomaKanaTableEntry () : _wstrPrefix (NULL), _wstrHiragana (NULL), _wstrKatakana (NULL) {
		return ;
	}
	virtual		~CTStaticRomaKanaTableEntry () {
		return ;
	}
	virtual BOOL	Init (LPCWSTR wstrPrefix, LPCWSTR wstrHiragana, LPCWSTR wstrKatakana) {
		_wstrPrefix		= wstrPrefix ;
		_wstrHiragana	= wstrHiragana ;
		_wstrKatakana	= wstrKatakana ;
		return	TRUE ;
	}
	virtual BOOL	Init (LPCWSTR wstrTable [3]) {
		_wstrPrefix		= wstrTable [0] ;
		_wstrHiragana	= wstrTable [1] ;
		_wstrKatakana	= wstrTable [2] ;
		return	TRUE ;
	}
	virtual LPCWSTR	GetPrefix () const {
		return	_wstrPrefix ;
	}
	virtual LPCWSTR	GetKatakana () const {
		return	_wstrKatakana ;
	}
	virtual LPCWSTR	GetHiragana () const {
		return	_wstrHiragana ;
	}
} ;

class CTDynamicRomaKanaTableEntry : public CTRomaKanaTableEntry {
private:
	LPWSTR					_wstrPrefix ;
	LPWSTR					_wstrHiragana ;
	LPWSTR					_wstrKatakana ;

public:
	CTDynamicRomaKanaTableEntry () : _wstrPrefix (NULL), _wstrHiragana (NULL), _wstrKatakana (NULL) {
		return ;
	} 
	virtual		~CTDynamicRomaKanaTableEntry () {
		_Uninit () ;
		return ;
	}
	virtual BOOL	Init (LPCWSTR wstrPrefix, LPCWSTR wstrHiragana, LPCWSTR wstrKatakana) {
		ASSERT (_wstrPrefix == NULL) ;
		if (wstrPrefix != NULL) {
			_wstrPrefix		= new WCHAR [wcslen (wstrPrefix) + 1] ;
			if (_wstrPrefix == NULL)
				return	FALSE ;
			wcscpy (_wstrPrefix, wstrPrefix) ;
		}
		if (wstrHiragana != NULL) {
			_wstrHiragana	= new WCHAR [wcslen (wstrHiragana) + 1] ;
			if (_wstrHiragana == NULL)
				return	FALSE ;
			wcscpy (_wstrHiragana, wstrHiragana) ;
		}
		if (wstrKatakana != NULL) {
			_wstrKatakana	= new WCHAR [wcslen (wstrKatakana) + 1] ;
			if (_wstrKatakana == NULL)
				return	FALSE ;
			wcscpy (_wstrKatakana, wstrKatakana) ;
		}
		return	TRUE ;
	}
	virtual BOOL	Init (LPCWSTR wstrTable [3]) {
		return	Init (wstrTable [0], wstrTable [1], wstrTable [2]) ;
	}
	virtual LPCWSTR	GetPrefix () const {
		return	_wstrPrefix ;
	}
	virtual LPCWSTR	GetKatakana () const {
		return	_wstrKatakana ;
	}
	virtual LPCWSTR	GetHiragana () const {
		return	_wstrHiragana ;
	}

private:
	virtual	BOOL	_Uninit () {
		if (_wstrPrefix != NULL) {
			delete[]	_wstrPrefix ;
			_wstrPrefix	= NULL ;
		}
		if (_wstrHiragana != NULL) {
			delete[]	_wstrHiragana ;
			_wstrHiragana	= NULL ;
		}
		if (_wstrKatakana != NULL) {
			delete[]	_wstrKatakana ;
			_wstrKatakana	= NULL ;
		}
		return	TRUE ;
	}
} ;

class CTRomaKanaTable {
private:
	CTRomaKanaTableEntry**	_rpEntries ;
	int						_nEntries ;

	static	LPCWSTR			_srSkkDefaultRomaKanaA [][3] ;
	static	LPCWSTR			_srSkkDefaultRomaKanaI [][3] ;
	static	LPCWSTR			_srSkkDefaultRomaKanaU [][3] ;
	static	LPCWSTR			_srSkkDefaultRomaKanaE [][3] ;
	static	LPCWSTR			_srSkkDefaultRomaKanaO [][3] ;

public:
	CTRomaKanaTable () ;
	virtual			~CTRomaKanaTable () ;
	
	virtual BOOL	Init (int ch) ;
	virtual const CTRomaKanaTableEntry*	Lookup (LPCWSTR wstr, int nwstr) ;

private:
	virtual	BOOL	_Init (LPCWSTR strSubKey, LPCWSTR (*pDefaultTable) [3], int nDefaultTable) ;
	virtual	BOOL	_Uninit () ;
} ;

#endif

