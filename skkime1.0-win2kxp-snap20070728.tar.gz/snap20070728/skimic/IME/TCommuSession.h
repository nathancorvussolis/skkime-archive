#if !defined (TCommuSession_h)
#define	TCommuSession_h

class	CTPacket ;

class CTCommunicateSession {
protected:
	static WCHAR					_rszSkkImePipeName [] ;
	
public:
	CTCommunicateSession () {
		return ;
	}
	virtual			~CTCommunicateSession () {
		return ;
	}

	static BOOL		InitPipeName () ;

protected:
	virtual	HANDLE	_OpenServer () ;
	virtual	BOOL	_Send (HANDLE hPipe, CTPacket* pPacket) ;
	virtual	BOOL	_Recv (HANDLE hPipe, CTPacket* pPacket) ;
	virtual	BOOL	_StartServer () ;
} ;

#endif

