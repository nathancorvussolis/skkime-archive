#if !defined (TAssocRule_h)
#define	TAssocRule_h

#include "wchar.h"

class CTAssocRule {
public:
	virtual	~CTAssocRule () {
		return ;
	}
	virtual BOOL		Init (LPCWSTR wstrState, LPCWSTR wstrNext, LPCWSTR wstrKatakana, LPCWSTR wstrHiragana) {
		return	TRUE ;
		UNREFERENCED_PARAMETER (wstrState) ;
		UNREFERENCED_PARAMETER (wstrNext) ;
		UNREFERENCED_PARAMETER (wstrKatakana) ;
		UNREFERENCED_PARAMETER (wstrHiragana) ;
	}
	virtual BOOL		Init (LPCWSTR rwstr[4]) {
		return	TRUE ;
		UNREFERENCED_PARAMETER (rwstr) ;
	}
	virtual void		Uninit () {
	}
	virtual	LPCWSTR		GetState  () const {
		return	NULL ;
	}
	virtual	LPCWSTR		GetNext   () const {
		return	NULL ;
	}
	virtual	LPCWSTR		GetOutput (BOOL fKatakana) const {
		return	NULL ;
		UNREFERENCED_PARAMETER (fKatakana) ;
	}
} ;

class CTDynamicAssocRule : public CTAssocRule {
private:
	LPWSTR		m_wstrState ;
	LPWSTR		m_wstrNext ;
	LPWSTR		m_wstrKatakana ;
	LPWSTR		m_wstrHiragana ;

public:
	CTDynamicAssocRule () : m_wstrState (0), m_wstrNext (0), m_wstrKatakana (0), m_wstrHiragana (0) {
		return ;
	}
	virtual ~CTDynamicAssocRule () {
		Uninit () ;
	}

	virtual BOOL		Init (
		register LPCWSTR	wstrState,
		register LPCWSTR	wstrNext,
		register LPCWSTR	wstrKatakana,
		register LPCWSTR	wstrHiragana) {
		/*	�������̎��ɂ̂ݎg�����Ƃ�z��B�Đݒ�Ȃǂ͂���Ȃ��ƍl����
		 *	����̂ŁANULL �� ASSERT ��������Bconstructor �̒��� new ��
		 *	��Ǝ��s�������_�� exception �� throw ���Ȃ��Ƃ����Ȃ��̂�
		 *	�c
		 */
		ASSERT (m_wstrState    == NULL) ;
		ASSERT (m_wstrNext     == NULL) ;
		ASSERT (m_wstrKatakana == NULL) ;
		ASSERT (m_wstrHiragana == NULL) ;
#define	ALLOC_AND_COPY(src,dest)	if ((src) != NULL && *(src) != L'\0') { \
	(dest) = new WCHAR [wcslen ((src)) + 1] ; \
	if ((dest) == NULL) \
		return	FALSE ; \
	wcscpy ((dest), (src)) ; \
}
		ALLOC_AND_COPY (wstrState,    m_wstrState) ;
		ALLOC_AND_COPY (wstrNext,     m_wstrNext) ;
		ALLOC_AND_COPY (wstrKatakana, m_wstrKatakana) ;
		ALLOC_AND_COPY (wstrHiragana, m_wstrHiragana) ;
#undef	ALLOC_AND_COPY
		return	TRUE ;
	}
	virtual BOOL		Init (
		LPCWSTR			rwstr[4]) {
		return	Init (rwstr [0], rwstr [1], rwstr [2], rwstr [3]) ;
	}

	virtual void	Uninit () {
		if (m_wstrState) {
			delete[]	m_wstrState ;
			m_wstrState	= NULL ;
		}
		if (m_wstrNext) {
			delete[]	m_wstrNext ;
			m_wstrNext	= NULL ;
		}
		if (m_wstrKatakana) {
			delete[]	m_wstrKatakana ;
			m_wstrKatakana	= NULL ;
		}
		if (m_wstrHiragana) {
			delete[]	m_wstrHiragana ;
			m_wstrHiragana	= NULL ;
		}
		return ;
	}

	virtual	LPCWSTR		GetNext () const {
		return	m_wstrNext ;
	}
	virtual LPCWSTR		GetState () const {
		return	m_wstrState ;
	}
	virtual LPCWSTR		GetOutput (register BOOL fKatakana) const {
		return	(fKatakana)? m_wstrKatakana : m_wstrHiragana ;
	}
} ;

/*	�����̃����o���������K�v���Ȃ����� AssocRule
 */
class CTStaticAssocRule : public CTAssocRule {
private:
	LPCWSTR		m_wstrState ;
	LPCWSTR		m_wstrNext ;
	LPCWSTR		m_wstrKatakana ;
	LPCWSTR		m_wstrHiragana ;

public:
	CTStaticAssocRule () : m_wstrState (NULL), m_wstrNext (NULL), m_wstrKatakana (NULL), m_wstrHiragana (NULL) {
		return ;
	}
	CTStaticAssocRule (LPCWSTR wstrState, LPCWSTR wstrNext, LPCWSTR wstrKatakana, LPCWSTR wstrHiragana) : m_wstrState (wstrState), m_wstrNext (wstrNext), m_wstrKatakana (wstrKatakana), m_wstrHiragana (wstrHiragana) {
		return ;
	}
	CTStaticAssocRule (LPCWSTR rpTable[4]) :
		m_wstrState (rpTable [0]),
		m_wstrNext (rpTable [1]),
		m_wstrKatakana (rpTable [2]),
		m_wstrHiragana (rpTable [3]) {
		return ;
	}
	virtual ~CTStaticAssocRule () {
		return ;	/* nothing to do */
	}
	virtual BOOL		Init (
		register LPCWSTR wstrState,
		register LPCWSTR wstrNext,
		register LPCWSTR wstrKatakana,
		register LPCWSTR wstrHiragana) {
		m_wstrState 	= wstrState ;
		m_wstrNext 		= wstrNext ;
		m_wstrKatakana	= wstrKatakana ;
		m_wstrHiragana	= wstrHiragana ;
		return	TRUE ;
	}
	virtual BOOL		Init (
		LPCWSTR			rwstr[4]) {
		m_wstrState 	= rwstr [0] ;
		m_wstrNext 		= rwstr [1] ;
		m_wstrKatakana	= rwstr [2] ;
		m_wstrHiragana	= rwstr [3] ;
		return	TRUE ;
	}
	virtual	LPCWSTR		GetNext () const {
		return	m_wstrNext ;
	}
	virtual LPCWSTR		GetState () const {
		return	m_wstrState ;
	}
	virtual LPCWSTR		GetOutput (register BOOL fKatakana) const {
		return	(fKatakana)? m_wstrKatakana : m_wstrHiragana ;
	}
} ;

#endif

