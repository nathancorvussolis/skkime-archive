#if !defined (TLispSession_h)
#define	TLispSession_h

#include "TCommuSession.h"

class CTLispSession : public CTCommunicateSession {
public:
	virtual BOOL	SetJNumList (LPCWSTR wstrJNumList, int nstrJNumList) ;
	virtual	BOOL	Eval (LPCWSTR wstrHenkanKey, int nstrHenkanKey, LPWSTR wstrDest, int nstrDest) ;
} ;

#endif

