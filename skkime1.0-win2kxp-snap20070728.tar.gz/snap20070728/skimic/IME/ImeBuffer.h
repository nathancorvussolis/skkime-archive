#pragma once

#include "TMarker.h"

#define	MAXCOMPLEN		(256)
#define	MAXPREFIXLEN	(MAXCOMPLEN)
#define	MAXBUFMARKER	(16)

enum {
	MARKER_POINT	= 0,
	MARKER_EDIT_TOP,
	MARKER_MARK,
	MARKER_J_KANA_STARTPOINT,
	MARKER_J_HENKAN_STARTPOINT,
	MARKER_J_HENKAN_ENDPOINT,
	MARKER_J_OKURIGANA_STARTPOINT,
	MARKER_J_READING_STARTPOINT,
	MARKER_J_READING_ENDPOINT,
	MAX_RESERVED_MARKERS
} ;

class CImeDoc ;
class CTRomaKanaTable ;
class CTSearchSession ;
class CTImeRecursiveEditSession ;
class CTJisyoUpdateSession ;
struct CImeBufferContext ;
struct IMECANDIDATES ;

class CImeBuffer {
	friend class CTImeRecursiveEditSession ;
	friend class CJSharp4HenkanInMinibuffSession ;
	friend class CJHenkanInMinibuffSession ;
	friend class CJInputByCodeOrMenuSession ;
	friend class CJPurgeSession ;
private:
	CImeDoc*	_pDoc ;

	WCHAR		_bufComp [MAXCOMPLEN] ;
	int			_nbufComp ;
	WCHAR		_bufJPrefix [MAXPREFIXLEN] ;
	int			_nbufJPrefix ;
	WCHAR		_bufJHenkanKey [MAXPREFIXLEN] ;
	int			_nbufJHenkanKey ;
	WCHAR		_bufJHenkanKey2 [MAXPREFIXLEN] ;
	int			_nbufJHenkanKey2 ;
	WCHAR		_bufJSearchKey [MAXPREFIXLEN] ;
	int			_nbufJSearchKey ;
	WCHAR		_bufJHenkanOkurigana [MAXPREFIXLEN] ;
	int			_nbufJHenkanOkurigana ;
	WCHAR		_bufJNumList [MAXPREFIXLEN] ;
	int			_nbufJNumList ;
	/*	�ꎞ�I�ɕϊ����ʂ�ۑ�����̂ɗp������o�b�t�@�B*/
	WCHAR		_bufJHenkanResult [MAXPREFIXLEN] ;
	int			_nbufJHenkanResult ;
	/*	�ϊ����ʂ̓ǂ݉�����ۊǂ��Ă����o�b�t�@�B
	 *---
	 *	�ҏW���̃e�L�X�g�̓��A_pmkJReadingStart �� _pmkJReadingEnd 
	 *	�ɋ��܂�镔���� _bufJReadingText �ɒu���������āA���ꂪ
	 *	���ʂ̓ǂ݉����ƂȂ�B*/
	WCHAR		_bufJReadingText [MAXPREFIXLEN] ;
	int			_nbufJReadingText ;

	BOOL		_fJMode ;
	BOOL		_fJisx0201 ;
	BOOL		_fJKatakana ;
	BOOL		_fJZenkaku ;
	BOOL		_fJOkurigana ;
	BOOL		_fJHenkanActive ;
	BOOL		_fJHenkanOn ;
	BOOL		_fJAbbrev ;
	int			_nJHenkanCount ;
	int			_nJOkuriIndexMin ;
	int			_nJOkuriIndexMax ;
	int			_nJOkuriAri ;
	WCHAR		_wchOkuriChar ;

	int			_nJInputCode1 ;
	int			_nJInputCode2 ;
	int			_nJInputByCodeOrMenuJumpDefault ;

	CTMarker*	_pmkPoint ;
	CTMarker*	_pmkEditTop ;
	CTMarker*	_pmkMark ;
	CTMarker*	_pmkJKanaStartPoint ;
	CTMarker*	_pmkJHenkanStartPoint ;
	CTMarker*	_pmkJHenkanEndPoint ;
	CTMarker*	_pmkJOkuriganaStartPoint ;
	CTMarker*	_pmkJReadingStartPoint ;
	CTMarker*	_pmkJReadingEndPoint ;
	CTMarker	_rMarker [MAXBUFMARKER] ;
	int			_nMarker ;

	CTSearchSession*	_pHenkanSession ;
	CTImeRecursiveEditSession*	_pRecursiveEditSession ;

	BOOL				(*_pFilterFunc)(CImeBuffer*) ;

	static const int	_rnJInputByCodeOrMenuJumpLowordTbl [] ;
	static const int	_nJCodeN1Min ;
	static const int	_nJCodeN1Max ;
	static const int	_nJCodeN2Min ;
	static const int	_nJCodeN2Max ;
	static const int	_nJCodeNull ;

public:
	CImeBuffer (CImeDoc* pDoc) ;
	virtual				~CImeBuffer () ;
	virtual BOOL		Init () ;
	virtual BOOL		Init (LPCWSTR wstrMessage, int nstrMessage, CTImeRecursiveEditSession* pSession = NULL) ;
	virtual	void		Uninit () ;
	virtual	BOOL		Clear () ;

	virtual BOOL		QueryFilterKeyEvent (WCHAR wch, BOOL* pfFiltered) ;
	virtual	BOOL		QueryToggleIMEKeyEvent (WCHAR wch, BOOL* pfFiltered) ;
	virtual BOOL		FilterKeyEvent () ;
	virtual LPCWSTR		GetText (int* pnLength) ;
	virtual	int			GetCursorPosition () const ;
	virtual	int			GetReadingText (LPWSTR wpDest, int nDest, int* pnShift) ;
	virtual	BOOL		GetConvertedRegion (int* pnBegin, int* pnEnd) const ;
	virtual	BOOL		GetSelectedRegion (int* pnBegin, int* pnEnd) const ;
	virtual	BOOL		SetConversionMode (int nMode) ;
	virtual	int			GetConversionMode () const ;
	virtual	int			GetKeymap () const ;
	virtual	BOOL		QueryUpdateContext (int* pnShift, int* pnCursor, BOOL* pfContinue) ;
	virtual	BOOL		UpdateContext () ;
	virtual	BOOL		SetReconvertText (LPCWSTR wstrTEXT, int nstrTEXT) ;
	virtual	BOOL		IsStatusActivep () const ;

private:
	BOOL		_NormalFilter () ;
	BOOL		_JKanaInputFilter () ;
	BOOL		_JHenkanShowCandidatesFilter () ;

	BOOL		_JKanaInput () ;
	BOOL		_JToggleKana () ;
	BOOL		_JToggleJisx0201 () ;
	BOOL		_JSetHenkanPoint () ;
	BOOL		_JSetHenkanPointSubr () ;
	BOOL		_JStartHenkan () ;
	BOOL		_JSelfInsert () ;
	BOOL		_JZenkakuInsert () ;
	BOOL		_JModeOff () ;
	BOOL		_JZenkakuEiji () ;
	BOOL		_JAbbrevInput () ;
	BOOL		_JInsertA () ;
	BOOL		_JInsertI () ;
	BOOL		_JInsertU () ;
	BOOL		_JInsertE () ;
	BOOL		_JInsertComma () ;
	BOOL		_JInsertPeriod () ;
	BOOL		_JNewline () ;
	BOOL		_JKeyboardQuit () ;
	BOOL		_JDeleteBackwardChar (int nCount = 1) ;

	BOOL		_Newline () ;
	BOOL		_BackwardChar () ;
	BOOL		_ForwardChar () ;
	BOOL		_DeleteBackwardChar (int nDelete = 1) ;
	BOOL		_SelfInsertCharacter () ;
	BOOL		_TransposeChars () ;
	BOOL		_EndOfLine () ;
	BOOL		_BeginningOfLine () ;
	BOOL		_SetMarkCommand () ;
	BOOL		_KillLine () ;
	BOOL		_KillRegion (int nStart = -1, int nEnd = -1) ;
	BOOL		_KillRingSave (int nStart = -1, int nEnd = -1) ;
	BOOL		_Yank () ;
	BOOL		_AbortRecursiveEdit () ;
	BOOL		_ExitMinibuffer () ;
	BOOL		_MouseDragRegion () ;
	BOOL		_JTryCompletion () ;
	BOOL		_JAbbrevComma () ;
	BOOL		_JAbbrevPeriod () ;

	BOOL		_JKakutei () ;
	BOOL		_JCompletion (BOOL fFirst = FALSE) ;
	BOOL		_JPreviousCompletion () ;
	BOOL		_JPurgeFromJisyo () ;
	BOOL		_JHenkan () ;
	BOOL		_JSetOkurigana () ;
	BOOL		_JNextCandidate () ;
	BOOL		_JPreviousCandidate () ;
	BOOL		_JToday () ;
	BOOL		_JInsert (CTRomaKanaTable* pTable) ;
	BOOL		_JErasePrefix () ;
	BOOL		_JInsertO () ;
	BOOL		_JInsertPrefix (LPCWSTR wstr, int nwstr) ;
	BOOL		_JInsertStr (LPCWSTR wstr, int nwstr) ;
	BOOL		_JEmulateOriginalMap () ;
	int			_JComputeNumericHenkanKey (LPWSTR wszBuffer, int nszBuffer) ;
	int			_JNumericConvert (LPWSTR wstrDest, int nstrDest, LPCWSTR wstrSource, int nstrSource) ;
	BOOL		_JInsertWord (int nPosition, LPCWSTR wstrWord, int nwstrWord) ;
	BOOL		_JChangeMarker () ;
	BOOL		_JChangeMarkerToWhite () ;
	BOOL		_JHenkanInMinibuff () ;
	BOOL		_ShowJHenkanCandidates () ;

	int			_CharAfter (int nPosition) ;
	BOOL		_SetMarker (CTMarker** ppMarker, int nMarkerIndex, const CTMarker* pSource) ;
	BOOL		_DeleteRegion (int nStartPoint, int nEndPoint) ;
	BOOL		_Insert (LPCWSTR wstr, int nwstr) ;
	int			_InsertEx (int nPosition, LPCWSTR wstr, int nwstr) ;
	BOOL		_DeleteChar (int nDelete) ;
	BOOL		_DeleteCharEx (int nPosition, int nDelete) ;
	int			_BufferSubstring (int nStartPoint, int nEndPoint, LPCWSTR* ppDest) ;
	CTMarker*	_MakeMarker (bool fCursor) ;
	BOOL		_DeleteMarker (CTMarker* pMarker) ;

	BOOL		_QueryProcessFunction (int nFuncNo) const ;

	BOOL		_JKatakanaHenkan () ;
	BOOL		_JKatakanaRegion (int nStartPoint, int nEndPoint, BOOL fVContract) ;
	BOOL		_JHiraganaHenkan () ;
	BOOL		_JHiraganaRegion (int nStartPoint, int nEndPoint) ;
	BOOL		_JHankanaHenkan () ;
	BOOL		_JHankanaRegion (int nStartPoint, int nEndPoint) ;
	BOOL		_JZenkanaHenkan () ;
	BOOL		_JZenkanaRegion (int nStartPoint, int nEndPoint, BOOL fKatakana) ;
	BOOL		_JZenkakuHenkan () ;
	BOOL		_JZenkakuRegion (int nStartPoint, int nEndPoint) ;
	BOOL		_JSharp4UpdateJisyo (BOOL fRecord) ;

	BOOL		_JUpdateJisyo (LPCWSTR wstrResult, int nstrResult, CTJisyoUpdateSession* pSession) ;
	int			_GetShiftCount () ;
	int			_HasWordAnnotationp (LPCWSTR wstrWord, int nstrWord) const ;

	BOOL		_SaveUserJisyo () ;

	static	BOOL		_stNormalFilter (CImeBuffer* pThis) ;
	static	BOOL		_stJKanaInputFilter (CImeBuffer* pThis) ;
	static	BOOL		_stJHenkanShowCandidatesFilter (CImeBuffer* pThis) ;

	BOOL				_PushContext (CImeBufferContext* pContext) ;
	BOOL				_PopContext (CImeBufferContext* pContext) ;

private:
	BOOL		_CreateJHenkanCandidateList (int iPageStart) ;

private:
	BOOL		_JInputByCodeOrMenu () ;
	BOOL		_JInputByCodeOrMenu0Start (int n1, int n2) ;
	BOOL		_JInputByCodeOrMenuJumpStart (int n) ;
	BOOL		_JInputByCodeOrMenu1Start (int n1, int n2) ;
	BOOL		_JInputByCodeOrMenuJumpFilter () ;
	BOOL		_JInputByCodeOrMenu1Filter () ;
	BOOL		_CreateJInputByCodeOrMenuJumpList (int n) ;
	BOOL		_CreateJInputByCodeOrMenu1List (int n1, int n2) ;

	static	BOOL		_stJInputByCodeOrMenuJumpFilter (CImeBuffer* pThis) ;
	static	BOOL		_stJInputByCodeOrMenu1Filter (CImeBuffer* pThis) ;

private:
	CImeBuffer () ;
} ;

struct CImeBufferContext {
	int			_nLastCommandChar ;
	int			_nThisCommand ;
	int			_nLastCommand ;
	LPARAM		_lLastKeyData ;

	WCHAR		_bufComp [MAXCOMPLEN] ;
	int			_nbufComp ;
	WCHAR		_bufJPrefix [MAXPREFIXLEN] ;
	int			_nbufJPrefix ;
	WCHAR		_bufJHenkanKey [MAXPREFIXLEN] ;
	int			_nbufJHenkanKey ;
	WCHAR		_bufJHenkanKey2 [MAXPREFIXLEN] ;
	int			_nbufJHenkanKey2 ;
	WCHAR		_bufJSearchKey [MAXPREFIXLEN] ;
	int			_nbufJSearchKey ;
	WCHAR		_bufJHenkanOkurigana [MAXPREFIXLEN] ;
	int			_nbufJHenkanOkurigana ;
	WCHAR		_bufJNumList [MAXPREFIXLEN] ;
	int			_nbufJNumList ;
	/*	�ꎞ�I�ɕϊ����ʂ�ۑ�����̂ɗp������o�b�t�@�B*/
	WCHAR		_bufJHenkanResult [MAXPREFIXLEN] ;
	int			_nbufJHenkanResult ;
	/*	�ϊ����ʂ̓ǂ݉�����ۊǂ��Ă����o�b�t�@�B
	 *---
	 *	�ҏW���̃e�L�X�g�̓��A_pmkJReadingStart �� _pmkJReadingEnd 
	 *	�ɋ��܂�镔���� _bufJReadingText �ɒu���������āA���ꂪ
	 *	���ʂ̓ǂ݉����ƂȂ�B*/
	WCHAR		_bufJReadingText [MAXPREFIXLEN] ;
	int			_nbufJReadingText ;

	BOOL		_fJMode ;
	BOOL		_fJisx0201 ;
	BOOL		_fJKatakana ;
	BOOL		_fJZenkaku ;
	BOOL		_fJOkurigana ;
	BOOL		_fJHenkanActive ;
	BOOL		_fJHenkanOn ;
	BOOL		_fJAbbrev ;
	int			_nJHenkanCount ;
	int			_nJOkuriIndexMin ;
	int			_nJOkuriIndexMax ;
	int			_nJOkuriAri ;
	WCHAR		_wchOkuriChar ;

	int			_nJInputCode1 ;
	int			_nJInputCode2 ;
	int			_nJInputByCodeOrMenuJumpDefault ;

	int			_nmkPoint ;
	int			_nmkEditTop ;
	int			_nmkMark ;
	int			_nmkJKanaStartPoint ;
	int			_nmkJHenkanStartPoint ;
	int			_nmkJHenkanEndPoint ;
	int			_nmkJOkuriganaStartPoint ;
	int			_nmkJReadingStartPoint ;
	int			_nmkJReadingEndPoint ;
	CTMarker	_rMarker [MAXBUFMARKER] ;
	int			_nMarker ;

	BOOL				(*_pFilterFunc)(CImeBuffer*) ;
} ;

