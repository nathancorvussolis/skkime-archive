#if !defined (UNITTEST)
#include "globals.h"
#else
#include "local.h"
#endif
#include "ImeDoc.h"
#include "ImeBuffer.h"
#include "RomaKanaTable.h"
#include "TAssocRule.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "ImeRecursiveEditSession.h"

#define	MAXCOMPSIZE				(256)
#define	MAXASSOCRULE			(8192)
#define	MAX_REGVALUE_SIZE		(512)
#define	MAX_LENGTH_KANAPREFIX	(MAXCOMPSIZE)
#define	MAX_PROCESS_UNREADEVENT	(128)

#define	REGPATH_GENERIC					L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\Generic"
#define	REGPATH_EGG_LIKE_NEWLINE		L"egg-like-newline"
#define	REGPATH_DELETE_IMPLIES_KAKUTEI	L"delete-implies-kakutei"
#define	REGPATH_USE_NUMERIC_CONVERSION	L"use-numeric-conversion"
#define	REGPATH_DABBREV_LIKE_COMPLETION	L"dabbrev-like-completion"
#define	REGPATH_KATAKANA_HIRAGANA_HENKAN	L"katakana-hiragana-henkan"
#define	REGPATH_NUMERIC_STYLE			L"numeric-style"
#define	REGPATH_DATE_AD					L"date-ad"
#define	REGPATH_SHOW_ANNOTATION			L"show-annotation"
#define	REGPATH_KAKUTEI_EARLY			L"kakutei-early"
#define	REGPATH_PROCESS_OKURI_EARLY		L"process-okuri-early"
#define	REGPATH_DELETE_OKURI_WHEN_QUIT	L"delete-okuri-when-quit"

#define	REGPATH_KEYMAP			L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\Keymap"
#define	REGSUBKEY_JMAP			L"j-map"
#define	REGSUBKEY_JABBREVMAP	L"j-abbrev-map"

#define	REGPATH_ROMAKANARULELIST	L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\RomaKanaRuleList"
#define	REGPATH_PREFIXLIST		L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\PrefixList"
#define	REGPATH_INPUTVECTOR		L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\InputVector"
#define	REGPATH_ZENKAKUVECTOR	L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\ZenkakuVector"

#define	REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS	L"j-henkan-show-candidate-keys"
#define	REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1	L"j-input-by-code-or-menu-keys1"
#define	REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2	L"j-input-by-code-or-menu-keys2"

LPCWSTR	CImeDoc::_rstrDefaultPrefixList []	= {
	L"by", L"ch", L"cy",  L"dh", L"dy", L"fy", L"gy", L"hy", L"jy",
	L"ky", L"my", L"py",  L"ry", L"sh", L"sy",	L"th", L"ts", L"ty",
	L"xk", L"xt", L"xts", L"xw", L"xy", L"zy"
} ;

/*========================================================================
 *	constructors
 */
CImeDoc::CImeDoc ()
{
	register int	i ;

	_rpRomaKanaTable 		= NULL ;
	_nAssocRule				= 0 ;
	_nbufUnreadEvent		= 0 ;
	_wchLastCommandChar		= L'\0' ;
	_nBuffer				= 0 ;
	_nUnusedBuffer			= 0 ;
	_pCurBuffer				= NULL ;
	_nbufMessage			= 0 ;
	_wKeyEvent				= (WPARAM) 0 ;
	_lKeyEvent				= (LPARAM) 0 ;
	_fFilter				= TRUE ;
	_nThisCommand			= FUNCNO_INVALID_CHAR ;
	_nLastCommand			= FUNCNO_INVALID_CHAR ;
	_pstrPrefixList			= NULL ;
	for (i = 0 ; i < INPUTVECTORSIZE ; i ++) {
		_rstrInputVector [i]	= NULL ;
		_rstrZenkakuVector [i]	= NULL ;
	}
	_pbyJMap				= _rbyDefaultJMap ;
	_pbyAbbrevMap			= _rbyDefaultAbbrevMap ;
	return ;
}

/*	Copy Constructor�A�������A����͗��p����Ă͂Ȃ�Ȃ��B
 */
CImeDoc::CImeDoc (const CImeDoc& doc)
{
	return ;
	UNREFERENCED_PARAMETER (doc) ;
}

CImeDoc::~CImeDoc () 
{
	Uninit () ;
	return ;
}

/*========================================================================
 *	public methods
 */
BOOL
CImeDoc::Init ()
{
	register CImeBuffer*	pBuffer ;

	/*	����2�����������Ȃ���΁B
	 */
	CTCommunicateSession::InitPipeName () ;
	_InitConfig () ;

	_nBuffer			= 0 ;
	_nUnusedBuffer		= 0 ;
	pBuffer	= _CreateBuffer () ;
	if (pBuffer == NULL)
		return	FALSE ;
	_pCurBuffer			= pBuffer ;
	_nbufMessage		= 0 ;
	_nbufUnreadEvent	= 0 ;
	_nThisCommand		= FUNCNO_INVALID_CHAR ;
	_nLastCommand		= FUNCNO_INVALID_CHAR ;
	return	TRUE ;
}

BOOL
CImeDoc::Uninit ()
{
	register int	i ;

	for (i = 0 ; i < _nBuffer ; i ++) {
		delete	_rpBuffer [i] ;
		_rpBuffer [i]	= NULL ;
	}
	for (i = 0 ; i < _nUnusedBuffer ; i ++) {
		delete	_rpUnusedBuffer [i] ;
		_rpUnusedBuffer [i]	= NULL ;
	}
	_nBuffer = _nUnusedBuffer = 0 ;

	_UninitConfig () ;
	return	TRUE ;
}

/*	Init ����̏�Ԃɖ߂��B�������A�ݒ�t�@�C���͓ǂݒ����Ȃ��B
 *	Init ���I�������ԂłȂ��Ɩ����B
 */
BOOL
CImeDoc::Clear ()
{
	register CImeBuffer*	pBuffer ;
	register int			i ;

	ASSERT (_nBuffer > 0) ;

	DEBUGPRINTF ((TEXT ("CImeDoc::Clear ()\n"))) ;

	/*	�o�b�t�@�����͏�����Ԃɖ߂��B
	 */
	for (i = 0 ; i < _nBuffer ; i ++) {
		delete	_rpBuffer [i] ;
		_rpBuffer [i]	= NULL ;
	}
	for (i = 0 ; i < _nUnusedBuffer ; i ++) {
		delete	_rpUnusedBuffer [i] ;
		_rpUnusedBuffer [i]	= NULL ;
	}
	_nBuffer = _nUnusedBuffer = 0 ;
	pBuffer	= _CreateBuffer () ;
	if (pBuffer == NULL)
		return	FALSE ;
	_pCurBuffer			= pBuffer ;
	_nbufMessage		= 0 ;
	_nbufUnreadEvent	= 0 ;
	_nThisCommand		= FUNCNO_INVALID_CHAR ;
	_nLastCommand		= FUNCNO_INVALID_CHAR ;
	_lKeyEvent			= 0 ;
	_CandidateList._iStyle	= IMECANDSTYLE_UNUSED ;
	_MessageText._iStyle	= IMECANDSTYLE_UNUSED ;
	DEBUGPRINTF ((TEXT ("CImeDoc::Clear () -- exit (%d)\n"), (_rpBuffer [0] == _pCurBuffer))) ;
	return	TRUE ;
}

/*	�܂� Query ����A����Ǝ��� Filter ���Ă΂��B���̍\����
 *	TextServiceFramework �ɍ��킹�Ă���B
 */
BOOL
CImeDoc::QueryFilterKeyEvent (
	register WPARAM			wParam,
	register LPARAM			lParam,
	register BOOL*			pfEaten)
{
	register WCHAR		wch	= _GetCharFromWPARAM (wParam) ;

	ASSERT (pfEaten != NULL) ;

	if (wch == (WCHAR)-1) {
		*pfEaten	= FALSE ;
		return	TRUE ;
	}
	if (_rpBuffer [0] != _pCurBuffer) {
		*pfEaten	= TRUE ;
		return	TRUE ;
	}
	return	GetCurrentBuffer ()->QueryFilterKeyEvent (wch, pfEaten) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

BOOL
CImeDoc::QueryToggleIMEKeyEvent (
	register WPARAM			wParam,
	register LPARAM			lParam,
	register BOOL*			pfEaten)
{
	register WCHAR		wch	= _GetCharFromWPARAM (wParam) ;

	ASSERT (pfEaten != NULL) ;

	if (wch == (WCHAR)-1) {
		*pfEaten	= FALSE ;
		return	TRUE ;
	}
	return	GetCurrentBuffer ()->QueryToggleIMEKeyEvent (wch, pfEaten) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

BOOL
CImeDoc::FilterKeyEvent (
	register WPARAM			wParam,
	register LPARAM			lParam,
	register BOOL*			pfEaten)
{
	WCHAR		wchCurrentIn, wch ;
	BOOL		fEaten ;
	int			nMaxProcess ;

	ASSERT (pfEaten != NULL) ;

	/*	�܂����b�Z�[�W����������B*/
	ClearMessage () ;

	/*	���񉟂��ꂽ�L�[�̏����B
	 */
	_wKeyEvent			= wParam ;
	_lKeyEvent			= lParam ;
	_fFilter			= TRUE ;
	wchCurrentIn		= _GetCharFromWPARAM (wParam) ;
	_wchLastCommandChar	= wchCurrentIn ;
	if (_wchLastCommandChar == (WCHAR) -1)
		goto	Exit ;

	DEBUGPRINTF ((TEXT ("CImeDoc::FilterKeyEvent (w:0x%lx, ch:%d)\n"), wParam, _wchLastCommandChar)) ;
	GetCurrentBuffer ()->FilterKeyEvent () ;
	
	/*	�p�����ď������ׂ��C�x���g�͂��邩�H
	 */
	nMaxProcess	= MAX_PROCESS_UNREADEVENT ;
	while (nMaxProcess -- > 0 && _nbufUnreadEvent > 0) {
		wch	= _wchLastCommandChar = _bufUnreadEvent [-- _nbufUnreadEvent] ;
		DEBUGPRINTF ((TEXT ("CImeDoc::FilterKeyEvent -> (ch:0x%lx, lef:%d)\n"),
					  (int)wch, _nbufUnreadEvent)) ;
		if (_pCurBuffer == _rpBuffer [0]) {
			GetCurrentBuffer ()->QueryFilterKeyEvent (wch, &fEaten) ;
			if (! fEaten && _nbufUnreadEvent <= 0) {
				if (wch == wchCurrentIn) {
					DEBUGPRINTF ((TEXT ("CImeDoc -> *pfEaten = False\n"))) ;
					_fFilter	= FALSE ;
				}
				break ;
			}
		}
		GetCurrentBuffer ()->FilterKeyEvent () ;
	}
	_nbufUnreadEvent	= 0 ;
	_DeleteUnusedBuffer () ;
	_nLastCommand	= _nThisCommand ;
	_UpdateCandidateInfoForStatusText () ;

  Exit:
	DEBUGPRINTF ((TEXT ("CImeDoc -> *pfEaten = %d\n"), _fFilter)) ;
	*pfEaten		= _fFilter ;
	return	TRUE ;
}

LPCWSTR
CImeDoc::GetPreeditText (int* pnLength)
{
	ASSERT (_nBuffer > 0 && _rpBuffer [0] != NULL) ;

	return	_rpBuffer [0]->GetText (pnLength) ;
}

BOOL
CImeDoc::GetPreeditCursor (int* pnCursor) const
{
	ASSERT (_nBuffer > 0 && _rpBuffer [0] != NULL) ;
	ASSERT (pnCursor != NULL) ;

	*pnCursor	= _rpBuffer [0]->GetCursorPosition () ;
	return	TRUE ;
}

const IMECANDIDATES*
CImeDoc::GetStatusText () const
{
	if (_pCurBuffer->IsStatusActivep ()) {
		return	(_CandidateList._iStyle != IMECANDSTYLE_UNUSED)? &_CandidateList : NULL ;
	} else {
		if (_rpBuffer [0] != _pCurBuffer) 
			return	(_MessageText._iStyle != IMECANDSTYLE_UNUSED)? &_MessageText : NULL ;
	}
	return	NULL ;
}

BOOL
CImeDoc::GetStatusCursor (int* pnCursor) const
{
	ASSERT (pnCursor != NULL) ;

	if (_rpBuffer [0] == _pCurBuffer)
		return	FALSE ;
	*pnCursor	= _pCurBuffer->GetCursorPosition () ;
	return	TRUE ;
}

int
CImeDoc::GetReadingText (
	LPWSTR		wpDest,
	int			nDest,
	int*		pnPos)
{
	return	_rpBuffer [0]->GetReadingText (wpDest, nDest, pnPos) ;
}

BOOL
CImeDoc::GetConvertedRegion (
	int* 	pnBegin,
	int*	pnEnd) const
{
	ASSERT (_rpBuffer [0] != NULL) ;
		
	return	_rpBuffer [0]->GetConvertedRegion (pnBegin, pnEnd) ;
}

BOOL
CImeDoc::GetSelectedRegion (
	int*	pnBegin,
	int*	pnEnd) const
{
	ASSERT (_pCurBuffer != NULL) ;
	return	_pCurBuffer->GetSelectedRegion (pnBegin, pnEnd) ;
}

BOOL
CImeDoc::SetConversionMode (
	register int		nMode)
{
	if (_rpBuffer [0] == NULL)
		return	FALSE ;
	return	_rpBuffer [0]->SetConversionMode (nMode) ;
}

int
CImeDoc::GetConversionMode () const 
{
	ASSERT (_rpBuffer [0] != NULL) ;
	return	_rpBuffer [0]->GetConversionMode () ;
}

BOOL
CImeDoc::IsStatusActivep () const
{
	return	(_rpBuffer [0] != _pCurBuffer || _rpBuffer [0]->IsStatusActivep ()) ;
}

BOOL
CImeDoc::QueryUpdateContext (
	register int*		pnShift,
	register int*		pnCursor,
	register BOOL*		pfContinue)
{
	ASSERT (_rpBuffer [0] != NULL) ;
	ASSERT (pnShift    != NULL) ;
	ASSERT (pnCursor   != NULL) ;
	ASSERT (pfContinue != NULL) ;

	if (_rpBuffer [0] != _pCurBuffer) {
		*pnShift	= 0 ;
		*pnCursor	= _rpBuffer [0]->GetCursorPosition () ;
		*pfContinue	= TRUE ;
		return	TRUE ;
	}
	return	_rpBuffer [0]->QueryUpdateContext (pnShift, pnCursor, pfContinue) ;
}

BOOL
CImeDoc::UpdateContext ()
{
	ASSERT (_rpBuffer [0] != NULL) ;

	if (_rpBuffer [0] != _pCurBuffer) 
		return	TRUE ;

	return	_rpBuffer [0]->UpdateContext () ;
}

void
CImeDoc::UpdateConfig ()
{
	_UninitConfig () ;
	_InitConfig () ;
	return ;
}

BOOL
CImeDoc::SetReconvertText (
	register LPCWSTR		wstrTEXT,
	register int			nstrTEXT)
{
	Clear () ;
	return	GetCurrentBuffer ()->SetReconvertText (wstrTEXT, nstrTEXT) ;
}

/*========================================================================*
 *	``library local'' public methods
 */
/*	keymap ���ꎩ�g�� buffer ���ꂼ��ɓƗ��ł��邪�AIme �Ƃ��ĕʂ� c++-mode
 *	�� buffer �ɓK�p����Ă���ȂǂƂ������Ƃ͂��肦�Ȃ��B
 *
 *	�䂦�ɋ��ʂ̂��̂Ƃ��āADocument �̒��Œ�`����B
 */
BOOL
CImeDoc::LookupKeymap (
	register WCHAR			wch,
	register int* 			pnFuncNo) const
{
	register int	nKeymap, nFuncNo ;

	if (_pCurBuffer == NULL || pnFuncNo == NULL)
		return	FALSE ;

	if (!(0 <= wch && wch < SIZE_IMEDOC_KEYMAP)) {
		*pnFuncNo	= FUNCNO_INVALID_CHAR ;
		return	TRUE ;
	}
	nKeymap	= _pCurBuffer->GetKeymap () ;
	switch (nKeymap) {
	case	IMEKEYMAP_ASCII:
		if (0x20 <= wch && wch < 0x7F) {
			nFuncNo	= FUNCNO_SELF_INSERT_CHARACTER ;
		} else if (wch == 0x0D) {
			nFuncNo	= FUNCNO_NEWLINE ;
		} else {
			nFuncNo	= _pbyJMap [wch] ;
		}
		break ;
	case	IMEKEYMAP_ZENKAKU:
		if (0x20 <= wch && wch < 0x7F) {
			nFuncNo	= FUNCNO_J_ZENKAKU_INSERT ;
		} else if (wch == 0x0D) {
			nFuncNo	= FUNCNO_NEWLINE ;
		} else {
			nFuncNo	= _pbyJMap [wch] ;
		}
		break ;
	case	IMEKEYMAP_ABBREV:
		nFuncNo		= _pbyAbbrevMap [wch] ;
		break ;
	case	IMEKEYMAP_JMODE:
	default:
		nFuncNo		= _pbyJMap [wch] ;
		break ;
	}
	*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

BOOL
CImeDoc::SetUnreadCommandChar (
	register int			ch)
{
	if (_nbufUnreadEvent >= MAXUNREADEVENT)
		return	FALSE ;
	_bufUnreadEvent [_nbufUnreadEvent ++]	= (WCHAR) ch ;
	return	TRUE ;
}

BOOL
CImeDoc::SetLastCommandChar (
	register int			ch)
{
	_wchLastCommandChar	= (WCHAR) ch ;
	return	TRUE ;
}

int
CImeDoc::GetLastCommandChar () const
{
	return	_wchLastCommandChar ;
}

int
CImeDoc::GetThisCommand () const
{
	return	_nThisCommand ;
}

BOOL
CImeDoc::SetThisCommand (
	register int			nFuncNo)
{
	_nThisCommand	= nFuncNo ;
	return	TRUE ;
}

int
CImeDoc::GetLastCommand () const
{
	return	_nLastCommand ;
}

BOOL
CImeDoc::SetLastCommand (
	register int			nFuncNo)
{
	_nLastCommand	= nFuncNo ;
	return	TRUE ;
}

BOOL
CImeDoc::UnprocessChar (
	register int			ch)
{
	if (_GetCharFromWPARAM (_wKeyEvent) == (WCHAR) ch) {
		DEBUGPRINTF ((TEXT ("CImeDoc::UnprocessChar (0x%x)\n"), (int)ch)) ;
		_fFilter	= FALSE ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

/*	�b��B
 */
const CTAssocRule*
CImeDoc::JAssocRule (
	register LPCWSTR		wstr,
	register int			nwstr)
{
	register CTAssocRule**	ppRule ;
	register int			n ;
	register LPCWSTR		wstrState ;

	ppRule	= _rpAssocRule ;
	n		= _nAssocRule ;
	while (n -- > 0) {
		wstrState	= (*ppRule)->GetState () ;
		if (! wcsncmp (wstr, wstrState, nwstr) && 
			*(wstrState + nwstr) == L'\0')
			return	*ppRule ;	/* hit */
		ppRule	++ ;
	}
	return	NULL ;
}

CTRomaKanaTable*
CImeDoc::GetRomaKana (
	register int			ch)
{
	static const char		rchVowel[] = { 'a', 'i', 'u', 'e', 'o' } ;
	register const char*	pch ;
	
	pch	= (const char*)memchr (rchVowel, ch, NELEMENTS (rchVowel)) ;
	if (pch == NULL)
		return	NULL ;
	return	_rpRomaKanaTable + (pch - rchVowel) ;
}

BOOL
CImeDoc::IsSkkDeleteOkuriWhenQuitp () const
{
	return	_rnGenericConfig [GC_DELETE_OKURI_WHEN_QUIT] != 0 ;
}

BOOL
CImeDoc::IsSkkProcessOkuriEarlyp () const
{
	return	_rnGenericConfig [GC_PROCESS_OKURI_EARLY] != 0 ;
}

BOOL
CImeDoc::IsSkkKakuteiEarlyp () const
{
	return	_rnGenericConfig [GC_KAKUTEI_EARLY] != 0 ;
}

BOOL
CImeDoc::IsJKakuteiEarlyp () const
{
	return	IsSkkKakuteiEarlyp () && ! IsSkkProcessOkuriEarlyp () ;
}

BOOL
CImeDoc::IsSkkEggLikeNewlinep () const
{
	return	_rnGenericConfig [GC_EGG_LIKE_NEWLINE] != 0 ;
}

BOOL
CImeDoc::IsSkkUseNumericConversionp () const
{
	return	_rnGenericConfig [GC_USE_NUMERIC_CONVERSION] != 0 ;
}

BOOL
CImeDoc::IsSkkDabbrevLikeCompletion () const
{
	return	_rnGenericConfig [GC_DABBREV_LIKE_COMPLETION] != 0 ;
}

BOOL
CImeDoc::IsSkkDeleteImpliesKakuteip () const
{
	return	_rnGenericConfig [GC_DELETE_IMPLIES_KAKUTEI] != 0 ;
}

BOOL
CImeDoc::IsSkkKatakanaHiraganaHenkanp () const 
{
	return	_rnGenericConfig [GC_KATAKANA_HIRAGANA_HENKAN] != 0 ;
}

BOOL
CImeDoc::IsSkkShowAnnotationp () const 
{
	return	_rnGenericConfig [GC_SHOW_ANNOTATION] != 0 ;
}

int
CImeDoc::GetSkkDateAd () const
{
	return	_rnGenericConfig [GC_DATE_AD] ;
}

int
CImeDoc::GetSkkNumberStyle () const
{
	return	_rnGenericConfig [GC_STYLE] ;
}

LPCWSTR
CImeDoc::GetSkkInputVector (
	register int			wch,
	register int*			pnWord) const 
{
	register LPCWSTR	wstrRetval ;
	register int		nIndex ;

	ASSERT (pnWord != NULL) ;

	nIndex	= (int) wch - 32 ;
	if (0 <= nIndex && nIndex < INPUTVECTORSIZE) {
		wstrRetval	= _rstrInputVector [nIndex] ;
	} else {
		wstrRetval	= NULL ;
	}
	*pnWord	= (wstrRetval != NULL)? wcslen (wstrRetval) : 0 ;
	return	wstrRetval ;
}

LPCWSTR
CImeDoc::GetSkkZenkakuVector (
	register int			wch,
	register int*			pnWord) const
{
	register LPCWSTR	wstrRetval ;
	register int		nIndex ;

	ASSERT (pnWord != NULL) ;

	nIndex	= (int) wch - 32 ;
	if (0 <= nIndex && nIndex < INPUTVECTORSIZE) {
		wstrRetval	= _rstrZenkakuVector [nIndex] ;
	} else {
		wstrRetval	= NULL ;
	}
	*pnWord	= (wstrRetval != NULL)? wcslen (wstrRetval) : 0 ;
	return	wstrRetval ;
}

BOOL
CImeDoc::IsValidPrefixp (
	register LPCWSTR		wstr,
	register int			nwstr) const
{
	if (_pstrPrefixList == NULL) {
		register int		i ;

		for (i = 0 ; i < NELEMENTS (_rstrDefaultPrefixList) ; i ++) {
			if (! wcsncmp (wstr, _rstrDefaultPrefixList [i], nwstr) &&
				*(_rstrDefaultPrefixList [i] + nwstr) == L'\0') 
				return	TRUE ;
		}
	} else {
		register LPCWSTR	wptr ;
		register int		n ;

		wptr	= _pstrPrefixList ;
		while (n = wcslen (wptr), n > 0) {
			if (n == nwstr && ! wcsncmp (wstr, wptr, nwstr))
				return	TRUE ;
			wptr	+= n + 1 ;
		}
	}
	return	FALSE ;
}

const BYTE*
CImeDoc::GetJHenkanShowCandidateKeys (int *pnKeys) const
{
	if (pnKeys != NULL)
		*pnKeys	= ARRAYSIZE (_JHenkanShowCandidateKeys) ;
	return	_JHenkanShowCandidateKeys ;
}

const BYTE*
CImeDoc::GetJInputByCodeOrMenuKeys1 (int *pnKeys) const
{
	if (pnKeys != NULL)
		*pnKeys	= ARRAYSIZE (_JInputByCodeOrMenuKeys1) ;
	return	_JInputByCodeOrMenuKeys1 ;
}

const BYTE*
CImeDoc::GetJInputByCodeOrMenuKeys2 (int *pnKeys) const
{
	if (pnKeys != NULL)
		*pnKeys	= ARRAYSIZE (_JInputByCodeOrMenuKeys2) ;
	return	_JInputByCodeOrMenuKeys2 ;
}

CImeBuffer*
CImeDoc::GetCurrentBuffer ()
{
	ASSERT (_pCurBuffer != NULL) ;
	return	_pCurBuffer ;
}

BOOL
CImeDoc::ReadFromMinibuffer (
	register LPCWSTR					wstrMessage,
	register int						nstrMessage,
	register CTImeRecursiveEditSession*	pSession)
{
	register CImeBuffer*	pBuffer ;

	pBuffer	= _CreateBuffer (wstrMessage, nstrMessage, pSession) ;
	if (pBuffer == NULL) {
		if (pSession != NULL)
			delete	pSession ;
		return	FALSE ;
	}
	_pCurBuffer	= pBuffer ;
	return	TRUE ;
}

BOOL
CImeDoc::ExitMinibuffer (
	register CImeBuffer*			pDestBuffer)
{
	register CImeBuffer*	pSrcBuffer ;
	register int			i, nSrc, nDest ;

	pSrcBuffer	= GetCurrentBuffer () ;
	if (pSrcBuffer == pDestBuffer)
		return	TRUE ;

	nSrc = nDest = -1 ;
	for (i = 0 ; i < _nBuffer ; i ++) {
		if (_rpBuffer [i] == pSrcBuffer) {
			nSrc	= i ;
			continue ;
		}
		if (_rpBuffer [i] == pDestBuffer) {
			nDest	= i ;
			continue ;
		}
	}
	if (nSrc < 0 || nDest < 0)
		return	FALSE ;

	_rpUnusedBuffer [_nUnusedBuffer ++]	= pSrcBuffer ;
	_rpBuffer [nSrc]	= NULL ;
	if (nSrc == (_nBuffer - 1))
		_nBuffer	-- ;
	_pCurBuffer			= pDestBuffer ;
	return	TRUE ;
}

BOOL
CImeDoc::SetMessage (
	register LPCWSTR				wstrMessage,
	register int					nstrMessage)
{
	ASSERT (wstrMessage != NULL || nstrMessage == 0) ;

	_nbufMessage	= (nstrMessage > MSGBUFSIZE)? MSGBUFSIZE : nstrMessage ;
	if (wstrMessage != NULL)
		memcpy (_bufMessage, wstrMessage, _nbufMessage * sizeof (WCHAR)) ;
	return	TRUE ;
}

BOOL
CImeDoc::SetMessage (
	register LPCWSTR				wstrMessage)
{
	ASSERT (wstrMessage != NULL) ;
	return	SetMessage (wstrMessage, wcslen (wstrMessage)) ;
}

LPCWSTR
CImeDoc::GetMessage (
	int*			piMessageLen) const
{
	if (piMessageLen != NULL)
		*piMessageLen	= _nbufMessage ;

	return	_bufMessage ;
}

BOOL
CImeDoc::HaveMessagep () const
{
	return	(_nbufMessage > 0) ;
}

BOOL
CImeDoc::ClearMessage ()
{
	_nbufMessage		= 0 ;
	return	TRUE ;
}

BOOL
CImeDoc::RecursiveEditp () const
{
	return	(_pCurBuffer != _rpBuffer [0]) ;
}

IMECANDIDATES*
CImeDoc::GetCandidateInfoBuffer ()
{
	return	&_CandidateList ;
}

int
CImeDoc::GetCandidateText (
	LPWSTR					strDest,
	int						nDest,
	TEXTREGION*				pTextHead,
	int*					piNumText,
	const IMECANDIDATES*	pMyCand)
{
	LPWSTR		pDest ;
	int			iCount, nKeys, iNumText ;
	UINT		iPageStart, iNextPage, iMaxPage, i ;
	TEXTREGION*	pText ;
	TEXTREGION*	pTextLast ;
	const UINT*	piPageIndex ;
	WCHAR		ch ;
	const BYTE*	pCandKeyTbl ;

	pDest		= strDest ;
	iCount		= 0 ;
	piPageIndex	= pMyCand->_vbufPageIndex.GetBuffer () ;
	iMaxPage	= pMyCand->_vbufPageIndex.GetUsage () ;
	iPageStart	= piPageIndex [pMyCand->_iCurrentPage] ;
	iNextPage	= ((pMyCand->_iCurrentPage + 1) < iMaxPage)? (piPageIndex [pMyCand->_iCurrentPage + 1]) : pMyCand->_iCount ;
	i			= iPageStart ;
	pCandKeyTbl	= GetJHenkanShowCandidateKeys (&nKeys) ;

	iNumText	= (piNumText != NULL)? *piNumText : 0 ;
	pText		= pTextHead ;
	if (piNumText != NULL && pText != NULL) {
		pTextLast	= pText + iNumText ;
	} else {
		pTextLast	= NULL ;
	}
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPWSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		wcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < iNextPage && i < pMyCand->_iCount && iCount < nKeys && nDest > 0) {
		LPCWSTR		pwCandidate ;
		int			nIndex, nCandLen ;

		ch			= (WCHAR)*(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *(pMyCand->_vbufCandidateIndex.GetBuffer () + i) ;
		nCandLen	= lstrlenW (pwCandidate) ;
		nIndex		= _HasWordAnnotation (pwCandidate, nCandLen) ;
		if (nIndex > 0) 
			nCandLen	= nIndex ;

		/*	���� annotation �����݂���ꍇ�B*/
		if (pText != NULL && pText < pTextLast) {
			if (nDest > 0 && nIndex > 0) {
				pText->m_nCandidate	= i ;
				pText->m_nOffset	= pDest - strDest ;
				pText->m_nLength	= (nDest < nCandLen)? nDest : nCandLen ;
			} else {
				pText->m_nCandidate	= 0 ;
				pText->m_nOffset	= 0 ;
				pText->m_nLength	= 0 ;
			}
			pText	++ ;
		}
		SAFE_COPY (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
	if (nDest > 0) {
		WCHAR	buffer [32] ;
		int		n ;
		n	= wnsprintfW (buffer, ARRAYSIZE (buffer), L" [�c�� %d]", pMyCand->_iCount - i) ;
		SAFE_COPY (pDest, nDest, buffer, n) ;
	}
	if (pText != NULL && piNumText != NULL)
		*piNumText	= pText - pTextHead ;

#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

int
CImeDoc::GetCodeMenuJumpText (
	LPWSTR					strDest,
	int						nDest,
	const IMECANDIDATES*	pMyCand)
{
	LPWSTR		pDest ;
	int			iCount, nKeys ;
	UINT		iPageStart, iNextPage, iMaxPage, i ;
	const UINT*	piPageIndex ;
	WCHAR		ch ;
	const BYTE*	pCandKeyTbl ;

	pDest		= strDest ;
	iCount		= 0 ;
	piPageIndex	= pMyCand->_vbufPageIndex.GetBuffer () ;
	iMaxPage	= pMyCand->_vbufPageIndex.GetUsage () ;
	iPageStart	= piPageIndex [pMyCand->_iCurrentPage] ;
	iNextPage	= ((pMyCand->_iCurrentPage + 1) < iMaxPage)? (piPageIndex [pMyCand->_iCurrentPage + 1]) : pMyCand->_iCount ;
	i			= iPageStart ;
	pCandKeyTbl	= GetJInputByCodeOrMenuKeys1 (&nKeys) ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPWSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		wcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < iNextPage && i < pMyCand->_iCount && iCount < nKeys && nDest > 0) {
		LPCWSTR		pwCandidate ;
		int			nCandLen ;

		ch			= (WCHAR)*(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *(pMyCand->_vbufCandidateIndex.GetBuffer () + i) ;
		nCandLen	= lstrlenW (pwCandidate) ;

		SAFE_COPY (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

int
CImeDoc::GetCodeMenu1Text (
	LPWSTR					strDest,
	int						nDest,
	const IMECANDIDATES*	pMyCand)
{
	LPWSTR		pDest ;
	int			iCount, nKeys ;
	UINT		iPageStart, iNextPage, iMaxPage, i ;
	const UINT*	piPageIndex ;
	WCHAR		ch ;
	const BYTE*	pCandKeyTbl ;

	pDest		= strDest ;
	iCount		= 0 ;
	piPageIndex	= pMyCand->_vbufPageIndex.GetBuffer () ;
	iMaxPage	= pMyCand->_vbufPageIndex.GetUsage () ;
	iPageStart	= piPageIndex [pMyCand->_iCurrentPage] ;
	iNextPage	= ((pMyCand->_iCurrentPage + 1) < iMaxPage)? (piPageIndex [pMyCand->_iCurrentPage + 1]) : pMyCand->_iCount ;
	i			= iPageStart ;
	pCandKeyTbl	= GetJInputByCodeOrMenuKeys2 (&nKeys) ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPWSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		wcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < iNextPage && i < pMyCand->_iCount && iCount < nKeys && nDest > 0) {
		LPCWSTR		pwCandidate ;
		int			nCandLen ;

		ch			= (WCHAR)*(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((const int*)pMyCand->_vbufCandidateIndex.GetBuffer () + i) ;
		nCandLen	= lstrlenW (pwCandidate) ;

		SAFE_COPY (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

/*========================================================================
 *	private methods
 */
BOOL
CImeDoc::_InitConfig ()
{
	if (!_InitGenericConfig () ||
		!_InitKeymap () ||
		!_InitRomaKanaTable () ||
		!_InitJAssocRule () ||
		!_InitPrefixList () ||
		!_InitInputVector () ||
		!_InitZenkakuVector () ||
		!_InitCandidateSelectKeys ())
		return	FALSE ;
	return	TRUE ;
}

void
CImeDoc::_UninitConfig ()
{
	register int	i ;

	for (i = 0 ; i < INPUTVECTORSIZE ; i ++) {
		if (_rstrZenkakuVector [i] != NULL) {
			delete []	_rstrZenkakuVector [i] ;
			_rstrZenkakuVector [i]	= NULL ;
		}
		if (_rstrInputVector [i] != NULL) {
			delete []	_rstrInputVector [i] ;
			_rstrInputVector [i]	= NULL ;
		}
	}
	if (_pstrPrefixList != NULL) {
		delete[]	_pstrPrefixList ;
		_pstrPrefixList	= NULL ;
	}
	if (_rpRomaKanaTable != NULL) {
		delete[]	_rpRomaKanaTable ;
		_rpRomaKanaTable	= NULL ;
	}
	if (_rpAssocRule != NULL) {
		for (i = 0 ; i < _nAssocRule ; i ++) {
			if (_rpAssocRule [i] != NULL) {
				delete	_rpAssocRule [i] ;
				_rpAssocRule [i]	= NULL ;
			}
		}
		delete[]	_rpAssocRule ;
		_rpAssocRule	= NULL ;
		_nAssocRule		= 0 ;
	}
	return ;
}

BOOL
CImeDoc::_InitGenericConfig ()
{
	static LPCWSTR		rwstrEntries [NUMGENERICCONFIG]	= {
		REGPATH_EGG_LIKE_NEWLINE,			REGPATH_DELETE_IMPLIES_KAKUTEI,
		REGPATH_USE_NUMERIC_CONVERSION,		REGPATH_DABBREV_LIKE_COMPLETION,
		REGPATH_KATAKANA_HIRAGANA_HENKAN,	REGPATH_NUMERIC_STYLE,
		REGPATH_DATE_AD,					REGPATH_SHOW_ANNOTATION,
		REGPATH_KAKUTEI_EARLY,				REGPATH_PROCESS_OKURI_EARLY,
		REGPATH_DELETE_OKURI_WHEN_QUIT
	} ;
	static int			rnDefaultValues [NUMGENERICCONFIG]	= {
		TRUE,								TRUE,
		TRUE,								FALSE,
		TRUE,								0,
		0,									FALSE,
		TRUE,								FALSE,
		FALSE
	} ;
	HKEY			hSubKey ;
	LONG			lResult ;
	register int	i ;

	lResult	= RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) ;
	if (lResult == ERROR_SUCCESS) {
		DWORD	dwType, dwValue, cbData ;

		for (i = 0 ; i < NELEMENTS (rwstrEntries) ; i ++) {
			cbData	= sizeof (dwValue) ;
			lResult	= RegQueryValueExW (hSubKey, rwstrEntries [i], NULL, &dwType, (LPBYTE)&dwValue, &cbData) ;
			if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
				_rnGenericConfig [i]	= (int) dwValue ;
			} else {
				_rnGenericConfig [i]	= rnDefaultValues [i] ;
			}
		}
		RegCloseKey (hSubKey) ;
	} else {
		for (i = 0 ; i < NELEMENTS (rwstrEntries) ; i ++) 
			_rnGenericConfig [i]	= rnDefaultValues [i] ;
	}
	return	TRUE ;
}

BOOL
CImeDoc::_InitKeymap ()
{
	register BOOL	fFoundAbbrevMap, fFoundNormalMap ;
	register int	i ;
	HKEY	hSubKey ;
	BYTE	rbyKeyMap [SIZE_MYKEYMAP] ;

	fFoundNormalMap	= FALSE ;
	fFoundAbbrevMap	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;
		
		/*	j-map ���̏����B*/
		cbData	= sizeof (rbyKeyMap) ;
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JMAP, NULL, &dwType, rbyKeyMap, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY) {
			register int	nData	= (int) cbData ;

			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < nData && i < SIZE_MYKEYMAP ; i ++) {
				if (rbyKeyMap [i] >= NUM_FUNCTIONS) {
					_rbyJMap [i]	= FUNCNO_INVALID_CHAR ;
				} else {
					_rbyJMap [i]	= rbyKeyMap [i] ;
				}
			}
			for (i = SIZE_MYKEYMAP ; i < SIZE_IMEDOC_KEYMAP ; i ++)
				_rbyJMap [i]	= _rbyDefaultJMap [i] ;
			fFoundNormalMap	= TRUE ;
		}
		/*	j-abbrev-map ���̏����B*/
		cbData	= sizeof (rbyKeyMap) ;
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JABBREVMAP, NULL, &dwType, rbyKeyMap, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY) {
			register int	nData	= (int) cbData ;
			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < nData && i < SIZE_MYKEYMAP ; i ++) {
				if (rbyKeyMap [i] >= NUM_FUNCTIONS) {
					_rbyAbbrevMap [i]	= FUNCNO_INVALID_CHAR ;
				} else {
					_rbyAbbrevMap [i]	= rbyKeyMap [i] ;
				}
			}
			for (i = SIZE_MYKEYMAP ; i < SIZE_IMEDOC_KEYMAP ; i ++)
				_rbyAbbrevMap [i]	= _rbyDefaultAbbrevMap [i] ;
			fFoundAbbrevMap	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	_pbyJMap		= (fFoundNormalMap)? _rbyJMap : _rbyDefaultJMap ;
	_pbyAbbrevMap	= (fFoundAbbrevMap)? _rbyAbbrevMap : _rbyDefaultAbbrevMap ;
	return	TRUE ;

}

BOOL
CImeDoc::_InitRomaKanaTable ()
{
	static const int			rch []	= { 'a', 'i', 'u', 'e', 'o' } ;
	register CTRomaKanaTable*	pRomaKanaTable ;
	register int				i ;

	ASSERT (_rpRomaKanaTable == NULL) ;

	_rpRomaKanaTable	= new CTRomaKanaTable [MAXROMAKANATABLE] ;
	if (_rpRomaKanaTable == NULL)
		return	FALSE ;

	pRomaKanaTable		= _rpRomaKanaTable ;
	for (i = 0 ; i < MAXROMAKANATABLE ; i ++) {
		if (! pRomaKanaTable->Init (rch [i])) 
			return	FALSE ;
		pRomaKanaTable	++ ;
	}
	return	TRUE ;
}

BOOL
CImeDoc::_InitJAssocRule ()
{
	HKEY					hSubKey ;
	WCHAR					szRegPathInfo [MAX_PATH] ;
	WCHAR					rbyData [MAX_REGVALUE_SIZE] ;
	DWORD					dwRegPathInfo, dwType, cbData ;
	register LONG			lResult ;
	register int			nIndex, i ;
	register CTAssocRule*	pAssocRule ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_ROMAKANARULELIST, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		register BOOL	fError	= FALSE ;

		/*	���[�}�������ϊ��e�[�u�����o�^����Ă���̂Ȃ�c�B*/
		for (nIndex = 0 ; nIndex < MAXASSOCRULE ; nIndex ++) {
			register int		nStateLen = 0, nNextLen = 0, nHoutputLen = 0, nKoutputLen = 0 ;

			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= NELEMENTS (rbyData) ;
			lResult	= RegEnumValueW (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;

			/*	szRegPathInfo = "nn" �̂悤�� szRegPathInfo ���u����ԁv�ɑ�������B
			 *	���R�� (�����, �����, �o��) �Ȃ̂ŁA����Ԃ������d�Ȃ邱�Ƃ͂���
			 *	�Ă͂Ȃ�Ȃ�����B
			 *	����Ԃ��u��v�͂��蓾��B
			 */
			lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ)
				continue ;
			/*	Too big value. */
			if (cbData >= sizeof (rbyData)) 
				continue ;
			cbData		= sizeof (rbyData) ;
			(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE *)rbyData, &cbData) ;
			
			nKoutputLen	= 0 ;
			if (L'1' <= szRegPathInfo [0] && szRegPathInfo [0] <= L'9') {
				nStateLen	= wcslen (rbyData) ;
				nNextLen	= (nStateLen   > 0)? wcslen (rbyData + nStateLen + 1) : 0 ;
				nHoutputLen	= (nNextLen    > 0)? wcslen (rbyData + nStateLen + 1 + nNextLen + 1) : 0 ;
				if (nStateLen <= 0 || nNextLen < 1 || nHoutputLen < 1) {
					fError	= TRUE ;
					break ;
				}
				/*	nKoutputLen == 0 �̏ꍇ�ɂ́A�]���� assoc rule �̉\��������B
				 *	�]���� (next, hira, kata) �� 3 ���������Acase ���l������
				 *	(now, next, hira, kata) �� 4 �g�ɂ����̂ŁB
				 */
				nKoutputLen	= (nHoutputLen > 0)? wcslen (rbyData + nStateLen + 1 + nNextLen + 1 + nHoutputLen + 1) : 0 ;
			}
			if (nKoutputLen <= 0) {
				nStateLen	= wcslen (szRegPathInfo) ;
				nNextLen	= wcslen (rbyData) ;
				nHoutputLen	= (nNextLen    > 0)? wcslen (rbyData + nNextLen + 1) : 0 ;
				nKoutputLen	= (nHoutputLen > 0)? wcslen (rbyData + nNextLen + 1 + nHoutputLen + 1) : 0 ;
			}
			if (nStateLen <= 0 || nNextLen  <  1 || nHoutputLen < 1 || nKoutputLen < 1) {
				fError	= TRUE ;
				break ;
			}
		}
		_nAssocRule		= nIndex ;
		_rpAssocRule	= new CTAssocRule* [_nAssocRule] ;
		for (i = 0 ; i < nIndex ; i ++) {
			register LPCWSTR	wstrState, wstrNext, wstrHiragana, wstrKatakana ;

			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= NELEMENTS (rbyData) ;
			lResult	= RegEnumValueW (hSubKey, (DWORD)i, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;

			/*	szRegPathInfo = "nn" �̂悤�� szRegPathInfo ���u����ԁv�ɑ�������B
			 *	���R�� (�����, �����, �o��) �Ȃ̂ŁA����Ԃ������d�Ȃ邱�Ƃ͂���
			 *	�Ă͂Ȃ�Ȃ�����B
			 *	����Ԃ��u��v�͂��蓾��B
			 */
			lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ)
				continue ;
			/*	Too big value. */
			if (cbData >= sizeof (rbyData)) 
				continue ;
			cbData		= sizeof (rbyData) ;
			(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE *)rbyData, &cbData) ;
			
			if (L'1' <= szRegPathInfo [0] && szRegPathInfo [0] <= L'9') {
				wstrState		= rbyData ;
				wstrNext		= wstrState		+ wcslen (wstrState)	+ 1 ;
				wstrHiragana	= wstrNext		+ wcslen (wstrNext)		+ 1 ;
				wstrKatakana	= wstrHiragana	+ wcslen (wstrHiragana)	+ 1 ;
				if (*wstrKatakana == L'\0') {
					/* traditional �ȏ󋵂ł���Ɖ��߂���B*/
					wstrKatakana	= wstrHiragana ;
					wstrHiragana	= wstrNext ;
					wstrNext		= wstrState ;
					wstrState		= szRegPathInfo ;
				}
			} else {
				wstrState		= szRegPathInfo ;
				wstrNext		= rbyData ;
				wstrHiragana	= wstrNext     + wcslen (wstrNext)     + 1 ;
				wstrKatakana	= wstrHiragana + wcslen (wstrHiragana) + 1 ;
			}

			pAssocRule		= new CTDynamicAssocRule () ;
			if (pAssocRule != NULL) {
				pAssocRule->Init (wstrState, wstrNext + 1, wstrKatakana + 1, wstrHiragana + 1) ;
				_rpAssocRule [i]	= pAssocRule ;
			}
		}
		RegCloseKey (hSubKey) ;
		if (fError)
			return	FALSE ;
	} else {
		static	LPCWSTR		srDefaultAssocRule [][4] = {
			{	L"nn",	NULL,	L"��",	L"��" },
			{	L"n'",	NULL,	L"��",	L"��" },
		} ;
		register LPCWSTR		(*pSrc)[4] ;
		register int			i ;
		
		/*	����� default �̏������̂݁B��ł�����Ɛݒ��ǂނ悤�ɂ�
		 *	�Ȃ���΂Ȃ�Ȃ��B
		 */
		_nAssocRule		= NELEMENTS (srDefaultAssocRule) ;
		_rpAssocRule	= new CTAssocRule* [_nAssocRule] ;
		if (_rpAssocRule == NULL) {
			_nAssocRule	= 0 ;
			return	FALSE ;
		}
		pSrc	= srDefaultAssocRule ;
		for (i = 0 ; i < NELEMENTS (srDefaultAssocRule) ; i ++) 
			_rpAssocRule [i]	= new CTStaticAssocRule (*pSrc ++) ;
		return	TRUE ;
	}
	return	TRUE ;
}

BOOL
CImeDoc::_InitPrefixList ()
{
	HKEY						hSubKey ;
	register BOOL				fRetval	= FALSE ;
	WCHAR						rbyData [MAX_REGVALUE_SIZE] ;
	register int				nPrefix, nLength ;
	BYTE*						pbData	= NULL ;

	_pstrPrefixList	= NULL ;
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_PREFIXLIST, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		register LONG		lResult ;
		register LPCWSTR	pPrefix ;
		DWORD				cbData, dwType ;

		lResult = RegQueryValueExW (hSubKey, NULL, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ) 
			goto	exit_regopen ;
		
		/*	cbData �ɂ͕K�v�ʂ����ɓ����Ă���̂ŁA��������̂܂܎g���B*/
		if (cbData < sizeof (rbyData)) {
			pbData	= (BYTE*) rbyData ;
			cbData	= sizeof (rbyData) ;
		} else {
			pbData	= new BYTE [cbData] ;
			if (pbData == NULL)
				goto	exit_regopen ;
		}
		(void) RegQueryValueExW (hSubKey, NULL, NULL, NULL, pbData, &cbData) ;
		
		/*	parse ����B*/
		pPrefix	= (LPCWSTR) pbData ;
		nLength	= 0 ;
		while (nPrefix = wcslen (pPrefix), nPrefix > 0) {
			if (nPrefix < MAX_LENGTH_KANAPREFIX) {
				nLength		+= (nPrefix + 1) ;
				/*	pPrefix, nPrefix */
			}
			pPrefix			+= (nPrefix + 1) ;
		}
		_pstrPrefixList	= new WCHAR [nLength + 1] ;
		if (_pstrPrefixList != NULL) {
			memcpy (_pstrPrefixList, rbyData, nLength * sizeof (WCHAR)) ;
			_pstrPrefixList [nLength]	= L'\0' ;
			fRetval	= TRUE ;
		}
 exit_regopen:
		if (pbData != NULL && pbData != (BYTE*)rbyData) {
			delete[]	pbData ;
			pbData	= NULL ;
		}
		RegCloseKey (hSubKey) ;
	}
	return	TRUE ;
}

BOOL
CImeDoc::_InitInputVector ()
{
	static	const struct {
		WCHAR	_wch ;
		LPCWSTR	_wstr ;
	}	srSkkinputDefaultInputVector []	= {
		{ L'!',	L"�I", },	{ L',',	L"�A", },
		{ L'-',	L"�[", },	{ L'.',	L"�B", },
		{ L':',	L"�F", },	{ L';',	L"�G", },
		{ L'?',	L"�H", },	{ L'[',	L"�u", },
		{ L']',	L"�v", },
	} ;
	HKEY				hSubKey ;
	WCHAR				szRegPathInfo [MAX_PATH] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	long				lValue ;
	register int		nIndex, i ;
	register LONG		lResult ;
	register BOOL		fRetval	= TRUE ;
	register LPWSTR		pDest ;

	for (i = 0 ; i < INPUTVECTORSIZE ; i++)
		_rstrInputVector [i]	= NULL ;
	
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_INPUTVECTOR, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
		register LPCWSTR	wptr ;
		for (i = 0 ; i < NELEMENTS (srSkkinputDefaultInputVector) ; i ++) {
			nIndex	= (int) srSkkinputDefaultInputVector [i]._wch - 32 ;
			ASSERT (0 <= nIndex && nIndex < INPUTVECTORSIZE) ;
			wptr	= srSkkinputDefaultInputVector [i]._wstr ;
			_rstrInputVector [nIndex]	= new WCHAR [wcslen (wptr) + 1] ;
			if (_rstrInputVector [nIndex] != NULL)
				wcscpy (_rstrInputVector [nIndex], wptr) ;
		}
		return	TRUE ;
	}
	for (nIndex = 0 ; ; nIndex ++) {
		dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
		cbData			= 0 ;
		lResult	= RegEnumValueW (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
		if (lResult != ERROR_SUCCESS)
			break ;
		lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS)
			continue ;
		/* ���傷����f�[�^�͎̂Ă�B*/
		if (dwType != REG_SZ) 
			continue ;
		/* vector[����] = �f�[�^ �Ƃ������B������ SPACE �ȉ��͐ݒ肵�Ȃ��B*/
		lValue	= _wtol (szRegPathInfo) ;
		if (lValue < 32 || lValue >= (INPUTVECTORSIZE + 32))
			continue ;

		pDest	= (LPWSTR) new BYTE [cbData] ;
		if (pDest != NULL) {
			(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE*)pDest, &cbData) ;
			_rstrInputVector [lValue - 32]	= pDest ;
		}
	}
	RegCloseKey (hSubKey) ;
	return	fRetval ;
}

BOOL
CImeDoc::_InitZenkakuVector ()
{
	static	const struct {
		WCHAR		_wch ;
		LPCWSTR		_wstr ;
	}	srSkkinputDefaultZenkakuVector []	= {
		{ 0x20,	L"�@", },	{ 0x21,	L"�I", },	{ 0x22,	L"�h", },	{ 0x23,	L"��", },
		{ 0x24,	L"��", },	{ 0x25,	L"��", },	{ 0x26,	L"��", },	{ 0x27,	L"�f", },
		{ 0x28,	L"�i", },	{ 0x29,	L"�j", },	{ 0x2A,	L"��", },	{ 0x2B,	L"�{", },
		{ 0x2C,	L"�C", },	{ 0x2D,	L"�|", },	{ 0x2E,	L"�D", },	{ 0x2F,	L"�^", },
		{ 0x30,	L"�O", },	{ 0x31,	L"�P", },	{ 0x32,	L"�Q", },	{ 0x33,	L"�R", },
		{ 0x34, L"�S", },	{ 0x35,	L"�T", },	{ 0x36,	L"�U", },	{ 0x37,	L"�V", }, 
		{ 0x38, L"�W", },	{ 0x39,	L"�X", },	{ 0x3A,	L"�F", },	{ 0x3B,	L"�G", },
		{ 0x3C, L"��", },	{ 0x3D,	L"��", },	{ 0x3E,	L"��", },	{ 0x3F,	L"�H", },
		{ 0x40, L"��", },	{ 0x41,	L"�`", },	{ 0x42,	L"�a", },	{ 0x43,	L"�b", },
		{ 0x44, L"�c", },	{ 0x45,	L"�d", },	{ 0x46,	L"�e", },	{ 0x47,	L"�f", },
		{ 0x48, L"�g", },	{ 0x49,	L"�h", },	{ 0x4A,	L"�i", },	{ 0x4B,	L"�j", },
		{ 0x4C, L"�k", },	{ 0x4D,	L"�l", },	{ 0x4E,	L"�m", },	{ 0x4F,	L"�n", }, 
		{ 0x50, L"�o", },	{ 0x51,	L"�p", },	{ 0x52,	L"�q", },	{ 0x53,	L"�r", },
		{ 0x54, L"�s", },	{ 0x55,	L"�t", },	{ 0x56,	L"�u", },	{ 0x57,	L"�v", },  
		{ 0x58, L"�w", },	{ 0x59,	L"�x", },	{ 0x5A,	L"�y", },	{ 0x5B,	L"�m", },
		{ 0x5C, L"�_", },	{ 0x5D,	L"�n", },	{ 0x5E,	L"�O", },	{ 0x5F,	L"�Q", },  
		{ 0x60, L"�e", },	{ 0x61,	L"��", },	{ 0x62,	L"��", },	{ 0x63,	L"��", },
		{ 0x64, L"��", },	{ 0x65,	L"��", },	{ 0x66,	L"��", },	{ 0x67,	L"��", },  
		{ 0x68, L"��", },	{ 0x69,	L"��", },	{ 0x6A,	L"��", },	{ 0x6B,	L"��", },
		{ 0x6C, L"��", },	{ 0x6D,	L"��", },	{ 0x6E,	L"��", },	{ 0x6F,	L"��", },  
		{ 0x70, L"��", },	{ 0x71,	L"��", },	{ 0x72,	L"��", },	{ 0x73,	L"��", },
		{ 0x74, L"��", },	{ 0x75,	L"��", },	{ 0x76,	L"��", },	{ 0x77,	L"��", },  
		{ 0x78, L"��", },	{ 0x79,	L"��", },	{ 0x7A,	L"��", },	{ 0x7B,	L"�o", },
		{ 0x7C, L"�b", },	{ 0x7D,	L"�p", },	{ 0x7E,	L"�`", },
	} ;
	HKEY				hSubKey ;
	WCHAR				szRegPathInfo [MAX_PATH] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	long				lValue ;
	register int		nIndex, i ;
	register LONG		lResult ;
	register BOOL		fRetval	= TRUE ;
	register LPWSTR		pDest ;

	for (i = 0 ; i < INPUTVECTORSIZE ; i++)
		_rstrZenkakuVector [i]	= NULL ;
	
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
		register LPCWSTR	wptr ;

		for (i = 0 ; i < NELEMENTS (srSkkinputDefaultZenkakuVector) ; i ++) {
			nIndex	= (int) srSkkinputDefaultZenkakuVector [i]._wch - 32 ;
			ASSERT (0 <= nIndex && nIndex < INPUTVECTORSIZE) ;
			wptr	= srSkkinputDefaultZenkakuVector [i]._wstr ;
			_rstrZenkakuVector [nIndex]	= new WCHAR [wcslen (wptr) + 1] ;
			if (_rstrZenkakuVector [nIndex] != NULL)
				wcscpy (_rstrZenkakuVector [nIndex], wptr) ;
		}
		return	TRUE ;
	}
	for (nIndex = 0 ; ; nIndex ++) {
		dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
		cbData			= 0 ;
		lResult	= RegEnumValueW (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
		if (lResult != ERROR_SUCCESS)
			break ;
		lResult	= RegQueryValueExW (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS)
			continue ;
		/* ���傷����f�[�^�͎̂Ă�B*/
		if (dwType != REG_SZ) 
			continue ;
		/* vector[����] = �f�[�^ �Ƃ������B������ SPACE �ȉ��͐ݒ肵�Ȃ��B*/
		lValue	= _wtol (szRegPathInfo) ;
		if (lValue < 32 || lValue >= (INPUTVECTORSIZE + 32))
			continue ;

		pDest	= (LPWSTR) new BYTE [cbData] ;
		if (pDest != NULL) {
			(void) RegQueryValueExW (hSubKey, szRegPathInfo, NULL, NULL, (BYTE*)pDest, &cbData) ;
			_rstrZenkakuVector [lValue - 32]	= pDest ;
		}
	}
	RegCloseKey (hSubKey) ;
	return	fRetval ;
}

BOOL
CImeDoc::_InitCandidateSelectKeys ()
{
	static	BYTE	srDefaultJHenkanShowCandidateKeys []	= {
		'a', 's', 'd', 'f', 'j', 'k', 'l'
	} ;
	static	BYTE	srDefaultJInputByCodeOrMenuKeys1 []		= {
		'a', 's', 'd', 'f', 'g', 'h', 'q', 'w', 'e', 'r', 't', 'y'
	} ;
	static	BYTE	srDefaultJInputByCodeOrMenuKeys2 []		= {
		'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'q', 'w', 'e', 'r', 't', 'y', 'u'
	} ;
	HKEY	hSubKey ;
	BOOL	fInitJHenkanShowCandidateKeys	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys1	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys2	= FALSE ;
	DWORD	dwType, cbData ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JHENKAN_SHOW_CANDIDATE_KEYS) {
			cbData	= NUM_JHENKAN_SHOW_CANDIDATE_KEYS ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, _JHenkanShowCandidateKeys, &cbData) ;
			fInitJHenkanShowCandidateKeys	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, _JInputByCodeOrMenuKeys1, &cbData) ;
			fInitJInputByCodeOrMenuKeys1	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, _JInputByCodeOrMenuKeys2, &cbData) ;
			fInitJInputByCodeOrMenuKeys2	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! fInitJHenkanShowCandidateKeys)
		memcpy (_JHenkanShowCandidateKeys, srDefaultJHenkanShowCandidateKeys, NUM_JHENKAN_SHOW_CANDIDATE_KEYS) ;
	if (! fInitJInputByCodeOrMenuKeys1)
		memcpy (_JInputByCodeOrMenuKeys1, srDefaultJInputByCodeOrMenuKeys1, NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) ;
	if (! fInitJInputByCodeOrMenuKeys2)
		memcpy (_JInputByCodeOrMenuKeys2, srDefaultJInputByCodeOrMenuKeys2, NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) ;
	return	TRUE ;
}

/*	WPARAM ���� WCHAR ���쐬����BWCHAR �ɕϊ����邽�߂� WIN32API ��
 *	ToAscii �𗘗p���Ă���B
 *	ToAscii �ŕϊ��ł��Ȃ������ɑ΂��ẮA�ꕔ�� VK_XXX �������E����
 *	128 �ȏ�̃R�[�h�����蓖�Ă邱�ƂƂ��Ă���B
 */
WCHAR
CImeDoc::_GetCharFromWPARAM (
	register WPARAM			wParam)
{
	static BYTE	byKeyState [256] = { 0 } ;
	static const BYTE	rVKKeyTbl []	= {
		VK_LEFT,	VK_UP,		VK_DOWN,	VK_RIGHT,	VK_INSERT,
		VK_DELETE,	VK_BACK,	VK_TAB,		VK_HOME,	VK_SPACE,
		VK_ESCAPE,	VK_KANJI,	VK_HELP,	VK_F1,		VK_F2,
		VK_F3,		VK_F4,		VK_F5,		VK_F6,		VK_F7,
		VK_F8,		VK_F9,		VK_F10,		VK_F11,		VK_F12,
		VK_CLEAR,	VK_RETURN,
	} ;
	static const WORD	rSubSpecialKeyTbl []	= {
		MYVK_LBUTTON,	MYVK_RBUTTON,	MYVK_MENU1,		MYVK_MENU2,
		MYVK_MENU3,		MYVK_MENU4,		MYVK_CONVERT,	MYVK_OPENCANDIDATE,
		MYVK_REVERT,	MYVK_COMPLETE,	MYVK_ABORT_CANDIDATELIST,
		MYVK_SETSELECTION_CANDIDATELIST,
		MYVK_FINALIZE_CANDIDATELIST,
		MYVK_ABORT_MINIBUFFER,
		MYVK_EXIT_MINIBUFFER,
	} ;

	if (wParam < 0x100) {
		register const BYTE*	ptr ;
		register int			nIndex ;
		WORD					rwCH [2] ;
		int						nFuncNo ;

		byKeyState [VK_CONTROL]	= (GetKeyState (VK_CONTROL) & 0x0800)? 0x80 : 0 ;
		byKeyState [VK_SHIFT]	= (GetKeyState (VK_SHIFT)   & 0x0800)? 0x80 : 0 ;
		rwCH [0]	= 0 ;
	
		/*	�܂��͌��݂� keyboard �����āA�ϊ��ł��Ȃ������ǂ������`�F�b�N
		 *	����B
		 */
		if (ToAscii (wParam, 0x80000000, byKeyState, rwCH, 0) == 0) {
			rwCH [0]	= (WCHAR)-1 ;
		} else {
			/*	keyboard �����ĕϊ��ł����ꍇ�̏����B
			 */
			if (rwCH [0] == TEXT(' ') && (byKeyState [VK_CONTROL] & 0x80))
				rwCH [0]	= 0 ;
		}

		/*	�E���ׂ������ł��邩�ǂ����̔���B�S�Ă� VK_XXX ������K�v
		 *	�͂Ȃ��B
		 */
		ptr	= (const BYTE*)memchr (rVKKeyTbl, wParam & 0x00FF, NELEMENTS (rVKKeyTbl)) ;
		if (ptr == NULL)
			return	rwCH [0] ;

		nIndex	= (ptr - rVKKeyTbl) * 3 ;
		if (byKeyState [VK_CONTROL] & 0x80) {
			nIndex	++ ;
		} else if (byKeyState [VK_SHIFT] & 0x80) {
			nIndex	+= 2 ;
		}
		if (! LookupKeymap ((WCHAR)(128 + nIndex), &nFuncNo) ||
			nFuncNo == FUNCNO_INVALID_CHAR) {
			return	rwCH [0] ;
		}
		return	(WCHAR)(128 + nIndex) ;
	} else {
		register int	i ;

		/*	subspecial key �� hit ����\��������B*/
		for (i = 0 ; i < NELEMENTS (rSubSpecialKeyTbl) ; i ++) {
			if (wParam == rSubSpecialKeyTbl [i])
				return	(WCHAR)(SIZE_MYKEYMAP + i) ;
		}
		return	(WCHAR)-1 ;
	}
}

CImeBuffer*
CImeDoc::_CreateBuffer (
	register LPCWSTR					wstrMessage,
	register int						nstrMessage,
	register CTImeRecursiveEditSession*	pSession)
{
	register CImeBuffer*	pBuffer ;
	register int			nIndex ;
	register BOOL			fInc ;

	/*	����ȏ�ċA�ł��Ȃ����H */
	if (_nBuffer >= MAXIMEBUFFER) {
		for (nIndex = 0 ; nIndex < MAXIMEBUFFER ; nIndex ++)
			if (_rpBuffer [nIndex] == NULL)
				break ;
		if (nIndex >= MAXIMEBUFFER)
			return	NULL ;
		fInc	= FALSE ;
	} else {
		nIndex	= _nBuffer ;
		fInc	= TRUE ;
	}
	pBuffer	= new CImeBuffer (this) ;
	if (pBuffer == NULL) 
		return	NULL ;
	if (! pBuffer->Init (wstrMessage, nstrMessage, pSession)) {
		delete	pBuffer ;
		return	NULL ;
	}
	_rpBuffer [nIndex]	= pBuffer ;
	if (fInc)
		_nBuffer	++ ;
	return	pBuffer ;
}

BOOL
CImeDoc::_DeleteUnusedBuffer ()
{
	register int	i ;

	for (i = 0 ; i < _nUnusedBuffer ; i ++) {
		delete	_rpUnusedBuffer [i] ;
		_rpUnusedBuffer [i]	= NULL ;
	}
	_nUnusedBuffer	= 0 ;
	for (i = _nBuffer - 1 ; i >= 0 && _rpBuffer [i] == NULL ; i --) 
		;
	_nBuffer	= i + 1 ;
	return	TRUE ;
}

/*========================================================================
 */
BOOL
CImeDoc::_UpdateCandidateInfoForStatusText ()
{
	IMECANDIDATES*	pMyCand ;

	ASSERT (_nBuffer > 0 && _rpBuffer [0] != NULL) ;

	pMyCand				= &_MessageText ;
	if (_rpBuffer [0] != _pCurBuffer) {
		LPCWSTR	pwText ;
		LPWSTR	pwDest ;
		UINT*	piDestIndex ;
		UINT*	piPageIndex ;
		int		iLength, iCursor, nText ;

		pMyCand->_iStyle	= IMECANDSTYLE_MINIBUFFERTEXT ;

		/*	Message ���������ꍇ�ɂ͐擪�Ɂu�I�v��ǉ����������c�B
		 *	���ƁA���O�� StatusLine ���`��ł��Ȃ��ꍇ�ɁA�J�[�\�����Ӗ�����
		 *	���������Ă��������B``|'' �ŗǂ����B
		 */
		pwText	= _pCurBuffer->GetText (&iLength) ;
		iCursor	= _pCurBuffer->GetCursorPosition () ;

		nText	= iLength + 1/*``|''�̕�*/ + 1/*nul�̕�*/ ;  
		pMyCand->_vbufCandidate.Clear () ;
		pMyCand->_vbufCandidateIndex.Clear () ;
		pMyCand->_vbufPageIndex.Clear () ;
		if (! pMyCand->_vbufCandidate.Require (nText) ||
			! pMyCand->_vbufCandidateIndex.Require (1) ||
			! pMyCand->_vbufPageIndex.Require (1))
			return	FALSE ;

		pMyCand->_iCount		= 1 ;
		pMyCand->_iSelection	= 0 ;
		pMyCand->_iCurrentPage	= 0 ;
		pwDest					= (LPWSTR) pMyCand->_vbufCandidate.GetBuffer () ;
		piDestIndex				= (UINT*) pMyCand->_vbufCandidateIndex.GetBuffer () ;
		*piDestIndex			= 0 ;
		piPageIndex				= (UINT*) pMyCand->_vbufPageIndex.GetBuffer () ;
		*piPageIndex			= 0 ;

		if (0 < iCursor) {
			memcpy (pwDest, pwText, iCursor * sizeof (WCHAR)) ;
			pwDest	+= iCursor ;
		}
		*pwDest ++	= L'|' ;
		if (iCursor < iLength) {
			memcpy (pwDest, pwText + iCursor, (iLength - iCursor) * sizeof (WCHAR)) ;
			pwDest	+= (iLength - iCursor) ;
		}
		*pwDest = L'\0' ;
	} else {
		pMyCand->_iStyle		= IMECANDSTYLE_UNUSED ;
		pMyCand->_iCount		= 0 ;
		pMyCand->_iSelection	= 0 ;
		pMyCand->_iCurrentPage	= 0 ;
		pMyCand->_vbufCandidate.Clear () ;
		pMyCand->_vbufCandidateIndex.Clear () ;
		pMyCand->_vbufPageIndex.Clear () ;
	}
	return	TRUE ;
}

