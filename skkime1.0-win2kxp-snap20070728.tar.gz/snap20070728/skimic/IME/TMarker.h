#if !defined (TMarker_h)
#define	TMarker_h

class CTMarker {
protected:
	int			m_iPosition ;
	bool		m_fCursor ;
	bool		m_fValid ;
public:
	CTMarker () : m_iPosition (0), m_fCursor (false), m_fValid (false) {
		return ;
	} 
	virtual		~CTMarker (){
		return ;
	}
	virtual bool		Initialize (bool fCursor = false){
		m_iPosition	= 0 ;
		m_fCursor	= fCursor ;
		m_fValid	= true ;
		return	true ;
	}
	virtual bool		Forward (int iCount = 1){
		m_iPosition	+= iCount ;
		return	true ;
	}
	virtual bool		Backward (int iCount = 1){
		if (m_iPosition > iCount){
			m_iPosition	-= iCount ;
		} else {
			m_iPosition	= 0 ;
		}
		return	true ;
	}
	virtual int			GetPosition () const {
		return	m_iPosition ;
	}
	virtual void		Invalidate () {
		m_fValid	= false ;
		return ;
	}
	virtual bool		IsCursor () const {
		return	m_fCursor ;
	}
	virtual bool		IsValidp () const {
		return	m_fValid ;
	}

	virtual bool		operator==(const CTMarker& marker) const {
		return	(m_iPosition == marker.m_iPosition) ;
	}

	virtual bool		operator==(int nPosition) const {
		return	(m_iPosition == nPosition) ;
	}

	virtual bool		operator!=(const CTMarker& marker) const {
		return	(m_iPosition != marker.m_iPosition) ;
	}

	virtual bool		operator<(const CTMarker& marker) const {
		return	(m_iPosition < marker.m_iPosition) ;
	}

	virtual bool		operator<(int nPosition) const {
		return	(m_iPosition < nPosition) ;
	}

	virtual bool		operator>(const CTMarker& marker) const {
		return	(m_iPosition > marker.m_iPosition) ;
	}

	virtual bool		operator>(int nPosition) const {
		return	(m_iPosition > nPosition) ;
	}

	virtual bool		operator<=(const CTMarker& marker) const {
		return	(m_iPosition <= marker.m_iPosition) ;
	}
	virtual bool		operator>=(const CTMarker& marker) const {
		return	(m_iPosition >= marker.m_iPosition) ;
	}
	virtual CTMarker	operator+(int iCount) const {
		return	CTMarker (m_iPosition + iCount) ;
	}
	virtual CTMarker	operator-(int iCount) const {
		return	CTMarker (m_iPosition - iCount) ;
	}
	virtual int			operator-(const CTMarker& marker) const {
		return	m_iPosition - marker.m_iPosition ;
	}
	virtual CTMarker&	operator=(const CTMarker& marker){
		m_iPosition	= marker.m_iPosition ;
		return	(*this) ;
	}
	virtual operator 	int () const {
		return	m_iPosition ;
	}
protected:
	CTMarker (int iPosition) : m_iPosition (iPosition), m_fCursor (false) {
		return ;
	} 
} ;

#endif

