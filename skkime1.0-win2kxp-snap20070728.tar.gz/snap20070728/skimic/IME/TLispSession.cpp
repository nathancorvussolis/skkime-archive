#include "local.h"
#include "TLispSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
CTLispSession::Eval (
	register LPCWSTR	wstrHenkanKey,
	register int		nstrHenkanKey,
	register LPWSTR		wstrDest,
	register int		nstrDest)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize ;
	WORD				wTotalResult ;
	register LPCWSTR	wstrResult ;
	register int		nResult, nRecv ;
	register BOOL		fRetval	= FALSE ;
	
	hPipe	= _OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.SetHeader (SKKISERV_PROTO_EVAL, 0) ||
		! packet.AddString (wstrHenkanKey, nstrHenkanKey) ||
		! packet.SetLength () ||
		! _Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! _Recv (hPipe, &packet) ||
		! packet.GetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.GetSize () ;
	if (nMajor != SKKISERV_PROTO_EVAL_REPLY)
		goto	exit_func ;
	if (! packet.GetCard16 (SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;
	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	wstrResult	= (LPCWSTR)(packet.GetData () + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	if (wTotalResult > 0) {
		register int		nTotalResult	= wTotalResult ;
		register int		nCopy ;

		if (nResult > nTotalResult)
			nResult		= nTotalResult ;
		nCopy			= (nResult < nstrDest)? nResult : nstrDest ;
		memcpy (wstrDest, wstrResult, nCopy * sizeof (WCHAR)) ;
		wstrDest		+= nCopy ;
		nTotalResult	-= nCopy ;
		nstrDest		-= nCopy ;
		while (nTotalResult > 0 && nstrDest > 0) {
			if (! _Recv (hPipe, &packet))
				break ;
			nRecv	= packet.GetSize () ;
			if (nRecv < 0)
				break ;
			wstrResult	= (LPCWSTR) packet.GetData () ;
			nResult		= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;
			nCopy			= (nResult < nstrDest)? nResult : nstrDest ;
			memcpy (wstrDest, wstrResult, nCopy * sizeof (WCHAR)) ;
			wstrDest		+= nCopy ;
			nTotalResult	-= nCopy ;
			nstrDest		-= nCopy ;
		}
		if (nstrDest > 0) 
			*wstrDest	= L'\0' ;
		fRetval	= TRUE ;
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

BOOL
CTLispSession::SetJNumList (
	register LPCWSTR	wstrJNumList,
	register int		nstrJNumList)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize ;
	register int		nRecv ;
	register BOOL		fRetval	= FALSE ;
	
	hPipe	= _OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.SetHeader (SKKISERV_PROTO_SETJNUMLIST, 0) ||
		! packet.AddString (wstrJNumList, nstrJNumList) ||
		! packet.SetLength () ||
		! _Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! _Recv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= packet.GetSize () ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! packet.GetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	fRetval	= (nMajor == SKKISERV_PROTO_SETJNUMLIST_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}


