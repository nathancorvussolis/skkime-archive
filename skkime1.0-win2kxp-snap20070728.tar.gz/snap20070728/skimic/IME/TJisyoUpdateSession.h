#if !defined (TJisyoUpdateSession_h)
#define	TJisyoUpdateSession_h

#include "TCommuSession.h"

class CTJisyoUpdateSession : public CTCommunicateSession {
public:
	virtual	BOOL		Update (LPCWSTR wstrHenkanKey, int nstrHenkanKey, LPCWSTR wstrResult, int nstrResult, BOOL fOkurigana) = 0 ;
} ;

class CTRecordSession : public CTJisyoUpdateSession {
public:
	virtual	BOOL		Update (LPCWSTR wstrHenkanKey, int nstrHenkanKey, LPCWSTR wstrResult, int nstrResult, BOOL fOkurigana) ;
} ;

class CTPurgeSession : public CTJisyoUpdateSession {
public:
	virtual	BOOL		Update (LPCWSTR wstrHenkanKey, int nstrHenkanKey, LPCWSTR wstrResult, int nstrResult, BOOL fOkurigana) ;
} ;

class	CTJisyoSaveSession : public CTCommunicateSession {
public:
	virtual	BOOL		Synchronize () ;
} ;

#endif

