#include "local.h"
#include "ImeBuffer.h"
#include "ImeDoc.h"
#include "TAssocRule.h"
#include "testkeymap.h"
#include "RomaKanaTable.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "ImeRecursiveEditSession.h"

const int	CImeBuffer::_rnJInputByCodeOrMenuJumpLowordTbl []	= { 177, 193, 209, 225, 241 } ;
const int	CImeBuffer::_nJCodeN1Min	= 161 ;
const int	CImeBuffer::_nJCodeN1Max	= 244 ;
const int	CImeBuffer::_nJCodeN2Min	= 161 ;
const int	CImeBuffer::_nJCodeN2Max	= 254 ;
const int	CImeBuffer::_nJCodeNull		= 128 ;

BOOL
CImeBuffer::_JInputByCodeOrMenu ()
{
	static LPCWSTR	wstrMenu	= L"JIS or EUC code (00nn or CR for Jump Menu): " ;

	if (! _pDoc->ReadFromMinibuffer (wstrMenu, wcslen (wstrMenu), new CJInputByCodeOrMenuSession (this)))
		return	FALSE ;
	/*	minibuffer �ł͉������͂̃f�t�H���g�������Ă����B*/
	return	_pDoc->GetCurrentBuffer ()->_JModeOff () ;
}

BOOL
CImeBuffer::_JInputByCodeOrMenu0Start (
	register int		n1,
	register int		n2)
{
	if (n1 == _nJCodeNull) {
		_JInputByCodeOrMenuJumpStart (n2) ;
	} else {
		_JInputByCodeOrMenu1Start (n1, n2) ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JInputByCodeOrMenuJumpStart (
	register int		n)
{
	if (n < _nJCodeN1Min)
		n	= _nJInputByCodeOrMenuJumpDefault ;

	if (! _CreateJInputByCodeOrMenuJumpList (n))
		return	FALSE ;
	_nJInputCode1	= n ;
	_pFilterFunc	= _stJInputByCodeOrMenuJumpFilter ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInputByCodeOrMenu1Start (
	register int		n1,
	register int		n2)
{
	if (! _CreateJInputByCodeOrMenu1List (n1, n2))
		return	FALSE ;
	_nJInputCode1		= n1 ;
	_nJInputCode2		= n2 ;
	_pFilterFunc		= _stJInputByCodeOrMenu1Filter ;
	return	TRUE ;
}

BOOL
CImeBuffer::_JInputByCodeOrMenuJumpFilter ()
{
	WCHAR			wch	= _pDoc->GetLastCommandChar () ;
	int				i, iNOrg ;
	const BYTE*		bptr ;
	IMECANDIDATES*	pMyCand ;

	pMyCand	= _pDoc->GetCandidateInfoBuffer () ;
	if (pMyCand == NULL || pMyCand->_iStyle != IMECANDSTYLE_CODE0)
		return	FALSE ;

	iNOrg	= _nJInputCode1 ;
	if (wch == WCH_FINALIZE_CANDIDATELIST) {
		i	= pMyCand->_iSelection ;
		if (0 <= i && i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) {
			if (i >= 6) {
				_nJInputCode1	++ ;
				if (_nJInputCode1 > _nJCodeN1Max)
					_nJInputCode1	= _nJCodeN1Min ;
				i	= i - 6 - 1 ;
			} else {
				i	-- ;
			}
			_nJInputByCodeOrMenuJumpDefault	= _nJInputCode1 ;
			return	_JInputByCodeOrMenu1Start (_nJInputCode1, (i < 0)? _nJCodeN1Min : _rnJInputByCodeOrMenuJumpLowordTbl [i]) ;
		} else {
			wch	= WCH_ABORT_CANDIDATELIST ;
		}
	} else {
		bptr	= _pDoc->GetJInputByCodeOrMenuKeys1 () ;
		for (i = 0 ; i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ; i ++) {
			if (wch == (WCHAR)*(bptr + i)) {
				if (i >= 6) {
					_nJInputCode1	++ ;
					if (_nJInputCode1 > _nJCodeN1Max)
						_nJInputCode1	= _nJCodeN1Min ;
					i	= i - 6 - 1 ;
				} else {
					i	-- ;
				}
				_nJInputByCodeOrMenuJumpDefault	= _nJInputCode1 ;
				return	_JInputByCodeOrMenu1Start (_nJInputCode1, (i < 0)? _nJCodeN1Min : _rnJInputByCodeOrMenuJumpLowordTbl [i]) ;
			}
		}
	}

	switch (wch) {
	case	WCH_SETSELECTION_CANDIDATELIST:
		break ;
	default:
	{
		WCHAR	bufText [256] ;
		int		nFuncNo ;
		UINT	iPageStart, iCurPage, iMaxPage ;
		UINT*	piPageIndex ;

		if (! _pDoc->LookupKeymap (wch, &nFuncNo))
			break ;

		switch (nFuncNo) {
		case	FUNCNO_J_PREVIOUS_CANDIDATE:
			_nJInputCode1 	-= 2 ;
			if (_nJInputCode1 < _nJCodeN1Min) 
				_nJInputCode1	= _nJCodeN1Max ;
			if (! _CreateJInputByCodeOrMenuJumpList (_nJInputCode1)) {
			}
			break ;

		case	FUNCNO_J_START_HENKAN:
			_nJInputCode1	+= 2 ;
			if (_nJInputCode1 > _nJCodeN1Max) 
				_nJInputCode1	= _nJInputCode1 - _nJCodeN1Max + _nJCodeN1Min - 1 ;
			if (! _CreateJInputByCodeOrMenuJumpList (_nJInputCode1)) {
			}
			break ;

		case	FUNCNO_J_KEYBOARD_QUIT:
			goto	j_keyboard_quit ;

		default:
			{
				int		nText ;

				if (wch == 63) {
					LPCWSTR	pwCode ;
					int		nText ;

					if (pMyCand->_iSelection < pMyCand->_iCount && pMyCand->_iSelection < pMyCand->_vbufCandidateIndex.GetUsage ()) {
						pwCode	= (LPWSTR) pMyCand->_vbufCandidate.GetBuffer () + *((UINT*)pMyCand->_vbufCandidateIndex.GetBuffer() + pMyCand->_iSelection) ;
						nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"�w%s�x EUC: %02x%02x (%3d,%3d), JIS: %02x%02x (%3d,%3d)",
							pwCode,
							iNOrg,			_nJCodeN1Min,		iNOrg,			_nJCodeN1Min,
							iNOrg - 128,	_nJCodeN1Min - 128,	iNOrg - 128,	_nJCodeN1Min - 128) ;

						_pDoc->SetMessage (bufText, nText) ;
					}
					break ;
				}
				if (wch > 0x20 && wch != 0x7F) {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"`%c' is not valid here!", wch) ;
				} else {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"0x%02x is not valid here!", wch) ;
				}
				_pDoc->SetMessage (bufText, nText) ;
			}
			break ;
		}
		break ;
	}
	case	WCH_ABORT_CANDIDATELIST:
j_keyboard_quit:
		pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
		_pDoc->ClearMessage () ;
		_pFilterFunc	= _stNormalFilter ;
		return	TRUE ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_JInputByCodeOrMenu1Filter ()
{
	WCHAR			wch	= (WCHAR) _pDoc->GetLastCommandChar () ;
	IMECANDIDATES*	pMyCand ;
	const BYTE*		bptr ;
	WCHAR			wchResult ;
	int				i, n1, n2, iN1Org, iN2Org ;
	UINT			iPageStart, iMaxPage, iCurPage ;
	UINT*			piPageIndex ;

	pMyCand	= _pDoc->GetCandidateInfoBuffer () ;
	if (pMyCand == NULL || pMyCand->_iStyle != IMECANDSTYLE_CODE1)
		return	FALSE ;

	n1		= _nJInputCode1 ;
	n2		= _nJInputCode2 ;
	iN1Org	= n1 ;
	iN2Org	= n2 ;
	if (wch == WCH_FINALIZE_CANDIDATELIST) {
		i	= pMyCand->_iSelection ;
		if (0 <= i && i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 && i < pMyCand->_iCount) {
			n2	+= i ;
			if (n2 > _nJCodeN2Max) {
				n2	= (n2 - _nJCodeN2Max - 1) + _nJCodeN2Min ;
				n1	++ ;
				if (n1 > _nJCodeN1Max) 
					n1	= _nJCodeN1Min ;
			}
			wchResult	= JCharToUnicode ((WORD)((n1 << 8) | n2)) ;
			_Insert ((wchResult != 0)? &wchResult : L" ", 1) ;
			_pFilterFunc	= _stNormalFilter ;
			_pDoc->ClearMessage () ;
			pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
			return	TRUE ;
		} else {
			wch	= WCH_ABORT_CANDIDATELIST ;
		}
	} else {
		bptr	= _pDoc->GetJInputByCodeOrMenuKeys2 () ;
		for (i = 0 ; i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 ; i ++) {
			if (wch == (WCHAR)*(bptr + i)) {
				wchResult	= JCharToUnicode ((WORD)((n1 << 8) | n2)) ;
				_Insert ((wchResult != 0)? &wchResult : L" ", 1) ;
				_pFilterFunc	= _stNormalFilter ;
				_pDoc->ClearMessage () ;
				pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
				return	TRUE ;
			}
			n2	++ ;
			if (n2 > _nJCodeN2Max) {
				n2	= _nJCodeN2Min ;
				n1	++ ;
				if (n1 > _nJCodeN1Max) 
					n1	= _nJCodeN1Min ;
			}
		}
	}

	switch (wch) {
	case	WCH_SETSELECTION_CANDIDATELIST:
		/*	�܂��R�[�h���Ȃ��B*/
		break ;
	case	L'>':	/* '<' �� '>' ������ function �Ɋ��蓖�Ă邩����B*/
		n2	= _nJInputCode2 ;
		n2	++ ;
		if (n2 > _nJCodeN2Max) {
			n2	= _nJCodeN2Min ;
			n1	++ ;
			if (n1 > _nJCodeN1Max) 
				n1	= _nJCodeN1Min ;
		}
		if (! _CreateJInputByCodeOrMenu1List (n1, n2)) 
			goto	j_keyboard_quit ;
		break ;

	case	L'<':
		n2	= _nJInputCode2 - 1 ;
		if (n2 < _nJCodeN2Min) {
			n2	= _nJCodeN2Max ;
			n1	-- ;
			if (n1 < _nJCodeN1Min)
				n1	= _nJCodeN1Max ;
		}
		if (! _CreateJInputByCodeOrMenu1List (n1, n2)) 
			goto	j_keyboard_quit ;
		break ;

	default:
	{
		int		nFuncNo ;

		if (! _pDoc->LookupKeymap (wch, &nFuncNo))
			break ;

		switch (nFuncNo) {
		case	FUNCNO_J_PREVIOUS_CANDIDATE:
			n2	-= 31 ;
			if (n2 < _nJCodeN2Min) {
				n2	+= 94 ;
				n1	-- ;
				if (n1 < _nJCodeN1Min)
					n1	= _nJCodeN1Max ;
			}
			if (! _CreateJInputByCodeOrMenu1List (n1, n2)) 
				goto	j_keyboard_quit ;
			break ;

		case	FUNCNO_J_START_HENKAN:
			n2	++ ;
			if (n2 > _nJCodeN2Max) {
				n2	= _nJCodeN2Min ;
				n1	++ ;
				if (n1 > _nJCodeN1Max) 
					n1	= _nJCodeN1Min ;
			}
			if (! _CreateJInputByCodeOrMenu1List (n1, n2)) 
				goto	j_keyboard_quit ;
			break ;

		case	FUNCNO_J_KEYBOARD_QUIT:
			goto	j_keyboard_quit ;

		default:
			{
				WCHAR	bufText [256] ;
				int		nText ;

				if (wch == 63) {
					LPCWSTR	pwCode ;
					int		nText ;

					if (pMyCand->_iSelection < pMyCand->_iCount && pMyCand->_iSelection < pMyCand->_vbufCandidateIndex.GetUsage ()) {
						pwCode	= (LPWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((int*)pMyCand->_vbufCandidateIndex.GetBuffer () + pMyCand->_iSelection) ;
						nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"�w%s�x EUC: %02x%02x (%3d,%3d), JIS: %02x%02x (%3d,%3d)",
							pwCode,
							iN1Org,			iN2Org,			iN1Org,			iN2Org,
							iN1Org - 128,	iN2Org - 128,	iN1Org - 128,	iN2Org - 128) ;

						_pDoc->SetMessage (bufText, nText) ;
					}
					break ;
				}
				if (wch > 0x20 && wch != 0x7F) {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"`%c' is not valid here!", wch) ;
				} else {
					nText	= wnsprintfW (bufText, NELEMENTS (bufText) - 1, L"0x%02x is not valid here!", wch) ;
				}
				_pDoc->SetMessage (bufText, nText) ;
			}
			break ;
		}
		break ;
	}
	case	WCH_ABORT_CANDIDATELIST:
j_keyboard_quit:
		_pDoc->ClearMessage () ;
		_pFilterFunc	= _stNormalFilter ;
		pMyCand->_iStyle	= IMECANDSTYLE_UNUSED ;
		return	TRUE ;
	}
	_nJInputCode1	= n1 ;
	_nJInputCode2	= n2 ;
	return	TRUE ;
}

BOOL
CImeBuffer::_CreateJInputByCodeOrMenuJumpList (
	int				n)
{
	IMECANDIDATES*		pMyCand ;
	LPWSTR				pwCandStr, pwDest ;
	UINT*				piDestIndex ;
	UINT*				piPageIndex ;
	WORD				woChara, woCode ;
	int 				i, nNumOfCand, iMaxPage ;

	/*	min, max ���܂�ŁA���ꂼ��� 6 ���A�ƁB*/
	nNumOfCand		= NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ;
	pMyCand			= _pDoc->GetCandidateInfoBuffer () ;
	if (pMyCand == NULL)
		return	FALSE ;

	iMaxPage		= 1 ;	//(nNumOfCand + NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 - 1) / NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ;
	if (iMaxPage <= 0)
		return	FALSE ;

	pMyCand->_vbufCandidate.Clear () ;
	pMyCand->_vbufCandidateIndex.Clear () ;
	pMyCand->_vbufPageIndex.Clear () ;
	if (! pMyCand->_vbufCandidate.Require (nNumOfCand * 2) ||
		! pMyCand->_vbufCandidateIndex.Require (nNumOfCand) ||
		! pMyCand->_vbufPageIndex.Require (iMaxPage)) {
		pMyCand->_vbufCandidate.Clear () ;
		pMyCand->_vbufCandidateIndex.Clear () ;
		pMyCand->_vbufPageIndex.Clear () ;
		return	FALSE ;
	}

	/* ��⃊�X�g�\���̂��m�ۂ��A����������B*/
	pMyCand->_iCount		= nNumOfCand ;
	pMyCand->_iStyle		= IMECANDSTYLE_CODE0 ;

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pwCandStr	= (LPWSTR) pMyCand->_vbufCandidate.GetBuffer () ;
	pwDest		= pwCandStr ;
	piDestIndex	= (UINT*) pMyCand->_vbufCandidateIndex.GetBuffer () ;

	piPageIndex	= (UINT*) pMyCand->_vbufPageIndex.GetBuffer () ;
	for (i = 0 ; i < iMaxPage ; i ++) 
		piPageIndex [i]	= i * NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ;

	*piDestIndex	= pwDest - pwCandStr ;
	woCode			= ((n & 0x00FF) << 8) | _nJCodeN1Min ;
	woChara			= JCharToUnicode (woCode) ;
	if (!woChara)	/* �ϊ��ł��Ȃ����͋󔒁B*/
		woChara	= L' ' ;
	*pwDest	++	= (WCHAR)woChara ;
	*pwDest ++	= L'\0' ;
	piDestIndex	++ ;
	for (i = 0 ; i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 / 2 - 1 ; i ++){
		*piDestIndex	= pwDest - pwCandStr ;
		woCode			= ((n & 0x00FF) << 8) | _rnJInputByCodeOrMenuJumpLowordTbl [i] ;
		/* j_char_jis_to_unicode */
		woChara		= JCharToUnicode (woCode) ;
		if (!woChara)	/* �ϊ��ł��Ȃ����͋󔒁B*/
			woChara	= L' ' ;
		*pwDest	++	= (WCHAR)woChara ;
		*pwDest ++	= L'\0' ;
		piDestIndex	++ ;
	}
	n			++ ;
	n			= (n <= _nJCodeN1Max)? n : _nJCodeN1Min ;

	*piDestIndex	= pwDest - pwCandStr ;
	woCode		= ((n & 0x00FF) << 8) | _nJCodeN1Min ;
	woChara		= JCharToUnicode (woCode) ;
	if (!woChara)	/* �ϊ��ł��Ȃ����͋󔒁B*/
		woChara	= L' ' ;
	*pwDest	++	= (WCHAR)woChara ;
	*pwDest ++	= L'\0' ;
	piDestIndex	++ ;
	for (i = 0 ; i < NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 / 2 - 1 ; i ++) {
		*piDestIndex	= pwDest - pwCandStr ;
		woCode			= ((n & 0x00FF) << 8) | _rnJInputByCodeOrMenuJumpLowordTbl [i] ;
		/* j_char_jis_to_unicode */
		woChara		= JCharToUnicode (woCode) ;
		if (!woChara)	/* �ϊ��ł��Ȃ����͋󔒁B*/
			woChara	= L' ' ;
		*pwDest	++	= (WCHAR)woChara ;
		*pwDest ++	= L'\0' ;
		piDestIndex	++ ;
	}
	pMyCand->_iSelection	= 0 ;
	pMyCand->_iCurrentPage	= 0 ;
	pMyCand->_dwUpdate		= IMECANDUPDATE_COUNT | IMECANDUPDATE_STRING | IMECANDUPDATE_CURRENT_PAGE | IMECANDUPDATE_PAGE_INDEX ;
	return	TRUE ;
}

BOOL
CImeBuffer::_CreateJInputByCodeOrMenu1List (
	int				n1,
	int				n2)
{
	IMECANDIDATES*	pMyCand ;
	LPWSTR			pwCandStr, pwDest ;
	UINT*			piDestIndex ;
	UINT*			piPageIndex ;
	WORD			woChara ;
	int				nNumOfCand, i, nCount1, nCount2, iMaxPage ;

	DEBUGPRINTF ((TEXT ("CImeBuffer::_CreateJInputByCodeOrMenu1List (n1:%d, n2:%d)\n"), n1, n2)) ;

	/*	���Ƃ��������Ȑ����ȁB*/
	nNumOfCand	= NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 ;
	pMyCand		= _pDoc->GetCandidateInfoBuffer () ;
	if (pMyCand == NULL)
		return	FALSE ;

	iMaxPage		= 1 ;
	if (iMaxPage <= 0)
		return	FALSE ;

	pMyCand->_vbufCandidate.Clear () ;
	pMyCand->_vbufCandidateIndex.Clear () ;
	pMyCand->_vbufPageIndex.Clear () ;
	if (! pMyCand->_vbufCandidate.Require (nNumOfCand * 2)  ||
		! pMyCand->_vbufCandidateIndex.Require (nNumOfCand) ||
		! pMyCand->_vbufPageIndex.Require (iMaxPage)) {
		pMyCand->_vbufCandidate.Clear () ;
		pMyCand->_vbufCandidateIndex.Clear () ;
		pMyCand->_vbufPageIndex.Clear () ;
		return	FALSE ;
	}

	/* ��⃊�X�g�\���̂��m�ۂ��A����������B*/
	pMyCand->_iStyle		= IMECANDSTYLE_CODE1 ;
	pMyCand->_iCount		= nNumOfCand ;

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pwCandStr	= (LPWSTR) pMyCand->_vbufCandidate.GetBuffer () ;
	pwDest		= pwCandStr ;
	piDestIndex	= (UINT*) pMyCand->_vbufCandidateIndex.GetBuffer () ;

	piPageIndex	= (UINT*) pMyCand->_vbufPageIndex.GetBuffer () ;
	for (i = 0 ; i < iMaxPage ; i ++)
		piPageIndex [i]	= 0 ;

	nCount1		= n1 ;	//_nJCodeN1Min ;
	nCount2		= n2 ;	//_nJCodeN2Min ;
	for (i = 0 ; i < nNumOfCand ; i ++) {
		*piDestIndex	= pwDest - pwCandStr ;
		/* JISX0208-1983 �����W���Ɋ܂܂�镶���� UNICODE �ɕ���������B*/
		woChara		= JCharToUnicode ((WORD)((nCount1 << 8) | nCount2)) ;
		if (!woChara)
			woChara	= L' ' ;
		*pwDest	++	= woChara ;
		*pwDest	++	= L'\0' ;
		
		nCount2		++ ;
		if (nCount2 > _nJCodeN2Max)
			nCount2	= _nJCodeN2Min ;
		if (nCount2 == _nJCodeN2Min) {
			nCount1 ++ ;
			if (nCount1 > _nJCodeN1Max)
				nCount1	= _nJCodeN1Min ;
		}	
		piDestIndex	++ ;
	}

	pMyCand->_iSelection	= 0 ;
	pMyCand->_iCurrentPage	= 0 ;
	pMyCand->_dwUpdate		= IMECANDUPDATE_COUNT | IMECANDUPDATE_STRING | IMECANDUPDATE_CURRENT_PAGE | IMECANDUPDATE_PAGE_INDEX ;
	DEBUGPRINTF ((TEXT ("n1(%d), n2(%d), selection(%d), currentpage(%d)\n"), n1, n2, pMyCand->_iSelection, pMyCand->_iCurrentPage)) ;
	return	TRUE ;
}

BOOL
CImeBuffer::_stJInputByCodeOrMenuJumpFilter (
	register CImeBuffer*	pThis)
{
	return	pThis->_JInputByCodeOrMenuJumpFilter () ;
}

BOOL
CImeBuffer::_stJInputByCodeOrMenu1Filter (
	register CImeBuffer*	pThis)
{
	return	pThis->_JInputByCodeOrMenu1Filter () ;
}


