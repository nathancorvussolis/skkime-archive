#pragma once

#include "testkeymap.h"
#include "ImeBuffer.h"
#include "varbuffer.h"

#define	MAXIMEBUFFER		(8)
#define	MAXROMAKANATABLE	(5)
#define	MAXUNREADEVENT		(4)
#define	MSGBUFSIZE			(256)
#define	INPUTVECTORSIZE		(128-32)

enum {
	GC_EGG_LIKE_NEWLINE	= 0,
	GC_DELETE_IMPLIES_KAKUTEI,
	GC_USE_NUMERIC_CONVERSION,
	GC_DABBREV_LIKE_COMPLETION,
	GC_KATAKANA_HIRAGANA_HENKAN,
	GC_STYLE,
	GC_DATE_AD,
	GC_SHOW_ANNOTATION,
	GC_KAKUTEI_EARLY,
	GC_PROCESS_OKURI_EARLY,
	GC_DELETE_OKURI_WHEN_QUIT,
	NUMGENERICCONFIG
} ;

enum {
	IMECMODE_HIRAGANA	= 0,
	IMECMODE_KATAKANA,
	IMECMODE_ZENKAKU,
	IMECMODE_HANKANA,
	IMECMODE_ASCII,
	IMECMODE_OFF,
} ;

enum {
	IMEKEYMAP_JMODE		= 0,
	IMEKEYMAP_ASCII,
	IMEKEYMAP_ZENKAKU,
	IMEKEYMAP_ABBREV,
} ;

/* IMECANDIDATES �� style */
enum {
	IMECANDSTYLE_UNUSED		= -1,		/* ����������ĂȂ���ԁB*/
	IMECANDSTYLE_READ		= 0,		/* HenkanCandidates */
	IMECANDSTYLE_CODE0,					/* MenuJump */
	IMECANDSTYLE_CODE1,					/* Menu1 */
	IMECANDSTYLE_MINIBUFFERTEXT,		/* �ċA�ҏW���[�h�B*/
	IMECANDSTYLE_UNKNOWN,
} ;

enum {
	SKKUI_OPEN_CANDIDATELIST			= 1,
	SKKUI_UPDATE_CANDIDATE_SELECTION	= 2,
	SKKUI_UPDATE_CANDIDATE_PAGESTART	= 4,
	SKKUI_UPDATE_CANDIDATE_STRING		= 8,	/* ���g���ω������B*/
	SKKUI_UPDATE_CANDIDATE_PAGESIZE		= 16,	/* �y�[�W�T�C�Y���ω������B*/
	SKKUI_UPDATE_CANDIDATE_COUNT		= 32,	/* �y�[�W�T�C�Y���ω������B*/
	SKKUI_CLOSE_CANDIDATELIST			= 64,
} ;

#define	NUM_JHENKAN_SHOW_CANDIDATE_KEYS		(7)
#define	NUM_JINPUT_BY_CODE_OR_MENU_KEYS1	(12)
#define	NUM_JINPUT_BY_CODE_OR_MENU_KEYS2	(16)
#define	MAX_LENGTH_ONE_ANNOTATION			(128)

class CImeBuffer ;
class CTAssocRule ;
class CTRomaKanaTable ;
class CTImeRecursiveEditSession ;

enum {
	IMECANDUPDATE_SELECTION				= 1,
	IMECANDUPDATE_CURRENT_PAGE			= 2,
	IMECANDUPDATE_COUNT					= 4,
	IMECANDUPDATE_STRING				= 8,
	IMECANDUPDATE_PAGE_INDEX			= 16,
} ;

struct IMECANDIDATES {
	int			_iStyle ;
	UINT		_iCount ;			/* �P�ꑍ���B*/
	UINT		_iSelection ;		/* dummy? */
	UINT		_iCurrentPage ;
	CVarbuffer <WCHAR, 256>		_vbufCandidate ;		/* �P��B */
	CVarbuffer <UINT, 128>		_vbufCandidateIndex ;
	CVarbuffer <UINT, 32>		_vbufPageIndex ;
	DWORD		_dwUpdate ;

public:
	IMECANDIDATES () : _iStyle (IMECANDSTYLE_UNUSED), _iCount (0), _iSelection (0), _iCurrentPage (0), _dwUpdate (0) {
		return ;
	}

	virtual	~IMECANDIDATES () {
	}
} ;

struct TEXTREGION {
	int			m_nCandidate ;
	int			m_nOffset ;
	int			m_nLength ;
} ;

struct IMETEXTATTRIBUTE {
	WCHAR		_wszWord [MAX_LENGTH_ONE_ANNOTATION] ;
	int			_nWordLen ;
	int			_nStartPos, _nEndPos ;
} ;

class CImeDoc {
private:
	CImeBuffer*			_rpBuffer [MAXIMEBUFFER] ;
	int					_nBuffer ;
	CImeBuffer*			_rpUnusedBuffer [MAXIMEBUFFER] ;
	int					_nUnusedBuffer ;
	CImeBuffer*			_pCurBuffer ;

	WCHAR				_bufUnreadEvent [MAXUNREADEVENT] ;
	int					_nbufUnreadEvent ;
	WCHAR				_wchLastCommandChar ;
	WPARAM				_wKeyEvent ;
	LPARAM				_lKeyEvent ;

	WCHAR				_bufMessage [MSGBUFSIZE] ;
	int					_nbufMessage ;

	IMECANDIDATES		_CandidateList ;
	IMECANDIDATES		_MessageText ;		/* fake minibuffer message by using candidate-list */

	int					_nThisCommand ;
	int					_nLastCommand ;
	BOOL				_fFilter ;

	CTRomaKanaTable*	_rpRomaKanaTable ;
	CTAssocRule**		_rpAssocRule ;
	int					_nAssocRule ;
	LPWSTR				_rstrInputVector [INPUTVECTORSIZE] ;
	LPWSTR				_rstrZenkakuVector [INPUTVECTORSIZE] ;
	LPWSTR				_pstrPrefixList ;
	static LPCWSTR		_rstrDefaultPrefixList [] ;
	LPCBYTE				_pbyJMap ;
	LPCBYTE				_pbyAbbrevMap ;
	BYTE				_rbyJMap [SIZE_IMEDOC_KEYMAP] ;
	BYTE				_rbyAbbrevMap [SIZE_IMEDOC_KEYMAP] ;
	static const BYTE	_rbyDefaultJMap [SIZE_IMEDOC_KEYMAP] ; 
	static const BYTE	_rbyDefaultAbbrevMap [SIZE_IMEDOC_KEYMAP] ; 
	int					_rnGenericConfig [NUMGENERICCONFIG] ;

	/*	Application �T�C�Y�� PageSize �̕ύX��v���ł���̂ŁA���ӂ���K�v������B
	 */
	BYTE				_JHenkanShowCandidateKeys [NUM_JHENKAN_SHOW_CANDIDATE_KEYS] ;
	BYTE				_JInputByCodeOrMenuKeys1 [NUM_JINPUT_BY_CODE_OR_MENU_KEYS1] ;
	BYTE				_JInputByCodeOrMenuKeys2 [NUM_JINPUT_BY_CODE_OR_MENU_KEYS2] ;

public:
	CImeDoc () ;
	virtual			~CImeDoc () ;

	virtual BOOL	Init () ;
	virtual BOOL	Uninit () ;
	virtual	BOOL	Clear () ;

	virtual BOOL	QueryFilterKeyEvent (WPARAM wParam, LPARAM lParam, BOOL* pfEaten) ;
	virtual	BOOL	QueryToggleIMEKeyEvent (WPARAM wParam, LPARAM lParam, BOOL* pfEaten) ;
	virtual BOOL	FilterKeyEvent (WPARAM wParam, LPARAM lParam, BOOL* pfEaten) ;
	virtual LPCWSTR	GetPreeditText (int* pnLength) ;
	virtual	BOOL	GetPreeditCursor (int* pnCursor) const ;
	virtual const IMECANDIDATES*	GetStatusText () const ;
	virtual	BOOL	GetStatusCursor (int* pnCursor) const ;
	virtual	int		GetReadingText (LPWSTR wpDest, int nDest, int* pnShift) ;
	virtual	BOOL	GetConvertedRegion (int* pnBegin, int* pnEnd) const ;
	virtual	BOOL	SetConversionMode (int nMode) ;
	virtual	int		GetConversionMode () const ;
	virtual	BOOL	IsStatusActivep () const ;
	virtual	BOOL	QueryUpdateContext (int* pnShift, int* pnCursor, BOOL* pfContinue) ;
	virtual	BOOL	UpdateContext () ;
	virtual	void	UpdateConfig () ;
	virtual	BOOL	SetReconvertText (LPCWSTR wstrTEXT, int nstrTEXT) ;
	virtual	BOOL	GetSelectedRegion (int* pnBegin, int* pnEnd) const ;

	virtual BOOL	LookupKeymap (WCHAR wch, int* pnFuncNo) const ;
	virtual int		GetLastCommandChar () const ;
	virtual BOOL	SetLastCommandChar (int ch) ;
	virtual BOOL	SetUnreadCommandChar (int ch) ;
	virtual	BOOL	UnprocessChar (int ch) ;
	virtual	int		GetLastCommand () const ;
	virtual	BOOL	SetLastCommand (int nCmd) ;
	virtual int		GetThisCommand () const ;
	virtual	BOOL	SetThisCommand (int nCmd) ;
	virtual LPARAM	GetLastKeyData () const { return _lKeyEvent ; }
	virtual void	SetLastKeyData (LPARAM lParam) { _lKeyEvent = lParam ; } 

	virtual const CTAssocRule*	JAssocRule (LPCWSTR wstr, int nwstr) ;
	virtual CTRomaKanaTable*	GetRomaKana (int ch) ;
	virtual BOOL	IsSkkDeleteOkuriWhenQuitp () const ;
	virtual	BOOL	IsSkkProcessOkuriEarlyp () const ;
	virtual	BOOL	IsSkkKakuteiEarlyp () const ;
	virtual	BOOL	IsJKakuteiEarlyp () const ;
	virtual BOOL	IsSkkEggLikeNewlinep () const ;
	virtual	BOOL	IsSkkUseNumericConversionp () const ;
	virtual	BOOL	IsSkkDabbrevLikeCompletion () const ;
	virtual	BOOL	IsSkkDeleteImpliesKakuteip () const ;
	virtual	BOOL	IsSkkKatakanaHiraganaHenkanp () const ;
	virtual BOOL	IsSkkShowAnnotationp () const ;
	virtual	int		GetSkkDateAd () const ;
	virtual	int		GetSkkNumberStyle () const ;
	virtual	LPCWSTR	GetSkkInputVector (int wch, int* pnWord) const ;
	virtual	LPCWSTR	GetSkkZenkakuVector (int wch, int* pnWord) const ;
	virtual	BOOL	IsValidPrefixp (LPCWSTR wstr, int nwstr) const ;
	virtual	const BYTE*	GetJHenkanShowCandidateKeys (int* pnKeys = NULL) const ;
	virtual	const BYTE*	GetJInputByCodeOrMenuKeys1 (int* pnKeys = NULL) const ;
	virtual	const BYTE*	GetJInputByCodeOrMenuKeys2 (int* pnKeys = NULL) const ;

	virtual	CImeBuffer*	GetCurrentBuffer () ;
	virtual	BOOL	ReadFromMinibuffer (LPCWSTR wstrMessasge, int nstrMessage, CTImeRecursiveEditSession* pSession) ;
	virtual	BOOL	ExitMinibuffer (CImeBuffer* pDestBuffer) ;

	virtual	BOOL	SetMessage (LPCWSTR wstrMessage, int nstrMessage) ;
	virtual	BOOL	SetMessage (LPCWSTR wstrMessage) ;
	virtual LPCWSTR	GetMessage (int* piMessageLen) const ;
//	virtual const IMECANDIDATES*	GetCandidateList () const ;
//	virtual BOOL	SetCandidateList (IMECANDIDATES* pCandidateList) ;
	virtual BOOL	HaveMessagep () const ;
	virtual	BOOL	ClearMessage () ;
	virtual BOOL	RecursiveEditp () const ;

	virtual IMECANDIDATES*	GetCandidateInfoBuffer () ;

	virtual	int		GetCandidateText (LPWSTR pwDest, int nDest, TEXTREGION* pText, int* piNumText, const IMECANDIDATES* pMyCand) ;
	virtual	int		GetCodeMenuJumpText (LPWSTR pwDest, int nDest, const IMECANDIDATES* pMyCand) ;
	virtual	int		GetCodeMenu1Text (LPWSTR pwDest, int nDest, const IMECANDIDATES* pMyCand) ;

private:
	CImeDoc (const CImeDoc& doc) ;
	BOOL		_InitConfig () ;
	void		_UninitConfig () ;
	BOOL		_InitGenericConfig () ;
	BOOL		_InitKeymap () ;
	BOOL		_InitRomaKanaTable () ;
	BOOL		_InitJAssocRule () ;
	BOOL		_InitPrefixList () ;
	BOOL		_InitZenkakuVector () ;
	BOOL		_InitInputVector () ;
	BOOL		_InitCandidateSelectKeys () ;

	WCHAR		_GetCharFromWPARAM (WPARAM wParam) ;
	CImeBuffer*	_CreateBuffer (LPCWSTR wstrMessage = NULL, int nstrMessage = 0, CTImeRecursiveEditSession* pSession = NULL) ;
	BOOL		_DeleteUnusedBuffer () ;

	BOOL		_UpdateCandidateInfoForStatusText () ;
} ;

__inline int	
_HasWordAnnotation (
	LPCWSTR			pWord,
	int				nWord)
{
	LPCWSTR		ptr ;

	if (pWord == NULL || nWord <= 0)
		return	-1 ;

	ptr	= pWord ;
	while (nWord > 0 && *ptr != L'\0') {
		if (*ptr == L';')
			return	(ptr - pWord) ;
		nWord	-- ;
		ptr		++ ;
	}
	return	-1 ;	/* Not found */
}
