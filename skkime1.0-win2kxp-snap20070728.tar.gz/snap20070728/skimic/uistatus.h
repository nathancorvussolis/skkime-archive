#pragma once

struct IMECANDIDATES ;
struct TEXTREGION ;

class CUIStatus : public ITfTextLayoutSink
{
	enum {
		MAX_ANNOTATIONS				= 32,
		NBUFFER_ANNOTATION_TEXT		= 1024,
		SKKIME_DEFAULT_HOVERTIME	= 400,
		TIMEEV_SHOWANNOTATION		= 0,
		UI_CURSORWIDTH				= 2,
		DEFAULT_MINIBUF_CHARWIDTH	= 80,
	} ;

	struct MYTOOLTIPINFO {
		int			_nCount ;
		POINT		_ptLastPos ;
		RECT		_rrcHitArea [MAX_ANNOTATIONS] ;
		int			_rnOffsets [MAX_ANNOTATIONS] ;
		int			_rnLengths [MAX_ANNOTATIONS] ;
		WCHAR		_bufText [NBUFFER_ANNOTATION_TEXT] ;
	} ;
public:
	CUIStatus (CSkkImeTextService* pTSF, CSkkImeMgr* pIME) ;
	~CUIStatus () ;

    /* IUnknown methods	*/
    STDMETHODIMP QueryInterface (REFIID riid, void **ppvObj) ;
    STDMETHODIMP_(ULONG) AddRef (void) ;
    STDMETHODIMP_(ULONG) Release (void) ;

    /*	ITfTextLayoutSink */
    STDMETHODIMP	OnLayoutChange(ITfContext *pContext, TfLayoutCode lcode, ITfContextView *pContextView) ;

	HRESULT		_Open (ITfContext* pContextDocument, ITfRange* pRange) ;
	void		_Close () ;
	void		_Update () ;
	void		_Popup (BOOL fShow) ;
	BOOL		_IsContextStatusWindow (ITfContext* pContext) const ;
	BOOL		_IsActivep (ITfContext* pContext) const ;
	void		_SetTargetRect (const RECT* pRC) ;

private:
    HRESULT		_AdviseTextLayoutSink () ;
    HRESULT		_UnadviseTextLayoutSink () ;

	BOOL		_CreateWindow () ;
	void		_AdjustWindow (ITfContextView* pContextView) ;
#if defined (DEBUG) || defined (_DEBUG)
	void		_QueryWindowPos (ITfContextView* pContextView) ;
#endif
	void		_PaintUIStatusWnd (HWND hwnd, HDC hdc) ;
	BOOL		_Paint (HDC hdc) ;
	BOOL		_TextOut (HDC hdc, int nX, int nY, LPCWSTR wstr, int nwstr, int* pCursor, SIZE* pSZ) ;
	void		_RelayEventToTooltip (HWND hWnd, UINT uMessage) ;
	void		_Drag (UINT uMessage) ;
	int			_GetCursorPos (HDC hDC, LPCWSTR wstring, int nwstring, const POINT* lppoint) ;

	BOOL		_PaintCandidateList (HDC hDC, const IMECANDIDATES* pMyCand, LPRECT prcDraw) ;
	BOOL		_PaintCodeList (HDC hDC, const IMECANDIDATES* pMyCand, LPRECT prcDraw) ;
	BOOL		_PaintMinibufferText (HDC hDC, const IMECANDIDATES* pMyCand, LPRECT prcDraw) ;

	void		_AdjustRect (RECT* prcDest, const IMECANDIDATES* pMyCand, const RECT* prcSrc) ;
	int			_GetCandidateText (LPWSTR strDest, int nDest, TEXTREGION* pText, const IMECANDIDATES* pMyCand) ;
	int			_GetCodeMenuJumpText (LPWSTR strDest, int nDest, const IMECANDIDATES* pMyCand) ;
	int			_GetCodeMenu1Text (LPWSTR strDest, int nDest, const IMECANDIDATES* pMyCand) ;
	BOOL		_GetStatusTextSize (HDC hDC, LPCWSTR pwSText, int nSTextLen, int iCursorPos, int nDefaultWidth, SIZE* pSZ) ;

	void		_HitTestAnnotation (HWND hWnd, const POINT* pPT) ;
	BOOL		_HideToolTipp () ;
	BOOL		_ConfigureAnnotation () ;
	BOOL		_HandleMinibufferContextMenu () ;
	int			_PopupMinibufferContextMenu () ;
	HMENU		_CreateClipboardMenu () ;
	BOOL		_ShowBalloonTip (const RECT* pRect) ;

private:
	LRESULT		_OnUIStatusSetCursor (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
	LRESULT		_OnUIStatusMouseMove (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
	LRESULT		_OnUIStatusTimer (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
	LRESULT		_OnUIStatusButtonDown (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
	LRESULT		_OnUIStatusButtonUp (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;

private:
	static	LRESULT	CALLBACK	_UIStatusWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
	static	LRESULT	CALLBACK	_UIToolTipWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;

private:
	CSkkImeTextService*	_pTSF ;
	CSkkImeMgr*			_pIME ;
	ITfContext*			_pContext ;
	ITfRange*			_pRange ;
	DWORD				_dwCookieTextLayoutSink ;
	HWND				_hwnd ;
	HWND				_hwndTT ;
	RECT				_rcTarget ;
	BOOL				_bButtonPressed ;
	MYTOOLTIPINFO		_ToolTipInfo ;
	TCHAR				_bufToolTip [256] ;

	static const TCHAR	_szUIStatusWndClass   [] ;
	static const TCHAR	_szUIToolTipClassName [] ;

	LONG				_cRef ;
} ;



	
