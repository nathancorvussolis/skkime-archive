#if !defined (CSkkImeMgr_h)
#define	skkimmgr_h

class CSkkImeTextService ;
class CImeDoc ;

struct TEXTREGION ;
struct IMECANDIDATES ;

enum {
	SKKIME_NOT_PROCESS_KEY	= 0,
	SKKIME_PROCESS_KEY,
	SKKIME_PROCESS_KEY_TOGGLEIME,
} ;

class CSkkImeMgr  : public ITfTextLayoutSink {
private:
	CSkkImeTextService*		m_pTSF ;
	CImeDoc*				m_pDoc ;
	DWORD					m_dwCookieTextLayoutSink ;
	ITfContext*				m_pContext ;
	LONG					m_cRef ;

public:
	CSkkImeMgr (CSkkImeTextService* pTSF) ;
	~CSkkImeMgr () ;

    /* IUnknown methods	*/
    STDMETHODIMP QueryInterface (REFIID riid, void **ppvObj) ;
    STDMETHODIMP_(ULONG) AddRef (void) ;
    STDMETHODIMP_(ULONG) Release (void) ;

    /*	ITfTextLayoutSink */
    STDMETHODIMP	OnLayoutChange(ITfContext *pContext, TfLayoutCode lcode, ITfContextView *pContextView) ;
	HRESULT			AdviseTextLayoutSink (ITfContext* pContext) ;
	HRESULT			UnadviseTextLayoutSink () ;

	BOOL		_Init () ;
	void		_Uninit () ;

	int			QueryProcessKey (WPARAM wParam, LPARAM lParam) ;
	HRESULT		OnEditSession (ITfContext* pContext, TfEditCookie ec, WPARAM wParam, LPARAM lParam, BOOL* pfEaten) ;
	BOOL		OnClearSession (TfEditCookie ec, ITfComposition* pComposition) ;
	HRESULT		OnToggleImeSession (ITfContext* pContext, TfEditCookie ec) ;
	BOOL		OnReconvertSession (ITfContext* pContext, TfEditCookie ec, LPCWSTR wstrTEXT) ;
	HRESULT		OnChangeInputModeSession (ITfContext* pContext, TfEditCookie ec, UINT uConversionMode, UINT uSentenceMode, BOOL bUpdateCompartment) ;
	CImeDoc*	GetDocument () ;
	BOOL		UpdateConfig () ;
	BOOL		PaintStatusWindow (HWND hwnd, HDC hdc) ;
	void		OnSetFocus (BOOL fFocus) ;
	BOOL		OnKeyboardOpen (BOOL fOpen) ;

private:
	BOOL		_UpdateCompose (ITfContext* pContext, TfEditCookie ec) ;
	HRESULT		_UpdateDisplayAttribute (ITfContext* pContext, TfEditCookie ec) ;
	HRESULT		_QueryFocus (ITfContext* pContext, TfEditCookie ec) ;
	BOOL		_TextOut (HDC hdc, int nX, int nY, LPCWSTR wstr, int nwstr, int* pCursor, SIZE* pSZ) ;

	HRESULT		_UpdateUIElements (ITfContext* pContext, TfEditCookie ec) ;
	HRESULT		_CloseUIElements () ;
	HRESULT		_UpdateToolTipUI () ;
	HRESULT		_UpdateCandidateListUI () ;
	HRESULT		_PopupUIElements (BOOL bFocus) ;
	HRESULT		_LayoutUIElements (ITfContext* pContext, TfEditCookie ec) ;
	HRESULT		_CalculateUIElementLayout (RECT* prcDest, const RECT* prcSrc) ;
	int			_GetCandidateText (LPWSTR strDest, int nDest, TEXTREGION* pText, const IMECANDIDATES* pMyCand) ;
	int			_GetCodeMenuJumpText (LPWSTR strDest, int nDest, const IMECANDIDATES* pMyCand) ;
	int			_GetCodeMenu1Text (LPWSTR strDest, int nDest, const IMECANDIDATES* pMyCand) ;
	HRESULT		_GetRangeRect (ITfContext* pContext, TfEditCookie ec, ITfRange* pRange, RECT* pRect) ;
	BOOL		_GetStatusTextSize (HDC hDC, LPCWSTR pwSText, int nSTextLen, int iCursorPos, int nDefaultWidth, SIZE* pSZ) ;
} ;

#endif

