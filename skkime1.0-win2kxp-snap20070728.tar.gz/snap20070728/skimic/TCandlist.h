#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"

class CTReconvCandidateString : public ITfCandidateString {
private:
	WCHAR			_wszText [MAXCOMPLEN] ;
	int				_nIndex ;

    LONG			_cRef ;     // COM ref count

public:
	CTReconvCandidateString (LPCWSTR wstrText, int nIndex) {
		lstrcpynW (_wszText, wstrText, MAXCOMPLEN) ;
		_nIndex	= nIndex ;
		_cRef	= 1 ;
		return ;
	}

	virtual	~CTReconvCandidateString ()	{
	}

    STDMETHODIMP_(ULONG) AddRef(void) {
        return	++ _cRef ;
    }

    STDMETHODIMP_(ULONG) Release(void) {
        LONG cr = --_cRef ;
		
        assert(_cRef >= 0) ;
		
        if (_cRef == 0) {
            delete	this ;
        }
        return cr ;
    }

	STDMETHODIMP	GetString (BSTR* pbstr) {
		if (pbstr == NULL)
			return	E_INVALIDARG ;
		*pbstr	= SysAllocString (_wszText) ;
		return	(*pbstr != NULL)? S_OK : E_OUTOFMEMORY ;
	}
	STDMETHODIMP	GetIndex (ULONG* pnIndex) {
		if (pnIndex == NULL)
			return	E_INVALIDARG ;
		*pnIndex	= (ULONG) _nIndex ;
		return	S_OK ;
	}
} ;

class CTReconvEnumTfCandidates : public IEnumTfCandidates {
private:
	CTReconvCandidateList*	_pCandList ;
	ULONG					_nPos ;
    LONG					_cRef ;     // COM ref count

public:
	CTReconvEnumTfCandidates (CTReconvCandidateList* pCandList) {
		assert (pCandList != NULL) ;
		_pCandList	= pCandList ;
		_pCandList->AddRef () ;
		_nPos		= 0 ;
		_cRef		= 1 ;
		return ;
	}

	virtual	~CTReconvEnumTfCandidates () {
		if (_pCandList != NULL)
			_pCandList->Release () ;
		_pCandList	= NULL ;
	}

	STDMETHODIMP	Clone (IEnumTfCandidates** ppEnum) {
		CTReconvEnumTfCandidates*	pEnum ;

		if (ppEnum == NULL)
			return	S_OK ;	/* ? */

		pEnum	= new CTReconvEnumTfCandidates (_pCandList) ;
		if (pEnum == NULL)
			return	E_OUTOFMEMORY ;

		pEnum->_nPos	= _nPos ;
		*ppEnum			= pEnum ;
		return	S_OK ;
	}

	/*	���݈ʒu����  ulCount ���� Candidate ���m�ۂ��āA�m�ۂł����ʂ�
	 *	pcFetched �ɓ����ĕԂ����B
	 */
	STDMETHODIMP	Next (ULONG ulCount, ITfCandidateString** ppCand, ULONG* pcFetched) {
		ULONG	nCnt, nFetched, n ;

		if (ulCount > 0 && ppCand == NULL)
			return	E_INVALIDARG ;

		if (FAILED (_pCandList->GetCandidateNum (&nCnt)))
			return	S_FALSE ;

		nFetched	= ((_nPos + ulCount) > nCnt)? (nCnt - _nPos) : ulCount ;
		if (pcFetched != NULL)
			*pcFetched	= nFetched ;
		for (n = 0 ; n < nFetched ; n ++) {
			hr	= _pCandList->GetCandidate (_nPos + n, ppCand + n) ;
			if (FAILED (hr))
				return	hr ;
		}
		_nPos	+= nFetched ;	/* ����͕K�v�ȓ��삩�H */
		return	S_OK ;
	}

	STDMETHODIMP	Reset () {
		_nPos	= 0 ;
		return	S_OK ;
	}

	STDMETHODIMP	Skip (ULONG ulCount) {
		ULONG	nNewPos	= _nPos + ulCount ;
		ULONG	nCnt ;

		if (FAILED (_pCandList->GetCandidateNum (&nCnt)))
			return	S_FALSE ;
		if (nNewPos >= nCnt) {
			_nPos	= nCnt - 1 ;
			return	S_FALSE ;
		}
		_nPos	= nNewPos ;
		return	S_OK ;
	}

    STDMETHODIMP_(ULONG) AddRef(void) {
        return	++ _cRef ;
    }

    STDMETHODIMP_(ULONG) Release(void) {
        LONG cr = --_cRef ;
		
        assert(_cRef >= 0) ;
		
        if (_cRef == 0) {
            delete	this ;
        }
        return cr ;
    }
} ;

/*	�t�ϊ��̃��X�g���\�z���邱�Ƃ����݂ł��Ȃ��̂ŁA�^����ꂽ range
 *	�����̂܂ܓ��邱�ƂɂȂ�B
 */
class CTReconvCandidateList : public ITfCandidateList {
private:
	WCHAR				_wszCandidate [MAXCOMPLEN] ;
    LONG				_cRef ;     // COM ref count
	ULONG				_nResult ;
	TfCandidateResult	_imcr ;

public:
	CTReconvCandidateList () {
		_nResult	= (ULONG) -1 ;
		_imcr		= CAND_CANCELED ;
		_cRef		= 1 ;
	}

	virtual			~CTReconvCandidateList () {
	}

	STDMETHODIMP	EnumCandidates (IEnumTfCandidates** ppEnum) {
		if (ppEnum == NULL)
			return	E_INVALIDARG ;
		*ppEnum	= new CTReconvEnumTfCandidates (this) ;
		return	(*ppEnum != NULL)? S_OK : E_OUTOFMEMORY ;
	}

	STDMETHODIMP	GetCandidate (ULONG nIndex, ITfCandidateString** pCand) {
		if (nIndex != 0)
			return	E_INVALIDARG ;
		if (pCand == NULL)
			return	E_INVALIDARG ;
		*pCand	= new CTReconvCandidateString (_wszCandidate, nIndex) ;
		return	(*pCand != NULL)? S_OK : E_OUTOFMEMORY ;
	}

	STDMETHODIMP	GetCandidateNum (ULONG* pnCnt) {
		if (pnCnt == NULL)
			return	E_INVALIDARG ;
		*pnCnt	= 1 ;
		return	S_OK ;
	}

	STDMETHODIMP	SetResult (ULONG nIndex, TfCandidateResult imcr) {
		if (imcr != CAND_CANCELED && nIndex != 0)
			return	E_FAIL ;
		_nResult	= nIndex ;
		_imcr		= imcr ;
		return	S_OK ;
	}

    STDMETHODIMP_(ULONG) AddRef(void) {
        return	++ _cRef ;
    }

    STDMETHODIMP_(ULONG) Release(void) {
        LONG cr = --_cRef ;
		
        assert(_cRef >= 0) ;
		
        if (_cRef == 0) {
            delete	this ;
        }
        return cr ;
    }
} ;

class CGetReconversionEditSession : public CEditSessionBase
{
  public:

}

STDAPI
CSkkImeTextService::QueryRange (
	ITfRange*			pRange,
	ITfRange**			ppNewRange,
	BOOL*				pfConvertable)
{
	HRESULT	hr ;

	/*	�{���͔͈͒��������Ȃ���΂Ȃ�Ȃ����c�B
	 */
	if (pRange == NULL)
		return	E_INVALIDARG ;

	if (ppNewRange != NULL) {
		hr	= pRange->Clone (ppNewRange) ;
		if (FAILED (hr))
			return	hr ;
	}
	if (pfConvertable != NULL)
		*pfConvertable	= TRUE ;
	return	S_OK ;
}

STDAPI
CSkkImeTextService::GetReconversion (
	ITfRange*			pRange,
	ITfCandidateList**	ppCandList)
{
	CGetReconversionEditSession*	pEditSession ;
	HRESULT	hr ;

	if (pRange == NULL || ppCandList == NULL)
		return	E_INVALIDARG ;

	if (FAILED (pRange->GetContext (&pContext)))
		return	E_INVALIDARG ;

	pEditSession	= CGetReconversionEditSession (this, pContext) ;
	if (pEditSession == NULL)
		return	E_OUTOFMEMORY ;

	pContext->RequestEditSession (_tfClientId, pEditSession, TF_ES_ASYNCDONTCARE | TF_ES_READ, &hr) ;
	if (SUCCEEDED (hr)) {
		pCandList	= pEditSession->GetCandidateList () ;
		*ppCandList	= pCandList ;
	}
	pEditSession->Release () ;
	return	hr ;
}

STDAPI
CSkkImeTextService::Reconvert ()
{
}

