#include "globals.h"
#include "skimic.h"

HRESULT
CSkkImeTextService::CreateInstance (
	IUnknown*		pUnkOuter,
	REFIID			riid,
	void**			ppvObj)
{
	CSkkImeTextService*	pTSF ;
	HRESULT				hr ;

	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
	if (pUnkOuter != NULL)
		return	CLASS_E_NOAGGREGATION ;

	pTSF	= new CSkkImeTextService ;
	if (pTSF == NULL)
		return	E_OUTOFMEMORY ;
	hr		= pTSF->QueryInterface (riid, ppvObj) ;
	pTSF->Release () ;
	return	hr ;
}

CSkkImeTextService::CSkkImeTextService ()
{
	DllAddRef () ;
	_pThreadMgr							= NULL ;
	_tfClientId							= TF_CLIENTID_NULL ;
	_pCModeLangBarItem					= NULL ;
	_dwThreadMgrEventSinkCookie			= TF_INVALID_COOKIE ;
	_dwThreadFocusSinkCookie			= TF_INVALID_COOKIE ;
	_dwTextEditSinkCookie				= TF_INVALID_COOKIE ;
	_dwCompKeyboardOpenCloseCookie		= TF_INVALID_COOKIE ;
	_dwCompKeyboardDisabledCookie		= TF_INVALID_COOKIE ;
	_dwCompEmptyContextCookie			= TF_INVALID_COOKIE ;
	_pTextEditSinkContext				= NULL ;
	_pComposition						= NULL ;
	_pSkkIme							= NULL ;
    _pIMELangBarItem					= NULL ;
    _pCModeLangBarItem					= NULL ;
	_pRCandidateList					= NULL ;
	_fCleaningUp						= FALSE ;
	_gaDisplayAttributeInput			= TF_INVALID_GUIDATOM ;
	_gaDisplayAttributeConverted		= TF_INVALID_GUIDATOM ;
	_pCandidateListUIElement			= NULL ;
	_pToolTipUIElement					= NULL ;
	_dwActivateFlag						= 0 ;
	_cRef								= 1 ;
}

CSkkImeTextService::~CSkkImeTextService ()
{
	DllRelease () ;
	return ;
}

STDAPI
CSkkImeTextService::QueryInterface (
	REFIID			riid,
	void**			ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::QueryInterface ()\n"))) ;

	*ppvObj	= NULL ;
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfTextInputProcessorEx)) {
		*ppvObj	= (ITfTextInputProcessorEx *)this ;
	} else if (IsEqualIID (riid, IID_ITfTextInputProcessor)) {
		*ppvObj	= (ITfTextInputProcessor*)this ;
#else
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfTextInputProcessor)) {
		*ppvObj	= (ITfTextInputProcessor*)this ;
#endif
	} else if (IsEqualIID (riid, IID_ITfThreadMgrEventSink)) {
		*ppvObj	= (ITfThreadMgrEventSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfThreadFocusSink)) {
		*ppvObj	= (ITfThreadFocusSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfTextEditSink)) {
		*ppvObj	= (ITfTextEditSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfKeyEventSink)) {
		*ppvObj	= (ITfKeyEventSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfFunctionProvider)) {
		*ppvObj	= (ITfFunctionProvider *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnConfigure)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = ITfFnConfigure\n"))) ;
		*ppvObj	= (ITfFnConfigure *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnConfigureRegisterWord)) {
		*ppvObj	= (ITfFnConfigureRegisterWord *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnReconversion)) {
		*ppvObj	= (ITfFnReconversion *) this ;
#if defined (not_work)
	} else if (IsEqualIID (riid, IID_ITfFnPropertyUIStatus)) {
		*ppvObj	= (ITfFnPropertyUIStatus *) this ;
#endif
	} else if (IsEqualIID (riid, IID_ITfDisplayAttributeProvider)) {
		*ppvObj	= (ITfDisplayAttributeProvider *)this ;
	} else if (IsEqualIID (riid, IID_ITfCleanupContextDurationSink)) {
		*ppvObj	= (ITfCleanupContextDurationSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfCleanupContextSink)) {
		*ppvObj	= (ITfCleanupContextSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfCompartmentEventSink)) {
		*ppvObj	= (ITfCompartmentEventSink *) this ;
#if defined (__ITfToolTipUIElement_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfToolTipUIElement)) {
		*ppvObj	= (ITfToolTipUIElement *)_pToolTipUIElement ;
#endif
#if defined (__ITfCandidateListUIElement_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfCandidateListUIElement)) {
		*ppvObj	= (ITfCandidateListUIElement *)_pCandidateListUIElement ;
#endif
#if defined (__ITfCandidateListUIElementBehavior_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfCandidateListUIElementBehavior)) {
		*ppvObj	= (ITfCandidateListUIElementBehavior *)_pCandidateListUIElement ;
#endif
	}

	if (*ppvObj) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

STDAPI_(ULONG)	CSkkImeTextService::AddRef ()
{
	return	++ _cRef ;
}

STDAPI_(ULONG)	CSkkImeTextService::Release ()
{
	LONG	cr	= -- _cRef ;

	assert (_cRef >= 0) ;

	if (_cRef == 0) 
		delete	this ;

	return	cr ;
}

STDAPI
CSkkImeTextService::Activate (
	ITfThreadMgr*		pThreadMgr,
	TfClientId			tfClientId)
{
	return	ActivateEx (pThreadMgr, tfClientId, 0) ;
}

STDAPI
CSkkImeTextService::ActivateEx (
	ITfThreadMgr*		pThreadMgr,
	TfClientId			tfClientId,
	DWORD				dwFlags)
{
	//ITfDocumentMgr*		pFocusDoc ;
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::Activate (0x%x)\n"), tfClientId)) ;

	if (pThreadMgr == NULL)
		return	E_INVALIDARG ;

	_pThreadMgr		= pThreadMgr ;
	_pThreadMgr->AddRef () ;

	_tfClientId		= tfClientId ;

	if (! _InitThreadMgrSink ()) {
		goto	exit_error ;
	}
	if (! _InitKeystrokeSink ()) {
		goto	exit_error ;
	}
    if (!_InitPreservedKey ()) {
        goto	exit_error ;
	}
	if (!_InitSkkImeMgr ()) {
		goto	exit_error ;
	}
	if (!_InitGlobalCompartment ()) {
		goto	exit_error ;
	}
	if (!_InitFunctionProvider ()) {
		goto	exit_error ;
	}
	if (!_InitReconversion ()) {
		goto	exit_error ;
	}
	if (! _InitDisplayAttributeGuidAtom ()) {
		goto	exit_error ;
	}
	if (! _InitLangBarItem ()) {
		goto	exit_error ;
	}
	if (! _InitUIElements (dwFlags)) {
		/* ����͎�������ĂȂ��\�������邩��G���[�͖�������B*/
	}
	_dwActivateFlag	= dwFlags ;
	return	S_OK ;

 exit_error:
	Deactivate () ;
	return	E_FAIL ;
}

STDAPI
CSkkImeTextService::Deactivate ()
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::Deactivate (0x%x)\n"), _tfClientId)) ;

	_UninitThreadMgrSink () ;
	/*	UninitLangBarItem (ButtonItem �̍폜) �����̒i�K�Ŏ��s����ƁA��͂� RemoveItem ��
	 *	�ُ�Ɏ��Ԃ��������Ă��܂����ƂɂȂ�B_pThreadMgr �� NULL �ł����삷��悤�ɏ�������
	 *	��̂��������悤���B
	*/
	_UninitLangBarItem () ;
    _UninitKeystrokeSink();
    _UninitPreservedKey () ;
    _InitTextEditSink (NULL) ;
	_UninitSkkImeMgr () ;
	_UninitGlobalCompartment () ;
	_UninitFunctionProvider () ;
	_UninitReconversion () ;
	_UninitUIElements () ;

	SafeReleaseClear (_pThreadMgr) ;
	_tfClientId	= TF_CLIENTID_NULL ;
	return	S_OK ;
}

BOOL
CSkkImeTextService::_GetFocusWnd (
	HWND*			phWnd)
{
    ITfDocumentMgr *pFocusDoc;
	ITfContext*		pContext ;
	ITfContextView*	pContextView ;
	BOOL			fRetval	= FALSE ;

	if (_pThreadMgr == NULL)
		return	FALSE ;
	if (_pThreadMgr->GetFocus (&pFocusDoc) != S_OK)
		return	FALSE ;
	if (pFocusDoc->GetTop (&pContext) == S_OK) {
		if (pContext->GetActiveView (&pContextView) == S_OK) {
			pContextView->GetWnd (phWnd) ;
			fRetval	= TRUE ;
			pContextView->Release () ;
		}
		pContext->Release () ;
	}
	pFocusDoc->Release () ;
	return	fRetval ;
}

TfClientId
CSkkImeTextService::_GetClientId ()
{
	return	_tfClientId ;
}

ITfThreadMgr*
CSkkImeTextService::_GetThreadMgr ()
{
	return	_pThreadMgr ;
}

HRESULT
CSkkImeTextService::_GetFocusContext (
	ITfContext**	ppContext)
{
	HRESULT         hr ;
	ITfDocumentMgr*	pFocusDoc ;
	ITfContext*		pContext ;

	if (ppContext == NULL || _pThreadMgr == NULL)
		return	E_INVALIDARG ;

	hr	= _pThreadMgr->GetFocus (&pFocusDoc) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pFocusDoc->GetTop (&pContext) ;
	if (FAILED (hr))
		goto	exit_func ;
	*ppContext	= pContext ;	/* [must] Caller must release pContext. */
exit_func:
	if (pFocusDoc != NULL)
		pFocusDoc->Release () ;
	return	hr ;
}


