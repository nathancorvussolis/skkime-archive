//
// compart.cpp
//
// Compartment example.
////		http://msdn.microsoft.com/downloads/samples/internet/default.asp?url=/downloads/samples/internet/TextServicesFrameWork/Keyboard/default.asp
//

#include "globals.h"
#include "skimic.h"
#include "editsess.h"
#include "skkimmgr.h"

class CKeyboardInputModeChangeSession : public CEditSessionBase
{
public:
    CKeyboardInputModeChangeSession (ITfContext *pContext, UINT uConversionMode, UINT uSentenseMode, BOOL bUpdate, CSkkImeMgr* pSkkIme) :
		CEditSessionBase(pContext)
	{
		_uConversionMode 	= uConversionMode ;
		_uSentenseMode		= uSentenseMode ;
		_bUpdate			= bUpdate ;
		_pSkkIme			= pSkkIme ;
		return ;
	}
	
    // ITfEditSession
    STDMETHODIMP DoEditSession (TfEditCookie ec) ;
	
private:
    UINT		_uConversionMode ;
	UINT		_uSentenseMode ;
	BOOL		_bUpdate ;
	CSkkImeMgr*	_pSkkIme ;
} ;


STDAPI
CSkkImeTextService::OnChange (
	REFGUID		rguidCompartment)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange ()\n"))) ;

	// nothing to do in this sample
	if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_OPENCLOSE)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_KEYBOARD_OPENCLOSE\n"))) ;
		/* Application ������ Keybaord �� Open/Close �����䂳�ꂽ�Ǝv���B*/
		_UpdateLangBarItem () ;
#if defined (TF_CONVERSIONMODE_NATIVE)
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION)) {
		unsigned int	uConversionMode ;

		/* ConversionMode �̕ύX���ʒm���ꂽ�B*/
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION\n"))) ;
		if (SUCCEEDED (_GetKeyboardInputModeConversion (&uConversionMode))) {
			ITfContext*		pContext ;

			if (SUCCEEDED (_GetFocusContext (&pContext))) {
				CEditSessionBase*	pEditSession ;
				HRESULT				hrEaten ;

				pEditSession	= new CKeyboardInputModeChangeSession (pContext, uConversionMode, 0, FALSE, _pSkkIme) ;
				if (pEditSession != NULL) {
					(void) pContext->RequestEditSession (_tfClientId, pEditSession, TF_ES_SYNC | TF_ES_READWRITE, &hrEaten) ;
					pEditSession->Release () ;
					delete	pEditSession ;
				}
				pContext->Release () ;
			}
		}
#endif
#if defined (TF_SENTENCEMODE_NONE)
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE)) {
		/* SentenseMode �̕ύX���ʒm���ꂽ�c���A����͎g���Ȃ��̂ňӖ��͂Ȃ��B*/
#endif
#if defined (not_work)
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_KEYBOARD_DISABLED)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_KEYBOARD_DISABLED\n"))) ;
	} else if (IsEqualGUID (rguidCompartment, GUID_COMPARTMENT_EMPTYCONTEXT)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnChange::GUID_COMPARTMENT_EMPTYCONTEXT\n"))) ;
#endif
	}
    return	S_OK ;
}

/*========================================================================*
 */
/*EXTERN_C const GUID GUID_COMPARTMENT_KEYBOARD_OPENCLOSE;*/
/*EXTERN_C const GUID GUID_COMPARTMENT_KEYBOARD_DISABLED;*/

BOOL
CSkkImeTextService::_InitContextCompartment(
	ITfContext*			pContext)
{
#if defined (not_work)
    ITfCompartmentMgr*	pCompMgr ;
    ITfCompartment*		pCompartment ;
	ITfSource*			pSource	= NULL ;
    HRESULT				hr ;

    // we want the mgr associated with pContext
    if (FAILED (pContext->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr)))
        return	FALSE ;
	
    hr	= pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_DISABLED, &pCompartment);
	if (SUCCEEDED (hr)) {
		hr	= pCompartment->QueryInterface (IID_ITfSource, (LPVOID*)&pSource) ;
		if (SUCCEEDED (hr)) {
			hr = pSource->AdviseSink (IID_ITfCompartmentEventSink, (ITfCompartmentEventSink*)this, &_dwCompKeyboardDisabledCookie) ;
			pSource->Release () ;
		}
		pCompartment->Release () ;
	}

	hr	= pCompMgr->GetCompartment (GUID_COMPARTMENT_EMPTYCONTEXT, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr	= pCompartment->QueryInterface (IID_ITfSource, (LPVOID*)&pSource) ;
		if (SUCCEEDED (hr)) {
			hr = pSource->AdviseSink (IID_ITfCompartmentEventSink, (ITfCompartmentEventSink*)this, &_dwCompEmptyContextCookie) ;
			pSource->Release () ;
		}
		pCompartment->Release () ;
	}
    pCompMgr->Release () ;
    return	(hr == S_OK) ;
#endif
	return	TRUE ;
	UNREFERENCED_PARAMETER (pContext) ;
}

void
CSkkImeTextService::_UninitContextCompartment (
	ITfContext*			pContext)
{
#if defined (not_work)
    ITfCompartmentMgr*	pCompMgr ;
	ITfCompartment*		pCompartment ;
	ITfSource*			pSource	= NULL ;
	HRESULT				hr ;

    // we want the mgr associated with pContext
    if (FAILED (pContext->QueryInterface(IID_ITfCompartmentMgr, (void **)&pCompMgr)))
        return ;

    hr	= pCompMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_DISABLED, &pCompartment) ;
    if (SUCCEEDED (hr)) {
		hr	= pCompartment->QueryInterface (IID_ITfSource, (LPVOID*)&pSource) ;
		if (SUCCEEDED (hr)) {
			hr = pSource->UnadviseSink (_dwCompKeyboardDisabledCookie) ;
			pSource->Release () ;
		}
		pCompartment->Release () ;
	}
    hr	= pCompMgr->GetCompartment (GUID_COMPARTMENT_EMPTYCONTEXT, &pCompartment) ;
    if (SUCCEEDED (hr)) {
		hr	= pCompartment->QueryInterface (IID_ITfSource, (LPVOID*)&pSource) ;
		if (SUCCEEDED (hr)) {
			hr = pSource->UnadviseSink (_dwCompEmptyContextCookie) ;
			pSource->Release () ;
		}
		pCompartment->Release () ;
	}
    pCompMgr->Release () ;
#endif
	_dwCompKeyboardDisabledCookie	= TF_INVALID_COOKIE ;
	_dwCompEmptyContextCookie		= TF_INVALID_COOKIE ;
	return ;
	UNREFERENCED_PARAMETER (pContext) ;
}

BOOL
CSkkImeTextService::_InitGlobalCompartment()
{
    ITfCompartmentMgr*	pCompartmentMgr ;
    ITfCompartment*		pCompartment ;
	HRESULT				hr ;
    BOOL				fRet ;

	if (_pThreadMgr == NULL)
		return	FALSE ;

    // we want the global mgr
	hr	= _pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompartmentMgr) ;
	if (FAILED (hr))
        return FALSE;

    fRet	= FALSE ;
    if (pCompartmentMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &pCompartment) != S_OK)
        goto	Exit ;

    fRet	= AdviseSink (pCompartment, (ITfCompartmentEventSink *)this, IID_ITfCompartmentEventSink, &_dwCompKeyboardOpenCloseCookie) ;
    pCompartment->Release () ;
    if (!fRet) {
		_dwCompKeyboardOpenCloseCookie	= TF_INVALID_COOKIE ;
    }

Exit:
    pCompartmentMgr->Release();
    return fRet;
}

void
CSkkImeTextService::_UninitGlobalCompartment ()
{
    ITfCompartmentMgr*	pCompartmentMgr ;
    ITfCompartment*		pCompartment ;
	HRESULT				hr ;

	if (_pThreadMgr == NULL)
		return ;

    // we want the global mgr
	hr	= _pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompartmentMgr) ;
	if (FAILED (hr))
		return ;

    // unadvise our event sink
    if (pCompartmentMgr->GetCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &pCompartment) == S_OK) {
        UnadviseSink (pCompartment, &_dwCompKeyboardOpenCloseCookie) ;
        pCompartment->Release () ;
    }

    // let the system free resources associated with the compartment on this
    // thread
    /*pCompartmentMgr->ClearCompartment(_tfClientId, c_guidMarkGlobalCompartment);*/
    pCompartmentMgr->Release () ;
	return ;
}

BOOL
CSkkImeTextService::_IsKeyboardDisabled ()
{
    ITfDocumentMgr*		pDocMgrFocus	= NULL ;
	ITfContext*			pContext		= NULL ;
	HRESULT				hr ;
	BOOL				fDisabled	= FALSE ;
	VARIANT				var ;

	if (_pThreadMgr == NULL)
		goto	Exit ;
	hr	= _pThreadMgr->GetFocus (&pDocMgrFocus) ;
	if (FAILED (hr) || pDocMgrFocus == NULL) 
		goto	Exit ;

	hr	= pDocMgrFocus->GetTop (&pContext) ; 
    if (FAILED (hr) || pContext == NULL) 
        goto	Exit ;

	if (SUCCEEDED (_GetContextCompartment (pContext, GUID_COMPARTMENT_KEYBOARD_DISABLED, &var))) {
		if (var.vt == VT_I4) {
			// Even VT_EMPTY, GetValue() can succeed
			fDisabled = (BOOL)var.lVal ;
			DEBUGPRINTF ((TEXT ("OpenClose (%d)\n"), (int)var.lVal)) ;
		}
		VariantClear (&var) ;
	}
	if (SUCCEEDED (_GetContextCompartment (pContext, GUID_COMPARTMENT_EMPTYCONTEXT, &var))) {
		if (var.vt == VT_I4) {
			// Even VT_EMPTY, GetValue() can succeed
			fDisabled = ! fDisabled? (BOOL)var.lVal : TRUE ;
			DEBUGPRINTF ((TEXT ("EmptyContext (%d)\n"), (int)var.lVal)) ;
		}
		VariantClear (&var) ;
	}
  Exit:
	if (pContext != NULL)
		pContext->Release () ;
    if (pDocMgrFocus != NULL)
        pDocMgrFocus->Release () ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_IsKeyboardDisabled (%d)\n"), fDisabled)) ;
	return	fDisabled ;
}

BOOL
CSkkImeTextService::_IsKeyboardOpen ()
{
	VARIANT		var ;
	BOOL		fOpen	= FALSE ;

	if (FAILED (_GetGlobalCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &var)))
		return	FALSE ;
	if (var.vt == VT_I4)
		fOpen	= (BOOL) var.lVal ;
	VariantClear (&var) ;
	return	fOpen ;
}

HRESULT
CSkkImeTextService::_SetKeyboardOpen (
	BOOL			fOpen)
{
	VARIANT				var ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_SetKeyboardOpen (%d)\n"), fOpen)) ;
	var.vt		= VT_I4 ;
	var.lVal	= fOpen ;
	return	_SetGlobalCompartment (GUID_COMPARTMENT_KEYBOARD_OPENCLOSE, &var) ;
}

#if defined (TF_CONVERSIONMODE_NATIVE)
HRESULT
CSkkImeTextService::_GetKeyboardInputModeConversion (
	unsigned int*		piModeConversion)
{
	VARIANT			var ;
	HRESULT			hr ;

	hr	= _GetGlobalCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION, &var) ;
	if (FAILED (hr))
		return	hr ;
	if (var.vt == VT_I4) {
		if (piModeConversion != NULL)
			*piModeConversion	= var.lVal ;
	} else {
		hr	= E_FAIL ;
	}
	VariantClear (&var) ;
	return	hr ;
}

HRESULT
CSkkImeTextService::_SetKeyboardInputModeConversion (
	unsigned int			iModeConversion)
{
	VARIANT				var ;

	var.vt		= VT_I4 ;
	var.lVal	= iModeConversion ;
	return	_SetGlobalCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION, &var) ;
}
#endif

#if defined (TF_SENTENCEMODE_NONE)
HRESULT
CSkkImeTextService::_GetKeyboardInputModeSentence (unsigned int* piModeSentence) 
{
	VARIANT			var ;
	HRESULT			hr ;

	hr	= _GetGlobalCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE, &var) ;
	if (FAILED (hr))
		return	hr ;
	if (var.vt == VT_I4) {
		if (piModeSentence != NULL)
			*piModeSentence	= var.lVal ;
	} else {
		hr	= E_FAIL ;
	}
	VariantClear (&var) ;
	return	hr ;
}

HRESULT
CSkkImeTextService::_SetKeyboardInputModeSentence (unsigned int iModeSentence) 
{
	VARIANT		var ;
	var.vt		= VT_I4 ;
	var.lVal	= iModeSentence ;
	return	_SetGlobalCompartment (GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE, &var) ;
}
#endif

HRESULT
CSkkImeTextService::_SetGlobalCompartment (
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	if (_pThreadMgr == NULL)
		return	E_FAIL ;

	hr	= _pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->SetValue (_tfClientId, pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

HRESULT
CSkkImeTextService::_GetGlobalCompartment (
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	if (_pThreadMgr == NULL)
		return	E_FAIL ;

	hr	= _pThreadMgr->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->GetValue (pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

HRESULT
CSkkImeTextService::_SetContextCompartment (
	ITfContext*	pContext,
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	hr	= pContext->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->SetValue (_tfClientId, pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

HRESULT
CSkkImeTextService::_GetContextCompartment (
	ITfContext*	pContext,
	REFGUID		rguidCompartment,
	VARIANT*	pValue)
{
    ITfCompartmentMgr*	pCompMgr	= NULL ;
	HRESULT				hr ;
	ITfCompartment*		pCompartment ;

	if (pValue == NULL)
		return	E_INVALIDARG ;

	hr	= pContext->QueryInterface (IID_ITfCompartmentMgr, (void **)&pCompMgr) ;
	if (FAILED (hr)) 
		return	hr ;

	hr	= pCompMgr->GetCompartment (rguidCompartment, &pCompartment) ;
	if (SUCCEEDED (hr)) {
		hr			= pCompartment->GetValue (pValue) ;
		pCompartment->Release () ;
	}
	pCompMgr->Release () ;
    return	hr ;
}

/*========================================================================
 *	class CKeyboardInputModeChangeSession
 */
STDAPI
CKeyboardInputModeChangeSession::DoEditSession (TfEditCookie ec) 
{
	if (_pSkkIme == NULL || _pContext == NULL)
		return	E_FAIL ;

	(void) _pSkkIme->OnChangeInputModeSession (_pContext, ec, _uConversionMode, _uSentenseMode, _bUpdate) ;
	return	S_OK ;
}



