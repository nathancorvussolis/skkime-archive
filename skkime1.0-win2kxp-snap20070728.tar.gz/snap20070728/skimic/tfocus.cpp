/*	ITfThreadFocusSink implementation
 *
 */
#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"

STDAPI
CSkkImeTextService::OnSetThreadFocus ()
{
	DEBUGPRINTF ((TEXT ("OnSetThreadFocus (0x%lx)\n"), _tfClientId)) ;
	if (_pSkkIme != NULL) {
		_UpdateLangBarItem () ;
		_pSkkIme->OnSetFocus (TRUE) ;
	}
    return S_OK;
}

/*	OnKillThreadFocus
 *
 *	Called by the system when the thread/appartment of this text service loses
 *	the ui focus.
 */
STDAPI
CSkkImeTextService::OnKillThreadFocus ()
{
	DEBUGPRINTF ((TEXT ("OnKillThreadFocus (0x%lx)\n"), _tfClientId)) ;
	if (_pSkkIme != NULL)
		_pSkkIme->OnSetFocus (FALSE) ;
    return	S_OK ;
}

