#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "IME\ImeDoc.h"
#include "CandListUI.h"
#include "ToolTipUI.h"
#include "editsess.h"

#define	REGPATH_GENERIC					TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.0\\Generic")
#define	REGPATH_ALWAYS_OPEN_KANAMODE	TEXT("always-open-kana-mode")

struct MYMENUITEMINFO {
	UINT				m_fMask ;
	UINT				m_fType ;
	DWORD				m_wID ;
	LPTSTR				m_dwTypeData ;
} ;

/*...
 */
#define	DEFAULT_MINIBUF_CHARWIDTH	80

extern	int		_HasWordAnnotation (LPCWSTR pWord, int nWord) ;
extern	HFONT	_CheckNativeCharset (HDC hDC) ;

/*========================================================================
 *	class CGetTextExtentEditSession
 */
class CGetTextExtentEditSession : public CEditSessionBase
{
public:
    CGetTextExtentEditSession (CSkkImeTextService* pTSF, ITfContext* pContext, ITfContextView* pContextView, ITfRange* pRange, RECT* pRect) : CEditSessionBase (pContext)
    {
		m_pTSF				= pTSF ;
        _pContextView		= pContextView ;
        _pRange				= pRange ;
		_pRect				= pRect ;
    }

    // ITfEditSession
    STDMETHODIMP	DoEditSession (TfEditCookie ec) ;

private:
	CSkkImeTextService*	m_pTSF ;
    ITfContextView*		_pContextView ;
    ITfRange*			_pRange ;
	RECT*				_pRect ;
} ;

STDAPI
CGetTextExtentEditSession::DoEditSession (TfEditCookie ec)
{
	RECT					rc, rcTemp ;
    BOOL					fClipped ;
	HRESULT					hr ;

	if (FAILED (_pContextView->GetScreenExt (&rcTemp)))
		return	E_FAIL ;

	hr	= _pContextView->GetTextExt (ec, _pRange, &rc, &fClipped) ;
	if (hr == S_OK && rc.top < rc.bottom) {
		//rc.left		= rcTemp.left ;
		//rc.right	= rcTemp.right ;
		if (rc.top > rcTemp.bottom || rc.bottom < rcTemp.top) {
			DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d) fail?\n"), rc.left, rc.right, rc.top, rc.bottom)) ;
			rc.top		= rcTemp.top ;
			rc.bottom	= rcTemp.bottom ;
			if (_pRect)
				*_pRect	= rcTemp ;
		} else {
			DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d)\n"), rc.left, rc.right, rc.top, rc.bottom)) ;
			if (_pRect)
				*_pRect	= rc ;
		}
	    return	S_OK ;
	} else {
		DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d) failed(0x%x),(range:%p)\n"),
			rc.left, rc.right, rc.top, rc.bottom,
			hr, _pRange)) ;
		if (_pRect)
			*_pRect	= rcTemp ;
		return	S_OK ;
	}
}

/*========================================================================
 *	class CSkkImeMgr
 */
CSkkImeMgr::CSkkImeMgr (CSkkImeTextService* pTSF)
{
	m_pTSF						= pTSF ;
	m_pTSF->AddRef () ;
	m_pDoc						= NULL ;
	m_dwCookieTextLayoutSink	= TF_INVALID_COOKIE ;
	m_pContext					= NULL ;
	m_cRef						= 1 ;
	DllAddRef () ;
	return ;
}

CSkkImeMgr::~CSkkImeMgr ()
{
	if (m_pDoc != NULL) {
		delete	m_pDoc ;
		m_pDoc	= NULL ;
	}
	m_pTSF->Release () ;
	m_pTSF	= NULL ;
	DllRelease () ;
	return ;
}

STDAPI
CSkkImeMgr::QueryInterface (REFIID riid, void** ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
    if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfTextLayoutSink)) {
        *ppvObj = (ITfTextLayoutSink *)this ;
    }

    if (*ppvObj) {
        AddRef () ;
        return	S_OK ;
    }
    return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CSkkImeMgr::AddRef ()
{
    return	++m_cRef ;
}

STDAPI_(ULONG)
CSkkImeMgr::Release ()
{
    LONG	cr = --m_cRef ;

    assert (m_cRef >= 0) ;

    if (m_cRef == 0) {
        delete	this ;
    }
    return	cr ;
}

STDAPI
CSkkImeMgr::OnLayoutChange (
	ITfContext*			pContext,
	TfLayoutCode		lcode,
	ITfContextView*		pContextView)
{
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::OnLayoutChange (%d)\n"), lcode)) ;

	if (pContext != m_pContext)
		return	S_OK ;

    switch (lcode) {
	case	TF_LC_CREATE:
	case	TF_LC_CHANGE:
		if (pContext != NULL && m_pTSF != NULL)
			_UpdateUIElements (pContext, m_pTSF->_GetClientId ()) ;
		break ;

	case TF_LC_DESTROY:
		_CloseUIElements () ;
		break ;
	default:
		break ;
    }
    return	S_OK ;
}

HRESULT
CSkkImeMgr::AdviseTextLayoutSink (ITfContext* pContext)
{
    HRESULT		hr ;
    ITfSource*	pSource	= NULL ;

	if (m_pContext == pContext)
		return	S_OK ;

	if (m_pContext != NULL) 
		UnadviseTextLayoutSink () ;

	if (pContext == NULL) 
		return	S_FALSE ;

    hr	= E_FAIL ;
    if (FAILED (pContext->QueryInterface (IID_ITfSource, (void **)&pSource)))
        goto	Exit ;

    if (FAILED (pSource->AdviseSink (IID_ITfTextLayoutSink, (ITfTextLayoutSink *)this, &m_dwCookieTextLayoutSink)))
        goto	Exit ;

    hr	= S_OK ;
	m_pContext	= pContext ;
	m_pContext->AddRef () ;
Exit:
    if (pSource != NULL)
        pSource->Release () ;
    return	hr ;
}

HRESULT
CSkkImeMgr::UnadviseTextLayoutSink ()
{
    HRESULT		hr ;
    ITfSource*	pSource	= NULL ;

    hr	= E_FAIL ;
    if (m_pContext == NULL)
        goto	Exit ;

    if (FAILED (m_pContext->QueryInterface (IID_ITfSource, (void **)&pSource)))
        goto	Exit ;

    if (FAILED (pSource->UnadviseSink (m_dwCookieTextLayoutSink)))
        goto	Exit;

    hr	= S_OK ;
Exit:
	if (m_pContext != NULL) {
		m_pContext->Release () ;
		m_pContext	= NULL ;
	}
	m_dwCookieTextLayoutSink	= TF_INVALID_COOKIE ;
    if (pSource != NULL)
        pSource->Release () ;
    return	hr ;
}

/*========================================================================
 */
BOOL
CSkkImeMgr::_Init ()
{
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_Init ()\n"))) ;

	m_pDoc	= new CImeDoc () ;
	if (m_pDoc == NULL)
		return	FALSE ;
	return	m_pDoc->Init () ;
}

void
CSkkImeMgr::_Uninit ()
{
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_Uninit ()\n"))) ;

	_CloseUIElements () ;

	if (m_pDoc != NULL) {
		delete	m_pDoc ;
		m_pDoc	= NULL ;
	}
	return ;
}

/*	�L�[�}�b�v�ɏ]���̂��؂��B
 *	�L�[��D�����ǂ����́A
 *		1. �t�H�[�J�X�� Top Buffer �ɑ��݂��邩�ۂ� 
 *			Yes -> 2. �̃`�F�b�N��
 *			No  -> �L�[��D��
 *		2. �����v���t�B�N�X�����邩
 *			Yes -> �L�[��D�� (���̌�A�L�[��Ԃ���������Ȃ���)
 *			No  -> 3. �̃`�F�b�N��
 *		3. �L�[�}�b�v������ (SKK/����/�J�i�̃��[�h�Ɉˑ����邪)
 *			�L�[�̓J�[�\���̈ړ��Ɋւ�����̂ł����āA�ҏW���̃e�L�X�g�𑀍삷��
 *			���̂ł͂Ȃ����H
 *			Yes -> �L�[���v���Z�X���Ȃ��B
 *			No  -> �L�[��D���B
 */
int
CSkkImeMgr::QueryProcessKey (
	WPARAM			wParam,		/* [in] */
	LPARAM			lParam)		/* [in] */
{
	BOOL	fEaten = FALSE, fToggleIME = FALSE ;

	/*	Control �̂݁AShift �݂̂͒D��Ȃ��B*/
	if (wParam == VK_CONTROL || wParam == VK_SHIFT || wParam == VK_MENU)
		return	SKKIME_NOT_PROCESS_KEY ;

	if (m_pDoc->QueryToggleIMEKeyEvent (wParam, lParam, &fToggleIME) && fToggleIME) 
		return	SKKIME_PROCESS_KEY_TOGGLEIME ;

	/*	���̑���ɂ��Ă͔Y�ݒ��B���̑���͎󂯎��ׂ����H
	 *
	 *	 if (m_pTSF->_IsComposing () || _IsDuringConversion ()) 
	 *	return	TRUE ;
	 */
	if (m_pTSF->_IsComposing ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::QueryProcessKey: Composing -> PROCESS_KEY\n"))) ;
		return	SKKIME_PROCESS_KEY ;
	}

	if (! m_pDoc->QueryFilterKeyEvent (wParam, lParam, &fEaten))
		return	SKKIME_NOT_PROCESS_KEY ;
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::QueryProcessKey: Composing -> QueryFilter (%d)\n"), fEaten)) ;
	return	fEaten? SKKIME_PROCESS_KEY : SKKIME_NOT_PROCESS_KEY ;
}

/*	DoEditSession �̒�����Ăяo�����B
 */
HRESULT
CSkkImeMgr::OnEditSession (
	ITfContext*	pContext,	/* [in] edit context */
	TfEditCookie	ec,			/* [in] edit cookie */
	WPARAM			wParam,		/* [in] virtual keycode */
	LPARAM			lParam,		/* [in] */
	BOOL*			pfEaten)	/* [out] Is this key event eaten? */
{
	int		nCMode ;
	BOOL	fToggleIME	= FALSE ;
	HRESULT	hr			= S_OK ;

	if (! m_pDoc->QueryToggleIMEKeyEvent (wParam, lParam, &fToggleIME))
		fToggleIME	= FALSE ;
	if (fToggleIME) {
		BOOL	fOpen	= m_pTSF->_IsKeyboardOpen () ;

		m_pTSF->_SetKeyboardOpen (fOpen? FALSE : TRUE) ;
		if (fOpen) {
			BOOL	fComposing ;
			ITfComposition*	pComposition ;

			fComposing	= m_pTSF->_IsComposing (&pComposition) ;
			if (fComposing) {
				m_pTSF->_TerminateCompositionInContext (pContext) ;
			}
			if (m_pDoc != NULL)
				m_pDoc->Clear () ;
		}
		*pfEaten	= TRUE ;
		return	S_OK ;
	}

	/*	filter �����O�̕ϊ����[�h���L�����Ă����B
	 */
	nCMode	= m_pDoc->GetConversionMode () ;
	if (! m_pDoc->FilterKeyEvent (wParam, lParam, pfEaten))
		return	S_FALSE ;

#if defined (DEBUG)
	if (pfEaten != NULL)
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::OnEditSession (Eaten:%d)\n"), (int)*pfEaten)) ;
#endif
	if (! _UpdateCompose (pContext, ec)) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose failed.\n"))) ;
		hr	= E_FAIL ;
	}
	if (! _UpdateDisplayAttribute (pContext, ec)) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateDisplayAttribute failed.\n"))) ;
		hr	= E_FAIL ;
	}

	/*	�ϊ����[�h���X�V����Ă���΁ALangBar �ɔ��f������B
	 *	�܂��ACompartment �ɔ��f������B
	 */
	if (nCMode != m_pDoc->GetConversionMode ()) {
#if defined (TF_CONVERSIONMODE_NATIVE)
		unsigned int	uTFCMode	= (unsigned int)-1 ;

		switch (m_pDoc->GetConversionMode ()) {
		case	IMECMODE_ASCII:
			uTFCMode	= TF_CONVERSIONMODE_ALPHANUMERIC ;
			break ;
		case	IMECMODE_ZENKAKU:
			uTFCMode	= TF_CONVERSIONMODE_ALPHANUMERIC | TF_CONVERSIONMODE_FULLSHAPE ;
			break ;
		case	IMECMODE_HANKANA:
			uTFCMode	= TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_KATAKANA ;
			break ;
		case	IMECMODE_KATAKANA:
			uTFCMode	= TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_KATAKANA | TF_CONVERSIONMODE_FULLSHAPE ;
			break ;
		case	IMECMODE_HIRAGANA:
			uTFCMode	= TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_FULLSHAPE ;
			break ;
		default:
			/* error */
			break ;
		}
		if (uTFCMode != (unsigned int)-1) 
			(void) m_pTSF->_SetKeyboardInputModeConversion (uTFCMode) ;
#endif
		m_pTSF->_UpdateLangBarItem (c_guidConversionModeItemButton) ;
	}
	/*	SentenseMode �͏�� TF_SENTENCEMODE_NONE */

	/*	ToolTipUI, CandidateListUI �̍X�V�B*/
	if (FAILED (_UpdateUIElements (pContext, ec))) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateStatusWindow failed.\n"))) ;
		hr	= E_FAIL ;
	}
	return	hr ;
}

BOOL
CSkkImeMgr::OnClearSession (
	TfEditCookie		ec,
	ITfComposition*	pComposition)
{
	BOOL	fRetval ;
	ITfRange*		pRange ;
	
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnClearSession ()\n"))) ;

	if (pComposition != NULL &&
		pComposition->GetRange (&pRange) == S_OK) {
		fRetval	= pRange->SetText (ec, 0, L"", 0) == S_OK ;
		pRange->Release () ;
		pRange	= NULL ;
	}
	if (m_pDoc != NULL) {
		/*	���̏��������ł� oh �̓�����Ԃ�ێ��ł��Ȃ��̂ŌӖ������ɂ���
		 *	�Ȃ�Ȃ��B�����A"IME ON","COMPOSITION TEXT���Ȃ�" ��Ԃŕs�ӂ�
		 *	OnClearSession ���Ăяo����āA���̓��[�h���ω����Ă��܂��悤��
		 *	��Ԃ�����邱�Ƃ͂ł���B
		 */
		int	nMode	= m_pDoc->GetConversionMode () ;
		m_pDoc->Clear () ;
		m_pDoc->SetConversionMode (nMode) ;
	}
	_CloseUIElements () ;
	return	TRUE ;
}

HRESULT
CSkkImeMgr::OnToggleImeSession (
	ITfContext*		pContext,	/* [in] edit context */
	TfEditCookie	ec)			/* [in] edit cookie */
{
	int		nCMode ;
	BOOL	fToggleIME	= FALSE ;
	HRESULT	hr			= S_OK ;

	BOOL	fOpen	= m_pTSF->_IsKeyboardOpen () ;

	m_pTSF->_SetKeyboardOpen (fOpen? FALSE : TRUE) ;
	if (fOpen) {
		BOOL	fComposing ;
		ITfComposition*	pComposition ;

		fComposing	= m_pTSF->_IsComposing (&pComposition) ;
		if (fComposing) {
			m_pTSF->_TerminateCompositionInContext (pContext) ;
		}
		if (m_pDoc != NULL)
			m_pDoc->Clear () ;
	}
	return	S_OK ;
}

BOOL
CSkkImeMgr::OnReconvertSession (
	ITfContext*	pContext,	/* [in] edit context */
	TfEditCookie	ec,			/* [in] edit cookie */
	LPCWSTR		wstrText)
{
	int		nCMode ;

	if (m_pDoc == NULL || m_pTSF->_IsKeyboardDisabled ())
		return	FALSE ;

	nCMode	= m_pDoc->GetConversionMode () ;
	m_pDoc->SetReconvertText (wstrText, lstrlenW (wstrText)) ;
	_UpdateCompose (pContext, ec) ;
	_UpdateDisplayAttribute (pContext, ec) ;
	if (nCMode != m_pDoc->GetConversionMode ()) 
		m_pTSF->_UpdateLangBarItem (c_guidConversionModeItemButton) ;

	if (! m_pTSF->_IsKeyboardOpen ()) {
		m_pTSF->_SetKeyboardOpen (TRUE) ;
	}
	_UpdateUIElements (pContext, ec) ;
	return	TRUE ;
}

HRESULT
CSkkImeMgr::OnChangeInputModeSession (
	ITfContext*		pContext,		/* [in] edit context */
	TfEditCookie	ec,				/* [in] edit cookie */
	UINT			uConversionMode,
	UINT			uSentenceMode,
	BOOL			bUpdateCompartment)
{
	int		nCMode ;
	HRESULT	hr			= S_OK ;

#if defined (TF_CONVERSIONMODE_NATIVE)
	switch (uConversionMode) {
	case	TF_CONVERSIONMODE_ALPHANUMERIC:
		nCMode	= IMECMODE_ASCII ;
		break ;
	case	TF_CONVERSIONMODE_ALPHANUMERIC | TF_CONVERSIONMODE_FULLSHAPE:
		nCMode	= IMECMODE_ZENKAKU ;
		break ;
	case	TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_KATAKANA:
		nCMode	= IMECMODE_HANKANA ;
		break ;
	case	TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_KATAKANA | TF_CONVERSIONMODE_FULLSHAPE:
		nCMode	= IMECMODE_KATAKANA ;
			break ;
	case	TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_FULLSHAPE:
		nCMode	= IMECMODE_HIRAGANA ;
		break ;
	default:
		/*	���̏ꍇ�� Compartment ��F�߂��Ȃ��̂ŁA��������B
		 *	�������� SetValue ����ƕK�� E_UNEXPECTED �̃G���[���߂�̂� Compartment ��
		 *	�����������Ƃ͂ł��Ȃ��B
		 */
		if (! bUpdateCompartment)
			return	S_OK ;
		nCMode	= -1 ;
	}
	/*	filter �����O�̕ϊ����[�h���L�����Ă����B
	 */
	if (m_pDoc->GetConversionMode () == nCMode)
		return	S_FALSE ;
	if (m_pDoc->IsStatusActivep ())
		return	S_FALSE ;
	if (! m_pDoc->SetConversionMode (nCMode))
		return	S_FALSE ;

	if (! _UpdateCompose (pContext, ec)) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose failed.\n"))) ;
		hr	= E_FAIL ;
	}
	if (! _UpdateDisplayAttribute (pContext, ec)) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateDisplayAttribute failed.\n"))) ;
		hr	= E_FAIL ;
	}

	/*	�ϊ����[�h���X�V����Ă���΁ALangBar �ɔ��f������B
	 *	�܂��ACompartment �ɔ��f������B
	 */
	if (bUpdateCompartment) {
		unsigned int	uTFCMode	= (unsigned int)-1 ;

		switch (m_pDoc->GetConversionMode ()) {
		case	IMECMODE_ASCII:
			uTFCMode	= TF_CONVERSIONMODE_ALPHANUMERIC ;
			break ;
		case	IMECMODE_ZENKAKU:
			uTFCMode	= TF_CONVERSIONMODE_ALPHANUMERIC | TF_CONVERSIONMODE_FULLSHAPE ;
			break ;
		case	IMECMODE_HANKANA:
			uTFCMode	= TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_KATAKANA ;
			break ;
		case	IMECMODE_KATAKANA:
			uTFCMode	= TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_KATAKANA | TF_CONVERSIONMODE_FULLSHAPE ;
			break ;
		case	IMECMODE_HIRAGANA:
			uTFCMode	= TF_CONVERSIONMODE_NATIVE | TF_CONVERSIONMODE_FULLSHAPE ;
			break ;
		default:
			/* error */
			break ;
		}
		if (uTFCMode != (unsigned int)-1) 
			(void) m_pTSF->_SetKeyboardInputModeConversion (uTFCMode) ;
	}
	m_pTSF->_UpdateLangBarItem (c_guidConversionModeItemButton) ;

	/*	SentenseMode �͏�� TF_SENTENCEMODE_NONE */
	if (bUpdateCompartment) {
		(void) m_pTSF->_SetKeyboardInputModeSentence (TF_SENTENCEMODE_NONE) ;
	}

	/*	ToolTipUI, CandidateListUI �̍X�V�B
	 */
	if (FAILED (_UpdateUIElements (pContext, ec))) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateStatusWindow failed.\n"))) ;
		hr	= E_FAIL ;
	}
#else
	m_pTSF->_UpdateLangBarItem (c_guidConversionModeItemButton) ;
	if (FAILED (_UpdateUIElements (pContext, ec))) {
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateStatusWindow failed.\n"))) ;
		hr	= E_FAIL ;
	}
#endif
	return	hr ;
}

CImeDoc*
CSkkImeMgr::GetDocument ()
{
	return		m_pDoc ;
}

/*	�ݒ�t�@�C����ǂݒ�������B*/
BOOL
CSkkImeMgr::UpdateConfig ()
{
	if (m_pDoc == NULL)
		return	FALSE ;
	m_pDoc->UpdateConfig () ;
	return	TRUE ;
}

void
CSkkImeMgr::OnSetFocus (
	BOOL			fFocus)
{
	if (fFocus) {
		if (m_pDoc != NULL)
			m_pDoc->UpdateConfig () ;
	}
	_PopupUIElements (fFocus) ;
	return ;
}

BOOL
CSkkImeMgr::OnKeyboardOpen (
	BOOL			fOpen)
{
	HKEY			hSubKey ;
	LONG	lResult ;
	DWORD	dwType, dwValue, cbData ;

	if (fOpen) {
		/*	Keyboard �� open �ɂȂ������Ɂu���ȁv���[�h�ɖ߂��ݒ肪�L�����ǂ���
		 *	������B
		 */
		if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
			return	FALSE ;
		
		cbData	= sizeof (dwValue) ;
		lResult	= RegQueryValueEx (hSubKey, REGPATH_ALWAYS_OPEN_KANAMODE, NULL, &dwType, (LPBYTE)&dwValue, &cbData) ;
		RegCloseKey (hSubKey) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			return	FALSE ;
		if (dwValue) {
			if (m_pDoc == NULL)
				return	FALSE ;
			if (m_pDoc->GetConversionMode () != IMECMODE_HIRAGANA)
				m_pDoc->SetConversionMode (IMECMODE_HIRAGANA) ;
		}
	} else {
		_CloseUIElements () ;
		if (m_pDoc != NULL) {
			int	nMode	= m_pDoc->GetConversionMode () ;
			m_pDoc->Clear () ;
			m_pDoc->SetConversionMode (nMode) ;
		}
	}
	return	TRUE ;
}

/*========================================================================*
 */
BOOL
CSkkImeMgr::_UpdateCompose (
	ITfContext*	pContext,
	TfEditCookie	ec)
{
    TF_SELECTION		tfSelection ;
	ULONG				cFetched ;
	ITfComposition*		pComposition ;
	WCHAR				wszPText [512] ;	/* ���[��Amagic number ��... */
	WCHAR				wszReadingText [512] ;
	LPCWSTR	wstrPText ;
	LPWSTR		wpDest ;
	int					nPText, nRawShift, nRawCursor ;
	int					nReadingShift, nReadingText ;
	int		n, nShift, nCursor, nDest ;
	LONG				cch ;
	ITfRange*			pRange		= NULL ;
	ITfProperty*		pProp 		= NULL ;
	ITfProperty*		pPropAttr	= NULL ;
	BOOL				fComposing ;
	BOOL				fRetval		= FALSE ;
	BOOL				fContinue ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose ()\n"))) ;

    if (pContext->GetSelection (ec, TF_DEFAULT_SELECTION, 1, &tfSelection, &cFetched) != S_OK ||
		cFetched != 1)
        return	FALSE ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 1\n"))) ;

	fComposing	= m_pTSF->_IsComposing (&pComposition) ;
	wstrPText	= m_pDoc->GetPreeditText (&nPText) ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 2\n"))) ;

	/*	Composition String ����ŁAMinibuffer ���L���łȂ��ꍇ�ɂ�
	 *	Composition ���I�����Ĕ�����B
	 *
	 *	if (nPText <= 0 __&& ! m_pDoc->IsStatusActivep ()__) {
	 *	����A�Ȃ�� status activep �� comment out�H Wed Oct 29 23:26:43 2003
	 */
	if (nPText <= 0 && ! m_pDoc->IsStatusActivep ()) {
		if (fComposing) 
			m_pTSF->_TerminateCompositionInContext (pContext) ;
		fRetval	= TRUE ;
		goto	Exit ;
	}
	if (! fComposing) {
		if (! m_pTSF->_StartComposition (pContext))
			goto	Exit ;
		(void) m_pTSF->_IsComposing (&pComposition) ;
	}

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 3\n"))) ;

	/*	Composition �̃e�L�X�g�̑���B
	 */
	if (pComposition == NULL || pComposition->GetRange (&pRange) != S_OK || pRange == NULL) 
		goto	Exit ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 4\n"))) ;

	/*	attribute ���� clear ���Ă����B*/
    if (SUCCEEDED (pContext->GetProperty (GUID_PROP_ATTRIBUTE, &pPropAttr) && pPropAttr != NULL)) {
		pPropAttr->Clear (ec, pRange) ;
		pPropAttr->Release () ;
	}

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 5\n"))) ;
#if defined (buggy_code_using_prop_reading) || 1
	if (SUCCEEDED (pContext->GetProperty (GUID_PROP_READING, &pProp) && pProp != NULL)) {
		pProp->Clear (ec, pRange) ;
	} else {
		pProp	= NULL ;
	}
#endif

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 6\n"))) ;

	/*	Composition �̃e�L�X�g�̓��A�m�肳�����̂̑���B
	 *	StartRange ���ړ����āA�ړ��ŊO�ꂽ�͈͂ɂ�����̂��m��
	 *	�����Ǝv���B
	 */
	if (! m_pDoc->QueryUpdateContext (&nRawShift, &nRawCursor, &fContinue)) 
		goto	Exit ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 7\n"))) ;

	nReadingShift	= nRawShift ;
	nReadingText	= m_pDoc->GetReadingText (wszReadingText, NELEMENTS (wszReadingText) - 1, &nReadingShift) ;
	wszReadingText [nReadingText]	= L'\0' ;
#if defined (DEBUG) || defined (DBG)
	OutputDebugStringW (wszReadingText) ;
#endif

	if (nPText <= 0 && m_pDoc->IsStatusActivep ()) {
		/*	Fri Oct 31 23:26:15 2003
		 *		���Ȃ茵�������������A�����ǉ�����B���̐S�́A
		 *		j-input-by-code-or-menu �������s������Ԃł́A
		 *		composition �����݂��Ȃ��Ǝv���āAterminate composition
		 *		���Ă΂�Ă��Ȃ����߁B
		 */
		/*	Wed Aug 31 09:45:03 2005
		 *		�c��芸�����ēx�폜�B���̎��̈Ӑ}�͖Y��Ă��܂��Ă���c
		if (pRange->SetText (ec, 0, L" ", 1) != S_OK) 
			goto	Exit ;
		 *	�폜�������R�� OfficeXP �̍s���ŃX�y�[�X��}������ƁASetText (L" ")
		 *	�� E_FAIL ���ĕςɂȂ邽�߁B
		 */
		nShift		= 0 ;
		nCursor		= 0 ;

		/*	wordpad �͓������E�E�E�H�Ƃ������AWordPad �ȊO�͉��̃R�[�h���Ȃ���
		 *	TextLayout �̏���������ƕԂ��Ă���Ȃ��B
		 *	�_�~�[�ł� Text ��ݒ肷��K�v������B(Sat Mar 31 13:02:34 2007)
		 */
		if (pRange->SetText (ec, 0, L" ", 1) != S_OK) {
			(void) m_pDoc->UpdateContext () ;
			goto	Exit ;
		}
	} else {
		/*	�n���ꂽ�e�L�X�g�̒��Ɋ܂܂����s�R�[�h�̖�����������
		 *	����΂Ȃ�Ȃ��BL'\n' �� 0x0D, 0x0A �ւƓW�J����Ɠ�����
		 *	�J�[�\���ʒu���C������K�v������B
		 */
		wpDest		= wszPText ;
		nDest		= NELEMENTS (wszPText) ;
		nShift		= nRawShift ;
		nCursor		= nRawCursor ;
		for (n = 0 ; n < nPText ; n ++) {
			if (n == nRawShift) 
				nShift	= wpDest - wszPText ;
			if (n == nRawCursor) 
				nCursor	= wpDest - wszPText ;
			if (*wstrPText == L'\n') {
				*wpDest ++	= 0x0D ;
				nDest -- ;
#if 0
				/*	0x0D, 0x0A �ɒ����̂͗ǂ��Ȃ��炵���B
				 *	Outlook2000 �͖��Ȃ����AInternet Explorer6
				 *	�Ŗ�肪�����B
				 */
				if (nDest > 1) {
					*wpDest ++	= 0x0D ;
					*wpDest ++	= 0x0A ;
					nDest -= 2 ;
				}
#endif
			} else {
				*wpDest ++	= *wstrPText ;
				nDest -- ;
			}
			wstrPText	++ ;
		}
		if (pRange->SetText (ec, 0, wszPText, wpDest - wszPText) != S_OK) {
			/*	�����ŃG���[���������Ă��AUpdateContext �͌Ăяo���Ȃ���΂Ȃ�Ȃ��B
			 *	�łȂ���΁A���� Update ��������Ƃ������[�v���������āA���̌��
			 *	�X�e�[�g�����Ɏ��s��������B(Fri Dec 09 11:36:30 2005)
			 */
			(void) m_pDoc->UpdateContext () ;
			goto	Exit ;
		}
	}

	if (! m_pDoc->UpdateContext ())
		goto	Exit ;

	DEBUGPRINTF ((TEXT ("nShift = %d/%d, nCursor = %d/%d, fContinute = %d\n"),
				  nShift, nRawShift, nCursor, nRawCursor, fContinue)) ;

	if (pRange->ShiftStart (ec, nShift, &cch, NULL) != S_OK)
		goto	Exit ;
	if (pComposition->ShiftStart (ec, pRange) != S_OK ||
		pComposition->ShiftEnd   (ec, pRange) != S_OK)
		goto	Exit ;

#if ! defined (no_prop_langid)
	{
		ITfProperty*	pPropLang	= NULL ;

		if (SUCCEEDED (pContext->GetProperty (GUID_PROP_LANGID, &pPropLang) && pPropLang != NULL)) {
			VARIANT		var ;
			HRESULT		hr ;

			VariantInit (&var) ;
			var.vt		= VT_UINT ;
			var.uintVal	= SKKIME_LANGID ;
			hr			= pPropLang->SetValue (ec, pRange, &var) ;
			pPropLang->Release () ;
		}
	}
#endif
	tfSelection.range->ShiftStartToRange (ec, pRange, TF_ANCHOR_START) ;
	tfSelection.range->Collapse (ec, TF_ANCHOR_START) ;
	tfSelection.range->ShiftStart (ec, nCursor, &cch, NULL) ;
	pContext->SetSelection (ec, 1, &tfSelection) ;

#if defined (buggy_code_using_prop_reading) || 1
	if (pProp != NULL && nReadingText > nReadingShift) {
		VARIANT		var ;
		HRESULT		hr ;

		VariantInit (&var) ;
		var.vt		= VT_BSTR ;
		var.bstrVal	= SysAllocString (wszReadingText + nReadingShift) ;
		hr	= pProp->SetValue (ec, pRange, &var) ;
		if (FAILED (hr)) {
#if defined (DEBUG) || defined (DBG)
			LPVOID lpMsgBuf	= NULL ;
			FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER |
				FORMAT_MESSAGE_FROM_SYSTEM |
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				hr,
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // ����̌���
				(LPTSTR) &lpMsgBuf,
				0,
				NULL) ;
			if (lpMsgBuf != NULL)
				OutputDebugString ((LPCTSTR)lpMsgBuf) ;
			LocalFree (lpMsgBuf) ;
			DEBUGPRINTF ((TEXT ("pProp->SetValue() failed (0x%lx)\n"), (DWORD)hr)) ;
			if (hr == E_INVALIDARG) {
				DEBUGPRINTF ((TEXT ("E_INVALIDARG\n"))) ;
			}
#endif
		}
		VariantClear (&var) ;
	}
#endif

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - 8\n"))) ;
	if (! fContinue)
		m_pTSF->_TerminateComposition (ec) ;
	fRetval	= TRUE ;

  Exit:
	if (pProp != NULL)
		pProp->Release () ;
	if (pRange != NULL)
		pRange->Release () ;
	tfSelection.range->Release () ;
	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateCompose () - leave(%d)\n"), fRetval)) ;
	return	fRetval ;
}

HRESULT
CSkkImeMgr::_UpdateDisplayAttribute (
	ITfContext*		pContext,
	TfEditCookie	ec)
{
	ITfComposition*			pComposition ;
	ITfRange*				pRange			= NULL ;
	ITfRange*				pRangeC			= NULL ;
	BOOL					fComposing, fConverted ;
	int						nBegin, nEnd ;
	HRESULT					hr	= E_FAIL ;

	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_UpdateDisplayAttribute ()\n"))) ;


	fComposing	= m_pTSF->_IsComposing (&pComposition) ;
	if (! fComposing)
		goto	Exit ;
	if ((hr = pComposition->GetRange (&pRange)) != S_OK) 
		goto	Exit ;

	fConverted	= m_pDoc->GetConvertedRegion (&nBegin, &nEnd) ;
	pRangeC		= NULL ;
	if (fConverted && nBegin < nEnd && nEnd > 0) {
		LONG	cch ;
		if (FAILED (pRange->Clone (&pRangeC)))
			goto	Exit ;
		if (FAILED (pRangeC->ShiftStart (ec, nBegin, &cch, NULL)) ||
			FAILED (pRangeC->Collapse (ec, TF_ANCHOR_START)) ||
			FAILED (pRangeC->ShiftEnd (ec, nEnd - nBegin, &cch, NULL)))
			goto	Exit ;
	}
	if (pRangeC != NULL) {
		hr	= m_pTSF->_SetCompositionDisplayAttributes (ec, pRange, pRangeC) ;
	} else {
		hr	= S_FALSE ;
	}
  Exit:
	if (pRange != NULL)
		pRange->Release () ;
	if (pRangeC != NULL)
		pRangeC->Release () ;
    return	hr ;
	UNREFERENCED_PARAMETER (pContext) ;
}

HRESULT
CSkkImeMgr::_QueryFocus (
	ITfContext*	pContext,
	TfEditCookie	ec)
{
    ITfRange*		pRangeComposition ;
    TF_SELECTION	tfSelection ;
	HRESULT			hr	= S_OK ;
	ULONG			cFetched ;
	BOOL			fCovered ;
	ITfComposition*	pComposition ;

//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (1) \n"))) ;

	if (! m_pTSF->_IsComposing (&pComposition))
		return	S_OK ;

//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (2) \n"))) ;

    if (pContext->GetSelection (ec, TF_DEFAULT_SELECTION, 1, &tfSelection, &cFetched) != S_OK ||
		cFetched != 1)
        return	S_FALSE ;
	
//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus(%p) -- (3) \n"), pComposition)) ;

    if (pComposition->GetRange (&pRangeComposition) == S_OK) {
        fCovered	= IsRangeCovered (ec, tfSelection.range, pRangeComposition) ;
        pRangeComposition->Release () ;
		
		DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (4) \n"))) ;
        if (!fCovered) {
            hr	= S_FALSE; // don't eat the key, it's outside our composition
            goto	Exit ;
        }
    }
//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (5) \n"))) ;
 Exit:
//	DEBUGPRINTF ((TEXT ("CSkkImeMgr::_QueryFocus() -- (6) \n"))) ;
    tfSelection.range->Release () ;
	return	hr ;
}

/*========================================================================
 *	UIElement �̑���Ɋւ��� method
 */
HRESULT
CSkkImeMgr::_UpdateUIElements (
	ITfContext*		pContext,
	TfEditCookie	ec)
{
	if (m_pTSF == NULL || m_pDoc == NULL)
		return	E_FAIL ;

	/*	SetText �� Range �Ƀe�L�X�g��ݒ肵�āAApplication �ɐ����߂��Ă��΂炭���Ȃ���
	 *	Range �̈ʒu�͓����Ȃ��B������A�����Ȃ� Minibuffer Window ��\������悤�ȑ���
	 *	(j-input-�Ƃ�) �����s�����ƁA�\���ʒu�������Ă��܂��B
	 *	����ɂ� AdviseTextLayoutSink �𗘗p���āAApplication �̌v�Z���I����Ă���ʒu���
	 *	�𓾂邵���Ȃ��B�������A������e�L�X�g���ݒ肳��Ă��Ȃ���΍s���Ȃ��̂�
	 *	Minibuffer Window ��\�����鎞�ɂ͉R�ł��e�L�X�g������K�v������c(�悤��)
	 *	UpdateCompose �� dummy �� SetText (L" ", 1) �͂���ł���B(����͂��Ȃ�s���Ȃ̂���
	 *	Application ���� Text ���Ȃ��̂� Range �̈ʒu�v�Z�Ȃ񂩂���`���͂Ȃ��ƍl����̂���
	 *	����Ȃ��͂Ȃ��c�B)
	 *	�ܘ_�AWordPad �̂悤�Ƀe�L�X�g�������Ă��Ȃ��Ă����������ȏꏊ��Ԃ��Ă������̂�
	 *	����̂����c��ʓI�ł͂Ȃ��悤���B
	 *	(*) Context �������j������̂��Ƃ����������^��͎c���Ă���B���̎����ŗǂ��̂���
	 *	�s���B
	 */
	AdviseTextLayoutSink (pContext) ;

	/* �\���ʒu�̍X�V�͂���(�\��/��\���Ɋւ�炸) */
	_LayoutUIElements (pContext, ec) ;

	/*	�X�V���ꂽ���g���ǂ��Ƃ��́AUIElements �̒��g�ɔC����B(Page, Count
	 *	���ύX���ꂽ�Ƃ��ǂ��Ƃ��B
	 */	
	_UpdateCandidateListUI () ;
	_UpdateToolTipUI () ;
	return	S_OK ;
}

HRESULT
CSkkImeMgr::_CloseUIElements ()
{
	CSkkImeCandidateListUIElement*	pCandListUI ;
	CSkkImeToolTipUIElement*		pToolTipUI ;
	BOOL	bShow ;

	if (m_pTSF == NULL || m_pDoc == NULL)
		return	E_FAIL ;

	pToolTipUI	= m_pTSF->_GetToolTipUI () ;
	if (pToolTipUI != NULL) {
		if (pToolTipUI->_IsActivep (&bShow)) {
			m_pTSF->_EndToolTipUI () ;
			pToolTipUI->_Close () ;
		}
	}
	pCandListUI	= m_pTSF->_GetCandidateListUI () ;
	if (pCandListUI != NULL) {
		if (pCandListUI->_IsActivep (&bShow)) {
			m_pTSF->_EndCandidateListUI () ;
			pCandListUI->_Close () ;
		}
	}
	UnadviseTextLayoutSink () ;
	return	S_OK ;
}

HRESULT
CSkkImeMgr::_PopupUIElements (
	BOOL		bFocus) 
{
	CSkkImeCandidateListUIElement*	pCandListUI ;
	CSkkImeToolTipUIElement*		pToolTipUI ;
	BOOL	bShow ;

	if (m_pTSF == NULL || m_pDoc == NULL)
		return	E_FAIL ;

	pToolTipUI	= m_pTSF->_GetToolTipUI () ;
	if (pToolTipUI != NULL) {
		if (pToolTipUI->_IsActivep (&bShow)) {
			if (bShow)
				pToolTipUI->_Popup (bFocus) ;
		}
	}
	pCandListUI	= m_pTSF->_GetCandidateListUI () ;
	if (pCandListUI != NULL) {
		if (pCandListUI->_IsActivep (&bShow)) {
			if (bShow)
				pCandListUI->_Popup (bFocus) ;
			m_pTSF->_EndCandidateListUI () ;
		}
	}
	return	S_OK ;
}

/*	�����ł́AUIElement �̕\���ʒu�Ƒ傫���𒲐����邾���ŁA�\��/��\���͕ύX���Ȃ��B
 *	Update �Ƃ��������Ȃ��B
 *	�܂��A������ UIElement �� UIElementId ���g���Ď擾���� UIElement ��ΏۂƂ��ĂȂ�
 *	�̂́A�\���ʒu�̒������K�v�Ȃ͎̂��O�� UIElement �̏ꍇ����������ł���B
 */
HRESULT
CSkkImeMgr::_UpdateToolTipUI ()
{
	CSkkImeToolTipUIElement*	pToolTipUI ;
	BOOL				bComposing ;
	ITfComposition*		pComposition	= NULL ;
	HRESULT	hr	= S_OK ;
	BOOL	bShow ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pToolTipUI	= m_pTSF->_GetToolTipUI () ;
	if (pToolTipUI == NULL)
		return	S_FALSE ;

	/*	Wed Aug 31 09:50:02 2005
	 *		Composing �łȂ���Ԃ� UIStatus �� Popup ����ƁA�e�L�X�g��ҏW���ĂȂ���Ԃ�
	 *		Popup ���c���Ă��܂��̂ł��܂�ǂ��Ȃ� (design �I�ɂ��AITfRange �̒l�I�ɂ�)�B
	 *---
	 *	Sat Mar 17 11:47:02 2007
	 *		ToolTip ���\������邩�ǂ����́AMessage �����邩�ǂ����ōs���B��⃊�X�g���\����
	 *		��Ă����ԂŁA���Ƀ}�E�X�J�[�\�������킹������ ToolTip ���\������邱�Ƃ�����
	 *		�悤�ɂ��Ă��邪�A������̃L�b�N�̔���́A�����ł͂ł��Ȃ��̂ŁB(Window Message
	 *		�����āA�}�E�X�J�[�\�������Ȃ��Ƃ����Ȃ�����c)
	 */
	bComposing	= m_pTSF->_IsComposing (&pComposition) ;
	if (bComposing && m_pDoc->HaveMessagep ()) {
		LPCWSTR	pwMessage ;
		int		iMessageLen ;
		DWORD	dwId ;

		pwMessage	= m_pDoc->GetMessage (&iMessageLen) ;
		pToolTipUI->_SetText (pwMessage, iMessageLen) ;

		/*	Active ���ǂ����̔��f�́AOpen ���ꂽ���ǂ�����1�_�̂݁B
		 *	���ꂪ�Ǝ�UI�Ȃ̂� Application ��UI�Ȃ̂��͕s��B
		 *
		 *	�����ɓ��ꂽ bShow �����̂ǂ��炩�������̂��������B
		 */
		if (! pToolTipUI->_IsActivep (&bShow)) {
			hr	= m_pTSF->_BeginToolTipUI (&dwId, &bShow) ;
			if (hr != E_NOINTERFACE && FAILED (hr))
				return	hr ;
			if (hr == E_NOINTERFACE) {
				dwId	= -1 ;
				bShow	= TRUE ;
			}
			hr	= pToolTipUI->_Open (dwId, bShow) ;
			if (FAILED (hr))
				return	hr ;
		} else {
			pToolTipUI->_Update () ;
		}
		m_pTSF->_UpdateToolTipUI () ;
	} else {
		if (pToolTipUI->_IsActivep (&bShow)) {
			m_pTSF->_EndToolTipUI () ;
			pToolTipUI->_Close () ;
		}
	}
	return	hr ;
}

HRESULT
CSkkImeMgr::_UpdateCandidateListUI ()
{
	CSkkImeCandidateListUIElement*	pCandListUI ;
	BOOL				bComposing ;
	ITfComposition*		pComposition	= NULL ;
	HRESULT	hr	= S_OK ;
	BOOL	bShow ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pCandListUI	= m_pTSF->_GetCandidateListUI () ;
	if (pCandListUI == NULL)
		return	S_FALSE ;

	/*	Wed Aug 31 09:50:02 2005
	 *		Composing �łȂ���Ԃ� UIStatus �� Popup ����ƁA�e�L�X�g��ҏW���ĂȂ���Ԃ�
	 *		Popup ���c���Ă��܂��̂ł��܂�ǂ��Ȃ� (design �I�ɂ��AITfRange �̒l�I�ɂ�)�B
	 *---
	 *	ToolTipUI �� CandidateListUI�A�ǂ���� Composing ������̂Ȃ�A�����œn���̂�����
	 *	�Ȃ񂶂�Ȃ����H
	 */
	bComposing	= m_pTSF->_IsComposing (&pComposition) ;
	if (bComposing && m_pDoc->IsStatusActivep ()) {

		if (! pCandListUI->_IsActivep (&bShow)) {
			DWORD	dwId ;

			hr	= m_pTSF->_BeginCandidateListUI (&dwId, &bShow) ;
			if (hr == E_NOINTERFACE) {
				dwId	= (DWORD)-1 ;
				bShow	= TRUE ;
			} else {
				if (FAILED (hr))
					return	hr ;
			}
			hr	= pCandListUI->_Open (dwId, bShow) ;
			if (FAILED (hr))
				return	hr ;
		} else {
			pCandListUI->_Update () ;
		}
		m_pTSF->_UpdateCandidateListUI () ;
	} else {
		if (pCandListUI->_IsActivep (&bShow)) {
			m_pTSF->_EndCandidateListUI () ;
			pCandListUI->_Close () ;
		}
	}
	return	hr ;
}

HRESULT
CSkkImeMgr::_LayoutUIElements (
	ITfContext*				pContext,
	TfEditCookie			ec)
{
	ITfComposition*			pComposition	= NULL ;
	const IMECANDIDATES*	pMyCand			= NULL ;
	RECT					rcUI, rcTarget ;
	HRESULT					hr				= E_FAIL ;
	BOOL					bTargetRect		= FALSE ;
	int						nPText			= 0 ;
	CSkkImeCandidateListUIElement*	pCandListUI ;
	CSkkImeToolTipUIElement*		pToolTipUI ;

	if (pContext == NULL)
		return	E_FAIL ;

	if (! m_pTSF->_IsComposing (&pComposition) || pComposition == NULL) 
		return	E_FAIL ;
	{
		ITfRange*			pRange	= NULL ;

		if (SUCCEEDED (pComposition->GetRange (&pRange)) && pRange != NULL) {
			hr	= _GetRangeRect (pContext, ec, pRange, &rcTarget) ;
			if (hr == S_OK && rcTarget.top < rcTarget.bottom)
				bTargetRect	= TRUE ;
			pRange->Release () ;
		}
	}
	if (! bTargetRect) {
		DEBUGPRINTF ((TEXT ("_GetRangeRect all failed.\n"))) ;
		rcTarget.left	= 0 ;
		rcTarget.top	= 0 ;
		rcTarget.right	= 1 ;
		rcTarget.bottom	= 1 ;
	}

	_CalculateUIElementLayout (&rcUI, &rcTarget) ;

	pCandListUI	= m_pTSF->_GetCandidateListUI () ;
	if (pCandListUI != NULL)
		pCandListUI->_MoveWindow (rcUI.left, rcUI.top, rcUI.right, rcUI.bottom) ;

	/* ToolTipUI �̈ʒu�� CandListUI �̕\��/��\���ŕω�����B
	*/
	if (m_pDoc != NULL && m_pDoc->HaveMessagep ()) {
		pToolTipUI	= m_pTSF->_GetToolTipUI () ;
		if (pToolTipUI != NULL) {
			pMyCand	= m_pDoc->GetStatusText () ;
			if (pMyCand != NULL && pMyCand->_iStyle != IMECANDSTYLE_UNUSED) {
				DEBUGPRINTF ((TEXT ("LayoutUIElements -> ToolTipUI::MoveWindow (%d, %d, 0, 0);1\n"), rcUI.left, rcUI.top + rcUI.bottom)) ;
				pToolTipUI->_MoveWindow (rcUI.left, rcUI.top + rcUI.bottom, 0, 0) ;
			} else {
				DEBUGPRINTF ((TEXT ("LayoutUIElements -> ToolTipUI::MoveWindow (%d, %d, 0, 0);2\n"), rcUI.left, rcUI.top)) ;
				pToolTipUI->_MoveWindow (rcUI.left, rcUI.top, 0, 0) ;
			}
		}
	}
	return	hr ;
}

HRESULT
CSkkImeMgr::_GetRangeRect (
	ITfContext*				pContext,
	TfEditCookie			ec,
	ITfRange*				pRange,
	RECT*					pRect)
{
	CGetTextExtentEditSession*	pEditSession	= NULL ;
	ITfContextView*				pContextView	= NULL ;
	HRESULT			hr, hrTargetRect ;

	if (pContext == NULL || pRange == NULL || pRect == NULL)
		return	E_INVALIDARG ;

	hr	= pContext->GetActiveView (&pContextView) ;
	if (FAILED (hr))
		return	hr ;

	pEditSession	= new CGetTextExtentEditSession (m_pTSF, pContext, pContextView, pRange, pRect) ;
	if (pEditSession == NULL) {
		hr	= E_FAIL ;
		goto	out ;
	}
	hr	= pContext->RequestEditSession (ec, pEditSession, TF_ES_SYNC | TF_ES_READ, &hrTargetRect) ;
	pEditSession->Release () ;
	if (hr == S_OK) 
		hr	= hrTargetRect ;
out:
	pContextView->Release () ;
	return	hr ;
}

HRESULT
CSkkImeMgr::_CalculateUIElementLayout (
	RECT*				prcDest,
	const RECT*			prcSrc)
{
	const IMECANDIDATES*	pMyCand ;
	HDC					hDC ;
	HFONT				hOldFont ;
	RECT				rcUI, rcWork ;
	int					nWidth, nHeight, nFontHeight, nFontWidth ;
	int					nFrameWidth, nFrameHeight, nDefaultWidth, nDefaultHeight ;
	int					iStyle ;
	TEXTMETRIC			tm ;
	SIZE				sz ;

	memset (&rcUI, 0, sizeof (rcUI)) ;

	/*	��ʑS�̂̃T�C�Y�𓾂�B*/
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, 0) ;

	hDC		= CreateDC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
	if (hDC == NULL) {
		if (prcDest != NULL) {
			prcDest->left	= 0 ;
			prcDest->top	= 0 ;
			prcDest->right	= rcWork.right ;
			prcDest->bottom	= 18 ;
		}
		return	E_FAIL ;	// ���̏ꍇ�͌v�Z�s�\�B
	}

	hOldFont	= (HFONT) _CheckNativeCharset (hDC) ;
	if (GetTextMetrics (hDC, &tm)) {
		nFontWidth	= tm.tmAveCharWidth ;
		nFontHeight	= tm.tmHeight ;
	} else {
		GetTextExtentPoint32W (hDC, L"��", 1, &sz) ;
		nFontWidth	= (sz.cx + 1) / 2 ;
		nFontHeight	= sz.cy ;
	}
	nFrameWidth		= GetSystemMetrics (SM_CXDLGFRAME) * 2 ;
	nFrameHeight	= GetSystemMetrics (SM_CYDLGFRAME) * 2 ;
	nDefaultWidth	= nFontWidth * DEFAULT_MINIBUF_CHARWIDTH + nFrameWidth ;
	nDefaultWidth	= (nDefaultWidth > rcWork.right)? rcWork.right : nDefaultWidth ;
	nDefaultHeight	= nFontHeight + nFrameHeight ;
	nDefaultHeight	= (nDefaultHeight > rcWork.bottom)? rcWork.bottom : nDefaultHeight ;

	nWidth	= (prcSrc != NULL && nDefaultWidth < (prcSrc->right - prcSrc->left))? (prcSrc->right - prcSrc->left) : nDefaultWidth ;
	nHeight	= 0 ;

	if ((nWidth + nFrameWidth) > (rcWork.right - rcWork.left)) 
		nWidth	= rcWork.right - rcWork.left - nFrameWidth ;
	if (nWidth <= 0) {
		nWidth		= prcSrc->right - prcSrc->left ;
		nHeight		= prcSrc->bottom - prcSrc->top ;
		goto	skip_calc ;
	}

	pMyCand	= m_pDoc->GetStatusText () ;
	iStyle	= (pMyCand != NULL)? pMyCand->_iStyle : IMECANDSTYLE_UNUSED ;
	switch (iStyle) {
	case	IMECANDSTYLE_READ:
		{
			WCHAR	bufText [1024] ;
			int		nText ;
			SIZE	sz ;

			nText	= m_pDoc->GetCandidateText (bufText, ARRAYSIZE (bufText), NULL, NULL, pMyCand) ;
			if (nText > 0) {
				GetTextExtentPoint32W (hDC, bufText, nText, &sz) ;
				if ((sz.cx + nFrameWidth) > nWidth) {
					int	n	= nWidth - nFrameWidth ;
					nHeight	= (sz.cx + n - 1) / n * sz.cy + nFrameHeight ;
				} else {
					nHeight	= sz.cy + nFrameHeight ;
				}
				nHeight	= (nHeight < nDefaultHeight)? nDefaultHeight : nHeight ;
			} else {
				nHeight	= nDefaultHeight ;
			}
		}
		break ;
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		nHeight	= nDefaultHeight ;
		break ;	

	case	IMECANDSTYLE_MINIBUFFERTEXT:
	default:
		{
			LPCWSTR		pwSText ;
			int			nSTextLen, iCursorPos ;
			SIZE		sz ;

			if (pMyCand != NULL && pMyCand->_iCount == 1 && iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
				if (! m_pDoc->GetStatusCursor (&iCursorPos))
					iCursorPos	= -1 ;
				pwSText		= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *(pMyCand->_vbufCandidateIndex.GetBuffer () + 0) ;
				nSTextLen	= lstrlenW (pwSText) ;
			} else {
				if (! m_pDoc->HaveMessagep ()) 
					break ;
				pwSText		= m_pDoc->GetMessage (&nSTextLen) ;
				iCursorPos	= -1 ;
			}
			/* Minibuffer Text �̏ꍇ�B*/
			if (_GetStatusTextSize (hDC, pwSText, nSTextLen, iCursorPos, nWidth - nFrameWidth, &sz)) {
				nWidth	= sz.cx + nFrameWidth ;
				nHeight	= sz.cy + nFrameHeight ;
			}
		}
		break ;
	}

	/*	�\���ʒu�̒����BMulti-Screen ���l�����āB
	 */
skip_calc:
	{
		POINT	pt, ptOffset, ptBase ;

		pt.x	= prcSrc->left ;
		pt.y	= prcSrc->bottom + 1 ;
		if (rcWork.right > 0) {
			ptOffset.x	= pt.x % rcWork.right ;
			if (ptOffset.x < 0)
				ptOffset.x	= rcWork.right + ptOffset.x ;
			ptBase.x	= pt.x - ptOffset.x ;
			if ((ptOffset.x + nWidth) > rcWork.right){
				ptOffset.x	= rcWork.right - nWidth ;
			if (ptOffset.x < 0)
				ptOffset.x	= 0 ;
			}
			pt.x		= ptBase.x + ptOffset.x ;
		}
		if (rcWork.bottom > 0) {
			ptOffset.y	= pt.y % rcWork.bottom ;
			if (ptOffset.y < 0)
				ptOffset.y	= rcWork.bottom + ptOffset.y ;
			ptBase.y	= pt.y - ptOffset.y ;
			if ((ptOffset.y + nHeight) > rcWork.bottom){
				ptOffset.y = rcWork.bottom - nHeight ;
			}
			if (ptOffset.y < 0)
				ptOffset.y	= 0 ;
			pt.y		= ptBase.y + ptOffset.y ;
		}
		rcUI.left	= pt.x ;
		rcUI.top	= pt.y ;
		rcUI.right	= nWidth ;
		rcUI.bottom	= nHeight ;
	}

	DEBUGPRINTF ((TEXT ("View(l:%d, t:%d, r:%d, b:%d), WorkArea(l:%d, t:%d, r:%d, b:%d), w:%d, h:%d\n"),
				  prcSrc->left, prcSrc->top, prcSrc->right, prcSrc->bottom,
				  rcWork.left, rcWork.top, rcWork.right, rcWork.bottom,
				  nFontWidth, nFontHeight)) ;
	DEBUGPRINTF ((TEXT ("_CalculateUIElementLayout -> Result(l:%d, t:%d, r:%d, b:%d)\n"), 
		rcUI.left, rcUI.top, rcUI.right, rcUI.bottom)) ;
	if (prcDest != NULL)
		*prcDest	= rcUI ;
	DeleteObject (SelectObject (hDC, hOldFont)) ;
	DeleteDC (hDC) ;
	return	S_OK ;
}

BOOL
CSkkImeMgr::_GetStatusTextSize (
	HDC						hDC,
	LPCWSTR					pwSText,
	int						nSTextLen,
	int						iCursorPos,
	int						nDefaultWidth,
	SIZE*					pSZ)
{
	/*	Key 1 �ɕt�� ``X:'' ��2�����ASeparator �̋󔒂� 1 �����A
	 *	���̕\���� 1 �` 2 �����A
	 *	����āANELEMENTS (pCandidateKey) * (2 + 1 + 1) �܂��� (2 + 1 + 2)
	 *	���������B
	 */
	RECT			rc ;
	int				x, y, nDY ;
	TEXTMETRIC		tm ;
	BOOL			bCalculate ;
	int				iCalculateCount ;

	rc.left			= 0 ;
	rc.top			= 0 ;
	rc.right		= nDefaultWidth ;
	iCalculateCount	= 3 ;

	/* Minibuffer Window �̑傫���𓾂�B*/
	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	do {
		LPCWSTR		pText ;
		int			nText, nTextPos ;
		BOOL		bCursorPos ;

		pText		= pwSText ;
		nText		= nSTextLen ;
		nTextPos	= 0 ;
		y			= rc.top ;
		x			= rc.left ;
		bCursorPos	= FALSE ;
		bCalculate	= FALSE ;
		while (0 < nText) {
			int		nChar, iSX ;
			BOOL	bCRLF ;
			SIZE	sz ;

			bCRLF	= FALSE ;
			iSX		= x ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				if ((nTextPos + nChar - 1) == iCursorPos && *(pText + nChar - 1) == L'|') {
					break ;	/* cursor */
				}
				GetTextExtentPointW (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) >= rc.right) {
					if (nChar == 1 && x == rc.left) {
						/*	width ��ύX���čŏ�����B
						 *	�������A�������[�v�ɓ���Ȃ��悤�ɍő�v�Z�񐔂�
						 *	�ݒ肵�Ă����B
						 */
						rc.right	= rc.left + sz.cx + 1 ;
						if (iCalculateCount <= 0)
							return	FALSE ;
						bCalculate	= TRUE ;
						iCalculateCount	-- ;
					}
					bCRLF	= TRUE ;
					break ;
				}
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;
			/* �e�L�X�g��\������B*/
			GetTextExtentPointW (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
			if (bCRLF) {
				/*	�܂�Ԃ��L����\������B*/
				GetTextExtentPointW (hDC, L"\\", 1, &sz) ;
				x	+= sz.cx ;
			}

			/* �K�v�Ȃ�J�[�\����\������B*/
			/*if (nTextPos <= iCursorPos && iCursorPos <= (nTextPos + nChar)){*/
			if ((nTextPos + nChar) == iCursorPos) {
				/* �J�[�\���̒��O�܂ŕ`�悳��Ă����ԁB*/
				if ((nChar + 1) >= nText) {
				} else {
					bCursorPos		= TRUE ;
				}
				nChar	++ ;	/* skip: �J�[�\���ʒu�ɑ}������Ă���``|'' */
			} else {
				if (bCursorPos) {
					bCursorPos	= FALSE ;
				}
			}
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			if (bCRLF) {
				y		+= nDY ;
				x		= rc.left ;
			}
		}
	}	while (bCalculate) ;

	if (pSZ != NULL) {
		pSZ->cx	= (y > rc.top || iCursorPos != -1)? rc.right : x ;
		pSZ->cy	= y + nDY ;
	}
	return	TRUE ;
}

/*========================================================================*
 */
BOOL
CSkkImeTextService::_InitSkkImeMgr ()
{
    BOOL		fThreadfocus ;
    ITfSource*	pSource	= NULL ;

	_pSkkIme	= new CSkkImeMgr (this) ;
	if (_pSkkIme == NULL)
		return	FALSE ;

	if (! _pSkkIme->_Init ())
		goto	ExitError ;

    // we also need a thread focus sink
	if (_pThreadMgr != NULL) {
		if (_pThreadMgr->QueryInterface(IID_ITfSource, (void **)&pSource) != S_OK) {
			pSource	= NULL ;
			goto	ExitError ;
		}

		if (pSource->AdviseSink(IID_ITfThreadFocusSink, (ITfThreadFocusSink *)this, &_dwThreadFocusSinkCookie) != S_OK) {
			// make sure we don't try to Unadvise _dwThreadFocusSinkCookie later
			_dwThreadFocusSinkCookie	= TF_INVALID_COOKIE ;
			goto	ExitError ;
		}
		pSource->Release () ;
		pSource	= NULL ;

		// we may need to display the snoop window right now
		// our thread focus sink won't be called until something changes,
		// so we need to check the current state.

		if (_pThreadMgr->IsThreadFocus(&fThreadfocus) == S_OK && fThreadfocus) {
			OnSetThreadFocus () ;
		}
	}
    return	TRUE ;

ExitError:
    SafeRelease(pSource);
    _UninitSkkImeMgr () ;
    return FALSE;
}

void
CSkkImeTextService::_UninitSkkImeMgr ()
{
    ITfSource*	pSource ;

    if (_pSkkIme != NULL) {
        _pSkkIme->_Uninit () ;
		_pSkkIme->Release () ;
		_pSkkIme	= NULL ;
    }
    if (_dwThreadFocusSinkCookie != TF_INVALID_COOKIE) {
		if (_pThreadMgr != NULL) {
			if (_pThreadMgr->QueryInterface(IID_ITfSource, (void **)&pSource) == S_OK) {
				pSource->UnadviseSink(_dwThreadFocusSinkCookie);
				pSource->Release();
			}
		}
        _dwThreadFocusSinkCookie = TF_INVALID_COOKIE;
    }
	return ;
}

/*========================================================================
 *	....
 */

HFONT
_CheckNativeCharset (
	HDC	hDC) 
{
	BOOL		bDiffCharSet	= FALSE ;
	HFONT		hOldFont ;
	LOGFONT	lfFont ;

	hOldFont	= (HFONT) GetCurrentObject (hDC, OBJ_FONT) ;
	GetObject (hOldFont, sizeof(LOGFONT), &lfFont) ;

	if (lfFont.lfCharSet != SHIFTJIS_CHARSET/*NATIVE_CHARSET*/) {
		bDiffCharSet			= TRUE ;
		lfFont.lfWeight			= FW_NORMAL ;
		lfFont.lfCharSet		= SHIFTJIS_CHARSET ; //NATIVE_CHARSET
		lfFont.lfFaceName[0]	= TEXT ('\0') ;
		SelectObject (hDC, CreateFontIndirect (&lfFont)) ;
	} else {
		hOldFont				= NULL ;
	}
	return	hOldFont ;
}

