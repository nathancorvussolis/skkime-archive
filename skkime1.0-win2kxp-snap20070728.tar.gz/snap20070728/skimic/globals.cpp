/*	globals.cpp
 *
 *	Global variables.
 */
#include "globals.h"
#include <tchar.h>
#include <stdarg.h>
#include <shlwapi.h>

HINSTANCE			g_hInst ;

LONG				g_cRefDll	= -1 ;	// -1 /w no refs, for win95 InterlockedIncrement/Decrement compat

CRITICAL_SECTION	g_cs ;

/*	������ GUID �̐����ɂ� GUIDGEN.EXE ���g���B������ GUID ��
 *	���p/�Q��?�̂�����ɂ��ẮA�܂��������B
 */
// {830DE831-E04D-40bb-8683-1E179A5F1A4F}
const CLSID	c_clsidSkkImeTextService	= {
	0x830de831, 0xe04d, 0x40bb, { 0x86, 0x83, 0x1e, 0x17, 0x9a, 0x5f, 0x1a, 0x4f }
} ;

// {930C0CDC-A91F-4d7c-B23A-67749D4EBFCD}
const GUID	c_guidSkkImeProfile = {
	0x930c0cdc, 0xa91f, 0x4d7c, { 0xb2, 0x3a, 0x67, 0x74, 0x9d, 0x4e, 0xbf, 0xcd }
} ;

// {82FD14C8-A99A-4882-A6E5-7493CA67866A}
const GUID	c_guidConversionModeItemButton = {
	0x82fd14c8, 0xa99a, 0x4882, { 0xa6, 0xe5, 0x74, 0x93, 0xca, 0x67, 0x86, 0x6a }
} ;

// {EDA78BBB-65F7-4a1b-9551-309D9FE6200C}
const GUID	c_guidToolItemButton	= {
	0xeda78bbb, 0x65f7, 0x4a1b, { 0x95, 0x51, 0x30, 0x9d, 0x9f, 0xe6, 0x20, 0xc }
} ;

// {E79044E1-9AC4-4735-A2D2-F4F02D1CCD49}
const GUID	c_guidSkkImeDisplayAttribute	= {
	0xe79044e1, 0x9ac4, 0x4735, { 0xa2, 0xd2, 0xf4, 0xf0, 0x2d, 0x1c, 0xcd, 0x49 }
} ;

// {8B4DFEB4-ECF8-4130-892E-CA96132BD16D}
const GUID	c_guidSkkImeDisplayAttributeInput	= {
	0x8b4dfeb4, 0xecf8, 0x4130, { 0x89, 0x2e, 0xca, 0x96, 0x13, 0x2b, 0xd1, 0x6d }
} ;

// {22CF531C-32F0-4121-80F5-78B3BA3002A5}
const GUID	c_guidSkkImeDisplayAttributeTargetConverted	= {
	0x22cf531c, 0x32f0, 0x4121, { 0x80, 0xf5, 0x78, 0xb3, 0xba, 0x30, 0x2, 0xa5 }
} ;

// {D8E44F2A-A92D-48f6-8D90-78B1919DF848}
const GUID	c_guidSkkImePreservedKeyToggleIME = {
	0xd8e44f2a, 0xa92d, 0x48f6, { 0x8d, 0x90, 0x78, 0xb1, 0x91, 0x9d, 0xf8, 0x48 }
} ;

/*========================================================================*
 *	global ``C'' functions
 */

/*	AdviseSink
 */
BOOL
AdviseSink (
	IUnknown*	pSourceIn,
	IUnknown*	pSink,
	REFIID		riid,
	DWORD*		pdwCookie)
{
    ITfSource*	pSource ;
    HRESULT		hr ;

	if (pSourceIn == NULL)
		return	FALSE ;
    if (pSourceIn->QueryInterface(IID_ITfSource, (void **)&pSource) != S_OK)
        return	FALSE ;

    hr = pSource->AdviseSink(riid, pSink, pdwCookie);

    pSource->Release () ;

    if (hr != S_OK) {
        // make sure we don't try to Unadvise pdwCookie later
        *pdwCookie = TF_INVALID_COOKIE;
        return FALSE;
    }

    return TRUE;
}

/*	UnadviseSink
 */
void
UnadviseSink (
	IUnknown*		pSourceIn,
	DWORD*			pdwCookie)
{
    ITfSource*		pSource ;

    if (*pdwCookie == TF_INVALID_COOKIE)
        return ; // never Advised

	if (pSourceIn == NULL)
		return ;

    if (pSourceIn->QueryInterface(IID_ITfSource, (void **)&pSource) == S_OK) {
        pSource->UnadviseSink (*pdwCookie) ;
        pSource->Release () ;
    }

    *pdwCookie	= TF_INVALID_COOKIE ;
	return ;
}

/*	AdviseSingleSink
 */
BOOL
AdviseSingleSink (
	TfClientId		tfClientId,
	IUnknown*		pSourceIn,
	IUnknown*		pSink,
	REFIID			riid)
{
    ITfSourceSingle*	pSource ;
    HRESULT				hr ;

    if (pSourceIn->QueryInterface(IID_ITfSourceSingle, (void **)&pSource) != S_OK)
        return	FALSE ;

    hr = pSource->AdviseSingleSink (tfClientId, riid, pSink) ;

    pSource->Release () ;

    return	(hr == S_OK);
}

/*	UnadviseSingleSink
 */
void
UnadviseSingleSink (
	TfClientId		tfClientId,
	IUnknown*		pSourceIn,
	REFIID			riid)
{
    ITfSourceSingle*	pSource ;

    if (pSourceIn->QueryInterface(IID_ITfSourceSingle, (void **)&pSource) == S_OK) {
        pSource->UnadviseSingleSink (tfClientId, riid) ;
        pSource->Release () ;
    }
}

void
InsertTextAtSelection (
	TfEditCookie		ec,
	ITfContext*			pContext,
	const WCHAR*		pchText,
	ULONG				cchText)
{
    ITfInsertAtSelection*	pInsertAtSelection ;
    ITfRange*				pRange ;
    TF_SELECTION			tfSelection ;

    // we need a special interface to insert text at the selection
    if (pContext->QueryInterface(IID_ITfInsertAtSelection, (void **)&pInsertAtSelection) != S_OK)
        return;

    // insert the text
    if (pInsertAtSelection->InsertTextAtSelection(ec, 0, pchText, cchText, &pRange) != S_OK)
        goto Exit;

    // update the selection, we'll make it an insertion point just past
    // the inserted text.
    pRange->Collapse(ec, TF_ANCHOR_END);

    tfSelection.range = pRange;
    tfSelection.style.ase = TF_AE_NONE;
    tfSelection.style.fInterimChar = FALSE;

    pContext->SetSelection(ec, 1, &tfSelection);

    pRange->Release();

Exit:
    pInsertAtSelection->Release();
}

BOOL
IsRangeCovered (TfEditCookie ec, ITfRange *pRangeTest, ITfRange *pRangeCover)
{
    LONG lResult;

    if (pRangeCover->CompareStart (ec, pRangeTest, TF_ANCHOR_START, &lResult) != S_OK ||
        lResult > 0) {
		DEBUGPRINTF ((TEXT ("pRangeCover->CompareStart (pRangeTest) = %ld\n"), lResult)) ;
        return	FALSE ;
    }

    if (pRangeCover->CompareEnd(ec, pRangeTest, TF_ANCHOR_END, &lResult) != S_OK ||
        lResult < 0) {
		DEBUGPRINTF ((TEXT ("pRangeCover->CompareEnd (pRangeTest) = %ld\n"), lResult)) ;
        return	FALSE ;
    }
    return	TRUE ;
}

BOOL
GetGUIDAtomFromGUID (
	REFGUID		refguid,
	DWORD*		pdw)
{
	ITfCategoryMgr*	pCategoryMgr ;
	HRESULT	hr ;

	hr = CoCreateInstance (CLSID_TF_CategoryMgr,
						   NULL, 
						   CLSCTX_INPROC_SERVER, 
						   IID_ITfCategoryMgr,
						   (void**)&pCategoryMgr) ;
	if (hr != S_OK)
        return	FALSE ;
	hr	= pCategoryMgr->RegisterGUID (refguid, pdw) ;
	pCategoryMgr->Release () ;
	return	(hr == S_OK) ;
}


void
DebugPrintf (
	LPCTSTR		strFormat,
	...)
{
	TCHAR		szBuffer [2048] ;
	va_list		vl ;

	if (strFormat == NULL)
		return ;

	va_start (vl, strFormat) ;
	wvnsprintf (szBuffer, sizeof (szBuffer) / sizeof (szBuffer [0]) - 1, strFormat, vl) ;
	va_end (vl) ;
	OutputDebugString (szBuffer) ;
	return ;
}

void
DebugPrintfW (
	LPCWSTR		strFormat,
	...)
{
	WCHAR		szBuffer [2048] ;
	va_list		vl ;

	if (strFormat == NULL)
		return ;

	va_start (vl, strFormat) ;
	wvnsprintfW (szBuffer, sizeof (szBuffer) / sizeof (szBuffer [0]) - 1, strFormat, vl) ;
	va_end (vl) ;
	OutputDebugStringW (szBuffer) ;
	return ;
}

