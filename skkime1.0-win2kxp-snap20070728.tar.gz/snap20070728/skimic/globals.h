//
// globals.h
//
// Global variable declarations.
//

#ifndef GLOBALS_H
#define GLOBALS_H

#include <windows.h>
#include <shlwapi.h>
#include <wchar.h>
#include <ole2.h>
#include <olectl.h>
#include <assert.h>
#include "msctf.h"
#include "ctffunc.h"

/*	function prototypes
 */
LONG	DllAddRef () ;
LONG	DllRelease () ;

void	InsertTextAtSelection (TfEditCookie ec, ITfContext *pContext, const WCHAR *pchText, ULONG cchText) ;
BOOL	AdviseSink (IUnknown *pSource, IUnknown *pSink, REFIID riid, DWORD *pdwCookie) ;
void	UnadviseSink (IUnknown *pSource, DWORD *pdwCookie) ;
BOOL	AdviseSingleSink (TfClientId tfClientId, IUnknown *pSource, IUnknown *pSink, REFIID riid) ;
void	UnadviseSingleSink (TfClientId tfClientId, IUnknown *pSource, REFIID riid) ;
BOOL	IsRangeCovered (TfEditCookie ec, ITfRange *pRangeTest, ITfRange *pRangeCover) ;
BOOL	GetGUIDAtomFromGUID (REFGUID refguid, DWORD* pdw) ;

void	DebugPrintf	(LPCTSTR strFormat,...) ;
void	DebugPrintfW(LPCWSTR strFormat,...) ;

#define	NELEMENTS(a) (sizeof(a)/sizeof(a[0]))
#if !defined (ARRAYSIZE)
#define	ARRAYSIZE(a) (sizeof(a)/sizeof(a[0]))
#endif
#define	ASSERT(x)	assert(x)

/*	�ނށALANGID�c����� SKKIME �� LANGID �ƈ�v������
 *	���Ƃ��K�v�Ȃ̂��H
 *
 *	MAKELANGID(p,s) := (s) << 10 | (p) ���BLANG_JAPANESE = 0x11 
 *	������A
 */
#define	SKKIME_LANGID			MAKELANGID(LANG_JAPANESE, SUBLANG_DEFAULT)
#define	SKKIME_KEYBOARDLAYOUT	TEXT("E0100411")	

#define	SKKIME_DESC				TEXT("SKKIME ver. 1.0")
#define	SKKIME_DESC_W			L"SKKIME ver. 1.0"
#define	SKKIME_DESC_A			"SKKIME ver. 1.0"
#define	SKKIME_MODEL			TEXT("Apartment")

//#define LANGBAR_ITEM_DESC	L"���̓��[�h" // max 32 chars! �ށA�ő�32�����������B

#define SKKIME_ICON_INDEX  7

//#define	REGKEY_SHOWKEYBRDICON		L"ShowKeyboardIcon"
//#define	REGKEY_SHOWIMEICON			L"ShowInputMethodIcon"
//#define	REGKEY_SHOWINPUTMODEICON	L"ShowInputModeIcon"

#define SafeRelease(punk)       \
{                               \
    if ((punk) != NULL)         \
    {                           \
        (punk)->Release();      \
    }                           \
}                   

#define SafeReleaseClear(punk)  \
{                               \
    if ((punk) != NULL)         \
    {                           \
        (punk)->Release();      \
        (punk) = NULL;          \
    }                           \
}                   

#if defined (DEBUG) || defined (DBG) || defined (_DEBUG)
#define	DEBUGPRINTF(text)	DebugPrintf##text
#define	DEBUGPRINTFW(text)	DebugPrintfW##text
#else
#define	DEBUGPRINTF(text)	/*text*/
#define	DEBUGPRINTFW(text)	/*text*/
#endif
#if !defined (MIN)
#define	MIN(left,right)		(((left) < (right))? (left) : (right))
#endif

//+---------------------------------------------------------------------------
//
// SafeStringCopy
//
// Copies a string from one buffer to another.  wcsncpy does not always
// null-terminate the destination buffer; this function does.
//----------------------------------------------------------------------------

inline void SafeStringCopy (WCHAR *pchDst, ULONG cchMax, const WCHAR *pchSrc)
{
    if (cchMax > 0) {
		wcsncpy(pchDst, pchSrc, cchMax) ;
		pchDst[cchMax-1] = '\0';
	}
}

extern HINSTANCE		g_hInst ;
extern LONG				g_cRefDll ;
extern CRITICAL_SECTION	g_cs ;
extern const CLSID		c_clsidSkkImeTextService ;
extern const GUID		c_guidSkkImeProfile ;
extern const GUID		c_guidConversionModeItemButton ;
extern const GUID		c_guidToolItemButton ;
extern const GUID		c_guidSkkImeDisplayAttribute ;
extern const GUID		c_guidSkkImeDisplayAttributeInput ;
extern const GUID		c_guidSkkImeDisplayAttributeTargetConverted	;
extern const GUID		c_guidSkkImePreservedKeyToggleIME ;

#endif // GLOBALS_H
