/*	register.cpp
 *
 *	COM Server registration code. ���Aregsvr32 �̎��ɗ��p�����
 *	�ƁB
 */
#include <windows.h>
#include <ole2.h>
#include "msctf.h"
#include "globals.h"
#include "skimic.h"

#define	CLSID_STRLEN 38  // strlen("{xxxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxx}")

#if defined (_UNICODE) || defined (UNICODE)
#define		CLSIDToString(refGUID,pch)	CLSIDToStringW((refGUID),(pch))
#else
#define		CLSIDToString(refGUID,pch)	CLSIDToStringA((refGUID),(pch))
#endif

const struct {
    const GUID*	pguidCategory ;
    const GUID*	pguid ;
}	c_rgCategories []	= {
    { &GUID_TFCAT_TIP_KEYBOARD,					&c_clsidSkkImeTextService	},
    { &GUID_TFCAT_DISPLAYATTRIBUTEPROVIDER,		&c_clsidSkkImeTextService	},
#if defined (TF_CONVERSIONMODE_ALPHANUMERIC)
	{ &GUID_TFCAT_TIPCAP_INPUTMODECOMPARTMENT,	&c_clsidSkkImeTextService	},
#endif
#if defined (__ITfUIElement_INTERFACE_DEFINED__)
	{ &GUID_TFCAT_TIPCAP_UIELEMENTENABLED,		&c_clsidSkkImeTextService	},
#endif
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
	{ &GUID_TFCAT_TIPCAP_SECUREMODE,			&c_clsidSkkImeTextService	},
#endif
} ;

static const TCHAR	c_szInfoKeyPrefix []	= TEXT ("CLSID\\") ;
static const TCHAR	c_szInProcSvr32 []		= TEXT ("InProcServer32") ;
static const TCHAR	c_szModelName []		= TEXT ("ThreadingModel") ;

/*  RegisterProfiles
 */
BOOL
CSkkImeTextService::RegisterProfiles ()
{
    ITfInputProcessorProfiles*	pInputProcessProfiles ;
    WCHAR	achIconFile [MAX_PATH] ;
    char	achFileNameA [MAX_PATH] ;
    DWORD	cchA ;
    int		cchIconFile ;
    HRESULT	hr ;
	HKL		hKL ;

    hr = CoCreateInstance (
		CLSID_TF_InputProcessorProfiles,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_ITfInputProcessorProfiles,
		(void**)&pInputProcessProfiles) ;
    if (hr != S_OK)
        return	E_FAIL ;

    hr	= pInputProcessProfiles->Register (c_clsidSkkImeTextService) ;
    if (hr != S_OK)
        goto	Exit ;

    cchA = GetModuleFileNameA (g_hInst, achFileNameA, NELEMENTS (achFileNameA)) ;

    cchIconFile = MultiByteToWideChar(CP_ACP, 0, achFileNameA, cchA, achIconFile, NELEMENTS(achIconFile)-1) ;
    achIconFile[cchIconFile] = '\0' ;

    hr = pInputProcessProfiles->AddLanguageProfile (
		c_clsidSkkImeTextService,
		SKKIME_LANGID, 
		c_guidSkkImeProfile, 
		SKKIME_DESC_W, 
		(ULONG)wcslen (SKKIME_DESC_W),
		achIconFile,
		cchIconFile,
		SKKIME_ICON_INDEX) ;	/* ICON INDEX? */
#if 1
	/*	IME �� bind �����邽�߂ɂ� SubstuteKeyboardLayout ���K�v
	 *	�Ȃ̂��낤���H ����Ƃ� AddLanguageProfile �� LANGID ��
	 *	SKKIME �� LANGID �ƈ�v�����邱�Ƃŗǂ��̂��낤���H
	 *	(��v�����ėǂ��̂��H�Ƃ�����������)
	 */
	if (hr != S_OK)
		goto	Exit ;
	hKL	= LoadKeyboardLayout (SKKIME_KEYBOARDLAYOUT, KLF_ACTIVATE) ;
	if (hKL != NULL) {
		hr	= pInputProcessProfiles->SubstituteKeyboardLayout (
			c_clsidSkkImeTextService,
			SKKIME_LANGID,
			c_guidSkkImeProfile,
			hKL) ;
	}
#endif
 Exit:
    pInputProcessProfiles->Release () ;
    return (hr == S_OK);
}

/*	UnregisterProfiles
 *
 *	�����Ƃ���AInputProcessProfiles ���� Unregister �𗘗p����
 *	���� service �� classid ���폜���邱�ƁA���ړI�B
 */
void
CSkkImeTextService::UnregisterProfiles ()
{
    ITfInputProcessorProfiles*	pInputProcessProfiles ;
    HRESULT	hr ;

    hr	= CoCreateInstance (
		CLSID_TF_InputProcessorProfiles,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_ITfInputProcessorProfiles,
		(void**)&pInputProcessProfiles) ;

    if (hr != S_OK)
        return ;

    pInputProcessProfiles->Unregister (c_clsidSkkImeTextService) ;
    pInputProcessProfiles->Release () ;
	return ;
}

/*	RegisterCategories
 *
 *	�J�e�S�����ǂ������̂������\���c�����Ă���Ƃ͌����Ȃ�����ǂ��A
 *	c_rgCategories ������ɁA�����������̂炵���B
 */
BOOL
CSkkImeTextService::RegisterCategories (
	BOOL		fRegister)
{
    ITfCategoryMgr*	pCategoryMgr ;
    int		i ;
    HRESULT	hr ;

    hr = CoCreateInstance (
		CLSID_TF_CategoryMgr,
		NULL, 
		CLSCTX_INPROC_SERVER, 
		IID_ITfCategoryMgr,
		(void**)&pCategoryMgr) ;
    if (hr != S_OK)
        return	FALSE ;

    for (i = 0 ; i < NELEMENTS (c_rgCategories) ; i++) {
        if (fRegister) {
            hr = pCategoryMgr->RegisterCategory (
				c_clsidSkkImeTextService,
				*c_rgCategories[i].pguidCategory,
				*c_rgCategories[i].pguid) ;
        } else {
            hr = pCategoryMgr->UnregisterCategory (
				c_clsidSkkImeTextService,
				*c_rgCategories[i].pguidCategory,
				*c_rgCategories[i].pguid) ;
        }
        if (hr != S_OK)
            break ;
    }
    pCategoryMgr->Release () ;
    return	(hr == S_OK) ;
}

/*	CLSIDToStringA
 */
BOOL
CLSIDToStringA (
	REFGUID			refGUID,
	char*			pchA)
{
    static const BYTE GuidMap[] = {
		3, 2, 1, 0, '-', 5, 4, '-', 7, 6, '-',
		8, 9, '-', 10, 11, 12, 13, 14, 15} ;

    static const char szDigits[] = "0123456789ABCDEF";

    int		i ;
    char*	p = pchA ;

    const BYTE * pBytes = (const BYTE *) &refGUID;

    *p++ = '{';
    for (i = 0; i < sizeof(GuidMap); i++) {
        if (GuidMap[i] == '-') {
            *p++ = '-';
        } else {
            *p++ = szDigits[ (pBytes[GuidMap[i]] & 0xF0) >> 4 ];
            *p++ = szDigits[ (pBytes[GuidMap[i]] & 0x0F) ];
        }
    }
	
    *p++ = '}';
    *p   = '\0';

    return	TRUE ;
}

BOOL
CLSIDToStringW (
	REFGUID			refGUID,
	WCHAR*			pchW)
{
    static const BYTE GuidMap[] = {
		3, 2, 1, 0, '-', 5, 4, '-', 7, 6, '-', 8, 9, '-', 10, 11, 12, 13, 14, 15
	} ;
    static const WCHAR szDigits[] = L"0123456789ABCDEF";

    int		i ;
    WCHAR*	p = pchW ;

    const BYTE * pBytes = (const BYTE *) &refGUID;

    *p++ = L'{';
    for (i = 0; i < sizeof(GuidMap); i++) {
        if (GuidMap[i] == '-') {
            *p++ = L'-';
        } else {
            *p++ = szDigits[ (pBytes[GuidMap[i]] & 0xF0) >> 4 ];
            *p++ = szDigits[ (pBytes[GuidMap[i]] & 0x0F) ];
        }
    }
	
    *p++ = L'}';
    *p   = L'\0';

    return	TRUE ;
}

/*	RecurseDeleteKey
 *
 *	����͂��̂܂ܓǂ�ŕ����̔@���Ƃ����ׂ����BNT �ɂ����� 
 *	RegDeleteKey �͓���� key �� subkey ������Ɠ����Ȃ�����
 *	�K�v���A�������B���������΁AIME �̎����������܂����W�X�g
 *	��������ł��Ȃ������悤�ȋC������c�B�����ARegEnumKey 
 *	������������肭�����ĂȂ������悤�ȋC������̂����c�B
 */
LONG
RecurseDeleteKey (
	HKEY		hParentKey,
	LPCTSTR		lpszKey)
{
    HKEY		hKey ;
    LONG		lRes ;
    FILETIME	time ;
    TCHAR		szBuffer [256] ;
    DWORD		dwSize	= NELEMENTS (szBuffer) ;

    if (RegOpenKey (hParentKey, lpszKey, &hKey) != ERROR_SUCCESS)
        return	ERROR_SUCCESS; // let's assume we couldn't open it because it's not there

    lRes = ERROR_SUCCESS;
    while (RegEnumKeyEx(hKey, 0, szBuffer, &dwSize, NULL, NULL, NULL, &time) == ERROR_SUCCESS) {
        szBuffer[NELEMENTS(szBuffer)-1] = '\0';
        lRes = RecurseDeleteKey(hKey, szBuffer);
        if (lRes != ERROR_SUCCESS)
            break;
        dwSize = NELEMENTS(szBuffer);
    }
    RegCloseKey(hKey);

    return lRes == ERROR_SUCCESS ? RegDeleteKey(hParentKey, lpszKey) : lRes;
}

/*	RegisterServer
 *
 *	���W�X�g���� COM �T�[�o�Ƃ��Ă̏��������œo�^���Ă���悤���B
 *	�������̕����͎����I�ɂȂ����̂��Ƃ΂���v���Ă������A�����ł�
 *	�Ȃ��炵���B
 */
BOOL
CSkkImeTextService::RegisterServer ()
{
    DWORD	dw ;
    HKEY	hKey ;
    HKEY	hSubKey ;
	int		nResult ;
    TCHAR	achIMEKey [NELEMENTS(c_szInfoKeyPrefix) + CLSID_STRLEN] ;
    TCHAR	achFileName [MAX_PATH] ;
    BOOL	fRet		= FALSE ;

    if (!CLSIDToString (c_clsidSkkImeTextService, achIMEKey + NELEMENTS (c_szInfoKeyPrefix) - 1))
        return	FALSE ;
    memcpy (achIMEKey, c_szInfoKeyPrefix, sizeof (c_szInfoKeyPrefix) - sizeof (TCHAR)) ;
	
	nResult	= RegCreateKeyEx(HKEY_CLASSES_ROOT, achIMEKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKey, &dw) ;
    if (nResult != ERROR_SUCCESS) 
		return	FALSE ;

	nResult	= RegSetValueEx (hKey, NULL, 0, REG_SZ, (BYTE *)SKKIME_DESC, (lstrlen(SKKIME_DESC) + 1) * sizeof (TCHAR)) ;
	if (nResult != ERROR_SUCCESS)
		goto	Exit ;

	nResult	= RegCreateKeyEx(hKey, c_szInProcSvr32, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hSubKey, &dw) ;
	if (nResult != ERROR_SUCCESS) 
		goto	Exit_1 ;

	dw	= GetModuleFileName (g_hInst, achFileName, NELEMENTS (achFileName)) ;

	if (RegSetValueEx (hSubKey, NULL, 0, REG_SZ, (BYTE *)achFileName, (lstrlen (achFileName) + 1) * sizeof (TCHAR)) == ERROR_SUCCESS &&
		RegSetValueEx (hSubKey, c_szModelName, 0, REG_SZ, (BYTE *)SKKIME_MODEL, (lstrlen (SKKIME_MODEL) + 1) * sizeof (TCHAR)) == ERROR_SUCCESS) {
		fRet	= TRUE ;
	}
 Exit_1:
	RegCloseKey (hSubKey) ;
 Exit:
	RegCloseKey (hKey) ;
    return	fRet ;
}

/*  UnregisterServer
 */
void
CSkkImeTextService::UnregisterServer ()
{
    TCHAR	achIMEKey [NELEMENTS (c_szInfoKeyPrefix) + CLSID_STRLEN] ;

    if (!CLSIDToString (c_clsidSkkImeTextService, achIMEKey + NELEMENTS (c_szInfoKeyPrefix) - 1))
        return ;

    memcpy (achIMEKey, c_szInfoKeyPrefix, sizeof (c_szInfoKeyPrefix) - sizeof (TCHAR)) ;
    RecurseDeleteKey (HKEY_CLASSES_ROOT, achIMEKey) ;
	return ;
}
