#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "editsess.h"

#if !defined (MAXCOMPLEN)
#define	MAXCOMPLEN	256
#endif

class CTReconvCandidateString ;
class CTReconvCandidateList ;
class CTReconvEnumTfCandidates ;

class CTReconvCandidateString : public ITfCandidateString {
private:
	WCHAR			_wszText [MAXCOMPLEN] ;
	int				_nIndex ;

    LONG			_cRef ;     // COM ref count

public:
	CTReconvCandidateString (LPCWSTR wstrText, int nIndex) {
		lstrcpynW (_wszText, wstrText, MAXCOMPLEN) ;
		_nIndex	= nIndex ;
		_cRef	= 1 ;
		return ;
	}

	virtual	~CTReconvCandidateString ()	{
	}

	STDMETHODIMP	QueryInterface (REFIID riid, void** ppvObj) {
		if (ppvObj == NULL)
			return	E_INVALIDARG ;

		*ppvObj	= NULL ;
		if (IsEqualIID (riid, IID_IUnknown) ||
			IsEqualIID (riid, IID_ITfCandidateString)) {
			*ppvObj	= (ITfCandidateString *)this ;
		}
		if (*ppvObj) {
			AddRef () ;
			return	S_OK ;
		}
		return	E_NOINTERFACE ;
	}

    STDMETHODIMP_(ULONG) AddRef(void) {
        return	++ _cRef ;
    }

    STDMETHODIMP_(ULONG) Release(void) {
        LONG cr = --_cRef ;
		
        assert(_cRef >= 0) ;
		
        if (_cRef == 0) {
            delete	this ;
        }
        return cr ;
    }

	STDMETHODIMP	GetString (BSTR* pbstr) {
		if (pbstr == NULL)
			return	E_INVALIDARG ;
		*pbstr	= SysAllocString (_wszText) ;
		return	(*pbstr != NULL)? S_OK : E_OUTOFMEMORY ;
	}
	STDMETHODIMP	GetIndex (ULONG* pnIndex) {
		if (pnIndex == NULL)
			return	E_INVALIDARG ;
		*pnIndex	= (ULONG) _nIndex ;
		return	S_OK ;
	}
} ;

class CTReconvEnumTfCandidates : public IEnumTfCandidates {
private:
	ITfCandidateList*		_pCandList ;
	ULONG					_nPos ;
    LONG					_cRef ;     // COM ref count

public:
	CTReconvEnumTfCandidates (ITfCandidateList* pCandList) {
		assert (pCandList != NULL) ;
		_pCandList	= pCandList ;
		_pCandList->AddRef () ;
		_nPos		= 0 ;
		_cRef		= 1 ;
		return ;
	}

	~CTReconvEnumTfCandidates () {
		if (_pCandList != NULL)
			_pCandList->Release () ;
		_pCandList	= NULL ;
	}

	STDMETHODIMP	QueryInterface (REFIID riid, void** ppvObj) {
		if (ppvObj == NULL)
			return	E_INVALIDARG ;

		*ppvObj	= NULL ;
		if (IsEqualIID (riid, IID_IUnknown) ||
			IsEqualIID (riid, IID_IEnumTfCandidates)) {
			*ppvObj	= (IEnumTfCandidates *)this ;
		}
		if (*ppvObj) {
			AddRef () ;
			return	S_OK ;
		}
		return	E_NOINTERFACE ;
	}

	STDMETHODIMP	Clone (IEnumTfCandidates** ppEnum) {
		CTReconvEnumTfCandidates*	pEnum ;
		
		if (ppEnum == NULL)
			return	S_OK ;	/* ? */

		pEnum	= new CTReconvEnumTfCandidates (_pCandList) ;
		if (pEnum == NULL)
			return	E_OUTOFMEMORY ;

		pEnum->_nPos	= _nPos ;
		*ppEnum			= pEnum ;
		return	S_OK ;
	}

	/*	���݈ʒu����  ulCount ���� Candidate ���m�ۂ��āA�m�ۂł����ʂ�
	 *	pcFetched �ɓ����ĕԂ����B
	 */
	STDMETHODIMP	Next (ULONG ulCount, ITfCandidateString** ppCand, ULONG* pcFetched) {
		ULONG	nCnt, nFetched, n ;
		HRESULT	hr ;

		if (ulCount > 0 && ppCand == NULL)
			return	E_INVALIDARG ;

		if (FAILED (_pCandList->GetCandidateNum (&nCnt)))
			return	S_FALSE ;

		nFetched	= ((_nPos + ulCount) > nCnt)? (nCnt - _nPos) : ulCount ;
		if (pcFetched != NULL)
			*pcFetched	= nFetched ;
		for (n = 0 ; n < nFetched ; n ++) {
			hr	= _pCandList->GetCandidate (_nPos + n, ppCand + n) ;
			if (FAILED (hr))
				return	hr ;
		}
		_nPos	+= nFetched ;	/* ����͕K�v�ȓ��삩�H */
		return	S_OK ;
	}

	STDMETHODIMP	Reset () {
		_nPos	= 0 ;
		return	S_OK ;
	}

	STDMETHODIMP	Skip (ULONG ulCount) {
		ULONG	nNewPos	= _nPos + ulCount ;
		ULONG	nCnt ;

		if (FAILED (_pCandList->GetCandidateNum (&nCnt)))
			return	S_FALSE ;
		if (nNewPos >= nCnt) {
			_nPos	= nCnt - 1 ;
			return	S_FALSE ;
		}
		_nPos	= nNewPos ;
		return	S_OK ;
	}

    STDMETHODIMP_(ULONG) AddRef(void) {
        return	++ _cRef ;
    }

    STDMETHODIMP_(ULONG) Release(void) {
        LONG cr = --_cRef ;
		
        assert(_cRef >= 0) ;
		
        if (_cRef == 0) {
            delete	this ;
        }
        return cr ;
    }
} ;

/*	�t�ϊ��̃��X�g���\�z���邱�Ƃ����݂ł��Ȃ��̂ŁA�^����ꂽ range
 *	�����̂܂ܓ��邱�ƂɂȂ�B
 */
class CTReconvCandidateList : public ITfCandidateList {
private:
	WCHAR				_wszCandidate [MAXCOMPLEN] ;
    LONG				_cRef ;     // COM ref count
	ULONG				_nResult ;
	TfCandidateResult	_imcr ;

public:
	CTReconvCandidateList (LPCWSTR wstrTEXT) {
		lstrcpynW (_wszCandidate, wstrTEXT, NELEMENTS (_wszCandidate)) ;
		_nResult	= (ULONG) -1 ;
		_imcr		= CAND_CANCELED ;
		_cRef		= 1 ;
	}

	virtual			~CTReconvCandidateList () {
	}

	STDMETHODIMP	QueryInterface (REFIID riid, void** ppvObj) {
		if (ppvObj == NULL)
			return	E_INVALIDARG ;

		*ppvObj	= NULL ;
		if (IsEqualIID (riid, IID_IUnknown) ||
			IsEqualIID (riid, IID_ITfCandidateList)) {
			*ppvObj	= (ITfCandidateList*) this ;
		}
		if (*ppvObj) {
			AddRef () ;
			return	S_OK ;
		}
		return	E_NOINTERFACE ;
	}

	STDMETHODIMP	EnumCandidates (IEnumTfCandidates** ppEnum) {
		if (ppEnum == NULL)
			return	E_INVALIDARG ;
		*ppEnum	= new CTReconvEnumTfCandidates (this) ;
		return	(*ppEnum != NULL)? S_OK : E_OUTOFMEMORY ;
	}

	STDMETHODIMP	GetCandidate (ULONG nIndex, ITfCandidateString** pCand) {
		if (nIndex != 0)
			return	E_INVALIDARG ;
		if (pCand == NULL)
			return	E_INVALIDARG ;
		*pCand	= new CTReconvCandidateString (_wszCandidate, nIndex) ;
		return	(*pCand != NULL)? S_OK : E_OUTOFMEMORY ;
	}

	STDMETHODIMP	GetCandidateNum (ULONG* pnCnt) {
		if (pnCnt == NULL)
			return	E_INVALIDARG ;
		*pnCnt	= 1 ;
		return	S_OK ;
	}

	STDMETHODIMP	SetResult (ULONG nIndex, TfCandidateResult imcr) {
		if (imcr != CAND_CANCELED && nIndex != 0)
			return	E_FAIL ;
		_nResult	= nIndex ;
		_imcr		= imcr ;
		return	S_OK ;
	}

    STDMETHODIMP_(ULONG) AddRef(void) {
        return	++ _cRef ;
    }

    STDMETHODIMP_(ULONG) Release(void) {
        LONG cr = --_cRef ;
		
        assert(_cRef >= 0) ;
		
        if (_cRef == 0) {
            delete	this ;
        }
        return cr ;
    }

	ULONG	GetResult (TfCandidateResult* pResult) {
		if (pResult != NULL)
			*pResult	= _imcr ;
		return	_nResult ;
	}
} ;

class CQueryReconversionSession : public CEditSessionBase
{
public:
	CQueryReconversionSession (CSkkImeTextService* pTSF, ITfContext* pContext, ITfRange* pRange) :
		CEditSessionBase (pContext)
	{
		_pTSF	= pTSF ;
		_pTSF->AddRef () ;
		_pRange	= pRange ;
		_pRange->AddRef () ;
	}

	~CQueryReconversionSession ()
	{
		_pTSF->Release () ;
		_pTSF	= NULL ;
		_pRange->Release () ;
		_pRange	= NULL ;
	}
	
	STDMETHODIMP	DoEditSession (TfEditCookie ec) ;

	HRESULT	GetResult (ITfRange** ppNewRange)
	{
		return	_pRange->Clone (ppNewRange) ;
	}

private:
	CSkkImeTextService*	_pTSF ;
	ITfRange*			_pRange ;
} ;

class CGetReconversionEditSession : public CEditSessionBase
{
public:
	CGetReconversionEditSession (CSkkImeTextService* pTSF, ITfContext* pContext, ITfRange* pRange) :
		CEditSessionBase (pContext)
	{
		DEBUGPRINTF ((TEXT ("CGetReconversionEditSession::constructor\n"))) ;
		_pTSF	= pTSF ;
		_pTSF->AddRef () ;
		_pRange	= pRange ;
		_pRange->AddRef () ;

		_wszTEXT [0]	= L'\0' ;
		_nTEXT	= 0 ;
	}

	~CGetReconversionEditSession ()
	{
		DEBUGPRINTF ((TEXT ("CGetReconversionEditSession::destructor\n"))) ;
		_pTSF->Release () ;
		_pTSF	= NULL ;
		_pRange->Release () ;
		_pRange	= NULL ;
	}

	STDMETHODIMP	DoEditSession (TfEditCookie ec) ;

	CTReconvCandidateList*	GetCandidateList ()
	{
#if defined (DEBUG) || defined (DBG)
		OutputDebugStringW (L"CGetReconversionEditSession::GetCandidateList\n") ;
		OutputDebugStringW (_wszTEXT) ;
#endif
		return	new CTReconvCandidateList (_wszTEXT) ;
	}

private:
	CSkkImeTextService*	_pTSF ;
	ITfRange*			_pRange ;
	WCHAR				_wszTEXT [MAXCOMPLEN] ;
	int					_nTEXT ;
} ;

class CReconvertEditSession : public CEditSessionBase
{
public:
	CReconvertEditSession (CSkkImeTextService* pTSF, ITfContext* pContext, CTReconvCandidateList* pCandList) : 
		CEditSessionBase (pContext)
	{
		_pTSF		= pTSF ;
		_pTSF->AddRef () ;
		_pCandList	= pCandList ;
		_pCandList->AddRef () ;
	}

	~CReconvertEditSession ()
	{
		_pTSF->Release () ;
		_pTSF		= NULL ;
		_pCandList->Release () ;
		_pCandList	= NULL ;
	}

	STDMETHODIMP	DoEditSession (TfEditCookie ec) ;

private:
	CSkkImeTextService*		_pTSF ;
	CTReconvCandidateList*	_pCandList ;
} ;

STDAPI
CQueryReconversionSession::DoEditSession (
	register TfEditCookie		ec)
{
	BOOL	fEmpty ;
	WCHAR	wszBuffer [256] ;
	ULONG	cch ;

	if (FAILED (_pRange->IsEmpty (ec, &fEmpty)))
		return	E_FAIL ;
	if (fEmpty) {
		DEBUGPRINTF ((TEXT ("CQueryReconversionSession/Range is empty.\n"))) ;
	} else {
		if (FAILED (_pRange->GetText (ec, 0, wszBuffer, NELEMENTS (wszBuffer) - 1, &cch))) {
			DEBUGPRINTF ((TEXT ("CQueryReconversionSession/GetText failed.\n"))) ;
		} else {
			wszBuffer [cch]	= L'\0' ;
			DEBUGPRINTF ((TEXT ("CQueryReconversionSession/Range is \"%s\"(%d)\n"), wszBuffer, cch)) ;
		}
	}
	return	S_OK ;
}

/*	Range �͈͓̔��ɂ��镶������E�������̏������s���Ă���B
 */
STDAPI
CGetReconversionEditSession::DoEditSession (
	register TfEditCookie		ec)
{
	ULONG	cch	= 0 ;

	if (FAILED (_pRange->GetText (ec, 0, _wszTEXT, MAXCOMPLEN - 1, &cch))) {
		DEBUGPRINTF ((TEXT ("CGetReconversionEditSession::DoEditSession failed.\n"))) ;
		return	E_FAIL ;
	}
	_nTEXT	= cch ;
	_wszTEXT [cch]	= L'\0' ;
#if defined (DEBUG) || defined (DBG)
	DEBUGPRINTF ((TEXT ("CGetReconversionEditSession::DoEditSession\n"))) ;
	OutputDebugStringW (_wszTEXT) ;
#endif
	return	S_OK ;
}

/*	Reconvert ���������鎞�̏����B
 */
STDAPI
CReconvertEditSession::DoEditSession (
	register TfEditCookie		ec)
{
	CSkkImeMgr*			pIME	= _pTSF->_GetCurrentIME () ;
	ULONG				nResult ;
	TfCandidateResult	imcr ;
	ITfCandidateString*	pCandStr ;
	BSTR				bstrCand ;
	HRESULT				hr ;

	nResult	= _pCandList->GetResult (&imcr) ;
	DEBUGPRINTF ((TEXT ("CReconversionEditSession/Result is \"%d\"\n"), nResult)) ;
	if (nResult == (ULONG)-1) {
		/*	��x���I�����ꂽ���Ƃ͂Ȃ��Ƃ������Ƃ�����A
		 *	������ dialog box �ł��o���āA�ǂ̌�₪�ǂ�����
		 *	���[�U�ɐq�˂�K�v������B
		 *
		 *	���A���͌���1�����Ȃ��āA���͂��ꂽ���̂�����
		 *	�܂܂Ȃ̂ŁA���̂悤�ɐݒ肷��B
		 */
		nResult	= 0 ;
		imcr	= CAND_FINALIZED ;
	} else {
		/*	��x�Ȃ�I�����ꂽ���Ƃ�����B
		 */
		if (imcr != CAND_FINALIZED) {
			/*	���ǁA���[�U�̓L�����Z�������Ɖ��߂���B
			 */
			hr	= S_OK ;
			goto	exit_func ;
		}
	}

	/*	�I�����ꂽ����ҏW�\���ɖ߂��B
	 */
	hr	= _pCandList->GetCandidate (nResult, &pCandStr) ;
	if (FAILED (hr))
		goto	exit_func ;
	if (SUCCEEDED (pCandStr->GetString (&bstrCand))) {
		OutputDebugStringW (bstrCand) ;
		hr	= pIME->OnReconvertSession (_pContext, ec, bstrCand) ;
		SysFreeString (bstrCand) ;
	}
	pCandStr->Release () ;
  exit_func:
	return	hr ;
}

/*========================================================================*
 */
STDAPI
CSkkImeTextService::QueryRange (
	ITfRange*			pRange,
	ITfRange**			ppNewRange,
	BOOL*				pfConvertable)
{
	CQueryReconversionSession*	pQuerySession ;
	ITfContext*	pContext ;
	HRESULT		hr ;

	DEBUGPRINTF ((TEXT ("ITfReconvert::QueryRange()\n"))) ;

	/*	�{���͔͈͒��������Ȃ���΂Ȃ�Ȃ����c�B
	 */
	if (pRange == NULL) {
		DEBUGPRINTF ((TEXT ("ITfReconvert::QueryRange(): pRange == NULL\n"))) ;
		return	E_INVALIDARG ;
	}
	if (FAILED (pRange->GetContext (&pContext)))
		return	E_INVALIDARG ;

	pQuerySession	= new CQueryReconversionSession (this, pContext, pRange) ;
	if (pQuerySession == NULL)
		return	E_OUTOFMEMORY ;

	pContext->RequestEditSession (_tfClientId, pQuerySession, TF_ES_SYNC | TF_ES_READ, &hr) ;
	if (SUCCEEDED (hr)) {
		hr	= pQuerySession->GetResult (ppNewRange) ;
		if (FAILED (hr))
			goto	exit_func ;
	}
	pQuerySession->Release () ;
	if (pfConvertable != NULL)
		*pfConvertable	= TRUE ;
	hr	= S_OK ;
  exit_func:
	return	hr ;
}

STDAPI
CSkkImeTextService::GetReconversion (
	ITfRange*			pRange,
	ITfCandidateList**	ppCandList)
{
	CGetReconversionEditSession*	pEditSession ;
	ITfContext*	pContext ;
	HRESULT	hr ;

	DEBUGPRINTF ((TEXT ("ITfReconvert::GetReconversion()\n"))) ;

	if (pRange == NULL || ppCandList == NULL)
		return	E_INVALIDARG ;

	if (FAILED (pRange->GetContext (&pContext)))
		return	E_INVALIDARG ;

	pEditSession	= new CGetReconversionEditSession (this, pContext, pRange) ;
	if (pEditSession == NULL)
		return	E_OUTOFMEMORY ;

	if (_pRCandidateList != NULL) {
		_pRCandidateList->Release () ;
		_pRCandidateList	= NULL ;
	}

	pContext->RequestEditSession (_tfClientId, pEditSession, TF_ES_SYNC | TF_ES_READ, &hr) ;
	if (SUCCEEDED (hr)) {
		CTReconvCandidateList*	pCandList ;

		pCandList	= pEditSession->GetCandidateList () ;
		if (pCandList == NULL) {
			hr	= E_OUTOFMEMORY ;
			goto	exit_func ;
		}
		_pRCandidateList	= pCandList ;
		_pRCandidateList->AddRef () ;
		*ppCandList	= pCandList ;
	}

  exit_func:
	pEditSession->Release () ;
	return	hr ;
}

/*��
 *	SetResult ����ĂȂ����́A���̒��Ń_�C�A���O���o���Č���I��������̂�
 *	����������̂悤���B
 *	�����ASetResult �� CandidateList �̒�����u���̌�₪�ǂ��v�ƑI�΂�Ă�
 *	��΁A������̗p�������ȋC������B����͎������Ȃ��Ƃ����Ȃ��������ȁB
 *
 *	Query �� GetCandidateList �����ꂸ�ɁA���� Reconvert ���Ă΂��\������
 *	��ȁB���̏ꍇ�ɂ͍l���Ȃ��Ƃ����Ȃ����B
 */
STDAPI
CSkkImeTextService::Reconvert (
	ITfRange*			pRange)
{
	CReconvertEditSession*	pEditSession ;
	ITfContext*	pContext ;
	HRESULT		hr ;

	DEBUGPRINTF ((TEXT ("ITfReconvert::Reconvert()\n"))) ;

	if (pRange == NULL)
		return	E_INVALIDARG ;

	if (FAILED (pRange->GetContext (&pContext)))
		return	E_INVALIDARG ;

	/*	��x�� GetCandidateList ���Ă΂�ĂȂ��ꍇ�ɂ́A���� Range �ɍ��ݒ�
	 *	����Ă��镶�����D���B
	 */
	if (_pRCandidateList == NULL) {
		ITfCandidateList*	pCandList	= NULL ;

		hr	= GetReconversion (pRange, &pCandList) ;
		if (FAILED (hr))
			return	hr ;
		pCandList->Release () ;
	}

	pEditSession	= new CReconvertEditSession (this, pContext, _pRCandidateList) ;
	if (pEditSession == NULL)
		return	E_OUTOFMEMORY ;

	if (_pRCandidateList != NULL) {
		_pRCandidateList->Release () ;
		_pRCandidateList	= NULL ;
	}
	pContext->RequestEditSession (_tfClientId, pEditSession, TF_ES_ASYNCDONTCARE | TF_ES_READWRITE, &hr) ;
	pEditSession->Release () ;
	return	hr ;
}


/*========================================================================*
 */
BOOL
CSkkImeTextService::_InitReconversion ()
{
	_pRCandidateList	= NULL ;
	return	TRUE ;
}

void
CSkkImeTextService::_UninitReconversion ()
{
	SafeReleaseClear (_pRCandidateList) ;
	_pRCandidateList	= NULL ;
	return ;
}

