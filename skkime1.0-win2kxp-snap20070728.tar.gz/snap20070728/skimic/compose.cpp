/*	compose.cpp
 *
 *	Composition code.
 */

#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "editsess.h"

class CCompositionEditSession : public CEditSessionBase
{
public:
    CCompositionEditSession (ITfContext* pContext, CSkkImeTextService* pTSF) :
		CEditSessionBase (pContext)
    {
		_pTSF	= pTSF ;
		_pTSF->AddRef () ;
    }
    ~CCompositionEditSession()
    {
		_pTSF->Release () ;
		_pTSF	= NULL ;
    }

    // ITfEditSession
    STDMETHODIMP	DoEditSession (TfEditCookie ec) ;

private:
	CSkkImeTextService*	_pTSF ;
} ;

class CTerminateCompositionEditSession : public CEditSessionBase
{
public:
    CTerminateCompositionEditSession (CSkkImeTextService* pTSF, ITfContext *pContext) :
		CEditSessionBase (pContext)
    {
        _pTSF	= pTSF ;
		_pTSF->AddRef () ;
    }
    ~CTerminateCompositionEditSession ()
	{
        _pTSF->Release () ;
		_pTSF	= NULL ;
    }

    // ITfEditSession
    STDMETHODIMP DoEditSession (TfEditCookie ec)
    {
		ITfRange*		pRange			= NULL ;
		ITfComposition*	pComposition	= NULL ;

		if (_pTSF->_IsComposing (&pComposition)) {
			if (pComposition->GetRange (&pRange) == S_OK) {
				pRange->SetText (ec, 0, L"", 0) ;
				pRange->Release () ;
				pRange	= NULL ;
			}
		}
        _pTSF->_TerminateComposition (ec) ;
        return	S_OK ;
    }

private:
	CSkkImeTextService*	_pTSF ;
} ;

BOOL
CSkkImeTextService::_StartComposition (
	register ITfContext*		pContext)
{
    CCompositionEditSession*	pCompositionEditSession	= NULL ;
	HRESULT						hr	= E_FAIL ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_StartComposition (Context:%p)\n"), pContext)) ;

	if (_IsComposing ())
		return	TRUE ;

	pCompositionEditSession = new CCompositionEditSession (pContext, this) ;
    if (pCompositionEditSession != NULL) {
		/* we need a document write lock
		 * the CCompositionEditSession will do all the work when the
		 * CCompositionEditSession::DoEditSession method is called by the context
		 */
		pContext->RequestEditSession (_tfClientId, pCompositionEditSession, TF_ES_READWRITE | TF_ES_ASYNCDONTCARE, &hr) ;
		DEBUGPRINTF ((TEXT ("_StartComposition (Context:%p) result (0x%x)\n"), pContext, hr)) ;
        pCompositionEditSession->Release () ;
    }
	return	(hr == S_OK) ;
}

void
CSkkImeTextService::_TerminateComposition (
	register TfEditCookie		ec)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_TerminateComposition ()\n"))) ;

	if (_pComposition != NULL) {
		_ClearCompositionDisplayAttributes (ec) ;
		_pComposition->EndComposition (ec) ;
		SafeReleaseClear (_pComposition) ;
	}
	return ;
}

void
CSkkImeTextService::_TerminateCompositionInContext (
	register ITfContext*		pContext)
{
    CTerminateCompositionEditSession*	pEditSession ;
    HRESULT	hr ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_TerminateCompositionInContext ()\n"))) ;

	pEditSession	= new CTerminateCompositionEditSession (this, pContext) ;
    if (pEditSession != NULL) {
        pContext->RequestEditSession (_tfClientId, pEditSession, TF_ES_ASYNCDONTCARE | TF_ES_READWRITE, &hr) ;
        pEditSession->Release () ;
    }
	return ;
}

void
CSkkImeTextService::_SetComposition (
	register ITfComposition*	pComposition)
{
	_pComposition	= pComposition ;
	return ;
}

BOOL
CSkkImeTextService::_IsComposing (
	register ITfComposition**	ppComposition)
{
	if (ppComposition)
		*ppComposition	= _pComposition ;
	return	(_pComposition != NULL) ;
}

STDAPI
CSkkImeTextService::OnCompositionTerminated (
	register TfEditCookie		ecWrite,
	register ITfComposition*	pComposition)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnCompositionTerminated ()\n"))) ;
    // we already have the composition cached, so we can ignore pComposition...

    // all this service wants to do is clear the display property
    _ClearCompositionDisplayAttributes (ecWrite) ;

	if (_pSkkIme != NULL) 
		_pSkkIme->OnClearSession (ecWrite, pComposition) ;

    // releae our cached composition
	if (_pComposition != NULL) {
		_pComposition->Release () ;
		_pComposition	= NULL ;
	}
    return	S_OK ;
}

void
CSkkImeTextService::_ClearCompositionDisplayAttributes (
	register TfEditCookie		ec)
{
	ITfContext*		pContext ;
    ITfRange*		pRangeComposition ;
    ITfProperty*	pDisplayAttributeProperty ;
#if defined (ClearCompositionDisplayAttributesMustClearReadingProperty)
	ITfProperty*	pReadingProperty ;
#endif

    // get the compositon range.
    if (FAILED (_pComposition->GetRange (&pRangeComposition)))
        return ;

    if (FAILED (pRangeComposition->GetContext (&pContext))) {
        pContext	= NULL ;
        goto	Exit ;
    }

    // get our the display attribute property
    if (SUCCEEDED (pContext->GetProperty (GUID_PROP_ATTRIBUTE, &pDisplayAttributeProperty))) {
        pDisplayAttributeProperty->Clear (ec, pRangeComposition) ;
        pDisplayAttributeProperty->Release () ;
    }
#if defined (ClearCompositionDisplayAttributesMustClearReadingProperty)
	if (SUCCEEDED (pContext->GetProperty (GUID_PROP_READING, &pReadingProperty))) {
		pReadingProperty->Clear (ec, pRangeComposition ) ;
		pReadingProperty->Release () ;
	}
#endif
  Exit:
	if (pContext != NULL)
		pContext->Release () ;
    pRangeComposition->Release () ;
	return ;
}

BOOL
CSkkImeTextService::_SetCompositionDisplayAttributes (
	register TfEditCookie		ec,
	register ITfRange*			pRangeInput,
	register ITfRange*			pRangeConverted)
{
	ITfContext*		pContext ;
    ITfRange*		pRangeComposition ;
    ITfProperty*	pDisplayAttributeProperty ;
	VARIANT			varI, varC ;
	BOOL			fEmpty ;
	HRESULT			hr ;

    // get the compositon range.
    if (FAILED (_pComposition->GetRange (&pRangeComposition)))
        return	FALSE ;

    if (FAILED (pRangeComposition->GetContext (&pContext))) {
        pContext	= NULL ;
        goto	Exit ;
    }

    // get our the display attribute property
    if (FAILED (pContext->GetProperty (GUID_PROP_ATTRIBUTE, &pDisplayAttributeProperty)))
		goto	Exit ;

	VariantInit (&varI) ;
	VariantInit (&varC) ;
	varI.vt		= VT_I4 ;
	varI.lVal	= (DWORD) _gaDisplayAttributeInput ;
	varC.vt		= VT_I4 ;
	varC.lVal	= (DWORD) _gaDisplayAttributeConverted ;

	pDisplayAttributeProperty->Clear (ec, pRangeComposition) ;
	if (pRangeInput != NULL) {
		hr	= pRangeInput->IsEmpty (ec, &fEmpty) ;
		if (SUCCEEDED (hr) && !fEmpty)
			pDisplayAttributeProperty->SetValue (ec, pRangeInput, &varI) ;
	}
	if (pRangeConverted != NULL) {
		hr	= pRangeConverted->IsEmpty (ec, &fEmpty) ;
		if (SUCCEEDED (hr) && !fEmpty)
			pDisplayAttributeProperty->SetValue (ec, pRangeConverted, &varC) ;
	}
	pDisplayAttributeProperty->Release () ;
	VariantClear (&varI) ;
	VariantClear (&varC) ;
  Exit:
	return	TRUE ;
}

STDAPI
CCompositionEditSession::DoEditSession (
	register TfEditCookie		ec)
{
    ITfInsertAtSelection*	pInsertAtSelection	= NULL ;
    ITfContextComposition*	pContextComposition	= NULL ;
    ITfComposition*			pComposition		= NULL ;
    ITfRange*				pRangeInsert		= NULL ;
    HRESULT					hr					= E_FAIL ;

	DEBUGPRINTF ((TEXT ("CCompositionEditSession::DoEditSession ()\n"))) ;

    if (_pContext->QueryInterface (IID_ITfContextComposition, (void **)&pContextComposition) != S_OK)
        return	E_FAIL ;

	// let's start a new composition over the current selection
	// this is totally contrived, a real text service would have
	// some meaningful logic to trigger this
	
	// first, test where a keystroke would go in the document if we did an insert
	// we need a special interface to insert text at the selection
	if (_pContext->QueryInterface (IID_ITfInsertAtSelection, (void **)&pInsertAtSelection) != S_OK) {
		pInsertAtSelection	= NULL ;
		goto	Exit ;
	}

	if (pInsertAtSelection->InsertTextAtSelection (ec, TF_IAS_QUERYONLY, NULL, 0, &pRangeInsert) != S_OK) {
		DEBUGPRINTF ((TEXT ("ITfContextComposition::InsertTextAtSelection failed.\n"))) ;
		goto	Exit ;
	}

	// start the composition
	if (pContextComposition->StartComposition (ec, pRangeInsert, _pTSF, &pComposition) != S_OK) {
		DEBUGPRINTF ((TEXT ("ITfContextComposition::StartComposition failed.\n"))) ;
		pComposition	= NULL ;
	}
	pRangeInsert->Release () ;

	/*	pComposition may be NULL even if StartComposition return S_OK,
	 *	this mean the application rejected the composition
	 */
	if (pComposition != NULL) {
		ITfRange*	pRange	= NULL ;

		_pTSF->_SetComposition (pComposition) ;
		if (SUCCEEDED (pComposition->GetRange (&pRange))) {
			_pTSF->_SetCompositionDisplayAttributes (ec, pRange, NULL) ;
			pRange->Release () ;
		}
	}
    hr	= S_OK ;

 Exit:
	if (pContextComposition != NULL)
		pContextComposition->Release () ;
	if (pInsertAtSelection != NULL)
		pInsertAtSelection->Release () ;
	return	hr ;
}




