#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"

#define	SKKIME_FUNCTION_DESC	L"SKKIME1.0 FunctionProvider"

// {F3BF69BE-583C-4598-BE01-5386899C2CA4}
static const GUID	_Guid_ITfFunctionProvider = {
	0xf3bf69be, 0x583c, 0x4598, { 0xbe, 0x1, 0x53, 0x86, 0x89, 0x9c, 0x2c, 0xa4 }
} ;

HRESULT
CSkkImeTextService::GetType (
	GUID*		pguid)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetType ()\n"))) ;

	if (pguid == NULL)
		return	E_INVALIDARG ;
	*pguid	= _Guid_ITfFunctionProvider ;
	return	S_OK ;
}

HRESULT
CSkkImeTextService::GetDescription (
	BSTR*		pbstrDesc)
{
	BSTR	bstrDesc ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetDescription ()\n"))) ;

	if (pbstrDesc == NULL)
		return	E_INVALIDARG ;

	bstrDesc	= SysAllocString (SKKIME_FUNCTION_DESC) ;
	if (bstrDesc == NULL)
		return	E_OUTOFMEMORY ;
	*pbstrDesc	= bstrDesc ;
	return	S_OK ;
}

HRESULT
CSkkImeTextService::GetFunction (
	REFGUID		rguid,
	REFIID		riid,
	IUnknown**	ppunk)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction ()\n"))) ;

	if (ppunk == NULL)
		return	E_INVALIDARG ;

	/*	
	 */
	*ppunk	= NULL ;
	if (IsEqualIID (riid, IID_ITfFnConfigure)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnConfigure)\n"))) ;
		*ppunk	= (ITfFnConfigure *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnConfigureRegisterWord)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnConfigureRegisterWord)\n"))) ;
		*ppunk	= (ITfFnConfigureRegisterWord *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnReconversion)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnReconversion)\n"))) ;
		*ppunk	= (ITfFnReconversion *)this ;
#if defined (not_work)
		/*	ITfFnPropertyUIStatus �͉��������Ηǂ��̂��낤�B�܂���񂪂Ȃ��B
		 */
	} else if (IsEqualIID (riid, IID_ITfFnPropertyUIStatus)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnPropertyUIStatus)\n"))) ;
		*ppunk	= (ITfFnPropertyUIStatus *)this ;
#endif
	}
	if (*ppunk != NULL) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

BOOL
CSkkImeTextService::_InitFunctionProvider ()
{
	HRESULT				hr ;
	ITfSourceSingle*	pSourceSingle ;

	if (_pThreadMgr == NULL)
		return	FALSE ;
	hr = _pThreadMgr->QueryInterface(IID_ITfSourceSingle, (LPVOID*)&pSourceSingle) ;
	if (FAILED (hr)) {
		DEBUGPRINTF ((TEXT ("_pThreadMgr->QueryInterface failed (0x%lx)\n"), (DWORD)hr)) ;
		return	FALSE ;
	}
	
	hr	= pSourceSingle->AdviseSingleSink (_tfClientId, IID_ITfFunctionProvider, (ITfFnConfigure *)this) ;
#if defined (DEBUG) || defined (DBG)
	if (FAILED (hr)) {
		DEBUGPRINTF ((TEXT ("pSourceSingle->AdviseSingleSink failed (0x%lx)\n"), (DWORD)hr)) ;
	}
#endif
	pSourceSingle->Release () ;
	return	SUCCEEDED (hr) ;
}

void
CSkkImeTextService::_UninitFunctionProvider ()
{
	HRESULT				hr ;
	ITfSourceSingle*	pSourceSingle ;

	if (_pThreadMgr == NULL)
		return ;
	hr = _pThreadMgr->QueryInterface(IID_ITfSourceSingle, (LPVOID*)&pSourceSingle) ;
	if (FAILED (hr)) 
		return ;
	
	pSourceSingle->UnadviseSingleSink (_tfClientId, IID_ITfFunctionProvider) ;
	pSourceSingle->Release () ;
	return ;
}

