#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "uistatus.h"
#include "commctrl.h"
#include "IME\ImeDoc.h"
#include "editsess.h"
#include "daiparam.h"
#include "resource.h"

struct TEXTREGION {
	int			m_nCandidate ;
	int			m_nOffset ;
	int			m_nLength ;
} ;

struct MYMENUITEMINFO {
	UINT				m_fMask ;
	UINT				m_fType ;
	DWORD				m_wID ;
	LPTSTR				m_dwTypeData ;
} ;

/*========================================================================
 *	prototypes
 */
static	HFONT	_CheckNativeCharset (HDC hDC) ;
static	int		_HasWordAnnotation (LPCWSTR pWord, int nWord) ;
static	HBRUSH	_GetImeLineBrush (HWND, int, int, COLORREF*, HBITMAP*, int*) ;

/*========================================================================
 *	class CGetTextExtentEditSession
 */
class CGetTextExtentEditSession : public CEditSessionBase
{
public:
    CGetTextExtentEditSession (CSkkImeTextService* pTSF, ITfContext* pContext, ITfContextView* pContextView, ITfRange* pRange, CUIStatus* pUIStatus) : CEditSessionBase (pContext)
    {
		_pTSF				= pTSF ;
        _pContextView		= pContextView ;
        _pRange				= pRange ;
		_pUIStatus			= pUIStatus ;
    }

    // ITfEditSession
    STDMETHODIMP	DoEditSession (TfEditCookie ec) ;

private:
	CSkkImeTextService*	_pTSF ;
    ITfContextView*		_pContextView ;
    ITfRange*			_pRange ;
	CUIStatus*			_pUIStatus ;
} ;

STDAPI
CGetTextExtentEditSession::DoEditSession (TfEditCookie ec)
{
	RECT					rc, rcTemp ;
    BOOL					fClipped ;
	HRESULT					hr ;

	if (FAILED (_pContextView->GetScreenExt (&rcTemp)))
		return	S_FALSE ;

	hr	= _pContextView->GetTextExt (ec, _pRange, &rc, &fClipped) ;
	if (hr == S_OK && rc.top < rc.bottom) {
		DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d)\n"), rc.left, rc.right, rc.top, rc.bottom)) ;
		//rc.left		= rcTemp.left ;
		//rc.right	= rcTemp.right ;
		_pUIStatus->_SetTargetRect (&rc) ;
	} else {
		DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d) failed(0x%x),(range:%p)\n"),
			rc.left, rc.right, rc.top, rc.bottom,
			hr, _pRange)) ;
		_pUIStatus->_SetTargetRect (&rcTemp) ;
	}
    return	S_OK ;
}

/*========================================================================
 *	class CUIStatus
 */
const TCHAR		CUIStatus::_szUIStatusWndClass   []	= TEXT ("SkkImeTextService CUIStatus Wnd Class") ;
const TCHAR		CUIStatus::_szUIToolTipClassName []	= TEXT ("SkkImeTextService CUIToolTip Wnd Class") ;

CUIStatus::CUIStatus (
	CSkkImeTextService*		pTSF,
	CSkkImeMgr*				pIME)
{
	_pTSF					= pTSF ;
	_pIME					= pIME ;
	_pContext				= NULL ;
	_pRange					= NULL ;
	_dwCookieTextLayoutSink	= TF_INVALID_COOKIE ;
	_hwnd					= NULL ;
	_cRef					= 1 ;
	_bButtonPressed			= FALSE ;
	_rcTarget.left	= _rcTarget.top		= 0 ;
	_rcTarget.right	= _rcTarget.bottom	= 1 ;
	DllAddRef () ;
	return ;
}

CUIStatus::~CUIStatus ()
{
	_Close () ;
	DllRelease () ;
	return ;
}

STDAPI
CUIStatus::QueryInterface (REFIID riid, void** ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
    if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfTextLayoutSink)) {
        *ppvObj = (ITfTextLayoutSink *)this ;
    }

    if (*ppvObj) {
        AddRef () ;
        return	S_OK ;
    }
    return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CUIStatus::AddRef ()
{
    return	++_cRef ;
}

STDAPI_(ULONG)
CUIStatus::Release ()
{
    LONG	cr = --_cRef ;

    assert (_cRef >= 0) ;

    if (_cRef == 0) {
        delete	this ;
    }
    return	cr ;
}

STDAPI
CUIStatus::OnLayoutChange (
	ITfContext*			pContext,
	TfLayoutCode		lcode,
	ITfContextView*		pContextView)
{
	DEBUGPRINTF ((TEXT ("CUIStatus::OnLayoutChange ()\n"))) ;

    if (pContext != _pContext)
        return	S_OK ;

    switch (lcode) {
	case	TF_LC_CREATE:
	case	TF_LC_CHANGE:
		DEBUGPRINTF ((TEXT ("CUIStatus::OnLayoutChange (TF_LC_CHANGE)\n"))) ;
		if (_hwnd != NULL) 
			_AdjustWindow (pContextView) ;
		break ;

	case TF_LC_DESTROY:
		DEBUGPRINTF ((TEXT ("CUIStatus::OnLayoutChange (TF_LC_DESTROY)\n"))) ;
		_Close () ;
		break ;
	default:
		break ;
    }
    return	S_OK ;
}

/*========================================================================*
 */
HRESULT
CUIStatus::_Open (
	ITfContext*			pContextDocument,
	ITfRange*			pRange)
{
	ITfContextView*	pContextView	= NULL ;
    HRESULT			hr				= E_FAIL ;

	DEBUGPRINTF ((TEXT ("CUIStatus::_ShowWindow (Context:%p)\n"), pContextDocument)) ;

	_Close () ;
	_pRange		= pRange ;
	if (_pRange != NULL)
		_pRange->AddRef () ;
    _pContext	= pContextDocument ;
    _pContext->AddRef () ;
    if (FAILED (_AdviseTextLayoutSink ()))
        goto	Exit ;

	if (_CreateWindow ()) {
		RECT					rcUI ;
		CImeDoc*				pDoc	= NULL ;
		const IMECANDIDATES*	pMyCand ;

		if (FAILED (_pContext->GetActiveView (&pContextView))) 
			goto	Skip ;
		_AdjustWindow (pContextView) ;
Skip:
		pDoc	= (_pIME != NULL)? _pIME->GetDocument () : NULL ;
		if (pDoc != NULL) {
			pMyCand		= pDoc->GetStatusText () ;
		} else {
			pMyCand		= NULL ;
		}
		_AdjustRect (&rcUI, pMyCand, &_rcTarget) ;
		MoveWindow (_hwnd, rcUI.left, rcUI.top, rcUI.right, rcUI.bottom, TRUE) ;
		DEBUGPRINTF ((TEXT ("CUIStatus::_Open -> MoveWindow (%d, %d, %d, %d)\n"),
			rcUI.left, rcUI.top, rcUI.right, rcUI.bottom)) ;

		_ConfigureAnnotation () ;
		_ShowBalloonTip (&rcUI) ;
		if (pMyCand != NULL && pMyCand->_iStyle != IMECANDSTYLE_UNUSED) {
			ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
		} else {
			ShowWindow (_hwnd, SW_HIDE) ;
		}
		hr	= S_OK ;
    }
Exit:
	_bButtonPressed	= FALSE ;
	if (pContextView != NULL)
		pContextView->Release () ;
    if (FAILED (hr)) 
		_Close () ;
    return	hr ;
}

void
CUIStatus::_Update ()
{
	CImeDoc*				pDoc	= NULL ;
	RECT					rcWnd, rcUI, rc ;
	const IMECANDIDATES*	pMyCand ;

	if (_hwnd == NULL || _pContext == NULL)
		return ;
#if 0 //defined (DEBUG) || defined (_DEBUG)
	{
		ITfContextView*	pContextView	= NULL ;
		if (SUCCEEDED (_pContext->GetActiveView (&pContextView)) && pContextView != NULL) {
			_QueryWindowPos (pContextView) ;
			pContextView->Release () ;
		}
	}
#endif
	GetWindowRect (_hwnd, &rcWnd) ;
	GetClientRect (_hwnd, &rc) ;
	rc.left	= rcWnd.left ;
	rc.top	= rcWnd.top ;
	pDoc	= (_pIME != NULL)? _pIME->GetDocument () : NULL ;
	if (pDoc != NULL) {
		pMyCand		= pDoc->GetStatusText () ;
	} else {
		pMyCand		= NULL ;
	}
	if (pMyCand == NULL) {
		ShowWindow (_hwnd, SW_HIDE) ;
		return ;
	}

	_AdjustRect (&rcUI, pMyCand, &_rcTarget) ;
	if (pMyCand != NULL && pMyCand->_iStyle != IMECANDSTYLE_UNUSED) {
		if (rcUI.left  != rcWnd.left || rcUI.top != rcWnd.top ||
			rcUI.right != (rcWnd.right - rcWnd.left) || rcUI.bottom != (rcWnd.bottom - rcWnd.top)) {
			DEBUGPRINTF ((TEXT ("CUIStatus::_Update (position(%d,%d,w:%d,h:%d)->(%d,%d,w:%d,h:%d),%d,%d\n"),
				rcWnd.left, rcWnd.top, rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top,
				rcUI.left, rcUI.top, rcUI.right, rcUI.bottom)) ;
			MoveWindow (_hwnd, rcUI.left, rcUI.top, rcUI.right, rcUI.bottom, TRUE) ;
//			ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
		}
	}
	_ConfigureAnnotation () ;
	_ShowBalloonTip (&rcUI) ;
	if (pMyCand != NULL && pMyCand->_iStyle != IMECANDSTYLE_UNUSED) {
		ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
		InvalidateRect (_hwnd, NULL, FALSE) ;
	} else {
		ShowWindow (_hwnd, SW_HIDE) ;
	}
	return ;
}

void
CUIStatus::_Close ()
{
	DEBUGPRINTF ((TEXT ("CUIStatus::_Close ()\n"))) ;

    if (_hwnd) {
		DEBUGPRINTF ((TEXT ("CUIStatus::_Close () -> DestroyWindow\n"))) ;
		ShowWindow (_hwnd, SW_HIDE) ;
		DestroyWindow (_hwnd) ;
		_hwnd	= NULL ;
    }
    if (_pContext) {
		_UnadviseTextLayoutSink () ;
		_pContext->Release () ;
		_pContext	= NULL ;
    }
	if (_pRange) {
		_pRange->Release () ;
		_pRange		= NULL ;
	}
	_dwCookieTextLayoutSink	= TF_INVALID_COOKIE ;
	return ;
}

void
CUIStatus::_Popup (BOOL fShow)
{
	if (_hwnd == NULL || _pContext == NULL)
		return ;
	ShowWindow (_hwnd, fShow? SW_SHOWNOACTIVATE : SW_HIDE) ;
	return ;
}

BOOL
CUIStatus::_IsContextStatusWindow (ITfContext* pContext) const
{
	return	(pContext == _pContext) ;
}

BOOL
CUIStatus::_IsActivep (ITfContext* pContext) const
{
	return	_hwnd != NULL && _IsContextStatusWindow (pContext) ;
}

HRESULT
CUIStatus::_AdviseTextLayoutSink()
{
    HRESULT		hr ;
    ITfSource*	pSource	= NULL ;

    hr	= E_FAIL ;
    if (FAILED (_pContext->QueryInterface (IID_ITfSource, (void **)&pSource)))
        goto	Exit ;

    if (FAILED (pSource->AdviseSink (IID_ITfTextLayoutSink, (ITfTextLayoutSink *)this, &_dwCookieTextLayoutSink)))
        goto	Exit ;

    hr	= S_OK ;
Exit:
    if (pSource != NULL)
        pSource->Release () ;
    return	hr ;
}

HRESULT
CUIStatus::_UnadviseTextLayoutSink()
{
    HRESULT		hr ;
    ITfSource*	pSource	= NULL ;

    hr	= E_FAIL ;
    if (_pContext == NULL)
        goto	Exit ;

    if (FAILED (_pContext->QueryInterface (IID_ITfSource, (void **)&pSource)))
        goto	Exit ;

    if (FAILED (pSource->UnadviseSink (_dwCookieTextLayoutSink)))
        goto	Exit;

    hr	= S_OK ;
Exit:
    if (pSource != NULL)
        pSource->Release () ;
    return	hr ;
}

/*========================================================================*
 */
BOOL
CUIStatus::_CreateWindow ()
{
	WNDCLASS	wc ;

	if (_hwnd != NULL)
		return	TRUE ;

	memset (&wc, 0, sizeof (wc)) ;
	wc.lpfnWndProc		= CUIStatus::_UIStatusWndProc ;
	wc.hInstance		= g_hInst ;
	wc.lpszClassName	= CUIStatus::_szUIStatusWndClass ;

	if (RegisterClass (&wc) == 0) {
		DWORD	dwError	= GetLastError () ;
		if (dwError != ERROR_CLASS_ALREADY_EXISTS) {
			DEBUGPRINTF ((TEXT ("CUIStatus::_RegisterClass (0x%lx) failed.\n"), dwError)) ;
			return	FALSE ;
		}
	}

	memset (&wc, 0, sizeof (wc)) ;
	wc.lpfnWndProc		= CUIStatus::_UIToolTipWndProc ;
	wc.hInstance		= g_hInst ;
	wc.cbWndExtra		= sizeof (LONG) ;
	wc.lpszClassName	= CUIStatus::_szUIToolTipClassName ;
	if (RegisterClass (&wc) == 0) {
		DWORD	dwError	= GetLastError () ;
		if (dwError != ERROR_CLASS_ALREADY_EXISTS) {
			DEBUGPRINTF ((TEXT ("CUIStatus::_RegisterClass (0x%lx) failed.\n"), dwError)) ;
			return	FALSE ;
		}
	}

	_hwnd	= CreateWindowEx (WS_EX_DLGMODALFRAME | WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
							  _szUIStatusWndClass,
							  TEXT ("SkkImeTextService CUIStatus Wnd"),
							  WS_DISABLED | WS_POPUP,
							  0, 0, 100, 32, NULL, NULL, g_hInst, this) ;
	if (_hwnd == NULL || ! IsWindow (_hwnd)) {
		DEBUGPRINTF ((TEXT ("CUIStatus::_CreateWindowEx () failed.\n"))) ;
		return	FALSE ;
	}
	ShowWindow (_hwnd, SW_HIDE) ;

	/*	tooltip Window ���쐬����B*/
	_hwndTT		= CreateWindowEx (WS_EX_TOPMOST, (LPTSTR)_szUIToolTipClassName, NULL, 
			WS_DISABLED | WS_POPUP | WS_BORDER, 0, 0, 1, 1, _hwnd, NULL, g_hInst, this) ;
	if (_hwndTT == NULL || ! IsWindow (_hwndTT)) {
		DEBUGPRINTF ((TEXT ("CUIStatus::_CreateWindowEx () failed (tooltip).\n"))) ;
		return	FALSE ;
	}
	ShowWindow (_hwndTT, SW_HIDE) ;
	return	TRUE ;
}

void
CUIStatus::_SetTargetRect (
	const RECT*		pRect)
{
	if (pRect != NULL) {
		_rcTarget	= *pRect ;
	} else {
		_rcTarget.left  = _rcTarget.top    = 0 ;
		_rcTarget.right = _rcTarget.bottom = 1 ;
	}
	return ;
}

void
CUIStatus::_AdjustWindow (
	ITfContextView*		pContextView)
{
	CGetTextExtentEditSession*	pEditSession ;
	HRESULT						hr ;
	
	if (_pContext == NULL || _hwnd == NULL || pContextView == NULL)
		return ;

	pEditSession	= new CGetTextExtentEditSession (_pTSF, _pContext, pContextView, _pRange, this) ;
	if (pEditSession != NULL) {
		_pContext->RequestEditSession (_pTSF->_GetClientId (), pEditSession, TF_ES_SYNC | TF_ES_READ, &hr) ;
		if (hr == S_OK) {
			CSkkImeMgr*					pIME	= NULL ;
			CImeDoc*					pDoc	= NULL ;
			const IMECANDIDATES*		pMyCand	= NULL ;
			RECT						rcUI ;

			pIME	= (_pTSF != NULL)? _pTSF->_GetCurrentIME () : NULL ;
			pDoc	= (pIME  != NULL)? pIME->GetDocument () : NULL ;
			if (pDoc != NULL) {
				pMyCand		= pDoc->GetStatusText () ;
			} else {
				pMyCand		= NULL ;
			}
			_AdjustRect (&rcUI, pMyCand, &_rcTarget) ;
			MoveWindow (_hwnd, rcUI.left, rcUI.top, rcUI.right, rcUI.bottom, TRUE) ;
			_ConfigureAnnotation () ;
			_ShowBalloonTip (&rcUI) ;
			if (pMyCand != NULL && pMyCand->_iStyle != IMECANDSTYLE_UNUSED) {
				ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
			} else {
				ShowWindow (_hwnd, SW_HIDE) ;
			}
		}
		pEditSession->Release () ;
	}
	return ;
}

#if defined (DEBUG) || defined (_DEBUG)
void
CUIStatus::_QueryWindowPos (
	ITfContextView*		pContextView)
{
	CGetTextExtentEditSession*	pEditSession ;
	HRESULT						hr ;
	RECT						rc ;
	
	if (_pContext == NULL || _hwnd == NULL || pContextView == NULL)
		return ;

	rc				= _rcTarget ;
	pEditSession	= new CGetTextExtentEditSession (_pTSF, _pContext, pContextView, _pRange, this) ;
	if (pEditSession != NULL) {
		_pContext->RequestEditSession (_pTSF->_GetClientId (), pEditSession, TF_ES_SYNC | TF_ES_READ, &hr) ;
		if (hr == S_OK) {
			DEBUGPRINTF ((TEXT ("Query result(l:%d, r:%d, t:%d, b:%d)\n"),
				_rcTarget.left, _rcTarget.right, _rcTarget.top, _rcTarget.bottom)) ;
		}
		pEditSession->Release () ;
	}
	_rcTarget		= rc ;
	return ;
}
#endif

void
CUIStatus::_PaintUIStatusWnd (
	HWND	hwnd,
	HDC		hDC)
{
	CImeDoc*	pDoc	= NULL ;
	HFONT		hOldFont ;
	const IMECANDIDATES*	pMyCand ;
	RECT		rc ;

	pDoc		= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return ;

	pMyCand		= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED) {
		ShowWindow (hwnd, SW_HIDE) ;
		return ;
	}

	hOldFont	= _CheckNativeCharset (hDC) ;
	GetClientRect (_hwnd, &rc) ;
	switch (pMyCand->_iStyle) {
	case	IMECANDSTYLE_READ:
		_PaintCandidateList (hDC, pMyCand, &rc) ;
		break ;
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		_PaintCodeList (hDC, pMyCand, &rc) ;
		break ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
		_PaintMinibufferText (hDC, pMyCand, &rc) ;
		break ;
	default:
		break ;
	}
	DeleteObject (SelectObject (hDC, hOldFont)) ;
	return ;
}

BOOL
CUIStatus::_PaintCandidateList (
	HDC						hDC,
	const IMECANDIDATES*	pMyCand,
	LPRECT					prcDraw)
{
	HBRUSH				hULBrush = NULL, hOldBrush = NULL ;
	HBRUSH				hBrushBg = NULL ;
	HBITMAP				hbmUL = NULL ;
	int					nULHeight, nPageSize, nText ;
	COLORREF			colUL ;
	SIZE				sz ;
	WCHAR				bufText [1024] ;
	TEXTREGION			bufAnnot [32] ;
	TEXTREGION*			pbufAnnot ;

	hBrushBg	= (HBRUSH) CreateSolidBrush (GetBkColor (hDC)) ;
	hULBrush	= _GetImeLineBrush (_hwnd, MYCOLOR_TEXTAUTO, MYLINE_THIN_DITHER, &colUL, &hbmUL, &nULHeight) ;
	if (hULBrush)
		hOldBrush	= (HBRUSH) SelectObject (hDC, hULBrush) ;

	pbufAnnot	= (pMyCand->_iPageSize >= ARRAYSIZE (bufAnnot))? NULL : bufAnnot ;
	nPageSize	= (pbufAnnot == NULL)? 0 : pMyCand->_iPageSize ;
	memset (bufAnnot, 0, sizeof (bufAnnot)) ;
	nText		= _GetCandidateText (bufText, ARRAYSIZE (bufText), pbufAnnot, pMyCand) ;
	if (nText > 0) {
		int			nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPCWSTR		pwText ;
		TEXTREGION*	pAnnot ;
		TEXTMETRIC	tm ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= prcDraw->top ;
		pwText		= bufText ;
		nTextPos	= 0 ;

		while (y < prcDraw->bottom && 0 < nText) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= prcDraw->left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
				if ((x + sz.cx) > prcDraw->right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			/* ���̍s�ɂ� nChar �����\������B*/
			TextOutW (hDC, x, y, pwText, nChar) ;
			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
			x	+= sz.cx ;

			/* �܂�Ԃ�������\������B*/
			if (nChar < nText) {
				SIZE	szBackslash ;
				TextOutW (hDC, x, y, L"\\", 1) ;
				GetTextExtentPoint32W (hDC, L"\\", 1, &szBackslash) ;
				x	+= szBackslash.cx ;
			} else {
				RECT	rc ;
				rc.left	= x ;	rc.right	= prcDraw->right ;
				rc.top	= y ;	rc.bottom	= y + nDY ;	
				FillRect (hDC, &rc, hBrushBg) ;
			}

#define	IsTextRegionCrossp(text1,ntext1,text2,ntext2)	(!((((text1)+(ntext1))<=(text2)||(text1)>=((text2)+(ntext2)))))
			for (nAnnot = 0 ; nAnnot < nPageSize ; nAnnot ++) {
				int	nOffset, nLength ;

				pAnnot	= &bufAnnot [nAnnot] ;
				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32W (hDC, pwText, nOffset, &sz) ;
					nAnnotX	= prcDraw->left + sz.cx ;
				} else {
					nAnnotX	= prcDraw->left ;
				}
				GetTextExtentPoint32W (hDC, pwText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				if (hULBrush) 
					PatBlt (hDC, nAnnotX, y + nDY - nULHeight, nAnnotWidth, nULHeight, PATCOPY) ;
			}
			pwText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
		if (y < prcDraw->bottom) {
			RECT	rc ;
			rc.left	= prcDraw->left ;	rc.right	= prcDraw->right ;
			rc.top	= y ;				rc.bottom	= y + nDY ;	
			FillRect (hDC, &rc, hBrushBg) ;
		}
	}

	if (hULBrush) {
		(void) SelectObject (hDC, hOldBrush) ;
		DeleteObject (hULBrush) ;
	}
	if (hBrushBg) 
		DeleteObject (hBrushBg) ;
	if (hbmUL)
		DeleteObject (hbmUL) ;
	return	TRUE ;
}

BOOL
CUIStatus::_PaintCodeList (
	HDC						hDC,
	const IMECANDIDATES*	pMyCand,
	LPRECT					prcDraw)
{
	WCHAR		bufText [1024] ;
	int			nText ;

	if (pMyCand->_iStyle == IMECANDSTYLE_CODE0) {
		nText		= _GetCodeMenuJumpText (bufText, ARRAYSIZE (bufText), pMyCand) ;
	} else {
		nText		= _GetCodeMenu1Text (bufText, ARRAYSIZE (bufText), pMyCand) ;
	}
	if (nText > 0) {
		int			nDY, nDefaultDY, x, y, nChar ;
		LPCWSTR		pwText ;
		TEXTMETRIC	tm ;
		SIZE		sz ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= prcDraw->top ;
		pwText		= bufText ;
		while (y < prcDraw->bottom && 0 < nText) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= prcDraw->left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
				if ((x + sz.cx) > prcDraw->right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			/* ���̍s�ɂ� nChar �����\������B*/
			TextOutW (hDC, x, y, pwText, nChar) ;
			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
			x	+= sz.cx ;

			/* �܂�Ԃ�������\������B*/
			if (nChar < nText) {
				SIZE	szBackslash ;
				TextOutW (hDC, x, y, L"\\", 1) ;
				GetTextExtentPoint32W (hDC, L"\\", 1, &szBackslash) ;
				x	+= szBackslash.cx ;
			}
			pwText		+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
	}
	return	TRUE ;
}

BOOL
CUIStatus::_PaintMinibufferText (
	HDC						hDC,
	const IMECANDIDATES*	pMyCand,
	LPRECT					prcDraw)
{
	CImeDoc*		pDoc ;
//	HBRUSH			hbr ;
	int				nRegionStart, nRegionEnd ;
	int				x, y, nDY, nText, nTextPos ;
	LPCWSTR			pwSText, pText ;
	int				iCursorPos ;
	BOOL			fRegionSelected ;
	TEXTMETRIC		tm ;
	BOOL			bCursorPos ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	FALSE ;
	if (pMyCand == NULL || pMyCand->_iCount != 1 || pMyCand->_iStyle != IMECANDSTYLE_MINIBUFFERTEXT)
		return	FALSE ;

	pwSText	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((int*)pMyCand->_vbufCandidateIndex.GetBuffer () + 0) ;

	iCursorPos		= -1 ;
	fRegionSelected	= FALSE ;
	if (! pDoc->GetStatusCursor (&iCursorPos))
		iCursorPos	= -1 ;
	if (iCursorPos >= 0) {
		fRegionSelected	= pDoc->GetSelectedRegion (&nRegionStart, &nRegionEnd) ;
		if (fRegionSelected) {
			if (nRegionStart > iCursorPos)
				nRegionStart	++ ;
			if (nRegionEnd > iCursorPos)
				nRegionEnd		++ ;
		} else {
			fRegionSelected	= FALSE ;
		}
	}
	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	SetBkMode (hDC, OPAQUE) ;
	//	�F�̑���c�ǂ����悤���Bfocus ���Ă��� Window �̔w�i�F�Ȃ�ĕs�������B
//	SetBkColor (hDC, GetBkColor (hPDC)) ;
//	SetTextColor (hDC, RGB (0, 0, 0)) ;

	pText		= pwSText ;
	nText		= lstrlenW (pwSText) ;
	nTextPos	= 0 ;
	y			= prcDraw->top ;
	x			= prcDraw->left ;
	bCursorPos	= FALSE ;
	while (y < prcDraw->bottom && 0 < nText) {
		int		nChar, iSX ;
		BOOL	bCRLF ;
		SIZE	sz ;

		bCRLF	= FALSE ;
		iSX		= x ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			if ((nTextPos + nChar - 1) == iCursorPos && *(pText + nChar - 1) == L'|') {
				break ;	/* cursor */
			}
			GetTextExtentPoint32W (hDC, pText, nChar, &sz) ;
			if ((x + sz.cx) >= prcDraw->right) {
				bCRLF	= TRUE ;
				break ;
			}
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;

		if (fRegionSelected && !(nRegionEnd <= nTextPos || (nTextPos + nChar) <= nRegionStart)) {
			int	nStart, nEnd ;

			if (nTextPos < nRegionStart) {
				TextOutW (hDC, x, y, pText, nRegionStart - nTextPos) ;
				GetTextExtentPoint32W (hDC, pText, nRegionStart - nTextPos, &sz) ;
				x	+= sz.cx ;
			}
			nStart	= (nRegionStart < nTextPos)? nTextPos : nRegionStart ;
			nEnd	= (nRegionEnd   >= (nTextPos + nChar))? (nTextPos + nChar) : nRegionEnd ;
			if (nStart < nEnd) {
				COLORREF	colBack	= GetBkColor (hDC) ;
				SetBkColor (hDC, RGB (192, 192, 224)) ;
				TextOutW (hDC, x, prcDraw->top, pwSText + nStart, nEnd - nStart) ;
				GetTextExtentPoint32W (hDC, pwSText + nStart, nEnd - nStart, &sz) ;
				SetBkColor (hDC, colBack) ;
				x	+= sz.cx ;
			}
			if (nEnd < (nTextPos + nChar)) {
				TextOutW (hDC, x, prcDraw->top, pwSText + nEnd, nTextPos + nChar - nEnd) ;
				GetTextExtentPoint32W (hDC, pwSText + nEnd, nTextPos + nChar - nEnd, &sz) ;
				x	+= sz.cx ;
			}
		} else {
			/* �e�L�X�g��\������B*/
			TextOutW (hDC, x, y, pText, nChar) ;
			GetTextExtentPoint32W (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
		}

		if (bCRLF) {
			/*	�܂�Ԃ��L����\������B*/
			TextOutW (hDC, x, y, L"\\", 1) ;
			GetTextExtentPoint32W (hDC, L"\\", 1, &sz) ;
			x	+= sz.cx ;
		}
		if (bCRLF || nChar == nText)
			PatBlt (hDC, x, y, prcDraw->right - x, nDY, PATCOPY) ;

		/* �K�v�Ȃ�J�[�\����\������B*/
		/*if (nTextPos <= iCursorPos && iCursorPos <= (nTextPos + nChar)){*/
		if ((nTextPos + nChar) == iCursorPos) {
			/* �J�[�\���̒��O�܂ŕ`�悳��Ă����ԁB*/
			if ((nChar + 1) >= nText) {
				RECT			invRect ;
				GetTextExtentPoint32W (hDC, pText, iCursorPos - nTextPos, &sz) ;
				invRect.left	= iSX + sz.cx ;
				invRect.right	= iSX + sz.cx + UI_CURSORWIDTH ;
				invRect.top		= y ;
				invRect.bottom	= y + nDY ;
				PatBlt (hDC, x, y, prcDraw->right - x, nDY, PATCOPY) ;
				InvertRect (hDC, &invRect) ;
			} else {
				bCursorPos		= TRUE ;
			}
			nChar	++ ;	/* skip: �J�[�\���ʒu�ɑ}������Ă���``|'' */
		} else {
			if (bCursorPos) {
				RECT			invRect ;
				invRect.left	= iSX ;
				invRect.right	= iSX + UI_CURSORWIDTH ;
				invRect.top		= y ;
				invRect.bottom	= y + nDY ;
				InvertRect (hDC, &invRect) ;
				bCursorPos	= FALSE ;
			}
		}
		pText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		if (bCRLF) {
			y		+= nDY ;
			x		= prcDraw->left ;
		}
	}
	return	TRUE ;
}

BOOL
CUIStatus::_TextOut (
	HDC			hdc,
	int			nX,
	int			nY,
	LPCWSTR		wstr, 
	int			nwstr,
	int*		pCursor,
	SIZE*		pSZ)
{
	SIZE	sz ;

	if (nwstr > 0) {
		TextOutW (hdc, nX, nY, wstr, nwstr) ;
		if (pCursor != NULL) {
			GetTextExtentPoint32W (hdc, wstr, *pCursor, &sz) ;
			Rectangle (hdc, nX + sz.cx, nY, nX + sz.cx + 1, nY + sz.cy) ;
		}
	} else {
		if (pCursor != NULL) {
			GetTextExtentPoint32W (hdc, L"|", 1, &sz) ;
			Rectangle (hdc, nX + sz.cx, nY, nX + sz.cx + 1, nY + sz.cy) ;
		}
	}
	if (pSZ != NULL) {
		if (nwstr > 0) {
			GetTextExtentPoint32W (hdc, wstr, nwstr, &sz) ;
			if (pCursor != NULL && *pCursor == nwstr)
				sz.cx	+= 1 ;
			*pSZ	= sz ;
		} else {
			GetTextExtentPoint32W (hdc, L"|", 1, pSZ) ;
			pSZ->cx	= 1 ;
		}
	}
	return	TRUE ;
}

void
CUIStatus::_RelayEventToTooltip (
	HWND		hWnd,
	UINT		uMessage)
{
	MSG				msg ;
	POINT			pt ;

	if (! IsWindow (_hwndTT) || ! GetCursorPos (&pt))
		return ;

	switch (uMessage) {
		case	WM_SETCURSOR:
			{
				msg.hwnd	= hWnd ;
				msg.message	= WM_MOUSEMOVE ;
				msg.pt.x	= pt.x ;
				msg.pt.y	= pt.y ;
				ScreenToClient (hWnd, &pt) ;
				msg.lParam	= pt.y << 16 | pt.x ;
				msg.wParam	= 0 ;
				msg.time	= GetTickCount () ;
				(void) SendMessage (_hwndTT, (UINT) TTM_RELAYEVENT, (WPARAM) 0, (LPARAM) &msg) ;
				break ;
			}
		default:
			break ;
	}
	return ;
}

void
CUIStatus::_Drag (
	UINT		uMessage)
{
#if 0
	CImeDoc*				pDoc	= NULL ;
	HDC						hDC ;
	POINT					pos ;
	int						nNewCursor ;
	register LPCWSTR		wstrTop ;
	int						nwstr, nCursor ;
	BOOL					bCursor ;
	const IMETEXTATTRIBUTE*	pTextAttrs = NULL ;
	int						nTextAttrs = 0 ;

	/*	�}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 *	�ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (uMessage != WM_RBUTTONDOWN && uMessage != WM_RBUTTONUP &&
		uMessage != WM_LBUTTONDOWN && !_bButtonPressed)
		return ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (_hwnd, &pos))
		return ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return ;

	wstrTop	= pDoc->GetStatusText () ;
	if (nwstr <= 0 || wstrTop == NULL) 
		return ;

	/*	Status Window �� Cursor ���ړ����Ă��Ȃ���Ζ�������B
	 */
	bCursor		= pDoc->GetStatusCursor (&nCursor) ;
	if (! bCursor)
		return ;

	hDC		= GetDC (_hwnd) ;
	if (! hDC)
		return ;

	DEBUGPRINTF ((TEXT ("CUIStatus::_Drag (%d)\n"), uMessage)) ;
	if (uMessage != WM_RBUTTONUP && uMessage != WM_RBUTTONDOWN){
		BOOL	bRedraw, bEaten ;

		nNewCursor	= _GetCursorPos (hDC, wstrTop, nwstr, &pos) ;
		/* �̈�I���J�n�ʒu���L������B*/
		switch (uMessage){
		case	WM_LBUTTONDOWN:
			bRedraw	= (nNewCursor != nCursor) ;
			(void) pDoc->FilterKeyEvent (MYVK_LBUTTON, (LPARAM)nNewCursor, &bEaten) ;
#if 0
			ImeDoc_FilterKeyEvent (&lpMyCompStr->_Doc, MYVK_LBUTTON, dwCursor, NULL, &fEaten) ;
			SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
#endif
			if (bRedraw)
				InvalidateRect (_hwnd, NULL, FALSE) ;
			break ;

		case	WM_LBUTTONUP:
			nNewCursor	|= 0x80000000L ;
			/*	fall-through */
		case	WM_MOUSEMOVE:
		case	WM_NCMOUSEMOVE:
			if (_bButtonPressed) {
				bRedraw	= (nNewCursor != nCursor) ;
				(void) pDoc->FilterKeyEvent (MYVK_LBUTTON, (LPARAM)nNewCursor, &bEaten) ;
#if 0
				ImeDoc_FilterKeyEvent (&lpMyCompStr->_Doc, MYVK_LBUTTON, (LPARAM)nNewCursor, NULL, &fEaten) ;
				SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
#endif
				if (bRedraw)
					InvalidateRect (_hwnd, NULL, FALSE) ;
			}
			break ;
		default:
			break ;
		}
	}
	ReleaseDC (_hwnd, hDC) ;

	if (uMessage == WM_LBUTTONDOWN){
		_bButtonPressed	= TRUE ;
		SetCapture (_hwnd) ;
	}
	if (uMessage == WM_LBUTTONUP || uMessage == WM_RBUTTONUP){
		ReleaseCapture () ;
		_bButtonPressed	= FALSE ;
		if (uMessage == WM_RBUTTONUP){
		}
	}
#endif
	return ;
}

int
CUIStatus::_GetCursorPos (
	HDC								hDC,
	LPCWSTR							wstring,
	int								nwstring,
	const POINT*					lppoint)
{
	int				nCursor	= -1 ;
	SIZE			sz ;

	if (nwstring <= 0 || wstring == NULL || lppoint == NULL)
		return	0 ;

	nCursor	= 0 ;
	while (nCursor < nwstring) {
		if (! GetTextExtentPoint32W (hDC, wstring, nCursor + 1, &sz))
			break ;
		if (lppoint->x < sz.cx)
			break ;
		nCursor	++ ;
	}
	return	nCursor ;
}

LRESULT	CALLBACK
CUIStatus::_UIStatusWndProc (
	HWND			hwnd,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	CUIStatus*		pThis ;

	switch (uMsg) {
	case	WM_CREATE:
		SetWindowLongPtr (hwnd, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCT *)lParam)->lpCreateParams) ;
		return	0L ;

	case	WM_SETCURSOR:
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) 
			return	pThis->_OnUIStatusSetCursor (hwnd, uMsg, wParam, lParam) ;
		return	0L ;

	case	WM_TIMER:
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) 
			return	pThis->_OnUIStatusTimer (hwnd, uMsg, wParam, lParam) ;
		return	0L ;

	case	WM_PAINT:
	{
		PAINTSTRUCT	ps ;
		HDC			hdc ;

		hdc		= BeginPaint (hwnd, &ps) ;
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL)
			pThis->_PaintUIStatusWnd (hwnd, hdc) ;
		EndPaint (hwnd, &ps) ;
		return	0L ;
	}

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) 
			return	pThis->_OnUIStatusButtonDown (hwnd, uMsg, wParam, lParam) ;
		return	0L ;

	case WM_MOUSEMOVE:
	case WM_NCMOUSEMOVE:
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) 
			return	pThis->_OnUIStatusMouseMove (hwnd, uMsg, wParam, lParam) ;
		return	0L ;

	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) 
			return	pThis->_OnUIStatusButtonUp (hwnd, uMsg, wParam, lParam) ;
		return	0L ;

	default:
		return	DefWindowProc (hwnd, uMsg, wParam, lParam) ;
	}
}

LRESULT
CUIStatus::_OnUIStatusSetCursor (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	BOOL					bMinibuffered ;

	if (_pIME == NULL)
		return	0L ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	0L ;
	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED)
		return	0L ;

	bMinibuffered	= (pMyCand->_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) ;
	if (bMinibuffered) {
		switch (HIWORD (lParam)) {
		case	WM_LBUTTONDOWN:
		case	WM_RBUTTONDOWN:
			_OnUIStatusButtonDown (hWnd, HIWORD(lParam), 0, 0) ;
			break ;
		case	WM_LBUTTONUP:
		case	WM_RBUTTONUP:
			_OnUIStatusButtonUp (hWnd, HIWORD(lParam), 0, 0) ;
			break ;
		default:
			_OnUIStatusMouseMove (hWnd, WM_MOUSEMOVE, 0, 0) ;
			break ;
		}
	} else {
		/* tooltip �̏����B*/
		if (IsWindow (_hwndTT) && _HideToolTipp ())
			ShowWindow (_hwndTT, SW_HIDE) ;

		if (HIWORD (lParam) != WM_LBUTTONDOWN && HIWORD (lParam) != WM_RBUTTONDOWN) {
			UINT	uHoverTime ;
			if (pDoc->IsSkkShowAnnotationp ()) {
				if (! SystemParametersInfo (SPI_GETMOUSEHOVERTIME, 0, &uHoverTime, 0))
					uHoverTime	= SKKIME_DEFAULT_HOVERTIME ;
				SetTimer (hWnd, TIMEEV_SHOWANNOTATION, uHoverTime, NULL) ;
			}
		}
	}
	return	0L ;
}

LRESULT
CUIStatus::_OnUIStatusTimer (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	KillTimer (hWnd, wParam) ;

	if (_pIME != NULL) {
		CImeDoc*	pDoc	= _pIME->GetDocument () ;

		if (pDoc != NULL && pDoc->IsSkkShowAnnotationp ()) {
			const IMECANDIDATES*	pMyCand	= pDoc->GetStatusText () ;

			if (pMyCand != NULL && pMyCand->_iStyle == IMECANDSTYLE_READ) {
				POINT		pt ;

				GetCursorPos (&pt) ;
				ScreenToClient (hWnd, &pt) ;
				_HitTestAnnotation (hWnd, &pt) ;
			}
		}
	}
	return	0L ;
}

LRESULT
CUIStatus::_OnUIStatusMouseMove (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	POINT					pos ;
	int						nDummy ;

	if (! _bButtonPressed)
		return	0L ;

	if (_pIME == NULL)
		return	0L ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (hWnd, &pos))
		return	0L ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	0L ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle != IMECANDSTYLE_MINIBUFFERTEXT)
		return	0L ;

	if (pDoc->GetStatusCursor (&nDummy)){
	}
	return	0L ;
}

LRESULT
CUIStatus::_OnUIStatusButtonDown (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	POINT					pos ;

	if (_pIME == NULL)
		return	0L ;
	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	0L ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (hWnd, &pos))
		return	0L ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand != NULL && pMyCand->_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		int		nDummy ;

		if (pDoc->GetStatusCursor (&nDummy)) {
			/*	���������B
			 */

			_bButtonPressed	= TRUE ;
			SetCapture (hWnd) ;
		}
	}
	return	0L ;
}

LRESULT
CUIStatus::_OnUIStatusButtonUp (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	POINT					pos ;
	const IMECANDIDATES*	pMyCand ;

	/*
	 * �}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 * �ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (! _bButtonPressed) 
		goto	exit_func ;

	GetCursorPos (&pos) ;
	if (! ScreenToClient (hWnd, &pos))
		goto	exit_func ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		goto	exit_func ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand != NULL && pMyCand->_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		int				nDummy ;

		/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
		if (pDoc->GetStatusCursor (&nDummy)){
			/*	�ށAEditSession ���쐬���Ȃ��Ƃ����Ȃ��̂ł͂Ȃ����낤���H
			 */
		}
	}
exit_func:
	ReleaseCapture () ;	/* ReleaseCapture �����͕K�{�B*/

	if (_bButtonPressed && message == WM_RBUTTONUP){
		_HandleMinibufferContextMenu () ;
	}
	return	0L ;
}


////////////////////////////////////////////////////////////////////////
//	private functions

/*	�e�L�X�g��\������̂ɕK�v�ȗ̈���v�Z����B
 */
void
CUIStatus::_AdjustRect (
	RECT*					prcDest,
	const IMECANDIDATES*	pMyCand,
	const RECT*				prcSrc)
{
	HDC					hdc ;
	HFONT				holdfont ;
	RECT				rcUI, rcWork ;
	int					nWidth, nHeight, nFontHeight, nFontWidth ;
	int					nFrameWidth, nFrameHeight, nDefaultWidth, nDefaultHeight ;
	int					iStyle ;
	TEXTMETRIC			tm ;
	SIZE				sz ;

	memset (&rcUI, 0, sizeof (rcUI)) ;

	/*	��ʑS�̂̃T�C�Y�𓾂�B*/
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, 0) ;

	hdc		= CreateDC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
	if (hdc == NULL) {
		if (prcDest != NULL) {
			prcDest->left	= 0 ;
			prcDest->top	= 0 ;
			prcDest->right	= rcWork.right ;
			prcDest->bottom	= 18 ;
		}
		return ;	// ���̏ꍇ�͌v�Z�s�\�B
	}

	holdfont	= (HFONT) _CheckNativeCharset (hdc) ;
	if (GetTextMetrics (hdc, &tm)) {
		nFontWidth	= tm.tmAveCharWidth ;
		nFontHeight	= tm.tmHeight ;
	} else {
		GetTextExtentPoint32W (hdc, L"��", 1, &sz) ;
		nFontWidth	= (sz.cx + 1) / 2 ;
		nFontHeight	= sz.cy ;
	}
	nFrameWidth		= GetSystemMetrics (SM_CXDLGFRAME) * 2 ;
	nFrameHeight	= GetSystemMetrics (SM_CYDLGFRAME) * 2 ;
	nDefaultWidth	= nFontWidth * DEFAULT_MINIBUF_CHARWIDTH + nFrameWidth ;
	nDefaultWidth	= (nDefaultWidth > rcWork.right)? rcWork.right : nDefaultWidth ;
	nDefaultHeight	= nFontHeight + nFrameHeight ;
	nDefaultHeight	= (nDefaultHeight > rcWork.bottom)? rcWork.bottom : nDefaultHeight ;

	nWidth	= (prcSrc != NULL && nDefaultWidth < (prcSrc->right - prcSrc->left))? (prcSrc->right - prcSrc->left) : nDefaultWidth ;
	nHeight	= 0 ;

	if ((nWidth + nFrameWidth) > (rcWork.right - rcWork.left)) 
		nWidth	= rcWork.right - rcWork.left - nFrameWidth ;
	if (nWidth <= 0) {
		nWidth		= prcSrc->right - prcSrc->left ;
		nHeight		= prcSrc->bottom - prcSrc->top ;
		goto	skip_calc ;
	}

	iStyle	= (pMyCand != NULL)? pMyCand->_iStyle : IMECANDSTYLE_UNUSED ;
	switch (iStyle) {
	case	IMECANDSTYLE_READ:
		{
			WCHAR	bufText [1024] ;
			int		nText ;
			SIZE	sz ;

			nText	= _GetCandidateText (bufText, ARRAYSIZE (bufText), NULL, pMyCand) ;
			if (nText > 0) {
				GetTextExtentPoint32W (hdc, bufText, nText, &sz) ;
				if ((sz.cx + nFrameWidth) > nWidth) {
					int	n	= nWidth - nFrameWidth ;
					nHeight	= (sz.cx + n - 1) / n * sz.cy + nFrameHeight ;
				} else {
					nHeight	= sz.cy + nFrameHeight ;
				}
				nHeight	= (nHeight < nDefaultHeight)? nDefaultHeight : nHeight ;
			} else {
				nHeight	= nDefaultHeight ;
			}
		}
		break ;
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		nHeight	= nDefaultHeight ;
		break ;	

	case	IMECANDSTYLE_MINIBUFFERTEXT:
	default:
		{
			CImeDoc*	pDoc ;
			LPCWSTR		pwSText ;
			int			nSTextLen, iCursorPos ;
			SIZE		sz ;

			if (_pIME == NULL)
				break ;
			pDoc	= _pIME->GetDocument () ;
			if (pDoc == NULL)
				break ;

			if (pMyCand != NULL && pMyCand->_iCount == 1 && iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
				if (! pDoc->GetStatusCursor (&iCursorPos))
					iCursorPos	= -1 ;
				pwSText		= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((int*)pMyCand->_vbufCandidateIndex.GetBuffer () + 0) ;
				nSTextLen	= lstrlenW (pwSText) ;
			} else {
				if (! pDoc->HaveMessagep ()) 
					break ;
				pwSText		= pDoc->GetMessage (&nSTextLen) ;
				iCursorPos	= -1 ;
			}
			/* Minibuffer Text �̏ꍇ�B*/
			if (_GetStatusTextSize (hdc, pwSText, nSTextLen, iCursorPos, nWidth - nFrameWidth, &sz)) {
				nWidth	= sz.cx + nFrameWidth ;
				nHeight	= sz.cy + nFrameHeight ;
			}
		}
		break ;
	}

	/*	�\���ʒu�̒����BMulti-Screen ���l�����āB
	 */
skip_calc:
	{
		POINT	pt, ptOffset, ptBase ;

		pt.x	= prcSrc->left ;
		pt.y	= prcSrc->bottom + 1 ;
		if (rcWork.right > 0) {
			ptOffset.x	= pt.x % rcWork.right ;
			if (ptOffset.x < 0)
				ptOffset.x	= rcWork.right + ptOffset.x ;
			ptBase.x	= pt.x - ptOffset.x ;
			if ((ptOffset.x + nWidth) > rcWork.right){
				ptOffset.x	= rcWork.right - nWidth ;
			if (ptOffset.x < 0)
				ptOffset.x	= 0 ;
			}
			pt.x		= ptBase.x + ptOffset.x ;
		}
		if (rcWork.bottom > 0) {
			ptOffset.y	= pt.y % rcWork.bottom ;
			if (ptOffset.y < 0)
				ptOffset.y	= rcWork.bottom + ptOffset.y ;
			ptBase.y	= pt.y - ptOffset.y ;
			if ((ptOffset.y + nHeight) > rcWork.bottom){
				ptOffset.y = rcWork.bottom - nHeight ;
			}
			if (ptOffset.y < 0)
				ptOffset.y	= 0 ;
			pt.y		= ptBase.y + ptOffset.y ;
		}
		rcUI.left	= pt.x ;
		rcUI.top	= pt.y ;
		rcUI.right	= nWidth ;
		rcUI.bottom	= nHeight ;
	}

	DEBUGPRINTF ((TEXT ("View(l:%d, t:%d, r:%d, b:%d), WorkArea(l:%d, t:%d, r:%d, b:%d), w:%d, h:%d\n"),
				  prcSrc->left, prcSrc->top, prcSrc->right, prcSrc->bottom,
				  rcWork.left, rcWork.top, rcWork.right, rcWork.bottom,
				  nFontWidth, nFontHeight)) ;
exit_func:
	if (prcDest != NULL)
		*prcDest	= rcUI ;
	DeleteObject (SelectObject (hdc, holdfont)) ;
	DeleteDC (hdc) ;
	return ;
}

int
CUIStatus::_GetCandidateText (
	LPWSTR					strDest,
	int						nDest,
	TEXTREGION*				pText,
	const IMECANDIDATES*	pMyCand)
{
	CImeDoc*	pDoc ;
	LPWSTR		pDest ;
	int			i, iCount, nKeys ;
	WCHAR		ch ;
	const BYTE*	pCandKeyTbl ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	0 ;

	pDest		= strDest ;
	iCount		= 0 ;
	i			= pMyCand->_iPageStart ;
	pCandKeyTbl	= pDoc->GetJHenkanShowCandidateKeys (&nKeys) ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPWSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		wcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < (pMyCand->_iPageStart + pMyCand->_iPageSize) && i < pMyCand->_iCount && iCount < nKeys && nDest > 0) {
		LPCWSTR		pwCandidate ;
		int			nIndex, nCandLen ;

		ch			= (WCHAR)*(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((const int*)pMyCand->_vbufCandidateIndex.GetBuffer () + i) ;
		nCandLen	= lstrlenW (pwCandidate) ;
		nIndex		= _HasWordAnnotation (pwCandidate, nCandLen) ;
		if (nIndex > 0) 
			nCandLen	= nIndex ;

		/*	���� annotation �����݂���ꍇ�B*/
		if (pText != NULL) {
			if (nDest > 0 && nIndex > 0) {
				pText->m_nCandidate	= i ;
				pText->m_nOffset	= pDest - strDest ;
				pText->m_nLength	= (nDest < nCandLen)? nDest : nCandLen ;
			} else {
				pText->m_nCandidate	= 0 ;
				pText->m_nOffset	= 0 ;
				pText->m_nLength	= 0 ;
			}
			pText	++ ;
		}
		SAFE_COPY (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
	if (nDest > 0) {
		WCHAR	buffer [32] ;
		int		n ;
		n	= wnsprintfW (buffer, ARRAYSIZE (buffer), L" [�c�� %d]", pMyCand->_iCount - i) ;
		SAFE_COPY (pDest, nDest, buffer, n) ;
	}
#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

int
CUIStatus::_GetCodeMenuJumpText (
	LPWSTR					strDest,
	int						nDest,
	const IMECANDIDATES*	pMyCand)
{
	CImeDoc*	pDoc ;
	LPWSTR		pDest ;
	int			i, iCount, nKeys ;
	WCHAR		ch ;
	const BYTE*	pCandKeyTbl ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	0 ;

	pDest		= strDest ;
	iCount		= 0 ;
	i			= pMyCand->_iPageStart ;
	pCandKeyTbl	= pDoc->GetJInputByCodeOrMenuKeys1 (&nKeys) ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPWSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		wcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < (pMyCand->_iPageStart + pMyCand->_iPageSize) && i < pMyCand->_iCount && iCount < nKeys && nDest > 0) {
		LPCWSTR		pwCandidate ;
		int			nCandLen ;

		ch			= (WCHAR)*(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((const int*)pMyCand->_vbufCandidateIndex.GetBuffer () + i) ;
		nCandLen	= lstrlenW (pwCandidate) ;

		SAFE_COPY (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

int
CUIStatus::_GetCodeMenu1Text (
	LPWSTR					strDest,
	int						nDest,
	const IMECANDIDATES*	pMyCand)
{
	CImeDoc*	pDoc ;
	LPWSTR		pDest ;
	int			i, iCount, nKeys ;
	WCHAR		ch ;
	const BYTE*	pCandKeyTbl ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	0 ;

	pDest		= strDest ;
	iCount		= 0 ;
	i			= pMyCand->_iPageStart ;
	pCandKeyTbl	= pDoc->GetJInputByCodeOrMenuKeys2 (&nKeys) ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPWSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		wcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < (pMyCand->_iPageStart + pMyCand->_iPageSize) && i < pMyCand->_iCount && iCount < nKeys && nDest > 0) {
		LPCWSTR		pwCandidate ;
		int			nCandLen ;

		ch			= (WCHAR)*(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((const int*)pMyCand->_vbufCandidateIndex.GetBuffer () + i) ;
		nCandLen	= lstrlenW (pwCandidate) ;

		SAFE_COPY (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

BOOL
CUIStatus::_GetStatusTextSize (
	HDC						hDC,
	LPCWSTR					pwSText,
	int						nSTextLen,
	int						iCursorPos,
	int						nDefaultWidth,
	SIZE*					pSZ)
{
	/*	Key 1 �ɕt�� ``X:'' ��2�����ASeparator �̋󔒂� 1 �����A
	 *	���̕\���� 1 �` 2 �����A
	 *	����āANELEMENTS (pCandidateKey) * (2 + 1 + 1) �܂��� (2 + 1 + 2)
	 *	���������B
	 */
	RECT			rc ;
	int				x, y, nDY ;
	TEXTMETRIC		tm ;
	BOOL			bCalculate ;
	int				iCalculateCount ;

	rc.left			= 0 ;
	rc.top			= 0 ;
	rc.right		= nDefaultWidth ;
	iCalculateCount	= 3 ;

	/* Minibuffer Window �̑傫���𓾂�B*/
	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	do {
		LPCWSTR		pText ;
		int			nText, nTextPos ;
		BOOL		bCursorPos ;

		pText		= pwSText ;
		nText		= nSTextLen ;
		nTextPos	= 0 ;
		y			= rc.top ;
		x			= rc.left ;
		bCursorPos	= FALSE ;
		bCalculate	= FALSE ;
		while (0 < nText) {
			int		nChar, iSX ;
			BOOL	bCRLF ;
			SIZE	sz ;

			bCRLF	= FALSE ;
			iSX		= x ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				if ((nTextPos + nChar - 1) == iCursorPos && *(pText + nChar - 1) == L'|') {
					break ;	/* cursor */
				}
				GetTextExtentPointW (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) >= rc.right) {
					if (nChar == 1 && x == rc.left) {
						/*	width ��ύX���čŏ�����B
						 *	�������A�������[�v�ɓ���Ȃ��悤�ɍő�v�Z�񐔂�
						 *	�ݒ肵�Ă����B
						 */
						rc.right	= rc.left + sz.cx + 1 ;
						if (iCalculateCount <= 0)
							return	FALSE ;
						bCalculate	= TRUE ;
						iCalculateCount	-- ;
					}
					bCRLF	= TRUE ;
					break ;
				}
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;
			/* �e�L�X�g��\������B*/
			GetTextExtentPointW (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
			if (bCRLF) {
				/*	�܂�Ԃ��L����\������B*/
				GetTextExtentPointW (hDC, L"\\", 1, &sz) ;
				x	+= sz.cx ;
			}

			/* �K�v�Ȃ�J�[�\����\������B*/
			/*if (nTextPos <= iCursorPos && iCursorPos <= (nTextPos + nChar)){*/
			if ((nTextPos + nChar) == iCursorPos) {
				/* �J�[�\���̒��O�܂ŕ`�悳��Ă����ԁB*/
				if ((nChar + 1) >= nText) {
				} else {
					bCursorPos		= TRUE ;
				}
				nChar	++ ;	/* skip: �J�[�\���ʒu�ɑ}������Ă���``|'' */
			} else {
				if (bCursorPos) {
					bCursorPos	= FALSE ;
				}
			}
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			if (bCRLF) {
				y		+= nDY ;
				x		= rc.left ;
			}
		}
	}	while (bCalculate) ;

	if (pSZ != NULL) {
		pSZ->cx	= (y > rc.top || iCursorPos != -1)? rc.right : x ;
		pSZ->cy	= y + nDY ;
	}
	return	TRUE ;
}

void
CUIStatus::_HitTestAnnotation (
	HWND			hWnd,
	const POINT*	pPT)
{
	int		nTool ;
	
	if (_hwndTT == NULL || ! IsWindow (_hwndTT))
		return ;

	for (nTool = 0 ; nTool < _ToolTipInfo._nCount ; nTool ++) {
		if (_ToolTipInfo._rrcHitArea [nTool].left <= pPT->x && pPT->x < _ToolTipInfo._rrcHitArea [nTool].right &&
			_ToolTipInfo._rrcHitArea [nTool].top  <= pPT->y && pPT->y < _ToolTipInfo._rrcHitArea [nTool].bottom) {
			POINT	pt ;
			RECT	rc ;
			/* hit */
			pt.x	= pPT->x ;
			pt.y	= pPT->y ;
			ClientToScreen (hWnd, &pt) ;
			_ToolTipInfo._ptLastPos.x	= pt.x ;
			_ToolTipInfo._ptLastPos.y	= pt.y ;
			if (! GetWindowRect (hWnd, &rc))
				rc.bottom	= pt.y + GetSystemMetrics (SM_CYCURSOR) / 2 ;
			MoveWindow (_hwndTT, pt.x, rc.bottom, 1, 1, TRUE) ;
			SetWindowTextW (_hwndTT, _ToolTipInfo._bufText + _ToolTipInfo._rnOffsets [nTool]) ;
			ShowWindow (_hwndTT, SW_SHOWNOACTIVATE) ;
			break ;
		}
	}
	return ;
}

BOOL
CUIStatus::_HideToolTipp ()
{
	POINT		pt ;
	GetCursorPos (&pt) ;
	if (pt.x == _ToolTipInfo._ptLastPos.x && pt.y == _ToolTipInfo._ptLastPos.y)
		return	FALSE ;
	return	TRUE ;
}

BOOL
CUIStatus::_ConfigureAnnotation ()
{
	CImeDoc*				pDoc		= NULL ;
	const IMECANDIDATES*	pMyCand		= NULL ;
	HFONT					hOldFont	= NULL ;
	HDC						hDC			= NULL ;
	RECT					rcDraw ;
	int						nPageSize, nText ;
	SIZE					sz ;
	WCHAR					bufText [1024] ;
	TEXTREGION				bufAnnot [32] ;
	TEXTREGION*				pbufAnnot ;
	MYTOOLTIPINFO*			pToolTipInfo ;
	BOOL					bRetval		= FALSE ;

	if (_hwnd == NULL || ! IsWindow (_hwnd) || _hwndTT == NULL || ! IsWindow (_hwndTT))
		return	FALSE ;
	ShowWindow (_hwndTT, SW_HIDE) ;

	pDoc		= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	FALSE ;
	pMyCand		= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle != IMECANDSTYLE_READ)
		return	FALSE ;

	hDC			= GetDC (_hwnd) ;
	if (!hDC)
		return	FALSE ;

	hOldFont	= _CheckNativeCharset (hDC) ;
	GetClientRect (_hwnd, &rcDraw) ;

	/*	TOOL ��ǉ�����B*/
	pbufAnnot	= (pMyCand->_iPageSize >= NELEMENTS (bufAnnot))? NULL : bufAnnot ;
	nPageSize	= (pbufAnnot == NULL)? 0 : pMyCand->_iPageSize ;

	pToolTipInfo	= &_ToolTipInfo ;

	memset (bufAnnot, 0, sizeof (bufAnnot)) ;
	nText		= _GetCandidateText (bufText, NELEMENTS (bufText), pbufAnnot, pMyCand) ;
	if (nText > 0) {
		int			nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPCWSTR		pwText ;
		TEXTREGION*	pAnnot ;
		TEXTMETRIC	tm ;
		int			nTool, nLeft ;
		WCHAR*		pwDest ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= rcDraw.top ;
		pwText		= bufText ;
		nTextPos	= 0 ;
		nTool		= 0 ;
		pwDest		= pToolTipInfo->_bufText ;
		nLeft		= NBUFFER_ANNOTATION_TEXT ;

		while (y < rcDraw.bottom && 0 < nText && nLeft > 0 && nTool < MAX_ANNOTATIONS) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= rcDraw.left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
				if ((x + sz.cx) > rcDraw.right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;

			/* ���̍s�� hit ����BTEXTREGION �𗘗p����B*/
			for (nAnnot = 0 ; nAnnot < nPageSize && nLeft > 0 && nTool < MAX_ANNOTATIONS ; nAnnot ++) {
				LPCWSTR		lpstr ;
				int			nOffset, nLength, nIndex, nCandLen ;

				pAnnot	= &bufAnnot [nAnnot] ;
				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32W (hDC, pwText, nOffset, &sz) ;
					nAnnotX	= rcDraw.left + sz.cx ;
				} else {
					nAnnotX	= rcDraw.left ;
				}
				GetTextExtentPoint32W (hDC, pwText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				/* �O�̂��߂Ɍ�₪���݂��邩�`�F�b�N����B*/
				if (pAnnot->m_nCandidate >= pMyCand->_iCount)
					continue ;

				lpstr		= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *((int*)pMyCand->_vbufCandidateIndex.GetBuffer () + pAnnot->m_nCandidate) ;
				nCandLen	= lstrlenW (lpstr) ;
				nIndex		= _HasWordAnnotation (lpstr, nCandLen) ;
				if (nIndex <= 0 || (nIndex + 1) >= nCandLen) {
					/* �����ρB*/
					continue ;
				}

				/*	(nAnnotX, y) - (nAnnotX + nAnnotWidth, y + nDY)
				 */
				pToolTipInfo->_rrcHitArea [nTool].left		= nAnnotX ;
				pToolTipInfo->_rrcHitArea [nTool].right		= nAnnotX + nAnnotWidth ;
				pToolTipInfo->_rrcHitArea [nTool].top		= y ;
				pToolTipInfo->_rrcHitArea [nTool].bottom	= y + nDY ;
				pToolTipInfo->_rnOffsets [nTool]			= pwDest - pToolTipInfo->_bufText ;

				nLength		= lstrlenW (lpstr + nIndex + 1) ;
				nLength		= (nLength > nLeft)? (nLeft - 1) : nLength ;
				if (nLength > 0) {
					wcsncpy (pwDest, lpstr + nIndex + 1, nLength) ;
					pwDest [nLength]	= L'\0' ;
				}
				pToolTipInfo->_rnLengths [nTool]			= nLength ;
				pwDest			+= nLength + 1 ;
				nTool			++ ;
			}
			x			+= sz.cx ;
			pwText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
		pToolTipInfo->_nCount	= nTool ;
	} else {
		pToolTipInfo->_nCount	= 0 ;
	}
	bRetval	= TRUE ;

	if (hDC != NULL) {
		if (hOldFont) 
			DeleteObject (SelectObject (hDC, hOldFont)) ;
		ReleaseDC (_hwnd, hDC) ;
	}
	return	bRetval ;
}

BOOL	
CUIStatus::_HandleMinibufferContextMenu ()
{
	int				nCmd ;
	unsigned int		uVK ;

	nCmd	= _PopupMinibufferContextMenu () ;
	switch (nCmd){
	case	IDM_CUT:
		uVK	= MYVK_MENU1 ;
		break ;
	case	IDM_PASTE:
		uVK	= MYVK_MENU2 ;
		break ;
	case	IDM_COPY:
		uVK	= MYVK_MENU3 ;
		break ;
	case	IDM_DELETE:
		uVK	= MYVK_MENU4 ;
		break ;
	default:
		uVK	= 0 ;
		break ;
	}
	if (uVK != 0) {
	}
	return	TRUE ;
}

int	
CUIStatus::_PopupMinibufferContextMenu ()
{
	HMENU		hMenu ;
	int			nCmd ;
	POINT		pos ;
	HCURSOR		hCursor ;

	hMenu		= 0 ;
	nCmd		= -1 ;
	GetCursorPos ((LPPOINT)&pos) ;

	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	hMenu	= _CreateClipboardMenu () ;
	if (hMenu){
		/* ���j���[��\�����āA�I��������B*/
		hCursor	= SetCursor (LoadCursor (NULL, IDC_ARROW)) ;
		nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, pos.x, pos.y, 0, _hwnd, NULL) ;
		DestroyMenu (hMenu) ;
		(void)SetCursor (hCursor) ;
	}
	return	nCmd ;
}

HMENU
CUIStatus::_CreateClipboardMenu ()
{
	static	MYMENUITEMINFO	myClipboardMenuItemInfoTbl []	= {
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_CUT,	TEXT ("�؂���"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_PASTE,	TEXT ("�\��t��"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_COPY,	TEXT ("�R�s�["), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_DELETE,	TEXT ("�폜"), },
	  { MIIM_TYPE,							MFT_SEPARATOR,	0,			NULL, },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDCANCEL,	TEXT ("�L�����Z��"), },
	} ;
	CImeDoc*				pDoc ;
	HMENU					hMenu ;
	MYMENUITEMINFO*			lpMyMenu ;
	MENUITEMINFO			menuItemInfo ;
	int						i, nStartPos, nEndPos ;
	BOOL					f ;

	if (_pIME == NULL) 
		return	0 ;

	pDoc		= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	0 ;

	hMenu		= CreatePopupMenu () ;
	if (!hMenu)
		return	0 ;
	/* �܂����j���[�̍��ڂ�ݒ肷��B*/
	lpMyMenu	= myClipboardMenuItemInfoTbl ;
	for (i = 0 ; i < NELEMENTS (myClipboardMenuItemInfoTbl) ; i ++){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= lpMyMenu->m_fMask ;
		menuItemInfo.fType			= lpMyMenu->m_fType ;
		menuItemInfo.wID			= lpMyMenu->m_wID ;
		menuItemInfo.fState			= MFS_ENABLED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		//menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= lpMyMenu->m_dwTypeData ;
		menuItemInfo.cch			= lstrlen (menuItemInfo.dwTypeData) ;
		InsertMenuItem (hMenu, i, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		lpMyMenu	++ ;
	}
	/* �̈�I�����L���ł��邩�ǂ����𔻒肷��B*/
	f			= pDoc->GetSelectedRegion (&nStartPos, &nEndPos) ;
	if (!f || nStartPos == nEndPos) {
		EnableMenuItem (hMenu, 0, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 2, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 3, MF_BYPOSITION | MF_GRAYED) ;
	}
	/* �N���b�v�{�[�h�Ƀe�L�X�g�����݂��邩�ǂ����`�F�b�N����B*/
	if (!IsClipboardFormatAvailable (CF_TEXT))
		EnableMenuItem (hMenu, 1, MF_BYPOSITION | MF_GRAYED) ;
	return	hMenu ;
}

////////////////////////////////////////////////////////////////////////
//	private functions

#define	FIGWL_MOUSE		0

LRESULT	CALLBACK
CUIStatus::_UIToolTipWndProc (
	HWND			hwnd,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	CUIStatus*		pThis ;

	switch (uMsg) {
	case	WM_CREATE:
		SetWindowLongPtr (hwnd, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCT *)lParam)->lpCreateParams) ;
		SetWindowLong    (hwnd, FIGWL_MOUSE, 0L) ;
		return	0L ;

	case	WM_SETCURSOR:
	{
		DWORD	dwMouse	= (DWORD) GetWindowLong (hwnd, FIGWL_MOUSE) ;
		POINT	ptCursor ;

		GetCursorPos (&ptCursor) ;
		if (LOWORD (dwMouse)  != ptCursor.x || HIWORD (dwMouse) != ptCursor.y)
			ShowWindow (hwnd, SW_HIDE) ;
		SetWindowLong (hwnd, FIGWL_MOUSE, ((DWORD)ptCursor.y << 16) | (WORD)ptCursor.x) ;
		return	0L ;
	}

	case	WM_SETTEXT:
	{
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) {
			const TCHAR*	strText	= (const TCHAR*) lParam ;
			int		nText	= 0 ;

			if (strText != NULL && *strText != L'\0') {
				nText	= lstrlen (strText) ;
				lstrcpyn (pThis->_bufToolTip, strText, NELEMENTS (pThis->_bufToolTip)) ;
			} else {
				pThis->_bufToolTip [0]	= TEXT ('\0') ;
				return	0L ;
			}

			/*	Resize Window */
			if (nText > 0) {
				HDC		hDC ;
				SIZE	sz ;
				RECT	rc ;
				POINT	ptCursor ;

				hDC		= GetDC (hwnd) ;
				sz.cx = sz.cy	= 0 ;
				if (hDC != NULL) {
					if (GetTextExtentPoint32 (hDC, strText, nText, &sz)) {
						sz.cx	+= GetSystemMetrics (SM_CXBORDER) * 2 ;
						sz.cy	+= GetSystemMetrics (SM_CYBORDER) * 2 ;
					}
					ReleaseDC (hwnd, hDC) ;
				}
				if (! GetWindowRect (hwnd, &rc))
					rc.left = rc.top = 0 ;

				GetCursorPos (&ptCursor) ;
				SetWindowLong (hwnd, FIGWL_MOUSE, ((DWORD)ptCursor.y << 16) | (WORD)ptCursor.x) ;
				MoveWindow (hwnd, rc.left, rc.top, sz.cx, sz.cy, TRUE) ;
			} else {
				ShowWindow (hwnd, SW_HIDE) ;
			}
		}
		return	0L ;
	}

	case	WM_PAINT:
	{
		PAINTSTRUCT	ps ;
		HDC			hDC ;

		hDC		= BeginPaint (hwnd, &ps) ;
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) {
			TextOut (hDC, 0, 0, pThis->_bufToolTip, lstrlen (pThis->_bufToolTip)) ;
		}
		EndPaint (hwnd, &ps) ;
		return	0L ;
	}

	default:
		return	DefWindowProc (hwnd, uMsg, wParam, lParam) ;
	}
}

BOOL
CUIStatus::_ShowBalloonTip (
	const RECT*		pRect)
{
	CImeDoc*	pDoc ;
	const IMECANDIDATES*	pMyCand ;
	BOOL		bNeedShow, bNeedCandWnd ;
	LPCWSTR		pwText ;
	int			iTextLen ;
	WCHAR		bufText [256] ;
	POINT		pt ;
//	RECT		rc ;

	if (_hwndTT == NULL || ! IsWindow (_hwndTT))
		return	FALSE ;

	/*	minibuffer mode �� message �����݂���Aor
	 *	���ꗗ�\�� mode �� message �����݂���ꍇ�̏����B
	 */
	if (_pIME == NULL)
		return	FALSE ;
	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	FALSE ;

	pMyCand			= pDoc->GetStatusText () ;
	bNeedCandWnd	= (pMyCand != NULL && pMyCand->_iStyle != IMECANDSTYLE_UNUSED) ;
	bNeedShow		= pDoc->HaveMessagep () ;
	if (! bNeedShow) {
		ShowWindow (_hwndTT, SW_HIDE) ;
		return	TRUE ;
	}

	pwText		= pDoc->GetMessage (&iTextLen) ;
	if (iTextLen <= 0) {
		ShowWindow (_hwndTT, SW_HIDE) ;
		return	TRUE ;
	}
	if (iTextLen >= NELEMENTS (bufText)) {
		wcsncpy (bufText, pwText, (NELEMENTS (bufText) - 4)) ;
		bufText [NELEMENTS (bufText) - 4]	= L'.' ;
		bufText [NELEMENTS (bufText) - 3]	= L'.' ;
		bufText [NELEMENTS (bufText) - 2]	= L'.' ;
		bufText [NELEMENTS (bufText) - 1]	= L'\0' ;
	} else {
		wcsncpy (bufText, pwText, iTextLen) ;
		bufText [iTextLen]	= L'\0' ;
	}
	GetCursorPos (&pt) ;
	_ToolTipInfo._ptLastPos.x	= pt.x ; 
	_ToolTipInfo._ptLastPos.y	= pt.y ; 

//	GetWindowRect (_hwnd, &rc) ;
	if (bNeedCandWnd) {
		/* Window �̏ꏊ�́E�E�E */
		MoveWindow (_hwndTT, pRect->left, pRect->top + pRect->bottom, 1, 1, TRUE) ;
	} else {
		MoveWindow (_hwndTT, pRect->left, pRect->top, 1, 1, TRUE) ;
	}
	/* SetWindowText �ŃT�C�Y�̒����������B*/
	SetWindowTextW (_hwndTT, bufText) ;
	ShowWindow (_hwndTT, SW_SHOWNOACTIVATE) ;
	return	TRUE ;
}

int	
_HasWordAnnotation (
	LPCWSTR			pWord,
	int				nWord)
{
	LPCWSTR		ptr ;

	if (pWord == NULL || nWord <= 0)
		return	-1 ;

	ptr	= pWord ;
	while (nWord > 0 && *ptr != L'\0') {
		if (*ptr == L';')
			return	(ptr - pWord) ;
		nWord	-- ;
		ptr		++ ;
	}
	return	-1 ;	/* Not found */
}

////////////////////////////////////////////////////////////////////////
//	private functions

static	int		srnMyColorIndex2SysColorIndexTbl []	= {
	COLOR_BTNFACE,
	COLOR_BTNTEXT,
	COLOR_ACTIVEBORDER,
	COLOR_ACTIVECAPTION,
	COLOR_CAPTIONTEXT,
	COLOR_APPWORKSPACE,
	COLOR_WINDOW,
	COLOR_WINDOWTEXT,
	COLOR_DESKTOP,
	COLOR_INFOBK,
	COLOR_INFOTEXT,
	COLOR_WINDOWTEXT,
	COLOR_MENU,
	COLOR_MENUTEXT,
	COLOR_HIGHLIGHTTEXT,
	COLOR_HIGHLIGHT,
	COLOR_INACTIVEBORDER,
	COLOR_INACTIVECAPTION,
	COLOR_INACTIVECAPTIONTEXT,
} ;

/*	�_���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDottedBrush [8]	= {
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
} ;

/*	�f�B�U���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDitherBrush [8]	= {
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
} ;


HFONT
_CheckNativeCharset (
	register HDC	hDC) 
{
	register BOOL		bDiffCharSet	= FALSE ;
	register HFONT		hOldFont ;
	LOGFONT	lfFont ;

	hOldFont	= (HFONT) GetCurrentObject (hDC, OBJ_FONT) ;
	GetObject (hOldFont, sizeof(LOGFONT), &lfFont) ;

	if (lfFont.lfCharSet != SHIFTJIS_CHARSET/*NATIVE_CHARSET*/) {
		bDiffCharSet			= TRUE ;
		lfFont.lfWeight			= FW_NORMAL ;
		lfFont.lfCharSet		= SHIFTJIS_CHARSET ; //NATIVE_CHARSET
		lfFont.lfFaceName[0]	= TEXT ('\0') ;
		SelectObject (hDC, CreateFontIndirect (&lfFont)) ;
	} else {
		hOldFont				= NULL ;
	}
	return	hOldFont ;
}

COLORREF
_GetImeColor (
	HWND	hwnd,
	int	nColor)
{
	HDC		hdc ;
	COLORREF	col ;

	switch (nColor) {
	case	MYCOLOR_TEXTAUTO:
	case	MYCOLOR_BACKAUTO:
		hdc	= GetDC (hwnd) ;
		col	= GetBkColor (hdc) ;
		ReleaseDC (hwnd, hdc) ;
		return	(nColor == MYCOLOR_BACKAUTO)? col : ~col ;
	case	MYCOLOR_BLACK:
		return	PALETTERGB (  0,   0,   0) ;
	case	MYCOLOR_DARKRED:
		return	PALETTERGB (128,   0,   0) ;
	case	MYCOLOR_DARKGREEN:
		return	PALETTERGB (  0, 128,   0) ;
	case	MYCOLOR_DARKYELLOW:
		return	PALETTERGB (128, 128,   0) ;
	case	MYCOLOR_DARKBLUE:
		return	PALETTERGB (  0,   0, 128) ;
	case	MYCOLOR_DARKPURPLE:
		return	PALETTERGB (128,   0, 128) ;
	case	MYCOLOR_DARKLIGHTBLUE:
		return	PALETTERGB (0,   128, 128) ;
	case	MYCOLOR_DARKGRAY:
		return	PALETTERGB (128, 128, 128) ;
	case	MYCOLOR_LIGHTGRAY:
		return	PALETTERGB (192, 192, 192) ;
	case	MYCOLOR_RED:
		return	PALETTERGB (255,   0,   0) ;
	case	MYCOLOR_GREEN:
		return	PALETTERGB (  0, 255,   0) ;
	case	MYCOLOR_YELLOW:
		return	PALETTERGB (255, 255,   0) ;
	case	MYCOLOR_BLUE:
		return	PALETTERGB (  0,   0, 255) ;
	case	MYCOLOR_PURPLE:
		return	PALETTERGB (255,   0, 255) ;
	case	MYCOLOR_LIGHTBLUE:
		return	PALETTERGB (  0, 255, 255) ;
	case	MYCOLOR_WHITE:
		return	PALETTERGB (255, 255, 255) ;
	default:
		if (MYCOLOR_SYSTEM <= nColor && nColor < MAX_MYCOLOR) {
			nColor	-= MYCOLOR_SYSTEM ;
			return	GetSysColor (srnMyColorIndex2SysColorIndexTbl [nColor]) ;
		}
		break ;
	}
	return	PALETTERGB (0, 0, 0) ;
}

HBRUSH
_GetImeLineBrush (
	HWND				hwnd,		/* [in] */
	int					nLineColor,	/* [in] */
	int					nLineType,	/* [in] */
	COLORREF*			pColBrush,	/* [out] */
	HBITMAP*			phBm,		/* [out] */
	int*				pnWidth)	/* [out] */
{
	COLORREF	colBrush ;
	HBRUSH		hBrush	= NULL ;
	HBITMAP	hBitmap	= NULL ;

	if (pColBrush == NULL || phBm == NULL || pnWidth == NULL) {
		return	NULL ;
	}

	colBrush	= _GetImeColor (hwnd, nLineColor) ;
	switch (nLineType) {
	case	MYLINE_SOLID:
		*pnWidth	= 1 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_DOTTED:
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDottedBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		*pnWidth	= 1 ;
		break ;
	case	MYLINE_THICK_SOLID:
		*pnWidth	= 2 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_THIN_DITHER:
		*pnWidth	= 2 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_THICK_DITHER:
		*pnWidth	= 3 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_NO:
	default:
		*pnWidth	= 0 ;
		break ;
	}
	*pColBrush	= colBrush ;
	*phBm		= hBitmap ;
	return	hBrush ;
}

