#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "CandListUI.h"
#include "ToolTipUI.h"

BOOL
CSkkImeTextService::_InitUIElements (DWORD dwFlags)
{
	if (_pCandidateListUIElement == NULL) {
		_pCandidateListUIElement	= new CSkkImeCandidateListUIElement (this) ;
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
		if (_pCandidateListUIElement != NULL)
			_pCandidateListUIElement->_Init ((dwFlags & TF_TMAE_CONSOLE) != 0) ;
#else
		if (_pCandidateListUIElement != NULL)
			_pCandidateListUIElement->_Init (FALSE) ;
#endif
	}
	if (_pToolTipUIElement == NULL) {
		_pToolTipUIElement			= new CSkkImeToolTipUIElement (this) ;
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
		if (_pToolTipUIElement != NULL)
			_pToolTipUIElement->_Init ((dwFlags & TF_TMAE_CONSOLE) != 0) ;
#else
		if (_pToolTipUIElement != NULL)
			_pToolTipUIElement->_Init (FALSE) ;
#endif
	}
	return	TRUE ;
}

void
CSkkImeTextService::_UninitUIElements ()
{
	if (_pCandidateListUIElement != NULL) {
		_pCandidateListUIElement->_Uninit () ;
		_pCandidateListUIElement->Release () ;
		_pCandidateListUIElement	= NULL ;
	}
	if (_pToolTipUIElement != NULL) {
		_pToolTipUIElement->_Uninit () ;
		_pToolTipUIElement->Release () ;
		_pToolTipUIElement	= NULL ;
	}
	return ;
}

HRESULT
CSkkImeTextService::_BeginToolTipUI (
	DWORD*				pdwToolTipId,
	BOOL*				pbShow)
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	DEBUGPRINTF ((TEXT ("[enter] CSkkImeTextService::_BeginToolTipUI ()\n"))) ;
	if (_pThreadMgr == NULL || _pToolTipUIElement == NULL) {
		DEBUGPRINTF ((TEXT ("[leave] CSkkImeTextService::_BeginToolTipUI () failed.\n"))) ;
		return	E_FAIL ;
	}
	hr	= _pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr)) {
		DEBUGPRINTF ((TEXT ("[leave] CSkkImeTextService::_BeginToolTipUI () failed (hr:0x%0x).\n"), hr)) ;
		return	hr ;
	}
	hr	= pUIElementMgr->BeginUIElement (_pToolTipUIElement, pbShow, pdwToolTipId) ;
	pUIElementMgr->Release () ;
	DEBUGPRINTF ((TEXT ("[leave] CSkkImeTextService::_BeginToolTipUI ()\n"))) ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_EndToolTipUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (_pThreadMgr == NULL || _pToolTipUIElement == NULL)
		return	E_FAIL ;
	if (! _pToolTipUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= _pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->EndUIElement (_pToolTipUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_UpdateToolTipUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (_pThreadMgr == NULL || _pToolTipUIElement == NULL)
		return	E_FAIL ;
	if (! _pToolTipUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= _pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->UpdateUIElement (_pToolTipUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_BeginCandidateListUI (
	DWORD*				pdwToolTipId,
	BOOL*				pbShow)
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (_pThreadMgr == NULL || _pCandidateListUIElement == NULL)
		return	E_FAIL ;
	hr	= _pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;
	hr	= pUIElementMgr->BeginUIElement (_pCandidateListUIElement, pbShow, pdwToolTipId) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_EndCandidateListUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (_pThreadMgr == NULL || _pCandidateListUIElement == NULL)
		return	E_FAIL ;
	if (! _pCandidateListUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= _pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->EndUIElement (_pCandidateListUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_UpdateCandidateListUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (_pThreadMgr == NULL || _pCandidateListUIElement == NULL)
		return	E_FAIL ;
	if (! _pCandidateListUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= _pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->UpdateUIElement (_pCandidateListUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

CSkkImeToolTipUIElement*
CSkkImeTextService::_GetToolTipUI () 
{
	return	_pToolTipUIElement ;
}

CSkkImeCandidateListUIElement*
CSkkImeTextService::_GetCandidateListUI () 
{
	return	_pCandidateListUIElement ;
}

