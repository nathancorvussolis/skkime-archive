/*	langbar.cpp
 *
 *	Language bar ui code
 */
#include "globals.h"
#include "skimic.h"
#include "resource.h"
#include "confcommon.h"

#define LANGBAR_ITEM_DESC	L"���͕���"	// max 32 chars! �ށA�ő�32�����������B
#define	SKKIME_LANGBARITEMSINK_COOKIE	0x0fab0fad

typedef struct {
	const WCHAR*	pchDesc ;
	DWORD			(*pfnGetFlag)(CSkkImeTextService* _this) ;
	void			(*pfnHandler)(CSkkImeTextService* _this) ;
}	TSFLBMENUINFO ;

static	const TSFLBMENUINFO	c_rgMenuItems []	= {
	{ L"�w���v(&H)",
	  NULL,
	  CSkkImeTextService::_Menu_Help },
	{ L"�v���p�e�B(&R)",
	  NULL,
	  CSkkImeTextService::_Menu_Property },
	{ L"�ĕϊ�(&C)",
	  CSkkImeTextService::_Menu_GetNormalFlag,
	  CSkkImeTextService::_Menu_Reconversion },
	{ NULL,
	  NULL,
	  NULL },
	{ L"�L�[�{�[�h�̕\��/��\��",
	  CSkkImeTextService::_Menu_GetToggleKeyboardFlag,
	  CSkkImeTextService::_Menu_ToggleShowKeyboard },
	{ NULL,
	  NULL,
	  NULL },
	{ L"�L�����Z��",
	  NULL,	
	  NULL }
} ;

// {68D148D7-E134-45ef-B596-C5EE7915F819}
static	const GUID	c_guidImeItemButtonIME	= {
	0x68d148d7, 0xe134, 0x45ef, { 0xb5, 0x96, 0xc5, 0xee, 0x79, 0x15, 0xf8, 0x19 }
} ;

enum {
	MENU_ITEM_INDEX_CANCEL		= -1,
	MENU_ITEM_INDEX_HELP,
	MENU_ITEM_INDEX_PROPERTY,
	MENU_ITEM_INDEX_RECONVRESION,
	MENU_ITEM_INDEX_SHOWKEYBOARD,
} ;

/*	�c�{�^���̐����� class ���K�v���ƍl����̂��ǂ��������B
 *	�ォ��ǉ����Ȃ��Ƃ����Ȃ����ȁB
 */
class	CLangBarItemIMEButton : public ITfLangBarItemButton,
									public ITfSource
{
public:
	CLangBarItemIMEButton (CSkkImeTextService* pSkkIme) ;
	~CLangBarItemIMEButton () ;

	// IUnknown
	STDMETHODIMP QueryInterface (REFIID riid, void **ppvObj) ;
	STDMETHODIMP_(ULONG) AddRef (void) ;
	STDMETHODIMP_(ULONG) Release (void) ;
	
	// ITfLangBarItem
	STDMETHODIMP GetInfo (TF_LANGBARITEMINFO *pInfo) ;
	STDMETHODIMP GetStatus (DWORD *pdwStatus) ;
	STDMETHODIMP Show (BOOL fShow) ;
	STDMETHODIMP GetTooltipString (BSTR *pbstrToolTip) ;
	
	// ITfLangBarItemButton
	STDMETHODIMP OnClick (TfLBIClick click, POINT pt, const RECT *prcArea) ;
	STDMETHODIMP InitMenu (ITfMenu *pMenu) ;
	STDMETHODIMP OnMenuSelect (UINT wID) ;
	STDMETHODIMP GetIcon (HICON *phIcon) ;
	STDMETHODIMP GetText (BSTR *pbstrText) ;
	
	// ITfSource
	STDMETHODIMP AdviseSink(REFIID riid, IUnknown *punk, DWORD *pdwCookie);
	STDMETHODIMP UnadviseSink(DWORD dwCookie);

	STDMETHODIMP	Update () ;

private:
	CSkkImeTextService*		_pSkkIme ;
	ITfLangBarItemSink*		_pLangBarItemSink ;
	TF_LANGBARITEMINFO		_tfLangBarItemInfo ;
	LONG					_cRef ;
} ;

CLangBarItemIMEButton::CLangBarItemIMEButton (
	CSkkImeTextService*		pSkkIme)
{
	DllAddRef () ;

	_tfLangBarItemInfo.clsidService	= c_clsidSkkImeTextService ;
	_tfLangBarItemInfo.guidItem		= c_guidToolItemButton ;
	_tfLangBarItemInfo.dwStyle		= TF_LBI_STYLE_BTN_MENU | TF_LBI_STYLE_SHOWNINTRAY ;
	_tfLangBarItemInfo.ulSort		= 1 ;
	SafeStringCopy (_tfLangBarItemInfo.szDescription, NELEMENTS (_tfLangBarItemInfo.szDescription), LANGBAR_ITEM_DESC) ;

	_pSkkIme			= pSkkIme ;
	_pSkkIme->AddRef () ;
	_pLangBarItemSink	= NULL ;
	_cRef				= 1 ;
	return ;
}

CLangBarItemIMEButton::~CLangBarItemIMEButton ()
{
	DllRelease () ;
	_pSkkIme->Release () ;
	return ;
}

STDAPI
CLangBarItemIMEButton::QueryInterface (
	REFIID			riid,
	void**			ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfLangBarItem) ||
		IsEqualIID (riid, IID_ITfLangBarItemButton)) {
		*ppvObj	= (ITfLangBarItemButton *)this ;
	} else if (IsEqualIID (riid, IID_ITfSource)) {
		*ppvObj	= (ITfSource *)this ;
	}
	if (*ppvObj != NULL) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CLangBarItemIMEButton::AddRef ()
{
	return	++ _cRef ;
}

STDAPI_(ULONG)
CLangBarItemIMEButton::Release ()
{
	LONG	cr	= -- _cRef ;

	if (_cRef == 0) {
		delete	this ;
	}
	return	cr ;
}

STDAPI
CLangBarItemIMEButton::GetInfo (
	TF_LANGBARITEMINFO*		pInfo)
{
	if (pInfo == NULL)
		return	E_INVALIDARG ;

	*pInfo	= _tfLangBarItemInfo ;
	return	S_OK ;
}

STDAPI
CLangBarItemIMEButton::Show (
	BOOL					fShow)
{
    return	E_NOTIMPL ;
}

STDAPI
CLangBarItemIMEButton::GetStatus (
	DWORD*					pdwStatus)
{
	if (pdwStatus == NULL)
		return	E_INVALIDARG ;

	*pdwStatus	= (_pSkkIme->_IsKeyboardDisabled ())? TF_LBI_STATUS_DISABLED : 0 ;
	return	S_OK ;
}

/*	Button �� tooltip ��Ԃ��B�Ԃ��l�� SysAllocString �ɂ����
 *	�m�ۂ����̈�ɏ������K�v������B����� SysFreeString ��
 *	��̂́A�Ăяo�������̐ӔC�ł���B
 */
STDAPI
CLangBarItemIMEButton::GetTooltipString (
	BSTR*					pbstrToolTip)
{
	if (pbstrToolTip == NULL)
		return	E_INVALIDARG ;

	*pbstrToolTip	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrToolTip == NULL)? E_OUTOFMEMORY : S_OK ;
}

/*	ITfLangBarItemButton::OnClick
 *
 *	���� method �̓��[�U������o�[�� TF_LBI_STYLE_BTN_BUTTON �܂�
 *	�� TF_LBI_STYLE_BTN_TOGGLE �X�^�C���������Ă���{�^���̏�Ń}
 *	�E�X���N���b�N�������ɌĂяo�����B
 *	�����{�^�� item �� TF_LBI_STYLE_BTN_BUTTON �X�^�C���������Ȃ�
 *	�̂Ȃ�A���� method �g���Ȃ��B
 *(*)
 *	���̏󋵂ł͓��ɉ�������K�v�͂Ȃ��̂ŁAS_OK �𑦕Ԃ��B
 */
STDAPI
CLangBarItemIMEButton::OnClick (
	TfLBIClick				click,
	POINT					pt,
	const RECT*				prcArea)
{
	return	S_OK ;
}

/*	ITfLangBarItemButton::InitMenu
 *
 *	���� method �� TF_LBI_STYLE_BTN_MENU �X�^�C��������������o�[�̃{�^��
 *	������o�[���{�^���ɑ΂��ĕ\������ menu item ��ǉ����ėL���ɂ��邽��
 *	�ɌĂяo�����B
 */
STDAPI
CLangBarItemIMEButton::InitMenu (
	ITfMenu*				pMenu)
{
	register int		i ;
	register DWORD		dwFlag ;
	register LPCWSTR	wstrDesc ;
	register ULONG		nstrDesc ;

	if (pMenu == NULL)
		return	E_INVALIDARG ;

	for (i = 0 ; i < NELEMENTS (c_rgMenuItems) ; i ++) {
		wstrDesc		= c_rgMenuItems [i].pchDesc ;
		if (wstrDesc != NULL) {
			nstrDesc	= wcslen (wstrDesc) ;
			dwFlag		= (c_rgMenuItems [i].pfnGetFlag != NULL)? (c_rgMenuItems [i].pfnGetFlag)(_pSkkIme) : 0 ;
		} else {
			nstrDesc	= 0 ;
			dwFlag		= TF_LBMENUF_SEPARATOR ;
		}
		pMenu->AddMenuItem (i, dwFlag, NULL, NULL, wstrDesc, nstrDesc, NULL) ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemIMEButton::OnMenuSelect (
	UINT					wID)
{
	if (wID >= NELEMENTS (c_rgMenuItems))
		return	E_FAIL ;

	/*	NULL �̏ꍇ�� Cancel ���Ǝv�����Ƃɂ���B*/
	if (c_rgMenuItems [wID].pfnHandler != NULL) {
		c_rgMenuItems [wID].pfnHandler (_pSkkIme) ;
//		_pSkkIme->_UpdateLangBarItem (c_guidToolItemButton) ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemIMEButton::GetIcon (
	HICON*					phIcon)
{
	if (phIcon == NULL)
		return	E_INVALIDARG ;

    *phIcon	= (HICON)LoadImage (g_hInst, TEXT ("IDI_SKKIME"), IMAGE_ICON, 16, 16, LR_SHARED) ;
    return (*phIcon != NULL) ? S_OK : E_FAIL ;
}

STDAPI
CLangBarItemIMEButton::GetText (
	BSTR*			pbstrText)
{
	if (pbstrText == NULL)
		return	E_INVALIDARG ;

	*pbstrText	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrText == NULL)? E_OUTOFMEMORY : S_OK ;
}

STDAPI
CLangBarItemIMEButton::AdviseSink (
	REFIID			riid,
	IUnknown*		punk,
	DWORD*			pdwCookie)
{
    if (!IsEqualIID (IID_ITfLangBarItemSink, riid))
        return	CONNECT_E_CANNOTCONNECT ;

    if (_pLangBarItemSink != NULL)
        return	CONNECT_E_ADVISELIMIT ;

    if (punk->QueryInterface (IID_ITfLangBarItemSink, (void **)&_pLangBarItemSink) != S_OK) {
        _pLangBarItemSink	= NULL ;
        return	E_NOINTERFACE ;
    }

    *pdwCookie	= SKKIME_LANGBARITEMSINK_COOKIE ;
    return	S_OK ;
}

STDAPI
CLangBarItemIMEButton::UnadviseSink (
	DWORD			dwCookie)
{
    if (dwCookie != SKKIME_LANGBARITEMSINK_COOKIE)
        return	CONNECT_E_NOCONNECTION ;

    if (_pLangBarItemSink == NULL)
        return	CONNECT_E_NOCONNECTION ;

    _pLangBarItemSink->Release () ;
    _pLangBarItemSink	= NULL ;

    return	S_OK ;
}

STDAPI
CLangBarItemIMEButton::Update ()
{
    if (_pLangBarItemSink == NULL)
        return	CONNECT_E_NOCONNECTION ;

	_pLangBarItemSink->OnUpdate (TF_LBI_STATUS) ;
	return	S_OK ;
}

/*========================================================================*
 *	public function interface
 */
BOOL
CSkkImeTextService::_InitIMELangBarItem ()
{
	ITfLangBarItemMgr*	pLangBarItemMgr ;
	ITfLangBarItem*		pItem ;
	BOOL				bRet ;
	HRESULT				hr ;

	if (! _IsShowLangBarItem (REGKEY_SHOWIMEICON)) 
		return	TRUE ;

	if (_pThreadMgr == NULL)
		return	FALSE ;

	if (_pThreadMgr->QueryInterface (IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) != S_OK) 
		return	FALSE ;

	pItem	= NULL ;
	if (SUCCEEDED (pLangBarItemMgr->GetItem (c_guidImeItemButtonIME, &pItem)) && pItem != NULL) {
		pLangBarItemMgr->RemoveItem (pItem) ;
		pItem->Release () ;
	}

	bRet			= FALSE ;
	_pIMELangBarItem	= new CLangBarItemIMEButton (this) ;
	if (_pIMELangBarItem == NULL)
		goto	Exit ;

	/*	�ǂ����ʂ� process �Œǉ����Ă��� Button ���܂������Ă��Ȃ����Ƃ�����炵���B
	 *	���̂��� AddItem ���G���[��Ԃ��\��������̂ŁA����� RemoveItem ���Ă���
	 *	�ǉ�����B
	 */
	hr	= pLangBarItemMgr->AddItem (_pIMELangBarItem) ;
	if (FAILED (hr)) {
		_pIMELangBarItem->Release () ;
		_pIMELangBarItem	= NULL ;
		bRet	= FALSE ;
		goto	Exit ;
	}
	bRet	= TRUE ;
 Exit:
	pLangBarItemMgr->Release () ;
	return	bRet ;
}

void
CSkkImeTextService::_UninitIMELangBarItem ()
{
	ITfLangBarItemMgr*	pLangBarItemMgr ;
	
	if (_pIMELangBarItem == NULL)
		return ;
	
	if (_pThreadMgr != NULL) {
		if (_pThreadMgr->QueryInterface (IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) == S_OK) {
			pLangBarItemMgr->RemoveItem (_pIMELangBarItem) ;
			pLangBarItemMgr->Release () ;
		}
	}
	_pIMELangBarItem->Release () ;
	_pIMELangBarItem	= NULL ;
	return ;
}

void
CSkkImeTextService::_UpdateIMELangBarItem ()
{
	ITfLangBarItemMgr*	pLangBarItemMgr ;

	if (_pThreadMgr == NULL)
		return ;

	if (_pThreadMgr->QueryInterface (IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) != S_OK)
		return ;

	if (_IsShowLangBarItem (REGKEY_SHOWIMEICON) && _pIMELangBarItem != NULL) 
		_pIMELangBarItem->Update () ;
	pLangBarItemMgr->Release () ;
	return ;
}

