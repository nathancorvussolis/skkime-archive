#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "CandListUI.h"
#include "ToolTipUI.h"
#include "IME\ImeDoc.h"
#include "daiparam.h"
#include "resource.h"

/*========================================================================
 *	structures
 */
struct MYMENUITEMINFO {
	UINT				m_fMask ;
	UINT				m_fType ;
	DWORD				m_wID ;
	LPTSTR				m_dwTypeData ;
} ;

/*========================================================================
 *	prototypes
 */
static	COLORREF	_GetImeColor		(HWND hwnd, int nColor) ;
static	HBRUSH		_GetImeLineBrush	(HWND, int, int, COLORREF*, HBITMAP*, int*) ;
extern	HFONT		_CheckNativeCharset	(HDC) ;

/*========================================================================
 *	class CSkkImeCandidateListUIElement
 */
// {B6B9EEB4-5FCD-496f-A4A2-56B1372F70CF}
const GUID	CSkkImeCandidateListUIElement::m_guidSkkImeCandidateListUIElement = {
	0xb6b9eeb4, 0x5fcd, 0x496f, { 0xa4, 0xa2, 0x56, 0xb1, 0x37, 0x2f, 0x70, 0xcf }
};

CSkkImeCandidateListUIElement::CSkkImeCandidateListUIElement (
	CSkkImeTextService*		pTSF)
{
	m_pTSF	= pTSF ;

	m_dwElementId		= (DWORD)-1 ;
	m_bOpen				= FALSE ;
	m_bShow				= FALSE ;
	m_hWnd				= NULL ;
	m_iStyle			= IMECANDSTYLE_UNUSED ;
	m_bufAnnotation		= NULL ;
	m_iNumAnnotation	= 0 ;
	m_nTextLen			= 0 ;
	m_iCursorPos		= -1 ;
	m_bRegionSelected	= FALSE ;
	m_cRef				= 1 ;
	m_bConsole			= FALSE ;
	m_bButtonPressed	= FALSE ;
	memset (&m_ToolTipInfo, 0, sizeof (m_ToolTipInfo)) ;
	DllAddRef () ;
	return ;
}

CSkkImeCandidateListUIElement::~CSkkImeCandidateListUIElement ()
{
	DllRelease () ;
	return ;
}

HRESULT
CSkkImeCandidateListUIElement::QueryInterface (
	REFIID		riid,
	void**		ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
#if defined (__ITfCandidateListUIElementBehavior_INTERFACE_DEFINED__)
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfCandidateListUIElementBehavior)) {
		*ppvObj	= (ITfCandidateListUIElementBehavior *)this ;
	} else if (IsEqualIID (riid, IID_ITfCandidateListUIElement)) {
		*ppvObj	= (ITfCandidateListUIElement *)this ;
#else 
	if (IsEqualIID (riid, IID_IUnknown)) {
		*ppvObj	= (IUnknown*) this ;
#endif
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfUIElement)) {
		*ppvObj	= (ITfUIElement *)this ;
#endif
	} 
	if (*ppvObj) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

ULONG
CSkkImeCandidateListUIElement::AddRef ()
{
	m_cRef	++ ;
	return	m_cRef ;
}

ULONG
CSkkImeCandidateListUIElement::Release ()
{
	ULONG	cRef	= -- m_cRef ;

	if (cRef == 0) 
		delete	this ;
	return	cRef ;
}

HRESULT
CSkkImeCandidateListUIElement::GetDescription (
	BSTR*				pbstrDescription)
{
	if (pbstrDescription == NULL)
		return	E_INVALIDARG ;
	return	E_NOTIMPL ;
}

HRESULT
CSkkImeCandidateListUIElement::GetGUID (
	GUID*				pguid)
{
	if (pguid == NULL)
		return	E_INVALIDARG ;

	memcpy (pguid, &m_guidSkkImeCandidateListUIElement, sizeof (m_guidSkkImeCandidateListUIElement)) ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::Show (BOOL bShow) 
{
	if (bShow) {
		if (! m_bOpen) {
			return	E_FAIL ;	/* ... */
		}
		if (! m_bShow) 
			ShowWindow (m_hWnd, SW_SHOWNOACTIVATE) ;
		m_bShow	= bShow ;
	} else {
		if (m_bShow)
			ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShow	= FALSE ;
	}
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::IsShown (BOOL* pbShow) 
{
	if (pbShow == NULL)
		return	E_INVALIDARG ;
	*pbShow	= m_bOpen && m_bShow ;	/* m_bShow �̂݁H */
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetUpdatedFlags (DWORD* pdwFlags)
{
	if (pdwFlags == NULL)
		return	E_INVALIDARG ;
	*pdwFlags		= m_dwUpdateFlags ;
	m_dwUpdateFlags	= 0 ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetDocumentMgr (ITfDocumentMgr** ppdim)
{
	if (ppdim == NULL)
		return	E_INVALIDARG ;

	return	_GetDocumentMgr (ppdim) ;
}

HRESULT
CSkkImeCandidateListUIElement::GetCount (UINT* puCount) 
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL)
		return	E_FAIL ;

	if (puCount == NULL)
		return	E_INVALIDARG ;

	*puCount	= pMyCand->_iCount ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetSelection (UINT* puIndex) 
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL)
		return	E_FAIL ;

	if (puIndex == NULL)
		return	E_INVALIDARG ;
	*puIndex	= pMyCand->_iSelection ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetString (UINT uIndex, BSTR* pstr) 
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	BSTR	pbResult	= NULL ;
	LPCWSTR	pwResult ;

	if (pstr == NULL)
		return	E_INVALIDARG ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL)
		return	E_FAIL ;
	if (uIndex >= pMyCand->_iCount)
		return	E_INVALIDARG ;

	pwResult	= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *(pMyCand->_vbufCandidateIndex.GetBuffer () + uIndex) ;
	*pstr		= NULL ;
    if ((pbResult = SysAllocString (pwResult)) == NULL)
        return	E_OUTOFMEMORY ;

    *pstr	= pbResult ;
    return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetPageIndex (UINT* pIndex, UINT uSize, UINT* puPageCnt) 
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED)
		return	E_FAIL ;

	/* Set number of pages */ 
	if (puPageCnt != NULL)
		*puPageCnt	= pMyCand->_vbufPageIndex.GetUsage () ;

	/* Set an array of the indexes that each page starts from. */
	if (pIndex != NULL) {
		const UINT*	puPageIndex ;
		UINT		iMaxPage, i ;

		puPageIndex	= pMyCand->_vbufPageIndex.GetBuffer () ;
		iMaxPage	= pMyCand->_vbufPageIndex.GetUsage () ;
		for (i = 0 ; i < uSize && i < iMaxPage ; i ++) {
			pIndex [i]	= puPageIndex [i] ;
		}
	}
	return	S_OK ;
}

/*	PageIndex �̐ݒ�c���B
 */
HRESULT
CSkkImeCandidateListUIElement::SetPageIndex (UINT* pIndex, UINT uPageCnt) 
{
	return	E_NOTIMPL ;
}

/*	����́cSetPageIndex/GetPageIndex �ō��ꂽ PageStart Index[] �̉�������
 *	�Ԃ��̂��c�B
 */
HRESULT
CSkkImeCandidateListUIElement::GetCurrentPage (UINT* pPage)
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED)
		return	E_FAIL ;
	if (pPage == NULL)
		return	E_INVALIDARG ;
	*pPage	= pMyCand->_iCurrentPage ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::SetSelection (UINT nIndex) 
{
	return	E_NOTIMPL ;
}

HRESULT
CSkkImeCandidateListUIElement::Finalize () 
{
	/*	current selection �Ŋm�肷��B-> candidate-list �����Bminibuffer-text ����
	 *	�������H
	 */
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;

	if (! m_bOpen)
		return	E_FAIL ;
	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED) {
		if (m_bShow) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShow	= FALSE ;
		}
		m_pTSF->_EndCandidateListUI () ;
		m_bOpen	= FALSE ;
		return	S_OK ;
	}
	switch (pMyCand->_iStyle) {
	case	IMECANDSTYLE_READ:
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		return	_SendKeyDownToContext ((WPARAM) MYVK_FINALIZE_CANDIDATELIST, (LPARAM) 0) ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
	default:
		return	_SendKeyDownToContext ((WPARAM) MYVK_EXIT_MINIBUFFER, (LPARAM) 0) ;
	}
}

HRESULT
CSkkImeCandidateListUIElement::Abort () 
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;

	if (! m_bOpen)
		return	E_FAIL ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED) {
		if (m_bShow) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShow	= FALSE ;
		}
		m_pTSF->_EndCandidateListUI () ;
		m_bOpen	= FALSE ;
		return	S_OK ;
	}
	switch (pMyCand->_iStyle) {
	case	IMECANDSTYLE_READ:
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		return	_SendKeyDownToContext ((WPARAM) MYVK_ABORT_CANDIDATELIST, (LPARAM) 0) ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
	default:
		return	_SendKeyDownToContext ((WPARAM) MYVK_ABORT_MINIBUFFER, (LPARAM) 0) ;
	}
}


/*========================================================================
 *	library internal public methos
 */
TCHAR	CSkkImeCandidateListUIElement::m_szWndClass []	= TEXT ("SkkImeTextService CandidateListUI Wnd Class") ;

BOOL
CSkkImeCandidateListUIElement::_Init (BOOL bConsole)
{
	WNDCLASS	wc ;

	/*	Console �������ꍇ�ɂ́AWindow �͍��Ȃ��Ă��ǂ��Ƃ��������Ȃ��Ǝv���B
	 *	Console ���ǂ����̔���͉��������ŏo����H
	 */
	m_bufAnnotation	= new TEXTREGION [MAX_ANNOTATION] ;
	if (m_bufAnnotation == NULL)
		return	FALSE ;

	if (! bConsole) {
		if (m_hWnd != NULL)
			return	TRUE ;

		memset (&wc, 0, sizeof (wc)) ;
		wc.lpfnWndProc		= CSkkImeCandidateListUIElement::_WndProc ;
		wc.hInstance		= g_hInst ;
		wc.lpszClassName	= CSkkImeCandidateListUIElement::m_szWndClass ;

		if (RegisterClass (&wc) == 0) {
			DWORD	dwError	= GetLastError () ;
			if (dwError != ERROR_CLASS_ALREADY_EXISTS) {
				DEBUGPRINTF ((TEXT ("CUIStatus::_RegisterClass (0x%lx) failed.\n"), dwError)) ;
				return	FALSE ;
			}
		}
		m_hWnd	= CreateWindowEx (WS_EX_DLGMODALFRAME | WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
								  m_szWndClass,
								  TEXT ("SkkImeTextService CandidateListUI Wnd"),
								  WS_DISABLED | WS_POPUP,
								  0, 0, 100, 32, NULL, NULL, g_hInst, this) ;
		if (m_hWnd == NULL || ! IsWindow (m_hWnd)) {
			DEBUGPRINTF ((TEXT ("CUIStatus::_CreateWindowEx () failed.\n"))) ;
			return	FALSE ;
		}
		ShowWindow (m_hWnd, SW_HIDE) ;
	}
	m_bConsole			= bConsole ;
	m_bButtonPressed	= FALSE ;
	memset (&m_ToolTipInfo, 0, sizeof (m_ToolTipInfo)) ;
	return	TRUE ;
}

void
CSkkImeCandidateListUIElement::_Uninit ()
{
	if (m_bufAnnotation != NULL) {
		delete[]	m_bufAnnotation ;
		m_bufAnnotation	= NULL ;
	}
	if (m_hWnd != NULL && IsWindow (m_hWnd)) {
		DestroyWindow (m_hWnd) ;
		m_hWnd	= NULL ;
	}
	m_bConsole	= FALSE ;
	m_nTextLen	= 0 ;
	return ;
}

BOOL
CSkkImeCandidateListUIElement::_Open (
	DWORD		dwElementId,
	BOOL		bShow)
{
	if (m_bOpen)
		return	FALSE ;

	m_dwElementId	= dwElementId ;
	m_bShow			= bShow ;
	m_bOpen			= TRUE ;

	if (bShow) {
		if (m_hWnd == NULL || ! IsWindow (m_hWnd))
			return	FALSE ;
		_UpdateText () ;
		ShowWindow (m_hWnd, SW_SHOWNOACTIVATE) ;
	}
	return	TRUE ;
}

void
CSkkImeCandidateListUIElement::_Close ()
{
	if (! m_bOpen) 
		return ;

	m_bOpen	= FALSE ;
	if (m_bShow) {
		if (m_hWnd != NULL && IsWindow (m_hWnd))
			ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShow	= FALSE ;
	}
	return ;
}

BOOL
CSkkImeCandidateListUIElement::_Update ()
{
	/*
	 *	TF_CLUIE_DOCUMENTMGR	The target document manager was changed. 
	 *	TF_CLUIE_COUNT			The count of the candidate string was changed. 
	 *	TF_CLUIE_SELECTION		The selection of the candidate was changed. 
	 *	TF_CLUIE_STRING			Some strings in the list were changed. 
	 *	TF_CLUIE_PAGEINDEX		The current page index or some page index was changed. 
	 *	TF_CLUIE_CURRENTPAGE	The page was changed. 
	 */
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	DWORD	dwUpdateFlags ;

	if (FAILED (_GetDocument (&pDoc)))
		return	FALSE ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED) {
		m_nTextLen			= 0 ;
		m_iNumAnnotation	= 0 ;
		return	FALSE ;
	}

	dwUpdateFlags	= 0 ;
#if defined (__ITfCandidateListUIElement_INTERFACE_DEFINED__)
	if (pMyCand->_dwUpdate & IMECANDUPDATE_SELECTION) {
		dwUpdateFlags	|= TF_CLUIE_SELECTION ;
	}
	if (pMyCand->_dwUpdate & IMECANDUPDATE_CURRENT_PAGE) {
		dwUpdateFlags	|= TF_CLUIE_CURRENTPAGE ;
	}
	if (pMyCand->_dwUpdate & IMECANDUPDATE_COUNT) {
		dwUpdateFlags	|= TF_CLUIE_COUNT ;
	}
	if (pMyCand->_dwUpdate & IMECANDUPDATE_STRING) {
		dwUpdateFlags	|= TF_CLUIE_STRING ;
	}
	if (pMyCand->_dwUpdate & IMECANDUPDATE_PAGE_INDEX) {
		dwUpdateFlags	|= TF_CLUIE_PAGEINDEX ;
	}
	if (m_iStyle != pMyCand->_iStyle || m_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		m_iStyle		= pMyCand->_iStyle ;
		/* �����̔���͔��������c�B*/
		dwUpdateFlags	|= TF_CLUIE_STRING ;
	}
#else
	dwUpdateFlags	= pMyCand->_dwUpdate ;
	if (m_iStyle != pMyCand->_iStyle || m_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		m_iStyle		= pMyCand->_iStyle ;
		dwUpdateFlags	|= 1 ;
	}
#endif
	/* string �� update �����Ƃ�Ȃ��c�B*/
	m_dwUpdateFlags	|= dwUpdateFlags ;

	if (m_bShow && dwUpdateFlags != 0) {
		_UpdateText () ;
		InvalidateRect (m_hWnd, NULL, FALSE) ;
	}
	return	TRUE ;
}

BOOL
CSkkImeCandidateListUIElement::_IsActivep (BOOL* pbShow) const
{
	if (pbShow != NULL)
		*pbShow	= m_bShow ;

	return	m_bOpen ;
}

DWORD
CSkkImeCandidateListUIElement::_GetUIElementId () const
{
	return	m_dwElementId ;
}

BOOL
CSkkImeCandidateListUIElement::_MoveWindow (
	int				iX,
	int				iY,
	int				iWidth,
	int				iHeight)
{
	m_rcWnd.left	= iX ;
	m_rcWnd.top		= iY ;
	if (iWidth != 0)
		m_rcWnd.right	= iWidth ;
	if (iHeight != 0)
		m_rcWnd.bottom	= iHeight ;
	if (m_hWnd != NULL && IsWindow (m_hWnd))
		MoveWindow (m_hWnd, m_rcWnd.left, m_rcWnd.top, m_rcWnd.right, m_rcWnd.bottom, TRUE) ;
	return	TRUE ;
}

void
CSkkImeCandidateListUIElement::_Popup (BOOL bFocus) 
{
	if (m_bOpen && m_bShow && m_hWnd != NULL && IsWindow (m_hWnd)) {
		ShowWindow (m_hWnd, bFocus? SW_SHOWNOACTIVATE : SW_HIDE) ;
	}
	return ;
}

/*================================================================
 *	private methods
 */
HRESULT
CSkkImeCandidateListUIElement::_GetDocumentMgr (
	ITfDocumentMgr**	ppdim)
{
	ITfThreadMgr*	pThreadMgr ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pThreadMgr	= m_pTSF->_GetThreadMgr () ;
	if (pThreadMgr == NULL)
		return	E_FAIL ;
	return	pThreadMgr->GetFocus (ppdim) ;
}

HRESULT
CSkkImeCandidateListUIElement::_GetDocument (
	CImeDoc**			ppDoc)
{
	CSkkImeMgr*	pIME ;
	CImeDoc*	pDoc ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pIME	= m_pTSF->_GetCurrentIME () ;
	if (pIME == NULL)
		return	E_FAIL ;

	pDoc	= pIME->GetDocument () ;
	if (pDoc == NULL)
		return	E_FAIL ;

	if (ppDoc != NULL)
		*ppDoc	= pDoc ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::_GetToolTipUI (
	CSkkImeToolTipUIElement**	ppToolTipUI)
{
	CSkkImeToolTipUIElement*	pToolTipUI ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pToolTipUI	= m_pTSF->_GetToolTipUI () ;
	if (pToolTipUI == NULL)
		return	E_FAIL ;
	if (ppToolTipUI != NULL)
		*ppToolTipUI	= pToolTipUI ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::_SendKeyDownToContext (
	WPARAM			wParam,
	LPARAM			lParam)
{
	HRESULT         hr;
	ITfDocumentMgr  *pFocusDoc;

	hr	= _GetDocumentMgr (&pFocusDoc) ;
	if (SUCCEEDED (hr)) {
		ITfContext*	pContext ;

		hr	= pFocusDoc->GetTop (&pContext) ;
		if (SUCCEEDED (hr)) {
			BOOL	bEaten ;

			//Use the context.
			hr	= m_pTSF->OnKeyDown (pContext, wParam, lParam, &bEaten) ;
			pContext->Release () ;
		}
		pFocusDoc->Release () ;
	}
	return	hr ;
}

void
CSkkImeCandidateListUIElement::_UpdateText ()
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;

	if (FAILED (_GetDocument (&pDoc)))
		return ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED) {
		m_nTextLen			= 0 ;
		m_iNumAnnotation	= 0 ;
		return ;
	}

	m_iNumAnnotation	= 0 ;
	switch (pMyCand->_iStyle) {
	case	IMECANDSTYLE_READ:
		{
			m_iNumAnnotation	= (m_bufAnnotation != NULL)? MAX_ANNOTATION : 0 ;
			m_nTextLen	= pDoc->GetCandidateText (m_wszText, ARRAYSIZE (m_wszText), m_bufAnnotation, &m_iNumAnnotation, pMyCand) ;
			_ConfigureAnnotation (m_bufAnnotation, m_iNumAnnotation) ;
		}
		break ;
	case	IMECANDSTYLE_CODE0:
		m_nTextLen	= pDoc->GetCodeMenuJumpText (m_wszText, ARRAYSIZE (m_wszText), pMyCand) ;
		break ;
	case	IMECANDSTYLE_CODE1:
		m_nTextLen	= pDoc->GetCodeMenu1Text (m_wszText, ARRAYSIZE (m_wszText), pMyCand) ;
		break ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
		m_nTextLen	= _GetMinibufferText (m_wszText, ARRAYSIZE (m_wszText), pMyCand) ;
		break ;
	default:
		m_nTextLen	= 0 ;
		break ;
	}
	return ;
}


int
CSkkImeCandidateListUIElement::_GetMinibufferText (
	LPWSTR					pwText,
	int						iTextSize,
	const IMECANDIDATES*	pMyCand)
{
	CImeDoc*	pDoc ;
	int			nRegionStart = -1, nRegionEnd = -1, nText ;
	int			iCursorPos, iResult ;
	LPCWSTR		pwSText ;
	BOOL		fRegionSelected ;

	if (FAILED (_GetDocument (&pDoc))) 
		return	0 ;
	if (pMyCand == NULL || pMyCand->_iCount != 1 || pMyCand->_iStyle != IMECANDSTYLE_MINIBUFFERTEXT) 
		return	0 ;

	pwSText			= pMyCand->_vbufCandidate.GetBuffer () + *(pMyCand->_vbufCandidateIndex.GetBuffer () + 0) ;
	nText			= lstrlenW (pwSText) ;

	iCursorPos		= -1 ;
	fRegionSelected	= FALSE ;
	if (! pDoc->GetStatusCursor (&iCursorPos))
		iCursorPos	= -1 ;
	if (iCursorPos >= 0) {
		fRegionSelected	= pDoc->GetSelectedRegion (&nRegionStart, &nRegionEnd) ;
		if (iCursorPos < nText && pwSText [iCursorPos] == L'|') {
			LPWSTR	pwDest, pwDestLast ;
			LPCWSTR	pwSrc,	pwSrcLast ;
			int		n ;

			pwDest		= pwText ;
			pwDestLast	= pwDest + iTextSize ;
			pwSrc		= pwSText ;
			pwSrcLast	= pwSText + nText ;
			n			= (iCursorPos < iTextSize)? iCursorPos : iTextSize ;
			wcsncpy (pwDest, pwSrc, n) ;
			pwDest	+= n ;
			pwSrc	+= n + 1 ;
			if (pwDest < pwDestLast && pwSrc < pwSrcLast) {
				n		= MIN ((pwDestLast - pwDest), (pwSrcLast - pwSrc)) ;
				wcsncpy (pwDest, pwSrc, n) ;
				pwDest	+= n ;
			}
			iResult		= pwDest - pwText ;
		} else {
			iResult	= MIN (nText, iTextSize) ;
			wcsncpy (pwText, pwSText, iResult) ;
		}
	} else {
		iResult	= MIN (nText, iTextSize) ;
		wcsncpy (pwText, pwSText, iResult) ;
	}
	m_iCursorPos		= iCursorPos ;
	m_bRegionSelected	= fRegionSelected ;
	m_iRegionStart		= nRegionStart ;
	m_iRegionEnd		= nRegionEnd ;
	return	iResult ;
}

/*================================================================
 *	Window Message Handlers
 */
LRESULT	CALLBACK
CSkkImeCandidateListUIElement::_WndProc (
	HWND			hWnd,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_CREATE:
		SetWindowLongPtr (hWnd, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCT *)lParam)->lpCreateParams) ;
		return	0L ;

	case	WM_SETCURSOR:
		{
			CSkkImeCandidateListUIElement*	pThis ;
			
			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnSetCursor (wParam, lParam) ;
			}
		}
		break ;

	case	WM_MOUSEMOVE:
		{
			CSkkImeCandidateListUIElement*	pThis ;
			
			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnMouseMove (wParam, lParam) ;
			}
		}
		break ;

	case	WM_LBUTTONDOWN:
	case	WM_RBUTTONDOWN:
		{
			CSkkImeCandidateListUIElement*	pThis ;
			
			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnButtonDown (uMessage, wParam, lParam) ;
			}
		}
		break ;

	case	WM_LBUTTONUP:
	case	WM_RBUTTONUP:
		{
			CSkkImeCandidateListUIElement*	pThis ;
			
			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnButtonUp (uMessage, wParam, lParam) ;
			}
		}
		break ;

	case	WM_TIMER:
		{
			CSkkImeCandidateListUIElement*	pThis ;
			
			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnTimer (wParam, lParam) ;
			}
		}
		break ;

	case	WM_PAINT:
		{
			CSkkImeCandidateListUIElement*	pThis ;
			HDC			hDC ;
			PAINTSTRUCT	ps ;

			hDC		= BeginPaint (hWnd, &ps) ;
			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnPaint (hDC) ;
			}
			EndPaint (hWnd, &ps) ;
		}
		break ;

	default:
		return	DefWindowProc (hWnd, uMessage, wParam, lParam) ;
	}
	return	0L ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnSetCursor (
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	BOOL					bMinibuffered ;

	if (FAILED (_GetDocument (&pDoc)))
		return	0L ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED)
		return	0L ;

	bMinibuffered	= (pMyCand->_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) ;
	if (bMinibuffered) {
		switch (HIWORD (lParam)) {
		case	WM_LBUTTONDOWN:
		case	WM_RBUTTONDOWN:
			_OnButtonDown (HIWORD(lParam), 0, 0) ;
			break ;
		case	WM_LBUTTONUP:
		case	WM_RBUTTONUP:
			_OnButtonUp (HIWORD(lParam), 0, 0) ;
			break ;
		default:
			_OnMouseMove (0, 0) ;
			break ;
		}
	} else {
		/* tooltip �̏����B*/
		_HideToolTip () ;

		if (HIWORD (lParam) != WM_LBUTTONDOWN && HIWORD (lParam) != WM_RBUTTONDOWN && m_iNumAnnotation > 0) {
			UINT	uHoverTime ;
			if (pDoc->IsSkkShowAnnotationp ()) {
				if (! SystemParametersInfo (SPI_GETMOUSEHOVERTIME, 0, &uHoverTime, 0))
					uHoverTime	= SKKIME_DEFAULT_HOVERTIME ;
				SetTimer (m_hWnd, TIMEEV_SHOWANNOTATION, uHoverTime, NULL) ;
			}
		}
	}
	return	0L ;
	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnMouseMove (
	WPARAM		wParam,
	LPARAM		lParam)
{
	return	0L ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnButtonDown (
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	POINT					pos ;

	if (FAILED (_GetDocument (&pDoc)))
		return	0L ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (m_hWnd, &pos))
		return	0L ;

	pMyCand	= pDoc->GetStatusText () ;
	if (pMyCand != NULL && pMyCand->_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		int		nDummy, iCursorPos ;

		if (pDoc->GetStatusCursor (&nDummy)) {
			/*	���������B�����A�J�[�\���̈ړ��ƃ}�[�N�̐ݒ�Ƃ����Ƃ��B
			 *	�J�[�\���ʒu�𓾂āABUTTONDOWN �𑗐M����B
			 */
			if (uMessage == WM_LBUTTONDOWN) {
				if (_GetTextPosition (&pos, &iCursorPos)) 
					_SendKeyDownToContext ((WPARAM) MYVK_LBUTTON, (LPARAM) iCursorPos) ;
			}
			m_bButtonPressed	= TRUE ;
			SetCapture (m_hWnd) ;
		}
	}
	return	0L ;
	UNREFERENCED_PARAMETER (uMessage) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnButtonUp (
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	/*
	 * �}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 * �ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (! m_bButtonPressed) 
		return	0L ;

	ReleaseCapture () ;	/* ReleaseCapture �����͕K�{�B*/
	m_bButtonPressed	= FALSE ;

	switch (uMessage) {
	case	WM_LBUTTONUP:
		{
			CImeDoc*				pDoc ;
			POINT					pos ;
			const IMECANDIDATES*	pMyCand ;

			GetCursorPos (&pos) ;
			if (! ScreenToClient (m_hWnd, &pos))
				return	0L ;

			if (FAILED (_GetDocument (&pDoc)))
				return	0L ;

			pMyCand	= pDoc->GetStatusText () ;
			if (pMyCand != NULL && pMyCand->_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
				int				nDummy, iCursorPos ;

				/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
				if (pDoc->GetStatusCursor (&nDummy)){
					if (_GetTextPosition (&pos, &iCursorPos)) 
						_SendKeyDownToContext ((WPARAM) MYVK_LBUTTON, (LPARAM) iCursorPos | 0x80000000) ;
				}
			}
		}
		break ;
	case	WM_RBUTTONUP:
		_HandleMinibufferContextMenu () ;
		break ;
	default:
		break ;
	}
	return	0L ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnTimer (
	WPARAM		wParam,
	LPARAM		lParam)
{
	KillTimer (m_hWnd, wParam) ;

	if (m_iNumAnnotation > 0) {
		CImeDoc*	pDoc ;

		if (FAILED (_GetDocument (&pDoc)))
			return	0L ;

		if (pDoc != NULL && pDoc->IsSkkShowAnnotationp ()) {
			const IMECANDIDATES*	pMyCand	= pDoc->GetStatusText () ;

			if (pMyCand != NULL && pMyCand->_iStyle == IMECANDSTYLE_READ) {
				POINT		pt ;

				GetCursorPos (&pt) ;
				ScreenToClient (m_hWnd, &pt) ;
				_HitTestAnnotation (&pt) ;
			}
		}
	}
	return	0L ;
	UNREFERENCED_PARAMETER (lParam) ;
}

void
CSkkImeCandidateListUIElement::_OnPaint (
	HDC			hDC)
{
	CImeDoc*	pDoc	= NULL ;
	HFONT		hOldFont ;
	const IMECANDIDATES*	pMyCand ;
	RECT		rc ;

	if (FAILED (_GetDocument (&pDoc)))
		return ;

	pMyCand		= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle == IMECANDSTYLE_UNUSED) {
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShow	= FALSE ;
		return ;
	}

	hOldFont	= _CheckNativeCharset (hDC) ;
	GetClientRect (m_hWnd, &rc) ;
	switch (pMyCand->_iStyle) {
	case	IMECANDSTYLE_READ:
		_PaintCandidateList (hDC, &rc) ;
		break ;
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		_PaintCodeList (hDC, &rc) ;
		break ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
		_PaintMinibufferText (hDC, &rc) ;
		break ;
	default:
		break ;
	}
	DeleteObject (SelectObject (hDC, hOldFont)) ;
	return ;
}

BOOL
CSkkImeCandidateListUIElement::_PaintCandidateList (
	HDC						hDC,
	LPRECT					prcDraw)
{
	HBRUSH			hULBrush = NULL, hOldBrush = NULL ;
	HBRUSH			hBrushBg = NULL ;
	HBITMAP			hbmUL = NULL ;
	int				nULHeight, nText ;
	COLORREF		colUL ;
	SIZE			sz ;
	const TEXTREGION*	pbufAnnot ;
	int				nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
	LPCWSTR			pwText ;
	const TEXTREGION*	pAnnot ;
	TEXTMETRIC		tm ;

	if (m_nTextLen <= 0)
		return	TRUE ;

	hBrushBg	= (HBRUSH) CreateSolidBrush (GetBkColor (hDC)) ;
	hULBrush	= _GetImeLineBrush (m_hWnd, MYCOLOR_TEXTAUTO, MYLINE_THIN_DITHER, &colUL, &hbmUL, &nULHeight) ;
	if (hULBrush)
		hOldBrush	= (HBRUSH) SelectObject (hDC, hULBrush) ;

	pbufAnnot	= m_bufAnnotation ;
	GetTextMetrics (hDC, &tm) ;
	nDefaultDY	= tm.tmHeight ;

	y			= prcDraw->top ;
	pwText		= m_wszText ;
	nTextPos	= 0 ;
	nText		= m_nTextLen ;
	sz.cx		= 0 ;
	sz.cy		= 0 ;
	nDY			= nDefaultDY ;

	while (y < prcDraw->bottom && 0 < nText) {
		/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
		x	= prcDraw->left ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
			if ((x + sz.cx) > prcDraw->right) 
				break ;
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;

		/* ���̍s�ɂ� nChar �����\������B*/
		TextOutW (hDC, x, y, pwText, nChar) ;
		nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
		x	+= sz.cx ;

		/* �܂�Ԃ�������\������B*/
		if (nChar < nText) {
			SIZE	szBackslash ;
			TextOutW (hDC, x, y, L"\\", 1) ;
			GetTextExtentPoint32W (hDC, L"\\", 1, &szBackslash) ;
			x	+= szBackslash.cx ;
		} else {
			RECT	rc ;
			rc.left	= x ;	rc.right	= prcDraw->right ;
			rc.top	= y ;	rc.bottom	= y + nDY ;	
			FillRect (hDC, &rc, hBrushBg) ;
		}

#define	IsTextRegionCrossp(text1,ntext1,text2,ntext2)	(!((((text1)+(ntext1))<=(text2)||(text1)>=((text2)+(ntext2)))))
		for (nAnnot = 0 ; nAnnot < m_iNumAnnotation ; nAnnot ++) {
			int	nOffset, nLength ;

			pAnnot	= m_bufAnnotation + nAnnot ;
			if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
				continue ;
			nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
			nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
			if (nLength > nChar)
				nLength	= nChar ;

			if (nOffset > 0) {
				GetTextExtentPoint32W (hDC, pwText, nOffset, &sz) ;
				nAnnotX	= prcDraw->left + sz.cx ;
			} else {
				nAnnotX	= prcDraw->left ;
			}
			GetTextExtentPoint32W (hDC, pwText + nOffset, nLength, &sz) ;
			nAnnotWidth	= sz.cx ;

			if (hULBrush) 
				PatBlt (hDC, nAnnotX, y + nDY - nULHeight, nAnnotWidth, nULHeight, PATCOPY) ;
		}
		pwText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		y			+= nDY ;
	}
	if (y < prcDraw->bottom) {
		RECT	rc ;
		rc.left	= prcDraw->left ;	rc.right	= prcDraw->right ;
		rc.top	= y ;				rc.bottom	= y + nDY ;	
		FillRect (hDC, &rc, hBrushBg) ;
	}

	if (hULBrush) {
		(void) SelectObject (hDC, hOldBrush) ;
		DeleteObject (hULBrush) ;
	}
	if (hBrushBg) 
		DeleteObject (hBrushBg) ;
	if (hbmUL)
		DeleteObject (hbmUL) ;
	return	TRUE ;
}

BOOL
CSkkImeCandidateListUIElement::_PaintCodeList (
	HDC						hDC,
	LPRECT					prcDraw)
{
	int			nText ;
	int			nDY, nDefaultDY, x, y, nChar ;
	LPCWSTR		pwText ;
	TEXTMETRIC	tm ;
	SIZE		sz ;
	HBRUSH		hBrushBg ;

	if (m_nTextLen <= 0) 
		return	TRUE ;

	GetTextMetrics (hDC, &tm) ;
	nDefaultDY	= tm.tmHeight ;
	hBrushBg	= (HBRUSH) CreateSolidBrush (GetBkColor (hDC)) ;

	y			= prcDraw->top ;
	pwText		= m_wszText ;
	nText		= m_nTextLen ;
	sz.cx	= sz.cy	= 0 ;
	while (y < prcDraw->bottom && 0 < nText) {
		/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
		x	= prcDraw->left ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
			if ((x + sz.cx) > prcDraw->right) 
				break ;
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;

		/* ���̍s�ɂ� nChar �����\������B*/
		TextOutW (hDC, x, y, pwText, nChar) ;
		nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
		x	+= sz.cx ;

		/* �܂�Ԃ�������\������B*/
		if (nChar < nText) {
			SIZE	szBackslash ;
			TextOutW (hDC, x, y, L"\\", 1) ;
			GetTextExtentPoint32W (hDC, L"\\", 1, &szBackslash) ;
			x	+= szBackslash.cx ;
		} else {
			RECT	rc ;
			rc.left	= x ;	rc.right	= prcDraw->right ;
			rc.top	= y ;	rc.bottom	= y + nDY ;	
			FillRect (hDC, &rc, hBrushBg) ;
		}
		pwText		+= nChar ;
		nText		-= nChar ;
		y			+= nDY ;
	}
	if (y < prcDraw->bottom) {
		RECT	rc ;
		rc.left	= prcDraw->left ;	rc.right	= prcDraw->right ;
		rc.top	= y ;				rc.bottom	= y + nDefaultDY ;	
		FillRect (hDC, &rc, hBrushBg) ;
	}
	if (hBrushBg) 
		DeleteObject (hBrushBg) ;
	return	TRUE ;
}

BOOL
CSkkImeCandidateListUIElement::_PaintMinibufferText (
	HDC						hDC,
	LPRECT					prcDraw)
{
	CImeDoc*		pDoc ;
//	HBRUSH			hbr ;
	int				nRegionStart, nRegionEnd ;
	int				x, y, nDY, nText, nTextPos ;
	LPCWSTR			pwSText, pText ;
	int				iCursorPos ;
	BOOL			fRegionSelected ;
	TEXTMETRIC		tm ;
	BOOL			bCursorPos ;
	HBRUSH			hBrushBg ;

	if (FAILED (_GetDocument (&pDoc)))
		return	FALSE ;

	pwSText			= m_wszText ;
	iCursorPos		= m_iCursorPos ;
	fRegionSelected	= m_bRegionSelected ;
	nRegionStart	= m_bRegionSelected? m_iRegionStart : -1 ;
	nRegionEnd		= m_bRegionSelected? m_iRegionEnd   : -1 ;

	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;
	hBrushBg	= (HBRUSH) CreateSolidBrush (GetBkColor (hDC)) ;

	SetBkMode (hDC, OPAQUE) ;
	//	�F�̑���c�ǂ����悤���Bfocus ���Ă��� Window �̔w�i�F�Ȃ�ĕs�������B
//	SetBkColor (hDC, GetBkColor (hPDC)) ;
//	SetTextColor (hDC, RGB (0, 0, 0)) ;

	pText		= pwSText ;
	nText		= m_nTextLen ;
	nTextPos	= 0 ;
	y			= prcDraw->top ;
	x			= prcDraw->left ;
	bCursorPos	= FALSE ;
	while (y < prcDraw->bottom && 0 < nText) {
		int		nChar, iSX ;
		BOOL	bCRLF ;
		SIZE	sz ;

		bCRLF	= FALSE ;
		iSX		= x ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			GetTextExtentPoint32W (hDC, pText, nChar, &sz) ;
			if ((x + sz.cx) >= prcDraw->right) {
				bCRLF	= TRUE ;
				break ;
			}
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;

		if (fRegionSelected && !(nRegionEnd <= nTextPos || (nTextPos + nChar) <= nRegionStart)) {
			int	nStart, nEnd ;

			if (nTextPos < nRegionStart) {
				TextOutW (hDC, x, y, pText, nRegionStart - nTextPos) ;
				GetTextExtentPoint32W (hDC, pText, nRegionStart - nTextPos, &sz) ;
				x	+= sz.cx ;
			}
			nStart	= (nRegionStart < nTextPos)? nTextPos : nRegionStart ;
			nEnd	= (nRegionEnd   >= (nTextPos + nChar))? (nTextPos + nChar) : nRegionEnd ;
			if (nStart < nEnd) {
				COLORREF	colBack	= GetBkColor (hDC) ;
				SetBkColor (hDC, RGB (192, 192, 224)) ;
				TextOutW (hDC, x, prcDraw->top, pwSText + nStart, nEnd - nStart) ;
				GetTextExtentPoint32W (hDC, pwSText + nStart, nEnd - nStart, &sz) ;
				SetBkColor (hDC, colBack) ;
				x	+= sz.cx ;
			}
			if (nEnd < (nTextPos + nChar)) {
				TextOutW (hDC, x, prcDraw->top, pwSText + nEnd, nTextPos + nChar - nEnd) ;
				GetTextExtentPoint32W (hDC, pwSText + nEnd, nTextPos + nChar - nEnd, &sz) ;
				x	+= sz.cx ;
			}
		} else {
			/* �e�L�X�g��\������B*/
			TextOutW (hDC, x, y, pText, nChar) ;
			GetTextExtentPoint32W (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
		}

		if (bCRLF) {
			/*	�܂�Ԃ��L����\������B*/
			TextOutW (hDC, x, y, L"\\", 1) ;
			GetTextExtentPoint32W (hDC, L"\\", 1, &sz) ;
			x	+= sz.cx ;
		}
		if (bCRLF || nChar == nText)
			PatBlt (hDC, x, y, prcDraw->right - x, nDY, PATCOPY) ;

		/* �K�v�Ȃ�J�[�\����\������B*/
		if (nTextPos <= iCursorPos && iCursorPos <= (nTextPos + nChar)) {
			RECT			invRect ;

			if (iCursorPos > nTextPos) {
				GetTextExtentPoint32W (hDC, pText, iCursorPos - nTextPos, &sz) ;
				invRect.left	= iSX + sz.cx ;
				invRect.right	= iSX + sz.cx + UI_CURSORWIDTH ;
			} else {
				invRect.left	= iSX ;
				invRect.right	= iSX + UI_CURSORWIDTH ;
			}
			invRect.top		= y ;
			invRect.bottom	= y + nDY ;
			InvertRect (hDC, &invRect) ;
		}	
		pText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		if (bCRLF) {
			y		+= nDY ;
			x		= prcDraw->left ;
		}
	}
	if (y < prcDraw->bottom) {
		RECT	rc ;
		rc.left	= x ;		rc.right	= prcDraw->right ;
		rc.top	= y + nDY ;	rc.bottom	= prcDraw->bottom ;
		if (rc.top < rc.bottom)
			FillRect (hDC, &rc, hBrushBg) ;
	}
	return	TRUE ;
}


BOOL
CSkkImeCandidateListUIElement::_GetTextPosition (
	const POINT*			pPoint,
	int*					piCursorPos)
{
	HDC			hDC ;
	LPCWSTR		pText ;
	int			nText, iCursorPos, nDY, y ;
	RECT		rc ;
	TEXTMETRIC	tm ;

	pText		= m_wszText ;
	nText		= m_nTextLen ;
	hDC			= GetDC (m_hWnd) ;
	if (!hDC)
		return	FALSE ;

	GetClientRect (m_hWnd, &rc) ;
	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	iCursorPos	= 0 ;
	y			= 0 ;
	while (y < pPoint->y) {
		int		nChar ;
		SIZE	sz ;

		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			GetTextExtentPoint32W (hDC, pText, nChar, &sz) ;
			if (pPoint->x < sz.cx && y <= pPoint->y && pPoint->y < (y + sz.cy)) {
				/* found */
				iCursorPos	= (pText + nChar - 1) - m_wszText ;
				goto	exit_loop ;
			}
			if (sz.cx >= rc.right) {
				break ;
			}
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;
		y		+= nDY ;
		pText	+= nChar ;
		nText	-= nChar ;
	}
	iCursorPos	= pText - m_wszText ;
exit_loop:
	ReleaseDC (m_hWnd, hDC) ;
	if (piCursorPos != NULL)
		*piCursorPos	= iCursorPos ;
	return	TRUE ;
}

void
CSkkImeCandidateListUIElement::_HitTestAnnotation (
	const POINT*	pPT)
{
	CSkkImeToolTipUIElement*	pToolTipUI ;
	int		nTool ;
	
	if (FAILED (_GetToolTipUI (&pToolTipUI)))
		return ;
	for (nTool = 0 ; nTool < m_ToolTipInfo.m_nCount ; nTool ++) {
		if (m_ToolTipInfo.m_rrcHitArea [nTool].left <= pPT->x && pPT->x < m_ToolTipInfo.m_rrcHitArea [nTool].right &&
			m_ToolTipInfo.m_rrcHitArea [nTool].top  <= pPT->y && pPT->y < m_ToolTipInfo.m_rrcHitArea [nTool].bottom) {
			POINT	pt ;
			RECT	rc ;
			BOOL	bShow ;

			/* hit */
			pt.x	= pPT->x ;
			pt.y	= pPT->y ;
			ClientToScreen (m_hWnd, &pt) ;
			m_ToolTipInfo.m_ptLastPos.x	= pt.x ;
			m_ToolTipInfo.m_ptLastPos.y	= pt.y ;
			if (! GetWindowRect (m_hWnd, &rc))
				rc.bottom	= pt.y + GetSystemMetrics (SM_CYCURSOR) / 2 ;

			pToolTipUI->_MoveWindow (pt.x, rc.bottom, 0, 0) ;
			pToolTipUI->_SetText (m_ToolTipInfo.m_bufText + m_ToolTipInfo.m_rnOffsets [nTool]) ;
			DEBUGPRINTF ((TEXT ("Annotation: x:%d, y:%d, text:%d\n"), pt.x, rc.bottom, lstrlenW (m_ToolTipInfo.m_bufText + m_ToolTipInfo.m_rnOffsets [nTool]))) ;

			if (pToolTipUI->_IsActivep (&bShow)) {
				if (bShow)
					pToolTipUI->_Update () ;
				m_pTSF->_UpdateToolTipUI () ;
			} else {
				DWORD	dwElementId ;
				HRESULT	hr ;

				hr	= m_pTSF->_BeginToolTipUI (&dwElementId, &bShow) ;
				if (hr != E_NOINTERFACE && FAILED (hr))
					break ;
				if (hr == E_NOINTERFACE) {
					dwElementId	= -1 ;
					bShow		= TRUE ;
				}
				(void) pToolTipUI->_Open (dwElementId, bShow) ;
			}
			break ;
		}
	}
	return ;
}

BOOL
CSkkImeCandidateListUIElement::_ConfigureAnnotation (
	const TEXTREGION*		pAnnotation,
	int						iNumAnnotation)
{
	CImeDoc*				pDoc		= NULL ;
	const IMECANDIDATES*	pMyCand		= NULL ;
	HFONT					hOldFont	= NULL ;
	HDC						hDC			= NULL ;
	RECT					rcDraw ;
	int						nText ;
	SIZE					sz ;
	MYTOOLTIPINFO*			pToolTipInfo ;
	BOOL					bRetval		= FALSE ;

/*	if (_hwnd == NULL || ! IsWindow (_hwnd) || _hwndTT == NULL || ! IsWindow (_hwndTT))
		return	FALSE ;
	ShowWindow (_hwndTT, SW_HIDE) ;*/

	if (FAILED (_GetDocument (&pDoc)))
		return	FALSE ;
	pMyCand		= pDoc->GetStatusText () ;
	if (pMyCand == NULL || pMyCand->_iStyle != IMECANDSTYLE_READ)
		return	FALSE ;

	hDC			= GetDC (m_hWnd) ;
	if (!hDC)
		return	FALSE ;

	hOldFont	= _CheckNativeCharset (hDC) ;
	GetClientRect (m_hWnd, &rcDraw) ;

	/*	TOOL ��ǉ�����B*/
	pToolTipInfo	= &m_ToolTipInfo ;
	nText			= m_nTextLen ;
	if (nText > 0) {
		int					nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPCWSTR				pwText ;
		const TEXTREGION*	pAnnot ;
		TEXTMETRIC			tm ;
		int					nTool, nLeft ;
		WCHAR*				pwDest ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= rcDraw.top ;
		pwText		= m_wszText ;
		nTextPos	= 0 ;
		nTool		= 0 ;
		pwDest		= pToolTipInfo->m_bufText ;
		nLeft		= NBUFFER_ANNOTATION_TEXT ;
		sz.cx = sz.cy	= 0 ;

		while (y < rcDraw.bottom && 0 < nText && nLeft > 0 && nTool < MAX_ANNOTATION) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= rcDraw.left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
				if ((x + sz.cx) > rcDraw.right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;

			/* ���̍s�� hit ����BTEXTREGION �𗘗p����B*/
			pAnnot	= pAnnotation ;
			for (nAnnot = 0 ; nAnnot < iNumAnnotation && nLeft > 0 && nTool < MAX_ANNOTATION ; nAnnot ++, pAnnot ++) {
				LPCWSTR		lpstr ;
				int			nOffset, nLength, nIndex, nCandLen ;

				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32W (hDC, pwText, nOffset, &sz) ;
					nAnnotX	= rcDraw.left + sz.cx ;
				} else {
					nAnnotX	= rcDraw.left ;
				}
				GetTextExtentPoint32W (hDC, pwText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				/* �O�̂��߂Ɍ�₪���݂��邩�`�F�b�N����B*/
				if (pAnnot->m_nCandidate >= pMyCand->_iCount)
					continue ;

				lpstr		= (LPCWSTR)pMyCand->_vbufCandidate.GetBuffer () + *(pMyCand->_vbufCandidateIndex.GetBuffer () + pAnnot->m_nCandidate) ;
				nCandLen	= lstrlenW (lpstr) ;
				nIndex		= _HasWordAnnotation (lpstr, nCandLen) ;
				if (nIndex <= 0 || (nIndex + 1) >= nCandLen) {
					/* �����ρB*/
					continue ;
				}

				/*	(nAnnotX, y) - (nAnnotX + nAnnotWidth, y + nDY)
				 */
				pToolTipInfo->m_rrcHitArea [nTool].left		= nAnnotX ;
				pToolTipInfo->m_rrcHitArea [nTool].right	= nAnnotX + nAnnotWidth ;
				pToolTipInfo->m_rrcHitArea [nTool].top		= y ;
				pToolTipInfo->m_rrcHitArea [nTool].bottom	= y + nDY ;
				pToolTipInfo->m_rnOffsets  [nTool]			= pwDest - pToolTipInfo->m_bufText ;

				nLength		= lstrlenW (lpstr + nIndex + 1) ;
				nLength		= (nLength > nLeft)? (nLeft - 1) : nLength ;
				if (nLength > 0) {
					wcsncpy (pwDest, lpstr + nIndex + 1, nLength) ;
					pwDest [nLength]	= L'\0' ;
				}
				pToolTipInfo->m_rnLengths [nTool]			= nLength ;
				pwDest			+= nLength + 1 ;
				nTool			++ ;
			}
			x			+= sz.cx ;
			pwText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
		pToolTipInfo->m_nCount	= nTool ;
	} else {
		pToolTipInfo->m_nCount	= 0 ;
	}
	bRetval	= TRUE ;

	if (hDC != NULL) {
		if (hOldFont) 
			DeleteObject (SelectObject (hDC, hOldFont)) ;
		ReleaseDC (m_hWnd, hDC) ;
	}
	return	bRetval ;
}

BOOL	
CSkkImeCandidateListUIElement::_HandleMinibufferContextMenu ()
{
	int				nCmd ;
	unsigned int	uVK ;

	nCmd	= _PopupMinibufferContextMenu () ;
	switch (nCmd){
	case	IDM_CUT:
		uVK	= MYVK_MENU1 ;
		break ;
	case	IDM_PASTE:
		uVK	= MYVK_MENU2 ;
		break ;
	case	IDM_COPY:
		uVK	= MYVK_MENU3 ;
		break ;
	case	IDM_DELETE:
		uVK	= MYVK_MENU4 ;
		break ;
	default:
		uVK	= 0 ;
		break ;
	}
	if (uVK != 0) {
		HRESULT	hr	= _SendKeyDownToContext ((WPARAM) uVK, (LPARAM) 0) ;
		if (FAILED (hr))
			return	FALSE ;
	}
	return	TRUE ;
}

int	
CSkkImeCandidateListUIElement::_PopupMinibufferContextMenu ()
{
	HMENU		hMenu ;
	int			nCmd ;
	POINT		pos ;
	HCURSOR		hCursor ;

	hMenu		= 0 ;
	nCmd		= -1 ;
	GetCursorPos ((LPPOINT)&pos) ;

	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	hMenu	= _CreateClipboardMenu () ;
	if (hMenu != NULL){
		/* ���j���[��\�����āA�I��������B*/
		hCursor	= SetCursor (LoadCursor (NULL, IDC_ARROW)) ;
		nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, pos.x, pos.y, 0, m_hWnd, NULL) ;
		DestroyMenu (hMenu) ;
		(void)SetCursor (hCursor) ;
	}
	return	nCmd ;
}

HMENU
CSkkImeCandidateListUIElement::_CreateClipboardMenu ()
{
	static	MYMENUITEMINFO	myClipboardMenuItemInfoTbl []	= {
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_CUT,	TEXT ("�؂���"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_PASTE,	TEXT ("�\��t��"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_COPY,	TEXT ("�R�s�["), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_DELETE,	TEXT ("�폜"), },
	  { MIIM_TYPE,							MFT_SEPARATOR,	0,			NULL, },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDCANCEL,	TEXT ("�L�����Z��"), },
	} ;
	CImeDoc*				pDoc ;
	HMENU					hMenu ;
	MYMENUITEMINFO*			lpMyMenu ;
	MENUITEMINFO			menuItemInfo ;
	int						i, nStartPos, nEndPos ;
	BOOL					f ;

	if (FAILED (_GetDocument (&pDoc)))
		return	NULL ;

	hMenu		= CreatePopupMenu () ;
	if (!hMenu)
		return	NULL ;

	/* �܂����j���[�̍��ڂ�ݒ肷��B*/
	lpMyMenu	= myClipboardMenuItemInfoTbl ;
	for (i = 0 ; i < NELEMENTS (myClipboardMenuItemInfoTbl) ; i ++){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= lpMyMenu->m_fMask ;
		menuItemInfo.fType			= lpMyMenu->m_fType ;
		menuItemInfo.wID			= lpMyMenu->m_wID ;
		menuItemInfo.fState			= MFS_ENABLED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		//menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= lpMyMenu->m_dwTypeData ;
		menuItemInfo.cch			= lstrlen (menuItemInfo.dwTypeData) ;
		InsertMenuItem (hMenu, i, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		lpMyMenu	++ ;
	}
	/* �̈�I�����L���ł��邩�ǂ����𔻒肷��B*/
	f			= pDoc->GetSelectedRegion (&nStartPos, &nEndPos) ;
	if (!f || nStartPos == nEndPos) {
		EnableMenuItem (hMenu, 0, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 2, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 3, MF_BYPOSITION | MF_GRAYED) ;
	}
	/* �N���b�v�{�[�h�Ƀe�L�X�g�����݂��邩�ǂ����`�F�b�N����B*/
	if (!IsClipboardFormatAvailable (CF_TEXT))
		EnableMenuItem (hMenu, 1, MF_BYPOSITION | MF_GRAYED) ;
	return	hMenu ;
}

void
CSkkImeCandidateListUIElement::_HideToolTip ()
{
	CSkkImeToolTipUIElement*	pToolTipUI ;
	BOOL	bShow ;
	POINT	pt ;

	if (FAILED (_GetToolTipUI (&pToolTipUI)))
		return ;
	if (pToolTipUI->_IsActivep (&bShow)) {
		GetCursorPos (&pt) ;
		if (pt.x != m_ToolTipInfo.m_ptLastPos.x || pt.y != m_ToolTipInfo.m_ptLastPos.y) {
			if (bShow)
				pToolTipUI->_Close () ;
			m_pTSF->_EndToolTipUI () ;
		}
	}
	return ;
}

////////////////////////////////////////////////////////////////////////
//	private functions

static	int		srnMyColorIndex2SysColorIndexTbl []	= {
	COLOR_BTNFACE,
	COLOR_BTNTEXT,
	COLOR_ACTIVEBORDER,
	COLOR_ACTIVECAPTION,
	COLOR_CAPTIONTEXT,
	COLOR_APPWORKSPACE,
	COLOR_WINDOW,
	COLOR_WINDOWTEXT,
	COLOR_DESKTOP,
	COLOR_INFOBK,
	COLOR_INFOTEXT,
	COLOR_WINDOWTEXT,
	COLOR_MENU,
	COLOR_MENUTEXT,
	COLOR_HIGHLIGHTTEXT,
	COLOR_HIGHLIGHT,
	COLOR_INACTIVEBORDER,
	COLOR_INACTIVECAPTION,
	COLOR_INACTIVECAPTIONTEXT,
} ;

/*	�_���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDottedBrush [8]	= {
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
} ;

/*	�f�B�U���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDitherBrush [8]	= {
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
} ;

COLORREF
_GetImeColor (
	HWND	hwnd,
	int	nColor)
{
	HDC		hdc ;
	COLORREF	col ;

	switch (nColor) {
	case	MYCOLOR_TEXTAUTO:
	case	MYCOLOR_BACKAUTO:
		hdc	= GetDC (hwnd) ;
		col	= GetBkColor (hdc) ;
		ReleaseDC (hwnd, hdc) ;
		return	(nColor == MYCOLOR_BACKAUTO)? col : ~col ;
	case	MYCOLOR_BLACK:
		return	PALETTERGB (  0,   0,   0) ;
	case	MYCOLOR_DARKRED:
		return	PALETTERGB (128,   0,   0) ;
	case	MYCOLOR_DARKGREEN:
		return	PALETTERGB (  0, 128,   0) ;
	case	MYCOLOR_DARKYELLOW:
		return	PALETTERGB (128, 128,   0) ;
	case	MYCOLOR_DARKBLUE:
		return	PALETTERGB (  0,   0, 128) ;
	case	MYCOLOR_DARKPURPLE:
		return	PALETTERGB (128,   0, 128) ;
	case	MYCOLOR_DARKLIGHTBLUE:
		return	PALETTERGB (0,   128, 128) ;
	case	MYCOLOR_DARKGRAY:
		return	PALETTERGB (128, 128, 128) ;
	case	MYCOLOR_LIGHTGRAY:
		return	PALETTERGB (192, 192, 192) ;
	case	MYCOLOR_RED:
		return	PALETTERGB (255,   0,   0) ;
	case	MYCOLOR_GREEN:
		return	PALETTERGB (  0, 255,   0) ;
	case	MYCOLOR_YELLOW:
		return	PALETTERGB (255, 255,   0) ;
	case	MYCOLOR_BLUE:
		return	PALETTERGB (  0,   0, 255) ;
	case	MYCOLOR_PURPLE:
		return	PALETTERGB (255,   0, 255) ;
	case	MYCOLOR_LIGHTBLUE:
		return	PALETTERGB (  0, 255, 255) ;
	case	MYCOLOR_WHITE:
		return	PALETTERGB (255, 255, 255) ;
	default:
		if (MYCOLOR_SYSTEM <= nColor && nColor < MAX_MYCOLOR) {
			nColor	-= MYCOLOR_SYSTEM ;
			return	GetSysColor (srnMyColorIndex2SysColorIndexTbl [nColor]) ;
		}
		break ;
	}
	return	PALETTERGB (0, 0, 0) ;
}

HBRUSH
_GetImeLineBrush (
	HWND				hwnd,		/* [in] */
	int					nLineColor,	/* [in] */
	int					nLineType,	/* [in] */
	COLORREF*			pColBrush,	/* [out] */
	HBITMAP*			phBm,		/* [out] */
	int*				pnWidth)	/* [out] */
{
	COLORREF	colBrush ;
	HBRUSH		hBrush	= NULL ;
	HBITMAP	hBitmap	= NULL ;

	if (pColBrush == NULL || phBm == NULL || pnWidth == NULL) {
		return	NULL ;
	}

	colBrush	= _GetImeColor (hwnd, nLineColor) ;
	switch (nLineType) {
	case	MYLINE_SOLID:
		*pnWidth	= 1 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_DOTTED:
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDottedBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		*pnWidth	= 1 ;
		break ;
	case	MYLINE_THICK_SOLID:
		*pnWidth	= 2 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_THIN_DITHER:
		*pnWidth	= 2 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_THICK_DITHER:
		*pnWidth	= 3 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_NO:
	default:
		*pnWidth	= 0 ;
		break ;
	}
	*pColBrush	= colBrush ;
	*phBm		= hBitmap ;
	return	hBrush ;
}

