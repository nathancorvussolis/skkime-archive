/*	config.cpp
 *
 *	ITfFnConfigure implementation
 */
#include "globals.h"
#include <shlwapi.h>
#include "skimic.h"
#include "skkimmgr.h"
#include "confcommon.h"

//	�䂾�B
#define	DISPLAYNAME_DESC	L"SKKIME1.0(Disp)"

HRESULT
CSkkImeTextService::Show (
	HWND		hwndParent,
	LANGID		langid,
	REFGUID		rguidProfile)
{
	WCHAR					rszWindowsDir [MAX_PATH + 1] ;
	WCHAR					rszCmd [MAX_PATH + 1] ;
    STARTUPINFOW			si ;
    PROCESS_INFORMATION		pi ;
	int						nWindowsDir, n ;
	BOOL					fRetval ;

	/*	Secure Session �Ȃ�� Config �͎��s���Ă͂Ȃ�Ȃ��B*/
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
	if (_dwActivateFlag & TF_TMAE_SECUREMODE)
		return	E_FAIL ;
#endif
	if (langid != SKKIME_LANGID)
		return	E_FAIL ;

	nWindowsDir	= GetWindowsDirectoryW (rszWindowsDir, NELEMENTS (rszWindowsDir) - 1) ;
	rszWindowsDir [nWindowsDir]		= L'\0' ;
	n			= wnsprintfW (rszCmd, NELEMENTS (rszCmd) - 1, L"%s" L"\\" PROGRAMF_DIR L"\\" SKKIMEProg_S_DIR L"\\" SKKIMEConfigProg, rszWindowsDir) ;
	rszCmd [n]	= L'\0' ;

	ZeroMemory (&si, sizeof(si)) ;
	si.cb	= sizeof (si) ;
	if (! CreateProcessW (rszCmd, L"", NULL, NULL, FALSE, 0, NULL, rszWindowsDir, &si, &pi)) {
		fRetval	= FALSE ;
	} else {
		/* �҂��Ȃ��B(void) WaitForSingleObject (pi.hProcess, INFINITE) ;*/
		/* �s�v�ɂȂ����n���h��������B*/
		CloseHandle (pi.hProcess) ;
		CloseHandle (pi.hThread) ;
		fRetval	= TRUE ;
	} 

	/*	keyboard layout �� unload ����ׂ��Ȃ̂��ۂ���������Ȃ��B
	 *	����ׂ����낤���H
	 *	�m���ɂ��̒i�K�ł� hKL �͂����s�v�����c�B
	if (fRetval && _pSkkIme != NULL) 
		_pSkkIme->UpdateConfig () ;

	 */
	return fRetval? S_OK : E_FAIL ;

	UNREFERENCED_PARAMETER (hwndParent) ;
	UNREFERENCED_PARAMETER (rguidProfile) ;
}

STDAPI
CSkkImeTextService::GetDisplayName (
	BSTR*			pbstrName)
{
	if (pbstrName == NULL)
		return	E_INVALIDARG ;
	
	*pbstrName	= SysAllocString (DISPLAYNAME_DESC) ;
	return	(*pbstrName == NULL)? E_OUTOFMEMORY : S_OK ;
}

