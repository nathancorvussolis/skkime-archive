/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#define	REGPATH_ROMAKANARULELIST	REGPATH_SKKIME_BASE TEXT("\\RomaKanaRuleList")
#define	MAX_LENGTH_ROMAKANARULE_STATE	(64)
#define	MAX_LENGTH_ROMAKANARULE_HOUTPUT	(64)
#define	MAX_LENGTH_ROMAKANARULE_KOUTPUT	(64)

typedef struct tagSKKROMAKANARULE {
	LPTSTR			state ;
	LPTSTR			next ;
	LPTSTR			houtput ;
	LPTSTR			koutput ;
}	SKKROMAKANARULE, NEAR *PSKKROMAKANARULE, FAR *LPSKKROMAKANARULE ;

typedef struct {
	TCHAR		m_strState     [MAX_LENGTH_ROMAKANARULE_STATE] ;
	TCHAR		m_strNextState [MAX_LENGTH_ROMAKANARULE_STATE] ;
	TCHAR		m_strHoutput   [MAX_LENGTH_ROMAKANARULE_HOUTPUT] ;
	TCHAR		m_strKoutput   [MAX_LENGTH_ROMAKANARULE_KOUTPUT] ;
}	TDlgEditRomaKanaRuleArg ;

static	INT_PTR	skkimeConfig_dlgRomaKanaRuleOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgRomaKanaRuleOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgRomaKanaRuleOnCommand		(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL	skkimeConfig_editRomaKanaRule				(HWND, int, int) ;
static	INT_PTR CALLBACK		skkimeConfig_dlgEditRomaKanaRule	(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL	skkimeConfig_initRomaKanaRuleList	(LPCTSTR, SKKROMAKANARULENODE**, SKKROMAKANARULE*, int) ;
static	BOOL	skkimeConfig_updateRomaKanaRuleList	(LPCTSTR, SKKROMAKANARULENODE*) ;
static	SKKROMAKANARULENODE*	skkimeConfig_newRomaKanaRuleNode	(int, int, int, int) ;
static	SKKROMAKANARULENODE*	skkimeConfig_findRomaKanaRuleNode	(SKKROMAKANARULENODE**, LPCTSTR) ;
static	BOOL	skkimeConfig_registerRomaKanaRuleNode	(SKKROMAKANARULENODE**, SKKROMAKANARULENODE*) ;
static	BOOL	skkimeConfig_unregisterRomaKanaRuleNode	(SKKROMAKANARULENODE**, SKKROMAKANARULENODE*) ;

static	SKKROMAKANARULE		srDefaultRomaKanaRuleList [] = {
	{ TEXT ("nn"),	TEXT (""),	TEXT ("��"),	TEXT ("��")},
	{ TEXT ("n'"),	TEXT (""),	TEXT ("��"),	TEXT ("��")},
} ;

/*========================================================================
 *	public functions
 */
BOOL
skkimeConfig_InitializeRomaKanaRuleList (
	SKKROMAKANARULENODE**	plstTop)
{
	if (plstTop == NULL)
		return	FALSE ;

	return	skkimeConfig_initRomaKanaRuleList (REGPATH_ROMAKANARULELIST, plstTop, srDefaultRomaKanaRuleList, NELEMENTS (srDefaultRomaKanaRuleList)) ;
}

BOOL
skkimeConfig_UpdateRomaKanaRuleList (
	SKKROMAKANARULENODE*	lstTop)
{
	if (lstTop == NULL)
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_UpdateRomaKanaRuleList (%p)\n"), lstTop)) ;
	return	skkimeConfig_updateRomaKanaRuleList (REGPATH_ROMAKANARULELIST, lstTop) ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgRomaKanaRuleProc (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (message) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgRomaKanaRuleOnInitDialog (hDlg, message, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgRomaKanaRuleOnNotify (hDlg, message, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgRomaKanaRuleOnCommand (hDlg, message, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;

	UNREFERENCED_PARAMETER (wParam) ;
}

/*========================================================================
 *	private functions
 */
INT_PTR
skkimeConfig_dlgRomaKanaRuleOnInitDialog (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	static LPTSTR	rszColumnTitle []	= {
		TEXT("�����"), TEXT("�����"), TEXT("�����o��"), TEXT("�Љ����o��"),
	} ;
	static int		rnColumnWidth []	= {
		60, 60, 70, 80,
	} ;
	LPPROPSHEETPAGE			pPropSheet ;
	SkkimeConfigArg*		pConfArg ;
	HWND					hwndRomaKanaRule ;
	SKKROMAKANARULENODE*	pNode ;
	int						n ;
	LV_COLUMN				lvColumn;
	LVITEM					lvI ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	hwndRomaKanaRule	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndRomaKanaRule != NULL) {
		ListView_DeleteAllItems (hwndRomaKanaRule) ;
		ListView_SetExtendedListViewStyle (hwndRomaKanaRule, LVS_EX_FULLROWSELECT) ;

		lvColumn.mask	= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt	= LVCFMT_LEFT ;

		// Insert the five columns in the list view.
		for (n = 0; n < 4 ; n ++) {
			lvColumn.pszText	= rszColumnTitle [n] ;
			lvColumn.cx			= rnColumnWidth [n] ;
			ListView_InsertColumn (hwndRomaKanaRule, n, &lvColumn) ;
		}

		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ; 
		lvI.stateMask	= 0 ;
		pNode			= pConfArg->m_lstRomaKanaRule ;
		n				= 0 ;
		while (pNode != NULL) {
			int	nItem ;
			lvI.iItem		= n ;
			lvI.iImage		= n ;
			lvI.iSubItem	= 0 ;
			lvI.lParam		= (LPARAM) pNode ;
			lvI.pszText		= pNode->m_strState ;
			nItem	= ListView_InsertItem (hwndRomaKanaRule, &lvI) ;
			if (nItem != -1) {
				ListView_SetItemText (hwndRomaKanaRule, nItem, 1, pNode->m_strNext) ;
				ListView_SetItemText (hwndRomaKanaRule, nItem, 2, pNode->m_strHoutput) ;
				ListView_SetItemText (hwndRomaKanaRule, nItem, 3, pNode->m_strKoutput) ;
			}
			pNode	= pNode->m_pNext ;
			n		++ ;
		}
	}
	return	TRUE ;
	UNREFERENCED_PARAMETER (message) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgRomaKanaRuleOnCommand (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	WORD	wNotifyCode ;
	WORD	wID ;
	HWND	hwndCtl ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	DEBUGPRINTF ((TEXT ("HWND:(%lx), ID(%u), Notify(%u), CTLWND:(%lx)\n"),
				  hDlg, wID, wNotifyCode, hwndCtl)) ;

	switch (wID) {
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
	case	IDC_BUTTON_DELETE:
		if (wNotifyCode == BN_CLICKED) {
			int	nItem	= -1 ;

			if (wID != IDC_BUTTON_INSERT) {
				HWND	hwndLV ;

				hwndLV	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
				if (hwndLV == NULL)
					return	1 ;
				nItem	= ListView_GetSelectionMark (hwndLV) ;
			}
			skkimeConfig_editRomaKanaRule (hDlg, nItem, wID) ;
			return	0 ;
		}
		break ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (message) ;
}

INT_PTR
skkimeConfig_dlgRomaKanaRuleOnNotify (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	NMHDR	FAR*		pNMHDR	= (NMHDR *) lParam ;
	static TMYMENUITEM		rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ǉ�"), IDC_BUTTON_INSERT, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ύX"), IDC_BUTTON_EDIT, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�폜"), IDC_BUTTON_DELETE, },
	} ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_ROMAKANARULE:
	{
		if (pNMHDR->code == NM_RCLICK) {
			NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;
			int	n ;

			n	= skkimeConfig_PopupMenu (hDlg, rmi, NELEMENTS (rmi)) ;
			DEBUGPRINTF ((TEXT ("NM: item(%d), lParam(%d)\n"), pNM->iItem, pNM->lParam)) ;
			if (n > 0) 
				skkimeConfig_editRomaKanaRule (hDlg, ((n != IDC_BUTTON_INSERT)? pNM->iItem : -1), n) ;
			DEBUGPRINTF ((TEXT ("TrackPopupMenu returns %d\n"), n)) ;
		}
		return	FALSE ;
	}
	default:
		switch (pNMHDR->code){
		case PSN_SETACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
			return	TRUE ;

		case PSN_APPLY:
		{
			if (skkimeConfig_UpdateRomaKanaRuleList (pConfArg->m_lstRomaKanaRule)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;
		}
		case PSN_RESET:
		case PSN_HELP:
			break ;

		default:
			return FALSE ;
		}
		return	TRUE ;
	}

	UNREFERENCED_PARAMETER (message) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
skkimeConfig_editRomaKanaRule (
	HWND		hDlg,
	int		nItem,
	int		nCommand)
{
	LPPROPSHEETPAGE			pPropSheet ;
	SkkimeConfigArg*		pConfArg ;
	HWND					hwndLV ;
	SKKROMAKANARULENODE**	plstTop ;
	SKKROMAKANARULENODE*	pNode ;
	LVITEM					lvI ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	hwndLV		= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndLV == NULL || pConfArg == NULL)
		return	FALSE ;
	plstTop		= &pConfArg->m_lstRomaKanaRule ;

	if (nItem >= 0) {
		lvI.mask		= LVIF_PARAM ;
		lvI.state		= 0 ;
		lvI.stateMask	= 0 ;
		lvI.iItem		= nItem ;
		lvI.iSubItem	= 0 ;
		lvI.pszText		= 0 ;
		lvI.cchTextMax	= 0 ;
		if (! ListView_GetItem (hwndLV, &lvI)) {
			pNode		= NULL ;
		} else {
			pNode		= (SKKROMAKANARULENODE*) lvI.lParam ;
		}
	} else {
		pNode	= NULL ;
	}
	switch (nCommand) {
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
	{
		SKKROMAKANARULENODE*	pNewNode ;
		int			nRetval, nStateLen, nNextLen, nHoutputLen, nKoutputLen ;
		BOOL			f	= FALSE ;
		TDlgEditRomaKanaRuleArg	arg ;

		if (pNode != NULL) {
			lstrcpyn (arg.m_strState,     pNode->m_strState,   MAX_LENGTH_ROMAKANARULE_STATE) ;
			lstrcpyn (arg.m_strNextState, pNode->m_strNext,    MAX_LENGTH_ROMAKANARULE_STATE) ;
			lstrcpyn (arg.m_strHoutput,   pNode->m_strHoutput, MAX_LENGTH_ROMAKANARULE_HOUTPUT) ;
			lstrcpyn (arg.m_strKoutput,   pNode->m_strKoutput, MAX_LENGTH_ROMAKANARULE_KOUTPUT) ;
			arg.m_strState     [MAX_LENGTH_ROMAKANARULE_STATE   - 1]	= TEXT ('\0') ;
			arg.m_strNextState [MAX_LENGTH_ROMAKANARULE_STATE   - 1]	= TEXT ('\0') ;
			arg.m_strHoutput   [MAX_LENGTH_ROMAKANARULE_HOUTPUT - 1]	= TEXT ('\0') ;
			arg.m_strKoutput   [MAX_LENGTH_ROMAKANARULE_KOUTPUT - 1]	= TEXT ('\0') ;
		} else {
			arg.m_strState     [0]	= TEXT ('\0') ;
			arg.m_strNextState [0]	= TEXT ('\0') ;
			arg.m_strHoutput   [0]	= TEXT ('\0') ;
			arg.m_strKoutput   [0]	= TEXT ('\0') ;
		}
		nRetval	= DialogBoxParam (pConfArg->m_hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_ROMAKANARULE), hDlg, skkimeConfig_dlgEditRomaKanaRule, (LPARAM) &arg) ;
		if (nRetval != IDOK) 
			break ;

		nStateLen	= lstrlen (arg.m_strState)     + 1 ;
		nNextLen	= lstrlen (arg.m_strNextState) + 1 ;
		nHoutputLen	= lstrlen (arg.m_strHoutput)   + 1 ;
		nKoutputLen	= lstrlen (arg.m_strKoutput)   + 1 ;
		if (nStateLen <= 1) {
			DEBUGPRINTF ((TEXT ("fatal: state is empty.\n"))) ;
			return	FALSE ;
		}
		pNewNode	= skkimeConfig_newRomaKanaRuleNode (nStateLen, nNextLen, nHoutputLen, nKoutputLen) ;
		lstrcpy (pNewNode->m_strState,   arg.m_strState) ;
		lstrcpy (pNewNode->m_strNext,    arg.m_strNextState) ;
		lstrcpy (pNewNode->m_strHoutput, arg.m_strHoutput) ;
		lstrcpy (pNewNode->m_strKoutput, arg.m_strKoutput) ;

		/*	������Ԃ𕡐���邱�Ƃ͂ł��Ȃ��B*/
		pNode	= skkimeConfig_findRomaKanaRuleNode (plstTop, arg.m_strState) ;

		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ; 
		lvI.stateMask	= 0 ;
		lvI.iImage		= 0 ;
		lvI.iSubItem	= 0 ;
		lvI.lParam		= (LPARAM) pNewNode ;
		if (! skkimeConfig_registerRomaKanaRuleNode (plstTop, pNewNode)) {
			DEBUGPRINTF ((TEXT ("fatal: failed in registering roma-kana-rule-node(%p)\n"),
						  pNewNode)) ;
			FREE (pNewNode) ;
			return	FALSE ;
		}
		lvI.pszText		= pNewNode->m_strState ;
		if (pNode != NULL) {
			LVFINDINFO		lvfi ;

			lvfi.flags		= LVFI_PARAM ;
			lvfi.lParam		= (LPARAM) pNode ;
			nItem			= ListView_FindItem (hwndLV, -1, &lvfi) ;
			if (nItem >= 0) {
				lvI.iItem		= nItem ;
				f	= ListView_SetItem (hwndLV, &lvI) ;
			}
			skkimeConfig_unregisterRomaKanaRuleNode (plstTop, pNode) ;
			FREE (pNode) ;
		} else {
			nItem	= ListView_GetItemCount (hwndLV) ;
			nItem	= ListView_InsertItem (hwndLV, &lvI) ;
			f		= (nItem != -1) ;
		}
		if (f) {
			/*	�e�L�X�g�̐ݒ�B*/
			ListView_SetItemText (hwndLV, nItem, 1, (LPTSTR) pNewNode->m_strNext) ;
			ListView_SetItemText (hwndLV, nItem, 2, (LPTSTR) pNewNode->m_strHoutput) ;
			ListView_SetItemText (hwndLV, nItem, 3, (LPTSTR) pNewNode->m_strKoutput) ;
		}
		PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		break ;
	}
	case	IDC_BUTTON_DELETE:
		if (pNode == NULL || nItem < 0) {
			DEBUGPRINTF ((TEXT ("editRomaKanaRule: no row is selected\n"))) ;
			return	FALSE ;
		}
		ListView_DeleteItem (hwndLV, nItem) ;
		skkimeConfig_unregisterRomaKanaRuleNode (plstTop, pNode) ;
		FREE (pNode) ;
		PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

INT_PTR CALLBACK
skkimeConfig_dlgEditRomaKanaRule (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	TDlgEditRomaKanaRuleArg*	pArg ;
	HWND	hwndState, hwndNext, hwndHoutput, hwndKoutput ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

		pArg		= (TDlgEditRomaKanaRuleArg*) lParam ;
		hwndState	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_STATE) ;
		hwndNext	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_NEXTSTATE) ;
		hwndHoutput	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_HOUTPUT) ;
		hwndKoutput	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_KOUTPUT) ;

		if (pArg == NULL || hwndState == NULL || hwndNext == NULL ||
			hwndHoutput == NULL || hwndKoutput == NULL) {
			DEBUGPRINTF ((TEXT ("fatal: can't initialize dialog: IDD_DIALOG_EDIT_ROMAKANARULE\n"))) ;
			return	TRUE ;
		}
		SendMessage (hwndState,   EM_LIMITTEXT, (WPARAM) MAX_LENGTH_ROMAKANARULE_STATE, 0) ;
		SendMessage (hwndNext,    EM_LIMITTEXT, (WPARAM) MAX_LENGTH_ROMAKANARULE_STATE, 0) ;
		SendMessage (hwndHoutput, EM_LIMITTEXT, (WPARAM) MAX_LENGTH_ROMAKANARULE_HOUTPUT, 0) ;
		SendMessage (hwndKoutput, EM_LIMITTEXT, (WPARAM) MAX_LENGTH_ROMAKANARULE_KOUTPUT, 0) ;
		SetWindowText (hwndState,   pArg->m_strState) ;
		SetWindowText (hwndNext,    pArg->m_strNextState) ;
		SetWindowText (hwndHoutput, pArg->m_strHoutput) ;
		SetWindowText (hwndKoutput, pArg->m_strKoutput) ;
		return	TRUE ;
	}
	case	WM_COMMAND:
		switch (LOWORD (wParam)) {
		case	IDOK:
		{
			pArg		= (TDlgEditRomaKanaRuleArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			hwndState	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_STATE) ;
			hwndNext	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_NEXTSTATE) ;
			hwndHoutput	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_HOUTPUT) ;
			hwndKoutput	= GetDlgItem (hDlg, IDC_EDIT_ROMAKANARULE_KOUTPUT) ;
			GetWindowText (hwndState,   pArg->m_strState,     MAX_LENGTH_ROMAKANARULE_STATE) ;
			GetWindowText (hwndNext,    pArg->m_strNextState, MAX_LENGTH_ROMAKANARULE_STATE) ;
			GetWindowText (hwndHoutput, pArg->m_strHoutput,   MAX_LENGTH_ROMAKANARULE_HOUTPUT) ;
			GetWindowText (hwndKoutput, pArg->m_strKoutput,   MAX_LENGTH_ROMAKANARULE_KOUTPUT) ;
			if (pArg->m_strState [0] == TEXT ('\0'))
				wParam	= IDCANCEL ;
		}
		/*	fall through */
		case	IDCANCEL:
			EndDialog (hDlg, wParam) ;
			return	TRUE ;
		default:
			break ;
		}
		break ;
	default:
		break ;
	}
	return	FALSE ;
}

/*	. . .   .
 *	RoMaKanaRule
 */
BOOL
skkimeConfig_initRomaKanaRuleList (
	LPCTSTR					pstrSubKey,
	SKKROMAKANARULENODE**	plstRuleListTop,
	SKKROMAKANARULE*		pDefaultRuleList,
	int						nDefaultRuleList)
{
	HKEY				hSubKey ;
	TCHAR				szRegPathInfo [MAX_PATH] ;
	TCHAR				rbyData [MAX_REGVALUE_SIZE] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	SKKROMAKANARULENODE*	pNode ;
	SKKROMAKANARULENODE*	pLastNode ;
	int		nIndex, nStateLen, nNextLen, nHoutputLen, nKoutputLen ;
	LONG		lResult ;

	pLastNode	= NULL ;
	pNode		= NULL ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		BOOL	fError	= FALSE ;

		/*	���[�}�������ϊ��e�[�u�����o�^����Ă���̂Ȃ�c�B*/
		for (nIndex = 0 ; ; nIndex ++) {
			LPCTSTR	strState, strNext, strHoutput, strKoutput ;

			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= sizeof (rbyData) ;
			lResult	= RegEnumValue (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;

			/*	szRegPathInfo = "nn" �̂悤�� szRegPathInfo ���u����ԁv�ɑ�������B
			 *	���R�� (�����, �����, �o��) �Ȃ̂ŁA����Ԃ������d�Ȃ邱�Ƃ͂���
			 *	�Ă͂Ȃ�Ȃ�����B
			 *	����Ԃ��u��v�͂��蓾��B
			 */
			lResult	= RegQueryValueEx (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ)
				continue ;
			/*	Too big value. */
			if (cbData >= sizeof (rbyData)) 
				continue ;
			cbData	= sizeof (rbyData) ;
			(void) RegQueryValueEx (hSubKey, szRegPathInfo, NULL, NULL, (BYTE *)rbyData, &cbData) ;
			
			nStateLen	= nNextLen	= nHoutputLen	= nKoutputLen	= 0 ;
			strState	= strNext	= strHoutput	= strKoutput	= NULL ;
			if (TEXT ('0') <= szRegPathInfo [0] && szRegPathInfo [0] <= TEXT ('9')) {
				nStateLen	= lstrlen ((LPCTSTR) rbyData) ;
				nNextLen	= (nStateLen   > 0)? lstrlen ((LPCTSTR) rbyData + nStateLen + 1) : 0 ;
				nHoutputLen	= (nNextLen    > 0)? lstrlen ((LPCTSTR) rbyData + nStateLen + 1 + nNextLen + 1) : 0 ;
				if (nStateLen <= 0 || nNextLen < 1 || nHoutputLen < 1) {
					fError	= TRUE ;
					break ;
				}
				/*	nKoutputLen == 0 �̏ꍇ�ɂ́A�]���� assoc rule �̉\��������B
				 *	�]���� (next, hira, kata) �� 3 ���������Acase ���l������
				 *	(now, next, hira, kata) �� 4 �g�ɂ����̂ŁB
				 */
				nKoutputLen	= (nHoutputLen > 0)? lstrlen ((LPCTSTR) rbyData + nStateLen + 1 + nNextLen + 1 + nHoutputLen + 1) : 0 ;
				strState	= (LPCTSTR) rbyData ;
				strNext		= (LPCTSTR) rbyData + nStateLen + 1 ;
				strHoutput	= (LPCTSTR) rbyData + nStateLen + 1 + nNextLen + 1 ;
				strKoutput	= (LPCTSTR) rbyData + nStateLen + 1 + nNextLen + 1 + nHoutputLen + 1 ;
			}
			if (nKoutputLen <= 0) {
				nStateLen	= lstrlen ((LPCTSTR) szRegPathInfo) ;
				nNextLen	= lstrlen ((LPCTSTR) rbyData) ;
				nHoutputLen	= (nNextLen    > 0)? lstrlen ((LPCTSTR) rbyData + nNextLen + 1) : 0 ;
				nKoutputLen	= (nHoutputLen > 0)? lstrlen ((LPCTSTR) rbyData + nNextLen + 1 + nHoutputLen + 1) : 0 ;
				strState	= (LPCTSTR) szRegPathInfo ;
				strNext		= (LPCTSTR) rbyData ;
				strHoutput	= (LPCTSTR) rbyData + nNextLen + 1 ;
				strKoutput	= (LPCTSTR) rbyData + nNextLen + 1 + nHoutputLen + 1 ;
			}
			if (nStateLen <= 0 || nNextLen < 1 || nHoutputLen < 1 || nKoutputLen < 1) {
				fError	= TRUE ;
				break ;
			}

			pNode		= skkimeConfig_newRomaKanaRuleNode (nStateLen, nNextLen, nHoutputLen, nKoutputLen) ;
			if (pNode == NULL) {
				fError	= TRUE ;
				break ;
			}
			lstrcpy (pNode->m_strState,		strState) ;
			lstrcpy (pNode->m_strNext,		strNext    + 1) ;
			lstrcpy (pNode->m_strHoutput,	strHoutput + 1) ;
			lstrcpy (pNode->m_strKoutput,	strKoutput + 1) ;

			pNode->m_pPrev	= pLastNode ;
			if (pLastNode != NULL)
				pLastNode->m_pNext	= pNode ;
			pLastNode		= pNode ;
		}
		RegCloseKey (hSubKey) ;
		if (fError)
			return	FALSE ;
	} else if (pDefaultRuleList != NULL && nDefaultRuleList > 0) {
		SKKROMAKANARULE*	pRule ;

		pRule	= pDefaultRuleList ;
		for (nIndex = 0 ; nIndex < nDefaultRuleList ; nIndex ++) {
			nStateLen	= lstrlen (pRule->state) ;
			nNextLen	= lstrlen (pRule->next)    + 1 ;
			nHoutputLen	= lstrlen (pRule->houtput) + 1 ;
			nKoutputLen	= lstrlen (pRule->koutput) + 1 ;
			pNode		= skkimeConfig_newRomaKanaRuleNode (nStateLen, nNextLen, nHoutputLen, nKoutputLen) ;
			if (pNode == NULL)
				return	FALSE ;
			lstrcpy (pNode->m_strState,	pRule->state) ;
			lstrcpy (pNode->m_strNext,	pRule->next) ;
			lstrcpy (pNode->m_strHoutput,	pRule->houtput) ;
			lstrcpy (pNode->m_strKoutput,	pRule->koutput) ;

			pNode->m_pPrev	= pLastNode ;
			if (pLastNode != NULL)
				pLastNode->m_pNext	= pNode ;
			pLastNode		= pNode ;

			pRule	++ ;
		}
	}
	if (pLastNode != NULL) {
		pNode	= pLastNode ;
		while (pNode->m_pPrev != NULL)
			pNode	= pNode->m_pPrev ;
		*plstRuleListTop	= pNode ;
	} else {
		*plstRuleListTop	= pNode ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_updateRomaKanaRuleList (
	LPCTSTR					pstrSubKey,
	SKKROMAKANARULENODE*	lstRuleListTop)
{
	SKKROMAKANARULENODE*	pNode ;
	int	nStateLen, nNextLen, nHoutLen, nKoutLen, nTotal, n ;
	TCHAR			szData [MAX_REGVALUE_SIZE] ;
	HKEY			hSubKey ;
	TCHAR			buf [16] ;

	if (! skkimeConfig_CreateKey (pstrSubKey, TRUE, &hSubKey))
		return	FALSE ;

	pNode	= lstRuleListTop ;
	n		= 1 ;
	while (pNode != NULL) {
		/* MULTI_SZ �ƁB*/
		nStateLen	= lstrlen (pNode->m_strState) ;
		nNextLen	= lstrlen (pNode->m_strNext) ;
		nHoutLen	= lstrlen (pNode->m_strHoutput) ;
		nKoutLen	= lstrlen (pNode->m_strKoutput) ;
		nTotal		= nStateLen + nNextLen + nHoutLen + nKoutLen ;
		if (nStateLen > 0 && 0 <= nTotal && nTotal < (MAX_REGVALUE_SIZE - (4 + 3 + 1))) {
			LPTSTR	pDest	= szData ;
			DEBUGPRINTF ((TEXT ("State(%s), Next(%s), H(%s), K(%s)\n"),
						  pNode->m_strState, pNode->m_strNext,
						  pNode->m_strHoutput, pNode->m_strKoutput)) ;
			lstrcpy (pDest, pNode->m_strState) ;		pDest	+= nStateLen + 1 ;
			lstrcpy (pDest, TEXT ("_")) ;			pDest	++ ;
			lstrcpy (pDest, pNode->m_strNext) ;		pDest	+= nNextLen + 1 ;
			lstrcpy (pDest, TEXT ("_")) ;			pDest	++ ;
			lstrcpy (pDest, pNode->m_strHoutput) ;	pDest	+= nHoutLen + 1 ;
			lstrcpy (pDest, TEXT ("_")) ;			pDest	++ ;
			lstrcpy (pDest, pNode->m_strKoutput) ;	pDest	+= nKoutLen + 1 ;
			*pDest	= TEXT ('\0') ;
			wnsprintf (buf, NELEMENTS (buf) - 1, TEXT ("%d"), n) ;
			buf [NELEMENTS (buf) - 1]	= TEXT ('\0') ;
			if (RegSetValueEx (hSubKey, buf, 0, REG_MULTI_SZ, (BYTE *)szData, sizeof (TCHAR) * (nTotal + 4 + 3 + 1)) != ERROR_SUCCESS) {
				DEBUGPRINTF ((TEXT ("RegSetValueEx: failed (\"%s\", \"%s\")\n"),
							  pNode->m_strState, szData)) ;
				break ;
			}
			n	++ ;
		}
		pNode	= pNode->m_pNext ;
	}
	RegCloseKey (hSubKey) ;
	return	pNode == NULL ;
}

SKKROMAKANARULENODE*
skkimeConfig_newRomaKanaRuleNode (
	int			nStateLen,
	int			nNextLen,
	int			nHoutputLen,
	int			nKoutputLen)
{
	SKKROMAKANARULENODE*	pNode ;

	pNode		= MALLOC (sizeof (SKKROMAKANARULENODE) + sizeof (TCHAR) * (nStateLen + 1 + nNextLen + nHoutputLen + nKoutputLen)) ;
	if (pNode == NULL)
		return	NULL ;

	pNode->m_strState		= (LPTSTR)(pNode + 1) ;
	pNode->m_strNext		= pNode->m_strState   + nStateLen + 1 ;
	pNode->m_strHoutput		= pNode->m_strNext    + nNextLen ;
	pNode->m_strKoutput		= pNode->m_strHoutput + nHoutputLen ;
	pNode->m_pPrev			= NULL ;
	pNode->m_pNext			= NULL ;
	return	pNode ;
}

SKKROMAKANARULENODE*
skkimeConfig_findRomaKanaRuleNode (
	SKKROMAKANARULENODE**	plstTop,
	LPCTSTR					strState)
{
	SKKROMAKANARULENODE*	pNode ;

	if (plstTop == NULL || strState == NULL) 
		return	NULL ;

	pNode	= *plstTop ;
	while (pNode != NULL) {
		if (pNode->m_strState != NULL && !lstrcmp (pNode->m_strState, strState))
			return	pNode ;
		pNode	= pNode->m_pNext ;
	}
	return	NULL ;
}

BOOL
skkimeConfig_registerRomaKanaRuleNode (
	SKKROMAKANARULENODE**	plstTop,
	SKKROMAKANARULENODE*	pNode)
{
	SKKROMAKANARULENODE*	pNextNode ;

	if (plstTop == NULL || pNode == NULL)
		return	FALSE ;

	pNextNode		= *plstTop ;
	pNode->m_pNext	= pNextNode ;
	pNode->m_pPrev	= NULL ;
	if (pNextNode != NULL)
		pNextNode->m_pPrev	= pNode ;
	*plstTop		= pNode ;
	return	TRUE ;
}

BOOL
skkimeConfig_unregisterRomaKanaRuleNode (
	SKKROMAKANARULENODE**	plstTop,
	SKKROMAKANARULENODE*	pNode)
{
	SKKROMAKANARULENODE*	pPrevNode ;
	SKKROMAKANARULENODE*	pNextNode ;

	if (pNode == NULL || plstTop == NULL)
		return	FALSE ;

	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode == NULL) {
		if (*plstTop != pNode) {
			DEBUGPRINTF ((TEXT ("fatal: invalid node? listtop(%p) != node(%p)\n"),
						  *plstTop, pNode)) ;
			return	FALSE ;
		}
		*plstTop	= pNextNode ;
	} else {
		pPrevNode->m_pNext	= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pPrevNode ;
	}
	pNode->m_pPrev	= NULL ;
	pNode->m_pNext	= NULL ;
	return	TRUE ;

}

