#if !defined (NO_TSF)
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

/*	����o�[�܂��̐ݒ�B
 *
 */
#define	REGPATH_CICERO	REGPATH_SKKIME_BASE TEXT("\\CICERO")

typedef struct {
	int			m_iItem ;
	int			m_iSubItem ;
	int			m_nIndex ;
	BOOL		m_fVisible ;
	int			m_rnIndex [2] ;
}	INPLACECBCONF ;

static	BOOL	skkimeConfig_initCICERO		(LPCTSTR, CICEROCONFIG*) ;
static	BOOL	skkimeConfig_updateCICERO	(LPCTSTR, CICEROCONFIG*) ;

static	INT_PTR	skkimeConfig_dlgCiceroOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgCiceroOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgCiceroOnCommand		(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL	dlgCicero_onNMClickLVLangBarIcon	(HWND, LPNMITEMACTIVATE, SkkimeConfigArg*, CICEROCONFIG*) ;
static	BOOL	dlgCicero_onBeginLabelEdit	(HWND, NMLVDISPINFO*, SkkimeConfigArg*, CICEROCONFIG*) ;
static	BOOL	dlgCicero_killFocusInPlaceCB(HWND, HWND, SkkimeConfigArg*, CICEROCONFIG*) ;
static	BOOL	dlgCicero_onEndLabelEdit	(HWND, NMLVDISPINFO*, SkkimeConfigArg*, CICEROCONFIG*) ;
static	BOOL	dlgCicero_defNotifyProc		(HWND, NMHDR*, SkkimeConfigArg*) ;
static	int		dlgCicero_getIndexWithItem	(HWND, int) ;

BOOL
skkimeConfig_InitializeCICERO (
	CICEROCONFIG*	pConfCICERO)
{
	if (pConfCICERO == NULL)
		return	FALSE ;
	return	skkimeConfig_initCICERO (REGPATH_CICERO, pConfCICERO) ;
}	

BOOL
skkimeConfig_UpdateCICERO (
	CICEROCONFIG*	pConfCICERO)
{
	if (pConfCICERO == NULL)
		return	FALSE ;

	if (skkimeConfig_updateCICERO (REGPATH_CICERO, pConfCICERO)) {
#if ! defined (CONFIG_UNIT_TEST)
		bTSF_UpdateLanguageBar () ;	/* ... */
#endif
		return	TRUE ;
	}
	return	FALSE ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgCiceroProc (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (message) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgCiceroOnInitDialog (hDlg, message, wParam, lParam) ;

	case	WM_NOTIFY:
		return	skkimeConfig_dlgCiceroOnNotify (hDlg, message, wParam, lParam) ;

	case	WM_COMMAND:
		return	skkimeConfig_dlgCiceroOnCommand (hDlg, message, wParam, lParam) ;

	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================*
 */
INT_PTR
skkimeConfig_dlgCiceroOnInitDialog (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND				hdlgList ;
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	CICEROCONFIG*		pConfCicero ;
	static struct {
		LPTSTR	m_strTitle ;
		int		m_nWidth ;
	}	srColumnInfo []	= {
		{ TEXT ("�A�C�R��"),		130, },
		{ TEXT ("�\���ݒ�"),		100, },
	} ;
	static LPTSTR				srstrItem [] = {
		TEXT ("�L�[�{�[�h"),
		TEXT ("���͕���"),
		TEXT ("���̓��[�h"),
	} ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	pConfCicero	= &pConfArg->m_CiceroConfig ;

	hdlgList	= GetDlgItem (hDlg, IDC_LIST_LANGBARICON) ;
	if (hdlgList != NULL) {
		int			nIndex, i, nItem ;
		LV_COLUMN	lvColumn;
		LVITEM		lvI ;
		DLGPROC		pOrigDlgProc ;

		ListView_DeleteAllItems (hdlgList) ;

		lvColumn.mask	= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt	= LVCFMT_LEFT ;
		
		// Insert the columns in the list view.
		for (nIndex = 0; nIndex < NELEMENTS (srColumnInfo) ; nIndex ++) {
			lvColumn.cx			= srColumnInfo [nIndex].m_nWidth ;
			lvColumn.pszText	= srColumnInfo [nIndex].m_strTitle ;
			ListView_InsertColumn (hdlgList, nIndex, &lvColumn) ;
		}
		
		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ; 
		lvI.stateMask	= 0 ;
		//nItem			= 0 ;
		
		// Initialize LVITEM members that are different for each item. 
		nIndex	= 0 ;
		for (i = 0 ; i < NUM_SHOWKEYICON ; i ++) {
			lvI.iItem		= nIndex ;
			lvI.iImage		= 0 ;
			lvI.iSubItem	= 0 ;
			lvI.lParam		= (LPARAM) nIndex ;
			lvI.pszText		= srstrItem [i] ;
			nItem			= ListView_InsertItem (hdlgList, &lvI) ;
			if (nItem != -1) {
				ListView_SetItemText (hdlgList, nItem, 1, pConfCicero->m_rfShowLangBarIcon [i]? TEXT ("�\��") : TEXT ("��\��")) ;
				nIndex	++ ;
			}
		}
	}
	pConfCicero->m_hwndEdit			= NULL ;
	pConfCicero->m_nEditingItem		= -1 ;
	pConfCicero->m_nEditingSubItem	= -1 ;
	pConfCicero->m_nEditTrue		= -1 ;
	return	FALSE ;

	UNREFERENCED_PARAMETER (message) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgCiceroOnNotify (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	CICEROCONFIG*		pConfCicero ;
	NMHDR	FAR*		pNMHDR	= (NMHDR *) lParam ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *)  pPropSheet->lParam ; 
	pConfCicero	= &pConfArg->m_CiceroConfig ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_LANGBARICON:
		switch (pNMHDR->code) {
		case	NM_CLICK:
			return	dlgCicero_onNMClickLVLangBarIcon (hDlg, (LPNMITEMACTIVATE) lParam, pConfArg, pConfCicero) ;
		
		case	LVN_BEGINLABELEDIT:
			return	!dlgCicero_onBeginLabelEdit (hDlg, (NMLVDISPINFO*) lParam, pConfArg, pConfCicero) ; 
		case	LVN_ENDLABELEDIT:
			dlgCicero_onEndLabelEdit (hDlg, (NMLVDISPINFO*) lParam, pConfArg, pConfCicero) ;

		case	NM_CUSTOMDRAW:
		{
			LPNMLVCUSTOMDRAW	lpLVCD	= (LPNMLVCUSTOMDRAW) lParam ;
			LRESULT			lRetval	= 0 ;

			switch (lpLVCD->nmcd.dwDrawStage) {
			case	CDDS_PREPAINT:
				lRetval		= CDRF_NOTIFYITEMDRAW ;
				break ;
			case	CDDS_ITEMPREPAINT:
				lRetval		= CDRF_NOTIFYSUBITEMDRAW ;
				break ;
			case	CDDS_ITEMPREPAINT | CDDS_SUBITEM:
			{
			    int		nItem		= lpLVCD->nmcd.dwItemSpec ;
				int		nSubItem	= lpLVCD->iSubItem ;
				//HWND		hwnd		= pNMHDR->hwndFrom ;
				//HDC		hDC			= lpLVCD->nmcd.hdc ;

				if (pConfCicero->m_hwndEdit != NULL &&
					pConfCicero->m_nEditingItem == nItem &&
					pConfCicero->m_nEditingSubItem == nSubItem) {
					lRetval		= CDRF_SKIPDEFAULT ;
				} else {
					lRetval		= CDRF_NOTIFYSUBITEMDRAW ;
				}
				break ;
			}
			default:
				lRetval		= CDRF_DODEFAULT ;
				break ;
			}
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, lRetval) ;
			return	TRUE ;
		}
		default:
			break ;
		}
		return	TRUE;
	default:
		return	dlgCicero_defNotifyProc (hDlg, pNMHDR, pConfArg) ;
	}

	UNREFERENCED_PARAMETER (message) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgCiceroOnCommand (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	CICEROCONFIG*		pConfCicero ;
	WORD	wNotifyCode ;
	WORD	wID ;
	HWND	hwndCtl ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *)  pPropSheet->lParam ; 
	pConfCicero	= &pConfArg->m_CiceroConfig ;

	if (wID == IDC_LIST_LANGBARICON) {
		HWND	hwndLV	= GetDlgItem (hDlg, IDC_LIST_LANGBARICON) ;

		if (hwndLV == NULL)
			return	1 ;
	} else if (pConfCicero->m_hwndEdit != NULL &&
			   hwndCtl == pConfCicero->m_hwndEdit) {
		switch (wNotifyCode) {
		case	CBN_SELCHANGE:
		{
			int	nCurSel, nItem, nIndex ;
			BOOL	fVisible ;
			HWND	hwndLV ;

			hwndLV		= GetDlgItem (hDlg, IDC_LIST_LANGBARICON) ;
			nCurSel		= SendMessage (hwndCtl, CB_GETCURSEL, 0, 0) ;
			fVisible	= (nCurSel == pConfCicero->m_nEditTrue) ;
			nItem		= pConfCicero->m_nEditingItem ;
			nIndex		= dlgCicero_getIndexWithItem (hwndLV, nItem) ;
			if (0 <= nIndex && nIndex < NUM_SHOWKEYICON &&
				fVisible != pConfCicero->m_rfShowLangBarIcon [nIndex]) {
				pConfCicero->m_rfShowLangBarIcon [nIndex]	= fVisible ;
				PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
			}
			break ;
		}
		case	CBN_KILLFOCUS:
		case	CBN_SELENDOK:
		case	CBN_SELENDCANCEL:
			break ;
		}
	}

	return 0 ;

	UNREFERENCED_PARAMETER (message) ;
}

/*========================================================================*
 */

BOOL
skkimeConfig_initCICERO (
	LPCTSTR			strSubKey,
	CICEROCONFIG*	pConfCICERO)
{
	HKEY			hSubKey ;
	static LPCTSTR	rstrKEY [NUM_SHOWKEYICON]	= {
		REGKEY_SHOWKEYBRDICON,
		REGKEY_SHOWIMEICON,
		REGKEY_SHOWINPUTMODEICON
	} ;
	BOOL			rfShow [NUM_SHOWKEYICON] = { TRUE, TRUE, TRUE } ;
	int	i ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, strSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD			dwValue, cbData, dwType ;

		for (i = 0 ; i < NELEMENTS (rstrKEY) ; i ++) {
			cbData	= sizeof (DWORD) ;
			dwValue	= 0 ;
			if (RegQueryValueEx (hSubKey, rstrKEY [i], NULL, &dwType, (LPBYTE) &dwValue, &cbData) == ERROR_SUCCESS &&
				dwType == REG_DWORD) 
				rfShow [i]	= (dwValue != 0) ;
		}
		RegCloseKey (hSubKey) ;
	}
	for (i = 0 ; i < NUM_SHOWKEYICON ; i ++)
		pConfCICERO->m_rfShowLangBarIcon [i]	= rfShow [i] ;
	return	TRUE ;
}

BOOL
skkimeConfig_updateCICERO (
	LPCTSTR			strSubKey,
	CICEROCONFIG*	pConfCICERO)
{
	static LPCTSTR	rstrKEY [NUM_SHOWKEYICON]	= {
		REGKEY_SHOWKEYBRDICON,
		REGKEY_SHOWIMEICON,
		REGKEY_SHOWINPUTMODEICON
	} ;
	HKEY			hSubKey ;
	DWORD			dwShow ;
	BOOL	fRetval	= TRUE ;
	int	i ;

	if (! skkimeConfig_CreateKey (strSubKey, FALSE, &hSubKey))
		return	FALSE ;
	
	for (i = 0 ; i < NELEMENTS (rstrKEY) ; i ++) {
		dwShow	= pConfCICERO->m_rfShowLangBarIcon [i] ;
		if (RegSetValueEx (hSubKey, rstrKEY [i], 0, REG_DWORD, (LPBYTE) &dwShow, sizeof (DWORD)) != ERROR_SUCCESS) {
			fRetval	= FALSE ;
			break ;
		}
	}
	if (RegCloseKey (hSubKey) != ERROR_SUCCESS)
		fRetval	= FALSE ;
	return	fRetval ;
}

BOOL
dlgCicero_onNMClickLVLangBarIcon (
	HWND				hDlg,
	LPNMITEMACTIVATE	pNMIA,
	SkkimeConfigArg*	pConfArg,
	CICEROCONFIG*		pConfCicero)
{
	HWND				hwndLV ;
	int				nIndex, nSubItem, nItem ;
	LVITEM						lvI ;
	LVHITTESTINFO				lvHIT ;

	hwndLV	= GetDlgItem (hDlg, IDC_LIST_LANGBARICON) ;

	lvHIT.pt		= pNMIA->ptAction ;
	lvHIT.flags		= LVHT_ONITEMLABEL ;
	lvHIT.iItem		= 0 ;
	lvHIT.iSubItem	= 0 ;
	if (ListView_SubItemHitTest (hwndLV, &lvHIT) < 0)
		return	TRUE ;
	nItem			= lvHIT.iItem ;
	nSubItem		= lvHIT.iSubItem ;

	if (nItem == pConfCicero->m_nEditingItem &&
		nSubItem == pConfCicero->m_nEditingSubItem) {
		WPARAM		wParam	= MK_LBUTTON ;
		LPARAM		lParam	= MAKELPARAM (pNMIA->ptAction.x, pNMIA->ptAction.y) ;

		SendMessage (pConfCicero->m_hwndEdit, WM_LBUTTONDOWN, wParam, lParam) ;
		return	TRUE ;
	}

	/*	�ʂ̏ꏊ���N���b�N���ꂽ���� Kill ����B*/
	if (pConfCicero->m_hwndEdit != NULL) {
		dlgCicero_killFocusInPlaceCB (hDlg, pConfCicero->m_hwndEdit, pConfArg, pConfCicero) ;
	}

	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM ;		
	lvI.iItem		= nItem ;
	lvI.iSubItem	= 0 ;
	if (! ListView_GetItem (hwndLV, &lvI))
		return	TRUE ;
	nIndex			= lvI.lParam ;
	
	/*	������ Subitem ���I�����ꂽ���H */
	if (nItem >= 0 && nSubItem > 0 &&
		0 <= nIndex && nIndex < NUM_SHOWKEYICON) {
		NMLVDISPINFO		di ;
		
		ListView_SetItemState (hwndLV, nItem, 0, LVIS_CUT | LVIS_DROPHILITED | LVIS_SELECTED | LVIS_FOCUSED) ;

		di.hdr.hwndFrom		= hwndLV ;
		di.hdr.idFrom		= GetDlgCtrlID (hwndLV) ;
		di.hdr.code			= LVN_BEGINLABELEDIT ;
		
		di.item.mask		= LVIF_TEXT ;
		di.item.iItem		= nItem ;
		di.item.iSubItem	= nSubItem ;
		di.item.pszText		= pConfCicero->m_rfShowLangBarIcon [nIndex]? TEXT ("�\��") : TEXT ("��\��") ;
		di.item.cchTextMax	= lstrlen ((LPCTSTR)di.item.pszText) ;
		
		SendMessage (hDlg, WM_NOTIFY, LVN_BEGINLABELEDIT, (LPARAM) &di) ;
	}
	return	TRUE ;	/* NM_CLICK �̕Ԃ�l�͖��������B*/
}

BOOL
dlgCicero_onBeginLabelEdit (
	HWND				hDlg,
	NMLVDISPINFO*		pdi,
	SkkimeConfigArg*	pConfArg,
	CICEROCONFIG*		pConfCicero)
{
	HWND	hwndEdit, hwndLV ;
	RECT			rc ;
	int	nItem, nIndex, x, y, width, height ;
	BOOL	fVisible ;
	int				rCBItem [2] ;
	POINT			pt ;
	HFONT	hFont ;

	if (pConfCicero->m_hwndEdit != NULL)
		return	FALSE ;

	hwndLV	= GetDlgItem (hDlg, IDC_LIST_LANGBARICON) ;
	if (hwndLV == NULL)
		return	FALSE ;

	hFont		= (HFONT) SendMessage (hwndLV, WM_GETFONT, 0, 0) ;
	nIndex		= dlgCicero_getIndexWithItem (hwndLV, pdi->item.iItem) ;
	if (nIndex < 0)
		return	FALSE ;

	/*	COMBOBOX �̍쐬�Ə������B
	 */
	/*	COMBOBOX �̈ʒu�����B
	 */
	ListView_GetSubItemRect (hwndLV, pdi->item.iItem, pdi->item.iSubItem, LVIR_BOUNDS, &rc) ;
	//SendMessage (hwndEdit, CB_SETITEMHEIGHT, (WPARAM) -1, (LPARAM) (rc.bottom - rc.top) * 2) ;
	//SendMessage (hwndEdit, CB_SETDROPPEDWIDTH, (WPARAM) (rc.bottom - rc.top) * 2, 0) ;
	pt.x	= rc.left ;
	pt.y	= rc.top ;
	ClientToScreen (hwndLV, &pt) ;
	ScreenToClient (hDlg, &pt) ;
	x		= pt.x ;
	y		= pt.y - 4 ;
	width	= rc.right - rc.left ;
	height	= (rc.bottom - rc.top) * 4 ;
	hwndEdit	= CreateWindow (TEXT ("COMBOBOX"), TEXT ("LocInPlaceEdit"), WS_BORDER | WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST, x, y, width, height, hDlg, NULL, pConfArg->m_hInst, NULL) ;
	if (hwndEdit == NULL) 
		return	FALSE ;

	fVisible	= pConfCicero->m_rfShowLangBarIcon [nIndex] ;
	rCBItem [1]	= (int) SendMessage (hwndEdit, CB_ADDSTRING, 0, (LPARAM) TEXT ("�\��")) ;
	rCBItem [0]	= (int) SendMessage (hwndEdit, CB_ADDSTRING, 0, (LPARAM) TEXT ("��\��")) ;
	SendMessage (hwndEdit, CB_SETCURSEL, rCBItem [fVisible != FALSE], 0) ;
	SendMessage (hwndEdit, WM_SETFONT, (WPARAM) hFont, 0) ;

	SetWindowPos (hwndEdit, HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE) ;
	SetFocus (hwndEdit) ;

	pConfCicero->m_hwndEdit			= hwndEdit ;
	pConfCicero->m_nEditingItem		= pdi->item.iItem ;
	pConfCicero->m_nEditingSubItem	= pdi->item.iSubItem ;
	pConfCicero->m_nEditTrue		= rCBItem [1] ;
	return	TRUE ;
}

BOOL
dlgCicero_killFocusInPlaceCB (
	HWND				hDlg,
	HWND				hwndCtrl,
	SkkimeConfigArg*	pConfArg,
	CICEROCONFIG*		pConfCicero)
{
	HWND			hwndLV ;
	NMLVDISPINFO	di ;
	int				nCurSel ;
	BOOL			fVisible ;
		
	nCurSel				= SendMessage (hwndCtrl, CB_GETCURSEL, 0, 0) ;
	fVisible			= (nCurSel == pConfCicero->m_nEditTrue) ;

	hwndLV				= GetDlgItem (hDlg, IDC_LIST_LANGBARICON) ;
	di.hdr.hwndFrom		= hwndLV ;
	di.hdr.idFrom		= GetDlgCtrlID (hwndLV) ;
	di.hdr.code			= LVN_ENDLABELEDIT ;
	
	di.item.mask		= LVIF_TEXT ;
	di.item.iItem		= pConfCicero->m_nEditingItem ;
	di.item.iSubItem	= pConfCicero->m_nEditingSubItem ;
	di.item.pszText		= fVisible? TEXT ("�\��") : TEXT ("��\��") ;
	di.item.cchTextMax	= lstrlen ((LPCTSTR)di.item.pszText) ;
	SendMessage (hDlg, WM_NOTIFY, LVN_ENDLABELEDIT, (LPARAM) &di) ;
	return	TRUE ;
}

BOOL
dlgCicero_onEndLabelEdit (
	HWND				hDlg,
	NMLVDISPINFO*		pdi,
	SkkimeConfigArg*	pConfArg,
	CICEROCONFIG*		pConfCicero)
{
	int			iItem		= pdi->item.iItem ;
	int			iSubItem	= pdi->item.iSubItem ;
	LVITEM		lvI ;
	HWND		hwndLV ;
	int			nIndex ;
	
	if (! pConfCicero->m_hwndEdit)
		return	FALSE ;
	
	hwndLV	= GetDlgItem (hDlg, IDC_LIST_LANGBARICON) ;
	if (hwndLV == NULL)
		goto	skip ;

	if (pdi->item.pszText) {
		nIndex	= dlgCicero_getIndexWithItem (hwndLV, iItem) ;
		if (nIndex < 0 || nIndex >= NUM_SHOWKEYICON)
			goto	skip ;
		if (! lstrcmp (pdi->item.pszText, TEXT ("�\��"))) {
			ListView_SetItemText (hwndLV, iItem, iSubItem, TEXT ("�\��")) ;
			pConfCicero->m_rfShowLangBarIcon [nIndex]	= TRUE ;
		} else {
			ListView_SetItemText (hwndLV, iItem, iSubItem, TEXT ("��\��")) ;
			pConfCicero->m_rfShowLangBarIcon [nIndex]	= FALSE ;
		}
		PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
	}
  skip:
	DestroyWindow (pConfCicero->m_hwndEdit) ;
	pConfCicero->m_hwndEdit			= NULL ;
	pConfCicero->m_nEditingItem		= -1 ;
	pConfCicero->m_nEditingSubItem	= -1 ;
	pConfCicero->m_nEditTrue		= -1 ;
	return	TRUE ;
}

BOOL
dlgCicero_defNotifyProc (
	HWND				hDlg,
	NMHDR*				pNMHDR,
	SkkimeConfigArg*	pConfArg)
{
	switch (pNMHDR->code){
	case PSN_SETACTIVE:
		SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
		return	TRUE ;
		
	case PSN_KILLACTIVE:
		SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
		return	TRUE ;
		
	case PSN_APPLY:
	{
		if (skkimeConfig_UpdateCICERO (&pConfArg->m_CiceroConfig)) {
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
		} else {
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
		}
		return	TRUE ;
	}
	case PSN_RESET:
	case PSN_HELP:
		break ;
	default:
		return FALSE ;
	}
	return	TRUE ;
}

int
dlgCicero_getIndexWithItem (
	HWND				hwndLV,
	int				nItem)
{
	LVITEM		lvI ;

	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask	= LVIF_PARAM ;
	lvI.iItem	= nItem ;
	if (! ListView_GetItem (hwndLV, &lvI))
		return	-1 ;
	return	(int) lvI.lParam ;
}

#endif
