#include "StdAfx.h"
#include <prsht.h>
#include <limits.h>
#include "skimconf.h"
#include "confcommon.h"
#include "TServerSession.h"
#include "version.h"

#define	MAX_PAGES			(16)
#define	MAX_SKKIME_CONFIG_MEMORY	(1024 * 1024 * 2)

typedef struct tagSkkimePageSheetDefine {
	LPCTSTR					m_strTitle ;
	INT_PTR (CALLBACK		*m_pDlgProc)(HWND, UINT, WPARAM, LPARAM) ;
	INT						m_nResId ;
}	SkkimePageSheetDefine ;

/*	�v���g�^�C�v�錾�B */
static	BOOL			skkimeConfig_main			(HINSTANCE, HWND, DWORD) ;
static	BOOL			skkimeConfig_initializeInstance	(SkkimeConfigArg*, HWND) ;
static	void			skkimeConfig_exitInstance	(void) ;
static	int	CALLBACK	skkimeConfig_propSheetProc	(HWND, UINT, LPARAM) ;
static	BOOL			skkimeConfig_newPageSheet	(LPPROPSHEETHEADER, SkkimePageSheetDefine*, void*) ;
static	BOOL			skkimeConfig_loadConfig 	(SkkimeConfigArg*) ;
static	BOOL			skkimeConfig_updateConfig	(SkkimeConfigArg*) ;

/*	�O���[�o���ϐ��B*/
HINSTANCE						g_hInst	= NULL ;

static	SkkimeConfigArg*		spCurrentConfigArg	= NULL ;

static	SkkimePageSheetDefine	srSkkimePageSheetTbl []	= {
	{ TEXT("�S��"),	
	  skkimeConfig_dlgGenericProc,			IDD_PROPPAGE_GENERIC, },
	{ TEXT("�L�[�ݒ�"),	
	  skkimeConfig_dlgKeybindProc,			IDD_PROPPAGE_KEYBIND, },
	{ TEXT("�����ݒ�"),
	  skkimeConfig_dlgDictionaryProc,		IDD_PROPPAGE_DICT, },
	{ TEXT("���[�}�������e�[�u���ݒ�"),
	  skkimeConfig_dlgRomaKanaTblProc,		IDD_PROPPAGE_ROMAKANATABLE, },
	{ TEXT("�����v���t�B�N�X�ݒ�"),	
	  skkimeConfig_dlgKanaPrefixTblProc,	IDD_PROPPAGE_KANAPREFIX, },
	{ TEXT("���[�}�������ϊ����[���ݒ�"),
	  skkimeConfig_dlgRomaKanaRuleProc,		IDD_PROPPAGE_ROMAKANARULE, },
	{ TEXT("���̓x�N�g���ݒ�"),
	  skkimeConfig_dlgInputVectorProc,		IDD_PROPPAGE_INPUTVECTOR, },
	{ TEXT("�S�p�x�N�g���ݒ�"),
	  skkimeConfig_dlgZenkakuVectorProc,	IDD_PROPPAGE_ZENKAKUVECTOR, },
	{ TEXT("�F�ݒ�"),	
	  skkimeConfig_dlgColorFaceTblProc,		IDD_PROPPAGE_CONFIGCOLOR, },
	{ TEXT("���I���L�[�̐ݒ�"),
	  skkimeConfig_dlgCandidateSelectKeyProc,	IDD_PROPPAGE_CANDSEL, },
} ;

#if !defined (NO_TSF)
static	SkkimePageSheetDefine	srSkkimeTsfPageSheetTbl []	= {
	{ TEXT ("����o�["),
	  skkimeConfig_dlgCiceroProc,			IDD_PROPPAGE_CONFIGCICERO, },
} ;
#endif

int	WINAPI
_tWinMain (
	register HINSTANCE	hInstance,
	register HINSTANCE	hPrevInstance,
	register LPTSTR		lpCmdLine,
	register int		nCmdShow)
{
	INITCOMMONCONTROLSEX	initCtrls ;

	memset (&initCtrls, 0, sizeof (initCtrls)) ;
	initCtrls.dwSize	= sizeof (initCtrls) ;
	initCtrls.dwICC		= ICC_LISTVIEW_CLASSES | ICC_STANDARD_CLASSES ;
	InitCommonControlsEx (&initCtrls) ;

	(void) TServerSession_ClassInit () ;
	skkimeConfig_main (hInstance, NULL, 0) ;
	return	0 ;
	UNREFERENCED_PARAMETER (hPrevInstance) ;
	UNREFERENCED_PARAMETER (lpCmdLine) ;
	UNREFERENCED_PARAMETER (nCmdShow) ;
}

/*
 */
BOOL
skkimeConfig_CreateKey (
	register LPCTSTR	pstrSubKey,
	register BOOL		fClean,
	register HKEY*		phKey)
{
	HKEY	hSubKey ;
	DWORD	dwDispose ;
	LONG	lResult ;

	ASSERT (pstrSubKey != NULL) ;
	ASSERT (phKey != NULL) ;

	if (fClean) {
		lResult	= RegDeleteKey (HKEY_CURRENT_USER, pstrSubKey) ;
		DEBUGPRINTF ((TEXT ("RegDeleteKey (\"%s\") returned %ld.\n"), pstrSubKey, lResult)) ;
	}
	if (RegCreateKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, NULL, &hSubKey, &dwDispose) != ERROR_SUCCESS) {
		DEBUGPRINTF ((TEXT ("RegCreateKeyEx (\"%s\") failed.\n"), pstrSubKey)) ;
		return	FALSE ;
	}
	*phKey	= hSubKey ;
	return	TRUE ;
}

int
skkimeConfig_PopupMenu (
	register HWND			hwndOwner,
	register TMYMENUITEM*	pMenuItem,
	register int			nMenuItem)
{
	register HMENU				hMenu	= CreatePopupMenu () ;
	static MENUITEMINFO			mmi ;
	POINT						pt ;
	register int				i, n ;

	memset (&mmi, 0, sizeof (mmi)) ;
	mmi.cbSize	= sizeof (mmi) ;
	for (i = 0 ; i < nMenuItem ; i ++) {
#if(WINVER >= 0x0500)
		mmi.fMask		= pMenuItem->m_fMask ;
#else
		mmi.fMask		= pMenuItem->m_fMask | 0x00000140 ;
#endif
		mmi.fType		= pMenuItem->m_fType ;
		mmi.dwTypeData	= pMenuItem->m_strText ;
		mmi.wID			= pMenuItem->m_wID ;
		mmi.cch			= lstrlen (pMenuItem->m_strText) ;
		InsertMenuItem (hMenu, i, TRUE, &mmi) ;
		pMenuItem	++ ;
	}
	if (! GetCursorPos (&pt)) 
		pt.x	= pt.y	= 0 ;
	n	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwndOwner, NULL) ;
	DestroyMenu (hMenu) ;
	return	n ;
}

/*========================================================================*/

BOOL
skkimeConfig_main (
	HINSTANCE	hInstance,
	HWND		hWnd,
	DWORD		dw)
{
	SkkimeConfigArg	confArg ;
	BOOL			fRetval ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_main (): enter\n"))) ;

	g_hInst	= hInstance ;
	memset (&confArg, 0, sizeof (confArg)) ;
	confArg.m_hInst	= hInstance ;
	fRetval	= skkimeConfig_loadConfig (&confArg) ;
	fRetval	= skkimeConfig_initializeInstance (&confArg, hWnd) ;
	skkimeConfig_exitInstance () ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_main (): leave\n"))) ;
	return	fRetval ;
	UNREFERENCED_PARAMETER (dw) ;
}

BOOL
skkimeConfig_initializeInstance (
	register SkkimeConfigArg*	pConfArg,
	register HWND				hWnd)
{
	HPROPSHEETPAGE	rPages [MAX_PAGES] ;
	PROPSHEETHEADER	psh ;
	register int	i ;
	register BOOL	fRetval	= FALSE ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_initializeInstance ()\n"))) ;

	psh.dwSize		= sizeof (psh) ;
	psh.dwFlags		= PSH_PROPTITLE | PSH_USECALLBACK ;
	psh.hwndParent	= hWnd ;

	/*
	 *	����l�Ƃ��Đݒ肵�����ɂ� hInst �̒l����낵�������炵���̂ŁA
	 *	hInstance �͐e Window ����Ⴄ���Ƃɂ���B
	 */
	psh.hInstance	= pConfArg->m_hInst ;
	psh.pszIcon		= NULL ;
	psh.pszCaption	= SKKIME_VERSION TEXT (" ") ;
	psh.nPages		= 0 ;
	psh.nStartPage	= 0 ;
	psh.phpage		= rPages ;
	psh.pfnCallback	= skkimeConfig_propSheetProc ;

	for (i = 0 ; i < NELEMENTS (srSkkimePageSheetTbl) ; i ++) {
		if (! skkimeConfig_newPageSheet (&psh, &srSkkimePageSheetTbl [i], pConfArg))
			goto	exit_func ;
	}
#if !defined (NO_TSF)
	/*	����o�[�̐ݒ�́A���ꂪ�L���łȂ���Ε\������K�v�͂Ȃ��B*/
	if (bTSF_IsTSFEnabled ()) {
		for (i = 0 ; i < NELEMENTS (srSkkimeTsfPageSheetTbl) ; i ++) {
			if (! skkimeConfig_newPageSheet (&psh, &srSkkimeTsfPageSheetTbl [i], pConfArg))
				goto	exit_func ;
		}
	}
#endif
	/*	�����Acritical section ... �����ɓ�����ƕ�����B*/
	spCurrentConfigArg	= pConfArg ;
	if (psh.nPages > 0) {
		register int	n = PropertySheet (&psh) ;
		if (n > 0) {
			if (skkimeConfig_updateConfig (pConfArg)) 
				UpdateServerConfiguration () ;
		}
		fRetval	= TRUE ;
	}

 exit_func:
	return	fRetval ;
}

void
skkimeConfig_exitInstance (void)
{
	return ;
}

int	CALLBACK
skkimeConfig_propSheetProc (
	register HWND					hwndDlg,
	register UINT					uMsg,
	register LPARAM					lParam)
{
	switch (uMsg) {
	case	PSCB_INITIALIZED:
		/*	�ň�...�B���������ǂ�������� PropertySheet �� Window Handle ��
		 *	�܂Ƃ��ɓ��邱�Ƃ��ł���񂾂낤�H */
		if (spCurrentConfigArg != NULL)
			spCurrentConfigArg->m_hPropSheetDlg	= hwndDlg ;
		break ;
	default:
		break ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

BOOL
skkimeConfig_newPageSheet (
	LPPROPSHEETHEADER		ppsh,
	SkkimePageSheetDefine*	pDefine,
	void*					pvParam)
{
	PROPSHEETPAGE		psp ;
	/*register LPCTSTR	pszTitle ;
	  register DLGPROC	pfn ;
	  register LPCTSTR	pszTemplate ;*/

	/* �����̃`�F�b�N�B*/
	if (ppsh == NULL || pDefine == NULL)
		return	FALSE ;
	if (ppsh->nPages >= MAX_PAGES)
		return	FALSE ;

	/* �v���p�e�B�V�[�g�Ƀy�[�W��ǉ�����B*/
	psp.dwSize		= sizeof (psp) ;
	psp.dwFlags		= PSP_DEFAULT ; //USETITLE ; 	//PSP_DLGINDIRECT ;
	psp.hInstance	= g_hInst ; //ppsh->hInstance ; /* hInst */
	psp.pszTemplate	= MAKEINTRESOURCE(pDefine->m_nResId) ;
	//psp.pResource	= (LPDLGTEMPLATE)lpResource ;
	psp.pszIcon		= 0 ;
	psp.pfnDlgProc	= pDefine->m_pDlgProc ;
	psp.pfnCallback	= 0 ;
	psp.pszTitle	= pDefine->m_strTitle ;
	psp.lParam		= (LPARAM) pvParam ;
	ppsh->phpage [ppsh->nPages]	= CreatePropertySheetPage (&psp) ;
	if (ppsh->phpage [ppsh->nPages]){
		ppsh->nPages	++ ;
	} else {
		DEBUGPRINTF ((TEXT ("CreatePropertySheetPage failed (%d)\n"), ppsh->nPages)) ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_loadConfig (
	register SkkimeConfigArg*	pArg)
{
	DEBUGPRINTF ((TEXT ("skkimeConfig_updateInstane (): enter\n"))) ;

	if (!skkimeConfig_InitializeGeneric (&pArg->m_GenericConfig)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_InitializeGeneric (): failed\n"))) ;
		return	FALSE ;
	}

	/*	���̓x�N�g���̏������B*/
	if (! skkimeConfig_InitializeInputVector (pArg->m_rInputVector)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_initInputVector(): INPUTVECTOR failed\n"))) ;
		return	FALSE ;
	}

	/*	�S�p�x�N�g���̏������B*/
	if (! skkimeConfig_InitializeZenkakuVector (pArg->m_rZenkakuVector)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_initInputVector(): ZENKAKUVECTOR failed\n"))) ;
		return	FALSE ;
	}

	/*	�L�[�}�b�v�̏������B*/
	if (! skkimeConfig_InitializeKeymap (pArg->m_rJMap, pArg->m_rAbbrevMap)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_initKeymap(): failed\n"))) ;
		return	FALSE ;
	}

	/*	���[�}�������ϊ��e�[�u���̏������B*/
	if (! skkimeConfig_InitializeRomaKanaTableA (&pArg->m_lstRomaKanaA) ||
		! skkimeConfig_InitializeRomaKanaTableI (&pArg->m_lstRomaKanaI) ||
		! skkimeConfig_InitializeRomaKanaTableU (&pArg->m_lstRomaKanaU) ||
		! skkimeConfig_InitializeRomaKanaTableE (&pArg->m_lstRomaKanaE) ||
		! skkimeConfig_InitializeRomaKanaTableO (&pArg->m_lstRomaKanaO)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_initRomaKanaTable(): failed\n"))) ;
		return	FALSE ;
	}

	/*	���[�}�������ϊ����[�����X�g�̏������B*/
	if (! skkimeConfig_InitializeRomaKanaRuleList (&pArg->m_lstRomaKanaRule)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_initRomaKanaRuleList(): failed\n"))) ;
		return	FALSE ;
	}

	/*	�v���t�B�N�X���X�g�̏������B*/
	if (! skkimeConfig_InitializePrefixList (&pArg->m_lstPrefix)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_initPrefixList(): failed\n"))) ;
		return	FALSE ;
	}

	/*	�����ݒ�̏������B*/
	if (!skkimeConfig_InitializeSearchJisyoList (&pArg->m_lstSearchJisyo, pArg->m_rszUserJisyoPath)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_initSearchJisyoList (): failed\n"))) ;
		return	FALSE ;
	}

	if (!skkimeConfig_InitializeColorFace (pArg->m_rColorFaceSet)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_InitializeColorFace (): failed\n"))) ;
		return	FALSE ;
	}
#if !defined (NO_TSF)
	if (!skkimeConfig_InitializeCICERO (&pArg->m_CiceroConfig)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_InitializeCICERO (): failed\n"))) ;
		return	FALSE ;
	}
#endif
	if (! skkimeConfig_InitializeCandidateSelectKey (&pArg->m_CandSelKey)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_InitializeCandidateSelectKey (): failed\n"))) ;
		return	FALSE ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_updateConfig (
	register SkkimeConfigArg*	pArg)
{
	if (! skkimeConfig_UpdateKeymap (pArg->m_rJMap, pArg->m_rAbbrevMap)) {
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateInputVector   (pArg->m_rInputVector) ||
		! skkimeConfig_UpdateZenkakuVector (pArg->m_rZenkakuVector)) {
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateRomaKanaTableA (pArg->m_lstRomaKanaA) ||
		! skkimeConfig_UpdateRomaKanaTableI (pArg->m_lstRomaKanaI) ||
		! skkimeConfig_UpdateRomaKanaTableU (pArg->m_lstRomaKanaU) ||
		! skkimeConfig_UpdateRomaKanaTableE (pArg->m_lstRomaKanaE) ||
		! skkimeConfig_UpdateRomaKanaTableO (pArg->m_lstRomaKanaO)) {
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateRomaKanaRuleList (pArg->m_lstRomaKanaRule)) {
		return	FALSE ;
	}

	if (! skkimeConfig_UpdatePrefixList (pArg->m_lstPrefix)) {
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateSearchJisyoList (pArg->m_lstSearchJisyo, pArg->m_rszUserJisyoPath)) {
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateColorFace (pArg->m_rColorFaceSet)) {
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateGeneric (&pArg->m_GenericConfig)) {
		return	FALSE ;
	}
#if !defined (NO_TSF)
	if (!skkimeConfig_UpdateCICERO (&pArg->m_CiceroConfig)) {
		return	FALSE ;
	}
#endif
	if (!skkimeConfig_UpdateCandidateSelectKey (&pArg->m_CandSelKey)) {
		return	FALSE ;
	}
	return	TRUE ;
}

/*========================================================================
 */
static	int		srnMyColorIndex2SysColorIndexTbl []	= {
	COLOR_BTNFACE,
	COLOR_BTNTEXT,
	COLOR_ACTIVEBORDER,
	COLOR_ACTIVECAPTION,
	COLOR_CAPTIONTEXT,
	COLOR_APPWORKSPACE,
	COLOR_WINDOW,
	COLOR_WINDOWTEXT,
	COLOR_DESKTOP,
	COLOR_INFOBK,
	COLOR_INFOTEXT,
	COLOR_WINDOWTEXT,
	COLOR_MENU,
	COLOR_MENUTEXT,
	COLOR_HIGHLIGHTTEXT,
	COLOR_HIGHLIGHT,
	COLOR_INACTIVEBORDER,
	COLOR_INACTIVECAPTION,
	COLOR_INACTIVECAPTIONTEXT,
} ;

COLORREF
GetImeColor (
	register HWND	hwnd,
	register int	nColor)
{
	register HDC		hdc ;
	register COLORREF	col ;

	switch (nColor) {
	case	MYCOLOR_TEXTAUTO:
	case	MYCOLOR_BACKAUTO:
		hdc	= GetDC (hwnd) ;
		col	= GetBkColor (hdc) ;
		ReleaseDC (hwnd, hdc) ;
		return	(nColor == MYCOLOR_BACKAUTO)? col : ~col ;
	case	MYCOLOR_BLACK:
		return	PALETTERGB (  0,   0,   0) ;
	case	MYCOLOR_DARKRED:
		return	PALETTERGB (128,   0,   0) ;
	case	MYCOLOR_DARKGREEN:
		return	PALETTERGB (  0, 128,   0) ;
	case	MYCOLOR_DARKYELLOW:
		return	PALETTERGB (128, 128,   0) ;
	case	MYCOLOR_DARKBLUE:
		return	PALETTERGB (  0,   0, 128) ;
	case	MYCOLOR_DARKPURPLE:
		return	PALETTERGB (128,   0, 128) ;
	case	MYCOLOR_DARKLIGHTBLUE:
		return	PALETTERGB (0,   128, 128) ;
	case	MYCOLOR_DARKGRAY:
		return	PALETTERGB (128, 128, 128) ;
	case	MYCOLOR_LIGHTGRAY:
		return	PALETTERGB (192, 192, 192) ;
	case	MYCOLOR_RED:
		return	PALETTERGB (255,   0,   0) ;
	case	MYCOLOR_GREEN:
		return	PALETTERGB (  0, 255,   0) ;
	case	MYCOLOR_YELLOW:
		return	PALETTERGB (255, 255,   0) ;
	case	MYCOLOR_BLUE:
		return	PALETTERGB (  0,   0, 255) ;
	case	MYCOLOR_PURPLE:
		return	PALETTERGB (255,   0, 255) ;
	case	MYCOLOR_LIGHTBLUE:
		return	PALETTERGB (  0, 255, 255) ;
	case	MYCOLOR_WHITE:
		return	PALETTERGB (255, 255, 255) ;
	default:
		if (MYCOLOR_SYSTEM <= nColor && nColor < MAX_MYCOLOR) {
			nColor	-= MYCOLOR_SYSTEM ;
			return	GetSysColor (srnMyColorIndex2SysColorIndexTbl [nColor]) ;
		}
		break ;
	}
	return	PALETTERGB (0, 0, 0) ;
}

/*	�_���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDottedBrush [8]	= {
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
} ;

/*	�f�B�U���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDitherBrush [8]	= {
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
} ;

HBRUSH
GetImeLineBrush (
	register HWND				hwnd,		/* [in] */
	register int				nLineColor,	/* [in] */
	register int				nLineType,	/* [in] */
	register COLORREF*			pColBrush,	/* [out] */
	register HBITMAP*			phBm,		/* [out] */
	register int*				pnWidth)	/* [out] */
{
	register COLORREF	colBrush ;
	register HBRUSH		hBrush	= NULL ;
	register HBITMAP	hBitmap	= NULL ;

	if (pColBrush == NULL || phBm == NULL || pnWidth == NULL) {
		return	NULL ;
	}

	colBrush	= GetImeColor (hwnd, nLineColor) ;
	switch (nLineType) {
	case	MYLINE_SOLID:
		*pnWidth	= 1 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_DOTTED:
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDottedBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		*pnWidth	= 1 ;
		break ;
	case	MYLINE_THICK_SOLID:
		*pnWidth	= 2 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_THIN_DITHER:
		*pnWidth	= 2 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_THICK_DITHER:
		*pnWidth	= 3 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_NO:
	default:
		*pnWidth	= 0 ;
		break ;
	}
	*pColBrush	= colBrush ;
	*phBm		= hBitmap ;
	return	hBrush ;
}

/*========================================================================
 *	Unit Test ��p�B
 */
void
DebugPrintf (
	LPCTSTR	ptszFormat,
	...)
{
	TCHAR	szBuffer [2048] ;
	va_list	vl ;
	
	/*	vsnprintf �� DLL function �Ƃ��Ă͕s�K�؁Bmain ��v������̂ŁB*/
	va_start (vl, ptszFormat) ;
	wvsprintf (szBuffer, ptszFormat, vl) ;
	va_end (vl) ;
	szBuffer [1024]	= TEXT ('\0') ;
	OutputDebugString (szBuffer) ;
	return ;
}

