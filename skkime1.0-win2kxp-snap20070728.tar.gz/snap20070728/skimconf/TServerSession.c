#include "StdAfx.h"
#include <lmcons.h>
#include "skimconf.h"
#include "confcommon.h"
#include "TProtocol.h"
#include "TPacket.h"
#include "TServerSession.h"
#include "jstring.h"

#define	SKKIME_PIPE_PREFIX_NUM	(10)
#define	OPENSERVER_MAX_RETRY	(128)
//#define	PROGRAMF_DIR			L"IME"
//#define	SKKIMEProg_S_DIR		L"SKKIM10"
//#define	SKKIMEServerFile		L"skkiserv.exe"

static	CTHenkanSession*	tHenkanSession_Create	(LPCWSTR, int) ;
static	BOOL	tHenkanSession_UpdateCandidateList	(CTHenkanSession*, int) ;
static	CTSearchSessionCandidate*	tHenkanSession_CreateCandidate (CTHenkanSession*, int, int) ;
static	BOOL	tHenkanSession_NewCandidate			(CTHenkanSession*, int, int) ;
static	BOOL	tHenkanSession_IsExistCandidatep	(CTHenkanSession*, LPCWSTR, int) ;
static	BOOL	tHenkanSession_RegisterCandidate	(CTHenkanSession*, CTSearchSessionCandidate*) ;
static	BOOL	tHenkanSession_CleanupHashTable		(CTHenkanSession*) ;
static	BOOL	tHenkanSession_CleanupHashTableSub	(CTSearchSessionCandidate*) ;

static	BOOL	tHenkanSession_Search			(CTHenkanSession*) ;
static	BOOL	tOkuriHenkanSession_Search		(CTHenkanSession*) ;
static	BOOL	tHenkanSession_IsSeparator		(WCHAR) ;
static	BOOL	tCompletionSession_Search		(CTHenkanSession*) ;
static	BOOL	tCompletionSession_IsSeparator	(WCHAR) ;

/*========================================================================*/
static	HANDLE	tServerSession_OpenServer	(void) ;
static	BOOL	tServerSession_Send			(HANDLE, CTPacket*) ;
static	BOOL	tServerSession_Recv			(HANDLE, CTPacket*) ;
static	BOOL	tServerSession_StartServer	(void) ;

/*========================================================================*/
static	CTSearchSessionCandidate*	TSearchSessionCandidate_Create	(int) ;
static	CTSearchSessionCandidate*	TSearchSessionCandidate_GetNext	(CTSearchSessionCandidate*) ;
static	CTSearchSessionCandidate*	TSearchSessionCandidate_GetPrevious	(CTSearchSessionCandidate*) ;
static	CTSearchSessionCandidate*	TSearchSessionCandidate_GetLeft	(CTSearchSessionCandidate*) ;
static	CTSearchSessionCandidate*	TSearchSessionCandidate_GetRight	(CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_SetNext (CTSearchSessionCandidate*, CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_SetPrevious (CTSearchSessionCandidate*, CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_SetRight	(CTSearchSessionCandidate*, CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_SetLeft	(CTSearchSessionCandidate*, CTSearchSessionCandidate*) ;
static	int		TSearchSessionCandidate_GetValue	(CTSearchSessionCandidate*) ;
static	void	TSearchSessionCandidate_SetLink	(CTSearchSessionCandidate*, CTSearchSessionCandidate*) ;
static	CTSearchSessionCandidate*	TSearchSessionCandidate_GetLink (CTSearchSessionCandidate*) ;

/*========================================================================*/
static	WCHAR	_rszSkkImePipeName [MAX_PATH]	= SKKISERVER_PIPE_BASENAMEW ;

CTHenkanSession*
TCompletionSession_Init (
	register LPCWSTR	wstring,
	register int		nstring)
{
	register CTHenkanSession*	pSession ;

	pSession	= tHenkanSession_Create (wstring, nstring) ;
	if (pSession == NULL)
		return	NULL ;
	pSession->_pSearchProc		= tCompletionSession_Search ;
	pSession->_pSeparatorpProc	= tCompletionSession_IsSeparator ;
	return	pSession ;
}

CTHenkanSession*
THenkanSession_Init (
	register LPCWSTR	wstring,
	register int		nstring)
{
	register CTHenkanSession*	pSession ;

	pSession	= tHenkanSession_Create (wstring, nstring) ;
	if (pSession == NULL)
		return	NULL ;
	pSession->_pSearchProc		= tHenkanSession_Search ;
	pSession->_pSeparatorpProc	= tHenkanSession_IsSeparator ;
	return	pSession ;
}

CTHenkanSession*
TOkuriHenkanSession_Init (
	register LPCWSTR	wstring,
	register int		nstring)
{
	register CTHenkanSession*	pSession ;

	pSession	= tHenkanSession_Create (wstring, nstring) ;
	if (pSession == NULL)
		return	NULL ;
	pSession->_pSearchProc		= tOkuriHenkanSession_Search ;
	pSession->_pSeparatorpProc	= tHenkanSession_IsSeparator ;
	return	pSession ;
}

void
THenkanSession_Uninit (
	register CTHenkanSession*	pSession)
{
	if (pSession != NULL) {
		TVarbuffer_Uninit (&pSession->_vbufCandidate) ;
		/*	Candidate List �̃N���A�B*/
		tHenkanSession_CleanupHashTable (pSession) ;
		FREE (pSession) ;
	}
	return ;
}

LPCWSTR
THenkanSession_GetKeyword (
	register CTHenkanSession*	pSession,
	register int*				pnWord)
{
	ASSERT (pSession != NULL) ;

	if (pnWord != NULL)
		*pnWord	= pSession->_nwstrKeyword ;
	return	pSession->_rszKeyword ;
}

BOOL
THenkanSession_NextCandidate (
	register CTHenkanSession*	pSession)
{
	register CTSearchSessionCandidate*	pCandidate ;

	ASSERT (pSession != NULL) ;

	if (pSession->_pCurCandidate == NULL)
		return	FALSE ;

	pCandidate		= TSearchSessionCandidate_GetNext (pSession->_pCurCandidate) ;
	if (pCandidate == NULL) {
		/*	Session ���p�����Ă������́A������������B*/
		while (pSession->_nSearchCount >= 0) {
			if (! (pSession->_pSearchProc)(pSession))
				return	FALSE ;
			pCandidate	= TSearchSessionCandidate_GetNext (pSession->_pCurCandidate) ;
			if (pCandidate != NULL)
				break ;
		}
		if (pCandidate == NULL)
			return	FALSE ;
	}
	pSession->_pCurCandidate	= pCandidate ;
	return	TRUE ;
}

BOOL
THenkanSession_PreviousCandidate (
	register CTHenkanSession*	pSession)
{
	register CTSearchSessionCandidate*	pCandidate ;

	ASSERT (pSession != NULL) ;

	if (pSession->_pCurCandidate == NULL)
		return	FALSE ;
	pCandidate		= TSearchSessionCandidate_GetPrevious (pSession->_pCurCandidate) ;
	if (pCandidate == NULL)
		return	FALSE ;
	pSession->_pCurCandidate	= pCandidate ;
	return	TRUE ;
}

BOOL
THenkanSession_Rewind (
	register CTHenkanSession*	pSession)
{
	ASSERT (pSession != NULL) ;

	pSession->_pCurCandidate	= pSession->_pTopCandidate ;
	return	TRUE ;
}

LPCWSTR
THenkanSession_GetCandidate (
	register CTHenkanSession*	pSession)
{
	register int		nPosition ;

	ASSERT (pSession != NULL) ;

	if (pSession->_pCurCandidate == NULL) {
		/*	���肦�Ȃ���ԁB*/
		if (pSession->_pTopCandidate != NULL)
			return	NULL ;

		/*	Session ���p�����Ă������́A������������B*/
		while (pSession->_nSearchCount >= 0) {
			if (! (pSession->_pSearchProc)(pSession))
				return	NULL ;
			if (pSession->_pTopCandidate != NULL)
				break ;
		}
		/*	�����͑S�Ď��s���Ă���B*/
		if (pSession->_pTopCandidate == NULL)
			return	NULL ;
		pSession->_pCurCandidate	= pSession->_pTopCandidate ;
	}
	
	nPosition		= TSearchSessionCandidate_GetValue (pSession->_pCurCandidate) ;
	ASSERT (0 <= nPosition && nPosition < TVarbuffer_GetUsage (&pSession->_vbufCandidate)) ;
	return	(LPCWSTR)TVarbuffer_GetBuffer (&pSession->_vbufCandidate) + nPosition ;
}

BOOL
THenkanSession_InsertCandidate (
	register CTHenkanSession*	pSession,
	register LPCWSTR			wstrCandidate,
	register int				nstrCandidate)
{
	register CTSearchSessionCandidate*	pEntry ;

	if (pSession == NULL || nstrCandidate <= 0 || wstrCandidate == NULL)
		return	FALSE ;

	if (pSession->_pCurCandidate == NULL &&
		pSession->_pTopCandidate != NULL) 
		return	FALSE ;

	if (! TVarbuffer_Add (&pSession->_vbufCandidate, wstrCandidate, nstrCandidate))
		return	FALSE ;

	pEntry	= tHenkanSession_CreateCandidate (pSession, pSession->_nParsePosition, nstrCandidate) ;
	/*	���̃p�[�Y�ʒu�̓o�b�t�@�̍Ō�ɂȂ�Ǝv���B*/
	pSession->_nParsePosition	= TVarbuffer_GetUsage (&pSession->_vbufCandidate) ;

	/*	���[�ށB����͂܂����ȁB*/
	if (pEntry == NULL)
		return	FALSE ;

	if (pSession->_pCurCandidate != NULL) {
		register CTSearchSessionCandidate*	pNextEntry ;

		pNextEntry	= TSearchSessionCandidate_GetNext	(pSession->_pCurCandidate) ;
		TSearchSessionCandidate_SetNext (pSession->_pCurCandidate, pEntry) ;
		if (pNextEntry != NULL) {
			TSearchSessionCandidate_SetPrevious (pNextEntry, pEntry) ;
			TSearchSessionCandidate_SetNext (pEntry, pNextEntry) ;
		} else {
			pSession->_pLastCandidate	= pEntry ;
		}
		TSearchSessionCandidate_SetPrevious (pEntry, pSession->_pCurCandidate) ;
	} else {
		pSession->_pTopCandidate	= pEntry ;
		pSession->_pCurCandidate	= pEntry ;
		pSession->_pLastCandidate	= pEntry ;
	}
	pSession->_nCandidate	++ ;
	return	TRUE ;
}

BOOL
THenkanSession_RemoveCandidate (
	register CTHenkanSession*	pSession)
{
	register CTSearchSessionCandidate*	pPrevEntry ;
	register CTSearchSessionCandidate*	pNextEntry ;

	if (pSession->_pCurCandidate == NULL)
		return	FALSE ;

	pNextEntry	= TSearchSessionCandidate_GetNext	(pSession->_pCurCandidate) ;
	pPrevEntry	= TSearchSessionCandidate_GetPrevious(pSession->_pCurCandidate) ;

	if (pPrevEntry != NULL) {
		TSearchSessionCandidate_SetNext (pPrevEntry, pNextEntry) ;
	} else {
		pSession->_pTopCandidate	= pNextEntry ;
	}
	if (pNextEntry != NULL) {
		TSearchSessionCandidate_SetPrevious (pNextEntry, pPrevEntry) ;
	} else {
		pSession->_pLastCandidate	= pPrevEntry ;
	}
	if (pNextEntry != NULL) {
		pSession->_pCurCandidate	= pNextEntry ;
	} else {
		pSession->_pCurCandidate	= pPrevEntry ;
	}
#if defined (DBG) || defined (DEBUG)
	if (pSession->_nCandidate <= 0) {
		DEBUGPRINTF ((TEXT ("Something wrong in RemoveCandiate (%d < 0)\n"), pSession->_nCandidate)) ;
	}
#endif
	pSession->_nCandidate	-- ;
	return	TRUE ;
}

/* 	#4 �ϊ��̂��߂ɕK�v�B_pRef �� #4 �̓����Ă���ϊ����ʂ��w���悤��
 *	�ݒ肷��B
 *
 *	�Ⴆ�΁A�u����17�v -> �u����#�v�Ō��� -> �u��#4�v-> #4 �ϊ���
 *	���s -> �u��\���v �ƂȂ�킯�����A
 *	�u�\���v�̕��������� #4 �������Ƃ�����񂪕K�v�ɂȂ�B(����͓o�^
 *	�̎���)
 */
BOOL
THenkanSession_LinkCandidate (
	register CTHenkanSession*			pSession,
	register CTSearchSessionCandidate*	pLink)
{
	if (pSession == NULL || pSession->_pCurCandidate == NULL)
		return	FALSE ;
	TSearchSessionCandidate_SetLink (pSession->_pCurCandidate, pLink) ;
	return	TRUE ;
}

LPCWSTR
THenkanSession_GetReferCandidate (
	register CTHenkanSession*	pSession)
{
	CTSearchSessionCandidate*	pRef	= NULL ; 
	register int				nPosition ;

	/*	���̏ꍇ�ɂ́A�u������������v�Ȃ�Ďꏟ�Ȃ��Ƃ͂��Ȃ��B
	 */
	if (pSession == NULL || pSession->_pCurCandidate == NULL) 
		return	NULL ;

	pRef	= TSearchSessionCandidate_GetLink (pSession->_pCurCandidate) ;
	if (pRef == NULL)
		return	NULL ;

	nPosition		= TSearchSessionCandidate_GetValue (pRef) ;
	ASSERT (0 <= nPosition && nPosition < TVarbuffer_GetUsage (&pSession->_vbufCandidate)) ;
	return	(LPCWSTR)TVarbuffer_GetBuffer (&pSession->_vbufCandidate) + nPosition ;
}

CTSearchSessionCandidate*
THenkanSession_GetCurrentPoint (
	register CTHenkanSession*	pSession)
{
	if (pSession == NULL)
		return	NULL ;
	return	pSession->_pCurCandidate ;
}

int
THenkanSession_GetNumberOfCandidate (
	register CTHenkanSession*	pSession,
	register BOOL*				pfContinue)
{
	ASSERT (pSession != NULL) ;
	if (pfContinue != NULL)
		*pfContinue	= (pSession->_nSearchCount >= 0) ;
	return	pSession->_nCandidate ;
}

/*========================================================================*
 */
CTHenkanSession*
tHenkanSession_Create (
	register LPCWSTR	wstring,
	register int		nstring)
{
	register CTHenkanSession*	pSession ;
	register int	n, i ;

	pSession	= MALLOC (sizeof (CTHenkanSession)) ;
	if (pSession == NULL)
		return	NULL ;

	n	= (nstring < MAXKEYWORDLEN)? nstring : MAXKEYWORDLEN ;
	memcpy (pSession->_rszKeyword, wstring, sizeof (WCHAR) * n) ;
	pSession->_nwstrKeyword		= n ;
	pSession->_pCurCandidate	= NULL ;
	pSession->_pTopCandidate	= NULL ;
	pSession->_pLastCandidate	= NULL ;

	for (i = 0 ; i < NELEMENTS (pSession->_rpTblCandidate) ; i ++)
		pSession->_rpTblCandidate [i]	= NULL ;

	TVarbuffer_Init (&pSession->_vbufCandidate, sizeof (WCHAR)) ;
	pSession->_nCandidate		= 0 ;
	pSession->_nSearchCount		= 0 ;
	pSession->_nParsePosition	= 0 ;
	return	pSession ;
}

BOOL
tHenkanSession_UpdateCandidateList (
	register CTHenkanSession*	pSession,
	register int				nPosition)
{
	register int		nEndPos, iSlashCheck, nCount, nPrevPos ;
	register BOOL		fDoubleQuoteCheck ;
	register LPWSTR		ptr ;
#if defined (DBG) || defined (DEBUG)
	int					nFound = 0 ;
#endif

	ptr					= (LPWSTR) TVarbuffer_GetBuffer (&pSession->_vbufCandidate) + nPosition ;
	nEndPos				= TVarbuffer_GetUsage (&pSession->_vbufCandidate) ;
	fDoubleQuoteCheck	= FALSE ;
	nCount				= 0 ;
	iSlashCheck			= 0 ;
	if (nPosition == 0) {
		while (nPosition < nEndPos && ! (pSession->_pSeparatorpProc) (*ptr)) {
			ptr			++ ;
			nPosition	++ ;
		}
	}
	nPrevPos			= nPosition ;

	while (nPosition < nEndPos) {
		/* �_�u���N�E�H�[�g�𖳎�����_�������Ŋm�F����B*/
		if (iSlashCheck <= 0 && *ptr == L'\\')
			iSlashCheck	= 2 ;
		if (iSlashCheck <= 0) {
			switch (*ptr){
				/* Double Quote �̊Ԃ͗v���ӁB�o�b�N�X���b�V���̎��ł͂Ȃ��_�u
				 * ���N�E�H�[�g�Ɉ͂܂ꂽ�����͈�̕�����(�Ƃ��������Ƃ���
				 * ���������B���ɂ��̒��� slash �������Ă��Ă��������邱�Ƃɂ�
				 * ��B*/  
			case 0x22:
				if (!fDoubleQuoteCheck){
					/* �����_�u���N�E�H�[�g�̒��ɂȂ���΁A���������̕���
					 * �񂪊J�n�������ƂɂȂ�B*/
					fDoubleQuoteCheck	= TRUE ;
				} else {
					/* �����_�u���N�E�H�[�g�̒��Ń_�u���N�E�H�[�g�����t������c�B 
					 * ���R�A�_�u���N�E�H�[�g�̒��𔲂������ƂɂȂ�B*/
					fDoubleQuoteCheck 	= FALSE ;
				}
				/* �J�[�\���ʒu�̈ړ��B*/
				ptr			++ ;
				nPosition	++ ;
				nCount		++ ;
				continue ;
				
				/* ������̏I�[�����t���Ă��܂����ꍇ�̏����B*/
			case L'\n' :
			case L'\r' :
			case L'\0' :
				/* �������ɏI�[�����̓_�u���N�E�H�[�g�̒����낤�������낤����
				 * ���ł��Ȃ��c�B�����_�u���N�E�H�[�g�̒��ɓo�ꂵ����G���[��
				 * �O�̉��҂ł��Ȃ��B*/
				goto exit_loop ;

			default :
				/* �^�͌��ƌ��̊ԂɕK�����݂���B*/
				if ((pSession->_pSeparatorpProc) (*ptr)) {
					/* �_�u���N�E�H�[�g�̒��ɓo�ꂵ���̂ł���΁A�{���̋@�\�͖����B*/
					if (fDoubleQuoteCheck)
						break ;
				
					/* �����̈ʒu�̕����͏I�[�������č\���܂��B���F��؂�ȊO�ɖ�
					 * �����ĂȂ��̂�����B����Ȃ� NUL �����ł��\���B*/
					*ptr	= L'\0' ;
					/* �V�����m�[�h���������B*/
					if (nCount > 0 && nPrevPos < nPosition) {
						/*	����(annotation) �����݂���\��������B�\���c�ł��邩
						 *	�ۂ��͒u���Ă����āA���̏����������Ȃ���΁B
						 */
						tHenkanSession_NewCandidate (pSession, nPrevPos, nCount) ;
#if defined (DBG) || defined (DEBUG)
						nFound ++ ;
#endif
					}
					/* �ꏊ�y�сA�|�C���^������₷�B*/
					ptr			++ ;
					nPosition	++ ;
					/* �O��(�܂荡�̏ꏊ)�A"/" �����t�����ꏊ�� pPos �ɋL������B*/
					nPrevPos	= nPosition ;
					nCount		= 0 ;
					continue ;
				} else {
					break ;
				}
			}
		}
		ptr			++ ;
		nPosition	++ ;
		nCount		++ ;
		if (iSlashCheck > 0)
			iSlashCheck	-- ;
	}
  exit_loop:
#if defined (DBG) || defined (DEBUG)
	DEBUGPRINTF ((TEXT ("_UpdateCandidateList (found: %d)\n"), nFound)) ;
#endif
	return	nPrevPos ;
}

CTSearchSessionCandidate*
tHenkanSession_CreateCandidate (
	register CTHenkanSession*	pSession,
	register int				nPosition,
	register int				nCount)
{
	register CTSearchSessionCandidate*	pEntry ;
	register LPCWSTR	wstring ;

	wstring	= (LPCWSTR) TVarbuffer_GetBuffer (&pSession->_vbufCandidate) + nPosition ;
	if (tHenkanSession_IsExistCandidatep (pSession, wstring, nCount))
		return	NULL ;

	pEntry	= TSearchSessionCandidate_Create (nPosition) ;
	if (pEntry == NULL)
		return	NULL ;
	if (! tHenkanSession_RegisterCandidate (pSession, pEntry)) {
		FREE (pEntry) ;
		return	NULL ;
	}
	return	pEntry ;
}

BOOL
tHenkanSession_NewCandidate (
	register CTHenkanSession*	pSession,
	register int				nPosition,
	register int				nCount)
{
	register CTSearchSessionCandidate*	pEntry ;

	pEntry	= tHenkanSession_CreateCandidate (pSession, nPosition, nCount) ;
	if (pEntry == NULL)
		return	FALSE ;

	if (pSession->_pLastCandidate != NULL) 
		TSearchSessionCandidate_SetNext (pSession->_pLastCandidate, pEntry) ;
	if (pSession->_pTopCandidate == NULL)
		pSession->_pTopCandidate	= pEntry ;
	TSearchSessionCandidate_SetPrevious (pEntry, pSession->_pLastCandidate) ;
	pSession->_pLastCandidate	= pEntry ;
	pSession->_nCandidate	++ ;
	return	TRUE ;
}

BOOL
tHenkanSession_IsExistCandidatep (
	register CTHenkanSession*	pSession,
	register LPCWSTR	wstring,
	register int		nstring)
{
	register CTSearchSessionCandidate*	pEntry ;
	register int		nIndex, nPosition, nszBuffer, nCompare ;
	register LPCWSTR	wszBuffer ;

	nIndex		= (unsigned int)*wstring * nstring % CANDIDATEHASHSIZE ;
	ASSERT (0 <= nIndex && nIndex < CANDIDATEHASHSIZE) ;
	pEntry		= pSession->_rpTblCandidate [nIndex] ;
	if (pEntry == NULL)
		return	FALSE ;
	wszBuffer	= TVarbuffer_GetBuffer (&pSession->_vbufCandidate) ;
	nszBuffer	= TVarbuffer_GetUsage  (&pSession->_vbufCandidate) ;
	while (pEntry != NULL) {
		nPosition	= TSearchSessionCandidate_GetValue (pEntry) ;
		ASSERT (0 <= nPosition && nPosition < nszBuffer) ;
		nCompare	= wcsncmp (wstring, wszBuffer + nPosition, nstring) ;
		if (nCompare == 0) {
			if (*(wszBuffer + nPosition + nstring) == L'\0') 
				return	TRUE ;
			nCompare	= 1 ;
		}
		if (nCompare > 0) {
			pEntry	= TSearchSessionCandidate_GetRight (pEntry) ;
		} else {
			pEntry	= TSearchSessionCandidate_GetLeft  (pEntry) ;
		}
	}
	return	FALSE ;
}

BOOL
tHenkanSession_RegisterCandidate (
	register CTHenkanSession*	pSession,
	register CTSearchSessionCandidate*	pNewEntry)
{
	register CTSearchSessionCandidate*	pEntry ;
	register int		nIndex, nPosition, nstring, nszBuffer, nCompare ;
	register LPCWSTR	wszBuffer ;
	register LPCWSTR	wstring ;

	wszBuffer	= TVarbuffer_GetBuffer (&pSession->_vbufCandidate) ;
	nszBuffer	= TVarbuffer_GetUsage  (&pSession->_vbufCandidate) ;
	wstring		= wszBuffer + TSearchSessionCandidate_GetValue (pNewEntry) ;
	nstring		= lstrlenW (wstring) ;
	nIndex		= (unsigned int)*wstring * nstring % CANDIDATEHASHSIZE ;
	ASSERT (0 <= nIndex && nIndex < CANDIDATEHASHSIZE) ;
	pEntry		= pSession->_rpTblCandidate [nIndex] ;
	if (pEntry == NULL) {
		pSession->_rpTblCandidate [nIndex]	= pNewEntry ;
		return	TRUE ;
	}

	while (pEntry != NULL) {
		nPosition	= TSearchSessionCandidate_GetValue (pEntry) ;
		ASSERT (0 <= nPosition && nPosition < nszBuffer) ;
		nCompare	= wcsncmp (wstring, wszBuffer + nPosition, nstring) ;
		if (nCompare == 0) {
			if (*(wszBuffer + nPosition + nstring) == L'\0') 
				return	TRUE ;
			nCompare	= 1 ;
		}
		if (nCompare > 0) {
			if (TSearchSessionCandidate_GetRight (pEntry) == NULL) {
				TSearchSessionCandidate_SetRight (pEntry, pNewEntry) ;
				return	TRUE ;
			}
			pEntry	= TSearchSessionCandidate_GetRight (pEntry) ;
		} else {
			if (TSearchSessionCandidate_GetLeft (pEntry) == NULL) {
				TSearchSessionCandidate_SetLeft (pEntry, pNewEntry) ;
				return	TRUE ;
			}
			pEntry	= TSearchSessionCandidate_GetLeft (pEntry) ;
		}
	}
	return	FALSE ;
}

BOOL
tHenkanSession_CleanupHashTable (
	register CTHenkanSession*	pSession)
{
	register int		i ;

	for (i = 0 ; i < CANDIDATEHASHSIZE ; i ++) {
		if (pSession->_rpTblCandidate [i] != NULL)
			tHenkanSession_CleanupHashTableSub (pSession->_rpTblCandidate [i]) ;
	}
	return	TRUE ;
}

BOOL
tHenkanSession_CleanupHashTableSub (
	register CTSearchSessionCandidate*	pEntry)
{
	register CTSearchSessionCandidate*	pLeft ;
	register CTSearchSessionCandidate*	pRight ;

	ASSERT (pEntry != NULL) ;

	pLeft	= TSearchSessionCandidate_GetLeft (pEntry) ;
	pRight	= TSearchSessionCandidate_GetRight (pEntry) ;
	if (pLeft  != NULL) 
		tHenkanSession_CleanupHashTableSub (pLeft) ;
	if (pRight != NULL)
		tHenkanSession_CleanupHashTableSub (pRight) ;
	FREE (pEntry) ;
	return	TRUE ;
}

/*========================================================================
 */
BOOL
tHenkanSession_Search (
	register CTHenkanSession*	pSession)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	BOOL				fResult	= FALSE ;
	WORD				woTotalResult ;
	int					nMajor, nMinor, nSize, nRecv ;
	register LPCWSTR	strResult ;
	register int		nResult ;
	register int		nNext	= -1 ;

	ASSERT (pSession != NULL) ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_SEARCH_EX, pSession->_nSearchCount) ||
		! TPacket_AddString (&packet, pSession->_rszKeyword, pSession->_nwstrKeyword) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_SEARCH_REPLY)
		goto	exit_func ;
	if (! TPacket_GetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &woTotalResult))
		goto	exit_func ;
	
	if ((int)(woTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;
	
	strResult	= (LPCWSTR)(TPacket_GetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	nResult		= (nResult > woTotalResult)? woTotalResult : nResult ;
	if (woTotalResult > 0) {
		if (! TVarbuffer_Add (&pSession->_vbufCandidate, strResult, nResult))
			goto	exit_func ;
		pSession->_nParsePosition	= tHenkanSession_UpdateCandidateList (pSession, pSession->_nParsePosition) ;
	}
	fResult		= TRUE ;
	nNext		= (signed char)nMinor ;
	if (0 <= nNext && nNext <= pSession->_nSearchCount)
		nNext	= -1 ;
	
  exit_func:
	pSession->_nSearchCount	= nNext ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fResult ;
}

BOOL
tOkuriHenkanSession_Search (
	register CTHenkanSession*	pSession)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	BOOL				fResult	= FALSE ;
	WORD				woTotalResult ;
	int					nMajor, nMinor, nSize, nRecv ;
	register LPCWSTR	strResult ;
	register int		nResult ;
	register int		nNext	= -1 ;

	ASSERT (pSession != NULL) ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_OKURI_SEARCH_EX, pSession->_nSearchCount) ||
		! TPacket_AddString (&packet, pSession->_rszKeyword, pSession->_nwstrKeyword) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_SEARCH_REPLY)
		goto	exit_func ;
	if (! TPacket_GetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &woTotalResult))
		goto	exit_func ;
	
	if ((int)(woTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;
	
	strResult	=  (LPCWSTR)(TPacket_GetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	nResult		= (nResult > woTotalResult)? woTotalResult : nResult ;
	if (woTotalResult > 0) {
		if (! TVarbuffer_Add (&pSession->_vbufCandidate, strResult, nResult))
			goto	exit_func ;
		pSession->_nParsePosition	= tHenkanSession_UpdateCandidateList (pSession, pSession->_nParsePosition) ;
	}
	fResult		= TRUE ;
	nNext		= (signed char)nMinor ;
	if (0 <= nNext && nNext <= pSession->_nSearchCount)
		nNext	= -1 ;
	
  exit_func:
	/* session �̏I���́c���͈�񌟍������Ȃ��̂ŁA�����ŏI���B*/
	pSession->_nSearchCount	= nNext ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fResult ;
}

BOOL
tHenkanSession_IsSeparator (
	register WCHAR		wch)
{
	return	(wch == L'/') ;
}

BOOL
tCompletionSession_Search (
	register CTHenkanSession*	pSession)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	BOOL				fResult	= FALSE ;
	WORD				woTotalResult ;
	int					nMajor, nMinor, nSize, nRecv ;
	register LPCWSTR	strResult ;
	register int		nResult ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_COMPLETION, 1) ||
		! TPacket_AddString (&packet, pSession->_rszKeyword, pSession->_nwstrKeyword) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_COMPLETION_REPLY)
		goto	exit_func ;
	if (! TPacket_GetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &woTotalResult))
		goto	exit_func ;
	
	if ((int)(woTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;
	
	strResult	= (LPCWSTR)(TPacket_GetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	nResult		= (nResult > woTotalResult)? woTotalResult : nResult ;
	if (woTotalResult > 0) {
		if (! TVarbuffer_Add (&pSession->_vbufCandidate, strResult, nResult))
			goto	exit_func ;
		pSession->_nParsePosition	= tHenkanSession_UpdateCandidateList (pSession, pSession->_nParsePosition) ;
	}
	fResult			= TRUE ;
	
  exit_func:
	/* session �̏I���́c���͈�񌟍������Ȃ��̂ŁA�����ŏI���B*/
	pSession->_nSearchCount	= -1 ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fResult ;
}

BOOL
tCompletionSession_IsSeparator (
	register WCHAR		wch)
{
	return	(wch == L' ') ;
}

/*========================================================================*
 */
BOOL
TServerSession_ClassInit (void)
{
	WCHAR		rszUserName [UNLEN + 1] ;
	ULONG		ulUserNameLen ;
	register LPWSTR		ptr ;
	register LPWSTR		pSrc ;
	register int		nptr, n ;

	ulUserNameLen	= sizeof (rszUserName) / sizeof (rszUserName [0]) - 1 ;
	if (! GetUserNameW (rszUserName, &ulUserNameLen)) 
		return	FALSE ;
	rszUserName [UNLEN]	= TEXT ('\0') ;

	/*	�V�X�e�����[�U�͍��Ȃ��c�Ƃ���B
	 *
	 *	�V�X�e���ƒʏ�̃��[�U�̓v���Z�X��Ԃ����L����̂ŁA������ skkiserv
	 *	���N������ƁAsystem �̃v���t�B�[���œ����Ă��� skkiserv �Ɉ�ʃ��[
	 *	�U�� query �������邱�ƂɂȂ�...��ʃ��[�U�̐ݒ肪���f����Ȃ��Ȃ���
	 *	���܂��B
	 *	��``SYSTEM'' �������炵�����ǁAcase �������Ĕ�r����B
	 */
	if (! lstrcmpiW (rszUserName, L"system")) 
		return	FALSE ;

	ptr		= _rszSkkImePipeName ;
	nptr	= MAX_PATH ;
	lstrcpyW (ptr, L"\\\\.\\pipe\\pskkime-") ;
	n		= lstrlenW (ptr) ;
	ptr		+= n ;
	nptr	-= n ;
	pSrc	= rszUserName ;
	while (nptr > 0 && *pSrc != L'\0') {
		/*	�p�X�����Ƃ��Ďg�p�ł��Ȃ����͎̂̂Ă�B*/
		if (*pSrc == L'\\' || *pSrc == L'*' || *pSrc == L'?' ||
			*pSrc == L':'  || *pSrc == L'.' || *pSrc == L'/') {
			*ptr ++	= L'-' ;
		} else {
			*ptr ++	= *pSrc ;
		}
		pSrc	++ ;
		nptr	-- ;
	}
	DEBUGPRINTF ((TEXT ("skimic: pipename = \"%s\"\n"), _rszSkkImePipeName)) ;
	return	TRUE ;
}

HANDLE
tServerSession_OpenServer (void)
{
	register HANDLE		hPipe ;
	register int		nRetry ;
	register BOOL		fServerStart ;

	hPipe			= INVALID_HANDLE_VALUE ;
	nRetry			= OPENSERVER_MAX_RETRY ;
	fServerStart	= FALSE ;
	while (nRetry -- > 0) {
		register DWORD	dwError ;

		hPipe	= CreateFileW (_rszSkkImePipeName, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0) ;
		dwError	= GetLastError () ;
		if (hPipe != INVALID_HANDLE_VALUE) {
			break ;
		}
		if (dwError != ERROR_PIPE_BUSY) {
			if (dwError == ERROR_FILE_NOT_FOUND) {
				if (! fServerStart) {
					if (! tServerSession_StartServer ())
						break ;
					fServerStart	= TRUE ;
				}
				/*	skkiserv ���N���Ă���̂�҂B*/
				Sleep (100) ;
				continue ;
			}
			/*	ERROR_FILE_NOT_FOUND �ȊO�̏ꍇ�ɂ͑z��O�Ȃ̂Ŕ�����B*/
			break ;
		}
		/*	PIPE �� BUSY �łȂ��Ȃ�̂�҂B�������A�����҂�����
		 *	PIPE �� BUSY �łȂ��Ȃ����̂ɐ��䂪�߂�Ȃ����Ƃ�����̂�
		 *	(�^�C�~���O�ˑ��H)
		 *	��莞�Ԃŏ����𔲂��ABUSY �Ȃ�ēx�҂A�Ƃ������Ƃ��J��
		 *	�Ԃ��B
		 */
		if (WaitNamedPipeW (_rszSkkImePipeName, 100) == 0) {
			dwError	= GetLastError () ;
			if (dwError != ERROR_SEM_TIMEOUT && dwError != ERROR_FILE_NOT_FOUND)
				break ;
		}
	}
	return	hPipe ;
}

BOOL
tServerSession_Send (
	register HANDLE			hPipe,
	register CTPacket*		pPacket)
{
	register const BYTE*	ptr		= TPacket_GetData (pPacket) ;
	register int			nptr	= TPacket_GetSize (pPacket) ;
	DWORD					dwWrite ;

	while (nptr > 0) {
		if (! WriteFile (hPipe, ptr, nptr, &dwWrite, NULL)) {
/*			DWORD	dwError	= GetLastError () ;*/
			return	FALSE ;
		}
		ptr		+= dwWrite ;
		nptr	-= dwWrite ;
	}
	FlushFileBuffers (hPipe) ;
	return	TRUE ;
}

BOOL
tServerSession_Recv (
	register HANDLE		hPipe,
	register CTPacket*	pPacket)
{
	DWORD	dwRead ;

	if (! ReadFile (hPipe, TPacket_GetData (pPacket), PACKETBUFSIZE, &dwRead, NULL)) {
		DWORD	dwError	= GetLastError () ;
		return	FALSE ;
	}
	TPacket_SetSize (pPacket, dwRead) ;
	return	TRUE ;
}

BOOL
tServerSession_StartServer (void)
{
	WCHAR					rszWindowsDir [MAX_PATH + 1] ;
	WCHAR					rszCmd [MAX_PATH + 1] ;
    STARTUPINFOW			si ;
    PROCESS_INFORMATION		pi ;
	register int			nWindowsDir, n ;
	register BOOL			fRetval ;

	nWindowsDir	= GetWindowsDirectoryW (rszWindowsDir, MAX_PATH) ;
	n			= (nWindowsDir < MAX_PATH)? nWindowsDir : MAX_PATH ;
	wcsncpy (rszCmd, rszWindowsDir, n) ;
	rszCmd [n]	= L'\0' ;
	wcsncpy (rszCmd + n, L"\\" PROGRAMF_DIR L"\\" SKKIMEProg_S_DIR L"\\" SKKIMEServerFile, MAX_PATH - n) ;
	rszCmd [MAX_PATH - 1]	= L'\0' ;

	ZeroMemory (&si, sizeof(si)) ;
	si.cb	= sizeof (si) ;

	/*	������ pipename ��n���\���ɖ߂��Ă݂�B(�����P�T�N�V���Q�S��(��))
	 *	Windows2000sp4 �� skkiserv �� connect ���s���錻�ۂ�������̂ŁB
	 *	�����͂����̏������낤���H 
	 *	���̂� skkiserv �� pipename ������ɍ���Ă����Ɨ\�z���Ă��鎞��
	 *	if (! CreateProcessW (rszCmd, L"", NULL, NULL, FALSE, 0, NULL, rszWindowsDir, &si, &pi)) {
	 *	�����B
	 */
	if (! CreateProcessW (rszCmd, &_rszSkkImePipeName [SKKIME_PIPE_PREFIX_NUM], NULL, NULL, FALSE, 0, NULL, rszWindowsDir, &si, &pi)) {
		DWORD	dwError	= GetLastError () ;
		fRetval	= FALSE ;
	} else {
		WaitForInputIdle (pi.hProcess, 3000) ;

		/* �s�v�ɂȂ����n���h��������B*/
		CloseHandle (pi.hProcess) ;
		CloseHandle (pi.hThread) ;
		fRetval	= TRUE ;
	}
	return	fRetval ;
}

/*========================================================================*
 */
CTSearchSessionCandidate*
TSearchSessionCandidate_Create (
	register int		nPosition)
{
	register CTSearchSessionCandidate*	pCandidate ;

	pCandidate	= MALLOC (sizeof (CTSearchSessionCandidate)) ;
	if (pCandidate == NULL)
		return	NULL ;

	pCandidate->_nIndex	= nPosition ;
	pCandidate->_pPrev	= NULL ;
	pCandidate->_pNext	= NULL ;
	pCandidate->_pLeft	= NULL ;
	pCandidate->_pRight	= NULL ;
	pCandidate->_pRef	= NULL ;
	return	pCandidate ;
}

CTSearchSessionCandidate*
TSearchSessionCandidate_GetNext	(
	register CTSearchSessionCandidate*	pCandidate)
{
	ASSERT (pCandidate != NULL) ;
	return	pCandidate->_pNext ;
}

CTSearchSessionCandidate*
TSearchSessionCandidate_GetPrevious	(
	register CTSearchSessionCandidate*	pCandidate)
{
	ASSERT (pCandidate != NULL) ;
	return	pCandidate->_pPrev ;
}

CTSearchSessionCandidate*
TSearchSessionCandidate_GetLeft	(
	register CTSearchSessionCandidate*	pCandidate)
{
	ASSERT (pCandidate != NULL) ;
	return	pCandidate->_pLeft ;
}

CTSearchSessionCandidate*
TSearchSessionCandidate_GetRight	(
	register CTSearchSessionCandidate*	pCandidate)
{
	ASSERT (pCandidate != NULL) ;
	return	pCandidate->_pRight ;
}

void
TSearchSessionCandidate_SetNext (
	register CTSearchSessionCandidate*	pCur,
	register CTSearchSessionCandidate*	pNext)
{
	ASSERT (pCur != NULL) ;
	pCur->_pNext	= pNext ;
	return ;
}

void
TSearchSessionCandidate_SetPrevious (
	register CTSearchSessionCandidate*	pCur,
	register CTSearchSessionCandidate*	pPrev)
{
	ASSERT (pCur != NULL) ;
	pCur->_pPrev	= pPrev ;
	return ;
}

void
TSearchSessionCandidate_SetLeft (
	register CTSearchSessionCandidate*	pCur,
	register CTSearchSessionCandidate*	pLeft)
{
	ASSERT (pCur != NULL) ;
	pCur->_pLeft	= pLeft ;
	return ;
}

void
TSearchSessionCandidate_SetRight (
	register CTSearchSessionCandidate*	pCur,
	register CTSearchSessionCandidate*	pRight)
{
	ASSERT (pCur != NULL) ;
	pCur->_pRight	= pRight ;
	return ;
}

int
TSearchSessionCandidate_GetValue (
	register CTSearchSessionCandidate*	pCandidate)
{
	ASSERT (pCandidate != NULL) ;
	return	pCandidate->_nIndex ;
}

void
TSearchSessionCandidate_SetLink (
	register CTSearchSessionCandidate*	pCur,
	register CTSearchSessionCandidate*	pRef)
{
	ASSERT (pCur != NULL) ;
	pCur->_pRef	= pRef ;
	return ;
}

CTSearchSessionCandidate*
TSearchSessionCandidate_GetLink (
	register CTSearchSessionCandidate*	pCur)
{
	ASSERT (pCur != NULL) ;
	return	pCur->_pRef ;
}

/*========================================================================*
 */
BOOL
RecordCandidate (
	register LPCWSTR	wstrHenkanKey,
	register int		nstrHenkanKey,
	register LPCWSTR	wstrResult,
	register int		nstrResult,
	register BOOL		fOkurigana)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_RECORD, fOkurigana) ||
		! TPacket_AddString (&packet, wstrHenkanKey, nstrHenkanKey) ||
		! TPacket_AddString (&packet, wstrResult, nstrResult) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_RECORD_REPLY) ;
}

BOOL
PurgeCandidate (
	register LPCWSTR	wstrHenkanKey, 
	register int		nstrHenkanKey,
	register LPCWSTR	wstrResult,
	register int		nstrResult,
	register BOOL		fOkurigana)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_PURGE, fOkurigana) ||
		! TPacket_AddString (&packet, wstrHenkanKey, nstrHenkanKey) ||
		! TPacket_AddString (&packet, wstrResult, nstrResult) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_PURGE_REPLY) ;
} 

/*========================================================================*
 */
BOOL
SetCutBuffer (
	register LPCWSTR	pSrc,
	register int		nSrc,
	register BOOL		fAppend)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor, nMinor, nSize ;
	register int		nRecv ;
	register BOOL		fRetval	= FALSE ;

	hPipe		= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE) 
		return	FALSE ;

	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_SETCUTBUFFER, fAppend) ||
		! TPacket_AddString (&packet, pSrc, nSrc) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	fRetval	= (nMajor == SKKISERV_PROTO_SETCUTBUFFER_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

int
GetCutBuffer (
	register LPWSTR		pDest,
	register int		nDest)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	register int		nBufferLeft	= nDest ;
	register LPCWSTR	pResult ;
	register int		nRecv, nResult ;
	int					nMajor, nMinor, nSize ;
	WORD				wTotalResult ;

	hPipe		= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE) 
		return	FALSE ;

	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader  (&packet, SKKISERV_PROTO_GETCUTBUFFER, 0) ||
		! TPacket_SetLength  (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;

	if (! tServerSession_Recv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	if (nMajor != SKKISERV_PROTO_GETCUTBUFFER_REPLY ||
		! TPacket_GetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;

	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	pResult	= (LPCWSTR)(TPacket_GetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult	= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	if (wTotalResult > 0) {
		register int		nTotalResult	= wTotalResult ;
		register int		nCopy ;
		register LPWSTR		ptr				= pDest ;

		/*	����擾�����ʂ͂ǂ�����ATotal Size �𒴂��邱�Ƃ͂����Ă�
		 *	�Ȃ�Ȃ����B
		 */
		if (nResult > nTotalResult)
			nResult		= nTotalResult ;

		nCopy			= (nResult < nBufferLeft)? nResult : nBufferLeft ;
		memcpy (ptr, pResult, nCopy * sizeof (WCHAR)) ;
		ptr				+= nCopy ;
		nTotalResult	-= nCopy ;
		nBufferLeft		-= nCopy ;
		while (nTotalResult > 0 && nBufferLeft > 0) {
			if (! tServerSession_Recv (hPipe, &packet))
				break ;
			nRecv	= TPacket_GetSize (&packet) ;
			if (nRecv < 0)
				break ;
			pResult	= (LPCWSTR) TPacket_GetData (&packet) ;
			nResult	= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;
			nCopy			= (nResult < nBufferLeft)? nResult : nBufferLeft ;
			memcpy (ptr, pResult, nCopy * sizeof (WCHAR)) ;
			ptr				+= nCopy ;
			nTotalResult	-= nCopy ;
			nBufferLeft		-= nCopy ;
		}
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nDest - nBufferLeft) ;
}

/*========================================================================*
 */
BOOL
TLispEval (
	register LPCWSTR	wstrHenkanKey,
	register int		nstrHenkanKey,
	register LPWSTR		wstrDest,
	register int		nstrDest)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize ;
	WORD				wTotalResult ;
	register LPCWSTR	wstrResult ;
	register int		nResult, nRecv ;
	register BOOL		fRetval	= FALSE ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_EVAL, 0) ||
		! TPacket_AddString (&packet, wstrHenkanKey, nstrHenkanKey) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_EVAL_REPLY)
		goto	exit_func ;
	if (! TPacket_GetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;
	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	wstrResult	= (LPCWSTR)(TPacket_GetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	if (wTotalResult > 0) {
		register int		nTotalResult	= wTotalResult ;
		register int		nCopy ;

		if (nResult > nTotalResult)
			nResult		= nTotalResult ;
		nCopy			= (nResult < nstrDest)? nResult : nstrDest ;
		memcpy (wstrDest, wstrResult, nCopy * sizeof (WCHAR)) ;
		wstrDest		+= nCopy ;
		nTotalResult	-= nCopy ;
		nstrDest		-= nCopy ;
		while (nTotalResult > 0 && nstrDest > 0) {
			if (! tServerSession_Recv (hPipe, &packet))
				break ;
			nRecv	= TPacket_GetSize (&packet) ;
			if (nRecv < 0)
				break ;
			wstrResult	= (LPCWSTR) TPacket_GetData (&packet) ;
			nResult		= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;
			nCopy			= (nResult < nstrDest)? nResult : nstrDest ;
			memcpy (wstrDest, wstrResult, nCopy * sizeof (WCHAR)) ;
			wstrDest		+= nCopy ;
			nTotalResult	-= nCopy ;
			nstrDest		-= nCopy ;
		}
		if (nstrDest > 0) 
			*wstrDest	= L'\0' ;
		fRetval	= TRUE ;
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

BOOL
TSetJNumList (
	register LPCWSTR	wstrJNumList,
	register int		nstrJNumList)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize ;
	register int		nRecv ;
	register BOOL		fRetval	= FALSE ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_SETJNUMLIST, 0) ||
		! TPacket_AddString (&packet, wstrJNumList, nstrJNumList) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	fRetval	= (nMajor == SKKISERV_PROTO_SETJNUMLIST_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

/*========================================================================*
 */
BOOL
UpdateServerConfiguration (void)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_UPDATE, 0) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_UPDATE_REPLY) ;
}

BOOL
SynchronizeLocalJisyo (void)
{
	CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= tServerSession_OpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_Initialize (&packet) ;
	if (! TPacket_SetHeader (&packet, SKKISERV_PROTO_SAVELOCALJISYO, 0) ||
		! TPacket_SetLength (&packet) ||
		! tServerSession_Send (hPipe, &packet))
		goto	exit_func ;
	
	if (! tServerSession_Recv (hPipe, &packet) ||
		! TPacket_GetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_GetSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_SAVELOCALJISYO_REPLY) ;
}

