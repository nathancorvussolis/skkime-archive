#pragma once

#include <windows.h>
#include <tchar.h>
#include <commctrl.h>
#include <shlwapi.h>
#include <limits.h>
#include <stddef.h>
#include <assert.h>

#if !defined (NELEMENTS)
#define	NELEMENTS(myarray)	(sizeof(myarray)/sizeof(myarray[0]))
#endif
#if !defined (MALLOC)
#define	MALLOC(iSize)		malloc((iSize))
#endif
#if !defined (FREE)
#define	FREE(ptr)			free((ptr))
#endif
#if !defined (NELEMENTS)
#define	NELEMENTS(array)	(sizeof (array) / sizeof (array[0]))
#endif
#if defined (DEBUG)
#include "debug.h"
#define	DEBUGPRINTF(arg)	DebugPrintf##arg
#define	DEBUGPRINTFW(arg)	DebugPrintfW##arg
#define	ASSERT(x)			assert((x))
#else
#define	DEBUGPRINTF(arg)	/*arg*/
#define	DEBUGPRINTFW(arg)	/*arg*/
#define	ASSERT(expr)		/*expr*/
#endif

