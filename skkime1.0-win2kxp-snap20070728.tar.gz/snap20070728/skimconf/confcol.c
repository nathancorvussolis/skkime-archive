/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#define	REGPATH_COLORFACE	REGPATH_SKKIME_BASE TEXT("\\ColorFace")
#define	REGSUBKEY_COLORFACE	TEXT("style")

typedef struct tagMYCOLORDEF {
	LPTSTR		m_strText ;
	int			m_nType ;
}	MYCOLORDEF ;

/*========================================================================*
 *	prototypes
 */
static	INT_PTR	skkimeConfig_dlgColorFaceOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgColorFaceOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgColorFaceOnCommand		(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL	skkimeConfig_setupColorComboBox		(HWND) ;
static	BOOL	skkimeConfig_setupLineTypeComboBox	(HWND) ;
static	void	skkimeConfig_setColorComboBox		(HWND, const MYCOLORFACESET*) ;

static	BOOL	skkimeConfig_initColorFace (LPCTSTR, MYCOLORFACESET*, const MYCOLORFACESET*, int) ;
static	BOOL	skkimeConfig_updateColorFace (LPCTSTR, MYCOLORFACESET*) ;

/*========================================================================*
 *	global variables
 */
static	MYCOLORFACESET		srSkkImeDefaultColorFace []	= {
	/*	���ϊ�������B*/
	{ MYCOLOR_TEXTAUTO,			/* ����(����) */	/* �����F�B*/
	  MYCOLOR_BACKAUTO,			/* ����(�w�i) */ 	/* �w�i�F�B*/
	  MYCOLOR_TEXTAUTO,			/* ����(����) */	/* �����F�B*/
	  MYLINE_THIN_DITHER,		/* �f�B�U(��) */	/* �����^�C�v�B*/
	},
	/*	�ϊ�������B*/
	{ MYCOLOR_HIGHLIGHTTEXT,	/* �I������(����) */	/* �����F�B*/
	  MYCOLOR_HIGHLIGHT,		/* �I������(�w�i) */	/* �w�i�F�B*/
	  MYCOLOR_TEXTAUTO,			/* ����(����) */	 	/* �����F�B*/
	  MYLINE_NO,				/* �Ȃ� */				/* �����^�C�v�B*/
	},
} ;

static	MYCOLORDEF		srSkkImeColorDefinition []	= {
	{ TEXT ("����(����)"),						MYCOLOR_TEXTAUTO, },
	{ TEXT ("����(�w�i)"),						MYCOLOR_BACKAUTO, },
	{ TEXT ("��"),								MYCOLOR_BLACK, },
	{ TEXT ("�Â���"),							MYCOLOR_DARKRED, },	
	{ TEXT ("�Â���"),							MYCOLOR_DARKGREEN, },
	{ TEXT ("�Â����F"),						MYCOLOR_DARKYELLOW, },
	{ TEXT ("�Â���"),							MYCOLOR_DARKBLUE, },
	{ TEXT ("�Â���"),							MYCOLOR_DARKPURPLE, },
	{ TEXT ("�Â����F"),						MYCOLOR_DARKLIGHTBLUE, },
	{ TEXT ("�Â��D�F"),						MYCOLOR_DARKGRAY, },
	{ TEXT ("���邢�D�F"),						MYCOLOR_LIGHTGRAY, },
	{ TEXT ("��"),								MYCOLOR_RED, },
	{ TEXT ("��"),								MYCOLOR_GREEN, },
	{ TEXT ("���F"),							MYCOLOR_YELLOW, },
	{ TEXT ("��"),								MYCOLOR_BLUE, },
	{ TEXT ("��"),								MYCOLOR_PURPLE, },
	{ TEXT ("���F"),							MYCOLOR_LIGHTBLUE, },
	{ TEXT ("��"),								MYCOLOR_WHITE, },
	{ TEXT ("3D�I�u�W�F�N�g"),					MYCOLOR_BTNFACE, },
	{ TEXT ("3D�I�u�W�F�N�g�̕���"),			MYCOLOR_BTNTEXT, },
	{ TEXT ("�A�N�e�B�u �E�B���h�E�̋��E"),		MYCOLOR_ACTIVEBORDER, },
	{ TEXT ("�A�N�e�B�u �^�C�g�� �o�["),		MYCOLOR_ACTIVECAPTION, },
	{ TEXT ("�A�N�e�B�u �^�C�g�� �o�[�̕���"),	MYCOLOR_CAPTIONTEXT, },
	{ TEXT ("�A�v���P�[�V������ƈ�"),			MYCOLOR_APPWORKSPACE, },
	{ TEXT ("�E�B���h�E"),						MYCOLOR_WINDOW, },
	{ TEXT ("�E�B���h�E�̕���"),				MYCOLOR_WINDOWTEXT, },
	{ TEXT ("�f�X�N�g�b�v"),					MYCOLOR_DESKTOP, },
	{ TEXT ("�q���g"),							MYCOLOR_INFOBK, },
	{ TEXT ("�q���g�̕���"),					MYCOLOR_INFOTEXT, },
	{ TEXT ("���b�Z�[�W�{�b�N�X�̕���"),		MYCOLOR_MSGBOXTEXT, },
	{ TEXT ("���j���["),						MYCOLOR_MENU, },
	{ TEXT ("���j���[�̕���"),					MYCOLOR_MENUTEXT, },
	{ TEXT ("�I������(����)"),					MYCOLOR_HIGHLIGHTTEXT, },
	{ TEXT ("�I������(�w�i)"),					MYCOLOR_HIGHLIGHT, },
	{ TEXT ("��A�N�e�B�u �E�B���h�E�̋��E"),	MYCOLOR_INACTIVEBORDER, },
	{ TEXT ("��A�N�e�B�u �^�C�g�� �o�["),		MYCOLOR_INACTIVECAPTION, },
	{ TEXT ("��A�N�e�B�u �^�C�g�� �o�[�̕���"),MYCOLOR_INACTIVECAPTIONTEXT, },
} ;

BOOL
skkimeConfig_InitializeColorFace (
	MYCOLORFACESET*	pColorFaceSet)
{
	if (pColorFaceSet == NULL)
		return	FALSE ;

	return	skkimeConfig_initColorFace (REGPATH_COLORFACE, pColorFaceSet, srSkkImeDefaultColorFace, NELEMENTS (srSkkImeDefaultColorFace)) ;
}

BOOL
skkimeConfig_UpdateColorFace (
	MYCOLORFACESET*		pColorFace)
{
	if (pColorFace == NULL)
		return	FALSE ;
	return	skkimeConfig_updateColorFace (REGPATH_COLORFACE, pColorFace) ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgColorFaceTblProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgColorFaceOnInitDialog (hDlg, uMsg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgColorFaceOnNotify (hDlg, uMsg, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgColorFaceOnCommand (hDlg, uMsg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	private functions
 */
INT_PTR
skkimeConfig_dlgColorFaceOnInitDialog (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	int					n ;
	LVITEM		lvI ;
	static struct {
		int			m_nWidth ;
		LPCTSTR		m_strText ;
	}	srColumnDef []	= {
		{ 120,	TEXT ("�ύX��"), },
		{ 60,	TEXT ("�v���r���["), },	/*	preview �� owner-draw �̕K�v���肩�H */
	} ;
	static LPTSTR				srColorFaceTitle []	= {
		TEXT ("���ϊ�������"),	TEXT ("�ϊ�������"),
	} ;
	HWND	hwndLV, hwndCB ;
	MYCOLORFACESET*	pColor ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgColorFaceOnInitDialog (%x)\n"), hDlg)) ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR)lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SELECTFACE) ;
	if (hwndLV != NULL) {
		LV_COLUMN		lvColumn ;
		int	i, nItem ;
		POINT			pt ;

		ListView_DeleteAllItems (hwndLV) ;
		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		for (i = 0 ; i < NELEMENTS (srColumnDef) ; i ++) {
			lvColumn.cx			= srColumnDef [i].m_nWidth ;
			lvColumn.pszText	= (LPTSTR) srColumnDef [i].m_strText ;
			ListView_InsertColumn (hwndLV, i, &lvColumn) ;
		}

		memset (&lvI, 0, sizeof (lvI)) ;
		lvI.mask		= LVIF_PARAM | LVIF_STATE ;
		n				= 0 ;
		for (i = 0 ; i < MAX_SKKIME_COLORFACE ; i ++) {
			lvI.iItem		= i ;
			lvI.lParam		= (LPARAM) i ;
			nItem			= ListView_InsertItem (hwndLV, &lvI) ;
			if (nItem >= 0) {
				ListView_SetItemText (hwndLV, nItem, 0, srColorFaceTitle [i]) ;
				ListView_SetItemText (hwndLV, nItem, 1, TEXT ("��������")) ;
			}
		}
		ListView_SetSelectionMark (hwndLV, nItem) ;
		ListView_SetItemState (hwndLV, nItem, LVIS_FOCUSED | LVIS_SELECTED, 0) ;
		ListView_GetItemPosition (hwndLV, 0, &pt) ;
		SendMessage (hwndLV, WM_LBUTTONDOWN, 0, (LPARAM)(((DWORD)(WORD)pt.y << 16) | (DWORD)(WORD)pt.x)) ;
	}
	pColor			= &pConfArg->m_rColorFaceSet [0] ;
	hwndCB			= GetDlgItem (hDlg, IDC_COMBO_FORECOLOR) ;
	skkimeConfig_setupColorComboBox (hwndCB) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nTextColor, (LPARAM) 0) ;
	hwndCB			= GetDlgItem (hDlg, IDC_COMBO_BACKCOLOR) ;
	skkimeConfig_setupColorComboBox (hwndCB) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nBackColor, (LPARAM) 0) ;
	hwndCB			= GetDlgItem (hDlg, IDC_COMBO_ULCOLOR) ;
	skkimeConfig_setupColorComboBox (hwndCB) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nUnderLineColor, (LPARAM) 0) ;
	hwndCB			= GetDlgItem (hDlg, IDC_COMBO_UNDERLINE) ;
	skkimeConfig_setupLineTypeComboBox (hwndCB) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nUnderLineType, (LPARAM) 0) ;
	return	TRUE ;

	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgColorFaceOnNotify (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	NMHDR	FAR*		pNMHDR	= (NMHDR *) lParam ;
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	MYCOLORFACESET*		pColor ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_COMBO_FORECOLOR:
	case	IDC_COMBO_BACKCOLOR:
	case	IDC_COMBO_ULCOLOR:
	case	IDC_COMBO_UNDERLINE:
	{
		/*	������ preview �̏�Ԃ�ύX���Ȃ���΂Ȃ�Ȃ��B*/
		return	FALSE ;
	}
	case	IDC_LIST_SELECTFACE:
	{
		switch (pNMHDR->code) {
			/*	ListView �� customdraw �̂��߂̏����B
			 */
		case	NM_CUSTOMDRAW:
		{
			LPNMLVCUSTOMDRAW	lpLVCD	= (LPNMLVCUSTOMDRAW) lParam ;
			LRESULT			lRetval	= 0 ;

			switch (lpLVCD->nmcd.dwDrawStage) {
			case	CDDS_PREPAINT:
				lRetval		= CDRF_NOTIFYITEMDRAW ;
				break ;
			case	CDDS_ITEMPREPAINT:
				lRetval		= CDRF_NOTIFYSUBITEMDRAW ;
				break ;
			case	CDDS_ITEMPREPAINT | CDDS_SUBITEM:
			{
			    int		nItem		= lpLVCD->nmcd.dwItemSpec ;
				int		nSubItem	= lpLVCD->iSubItem ;
				static   LPCTSTR	str			= TEXT ("��������") ;
				HWND	hwnd		= pNMHDR->hwndFrom ;
				HDC		hDC			= lpLVCD->nmcd.hdc ;

				if (nItem < 0 || nItem >= MAX_SKKIME_COLORFACE)
					break ;

				pColor		= &pConfArg->m_rColorFaceSet [nItem] ;
				if (nSubItem == 1) {
					RECT		rc ;
					SIZE		sz ;
					HBRUSH		hBrush ;
					HBITMAP		hBitmap ;
					int			nWidth, nBkMode ;
					COLORREF	colLine, colTextBak, colBkBak ;

					/*	�T���v�������u���������v��`�悷��B
					 */
					colTextBak	= SetTextColor (hDC, GetImeColor (hwnd, pColor->m_nTextColor)) ;
					colBkBak	= SetBkColor   (hDC, GetImeColor (hwnd, pColor->m_nBackColor)) ;
					nBkMode		= SetBkMode	 (hDC, OPAQUE) ;
					ListView_GetItemRect (hwnd, nItem, &rc, LVIR_BOUNDS) ;
					rc.left		= lpLVCD->nmcd.rc.left ;
					rc.right	= lpLVCD->nmcd.rc.right ;
					DrawText (hDC, str, lstrlen (str), &rc, DT_LEFT | DT_TOP) ;
					
					/*	�T���v�������u���������v�ɉ����������B
					 */
					GetTextExtentPoint32 (hDC, str, lstrlen (str), &sz) ;
					hBrush	= GetImeLineBrush (hwnd, pColor->m_nUnderLineColor, pColor->m_nUnderLineType, &colLine, &hBitmap, &nWidth) ; 
					if (hBrush != NULL) {
						HBRUSH	hOldBrush ;
						int		nCX, nX, nY ;

						nX	= rc.left ;
						nCX	= ((nX + sz.cx) > rc.right)? (rc.right - nX) : sz.cx ;
						nY	= ((rc.top + sz.cy) > rc.bottom)? rc.bottom : (rc.top + sz.cy) ;
						nY	-= nWidth ;
						hOldBrush		= (HBRUSH) SelectObject (hDC, hBrush) ;
						SetTextColor (hDC, colLine) ;
						PatBlt (hDC, nX, nY, nCX, nWidth, PATCOPY) ;
						(void) SelectObject (hDC, hOldBrush) ;
						DeleteObject (hBrush) ;
					}
					if (hBitmap != NULL) 
						DeleteObject (hBitmap) ;
					lRetval		= CDRF_SKIPDEFAULT ;
					SetTextColor (hDC, colTextBak) ;
					SetBkColor (hDC, colBkBak) ;
					SetBkMode	 (hDC, nBkMode) ;
				} else {
					lRetval		= CDRF_NOTIFYSUBITEMDRAW ;
				}
				break ;
			}
			default:
				lRetval		= CDRF_DODEFAULT ;
				break ;
			}
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, lRetval) ;
			return	TRUE ;
		}

		/*	ListView ���őI������Ă��� item ���ύX���ꂽ�ꍇ�ɁA
		 *	�E���� ComboBox �̕\�����X�V���Ȃ���΂Ȃ�Ȃ��B
		 */
		case	NM_CLICK:
		case	NM_DBLCLK:
		case	NM_RCLICK:
		case	NM_RDBLCLK:
		{
			LPNMITEMACTIVATE	lpnmitem = (LPNMITEMACTIVATE) lParam ;
			
			DEBUGPRINTF ((TEXT ("NM_CLICK (item:%d)\n"), lpnmitem->iItem)) ;

			if (lpnmitem->iItem < 0 || 
				lpnmitem->iItem >= MAX_SKKIME_COLORFACE)
				break ;
			pColor	= &pConfArg->m_rColorFaceSet [lpnmitem->iItem] ;
			skkimeConfig_setColorComboBox (hDlg, pColor) ;
			return	0 ;
		}
		default:
			break ;
		}
		break ;
	}
	default:
		switch (pNMHDR->code){
		case PSN_SETACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
			return	TRUE ;

		case PSN_RESET:
		case PSN_HELP:
			break ;

		case PSN_APPLY:
			if (skkimeConfig_UpdateColorFace (pConfArg->m_rColorFaceSet)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;

		default:
			return	FALSE ;
		}
		return	TRUE ;
	}
	return	TRUE ;

	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgColorFaceOnCommand (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	WORD				wNotifyCode ;
	WORD				wID ;
	HWND				hwndCtl ;
	//HWND	hwndLV ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	if (wNotifyCode == CBN_SELCHANGE) {
		HWND	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SELECTFACE) ;
		MYCOLORFACESET*	pColor ;
		int	nItem ;
		long	lResult ;

		if (hwndLV == NULL)
			return	0 ;
		nItem	= ListView_GetSelectionMark (hwndLV) ;
		if (nItem < 0 || nItem >= MAX_SKKIME_COLORFACE)
			return	0 ;
		pColor	= &pConfArg->m_rColorFaceSet [nItem] ;
		lResult	= SendMessage (hwndCtl, CB_GETCURSEL, 0, 0) ;
		switch (wID) {
		case	IDC_COMBO_FORECOLOR:
			pColor->m_nTextColor	= lResult ;
			break ;
		case	IDC_COMBO_BACKCOLOR:
			pColor->m_nBackColor	= lResult ;
			break ;
		case	IDC_COMBO_ULCOLOR:
			pColor->m_nUnderLineColor	= lResult ;
			break ;
		case	IDC_COMBO_UNDERLINE:
			pColor->m_nUnderLineType	= lResult ;
			break ;
		default:
			return	0 ;
		}
		/*	�`��A�X�V�B*/
		PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		InvalidateRect (hwndLV, NULL, FALSE) ;
		return	1 ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (uMsg) ;
}

BOOL
skkimeConfig_setupColorComboBox (
	HWND		hwndCB)
{
	int			i, nRetval ;
	MYCOLORDEF*	ptr ;

	if (hwndCB == NULL || ! IsWindow (hwndCB))
		return	FALSE ;

	ptr	= srSkkImeColorDefinition ;
	for (i = 0 ; i < NELEMENTS (srSkkImeColorDefinition) ; i ++) {
		nRetval	= SendMessage (hwndCB, CB_INSERTSTRING, i, (LPARAM) ptr->m_strText) ;
		ptr	++ ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_setupLineTypeComboBox (
	HWND		hwndCB)
{
	static LPCTSTR		srString []	= {
		TEXT ("�Ȃ�"),	TEXT ("����"),			TEXT ("�_��"),
		TEXT ("����"),	TEXT ("�f�B�U�א�"),	TEXT ("�f�B�U����"),
	} ;
	int		i ;

	if (hwndCB == NULL || ! IsWindow (hwndCB))
		return	FALSE ;

	for (i = 0 ; i < NELEMENTS (srString) ; i ++) 
		SendMessage (hwndCB, CB_INSERTSTRING, i, (LPARAM) srString [i]) ;
	return	TRUE ;
}

void
skkimeConfig_setColorComboBox (
	HWND					hDlg,
	const MYCOLORFACESET*	pColor)
{
	HWND	hwndCB ;

	if (hDlg == NULL || pColor == NULL)
		return ;

	hwndCB	= GetDlgItem (hDlg, IDC_COMBO_FORECOLOR) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nTextColor, 0) ;
	hwndCB	= GetDlgItem (hDlg, IDC_COMBO_BACKCOLOR) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nBackColor, 0) ;
	hwndCB	= GetDlgItem (hDlg, IDC_COMBO_ULCOLOR) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nUnderLineColor, 0) ;
	hwndCB	= GetDlgItem (hDlg, IDC_COMBO_UNDERLINE) ;
	SendMessage (hwndCB, CB_SETCURSEL, (WPARAM) pColor->m_nUnderLineType, 0) ;
	return ;
}

BOOL
skkimeConfig_initColorFace (
	LPCTSTR					strRegPath,
	MYCOLORFACESET*			pColorFaceSet,
	const MYCOLORFACESET*	pColorFaceSetDefault,
	int						nColorFaceSetDefault)
{
	HKEY			hSubKey ;
	BYTE			rbyStyle [MAX_SKKIME_COLORFACE * 4] ;
	BOOL			fInitialized	= FALSE ;

	if (strRegPath == NULL ||
		pColorFaceSetDefault == NULL ||
		nColorFaceSetDefault <= 0)
		return	FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, strRegPath, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;
		
		DEBUGPRINTF ((TEXT ("RegKeyOpenEx succeeded (\"%s\")\n"), strRegPath)) ;

		/*	j-map ���̏����B*/
		cbData	= sizeof (rbyStyle) ;
		if (RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, rbyStyle, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == sizeof (rbyStyle)) {
			const MYCOLORFACESET*	pDefault	= pColorFaceSetDefault ;
			MYCOLORFACESET*		pColor		= pColorFaceSet ;
			LPBYTE					pByte		= rbyStyle ;
			int					i ;

			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < MAX_SKKIME_COLORFACE ; i ++) {
				pColor->m_nTextColor		= IsValidColor (*pByte)? *pByte : pDefault->m_nTextColor ;	pByte	++ ;
				pColor->m_nBackColor		= IsValidColor (*pByte)? *pByte : pDefault->m_nBackColor ;	pByte	++ ;
				pColor->m_nUnderLineColor	= IsValidColor (*pByte)? *pByte : pDefault->m_nUnderLineColor ;	pByte	++ ;
				pColor->m_nUnderLineType	= IsValidLineType (*pByte)? *pByte : pDefault->m_nUnderLineType ;	pByte	++ ;
				pColor		++ ;
				pDefault	++ ;
			}
			fInitialized	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! fInitialized)
		memcpy (pColorFaceSet, pColorFaceSetDefault, sizeof (MYCOLORFACESET) * nColorFaceSetDefault) ;
	return	TRUE ;
}

BOOL
skkimeConfig_updateColorFace (
	LPCTSTR				strRegPath,
	MYCOLORFACESET*		pColorFaceSet)
{
	HKEY				hSubKey ;
	BYTE				rbyStyle [MAX_SKKIME_COLORFACE * 4] ;
	BOOL				fRetval	= TRUE ;
	MYCOLORFACESET*		pColor ;
	LPBYTE				pByte ;
	int				i ;

	if (! skkimeConfig_CreateKey (strRegPath, FALSE, &hSubKey))
		return	FALSE ;

	pColor	= pColorFaceSet ;
	pByte	= rbyStyle ;
	for (i = 0 ; i < MAX_SKKIME_COLORFACE ; i ++) {
		*pByte	++	= (BYTE) pColor->m_nTextColor ;
		*pByte	++	= (BYTE) pColor->m_nBackColor ;
		*pByte	++	= (BYTE) pColor->m_nUnderLineColor ;
		*pByte	++	= (BYTE) pColor->m_nUnderLineType ;
		pColor	++ ;
	}
	if (RegSetValueEx (hSubKey, REGSUBKEY_COLORFACE, 0, REG_BINARY, rbyStyle, sizeof (rbyStyle)) != ERROR_SUCCESS) {
		fRetval	= FALSE ;
	}
	if (RegCloseKey (hSubKey) != ERROR_SUCCESS)
		fRetval	= FALSE ;
	return	fRetval ;
}




