#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_0.h"
#include "prsht.h"
#include "conf\skimcnfp.h"
#include <limits.h>
#include "resource.h"
#include "TServerSession.h"
#include "version.h"

#define	MAX_PAGES			(16)
#define	MAX_SKKIME_CONFIG_MEMORY	(1024 * 1024 * 2)

typedef struct tagSkkimePageSheetDefine {
	LPCTSTR					m_strTitle ;
	INT_PTR (CALLBACK		*m_pDlgProc)(HWND, UINT, WPARAM, LPARAM) ;
	INT						m_nResId ;
}	SkkimePageSheetDefine ;

/*	�v���g�^�C�v�錾�B */
static	BOOL			skkimeConfig_initializeInstance	(SkkimeConfigArg*, HWND) ;
static	void			skkimeConfig_exitInstance	(void) ;
static	int	CALLBACK	skkimeConfig_propSheetProc	(HWND, UINT, LPARAM) ;
static	BOOL	skkimeConfig_newPageSheet	(LPPROPSHEETHEADER, SkkimePageSheetDefine*, void*) ;
static	BOOL	skkimeConfig_loadConfig 	(SkkimeConfigArg*) ;
static	BOOL	skkimeConfig_updateConfig	(SkkimeConfigArg*) ;

/*	�O���[�o���ϐ��B*/
#if defined (CONFIG_UNIT_TEST)
HINSTANCE						hInst	= NULL ;
#endif
static	SkkimeConfigArg*		spCurrentConfigArg	= NULL ;

static	SkkimePageSheetDefine	srSkkimePageSheetTbl []	= {
	{ TEXT("�S��"),	
	  skkimeConfig_dlgGenericProc,			IDD_PROPPAGE_GENERIC, },
	{ TEXT("�L�[�ݒ�"),	
	  skkimeConfig_dlgKeybindProc,			IDD_PROPPAGE_KEYBIND, },
	{ TEXT("�����ݒ�"),
	  skkimeConfig_dlgDictionaryProc,		IDD_PROPPAGE_DICT, },
	{ TEXT("���[�}�������e�[�u���ݒ�"),
	  skkimeConfig_dlgRomaKanaTblProc,		IDD_PROPPAGE_ROMAKANATABLE, },
	{ TEXT("�����v���t�B�N�X�ݒ�"),	
	  skkimeConfig_dlgKanaPrefixTblProc,	IDD_PROPPAGE_KANAPREFIX, },
	{ TEXT("���[�}�������ϊ����[���ݒ�"),
	  skkimeConfig_dlgRomaKanaRuleProc,		IDD_PROPPAGE_ROMAKANARULE, },
	{ TEXT("���̓x�N�g���ݒ�"),
	  skkimeConfig_dlgInputVectorProc,		IDD_PROPPAGE_INPUTVECTOR, },
	{ TEXT("�S�p�x�N�g���ݒ�"),
	  skkimeConfig_dlgZenkakuVectorProc,	IDD_PROPPAGE_ZENKAKUVECTOR, },
	{ TEXT("�F�ݒ�"),	
	  skkimeConfig_dlgColorFaceTblProc,		IDD_PROPPAGE_CONFIGCOLOR, },
	{ TEXT("���I���L�[�̐ݒ�"),
	  skkimeConfig_dlgCandidateSelectKeyProc,	IDD_PROPPAGE_CANDSEL, },
} ;

#if !defined (NO_TSF)
static	SkkimePageSheetDefine	srSkkimeTsfPageSheetTbl []	= {
	{ TEXT ("����o�["),
	  skkimeConfig_dlgCiceroProc,			IDD_PROPPAGE_CONFIGCICERO, },
} ;
#endif

#if defined (CONFIG_UNIT_TEST)
int	WINAPI
_tWinMain (
	register HINSTANCE	hInstance,
	register HINSTANCE	hPrevInstance,
	register LPTSTR		lpCmdLine,
	register int		nCmdShow)
{
	TServerSession_ClassInit () ;
	skkimeConfig_main (hInstance, NULL, 0) ;
	return	0 ;
	UNREFERENCED_PARAMETER (hPrevInstance) ;
	UNREFERENCED_PARAMETER (lpCmdLine) ;
	UNREFERENCED_PARAMETER (nCmdShow) ;
}
#endif

/*
 */
BOOL
skkimeConfig_CreateKey (
	register LPCMYSTR	pstrSubKey,
	register BOOL		fClean,
	register HKEY*		phKey)
{
	HKEY	hSubKey ;
	DWORD	dwDispose ;
	LONG	lResult ;

	ASSERT (pstrSubKey != NULL) ;
	ASSERT (phKey != NULL) ;

	if (fClean) {
		lResult	= MyRegDeleteKey (HKEY_CURRENT_USER, pstrSubKey) ;
		DEBUGPRINTF ((MYTEXT ("RegDeleteKey (\"%s\") returned %ld.\n"), pstrSubKey, lResult)) ;
	}
	if (MyRegCreateKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, NULL, &hSubKey, &dwDispose) != ERROR_SUCCESS) {
		DEBUGPRINTF ((MYTEXT ("RegCreateKeyEx (\"%s\") failed.\n"), pstrSubKey)) ;
		return	FALSE ;
	}
	*phKey	= hSubKey ;
	return	TRUE ;
}

int
skkimeConfig_PopupMenu (
	register HWND			hwndOwner,
	register TMYMENUITEM*	pMenuItem,
	register int			nMenuItem)
{
	register HMENU				hMenu	= CreatePopupMenu () ;
	static MENUITEMINFO			mmi ;
	POINT						pt ;
	register int				i, n ;

	memset (&mmi, 0, sizeof (mmi)) ;
	mmi.cbSize	= sizeof (mmi) ;
	for (i = 0 ; i < nMenuItem ; i ++) {
#if(WINVER >= 0x0500)
		mmi.fMask		= pMenuItem->m_fMask ;
#else
		mmi.fMask		= pMenuItem->m_fMask | 0x00000140 ;
#endif
		mmi.fType		= pMenuItem->m_fType ;
		mmi.dwTypeData	= pMenuItem->m_strText ;
		mmi.wID			= pMenuItem->m_wID ;
		mmi.cch			= lstrlen (pMenuItem->m_strText) ;
		InsertMenuItem (hMenu, i, TRUE, &mmi) ;
		pMenuItem	++ ;
	}
	if (! GetCursorPos (&pt)) 
		pt.x	= pt.y	= 0 ;
	n	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwndOwner, NULL) ;
	DestroyMenu (hMenu) ;
	return	n ;
}

/*========================================================================*/

BOOL
skkimeConfig_main (
	register HINSTANCE	hInstance,
	register HWND		hWnd,
	register DWORD		dw)
{
	SkkimeConfigArg	confArg ;
	register void*	pvHeapArea ;
	register BOOL	fRetval ;

	DEBUGPRINTF ((MYTEXT ("skkimeConfig_main (): enter\n"))) ;

	pvHeapArea	= HeapAlloc (GetProcessHeap (), 0, MAX_SKKIME_CONFIG_MEMORY) ;
	if (pvHeapArea == NULL)
		return	FALSE ;

	memset (&confArg, 0, sizeof (confArg)) ;
	TinyMalloc_Initialize (&confArg.m_MemMgr, pvHeapArea, MAX_SKKIME_CONFIG_MEMORY) ;
	confArg.m_hInst	= hInstance ;

	fRetval	= skkimeConfig_loadConfig (&confArg) ;
	fRetval	= skkimeConfig_initializeInstance (&confArg, hWnd) ;
	skkimeConfig_exitInstance () ;
	TinyMalloc_Uninitialize (&confArg.m_MemMgr) ;
	HeapFree (GetProcessHeap (), 0, pvHeapArea) ;

	DEBUGPRINTF ((MYTEXT ("skkimeConfig_main (): leave\n"))) ;
	return	fRetval ;
}

BOOL
skkimeConfig_initializeInstance (
	register SkkimeConfigArg*	pConfArg,
	register HWND				hWnd)
{
	HPROPSHEETPAGE	rPages [MAX_PAGES] ;
	PROPSHEETHEADER	psh ;
	register int	i ;
	register BOOL	fRetval	= FALSE ;

	DEBUGPRINTF ((MYTEXT ("skkimeConfig_initializeInstance ()\n"))) ;

	psh.dwSize		= sizeof (psh) ;
	psh.dwFlags		= PSH_PROPTITLE | PSH_USECALLBACK ;
	psh.hwndParent	= hWnd ;

	/*
	 *	����l�Ƃ��Đݒ肵�����ɂ� hInst �̒l����낵�������炵���̂ŁA
	 *	hInstance �͐e Window ����Ⴄ���Ƃɂ���B
	 */
	psh.hInstance	= pConfArg->m_hInst ;
	psh.pszIcon		= NULL ;
	psh.pszCaption	= SKKIME_VERSION TEXT (" ") ;
	psh.nPages		= 0 ;
	psh.nStartPage	= 0 ;
	psh.phpage		= rPages ;
	psh.pfnCallback	= skkimeConfig_propSheetProc ;

	for (i = 0 ; i < NELEMENTS (srSkkimePageSheetTbl) ; i ++) {
		if (! skkimeConfig_newPageSheet (&psh, &srSkkimePageSheetTbl [i], pConfArg))
			goto	exit_func ;
	}
#if !defined (NO_TSF)
	/*	����o�[�̐ݒ�́A���ꂪ�L���łȂ���Ε\������K�v�͂Ȃ��B*/
#if ! defined (CONFIG_UNIT_TEST)
	if (bTSF_IsTSFEnabled ()) {
#endif
		DEBUGPRINTFEX (100, (TEXT ("Add TSF pages\n"))) ;
		for (i = 0 ; i < NELEMENTS (srSkkimeTsfPageSheetTbl) ; i ++) {
			if (! skkimeConfig_newPageSheet (&psh, &srSkkimeTsfPageSheetTbl [i], pConfArg))
				goto	exit_func ;
		}
#if ! defined (CONFIG_UNIT_TEST)
	}
#endif
#endif
	DEBUGPRINTF ((MYTEXT ("skkimeConfig_initInstance: pConfArg(%p), hwnd(%x)\n"),
				  pConfArg, (unsigned int)hWnd)) ;

	/*	�����Acritical section ... �����ɓ�����ƕ�����B*/
	spCurrentConfigArg	= pConfArg ;
	if (psh.nPages > 0) {
		register int	n = PropertySheet (&psh) ;
		DEBUGPRINTFEX (99, (MYTEXT ("PropertySheet () returns %d. \n"), n)) ;
		if (n > 0) {
#if ! defined (CONFIG_UNIT_TEST)
			if (skkimeConfig_updateConfig (pConfArg)) 
				UpdateServerConfiguration () ;
#else
			skkimeConfig_updateConfig (pConfArg) ;
#endif
		}
		fRetval	= TRUE ;
	}

 exit_func:
	return	fRetval ;
}

void
skkimeConfig_exitInstance (void)
{
	return ;
}

int	CALLBACK
skkimeConfig_propSheetProc (
	register HWND					hwndDlg,
	register UINT					uMsg,
	register LPARAM					lParam)
{
	switch (uMsg) {
	case	PSCB_INITIALIZED:
		/*	�ň�...�B���������ǂ�������� PropertySheet �� Window Handle ��
		 *	�܂Ƃ��ɓ��邱�Ƃ��ł���񂾂낤�H */
		if (spCurrentConfigArg != NULL)
			spCurrentConfigArg->m_hPropSheetDlg	= hwndDlg ;
		break ;
	default:
		break ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

BOOL
skkimeConfig_newPageSheet (
	register LPPROPSHEETHEADER		ppsh,
	register SkkimePageSheetDefine*	pDefine,
	register void*					pvParam)
{
	PROPSHEETPAGE		psp ;
	/*register LPCTSTR	pszTitle ;
	  register DLGPROC	pfn ;
	  register LPCTSTR	pszTemplate ;*/

	/* �����̃`�F�b�N�B*/
	if (ppsh == NULL || pDefine == NULL)
		return	FALSE ;
	if (ppsh->nPages >= MAX_PAGES)
		return	FALSE ;

	/* �v���p�e�B�V�[�g�Ƀy�[�W��ǉ�����B*/
	psp.dwSize		= sizeof (psp) ;
	psp.dwFlags		= PSP_DEFAULT ; //USETITLE ; 	//PSP_DLGINDIRECT ;
	psp.hInstance	= g_hInst ; //ppsh->hInstance ; /* hInst */
	psp.pszTemplate	= MAKEINTRESOURCE(pDefine->m_nResId) ;
	//psp.pResource	= (LPDLGTEMPLATE)lpResource ;
	psp.pszIcon		= 0 ;
	psp.pfnDlgProc	= pDefine->m_pDlgProc ;
	psp.pfnCallback	= 0 ;
	psp.pszTitle	= pDefine->m_strTitle ;
	psp.lParam		= (LPARAM) pvParam ;
	ppsh->phpage [ppsh->nPages]	= CreatePropertySheetPage (&psp) ;
	if (ppsh->phpage [ppsh->nPages]){
		ppsh->nPages	++ ;
	} else {
		DEBUGPRINTF ((MYTEXT ("CreatePropertySheetPage failed (%d)\n"), ppsh->nPages)) ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_loadConfig (
	register SkkimeConfigArg*	pArg)
{
	register TINYMEMMGR*	pMemMgr	;

	DEBUGPRINTF ((MYTEXT ("skkimeConfig_updateInstane (): enter\n"))) ;
	pMemMgr	= &pArg->m_MemMgr ;

	if (!skkimeConfig_InitializeGeneric (pMemMgr, &pArg->m_GenericConfig)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_InitializeGeneric (): failed\n"))) ;
		return	FALSE ;
	}

	/*	���̓x�N�g���̏������B*/
	if (! skkimeConfig_InitializeInputVector (pMemMgr, pArg->m_rInputVector)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_initInputVector(): INPUTVECTOR failed\n"))) ;
		return	FALSE ;
	}

	/*	�S�p�x�N�g���̏������B*/
	if (! skkimeConfig_InitializeZenkakuVector (pMemMgr, pArg->m_rZenkakuVector)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_initInputVector(): ZENKAKUVECTOR failed\n"))) ;
		return	FALSE ;
	}

	/*	�L�[�}�b�v�̏������B*/
	if (! skkimeConfig_InitializeKeymap (pMemMgr, pArg->m_rJMap, pArg->m_rAbbrevMap)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_initKeymap(): failed\n"))) ;
		return	FALSE ;
	}

	/*	���[�}�������ϊ��e�[�u���̏������B*/
	if (! skkimeConfig_InitializeRomaKanaTableA (pMemMgr, &pArg->m_lstRomaKanaA) ||
		! skkimeConfig_InitializeRomaKanaTableI (pMemMgr, &pArg->m_lstRomaKanaI) ||
		! skkimeConfig_InitializeRomaKanaTableU (pMemMgr, &pArg->m_lstRomaKanaU) ||
		! skkimeConfig_InitializeRomaKanaTableE (pMemMgr, &pArg->m_lstRomaKanaE) ||
		! skkimeConfig_InitializeRomaKanaTableO (pMemMgr, &pArg->m_lstRomaKanaO)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_initRomaKanaTable(): failed\n"))) ;
		return	FALSE ;
	}

	/*	���[�}�������ϊ����[�����X�g�̏������B*/
	if (! skkimeConfig_InitializeRomaKanaRuleList (pMemMgr, &pArg->m_lstRomaKanaRule)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_initRomaKanaRuleList(): failed\n"))) ;
		return	FALSE ;
	}

	/*	�v���t�B�N�X���X�g�̏������B*/
	if (! skkimeConfig_InitializePrefixList (pMemMgr, &pArg->m_lstPrefix)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_initPrefixList(): failed\n"))) ;
		return	FALSE ;
	}

	/*	�����ݒ�̏������B*/
	if (!skkimeConfig_InitializeSearchJisyoList (pMemMgr, &pArg->m_lstSearchJisyo, pArg->m_rszUserJisyoPath)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_initSearchJisyoList (): failed\n"))) ;
		return	FALSE ;
	}

	if (!skkimeConfig_InitializeColorFace (pMemMgr, pArg->m_rColorFaceSet)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_InitializeColorFace (): failed\n"))) ;
		return	FALSE ;
	}
#if !defined (NO_TSF)
	if (!skkimeConfig_InitializeCICERO (pMemMgr, &pArg->m_CiceroConfig)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_InitializeCICERO (): failed\n"))) ;
		return	FALSE ;
	}
#endif
	if (! skkimeConfig_InitializeCandidateSelectKey (pMemMgr, &pArg->m_CandSelKey)) {
		DEBUGPRINTF ((MYTEXT ("skkimeConfig_InitializeCandidateSelectKey (): failed\n"))) ;
		return	FALSE ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_updateConfig (
	register SkkimeConfigArg*	pArg)
{
	register TINYMEMMGR*	pMemMgr	;

	pMemMgr	= &pArg->m_MemMgr ;
	DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updateInstane (): enter\n"))) ;

	if (! skkimeConfig_UpdateKeymap (pArg->m_rJMap, pArg->m_rAbbrevMap)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updateKeymap () failed\n"))) ;
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateInputVector   (pArg->m_rInputVector) ||
		! skkimeConfig_UpdateZenkakuVector (pArg->m_rZenkakuVector)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updateInputVector () failed\n"))) ;
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateRomaKanaTableA (pArg->m_lstRomaKanaA) ||
		! skkimeConfig_UpdateRomaKanaTableI (pArg->m_lstRomaKanaI) ||
		! skkimeConfig_UpdateRomaKanaTableU (pArg->m_lstRomaKanaU) ||
		! skkimeConfig_UpdateRomaKanaTableE (pArg->m_lstRomaKanaE) ||
		! skkimeConfig_UpdateRomaKanaTableO (pArg->m_lstRomaKanaO)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updateRomaKanaTable () failed\n"))) ;
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateRomaKanaRuleList (pArg->m_lstRomaKanaRule)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updateRomaKanaRuleList () failed\n"))) ;
		return	FALSE ;
	}

	if (! skkimeConfig_UpdatePrefixList (pArg->m_lstPrefix)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updatePrefixList () failed\n"))) ;
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateSearchJisyoList (pArg->m_lstSearchJisyo, pArg->m_rszUserJisyoPath)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updateSearchJisyoList () failed\n"))) ;
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateColorFace (pArg->m_rColorFaceSet)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_UpdateColorFace () failed\n"))) ;
		return	FALSE ;
	}

	if (! skkimeConfig_UpdateGeneric (&pArg->m_GenericConfig)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_UpdateGeneric () failed\n"))) ;
		return	FALSE ;
	}
#if !defined (NO_TSF)
	if (!skkimeConfig_UpdateCICERO (&pArg->m_CiceroConfig)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_UpdateCICERO () failed\n"))) ;
		return	FALSE ;
	}
#endif
	if (!skkimeConfig_UpdateCandidateSelectKey (&pArg->m_CandSelKey)) {
		DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_UpdateCandidateSelectKey () failed\n"))) ;
		return	FALSE ;
	}
	DEBUGPRINTFEX (99, (MYTEXT ("skkimeConfig_updateInstane (): leave\n"))) ;
	return	TRUE ;
}

/*========================================================================
 *	Unit Test ��p�B
 */
#if defined (CONFIG_UNIT_TEST)
void
DebugPrintf (
	LPCMYSTR	ptszFormat,
	...)
{
	MYCHAR	szBuffer [2048] ;
	va_list	vl ;
	
	/*	vsnprintf �� DLL function �Ƃ��Ă͕s�K�؁Bmain ��v������̂ŁB*/
	va_start (vl, ptszFormat) ;
	Mywvsprintf (szBuffer, ptszFormat, vl) ;
	va_end (vl) ;
	szBuffer [1024]	= MYTEXT ('\0') ;
	MyOutputDebugString (szBuffer) ;
	return ;
}
#endif

