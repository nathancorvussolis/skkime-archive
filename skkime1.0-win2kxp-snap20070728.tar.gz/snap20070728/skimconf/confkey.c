/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#if !defined (UNICODE)
#define	REGPATH_KEYMAP			REGPATH_SKKIME_BASE TEXT("\\Keymap")
#define	REGSUBKEY_JMAP			TEXT("j-map")
#define	REGSUBKEY_JABBREVMAP	TEXT("j-abbrev-map")
#else
#define	REGPATH_KEYMAP			REGPATHW_KEYMAP
#define	REGSUBKEY_JMAP			REGSUBKEYW_JMAP
#define	REGSUBKEY_JABBREVMAP	REGSUBKEYW_JABBREVMAP
#endif
#define	NUM_COLUMN_LIST_KEYBIND	(3)

/*========================================================================
 *	private structures
 */
typedef struct {
	LPTSTR			m_pszText ;
	UINT			m_uKeyCode ;
}	TVKKEYBIND ;

typedef struct {
	int			m_nCurSel ;
	int			m_nJMapBind ;
	int			m_nJAbbrevBind ;
	BYTE*		m_pJMap ;
	BYTE*		m_pAbbrevMap ;
}	TDlgSelectKeyBindArg ;

/*========================================================================
 *	private function prototypes 
 */
static	int					skkimeConfig_key2item				(BYTE*, UINT) ;
static	INT_PTR				skkimeConfig_dlgKeyBindOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR				skkimeConfig_dlgKeyBindOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR				skkimeConfig_dlgKeyBindOnCommand	(HWND, UINT, WPARAM, LPARAM) ;
static	BOOL				skkimeConfig_doSelectKeyBind		(HWND, int, int) ;
static	INT_PTR CALLBACK	skkimeConfig_dlgSelectKeyBind		(HWND, UINT, WPARAM, LPARAM) ;
static	int CALLBACK		skkimeConfig_compareKeyBind			(LPARAM, LPARAM, LPARAM) ;

static	BOOL				skkimeConfig_initKeymap		(LPCTSTR, BYTE*, BYTE*) ;
static	BOOL				skkimeConfig_updateKeymap	(LPCTSTR, BYTE*, BYTE*) ;

/*========================================================================
 *	private global variables
 */
/*
 * �u���ȃ��[�h�v�Ɓu�J�i���[�h�v�� Default �̃L�[�o�C���h�B
 */
static const int	riDefaultSkkJMapBind [SIZE_MYKEYMAP]	= {
	FUNCNO_J_SET_MARK_COMMAND,		FUNCNO_J_BEGINNING_OF_LINE,		
	FUNCNO_J_BACKWARD_CHAR,			FUNCNO_J_PREFIX_CHAR,			
	FUNCNO_J_DELETE_CHAR,			FUNCNO_J_END_OF_LINE,			
	FUNCNO_J_FORWARD_CHAR,			FUNCNO_J_KEYBOARD_QUIT,			
	FUNCNO_J_DELETE_BACKWARD_CHAR,	FUNCNO_J_TRY_COMPLETION,		
	FUNCNO_J_KANAINPUT_MODE_ON,		FUNCNO_J_KILL_LINE,				
	FUNCNO_J_REDRAW,				FUNCNO_J_NEWLINE,				
	FUNCNO_J_NEXT_LINE,				FUNCNO_INVALID_CHAR,			
	FUNCNO_J_PREVIOUS_LINE,			FUNCNO_J_TOGGLE_JISX0201,		
	FUNCNO_INVALID_CHAR,			FUNCNO_INVALID_CHAR,			
	FUNCNO_J_TRANSPOSE_CHARS,		FUNCNO_INVALID_CHAR,			
	FUNCNO_INVALID_CHAR,			FUNCNO_J_KILL_REGION,			
	FUNCNO_J_PREFIX_CHAR,			FUNCNO_J_YANK,					
	FUNCNO_INVALID_CHAR,			FUNCNO_J_PREFIX_CHAR,			
	FUNCNO_INVALID_CHAR,			FUNCNO_INVALID_CHAR,			
	FUNCNO_INVALID_CHAR,			FUNCNO_INVALID_CHAR,			
	FUNCNO_J_START_HENKAN,			FUNCNO_J_SELF_INSERT,			
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,			
	FUNCNO_J_DISPLAY_CODE_FOR_CHAR_AT_POINT,	FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_INSERT_COMMA,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_INSERT_PERIOD,			FUNCNO_J_ABBREV_INPUT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_TODAY,					FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_ZENKAKU_EIJI,			FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT_SUBR,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_PURGE_FROM_JISYO,		FUNCNO_J_SET_HENKAN_POINT,
	FUNCNO_J_SET_HENKAN_POINT,		FUNCNO_J_SELF_INSERT,
	FUNCNO_J_INPUT_BY_CODE_OR_MENU,	FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_INSERT_A,	
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_KANA_INPUT,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_INSERT_E,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_KANA_INPUT,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_INSERT_I,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_KANA_INPUT,
	FUNCNO_J_MODE_OFF,				FUNCNO_J_KANA_INPUT,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_KANA_INPUT,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_TOGGLE_KANA,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_KANA_INPUT,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_INSERT_U,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_KANA_INPUT,
	FUNCNO_J_PREVIOUS_CANDIDATE,	FUNCNO_J_KANA_INPUT,
	FUNCNO_J_KANA_INPUT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_SELF_INSERT,
	FUNCNO_J_SELF_INSERT,			FUNCNO_J_DELETE_CHAR,
	/*	special key �̕��B*/
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
} ;

/*
 * �uABBREV���[�h�v�� Default �L�[�o�C���h�B
 */
static	const int	riDefaultAbbrevMapBind [SIZE_MYKEYMAP] = {
	FUNCNO_INVALID_CHAR,			FUNCNO_J_BEGINNING_OF_LINE,
	FUNCNO_J_BACKWARD_CHAR,			FUNCNO_J_PREFIX_CHAR,
	FUNCNO_J_DELETE_CHAR,			FUNCNO_J_END_OF_LINE,
	FUNCNO_J_FORWARD_CHAR,			FUNCNO_J_KEYBOARD_QUIT,
	FUNCNO_J_DELETE_BACKWARD_CHAR,	FUNCNO_J_TRY_COMPLETION,
	FUNCNO_J_KANAINPUT_MODE_ON,		FUNCNO_J_KILL_LINE,
	FUNCNO_J_REDRAW,				FUNCNO_J_NEWLINE,
	FUNCNO_J_NEXT_LINE,				FUNCNO_INVALID_CHAR,
	FUNCNO_J_PREVIOUS_LINE,			FUNCNO_J_ZENKAKU_HENKAN,
	FUNCNO_INVALID_CHAR,			FUNCNO_INVALID_CHAR,
	FUNCNO_J_TRANSPOSE_CHARS,		FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,			FUNCNO_J_KILL_REGION,
	FUNCNO_J_PREFIX_CHAR,			FUNCNO_J_YANK,
	FUNCNO_INVALID_CHAR,			FUNCNO_J_PREFIX_CHAR,
	FUNCNO_INVALID_CHAR,			FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,			FUNCNO_INVALID_CHAR,
	FUNCNO_J_START_HENKAN,			FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_J_ABBREV_COMMA,			FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_J_ABBREV_PERIOD,			FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_SELF_INSERT_CHARACTER,
	FUNCNO_SELF_INSERT_CHARACTER,	FUNCNO_J_DELETE_CHAR,
	/*	special key �̕��B*/
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,	FUNCNO_INVALID_CHAR,
} ;

static LPCTSTR	srszKeyFuncName [NUM_SELECTABLE_FUNCTIONS] = {
	TEXT ("self-insert-char"),
	TEXT ("j-self-insert"),
	TEXT ("j-zenkaku-insert"),
	TEXT ("j-display-code-for-char-at-point"),
	TEXT ("j-set-henkan-point"),
	TEXT ("j-set-henkan-point-subr"),
	TEXT ("j-insert-a"),
	TEXT ("j-insert-e"),
	TEXT ("j-insert-i"),
	TEXT ("j-insert-o"),
	TEXT ("j-insert-u"),
	TEXT ("j-kana-input"),
	TEXT ("j-start-henkan"),
	TEXT ("j-insert-comma"),
	TEXT ("j-insert-period"),
	TEXT ("j-purge-from-jisyo"),
	TEXT ("j-input-by-code-or-menu"),
	TEXT ("j-mode-off"),
	TEXT ("j-toggle-kana"),
	TEXT ("j-previous-candidate"),
	TEXT ("j-kakutei"),
	TEXT ("j-abbrev-input"),
	TEXT ("j-abbrev-period"),
	TEXT ("j-abbrev-comma"),
	TEXT ("j-zenkaku-eiji"),
	TEXT ("j-zenkaku-henkan"), 
	TEXT ("j-today"),
	TEXT ("j-mode-off-and-self-insert"),
	TEXT ("j-kanainput-mode-on"),
	TEXT ("j-newline"),
	TEXT ("set-mark-command"),
	TEXT ("forward-char"),
	TEXT ("backward-char"),
	TEXT ("delete-char"),
	TEXT ("backward-delete-char"),
	TEXT ("j-try-completion"),
	TEXT ("end-of-line"),
	TEXT ("beginning-of-line"),
	TEXT ("kill-line"),
	TEXT ("yank"),
	TEXT ("kill-region"),
	TEXT ("kill-ring-save"),
	TEXT ("exchange-point-and-mark"),
	TEXT ("previous-line"),
	TEXT ("next-line"),
	TEXT ("transpose-chars"),
	TEXT ("redraw"),
	TEXT ("prefix-char"),
	TEXT ("delete-region"),
	TEXT ("j-sendback-key"),
	TEXT ("keyboard-quit"),
	TEXT ("j-toggle-jisx0201"),
	TEXT ("not-modified"),
	TEXT ("forward-word"),
	TEXT ("backward-word"),
	TEXT ("upase-word"),
	TEXT ("downcase-word"),
	TEXT ("capitalize-word"),
	TEXT ("toggle-ime"),
	TEXT ("left-arrow"),
	TEXT ("up-arrow"),
	TEXT ("right-arrow"),
	TEXT ("down-arrow"),
	TEXT ("invalid-char"),
	/* registry �� invalid-char ������ƑO��insert����̂�bind���ύX����Ă��܂��̂Ō�ɒǉ�����B*/
	TEXT ("save-user-jisyo"),
} ;

static	const TVKKEYBIND	srVkKeyBinds [NUM_MYSPECIAL_KEY]	= {
	{ TEXT ("left"),		VK_LEFT, },
	{ TEXT ("up"),		VK_UP, },
	{ TEXT ("down"),		VK_DOWN, },
	{ TEXT ("right"),		VK_RIGHT, },
	{ TEXT ("insert"),	VK_INSERT, },
	{ TEXT ("delete"),	VK_DELETE, },
	{ TEXT ("backspace"),	VK_BACK, },
	{ TEXT ("tab"),		VK_TAB, },
	{ TEXT ("home"),		VK_HOME, },
	{ TEXT ("space"),		VK_SPACE, },
	{ TEXT ("escape"),	VK_ESCAPE, },
	{ TEXT ("kanji"),		VK_KANJI, },
	{ TEXT ("help"),		VK_HELP, },
	{ TEXT ("f1"),		VK_F1, },
	{ TEXT ("f2"),		VK_F2, },
	{ TEXT ("f3"),		VK_F3, },
	{ TEXT ("f4"),		VK_F4, },
	{ TEXT ("f5"),		VK_F5, },
	{ TEXT ("f6"),		VK_F6, },
	{ TEXT ("f7"),		VK_F7, },
	{ TEXT ("f8"),		VK_F8, },
	{ TEXT ("f9"),		VK_F9, },
	{ TEXT ("f10"),		VK_F10, },
	{ TEXT ("f11"),		VK_F11, },
	{ TEXT ("f12"),		VK_F12, },
	{ TEXT ("clear"),		VK_CLEAR, },
	{ TEXT ("return"),	VK_RETURN, },
} ;

/*========================================================================
 *	public functions
 */
BOOL
skkimeConfig_InitializeKeymap (
	BYTE*			pJMap,
	BYTE*			pAbbrevMap)
{
	if (pJMap == NULL || pAbbrevMap == NULL)
		return	FALSE ;
	return	skkimeConfig_initKeymap (REGPATH_KEYMAP, pJMap, pAbbrevMap) ;
}

BOOL
skkimeConfig_UpdateKeymap (
	BYTE*			pJMap,
	BYTE*			pAbbrevMap)
{
	if (pJMap == NULL || pAbbrevMap == NULL)
		return	FALSE ;
	DEBUGPRINTF ((TEXT ("skkimeConfig_updateKeymap (%p, %p)\n"), pJMap, pAbbrevMap)) ;
	return	skkimeConfig_updateKeymap (REGPATH_KEYMAP, pJMap, pAbbrevMap) ;
}

/*	�L�[�̔��菇���́A
 *	(1) ���z�L�[�R�[�h�ւ� bind ���`�F�b�N�B
 *	(2) �����R�[�h�ւ� bind ���`�F�b�N�B
 *	�ł���B
 *	���āA���̏��͎��ۂ� keymap ���Ђ����Ɏg���̂ł����āA�����ł͕s�v�Ȃ��
 *	�����ǂˁB
 */
void
skkimeConfig_key2string (
	LPTSTR		pstrBuffer,
	UINT		uKey)
{
	static LPCTSTR	rpFormat []	= {
		TEXT ("[%s]"), TEXT ("[C-%s]"), TEXT ("[S-%s]"),
	} ;

	if (/*0 <= uKey &&*/ uKey < 0x20) {
		wsprintf (pstrBuffer, TEXT ("\\C-%c"), TEXT ("@abcdefghijklmnopqrstuvwxyz[\\]^_") [uKey]) ;
		return ;
	}
	if (uKey == 0x20) {
		lstrcpy (pstrBuffer, TEXT ("\\40")) ;
		return ;
	}
	if (0x20 < uKey && uKey < 0x7F) {
		wsprintf (pstrBuffer, TEXT ("%c"), uKey) ;
		return ;
	}
	if (uKey == 0x7F) {
		lstrcpy (pstrBuffer, TEXT ("\\177")) ;
		return ;
	}
	if (0x80 <= uKey && uKey < SIZE_MYKEYMAP) {
		int	nMajor, nMinor ;
		nMajor	= (uKey - 0x80) / NUM_BIND_PER_MYSPECIAL_KEY ;
		nMinor	= (uKey - 0x80) % NUM_BIND_PER_MYSPECIAL_KEY ;
		wsprintf (pstrBuffer, rpFormat [nMinor], srVkKeyBinds [nMajor].m_pszText) ;
		return ;
	}
	lstrcpy (pstrBuffer, TEXT ("undefined")) ;
	return ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgKeybindProc (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgKeybindProc (%x, %d, %x, %x)\n"),
				  hDlg, message, wParam, lParam)) ;

	switch (message) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgKeyBindOnInitDialog (hDlg, message, wParam, lParam) ;

	case	WM_NOTIFY:
		return	skkimeConfig_dlgKeyBindOnNotify (hDlg, message, wParam, lParam) ;

	case	WM_COMMAND:
		return	skkimeConfig_dlgKeyBindOnCommand (hDlg, message, wParam, lParam) ;

	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	Private functions
 */
INT_PTR
skkimeConfig_dlgKeyBindOnInitDialog (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND				hDlgKeybind ;
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	static struct {
		LPTSTR	m_strTitle ;
		int		m_nWidth ;
	}	srColumnInfo [NUM_COLUMN_LIST_KEYBIND]	= {
		{ TEXT ("key"),		100, },
		{ TEXT ("j-map"),		130, },
		{ TEXT ("j-abbrev"),	130, },
	} ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgKeyBindOnInitDialog: lParam(%p), pConfArg(%p)\n"), pPropSheet, pConfArg)) ;

	hDlgKeybind	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hDlgKeybind != NULL) {
		int	nIndex, nKey ;
		LV_COLUMN		lvColumn;
		LVITEM			lvI ;

		ListView_DeleteAllItems (hDlgKeybind) ;
		ListView_SetExtendedListViewStyle (hDlgKeybind, LVS_EX_FULLROWSELECT) ;
		
		lvColumn.mask	= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt	= LVCFMT_LEFT ;
		
		// Insert the five columns in the list view.
		for (nIndex = 0; nIndex < NUM_COLUMN_LIST_KEYBIND ; nIndex ++) {
			lvColumn.cx			= srColumnInfo [nIndex].m_nWidth ;
			lvColumn.pszText	= srColumnInfo [nIndex].m_strTitle ;
			ListView_InsertColumn (hDlgKeybind, nIndex, &lvColumn) ;
		}
		
		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ; 
		lvI.stateMask	= 0 ;
		//nItem			= 0 ;
		
		// Initialize LVITEM members that are different for each item. 
		nIndex	= 0 ;
		for (nKey = 0 ; nKey < SIZE_MYKEYMAP ; nKey ++) {
			int	nJMapBind, nAbbrevBind, nItem ;
			TCHAR	szBuffer [32] ;
			
			nJMapBind	= skkimeConfig_key2item (pConfArg->m_rJMap,      nKey) ;
			nAbbrevBind	= skkimeConfig_key2item (pConfArg->m_rAbbrevMap, nKey) ;
			if ((0 <= nJMapBind && nJMapBind < NUM_SELECTABLE_FUNCTIONS &&
				 nJMapBind   != FUNCNO_INVALID_CHAR &&
				 nJMapBind   != FUNCNO_NOFUNCTION) ||
				(0 <= nAbbrevBind && nAbbrevBind < NUM_SELECTABLE_FUNCTIONS && 
				 nAbbrevBind != FUNCNO_INVALID_CHAR &&
				 nAbbrevBind != FUNCNO_NOFUNCTION)) {

				DEBUGPRINTF ((TEXT ("Key(%d), j-map(%d), abbrev-map(%d)\n"), 
							  nKey, nJMapBind, nAbbrevBind)) ;

				lvI.iItem		= nIndex ;
				lvI.iImage		= 0 ;
				lvI.iSubItem	= 0 ;
				lvI.lParam		= (LPARAM) nKey ;
				skkimeConfig_key2string (szBuffer, nKey) ;
				lvI.pszText		= szBuffer ;
				nItem			= ListView_InsertItem (hDlgKeybind, &lvI) ;
				if (nItem != -1) {
					DEBUGPRINTF ((TEXT ("Item(%d) <- \"%s\", \"%s\"\n"),
								  nItem,
								  srszKeyFuncName [nJMapBind],
								  srszKeyFuncName [nAbbrevBind])) ;
					ListView_SetItemText (hDlgKeybind, nItem, 1, (LPTSTR) srszKeyFuncName [nJMapBind]) ;
					ListView_SetItemText (hDlgKeybind, nItem, 2, (LPTSTR) srszKeyFuncName [nAbbrevBind]) ;
				}
				nIndex	++ ;
			}
		}
	}
	return	FALSE ;

	UNREFERENCED_PARAMETER (message) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgKeyBindOnNotify (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	NMHDR	FAR*		pNMHDR	= (NMHDR *) lParam ;
	static TMYMENUITEM		rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0, TEXT("�ǉ�"), IDC_BUTTON_INSERT, },
		{ MIIM_ID | MIIM_STRING, 0, TEXT("�ύX"), IDC_BUTTON_EDIT, },
		{ MIIM_ID | MIIM_STRING, 0, TEXT("�폜"), IDC_BUTTON_DELETE, },
	} ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_KEYBIND:
	{
		if (pNMHDR->code == NM_RCLICK) {
			NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;
			int	n ;

			n	= skkimeConfig_PopupMenu (hDlg, rmi, NELEMENTS (rmi)) ;
			DEBUGPRINTF ((TEXT ("NM: item(%d), lParam(%d)\n"), pNM->iItem, pNM->lParam)) ;
			if (n > 0) 
				skkimeConfig_doSelectKeyBind (hDlg, pNM->iItem, n) ;
			DEBUGPRINTF ((TEXT ("TrackPopupMenu returns %d\n"), n)) ;
		}
		return	FALSE ;
	}
	default:
		switch (pNMHDR->code){
		case PSN_SETACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
			return	TRUE ;

		case PSN_APPLY:
		{
			if (skkimeConfig_UpdateKeymap (pConfArg->m_rJMap, pConfArg->m_rAbbrevMap)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;
		}
		case PSN_RESET:
		case PSN_HELP:
			break ;
		default:
			return FALSE ;
		}
		return	TRUE ;
	}

	UNREFERENCED_PARAMETER (message) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgKeyBindOnCommand (
	HWND		hDlg,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	WORD	wNotifyCode ;
	WORD	wID ;
	HWND	hwndCtl ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	DEBUGPRINTF ((TEXT ("HWND:(%lx), ID(%u), Notify(%u), CTLWND:(%lx)\n"),
				  hDlg, wID, wNotifyCode, hwndCtl)) ;

	if ((wID == IDC_BUTTON_INSERT || wID == IDC_BUTTON_EDIT || wID == IDC_BUTTON_DELETE) &&
		wNotifyCode == BN_CLICKED) {
		HWND	hwndLV	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
		int	nMark	= -1 ;
		if (hwndLV == NULL)
			return	1 ;
		if (wID != IDC_BUTTON_INSERT) {
			nMark	= ListView_GetSelectionMark (hwndLV) ;
			if (nMark < 0)
				return	1 ;
		}
		skkimeConfig_doSelectKeyBind (hDlg, nMark, wID) ;
	}
	return 0 ;

	UNREFERENCED_PARAMETER (message) ;
}

/*	�X�̃L�[�o�C���h�����肷��_�C�A���O�B
 */
BOOL
skkimeConfig_doSelectKeyBind (
	HWND	hDlg,
	int	nItem,
	int	nControl)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndLV ;
	int					nRetval, nCurSel ;
	LVFINDINFO			lvfi ;
	LVITEM				lvI ;
	TCHAR				szBuffer [32] ;

	pPropSheet		= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg		= (SkkimeConfigArg *) pPropSheet->lParam ;
	hwndLV			= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hwndLV == NULL || pConfArg == NULL)
		return	FALSE ;
	lvI.mask		= LVIF_PARAM ;
	lvI.state		= 0 ;
	lvI.stateMask	= 0 ;
	lvI.iItem		= nItem ;
	lvI.iSubItem	= 0 ;
	lvI.pszText		= 0 ;
	lvI.cchTextMax	= 0 ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		nCurSel		= -1 ;
	} else {
		nCurSel		= lvI.lParam ;
	}

	switch (nControl) {
	case	IDC_BUTTON_EDIT:
		if (nCurSel < 0 || nCurSel >= SIZE_MYKEYMAP)
			return	FALSE ;
		/*	fall through */

	case	IDC_BUTTON_INSERT:
	{
		TDlgSelectKeyBindArg	arg ;

		arg.m_nCurSel		= nCurSel ;
		arg.m_nJMapBind		= FUNCNO_NOFUNCTION ;
		arg.m_nJAbbrevBind	= FUNCNO_NOFUNCTION ;
		arg.m_pJMap			= pConfArg->m_rJMap ;
		arg.m_pAbbrevMap	= pConfArg->m_rAbbrevMap ;

		nRetval	= DialogBoxParam (pConfArg->m_hInst, MAKEINTRESOURCE (IDD_DIALOG_SELECTKEYBIND), hDlg, skkimeConfig_dlgSelectKeyBind, (LPARAM) &arg) ;
		if (nRetval == IDOK) {
			int	nAbbrevBind, nJMapBind ;

			nCurSel		= arg.m_nCurSel ;
			nJMapBind	= arg.m_nJMapBind ;
			nAbbrevBind	= arg.m_nJAbbrevBind ;
			if ((0 <= nCurSel     && nCurSel     < SIZE_MYKEYMAP) &&
				(0 <= nJMapBind   && nJMapBind   < NUM_SELECTABLE_FUNCTIONS) &&
				(0 <= nAbbrevBind && nAbbrevBind < NUM_SELECTABLE_FUNCTIONS)) {
				/*	CurSel ���ω����邱�Ƃ�����̂ŁAnItem �͎�蒼���B*/
				memset (&lvfi, 0, sizeof (lvfi)) ;
				lvfi.flags		= LVFI_PARAM ;
				lvfi.lParam		= nCurSel ;
				nItem			= ListView_FindItem (hwndLV, -1, &lvfi) ;

				lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
				lvI.state		= 0 ; 
				lvI.stateMask	= 0 ;
				lvI.iImage		= 0 ;
				lvI.iSubItem	= 0 ;
				lvI.lParam		= (LPARAM) nCurSel ;
				skkimeConfig_key2string (szBuffer, nCurSel) ;
				lvI.pszText		= szBuffer ;

				if (nItem < 0) {
					nItem			= ListView_GetItemCount (hwndLV) ;
					lvI.iItem		= nItem ;
					ListView_InsertItem (hwndLV, &lvI) ;
					ListView_SetItemText (hwndLV, nItem, 1, (LPTSTR) srszKeyFuncName [nJMapBind]) ;
					ListView_SetItemText (hwndLV, nItem, 2, (LPTSTR) srszKeyFuncName [nAbbrevBind]) ;
					ListView_SortItems   (hwndLV, skkimeConfig_compareKeyBind, 0) ;
				} else {
					lvI.iItem		= nItem ;
					ListView_SetItem     (hwndLV, &lvI) ;
					ListView_SetItemText (hwndLV, nItem, 1, (LPTSTR) srszKeyFuncName [nJMapBind]) ;
					ListView_SetItemText (hwndLV, nItem, 2, (LPTSTR) srszKeyFuncName [nAbbrevBind]) ;
				}
				pConfArg->m_rJMap		[nCurSel]	= (unsigned char)nJMapBind ;
				pConfArg->m_rAbbrevMap	[nCurSel]	= (unsigned char)nAbbrevBind ;
				ListView_Update (hwndLV, nItem) ;
			}
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		}
		break ;
	}
	case	IDC_BUTTON_DELETE:
		if (0 <= nCurSel && nCurSel < SIZE_MYKEYMAP) {
			pConfArg->m_rJMap      [nCurSel]	= FUNCNO_INVALID_CHAR ;
			pConfArg->m_rAbbrevMap [nCurSel]	= FUNCNO_INVALID_CHAR ;
			if (! ListView_DeleteItem (hwndLV, nItem)) {
				DEBUGPRINTF ((TEXT ("ListView_DeleteItem (%lx, %d) failed\n"), hwndLV, nItem)) ;
			}
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		}
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

INT_PTR CALLBACK
skkimeConfig_dlgSelectKeyBind (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND	hwndKeyToBind, hwndJMap, hwndJAbbrevMap ;
	TDlgSelectKeyBindArg*	pArg ;
	TCHAR					szBuffer [32] ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		int	i, nCurSel, nJMapFunc, nJAbbrevFunc ;

		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

		pArg			= (TDlgSelectKeyBindArg*) lParam ;
		if (pArg != NULL && 0 <= pArg->m_nCurSel && pArg->m_nCurSel < SIZE_MYKEYMAP) {
			nCurSel			= pArg->m_nCurSel ;
			nJMapFunc		= pArg->m_pJMap      [nCurSel] ;
			nJAbbrevFunc	= pArg->m_pAbbrevMap [nCurSel] ;
		} else {
			nCurSel			= -1 ;
			nJMapFunc		= -1 ;
			nJAbbrevFunc	= -1 ;
		}
		hwndKeyToBind	= GetDlgItem (hDlg, IDC_COMBO_KEYTOBIND) ;
		DEBUGPRINTF ((TEXT ("hwndKeyToBind (%lx), Select(%d), Map(%d/%d)\n"),
					  hwndKeyToBind, nCurSel, nJMapFunc, nJAbbrevFunc)) ;
		if (hwndKeyToBind != NULL) {
			/*	���̗̈�́u�����v�Ƃ��Ĉ����B*/
			for (i = 0 ; i < SIZE_MYKEYMAP ; i ++) {
				skkimeConfig_key2string (szBuffer, i) ;
				SendMessage (hwndKeyToBind, CB_ADDSTRING, 0, (LPARAM) szBuffer) ;
			}
			if (nCurSel >= 0)
				SendMessage (hwndKeyToBind, CB_SETCURSEL, (WPARAM) nCurSel, (LPARAM) 0) ;
		}
		hwndJMap		= GetDlgItem (hDlg, IDC_COMBO_JMAPFUNCTOBIND) ;
		hwndJAbbrevMap	= GetDlgItem (hDlg, IDC_COMBO_JABBREVMAPFUNCTOBIND) ;
		if (hwndJMap != NULL && hwndJAbbrevMap != NULL) {
			for (i = 0 ; i < NUM_SELECTABLE_FUNCTIONS ; i ++) {
				SendMessage (hwndJMap, CB_ADDSTRING, 0, (LPARAM) srszKeyFuncName [i]) ;
				SendMessage (hwndJAbbrevMap, CB_ADDSTRING, 0, (LPARAM) srszKeyFuncName [i]) ;
			}
			if (nJMapFunc >= 0)
				SendMessage (hwndJMap, CB_SETCURSEL, (WPARAM) nJMapFunc, (LPARAM) 0) ;
			if (nJAbbrevFunc >= 0)
				SendMessage (hwndJAbbrevMap, CB_SETCURSEL, (WPARAM) nJAbbrevFunc, (LPARAM) 0) ;
		}
		return	TRUE ;
	}
	case	WM_COMMAND:
		/*	���[�ށB�Ԃ�l�� global �ϐ����o�R���邵���Ȃ���... */
		switch (LOWORD (wParam)) {
		case	IDOK:
		{
			int	nKeyCodeInt, nJMapBind, nJAbbrevBind ;

			/*	���ݑI������Ă��� item �𓾂�BCB_ERR �̏ꍇ�� undefined ��
			 *	�Ǝv��...���ȁB*/
			pArg	= (TDlgSelectKeyBindArg *)GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				hwndKeyToBind	= GetDlgItem (hDlg, IDC_COMBO_KEYTOBIND) ;
				hwndJMap		= GetDlgItem (hDlg, IDC_COMBO_JMAPFUNCTOBIND) ;
				hwndJAbbrevMap	= GetDlgItem (hDlg, IDC_COMBO_JABBREVMAPFUNCTOBIND) ;
				nKeyCodeInt		= SendMessage (hwndKeyToBind,  CB_GETCURSEL, 0, 0) ;
				nJMapBind		= SendMessage (hwndJMap,       CB_GETCURSEL, 0, 0) ;
				nJAbbrevBind	= SendMessage (hwndJAbbrevMap, CB_GETCURSEL, 0, 0) ;
				if (nKeyCodeInt 	!= CB_ERR &&
					nJMapBind   	!= CB_ERR &&
					nJAbbrevBind	!= CB_ERR) {
					DEBUGPRINTF ((TEXT ("Select (%d, %d, %d)\n"),
								  nKeyCodeInt, nJMapBind, nJAbbrevBind)) ;
					pArg->m_nCurSel			= nKeyCodeInt ;
					pArg->m_nJMapBind		= nJMapBind ;
					pArg->m_nJAbbrevBind	= nJAbbrevBind ;
				} else {
					/*	������ƒl�������Ă��Ȃ���� CANCEL �ƈ����B*/
					pArg->m_nCurSel			= -1 ;
					pArg->m_nJMapBind		= FUNCNO_INVALID_CHAR ;
					pArg->m_nJAbbrevBind	= FUNCNO_INVALID_CHAR ;
					wParam					= IDCANCEL ;
				}
			}
		}
		case	IDCANCEL:
			EndDialog (hDlg, wParam) ;
			return	TRUE ;
		}
	default:
		break ;
	}
	return	FALSE ;
}

int CALLBACK
skkimeConfig_compareKeyBind (
	LPARAM		lParam1,
	LPARAM		lParam2, 
	LPARAM		lParamSort)
{
	return	(lParam1 - lParam2) ;
	UNREFERENCED_PARAMETER (lParamSort) ;
}

/*	�L�[�o�C���h�̓��W�X�g���� BINARY �ŏ�����Ă���B
 */
BOOL
skkimeConfig_initKeymap (
	LPCTSTR		pstrSubKey,
	BYTE*			pJMap,
	BYTE*			pAbbrevMap)
{
	BOOL	fFoundAbbrevMap, fFoundNormalMap ;
	int	i ;
	HKEY	hSubKey ;
	BYTE	rbyKeyMap [SIZE_MYKEYMAP] ;

	fFoundNormalMap	= FALSE ;
	fFoundAbbrevMap	= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;

		DEBUGPRINTF ((TEXT ("RegKeyOpenEx succeeded (\"%s\")\n"), pstrSubKey)) ;

		/*	j-map ���̏����B*/
		cbData	= sizeof (rbyKeyMap) ;
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JMAP, NULL, &dwType, rbyKeyMap, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY) {
			int	nData	= (int) cbData ;
			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < nData ; i ++) {
				if (rbyKeyMap [i] >= NUM_SELECTABLE_FUNCTIONS) {
					*(pJMap + i)	= FUNCNO_INVALID_CHAR ;
				} else {
					*(pJMap + i)	= rbyKeyMap [i] ;
				}
			}
			fFoundNormalMap	= TRUE ;
		}
		/*	j-abbrev-map ���̏����B*/
		cbData	= sizeof (rbyKeyMap) ;
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JABBREVMAP, NULL, &dwType, rbyKeyMap, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY) {
			int	nData	= (int) cbData ;
			/*	�������o�^����Ă���ꍇ�̏����B*/
			for (i = 0 ; i < nData ; i ++) {
				if (rbyKeyMap [i] >= NUM_SELECTABLE_FUNCTIONS) {
					*(pAbbrevMap + i)	= FUNCNO_INVALID_CHAR ;
				} else {
					*(pAbbrevMap + i)	= rbyKeyMap [i] ;
				}
			}
			fFoundAbbrevMap	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! fFoundNormalMap) {
		for (i = 0 ; i < SIZE_MYKEYMAP ; i ++) 
			*(pJMap + i)	= (BYTE)riDefaultSkkJMapBind [i] ;
	}
	if (! fFoundAbbrevMap) {
		for (i = 0 ; i < SIZE_MYKEYMAP ; i ++)
			*(pAbbrevMap + i)	= (BYTE)riDefaultAbbrevMapBind [i] ;
	}
	return	TRUE ;
}

/*	�X�V���ʂ����W�X�g���ɏ����o��������s���B
 */
BOOL
skkimeConfig_updateKeymap (
	LPCTSTR	pstrSubKey,
	BYTE*		pJMap,
	BYTE*		pAbbrevMap)
{
	HKEY			hSubKey ;
	BOOL	fRetval	= TRUE ;

	if (! skkimeConfig_CreateKey (pstrSubKey, FALSE, &hSubKey))
		return	FALSE ;
	
	if (RegSetValueEx (hSubKey, REGSUBKEY_JMAP,			0, REG_BINARY, pJMap,      SIZE_MYKEYMAP) != ERROR_SUCCESS ||
		RegSetValueEx (hSubKey, REGSUBKEY_JABBREVMAP,	0, REG_BINARY, pAbbrevMap, SIZE_MYKEYMAP) != ERROR_SUCCESS) {
		fRetval	= FALSE ;
	}
	if (RegCloseKey (hSubKey) != ERROR_SUCCESS)
		fRetval	= FALSE ;
	return	fRetval ;
}

int
skkimeConfig_key2item (
	BYTE*		pKeymap,
	UINT		uKey)
{
	if (uKey >= SIZE_MYKEYMAP)
		return	FUNCNO_NOFUNCTION ;
	return	*(pKeymap + uKey) ;
}

