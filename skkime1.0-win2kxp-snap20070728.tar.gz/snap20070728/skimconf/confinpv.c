/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#define	REGPATH_INPUTVECTOR			REGPATH_SKKIME_BASE TEXT("\\InputVector")
#define	REGPATH_ZENKAKUVECTOR		REGPATH_SKKIME_BASE TEXT("\\ZenkakuVector")
#define	MAX_LENGTH_INPUTVECTOR		(128)

typedef struct {
	int				m_nKeyCode ;
	LPTSTR			m_strInputVector ;
}	TDEFINPUTVECTOR ;

typedef struct {
	int				m_nCurSel ;
	LPTSTR*			m_pInputVector ;
	TCHAR			m_strValue [MAX_LENGTH_INPUTVECTOR] ;		/* 128 �����ȏ�͑ʖځB*/
}	TDlgEditInputVectorArg ;

/*	Prototype 
 */
static	INT_PTR	skkimeConfig_dlgInputVectorOnInitDialog (HWND, WPARAM, LPARAM, int) ;
static	INT_PTR	skkimeConfig_dlgInputVectorOnCommand    (HWND, WPARAM, LPARAM, int) ;
static	INT_PTR	skkimeConfig_dlgInputVectorOnNotify     (HWND, WPARAM, LPARAM, int) ;
static	BOOL				skkimeConfig_doEditInputVector	(HWND, int, int, int, LPTSTR*) ;
static	INT_PTR CALLBACK	skkimeConfig_dlgEditInputVector	(HWND, UINT, WPARAM, LPARAM) ;
static	int CALLBACK		skkimeConfig_compareInputVector (LPARAM, LPARAM, LPARAM) ;
static	BOOL	skkimeConfig_initInputVector			(LPCTSTR, LPTSTR*, TDEFINPUTVECTOR*, int) ;
static	BOOL	skkimeConfig_updateInputVector			(LPCTSTR, LPTSTR*) ;

/*	static global variables
 */
static	TDEFINPUTVECTOR		srSkkinputDefaultInputVector []	= {
	{ '!',	TEXT ("�I"), },	{ ',',	TEXT ("�A"), },
	{ '-',	TEXT ("�["), },	{ '.',	TEXT ("�B"), },
	{ ':',	TEXT ("�F"), },	{ ';',	TEXT ("�G"), },
	{ '?',	TEXT ("�H"), },	{ '[',	TEXT ("�u"), },
	{ ']',	TEXT ("�v"), },
} ;

static	TDEFINPUTVECTOR		srSkkinputDefaultZenkakuVector []	= {
	{ 0x20,	TEXT ("�@"), },	{ 0x21,	TEXT ("�I"), },
	{ 0x22,	TEXT ("�h"), },	{ 0x23,	TEXT ("��"), },
	{ 0x24,	TEXT ("��"), },	{ 0x25,	TEXT ("��"), },
	{ 0x26,	TEXT ("��"), },	{ 0x27,	TEXT ("�f"), },
	{ 0x28,	TEXT ("�i"), },	{ 0x29,	TEXT ("�j"), },
	{ 0x2A,	TEXT ("��"), },	{ 0x2B,	TEXT ("�{"), },
	{ 0x2C,	TEXT ("�C"), },	{ 0x2D,	TEXT ("�|"), },
	{ 0x2E,	TEXT ("�D"), },	{ 0x2F,	TEXT ("�^"), },
	{ 0x30,	TEXT ("�O"), },	{ 0x31,	TEXT ("�P"), },
	{ 0x32,	TEXT ("�Q"), },	{ 0x33,	TEXT ("�R"), },
	{ 0x34, TEXT ("�S"), },	{ 0x35,	TEXT ("�T"), },
	{ 0x36,	TEXT ("�U"), },	{ 0x37,	TEXT ("�V"), }, 
	{ 0x38, TEXT ("�W"), },	{ 0x39,	TEXT ("�X"), },
	{ 0x3A,	TEXT ("�F"), },	{ 0x3B,	TEXT ("�G"), },
	{ 0x3C, TEXT ("��"), },	{ 0x3D,	TEXT ("��"), },
	{ 0x3E,	TEXT ("��"), },	{ 0x3F,	TEXT ("�H"), },
	{ 0x40, TEXT ("��"), },	{ 0x41,	TEXT ("�`"), },
	{ 0x42,	TEXT ("�a"), },	{ 0x43,	TEXT ("�b"), },
	{ 0x44, TEXT ("�c"), },	{ 0x45,	TEXT ("�d"), },
	{ 0x46,	TEXT ("�e"), },	{ 0x47,	TEXT ("�f"), },
	{ 0x48, TEXT ("�g"), },	{ 0x49,	TEXT ("�h"), },
	{ 0x4A,	TEXT ("�i"), },	{ 0x4B,	TEXT ("�j"), },
	{ 0x4C, TEXT ("�k"), },	{ 0x4D,	TEXT ("�l"), },
	{ 0x4E,	TEXT ("�m"), },	{ 0x4F,	TEXT ("�n"), }, 
	{ 0x50, TEXT ("�o"), },	{ 0x51,	TEXT ("�p"), },
	{ 0x52,	TEXT ("�q"), },	{ 0x53,	TEXT ("�r"), },
	{ 0x54, TEXT ("�s"), },	{ 0x55,	TEXT ("�t"), },
	{ 0x56,	TEXT ("�u"), },	{ 0x57,	TEXT ("�v"), },  
	{ 0x58, TEXT ("�w"), },	{ 0x59,	TEXT ("�x"), },
	{ 0x5A,	TEXT ("�y"), },	{ 0x5B,	TEXT ("�m"), },
	{ 0x5C, TEXT ("�_"), },	{ 0x5D,	TEXT ("�n"), },
	{ 0x5E,	TEXT ("�O"), },	{ 0x5F,	TEXT ("�Q"), },  
	{ 0x60, TEXT ("�e"), },	{ 0x61,	TEXT ("��"), },
	{ 0x62,	TEXT ("��"), },	{ 0x63,	TEXT ("��"), },
	{ 0x64, TEXT ("��"), },	{ 0x65,	TEXT ("��"), },
	{ 0x66,	TEXT ("��"), },	{ 0x67,	TEXT ("��"), },  
	{ 0x68, TEXT ("��"), },	{ 0x69,	TEXT ("��"), },
	{ 0x6A,	TEXT ("��"), },	{ 0x6B,	TEXT ("��"), },
	{ 0x6C, TEXT ("��"), },	{ 0x6D,	TEXT ("��"), },
	{ 0x6E,	TEXT ("��"), },	{ 0x6F,	TEXT ("��"), },  
	{ 0x70, TEXT ("��"), },	{ 0x71,	TEXT ("��"), },
	{ 0x72,	TEXT ("��"), },	{ 0x73,	TEXT ("��"), },
	{ 0x74, TEXT ("��"), },	{ 0x75,	TEXT ("��"), },
	{ 0x76,	TEXT ("��"), },	{ 0x77,	TEXT ("��"), },  
	{ 0x78, TEXT ("��"), },	{ 0x79,	TEXT ("��"), },
	{ 0x7A,	TEXT ("��"), },	{ 0x7B,	TEXT ("�o"), },
	{ 0x7C, TEXT ("�b"), },	{ 0x7D,	TEXT ("�p"), },
	{ 0x7E,	TEXT ("�`"), },
} ;

/*========================================================================
 *	public functions
 */
BOOL
skkimeConfig_InitializeInputVector (
	LPTSTR*		ppInputVector)
{
	if (ppInputVector == NULL)
		return	FALSE ;

	return	skkimeConfig_initInputVector (REGPATH_INPUTVECTOR, ppInputVector, srSkkinputDefaultInputVector, NELEMENTS (srSkkinputDefaultInputVector)) ;
}

BOOL
skkimeConfig_InitializeZenkakuVector (
	LPTSTR*		ppZenkakuVector)
{
	if (ppZenkakuVector == NULL)
		return	FALSE ;

	return	skkimeConfig_initInputVector (REGPATH_ZENKAKUVECTOR, ppZenkakuVector, srSkkinputDefaultZenkakuVector, NELEMENTS (srSkkinputDefaultZenkakuVector)) ;
}

BOOL
skkimeConfig_UpdateInputVector (
	LPTSTR*		ppInputVector)
{
	if (ppInputVector == NULL)
		return	FALSE ;
	DEBUGPRINTF ((TEXT ("skkimeConfig_updateInputVector (%p)\n"), ppInputVector)) ;
	return	skkimeConfig_updateInputVector (REGPATH_INPUTVECTOR, ppInputVector) ;
}

BOOL
skkimeConfig_UpdateZenkakuVector (
	LPTSTR*		ppZenkakuVector)
{
	if (ppZenkakuVector == NULL)
		return	FALSE ;
	DEBUGPRINTF ((TEXT ("skkimeConfig_updateZenkakuVector (%p)\n"), ppZenkakuVector)) ;
	return	skkimeConfig_updateInputVector (REGPATH_ZENKAKUVECTOR, ppZenkakuVector) ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgInputVectorProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgInputVectorProc (%x, %d, %x, %x)\n"),
				  hDlg, uMsg, wParam, lParam)) ;
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgInputVectorOnInitDialog (hDlg, wParam, lParam, IDC_LIST_INPUTVECTOR) ;

	case	WM_COMMAND:
		return	skkimeConfig_dlgInputVectorOnCommand (hDlg, wParam, lParam, IDC_LIST_INPUTVECTOR) ;

	case	WM_NOTIFY:
	{
		LPPROPSHEETPAGE	pPropSheet ;
		SkkimeConfigArg*	pConfArg ;
		NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

		if (pNMHDR->idFrom == IDC_LIST_INPUTVECTOR)
			return	skkimeConfig_dlgInputVectorOnNotify (hDlg, wParam, lParam, IDC_LIST_INPUTVECTOR) ;

		pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
		pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

		switch (pNMHDR->code){
		case PSN_SETACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
			return	TRUE ;

		case PSN_APPLY:
		{
			if (skkimeConfig_UpdateInputVector (pConfArg->m_rInputVector)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;
		}
		case PSN_RESET:
		case PSN_HELP:
			break ;

		default:
			return FALSE ;
		}
		return	TRUE ;
	}
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgZenkakuVectorProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgZenkakuVectorProc (%x, %d, %x, %x)\n"),
				 hDlg, uMsg, wParam, lParam)) ;
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgInputVectorOnInitDialog (hDlg, wParam, lParam, IDC_LIST_ZENKAKUVECTOR) ;

	case	WM_COMMAND:
		return	skkimeConfig_dlgInputVectorOnCommand (hDlg, wParam, lParam, IDC_LIST_ZENKAKUVECTOR) ;

	case	WM_NOTIFY:
	{
		NMHDR	FAR*		pNMHDR	= (NMHDR *) lParam ;
		LPPROPSHEETPAGE		pPropSheet ;
		SkkimeConfigArg*	pConfArg ;

		if (pNMHDR->idFrom == IDC_LIST_ZENKAKUVECTOR)
			return	skkimeConfig_dlgInputVectorOnNotify (hDlg, wParam, lParam, IDC_LIST_ZENKAKUVECTOR) ;

		pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
		pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

		switch (pNMHDR->code){
		case PSN_SETACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
			return	TRUE ;

		case PSN_APPLY:
		{
			if (skkimeConfig_UpdateZenkakuVector (pConfArg->m_rZenkakuVector)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;
		}
		case PSN_RESET:
		case PSN_HELP:
			break ;
		default:
			return FALSE ;
		}
		return	TRUE ;
	}
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	private functions
 */
INT_PTR
skkimeConfig_dlgInputVectorOnInitDialog (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam,
	int		nResourceId)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndInputVectorList ;
	BOOL				fZenkaku	= (nResourceId == IDC_LIST_ZENKAKUVECTOR) ;
	LPTSTR*				pInputVector ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgInputVectorOnInitDialog (%lx)\n"), hDlg)) ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR)lParam) ;
	pPropSheet			= (LPPROPSHEETPAGE) lParam ;
	pConfArg			= (SkkimeConfigArg *) pPropSheet->lParam ;
	hwndInputVectorList	= GetDlgItem (hDlg, nResourceId) ;
	if (hwndInputVectorList != NULL && pConfArg != NULL) {
		int	i, nLength, nItem ;
		LVITEM		lvI ;
		TCHAR			rszBuffer [256] ;

		pInputVector	= (fZenkaku)? pConfArg->m_rZenkakuVector : pConfArg->m_rInputVector ;

		ListView_DeleteAllItems (hwndInputVectorList) ;
		ListView_SetExtendedListViewStyle (hwndInputVectorList, LVS_EX_FULLROWSELECT) ;

		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ; 
		lvI.stateMask	= 0 ;

		nItem			= 0 ;
		for (i = 0 ; i < MAX_INPUTVECTOR ; i ++) {
			if (pInputVector  [i] != NULL) {
				lvI.iItem		= nItem ;
				lvI.iImage		= 0 ;
				lvI.iSubItem	= 0 ;
				lvI.lParam		= (LPARAM) i ;
				nLength			= lstrlen (pInputVector [i]) ;
				/* 128 ������������������������Ȃ��B*/
				if (nLength < MAX_LENGTH_INPUTVECTOR) {
					wsprintf (rszBuffer, TEXT ("[%2x] `%c' = `%s'"), i, i, pInputVector [i]) ;
					lvI.pszText		= rszBuffer ;
					if (ListView_InsertItem (hwndInputVectorList, &lvI) != -1) {
						nItem	++ ;
					} else {
						DEBUGPRINTF ((TEXT ("dlgInputVectorProc: ListView_InsertItem () failed (%d).\n"), i)) ;
					}
				} else {
					FREE (pInputVector [i]) ;
					pInputVector [i]	= NULL ;
				}
			}
		}
	} else {
		DEBUGPRINTF ((TEXT ("IDC_LIST_INPUTVECTOR: error (%ld)\n"), GetLastError ())) ;
	}
	return	FALSE ;

	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgInputVectorOnNotify (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam,
	int			nResourceId)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	NMHDR	FAR*		pNMHDR		= (NMHDR *) lParam ;
	BOOL				fZenkaku	= (nResourceId == IDC_LIST_ZENKAKUVECTOR) ;
	LPTSTR*				pInputVector ;
	static TMYMENUITEM			rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ǉ�"), IDC_BUTTON_INSERT, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ύX"), IDC_BUTTON_EDIT, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�폜"), IDC_BUTTON_DELETE, },
	} ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	if (pConfArg != NULL && pNMHDR->code == NM_RCLICK) {
		NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;
		int			n ;

		pInputVector	= (fZenkaku)? pConfArg->m_rZenkakuVector : pConfArg->m_rInputVector ;

		n	= skkimeConfig_PopupMenu (hDlg, rmi, NELEMENTS (rmi)) ;
		DEBUGPRINTF ((TEXT ("NM: item(%d), lParam(%d)\n"), pNM->iItem, pNM->lParam)) ;
		if (n > 0) 
			skkimeConfig_doEditInputVector (hDlg, nResourceId, ((n != IDC_BUTTON_INSERT)? pNM->iItem : -1), n, pInputVector) ;
		DEBUGPRINTF ((TEXT ("TrackPopupMenu returns %d\n"), n)) ;
	}
	return	FALSE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgInputVectorOnCommand (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam,
	int		nResourceId)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	WORD	wNotifyCode ;
	WORD	wID ;
	HWND	hwndCtl ;
	BOOL	fZenkaku ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;
	fZenkaku	= (nResourceId == IDC_LIST_ZENKAKUVECTOR) ;

	if (pConfArg == NULL)
		return	FALSE ;

	if ((wID == IDC_BUTTON_INSERT || wID == IDC_BUTTON_EDIT || wID == IDC_BUTTON_DELETE) &&
		wNotifyCode == BN_CLICKED) {
		HWND	hwndLV	= GetDlgItem (hDlg, nResourceId) ;
		int		nMark	= -1 ;
		LPTSTR*	pInputVector ;

		if (hwndLV == NULL)
			return	FALSE ;
		if (wID != IDC_BUTTON_INSERT) {
			nMark	= ListView_GetSelectionMark (hwndLV) ;
			if (nMark < 0)
				return	FALSE ;
		}
		pInputVector	= (fZenkaku)? pConfArg->m_rZenkakuVector : pConfArg->m_rInputVector ;
		skkimeConfig_doEditInputVector (hDlg, nResourceId, nMark, wID, pInputVector) ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_doEditInputVector (
	HWND		hDlg,
	int			nResourceId,
	int			nItem,
	int			nControl,
	LPTSTR*		pInputVector)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndLV ;
	LVFINDINFO			lvfi ;
	LVITEM				lvI ;
	int					nCurSel ;
	TCHAR				rszBuffer [256] ;

	pPropSheet		= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg		= (SkkimeConfigArg *) pPropSheet->lParam ;
	hwndLV			= GetDlgItem (hDlg, nResourceId) ;
	if (hwndLV == NULL || pConfArg == NULL)
		return	FALSE ;

	if (nItem >= 0) {
		lvI.mask		= LVIF_PARAM ;
		lvI.state		= 0 ;
		lvI.stateMask	= 0 ;
		lvI.iItem		= nItem ;
		lvI.iSubItem	= 0 ;
		lvI.pszText		= 0 ;
		lvI.cchTextMax	= 0 ;
		if (! ListView_GetItem (hwndLV, &lvI)) {
			nCurSel		= -1 ;
		} else {
			nCurSel		= lvI.lParam ;
		}
	} else {
		/* INSERT �̎��͑I������Ă�����e�����Ȃ��B*/
		nCurSel	= -1 ;
	}

	switch (nControl) {
	case	IDC_BUTTON_EDIT:
		if (nCurSel < 0 || nCurSel >= MAX_INPUTVECTOR)
			return	FALSE ;
		/*	fall through */

	case	IDC_BUTTON_INSERT:
	{
		TDlgEditInputVectorArg	arg ;
		int			nRetval ;

		arg.m_nCurSel		= nCurSel ;
		arg.m_pInputVector	= pInputVector ;
		nRetval	= DialogBoxParam (pConfArg->m_hInst, MAKEINTRESOURCE (IDD_DIALOG_INPUTVECTOR), hDlg, skkimeConfig_dlgEditInputVector, (LPARAM) &arg) ;
		if (nRetval == IDOK) {
			nCurSel	= arg.m_nCurSel ;

			if (0 <= nCurSel && nCurSel < MAX_INPUTVECTOR) {
				LPTSTR	pDest ;
				int		nLength ;

				if (pInputVector [nCurSel]	!= NULL) {
					lvfi.flags		= LVFI_PARAM ;
					lvfi.lParam		= (LPARAM) nCurSel ;
					nItem			= ListView_FindItem (hwndLV, -1, &lvfi) ;

					FREE (pInputVector [nCurSel]) ;
					pInputVector [nCurSel]	= NULL ;
				} else {
					nItem			= -1 ;
				}
				nLength	= lstrlen (arg.m_strValue) ;
				pDest	= MALLOC (sizeof (TCHAR) * (nLength + 1)) ;
				if (pDest != NULL) 
					memcpy (pDest, arg.m_strValue, sizeof (TCHAR) * (nLength + 1)) ;
				pInputVector [nCurSel]	= pDest ;

				lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
				lvI.state		= 0 ; 
				lvI.stateMask	= 0 ;
				lvI.iImage		= 0 ;
				lvI.iSubItem	= 0 ;
				lvI.lParam		= (LPARAM) nCurSel ;
				wsprintf (rszBuffer, TEXT ("[%2x] `%c' = `%s'"), nCurSel, nCurSel, pInputVector [nCurSel]) ;
				lvI.pszText		= rszBuffer ;
				if (nItem >= 0) {
					lvI.iItem	= nItem ;
					ListView_SetItem (hwndLV, &lvI) ;
				} else {
					lvI.iItem	= ListView_GetItemCount (hwndLV) ;
					ListView_InsertItem (hwndLV, &lvI) ;
					ListView_SortItems  (hwndLV, skkimeConfig_compareInputVector, 0) ;
				}
				PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
			}
		}
		break ;
	}
	case	IDC_BUTTON_DELETE:
		if (0 <= nCurSel && nCurSel < MAX_INPUTVECTOR) {
			if (pInputVector [nCurSel]	!= NULL) {
				FREE (pInputVector [nCurSel]) ;
				pInputVector [nCurSel]	= NULL ;
			}
			if (! ListView_DeleteItem (hwndLV, nItem)) {
				DEBUGPRINTF ((TEXT ("ListView_DeleteItem (%lx, %d) failed\n"), 
							  hwndLV, nItem)) ;
			}
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		}
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

/*
 */
INT_PTR CALLBACK
skkimeConfig_dlgEditInputVector (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND		hwndKey, hwndEdit ;
	TCHAR		szBuffer [32] ;
	LPTSTR*		pInputVector ;
	TDlgEditInputVectorArg*	pArg ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		int	i, nCurSel ;

		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

		pArg			= (TDlgEditInputVectorArg*) lParam ;
		if (pArg != NULL && 0 <= pArg->m_nCurSel && pArg->m_nCurSel < MAX_INPUTVECTOR) {
			nCurSel			= pArg->m_nCurSel ;
		} else {
			nCurSel			= -1 ;
		}
		hwndKey	= GetDlgItem (hDlg, IDC_COMBO_CHARTOBIND) ;
		if (hwndKey != NULL) {
			/*	���̗̈�́u�����v�Ƃ��Ĉ����B*/
			for (i = 0 ; i < MAX_INPUTVECTOR ; i ++) {
				skkimeConfig_key2string (szBuffer, i) ;
				SendMessage (hwndKey, CB_ADDSTRING, 0, (LPARAM) szBuffer) ;
			}
			if (nCurSel >= 0)
				SendMessage (hwndKey, CB_SETCURSEL, (WPARAM) nCurSel, (LPARAM) 0) ;
		}
		hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_CHARVALUE) ;
		if (hwndEdit != NULL) {
			pInputVector	= pArg->m_pInputVector ;
			SendMessage (hwndEdit, EM_LIMITTEXT, (WPARAM) MAX_LENGTH_INPUTVECTOR - 1, 0) ;
			if (0 <= nCurSel && nCurSel < MAX_INPUTVECTOR &&
				pInputVector != NULL && pInputVector [nCurSel] != NULL) 
				SetWindowText (hwndEdit, pInputVector [nCurSel]) ;
		}
		return	TRUE ;
	}
	case	WM_COMMAND:
		/*	���[�ށB�Ԃ�l�� global �ϐ����o�R���邵���Ȃ���... */
		switch (LOWORD (wParam)) {
		case	IDOK:
		{
			int	nCH ;

			pArg	= (TDlgEditInputVectorArg *)GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				hwndKey		= GetDlgItem (hDlg, IDC_COMBO_CHARTOBIND) ;
				hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_CHARVALUE) ;
				nCH				= SendMessage (hwndKey,        CB_GETCURSEL, 0, 0) ;
				GetWindowText (hwndEdit, pArg->m_strValue, MAX_LENGTH_INPUTVECTOR) ;
				pArg->m_strValue [MAX_LENGTH_INPUTVECTOR - 1]	= TEXT ('\0') ;
				if (nCH != CB_ERR) {
					pArg->m_nCurSel			= nCH ;
				} else {
					/*	������ƒl�������Ă��Ȃ���� CANCEL �ƈ����B*/
					pArg->m_nCurSel			= -1 ;
					pArg->m_strValue [0]	= TEXT ('\0') ;
					wParam					= IDCANCEL ;
				}
			}
			/*	fall through */
		}
		case	IDCANCEL:
			EndDialog (hDlg, wParam) ;
			return	TRUE ;
		default:
			break ;
		}
		/*	fall through */
	default:
		break ;
	}
	return	FALSE ;
}

int CALLBACK
skkimeConfig_compareInputVector (
	LPARAM		lParam1,
	LPARAM		lParam2, 
	LPARAM		lParamSort)
{
	return	(lParam1 - lParam2) ;
	UNREFERENCED_PARAMETER (lParamSort) ;
}

BOOL
skkimeConfig_initInputVector (
	LPCTSTR				pstrSubKey,
	LPTSTR*				ppVectorTable,
	TDEFINPUTVECTOR*	pDefaultVector,
	int					nDefaultVector)
{
	HKEY		hSubKey ;
	TCHAR		szRegPathInfo [MAX_PATH] ;
	DWORD		dwRegPathInfo, dwType, cbData ;
	long		lValue ;
	int			nIndex ;
	LONG		lResult ;
	BOOL		fRetval	= TRUE ;
	int			i ;
	LPTSTR		pDest ;

	for (i = 0 ; i < MAX_INPUTVECTOR ; i++)
		*(ppVectorTable + i)	= NULL ;
	
	if (RegOpenKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
		TDEFINPUTVECTOR*	pDefVector ;
		LPCTSTR			strVector ;
		int				nCode, nDest ;

		pDefVector	= pDefaultVector ;
		for (i = 0 ; i < nDefaultVector ; i ++) {
			nCode		= pDefVector->m_nKeyCode ;
			strVector	= pDefVector->m_strInputVector ;
			ASSERT (0 <= nCode && nCode < MAX_INPUTVECTOR) ;
			ASSERT (strVector != NULL) ;

			nDest		= lstrlen (strVector) + 1 ;
			pDest		= MALLOC (nDest * sizeof (TCHAR)) ;
			if (pDest == NULL)
				return	FALSE ;

			/*	TCHAR �̊i�[��� nDest ������B*/
			lstrcpy (pDest, strVector) ;
			DEBUGPRINTF ((TEXT ("InputVector(%d):\"%s\"\n"), nCode, pDest)) ;
			*(ppVectorTable + nCode)	= pDest ;
			pDefVector	++ ;
		}
		return	TRUE ;
	}

	for (nIndex = 0 ; ; nIndex ++) {
		dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
		cbData			= 0 ;
		lResult	= RegEnumValue (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
		if (lResult != ERROR_SUCCESS)
			break ;
		lResult	= RegQueryValueEx (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS)
			continue ;
		/* ���傷����f�[�^�͎̂Ă�B*/
		if (dwType != REG_SZ) 
			continue ;
		/* vector[����] = �f�[�^ �Ƃ������B*/
		lValue	= _ttol (szRegPathInfo) ;
		if (lValue < 0 || lValue >= MAX_INPUTVECTOR)
			continue ;
		pDest	= MALLOC (cbData) ;
		if (pDest == NULL) {
			fRetval	= FALSE ;
			break ;
		}
		(void) RegQueryValueEx (hSubKey, szRegPathInfo, NULL, NULL, (BYTE*)pDest, &cbData) ;
		*(ppVectorTable + lValue)	= pDest ;
	}
	RegCloseKey (hSubKey) ;
	return	fRetval ;
}

BOOL
skkimeConfig_updateInputVector (
	LPCTSTR	pstrSubKey,
	LPTSTR*	ppInputVector)
{
	HKEY	hSubKey ;
	TCHAR	szRegPathInfo [MAX_PATH] ;
	LPTSTR*	pTable ;
	int		i ;
	
	if (! skkimeConfig_CreateKey (pstrSubKey, TRUE, &hSubKey)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_updateInputVector (): create-key(\"%s\") failed\n"), pstrSubKey)) ;
		return	FALSE ;
	}

	/*	����̒l��o�^����B*/
	pTable	= ppInputVector ;
	for (i = 0 ; i < MAX_INPUTVECTOR ; i ++) {
		if (*pTable != NULL && **pTable != TEXT ('\0')) {
			wsprintf (szRegPathInfo, TEXT ("%d"), i) ;
			/*	REG_SZ �œo�^����ꍇ�ɂ́A�I�[�� NUL ���܂߂��T�C�Y�� cbdata ��
			 *	�n���Ȃ���΂Ȃ�Ȃ��B�v���ӁB
			 */
			if (RegSetValueEx (hSubKey, szRegPathInfo, 0, REG_SZ, (BYTE *)*pTable, sizeof (TCHAR) * (lstrlen (*pTable) + 1)) != ERROR_SUCCESS) {
				break ;
			}
		}
		pTable	++ ;
	}
	RegCloseKey (hSubKey) ;
	return	(i < MAX_INPUTVECTOR)? FALSE : TRUE ;
}

