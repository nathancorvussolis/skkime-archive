#include "StdAfx.h"
#include "confcommon.h"
#include "keymap.h"
#define	_NO_EXTERN_
#include "confdefaults.h"
