#if !defined (TPacket_h)
#define	TPacket_h

/*	�}�N���B
 */
#define	bytep2word(ptr)	(((WORD)((ptr)[0])) | ((WORD)((ptr)[1]) << 8))

/*
 *	�萔��`�B
 */
#define	PACKETBUFSIZE	(2048)

/*
 *	�\���̂̒�`�B
 */
typedef struct tagTPacket {
	BYTE	m_rbyBuffer [PACKETBUFSIZE] ;
	int		m_nUsage ;
}	CTPacket ;

/*	�v���g�^�C�v�錾�B*/
void	TPacket_Initialize	(CTPacket*) ;
BOOL	TPacket_SetHeader	(CTPacket*, int, int) ;
BOOL	TPacket_AddPad		(CTPacket*) ;
BOOL	TPacket_AddCard32	(CTPacket*, DWORD) ;
BOOL	TPacket_AddCard16	(CTPacket*, WORD) ;
BOOL	TPacket_AddCard8	(CTPacket*, BYTE) ;
BOOL	TPacket_SetLength	(CTPacket*) ;
BOOL	TPacket_SetCard16	(CTPacket*, int, WORD) ;
BOOL	TPacket_GetCard16	(CTPacket*, int, WORD*) ;
BOOL	TPacket_AddString	(CTPacket*, LPCWSTR, int) ;
BOOL	TPacket_AddByte		(CTPacket*, LPBYTE, int) ;
BOOL	TPacket_GetHeader	(CTPacket*, int*, int*, int*) ;
BYTE*	TPacket_GetData		(CTPacket*) ;
int		TPacket_GetSize		(CTPacket*) ;
void	TPacket_SetSize		(CTPacket*, int) ;
BOOL	TPacket_Send		(HANDLE, CTPacket*) ;
BOOL	TPacket_Recv		(HANDLE, CTPacket*) ;

#endif

