#if !defined (TServerSession_h)
#define	TServerSession_h

#include "varbuffer.h"

#define	MAXKEYWORDLEN		(256)
#define	CANDIDATEHASHSIZE	(37)

typedef struct tagCTSearchSessionCandidate {
	int		_nIndex ;
	struct tagCTSearchSessionCandidate*	_pPrev ;
	struct tagCTSearchSessionCandidate*	_pNext ;
	struct tagCTSearchSessionCandidate*	_pRef ;
	struct tagCTSearchSessionCandidate*	_pLeft ;
	struct tagCTSearchSessionCandidate*	_pRight ;
}	CTSearchSessionCandidate ;

typedef struct tagCTHenkanSession {
	WCHAR							_rszKeyword [MAXKEYWORDLEN] ;
	int								_nwstrKeyword ;

	CTSearchSessionCandidate*		_pCurCandidate ;
	CTSearchSessionCandidate*		_pTopCandidate ;
	CTSearchSessionCandidate*		_pLastCandidate ;
	/*	�P��̏d�Ȃ������邽�߂� hash table */
	CTSearchSessionCandidate*		_rpTblCandidate [CANDIDATEHASHSIZE] ;
	/*	�P��̗���܂Ƃ߂ĕێ����Ă���o�b�t�@�B*/
	TVarbuffer						_vbufCandidate ;
	int								_nCandidate ;
	int								_nSearchCount ;
	int								_nParsePosition ;

	BOOL	(*_pSearchProc)(struct tagCTHenkanSession*) ;
	BOOL	(*_pSeparatorpProc)(WCHAR) ;
}	CTHenkanSession ;


/*	�ϊ�/completion �֘A�B*/
CTHenkanSession*	TCompletionSession_Init (LPCWSTR, int) ;
CTHenkanSession*	THenkanSession_Init (LPCWSTR, int) ;
CTHenkanSession*	TOkuriHenkanSession_Init (LPCWSTR, int) ;
void	THenkanSession_Uninit (CTHenkanSession*) ;

LPCWSTR	THenkanSession_GetKeyword (CTHenkanSession*, int*) ;
BOOL	THenkanSession_NextCandidate (CTHenkanSession*) ;
BOOL	THenkanSession_PreviousCandidate (CTHenkanSession*) ;
LPCWSTR	THenkanSession_GetCandidate (CTHenkanSession*) ;
BOOL	THenkanSession_InsertCandidate (CTHenkanSession*, LPCWSTR, int) ;
BOOL	THenkanSession_RemoveCandidate (CTHenkanSession*) ;
BOOL	THenkanSession_Rewind (CTHenkanSession*) ;
BOOL	THenkanSession_LinkCandidate (CTHenkanSession*, CTSearchSessionCandidate*) ;
LPCWSTR	THenkanSession_GetReferCandidate (CTHenkanSession*) ;
CTSearchSessionCandidate*	THenkanSession_GetCurrentPoint (CTHenkanSession*) ;
int		THenkanSession_GetNumberOfCandidate (CTHenkanSession*, BOOL*) ;

/*	record/purge */
BOOL	RecordCandidate (LPCWSTR, int, LPCWSTR, int, BOOL) ;
BOOL	PurgeCandidate (LPCWSTR, int, LPCWSTR, int, BOOL) ;

/*	cutbuffer �֘A�B*/
BOOL	SetCutBuffer (LPCWSTR, int, BOOL) ;
int		GetCutBuffer (LPWSTR, int) ;

/*	lisp �֘A�B*/
BOOL	TLispEval (LPCWSTR, int, LPWSTR, int) ;
BOOL	TSetJNumList (LPCWSTR, int) ;

/*	*/
BOOL	TServerSession_ClassInit	(void) ;
BOOL	UpdateServerConfiguration	(void) ;
BOOL	SynchronizeLocalJisyo		(void) ;

#endif

