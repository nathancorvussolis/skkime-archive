#pragma once

#ifdef _UNICODE
#if defined _M_IX86
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_IA64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='ia64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
#endif

#include "resource.h"
#include "confcommon.h"
#include "keymap.h"

#define	MAX_REGVALUE_SIZE	(sizeof (TCHAR) * 256)

typedef struct {
	unsigned int	m_fMask ;
	int				m_fType ;
	LPTSTR			m_strText ;
	DWORD			m_wID ;
}	TMYMENUITEM ;

typedef struct tagROMAKANATABLENODE {
	LPTSTR			m_strPrefix ;
	LPTSTR			m_strKana ;
	LPTSTR			m_strKatakana ;
	int				m_chVowel ;
	struct tagROMAKANATABLENODE*	m_pPrev ;
	struct tagROMAKANATABLENODE*	m_pNext ;
}	ROMAKANATABLENODE ;

typedef struct tagPREFIXLISTNODE {
	LPTSTR			m_strPrefix ;
	struct tagPREFIXLISTNODE*		m_pPrev ;
	struct tagPREFIXLISTNODE*		m_pNext ;
}	PREFIXLISTNODE ;

typedef struct tagSKKROMAKANARULENODE {
	LPTSTR			m_strState ;
	LPTSTR			m_strNext ;
	LPTSTR			m_strHoutput ;
	LPTSTR			m_strKoutput ;
	struct tagSKKROMAKANARULENODE*	m_pPrev ;
	struct tagSKKROMAKANARULENODE*	m_pNext ;
}	SKKROMAKANARULENODE ;

typedef struct tagPORTANDHOSTNODE {
	int				m_nPort ;
	LPTSTR			m_strHost ;
	struct tagPORTANDHOSTNODE*		m_pPrev ;
	struct tagPORTANDHOSTNODE*		m_pNext ;
}	PORTANDHOSTNODE ;

typedef struct tagDICTNODE {
	int						m_nIndex ;
	int						m_nType ;
	PORTANDHOSTNODE*		m_lstHost ;
	LPTSTR					m_strPath ;
	BOOL					m_fEnableAuxJisyo ;	// DICTYPE_SERVER only
	BOOL					m_fSortedAuxJisyo ;	// DICTYPE_SERVER only
	struct tagDICTNODE*		m_pPrev ;
	struct tagDICTNODE*		m_pNext ;
}	DICTNODE ;

typedef struct tagSkkimeConfigArg {
	HWND					m_hPropSheetDlg ;
	HINSTANCE				m_hInst ;
	LPPROPSHEETPAGE			m_pPropSheet ;
	BYTE					m_rJMap				[SIZE_MYKEYMAP] ;
	BYTE					m_rAbbrevMap		[SIZE_MYKEYMAP] ;
	LPTSTR					m_rInputVector		[MAX_INPUTVECTOR] ;
	LPTSTR					m_rZenkakuVector	[MAX_INPUTVECTOR] ;
	ROMAKANATABLENODE*		m_lstRomaKanaA ;
	ROMAKANATABLENODE*		m_lstRomaKanaI ;
	ROMAKANATABLENODE*		m_lstRomaKanaU ;
	ROMAKANATABLENODE*		m_lstRomaKanaE ;
	ROMAKANATABLENODE*		m_lstRomaKanaO ;
	SKKROMAKANARULENODE*	m_lstRomaKanaRule ;
	PREFIXLISTNODE*			m_lstPrefix ;
	DICTNODE*				m_lstSearchJisyo ;
	TCHAR					m_rszUserJisyoPath [MAX_PATH + 1] ;
	MYCOLORFACESET			m_rColorFaceSet		[MAX_SKKIME_COLORFACE] ;
	MYGENERICCONFIG			m_GenericConfig ;
#if !defined (NO_TSF)
	CICEROCONFIG			m_CiceroConfig ;
#endif
	MYCANDSELKEY			m_CandSelKey ;
}	SkkimeConfigArg ;


/*========================================================================
 *	prototypes
 */
/*	confmain.c */
BOOL				skkimeConfig_CreateKey	(LPCTSTR, BOOL, HKEY*) ;
int					skkimeConfig_PopupMenu	(HWND, TMYMENUITEM*, int) ;
COLORREF			GetImeColor				(HWND, int) ;
HBRUSH				GetImeLineBrush			(HWND, int, int, COLORREF*, HBITMAP*, int*) ;
void				DebugPrintf				(LPCTSTR,...) ;

/*	confinpv.c */
BOOL				skkimeConfig_InitializeInputVector		(LPTSTR*) ;
BOOL				skkimeConfig_InitializeZenkakuVector	(LPTSTR*) ;
BOOL				skkimeConfig_UpdateInputVector			(LPTSTR*) ;
BOOL				skkimeConfig_UpdateZenkakuVector		(LPTSTR*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgInputVectorProc			(HWND, UINT, WPARAM, LPARAM) ;
INT_PTR	CALLBACK	skkimeConfig_dlgZenkakuVectorProc		(HWND, UINT, WPARAM, LPARAM) ;

/*	confkey.c */
BOOL				skkimeConfig_InitializeKeymap			(BYTE*, BYTE*) ;
BOOL				skkimeConfig_UpdateKeymap				(BYTE*, BYTE*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgKeybindProc				(HWND, UINT, WPARAM, LPARAM) ;
void				skkimeConfig_key2string					(LPTSTR, UINT) ;

/*	confrmkt.c */
BOOL				skkimeConfig_InitializeRomaKanaTableA	(ROMAKANATABLENODE**) ;
BOOL				skkimeConfig_InitializeRomaKanaTableI	(ROMAKANATABLENODE**) ;
BOOL				skkimeConfig_InitializeRomaKanaTableU	(ROMAKANATABLENODE**) ;
BOOL				skkimeConfig_InitializeRomaKanaTableE	(ROMAKANATABLENODE**) ;
BOOL				skkimeConfig_InitializeRomaKanaTableO	(ROMAKANATABLENODE**) ;
BOOL				skkimeConfig_UpdateRomaKanaTableA		(ROMAKANATABLENODE*) ;
BOOL				skkimeConfig_UpdateRomaKanaTableI		(ROMAKANATABLENODE*) ;
BOOL				skkimeConfig_UpdateRomaKanaTableU		(ROMAKANATABLENODE*) ;
BOOL				skkimeConfig_UpdateRomaKanaTableE		(ROMAKANATABLENODE*) ;
BOOL				skkimeConfig_UpdateRomaKanaTableO		(ROMAKANATABLENODE*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgRomaKanaTblProc			(HWND, UINT, WPARAM, LPARAM) ;

/*	confrmkr.c */
BOOL				skkimeConfig_InitializeRomaKanaRuleList	(SKKROMAKANARULENODE**) ;
BOOL				skkimeConfig_UpdateRomaKanaRuleList		(SKKROMAKANARULENODE*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgRomaKanaRuleProc		(HWND, UINT, WPARAM, LPARAM) ;

/*	confprfx.c */
BOOL				skkimeConfig_InitializePrefixList		(PREFIXLISTNODE**) ;
BOOL				skkimeConfig_UpdatePrefixList			(PREFIXLISTNODE*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgKanaPrefixTblProc		(HWND, UINT, WPARAM, LPARAM) ;

/*	confdict.c */
BOOL				skkimeConfig_InitializeSearchJisyoList	(DICTNODE**, LPTSTR) ;
BOOL				skkimeConfig_UpdateSearchJisyoList		(DICTNODE*, LPTSTR) ;
INT_PTR	CALLBACK	skkimeConfig_dlgDictionaryProc			(HWND, UINT, WPARAM, LPARAM) ;

/*	confcol.c */
BOOL				skkimeConfig_InitializeColorFace		(MYCOLORFACESET*) ;
BOOL				skkimeConfig_UpdateColorFace			(MYCOLORFACESET*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgColorFaceTblProc		(HWND, UINT, WPARAM, LPARAM) ;

/*	confgene.c */
BOOL				skkimeConfig_InitializeGeneric			(MYGENERICCONFIG*) ;
BOOL				skkimeConfig_UpdateGeneric				(MYGENERICCONFIG*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgGenericProc				(HWND, UINT, WPARAM, LPARAM) ;

#if !defined (NO_TSF)
/*	confcicer.c */
BOOL				skkimeConfig_InitializeCICERO			(CICEROCONFIG*) ;
BOOL				skkimeConfig_UpdateCICERO				(CICEROCONFIG*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgCiceroProc				(HWND, UINT, WPARAM, LPARAM) ;
#endif
/*	confcsel.c */
BOOL				skkimeConfig_InitializeCandidateSelectKey	(MYCANDSELKEY*) ;
BOOL				skkimeConfig_UpdateCandidateSelectKey		(MYCANDSELKEY*) ;
INT_PTR	CALLBACK	skkimeConfig_dlgCandidateSelectKeyProc	(HWND, UINT, WPARAM, LPARAM) ;

