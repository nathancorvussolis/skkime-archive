#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"
#include "..\TServerSession.h"

#define	REGPATH_DICTIONARY				REGPATH_SKKIME_BASE TEXT("\\Dictionaries")
#define	REGKEY_USERJISYO				TEXT("UserJisyo")
#define	SKKIME_DEFAULT_JISYO_SETTING	TEXT("user=")
#define	SKKIME_DEFAULT_USERJISYOPATH	TEXT("%USERPROFILE%\\Application Data\\skk\\skki1_0\\skki1_0u.dic")

enum {
	DICTYPE_USER		= 0,
	DICTYPE_SERVER,
	DICTYPE_FILE,
	DICTYPE_SORT,
} ;

typedef struct {
	SkkimeConfigArg*	m_pConfArg ;
	LPPROPSHEETPAGE		m_pPropSheet ;
	HICON				m_hiconArrowUp ;
	HICON				m_hiconArrowDown ;
}	TDlgDictionaryParam ;

typedef struct {
	HINSTANCE			m_hInst ;
	int					m_nType ;
	TCHAR				m_strPath [MAX_PATH + 1] ;
	BOOL				m_fEnableAuxJisyo ;
	BOOL				m_fSortedAuxJisyo ;
	PORTANDHOSTNODE*	m_lstHost ;
}	TDlgEditDictArg ;

typedef struct {
	TCHAR				m_strHost [MAX_PATH + 1] ;	// ?
	int					m_nPort ;
}	TDlgEditServerJisyoArg ;

static	INT_PTR	skkimeConfig_dlgDictionaryOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgDictionaryOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgDictionaryOnCommand		(HWND, UINT, WPARAM, LPARAM) ;
static	BOOL	skkimeConfig_editDictionary				(HWND, int, int) ;

static	INT_PTR	CALLBACK	skkimeConfig_dlgEditServerJisyo	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgEditServerJisyoOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgEditServerJisyoOnCommand	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgEditServerJisyoOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	BOOL	skkimeConfig_editServerJisyo				(HWND, int, int) ;
static	INT_PTR CALLBACK	skkimeConfig_dlgEditJisyoServer	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	skkimeConfig_dlgEditFileJisyo	(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL				skkimeConfig_setDictionaryItemText	(HWND, int, DICTNODE*) ;
static	PORTANDHOSTNODE*	skkimeConfig_copyPortAndHostList	(PORTANDHOSTNODE*) ;

static	BOOL	skkimeConfig_initSearchJisyoList (LPCTSTR, DICTNODE**, LPTSTR) ;
static	BOOL	skkimeConfig_updateSearchJisyoList	(LPCTSTR, DICTNODE*, LPTSTR) ;
static	BOOL	skkimeConfig_parseDictNumber	(LPCTSTR, int*) ;
static	DICTNODE*	skkimeConfig_parseDictionarySetting	(LPCTSTR, int) ;
static	PORTANDHOSTNODE*	skkimeConfig_parsePortAndHost	(LPCTSTR, int) ;
static	BOOL	skkimeConfig_insertDictionaryInSearchList	(DICTNODE**, DICTNODE*) ;
static	DICTNODE*	skkimeConfig_newDictionaryNode	(int, LPCTSTR) ;
static	BOOL	skkimeConfig_registerDictionaryNode	(DICTNODE**, DICTNODE*, DICTNODE*) ;
static	BOOL	skkimeConfig_unregisterDictionaryNode	(DICTNODE**, DICTNODE*) ;
static	void	skkimeConfig_deleteDictionaryNode	(DICTNODE*) ;
static	void	skkimeConfig_deleteHostList	(PORTANDHOSTNODE*) ;
static	PORTANDHOSTNODE*	skkimeConfig_newPortAndHostNode	(LPCTSTR, int, int) ;
static	BOOL	skkimeConfig_registerPortAndHostNode	(PORTANDHOSTNODE*, PORTANDHOSTNODE**, PORTANDHOSTNODE*) ;
static	BOOL	skkimeConfig_unregisterPortAndHostNode	(PORTANDHOSTNODE*, PORTANDHOSTNODE**) ;
static	BOOL	skkimeConfig_hostlist2string		(LPTSTR, int, PORTANDHOSTNODE*) ;

static	BOOL	skkimeConfig_dlgDictionaryMoveSelectedNode	(HWND, SkkimeConfigArg*, BOOL) ;


/*========================================================================
 *	public functions
 */
BOOL
skkimeConfig_InitializeSearchJisyoList (
	DICTNODE**		plstJisyo,
	LPTSTR			strUserJisyoPath)
{
	if (plstJisyo == NULL || strUserJisyoPath == NULL)
		return	FALSE ;
	return	skkimeConfig_initSearchJisyoList (REGPATH_DICTIONARY, plstJisyo, strUserJisyoPath) ;
}

BOOL
skkimeConfig_UpdateSearchJisyoList (
	DICTNODE*		lstJisyo,
	LPTSTR			strUserJisyoPath)
{
	if (lstJisyo == NULL || strUserJisyoPath == NULL)
		return	FALSE ;
	DEBUGPRINTF ((TEXT ("skkimeConfig_UpdateSearchJisyoList (%p, \"%s\")\n"),
				  lstJisyo, strUserJisyoPath)) ;
	return	skkimeConfig_updateSearchJisyoList (REGPATH_DICTIONARY, lstJisyo, strUserJisyoPath) ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgDictionaryProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgDictionaryOnInitDialog (hDlg, uMsg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgDictionaryOnNotify (hDlg, uMsg, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgDictionaryOnCommand (hDlg, uMsg, wParam, lParam) ;
	case	WM_DESTROY:
	{
		TDlgDictionaryParam*	pParam ;
		SkkimeConfigArg*		pConfArg ;

		pParam	= (TDlgDictionaryParam*) GetWindowLongPtr (hDlg, DWLP_USER) ;
		if (pParam == NULL)
			break ;

		pConfArg		= pParam->m_pConfArg ;
		if (pParam->m_hiconArrowUp != NULL) {
			DestroyIcon (pParam->m_hiconArrowUp) ;
			pParam->m_hiconArrowUp	= NULL ;
		}
		if (pParam->m_hiconArrowDown != NULL) {
			DestroyIcon (pParam->m_hiconArrowDown) ;
			pParam->m_hiconArrowDown	= NULL ;
		}
		FREE (pParam) ;
		SetWindowLongPtr (hDlg, DWLP_USER, 0) ;
		break ;
	}
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	private functions
 */
INT_PTR
skkimeConfig_dlgDictionaryOnInitDialog (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE			pPropSheet ;
	SkkimeConfigArg*		pConfArg ;
	TDlgDictionaryParam*	pParam ;
	HWND	hwndEditUsrDicPath ;
	HWND	hwndListSearchDict ;
	HWND	hwndButton ;

	pPropSheet		= (LPPROPSHEETPAGE) lParam ;
	pConfArg		= (SkkimeConfigArg *) pPropSheet->lParam ;

	pParam			= MALLOC (sizeof (TDlgDictionaryParam)) ;
	if (pParam == NULL)
		return	TRUE ;	/* Geeee... critical error... */

	pParam->m_pConfArg			= pConfArg ;
	pParam->m_pPropSheet		= pPropSheet ;
	pParam->m_hiconArrowUp		= NULL ;
	pParam->m_hiconArrowDown	= NULL ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pParam) ;

	hwndEditUsrDicPath	= GetDlgItem (hDlg, IDC_EDIT_USRDICPATH) ;
	if (hwndEditUsrDicPath != NULL) {
		TCHAR	szPath [MAX_PATH + 1] ;
		if (! ExpandEnvironmentStrings (pConfArg->m_rszUserJisyoPath, szPath, MAX_PATH)) {
			SendMessage (hwndEditUsrDicPath, WM_SETTEXT, 0, (LPARAM) pConfArg->m_rszUserJisyoPath) ;
		} else {
			SendMessage (hwndEditUsrDicPath, WM_SETTEXT, 0, (LPARAM) szPath) ;
		}
		SendMessage (hwndEditUsrDicPath, EM_SETLIMITTEXT, (WPARAM) MAX_PATH, 0) ;
	}

	hwndListSearchDict	= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
	if (hwndListSearchDict != NULL) {
		DICTNODE*	pNode ;
		LV_COLUMN	lvColumn;
		LVITEM		lvI ;
		int			n ;
		static LPTSTR	rpszDicType []	= {
			TEXT ("���[�U����"),		TEXT ("�T�[�o����"),
			TEXT ("�t�@�C������"),		TEXT ("�\�[�g�σt�@�C������"),
		} ;
		
		ListView_DeleteAllItems (hwndListSearchDict) ;
		ListView_SetExtendedListViewStyle (hwndListSearchDict, LVS_EX_FULLROWSELECT) ;
		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.cx			= 120 ;
		lvColumn.pszText	= TEXT ("���") ;
		ListView_InsertColumn (hwndListSearchDict, 0, &lvColumn) ;
		lvColumn.cx			= 240 ;
		lvColumn.pszText	= TEXT ("�ݒ�") ;
		ListView_InsertColumn (hwndListSearchDict, 1, &lvColumn) ;
		
		lvI.mask		= LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ; 
		lvI.stateMask	= 0 ;
		lvI.iSubItem	= 0 ;
		lvI.pszText		= 0 ;
		pNode	= pConfArg->m_lstSearchJisyo ;
		n		= 0 ;
		while (pNode != NULL) {
			int	nItem ;
			lvI.iItem		= n ;
			lvI.iImage		= n ;
			lvI.lParam		= (LPARAM) pNode ;
			nItem			= ListView_InsertItem (hwndListSearchDict, &lvI) ;
			if (nItem != -1) 
				skkimeConfig_setDictionaryItemText (hwndListSearchDict, nItem, pNode) ;
			pNode	= pNode->m_pNext ;
			n		++ ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWUP) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= LoadImage (pConfArg->m_hInst, TEXT ("INDICICONL"), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			pParam->m_hiconArrowUp		= hIcon ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWDOWN) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= LoadImage (pConfArg->m_hInst, TEXT ("INDICICONK"), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			pParam->m_hiconArrowDown	= hIcon ;
		}
	}
	return	TRUE ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgDictionaryOnNotify (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	SkkimeConfigArg*		pConfArg ;
	TDlgDictionaryParam*	pParam ;
	NMHDR	FAR*			pNMHDR	= (NMHDR *) lParam ;
	static TMYMENUITEM		rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ǉ�"),		IDC_BUTTON_ADD_FILE_JISYO, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�T�[�o�ǉ�"),IDC_BUTTON_ADD_SERVER_JISYO, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ݒ�ύX"),	IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�폜"),		IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST, },
	} ;

	pParam	= (TDlgDictionaryParam*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pParam == NULL)
		return	1 ;

	pConfArg	= pParam->m_pConfArg ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_SEARCHDICT:
	{
		/*HWND		hwndLV	= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;*/
		NMLISTVIEW*	pNM		= (NMLISTVIEW*) lParam ;
		int			n ;

		switch (pNMHDR->code) {
		case	NM_RCLICK:
			n		= skkimeConfig_PopupMenu (hDlg, rmi, NELEMENTS (rmi)) ;
			if (n > 0) 
				skkimeConfig_editDictionary (hDlg, pNM->iItem, n) ;
			break ;
		default:
			break ;
		}
		break ;
	}
	default:
		switch (pNMHDR->code){
		case PSN_SETACTIVE:
		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_APPLY:
		{
			if (skkimeConfig_UpdateSearchJisyoList (pConfArg->m_lstSearchJisyo, pConfArg->m_rszUserJisyoPath)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
				UpdateServerConfiguration () ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;
		}
		case PSN_RESET:
		case PSN_HELP:
			break ;
		default:
			return FALSE ;
		}
	}
	return	TRUE ;
	
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgDictionaryOnCommand (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	TDlgDictionaryParam*	pParam ;
	SkkimeConfigArg*		pConfArg ;
	WORD				wNotifyCode ;
	WORD				wID ;
	HWND				hwndCtl ;

	pParam		= (TDlgDictionaryParam*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;
	pConfArg	= pParam->m_pConfArg ;

	switch (wID) {
	case	IDC_EDIT_USRDICPATH:
		/*	�G�f�B�b�g�{�b�N�X��ҏW����ƁAAPPLY ���L���ɂȂ�Ȃ���΁B*/
		if (wNotifyCode == EN_CHANGE) 
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		break ;
	case	IDC_BUTTON_BROWSE_USRDICTPATH:
	{
		SkkimeConfigArg*	pConfArg	= pParam->m_pConfArg ;
		OPENFILENAME	ofn ;
		TCHAR			szPath [MAX_PATH + 1] ;
		
		if (wNotifyCode == BN_CLICKED) {
			if (! ExpandEnvironmentStrings (pConfArg->m_rszUserJisyoPath, szPath, MAX_PATH)) 
				lstrcpyn (szPath, pConfArg->m_rszUserJisyoPath, MAX_PATH) ;
			szPath [MAX_PATH]	= TEXT ('\0') ;
			memset (&ofn, 0, sizeof (ofn)) ;
			ofn.lStructSize			= sizeof (OPENFILENAME) ;
			ofn.hwndOwner			= hDlg ;
			ofn.hInstance			= pConfArg->m_hInst ;
			ofn.lpstrFilter			= TEXT ("All\0*.*\0") ;
			ofn.lpstrCustomFilter	= NULL ;
			ofn.nFilterIndex		= 1 ;
			ofn.lpstrFile			= szPath ;
			ofn.nMaxFile			= MAX_PATH ;
			ofn.lpstrFileTitle		= NULL ;
			ofn.lpstrInitialDir		= TEXT ("") ;
			ofn.lpstrTitle			= TEXT ("���[�U�����̑I��") ;
			ofn.Flags				= OFN_CREATEPROMPT | OFN_HIDEREADONLY | OFN_LONGNAMES | OFN_NONETWORKBUTTON ;
			ofn.lpstrDefExt			= NULL ;
			ofn.lpfnHook			= NULL ;
			if (GetOpenFileName (&ofn) != 0) {
				lstrcpyn (pConfArg->m_rszUserJisyoPath, szPath, MAX_PATH) ;
				pConfArg->m_rszUserJisyoPath [MAX_PATH]	= TEXT ('\0') ;
				SetDlgItemText (hDlg, IDC_EDIT_USRDICPATH, szPath) ;
				PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
			}
			return	0 ;
		}
		return	1 ;
	}
	case	IDC_BUTTON_SAVEUSERJISYO:
	{
		/*	skkiserv �Ɏ����̕ۑ���v������B*/
		SynchronizeLocalJisyo () ;
		return	1 ;
	}
	case	IDC_BUTTON_REPAIR_USRDICT:
		return	1 ;
	case	IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST:
	case	IDC_BUTTON_ADD_FILE_JISYO:
	case	IDC_BUTTON_ADD_SERVER_JISYO:
	{
		if (wNotifyCode == BN_CLICKED) {
			HWND	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
			int	nItem ;

			if (hwndLV == NULL)
				return	1 ;
			nItem	= ListView_GetSelectionMark (hwndLV) ;
			skkimeConfig_editDictionary (hDlg, nItem, wID) ;
			return	0 ;
		}
		return	1 ;
	}
	case	IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST:
	{
		if (wNotifyCode == BN_CLICKED) {
			HWND		hwndLV		= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
			DICTNODE**	plstJisyo	= &pConfArg->m_lstSearchJisyo ;
			int			nItem ;
			DICTNODE*	pNode ;
			LVITEM		lvI ;

			if (hwndLV == NULL)
				return	1 ;

			nItem			= ListView_GetSelectionMark (hwndLV) ;
			if (nItem < 0)
				return	1 ;
			lvI.mask		= LVIF_PARAM ;
			lvI.iItem		= nItem ;
			if (! ListView_GetItem (hwndLV, &lvI)) {
				pNode		= NULL ;
			} else {
				pNode		= (DICTNODE *)lvI.lParam ;
			}
			if (pNode == NULL)
				return	1 ;

			ListView_DeleteItem (hwndLV, nItem) ;
			skkimeConfig_unregisterDictionaryNode (plstJisyo, pNode) ;
			skkimeConfig_deleteDictionaryNode (pNode) ;
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
			return	0 ;
		}
	}
	case	IDC_BUTTON_ARROWUP:
		if (wNotifyCode == BN_CLICKED) {
			if (skkimeConfig_dlgDictionaryMoveSelectedNode (hDlg, pConfArg, TRUE))
				PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_ARROWDOWN:
		if (wNotifyCode == BN_CLICKED) {
			if (skkimeConfig_dlgDictionaryMoveSelectedNode (hDlg, pConfArg, FALSE))
				PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
			return	0 ;
		}
		break ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (uMsg) ;
}

BOOL
skkimeConfig_editDictionary (
	HWND		hDlg,
	int		nItem,
	int		nCommand)
{
	TDlgDictionaryParam*	pParam ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndLV ;
	HINSTANCE			hInst ;
	DICTNODE**			plstJisyo ;
	DICTNODE*			pNode ;
	DICTNODE*			pNewNode ;
	TDlgEditDictArg		arg ;
	LVITEM				lvI ;
	int					nRetval, nPath ;

	pParam		= (TDlgDictionaryParam *) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndLV		= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
	if (hwndLV == NULL || pParam == NULL || pParam->m_pConfArg == NULL)
		return	FALSE ;
	pConfArg	= pParam->m_pConfArg ;
	plstJisyo	= &pConfArg->m_lstSearchJisyo ;
	hInst		= pConfArg->m_hInst ;

	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM ;
	lvI.iItem		= nItem ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		pNode		= NULL ;
	} else {
		pNode		= (DICTNODE *)lvI.lParam ;
	}

	arg.m_hInst			= hInst ;
	arg.m_strPath [0]	= TEXT ('\0') ;
	arg.m_lstHost		= NULL ;

	switch (nCommand) {
	case	IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST:
	{
		if (pNode == NULL)
			return	FALSE ;
		if (pNode->m_nType == DICTYPE_USER)
			return	TRUE ;

		arg.m_nType		= pNode->m_nType ;
		arg.m_lstHost	= pNode->m_lstHost ;
		if (pNode->m_strPath != NULL) {
			lstrcpy (arg.m_strPath, pNode->m_strPath) ;
		} else {
			arg.m_strPath [0]	= TEXT ('\0') ;
		}
		lstrcpy (arg.m_strPath, pNode->m_strPath) ;
		arg.m_fEnableAuxJisyo	= pNode->m_fEnableAuxJisyo ;
		arg.m_fSortedAuxJisyo	= pNode->m_fSortedAuxJisyo ;

		if (pNode->m_nType == DICTYPE_SERVER) {
			nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_SERVER_JISYO), hDlg, skkimeConfig_dlgEditServerJisyo, (LPARAM) &arg) ;
		} else if (pNode->m_nType == DICTYPE_FILE || pNode->m_nType == DICTYPE_SORT) {
			nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_FILE_JISYO), hDlg, skkimeConfig_dlgEditFileJisyo, (LPARAM) &arg) ;
		} else {
			return	FALSE ;	/* unknown jisyo type */
		}
		break ;
	}
	case	IDC_BUTTON_ADD_FILE_JISYO:
	{
		arg.m_nType		= DICTYPE_FILE ;
		nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_FILE_JISYO), hDlg, skkimeConfig_dlgEditFileJisyo, (LPARAM) &arg) ;
		break ;
	}
	case	IDC_BUTTON_ADD_SERVER_JISYO:
	{
		arg.m_nType				= DICTYPE_SERVER ;
		arg.m_fEnableAuxJisyo	= FALSE ;
		arg.m_fSortedAuxJisyo	= FALSE ;
		nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_SERVER_JISYO), hDlg, skkimeConfig_dlgEditServerJisyo, (LPARAM) &arg) ;
		break ;
	}
	case	IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST:
	{
		if (pNode == NULL || pNode->m_nType == DICTYPE_USER)
			return	FALSE ;
		ListView_DeleteItem (hwndLV, nItem) ;
		skkimeConfig_unregisterDictionaryNode (plstJisyo, pNode) ;
		skkimeConfig_deleteDictionaryNode (pNode) ;
		return	TRUE ;
	}
	default:
		return	FALSE ;
	}

	/*	nRetval ����͂��ē���B
	 */
	if (nRetval != IDOK) 
		return	TRUE ;
	switch (arg.m_nType) {
	case	DICTYPE_SERVER:
		if (arg.m_lstHost == NULL) {
			DEBUGPRINTF ((TEXT ("server-jisyo: no host/port\n"))) ;
			return	FALSE ;
		}
		break ;
	case	DICTYPE_SORT:
	case	DICTYPE_FILE:
		if (arg.m_strPath [0] == TEXT ('\0')) {
			DEBUGPRINTF ((TEXT ("file- or sort-jisyo: no path\n"))) ;
			return	FALSE ;
		}
		break ;
	default:
		return	FALSE ;
	}

	nPath		= lstrlen (arg.m_strPath) ;
	pNewNode	= skkimeConfig_newDictionaryNode (arg.m_nType, arg.m_strPath) ;
	if (pNewNode == NULL) {
		if (pNode->m_lstHost != arg.m_lstHost && arg.m_lstHost != NULL) 
			skkimeConfig_deleteHostList (arg.m_lstHost) ;
		return	FALSE ;	// out of memory 
	}
	if (arg.m_nType == DICTYPE_SERVER) {
		pNewNode->m_fSortedAuxJisyo	= arg.m_fSortedAuxJisyo ;
		pNewNode->m_fEnableAuxJisyo	= arg.m_fEnableAuxJisyo ;

		pNewNode->m_lstHost			= arg.m_lstHost ;
		if (pNode != NULL && pNode->m_lstHost == arg.m_lstHost) 
			pNode->m_lstHost	= NULL ;
		arg.m_lstHost		= NULL ;
	} else if (arg.m_nType == DICTYPE_FILE || arg.m_nType == DICTYPE_SORT) {
		pNewNode->m_fSortedAuxJisyo	= FALSE ;
		pNewNode->m_fEnableAuxJisyo	= FALSE ;

		pNewNode->m_lstHost	= NULL ;
	}

	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM | LVIF_STATE ;
	lvI.lParam		= (LPARAM) pNewNode ;
	if (nCommand == IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST) {
		lvI.iItem	= nItem ;
		ListView_SetItem (hwndLV, &lvI) ;
		skkimeConfig_registerDictionaryNode (plstJisyo, pNewNode, pNode) ;
		skkimeConfig_unregisterDictionaryNode (plstJisyo, pNode) ;
		skkimeConfig_deleteDictionaryNode (pNode) ;
		skkimeConfig_setDictionaryItemText (hwndLV, nItem, pNewNode) ;
	} else {
		skkimeConfig_registerDictionaryNode (plstJisyo, pNewNode, pNode) ;
		lvI.iItem	= (pNode == NULL)? 0 : (nItem + 1) ;
		nItem		= ListView_InsertItem (hwndLV, &lvI) ;
		if (nItem != -1) 
			skkimeConfig_setDictionaryItemText (hwndLV, nItem, pNewNode) ;
	}
	PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
	return	TRUE ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgEditServerJisyo (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgEditServerJisyoOnInitDialog (hDlg, uMsg, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgEditServerJisyoOnCommand (hDlg, uMsg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgEditServerJisyoOnNotify (hDlg, uMsg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
skkimeConfig_dlgEditServerJisyoOnInitDialog	(
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	PORTANDHOSTNODE*	pNode ;
	TDlgEditDictArg*	pArg ;
	int					nItem, n ;
	LV_COLUMN			lvColumn;
	LVITEM				lvI ;
	HWND				hwndAuxPath, hwndCheck, hwndLV ;
	TCHAR				szBuffer [32] ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pArg			= (TDlgEditDictArg*) lParam ;
	if (pArg == NULL)
		return	TRUE ;

	hwndAuxPath		= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
	if (hwndAuxPath != NULL) {
		SendMessage   (hwndAuxPath, EM_LIMITTEXT, (WPARAM) MAX_PATH, 0) ;
		SetWindowText (hwndAuxPath, pArg->m_strPath) ;
	}

	/*	���X�g���R�s�[����B�I���W���𑀍삷��킯�ɂ͂����Ȃ��̂ŁB*/
	pArg->m_lstHost	= skkimeConfig_copyPortAndHostList (pArg->m_lstHost) ;
	hwndLV			= GetDlgItem (hDlg, IDC_LIST_SERVER_DICT) ;

	if (hwndLV != NULL) {
		ListView_DeleteAllItems (hwndLV) ;
		ListView_SetExtendedListViewStyle (hwndLV, LVS_EX_FULLROWSELECT) ;
	
		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.pszText	= TEXT ("�z�X�g��") ;
		lvColumn.cx			= 120 ;
		ListView_InsertColumn (hwndLV, 0, &lvColumn) ;
		lvColumn.pszText	= TEXT ("�|�[�g�ԍ�") ;
		ListView_InsertColumn (hwndLV, 1, &lvColumn) ;
		
		pNode			= pArg->m_lstHost ;
		memset (&lvI, 0, sizeof (lvI)) ;
		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		n				= 0 ;
		while (pNode != NULL) {
			lvI.iItem	= n ;
			lvI.pszText	= pNode->m_strHost ;
			lvI.lParam	= (LPARAM) pNode ;
			nItem		= ListView_InsertItem (hwndLV, &lvI) ;
			if (nItem != -1) {
				wsprintf (szBuffer, TEXT ("%d"), pNode->m_nPort) ;
				ListView_SetItemText (hwndLV, nItem, 1, szBuffer) ;
			}
			pNode		= pNode->m_pNext ;
			n			++ ;
		}
	}

	CheckDlgButton (hDlg, IDC_CHECK_FILE_DICT_SORTEDP, (pArg->m_fSortedAuxJisyo)? BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_ENABLE_AUX_JISYO,  (pArg->m_fEnableAuxJisyo)? BST_CHECKED : BST_UNCHECKED) ;
	if (hwndAuxPath != NULL)
		EnableWindow (hwndAuxPath, pArg->m_fEnableAuxJisyo) ;
	hwndCheck	= GetDlgItem (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) ;
	if (hwndCheck != NULL)
		EnableWindow (hwndCheck, pArg->m_fEnableAuxJisyo) ;
	
	return	TRUE ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgEditServerJisyoOnCommand (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	WORD				wNotifyCode ;
	WORD				wID ;
	HWND				hwndCtl ;
	TDlgEditDictArg*	pArg ;

	pArg		= (TDlgEditDictArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	switch (wID) {
	case	IDC_BUTTON_ADD_NEW_JISYO_SERVER:
	case	IDC_BUTTON_MODIFY_JISYO_SERVER:
	case	IDC_BUTTON_REMOVE_JISYO_SERVER:
	{
		if (wNotifyCode == BN_CLICKED) {
			HWND	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SERVER_DICT) ;
			int	nItem ;

			if (hwndLV == NULL)
				break ;
			nItem	= ListView_GetSelectionMark (hwndLV) ;
			skkimeConfig_editServerJisyo (hDlg, nItem, wID) ;
			return	FALSE ;
		}
		break ;
	}
	case	IDC_CHECK_FILE_DICT_SORTEDP:
	{
		if (wNotifyCode == BN_CLICKED) {
			UINT	uCheck ;

			uCheck		= IsDlgButtonChecked (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) ;
			pArg->m_fSortedAuxJisyo	= (uCheck == BST_CHECKED)? TRUE : FALSE ;
			return	FALSE ;
		}
	}
	case	IDC_CHECK_ENABLE_AUX_JISYO:
	{
		if (wNotifyCode == BN_CLICKED) {
			UINT	uCheck ;
			BOOL	fEnable ;

			uCheck		= IsDlgButtonChecked (hDlg, IDC_CHECK_ENABLE_AUX_JISYO) ;
			fEnable		= (uCheck == BST_CHECKED)? TRUE : FALSE ;
			if (fEnable != pArg->m_fEnableAuxJisyo) {
				HWND	hwndCheck, hwndEdit ;

				hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
				hwndCheck	= GetDlgItem (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) ;
				if (hwndEdit != NULL)
					EnableWindow (hwndEdit,  fEnable) ;
				if (hwndCheck != NULL)
					EnableWindow (hwndCheck, fEnable) ;
				pArg->m_fEnableAuxJisyo	= fEnable ;
			}
			return	FALSE ;
		}
		break ;
	}
	case	IDC_BUTTON_BROWSE_FILE_DICT_PATH:
	{
		OPENFILENAME	ofn ;
		TCHAR			szPath [MAX_PATH + 1] ;

		if (wNotifyCode == BN_CLICKED) {
			lstrcpyn (szPath, pArg->m_strPath, MAX_PATH) ;
			szPath [MAX_PATH]	= TEXT ('\0') ;
			memset (&ofn, 0, sizeof (ofn)) ;
			ofn.lStructSize			= sizeof (OPENFILENAME) ;
			ofn.hwndOwner			= hDlg ;
			ofn.hInstance			= pArg->m_hInst ;
			ofn.lpstrFilter			= TEXT ("All\0*.*\0") ;
			ofn.lpstrCustomFilter	= NULL ;
			ofn.nFilterIndex		= 1 ;
			ofn.lpstrFile			= szPath ;
			ofn.nMaxFile			= MAX_PATH ;
			ofn.lpstrFileTitle		= NULL ;
			ofn.lpstrInitialDir		= TEXT ("") ;
			ofn.lpstrTitle			= TEXT ("�⏕�����̑I��") ;
			ofn.Flags				= OFN_HIDEREADONLY | OFN_LONGNAMES | OFN_NONETWORKBUTTON | OFN_PATHMUSTEXIST ;
			ofn.lpstrDefExt			= NULL ;
			ofn.lpfnHook			= NULL ;
			if (GetOpenFileName (&ofn) != 0) {
				lstrcpyn (pArg->m_strPath, szPath, MAX_PATH) ;
				pArg->m_strPath [MAX_PATH]	= TEXT ('\0') ;
				SetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, szPath) ;
			}
			return	FALSE ;
		}
		break ;
	}
	case	IDOK:
	case	IDCANCEL:
	{
		if (wID == IDOK) {
			if (pArg != NULL) {
				HWND	hwndAuxPath ;

				hwndAuxPath		= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
				pArg->m_strPath [0]	= TEXT ('\0') ;
				if (hwndAuxPath != NULL) 
					GetWindowText (hwndAuxPath, pArg->m_strPath, MAX_PATH) ;

				pArg->m_fSortedAuxJisyo	= (IsDlgButtonChecked (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) == BST_CHECKED)? TRUE : FALSE ;
				
				/*	host-port �̗�́c�����e�i���X����Ă���̂�
				 *	�����Ŕ����o���K�v�͂Ȃ��B*/
			} else {
				wID	= IDCANCEL ;
			}
		}
		if (wID == IDCANCEL) {
			skkimeConfig_deleteHostList (pArg->m_lstHost) ;
			pArg->m_lstHost	= NULL ;
		}
		EndDialog (hDlg, wID) ;
		return	FALSE ;
	}
	default:
		break ;
	}
	return	TRUE ;
	UNREFERENCED_PARAMETER (uMsg) ;
}

INT_PTR
skkimeConfig_dlgEditServerJisyoOnNotify (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;
	static TMYMENUITEM		rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ǉ�"), IDC_BUTTON_ADD_NEW_JISYO_SERVER, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ҏW"), IDC_BUTTON_MODIFY_JISYO_SERVER, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�폜"), IDC_BUTTON_REMOVE_JISYO_SERVER, },
	} ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_SERVER_DICT:
		if (pNMHDR->code == NM_RCLICK) {
			NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;
			int	n ;

			n	= skkimeConfig_PopupMenu (hDlg, rmi, NELEMENTS (rmi)) ;
			if (n > 0) 
				skkimeConfig_editServerJisyo (hDlg, pNM->iItem, n) ;
		}
		break ;
	default:
		break ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
skkimeConfig_editServerJisyo (
	HWND		hDlg,
	int		nItem,
	int		nCommand)
{
	TDlgEditDictArg*	pArg ;
	TDlgEditServerJisyoArg		arg ;
	HINSTANCE			hInst ;
	HWND				hwndLV ;
	LVITEM					lvI ;
	PORTANDHOSTNODE*	pNode ;
	int				nRetval ;
	TCHAR						szBuffer [32] ;

	pArg	= (TDlgEditDictArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;
	hInst	= pArg->m_hInst ;

	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SERVER_DICT) ;
	if (hwndLV == NULL)
		return	FALSE ;
	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM ;
	lvI.iItem		= nItem ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		pNode		= NULL ;
	} else {
		pNode		= (PORTANDHOSTNODE *)lvI.lParam ;
	}
	switch (nCommand) {
	case	IDC_BUTTON_ADD_NEW_JISYO_SERVER:
	case	IDC_BUTTON_MODIFY_JISYO_SERVER:
	{
		PORTANDHOSTNODE*	pNewNode ;
		int				nHostname ;
		
		arg.m_strHost [0]	= TEXT ('\0') ;
		arg.m_nPort			= 1178 ;
		if (pNode != NULL) {
			if (pNode->m_strHost != NULL)
				lstrcpyn (arg.m_strHost, pNode->m_strHost, MAX_PATH) ;
			arg.m_nPort	= pNode->m_nPort ;
		}
		nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_JISYOSERVER), hDlg, skkimeConfig_dlgEditJisyoServer, (LPARAM)&arg) ;
		if (nRetval != IDOK)
			return	TRUE ;
		nHostname	= lstrlen (arg.m_strHost) ;
		if (arg.m_nPort <= 0 || nHostname <= 0)
			return	FALSE ;
		pNewNode	= skkimeConfig_newPortAndHostNode (arg.m_strHost, nHostname, arg.m_nPort) ;
		if (pNewNode == NULL) {
			DEBUGPRINTF ((TEXT ("out of memory.\n"))) ;
			return	FALSE ;	// out of memory
		}
		skkimeConfig_registerPortAndHostNode   (pNewNode, &pArg->m_lstHost, pNode) ;
		skkimeConfig_unregisterPortAndHostNode (pNode, &pArg->m_lstHost) ;

		memset (&lvI, 0, sizeof (lvI)) ;
		lvI.mask		= LVIF_PARAM | LVIF_STATE ;
		lvI.lParam		= (LPARAM) pNewNode ;
		if (pNode != NULL) {
			lvI.iItem	= nItem ;
			ListView_SetItem (hwndLV, &lvI) ;
			FREE (pNode) ;
		} else {
			nItem		= ListView_InsertItem (hwndLV, &lvI) ;
		}
		ListView_SetItemText (hwndLV, nItem, 0, pNewNode->m_strHost) ;
		wsprintf (szBuffer, TEXT("%d"), pNewNode->m_nPort) ;
		ListView_SetItemText (hwndLV, nItem, 1, szBuffer) ;
		return	TRUE ;
	}
	case	IDC_BUTTON_REMOVE_JISYO_SERVER:
	{
		if (pNode == NULL)
			return	FALSE ;
		ListView_DeleteItem (hwndLV, nItem) ;
		skkimeConfig_unregisterPortAndHostNode (pNode, &pArg->m_lstHost) ;
		return	TRUE ;
	}
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

INT_PTR CALLBACK
skkimeConfig_dlgEditJisyoServer (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	TDlgEditServerJisyoArg*	pArg ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		HWND	hwndEditHost, hwndEditPort ;
		TCHAR			szBuffer [32] ;

		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
		pArg			= (TDlgEditServerJisyoArg*) lParam ;
		hwndEditHost	= GetDlgItem (hDlg, IDC_EDIT_HOSTNAME) ;
		hwndEditPort	= GetDlgItem (hDlg, IDC_EDIT_PORTNUM) ;
		if (pArg == NULL || hwndEditHost == NULL || hwndEditPort == NULL)
			break ;
		SendMessage   (hwndEditHost, EM_LIMITTEXT, (WPARAM) MAX_PATH, 0) ;
		SetWindowText (hwndEditHost, pArg->m_strHost) ;
		SendMessage   (hwndEditPort, EM_LIMITTEXT, (WPARAM) 32, 0) ;
		wsprintf (szBuffer, TEXT ("%d"), pArg->m_nPort) ;
		SetWindowText (hwndEditPort, szBuffer) ;
		return	TRUE ;
	}
	case	WM_COMMAND:
		switch (LOWORD (wParam)) {
		case	IDOK:
			pArg			= (TDlgEditServerJisyoArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				BOOL	fSuccess ;
				UINT	uVal ;

				GetDlgItemText (hDlg, IDC_EDIT_HOSTNAME, pArg->m_strHost, MAX_PATH) ;
				uVal	= GetDlgItemInt  (hDlg, IDC_EDIT_PORTNUM,  &fSuccess, TRUE) ;
				if (fSuccess)
					pArg->m_nPort	= (int)uVal ;
			} else {
				wParam	= IDCANCEL ;
			}
			/*	fall through */
		case	IDCANCEL:
			EndDialog (hDlg, wParam) ;
			return	TRUE ;
		default:
			break ;
		}
		break ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgEditFileJisyo (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	TDlgEditDictArg*	pArg ;
	HWND	hwndEditPath ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		UINT	uCheck ;

		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
		pArg			= (TDlgEditDictArg*) lParam ;
		hwndEditPath	= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
		if (pArg == NULL || hwndEditPath == NULL)
			break ;
		SendMessage   (hwndEditPath, EM_LIMITTEXT, (WPARAM) MAX_PATH, 0) ;
		SetWindowText (hwndEditPath, pArg->m_strPath) ;
		uCheck	= (pArg->m_nType == DICTYPE_SORT)? BST_CHECKED : BST_UNCHECKED ;
		CheckDlgButton (hDlg, IDC_CHECK_FILE_DICT_SORTEDP, uCheck) ;
		return	TRUE ;
	}
	case	WM_COMMAND:
	{
		WORD	wNotifyCode	= HIWORD (wParam) ;
		WORD	wID			= LOWORD (wParam) ;
		/*HWND	hwndCtl		= (HWND) lParam ;*/

		switch (wID) {
		case	IDC_BUTTON_BROWSE_FILE_DICT_PATH:
		{
			OPENFILENAME	ofn ;
			TCHAR			szPath [MAX_PATH + 1] ;

			pArg	= (TDlgEditDictArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg == NULL)
				break ;

			if (wNotifyCode == BN_CLICKED) {
				GetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, szPath, MAX_PATH) ;
				szPath [MAX_PATH]	= TEXT ('\0') ;
				memset (&ofn, 0, sizeof (ofn)) ;
				ofn.lStructSize			= sizeof (OPENFILENAME) ;
				ofn.hwndOwner			= hDlg ;
				ofn.hInstance			= pArg->m_hInst ;
				ofn.lpstrFilter			= TEXT ("All\0*.*\0") ;
				ofn.lpstrCustomFilter	= NULL ;
				ofn.nFilterIndex		= 1 ;
				ofn.lpstrFile			= szPath ;
				ofn.nMaxFile			= MAX_PATH ;
				ofn.lpstrFileTitle		= NULL ;
				ofn.lpstrInitialDir		= TEXT ("") ;
				ofn.lpstrTitle			= TEXT ("�����t�@�C���̑I��") ;
				ofn.Flags				= OFN_HIDEREADONLY | OFN_LONGNAMES | OFN_NONETWORKBUTTON | OFN_PATHMUSTEXIST ;
				ofn.lpstrDefExt			= NULL ;
				ofn.lpfnHook			= NULL ;
				if (GetOpenFileName (&ofn) != 0) 
					SetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, szPath) ;
			}
			break ;
		}
		case	IDOK:
		{
			pArg			= (TDlgEditDictArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				if (IsDlgButtonChecked (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) == BST_CHECKED) {
					pArg->m_nType	= DICTYPE_SORT ;
				} else {
					pArg->m_nType	= DICTYPE_FILE ;
				}
				GetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, pArg->m_strPath, MAX_PATH) ;
			} else {
				wParam	= IDCANCEL ;
			}
		}
		/*	fall through */
		case	IDCANCEL:
			EndDialog (hDlg, wParam) ;
			return	TRUE ;
		default:
			break ;
		}
		break ;
	}
	default:
		break ;
	}
	return	FALSE ;
}

BOOL
skkimeConfig_setDictionaryItemText (
	HWND		hwndLV,
	int			nItem,
	DICTNODE*	pNode)
{
	static LPTSTR	rpszDicType []	= {
		TEXT ("���[�U����"),	TEXT ("�T�[�o����"),
		TEXT ("�t�@�C������"),	TEXT ("�\�[�g�σt�@�C������"),
	} ;
	TCHAR			rszBuffer [256] ;
	LPTSTR	strArg ;
				
	if (hwndLV == NULL || nItem < 0 || pNode == NULL)
		return	FALSE ;

	switch (pNode->m_nType) {
	case	DICTYPE_SERVER:
		skkimeConfig_hostlist2string (rszBuffer, NELEMENTS (rszBuffer), pNode->m_lstHost) ;
		strArg	= rszBuffer ;
		break ;
	case	DICTYPE_FILE:
	case	DICTYPE_SORT:
		strArg	= pNode->m_strPath ;
		break ;
	case	DICTYPE_USER:
		strArg	= TEXT ("") ;
		break ;
	default:
		return	FALSE ;
	}
	ListView_SetItemText (hwndLV, nItem, 0, rpszDicType [pNode->m_nType]) ;
	ListView_SetItemText (hwndLV, nItem, 1, strArg) ;
	return	TRUE ;
}

PORTANDHOSTNODE*
skkimeConfig_copyPortAndHostList (
	PORTANDHOSTNODE*	lstHost)
{
	PORTANDHOSTNODE*	pTopNode ;
	PORTANDHOSTNODE*	pLastNode ;
	PORTANDHOSTNODE*	pNode ;
	PORTANDHOSTNODE*	pOrg ;
	int				nHostnameLen ;

	pLastNode	= NULL ;
	pOrg		= lstHost ;
	while (pOrg != NULL) {
		nHostnameLen	= lstrlen (pOrg->m_strHost) ;
		pNode	= MALLOC (sizeof (PORTANDHOSTNODE) + sizeof (TCHAR) * (nHostnameLen + 1)) ;
		if (pNode == NULL)
			break ;
		pNode->m_strHost	= (LPTSTR)(pNode + 1) ;
		lstrcpy (pNode->m_strHost, pOrg->m_strHost) ;
		pNode->m_nPort		= pOrg->m_nPort ;
		pNode->m_pNext		= NULL ;
		pNode->m_pPrev		= pLastNode ;
		if (pLastNode != NULL)
			pLastNode->m_pNext	= pNode ;
		pLastNode			= pNode ;
		pOrg				= pOrg->m_pNext ;
	}
	if (pLastNode != NULL) {
		PORTANDHOSTNODE*	pPrevNode ;

		pNode	= pLastNode ;
		while (pPrevNode = pNode->m_pPrev, pPrevNode != NULL)
			pNode	= pPrevNode ;
		pTopNode	= pNode ;
	} else {
		pTopNode	= NULL ;
	}
	return	pTopNode ;
}



BOOL
skkimeConfig_initSearchJisyoList (
	LPCTSTR			pstrSubKey,
	DICTNODE**		plstSearchJisyo,
	LPTSTR			strUserJisyoPath)
{
	HKEY				hSubKey ;
	TCHAR				szRegPathInfo [MAX_PATH + 1] ;
	TCHAR				rbyData [MAX_REGVALUE_SIZE] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	DICTNODE*	pNode ;

	*plstSearchJisyo	= NULL ;

	/*	���W�X�g������ݒ��ǂށB*/
	if (RegOpenKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		int	nIndex ;
		int				nDict ;
		LONG	lResult ;

		for (nIndex = 0 ; nIndex < INT_MAX ; nIndex ++) {
			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= NELEMENTS (rbyData) ;
			lResult	= RegEnumValue (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			if (skkimeConfig_parseDictNumber (szRegPathInfo, &nDict)) {
				/*	nDict �����������ԍ��B*/
				lResult	= RegQueryValueEx (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
				if (lResult != ERROR_SUCCESS || dwType != REG_SZ)
					continue ;
				/*	Too big value. */
				if (cbData >= sizeof (rbyData))
					continue ;
				cbData	= sizeof (rbyData) ;
				(void) RegQueryValueEx (hSubKey, szRegPathInfo, NULL, NULL, (BYTE *)rbyData, &cbData) ;

				pNode	= skkimeConfig_parseDictionarySetting (rbyData, nDict) ;
				if (pNode != NULL) 
					skkimeConfig_insertDictionaryInSearchList (plstSearchJisyo, pNode) ;
			}
		}
		lResult	= RegQueryValueEx (hSubKey, REGKEY_USERJISYO, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS ||
			(dwType != REG_SZ && dwType != REG_EXPAND_SZ) ||
			cbData > sizeof (TCHAR) * MAX_PATH) {
			lstrcpy (strUserJisyoPath, SKKIME_DEFAULT_USERJISYOPATH) ;
		} else {
			cbData	= MAX_PATH ;
			RegQueryValueEx (hSubKey, REGKEY_USERJISYO, NULL, &dwType, (BYTE *)strUserJisyoPath, &cbData) ;
			strUserJisyoPath [MAX_PATH]	= TEXT ('\0') ;
		}
		RegCloseKey (hSubKey) ;
		return	TRUE ;
	}

	/*	�f�t�H���g�̐ݒ������B
	 *	�f�t�H���g�̐ݒ�ł́A���[�U�����̌������擪�ɂ��邾���H
	 */
	pNode	= skkimeConfig_parseDictionarySetting (SKKIME_DEFAULT_JISYO_SETTING, 0) ;
	if (pNode == NULL)
		return	FALSE ;
	skkimeConfig_insertDictionaryInSearchList (plstSearchJisyo, pNode) ;

	/*	���[�U�����̃p�X�̓f�t�H���g�́A
	 *		%USERPROFILE%\Application Data\skk\skki1_0\skki1_0u.dic
	 *	�ł���B
	 */
	lstrcpy (strUserJisyoPath, SKKIME_DEFAULT_USERJISYOPATH) ;
	return	TRUE ;
}

BOOL
skkimeConfig_updateSearchJisyoList (
	LPCTSTR			pstrSubKey,
	DICTNODE*		lstSearchJisyo,
	LPTSTR			strUserJisyoPath)
{
	TCHAR		rbufTemp [MAX_PATH + 1] ;
	TCHAR		szData [MAX_REGVALUE_SIZE] ;
	HKEY		hSubKey ;
	BOOL		fRetval	= TRUE ;
	DICTNODE*	pNode ;
	int			nLength, nDest, nDict ;
	LPCTSTR		strFormat ;
	LPTSTR		pDest ;
	PORTANDHOSTNODE*	pHostPortNode ;

	if (! skkimeConfig_CreateKey (pstrSubKey, TRUE, &hSubKey)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_updateSearchJisyoList: create-key failed(\"%s\")\n"), pstrSubKey)) ;
		return	FALSE ;
	}

	pNode	= lstSearchJisyo ;
	nDict	= 0 ;
	while (pNode != NULL) {
		pDest	= szData ;
		nDest	= NELEMENTS (szData) ;
		switch (pNode->m_nType) {
		case	DICTYPE_USER:
			lstrcpy (pDest, TEXT ("user=")) ;
			pDest	+= 6 ;	/* lstrlen ("user=") == 6 */
			nDest	-= 6 ;
			break ;
		case	DICTYPE_SERVER:
			lstrcpy (pDest, TEXT ("server=")) ;
			pDest	+= 7 ;	/* lstrlen ("server=") == 7 */
			nDest	-= 7 ;
			pHostPortNode	= pNode->m_lstHost ;
			strFormat		= TEXT ("%d/%s") ;
			while (pHostPortNode != NULL) {
				if (pHostPortNode->m_nPort >= 0 &&
					pHostPortNode->m_strHost != NULL &&
					lstrlen (pHostPortNode->m_strHost) < (MAX_PATH - 16)) {
					wsprintf (rbufTemp, strFormat, pHostPortNode->m_nPort, pHostPortNode->m_strHost) ;
					nLength	= lstrlen (rbufTemp) ;
					if (nDest > nLength) {
						lstrcpy (pDest, rbufTemp) ;
						pDest		+= nLength ;
						nDest		-= nLength ;
						strFormat	= TEXT (",%d/%s") ;
					} else {
						DEBUGPRINTF ((TEXT ("Too many (port/host)s\n"))) ;
						/* ����ȏ�ۑ��ł��Ȃ��Ǝv���Ə����𔲂���B*/
						break ;
					}
				}
				pHostPortNode	= pHostPortNode->m_pNext ;
			}
			/*	�⏕�����̐ݒ�͂��邩�H */
			if (pNode->m_strPath != NULL && pNode->m_strPath [0] != TEXT ('\0')) {
				nLength	= lstrlen (pNode->m_strPath) ;
				if (nDest > (nLength + 8)) {	/* lstrlen (",aux:??=") == 8 */
					lstrcpy (pDest, TEXT (",aux:")) ;
					pDest	+= 5 ;
					*pDest	++ = (TCHAR)((pNode->m_fSortedAuxJisyo)? TEXT ('s') : TEXT ('f')) ;
					*pDest	++ = (TCHAR)((pNode->m_fEnableAuxJisyo)? TEXT ('e') : TEXT ('d')) ;
					*pDest	++ = TEXT ('=') ;
					nDest	-= 8 ;
					lstrcpy (pDest, pNode->m_strPath) ;
					pDest	+= nLength ;
					nDest	-= nLength ;
				}
			}
			break ;
		case	DICTYPE_SORT:
			lstrcpy (pDest, TEXT ("sort=")) ;
			goto	dictype_file_common ;
		case	DICTYPE_FILE:
			lstrcpy (pDest, TEXT ("file=")) ;
		dictype_file_common:
			pDest	+= 5 ;	/* lstrlen ("sort=") == 5 && lstrlen ("file=") == 5 */
			nDest	-= 5 ;
			nLength	= lstrlen (pNode->m_strPath) ;
			if ((nLength + (pDest - szData) + 1) >= MAX_REGVALUE_SIZE) {
				DEBUGPRINTF ((TEXT ("Too long dictionary path (%s).\n"), pNode->m_strPath)) ;
				goto	skip ;
			}
			lstrcpy (pDest, pNode->m_strPath) ;
			pDest	+= nLength ;
			nDest	-= nLength ;
			break ;
		default:
			DEBUGPRINTF ((TEXT ("Invalid dictionary type.\n"))) ;
			goto	skip ;
		}
		wsprintf (rbufTemp, TEXT ("Dict%d"), nDict) ;
		if (RegSetValueEx (hSubKey, rbufTemp, 0, REG_SZ, (BYTE *)szData, sizeof (TCHAR) * ((pDest - szData) + 1)) != ERROR_SUCCESS) {
			DEBUGPRINTF ((TEXT ("RegSetValueEx: failed (\"%s\", \"%s\")\n"), rbufTemp, szData)) ;
			fRetval	= FALSE ;
		} else {
			DEBUGPRINTF ((TEXT ("RegSetValueEx: \"%s\" <= \"%s\")\n"), rbufTemp, szData)) ;
			fRetval	= TRUE ;
		}
		nDict	++ ;
	skip:
		pNode	= pNode->m_pNext ;
	}

	nLength	= lstrlen (strUserJisyoPath) ;
	if (nLength > 0) {
		if (RegSetValueEx (hSubKey, REGKEY_USERJISYO, 0, REG_SZ, (BYTE *)strUserJisyoPath, sizeof (TCHAR) * (nLength + 1)) != ERROR_SUCCESS) {
			DEBUGPRINTF ((TEXT ("RegSetValueEx: failed (\"%s\")\n"), strUserJisyoPath)) ;
			fRetval	= FALSE ;
		}
	}
	RegCloseKey (hSubKey) ;
	return	fRetval ;
}

BOOL
skkimeConfig_parseDictNumber (
	LPCTSTR			pstrString,
	int*			pnDict)
{
	int	nValue ;

	if (_tcsncmp (pstrString, TEXT ("Dict"), 4))
		return	FALSE ;

	pstrString	+= 4 ;
	if (*pstrString == TEXT ('\0'))
		return	FALSE ;

	nValue	= 0 ;
	while (*pstrString != TEXT ('\0')) {
		if (! (TEXT ('0') <= *pstrString && *pstrString <= TEXT ('9')))
			return	FALSE ;
		nValue	= nValue * 10 + (*pstrString - TEXT ('0')) ;
		if (nValue < 0)
			return	FALSE ;
		pstrString	++ ;
	}
	*pnDict	= nValue ;
	return	TRUE ;
}

/*	�����̐ݒ蕶����͎��̒ʂ�ł���F
 *		�T�[�o�����̏ꍇ�Aserver=port1/host1,port2/host2,aux=aux-dictionarypath
 *		(����͍Ō�̗v�f)
 *		���[�U�����̏ꍇ�Auser=(�����͂Ȃ�)
 *		���̑������t�@�C���Afile=path
 *
 *	aux:??= �Ɖ��ρBaux:s �� sort ����Ă���Baux:f �ł����� file�Baux:e �� enable �ŁA
 *	aux:d �� disable�B�g�ݍ��킹�ł́A
 *		(s or f) and (e or d) �ɂȂ�B
 *	aux:se �Ƃ� aux:fe �Ƃ� aux:sd �Ƃ� aux:fd �Ƃ��B
 */
DICTNODE*
skkimeConfig_parseDictionarySetting (
	LPCTSTR		pstrSetting,
	int			nIndex)
{
	DICTNODE*	pNode	= NULL ;

	if (! _tcsncmp (pstrSetting, TEXT ("server="), 7)) {
		LPCTSTR	ptr	;
		LPCTSTR	pStart ;
		LPCTSTR	pAuxPath	= NULL ;
		int		nServer ;
		PORTANDHOSTNODE*	pHostPortNode ;
		PORTANDHOSTNODE*	plstHostPort	= NULL ;
		BOOL		fEnableAuxJisyo	= FALSE ;
		BOOL		fSortedAuxJisyo	= FALSE ;

		nServer	= 0 ;
		pStart	= pstrSetting + 7 ;
		while (*pStart != TEXT ('\0')) {
			ptr		= pStart ;
			while (*ptr != TEXT ('\0') && *ptr != TEXT (',')) 
				ptr	++ ;
			/*	�⏕�����̐ݒ肪���t�������ꍇ�A����ɑ����T�[�o��
			 *	�ݒ�͑��݂��Ȃ��B*/
			if (! _tcsncmp (pStart, TEXT ("aux:"), 4)) {
				pStart		+= 4 ;
				if (*pStart == TEXT('s') || *pStart == TEXT('f')) {
					fSortedAuxJisyo	= (*pStart == TEXT('s'))? TRUE : FALSE ;
					pStart	++ ;
				}
				if (*pStart == TEXT('e') || *pStart == TEXT('d')) {
					fEnableAuxJisyo	= (*pStart == TEXT ('e'))? TRUE : FALSE ;
					pStart	++ ;
				}
				/*	���̏ꍇ�ɂ̓G���[�B����̓V�r�A�B*/
				if (*pStart == TEXT('=')) {
					pAuxPath	= pStart + 1 ;
				} else {
					pAuxPath	= NULL ;
				}
				break ;
			}
			/*	port/host �̃T�[�o�̐ݒ�𔲂��o���B*/
			pHostPortNode	= skkimeConfig_parsePortAndHost (pStart, ptr - pStart) ;
			if (pHostPortNode != NULL) {
				pHostPortNode->m_pNext	= plstHostPort ;
				if (plstHostPort != NULL)
					plstHostPort->m_pPrev	= pHostPortNode ;
				plstHostPort			= pHostPortNode ;
			}
			if (*ptr == TEXT ('\0'))
				break ;
			pStart	= ptr + 1 ;
		}
		pNode	= skkimeConfig_newDictionaryNode (DICTYPE_SERVER, pAuxPath) ;
		pNode->m_fEnableAuxJisyo	= fEnableAuxJisyo ;
		pNode->m_fSortedAuxJisyo	= fSortedAuxJisyo ;
		pNode->m_lstHost			= plstHostPort ;
	} else if (! _tcsncmp (pstrSetting, TEXT ("user="), 5)) {
		pNode	= skkimeConfig_newDictionaryNode (DICTYPE_USER, NULL) ;
	} else if (! _tcsncmp (pstrSetting, TEXT ("file="), 5) ||
			   ! _tcsncmp (pstrSetting, TEXT ("sort="), 5)) {
		int	nType ;

		nType	= _tcsncmp (pstrSetting, TEXT ("sort="), 5) ? DICTYPE_FILE : DICTYPE_SORT ;
		pstrSetting	+= 5 ;
		if (*pstrSetting == TEXT ('\0'))
			return	NULL ;
		pNode	= skkimeConfig_newDictionaryNode (nType, pstrSetting) ;
	}
	if (pNode != NULL) {
		pNode->m_nIndex		= nIndex ;
		pNode->m_pNext		= NULL ;
		pNode->m_pPrev		= NULL ;
	}
	return	pNode ;
}	

PORTANDHOSTNODE*
skkimeConfig_parsePortAndHost (
	LPCTSTR		pstrPortAndHost,
	int			nPortAndHost)
{
	LPCTSTR	ptr		= pstrPortAndHost ;
	int		nPort	= 0 ;
	LPCTSTR	pHostname ;
	int		nHostnameLen ;

	if (*ptr != TEXT ('/')) {
		while (nPortAndHost > 0 && *ptr != TEXT ('/')) {
			if (! (TEXT ('0') <= *ptr && *ptr <= TEXT ('9')))
				return	NULL ;
			nPort	= nPort * 10 + (*ptr - TEXT ('0')) ;
			ptr				++ ;
			nPortAndHost	-- ;
		}
		if (nPort < 0 || nPort >= 65536)
			return	NULL ;
	} else {
		nPort	= SKKSERV_DEFAULT_PORTNUM ;
	}
	if (nPortAndHost <= 0 || *ptr != TEXT ('/'))
		return	NULL ;

	/*	"/" ��ǂݔ�΂��B*/
	nPortAndHost	-- ;
	ptr				++ ;

	nHostnameLen	= nPortAndHost ;
	pHostname		= ptr ;
	if (nHostnameLen <= 0)
		return	NULL ;

	/*	�ȉ��A�S�āA�ƌ��������Ƃ��낾���Ahostname �Ƃ��ĕs�K�؂ȕ���
	 *	������Ύ̂Ă����Ă��炤�B�^�ʖڂȃp�[�Y�͂��Ȃ��B
	 *	host part �ɗ��p�\�ȕ����� HTTP-URL �� RFC ���Q�l�ɂ��Ă���B*/
	while (nPortAndHost > 0 &&
		   ((TEXT ('0') <= *ptr && *ptr <= TEXT ('9')) ||
			(TEXT ('a') <= *ptr && *ptr <= TEXT ('z')) ||
			(TEXT ('A') <= *ptr && *ptr <= TEXT ('Z')) ||
			*ptr == TEXT ('-') ||
			*ptr == TEXT ('.'))) {
		ptr				++ ;
		nPortAndHost	-- ;
	}
	if (nPortAndHost != 0)
		return	NULL ;
	
	return	skkimeConfig_newPortAndHostNode (pHostname, nHostnameLen, nPort) ;
}

BOOL
skkimeConfig_insertDictionaryInSearchList (
	DICTNODE**	plstTop,
	DICTNODE*	pNewNode)
{
	DICTNODE*	pNode ;
	DICTNODE*	pPrevNode ;

	pNode		= *plstTop ;
	pPrevNode	= NULL ;
	while (pNode != NULL && pNode->m_nIndex < pNewNode->m_nIndex) {
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
	}
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext	= pNewNode ;
	} else {
		*plstTop			= pNewNode ;
	}
	pNewNode->m_pPrev	= pPrevNode ;
	pNewNode->m_pNext	= pNode ;
	if (pNode != NULL) 
		pNode->m_pPrev	= pNewNode ;
	return	TRUE ;
}

DICTNODE*
skkimeConfig_newDictionaryNode (
	int			nType,
	LPCTSTR		strPath)
{
	DICTNODE*	pNode ;
	int			nLength ;

	/*	MAX_PATH �ȏ�� PATH �̑��݂͋����Ȃ��B*/
	nLength	= (strPath != NULL)? (lstrlen (strPath) + 1) : 0 ;
	if (nLength > MAX_PATH)
		return	NULL ;
	pNode	= MALLOC (sizeof (DICTNODE) + sizeof (TCHAR) * nLength) ;
	if (strPath != NULL) {
		pNode->m_strPath	= (LPTSTR)(pNode + 1) ;
		lstrcpy (pNode->m_strPath, strPath) ;
	} else {
		pNode->m_strPath	= NULL ;
	}
	pNode->m_nIndex		= 0 ;
	pNode->m_pPrev		= NULL ;
	pNode->m_pNext		= NULL ;
	pNode->m_lstHost	= NULL ;
	pNode->m_nType		= nType ;
	return	pNode ;
}

BOOL
skkimeConfig_registerDictionaryNode (
	DICTNODE**		plstTop,
	DICTNODE*		pNode,
	DICTNODE*		pPrevNode)
{
	DICTNODE*	pNextNode ;

	if (pNode == NULL || plstTop == NULL)
		return	FALSE ;

	if (pPrevNode == NULL) {
		pNextNode				= *plstTop ;
		pNode->m_pNext			= pNextNode ;
		*plstTop				= pNode ;
		pNode->m_pPrev			= NULL ;
	} else {
		pNextNode				= pPrevNode->m_pNext ;
		pPrevNode->m_pNext		= pNode ;
		pNode->m_pNext			= pNextNode ;
		pNode->m_pPrev			= pPrevNode ;
	}
	if (pNextNode != NULL)
		pNextNode->m_pPrev		= pNode ;
	return	TRUE ;
}

BOOL
skkimeConfig_unregisterDictionaryNode (
	DICTNODE**		plstTop,
	DICTNODE*		pNode)
{
	DICTNODE*	pPrevNode ;
	DICTNODE*	pNextNode ;

	if (pNode == NULL || plstTop == NULL)
		return	FALSE ;
	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext		= pNextNode ;
	} else {
		// pNode == slstSkkinputSearchJisyo
		*plstTop				= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev		= pPrevNode ;
	}
	return	TRUE ;
}

void
skkimeConfig_deleteDictionaryNode (
	DICTNODE*		pNode)
{
	if (pNode == NULL)
		return ;
	if (pNode->m_lstHost != NULL) {
		skkimeConfig_deleteHostList (pNode->m_lstHost) ;
		pNode->m_lstHost	= NULL ;
	}
	FREE (pNode) ;
	return ;
}

void
skkimeConfig_deleteHostList (
	PORTANDHOSTNODE*	lstHost)
{
	PORTANDHOSTNODE*	pNode ;
	PORTANDHOSTNODE*	pNextNode ;

	pNode	= lstHost ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		FREE (pNode) ;
		pNode		= pNextNode ;
	}
	return ;
}

PORTANDHOSTNODE*
skkimeConfig_newPortAndHostNode (
	LPCTSTR		strHost,
	int			nHost,
	int			nPort)
{
	PORTANDHOSTNODE*	pNode ;

	pNode	= MALLOC (sizeof (PORTANDHOSTNODE) + sizeof (TCHAR) * (nHost + 1)) ;
	if (pNode == NULL)
		return	NULL ;
	pNode->m_pPrev		= NULL ;
	pNode->m_pNext		= NULL ;
	pNode->m_strHost	= (LPTSTR)(pNode + 1) ;
	pNode->m_nPort		= nPort ;
	memcpy (pNode->m_strHost, strHost, sizeof (TCHAR) * nHost) ;
	*(pNode->m_strHost + nHost)	= TEXT ('\0') ;
	return	pNode ;
}

BOOL
skkimeConfig_registerPortAndHostNode (
	PORTANDHOSTNODE*	pNode,
	PORTANDHOSTNODE**	plstPortAndHost,
	PORTANDHOSTNODE*	pPrevNode)
{
	PORTANDHOSTNODE*	pNextNode ;

	if (pNode == NULL || plstPortAndHost == NULL)
		return	FALSE ;
	if (pPrevNode == NULL) {
		pNextNode			= *plstPortAndHost ;
		*plstPortAndHost	= pNode ;
	} else {
		pNextNode			= pPrevNode->m_pNext ;
		pPrevNode->m_pNext	= pNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pNode ;
	}
	pNode->m_pPrev			= pPrevNode ;
	pNode->m_pNext			= pNextNode ;
	return	TRUE ;
}

BOOL
skkimeConfig_unregisterPortAndHostNode (
	PORTANDHOSTNODE*	pNode,
	PORTANDHOSTNODE**	plstPortAndHost)
{
	PORTANDHOSTNODE*	pPrevNode ;
	PORTANDHOSTNODE*	pNextNode ;

	if (pNode == NULL || plstPortAndHost == NULL)
		return	FALSE ;
	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode == NULL) {
		*plstPortAndHost	= pNextNode ;
	} else {
		pPrevNode->m_pNext	= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pPrevNode ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_hostlist2string (
	LPTSTR			pDest,
	int				nDest,
	PORTANDHOSTNODE*	plstHost)
{
	PORTANDHOSTNODE*	pNode ;
	LPCTSTR	pszFmt ;
	TCHAR				szBuffer [256] ;
	int		nLength ;

	pNode	= plstHost ;
	pszFmt	= TEXT ("%s/%d") ;
	while (pNode != NULL) {
		/*	32bit integer �� 10 �i�ŕ\��������10��������Α��v�H
		 *	16bit -> 65536 < 70000, 70000^2 = 4900000000 -> 10���B�}�C�i�X��
		 *	�\�������� 11�����B
		 *	3 �� " ,/" ��3�����B
		 */
		if (lstrlen (pNode->m_strHost) < (256 - 11 - 3) &&
			pNode->m_nPort >= 0) {
			wsprintf (szBuffer, pszFmt, pNode->m_strHost, pNode->m_nPort) ;
			nLength	= lstrlen (szBuffer) ;
			if (nDest < nLength) {
				memcpy (pDest, szBuffer, sizeof (TCHAR) * nLength) ;
				pDest	+= nLength ;
				nDest	-= nLength ;
				*pDest	= TEXT ('\0') ;
				pszFmt	= TEXT (", %s/%d") ;
			} else {
				memcpy (pDest, szBuffer, sizeof (TCHAR) * (nDest - 1)) ;
				*(pDest + nDest - 1)	= TEXT ('\0') ;
				break ;
			}
		}
		pNode	= pNode->m_pNext ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_dlgDictionaryMoveSelectedNode (
	HWND				hDlg,
	SkkimeConfigArg*	pConfArg,
	BOOL				fPrev)
{
	HWND			hwndLV ;
	DICTNODE**		plstJisyo ;
	DICTNODE*		pMoveNode ;
	LVITEM			lvI ;
	int				nItem ;
	LVFINDINFO		lvfI ;

	hwndLV			= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
	if (hwndLV == NULL)
		return	FALSE ;
	
	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM ;
	nItem			= ListView_GetSelectionMark (hwndLV) ;
	lvI.iItem		= nItem ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		DebugPrintf (TEXT ("ListView_GetItem failed (item:%d)\n"), nItem) ;
		return	FALSE ;
	}

	pMoveNode	= (DICTNODE*) lvI.lParam ;
	if (pMoveNode == NULL) {
		return	FALSE ;
	}

	memset (&lvfI, 0, sizeof (lvfI)) ;
	lvfI.flags		= LVFI_PARAM ;
	if (fPrev) {
		if (pMoveNode->m_pPrev != NULL) {
			DICTNODE*	pPrevNode	= pMoveNode->m_pPrev ;
			int		nPrevItem ;
			
			lvfI.lParam		= (LPARAM) pPrevNode ;
			nPrevItem		= ListView_FindItem (hwndLV, -1, &lvfI) ;
			if (nPrevItem >= 0) {
				plstJisyo	= &pConfArg->m_lstSearchJisyo ;
				skkimeConfig_unregisterDictionaryNode (plstJisyo, pMoveNode) ;
				skkimeConfig_registerDictionaryNode   (plstJisyo, pMoveNode, pPrevNode->m_pPrev) ;
				
				ListView_DeleteItem (hwndLV, nItem) ;
				memset (&lvI, 0, sizeof (lvI)) ;
				lvI.mask		= LVIF_PARAM ;
				lvI.iItem		= nPrevItem ;
				lvI.lParam		= (LPARAM) pMoveNode ;
				nItem			= ListView_InsertItem (hwndLV, &lvI) ;
				skkimeConfig_setDictionaryItemText (hwndLV, nItem, pMoveNode) ;
				ListView_SetSelectionMark (hwndLV, nItem) ;
				ListView_SetItemState (hwndLV, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
			}
		}
	} else {
		if (pMoveNode->m_pNext != NULL) {
			DICTNODE*	pNextNode	= pMoveNode->m_pNext ;
			int			nNextItem ;

			lvfI.lParam		= (LPARAM) pNextNode ;
			nNextItem		= ListView_FindItem (hwndLV, -1, &lvfI) ;
			if (nNextItem >= 0) {
				plstJisyo	= &pConfArg->m_lstSearchJisyo ;
				skkimeConfig_unregisterDictionaryNode (plstJisyo, pMoveNode) ;
				skkimeConfig_registerDictionaryNode   (plstJisyo, pMoveNode, pNextNode) ;
				
				ListView_DeleteItem (hwndLV, nItem) ;
				memset (&lvI, 0, sizeof (lvI)) ;
				lvI.mask		= LVIF_PARAM ;
				lvI.iItem		= nNextItem ;
				lvI.lParam		= (LPARAM) pMoveNode ;
				nItem			= ListView_InsertItem (hwndLV, &lvI) ;
				skkimeConfig_setDictionaryItemText (hwndLV, nItem, pMoveNode) ;
				ListView_SetSelectionMark (hwndLV, nItem) ;
				ListView_SetItemState (hwndLV, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
			}
		}
	}
	return	TRUE ;
}

