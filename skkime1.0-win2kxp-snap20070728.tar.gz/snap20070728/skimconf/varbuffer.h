#if !defined (varbuffer_h)
#define varbuffer_h

typedef struct tagTVarbuffer {
	BYTE		_rbyInternal [256] ;
	void*		_pBuffer ;
	int			_nWidth ;
	int			_nSize ;
	int			_nUsage ;
}	TVarbuffer ;


BOOL	TVarbuffer_Init		(TVarbuffer*, int) ;
void	TVarbuffer_Uninit	(TVarbuffer*) ;
void	TVarbuffer_Clear	(TVarbuffer*) ;
void*	TVarbuffer_GetBuffer(TVarbuffer*) ;
int		TVarbuffer_GetUsage	(TVarbuffer*) ;
BOOL	TVarbuffer_Add		(TVarbuffer*, const void*, int) ;
BOOL	TVarbuffer_Require	(TVarbuffer*, int) ;
BOOL	TVarbuffer_Sub		(TVarbuffer*, int) ;

#endif 

