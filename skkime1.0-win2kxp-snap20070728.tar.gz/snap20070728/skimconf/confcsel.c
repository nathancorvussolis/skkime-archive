/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#define	REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS	TEXT("j-henkan-show-candidate-keys")
#define	REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1	TEXT("j-input-by-code-or-menu-keys1")
#define	REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2	TEXT("j-input-by-code-or-menu-keys2")

static	INT_PTR	skkimeConfig_dlgCandidateSelectKeyOnInitDialog (HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgCandidateSelectKeyOnNotify (HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgCandidateSelectKeyOnCommand (HWND, UINT, WPARAM, LPARAM) ;
static	BOOL	skkimeConfig_getCurrentCandidateSelectKeyFromDialog (HWND) ;

static	BYTE	srDefaultJHenkanShowCandidateKeys []	= {
	'a', 's', 'd', 'f', 'j', 'k', 'l'
} ;
static	BYTE	srDefaultJInputByCodeOrMenuKeys1 []		= {
	'a', 's', 'd', 'f', 'g', 'h', 'q', 'w', 'e', 'r', 't', 'y'
} ;
static	BYTE	srDefaultJInputByCodeOrMenuKeys2 []		= {
	'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'q', 'w', 'e', 'r', 't', 'y', 'u'
} ;

BOOL
skkimeConfig_InitializeCandidateSelectKey (
	MYCANDSELKEY*		pArg)
{
	HKEY	hSubKey ;
	BOOL	fInitJHenkanShowCandidateKeys	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys1	= FALSE ;
	BOOL	fInitJInputByCodeOrMenuKeys2	= FALSE ;
	DWORD	dwType, cbData ;

	if (pArg == NULL)
		return	FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JHENKAN_SHOW_CANDIDATE_KEYS) {
			cbData	= NUM_JHENKAN_SHOW_CANDIDATE_KEYS ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, NULL, &dwType, pArg->_JHenkanShowCandidateKeys, &cbData) ;
			fInitJHenkanShowCandidateKeys	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS1 ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, NULL, &dwType, pArg->_JInputByCodeOrMenuKeys1, &cbData) ;
			fInitJInputByCodeOrMenuKeys1	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) {
			cbData = NUM_JINPUT_BY_CODE_OR_MENU_KEYS2 ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, NULL, &dwType, pArg->_JInputByCodeOrMenuKeys2, &cbData) ;
			fInitJInputByCodeOrMenuKeys2	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! fInitJHenkanShowCandidateKeys)
		memcpy (pArg->_JHenkanShowCandidateKeys, srDefaultJHenkanShowCandidateKeys, NUM_JHENKAN_SHOW_CANDIDATE_KEYS) ;
	if (! fInitJInputByCodeOrMenuKeys1)
		memcpy (pArg->_JInputByCodeOrMenuKeys1, srDefaultJInputByCodeOrMenuKeys1, NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) ;
	if (! fInitJInputByCodeOrMenuKeys2)
		memcpy (pArg->_JInputByCodeOrMenuKeys2, srDefaultJInputByCodeOrMenuKeys2, NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) ;
	return	TRUE ;
}

BOOL
skkimeConfig_UpdateCandidateSelectKey (
	MYCANDSELKEY*	pArg)
{
	HKEY			hSubKey ;
	BOOL	fRetval	= TRUE ;

	if (pArg == NULL)
		return	FALSE ;

	if (! skkimeConfig_CreateKey (REGPATH_GENERIC, FALSE, &hSubKey))
		return	FALSE ;

	if (RegSetValueEx (hSubKey, REGSUBKEY_JHENKAN_SHOW_CANDIDATE_KEYS, 0, REG_BINARY, (LPBYTE)pArg->_JHenkanShowCandidateKeys, NUM_JHENKAN_SHOW_CANDIDATE_KEYS) != ERROR_SUCCESS ||
		RegSetValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS1, 0, REG_BINARY, (LPBYTE)pArg->_JInputByCodeOrMenuKeys1, NUM_JINPUT_BY_CODE_OR_MENU_KEYS1) != ERROR_SUCCESS ||
		RegSetValueEx (hSubKey, REGSUBKEY_JINPUT_BY_CODE_OR_MENU_KEYS2, 0, REG_BINARY, (LPBYTE)pArg->_JInputByCodeOrMenuKeys2, NUM_JINPUT_BY_CODE_OR_MENU_KEYS2) != ERROR_SUCCESS)
		fRetval	= FALSE ;
	
	if (RegCloseKey (hSubKey) != ERROR_SUCCESS)
		fRetval	= FALSE ;
	return	fRetval ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgCandidateSelectKeyProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgCandidateSelectKeyOnInitDialog (hDlg, uMsg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgCandidateSelectKeyOnNotify (hDlg, uMsg, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgCandidateSelectKeyOnCommand (hDlg, uMsg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================*
 *	private functions
 */
INT_PTR
skkimeConfig_dlgCandidateSelectKeyOnInitDialog (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	MYCANDSELKEY*		pCandSel ;
	HWND				hwndCB ;
	int					nSel, nRes, ch ;
	TCHAR				szBuffer [2] ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgCandidateSelectKeyOnInitDialog (%x)\n"), hDlg)) ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR)lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	pCandSel	= &pConfArg->m_CandSelKey ;

	/*	�S�Ă� COMBOBOX �Ƀh���b�v�_�E�����X�g�̗v�f��ݒ肷��B
	 */
	szBuffer [1]	= TEXT ('\0') ;
	for (nRes = IDC_COMBO_HCANDSEL1 ; nRes <= IDC_COMBO_JCODE1_12 ; nRes ++) {
		hwndCB	= GetDlgItem (hDlg, nRes) ;
		if (hwndCB == NULL)
			continue ;
		for (ch = 0 ; ch < (0x7F - 0x21) ; ch ++) {
			szBuffer [0]	= TEXT (' ') + 1 + ch ;
			SendMessage (hwndCB, CB_INSERTSTRING, (WPARAM)ch, (LPARAM)szBuffer) ;
		}
	}

	/*	���݂̐ݒ�𔽉f������B
	 */
	for (nRes = IDC_COMBO_HCANDSEL1 ; nRes <= IDC_COMBO_HCANDSEL7 ; nRes ++) {
		hwndCB	= GetDlgItem (hDlg, nRes) ;
		if (hwndCB == NULL)
			continue ;
		nSel	= (int) pCandSel->_JHenkanShowCandidateKeys [nRes - IDC_COMBO_HCANDSEL1] ;
		nSel	= (TEXT (' ') < nSel && nSel < 0x7F)? (nSel - 0x21) : -1 ;
		SendMessage (hwndCB, CB_SETCURSEL, (WPARAM)nSel, (LPARAM) 0) ;
	}
	for (nRes = IDC_COMBO_JCODE1_1 ; nRes <= IDC_COMBO_JCODE1_12 ; nRes ++) {
		hwndCB	= GetDlgItem (hDlg, nRes) ;
		if (hwndCB == NULL)
			continue ;
		nSel	= (int) pCandSel->_JInputByCodeOrMenuKeys1 [nRes - IDC_COMBO_JCODE1_1] ;
		nSel	= (TEXT (' ') < nSel && nSel < 0x7F)? (nSel - 0x21) : -1 ;
		SendMessage (hwndCB, CB_SETCURSEL, (WPARAM)nSel, (LPARAM) 0) ;
	}
	for (nRes = IDC_COMBO_JCODE2_1 ; nRes <= IDC_COMBO_JCODE2_16 ; nRes ++) {
		hwndCB	= GetDlgItem (hDlg, nRes) ;
		if (hwndCB == NULL)
			continue ;
		nSel	= (int) pCandSel->_JInputByCodeOrMenuKeys2 [nRes - IDC_COMBO_JCODE2_1] ;
		nSel	= (TEXT (' ') < nSel && nSel < 0x7F)? (nSel - 0x21) : -1 ;
		SendMessage (hwndCB, CB_SETCURSEL, (WPARAM)nSel, (LPARAM) 0) ;
	}
	return	TRUE ;

	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgCandidateSelectKeyOnNotify (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (pNMHDR->code){
	case PSN_SETACTIVE:
		SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
		return	TRUE ;

	case PSN_KILLACTIVE:
		SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
		return	TRUE ;

	case PSN_APPLY:
	{
		if (skkimeConfig_getCurrentCandidateSelectKeyFromDialog (hDlg) &&
			skkimeConfig_UpdateCandidateSelectKey (&pConfArg->m_CandSelKey)) {
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
		} else {
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
		}
		return	TRUE ;
	}
	case PSN_RESET:
	case PSN_HELP:
	default:
		return	FALSE ;
	}
	return	TRUE ;

	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgCandidateSelectKeyOnCommand (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	WORD	wNotifyCode ;
	WORD	wID ;
	HWND	hwndCtl ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	if (IDC_COMBO_HCANDSEL1 <= wID && wID <= IDC_COMBO_JCODE1_12) {
		if (wNotifyCode == CBN_SELCHANGE) 
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
	}
	return	FALSE ;
	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

/*	Dialog ���猻�݂� Generic Config ��ǂݎ��B
 *
 *	CheckBox ��������Ă���Ȃ�A���̐��l�� TRUE ���A��������Ȃ����� 
 *	FALSE ���A�Ƃ������ɂ��āB
 */
BOOL
skkimeConfig_getCurrentCandidateSelectKeyFromDialog (
	HWND		hDlg)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	MYCANDSELKEY*		pCandSel ;
	HWND				hwndCB ;
	int				nRes, nSel ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	pCandSel	= &pConfArg->m_CandSelKey ;
	
	for (nRes = IDC_COMBO_HCANDSEL1 ; nRes <= IDC_COMBO_HCANDSEL7 ; nRes ++) {
		hwndCB	= GetDlgItem (hDlg, nRes) ;
		if (hwndCB == NULL)
			continue ;
		nSel	= SendMessage (hwndCB, CB_GETCURSEL, (WPARAM)0, (LPARAM) 0) ;
		if (nSel != CB_ERR) {
			pCandSel->_JHenkanShowCandidateKeys [nRes - IDC_COMBO_HCANDSEL1]	= TEXT (' ') + 1 + nSel ;
		}
	}
	for (nRes = IDC_COMBO_JCODE1_1 ; nRes <= IDC_COMBO_JCODE1_12 ; nRes ++) {
		hwndCB	= GetDlgItem (hDlg, nRes) ;
		if (hwndCB == NULL)
			continue ;
		nSel	= SendMessage (hwndCB, CB_GETCURSEL, (WPARAM)0, (LPARAM) 0) ;
		if (nSel != CB_ERR) {
			pCandSel->_JInputByCodeOrMenuKeys1 [nRes - IDC_COMBO_JCODE1_1]	= TEXT (' ') + 1 + nSel ;
		}
	}
	for (nRes = IDC_COMBO_JCODE2_1 ; nRes <= IDC_COMBO_JCODE2_16 ; nRes ++) {
		hwndCB	= GetDlgItem (hDlg, nRes) ;
		if (hwndCB == NULL)
			continue ;
		nSel	= SendMessage (hwndCB, CB_GETCURSEL, (WPARAM)0, (LPARAM) 0) ;
		if (nSel != CB_ERR) {
			pCandSel->_JInputByCodeOrMenuKeys2 [nRes - IDC_COMBO_JCODE2_1]	= TEXT (' ') + 1 + nSel ;
		}
	}
	return	TRUE ;
}


