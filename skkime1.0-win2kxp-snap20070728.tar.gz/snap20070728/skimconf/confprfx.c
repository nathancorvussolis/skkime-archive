/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#define	REGPATH_PREFIXLIST			REGPATH_SKKIME_BASE TEXT("\\PrefixList")
#define	MAX_LENGTH_KANAPREFIX		(128)

typedef struct {
	TCHAR		m_strKanaPrefix [MAX_LENGTH_KANAPREFIX] ;
}	TDlgEditKanaPrefixArg ;

static	INT_PTR	skkimeConfig_dlgKanaPrefixOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgKanaPrefixOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgKanaPrefixOnCommand		(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL	skkimeConfig_doEditKanaPrefix			(HWND, int, int) ;
static	INT_PTR CALLBACK	skkimeConfig_dlgEditKanaPrefix	(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL			skkimeConfig_initPrefixList				(LPCTSTR, PREFIXLISTNODE**, LPCTSTR*, int) ;
static	BOOL			skkimeConfig_updatePrefixList			(LPCTSTR, PREFIXLISTNODE*) ;
static	PREFIXLISTNODE*	skkimeConfig_newPrefixListNode			(LPCTSTR, int) ;
static	void			skkimeConfig_registerPrefixListNode		(PREFIXLISTNODE**, PREFIXLISTNODE*) ;
static	PREFIXLISTNODE*	skkimeConfig_findPrefixListNode			(PREFIXLISTNODE**, LPCTSTR) ;
static	void			skkimeConfig_unregisterPrefixListNode	(PREFIXLISTNODE**, PREFIXLISTNODE*) ;


/*========================================================================
 *	public functions
 */
BOOL
skkimeConfig_InitializePrefixList (
	PREFIXLISTNODE**	plstPrefix)
{
	if (plstPrefix == NULL)
		return	FALSE ;

	return	skkimeConfig_initPrefixList (REGPATH_PREFIXLIST, plstPrefix, g_rDefinitionOfDefaultPrefixList, NELEMENTS (g_rDefinitionOfDefaultPrefixList)) ;
}

BOOL
skkimeConfig_UpdatePrefixList (
	PREFIXLISTNODE*	lstPrefix)
{
	if (lstPrefix == NULL)
		return	FALSE ;

	return	skkimeConfig_updatePrefixList (REGPATH_PREFIXLIST, lstPrefix) ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgKanaPrefixTblProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgKanaPrefixOnInitDialog (hDlg, uMsg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgKanaPrefixOnNotify (hDlg, uMsg, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgKanaPrefixOnCommand (hDlg, uMsg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;

	UNREFERENCED_PARAMETER (wParam) ;
}

/*========================================================================
 *	private functions
 */
INT_PTR
skkimeConfig_dlgKanaPrefixOnInitDialog (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndKanaPrefixList ;
	PREFIXLISTNODE*		pNode ;
	int					n ;
	LVITEM				lvI ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgKanaPrefixOnInitDialog (%x)\n"), hDlg)) ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR)lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	hwndKanaPrefixList	= GetDlgItem (hDlg, IDC_LIST_KANAPREFIX) ;
	if (hwndKanaPrefixList != NULL) {
		ListView_DeleteAllItems (hwndKanaPrefixList) ;
		ListView_SetExtendedListViewStyle (hwndKanaPrefixList, LVS_EX_FULLROWSELECT) ;
		ListView_SetColumnWidth (hwndKanaPrefixList, 0, 30) ;
		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ; 
		lvI.stateMask	= 0 ;
		
		n				= 0 ;
		pNode			= pConfArg->m_lstPrefix ;
		while (pNode != NULL) {
			lvI.iItem		= n ;
			lvI.iImage		= 0 ;
			lvI.iSubItem	= 0 ;
			lvI.lParam		= (LPARAM) pNode ;
			lvI.pszText		= pNode->m_strPrefix ;
			if (ListView_InsertItem (hwndKanaPrefixList, &lvI) == -1) {
				DEBUGPRINTF ((TEXT ("dlgKanaPrefixTblProc: ListView_InsetItem failed(%d)\n"),
							  n)) ;
			}
			pNode	= pNode->m_pNext ;
			n		++ ;
		}
	}
	return	FALSE ;

	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgKanaPrefixOnNotify (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	NMHDR	FAR*		pNMHDR	= (NMHDR *) lParam ;
	static TMYMENUITEM		rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0, TEXT("�ǉ�"), IDC_BUTTON_INSERT_KANAPREFIX, },
		{ MIIM_ID | MIIM_STRING, 0, TEXT("�폜"), IDC_BUTTON_DELETE_KANAPREFIX, },
	} ;

	DEBUGPRINTF ((TEXT ("WM_NOTIFY: (from(%d), code(%d))\n"), pNMHDR->idFrom, pNMHDR->code)) ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_KANAPREFIX:
		if (pNMHDR->code == NM_RCLICK) {
			NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;
			int	n ;

			DEBUGPRINTF ((TEXT ("skkimeConfig_dlgKanaPrefixOnNotify(Msg:%u, %d)\n"), uMsg, pNMHDR->idFrom)) ;

			n	= skkimeConfig_PopupMenu (hDlg, rmi, NELEMENTS (rmi)) ;
			if (n > 0)
				skkimeConfig_doEditKanaPrefix (hDlg, ((n != IDC_BUTTON_INSERT_KANAPREFIX)? pNM->iItem : -1), n) ;
			return	FALSE ;
		}
		return	FALSE ;

	default:
		switch (pNMHDR->code){
		case PSN_SETACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
			return	TRUE ;

		case PSN_APPLY:
		{
			if (skkimeConfig_UpdatePrefixList (pConfArg->m_lstPrefix)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;
		}
		case PSN_RESET:
		case PSN_HELP:
			break ;
		default:
			return FALSE ;
		}
		return	TRUE ;
	}

	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgKanaPrefixOnCommand (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	WORD	wNotifyCode ;
	WORD	wID ;
	HWND	hwndCtl ;
	HWND	hwndLV ;
	int	nItem	= -1 ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;
	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	DEBUGPRINTF ((TEXT ("WM_COMMAND: (wID(%d), wNotifyCode(%d))\n"),
				  wID, wNotifyCode)) ;

	hwndLV		= GetDlgItem (hDlg, IDC_LIST_KANAPREFIX) ;
	if (hwndLV == NULL || pConfArg == NULL)
		return	1 ;
	
	switch (wID) {
	case	IDC_BUTTON_DELETE_KANAPREFIX:
		nItem	= ListView_GetSelectionMark (hwndLV) ;
		/*	fall through */
	case	IDC_BUTTON_INSERT_KANAPREFIX:
		if (wNotifyCode != BN_CLICKED)
			return	1 ;
		skkimeConfig_doEditKanaPrefix (hDlg, nItem, wID) ;
		return	0 ;

	case	IDC_EDIT_SEARCH_KANAPREFIX:
	{
		if (wNotifyCode != EN_CHANGE)
			return	TRUE ;

		wNotifyCode = BN_CLICKED ;
		/*	fall through */
	}
	case	IDC_BUTTON_SEARCH_KANAPREFIX:
	{
		LVFINDINFO	lvfi ;
		HWND		hwndEdit ;
		int			nStart ;
		TCHAR		sstrSearchPrefix [MAX_LENGTH_KANAPREFIX] ;

		if (wNotifyCode != BN_CLICKED)
			return	TRUE ;
		hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_SEARCH_KANAPREFIX) ;
		if (hwndEdit == NULL)
			return	TRUE ;

		GetWindowText (hwndEdit, sstrSearchPrefix, MAX_LENGTH_KANAPREFIX) ;
		sstrSearchPrefix [MAX_LENGTH_KANAPREFIX - 1]	= TEXT ('\0') ;
		lvfi.psz	= sstrSearchPrefix ;
		lvfi.flags	= LVFI_PARTIAL ;
		if (wID == IDC_EDIT_SEARCH_KANAPREFIX) {
			nStart	= 0 ;
		} else {
			nStart	= ListView_GetSelectionMark (hwndLV) ;
			if (nStart < 0)
				nStart	= 0 ;
		}
		nItem		= ListView_FindItem (hwndLV, nStart, &lvfi) ;
		if ((nItem == nStart || nItem < 0) && nStart != 0)
			nItem	= ListView_FindItem (hwndLV, -1, &lvfi) ;
		if (nItem >= 0) {
			ListView_SetSelectionMark (hwndLV, nItem) ;
			ListView_SetItemState (hwndLV, nItem, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED) ;
		}
		return	0 ;
	}
	default:
		break ;
	}
	return 0 ;
	UNREFERENCED_PARAMETER (uMsg) ;
}

BOOL
skkimeConfig_doEditKanaPrefix (
	HWND		hDlg,
	int			nItem,
	int			nCommand)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndLV ;
	PREFIXLISTNODE**	plstTop ;
	PREFIXLISTNODE*		pNode ;
	LVITEM			lvI ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	hwndLV		= GetDlgItem (hDlg, IDC_LIST_KANAPREFIX) ;
	if (hwndLV == NULL || pConfArg == NULL)
		return	FALSE ;
	plstTop		= &pConfArg->m_lstPrefix ;

	switch (nCommand) {
	case	IDC_BUTTON_INSERT_KANAPREFIX: 
	{
		TDlgEditKanaPrefixArg		arg ;
		int				nRetval ;
		int				nLength ;

		arg.m_strKanaPrefix [0]	= TEXT ('\0') ;
		nRetval	= DialogBoxParam (pConfArg->m_hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_KANAPREFIX), hDlg, skkimeConfig_dlgEditKanaPrefix, (LPARAM) &arg) ;
		if (nRetval == IDOK) {
			/* ����� kanaprefix �����݂���Ύ̂ĂȂ���΂Ȃ�Ȃ��B*/
			if (skkimeConfig_findPrefixListNode (plstTop, arg.m_strKanaPrefix) != NULL)
				return	FALSE ;

			nLength	= lstrlen (arg.m_strKanaPrefix) ;
			pNode	= skkimeConfig_newPrefixListNode (arg.m_strKanaPrefix, nLength) ;
			if (pNode == NULL)
				return	FALSE ;
			skkimeConfig_registerPrefixListNode (plstTop, pNode) ;

			lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
			lvI.state		= 0 ; 
			lvI.stateMask	= 0 ;
			lvI.iImage		= 0 ;
			lvI.iSubItem	= 0 ;
			lvI.lParam		= (LPARAM) pNode ;
			lvI.iItem		= ListView_GetItemCount (hwndLV) ;
			lvI.pszText		= arg.m_strKanaPrefix ;
			if (ListView_InsertItem  (hwndLV, &lvI) == -1)
				return	FALSE ;

			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		}
		break ;
	}
	case	IDC_BUTTON_DELETE_KANAPREFIX: 
	{
		lvI.mask		= LVIF_PARAM ;
		lvI.state		= 0 ;
		lvI.stateMask	= 0 ;
		lvI.iItem		= nItem ;
		lvI.iSubItem	= 0 ;
		lvI.pszText		= 0 ;
		lvI.cchTextMax	= 0 ;
		if (! ListView_GetItem (hwndLV, &lvI)) 
			return	FALSE ;
		ListView_DeleteItem (hwndLV, nItem) ;
		pNode			= (PREFIXLISTNODE *)lvI.lParam ;
		if (pNode == NULL)
			return	FALSE ;
		skkimeConfig_unregisterPrefixListNode (plstTop, pNode) ;
		FREE (pNode) ;
		PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		break ;
	}
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

INT_PTR CALLBACK
skkimeConfig_dlgEditKanaPrefix (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND	hwndEdit ;
	TDlgEditKanaPrefixArg*	pArg ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

		pArg		= (TDlgEditKanaPrefixArg*) lParam ;
		hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_KANAPREFIX) ;
		if (hwndEdit != NULL) {
			SendMessage (hwndEdit, EM_LIMITTEXT, (WPARAM) MAX_LENGTH_KANAPREFIX - 1, 0) ;
			SetWindowText (hwndEdit, pArg->m_strKanaPrefix) ;
		}
		return	TRUE ;
	}
	case	WM_COMMAND:
		switch (LOWORD (wParam)) {
		case	IDOK:
			pArg		= (TDlgEditKanaPrefixArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_KANAPREFIX) ;
				if (hwndEdit != NULL) {
					GetWindowText (hwndEdit, pArg->m_strKanaPrefix, MAX_LENGTH_KANAPREFIX) ;
					pArg->m_strKanaPrefix [MAX_LENGTH_KANAPREFIX - 1]	= TEXT ('\0') ;
					if (pArg->m_strKanaPrefix [0] == TEXT ('\0')) 
						wParam	= IDCANCEL ;
				} else {
					wParam	= IDCANCEL ;
				}
			}
			/* fall through */
		case	IDCANCEL:
			EndDialog (hDlg, wParam) ;
			return	TRUE ;
		default:
			break ;
		}
		/*	fall through */
	default:
		break ;
	}
	return	FALSE ;
}

BOOL
skkimeConfig_initPrefixList (
	LPCTSTR				pstrSubKey,
	PREFIXLISTNODE**	plstTop,
	LPCTSTR*			ppDefaultPrefixList,
	int					nDefaultPrefixList)
{
	HKEY			hSubKey ;
	BOOL			fRetval	= FALSE ;
	TCHAR			rbyData [MAX_REGVALUE_SIZE] ;
	int				nPrefix ;
	PREFIXLISTNODE*	pNode ;
	BYTE*			pbData	= NULL ;

	*plstTop	= NULL ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG		lResult ;
		LPCTSTR	pPrefix ;
		DWORD				cbData, dwType ;

		lResult = RegQueryValueEx (hSubKey, NULL, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ)
			goto	exit_regopen ;

		if (cbData < sizeof (rbyData)) {
			pbData	= (BYTE*)rbyData ;
			cbData	= sizeof (rbyData) ;
		} else {
			pbData	= MALLOC (cbData) ;
			if (pbData == NULL) 
				goto	exit_regopen ;
		}
		
		/*	cbData �ɂ͕K�v�ʂ����ɓ����Ă���̂ŁA��������̂܂܎g���B*/
		(void) RegQueryValueEx (hSubKey, NULL, NULL, NULL, pbData, &cbData) ;
		
		/*	parse ����B*/
		pPrefix	= (LPCTSTR) pbData ;
		while (nPrefix = lstrlen (pPrefix), nPrefix > 0) {
			if (nPrefix < MAX_LENGTH_KANAPREFIX) {
				pNode	= skkimeConfig_newPrefixListNode (pPrefix, nPrefix) ;
				if (pNode == NULL)
					goto	exit_regopen ;
				skkimeConfig_registerPrefixListNode (plstTop, pNode) ;
			}
			pPrefix			+= (nPrefix + 1) ;
		}
		fRetval	= TRUE ;
 exit_regopen:
		if (pbData != NULL && pbData != (BYTE*)rbyData) {
			FREE (pbData) ;
			pbData	= NULL ;
		}
		RegCloseKey (hSubKey) ;
	} else {
		int	i ;

		for (i = 0 ; i < nDefaultPrefixList ; i ++) {
			nPrefix		= lstrlen (ppDefaultPrefixList [i]) ;
			if (nPrefix < MAX_REGVALUE_SIZE) {
				lstrcpy (rbyData, ppDefaultPrefixList [i]) ;
				rbyData [MAX_REGVALUE_SIZE - 1]	= TEXT ('\0') ;

				if (0 < nPrefix && nPrefix < MAX_LENGTH_KANAPREFIX) {
					pNode		= skkimeConfig_newPrefixListNode (rbyData, nPrefix) ;
					if (pNode == NULL)
						break ;
					skkimeConfig_registerPrefixListNode (plstTop, pNode) ;
				}
			}
		}
		if (i == nDefaultPrefixList)
			fRetval	= TRUE ;
	}
	return	fRetval ;
}

BOOL
skkimeConfig_updatePrefixList (
	LPCTSTR				pstrSubKey,
	PREFIXLISTNODE*		plstTop)
{
	TCHAR		szData [MAX_REGVALUE_SIZE] ;
	HKEY		hSubKey ;
	LPTSTR		pDest ;
	int			nDest, nPrefixLen ;
	BOOL		fRetval ;
	PREFIXLISTNODE*	pNode ;

	if (! skkimeConfig_CreateKey (pstrSubKey, TRUE, &hSubKey))
		return	FALSE ;

	pNode	= plstTop ;
	pDest	= szData ;
	nDest	= MAX_REGVALUE_SIZE ;
	while (pNode != NULL) {
		nPrefixLen	= lstrlen (pNode->m_strPrefix) ;
		if ((nPrefixLen + 1 + 1) > nDest)
			break ;
		memcpy (pDest, pNode->m_strPrefix, sizeof (TCHAR) * (nPrefixLen + 1)) ;
		pDest	+= (nPrefixLen + 1) ;
		nDest	-= (nPrefixLen + 1) ;
		pNode	= pNode->m_pNext ;
	}
	if (nDest > 0) {
		*pDest	= TEXT ('\0') ;
		pDest	++ ;
		if (RegSetValueEx (hSubKey, NULL, 0, REG_MULTI_SZ, (BYTE *)szData, sizeof (TCHAR) * (pDest - szData)) != ERROR_SUCCESS) {
			DEBUGPRINTF ((TEXT ("RegSetValueEx: failed (\"NULL\", \"%s\")\n"), szData)) ;
			fRetval	= FALSE ;
		} else {
			fRetval	= TRUE ;
		}
	} else {
		DEBUGPRINTF ((TEXT ("Too long skk-perfix-list!\n"))) ;
		fRetval	= FALSE ;
	}
	RegCloseKey (hSubKey) ;
	return	fRetval ;
}

PREFIXLISTNODE*
skkimeConfig_newPrefixListNode (
	LPCTSTR		pPrefix,
	int			nPrefix)
{
	PREFIXLISTNODE*	pNode ;

	pNode	= MALLOC (sizeof (TCHAR) * (nPrefix + 1) + sizeof (PREFIXLISTNODE)) ;
	if (pNode == NULL)
		return	NULL ;
	pNode->m_pPrev		= NULL ;
	pNode->m_pNext		= NULL ;
	pNode->m_strPrefix	= (LPTSTR)(pNode + 1) ;
	lstrcpy (pNode->m_strPrefix, pPrefix) ;
	return	pNode ;
}

void
skkimeConfig_registerPrefixListNode (
	PREFIXLISTNODE**	plstTop,
	PREFIXLISTNODE*		pNode)
{
	PREFIXLISTNODE*	pNextNode ;
	if (pNode == NULL || plstTop == NULL)
		return ;

	pNextNode		= *plstTop ;
	pNode->m_pNext	= pNextNode ;
	if (pNextNode != NULL)
		pNextNode->m_pPrev	= pNode ;
	*plstTop		= pNode ;
	return ;
}

PREFIXLISTNODE*
skkimeConfig_findPrefixListNode (
	PREFIXLISTNODE**	plstTop,
	LPCTSTR			strKanaPrefix)
{
	PREFIXLISTNODE*	pNode ;

	if (plstTop == NULL || strKanaPrefix == NULL)
		return	NULL ;

	pNode	= *plstTop ;
	while (pNode != NULL) {
		if (! lstrcmp (pNode->m_strPrefix, strKanaPrefix))
			return	pNode ;
		pNode	= pNode->m_pNext ;
	}
	return	NULL ;
}

void
skkimeConfig_unregisterPrefixListNode (
	PREFIXLISTNODE**	plstTop,
	PREFIXLISTNODE*		pNode)
{
	PREFIXLISTNODE*	pPrevNode ;
	PREFIXLISTNODE*	pNextNode ;

	if (pNode == NULL || plstTop == NULL)
		return ;

	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode == NULL) {
		if (pNode != *plstTop) {
			DEBUGPRINTF ((TEXT ("PREFIXLISTNODE: node(%p) is invalid.\n"), pNode)) ;
			return ;
		}
		*plstTop	= pNextNode ;
	} else {
		pPrevNode->m_pNext		= pNextNode ;
	}
	if (pNextNode != NULL)
		pNextNode->m_pPrev	= NULL ;
	return ;
}

