/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#define	MAX_NUMBER_STYLE				(4)

typedef struct {
	int				m_nIDButton ;
	int				m_nIndex ;
}	DEFCHECKBOX ;

static	INT_PTR	skkimeConfig_dlgGenericOnInitDialog (HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgGenericOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	skkimeConfig_dlgGenericOnCommand	(HWND, UINT, WPARAM, LPARAM) ;
static	BOOL	skkimeConfig_getCurrentGenericSettingFromDialog	(HWND) ;
static	BOOL	skkimeConfig_regQueryDword			(HKEY, LPCTSTR, DWORD*) ;

static DEFCHECKBOX				srSkkimeCheckBoxTbl []	= {
	{	IDC_CHECK_OPEN_KANAMODE,			0, },
	{	IDC_CHECK_EGG_LIKE_NEWLINE,			1, },
	{	IDC_CHECK_DELETE_IMPLIES_KAKUTEI,	2, },
	{	IDC_CHECK_USE_NUMERIC_CONVERSION,	3, },
	{	IDC_CHECK_DABBREV_LIKE_COMPLETION,	4, },
	{	IDC_CHECK_KATAKANA_HIRAGANA_HENKAN,	5, },
	{	IDC_CHECK_SHOW_ANNOTATION,			8, },
	{	IDC_CHECK_KAKUTEI_EARLY,			9, },
	{	IDC_CHECK_PROCESS_OKURI_EARLY,		10, },
	{	IDC_CHECK_DELETE_OKURI_WHEN_QUIT,	11, }
} ;

BOOL
skkimeConfig_InitializeGeneric (
	MYGENERICCONFIG*	pArg)
{
	const DEFGENERICSETTING*	ptr ;
	LPBYTE				lpTop	= (LPBYTE)pArg ;
	HKEY				hSubKey ;
	int					i ;

	if (pArg == NULL)
		return	FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwValue ;

		ptr		= g_rDefintionOfGenericConfig ;
		for (i = 0 ; i < NELEMENTS (g_rDefintionOfGenericConfig) ; i ++) {
			if (! skkimeConfig_regQueryDword (hSubKey, ptr->m_strPath, &dwValue)) {
				dwValue	= ptr->m_nDefault ;
			}
			*((int *)(lpTop + ptr->m_nOffset))	= (int) dwValue ;
			ptr	++ ;
		}
		RegCloseKey (hSubKey) ;
	} else {
		ptr		= g_rDefintionOfGenericConfig ;
		for (i = 0 ; i < NELEMENTS (g_rDefintionOfGenericConfig) ; i ++) {
			*((int *)(lpTop + ptr->m_nOffset))	= ptr->m_nDefault ;
			ptr	++ ;
		}
	}
	return	TRUE ;
}

BOOL
skkimeConfig_UpdateGeneric (
	MYGENERICCONFIG*	pArg)
{
	HKEY						hSubKey ;
	LPBYTE						lpTop	= (LPBYTE)pArg ;
	int							i ;
	BOOL						fRetval	= TRUE ;
	const DEFGENERICSETTING*	ptr ;
	DWORD						dwValue ;

	if (pArg == NULL)
		return	FALSE ;

	if (! skkimeConfig_CreateKey (REGPATH_GENERIC, FALSE, &hSubKey))
		return	FALSE ;

	ptr	= g_rDefintionOfGenericConfig ;
	for (i = 0 ; i < NELEMENTS (g_rDefintionOfGenericConfig) ; i ++) {
		dwValue	= (DWORD)*(int *)(lpTop + ptr->m_nOffset) ;
		if (RegSetValueEx (hSubKey, ptr->m_strPath, 0, REG_DWORD, (LPBYTE)&dwValue, sizeof (DWORD)) != ERROR_SUCCESS) {
			fRetval	= FALSE ;
			break ;
		}
		ptr	++ ;
	}
	if (RegCloseKey (hSubKey) != ERROR_SUCCESS)
		fRetval	= FALSE ;
	return	fRetval ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgGenericProc (
	register HWND		hDlg,
	register UINT		uMsg,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgGenericOnInitDialog (hDlg, uMsg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgGenericOnNotify (hDlg, uMsg, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgGenericOnCommand (hDlg, uMsg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================*
 *	private functions
 */
INT_PTR
skkimeConfig_dlgGenericOnInitDialog (
	register HWND		hDlg,
	register UINT		uMsg,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	register LPPROPSHEETPAGE	pPropSheet ;
	register SkkimeConfigArg*	pConfArg ;
	register MYGENERICCONFIG*	pGeneConf ;
	register HWND				hwnd ;
	register LPBYTE				pBuffer ;
	register int				i, nRetval, nSel ;
	register DEFCHECKBOX*		pBoxDef ;
	static LPCTSTR				srDateAdTbl []	= {
		TEXT ("�w�肵�Ȃ�"),	TEXT ("�N��"),	TEXT ("����"),
	} ;
	static LPCTSTR				srNumberStyleTbl [MAX_NUMBER_STYLE]	= {
		TEXT ("���ϊ�"),		TEXT ("�S�p����"),
		TEXT ("�����\�L1"),	TEXT ("�����\�L2"),
	} ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_dlgGenericOnInitDialog (%x)\n"), hDlg)) ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR)lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	pGeneConf	= &pConfArg->m_GenericConfig ;

	/*	checkbox ���̐ݒ�B*/
	pBuffer		= (LPBYTE) pGeneConf ;
	pBoxDef		= srSkkimeCheckBoxTbl ;
	for (i = 0 ; i < NELEMENTS (srSkkimeCheckBoxTbl) ; i ++, pBoxDef ++) {
		register int	nOffset, nValue, nID ;

		nOffset	= g_rDefintionOfGenericConfig [pBoxDef->m_nIndex].m_nOffset ;
		nValue	= *(int *)(pBuffer + nOffset) ;
		nID		= pBoxDef->m_nIDButton ;
		CheckDlgButton (hDlg, nID, (nValue != 0)? BST_CHECKED : BST_UNCHECKED) ;
	}

	/*	combobox ���̐ݒ�B*/
	/*	date-ad = 0 ... �N��
	 *			= 1 ... ����
	 *	number-style	= 0 ... identity
	 *					= 1 ... �S�p
	 *					= 2 ... ����1
	 *					= 3 ... ����2
	 *					= 9 ... ����
	 */
	hwnd	= GetDlgItem (hDlg, IDC_COMBO_DATE_AD) ;
	if (hwnd != NULL && IsWindow (hwnd)) {
		for (i = 0 ; i < NELEMENTS (srDateAdTbl) ; i ++) {
			nRetval	= SendMessage (hwnd, CB_INSERTSTRING, i, (LPARAM) srDateAdTbl [i]) ;
		}
		if (pGeneConf->m_nDateAd < 0) {
			nSel	= 0 ;
		} else {
			nSel	= pGeneConf->m_nDateAd + 1 ;
		}
		SendMessage (hwnd, CB_SETCURSEL, (WPARAM) nSel, (LPARAM) 0) ;
	}
	hwnd	= GetDlgItem (hDlg, IDC_COMBO_NUMBER_STYLE) ;
	if (hwnd != NULL && IsWindow (hwnd)) {
		for (i = 0 ; i < NELEMENTS (srNumberStyleTbl) ; i ++) {
			nRetval	= SendMessage (hwnd, CB_INSERTSTRING, i, (LPARAM) srNumberStyleTbl [i]) ;
		}
		if (0 <= pGeneConf->m_nNumberStyle && pGeneConf->m_nNumberStyle < MAX_NUMBER_STYLE) {
			nSel	= pGeneConf->m_nNumberStyle ;
		} else {
			nSel	= 0 ;
		}
		SendMessage (hwnd, CB_SETCURSEL, (WPARAM) nSel, (LPARAM) 0) ;
	}
	return	TRUE ;

	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgGenericOnNotify (
	register HWND		hDlg,
	register UINT		uMsg,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	register LPPROPSHEETPAGE	pPropSheet ;
	register SkkimeConfigArg*	pConfArg ;
	register NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (pNMHDR->code){
	case PSN_SETACTIVE:
		SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
		return	TRUE ;

	case PSN_KILLACTIVE:
		SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
		return	TRUE ;

	case PSN_APPLY:
	{
		if (skkimeConfig_getCurrentGenericSettingFromDialog (hDlg) &&
			skkimeConfig_UpdateGeneric (&pConfArg->m_GenericConfig)) {
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
		} else {
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
		}
		return	TRUE ;
	}
	case PSN_RESET:
	case PSN_HELP:
	default:
		return	FALSE ;
	}
	return	TRUE ;

	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgGenericOnCommand (
	register HWND		hDlg,
	register UINT		uMsg,
	register WPARAM		wParam,
	register LPARAM		lParam)
{
	register LPPROPSHEETPAGE	pPropSheet ;
	register SkkimeConfigArg*	pConfArg ;
	register WORD	wNotifyCode ;
	register WORD	wID ;
	register HWND	hwndCtl ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (wID) {
	case	IDC_CHECK_OPEN_KANAMODE:
	case	IDC_CHECK_EGG_LIKE_NEWLINE:
	case	IDC_CHECK_DELETE_IMPLIES_KAKUTEI:
	case	IDC_CHECK_USE_NUMERIC_CONVERSION:
	case	IDC_CHECK_DABBREV_LIKE_COMPLETION:
	case	IDC_CHECK_KATAKANA_HIRAGANA_HENKAN:
	case	IDC_CHECK_SHOW_ANNOTATION:
	case	IDC_CHECK_KAKUTEI_EARLY:
	case	IDC_CHECK_PROCESS_OKURI_EARLY:
	case	IDC_CHECK_DELETE_OKURI_WHEN_QUIT:
		if (wNotifyCode == BN_CLICKED) 
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		break ;

	case	IDC_COMBO_NUMBER_STYLE:
	case	IDC_COMBO_DATE_AD:
		if (wNotifyCode == CBN_SELCHANGE) 
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		break ;

	default:
		break ;
	}
	return	FALSE ;
	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

/*	Dialog ���猻�݂� Generic Config ��ǂݎ��B
 *
 *	CheckBox ��������Ă���Ȃ�A���̐��l�� TRUE ���A��������Ȃ����� 
 *	FALSE ���A�Ƃ������ɂ��āB
 */
BOOL
skkimeConfig_getCurrentGenericSettingFromDialog (
	register HWND		hDlg)
{
	register LPPROPSHEETPAGE	pPropSheet ;
	register SkkimeConfigArg*	pConfArg ;
	register DEFCHECKBOX*		pBoxDef ;
	register LPBYTE				pBuffer ;
	register int				i, nID, nOffset ;
	register MYGENERICCONFIG*	pGeneConf ;
	register LRESULT			lResult ;
	register HWND				hwnd ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;
	
	pBoxDef		= srSkkimeCheckBoxTbl ;
	pGeneConf	= &pConfArg->m_GenericConfig ;
	pBuffer		= (LPBYTE) pGeneConf ;
	for (i = 0 ; i < NELEMENTS (srSkkimeCheckBoxTbl) ; i ++, pBoxDef ++) {
		nID		= pBoxDef->m_nIDButton ;
		nOffset	= g_rDefintionOfGenericConfig [pBoxDef->m_nIndex].m_nOffset ; 
		if (IsDlgButtonChecked (hDlg, nID) == BST_CHECKED) {
			*(int *)(pBuffer + nOffset)	= TRUE ;
		} else {
			*(int *)(pBuffer + nOffset)	= FALSE ;
		}
	}

	pGeneConf->m_nDateAd	= -1 ;
	hwnd		= GetDlgItem (hDlg, IDC_COMBO_DATE_AD) ;
	if (hwnd != NULL && IsWindow (hwnd)) {
		lResult		= SendMessage (hwnd, CB_GETCURSEL, 0, 0) ;
		if (lResult != CB_ERR) 
			pGeneConf->m_nDateAd	= lResult - 1 ;
	}

	pGeneConf->m_nNumberStyle	= 0 ;
	hwnd		= GetDlgItem (hDlg, IDC_COMBO_NUMBER_STYLE) ;
	if (hwnd != NULL && IsWindow (hwnd)) {
		lResult		= SendMessage (hwnd, CB_GETCURSEL, 0, 0) ;
		if (lResult != CB_ERR && 0 <= lResult && lResult < MAX_NUMBER_STYLE) 
			pGeneConf->m_nNumberStyle	= lResult ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_regQueryDword (
	register HKEY		hSubKey,
	register LPCTSTR	strPath,
	register DWORD*		pdwRetval)
{
	register LONG	lResult ;
	DWORD	dwType, dwValue, cbData ;

	cbData	= sizeof (dwValue) ;
	lResult	= RegQueryValueEx (hSubKey, strPath, NULL, &dwType, (LPBYTE)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		return	FALSE ;

	*pdwRetval	= dwValue ;
	return	TRUE ;
}

