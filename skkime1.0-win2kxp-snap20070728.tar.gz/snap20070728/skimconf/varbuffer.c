#include "StdAfx.h"
#include "varbuffer.h"

BOOL
TVarbuffer_Init		(
	register TVarbuffer*	pvbuf,
	register int			nWidth) 
{
	if (pvbuf == NULL || nWidth <= 0)
		return	FALSE ;

	pvbuf->_nWidth	= nWidth ;
	pvbuf->_nSize	= NELEMENTS (pvbuf->_rbyInternal) / nWidth ;
	pvbuf->_nUsage	= 0 ;
	pvbuf->_pBuffer	= pvbuf->_rbyInternal ;
	return	TRUE ;
}

void
TVarbuffer_Uninit	(
	register TVarbuffer*	pvbuf)
{
	ASSERT (pvbuf != NULL) ;
	TVarbuffer_Clear (pvbuf) ;
	return ;
}

void
TVarbuffer_Clear	(
	register TVarbuffer*	pvbuf)
{
	ASSERT (pvbuf != NULL) ;

	if (pvbuf->_pBuffer != pvbuf->_rbyInternal) {
		FREE (pvbuf->_pBuffer) ;
		pvbuf->_pBuffer	= pvbuf->_rbyInternal ;
	}
	pvbuf->_nUsage	= 0 ;
	pvbuf->_nSize	= NELEMENTS (pvbuf->_rbyInternal) / pvbuf->_nWidth ;
	return ;
}

void*	TVarbuffer_GetBuffer(
	register TVarbuffer*	pvbuf)
{
	ASSERT (pvbuf != NULL) ;
	return	pvbuf->_pBuffer ;
}

int	
TVarbuffer_GetUsage	(
	register TVarbuffer*	pvbuf)
{
	ASSERT (pvbuf != NULL) ;
	return	pvbuf->_nUsage ;
}

BOOL
TVarbuffer_Add		(
	register TVarbuffer*	pvbuf,
	register const void*	pvData,
	register int			nData)
{
	register BYTE*	pDest ;
	register int	nUsage ;

	ASSERT (pvbuf != NULL && pvbuf->_nWidth > 0) ;
	
	if (pvData == NULL || nData <= 0)
		return	FALSE ;

	nUsage	= pvbuf->_nUsage ;
	if (! TVarbuffer_Require (pvbuf, nData))
		return	FALSE ;

	pDest	= (BYTE*)pvbuf->_pBuffer + pvbuf->_nWidth * nUsage ;
	memcpy (pDest, pvData, nData * pvbuf->_nWidth) ;
	return	TRUE ;
}

BOOL	TVarbuffer_Sub		(
	register TVarbuffer*	pvbuf,
	register int			nData)
{
	if (nData == 0)
		return	TRUE ;

	if (nData < 0)
		return	TVarbuffer_Require (pvbuf, - nData) ;

	if (pvbuf->_nUsage < nData) {
		pvbuf->_nUsage	= 0 ;
	} else {
		pvbuf->_nUsage	-= nData ;
	}
	return	TRUE ;
}

BOOL
TVarbuffer_Require	(
	register TVarbuffer*	pvbuf,
	register int			nData)
{
	register int	nNewUsage, nNewSize ;

	ASSERT (pvbuf != NULL && pvbuf->_nWidth > 0) ;
	
	if (nData == 0)
		return	TRUE ;	/* Nothing to do */

	if (nData < 0) 
		return	TVarbuffer_Sub (pvbuf, - nData) ;
	
	nNewUsage	= pvbuf->_nUsage + nData ;
	if (nNewUsage > pvbuf->_nSize) {
		register void*	pNewBuffer ;

		nNewSize	= (nNewUsage + 127) & ~0x7F ;
		ASSERT (nNewSize >= nNewUsage) ;
		ASSERT (nNewSize >= pvbuf->_nSize) ;
		pNewBuffer	= MALLOC (nNewSize * pvbuf->_nWidth) ;
		if (pNewBuffer == NULL)
			return	FALSE ;
			memcpy (pNewBuffer, pvbuf->_pBuffer, pvbuf->_nUsage * pvbuf->_nWidth) ;
			if (pvbuf->_pBuffer != pvbuf->_rbyInternal) 
				FREE (pvbuf->_pBuffer) ;
			pvbuf->_pBuffer	= pNewBuffer ;
			pvbuf->_nSize	= nNewSize ;
	}
	pvbuf->_nUsage	+= nData ;
	ASSERT (pvbuf->_nUsage <= pvbuf->_nSize) ;
	return	TRUE ;
}



