/* # SKKIME (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of SKKIME.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdafx.h"
#include "skimconf.h"
#include "confdefaults.h"

#define	MAX_LENGTH_ROMAKANAPREFIX		(128)
#define	MAX_LENGTH_ROMAKANAKANA			(128)
#define	MAX_LENGTH_ROMAKANAKATA			(128)

#define	REGPATH_ROMAKANATABLE_A		REGPATH_SKKIME_BASE TEXT("\\RomaKanaTable\\A")
#define	REGPATH_ROMAKANATABLE_I		REGPATH_SKKIME_BASE TEXT("\\RomaKanaTable\\I")
#define	REGPATH_ROMAKANATABLE_U		REGPATH_SKKIME_BASE TEXT("\\RomaKanaTable\\U")
#define	REGPATH_ROMAKANATABLE_E		REGPATH_SKKIME_BASE TEXT("\\RomaKanaTable\\E")
#define	REGPATH_ROMAKANATABLE_O		REGPATH_SKKIME_BASE TEXT("\\RomaKanaTable\\O")

typedef struct tagROMAKANATABLE {
	LPTSTR			prefix ;
	LPTSTR			kana ;
	LPTSTR			katakana ;
}	ROMAKANATABLE, NEAR *PROMAKANATABLE, FAR *LPROMAKANATABLE ;

typedef struct {
	TCHAR		m_strPrefix   [MAX_LENGTH_ROMAKANAPREFIX] ;
	TCHAR		m_strKana     [MAX_LENGTH_ROMAKANAPREFIX] ;
	TCHAR		m_strKatakana [MAX_LENGTH_ROMAKANAPREFIX] ;
}	TDlgEditRomaKanaTableArg ;

static	INT_PTR		skkimeConfig_dlgRomaKanaTblOnInitDialog	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR		skkimeConfig_dlgRomaKanaTblOnCommand	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR		skkimeConfig_dlgRomaKanaTblOnNotify		(HWND, UINT, WPARAM, LPARAM) ;
static	BOOL		skkimeConfig_initControlRomaKanaTableList	(SkkimeConfigArg*, HWND, BOOL) ;
static	BOOL		skkimeConfig_initControlRomaKanaOneTable	(HWND, BOOL, ROMAKANATABLENODE*) ;
static	BOOL		skkimeConfig_switchKanaKata				(HWND, BOOL) ;

static	BOOL		skkimeConfig_editRomaKanaTable			(HWND, int, int) ;
static	INT_PTR CALLBACK	skkimeConfig_dlgEditRomaKanaTbl	(HWND, UINT, WPARAM, LPARAM) ;
static	int	CALLBACK	skkimeConfig_compareRomaKanaTblNode	(LPARAM, LPARAM, LPARAM) ;
static	BOOL	skkimeConfig_registerRomaKanaTableNode	(SkkimeConfigArg*, ROMAKANATABLENODE*) ;
static	BOOL	skkimeConfig_unregisterRomaKanaTableNode	(SkkimeConfigArg*, ROMAKANATABLENODE*) ;
static	ROMAKANATABLENODE**	skkimeConfig_getRomaKanaTableListTop	(SkkimeConfigArg*, int) ;

static	BOOL	skkimeConfig_initRomaKanaTable		(LPCTSTR, ROMAKANATABLENODE**, ROMAKANATABLE*, int, int) ;
static	BOOL	skkimeConfig_updateRomaKanaTable	(LPCTSTR, ROMAKANATABLENODE*) ;
static	ROMAKANATABLENODE*	skkimeConfig_newRomaKanaTableNode	(int, int, int) ;
static	ROMAKANATABLENODE*	skkimeConfig_findRomaKanaTableNode	(SkkimeConfigArg*, LPCTSTR, int) ;


/* ���[�}�����Ȃ̕ϊ��e�[�u���u���v�� */
static	ROMAKANATABLE		srSkkDefaultRomaKanaA [] = {
	{ TEXT (""),	TEXT ("��"),  		TEXT ("�A")   },
	{ TEXT ("b") ,	TEXT ("��"),  		TEXT ("�o")   },
	{ TEXT ("by"),	TEXT ("�т�"),		TEXT ("�r��") },
	{ TEXT ("ch"),	TEXT ("����"),		TEXT ("�`��") },  
	{ TEXT ("cy"),	TEXT ("����"),		TEXT ("�`��") }, 
	{ TEXT ("d"), 	TEXT ("��"),  		TEXT ("�_")   },
	{ TEXT ("dh"),	TEXT ("�ł�"),		TEXT ("�f��") },
	{ TEXT ("dy"),	TEXT ("����"),		TEXT ("�a��") },
	{ TEXT ("f"),	TEXT ("�ӂ�"),		TEXT ("�t�@") },
	{ TEXT ("fy"),	TEXT ("�ӂ�"),		TEXT ("�t��") },
	{ TEXT ("g"),	TEXT ("��"),  		TEXT ("�K")   },
	{ TEXT ("gy"),	TEXT ("����"),		TEXT ("�M��") },
	{ TEXT ("h"),	TEXT ("��"),  		TEXT ("�n")   },
	{ TEXT ("hy"),	TEXT ("�Ђ�"),		TEXT ("�q��") },
	{ TEXT ("j"),	TEXT ("����"),		TEXT ("�W��") },
	{ TEXT ("jy"),	TEXT ("����"),		TEXT ("�W��") },
	{ TEXT ("k"), 	TEXT ("��"),  		TEXT ("�J")   },
	{ TEXT ("ky"),	TEXT ("����"),		TEXT ("�L��") },
	{ TEXT ("m"), 	TEXT ("��"),  		TEXT ("�}")   },
	{ TEXT ("my"),	TEXT ("�݂�"),		TEXT ("�~��") },
	{ TEXT ("n"), 	TEXT ("��"),  		TEXT ("�i")   },
	{ TEXT ("ny"),	TEXT ("�ɂ�"),		TEXT ("�j��") },
	{ TEXT ("p"), 	TEXT ("��"),  		TEXT ("�p")   },
	{ TEXT ("py"),	TEXT ("�҂�"),		TEXT ("�s��") },
	{ TEXT ("r"), 	TEXT ("��"),  		TEXT ("��")   },
	{ TEXT ("ry"),	TEXT ("���"),		TEXT ("����") },
	{ TEXT ("s"), 	TEXT ("��"),  		TEXT ("�T")   },
	{ TEXT ("sh"),	TEXT ("����"),		TEXT ("�V��") },
	{ TEXT ("sy"),	TEXT ("����"),		TEXT ("�V��") }, 
	{ TEXT ("t"), 	TEXT ("��"),  		TEXT ("�^")   },
	{ TEXT ("th"),	TEXT ("�Ă�"),		TEXT ("�e�@") },
	{ TEXT ("ty"),	TEXT ("����"),		TEXT ("�`��") },
	{ TEXT ("v"), 	TEXT ("���J��"),	TEXT ("���@") },
	{ TEXT ("w"), 	TEXT ("��"),  		TEXT ("��") },
	{ TEXT ("x"), 	TEXT ("��"),  		TEXT ("�@")   },
	{ TEXT ("xk"),	TEXT ("��"),  		TEXT ("��") },
	{ TEXT ("xw"),	TEXT ("��"),  		TEXT ("��")   },
	{ TEXT ("xy"),	TEXT ("��"),  		TEXT ("��") },
	{ TEXT ("y"), 	TEXT ("��"),  		TEXT ("��")   },
	{ TEXT ("z"), 	TEXT ("��"),  		TEXT ("�U")   },
	{ TEXT ("zy"),	TEXT ("����"),		TEXT ("�W��") },
} ;

/* ���[�}�����Ȃ̕ϊ��e�[�u���u���v�� */
static	ROMAKANATABLE		srSkkDefaultRomaKanaI [] = {
	{ TEXT (""),	TEXT ("��"),		TEXT ("�C")   },
	{ TEXT ("b"),	TEXT ("��"),		TEXT ("�r")   },
	{ TEXT ("by"),	TEXT ("�т�"),		TEXT ("�r�B") },
	{ TEXT ("ch"),	TEXT ("��"),  		TEXT ("�`")   },
	{ TEXT ("cy"),	TEXT ("����"),		TEXT ("�`�B") },
	{ TEXT ("d"),	TEXT ("��"),		TEXT ("�a")   },
	{ TEXT ("dh"),	TEXT ("�ł�"),		TEXT ("�f�B") },
	{ TEXT ("dy"),	TEXT ("����"),		TEXT ("�a�B") },
	{ TEXT ("f"),	TEXT ("�ӂ�"),		TEXT ("�t�B") },
	{ TEXT ("fy"),	TEXT ("�ӂ�"),		TEXT ("�t�B") },
	{ TEXT ("g"),	TEXT ("��"),		TEXT ("�M")   },
	{ TEXT ("gy"),	TEXT ("����"),		TEXT ("�M�B") },
	{ TEXT ("h"),	TEXT ("��"),		TEXT ("�q")   },
	{ TEXT ("hy"),	TEXT ("�Ђ�"),		TEXT ("�q�B") },
	{ TEXT ("j"),	TEXT ("��"),		TEXT ("�W")   },
	{ TEXT ("jy"),	TEXT ("����"),		TEXT ("�W�B") },
	{ TEXT ("k"),	TEXT ("��"),		TEXT ("�L")   },
	{ TEXT ("ky"),	TEXT ("����"),		TEXT ("�L�B") },
	{ TEXT ("m"),	TEXT ("��"),		TEXT ("�~")   },
	{ TEXT ("my"),	TEXT ("�݂�"),		TEXT ("�~�B") },
	{ TEXT ("n"),	TEXT ("��"),		TEXT ("�j")   },
	{ TEXT ("ny"),	TEXT ("�ɂ�"),		TEXT ("�j�B") },
	{ TEXT ("p"),	TEXT ("��"),		TEXT ("�s")   },
	{ TEXT ("py"),	TEXT ("�҂�"),		TEXT ("�s�B") },
	{ TEXT ("r"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("ry"),	TEXT ("�股"),		TEXT ("���B") },
	{ TEXT ("s"),	TEXT ("��"),		TEXT ("�V")   },
	{ TEXT ("sh"),	TEXT ("��"),		TEXT ("�V")   },
	{ TEXT ("sy"),	TEXT ("����"),		TEXT ("�V�B") },
	{ TEXT ("t"),	TEXT ("��"),		TEXT ("�`")   },
	{ TEXT ("th"),	TEXT ("�Ă�"),		TEXT ("�e�B") },
	{ TEXT ("ty"),	TEXT ("����"),		TEXT ("�`�B") },
	{ TEXT ("v"),	TEXT ("���J��"),	TEXT ("���B") },
	{ TEXT ("w"),	TEXT ("����"),		TEXT ("�E�B") },
	{ TEXT ("x"),	TEXT ("��"),		TEXT ("�B")   },
	{ TEXT ("xw"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("z"),	TEXT ("��"),		TEXT ("�W")   },
	{ TEXT ("zy"),	TEXT ("����"),		TEXT ("�W�B") },
} ;

/* ���[�}�����Ȃ̕ϊ��e�[�u���u���v�� */
static	ROMAKANATABLE		srSkkDefaultRomaKanaU [] = {
	{ TEXT (""),	TEXT ("��"),		TEXT ("�E")   },
	{ TEXT ("b"),	TEXT ("��"),		TEXT ("�u")   },
	{ TEXT ("by"),	TEXT ("�т�"),		TEXT ("�r��") },
	{ TEXT ("ch"),	TEXT ("����"),		TEXT ("�`��") },
	{ TEXT ("cy"),	TEXT ("����"),		TEXT ("�`��") },
	{ TEXT ("d"),	TEXT ("��"),		TEXT ("�d")   },
	{ TEXT ("dh"),	TEXT ("�ł�"),		TEXT ("�f��") },
	{ TEXT ("dy"),	TEXT ("����"),		TEXT ("�a��") },
	{ TEXT ("f"),	TEXT ("��"),		TEXT ("�t")   },
	{ TEXT ("fy"),	TEXT ("�ӂ�"),		TEXT ("�t��") },
	{ TEXT ("g"),	TEXT ("��"),		TEXT ("�O")   },
	{ TEXT ("gy"),	TEXT ("����"),		TEXT ("�M��") },
	{ TEXT ("h"),	TEXT ("��"),		TEXT ("�t")   },
	{ TEXT ("hy"),	TEXT ("�Ђ�"),		TEXT ("�q��") },
	{ TEXT ("j"),	TEXT ("����"),		TEXT ("�W��") },
	{ TEXT ("jy"),	TEXT ("����"),		TEXT ("�W��") },
	{ TEXT ("k"),	TEXT ("��"),		TEXT ("�N")   },
	{ TEXT ("ky"),	TEXT ("����"),		TEXT ("�L��") },
	{ TEXT ("m"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("my"),	TEXT ("�݂�"),		TEXT ("�~��") },
	{ TEXT ("n"),	TEXT ("��"),		TEXT ("�k")   },
	{ TEXT ("ny"),	TEXT ("�ɂ�"),		TEXT ("�j��") },
	{ TEXT ("p"),	TEXT ("��"),		TEXT ("�v")   },
	{ TEXT ("py"),	TEXT ("�҂�"),		TEXT ("�s��") },
	{ TEXT ("r"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("ry"),	TEXT ("���"),		TEXT ("����") },
	{ TEXT ("s"),	TEXT ("��"),		TEXT ("�X")   },
	{ TEXT ("sh"),	TEXT ("����"),		TEXT ("�V��") },
	{ TEXT ("sy"),	TEXT ("����"),		TEXT ("�V��") },
	{ TEXT ("t"),	TEXT ("��"),		TEXT ("�c")   },
	{ TEXT ("th"),	TEXT ("�Ă�"),		TEXT ("�e��") },
	{ TEXT ("ts"),	TEXT ("��"),		TEXT ("�c")   },
	{ TEXT ("ty"),	TEXT ("����"),		TEXT ("�`��") },
	{ TEXT ("v"),	TEXT ("���J"),		TEXT ("��")   },
	{ TEXT ("w"),	TEXT ("��"),		TEXT ("�E")   },
	{ TEXT ("x"),	TEXT ("��"),		TEXT ("�D")   },
	{ TEXT ("xt"),	TEXT ("��"),		TEXT ("�b")   },
	{ TEXT ("xts"),	TEXT ("��"),		TEXT ("�b")   },
	{ TEXT ("xy"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("y"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("z"),	TEXT ("��"),		TEXT ("�Y")   },
	{ TEXT ("zy"),	TEXT ("����"),		TEXT ("�W��") },
} ;

/* ���[�}�����Ȃ̕ϊ��e�[�u���u���v�� */
static	ROMAKANATABLE		srSkkDefaultRomaKanaE [] = {
	{ TEXT (""),	TEXT ("��"),		TEXT ("�G")   },
	{ TEXT ("b"),	TEXT ("��"),		TEXT ("�x")   },
	{ TEXT ("by"),	TEXT ("�т�"),		TEXT ("�r�F") },
	{ TEXT ("ch"),	TEXT ("����"),		TEXT ("�`�F") },
	{ TEXT ("cy"),	TEXT ("����"),		TEXT ("�`�F") },
	{ TEXT ("d"),	TEXT ("��"),		TEXT ("�f")   },
	{ TEXT ("dh"),	TEXT ("�ł�"),		TEXT ("�f�F") },
	{ TEXT ("dy"),	TEXT ("����"),		TEXT ("�a�F") },
	{ TEXT ("f"),	TEXT ("�ӂ�"),		TEXT ("�t�F") },
	{ TEXT ("fy"),	TEXT ("�ӂ�"),		TEXT ("�t�F") },
	{ TEXT ("g"),	TEXT ("��"),		TEXT ("�Q")   },
	{ TEXT ("gy"),	TEXT ("����"),		TEXT ("�M�F") },
	{ TEXT ("h"),	TEXT ("��"),		TEXT ("�w")   },
	{ TEXT ("hy"),	TEXT ("�Ђ�"),		TEXT ("�q�F") },
	{ TEXT ("j"),	TEXT ("����"),		TEXT ("�W�F") },
	{ TEXT ("jy"),	TEXT ("����"),		TEXT ("�W�F") },
	{ TEXT ("k"),	TEXT ("��"),		TEXT ("�P")   },
	{ TEXT ("ky"),	TEXT ("����"),		TEXT ("�L�F") },
	{ TEXT ("m"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("my"),	TEXT ("�݂�"),		TEXT ("�~�F") },
	{ TEXT ("n"),	TEXT ("��"),		TEXT ("�l")   },
	{ TEXT ("ny"),	TEXT ("�ɂ�"),		TEXT ("�j�F") },
	{ TEXT ("p"),	TEXT ("��"),		TEXT ("�y")   },
	{ TEXT ("py"),	TEXT ("�҂�"),		TEXT ("�s�F") },
	{ TEXT ("r"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("ry"),	TEXT ("�肥"),		TEXT ("���F") },
	{ TEXT ("s"),	TEXT ("��"),		TEXT ("�Z")   },
	{ TEXT ("sh"),	TEXT ("����"),		TEXT ("�V�F") },
	{ TEXT ("sy"),	TEXT ("����"),		TEXT ("�V�F") },
	{ TEXT ("t"),	TEXT ("��"),		TEXT ("�e")   },
	{ TEXT ("th"),	TEXT ("�Ă�"),		TEXT ("�e�F") },
	{ TEXT ("ty"),	TEXT ("����"),		TEXT ("�`�F") },
	{ TEXT ("v"),	TEXT ("���J��"),	TEXT ("���F") },
	{ TEXT ("w"),	TEXT ("����"),		TEXT ("�E�F") },
	{ TEXT ("x"),	TEXT ("��"),		TEXT ("�F")   },
	{ TEXT ("xk"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("xw"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("y"),	TEXT ("����"),		TEXT ("�C�F") },
	{ TEXT ("z"),	TEXT ("��"),		TEXT ("�[")   },
	{ TEXT ("zy"),	TEXT ("����"),		TEXT ("�W�F") },
} ;

/* ���[�}�����Ȃ̕ϊ��e�[�u���u���v�� */
static	ROMAKANATABLE		srSkkDefaultRomaKanaO [] = {
	{ TEXT (""),	TEXT ("��"),		TEXT ("�I")   },
	{ TEXT ("b"),	TEXT ("��"),		TEXT ("�{")   },
	{ TEXT ("by"),	TEXT ("�т�"),		TEXT ("�r��") },
	{ TEXT ("ch"),	TEXT ("����"),		TEXT ("�`��") },
	{ TEXT ("cy"),	TEXT ("����"),		TEXT ("�`��") },
	{ TEXT ("d"),	TEXT ("��"),		TEXT ("�h")   },
	{ TEXT ("dh"),	TEXT ("�ł�"),		TEXT ("�f��") },
	{ TEXT ("dy"),	TEXT ("����"),		TEXT ("�a��") },
	{ TEXT ("f"),	TEXT ("�ӂ�"),		TEXT ("�t�H") },
	{ TEXT ("fy"),	TEXT ("�ӂ�"),		TEXT ("�t��") },
	{ TEXT ("g"),	TEXT ("��"),		TEXT ("�S")   },
	{ TEXT ("gy"),	TEXT ("����"),		TEXT ("�M��") },
	{ TEXT ("h"),	TEXT ("��"),		TEXT ("�z")   },
	{ TEXT ("hy"),	TEXT ("�Ђ�"),		TEXT ("�q��") },
	{ TEXT ("j"),	TEXT ("����"),		TEXT ("�W��") },
	{ TEXT ("jy"),	TEXT ("����"),		TEXT ("�W��") },
	{ TEXT ("k"),	TEXT ("��"),		TEXT ("�R")   },
	{ TEXT ("ky"),	TEXT ("����"),		TEXT ("�L��") },
	{ TEXT ("m"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("my"),	TEXT ("�݂�"),		TEXT ("�~��") },
	{ TEXT ("n"),	TEXT ("��"),		TEXT ("�m")   },
	{ TEXT ("ny"),	TEXT ("�ɂ�"),		TEXT ("�j��") },
	{ TEXT ("p"),	TEXT ("��"),		TEXT ("�|")   },
	{ TEXT ("py"),	TEXT ("�҂�"),		TEXT ("�s��") },
	{ TEXT ("r"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("ry"),	TEXT ("���"),		TEXT ("����") },
	{ TEXT ("s"),	TEXT ("��"),		TEXT ("�\")   },
	{ TEXT ("sh"),	TEXT ("����"),		TEXT ("�V��") },
	{ TEXT ("sy"),	TEXT ("����"),		TEXT ("�V��") },
	{ TEXT ("t"),	TEXT ("��"),		TEXT ("�g")   },
	{ TEXT ("th"),	TEXT ("�Ă�"),		TEXT ("�e��") },
	{ TEXT ("ty"),	TEXT ("����"),		TEXT ("�`��") },
	{ TEXT ("v"),	TEXT ("���J��"),	TEXT ("���H") },
	{ TEXT ("w"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("x"),	TEXT ("��"),		TEXT ("�H")   },
	{ TEXT ("xy"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("y"),	TEXT ("��"),		TEXT ("��")   },
	{ TEXT ("z"),	TEXT ("��"),		TEXT ("�]")   },
	{ TEXT ("zy"),	TEXT ("����"),		TEXT ("�W��") },
} ;

BOOL
skkimeConfig_InitializeRomaKanaTableA (
	ROMAKANATABLENODE**	plstRomaKanaA)
{
	if (plstRomaKanaA == NULL)
		return	FALSE ;
	return	skkimeConfig_initRomaKanaTable (REGPATH_ROMAKANATABLE_A, plstRomaKanaA, srSkkDefaultRomaKanaA, NELEMENTS (srSkkDefaultRomaKanaA), TEXT ('a')) ;
}

BOOL
skkimeConfig_InitializeRomaKanaTableI (
	ROMAKANATABLENODE**	plstRomaKanaI)
{
	if (plstRomaKanaI == NULL)
		return	FALSE ;
	return	skkimeConfig_initRomaKanaTable (REGPATH_ROMAKANATABLE_I, plstRomaKanaI, srSkkDefaultRomaKanaI, NELEMENTS (srSkkDefaultRomaKanaI), TEXT('i')) ;
}

BOOL
skkimeConfig_InitializeRomaKanaTableU (
	ROMAKANATABLENODE**	plstRomaKanaU)
{
	if (plstRomaKanaU == NULL)
		return	FALSE ;
	return	skkimeConfig_initRomaKanaTable (REGPATH_ROMAKANATABLE_U, plstRomaKanaU, srSkkDefaultRomaKanaU, NELEMENTS (srSkkDefaultRomaKanaU), TEXT('u')) ;
}

BOOL
skkimeConfig_InitializeRomaKanaTableE (
	ROMAKANATABLENODE**	plstRomaKanaE)
{
	if (plstRomaKanaE == NULL)
		return	FALSE ;
	return	skkimeConfig_initRomaKanaTable (REGPATH_ROMAKANATABLE_E, plstRomaKanaE, srSkkDefaultRomaKanaE, NELEMENTS (srSkkDefaultRomaKanaE), TEXT('e')) ;
}

BOOL
skkimeConfig_InitializeRomaKanaTableO (
	ROMAKANATABLENODE**	plstRomaKanaO)
{
	if (plstRomaKanaO == NULL)
		return	FALSE ;
	return	skkimeConfig_initRomaKanaTable (REGPATH_ROMAKANATABLE_O, plstRomaKanaO, srSkkDefaultRomaKanaO, NELEMENTS (srSkkDefaultRomaKanaO), TEXT('o')) ;
}

BOOL
skkimeConfig_UpdateRomaKanaTableA (
	ROMAKANATABLENODE*		lstRomaKanaA)
{
	if (lstRomaKanaA == NULL)
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_updateRomaKanaTableA (%p)\n"), lstRomaKanaA)) ;
	return	skkimeConfig_updateRomaKanaTable (REGPATH_ROMAKANATABLE_A, lstRomaKanaA) ;
}

BOOL
skkimeConfig_UpdateRomaKanaTableI (
	ROMAKANATABLENODE*		lstRomaKanaI)
{
	if (lstRomaKanaI == NULL)
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_updateRomaKanaTableI (%p)\n"), lstRomaKanaI)) ;
	return	skkimeConfig_updateRomaKanaTable (REGPATH_ROMAKANATABLE_I, lstRomaKanaI) ;
}

BOOL
skkimeConfig_UpdateRomaKanaTableU (
	ROMAKANATABLENODE*		lstRomaKanaU)
{
	if (lstRomaKanaU == NULL)
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_updateRomaKanaTableU (%p)\n"), lstRomaKanaU)) ;
	return	skkimeConfig_updateRomaKanaTable (REGPATH_ROMAKANATABLE_U, lstRomaKanaU) ;
}

BOOL
skkimeConfig_UpdateRomaKanaTableE (
	ROMAKANATABLENODE*		lstRomaKanaE)
{
	if (lstRomaKanaE == NULL)
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_updateRomaKanaTableE (%p)\n"), lstRomaKanaE)) ;
	return	skkimeConfig_updateRomaKanaTable (REGPATH_ROMAKANATABLE_E, lstRomaKanaE) ;
}

BOOL
skkimeConfig_UpdateRomaKanaTableO (
	ROMAKANATABLENODE*		lstRomaKanaO)
{
	if (lstRomaKanaO == NULL)
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("skkimeConfig_updateRomaKanaTableO (%p)\n"), lstRomaKanaO)) ;
	return	skkimeConfig_updateRomaKanaTable (REGPATH_ROMAKANATABLE_O, lstRomaKanaO) ;
}

INT_PTR	CALLBACK
skkimeConfig_dlgRomaKanaTblProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	skkimeConfig_dlgRomaKanaTblOnInitDialog (hDlg, uMsg, wParam, lParam) ;
	case	WM_COMMAND:
		return	skkimeConfig_dlgRomaKanaTblOnCommand (hDlg, uMsg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	skkimeConfig_dlgRomaKanaTblOnNotify (hDlg, uMsg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	private functions
 */
INT_PTR
skkimeConfig_dlgRomaKanaTblOnInitDialog (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE		pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndRomaKanaTblList, hwndRadio ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pPropSheet	= (LPPROPSHEETPAGE) lParam ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	hwndRomaKanaTblList	= GetDlgItem (hDlg, IDC_LIST_ROMAKANATABLE) ;
	if (hwndRomaKanaTblList == NULL)
		return	TRUE ;
	ListView_SetExtendedListViewStyle (hwndRomaKanaTblList, LVS_EX_FULLROWSELECT) ;
	skkimeConfig_initControlRomaKanaTableList (pConfArg, hwndRomaKanaTblList, FALSE) ;

	hwndRadio	= GetDlgItem (hDlg, IDC_RADIO_SHOW_ROMAKANATABLE_WITH_KANA) ;
	if (hwndRadio == NULL)
		return	TRUE ;
	SendMessage (hwndRadio, BM_SETCHECK, BST_CHECKED, 0) ;
	return	TRUE ;

	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
skkimeConfig_dlgRomaKanaTblOnCommand (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	WORD	wNotifyCode ;
	WORD	wID ;
	HWND	hwndCtl ;
	HWND	hwndLV ;

	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	DEBUGPRINTF ((TEXT ("WM_COMMAND: (wID(%d), wNotifyCode(%d))\n"),
				  wID, wNotifyCode)) ;

	switch (wID) {
	case	IDC_RADIO_SHOW_ROMAKANATABLE_WITH_KANA:
	case	IDC_RADIO_SHOW_ROMAKANATABLE_WITH_KATA:
	{
		hwndLV	= GetDlgItem (hDlg, IDC_LIST_ROMAKANATABLE) ;
		if (hwndLV == NULL)
			return	TRUE ;	/* Message ����������Ȃ����� 1 ��Ԃ��B*/
		skkimeConfig_switchKanaKata (hwndLV, (wID == IDC_RADIO_SHOW_ROMAKANATABLE_WITH_KATA)) ;
		return	FALSE ;	/* Message ���������ꂽ���� 0 ��Ԃ��B*/
	}
	case	IDC_EDIT_SEARCH:
	{
		if (wNotifyCode != EN_CHANGE)
			return	TRUE ;

		wNotifyCode = BN_CLICKED ;
		/*	fall through */
	}
	case	IDC_BUTTON_SEARCH_NEXT:
	{
		LVFINDINFO				lvfi ;
		HWND				hwndEdit ;
		int				nItem, nStart ;
		TCHAR						szBuffer [MAX_LENGTH_ROMAKANAPREFIX] ;

		if (wNotifyCode != BN_CLICKED)
			return	TRUE ;
		hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_SEARCH) ;
		hwndLV		= GetDlgItem (hDlg, IDC_LIST_ROMAKANATABLE) ;
		if (hwndEdit == NULL || hwndLV == NULL)
			return	TRUE ;	/* Message ����������Ȃ����� 1 ��Ԃ��B*/

		GetWindowText (hwndEdit, szBuffer, MAX_LENGTH_ROMAKANAPREFIX) ;
		szBuffer [MAX_LENGTH_ROMAKANAPREFIX - 1]	= TEXT ('\0') ;
		if (wID == IDC_EDIT_SEARCH) {
			nStart	= 0 ;
		} else {
			nStart	= ListView_GetSelectionMark (hwndLV) ;
			if (nStart < 0)
				nStart	= 0 ;
		}
		lvfi.psz	= szBuffer ;
		lvfi.flags	= LVFI_PARTIAL ;
		nItem		= ListView_FindItem (hwndLV, nStart, &lvfi) ;
		if ((nItem == nStart || nItem < 0) && nStart != 0)
			nItem	= ListView_FindItem (hwndLV, -1, &lvfi) ;
		if (nItem >= 0) {
			ListView_SetSelectionMark (hwndLV, nItem) ;
			ListView_SetItemState (hwndLV, nItem, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED) ;
		}
		return	FALSE ;
	}
	case	IDC_BUTTON_EDIT:
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_DELETE:
	{
		int	nItem ;

		if (wNotifyCode != BN_CLICKED) 
			return	TRUE ;

		if (wID != IDC_BUTTON_INSERT) {
			hwndLV	= GetDlgItem (hDlg, IDC_LIST_ROMAKANATABLE) ;
			if (hwndLV == NULL)
				return	TRUE ;	/* Message ����������Ȃ����� 1 ��Ԃ��B*/
			nItem	= ListView_GetSelectionMark (hwndLV) ;
		} else {
			nItem	= -1 ;
		}
		skkimeConfig_editRomaKanaTable (hDlg, nItem, wID) ;
		return	FALSE ;
	}
	default:
		break ;
	}
	return 0 ;
	UNREFERENCED_PARAMETER (uMsg) ;
}

INT_PTR
skkimeConfig_dlgRomaKanaTblOnNotify (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	NMHDR	FAR*		pNMHDR	= (NMHDR *) lParam ;
	static TMYMENUITEM		rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ǉ�"), IDC_BUTTON_INSERT, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�ύX"), IDC_BUTTON_EDIT, },
		{ MIIM_ID | MIIM_STRING, 0,  TEXT("�폜"), IDC_BUTTON_DELETE, },
	} ;

	pPropSheet	= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg	= (SkkimeConfigArg *) pPropSheet->lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_ROMAKANATABLE:
	{
		if (pNMHDR->code == NM_RCLICK) {
			NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;
			int	n ;

			n	= skkimeConfig_PopupMenu (hDlg, rmi, NELEMENTS (rmi)) ;
			DEBUGPRINTF ((TEXT ("NM: item(%d), lParam(%d)\n"), pNM->iItem, pNM->lParam)) ;
			if (n > 0) 
				skkimeConfig_editRomaKanaTable (hDlg, ((n != IDC_BUTTON_INSERT)? pNM->iItem : -1), n) ;
			DEBUGPRINTF ((TEXT ("TrackPopupMenu returns %d\n"), n)) ;
		}
		return	FALSE ;	/* WM_NOTIFY �� Return Value �� ignore �����̂�
						 * ����Ԃ��Ă��ǂ��B*/
	}
	default:
		switch (pNMHDR->code){
		case PSN_SETACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, 0) ;
			return	TRUE ;

		case PSN_KILLACTIVE:
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, FALSE) ;
			return	TRUE ;

		case PSN_APPLY:
		{
			if (skkimeConfig_UpdateRomaKanaTableA (pConfArg->m_lstRomaKanaA) &&
				skkimeConfig_UpdateRomaKanaTableI (pConfArg->m_lstRomaKanaI) &&
				skkimeConfig_UpdateRomaKanaTableU (pConfArg->m_lstRomaKanaU) &&
				skkimeConfig_UpdateRomaKanaTableE (pConfArg->m_lstRomaKanaE) &&
				skkimeConfig_UpdateRomaKanaTableO (pConfArg->m_lstRomaKanaO)) {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_NOERROR) ;
			} else {
				SetWindowLongPtr (hDlg, DWLP_MSGRESULT, PSNRET_INVALID) ;
			}
			return	TRUE ;
		}
		case PSN_RESET:
		case PSN_HELP:
			break ;
		default:
			return FALSE ;
		}
		return	TRUE ;
	}

	UNREFERENCED_PARAMETER (uMsg) ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
skkimeConfig_editRomaKanaTable (
	HWND	hDlg,
	int	nItem,
	int	nCommand)
{
	LPPROPSHEETPAGE	pPropSheet ;
	SkkimeConfigArg*	pConfArg ;
	HWND				hwndLV ;
	LVFINDINFO				lvfi ;
	LVITEM					lvI ;
	int				nRetval ;
	int				nPrefixLen, nKanaLen, nKataLen ;
	int				nVowel, nSpace ;
	ROMAKANATABLENODE*	pNode ;
	ROMAKANATABLENODE*	pNewNode ;
	BOOL				fKatakana ;
	TDlgEditRomaKanaTableArg	arg ;
	TCHAR						rszBuffer [256 + 16] ;

	pPropSheet		= (LPPROPSHEETPAGE) GetWindowLongPtr (hDlg, DWLP_USER) ;
	pConfArg		= (SkkimeConfigArg *) pPropSheet->lParam ;
	hwndLV			= GetDlgItem (hDlg, IDC_LIST_ROMAKANATABLE) ;
	if (hwndLV == NULL || pConfArg == NULL)
		return	FALSE ;

	lvI.mask		= LVIF_PARAM ;
	lvI.state		= 0 ;
	lvI.stateMask	= 0 ;
	lvI.iItem		= nItem ;
	lvI.iSubItem	= 0 ;
	lvI.pszText		= 0 ;
	lvI.cchTextMax	= 0 ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		pNode		= NULL ;
	} else {
		pNode		= (ROMAKANATABLENODE*) lvI.lParam ;
	}

	switch (nCommand) {
	case	IDC_BUTTON_EDIT:
	case	IDC_BUTTON_INSERT:
		arg.m_strPrefix   [0]	= TEXT ('\0') ;
		arg.m_strKana     [0]	= TEXT ('\0') ;
		arg.m_strKatakana [0]	= TEXT ('\0') ;
		if (pNode != NULL && pNode->m_strPrefix != NULL) {
			lstrcpyn (arg.m_strPrefix,   pNode->m_strPrefix, MAX_LENGTH_ROMAKANAPREFIX - 1) ;
			arg.m_strPrefix [MAX_LENGTH_ROMAKANAPREFIX - 2]	= TEXT ('\0') ;
			nPrefixLen	= lstrlen (arg.m_strPrefix) ;
			arg.m_strPrefix [nPrefixLen ++]	= (TCHAR) pNode->m_chVowel ;
			arg.m_strPrefix [nPrefixLen]	= TEXT ('\0') ;

			if (pNode->m_strKana != NULL) {
				lstrcpyn (arg.m_strKana,     pNode->m_strKana,   MAX_LENGTH_ROMAKANAKANA) ;
				arg.m_strKana [MAX_LENGTH_ROMAKANAKANA - 1]	= TEXT ('\0') ;
			}
			if (pNode->m_strKatakana != NULL) {
				lstrcpyn (arg.m_strKatakana, pNode->m_strKatakana, MAX_LENGTH_ROMAKANAKATA) ;
				arg.m_strKatakana [MAX_LENGTH_ROMAKANAKATA - 1]	= TEXT ('\0') ;
			}
		}
		nRetval	= DialogBoxParam (pConfArg->m_hInst, MAKEINTRESOURCE (IDD_DIALOG_EDIT_ROMAKANATBL), hDlg, skkimeConfig_dlgEditRomaKanaTbl, (LPARAM) &arg) ;
		if (nRetval == IDOK) {
			nPrefixLen	= lstrlen (arg.m_strPrefix) ;
			if (nPrefixLen <= 1) {
				DEBUGPRINTF ((TEXT ("Fatal: The length of prefix(%d) is too short.\n"),
							  nPrefixLen)) ;
				return	FALSE ;
			}
			nVowel	= arg.m_strPrefix [nPrefixLen - 1] ;
			if (nVowel != TEXT ('a') && nVowel != TEXT ('i') &&
				nVowel != TEXT ('u') && nVowel != TEXT ('e') &&
				nVowel != TEXT ('o')) {
				DEBUGPRINTF ((TEXT ("Fatal: Vowel(%c) is not acceptable.\n"), nVowel)) ;
				return	FALSE ;
			}
			arg.m_strPrefix [nPrefixLen - 1]	= TEXT ('\0') ;
			nKanaLen	= lstrlen (arg.m_strKana) + 1 ;
			nKataLen	= lstrlen (arg.m_strKatakana) + 1 ;
			pNewNode	= skkimeConfig_newRomaKanaTableNode (nPrefixLen, nKanaLen, nKataLen) ;
			if (pNewNode == NULL) {
				DEBUGPRINTF ((TEXT ("Fatal: Failed in creating new romakanatable-node,\n"))) ;
				return	FALSE ;
			}
			lstrcpy (pNewNode->m_strPrefix,   arg.m_strPrefix) ;
			lstrcpy (pNewNode->m_strKana,     arg.m_strKana) ;
			lstrcpy (pNewNode->m_strKatakana, arg.m_strKatakana) ;
			pNewNode->m_chVowel	= nVowel ;

			lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
			lvI.state		= 0 ; 
			lvI.stateMask	= 0 ;
			lvI.iImage		= 0 ;
			lvI.iSubItem	= 0 ;
			lvI.lParam		= (LPARAM) pNewNode ;
			fKatakana		= (IsDlgButtonChecked (hDlg, IDC_RADIO_SHOW_ROMAKANATABLE_WITH_KATA) == BST_CHECKED) ;
			nSpace			= lstrlen (pNewNode->m_strPrefix) ;
			nSpace			= (nSpace > 4)? 4 : nSpace ;
			wsprintf (rszBuffer, TEXT ("%s%c%s = %s"),
						pNewNode->m_strPrefix,
						pNewNode->m_chVowel,
						TEXT("    ") + nSpace,
						(fKatakana)? pNewNode->m_strKatakana : pNewNode->m_strKana) ;
			lvI.pszText		= rszBuffer ;

			pNode		= skkimeConfig_findRomaKanaTableNode (pConfArg, arg.m_strPrefix, nVowel) ;
			if (! skkimeConfig_registerRomaKanaTableNode (pConfArg, pNewNode)) {
				DEBUGPRINTF ((TEXT ("Fatal: Failed in registering new romakanatable-node,\n"))) ;
				FREE (pNewNode) ;	/* fatal */
				return	FALSE ;
			}

			if (pNode != NULL) {
				DEBUGPRINTF ((TEXT ("Change romakanatable-node(%p->%p)\n"), pNode, pNewNode)) ;
				lvfi.flags		= LVFI_PARAM ;
				lvfi.lParam		= (LPARAM) pNode ;
				nItem			= ListView_FindItem (hwndLV, -1, &lvfi) ;
				if (nItem >= 0) {
					lvI.iItem	= nItem ;
					ListView_SetItem (hwndLV, &lvI) ;
				}
				skkimeConfig_unregisterRomaKanaTableNode (pConfArg, pNode) ;
				FREE (pNode) ;
			} else {
				lvI.iItem		= ListView_GetItemCount (hwndLV) ;
				DEBUGPRINTF ((TEXT ("Insert new romakanatable-node(%p/%d)\n"), pNewNode, lvI.iItem)) ;
				ListView_InsertItem (hwndLV, &lvI) ;
				ListView_SortItems  (hwndLV, skkimeConfig_compareRomaKanaTblNode, 0) ;
			}
			PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		}
		break ;

	case	IDC_BUTTON_DELETE:
		if (pNode == NULL || nItem < 0)
			return	FALSE ;
		ListView_DeleteItem (hwndLV, nItem) ;
		skkimeConfig_unregisterRomaKanaTableNode (pConfArg, pNode) ;
		FREE (pNode) ;
		PropSheet_Changed (pConfArg->m_hPropSheetDlg, hDlg) ;
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

INT_PTR CALLBACK
skkimeConfig_dlgEditRomaKanaTbl (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	TDlgEditRomaKanaTableArg*	pArg ;
	HWND	hwndEditPrefix, hwndEditHira, hwndEditKata ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

		pArg			= (TDlgEditRomaKanaTableArg*) lParam ;
		hwndEditPrefix	= GetDlgItem (hDlg, IDC_EDIT_KANAPREFIX) ;
		hwndEditHira	= GetDlgItem (hDlg, IDC_EDIT_HIRAGANA) ;
		hwndEditKata	= GetDlgItem (hDlg, IDC_EDIT_KATAKANA) ;
		if (pArg != NULL) {
		}
		if (hwndEditPrefix != NULL) {
			SendMessage (hwndEditPrefix, EM_LIMITTEXT, (WPARAM) MAX_LENGTH_ROMAKANAPREFIX - 1, 0) ;
			if (pArg != NULL)
				SetWindowText (hwndEditPrefix, pArg->m_strPrefix) ;
		}
		if (hwndEditHira != NULL) {
			SendMessage (hwndEditHira,   EM_LIMITTEXT, (WPARAM) MAX_LENGTH_ROMAKANAKANA - 1, 0) ;
			if (pArg != NULL)
				SetWindowText (hwndEditHira, pArg->m_strKana) ;
		}
		if (hwndEditKata != NULL) {
			SendMessage (hwndEditKata,   EM_LIMITTEXT, (WPARAM) MAX_LENGTH_ROMAKANAKATA - 1, 0) ;
			if (pArg != NULL)
				SetWindowText (hwndEditKata, pArg->m_strKatakana) ;
		}
		return	TRUE ;
	}
	case	WM_COMMAND:
		/*	���[�ށB�Ԃ�l�� global �ϐ����o�R���邵���Ȃ���... */
		switch (LOWORD (wParam)) {
		case	IDOK:
		{
			/*	���ݑI������Ă��� item �𓾂�BCB_ERR �̏ꍇ�� undefined ��
			 *	�Ǝv��...���ȁB*/
			pArg	= (TDlgEditRomaKanaTableArg *)GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				hwndEditPrefix	= GetDlgItem (hDlg, IDC_EDIT_KANAPREFIX) ;
				hwndEditHira	= GetDlgItem (hDlg, IDC_EDIT_HIRAGANA) ;
				hwndEditKata	= GetDlgItem (hDlg, IDC_EDIT_KATAKANA) ;
				pArg->m_strPrefix   [0]	= TEXT ('\0') ;
				pArg->m_strKana     [0]	= TEXT ('\0') ;
				pArg->m_strKatakana [0]	= TEXT ('\0') ;
				if (hwndEditPrefix != NULL)
					GetWindowText (hwndEditPrefix, pArg->m_strPrefix,   MAX_LENGTH_ROMAKANAPREFIX) ;
				if (hwndEditHira != NULL)
					GetWindowText (hwndEditHira,   pArg->m_strKana,     MAX_LENGTH_ROMAKANAKANA) ;
				if (hwndEditKata != NULL)
					GetWindowText (hwndEditKata,   pArg->m_strKatakana, MAX_LENGTH_ROMAKANAKATA) ;
				if (pArg->m_strPrefix [0] == TEXT ('\0')) 
					wParam					= IDCANCEL ;
			}
			/*	fall through */
		}
		case	IDCANCEL:
			EndDialog (hDlg, wParam) ;
			return	TRUE ;
		}
	default:
		break ;
	}
	return	FALSE ;
}

BOOL
skkimeConfig_initControlRomaKanaTableList (
	SkkimeConfigArg*	pConfArg,
	HWND				hwndLV,
	BOOL				fKata)
{
	ListView_DeleteAllItems (hwndLV) ;
	skkimeConfig_initControlRomaKanaOneTable (hwndLV, fKata, pConfArg->m_lstRomaKanaA) ;
	skkimeConfig_initControlRomaKanaOneTable (hwndLV, fKata, pConfArg->m_lstRomaKanaI) ;
	skkimeConfig_initControlRomaKanaOneTable (hwndLV, fKata, pConfArg->m_lstRomaKanaU) ;
	skkimeConfig_initControlRomaKanaOneTable (hwndLV, fKata, pConfArg->m_lstRomaKanaE) ;
	skkimeConfig_initControlRomaKanaOneTable (hwndLV, fKata, pConfArg->m_lstRomaKanaO) ;
	return	TRUE ;
}

BOOL
skkimeConfig_initControlRomaKanaOneTable (
	HWND				hwndLV,
	BOOL				fKatakana,
	ROMAKANATABLENODE*	lstRomaKanaTbl)
{
	ROMAKANATABLENODE*	pNode ;
	int					n, nSpace ;
	LVITEM				lvI ;
	TCHAR				rszBuffer [256 + 16] ;

	lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
	lvI.state		= 0 ; 
	lvI.stateMask	= 0 ;
	n				= ListView_GetItemCount (hwndLV) ;
	pNode			= lstRomaKanaTbl ;
	while (pNode != NULL) {
		lvI.iItem		= n ;
		lvI.iImage		= 0 ;
		lvI.iSubItem	= 0 ;
		lvI.lParam		= (LPARAM) pNode ;
		nSpace			= lstrlen (pNode->m_strPrefix) ;
		nSpace			= (nSpace > 4)? 4 : nSpace ;
		wsprintf (rszBuffer, TEXT ("%s%c%s = %s"),
					pNode->m_strPrefix,
					pNode->m_chVowel,
					TEXT("    ") + nSpace,
					(fKatakana)? pNode->m_strKatakana : pNode->m_strKana) ;
		lvI.pszText		= rszBuffer ;
		if (ListView_InsertItem (hwndLV, &lvI) == -1) {
			DEBUGPRINTF ((TEXT ("ListView_InsertItem() error\n"))) ;
		}
		n		++ ;
		pNode	= pNode->m_pNext ;
	}
	return	TRUE ;
}

/*	�uListView �� DeleteAllItems ����ƃR�X�g���傫���B���[�U�ɂ����炩�ɕ�����B
 *	  item �̐����ς��Ȃ��̂Ȃ�Asetitemtext �Ő؂�ւ���̂��g�v�ɏ]���āA
 *	item text ���̂ݕύX����B
 */
BOOL
skkimeConfig_switchKanaKata (
	HWND	hwndLV,
	BOOL	fKatakana)
{
	ROMAKANATABLENODE*	pNode ;
	int					i, nSpace, nMaxItem ;
	LVITEM				lvI ;
	TCHAR				rszBuffer [256 + 16] ;

	if (hwndLV == NULL)
		return	FALSE ;

	nMaxItem		= ListView_GetItemCount (hwndLV) ;
	for (i = 0 ; i < nMaxItem ; i ++) {
		lvI.mask		= LVIF_PARAM ;
		lvI.iItem		= i ;
		lvI.iSubItem	= 0 ;
		if (ListView_GetItem (hwndLV, &lvI) == TRUE &&
			lvI.lParam != 0) {
			pNode		= (ROMAKANATABLENODE *) lvI.lParam ;
			nSpace		= lstrlen (pNode->m_strPrefix) ;
			nSpace		= (nSpace > 4)? 4 : nSpace ;
			wsprintf (rszBuffer, TEXT ("%s%c%s = %s"),
						pNode->m_strPrefix,
						pNode->m_chVowel,
						TEXT("    ") + nSpace,
						(fKatakana)? pNode->m_strKatakana : pNode->m_strKana) ;
			ListView_SetItemText (hwndLV, i, 0, rszBuffer) ;
		}
	}
	return	TRUE ;
}

int	CALLBACK
skkimeConfig_compareRomaKanaTblNode (
	LPARAM		lParam1,
	LPARAM		lParam2,
	LPARAM		lParamSort)
{
	ROMAKANATABLENODE*	pNode1	= (ROMAKANATABLENODE*) lParam1 ;
	ROMAKANATABLENODE*	pNode2	= (ROMAKANATABLENODE*) lParam2 ;
	LPCTSTR	str1 ;
	LPCTSTR	str2 ;
	int		nCompare ;

	str1	= (pNode1->m_strPrefix != NULL)? pNode1->m_strPrefix : TEXT ("") ;
	str2	= (pNode2->m_strPrefix != NULL)? pNode2->m_strPrefix : TEXT ("") ;

	nCompare	= lstrcmp (str1, str2) ;
	if (nCompare == 0) 
		return	(pNode1->m_chVowel - pNode2->m_chVowel) ;

	return	nCompare ;
	UNREFERENCED_PARAMETER (lParamSort) ;
}

/*========================================================================
 *	private functions
 */
BOOL
skkimeConfig_initRomaKanaTable (
	LPCTSTR				pstrSubKey,
	ROMAKANATABLENODE**	plstTableTop,
	ROMAKANATABLE*		pDefaultTable,
	int					nDefaultTable,
	int					nChVowel)
{
	HKEY				hSubKey ;
	TCHAR				szRegPathInfo [MAX_PATH] ;
	TCHAR				rbyData [MAX_REGVALUE_SIZE] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	int		nIndex ;
	LONG		lResult ;
	int		nPrefixLen, nKanaLen, nKataLen ;
	ROMAKANATABLENODE*	pNode ; 
	ROMAKANATABLENODE*	pLastNode ; 

	ASSERT (pstrSubKey   != NULL) ;
	ASSERT (plstTableTop != NULL) ;

	pLastNode	= NULL ;
	pNode		= NULL ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		BOOL	fError	= FALSE ;

		/*	���[�}�������ϊ��e�[�u�����o�^����Ă���̂Ȃ�c�B*/
		for (nIndex = 0 ; nIndex < INT_MAX ; nIndex ++) {
			dwRegPathInfo	= NELEMENTS (szRegPathInfo) ;
			cbData			= NELEMENTS (rbyData) ;
			lResult	= RegEnumValue (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			/*	szRegPathInfo = "ky" �Ƃ������v���t�B�N�X�ɑ����B
			 *	Value = REG_MULTI_SZ �ŁA������, �Љ����̏��ԁB�����񒷂� 0 �̏ꍇ�ɂ�
			 *	``nul nul'' �ɂȂ��ċ����I�[����Ă��܂���...�擪�ꕶ�����]���ɂ���B
			 *	������\0�Љ���\0\0 �̍\���A�ƁB
			 */
			lResult	= RegQueryValueEx (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ)
				continue ;
			/*	Too big value. */
			if (cbData >= sizeof (rbyData)) 
				continue ;
			cbData	= sizeof (rbyData) ;
			(void) RegQueryValueEx (hSubKey, szRegPathInfo, NULL, NULL, (BYTE*)rbyData, &cbData) ;

			nPrefixLen	= lstrlen (szRegPathInfo) ;
			nKanaLen	= lstrlen (rbyData) ;
			nKataLen	= lstrlen (rbyData + nKanaLen + 1) ;
			/*	�擪�� "_" ���t���Ă�B���ꂪ�����Ȃ�Ă��Ƃ�����̂͂��������B*/
			if (nKanaLen < 1 || nKataLen < 1)
				continue ;

			pNode		= skkimeConfig_newRomaKanaTableNode (nPrefixLen, nKanaLen, nKataLen) ;
			if (pNode == NULL) {
				fError	= TRUE ;
				break ;
			}
			lstrcpy (pNode->m_strPrefix,	szRegPathInfo) ;
			/*	"_" ���Ƃ΂��ăR�s�[����B*/
			lstrcpy (pNode->m_strKana,	(LPCTSTR)rbyData + 1) ;
			lstrcpy (pNode->m_strKatakana,(LPCTSTR)rbyData + nKanaLen + 1 + 1) ;
			pNode->m_chVowel	= nChVowel ;

			pNode->m_pPrev	= pLastNode ;
			if (pLastNode != NULL)
				pLastNode->m_pNext	= pNode ;
			pLastNode		= pNode ;
		}
		RegCloseKey (hSubKey) ;
		if (fError)
			return	FALSE ;
	} else if (pDefaultTable != NULL && nDefaultTable > 0) {
		ROMAKANATABLE*	pTable ;
		int			nPrefixLen, nKanaLen, nKataLen ;

		pTable	= pDefaultTable ;
		/*	�f�t�H���g�̏������s�������B*/
		for (nIndex = 0 ; nIndex < nDefaultTable ; nIndex ++, pTable ++) {
			nPrefixLen	= lstrlen (pTable->prefix)   + 1 ;
			nKanaLen	= lstrlen (pTable->kana)     + 1 ;
			nKataLen	= lstrlen (pTable->katakana) + 1 ;

			pNode		= skkimeConfig_newRomaKanaTableNode (nPrefixLen, nKanaLen, nKataLen) ;
			if (pNode == NULL)
				return	FALSE ;

			/*	MYSTR ���� TSTR �ɕϊ����R�s�[����B������Ƃ��Ă̏I�[�͂��Ă����B*/
			lstrcpy (pNode->m_strPrefix,	 pTable->prefix) ;
			lstrcpy (pNode->m_strKana,	 pTable->kana) ;
			lstrcpy (pNode->m_strKatakana, pTable->katakana) ;
			pNode->m_chVowel	= nChVowel ;
			DEBUGPRINTF ((TEXT ("prefix\"%s\", Kana\"%s\", Kata\"%s\"\n"),
						  pNode->m_strPrefix, pNode->m_strKana, pNode->m_strKatakana)) ;
			pNode->m_pPrev	= pLastNode ;
			if (pLastNode != NULL)
				pLastNode->m_pNext	= pNode ;
			pLastNode		= pNode ;
		}
	}
	if (pLastNode != NULL) {
		pNode	= pLastNode ;
		while (pNode->m_pPrev != NULL)
			pNode	= pNode->m_pPrev ;
		*plstTableTop	= pNode ;
	} else {
		*plstTableTop	= pNode ;
	}
	return	TRUE ;
}

BOOL
skkimeConfig_updateRomaKanaTable (
	LPCTSTR					pstrSubKey,
	ROMAKANATABLENODE*		lstTableTop)
{
	ROMAKANATABLENODE*	pNode ; 
	int	nKataLen, nKanaLen, nTotal ;
	TCHAR	szData [MAX_REGVALUE_SIZE] ;
	HKEY	hSubKey ;

	if (! skkimeConfig_CreateKey (pstrSubKey, TRUE, &hSubKey)) {
		DEBUGPRINTF ((TEXT ("skkimeConfig_updateRomaKanaTable (): create-key(\"%s\") failed\n"),
					  pstrSubKey)) ;
		return	FALSE ;
	}

	pNode	= lstTableTop ;
	while (pNode != NULL) {
		nKanaLen	= (pNode->m_strKana != NULL)?     lstrlen (pNode->m_strKana) : 0 ;
		nKataLen	= (pNode->m_strKatakana != NULL)? lstrlen (pNode->m_strKatakana) : 0 ;
		nTotal		= nKanaLen + nKataLen ;
		if (0 <= nTotal && nTotal < (MAX_REGVALUE_SIZE - 5)) {
			LPTSTR	pDest	= szData ;
			lstrcpy (pDest, TEXT ("_")) ;			pDest ++ ;
			lstrcpy (pDest, pNode->m_strKana) ;		pDest += nKanaLen + 1 ;
			lstrcpy (pDest, TEXT ("_")) ;			pDest ++ ;
			lstrcpy (pDest, pNode->m_strKatakana) ;	pDest += nKataLen + 1 ;
			*pDest	= TEXT ('\0') ;
			if (RegSetValueEx (hSubKey, pNode->m_strPrefix, 0, REG_MULTI_SZ, (BYTE *)szData, sizeof (TCHAR) * (nTotal + 5 /* ``_'' x 2 + NUL x 3*/)) != ERROR_SUCCESS) {
				DEBUGPRINTF ((TEXT ("RegSetValueEx: failed (\"%s\", \"%s\")\n"),
							  pNode->m_strPrefix, szData)) ;
				break ;
			}
		}
		pNode	= pNode->m_pNext ;
	}
	RegCloseKey (hSubKey) ;
	return	pNode == NULL ;
}

ROMAKANATABLENODE*
skkimeConfig_newRomaKanaTableNode (
	int			nPrefixLen,
	int			nKanaLen,
	int			nKataLen)
{
	ROMAKANATABLENODE*	pNode ;

	/*	���̒i�K�ł͂܂� TCHAR �ŊǗ�����BTCHAR �ւ̕ϊ��͍Ō�̒i�K�ŁB
	 *	���ӂ��ׂ��� nKataLen, nKanaLen �ɂ� '\0' �܂Ŋ܂񂾃T�C�Y��������
	 *	����B
	 */
	pNode		= MALLOC (sizeof (ROMAKANATABLENODE) + sizeof (TCHAR) * (nPrefixLen + 1 + nKanaLen + nKataLen)) ;
	if (pNode == NULL)
		return	NULL ;
	pNode->m_strPrefix		= (LPTSTR)(pNode + 1) ;
	pNode->m_strKana		= pNode->m_strPrefix + nPrefixLen + 1 ;
	pNode->m_strKatakana	= pNode->m_strKana   + nKanaLen ;
	pNode->m_pPrev			= NULL ;
	pNode->m_pNext			= NULL ;
	return	pNode ;
}

BOOL
skkimeConfig_registerRomaKanaTableNode (
	SkkimeConfigArg*		pArg,
	ROMAKANATABLENODE*		pNode)
{
	ROMAKANATABLENODE**	pListTop ;
	ROMAKANATABLENODE*		pNextNode ;

	if (pNode == NULL || pArg == NULL)
		return	FALSE ;
	pListTop	= skkimeConfig_getRomaKanaTableListTop (pArg, pNode->m_chVowel) ;
	if (pListTop == NULL)	/* fatal */
		return	FALSE ;
	pNextNode		= *pListTop ;
	pNode->m_pNext	= pNextNode ;
	if (pNextNode != NULL)
		pNextNode->m_pPrev	= pNode ;
	*pListTop		= pNode ;
	return	TRUE ;
}

BOOL
skkimeConfig_unregisterRomaKanaTableNode (
	SkkimeConfigArg*		pArg,
	ROMAKANATABLENODE*		pNode)
{
	ROMAKANATABLENODE**		pListTop ;
	ROMAKANATABLENODE*		pPrevNode ;
	ROMAKANATABLENODE*		pNextNode ;

	if (pNode == NULL || pArg == NULL)
		return	FALSE ;
	pListTop	= skkimeConfig_getRomaKanaTableListTop (pArg, pNode->m_chVowel) ;
	if (pListTop == NULL)	/* fatal */
		return	FALSE ;

	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode == NULL) {
		if (pNode != *pListTop) {
			DEBUGPRINTF ((TEXT ("fatal\n"))) ;
			return	FALSE ;
		}
		*pListTop	= pNextNode ;
	} else {
		pPrevNode->m_pNext	= pNextNode ;
	}
	if (pNextNode != NULL) 
		pNextNode->m_pPrev	= pPrevNode ;
	pNode->m_pPrev	= NULL ;
	pNode->m_pNext	= NULL ;
	return	TRUE ;
}

ROMAKANATABLENODE*
skkimeConfig_findRomaKanaTableNode (
	SkkimeConfigArg*		pArg,
	LPCTSTR					strPrefix,
	int						nChVowel)
{
	ROMAKANATABLENODE**		plstTop ;
	ROMAKANATABLENODE*		pNode ;

	if (strPrefix == NULL || pArg == NULL)	/* fatal */
		return	NULL ;
	plstTop	= skkimeConfig_getRomaKanaTableListTop (pArg, nChVowel) ;
	if (plstTop == NULL)	/* fatal */
		return	NULL ;
	pNode	= *plstTop ;
	while (pNode != NULL) {
		if (pNode->m_strPrefix != NULL && !lstrcmp (pNode->m_strPrefix, strPrefix))
			return	pNode ;	/* found */
		pNode	= pNode->m_pNext ;
	}
	return	NULL ;	/* not found */
}

ROMAKANATABLENODE**
skkimeConfig_getRomaKanaTableListTop (
	SkkimeConfigArg*		pArg,
	int					chVowel)
{
	switch (chVowel) {
	case	TEXT ('a'):
		return	&pArg->m_lstRomaKanaA ;
	case	TEXT ('i'):
		return	&pArg->m_lstRomaKanaI ;
	case	TEXT ('u'):
		return	&pArg->m_lstRomaKanaU ;
	case	TEXT ('e'):
		return	&pArg->m_lstRomaKanaE ;
	case	TEXT ('o'):
		return	&pArg->m_lstRomaKanaO ;
	default:
		break ;
	}
	return	NULL ;
}

