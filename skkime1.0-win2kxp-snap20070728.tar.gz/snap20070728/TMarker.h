#if !defined (TMarker_h)
#define	TMarker_h

typedef struct tagTMarker {
	int			_iPosition ;
	BOOL		_fCursor ;
	BOOL		_fValid ;
}	CTMarker ;

BOOL	TMarker_Init	 	(CTMarker*, BOOL) ;
int		TMarker_GetPosition	(CTMarker*) ;
BOOL	TMarker_Forward		(CTMarker*, int) ;
BOOL	TMarker_Backward	(CTMarker*, int) ;
BOOL	TMarker_IsCursor	(CTMarker*) ;
BOOL	TMarker_IsValidp	(CTMarker*) ;
BOOL	TMarker_SetPosition	(CTMarker*, const CTMarker*) ;
void	TMarker_Invalidate	(CTMarker*) ;

#endif

