#include "local.h"
#include <stdio.h>
#include <stdlib.h>
#include "jisyo.h"
#include "localjisyo.h"
#include "cstring.h"
#include "kstring.h"
#include "kfile.h"

#define	OKURIARI_STR	";; okuri-ari entries."
#define	OKURINASI_STR	";; okuri-nasi entries."

/*	�v���g�^�C�v�錾�B*/
static	BOOL	skkLocalJisyo_search		(SkkJisyo*, const Char*, int, BOOL, TVarbuffer*) ;
static	BOOL	skkLocalJisyo_record		(SkkJisyo*, const Char*, int, BOOL, const Char*, int) ;
static	BOOL	skkLocalJisyo_purge			(SkkJisyo*, const Char*, int, BOOL, const Char*, int) ;
static	BOOL	skkLocalJisyo_save			(SkkJisyo*) ;
static	BOOL	skkLocalJisyo_completion	(SkkJisyo*, const Char*, int, TVarbuffer*) ;
static	BOOL	skkLocalJisyo_destroy		(SkkJisyo*) ;
static	LPCTSTR	skkLocalJisyo_getPath		(SkkJisyo*) ;

static	BOOL	skkLocalJisyo_load			(SkkLocalJisyo*, LPCTSTR) ;
static	BOOL	skkLocalJisyo_initJisyo		(SkkLocalJisyo*) ;
static	int		skkLocalJisyo_findAnsiAtLineTop	(SkkLocalJisyo*, int, const char*) ;
static	int		skkLocalJisyo_findCandidate	(SkkLocalJisyo*, int, int, const Char*, int) ;
static	BOOL	skkLocalJisyo_findCompletion(TBufStringMarker*, TVarbuffer*) ;
static	BOOL	skkLocalJisyo_prepareDirectory	(LPCTSTR) ;
static	BOOL	skkLocalJisyo_moveLineToTop	(SkkLocalJisyo*, int, BOOL) ;

/*	VTBL
 */
static SkkJisyoFunc		sLocalJisyoProcTbl	= {
	skkLocalJisyo_search,
	skkLocalJisyo_completion,
	skkLocalJisyo_record,
	skkLocalJisyo_purge,
	skkLocalJisyo_save,
	skkLocalJisyo_destroy,
	skkLocalJisyo_getPath,
} ;

SkkJisyo*
SkkLocalJisyo_Create (
	register const Char*	pFileName,
	register int			nFileName)
{
	TCHAR					strPath [PATH_MAX + 1] ;
	register SkkJisyo*		pJisyo ;
	register SkkLocalJisyo*	pLocalJisyo ;

	if (nFileName > PATH_MAX)
		return	NULL ;

#if defined (UNICODE)
	internal2wstr (strPath, ARRAYSIZE (strPath) - 1, pFileName, nFileName) ;
#else
	cstrtostr (strPath, pFileName, nFileName) ;
#endif
	strPath [nFileName]	= '\0' ;
#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("SkkLocalJisyo_Create (localjisyo => \"%s\")\n"), strPath)) ;
#endif

	pJisyo	= MALLOC (sizeof (SkkJisyo) + sizeof (SkkLocalJisyo)) ;
	if (pJisyo == NULL)
		return	NULL ;

	pJisyo->m_pVtbl		= &sLocalJisyoProcTbl ;
	pLocalJisyo			= (SkkLocalJisyo *)(pJisyo + 1) ;
	memcpy (pLocalJisyo->m_tszPath, strPath, sizeof (TCHAR) * PATH_MAX) ;
	pLocalJisyo->m_nOkuriAriPos		= 0 ;
	pLocalJisyo->m_nOkuriNasiPos	= 0 ;
	pLocalJisyo->m_pNext			= NULL ;
	if (TFAILED (TBufString_Initialize (&pLocalJisyo->m_bufJisyo))) {
		FREE (pJisyo) ;
		return	NULL ;
	}

	if (TFAILED (skkLocalJisyo_load (pLocalJisyo, strPath))) {
		/* �����t�@�C�������݂��Ȃ���΁A���Ƃ�����������ɍ��B*/
		/* ��x�o�b�t�@������������B*/
		TBufString_Uninitialize (&pLocalJisyo->m_bufJisyo) ;
		TBufString_Initialize   (&pLocalJisyo->m_bufJisyo) ;
		skkLocalJisyo_initJisyo (pLocalJisyo) ;
	}
	pLocalJisyo->m_fModified		= FALSE ;
	return	pJisyo ;
}

SkkJisyo*
SkkLocalJisyo_CreateT (
	register LPCTSTR		strPath)
{
	register int			nstrPath ;
	register SkkJisyo*		pJisyo ;
	register SkkLocalJisyo*	pLocalJisyo ;

	if (strPath == NULL)
		return	NULL ;
	nstrPath	= lstrlen (strPath) ;
	if (nstrPath > PATH_MAX)
		return	NULL ;

#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("SkkLocalJisyo_CreateT (localjisyo => \"%s\")\n"), strPath)) ;
#endif
	pJisyo	= MALLOC (sizeof (SkkJisyo) + sizeof (SkkLocalJisyo)) ;
	if (pJisyo == NULL)
		return	NULL ;

	pJisyo->m_pVtbl		= &sLocalJisyoProcTbl ;
	pLocalJisyo			= (SkkLocalJisyo *)(pJisyo + 1) ;
	lstrcpy (pLocalJisyo->m_tszPath, strPath) ;
	/*memcpy (pLocalJisyo->m_tszPath, strPath, sizeof (TCHAR) * PATH_MAX) ;*/
	pLocalJisyo->m_nOkuriAriPos		= 0 ;
	pLocalJisyo->m_nOkuriNasiPos	= 0 ;
	pLocalJisyo->m_pNext			= NULL ;
	if (TFAILED (TBufString_Initialize (&pLocalJisyo->m_bufJisyo))) {
		FREE (pJisyo) ;
		return	NULL ;
	}

	if (TFAILED (skkLocalJisyo_load (pLocalJisyo, strPath))) {
		/* �����t�@�C�������݂��Ȃ���΁A���Ƃ�����������ɍ��B*/
		/* ��x�o�b�t�@������������B*/
		TBufString_Uninitialize (&pLocalJisyo->m_bufJisyo) ;
		TBufString_Initialize   (&pLocalJisyo->m_bufJisyo) ;
		skkLocalJisyo_initJisyo (pLocalJisyo) ;
	}
	return	pJisyo ;
}

/*========================================================================
 *	�X�̎����̑���B
 *========================================================================*/
BOOL
skkLocalJisyo_search (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register BOOL			fOkuri,
	register TVarbuffer*	pvbuf)
{
	register SkkLocalJisyo*	pJisyo ;
	register int	nStartPos, nEndPos, nPos ;
	TBufStringMarker	mk ;
	Char				cc, chPrev ;
	BOOL				bDuringAnnotation ;

	pJisyo		= (SkkLocalJisyo *)(pSkkJisyo + 1) ;
	nStartPos	= fOkuri? pJisyo->m_nOkuriAriPos  : pJisyo->m_nOkuriNasiPos ;
	nEndPos		= fOkuri? pJisyo->m_nOkuriNasiPos : INT_MAX ;
	nPos		= skkLocalJisyo_findCandidate (pJisyo, nStartPos, nEndPos, pKey, nKey) ;
	if (nPos < 0) {
		/*	Not found */
		return	TRUE ;
	}
	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nPos, &mk) ))
		return	FALSE ;
	while (cc = TBufStringMarker_GetChar (&mk), 
		   cc != (Char) -1 && cc != '/' && cc != '\n') 
		TBufStringMarker_Forward (&mk, 1) ;
	if (cc != '/')
		return	FALSE ;

	chPrev				= '\0' ;
	bDuringAnnotation	= FALSE ;
	do {
		if (TFAILED (TVarbuffer_Add (pvbuf, &cc, 1)))
			return	FALSE ;
		if (TFAILED (TBufStringMarker_Forward (&mk, 1)))
			break ;
		cc = TBufStringMarker_GetChar (&mk) ;

		switch (cc) {
			case	'[':
				if (fOkuri && chPrev == '/' && ! bDuringAnnotation)
					goto	exit_loop ;
				break ;
			case	'/':
				bDuringAnnotation	= FALSE ;
				break ;
			case	';':
				bDuringAnnotation	= TRUE ;
				break ;
			default:
				break ;
		}
		chPrev	= cc ;
	} while (cc != (Char) -1 && cc != '\n') ; 
	
exit_loop:
	return	TRUE ;
}

BOOL
skkLocalJisyo_completion (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register TVarbuffer*	pvbuf)
{
	register SkkLocalJisyo*	pJisyo	= (SkkLocalJisyo *)(pSkkJisyo + 1) ;
	register int			nPos ;
	TBufStringMarker		mk ;
	Char					cc ;
	static const Char		chSEPARATOR	= ' ' ;	/* separator �� space */

	nPos	= pJisyo->m_nOkuriNasiPos ;
	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nPos, &mk) ))
		return	FALSE ;

	while (cc = TBufStringMarker_GetChar (&mk), cc != (Char) -1) {
		if (cc != ';'){
			register const Char*	ptr		= pKey ;
			register int			nptr	= nKey ;

			while (nptr > 0){
				if (cc == (Char) -1 || cc != *ptr)
					break ;
				ptr		++ ;
				nptr	-- ;
				TBufStringMarker_Forward (&mk, 1) ;
				cc	= TBufStringMarker_GetChar (&mk) ;
			}
			if (nptr == 0) {
				if (TFAILED (TVarbuffer_Add (pvbuf, &chSEPARATOR, 1)) ||
					TFAILED (TVarbuffer_Add (pvbuf, pKey, nKey)) ||
					TFAILED (skkLocalJisyo_findCompletion (&mk, pvbuf)))
					return	FALSE ;
				continue ;
			}
		}
		/*	���s�܂ŃX�L�b�v����B*/
		while (cc != '\n' && cc != '\r' && cc != (Char) -1) {
			TBufStringMarker_Forward (&mk, 1) ;
			cc	= TBufStringMarker_GetChar (&mk) ;
		}
		/*	���s�̊Ԃ̓X�L�b�v����B*/
		while (cc == '\n' || cc == '\r') {
			TBufStringMarker_Forward (&mk, 1) ;
			cc	= TBufStringMarker_GetChar (&mk) ;
		}
		/*	�o�b�t�@�̍Ō�܂œ��B�������H */
		if (cc == (Char) -1)
			break ;
	}
	if (TVarbuffer_GetUsage (pvbuf) > 0) 
		return	TVarbuffer_Add (pvbuf, &chSEPARATOR, 1) ;
	return	TRUE ;
}

/*	�ϊ����ʂ̓o�^���s���Bauto-okuri �ɂ͑Ή����Ȃ��B
 */
BOOL
skkLocalJisyo_record (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register BOOL			fOkuri,
	register const Char*	pResult,
	register int			nResult)
{
	register SkkLocalJisyo*	pJisyo	= (SkkLocalJisyo *)(pSkkJisyo + 1) ;
	register int	nStartPos, nEndPos, nPos, nInsert, nQuote ;
	register Char	cc ;
	register BOOL	fRetval	= FALSE ;
	TVarbuffer			vbufWord ;
	TBufStringMarker	mk ;

	DEBUGPRINTF ((TEXT ("SkkLocalJisyo_Record (%p, %p, %d, %d, %p, %d)\n"),
				 pJisyo, pKey, nKey, fOkuri, pResult, nResult)) ;

	if (TFAILED (TVarbuffer_Initialize (&vbufWord, sizeof (Char))))
		return	FALSE ;

	/*	���͕������ quote ����B*/
	nQuote		= quoteCstring (NULL, pResult, nResult) ;
	if (nQuote > 0) {
		register Char*	strWord ;
		
		if (TFAILED (TVarbuffer_Require (&vbufWord, nQuote)))
			return	FALSE ;

		strWord	= TVarbuffer_GetBuffer (&vbufWord) ;
		(void) quoteCstring (strWord, pResult, nResult) ;
		pResult	= strWord ;
		nResult	= nQuote ;
	}

	/*	key ����� result �� check ���� unicode �����ɂ���K�v�����邩
	 *	check ����B
	 *	����� internal char �ɕϊ��������� unicode ���瓮�����Ȃ���������
	 *	�����邩�ǂ����A���画�f�ł���B
	 */
	if (internalStringContainsUnicodeCharp (pKey, nKey) ||
		internalStringContainsUnicodeCharp (pResult, nResult))
		pJisyo->m_fUnicode	= TRUE ;

	nStartPos	= fOkuri? pJisyo->m_nOkuriAriPos  : pJisyo->m_nOkuriNasiPos ;
	nEndPos		= fOkuri? pJisyo->m_nOkuriNasiPos : INT_MAX ;
	nPos		= skkLocalJisyo_findCandidate (pJisyo, nStartPos, nEndPos, pKey, nKey) ;
	if (nPos < 0) {
		/*	���̍s�̐擪�ɂ��� insert ���đ��v�B*/
		nPos	= nStartPos ;
		if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nPos, &mk) ))
			goto	exit_record ;
		while (cc = TBufStringMarker_GetChar (&mk), 
			   cc != (Char) -1 && cc != '\n') {
			TBufStringMarker_Forward (&mk, 1) ;
			nPos	++ ;
		}
		if (cc == (Char) -1) {
			DEBUGPRINTF ((TEXT ("Fatal, unexpected end of buffer.\n"))) ;
			goto	exit_record ;
		}
		TBufStringMarker_Forward (&mk, 1) ;
		nPos	++ ;

		/*	``������ /���/\n'' �����B*/
		TBufStringMarker_InsertString (&mk, pKey, nKey) ;
		TBufStringMarker_InsertChar   (&mk, ' ', 1) ;
		TBufStringMarker_InsertChar   (&mk, '/', 1) ;
		TBufStringMarker_InsertString (&mk, pResult, nResult) ;
		TBufStringMarker_InsertChar   (&mk, '/', 1) ;
		TBufStringMarker_InsertChar   (&mk, '\n', 1) ;
		nInsert	= nKey + 1 + 1 + nResult + 1 + 1 ;
	} else {
		register const Char*	ptr ;
		register int			nptr ;

		if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nPos, &mk) ))
			goto	exit_record ;
		while (cc = TBufStringMarker_GetChar (&mk), 
			   cc != (Char) -1 && cc != '/' && cc != '[' && cc != '\n') 
			TBufStringMarker_Forward (&mk, 1) ;
		if (cc != '/') {
			DEBUGPRINTF ((TEXT ("Fatal, separator not found.\n"))) ;
			goto	exit_record ;
		}
		
		/*	�܂��擪�ɍ���̕ϊ����ʂ�}������B*/
		TBufStringMarker_InsertChar   (&mk, '/', 1) ;
		TBufStringMarker_InsertString (&mk, pResult, nResult) ;
		nInsert	= 1 + nResult ;

		/*	���̈ʒu�� '/' �ł͂��܂��Ă���B��������s���܂ł�
		 *	�ϊ����ʂ����邩�ǂ���������B*/
		TBufStringMarker_Forward (&mk, 1) ;
		do {
			ptr		= pResult ;
			nptr	= nResult ;
			/*	�܂� '/' �܂ł��r����B�����ł� '[' �͍��B*/
			while (cc = TBufStringMarker_GetChar (&mk), 
				   cc != (Char)-1 && /*cc != '[' &&*/ cc != '/' && cc != '\n' &&
				   cc == *ptr && nptr > 0) {
				TBufStringMarker_Forward (&mk, 1) ;
				ptr		++ ;
				nptr	-- ;
			}
			if (nptr == 0) {
				cc = TBufStringMarker_GetChar (&mk) ;
				if (cc == '/') {
					/*	found */
					TBufStringMarker_Backward (&mk, nResult + 1) ;
					TBufStringMarker_DeleteChar (&mk, nResult + 1) ;
					nInsert	-= (nResult + 1) ;
					break ;
				}
			}
			/*	���� '/' �܂œǂݐi�߂�B*/
			while (cc != '/' && cc != (Char)-1 && cc != '\n') {
				TBufStringMarker_Forward (&mk, 1) ;
				cc = TBufStringMarker_GetChar (&mk) ;
			}
			/*	'/' �ł���ԁA�ǂݔ�΂��B*/
			while (cc == '/') {
				TBufStringMarker_Forward (&mk, 1) ;
				cc = TBufStringMarker_GetChar (&mk) ;
			}
			/*	'/' �̒���� '[' �͏I�����Ӗ�����Ƃ���B*/
		} while (cc != (Char) -1 && cc != '\n' && cc != '[') ;

		/*	nKey ��������̂́A
		 *	���� nPos ��
		 *		�ւ񂩂� /�ϊ�/
		 *	           ��
		 *	�́u��v�Ɓu/�v�̊Ԃ̋󔒂��w������B
		 */
		fRetval	= skkLocalJisyo_moveLineToTop (pJisyo, nPos - nKey, fOkuri) ;
	}
	if (fOkuri)
		pJisyo->m_nOkuriNasiPos	+= nInsert ;
	pJisyo->m_fModified	= TRUE ;
	fRetval	= TRUE ;
 exit_record:
	TVarbuffer_Uninitialize (&vbufWord) ;
	return	fRetval ;
}

/*	�ϊ����ʂ̓o�^���s���Bauto-okuri �ɂ͑Ή����Ȃ��B
 */
BOOL
skkLocalJisyo_purge (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register BOOL			fOkuri,
	register const Char*	pResult,
	register int			nResult)
{
	register SkkLocalJisyo*	pJisyo	= (SkkLocalJisyo *)(pSkkJisyo + 1) ;
	register int	nStartPos, nEndPos, nPos, nRemove, nCandPos, nLineTop ;
	register Char	cc ;
	TBufStringMarker	mk ;

	nStartPos	= fOkuri? pJisyo->m_nOkuriAriPos  : pJisyo->m_nOkuriNasiPos ;
	nEndPos		= fOkuri? pJisyo->m_nOkuriNasiPos : INT_MAX ;
	nPos		= skkLocalJisyo_findCandidate (pJisyo, nStartPos, nEndPos, pKey, nKey) ;
	if (nPos < 0) 
		return	FALSE ;

	nLineTop	= nPos - nKey ;
	assert (nLineTop >= 0) ;

	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nPos, &mk)))
		return	FALSE ;
	while (cc = TBufStringMarker_GetChar (&mk), 
		   cc != (Char) -1 && cc != '/' && cc != '[' && cc != '\n') {
		TBufStringMarker_Forward (&mk, 1) ;
		nPos	++ ;
	}
	if (cc != '/')
		return	FALSE ;

	/*	���̈ʒu�� '/' �ł͂��܂��Ă���B��������s���܂ł�
	 *	�ϊ����ʂ����邩�ǂ���������B*/
	TBufStringMarker_Forward (&mk, 1) ;
	nPos	++ ;
	nCandPos	= nPos ;

	do {
		register const Char*	ptr		= pResult ;
		register int			nptr	= nResult ;

		while (cc = TBufStringMarker_GetChar (&mk), 
			   cc != (Char)-1 && cc != '/' && cc == *ptr && nptr > 0) {
			TBufStringMarker_Forward (&mk, 1) ;
			ptr		++ ;
			nptr	-- ;
		}
		if (nptr == 0) {
			cc = TBufStringMarker_GetChar (&mk) ;
			if (cc == '/') 
				break ;
		}
		while (cc != '/' && cc != (Char)-1 && cc != '\n') {
			TBufStringMarker_Forward (&mk, 1) ;
			cc = TBufStringMarker_GetChar (&mk) ;
		}
		if (cc == '/')
			TBufStringMarker_Forward (&mk, 1) ;
	} while (cc != (Char) -1 && cc != '\n' && cc != '[') ;

	if (cc == (Char) -1 || cc == '\n' || cc == '[')
		return	FALSE ;

	/*	found�B�o�^����Ă���ϊ����ʂ��폜����B*/
	TBufStringMarker_Backward   (&mk, nResult + 1) ;
	TBufStringMarker_DeleteChar (&mk, nResult + 1) ;
	nRemove	= nResult + 1 ;

	/*	�S�Ă̒P�ꂪ�폜���ꂽ�̂��ǂ������`�F�b�N����B*/
	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nCandPos, &mk)))
		return	FALSE ;
	
	/*	������ '/' or '[' or '\n' �Ȃ�����͊������Ă���B*/
	cc	= TBufStringMarker_GetChar (&mk) ;
	if (cc == '/' || cc == '[' || cc == '\n') {
		TBufStringMarker	mkLineTop ;
		register int		nLineLen ;

		if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nLineTop, &mkLineTop)))
			return	FALSE ;

		mk			= mkLineTop ;
		nLineLen	= 0 ;
		while (cc = TBufStringMarker_GetChar (&mk), 
			   cc != (Char) -1 && cc != '\n') {
			TBufStringMarker_Forward (&mk, 1) ;
			nLineLen	++ ;
		}
		if (cc == '\n') 
			nLineLen	++ ;

		TBufStringMarker_DeleteChar (&mkLineTop, nLineLen) ;
		nRemove	+= nLineLen ;
	}
	if (fOkuri)
		pJisyo->m_nOkuriNasiPos	-= nRemove ;
	pJisyo->m_fModified	= TRUE ;
	return	TRUE ;
}

BOOL
skkLocalJisyo_save (
	register SkkJisyo*		pSkkJisyo)
{
	register SkkLocalJisyo*	pJisyo	= (SkkLocalJisyo *)(pSkkJisyo + 1) ;
	register FILE*		fp ;
	TBufStringMarker	mk ;
	char				buffer [1024] ;
	register Char		cc ;
	register char*		ptr ;
	register int		nptr, nctext ;
	KANJISTATEMACHINE	ksm ;

	assert (pJisyo != NULL) ;

	if (! pJisyo->m_fModified)
		return	TRUE ;

	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, 0, &mk))) 
		return	FALSE ;

	fp		= _tfopen (pJisyo->m_tszPath, TEXT("wb")) ;
#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("_tfopen => \"%s\"\n"), pJisyo->m_tszPath)) ;
#endif
	if (fp == NULL) {
		skkLocalJisyo_prepareDirectory (pJisyo->m_tszPath) ;
		fp	= _tfopen (pJisyo->m_tszPath, TEXT("wb")) ;
		if (fp == NULL)
			return	FALSE ;
	}

	/*	������ unicode �Ŏ����Ȃ���΂Ȃ�Ȃ������f����B*/
	if (pJisyo->m_fUnicode) {
		/*	unicode �ɂ���̂Ȃ�A0xFF 0xFE �ŊJ�n����K�v������B*/
		InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_UNICODE) ;
		buffer [0]	= 0xFF ;
		buffer [1]	= 0xFE ;
		fwrite (buffer, sizeof (char), 2, fp) ;
	} else {
		InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_ISO2022JP2) ;
	}
	ptr		= buffer ;
	nptr	= 0 ;
	/*	�ށAcoding-system �ǂ����悤���H */
	while (cc = TBufStringMarker_GetChar (&mk), cc != EOF) {
		TBufStringMarker_Forward (&mk, 1) ;
		nctext	= RtransferKanjiFiniteStateMachine (&ksm, cc, ptr) ;
		ptr		+= nctext ;
		nptr	+= nctext ;
		if (nptr < (sizeof (buffer) - 16)) {
			fwrite (buffer, 1, nptr, fp) ;
#if defined (DEBUG)
			fwrite (buffer, 1, nptr, stdout) ;
#endif
			ptr		= buffer ;
			nptr	= 0 ;
		}
	}
	if (nptr > 0) {
		fwrite (buffer, 1, nptr, fp) ;
#if defined (DEBUG)
		fwrite (buffer, 1, nptr, stdout) ;
#endif
	}
	fclose (fp) ;
	pJisyo->m_fModified	= FALSE ;
	return	TRUE ;
}

BOOL
skkLocalJisyo_destroy (
	register SkkJisyo*		pSkkJisyo)
{
	register SkkLocalJisyo*	pJisyo	= (SkkLocalJisyo *)(pSkkJisyo + 1) ;

	TBufString_Uninitialize (&pJisyo->m_bufJisyo) ;
	FREE (pSkkJisyo) ;
	return	TRUE ;
}

LPCTSTR
skkLocalJisyo_getPath (
	register SkkJisyo*			pSkkJisyo)
{
	register SkkLocalJisyo*	pJisyo	= (SkkLocalJisyo *)(pSkkJisyo + 1) ;

	return	pJisyo->m_tszPath ;
}

/*
 */
BOOL
skkLocalJisyo_load (
	register SkkLocalJisyo*		pJisyo,
	register LPCTSTR			pFileName)
{
	KFILE				kf ;
	TBufStringMarker	mk ;
	register Char		cc ;
	register BOOL		fResult ;
	register int		nOkuriAri, nOkuriNasi ;
#if defined (DEBUG)
	register int		nCount ;
#endif

	assert (pJisyo != NULL) ;
	assert (pFileName != NULL) ;

	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, 0, &mk) ))
		return	FALSE ;

	KFile_Init (&kf) ;
	if (TFAILED (KFile_Open (&kf, pFileName, -1))) 
		return	FALSE ;
	KFile_Rewind (&kf) ;

	/*	Unicode �������ꍇ�ɂ́Asave �̎��ɂ� unicode �ɂȂ�悤�A�����
	 *	�L�����Ă����B
	 */
	pJisyo->m_fUnicode	= (KFile_GetCodingSystem (&kf) == KCODING_SYSTEM_UNICODE) ;
	
	fResult	= TRUE ;
#if defined (DEBUG)
	nCount	= 0 ;
#endif
	while (cc = KFile_Getc (&kf), cc != EOF) {
		if (TFAILED (TBufStringMarker_InsertChar (&mk, cc, 1))) {
			DEBUGPRINTF ((TEXT ("skkLocalJisyo_load: insert-char failed.\n"))) ;
			break ;
		}
#if defined (DEBUG)
		nCount	++ ;
#endif
	}
	fResult	= (cc == EOF) ;
	KFile_Close (&kf) ;
#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("skkLocalJisyo_load: read-chars = %d\n"), nCount)) ;
#endif

	/*	����J�n�ʒu�Ƒ���Ȃ��J�n�ʒu��T���B����2�����݂��Ȃ�
	 *	�ꍇ�Ɂu�����͉��Ă���v�Ƃ݂Ȃ��B
	 */
	nOkuriAri	= skkLocalJisyo_findAnsiAtLineTop (pJisyo, 0, OKURIARI_STR) ;
	nOkuriNasi	= skkLocalJisyo_findAnsiAtLineTop (pJisyo, nOkuriAri, OKURINASI_STR) ;
	DEBUGPRINTF ((TEXT ("OkuriAri = %d, OkuriNasi = %d\n"), nOkuriAri, nOkuriNasi)) ;
	if (nOkuriAri < 0 || nOkuriNasi < 0) 
		return	FALSE ;

	pJisyo->m_nOkuriAriPos	= nOkuriAri ;
	pJisyo->m_nOkuriNasiPos	= nOkuriNasi ;
	return	TRUE ;
}

/*	
 */
int
skkLocalJisyo_findAnsiAtLineTop (
	register SkkLocalJisyo*	pJisyo,
	register int			nStartPos,
	register const char*	pString)
{
	TBufStringMarker		mk ;
	register int			nPos ;
	register const char*	ptr ;
	register Char			cc, chTop ;

	assert (pJisyo  != NULL) ;
	assert (pString != NULL) ;

	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nStartPos, &mk)))
		return	-1 ;

	/*	�s�����當���񂪈�v���邩�ǂ����𔻒肷��B*/
	nPos	= nStartPos ;
	chTop	= Char_MakeAscii (*pString) ;
	while (cc = TBufStringMarker_GetChar (&mk), cc != (Char) -1) {
		if (cc == chTop) {
			TBufStringMarker_Forward (&mk, 1) ;
			nPos	++ ;

			ptr		= pString + 1 ;
			while (*ptr != '\0') {
				cc	= TBufStringMarker_GetChar (&mk) ;
				DEBUGPRINTF ((TEXT ("findAnsiAtLineTop (%d): cc = 0x%08x, *ptr = %d\n"), nPos, (unsigned int)cc, (int)*ptr)) ;
				if (Char_DifferenceAscii (cc, *ptr) != 0)
					break ;
				TBufStringMarker_Forward (&mk, 1) ;
				nPos	++ ;
				ptr		++ ;
			}
			if (*ptr == '\0') {
				/*	���t�������B*/
				return	nPos ;
			}
		}

		/*	���̍s���܂ňړ�����B*/
		while (cc != (Char)-1 && cc != '\n') {
			TBufStringMarker_Forward (&mk, 1) ;
			nPos	++ ;
			cc = TBufStringMarker_GetChar (&mk) ;
		}
		TBufStringMarker_Forward (&mk, 1) ;
		nPos	++ ;
	}
	return	-1 ;
}

/*	���[�U������������Ԃɐݒ肷��B
 */
BOOL
skkLocalJisyo_initJisyo (
	register SkkLocalJisyo*	pJisyo)
{
	TBufStringMarker		mk ;
	register const char*	ptr ;
	static const char		sstrInitialJisyoContent []	= OKURIARI_STR "\n" OKURINASI_STR "\n" ;
	static int				snOkuriNasiPos	= -1 ;

	assert (pJisyo != NULL) ;

	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, 0, &mk)))
		return	FALSE ;

	ptr	= sstrInitialJisyoContent ;
	while (*ptr != '\0') {
		if (TFAILED (TBufStringMarker_InsertChar (&mk, Char_MakeAscii (*ptr), 1)))
			return	FALSE ;
		ptr	++ ;
	}
	pJisyo->m_nOkuriAriPos	= 0 ;
	/*	������Ƌꂵ���R�[�h������(�{���̓R���p�C�����ɕ������
	 *	���ǁA��𔲂��Ĉ�x���� strlen �𑖂点��B*/
	if (snOkuriNasiPos < 0)
		snOkuriNasiPos		= strlen (OKURIARI_STR "\n") ;
	pJisyo->m_nOkuriNasiPos	= snOkuriNasiPos ;

	pJisyo->m_fUnicode		= TRUE ;	/* �V�K�ɍ��ꍇ�ɂ� unicode */
	return	TRUE ;
}

/*	
 */
int
skkLocalJisyo_findCandidate (
	register SkkLocalJisyo*	pJisyo,
	register int			nStartPos,
	register int			nEndPos,
	register const Char*	pString,
	register int			nString)
{
	TBufStringMarker		mk ;
	register int			nPos, nptr ;
	register const Char*	ptr ;
	register Char			chTop, cc ;

	assert (pJisyo  != NULL) ;
	assert (pString != NULL) ;

	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nStartPos, &mk)))
		return	-1 ;

	/*	�s�����當���񂪈�v���邩�ǂ����𔻒肷��B*/
	nPos	= nStartPos ;
	chTop	= *pString ;
	while (cc = TBufStringMarker_GetChar (&mk), 
		   nPos < nEndPos && cc != (Char) -1) {
		if (cc == chTop) {
			TBufStringMarker_Forward (&mk, 1) ;
			nPos	++ ;

			ptr		= pString + 1 ;
			nptr	= nString - 1 ;
			while (nptr > 0) {
				cc	= TBufStringMarker_GetChar (&mk) ;
				if (cc != *ptr)
					break ;
				TBufStringMarker_Forward (&mk, 1) ;
				nPos	++ ;
				ptr		++ ;
				nptr	-- ;
			}
			if (nptr <= 0) {
				/*	���t�������B*/
				cc	= TBufStringMarker_GetChar (&mk) ;
				if (cc == ' ')
					return	nPos ;
			}
		}
		
		/*	���̍s���܂ňړ�����B*/
		while (cc != '\n' && cc != (Char) -1 && nPos < nEndPos) {
			TBufStringMarker_Forward (&mk, 1) ;
			nPos	++ ;
			cc = TBufStringMarker_GetChar (&mk) ;
		}
		TBufStringMarker_Forward (&mk, 1) ;
		nPos	++ ;
	}
	return	-1 ;
}

BOOL
skkLocalJisyo_findCompletion (
	register TBufStringMarker*	pMarker,
	register TVarbuffer*		pvbuf)
{
	register Char	cc ;
	register int	nPos ;
	Char			rszBuffer [16] ;

	nPos	= 0 ;
	while (cc = TBufStringMarker_GetChar (pMarker),
		   cc != (Char)-1 && cc != ' ' && cc != '[' && cc != '\n' && cc != '\r') {
		if (nPos >= ARRAYSIZE (rszBuffer)) {
			if (TFAILED (TVarbuffer_Add (pvbuf, rszBuffer, nPos)))
				return	FALSE ;
			nPos	= 0 ;
		}
		TBufStringMarker_Forward (pMarker, 1) ;
		rszBuffer [nPos ++]	= cc ;
	}
	if (nPos > 0) {
		if (TFAILED (TVarbuffer_Add (pvbuf, rszBuffer, nPos)))
			return	FALSE ;
	}
	while (cc != '\n' && cc != '\r' && cc != (Char) -1) {
		TBufStringMarker_Forward (pMarker, 1) ;
		cc	= TBufStringMarker_GetChar (pMarker) ;
	}
	while (cc == '\n' || cc == '\r') {
		TBufStringMarker_Forward (pMarker, 1) ;
		cc	= TBufStringMarker_GetChar (pMarker) ;
	}
	return	TRUE ;
}

BOOL
skkLocalJisyo_prepareDirectory (
	register LPCTSTR	pPath)
{
	register LPCTSTR	ptr ;
	register LPCTSTR	pLast ;
	register LPTSTR		pDir ;
	TCHAR				szDir [MAX_PATH + 1] ;

	if (pPath == NULL)
		return	FALSE ;

	pLast	= NULL ;
	ptr		= pPath ;
	pDir	= szDir ;
	while (*ptr != TEXT ('\0')) {
		while (*ptr != TEXT ('\0') && *ptr != TEXT ('\\')) {
			*pDir ++	= *ptr ++ ;
		}
		if (*ptr == TEXT ('\\')) {
			*pDir		= TEXT ('\0') ;
#if defined (DEBUG)
			DEBUGPRINTF ((TEXT ("CreateDierctory => \"%s\"\n"), szDir)) ;
#endif
			CreateDirectory (szDir, NULL) ;
			*pDir ++	= *ptr ++ ;
		}
	}
	return	TRUE ;
}

/*	�w�肳�ꂽ�ʒu����s���܂ł��w�肳�ꂽ�ʒu�Ɉړ�������B
 */
BOOL
skkLocalJisyo_moveLineToTop (
	register SkkLocalJisyo*	pJisyo,
	register int			nFrom,
	register BOOL			fOkuri)
{
	TVarbuffer			vbufLine ;
	register Char		cc ;
	Char				rCBuf [16] ;
	register Char*		ptr ;
	register int		nptr, nDelete, nTo ;
	register BOOL		fRetval	= FALSE ;
	TBufStringMarker	mk ;
	TBufStringMarker	mkDest ;

	DEBUGPRINTF ((TEXT ("moveLineToTop (%d, %d)\n"), nFrom, fOkuri)) ;

	if (TFAILED (TVarbuffer_Initialize (&vbufLine, sizeof (Char))))
		return	FALSE ;
	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nFrom, &mk))) {
		DEBUGPRINTF ((TEXT ("Can't solve marker (%d)\n"))) ;
		return	FALSE ;
	}

	ptr		= rCBuf ;
	nptr	= ARRAYSIZE (rCBuf) ;
	nDelete	= 0 ;
	while (cc = TBufStringMarker_GetChar (&mk), cc != (Char)-1) {
		*ptr	++ = cc ;
		nptr	-- ;
		if (nptr <= 0) {
			/*	�ꕶ���ǉ��`���J��Ԃ��Əd��������������16��������
			 *	�܂Ƃ߂Ă���i�[���邱�Ƃɂ��Ă݂�B*/
			if (TFAILED (TVarbuffer_Add (&vbufLine, rCBuf, ARRAYSIZE (rCBuf)))) {
				DEBUGPRINTF ((TEXT ("Add Line Failure\n"))) ;
				return	FALSE ;
			}
			ptr		= rCBuf ;
			nptr	= ARRAYSIZE (rCBuf) ;
		}
		TBufStringMarker_Forward (&mk, 1) ;
		nDelete	++ ;
		/*	�ړ��ɂ͉��s���܂߂�̂ŁA���s�R�[�h�����o�����ꍇ��
		 *	���[�v�𔲂���̂́A���̈ʒu�B*/
		if (cc == '\n')
			break ;
	}
	if (ptr != rCBuf)
		if (TFAILED (TVarbuffer_Add (&vbufLine, rCBuf, ptr - rCBuf))) {
			DEBUGPRINTF ((TEXT ("Add Line Failure\n"))) ;
			return	FALSE ;
		}

	/*	�ړ����̍s���폜����B*/
	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nFrom, &mk)) ||
		TFAILED (TBufStringMarker_DeleteChar   (&mk, nDelete))) {
		DEBUGPRINTF ((TEXT ("Delete or Solev failure\n"))) ;
		goto	Exit_Func ;
	}

	nTo	= (fOkuri)? pJisyo->m_nOkuriAriPos	: pJisyo->m_nOkuriNasiPos ;
	if (TFAILED (TBufString_SolveMarker (&pJisyo->m_bufJisyo, nTo, &mkDest))) {
		DEBUGPRINTF ((TEXT ("Can't solve marker (%d)\n"), nTo)) ;
		goto	Exit_Func ;
	}
	while (cc = TBufStringMarker_GetChar (&mkDest), 
		   cc != (Char) -1) {
		TBufStringMarker_Forward (&mkDest, 1) ;
		if (cc == '\n')
			break ;
	}
	if (cc != '\n') {
		DEBUGPRINTF ((TEXT ("Insertion Point Error? (0x%lx)\n"), cc)) ;
		goto	Exit_Func ;
	}
	/*	�ړ���ɃR�s�[���Ă������s�̒��g��}������B*/
	ptr		= TVarbuffer_GetBuffer (&vbufLine) ;
	nptr	= TVarbuffer_GetUsage  (&vbufLine) ;
#if defined (DEBUG)
	/*	��������肭�����Ă��Ȃ��悤�Ȃ̂ŁA�ǂ̕����񂪈ړ�����
	 *	���̂����܂��\������B*/
	{
		TCHAR	wbuf [512] ;

		ConvertCStrToTStr (ptr, nptr, wbuf, ARRAYSIZE (wbuf)) ;
		wbuf [ARRAYSIZE (wbuf) - 1]	= L'\0' ;
		DEBUGPRINTF ((TEXT ("MoveLine = \"%s\"\n"), wbuf)) ;
	}
#endif
	fRetval	= TBufStringMarker_InsertString (&mkDest, ptr, nptr) ;
 Exit_Func:
	TVarbuffer_Uninitialize (&vbufLine) ;
	return	fRetval ;
}

