#pragma once

/*	�e�X�g�p�̉��̃p�C�v���B*/
#define	SKKISERV_PIPENAME		TEXT("\\\\.\\pipe\\skkiserv_pipe")
#define	SZSERVICENAME			TEXT("SkkImeServer")
#define	SZAPPNAME				TEXT("skkiserv")
#define	SZSERVICEDISPLAYNAME	TEXT("SkkIme Internal Server")
#define	SZDEPENDENCIES			TEXT("")

#define	BUFSIZE					(2048)
#define	PIPE_TIMEOUT			(1000*5)
#define	MAX_PIPENAME			(256)

VOID	ServiceStart		(DWORD, LPTSTR*) ;
VOID	ServiceStop			(void) ;
void	AddToMessageLog		(LPTSTR lpszMsg) ;
BOOL	ReportStatusToSCMgr	(DWORD, DWORD, DWORD) ;

