#include "local.h"
#include <sddl.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <stdarg.h>
#include "skkiserv.h"
#include "jisyo.h"
#include "kanji.h"
#include "cstring.h"
#include "kfile.h"
#include "bufstring.h"
#include "user.h"
#include "immsec.h"
#include "kstring.h"
#include "protocol.h"
#include "packet.h"
#if defined (USE_LISPEVAL)
#include "lisp\lispmgr.h"
#include "lisp\lmachine.h"
#endif

/*
 */
VOID ServiceStart(DWORD dwArgc, LPTSTR *lpszArgv);
VOID ServiceStop();

static	BOOL	bCreatePipeName				(LPTSTR, int, LPCTSTR, int) ;
static	BOOL	bServiceMainloop			(void) ;
static	BOOL	bServeRequest				(SkkImeUser*, HANDLE, HANDLE*) ;
static	BOOL	bServeRequestOpen			(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestSearch			(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestRecord			(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestPurge			(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestTryCompletion	(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestEval			(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestSetCutbuffer	(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestGetCutbuffer	(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestUpdate			(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestSearchEx		(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestOkuriSearchEx	(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestSetJNumList	(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bServeRequestSaveLocalJisyo	(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*) ;
static	BOOL	bReplyPacket				(HANDLE, TVarbuffer*, HANDLE*) ;
static	BOOL	bReplyErrorPacket			(HANDLE, int, int, int, HANDLE*) ;
static	BOOL	bSendPacket					(HANDLE, BYTE*, int, HANDLE*) ;
static	BOOL	bGetClipboardText			(TVarbuffer*) ;

/*
 */
static	HANDLE	shEvServiceStop				= NULL ;

VOID
ServiceStart (DWORD dwArgc, LPTSTR *lpszArgv)
{
	_tprintf (TEXT ("ServiceStart\n")) ;

	shEvServiceStop		= CreateEvent (NULL, TRUE, FALSE, NULL) ;
	if (shEvServiceStop == NULL) {
		/* error */
		return ;
	}
	if (! bServiceMainloop ()) {
		/* error? */
	}
	if (shEvServiceStop != NULL) {
		CloseHandle (shEvServiceStop) ;
		shEvServiceStop	= NULL ;
	}
	return ;
}

VOID
ServiceStop (void)
{
	if (shEvServiceStop != NULL) {
		SetEvent (shEvServiceStop) ;
	}
	return ;
}

BOOL
bServiceMainloop (void)
{
	WSADATA					wsaData ;
	WORD					wVersion ;
	TCHAR					rszPipeName [256] ;
	HANDLE					hPipe	= NULL ;
	HANDLE					rhEvents [2] ;
	PSECURITY_ATTRIBUTES	psa	= NULL ;
	TCHAR					rszUserName [UNLEN + 1] ;
	DWORD					dwUserName ;
	OVERLAPPED				os ;
	SkkImeUser*				pSkkiservUser	= NULL ;
#if defined (USE_LISPEVAL)
	TLispManager*			pSkkiservLispMgr		= NULL ;
	TLispMachine*			pSkkiservLispMachine	= NULL ;
#endif
	BOOL					bRetval	= FALSE ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (!ReportStatusToSCMgr (SERVICE_START_PENDING, NO_ERROR, 3000))
		return	FALSE ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	wVersion	= MAKEWORD (2, 0) ;
	if (WSAStartup (wVersion, &wsaData) != 0)
		return	FALSE ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (LOBYTE (wsaData.wVersion) != 2 || HIBYTE (wsaData.wVersion) < 0) {
		WSACleanup () ;
		goto	cleanup ;
	}

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (!ReportStatusToSCMgr (SERVICE_START_PENDING, NO_ERROR, 3000))
		goto	cleanup ;

#if defined (USE_LISPEVAL)
	if (TFAILED (TLispMgr_Create (&pSkkiservLispMgr)) ||
		TFAILED (TLispMachine_Create (pSkkiservLispMgr, NULL, &pSkkiservLispMachine))) {
		goto	cleanup ;
	}
#endif

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (!ReportStatusToSCMgr (SERVICE_START_PENDING, NO_ERROR, 3000))
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	/*	���[�U�̍쐬�B�{���͈�l�������Ȃ��̂�����A����ȕ��ɕ������[�U��
	 *	���������߂�Ӗ��͂Ȃ��̂����c�B
	 */
	dwUserName	= UNLEN ;
	if (! GetUserName (rszUserName, &dwUserName)) 
		goto	cleanup ;
	
	if (!ReportStatusToSCMgr (SERVICE_START_PENDING, NO_ERROR, 3000))
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (! bCreatePipeName (rszPipeName, ARRAYSIZE (rszPipeName), rszUserName, (int)dwUserName))
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (!ReportStatusToSCMgr (SERVICE_START_PENDING, NO_ERROR, 3000))
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	pSkkiservUser	= SkkImeUser_Create (rszUserName, dwUserName) ;
	if (pSkkiservUser == NULL)
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	rhEvents [0]	= shEvServiceStop ;
	rhEvents [1]	= CreateEvent (NULL, TRUE, FALSE, NULL) ;
	if (rhEvents [1] == NULL)
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (!ReportStatusToSCMgr (SERVICE_START_PENDING, NO_ERROR, 3000))
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	psa		= CreateSecurityAttributes () ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	hPipe 	= CreateNamedPipe( 
			rszPipeName,				// pipe name 
			FILE_FLAG_OVERLAPPED |
			PIPE_ACCESS_DUPLEX,			// read/write access 
			PIPE_TYPE_MESSAGE |			// message type pipe 
			PIPE_WAIT,					// blocking mode 
			1,							// max. instances  
			BUFSIZE,					// output buffer size 
			BUFSIZE,					// input buffer size 
			1000,						// client time-out 
			psa) ;						// no security attribute 

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (hPipe == INVALID_HANDLE_VALUE) {
		DWORD	dwError	= GetLastError () ;
		goto	cleanup ;
	}

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	if (! ReportStatusToSCMgr (SERVICE_RUNNING, NO_ERROR, 0))
		goto	cleanup ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	while (TRUE) {
		DWORD	dwRetval ;

		_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

		memset (&os, 0, sizeof (OVERLAPPED)) ;
		os.hEvent	= rhEvents [1] ;
		ResetEvent (rhEvents [1]) ;

		_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

		ConnectNamedPipe (hPipe, &os) ;

		_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

		dwRetval	= WaitForMultipleObjects (2, rhEvents, FALSE, INFINITE) ;
		if (dwRetval != (WAIT_OBJECT_0+1))
			break ;

		_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

		if (GetLastError () == ERROR_IO_PENDING) {
			dwRetval	= WaitForMultipleObjects (2, rhEvents, FALSE, INFINITE) ;
			if (dwRetval != (WAIT_OBJECT_0+1))			// not overlapped i/o event - error occurred,
				break ;								// or server stop signaled
		}
		_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;
		if (! bServeRequest (pSkkiservUser, hPipe, rhEvents)) {
			_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;
		}
		FlushFileBuffers (hPipe) ; 
		DisconnectNamedPipe (hPipe) ;
	} 

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;

	/*	�����̃Z�[�u�B
	 */
	if (pSkkiservUser != NULL) {
//		BOOL	fRetval ;
		/*	�ւ�Ȃ����傭���Ă���B
		 */
//		fRetval	= SkkImeUser_Save (pSkkiservUser) ;
	}
	bRetval	= TRUE ;

cleanup:
#if defined (USE_LISPEVAL)
	if (pSkkiservLispMachine != NULL) {
		TLispMachine_Destroy (pSkkiservLispMachine) ;
		pSkkiservLispMachine	= NULL ;
	}
	if (pSkkiservLispMgr != NULL) {
		TLispMgr_Destroy (pSkkiservLispMgr) ;
		pSkkiservLispMgr	= NULL ;
	}
#endif
	if (pSkkiservUser != NULL) {
		SkkImeUser_Destroy (pSkkiservUser) ;
		pSkkiservUser	= NULL ;
	}
	if (hPipe != NULL) {
		CloseHandle (hPipe) ;
		hPipe	= NULL ;
	}
	if (psa != NULL){
		FreeSecurityAttributes (psa) ;	
		psa	= NULL ;
	}
	if (rhEvents [1] != NULL) {
		CloseHandle (rhEvents [1]) ;
		rhEvents [1]	= NULL ;
	}
	WSACleanup () ;

	_tprintf (TEXT ("bServiceMainloop -- %d\n"), __LINE__) ;
	return	bRetval ;
}

BOOL
bCreatePipeName (
	LPTSTR				pwBuffer,
	int					iBufferSize,
	LPCTSTR				pUserName,
	int					iUserNameLen)
{
	LPTSTR		ptr ;
	LPCTSTR		pSrc ;
	int			nptr, n ;

	ptr		= pwBuffer ;
	nptr	= iBufferSize ;
	lstrcpy (ptr, TEXT("\\\\.\\pipe\\pskkime-")) ;
	n		= lstrlen (ptr) ;
	ptr		+= n ;
	nptr	-= n ;
	pSrc	= pUserName ;
	while (nptr > 0 && iUserNameLen > 0) {
		/*	�p�X�����Ƃ��Ďg�p�ł��Ȃ����͎̂̂Ă�B*/
		if (*pSrc == TEXT('\\') || *pSrc == TEXT('*') || *pSrc == TEXT('?') ||
			*pSrc == TEXT(':')  || *pSrc == TEXT('.') || *pSrc == TEXT('/')) {
			*ptr ++	= TEXT('-') ;
		} else {
			*ptr ++	= *pSrc ;
		}
		pSrc			++ ;
		iUserNameLen	-- ;
		nptr			-- ;
	}
	if (nptr > 0) {
		*ptr	= TEXT ('\0') ;
	} else {
		if (iBufferSize > 0)
			pwBuffer [iBufferSize - 1]	= TEXT ('\0') ;
	}
	return	TRUE ;
}

BOOL
bServeRequest (
	SkkImeUser*	pUser,
	HANDLE		hPipe,
	HANDLE*		phEvents)
{
	static	BOOL	(*rpServiceFunction [])(SkkImeUser*, HANDLE, int, int, BYTE*, int, HANDLE*)	= {
		bServeRequestSearch,
		bServeRequestRecord,
		bServeRequestPurge,
		bServeRequestTryCompletion,
		bServeRequestEval,
		bServeRequestSetCutbuffer,
		bServeRequestGetCutbuffer,
		bServeRequestUpdate,
		bServeRequestSearchEx,
		bServeRequestOkuriSearchEx,
		bServeRequestSetJNumList,
		bServeRequestSaveLocalJisyo,
	} ;
	BYTE		rbyBuffer [2048] ;
	DWORD		dwRead ;
	int			nMajor, nMinor, nLength, nPos ;
	OVERLAPPED	os ;
	DWORD		dwWait ;
	BOOL		bRetval ;

	_tprintf (TEXT ("bServeRequest -- %d\n"), __LINE__) ;

	memset (&os, 0, sizeof (os)) ;
	os.hEvent	= phEvents [1] ;
	ResetEvent (phEvents [1]) ;

	bRetval	= ReadFile (hPipe, rbyBuffer, sizeof (rbyBuffer), &dwRead, &os) ;
	if (! bRetval) {
		DWORD	dwError	= GetLastError () ;

		if (dwError != ERROR_IO_PENDING) {
			DEBUGPRINTFEX (103, (TEXT ("bServeRequest(): fail in reading client packet(%ld)\n"), dwError)) ;
			bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_READ, phEvents) ;
			return	FALSE ;
		}

		/* operation not completed */
		dwWait = WaitForMultipleObjects (2, phEvents, FALSE, INFINITE) ;
		if (dwWait != (WAIT_OBJECT_0+1))
			return	FALSE ;
	}

	_tprintf (TEXT ("bServeRequest -- %d/ Read (%d)\n"), __LINE__, dwRead) ;

	if (dwRead < SKKISERV_PROTO_HEADER_SIZE) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET, phEvents) ;
		DEBUGPRINTFEX (103, (TEXT ("Packet is broken: Read(%ld) < %d\n"),
							 dwRead, SKKISERV_PROTO_HEADER_SIZE)) ;
		return	FALSE ;
	}
	_tprintf (TEXT ("bServeRequest -- %d\n"), __LINE__) ;

	/*	�p�P�b�g�ɂ́uMajor�ԍ��AMinor�ԍ��A�p�P�b�g�T�C�Y�v��
	 *	�����Ă���B�p�P�b�g�̑傫���� 2k �ȏ�ɂ͂Ȃ�Ȃ��B��
	 *	��𒴂�����͎̂̂Ă�B
	 *
	 *	���ƁA4�o�C�g���E�ɒ��ӁA�ƁB
	 */
	nMajor	= rbyBuffer [0] ;
	nMinor	= rbyBuffer [1] ;
	nLength	= bytep2word (&rbyBuffer [2]) ;
	if ((DWORD)nLength != dwRead) {
		DEBUGPRINTFEX (103, (TEXT ("Packet is broken: Length(%d) != Read(%ld)\n"),
							 nLength, dwRead)) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET, phEvents) ;
		DEBUGPRINTFEX (103, (TEXT ("Packet is broken: Length(%d) != Read(%ld)\n"),
							 nLength, dwRead)) ;
		return	FALSE ;
	}
	DEBUGPRINTFEX (103, (TEXT ("Packet(Major:%d, Minor:%d, Length:%d)\n"), nMajor, nMinor, nLength)) ;
	_tprintf (TEXT ("bServeRequest -- %d\n"), __LINE__) ;

	if (nMajor < 0 || nMajor > sizeof (rpServiceFunction) / sizeof (rpServiceFunction [0]))
		return	FALSE ;

	_tprintf (TEXT ("bServeRequest -- %d\n"), __LINE__) ;
	/*	�o�C�g���E�ɒ��ӂ��� LPCTSTR �ɂ��킹��B*/
	nPos	= SKKISERV_PROTO_HEADER_SIZE ;
	return	(rpServiceFunction [nMajor])(pUser, hPipe, nMajor, nMinor, &rbyBuffer [nPos], nLength - nPos, phEvents) ;
}

/*
 */
BOOL
bServeRequestSearch (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	LPCWSTR		pwKey ;
	BOOL		fOkuri ;
	Char		rkey [1024] ;
	TVarbuffer	vbuf ;
	TVarbuffer	vbufPacket ;
	int			nChar, nwKey, nCkey ;
	BOOL		fResult	= FALSE ;
	const Char*	pChar ;
#if defined (DEBUG)
	TCHAR	rszBuffer [1024] ;
#endif

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTFEX (103, (TEXT ("bServeRequestSearch (%p, %d, %d, %p, %d)\n"),
						 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwKey	= bytep2word (pData) ;
	if ((int)(nwKey * sizeof (wchar_t)) > nData) {
		DEBUGPRINTF ((TEXT ("bServeRequestSearch (): �p�P�b�g�����Ă���.\n"))) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		return	FALSE ;
	}
	pwKey	= (LPCWSTR) &pData [2] ;
	fOkuri	= (nMinor != 0) ;

#if defined (DEBUG)
	{
		TCHAR	rszBuffer [1024] ;

		lstrcpyn (rszBuffer, pwKey, 1023) ;
		rszBuffer [1023]	= TEXT ('\0') ;
		DEBUGPRINTF ((TEXT ("key = \"%s\"\n"), rszBuffer)) ;
	}
#endif

	/*	�����̌����B*/
	nCkey	= wstr2internal (rkey, ARRAYSIZE (rkey), pwKey, nwKey) ;
	if (nCkey < 0) {
		DEBUGPRINTF ((TEXT ("bServeRequestSearch (): �s���Ȍ����L�[.\n"))) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		return	FALSE ;
	}
	DEBUGPRINTF ((TEXT ("bServeRequestSearch (): �����J�n(%ld).\n"), GetTickCount ())) ;
	SkkImeUser_Search (pUser, rkey, nCkey, fOkuri, &vbuf) ;
	DEBUGPRINTF ((TEXT ("bServeRequestSearch (): �����I��(%ld).\n"), GetTickCount ())) ;
	
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SEARCH_REPLY, 0)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
#if defined (DEBUG)
	{
		const BYTE*	pwResult	= (BYTE *)TVarbuffer_GetBuffer (&vbufPacket) + SKKISERV_PROTO_HEADER_SIZE ;
		int			nbResult	= TVarbuffer_GetUsage (&vbufPacket) - SKKISERV_PROTO_HEADER_SIZE ;
		LPCTSTR	pwstr ;
		int		nwstr ;
		int		n ;

		pwstr	= (LPCTSTR) pwResult ;
		nwstr	= nbResult / sizeof (TCHAR) ;
		while (nwstr > 0) {
			n	= (nwstr > 1023)? 1023 : nwstr ;
			_tcsncpy (rszBuffer, pwstr, n) ;
			rszBuffer [n]	= TEXT ('\0') ;
			DEBUGPRINTF ((TEXT ("%s"), rszBuffer)) ;
			nwstr	-= n ;
			pwstr	+= n ;
		}
		DEBUGPRINTF ((TEXT ("\n"))) ;
	}
#endif
	DEBUGPRINTF ((TEXT ("bServeRequestSearch (): ���v���C�p�P�b�g���o.\n"))) ;
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
bServeRequestRecord (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	TVarbuffer			vbufPacket ;
	Char				rkey  [1024] ;
	Char				rcand [1024] ;
	LPCWSTR	pwKey, pwCand ;
	int		nwKey, nCkey, nwCand, nCCand ;
	BOOL		fOkuri ;
	BOOL		fResult	= FALSE ;

	DEBUGPRINTF ((TEXT ("bServeRequestRecord (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	fOkuri	= (nMinor != 0) ;
	nwKey	= bytep2word (pData) ;
	pwKey	= (LPCWSTR) &pData [2] ;
	pData	= pData + MAKEPAD(2 + nwKey * sizeof (wchar_t)) ;
	nwCand	= bytep2word (pData) ;
	pwCand	= (LPCWSTR) &pData [2] ;

	if (nData < (int)((nwKey + nwCand) * sizeof (wchar_t) + 2 + 2)) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		return	FALSE ;
	}

	nCkey	= wstr2internal (rkey,  ARRAYSIZE (rkey),  pwKey,  nwKey) ;
	nCCand	= wstr2internal (rcand, ARRAYSIZE (rcand), pwCand, nwCand) ;
	if (nCkey <= 0 || nCCand <= 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		return	FALSE ;
	}
	fResult	= SkkImeUser_Record (pUser, rkey, nCkey, fOkuri, rcand, nCCand) ;

	DEBUGPRINTF ((TEXT ("skkiserv: create return packet (result:%d)\n"), fResult)) ;
	
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_RECORD_REPLY, !fResult)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
	DEBUGPRINTF ((TEXT ("skkiserv: sent reply packet (result:%d)\n"), fResult)) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	DEBUGPRINTF ((TEXT ("skkiserv: exit bServeRequestRecord ()\n"))) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
bServeRequestPurge (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	TVarbuffer			vbufPacket ;
	Char				rkey  [1024] ;
	Char				rcand [1024] ;
	LPCWSTR	pwKey, pwCand ;
	int		nwKey, nCkey, nwCand, nCCand ;
	BOOL		fOkuri ;
	BOOL		fResult	= FALSE ;

	DEBUGPRINTF ((TEXT ("bServeRequestPurge (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	fOkuri	= (nMinor != 0) ;
	nwKey	= bytep2word (pData) ;
	pwKey	= (LPCWSTR) &pData [2] ;
	pData	= pData + MAKEPAD(2 + nwKey * sizeof (wchar_t)) ;
	nwCand	= bytep2word (pData) ;
	pwCand	= (LPCWSTR) &pData [2] ;

	if (nData < (int)((nwKey + nwCand) * sizeof (wchar_t) + 2 + 2)) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		return	FALSE ;
	}

	nCkey	= wstr2internal (rkey,  ARRAYSIZE (rkey),  pwKey,  nwKey) ;
	nCCand	= wstr2internal (rcand, ARRAYSIZE (rcand), pwCand, nwCand) ;
	if (nCkey < 0 || nCCand < 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		return	FALSE ;
	}
	fResult	= SkkImeUser_Purge (pUser, rkey, nCkey, fOkuri, rcand, nCCand) ;
	
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_PURGE_REPLY, !fResult)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
bServeRequestTryCompletion (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	LPCWSTR		pwKey ;
	Char		rkey [1024] ;
	TVarbuffer	vbuf ;
	TVarbuffer	vbufPacket ;
	int			nChar, nwKey, nCkey ;
	BOOL		fResult	= FALSE ;
	const Char*	pChar ;
#if defined (DEBUG)
	TCHAR		rszBuffer [1024] ;
#endif

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTF ((TEXT ("bServeRequestTryCompletion (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwKey	= bytep2word (pData) ;
	if ((int)(nwKey * sizeof (wchar_t)) > nData) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		return	FALSE ;
	}
	pwKey	= (LPCWSTR) &pData [2] ;

#if defined (DEBUG)
	{
		_tcsncpy (rszBuffer, pwKey, nwKey) ;
		rszBuffer [nwKey]	= TEXT ('\0') ;
		DEBUGPRINTF ((TEXT("key = \"%s\"\n"), rszBuffer)) ;
	}
#endif

	/*	�����̌����B*/
	nCkey	= wstr2internal (rkey, ARRAYSIZE (rkey), pwKey, nwKey) ;
	if (nCkey < 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		return	FALSE ;
	}
	if (TFAILED (SkkImeUser_TryCompletion (pUser, rkey, nCkey, &vbuf))) {
		DEBUGPRINTF ((TEXT ("SkkImeUser_Completion return FALSE\n"))) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_COMPLETION_REPLY, 0)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
#if defined (DEBUG)
	{
		const BYTE*	pwResult	= (BYTE *)TVarbuffer_GetBuffer (&vbufPacket) + SKKISERV_PROTO_HEADER_SIZE ;
		int			nbResult	= TVarbuffer_GetUsage (&vbufPacket) - SKKISERV_PROTO_HEADER_SIZE ;
		LPCTSTR	pwstr ;
		int		nwstr ;
		int		n ;

		pwstr	= (LPCTSTR) pwResult ;
		nwstr	= nbResult / sizeof (TCHAR) ;
		while (nwstr > 0) {
			n	= (nwstr > 1023)? 1023 : nwstr ;
			_tcsncpy (rszBuffer, pwstr, n) ;
			rszBuffer [n]	= TEXT ('\0') ;
			DEBUGPRINTF ((TEXT ("%s"), rszBuffer)) ;
			nwstr	-= n ;
			pwstr	+= n ;
		}
		DEBUGPRINTF ((TEXT ("\n"))) ;
	}
#endif
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
}

BOOL
bServeRequestEval (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
#if defined (USE_LISPEVAL)
	LPCWSTR		pwWord ;
	Char					rCWord [512] ;
	TVarbuffer				vbuf ;
	TVarbuffer				vbufPacket ;
	int			nChar, nwWord, nCWord ;
	const Char*	pChar ;
	BOOL			fResult	= FALSE, fRet ;
	TLispEntity*	pEntTarget ;

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTF ((TEXT ("bServeRequestEval (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwWord	= bytep2word (pData) ;
	if ((int)(nwWord * sizeof (wchar_t)) > nData) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		goto	exit_func ;
	}
	pwWord	= (LPCWSTR) &pData [2] ;

	/*	�����̌����B*/
	nCWord	= wstr2internal (rCWord, ARRAYSIZE (rCWord), pwWord, nwWord) ;
	if (nCWord >= ARRAYSIZE (rCWord)) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	if (nCWord < 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		goto	exit_func ;
	}
	pEntTarget	= lispMgr_ParseString (spSkkiservLispMgr, rCWord, nCWord, NULL) ;
	if (pEntTarget != NULL) {
		fRet	= TLispMachine_Test (spSkkiservLispMachine, pEntTarget, &vbuf) ;
		lispEntity_Release (spSkkiservLispMgr, pEntTarget) ;
	} else {
		fRet	= FALSE ;
	}
	if (TFAILED (fRet)) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_EVAL_FAIL, phEvents) ;
		goto	exit_func ;
	}
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_EVAL_REPLY, 0)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func_1 ;
	}
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
	lispMgr_CollectGarbage (spSkkiservLispMgr) ;
	lispMgr_CollectGarbage (spSkkiservLispMgr) ;
 exit_func_1:
	TVarbuffer_Uninitialize (&vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
#else	
	bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_NOT_IMPLEMENTED, phEvents) ;
	return	FALSE ;
	UNREFERENCED_PARAMETER (hPipe) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
#endif
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
}

/*
 *	(nMajor(1), nMinor(1), Length(2), String)
 *	String = (length(2), tchar(n))
 */
BOOL
bServeRequestSetCutbuffer (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
#if 0
	TVarbuffer			vbufPacket ;
	TVarbuffer			vbufCutbuffer ;
	LPWSTR		pString ;
	int		nLength, nBaseLength ;
	BOOL		fAppend ;
	BOOL		fResult	= FALSE ;
	HANDLE		hglbCopy ;
	LPWSTR		lpstrCopy ;

	DEBUGPRINTF ((TEXT ("bServeRequestSetCutbuffer (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	fAppend	= (nMinor != 0) ;

	if (nData < 2) {
		DEBUGPRINTF ((TEXT ("SetCutbuffer: empty string (%d)\n"), 
					 nData)) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET, phEvents) ;
		return	FALSE ;
	}

	pString	= (LPWSTR) &pData [2] ;
	nLength	= bytep2word (pData) ;
	if (nData < (int)(nLength * sizeof (wchar_t) + 2)) {
		DEBUGPRINTF ((TEXT ("SetCutbuffer: packet length(%d) < string length(%d/%d)\n"),
					 nData, (int)(nLength * sizeof (wchar_t) + 2), nLength)) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET, phEvents) ;
		return	FALSE ;
	}

	TVarbuffer_Initialize (&vbufCutbuffer, sizeof (wchar_t)) ;
	nBaseLength	= 0 ;
	if (fAppend) {
		if (TSUCCEEDED (bGetClipboardText (&vbufCutbuffer))) 
			nBaseLength	= TVarbuffer_GetUsage (&vbufCutbuffer) ;
	}

	if (!shwndSkkiserv || !OpenClipboard (shwndSkkiserv)) {
		DWORD	dwError	= GetLastError () ;
		DEBUGPRINTFEX (103, (TEXT ("SetCutbuffer: OpenClipboard(hwnd:%lx) failed(%lx)\n"), shwndSkkiserv, dwError)) ;
		TVarbuffer_Uninitialize (&vbufCutbuffer) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		return	FALSE ;
	}

	EmptyClipboard () ; 
 	hglbCopy = GlobalAlloc (GMEM_MOVEABLE, (nLength + nBaseLength + 1) * sizeof (wchar_t)) ;
	if (hglbCopy == NULL){
		CloseClipboard () ;
		TVarbuffer_Uninitialize (&vbufCutbuffer) ;
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		return	FALSE ;
	}
	lpstrCopy			= (LPWSTR)GlobalLock (hglbCopy) ; 
	if (nBaseLength > 0) 
		memcpy (lpstrCopy, TVarbuffer_GetBuffer (&vbufCutbuffer), nBaseLength * sizeof (wchar_t)) ;
	memcpy (lpstrCopy + nBaseLength, pString, nLength * sizeof (wchar_t)) ;
	lpstrCopy [nBaseLength + nLength]	= L'\0' ;
	GlobalUnlock (hglbCopy) ; 
	SetClipboardData (CF_UNICODETEXT, hglbCopy) ; 
	CloseClipboard () ;
	TVarbuffer_Uninitialize (&vbufCutbuffer) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SETCUTBUFFER_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;

  exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
#else
	bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
	return	FALSE ;
#endif
}

BOOL
bServeRequestGetCutbuffer (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
#if 0
	TVarbuffer			vbufPacket ;
	int		nLength ;
	BOOL		fResult ;
	BOOL		fRetval	= FALSE ;

	DEBUGPRINTF ((TEXT ("bServeRequestGetCutbuffer (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	if (!shwndSkkiserv) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		return	FALSE ;
	}

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_GETCUTBUFFER_REPLY, 0))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}

	nLength	= 0 ;
	fResult	= FALSE ;
 	if (IsClipboardFormatAvailable (CF_UNICODETEXT) &&
		OpenClipboard (shwndSkkiserv)){
		HANDLE	hglb ;

	 	hglb	= GetClipboardData (CF_UNICODETEXT) ;
		if (hglb != NULL){ 
			LPCWSTR	lpstr ;

			lpstr	= (LPCWSTR)GlobalLock (hglb) ; 
			if (lpstr != NULL){ 
				fResult	= TPacket_AddString (&vbufPacket, lpstr, lstrlen (lpstr)) ;
				GlobalUnlock (hglb) ; 
			} 
		} 
	}
	CloseClipboard () ;
	
	if (! fResult) {
		/*	empty string ��������B*/
		if (! TPacket_AddString (&vbufPacket, NULL, 0)) {
			bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
			goto	exit_func ;
		}
	}
	if (TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fRetval	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;

  exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fRetval ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
#else
	bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
	return	FALSE ;
#endif
}

BOOL
bServeRequestUpdate (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	TVarbuffer			vbufPacket ;
	BOOL		fRetval	= FALSE ;

	/*	Critical Section �̒��ɂ���̂ŁA�����ɕ����� thread ���������Ƃ�
	 *	�Ȃ��ƍl���ėǂ��B������A�v�����܂܂� update ����B
	 */
	DEBUGPRINTF ((TEXT ("bServeRequestUpdate (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	if (pUser == NULL) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		return	FALSE ;
	}
	SkkImeUser_Update (pUser) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_UPDATE_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fRetval	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fRetval ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
}

/*
 */
BOOL
bServeRequestSearchEx (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	LPCWSTR		pwKey ;
	Char					rkey [1024] ;
	TVarbuffer				vbuf ;
	TVarbuffer				vbufPacket ;
	int			nChar, nwKey, nCkey ;
	BOOL			fResult	= FALSE ;
	const Char*	pChar ;
	int						nNext	= -1 ;

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTFEX (103, (TEXT ("bServeRequestSearchEx (%p, %d, %d, %p, %d)\n"),
						 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwKey	= bytep2word (pData) ;
	if ((int)(nwKey * sizeof (wchar_t)) > nData) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		return	FALSE ;
	}
	pwKey	= (LPCWSTR) &pData [2] ;

#if 1
	{
		WCHAR buf [256] ;
		int		n ;
		n	= (nwKey < ARRAYSIZE (buf))? nwKey : ARRAYSIZE (buf) - 1 ;
		memcpy (buf, pwKey, n * sizeof (WCHAR)) ;
		buf [n]	= L'\0' ;
		DebugPrintf (TEXT ("Search Key = \"%s\"\n"), buf) ;
	}
#endif

	/*	�����̌����B*/
	nCkey	= wstr2internal (rkey, ARRAYSIZE (rkey), pwKey, nwKey) ;
	if (nCkey < 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		return	FALSE ;
	}
	SkkImeUser_SearchEx (pUser, rkey, nCkey, FALSE, nMinor, &vbuf, &nNext) ;
	DEBUGPRINTFEX (103, (TEXT ("bServeRequestSearchEx: next = %d\n"), nNext)) ;
	
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SEARCH_REPLY, nNext)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

/*
 */
BOOL
bServeRequestOkuriSearchEx (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	LPCWSTR		pwKey ;
	Char		rkey [1024] ;
	TVarbuffer	vbuf ;
	TVarbuffer	vbufPacket ;
	int			nChar, nwKey, nCkey ;
	BOOL		fResult	= FALSE ;
	const Char*	pChar ;
	int			nNext	= -1 ;

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTF ((TEXT ("bServeRequestOkuriSearchEx (%p, %d, %d, %p, %d)\n"),
				  hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwKey	= bytep2word (pData) ;
	if ((int)(nwKey * sizeof (wchar_t)) > nData) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		return	FALSE ;
	}
	pwKey	= (LPCWSTR) &pData [2] ;

	/*	�����̌����B*/
	nCkey	= wstr2internal (rkey, ARRAYSIZE (rkey), pwKey, nwKey) ;
	if (nCkey < 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		return	FALSE ;
	}
	SkkImeUser_SearchEx (pUser, rkey, nCkey, TRUE, nMinor, &vbuf, &nNext) ;
	
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SEARCH_REPLY, nNext)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
bServeRequestSetJNumList (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
#if defined (USE_LISPEVAL)
	static WCHAR			srwszLeft []	= L"(setq j-num-list (setq skk-num-list '(" ;
	static WCHAR			srwszRight []	= L")))" ;
	LPCWSTR		pwWord ;
	Char					rcWord [1024] ;
	TVarbuffer				vbuf ;
	TVarbuffer				vbufPacket ;
	int			ndwDest, nwWord, n ;
	BOOL			fResult	= FALSE, fError ;
	Char*			pdwDest ;
	TLispEntity*	pEntTarget ;

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTF ((TEXT ("bServeRequestSetJNumList (%p, %d, %d, %p, %d)\n"),
				  hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwWord	= bytep2word (pData) ;
	if ((int)(nwWord * sizeof (wchar_t)) > nData) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET, phEvents) ;
		goto	exit_func ;
	}

	pwWord	= (LPCWSTR) &pData [2] ;
	pdwDest	= rcWord ;
	ndwDest	= ARRAYSIZE (rcWord) ;

	n	= wstr2internal (pdwDest, ndwDest, srwszLeft, ARRAYSIZE (srwszLeft)) ;
	if (n <= 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		goto	exit_func ;
	}
	pdwDest	+= n ;
	ndwDest	-= n ;
	fError	= FALSE ;
	while (nwWord > 0) {
		if (L'0' <= *pwWord && *pwWord <= L'9') {
			*pdwDest ++	= '\"' ;
			ndwDest	-- ;
			while (nwWord > 0 && ndwDest > 0 && L'0' <= *pwWord && *pwWord <= L'9') {
				*pdwDest ++	= *pwWord ++ ;
				ndwDest	-- ;
				nwWord	-- ;
			}
			if (ndwDest <= 0) {
				fError	= TRUE ;
				break ;
			}
			*pdwDest ++	= '\"' ;
			ndwDest	-- ;
		} else if (*pwWord == L'/' || *pwWord == L'\0') {
			*pdwDest ++	= ' ' ;
			ndwDest	-- ;
			pwWord	++ ;
			nwWord	-- ;
		} else {
			fError	= TRUE ;
			break ;	/* invalid character */
		}
	}
	if (fError || ndwDest < ARRAYSIZE (srwszRight)) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	n	= wstr2internal (pdwDest, ndwDest, srwszRight, ARRAYSIZE (srwszRight)) ;
	if (n <= 0) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR, phEvents) ;
		goto	exit_func ;
	}
	pdwDest	+= n ;
	ndwDest	-= n ;

	pEntTarget	= lispMgr_ParseString (spSkkiservLispMgr, rcWord, pdwDest - rcWord, NULL) ;
	if (pEntTarget != NULL) {
		fError	= ! TLispMachine_Test (spSkkiservLispMachine, pEntTarget, &vbuf) ;
		lispEntity_Release (spSkkiservLispMgr, pEntTarget) ;
	} else {
		fError	= TRUE ;
	}
	if (fError) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_EVAL_FAIL, phEvents) ;
		goto	exit_func ;
	}

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SETJNUMLIST_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fResult	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
	lispMgr_CollectGarbage (spSkkiservLispMgr) ;
	lispMgr_CollectGarbage (spSkkiservLispMgr) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
#else
	bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_NOT_IMPLEMENTED, phEvents) ;
	return	FALSE ;
#endif
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
bServeRequestSaveLocalJisyo (
	SkkImeUser*		pUser,
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData,
	HANDLE*			phEvents)
{
	TVarbuffer			vbufPacket ;
	BOOL		fRetval	= FALSE ;

	/*	Critical Section �̒��ɂ���̂ŁA�����ɕ����� thread ���������Ƃ�
	 *	�Ȃ��ƍl���ėǂ��B������A�v�����܂܂� update ����B
	 */
	DEBUGPRINTF ((TEXT ("bServeRequestSaveLocalJisyo (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	if (pUser == NULL) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		return	FALSE ;
	}
	DEBUGPRINTFEX (103, (TEXT ("skkiserv: start to save localjisyo\n"))) ;
	fRetval	= SkkImeUser_Save (pUser) ;
	DEBUGPRINTFEX (103, (TEXT ("skkiserv: finished saving localjisyo ... %do\n"), fRetval)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SAVELOCALJISYO_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		bReplyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER, phEvents) ;
		goto	exit_func ;
	}
	fRetval	= bReplyPacket (hPipe, &vbufPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fRetval ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
}

BOOL
bReplyPacket (
	HANDLE			hPipe,
	TVarbuffer*		pvbufPacket,
	HANDLE*			phEvents)
{
	BYTE*			pPacket ;
	int				nPacket ;

	assert (pvbufPacket != NULL) ;

	pPacket	= TVarbuffer_GetBuffer (pvbufPacket) ;
	nPacket	= TVarbuffer_GetUsage  (pvbufPacket) ;
	return	bSendPacket (hPipe, pPacket, nPacket, phEvents) ;
}

BOOL
bReplyErrorPacket (
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	int				nErrorCode,
	HANDLE*			phEvents)
{
	BYTE*			pPacket ;
	int				nPacket ;
	BOOL			fResult	= FALSE ;
	TVarbuffer		vbufPacket ;
	
	/*	�p�P�b�g�̃w�b�_�𖄂߂�B
	 */
	if (TFAILED (TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE))))
		return	FALSE ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, nMajor, nMinor))   ||
		TFAILED (TPacket_AddCard16 (&vbufPacket, (WORD)nErrorCode)) ||
		TFAILED (TPacket_AddPad    (&vbufPacket)) ||
		TFAILED (TPacket_SetLength (&vbufPacket)))
		goto	exit_func ;

	pPacket	= TVarbuffer_GetBuffer (&vbufPacket) ;
	nPacket	= TVarbuffer_GetUsage  (&vbufPacket) ;
	fResult	= bSendPacket (hPipe, pPacket, nPacket, phEvents) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fResult ;
}

BOOL
bSendPacket (
	HANDLE			hPipe,
	BYTE*			pPacket,
	int				nPacket,
	HANDLE*			phEvents)
{
	OVERLAPPED	os ;

	while (nPacket > 0) {
		BOOL	bRetval ;
		DWORD	dwWrite, dwWait ;

		memset (&os, 0, sizeof (OVERLAPPED)) ;
		os.hEvent	= phEvents [1] ;
		ResetEvent (os.hEvent) ;

		bRetval	= WriteFile (hPipe, pPacket, nPacket, &dwWrite, &os) ;
		if (! bRetval) {
			DWORD	dwError	= GetLastError () ;

			if (dwError != ERROR_IO_PENDING) {
				DEBUGPRINTFEX (103, (TEXT ("bSendPacket (): fail(%lx).\n"), GetLastError ())) ;
				return	FALSE ;
			}
			dwWait	= WaitForMultipleObjects (2, phEvents, FALSE, INFINITE) ;
			if (dwWait != (WAIT_OBJECT_0 + 1))
				return	FALSE ;
		}
		pPacket	+= dwWrite ;
		nPacket	-= dwWrite ;
		_tprintf (TEXT ("Sent (%d bytes/left: %d)\n"), dwWrite, nPacket) ;
	}
	return	TRUE ;
}

BOOL
bGetClipboardText (
	TVarbuffer*	pvbufText)
{
#if 0
	BOOL	fResult	= FALSE ;

 	if (IsClipboardFormatAvailable (CF_UNICODETEXT) &&
		OpenClipboard (shwndSkkiserv)){
		HANDLE	hglb ;

	 	hglb	= GetClipboardData (CF_UNICODETEXT) ;
		if (hglb != NULL){ 
			LPCWSTR	lpstr ;

			lpstr	= (LPCWSTR)GlobalLock (hglb) ; 
			if (lpstr != NULL){ 
				fResult	= TVarbuffer_Add (pvbufText, lpstr, lstrlen (lpstr)) ;
				GlobalUnlock (hglb) ; 
			} 
		} 
	}
	CloseClipboard () ;
	return	fResult ;
#else
	return	FALSE ;
#endif
}

