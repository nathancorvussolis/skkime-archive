#include <windows.h>
#include <stdio.h>
#include <shlwapi.h>
#include <stdlib.h>
#include <process.h>
#include <tchar.h>
#include "skkiserv.h"

// internal variables
static	SERVICE_STATUS          ssStatus;       // current status of the service
static	SERVICE_STATUS_HANDLE   sshStatusHandle;
static	DWORD                   dwErr = 0;
static	BOOL                    bDebug = FALSE;
static	TCHAR                   szErr[256];

// internal function prototypes
static	VOID WINAPI	service_ctrl(DWORD dwCtrlCode);
static	VOID WINAPI	service_main(DWORD dwArgc, LPTSTR *lpszArgv);
static	VOID		CmdInstallService();
static	VOID		CmdRemoveService();
static	VOID		CmdDebugService(int argc, TCHAR **argv);
static	BOOL WINAPI	ControlHandler ( DWORD dwCtrlType );
static	LPTSTR		GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize );

//
//  FUNCTION: main
//
//  PURPOSE: entrypoint for service
//
//  PARAMETERS:
//    argc - number of command line arguments
//    argv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//    main() either performs the command line task, or
//    call StartServiceCtrlDispatcher to register the
//    main service thread.  When the this call returns,
//    the service has stopped, so exit.
//
int
_tmain(int iArgc, TCHAR* rpArgv[])
{
	static	SERVICE_TABLE_ENTRY dispatchTable[] = {
		{ SZSERVICENAME,	(LPSERVICE_MAIN_FUNCTION)service_main },
		{ NULL,				NULL}
	} ;
	
	if ((iArgc > 1) && ((*rpArgv [1] == TEXT ('-')) || (*rpArgv [1] == TEXT ('/')))) {
		if (! lstrcmpi (TEXT ("install"), rpArgv [1] + 1)) {
			CmdInstallService () ;
		} else if (! lstrcmpi (TEXT ("remove"), rpArgv [1] + 1)) {
			CmdRemoveService () ;
		} else if (! lstrcmpi (TEXT ("debug"), rpArgv [1] + 1)) {
			bDebug = TRUE;
			CmdDebugService(iArgc, rpArgv) ;
		} else {
		   _tprintf (TEXT ("%s -install          to install the service\n"), SZAPPNAME) ;
		   _tprintf (TEXT ("%s -remove           to remove the service\n"), SZAPPNAME) ;
		   _tprintf (TEXT ("%s -debug <params>   to run as a console app for debugging\n"), SZAPPNAME) ;
		   return	EXIT_FAILURE ;
		}
		return	EXIT_SUCCESS ;
	}

   printf( "\nStartServiceCtrlDispatcher being called.\n" );
   printf( "This may take several seconds.  Please wait.\n" );

   if (!StartServiceCtrlDispatcher (dispatchTable))
		AddToMessageLog(TEXT ("StartServiceCtrlDispatcher failed.")) ;

   return	EXIT_SUCCESS ;
}

//
//  FUNCTION: service_main
//
//  PURPOSE: To perform actual initialization of the service
//
//  PARAMETERS:
//    dwArgc   - number of command line arguments
//    lpszArgv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//    This routine performs the service initialization and then calls
//    the user defined ServiceStart() routine to perform majority
//    of the work.
//
void WINAPI
service_main (DWORD dwArgc, LPTSTR *lpszArgv)
{
	OutputDebugString (TEXT ("service_main\n")) ;

	// register our service control handler:
	//
	sshStatusHandle	= RegisterServiceCtrlHandler (SZSERVICENAME, service_ctrl) ;
	if (!sshStatusHandle)
		goto	cleanup ;

	// SERVICE_STATUS members that don't change in example
	//
	ssStatus.dwServiceType				= SERVICE_WIN32_OWN_PROCESS ;
	ssStatus.dwServiceSpecificExitCode	= 0 ;


	// report the status to the service control manager.
	//
	if (!ReportStatusToSCMgr (SERVICE_START_PENDING, NO_ERROR, 3000))
		goto	cleanup ;

	ServiceStart (dwArgc, lpszArgv) ;

cleanup:

   // try to report the stopped status to the service control manager.
   //
   if (sshStatusHandle)
		(VOID)ReportStatusToSCMgr (SERVICE_STOPPED, dwErr, 0) ;
   return ;
}



//
//  FUNCTION: service_ctrl
//
//  PURPOSE: This function is called by the SCM whenever
//           ControlService() is called on this service.
//
//  PARAMETERS:
//    dwCtrlCode - type of control requested
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
VOID WINAPI service_ctrl(DWORD dwCtrlCode)
{
	// Handle the requested control code.
	//
	switch (dwCtrlCode) {
	// Stop the service.
	//
	// SERVICE_STOP_PENDING should be reported before
	// setting the Stop Event - hServerStopEvent - in
	// ServiceStop().  This avoids a race condition
	// which may result in a 1053 - The Service did not respond...
	// error.
	case SERVICE_CONTROL_STOP:
		ReportStatusToSCMgr(SERVICE_STOP_PENDING, NO_ERROR, 0);
		ServiceStop();
		return;

		// Update the service status.
		//
	case SERVICE_CONTROL_INTERROGATE:
		break;

		// invalid control code
		//
	default:
		break;
	}

	ReportStatusToSCMgr(ssStatus.dwCurrentState, NO_ERROR, 0);
	return ;
}



//
//  FUNCTION: ReportStatusToSCMgr()
//
//  PURPOSE: Sets the current status of the service and
//           reports it to the Service Control Manager
//
//  PARAMETERS:
//    dwCurrentState - the state of the service
//    dwWin32ExitCode - error code to report
//    dwWaitHint - worst case estimate to next checkpoint
//
//  RETURN VALUE:
//    TRUE  - success
//    FALSE - failure
//
//  COMMENTS:
//
BOOL
ReportStatusToSCMgr(DWORD dwCurrentState,
                         DWORD dwWin32ExitCode,
                         DWORD dwWaitHint)
{
   static DWORD dwCheckPoint = 1;
   BOOL fResult = TRUE;

   if (! bDebug) {
	   // when debugging we don't report to the SCM
		if (dwCurrentState == SERVICE_START_PENDING) {
			ssStatus.dwControlsAccepted = 0;
		} else {
			ssStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
		}
		ssStatus.dwCurrentState = dwCurrentState;
		ssStatus.dwWin32ExitCode = dwWin32ExitCode;
		ssStatus.dwWaitHint = dwWaitHint;

		if (dwCurrentState == SERVICE_RUNNING ||
			dwCurrentState == SERVICE_STOPPED) {
			ssStatus.dwCheckPoint = 0;
		} else {
			ssStatus.dwCheckPoint = dwCheckPoint++;
		}

		// Report the status of the service to the service control manager.
		//
		if (!(fResult = SetServiceStatus( sshStatusHandle, &ssStatus))) {
			AddToMessageLog (TEXT ("SetServiceStatus")) ;
		}
	}
	return	fResult ;
}



//
//  FUNCTION: AddToMessageLog(LPTSTR lpszMsg)
//
//  PURPOSE: Allows any thread to log an error message
//
//  PARAMETERS:
//    lpszMsg - text for message
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
void
AddToMessageLog (LPTSTR lpszMsg)
{
	TCHAR	szMsg [(sizeof(SZSERVICENAME) / sizeof(TCHAR)) + 100 ];
	HANDLE  hEventSource;
	LPTSTR  lpszStrings[2];
	int		nText ;

	if (! bDebug) {
		dwErr = GetLastError();

		// Use event logging to log the error.
		//
		hEventSource = RegisterEventSource (NULL, SZSERVICENAME) ;

		switch (dwErr) {
		case	ERROR_FAILED_SERVICE_CONTROLLER_CONNECT:
			nText	= wnsprintf (szMsg, ARRAYSIZE (szMsg) - 1, TEXT ("%s error: ERROR_FAILED_SERVICE_CONROLLER_CONNECT"), SZSERVICENAME) ;
			break ;
		case	ERROR_INVALID_DATA:
			nText	= wnsprintf (szMsg, ARRAYSIZE (szMsg) - 1, TEXT ("%s error: ERROR_INVALID_DATA"), SZSERVICENAME) ;
			break ;
		case	ERROR_SERVICE_ALREADY_RUNNING:
			nText	= wnsprintf (szMsg, ARRAYSIZE (szMsg) - 1, TEXT ("%s error: ERROR_SERVICE_ALREADY_RUNNING"), SZSERVICENAME) ;
			break ;
		default:
			nText	= wnsprintf (szMsg, ARRAYSIZE (szMsg) - 1, TEXT ("%s error: %d"), SZSERVICENAME, dwErr);
			break ;
		}
		szMsg [nText]	= TEXT ('\0') ;
		lpszStrings[0] = szMsg;
		lpszStrings[1] = lpszMsg;

		_tprintf (TEXT ("%s\n"), szMsg) ;

		if (hEventSource != NULL) {
			ReportEvent(hEventSource, // handle of event source
                     EVENTLOG_ERROR_TYPE,  // event type
                     0,                    // event category
                     0,                    // event ID
                     NULL,                 // current user's SID
                     2,                    // strings in lpszStrings
                     0,                    // no bytes of raw data
                     lpszStrings,          // array of error strings
                     NULL);                // no raw data

			(VOID) DeregisterEventSource(hEventSource);
		}
	}
	return ;
}




///////////////////////////////////////////////////////////////////
//
//  The following code handles service installation and removal
//


//
//  FUNCTION: CmdInstallService()
//
//  PURPOSE: Installs the service
//
//  PARAMETERS:
//    none
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
void CmdInstallService (void)
{
	SC_HANDLE   schService ;
	SC_HANDLE   schSCManager ;

	TCHAR szPath[512];

	if (GetModuleFileName (NULL, szPath, 512) == 0) {
		_tprintf (TEXT("Unable to install %s - %s\n"), SZSERVICEDISPLAYNAME, GetLastErrorText(szErr, 256)) ;
		return	;
	}

	schSCManager	= OpenSCManager(
                               NULL,                   // machine (NULL == local)
                               NULL,                   // database (NULL == default)
                               SC_MANAGER_CONNECT | SC_MANAGER_CREATE_SERVICE  // access required
                               );
	if (schSCManager) {
		schService = CreateService(
								schSCManager,               // SCManager database
								SZSERVICENAME,        // name of service
								SZSERVICEDISPLAYNAME, // name to display
								SERVICE_QUERY_STATUS,         // desired access
								SERVICE_WIN32_OWN_PROCESS,  // service type
								SERVICE_DEMAND_START,       // start type
								SERVICE_ERROR_NORMAL,       // error control type
								szPath,                     // service's binary
								NULL,                       // no load ordering group
								NULL,                       // no tag identifier
								SZDEPENDENCIES,       // dependencies
								NULL,                       // LocalSystem account
								NULL);                      // no password

		if (schService) {
			_tprintf (TEXT ("%s installed.\n"), SZSERVICEDISPLAYNAME) ;
			CloseServiceHandle (schService) ;
		} else {
			_tprintf (TEXT ("CreateService failed - %s\n"), GetLastErrorText (szErr, 256)) ;
		}
		CloseServiceHandle (schSCManager) ;
	} else {
      _tprintf (TEXT ("OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256));
	}
	return ;
}



//
//  FUNCTION: CmdRemoveService()
//
//  PURPOSE: Stops and removes the service
//
//  PARAMETERS:
//    none
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
void	CmdRemoveService (void)
{
	SC_HANDLE   schService;
	SC_HANDLE   schSCManager;

	schSCManager = OpenSCManager(
                               NULL,                   // machine (NULL == local)
                               NULL,                   // database (NULL == default)
                               SC_MANAGER_CONNECT   // access required
                               );
	if (schSCManager) {
		schService = OpenService(schSCManager, SZSERVICENAME, DELETE | SERVICE_STOP | SERVICE_QUERY_STATUS);

		if (schService) {
			// try to stop the service
			if (ControlService (schService, SERVICE_CONTROL_STOP, &ssStatus)) {
				_tprintf (TEXT("Stopping %s."), SZSERVICEDISPLAYNAME);
				Sleep (1000) ;

				while (QueryServiceStatus (schService, &ssStatus)) {
					if (ssStatus.dwCurrentState == SERVICE_STOP_PENDING) {
						_tprintf (TEXT("."));
						Sleep( 1000 );
					} else {
						break ;
					}
				}

				if ( ssStatus.dwCurrentState == SERVICE_STOPPED) {
					_tprintf (TEXT ("\n%s stopped.\n"), SZSERVICEDISPLAYNAME );
				} else {
					_tprintf (TEXT ("\n%s failed to stop.\n"), SZSERVICEDISPLAYNAME );
				}
			}

			// now remove the service
			if (DeleteService (schService)) {
				_tprintf (TEXT("%s removed.\n"), SZSERVICEDISPLAYNAME );
			} else {
				_tprintf (TEXT("DeleteService failed - %s\n"), GetLastErrorText(szErr,256));
			}
			CloseServiceHandle (schService) ;
		} else {
         _tprintf (TEXT("OpenService failed - %s\n"), GetLastErrorText(szErr,256));
		}
		CloseServiceHandle (schSCManager) ;
	}  else {
      _tprintf (TEXT ("OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256));
	}
	return ;
}

///////////////////////////////////////////////////////////////////
//
//  The following code is for running the service as a console app
//


//
//  FUNCTION: CmdDebugService(int argc, char ** argv)
//
//  PURPOSE: Runs the service as a console application
//
//  PARAMETERS:
//    argc - number of command line arguments
//    argv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
void CmdDebugService(int argc, TCHAR** argv)
{
	DWORD dwArgc;
	LPTSTR *lpszArgv;

#ifdef UNICODE
	lpszArgv = CommandLineToArgvW (GetCommandLineW (), &(dwArgc)) ;
	if (NULL == lpszArgv) {
       // CommandLineToArvW failed!!
       _tprintf (TEXT("CmdDebugService CommandLineToArgvW returned NULL\n"));
       return;
	}
#else
	dwArgc		= (DWORD) argc;
	lpszArgv	= argv;
#endif
   _tprintf (TEXT("Debugging %s.\n"), SZSERVICEDISPLAYNAME);

	SetConsoleCtrlHandler( ControlHandler, TRUE );
	ServiceStart( dwArgc, lpszArgv );

#ifdef UNICODE
	// Must free memory allocated for arguments
	GlobalFree(lpszArgv);
#endif // UNICODE
	return ;
}


//
//  FUNCTION: ControlHandler ( DWORD dwCtrlType )
//
//  PURPOSE: Handled console control events
//
//  PARAMETERS:
//    dwCtrlType - type of control event
//
//  RETURN VALUE:
//    True - handled
//    False - unhandled
//
//  COMMENTS:
//
BOOL WINAPI ControlHandler ( DWORD dwCtrlType )
{
	switch ( dwCtrlType ) {
	case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate
	case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode
		_tprintf (TEXT("Stopping %s.\n"), SZSERVICEDISPLAYNAME);
		ServiceStop();
		return TRUE;
	default:
		break ;
	}
	return	FALSE;
}

//
//  FUNCTION: GetLastErrorText
//
//  PURPOSE: copies error message text to string
//
//  PARAMETERS:
//    lpszBuf - destination buffer
//    dwSize - size of buffer
//
//  RETURN VALUE:
//    destination buffer
//
//  COMMENTS:
//
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize )
{
	DWORD dwRet;
	LPTSTR lpszTemp = NULL;
	int		nText ;

	dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                          NULL,
                          GetLastError(),
                          LANG_NEUTRAL,
                          (LPTSTR)&lpszTemp,
                          0,
                          NULL );

	// supplied buffer is not long enough
	if ( !dwRet || ( (long)dwSize < (long)dwRet+14)) {
      lpszBuf[0] = '\0';
	} else {
		lpszTemp[lstrlen(lpszTemp)-2] = '\0';  //remove cr and newline character
		nText	= wnsprintf (lpszBuf, dwSize - 1, TEXT ("%s (0x%x)"), lpszTemp, GetLastError() );
		lpszBuf [nText]	= TEXT ('\0') ;
	}

   if ( lpszTemp )
      LocalFree((HLOCAL) lpszTemp );

   return lpszBuf;
}
