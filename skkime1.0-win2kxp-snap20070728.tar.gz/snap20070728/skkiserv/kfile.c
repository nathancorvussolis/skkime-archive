#include "local.h"
#include <assert.h>
#include "kfile.h"

enum {
	CHECKSIZE			= (2048),
} ;


BOOL
KFile_Init (
	register KFILE*	pFile)
{
	assert (pFile != NULL) ;

	pFile->m_iCodingSystem	= KCODING_SYSTEM_UNKNOWN ;

	pFile->m_pf	= NULL ;
	return	TRUE ;
}
	
BOOL
KFile_Open (
	register KFILE*			pFile,
	register LPCTSTR		pFileName,
	register int			iCodingSystem)
{
	assert (pFile != NULL) ;

	pFile->m_pf	= _tfopen (pFileName, TEXT("rb")) ;
	if (pFile->m_pf == NULL)
		return	FALSE ;

	if (iCodingSystem == KCODING_SYSTEM_UNKNOWN) {
		iCodingSystem	= KFile_DetectCodingSystem (pFile) ;
		if (iCodingSystem == KCODING_SYSTEM_UNKNOWN)
			iCodingSystem	= KCODING_SYSTEM_BINARY ;
	}
	pFile->m_iCodingSystem	= iCodingSystem ;
	InitializeKanjiFiniteStateMachine (&pFile->m_ksm, iCodingSystem) ;
	return	TRUE ;
}

BOOL
KFile_Close (
	register KFILE*			pFile)
{
	assert (pFile != NULL) ;

	return	(!fclose (pFile->m_pf))? TRUE : FALSE ;
}

Char
KFile_Getc (
	register KFILE*			pFile)
{
	register int		cc ;
	Char	dwc ;
	
	assert (pFile != NULL) ;

	dwc	= (Char)EOF ;
	while (
		cc	= fgetc (pFile->m_pf),
		cc != EOF) {
		if (TSUCCEEDED (TransferKanjiFiniteStateMachine (&pFile->m_ksm, cc, &dwc)))
			break ;
	}
	return	(cc == EOF)? EOF : dwc ;
}

BOOL
KFile_FindsAtBeginningOfLine (
	register KFILE*			pFile,
	register const Char*	pString)
{
	register Char			cc ;
	register const Char*	ptr ;

	assert (pFile != NULL) ;

	while (cc = KFile_Getc (pFile), cc != EOF) {
		if (cc == *pString) {
			ptr	= pString + 1 ;
			while (!Char_IsNul (*ptr)) {
				cc = KFile_Getc (pFile) ;
				if (cc == EOF || cc != *ptr)
					break ;
				ptr	++ ;
			}
			if (cc == EOF)
				break ;
			if (Char_IsNul (*ptr))
				return	TRUE ;
		}
		if (cc != '\n')
			if (!KFile_Nextline (pFile))
				break ;
	}
	return	FALSE ;
}

BOOL
KFile_FindsAtBeginningOfLineA (
	register KFILE*			pFile,
	register const char*	pString)
{
	register Char			cc ;
	register const char*	ptr ;

	assert (pFile != NULL) ;
	assert (pString != NULL && *pString != '\0') ;

	while (cc = KFile_Getc (pFile), cc != EOF) {
		if (!Char_DifferenceAscii (cc, *pString)) {
			ptr	= pString + 1 ;
			while (*ptr != '\0') {
				cc = KFile_Getc (pFile) ;
				if (cc == EOF || Char_DifferenceAscii (cc, *ptr))
					break ;
				ptr	++ ;
			}
			if (cc == EOF)
				break ;
			if (*ptr == '\0')
				return	TRUE ;
		}
		if (cc != '\n')
			if (!KFile_Nextline (pFile))
				break ;
	}
	return	FALSE ;
}

BOOL
KFile_Cmps (
	register KFILE*			pFile,
	register const Char*	pString)
{
	register Char		cc ;

	assert (pFile != NULL) ;
	assert (pString != NULL) ;
	
	while (!Char_IsNul (*pString)) {
		cc = KFile_Getc (pFile) ;
		if (cc == EOF || *pString != cc)
			break ;
		pString	++ ;
	}
	return	Char_IsNul (*pString) ;
}

BOOL
KFile_Cmpsn (
	register KFILE*			pFile,
	register const Char*	pString,
	register int			nStrLength)
{
	register Char		cc ;

	assert (pFile != NULL) ;
	assert (pString != NULL || nStrLength <= 0) ;
	
	while (nStrLength > 0 && !Char_IsNul (*pString)) {
		cc = KFile_Getc (pFile) ;
		if (cc == EOF || *pString != cc)
			break ;
		pString		++ ;
		nStrLength	-- ;
	}
	return	(nStrLength == 0 || Char_IsNul (*pString))? TRUE : FALSE ;
}

BOOL
KFile_Nextline (
	register KFILE*		pFile)
{
	register Char			cc ;

	assert (pFile != NULL) ;

	while (cc = KFile_Getc (pFile), cc != EOF && cc != '\n')
		;
	
	return	(cc == EOF)? FALSE : TRUE ;
}

BOOL
KFile_Tell (
	register KFILE*		pFile,
	register KFILEPOS*	pPos)
{
	assert (pFile != NULL) ;
	assert (pPos  != NULL) ;

	pPos->m_lPosition	= ftell (pFile->m_pf) ;
	memcpy (&pPos->m_ksm, &pFile->m_ksm, sizeof (KANJISTATEMACHINE)) ;
	return	TRUE ;
}

BOOL
KFile_Seek (
	register KFILE*		pFile,
	register KFILEPOS*	pPos)
{
	assert (pFile != NULL) ;
	assert (pPos  != NULL) ;

	fseek (pFile->m_pf, pPos->m_lPosition, SEEK_SET) ;
	memcpy (&pFile->m_ksm, &pPos->m_ksm, sizeof (KANJISTATEMACHINE)) ;
	return	TRUE ;
}

BOOL
KFile_Seekn (
	register KFILE*		pFile,
	register long		lOffset,
	register int		nWhence)
{
	fseek (pFile->m_pf, lOffset, nWhence) ;
	InitializeKanjiFiniteStateMachine (&pFile->m_ksm, pFile->m_iCodingSystem) ;
	return	TRUE ;
}

BOOL
KFile_Rewind (
	register KFILE*		pFile)
{
	assert (pFile != NULL) ;

	rewind (pFile->m_pf) ;

	InitializeKanjiFiniteStateMachine (&pFile->m_ksm, pFile->m_iCodingSystem) ;
	return	TRUE ;
}

int
KFile_GetCodingSystem (
	register KFILE*		pFile)
{
	assert (pFile != NULL) ;

	return	pFile->m_iCodingSystem ;
}

int
KFile_DetectCodingSystem (
	register KFILE*		pFile)
{
	char			achBuf [CHECKSIZE] ;
	register int	nRead ;

	assert (pFile != NULL) ;
	
	nRead			= fread (achBuf, sizeof (char), CHECKSIZE, pFile->m_pf) ;

	/*	Unicode �� check ������B*/
	if (nRead >= 2 &&
		(unsigned char)achBuf [0] == 0xFF && 
		(unsigned char)achBuf [1] == 0xFE) 
		return	KCODING_SYSTEM_UNICODE ;

	return	DetectKanjiCodingSystem (achBuf, nRead, NULL) ;
}


