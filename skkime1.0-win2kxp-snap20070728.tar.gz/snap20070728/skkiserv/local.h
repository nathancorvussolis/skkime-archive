#pragma once

#if !defined (windows_h)
#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <tchar.h>
#include <limits.h>
#include <locale.h>
#include <lmcons.h>
#define	windows_h
#endif
#include "debug.h"

#define	MALLOC(x)			malloc((x))
#define	FREE(x)				free((x))
#define	TFAILED(x)			(!(x))
#define	TSUCCEEDED(x)		((x))

#if !defined (ARRAYSIZE)
#define	ARRAYSIZE(array)	(sizeof array / sizeof array[0])
#endif

#if !defined (PATH_MAX)
#define	PATH_MAX			MAX_PATH
#endif


