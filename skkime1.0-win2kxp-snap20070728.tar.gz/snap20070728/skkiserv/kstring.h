#if !defined (kstring_h)
#define	kstring_h

#include "Char.h"

int		wstr2internal	(Char*, int, LPCWSTR, int) ;
int		internal2wstr	(LPWSTR, int, const Char*, int) ;
BOOL	internalStringContainsUnicodeCharp (const Char*, int) ;

#endif

