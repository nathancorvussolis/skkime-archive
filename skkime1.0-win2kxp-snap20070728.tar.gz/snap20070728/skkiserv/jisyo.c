#include "local.h"
#include "jisyo.h"

BOOL
SkkJisyo_Search (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register BOOL			fOkuri,
	register TVarbuffer*	pvbufResult)
{
	assert (pSkkJisyo != NULL) ;
	assert (pSkkJisyo->m_pVtbl != NULL) ;

	if (pSkkJisyo->m_pVtbl->m_pSearch == NULL)
		return	TRUE ;
	return	(pSkkJisyo->m_pVtbl->m_pSearch)(pSkkJisyo, pKey, nKey, fOkuri, pvbufResult) ;
}

BOOL
SkkJisyo_TryCompletion (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register TVarbuffer*	pvbufResult)
{
	assert (pSkkJisyo != NULL) ;
	assert (pSkkJisyo->m_pVtbl != NULL) ;

	if (pSkkJisyo->m_pVtbl->m_pCompletion == NULL)
		return	TRUE ;
	return	(pSkkJisyo->m_pVtbl->m_pCompletion)(pSkkJisyo, pKey, nKey, pvbufResult) ;
}

BOOL
SkkJisyo_Record (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register BOOL			fOkuri,
	register const Char*	pCand,
	register int			nCand)
{
	assert (pSkkJisyo != NULL) ;
	assert (pSkkJisyo->m_pVtbl != NULL) ;

	if (pSkkJisyo->m_pVtbl->m_pRecord == NULL)
		return	TRUE ;

	return	(pSkkJisyo->m_pVtbl->m_pRecord)(pSkkJisyo, pKey, nKey, fOkuri, pCand, nCand) ;
}

BOOL
SkkJisyo_Purge (
	register SkkJisyo*		pSkkJisyo,
	register const Char*	pKey,
	register int			nKey,
	register BOOL			fOkuri,
	register const Char*	pCand,
	register int			nCand)
{
	assert (pSkkJisyo != NULL) ;
	assert (pSkkJisyo->m_pVtbl != NULL) ;

	if (pSkkJisyo->m_pVtbl->m_pPurge == NULL)
		return	TRUE ;

	return	(pSkkJisyo->m_pVtbl->m_pPurge)(pSkkJisyo, pKey, nKey, fOkuri, pCand, nCand) ;
}

BOOL
SkkJisyo_Save (
	register SkkJisyo*		pSkkJisyo)
{
	assert (pSkkJisyo != NULL) ;
	assert (pSkkJisyo->m_pVtbl != NULL) ;

	if (pSkkJisyo->m_pVtbl->m_pSave == NULL)
		return	TRUE ;

	return	(pSkkJisyo->m_pVtbl->m_pSave)(pSkkJisyo) ;
}

BOOL
SkkJisyo_Destroy (
	register SkkJisyo*		pSkkJisyo)
{
	if (pSkkJisyo == NULL)
		return	TRUE ;
	assert (pSkkJisyo->m_pVtbl != NULL) ;
	assert (pSkkJisyo->m_pVtbl->m_pDestroy != NULL) ;
	return	(pSkkJisyo->m_pVtbl->m_pDestroy)(pSkkJisyo) ;
}

LPCTSTR
SkkJisyo_GetPath (
	register SkkJisyo*		pSkkJisyo)
{
	if (pSkkJisyo == NULL ||
		pSkkJisyo->m_pVtbl == NULL ||
		pSkkJisyo->m_pVtbl->m_pDestroy == NULL)
		return	NULL ;
	return	(pSkkJisyo->m_pVtbl->m_pGetPath)(pSkkJisyo) ;
}


