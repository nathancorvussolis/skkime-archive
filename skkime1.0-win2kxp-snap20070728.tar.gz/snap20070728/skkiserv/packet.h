#if !defined (packet_h)
#define	packet_h

#include "Char.h"
#include "varbuffer.h"

#define	bytep2word(ptr)	(((WORD)((ptr)[0])) | ((WORD)((ptr)[1]) << 8))

BOOL	TPacket_SetHeader	(TVarbuffer*, int, int) ;
BOOL	TPacket_AddPad		(TVarbuffer*) ;
BOOL	TPacket_AddCard32	(TVarbuffer*, DWORD) ;
BOOL	TPacket_AddCard16	(TVarbuffer*, WORD) ;
BOOL	TPacket_AddCard8	(TVarbuffer*, BYTE) ;
BOOL	TPacket_SetLength	(TVarbuffer*) ;
BOOL	TPacket_SetCard16	(TVarbuffer*, int, WORD) ;
BOOL	TPacket_AddKanji	(TVarbuffer*, const Char*, int) ;
BOOL	TPacket_AddString	(TVarbuffer*, LPCWSTR, int) ;

#endif
