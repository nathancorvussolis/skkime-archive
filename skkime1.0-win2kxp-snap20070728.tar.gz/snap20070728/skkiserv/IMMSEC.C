#include <windows.h>
#include <stdio.h>
#include <sddl.h>
#include <AccCtrl.h>
#include <Aclapi.h>
#include <shlwapi.h>
#include "immsec.h"
#include "debug.h"

#define MEMALLOC(x)      LocalAlloc(LMEM_FIXED, x)
#define MEMFREE(x)       LocalFree(x)

//
// internal functions
//
PSID			MyCreateSid		() ;
POSVERSIONINFO	GetVersionInfo	() ;

//
// debug functions
//
#if defined (DEBUG)
#define ERROROUT(x)      ErrorOut (x) 
#define WARNOUT(x)       WarnOut (x) 
#else
#define ERROROUT(x)		/*(x)*/
#define WARNOUT(x)		/*(x)*/
#endif

#ifdef DEBUG
VOID WarnOut (PTSTR pStr) 
{
    OutputDebugString (pStr) ;
}

VOID ErrorOut (PTSTR pStr) 
{
    DWORD dwError;
    DWORD dwResult;
    TCHAR buf1[512];
    TCHAR buf2[512];
	int		nText ;

    dwError = GetLastError();
    dwResult = FormatMessage (FORMAT_MESSAGE_FROM_SYSTEM,
                              NULL,
                              dwError,
                              MAKELANGID (LANG_ENGLISH, LANG_NEUTRAL) ,
                              buf1,
                              512,
                              NULL) ;                                   
    
    if  (dwResult > 0)  {
		nText	= wnsprintf (buf2, ARRAYSIZE (buf2) - 1, TEXT("%s:%s(0x%x)"), pStr, buf1, dwError);
    } else {
        nText	= wnsprintf (buf2, ARRAYSIZE (buf2) - 1, TEXT("%s:(0x%x)"), pStr, dwError);
    }
	buf2 [nText]	= TEXT ('\0') ;
    OutputDebugString (buf2) ;
}
#endif

PSECURITY_ATTRIBUTES CreateSecurityAttributes()
{
#if WINVER >= 0x0600
#define LOW_INTEGRITY_SDDL_SACL_W L"S:(ML;;NW;;;LW)"
	// The LABEL_SECURITY_INFORMATION SDDL SACL to be set for low integrity 
	DWORD					dwErr	= ERROR_SUCCESS ;
	PSECURITY_DESCRIPTOR	pSD		= NULL ;
	PSECURITY_ATTRIBUTES	psa		= NULL ;

	if (ConvertStringSecurityDescriptorToSecurityDescriptorW (LOW_INTEGRITY_SDDL_SACL_W, SDDL_REVISION_1, &pSD, NULL)) {
		psa = (PSECURITY_ATTRIBUTES)MEMALLOC (sizeof (SECURITY_ATTRIBUTES)) ;
		if  (psa == NULL)  {
			DEBUGPRINTFEX (103, (TEXT("CreateSecurityAttributes:LocalAlloc for psa failed\n"))) ;
			return NULL;
		}
		psa->nLength				= sizeof (SECURITY_ATTRIBUTES) ;
		psa->lpSecurityDescriptor	= (PVOID)pSD ;
		psa->bInheritHandle			= TRUE ;
	} else {
		psa	= NULL ;
	}
    return	psa ;
#else
	return	NULL ;
#endif
}


PSID MyCreateSid ()
{
    PSID        psid;
    BOOL        fResult;
    SID_IDENTIFIER_AUTHORITY SidAuthority = SECURITY_WORLD_SID_AUTHORITY;

    //
    // allocate and initialize an SID
    // 
    fResult = AllocateAndInitializeSid (&SidAuthority,
                                        1,
                                        SECURITY_WORLD_RID,
                                        0,0,0,0,0,0,0,
                                        &psid) ;
    if  (! fResult)  {
        ERROROUT (TEXT("MyCreateSid:AllocateAndInitializeSid failed"));
        return NULL;
    }

    if  (! IsValidSid (psid) ) {
        WARNOUT (TEXT("MyCreateSid:AllocateAndInitializeSid returns bogus sid"));
        FreeSid (psid) ;
        return NULL;
    }

    return psid;
}

//
// FreeSecurityAttributes()
//
// The purpose of this function:
//
//      Frees the memory objects allocated by previous
//      CreateSecurityAttributes() call.
//
VOID FreeSecurityAttributes (PSECURITY_ATTRIBUTES psa) 
{
    BOOL fResult;
    BOOL fDaclPresent;
    BOOL fDaclDefaulted;
    PACL pacl;

    if (psa == NULL)
        return;

    fResult = GetSecurityDescriptorDacl (psa->lpSecurityDescriptor,
                                         &fDaclPresent,
                                         &pacl,
                                         &fDaclDefaulted) ;                  
    if  (fResult)  {
        if  (pacl != NULL) 
            MEMFREE (pacl) ;
    } else {
        ERROROUT (TEXT("FreeSecurityAttributes:GetSecurityDescriptorDacl failed"));
    }

    MEMFREE (psa->lpSecurityDescriptor) ;
    MEMFREE (psa) ;
}

//
// IsNT()
//
// Return value:
//
//      TRUE if the current system is Windows NT
//
// Remarks:
//
//      The implementation of this function is not multi-thread safe.
//      You need to modify the function if you call the function in 
//      multi-thread environment.
//
BOOL IsNT()
{
    return GetVersionInfo()->dwPlatformId == VER_PLATFORM_WIN32_NT;
}

POSVERSIONINFO GetVersionInfo()
{
    static BOOL fFirstCall = TRUE;
    static OSVERSIONINFO os;

    if  (fFirstCall)  {
        os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
        if  (GetVersionEx (&os) ) {
            fFirstCall = FALSE;
        }
    }
    return &os;
}

void SetLowLabelToHandle (HANDLE hFile)
{
#if WINVER >= 0x0600
#define LOW_INTEGRITY_SDDL_SACL_W L"S:(ML;;NW;;;LW)"
	// The LABEL_SECURITY_INFORMATION SDDL SACL to be set for low integrity 
	DWORD					dwErr	= ERROR_SUCCESS ;
	PSECURITY_DESCRIPTOR	pSD		= NULL ;

	PACL pSacl			= NULL ;	// not allocated
	BOOL fSaclPresent	= FALSE ;
	BOOL fSaclDefaulted	= FALSE ;

	if (ConvertStringSecurityDescriptorToSecurityDescriptorW (LOW_INTEGRITY_SDDL_SACL_W, SDDL_REVISION_1, &pSD, NULL)) {
		if (GetSecurityDescriptorSacl(pSD, &fSaclPresent, &pSacl, &fSaclDefaulted)) {
			// Note that psidOwner, psidGroup, and pDacl are 
			// all NULL and set the new LABEL_SECURITY_INFORMATION
			dwErr = SetSecurityInfo (hFile, SE_KERNEL_OBJECT, LABEL_SECURITY_INFORMATION, NULL, NULL, NULL, pSacl);
			DEBUGPRINTFEX (103, (TEXT ("SetScurityInfo result (0x%0x/%d)\n"), dwErr, dwErr)) ;
		} else {
			dwErr	= GetLastError () ;
			DEBUGPRINTFEX (103, (TEXT ("GetSecurityDescriptorSacl failed (0x%0x/%d)\n"), dwErr, dwErr)) ;
		}
		LocalFree (pSD) ;
	} else {
		dwErr	= GetLastError () ;
		DEBUGPRINTFEX (103, (TEXT ("ConvertStringSecurityDescriptorToSecurityDescriptorW failed (0x%0x/%d)\n"), dwErr, dwErr)) ;
	}
#endif
	return ;
}
