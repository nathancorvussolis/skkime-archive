#include "local.h"
#include <stdio.h>
#include <assert.h>

static	int		url_isScheme		(LPCTSTR, int) ;
static	int		url_isUrlpath		(LPCTSTR, int) ;
static	int		url_isHostport		(LPCTSTR, int) ;
static	int		url_isHost			(LPCTSTR, int) ;
static	int		url_isHostname		(LPCTSTR, int) ;
static	int		url_isDomainlabel	(LPCTSTR, int) ;
static	int		url_isToplabel		(LPCTSTR, int) ;
static	int		url_isHostnumber	(LPCTSTR, int) ;
static	int		url_isHpath			(LPCTSTR, int) ;
static	int		url_isHsegment		(LPCTSTR, int) ;
static	int		url_isHiAlpha		(LPCTSTR, int) ;
static	int		url_isLowAlpha		(LPCTSTR, int) ;
static	int		url_isAlpha			(LPCTSTR, int) ;
static	int		url_isDigit			(LPCTSTR, int) ;
static	int		url_isAlphaDigit	(LPCTSTR, int) ;
static	int		url_isSafe			(LPCTSTR, int) ;
static	int		url_isExtra			(LPCTSTR, int) ;
static	int		url_isReserved		(LPCTSTR, int) ;
static	int		url_isHex			(LPCTSTR, int) ;
static	int		url_isEscape		(LPCTSTR, int) ;
static	int		url_isUnreserved	(LPCTSTR, int) ;
static	int		url_isUchar			(LPCTSTR, int) ;
static	int		url_isXchar			(LPCTSTR, int) ;
static	int		url_isDigits		(LPCTSTR, int) ;

#define	url_isSearch(x,y)		url_isHsegment((x),(y))
#define	url_isPort(x,y)			url_isDigits((x),(y))

#if defined (TEST)
int
_tmain (void)
{
	TCHAR	rszBuffer [256] ;
	TCHAR	rszScheme [256], rszHost [256], rszPort [256], rszHPath [256] ;
	int		n ;

	while (!feof (stdin)) {
		printf ("> ") ;
		fflush (stdout) ;
		if (_fgetts (rszBuffer, 256, stdin) == NULL)
			break ;
		n	= lstrlen (rszBuffer) ;
		if (n <= 0)
			continue ;
		while (n > 0 && 
			   (rszBuffer [n - 1] == TEXT ('\n') ||
				rszBuffer [n - 1] == TEXT ('\r') ||
				rszBuffer [n - 1] == TEXT ('\t') ||
				rszBuffer [n - 1] == TEXT (' ')))
			n	-- ;
		if (URLParser_Process (rszBuffer, n, rszScheme, 256, rszHost, 256, rszPort, 256, rszHPath, 256)) {
			printf ("%s://%s:%s/%s\n", rszScheme, rszHost, rszPort, rszHPath) ;
		} else {
			printf ("parse error\n") ;
		}
	}
	return	0 ;
}
#endif

BOOL
URLParser_Process (
	register LPCTSTR	pString,
	register int		nString,
	register LPTSTR		pScheme,
	register int		nScheme,
	register LPTSTR		pHost,
	register int		nHost,
	register LPTSTR		pPort,
	register int		nPort,
	register LPTSTR		pHpath,
	register int		nHpath)
{
	register int	n, nCopy, nHostport ;

	n	= url_isScheme (pString, nString) ;
	if (n <= 0) {
#if defined (DEBUG) || 0
		fprintf (stderr, "Not found: scheme part\n") ;
#endif
		return	FALSE ;
	}
	if (pScheme != NULL && nScheme > 0) {
		nCopy	= ((nScheme - 1) > n)? n : (nScheme - 1) ;
		_tcsncpy (pScheme, pString, nCopy) ;
		*(pScheme + nCopy)	= TEXT ('\0') ;
	}
	pString	+= n ;
	nString	-= n ;
	if (nString < 3 || _tcsncmp (pString, TEXT ("://"), 3)) {
#if defined (TEST)
		fprintf (stderr, "Not found: ``://''\n") ;
#endif
		return	FALSE ;
	}
	pString	+= 3 ;
	nString	-= 3 ;

	nHostport	= url_isHostport (pString, nString) ;
	if (nHostport > 0) {
		n	= url_isHost (pString, nString) ;
		assert (n > 0) ;
		if (pHost != NULL && nHost > 0) {
			nCopy	= ((nHost - 1) > n)? n : (nHost - 1) ;
			_tcsncpy (pHost, pString, nCopy) ;
			*(pHost + nCopy)	= TEXT ('\0') ;
		}
		if (nHostport > n && *(pString + n) == TEXT (':')) {
			register int	nPortPartLen ;

			nPortPartLen	= url_isPort (pString + n + 1, nString - n - 1) ;
			assert (nPortPartLen > 0) ;
			if (pPort != NULL && nPort > 0) {
				nCopy	= ((nPort - 1) > nPortPartLen)? nPortPartLen : (nPort - 1) ;
				_tcsncpy (pPort, pString + n + 1, nCopy) ;
				*(pPort + nCopy)	= TEXT ('\0') ;
			}
		} else {
			if (pPort != NULL && nPort > 0) 
				*pPort	= TEXT ('\0') ;
		}
		pString	+= nHostport ;
		nString	-= nHostport ;
		if (nString <= 0) {
			if (pHpath != NULL && nHpath > 0)
				*pHpath	= TEXT ('\0') ;
			return	TRUE ;
		}
	} else {
		if (pHost != NULL && nHost > 0) 
			*pHost	= TEXT ('\0') ;
		if (pPort != NULL && nPort > 0) 
			*pPort	= TEXT ('\0') ;
	}
	if (*pString != TEXT('/')) {
#if defined (DEBUG) || 0
		fprintf (stderr, "Not found: ``/''(%c)\n", *pString) ;
#endif
		return	FALSE ;
	}
	pString	++ ;
	nString	-- ;
	n	= url_isHpath (pString, nString) ;
	if (pHpath != NULL && nHpath > 0) {
		nCopy	= ((nHpath - 1) > n)? n : (nHpath - 1) ;
		_tcsncpy (pHpath, pString, nCopy) ;
		*(pHpath + nCopy)	= TEXT ('\0') ;
	}
	pString	+= n ;
	nString	-= n ;
	return	TRUE ;
}

static int
tchar2hex (
	register TCHAR		ch)
{
	if (TEXT ('0') <= ch && ch <= TEXT ('9'))
		return	ch - TEXT ('0') ;
	if (TEXT ('a') <= ch && ch <= TEXT ('f'))
		return	ch - TEXT ('a') + 10 ;
	if (TEXT ('A') <= ch && ch <= TEXT ('F'))
		return	ch - TEXT ('A') + 10 ;
	return	-1 ;
}

BOOL
URLParser_strcpy (
	register LPTSTR		pDest,
	register int		nDest,
	register LPCTSTR	pSrc,
	register int		nSrc)
{
	register TCHAR		ch ;
	register int		n ;

	while (nDest > 0 && nSrc > 0) {
		/*	``% hex hex'' �����t�������̏����B���ۂ� char �ɕϊ�����B
		 *	escape ����Ă��镶���𔻒�ɂ͎g��Ȃ��B
		 */
		if ((n = url_isEscape (pSrc, nSrc)) == 3) {
			ch	= (tchar2hex (*(pSrc + 1)) << 4) | (tchar2hex (*(pSrc + 2))) ;
		} else {
			ch	= *pSrc ;
			n	= 1 ;
		}
		*pDest ++	= ch ;
		nDest  -- ;
		pSrc		+= n ;
		nSrc		-= n ;
	}
	if (nDest > 0)
		*pDest		= TEXT ('\0') ;
	return	TRUE ;
}

int
url_isScheme (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	n, nLength ;

	nLength	= 0 ;
	do {
		n	= url_isLowAlpha (pString, nString) ;
		if (n <= 0)
			n	= url_isDigit (pString, nString) ;
		if (n <= 0)
			if (nString > 0 && 
				(*pString == TEXT ('+') ||
				 *pString == TEXT ('-') ||
				 *pString == TEXT ('.'))) 
				n	= 1 ;
		pString	+= n ;
		nString -= n ;
		nLength	+= n ;
	}	while (n > 0) ;

	return	nLength ;
}

int
url_isUrlpath (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	nLength, n ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	nLength	= 0 ;
	while (n = url_isXchar (pString, nString), n > 0) {
		nLength	+= n ;
		pString	+= n ;
		nString	-= n ;
	}
	return	nLength ;
}

int
url_isHostport (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	n, nLength = 0 ;

	/*	host �̕����̏����B
	 */
	n	= url_isHost (pString, nString) ;
	if (n <= 0)
		return	0 ;

	pString	+= n ;
	nString	-= n ;
	nLength	+= n ;

	/*	[ ":" port ] �̏����Bport ���q�b�g���Ȃ�������A
	 *	[ ... ] ���̂𖳂��������Ƃɂ��Ă���B
	 */
	if (nString > 0 && *pString == TEXT (':')) {
		pString	++ ;
		nString	-- ;
		n	= url_isPort (pString, nString) ;
		if (n > 0)
			nLength	+= (n + 1) ;
	}
	return	nLength ;
}

int
url_isHost (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	n ;

	n		= url_isHostname (pString, nString) ;
	if (n > 0)
		return	n ;
	return	url_isHostnumber (pString, nString) ;
}

int
url_isHostname (
	register LPCTSTR	pString,
	register int		nString)
{
	register int		n, nptr, nLength ;
	register LPCTSTR	ptr ;

	ptr		= pString ;
	nptr	= nString ;
	nLength	= 0 ;
	for ( ; ; ) {
		n	= url_isDomainlabel (ptr, nptr) ;
#if defined (DEBUG) || 0
		fprintf (stderr, "-(%d)\n", n) ;
#endif
		if (n <= 0)
			break ;
		if (nptr <= n || *(ptr + n) != TEXT ('.'))
			break ;
		n		++ ;
		ptr		+= n ;
		nptr	-= n ;
		nLength	+= n ;
	}
	n	= url_isToplabel (ptr, nptr) ;
#if defined (DEBUG) || 0
	fprintf (stderr, "(%d, %d, %c)\n", nLength, n, *ptr) ;
#endif
	if (n > 0) 
		return	(nLength + n) ;

	return	url_isToplabel (pString, nString) ;
}

int
url_isDomainlabel (
	register LPCTSTR	pString,
	register int		nString)
{
	register int		n, nLength, nPos ;

	n	= url_isAlphaDigit (pString, nString) ;
	if (n <= 0)
		return	n ;

	pString	+= n ;
	nString	-= n ;
	nPos	= n ;	/* �m��ʒu�B*/
	nLength	= n ;

	/*	domainlabel = alphadigit | alphadigit *[ alphadigit | "-" ] alphadigit
	 *
	 *	�Ȃ̂ŁA"-" ���������ꍇ�A�Ō�� alphadigit �����Ȃ���Ί��߂��K�v
	 *	������B����������ƁAalphadigit �����t����΁A�����܂ł͊m�肷��B
	 */
	for ( ; ; ) {
		if (nString > 0 && *pString == TEXT ('-')) {
			n	= 1 ;
		} else {
			n	= url_isAlphaDigit (pString, nString) ;
			if (n <= 0) 
				break ;
			nPos	= nLength + n ;
		}
		pString		+= n ;
		nString		-= n ;
		nLength		+= n ;
	}
	return	nPos ;
}

int
url_isToplabel (
	register LPCTSTR	pString,
	register int		nString)
{
	register int		n, nLength, nPos ;

	n	= url_isAlpha (pString, nString) ;
	if (n <= 0)
		return	n ;

	pString	+= n ;
	nString	-= n ;
	nPos	= n ;	/* �m��ʒu�B*/
	nLength	= n ;

	/*	toplabel = alpha | alpha *[ alphadigit | "-" ] alphadigit
	 *
	 *	�Ȃ̂ŁA"-" ���������ꍇ�A�Ō�� alphadigit �����Ȃ���Ί��߂��K�v
	 *	������B����������ƁAalphadigit �����t����΁A�����܂ł͊m�肷��B
	 */
	for ( ; ; ) {
		if (nString > 0 && *pString == TEXT ('-')) {
			n	= 1 ;
		} else {
			n	= url_isAlphaDigit (pString, nString) ;
			if (n <= 0) 
				break ;
			nPos	= nLength + n ;
		}
		pString		+= n ;
		nString		-= n ;
		nLength		+= n ;
	}
	return	nPos ;
}

int
url_isHostnumber (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	i, n, nLength	= 0 ;

	n	= url_isDigits (pString, nString) ;
	if (n <= 0)
		return	0 ;
	nLength	+= n ;
	pString	+= n ;
	nString	-= n ;
	for (i = 0 ; i < 3 ; i ++) {
		if (nString <= 0 || *pString != TEXT ('.')) 
			return	0 ;
		pString	++ ;
		nString	-- ;
		nLength	++ ;
		n	= url_isDigits (pString, nString) ;
		if (n <= 0)
			return	0 ;
		nLength	+= n ;
		pString	+= n ;
		nString	-= n ;
	}
	return	nLength ;
}

int
url_isHpath (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	n, nLength = 0;

	n	= url_isHsegment (pString, nString) ;
	if (n <= 0)
		return	0 ;
	pString	+= n ;
	nString	-= n ;
	nLength	+= n ;

	for ( ; ; ) {
		if (nString < 1 || *pString != TEXT ('/')) 
			break ;
		n	= url_isHsegment (pString + 1, nString - 1) ;
		if (n <= 0)
			break ;
		n	++ ;
		nLength	+= n ;
		pString	+= n ;
		nString	-= n ;
	}
	return	nLength ;
}

int
url_isHsegment (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;
	register int	n, nLength ;

	nLength	= 0 ;
	while (nString > 0) {
		ch	= *pString ;
		if (ch == TEXT (';') || ch == TEXT (':') || ch == TEXT ('@') ||
			ch == TEXT ('&') || ch == TEXT ('=')) {
			n	= 1 ;
		} else {
			n	= url_isUchar (pString, nString) ;
			if (n <= 0)
				break ;
		}
		pString	+= n ;
		nString -= n ;
		nLength	+= n ;
	}
	return	nLength ;
}

/*	hialpha		:= "A" | "B" | "C" | "D" | "E" |
 *				   "F" | "G" | "H" | "I" | "J" |
 *				   "K" | "L" | "M" | "N" | "O" |
 *				   "P" | "Q" | "R" | "S" | "T" |
 *				   "U" | "V" | "W" | "X" | "Y" |
 *				   "Z"
 */
int
url_isHiAlpha (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	ch	= *pString ;
	return	(TEXT ('A') <= ch && ch <= TEXT ('Z'))? 1 : 0 ;
}

/*	lowalpha	:= "a" | "b" | "c" | "d" | "e" |
 *				   "f" | "g" | "h" | "i" | "j" |
 *				   "k" | "l" | "m" | "n" | "o" |
 *				   "p" | "q" | "r" | "s" | "t" |
 *				   "u" | "v" | "w" | "x" | "y" |
 *				   "z"
 */
int
url_isLowAlpha (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	ch	= *pString ;
	return	(TEXT ('a') <= ch && ch <= TEXT ('z'))? 1 : 0 ;
}

/*	alpha		:= lowalpha | hialpha
 */
int
url_isAlpha (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	n ;

	n	= url_isLowAlpha (pString, nString) ;
	if (n > 0)
		return	n ;
	return	url_isHiAlpha  (pString, nString) ;
}

/*	digit		:= "0" | "1" | "2" | "3" | "4" |
 *				   "5" | "6" | "7" | "8" | "9"
 */
int
url_isDigit (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	ch	= *pString ;
	return	(TEXT ('0') <= ch && ch <= TEXT ('9'))? 1 : 0 ;
}

/*	alphadigit	:= alpha | digit
 */
int
url_isAlphaDigit (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	n ;

	n	= url_isAlpha (pString, nString) ;
	if (n > 0)
		return	n ;
	return	url_isDigit (pString, nString) ;
}

/*	safe		:= "$" | "-" | "_" | "." | "+"
 */
int
url_isSafe (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	ch	= *pString ;
	return	(ch == TEXT ('$') || ch == TEXT ('-') || ch == TEXT ('_') ||
			 ch == TEXT ('.') || ch == TEXT ('+')) ? 1 : 0 ;
}

int
url_isExtra (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	ch	= *pString ;
	return	(ch == TEXT ('!') || ch == TEXT ('*') || ch == TEXT ('\'') ||
			 ch == TEXT ('(') || ch == TEXT (')') || ch == TEXT (',')) ? 1 : 0 ;
}

int
url_isReserved (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	ch	= *pString ;
	return	(ch == TEXT (';') || ch == TEXT ('/') || ch == TEXT ('?') ||
			 ch == TEXT (':') || ch == TEXT ('@') || ch == TEXT ('&') ||
			 ch == TEXT ('=')) ? 1 : 0 ;
}	

int
url_isHex (
	register LPCTSTR	pString,
	register int		nString)
{
	register TCHAR	ch ;
	register int	n ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	n	= url_isDigit (pString, nString) ;
	if (n > 0)
		return	n ;

	ch	= *pString ;
	return	((TEXT ('A') <= ch && ch <= TEXT ('F')) ||
			 (TEXT ('a') <= ch && ch <= TEXT ('f')))? 1 : 0 ;
}

/*	escape	:= "%" hex hex
 */
int
url_isEscape (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	n, nRet ;

	if (pString == NULL || nString < 3)
		return	0 ;

	if (*pString != TEXT ('%'))
		return	0 ;

	n		= 1 ;
	nRet	= url_isHex (++ pString, -- nString) ;
	if (nRet <= 0)
		return	0 ;
	n		+= nRet ;
	nRet	= url_isHex (++ pString, -- nString) ;
	if (nRet <= 0)
		return	0 ;
	return	(n + nRet) ;
}

int
url_isUnreserved (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	i, n ;
	static   int	(*rpCheckProc [])(LPCTSTR, int)	= {
		url_isAlpha,	url_isDigit,	url_isSafe,	url_isExtra,
	} ;

	for (i = 0 ; i < ARRAYSIZE (rpCheckProc) ; i ++) {
		n	= (rpCheckProc [i]) (pString, nString) ;
		if (n > 0)
			return	n ;
	}
	return	0 ;
}

int
url_isUchar (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	i, n ;
	static   int	(*rpCheckProc [])(LPCTSTR, int)	= {
		url_isUnreserved,	url_isEscape,
	} ;

	for (i = 0 ; i < ARRAYSIZE (rpCheckProc) ; i ++) {
		n	= (rpCheckProc [i]) (pString, nString) ;
		if (n > 0)
			return	n ;
	}
	return	0 ;
}

int
url_isXchar (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	i, n ;
	static   int	(*rpCheckProc [])(LPCTSTR, int)	= {
		url_isUnreserved,	url_isReserved,	url_isEscape,
	} ;

	for (i = 0 ; i < ARRAYSIZE (rpCheckProc) ; i ++) {
		n	= (rpCheckProc [i]) (pString, nString) ;
		if (n > 0)
			return	n ;
	}
	return	0 ;
}

int
url_isDigits (
	register LPCTSTR	pString,
	register int		nString)
{
	register int	nLength, n ;

	if (pString == NULL || nString <= 0)
		return	0 ;

	nLength	= 0 ;
	while (n = url_isDigit (pString, nString), n > 0) {
		nLength	+= n ;
		pString	+= n ;
		nString	-= n ;
	}
	return	nLength ;
}

