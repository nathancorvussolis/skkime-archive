#include "local.h"
#include "protocol.h"
#include "packet.h"
#include "kanji.h"

BOOL
TPacket_SetHeader (
	register TVarbuffer*	pvbufPacket,
	register int			nMajor,
	register int			nMinor)
{
	BYTE	rbyCH [4] ;

	assert (pvbufPacket != NULL) ;

	rbyCH [0]	= (BYTE) nMajor ;
	rbyCH [1]	= (BYTE) nMinor ;
	return	TVarbuffer_Add (pvbufPacket, &rbyCH, 4) ;
}

BOOL
TPacket_AddPad (
	register TVarbuffer*	pvbufPacket)
{
	register int	nPad ;

	assert (pvbufPacket != NULL) ;

	nPad	= TVarbuffer_GetUsage (pvbufPacket) ;
	nPad	= (4 - (nPad & 3)) & 3 ;
	return	TVarbuffer_Require (pvbufPacket, nPad) ;
}

BOOL
TPacket_AddCard32 (
	register TVarbuffer*	pvbufPacket,
	register DWORD			dwDATA)
{
	BYTE	rbyCH [4] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= (BYTE)(dwDATA >>  0) ;
	rbyCH [1]	= (BYTE)(dwDATA >>  8) ;
	rbyCH [2]	= (BYTE)(dwDATA >> 16) ;
	rbyCH [3]	= (BYTE)(dwDATA >> 24) ;
	return	TVarbuffer_Add (pvbufPacket, rbyCH, 4) ;
}

BOOL
TPacket_AddCard16 (
	register TVarbuffer*	pvbufPacket,
	register WORD			woDATA)
{
	BYTE	rbyCH [2] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= (BYTE)(woDATA >>  0) ;
	rbyCH [1]	= (BYTE)(woDATA >>  8) ;
	return	TVarbuffer_Add (pvbufPacket, rbyCH, 2) ;
}

BOOL
TPacket_AddCard8 (
	register TVarbuffer*	pvbufPacket,
	register BYTE			byDATA)
{
	BYTE	rbyCH [1] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= byDATA ;
	return	TVarbuffer_Add (pvbufPacket, rbyCH, 1) ;
}

BOOL
TPacket_SetLength (
	register TVarbuffer*	pvbufPacket)
{
	register BYTE*	ptr ;
	register int	nPacket ;

	nPacket	= TVarbuffer_GetUsage  (pvbufPacket) ;
	if (nPacket <  SKKISERV_PROTO_HEADER_SIZE ||
		nPacket >= 0x10000)
		return	FALSE ;

	ptr		= (BYTE *)TVarbuffer_GetBuffer (pvbufPacket) + 2 ;
	*ptr ++	= (BYTE)(nPacket >> 0) ;
	*ptr ++	= (BYTE)(nPacket >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_SetCard16 (
	register TVarbuffer*	pvbufPacket,
	register int			nPos,
	register WORD			dwVALUE)
{
	register BYTE*	ptr ;
	register int	nUsage ;

	assert (pvbufPacket != NULL) ;

	nUsage	= TVarbuffer_GetUsage  (pvbufPacket) ;
	if (nPos < 0 || nPos >= nUsage)
		return	FALSE ;

	ptr		= (BYTE *)TVarbuffer_GetBuffer (pvbufPacket) + nPos ;
	*ptr ++	= (BYTE)(dwVALUE >> 0) ;
	*ptr ++	= (BYTE)(dwVALUE >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_AddKanji (
	register TVarbuffer*	pvbufPacket,
	register const Char*	pString,
	register int			nString)
{
	wchar_t					wbuf [128] ;
	unsigned char			rbuf [4] ;
	register wchar_t*		wptr ;
	KANJISTATEMACHINE		ksm ;
	register int			nChar, nPos, nwptr, n ;

	nPos	= TVarbuffer_GetUsage (pvbufPacket) ;
	if (TFAILED (TPacket_AddCard16 (pvbufPacket, 0)))
		return	FALSE ;

	nChar	= 0 ;
	wptr	= wbuf ;
	nwptr	= ARRAYSIZE (wbuf) ;
	InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_UNICODE) ;
	while (nString -- > 0) {
		n	= RtransferKanjiFiniteStateMachine (&ksm, *pString ++, (char*)rbuf) ;
		if (n == 2) {
			*wptr ++	= (((unsigned short)rbuf [1]) << 8) | (unsigned short)rbuf [0] ;
			nwptr -- ;
		} else {
			*wptr ++	= L'��' ;
			nwptr -- ;
		}
		if (nwptr <= 0) {
			/*	server-client �Ƃ��ɓ��� machine �Ȃ̂ŁAendian �̖��͂Ȃ��B*/
			if (TFAILED (TVarbuffer_Add (pvbufPacket, wbuf, sizeof (wbuf))))
				return	FALSE ;
			wptr	= wbuf ;
			nwptr	= ARRAYSIZE (wbuf) ;
		}
		nChar	++ ;
	}
	if (wptr != wbuf)
		if (TFAILED (TVarbuffer_Add (pvbufPacket, wbuf, (wptr - wbuf) * sizeof (wbuf[0]))))
			return	FALSE ;
	if (TFAILED (TPacket_AddPad (pvbufPacket)))
		return	FALSE ;
	if (nChar >= 0x10000 || nChar < 0)
		return	FALSE ;
#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("TPacket_AddKanji (pos:%d, len:%d)\n"), nPos, nChar)) ;
#endif
	return	TPacket_SetCard16 (pvbufPacket, nPos, (WORD)nChar) ;
}

BOOL
TPacket_AddString (
	register TVarbuffer*	pvbufPacket,
	register LPCWSTR		pString,
	register int			nString)
{
	register int			nPos ;

	if (nString < 0 || nString >= 0x10000)
		return	FALSE ;
	if (nString != 0 && pString == NULL)
		return	FALSE ;

	if (TFAILED (TPacket_AddCard16 (pvbufPacket, (WORD)nString)))
		return	FALSE ;

	nPos	= TVarbuffer_GetUsage (pvbufPacket) ;
	if (nString > 0) {
		register LPBYTE			ptr ;

		if (TFAILED (TVarbuffer_Require (pvbufPacket, sizeof (wchar_t) * nString)))
			return	FALSE ;

		ptr		= (LPBYTE)TVarbuffer_GetBuffer (pvbufPacket) + nPos ;
		memcpy (ptr, pString, nString * sizeof (wchar_t)) ;
	}
	if (TFAILED (TPacket_AddPad (pvbufPacket)))
		return	FALSE ;
	return	TRUE ;
}


