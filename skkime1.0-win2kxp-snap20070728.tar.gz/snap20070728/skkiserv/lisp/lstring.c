/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "lispmgrp.h"
#include "cstring.h"

#define	lispEntity_GetStringPtr(ptr)	((TLispString *)((TLispEntity *)(ptr) + 1))

static	BOOL	stringToCharListString	(TLispManager*, TLispEntity*, TLispEntity**) ;
static	BOOL	stringToCharListVector	(TLispManager*, TLispEntity*, TLispEntity**) ;
static	BOOL	stringToCharListList	(TLispManager*, TLispEntity*, TLispEntity**) ;
static	BOOL	concatEntity			(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	concatString			(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	concatVector			(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	concatList				(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	concatInteger			(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	substringString			(TLispManager*, TLispEntity*, long, long, TLispEntity**) ;
static	BOOL	substringVector			(TLispManager*, TLispEntity*, long, long, TLispEntity**) ;


/*	LISP ��������쐬����B������̏ꍇ�A���Ƃ����������񂪓o�^����Ă��Ă�
 *	�ēx���B*/
BOOL
lispMgr_CreateString (
	register TLispManager* 			pLispMgr,
	register const Char*			pString,
	register int					nString,
	register TLispEntity** const	ppEntReturn)
{
	TLispEntity*	pEntity ;
	register TLispString*	pLsString ;
	register size_t			nSize ;

	assert (pLispMgr    != NULL) ;
	assert (pString     != NULL || nString == 0) ;
	assert (ppEntReturn != NULL) ;

#if defined (DEBUG_LV99)
	fprintf (stderr, "Garbage collecting ...") ;
	fflush (stderr) ;
	lispMgr_CollectGarbage (pLispMgr) ;
	fprintf (stderr, "done.\n") ;
#endif	
	nSize	= sizeof (TLispString) + sizeof (Char) * ((nString > 1)? nString - 1 : 0) ;
	if (TFAILED (lispMgr_AllocateEntity (pLispMgr, nSize, &pEntity)))
		return	FALSE ;
		
	pEntity->m_iType		= LISPENTITY_STRING ;
	pEntity->m_lReferCount	= 0 ;	/* �쐬����͎Q�ƃJ�E���^�� 0�B*/
	
	pLsString				= lispEntity_GetStringPtr (pEntity) ;
	if (nString > 0) {
		memcpy (pLsString->m_achString, pString, sizeof (Char) * nString) ;
	}
	pLsString->m_nLength	= nString ;
	lispMgr_RegisterMisc (pLispMgr, pEntity) ;

	*ppEntReturn	= pEntity ;
	return	TRUE ;
}

BOOL
lispMgr_StringToCharList (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pSequence,
	register TLispEntity** const	ppReturn)
{
	int		iType ;

	assert (pLispMgr  != NULL) ;
	assert (pSequence != NULL) ;
	assert (ppReturn  != NULL) ;

	if (TFAILED (lispEntity_GetType (pLispMgr, pSequence, &iType)))
		return	FALSE ;
	switch (iType) {
	case	LISPENTITY_SYMBOL:
		if (TFAILED (lispEntity_Nullp (pLispMgr, pSequence)))
			return	FALSE ;
		lispMgr_CreateNil (pLispMgr, ppReturn) ;
		return	TRUE ;
	case	LISPENTITY_STRING:
		return	stringToCharListString (pLispMgr, pSequence, ppReturn) ;
	case	LISPENTITY_VECTOR:
		return	stringToCharListVector (pLispMgr, pSequence, ppReturn) ;
	case	LISPENTITY_CONSCELL:
		return	stringToCharListList   (pLispMgr, pSequence, ppReturn) ;
	default:
		return	FALSE ;
	}
}

BOOL
lispMgr_Concat (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pArglist,
	register TLispEntity*			pSeparator,
	register TLispEntity** const	ppReturn)
{
	TVarbuffer		vbufStr ;
	TLispEntity*	pArg ;
	TLispEntity*	pNextArglist ;
	const Char*		pString ;
	int				nLen ;
	TLispEntity*	pReturn ;

	assert (pLispMgr != NULL) ;
	assert (pArglist != NULL) ;
	assert (ppReturn != NULL) ;

	if (TFAILED (TVarbuffer_Initialize (&vbufStr, sizeof (Char)))) 
		return	FALSE ;

	if (TFAILED (lispEntity_Nullp (pLispMgr, pArglist))) {
		for ( ; ; ) {
			if (TFAILED (lispEntity_GetCar (pLispMgr, pArglist, &pArg)))
				break ;
			if (TFAILED (concatEntity (pLispMgr, pArg, &vbufStr)))
				break ;
			
			if (TFAILED (lispEntity_GetCdr (pLispMgr, pArglist, &pNextArglist)))
				break ;
			pArglist	= pNextArglist ;
			if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pArglist)))
				break ;
			if (pSeparator != NULL &&
				TFAILED (concatEntity (pLispMgr, pSeparator, &vbufStr)))
				break ;
		}
	}

	if (TFAILED (lispEntity_Nullp (pLispMgr, pArglist))) {
		TVarbuffer_Uninitialize (&vbufStr) ;
		return	FALSE ;
	}
	pString	= TVarbuffer_GetBuffer (&vbufStr) ;
	nLen	= TVarbuffer_GetUsage  (&vbufStr) ;
	if (TFAILED (lispMgr_CreateString (pLispMgr, pString, nLen, &pReturn))) {
		TVarbuffer_Uninitialize (&vbufStr) ;
		return	FALSE ;
	}
	*ppReturn	= pReturn ;
	return	TRUE ;
}

BOOL
lispMgr_Substring (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pArray,
	register long					lFrom,
	register long					lTo,
	register TLispEntity** const	ppReturn)
{
	int		iType ;
	
	assert (pLispMgr != NULL) ;
	assert (pArray   != NULL) ;

	if (TFAILED (lispEntity_GetType (pLispMgr, pArray, &iType)))
		return	FALSE ;
	switch (iType) {
	case	LISPENTITY_STRING:
		return	substringString (pLispMgr, pArray, lFrom, lTo, ppReturn) ;
	case	LISPENTITY_VECTOR:
		return	substringVector (pLispMgr, pArray, lFrom, lTo, ppReturn) ;
	default:
		return	FALSE ;
	}
}

BOOL
lispEntity_Upcase (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pObj,
	register TLispEntity** const	ppReturn)
{
	int			iType ;
	Char		cc ;
	const Char*	pString ;
	int			nLength ;
	BOOL		fResult ;

	assert (pLispMgr  != NULL) ;
	assert (pObj      != NULL) ;
	assert (ppReturn  != NULL) ;

	if (TFAILED (lispEntity_GetType (pLispMgr, pObj, &iType)) ||
		(iType != LISPENTITY_INTEGER && iType != LISPENTITY_STRING))
		return	FALSE ;
	
	if (iType == LISPENTITY_INTEGER) {
		long	lValue ;

		lispEntity_GetIntegerValue (pLispMgr, pObj, &lValue) ;
		cc		= Char_ToUpper ((Char)lValue) ;
		fResult	= lispMgr_CreateInteger (pLispMgr, cc, ppReturn) ;
	} else {
		TVarbuffer	vbufStr ;

		if (TFAILED (TVarbuffer_Initialize (&vbufStr, sizeof (Char))))
			return	FALSE ;

		lispEntity_GetStringValue (pLispMgr, pObj, &pString, &nLength) ;
		if (pString != NULL && nLength > 0) {
			while (nLength > 0) {
				cc	= Char_ToUpper (*pString) ;
				if (TFAILED (TVarbuffer_Add (&vbufStr, &cc, 1))) 
					return	FALSE ;
				pString	++ ;
				nLength	-- ;
			}
		}
		pString	= TVarbuffer_GetBuffer (&vbufStr) ;
		nLength	= TVarbuffer_GetUsage  (&vbufStr) ;
		fResult	= lispMgr_CreateString (pLispMgr, pString, nLength, ppReturn) ;
		TVarbuffer_Uninitialize (&vbufStr) ;
	}
	return	fResult ;
}

BOOL
lispEntity_Downcase (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pObj,
	register TLispEntity** const	ppReturn)
{
	int			iType ;
	Char		cc ;
	BOOL		fResult ;

	assert (pLispMgr  != NULL) ;
	assert (pObj      != NULL) ;
	assert (ppReturn  != NULL) ;

	if (TFAILED (lispEntity_GetType (pLispMgr, pObj, &iType)) ||
		(iType != LISPENTITY_INTEGER && iType != LISPENTITY_STRING))
		return	FALSE ;

	if (iType == LISPENTITY_INTEGER) {
		long	lValue ;

		lispEntity_GetIntegerValue (pLispMgr, pObj, &lValue) ;
		cc		= Char_ToLower ((Char)lValue) ;
		fResult	= lispMgr_CreateInteger (pLispMgr, cc, ppReturn) ;
	} else {
		TVarbuffer	vbufStr ;
		const Char*	pString ;
		int			nLength ;

		if (TFAILED (TVarbuffer_Initialize (&vbufStr, sizeof (Char))))
			return	FALSE ;
		lispEntity_GetStringValue (pLispMgr, pObj, &pString, &nLength) ;
		if (pString != NULL && nLength > 0) {
			while (nLength > 0) {
				cc	= Char_ToLower (*pString) ;
				if (TFAILED (TVarbuffer_Add (&vbufStr, &cc, 1))) 
					return	FALSE ;
				pString	++ ;
				nLength	-- ;
			}
		}
		pString	= TVarbuffer_GetBuffer (&vbufStr) ;
		nLength	= TVarbuffer_GetUsage  (&vbufStr) ;
		fResult	= lispMgr_CreateString (pLispMgr, pString, nLength, ppReturn) ;
		TVarbuffer_Uninitialize (&vbufStr) ;
	}
	return	fResult ;
}

BOOL
lispEntity_GetStringValue (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	const Char** const		ppString,
	register int*			pnLength)
{
	register TLispString*	pLsString ;
	
	assert (pLispMgr  != NULL) ;
	assert (pEntity   != NULL) ;
	assert (ppString  != NULL) ;
	assert (pnLength  != NULL) ;

	if (pEntity->m_iType != LISPENTITY_STRING)
		return	FALSE ;

	pLsString	= lispEntity_GetStringPtr (pEntity) ;
	*ppString	= pLsString->m_achString ;
	*pnLength	= pLsString->m_nLength ;
	return	TRUE ;
}

BOOL
lispEntity_GetStringElement (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register int			nIndex,
	register Char* const	pCh)
{
	register TLispString*	pLsString ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pCh      != NULL) ;

	if (pEntity->m_iType != LISPENTITY_STRING)
		return	FALSE ;

	pLsString	= lispEntity_GetStringPtr (pEntity) ;
	if (nIndex < 0 || nIndex >= pLsString->m_nLength)
		return	FALSE ;
			
	*pCh		= pLsString->m_achString [nIndex] ;
	return	TRUE ;
}

BOOL
lispEntity_SetStringElement (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register int			nIndex,
	register const Char		cc)
{
	register TLispString*	pLsString ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;

	if (pEntity->m_iType != LISPENTITY_STRING)
		return	FALSE ;

	pLsString	= lispEntity_GetStringPtr (pEntity) ;
	if (nIndex < 0 || nIndex >= pLsString->m_nLength)
		return	FALSE ;
			
	pLsString->m_achString [nIndex]	= cc ;
	return	TRUE ;
}

/*========================================================================
 *	private functions
 */
BOOL
stringToCharListString (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pSequence,
	register TLispEntity**	ppRetval)
{
	TLispEntity*	pRetval ;
	TLispEntity*	pNil ;
	const Char*		pString ;
	int				nLength ;

	lispMgr_CreateNil (pLispMgr, &pNil) ;
	lispEntity_GetStringValue (pLispMgr, pSequence, &pString, &nLength) ;

	if (pString != NULL && nLength > 0) {
		TLispEntity*	pTail ;
		TLispEntity*	pNewTail ;
		TLispEntity*	pChar ;

		if (TFAILED (lispMgr_CreateConscell (pLispMgr, pNil, pNil, &pRetval))) 
			return	FALSE ;
		lispEntity_AddRef (pLispMgr, pRetval) ;

		pTail	= pRetval ;
		for ( ; ; ) {
			if (TFAILED (lispMgr_CreateInteger  (pLispMgr, *pString, &pChar))) 
				break ;
			lispEntity_SetCar (pLispMgr, pTail, pChar) ;
			pString	++ ;
			nLength	-- ;
			if (nLength <= 0)
				break ;
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, pNil, pNil, &pNewTail)))
				break ;
			lispEntity_SetCdr (pLispMgr, pTail, pNewTail) ;
			pTail	= pNewTail ;
		}
		/*	�N������Q�Ƃ���Ȃ���ԂɕύX����BGC �̃^�C�~���O�́A�m�ۂ̎��_
		 *	�Ȃ̂ŁB���������A���� lisp engine �� entity �� create �����i�K��
		 *	�͎Q�Ƃ���ĂȂ���ԂɂȂ��Ă邵�B*/
		lispEntity_Release (pLispMgr, pRetval) ;
		if (nLength > 0) 
			return	FALSE ;
	} else {
		pRetval	= pNil ;
	}
	*ppRetval	= pRetval ;
	return	TRUE ;
}

BOOL
stringToCharListVector (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pSequence,
	register TLispEntity**	ppRetval)
{
	TLispEntity*	pRetval ;
	TLispEntity*	pNil ;
	TLispEntity**	ppElement ;
	int				nElement ;

	lispMgr_CreateNil (pLispMgr, &pNil) ;
	lispEntity_GetVectorValue (pLispMgr, pSequence, &ppElement, &nElement) ;

	if (ppElement != NULL && nElement > 0) {
		TLispEntity*	pTail ;
		TLispEntity*	pNewTail ;

		if (TFAILED (lispMgr_CreateConscell (pLispMgr, *ppElement, pNil, &pRetval))) 
			return	FALSE ;

		lispEntity_AddRef (pLispMgr, pRetval) ;
		ppElement	++ ;
		nElement	-- ;
		pTail		= pRetval ;
		while (nElement > 0) {
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, *ppElement, pNil, &pNewTail)))
				break ;
			lispEntity_SetCdr (pLispMgr, pTail, pNewTail) ;
			pTail	= pNewTail ;
			ppElement	++ ;
			nElement	-- ;
		}
		lispEntity_Release (pLispMgr, pRetval) ;
		if (nElement > 0)
			return	FALSE ;
	} else {
		pRetval	= pNil ;
	}
	*ppRetval	= pRetval ;
	return	TRUE ;
}

BOOL
stringToCharListList (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pSequence,
	register TLispEntity**	ppRetval)
{
	TLispEntity*	pHead ;
	TLispEntity*	pTail ;
	TLispEntity*	pNewTail ;
	TLispEntity*	pCar ;
	TLispEntity*	pNil ;
	TLispEntity*	pNextSequence ;

	lispMgr_CreateNil (pLispMgr, &pNil) ;
	if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pSequence))) {
		*ppRetval	= pNil ;
		return	TRUE ;
	}

	if (TFAILED (lispEntity_GetCar (pLispMgr, pSequence, &pCar)) ||
		TFAILED (lispMgr_CreateConscell (pLispMgr, pCar, pNil, &pTail)))
		return	FALSE ;

	pHead	= pTail ;
	lispEntity_AddRef (pLispMgr, pHead) ;
	if (TFAILED (lispEntity_GetCdr (pLispMgr, pSequence, &pNextSequence)))
		return	FALSE ;
	pSequence	= pNextSequence ;
	
	while (TFAILED (lispEntity_Nullp (pLispMgr, pSequence))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pSequence, &pCar)) ||
			TFAILED (lispMgr_CreateConscell (pLispMgr, pCar, pNil, &pNewTail)))
			break ;
		lispEntity_SetCdr (pLispMgr, pTail, pNewTail) ;
		pTail	= pNewTail ;
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pSequence, &pNextSequence)))
			break ;
		pSequence	= pNextSequence ;
	}
	lispEntity_Release (pLispMgr, pHead) ;
	if (TFAILED (lispEntity_Nullp (pLispMgr, pSequence))) {
		*ppRetval	= NULL ;
		return	FALSE ;
	} else {
		*ppRetval	= pHead ;
		return	TRUE ;
	}
}

BOOL
concatEntity (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pArg,
	register TVarbuffer*	pvbufStr)
{
	BOOL	fRetval	= FALSE ;
	int		iType ;
	
	if (TFAILED (lispEntity_GetType (pLispMgr, pArg, &iType)))
		return	FALSE ;
	switch (iType) {
	case	LISPENTITY_STRING:
		fRetval	= concatString (pLispMgr, pArg, pvbufStr) ;
		break ;
	case	LISPENTITY_CONSCELL:
		fRetval	= concatList (pLispMgr, pArg, pvbufStr) ;
		break ;
	case	LISPENTITY_VECTOR:
		fRetval	= concatVector (pLispMgr, pArg, pvbufStr) ;
		break ;
	case	LISPENTITY_INTEGER:
		fRetval	= concatInteger (pLispMgr, pArg, pvbufStr) ;
		break ;
	default:
		break ;
	}
	return	fRetval ;
}

BOOL
concatString (TLispManager* pLispMgr, TLispEntity* pArg, TVarbuffer* pvbufStr)
{
	const Char*	pString ;
	int			nLength ;

	assert (pLispMgr != NULL) ;
	assert (pArg     != NULL) ;
	assert (pvbufStr != NULL) ;

	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pArg, &pString, &nLength)))
		return	FALSE ;
	if (pString != NULL && nLength > 0) 
		return	TVarbuffer_Add (pvbufStr, pString, nLength) ;
	return	TRUE ;
}

BOOL
concatVector (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pArg,
	register TVarbuffer*	pvbufStr)
{
	TLispEntity*	pElement ;
	long			lValue ;
	Char			cc ;
	int				nLength ;
	int				nIndex ;
	
	assert (pLispMgr != NULL) ;
	assert (pArg     != NULL) ;
	assert (pvbufStr != NULL) ;

	if (TFAILED (lispEntity_GetLength (pLispMgr, pArg, &nLength)))
		return	FALSE ;
	
	for (nIndex = 0 ; nIndex < nLength ; nIndex ++) {
		if (TFAILED (lispEntity_GetVectorElement (pLispMgr, pArg, nIndex, &pElement)) ||
			TFAILED (lispEntity_GetIntegerValue  (pLispMgr, pElement, &lValue)))
			return	FALSE ;
		cc	= (Char) lValue ;
		if (TFAILED (TVarbuffer_Add (pvbufStr, &cc, 1)))
			return	FALSE ;
	}
	return	TRUE ;
}

BOOL
concatList (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pArg,
	register TVarbuffer*	pvbufStr)
{
	TLispEntity*	pElement ;
	TLispEntity*	pNextArg ;
	long			lValue ;
	Char			cc ;
	
	assert (pLispMgr != NULL) ;
	assert (pArg     != NULL) ;
	assert (pvbufStr != NULL) ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pArg))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pArg, &pElement)) ||
			TFAILED (lispEntity_GetIntegerValue (pLispMgr, pElement, &lValue)))
			return	FALSE ;
		cc	= (Char) lValue ;
		if (TFAILED (TVarbuffer_Add (pvbufStr, &cc, 1)))
			return	FALSE ;
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pArg, &pNextArg)))
			return	FALSE ;
		pArg	= pNextArg ;
	}
	return	TRUE ;
}

BOOL
concatInteger (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pArg,
	register TVarbuffer*	pvbufStr)
{
	Char	achBuf [128] ;
	Char*	ptr ;
	long	lValue, lRemainder ;
	long	lUse ;
	
	assert (pLispMgr != NULL) ;
	assert (pArg     != NULL) ;
	assert (pvbufStr != NULL) ;

	if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pArg, &lValue)))
		return	FALSE ;

	if (lValue == 0) {
		Char	cc	= Char_MakeAscii ('0') ;
		return	TVarbuffer_Add (pvbufStr, &cc, 1) ;
	}
#if defined (DEBUG)
	fprintf (stderr, "concat-integer %ld, ", lValue) ;
#endif
	ptr		= achBuf + ARRAYSIZE (achBuf) - 1 ;
	lUse	= 0 ;
	if (lValue < 0) {
		while (lUse < ARRAYSIZE(achBuf) && lValue != 0) {
			lRemainder	=  - (lValue % 10) ;
			assert (0 <= lRemainder && lRemainder < 10) ;
			*ptr --		= Char_MakeAscii ('0' + lRemainder) ;
			lValue		=  lValue / 10 ;
			lUse		++ ;
		}
		if (lUse >= ARRAYSIZE(achBuf) || lValue != 0)
			return	FALSE ;
		*ptr	= '-' ;
	} else {
		while (lUse < ARRAYSIZE(achBuf) && lValue != 0) {
			lRemainder	= lValue % 10 ;
			assert (0 <= lRemainder && lRemainder < 10) ;
			*ptr --		= Char_MakeAscii ('0' + lRemainder) ;
			lValue		= lValue / 10 ;
			lUse		++ ;
		}
		if (lValue != 0)
			return	FALSE ;
		ptr	++ ;
	}
#if defined (DEBUG)
	fprintf (stderr, "%ld\n", lUse) ;
#endif
	return	TVarbuffer_Add (pvbufStr, ptr, lUse) ;
}

BOOL
substringString (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register long			lFrom,
	register long			lTo,
	register TLispEntity**	ppReturn)
{
	const Char*		pString ;
	int				nLength ;
	TLispEntity*	pRetval ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	
	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntity, &pString, &nLength)))
		return	FALSE ;
	if (lFrom < 0) 
		lFrom	+= nLength ;
	if (lTo < 0)
		lTo		+= nLength ;
	/* out of range �̃`�F�b�N������B*/
	if (lFrom < 0 || lTo < 0 || lFrom > nLength || lTo > nLength)
		return	FALSE ;

	if (TFAILED (lispMgr_CreateString (pLispMgr, pString + lFrom, lTo - lFrom, &pRetval)))
		return	FALSE ;
	*ppReturn	= pRetval ;
	return	TRUE ;
}

BOOL
substringVector (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register long			lFrom,
	register long			lTo,
	register TLispEntity**	ppReturn)
{
	TLispEntity**	ppElement ;
	int				nElement ;
	TLispEntity*	pRetval ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	
	if (TFAILED (lispEntity_GetVectorValue (pLispMgr, pEntity, &ppElement, &nElement)))
		return	FALSE ;
	if (lFrom < 0) 
		lFrom	+= nElement ;
	if (lTo < 0)
		lTo		+= nElement ;
	/* out of range �̃`�F�b�N������B*/
	if (lFrom < 0 || lTo < 0 || lFrom > nElement || lTo > nElement)
		return	FALSE ;
	if (TFAILED (lispMgr_CreateVector (pLispMgr, ppElement + lFrom, lTo - lFrom, &pRetval)))
		return	FALSE ;
	*ppReturn	= pRetval ;
	return	TRUE ;
}

