#if !defined (vstack_h)
#define	vstack_h

#include "local.h"

enum {
	DEFAULT_VSTACK_SIZE	= 64,
} ;

typedef struct {
	unsigned char	m_achInternal [DEFAULT_VSTACK_SIZE] ;
	void*			m_pBuffer ;
	int				m_nWidth ;
	int				m_nUsage ;
	int				m_nSize ;
}	VStack ;

/*	Prototypes */
BOOL	Vstack_Initialize   (VStack* pStack, int nWidth) ;
BOOL	Vstack_Uninitialize (VStack* pStack) ;
BOOL	Vstack_Push         (VStack* pStack, const void* pData) ;
BOOL	Vstack_Pop          (VStack* pStack, void* pData) ;
BOOL	Vstack_Clear        (VStack* pStack) ;
BOOL	Vstack_Emptyp       (VStack* pStack) ;
BOOL	Vstack_GetHead		(VStack* pStack, void* pData) ;

#endif

