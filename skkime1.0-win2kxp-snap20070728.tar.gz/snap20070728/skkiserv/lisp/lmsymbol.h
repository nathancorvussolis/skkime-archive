/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined (lmsymbol_h)
#define	lmsymbol_h

/*	Prototype */
BOOL	lispMachine_MakeLocalSymbolValue			(TLispMachine* pLM, TLispEntity* pSymbol, TLispBind** ppBindReturn) ;
BOOL	lispMachine_MakeLocalSymbolValueWithName	(TLispMachine* pLM, const Char* pName, const int nName, TLispBind** ppBindReturn) ;

/*	Function Prototype for "Setter" */
#define	SETPROTO(symbol)	BOOL symbol (TLispMachine*, TLispEntity*, TLispEntity*)
#define	SETPROTON(symbol)	BOOL symbol (TLispMachine*, const Char*, int, TLispEntity*)

SETPROTO(lispMachine_SetCurrentSymbolValue) ;
SETPROTO(lispMachine_SetCurrentBufferLocalSymbolValue) ;
SETPROTO(lispMachine_SetGlobalSymbolValue) ;

SETPROTON(lispMachine_SetCurrentSymbolValueWithName) ;
SETPROTON(lispMachine_SetCurrentBufferLocalSymbolValueWithName) ;
SETPROTON(lispMachine_SetGlobalSymbolValueWithName) ;

/*	Function Prototype for "Getter" */
#define	GETPROTO(symbol)	BOOL symbol (TLispMachine*, TLispEntity*, TLispEntity** const )
#define	GETPROTON(symbol)	BOOL symbol (TLispMachine*, const Char*, int, TLispEntity** const)

GETPROTO(lispMachine_GetCurrentSymbolValue) ;
GETPROTO(lispMachine_GetGlobalSymbolValue) ;
GETPROTO(lispMachine_GetCurrentBufferLocalSymbolValue) ;

GETPROTON(lispMachine_GetCurrentSymbolValueWithName) ;
GETPROTON(lispMachine_GetGlobalSymbolValueWithName) ;
GETPROTON(lispMachine_GetCurrentBufferLocalSymbolValueWithName) ;

/*	Function Prototype for Function Value "Setter/Getter" */
SETPROTO(lispMachine_SetSymbolFunctionValue) ;
GETPROTO(lispMachine_GetSymbolFunctionValue) ;

/*	Property "Setter/Getter" */
SETPROTO(lispMachine_SetSymbolProperty) ;
GETPROTO(lispMachine_GetSymbolProperty) ;

#define	GETPROTOE(symbol)	BOOL symbol (TLispMachine*, TLispEntity*, TLispEntity*, TLispEntity** const )
GETPROTOE(lispMachine_GetSymbolValue) ;
GETPROTOE(lispMachine_GetBufferLocalSymbolValue) ;

#undef	SETPROTO
#undef	SETPROTON
#undef	GETPROTO
#undef	GETPROTON

BOOL	lispMachine_GetBufferLocalSymbolValue (TLispMachine*, TLispEntity*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMachine_GetFinalSymbolFunctionValue (TLispMachine*, TLispEntity*, TLispEntity**) ;

BOOL	lispMachine_SetCurrentSymbolValueWithNameA	(TLispMachine*, LPCTSTR, int, TLispEntity*) ;

#endif

