/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include <time.h>
#include "lmachinep.h"
#include "cstring.h"

static	TLMRESULT	lispMachineState_sitForStep		(TLispMachine*) ;
static	TLMRESULT	lispMachineState_sitForFinalize	(TLispMachine*) ;

/*	built-in function:
 *		(ding)
 *
 *	�x����炷�B
 */
TLMRESULT
lispMachineState_Ding (
	register TLispMachine*	pLM)
{
	return	LMR_RETURN ;
	UNREFERENCED_PARAMETER (pLM) ;
}

/*	built-in function:
 *		(make-character charset code1 code2)
 *
 *	��芸�����K���Ɏ�������Bskk8.6 ������� EUC-JP ��
 *	charset �� lc-jp �̂悤�����AEUC-JP ���� charset ��
 *	�̂��낤���H
 */
TLMRESULT
lispMachineState_MakeCharacter (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntCharset ;
	TLispEntity*	pEntCode ;
	long			lCode ;
	long			lCharset ;
	unsigned long	uCode ;
	Char			cc ;
	TLispEntity*	pEntRetval ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntCharset) ;
	if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntCharset, &lCharset)))
		goto	error ;
	if (lCharset < KCHARSET_ASCII || lCharset >= MAX_CHARSET)
		goto	error ;
	lispEntity_GetCdr  (pLispMgr, pEntArglist, &pEntArglist) ;

	uCode	= 0 ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntArglist))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntArglist, &pEntCode)) ||
			TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntCode, &lCode)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntArglist, &pEntArglist)))
			goto	error ;
		uCode	= (uCode << 8) | (unsigned char)lCode ;
	}
	/*	94 �����W���� 96 �����W���̈Ⴂ�ɒ��ӂ��ă}�X�N��������B
	 *	�{���͐������w�肳��Ă�����̂��ƍl���������B
	 */
	if (lCharset == KCHARSET_ASCII) {
		cc	= Char_Make (lCharset, uCode & 0x7F) ;
	} else if (KCHARSET_JISX0208_1978 <= lCharset && lCharset <= KCHARSET_JISX0212_1990) {
		cc	= Char_Make (lCharset, uCode & 0x7F7F) ;
	} else {
		cc	= Char_Make (lCharset, uCode) ;
	}
	if (TFAILED (lispMgr_CreateInteger (pLispMgr, cc, &pEntRetval)))
		return	LMR_ERROR ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;

  error:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

/*	built-in function:
 *		(current-time-string &optional SPECIFIED-TIME)
 *
 *	�l�Ԃ̓ǂ߂镶����̌`�� current time ��Ԃ��B
 *	�t�H�[�}�b�g�� `Sun Sep 16 01:03:52 1973' �ł���B
 *	�����������^����ꂽ��Acurrent time �̑���ɂ��̎���
 *	���t�H�[�}�b�g����B
 */
TLMRESULT
lispMachineState_CurrentTimeString (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntTime ;
	time_t			t ;
	TCHAR			achBuffer [256] ;
	Char			aChBuffer [256] ;
	LPCTSTR			pStrTime ;
	TLispEntity*	pEntRetval ;
	register int	nLength ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntTime) ;
	if (TFAILED (lispEntity_Nullp (pLispMgr, pEntTime))) {
		TLispEntity	*pEntHigh, *pEntLow ;
		long		lHigh, lLow ;

		if (TFAILED (lispEntity_Consp (pLispMgr, pEntTime)))
			goto	error ;
		lispEntity_GetCar (pLispMgr, pEntTime, &pEntHigh) ;
		lispEntity_GetCdr (pLispMgr, pEntTime, &pEntLow) ;
		if (TSUCCEEDED (lispEntity_Consp (pLispMgr, pEntLow)))
			lispEntity_GetCar (pLispMgr, pEntLow, &pEntLow) ;
		if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntHigh, &lHigh)) ||
			TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntLow,  &lLow)))
			goto	error ;
		t	= ((unsigned long)lHigh & 0xFFFF) << 16 | ((unsigned long)lLow & 0xFFFF) ;
	} else {
		t	= time (NULL) ;
	}
	pStrTime	= _tctime (&t) ;
	if (pStrTime == NULL)
		goto	error ;
	lstrcpyn (achBuffer, pStrTime, ARRAYSIZE (achBuffer)) ;
	achBuffer [ARRAYSIZE (achBuffer) - 1]	= TEXT ('\0') ;
	nLength		= lstrlen (achBuffer) ;
	while (nLength > 0 && (achBuffer [nLength - 1] == TEXT ('\n') ||
						   achBuffer [nLength - 1] == TEXT ('\r')))
		nLength	-- ;
	achBuffer [nLength]	= TEXT ('\0') ;
	strtocstr (aChBuffer, pStrTime, nLength) ;
	aChBuffer [nLength]	= TEXT ('\0') ;
	if (TFAILED (lispMgr_CreateString (pLispMgr, aChBuffer, Cstrlen (aChBuffer), &pEntRetval)))
		return	LMR_ERROR ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;

  error:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

