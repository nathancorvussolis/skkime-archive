/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lispmgrp.h"

#define	lispEntity_GetMarkerPtr(ptr)	((TLispMarker *)((TLispEntity *)(ptr) + 1))

BOOL
lispMgr_CreateMarker (
	register TLispManager*			pLispMgr,
	register TLispEntity** const	ppReturn)
{
	TLispEntity*		pEntity ;
	register TLispMarker*		pMarker ;

	assert (pLispMgr    != NULL) ;
	assert (ppReturn != NULL) ;

#if defined (DEBUG_LV99)
	fprintf (stderr, "Garbage collecting ...") ;
	fflush (stderr) ;
	lispMgr_CollectGarbage (pLispMgr) ;
	fprintf (stderr, "done.\n") ;
#endif
	if (TFAILED (lispMgr_AllocateEntity (pLispMgr, sizeof (TLispMarker), &pEntity)))
		return	FALSE ;
	
	pEntity->m_iType			= LISPENTITY_MARKER ;
	pMarker						= lispEntity_GetMarkerPtr (pEntity) ;
	pMarker->m_fInsertionType	= FALSE ;
	pMarker->m_pBuffer			= NULL ;
	pMarker->m_iPosition		= 0 ;
	pMarker->m_pPrevMarker		= NULL ;
	pMarker->m_pNextMarker		= NULL ;
	lispMgr_RegisterMisc (pLispMgr, pEntity) ;

	*ppReturn	= pEntity ;
	return	TRUE ;
}

void
lispMgr_DestroyMarker (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker)
{
	lispBuffer_RemoveMarker (pLispMgr, pEntMarker) ;
	return ;
}

BOOL
lispMarker_SetBufferPosition (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker,
	register TLispEntity*	pEntBuffer,
	register int			iPosition)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker					= lispEntity_GetMarkerPtr (pEntMarker) ;
	pMarker->m_pBuffer		= pEntBuffer ;
	pMarker->m_iPosition	= iPosition ;
	return	TRUE ;
}

BOOL
lispMarker_SetInsertionType (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker,
	register BOOL			fInsertionType)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker						= lispEntity_GetMarkerPtr (pEntMarker) ;
	pMarker->m_fInsertionType	= fInsertionType ;
	return	TRUE ;
}

BOOL
lispMarker_SetNext (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker,
	register TLispEntity*	pEntNextMarker)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker					= lispEntity_GetMarkerPtr (pEntMarker) ;
	pMarker->m_pNextMarker	= pEntNextMarker ;
	return	TRUE ;
}

BOOL
lispMarker_SetPrevious (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker,
	register TLispEntity*	pEntPrevMarker)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker					= lispEntity_GetMarkerPtr (pEntMarker) ;
	pMarker->m_pPrevMarker	= pEntPrevMarker ;
	return	TRUE ;
}

BOOL
lispMarker_GetInsertionType (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker,
	register BOOL*			pfTypeRet)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	assert (pfTypeRet     != NULL) ;
	
	pMarker		= lispEntity_GetMarkerPtr (pEntMarker) ;
	*pfTypeRet	= pMarker->m_fInsertionType ;
	return	TRUE ;
}

BOOL
lispMarker_GetBufferPosition (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntMarker,
	register TLispEntity** const	ppBufferReturn,
	register int* const				piPositionReturn)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker		= lispEntity_GetMarkerPtr (pEntMarker) ;
	if (ppBufferReturn != NULL)
		*ppBufferReturn		= pMarker->m_pBuffer ;
	if (piPositionReturn != NULL)
		*piPositionReturn	= pMarker->m_iPosition ;
	return	TRUE ;
}

BOOL
lispMarker_GetNext (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntMarker,
	register TLispEntity** const	ppReturn)
{
	register TLispMarker*	pMarker ;

	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	assert (ppReturn	  != NULL) ;
	
	pMarker		= lispEntity_GetMarkerPtr (pEntMarker) ;
	*ppReturn	= pMarker->m_pNextMarker ;
	return	TRUE ;
}

BOOL
lispMarker_GetPrevious (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntMarker,
	register TLispEntity** const	ppReturn)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	assert (ppReturn	  != NULL) ;
	
	pMarker		= lispEntity_GetMarkerPtr (pEntMarker) ;
	*ppReturn	= pMarker->m_pPrevMarker ;
	return	TRUE ;
}

/*
 *	�o�b�t�@�̒��� nPosition �̈ʒu�� nCount �����������}�����ꂽ�ꍇ��
 *	�}�[�J�̈ړ�����������B
 */
BOOL
lispMarker_MoveWithInsertion (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker,
	register int			nPosition,
	register int			nCount)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker		= lispEntity_GetMarkerPtr (pEntMarker) ;
	assert (pMarker->m_pBuffer != NULL) ;

#if defined (DEBUG_LV99)
	fprintf (stderr, "Marker (%d, %d), Pos(%d), Count(%d) -->",
			 pMarker->m_iPosition, pMarker->m_fInsertionType,
			 nPosition, nCount) ;
#endif
	if ((nPosition < pMarker->m_iPosition) ||
		(nPosition == pMarker->m_iPosition && pMarker->m_fInsertionType)) {
		pMarker->m_iPosition	+= nCount ;
#if defined (DEBUG_LV99)
		fprintf (stderr, "move (%d)\n", pMarker->m_iPosition) ;
	} else {
		fprintf (stderr, "nomove\n", pMarker->m_iPosition) ;
#endif
	}
	return	TRUE ;
}

BOOL
lispMarker_MoveWithDeletion (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker,
	register int			nPosition,
	register int			nCount)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker		= lispEntity_GetMarkerPtr (pEntMarker) ;
	assert (pMarker->m_pBuffer != NULL) ;

	if (nPosition < pMarker->m_iPosition) {
		pMarker->m_iPosition	-= nCount ;
		if (pMarker->m_iPosition < nPosition)
			pMarker->m_iPosition	= nPosition ;
	}
	return	TRUE ;
}

BOOL
lispMarker_Print (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker)
{
	register TLispMarker*	pMarker ;
	
	assert (pLispMgr      != NULL) ;
	assert (pEntMarker != NULL) ;
	
	pMarker		= lispEntity_GetMarkerPtr (pEntMarker) ;
	DEBUGPRINTF ((TEXT ("(buffer/position/type: %p/%d/%s)"),
				 pMarker->m_pBuffer,
				 pMarker->m_iPosition,
				 (pMarker->m_fInsertionType)? TEXT ("true") : TEXT ("false"))) ;
	return	TRUE ;
}


