/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"
#include "varbuffer.h"
#include "cstring.h"
#include "kanji.h"

static	BOOL	lispMachine_addTail (TLispManager*, TLispEntity*, TLispEntity**, TLispEntity**) ;
/*static	void	cputstr (FILE*, const Char*, int) ;*/

BOOL
lispMachineCode_PushVReg (
	register TLispMachine*	pLM,	
	register int			nReg)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;
	return	Vstack_Push (&pLM->m_vstNonLispObj, &pLM->m_alVREGS [nReg]) ;
}

BOOL
lispMachineCode_PopVReg (
	register TLispMachine*	pLM,
	register int			nReg)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;

	return	Vstack_Pop (&pLM->m_vstNonLispObj, &pLM->m_alVREGS [nReg]) ;
}

BOOL
lispMachineCode_SetVRegI (
	register TLispMachine*	pLM,
	register int			nReg,
	register long			lValue)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;

	pLM->m_alVREGS [nReg].m_lValue	= lValue ;
	return	TRUE ;
}

BOOL
lispMachineCode_SetVRegP (
	register TLispMachine*	pLM,
	register int			nReg,
	register void*			pvValue)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;

	pLM->m_alVREGS [nReg].m_pvValue	= pvValue ;
	return	TRUE ;
}

BOOL
lispMachineCode_SetVRegFP (
	register TLispMachine*	pLM,
	register int			nReg,
	register BOOL			(*pFunc)(TLispMachine*, TLispEntity*, TLispEntity*))
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;

	pLM->m_alVREGS [nReg].m_pfnValue	= pFunc ;
	return	TRUE ;
}

BOOL
lispMachineCode_GetVRegI (
	register TLispMachine*	pLM,
	register int			nReg,
	register long*			plValue)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;
	ASSERT (plValue != NULL) ;

	*plValue	= pLM->m_alVREGS [nReg].m_lValue ;
	return	TRUE ;
}

BOOL
lispMachineCode_GetVRegP (
	register TLispMachine*	pLM,
	register int			nReg,
	register void**			ppvValue)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;
	ASSERT (ppvValue != NULL) ;

	*ppvValue	= pLM->m_alVREGS [nReg].m_pvValue ;
	return	TRUE ;
}

BOOL
lispMachineCode_GetVRegFP (
	register TLispMachine*	pLM,
	register int			nReg,
	register BOOL			(**ppFunc)(TLispMachine*, TLispEntity*, TLispEntity*))
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_NONLISPOBJ_REGS) ;
	ASSERT (ppFunc != NULL) ;

	*ppFunc	= pLM->m_alVREGS [nReg].m_pfnValue ;
	return	TRUE ;
}

BOOL
lispMachineCode_MoveVReg (
	register TLispMachine*	pLM,
	register int			nDestReg,
	register int			nSrcReg)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nDestReg && nDestReg < MAX_NONLISPOBJ_REGS) ;
	ASSERT (0 <= nSrcReg  && nSrcReg  < MAX_NONLISPOBJ_REGS) ;

	memcpy (&pLM->m_alVREGS [nDestReg], &pLM->m_alVREGS [nSrcReg], sizeof (TNotLispValue)) ;
	return	TRUE ;
}

/*
 *	�Ԃ�l�� ACC �ɓ���B
 */
BOOL
lispMachineCode_Evaln (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntTarget,
	register TLMRESULT		(*pNextState)(TLispMachine*))
{
	int			iType ;

	ASSERT (pLM != NULL) ;
	ASSERT (pEntTarget != NULL) ;
	ASSERT (pLM->m_pLispMgr != NULL) ;

	lispMachineCode_SetLReg   (pLM, LM_LREG_ACC, pEntTarget) ;

	(void )lispEntity_GetType (pLM->m_pLispMgr, pEntTarget, &iType) ;
	switch (iType) {
	case	LISPENTITY_SYMBOL:
		lispMachineCode_PushState (pLM, pNextState) ;
		pLM->m_pState	= &lispMachineState_EvalSymbol ;
		break ;

	case	LISPENTITY_CONSCELL:
		lispMachineCode_PushState (pLM, pNextState) ;
		pLM->m_pState	= &lispMachineState_EvalCons ;
		break ;

	case	LISPENTITY_INTEGER:
	case	LISPENTITY_FLOAT:
	case	LISPENTITY_VECTOR:
	case	LISPENTITY_MARKER:
	case	LISPENTITY_BUFFER:
	case	LISPENTITY_STRING:
	default:
		pLM->m_pState	= pNextState ;
		break ;
	}
	return	TRUE ;
}

BOOL
lispMachineCode_Car (
	register TLispMachine*	pLM,
	register int			nDestReg,
	register int			nSrcReg)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pCAR ;

	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nDestReg && nDestReg < MAX_LISPOBJ_REGS) ;
	ASSERT (0 <= nSrcReg  && nSrcReg  < MAX_LISPOBJ_REGS) ;

	pLispMgr	= pLM->m_pLispMgr ;
	if (TFAILED (lispEntity_GetCar (pLispMgr, pLM->m_apLREGS [nSrcReg], &pCAR)) ||
		pCAR == NULL)
		return	FALSE ;
	lispEntity_AddRef (pLispMgr, pCAR) ;
	if (pLM->m_apLREGS [nDestReg] != NULL)
		lispEntity_Release (pLispMgr, pLM->m_apLREGS [nDestReg]) ;
	pLM->m_apLREGS [nDestReg]	= pCAR ;
	return	TRUE ;
}

BOOL
lispMachineCode_SetCurrentBuffer (
	register TLispMachine*	pLM,
	register TLispEntity*	pCurBuffer)
{
	ASSERT (pLM != NULL) ;
	ASSERT (pCurBuffer != NULL) ;
	ASSERT (pCurBuffer->m_iType == LISPENTITY_BUFFER) ;

	pLM->m_pCurBuffer = pCurBuffer ;
	return	TRUE ;
}

BOOL
lispMachineCode_GetCurrentBuffer (
	register TLispMachine*	pLM,
	register TLispEntity**	ppCurBuffer)
{
	ASSERT (pLM != NULL) ;
	ASSERT (ppCurBuffer != NULL) ;
	ASSERT (pLM->m_pCurBuffer != NULL) ;

	*ppCurBuffer	= pLM->m_pCurBuffer ;
	return	TRUE ;
}

BOOL
lispMachineCode_SetException (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntException,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr ;

	ASSERT (pLM           != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr   != NULL) ;

	ASSERT (pEntException != NULL) ;
	ASSERT (pEntValue     != NULL) ;
	lispEntity_AddRef (pLispMgr, pEntException) ;
	lispEntity_AddRef (pLispMgr, pEntValue) ;

	if (pLM->m_pEntException != NULL) 
		lispEntity_Release (pLispMgr, pLM->m_pEntException) ;
	if (pLM->m_pEntExceptionValue != NULL)
		lispEntity_Release (pLispMgr, pLM->m_pEntExceptionValue) ;

	pLM->m_pEntException		=  pEntException ;
	pLM->m_pEntExceptionValue	=  pEntValue ;

	/*	������ exception ���ݒ肳�ꂽ�̂Ȃ�A�t���O�����ĂĂ����B*/
	if (TFAILED (lispEntity_Nullp (pLispMgr, pEntException))) {
		pLM->m_uStatusFlag		|= LMSTATE_EXCEPTION ;
	} else {
		pLM->m_uStatusFlag		&= ~LMSTATE_EXCEPTION ;
	}
	return	TRUE ;
}

BOOL
lispMachineCode_GetException (
	register TLispMachine*	pLM,
	register TLispEntity**	ppEntExceptionRet,
	register TLispEntity**	ppEntExceptionValueRet)
{
	ASSERT (pLM != NULL) ;
	*ppEntExceptionRet		= pLM->m_pEntException ;
	*ppEntExceptionValueRet	= pLM->m_pEntExceptionValue ;
	return	TRUE ;
}

BOOL
lispMachineCode_ResetException (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntNil ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr   != NULL) ;
	pEntNil	= pLispMgr->m_apEntReserved [LISPMGR_INDEX_NIL] ;
	return	lispMachineCode_SetException (pLM, pEntNil, pEntNil) ;
}

BOOL
lispMachineCode_SetSignal (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntSymbol != NULL) ;
	ASSERT (pEntValue  != NULL) ;

	lispEntity_AddRef (pLispMgr, pEntSymbol) ;
	lispEntity_AddRef (pLispMgr, pEntValue) ;

	if (pLM->m_pEntSignal != NULL)
		lispEntity_Release (pLispMgr, pLM->m_pEntSignal) ;
	if (pLM->m_pEntSignalValue != NULL) 
		lispEntity_Release (pLispMgr, pLM->m_pEntSignalValue) ;

	pLM->m_pEntSignal		= pEntSymbol ;
	pLM->m_pEntSignalValue	= pEntValue ;
	/*	������ signal ���ݒ肳�ꂽ�̂Ȃ�A�t���O�����ĂĂ����B*/
	if (TFAILED (lispEntity_Nullp (pLispMgr, pEntSymbol))) {
		pLM->m_uStatusFlag	|= LMSTATE_SIGNAL ;
	} else {
		pLM->m_uStatusFlag	&= ~LMSTATE_SIGNAL ;
	}
	return	TRUE ;
}

BOOL
lispMachineCode_SetError (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntError ;
	TLispEntity*			pEntNil ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr   != NULL) ;
	lispMgr_CreateNil    (pLispMgr, &pEntNil) ;
	pEntError	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_ERROR) ;
	ASSERT (pEntError  != NULL) ;
	return	lispMachineCode_SetSignal (pLM, pEntError, pEntNil) ;
}

BOOL
lispMachineCode_SetErrorEx (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntErrorValue)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntError ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr   != NULL) ;
	pEntError	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_ERROR) ;
	ASSERT (pEntError      != NULL) ;
	ASSERT (pEntErrorValue != NULL) ;
	return	lispMachineCode_SetSignal (pLM, pEntError, pEntErrorValue) ;
}

BOOL
lispMachineCode_ResetSignal (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntNil ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr   != NULL) ;
	pEntNil	= pLispMgr->m_apEntReserved [LISPMGR_INDEX_NIL] ;
	return	lispMachineCode_SetSignal (pLM, pEntNil, pEntNil) ;
}

BOOL
lispMachineCode_GetSignal (
	register TLispMachine*	pLM,
	register TLispEntity**	ppEntSignalRet,
	register TLispEntity**	ppEntSignalValueRet)
{
	ASSERT (pLM != NULL) ;
	*ppEntSignalRet			= pLM->m_pEntSignal ;
	*ppEntSignalValueRet	= pLM->m_pEntSignalValue ;
	return	TRUE ;
}

/*[����]
 *	KEYMAP-ALIST: ((SYMBOL1 KEYMAP1) (SYMBOL2 KEYMAP2) ...)
 *
 *	�̌`������ SYMBOL �� VALUE ������ KEYMAP �𔲂��o���čs���B
 */
BOOL
lispMachineCode_CurrentMinorModeMaps (
	register TLispMachine*	pLM,
	register TLispEntity**	ppEntRetval)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntMinorModeMapAlist ;
	TLispEntity*	pEntNil ;
	TLispEntity*	pEntAlist ;
	TLispEntity*	pEntSymbolKeymap ;
	TLispEntity*	pEntSymbol ;
	TLispEntity*	pEntKeymap ;
	TLispEntity*	pEntSymVal ;
	TLispEntity*	pEntTop ;
	TLispEntity*	pEntTail ;

	ASSERT (pLM != NULL) ;
	ASSERT (ppEntRetval != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;
	lispMgr_CreateNil (pLispMgr, &pEntNil) ;
	pEntTop	= pEntTail = NULL ;

	pEntMinorModeMapAlist	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_MINOR_MODE_MAP_ALIST) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntMinorModeMapAlist, &pEntAlist)) ||
		TSUCCEEDED (lispEntity_Voidp (pLispMgr, pEntAlist))) {
		*ppEntRetval	= pEntNil ;
		return	TRUE ;
	}
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntAlist))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntAlist, &pEntSymbolKeymap)) ||
			TFAILED (lispEntity_GetCar (pLispMgr, pEntSymbolKeymap, &pEntSymbol)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntSymbolKeymap, &pEntKeymap)))
			break ;
		if (TSUCCEEDED (lispMachine_GetCurrentSymbolValue (pLM, pEntSymbol, &pEntSymVal)) &&
			TFAILED (lispEntity_Voidp (pLispMgr, pEntSymVal))) 
			if (TFAILED (lispMachine_addTail (pLispMgr, pEntKeymap, &pEntTop, &pEntTail)))
				break ;
		lispEntity_GetCdr (pLispMgr, pEntAlist, &pEntAlist) ;
	}
	if (pEntTop == NULL) {
		*ppEntRetval	= pEntNil ;
	} else {
		lispEntity_Release (pLispMgr, pEntTop) ;
		*ppEntRetval	= pEntTop ;
	}
	return	TRUE ;
}

BOOL
lispMachineCode_CreateMarker (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntBuffer,
	register int			nPosition,
	register TLispEntity**	ppEntRetval)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntMarker ;

	ASSERT (pLM         != NULL) ;
	ASSERT (pLispMgr    != NULL) ;
	ASSERT (ppEntRetval != NULL) ;

	if (TFAILED (lispMgr_CreateMarker (pLispMgr, &pEntMarker))) 
		return	FALSE ;
	if (pEntBuffer != NULL) {
		lispBuffer_AddMarker (pLispMgr, pEntBuffer, pEntMarker) ;
		lispMarker_SetBufferPosition (pLispMgr, pEntMarker, pEntBuffer, nPosition) ;
	}
	*ppEntRetval	= pEntMarker ;
	return	TRUE ;
}

BOOL
lispMachineCode_Featurep (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntFeature)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntFeatures ;
	TLispEntity*	pEntCar ;
	TLispEntity*	pValFeatures ;

	pEntFeatures	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_FEATURES) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntFeatures, &pValFeatures)) ||
		TSUCCEEDED (lispEntity_Voidp (pLispMgr, pValFeatures))) 
		return	FALSE ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pValFeatures))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pValFeatures, &pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pValFeatures, &pValFeatures)))
			return	FALSE ;
		if (TSUCCEEDED (lispEntity_Eq (pLispMgr, pEntCar, pEntFeature))) {
			return	TRUE ;
		}
	}
	return	FALSE ;
}

BOOL
lispMachineCode_Provide (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntFeature)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntFeatures ;
	TLispEntity*	pValFeatures ;
	TLispEntity*	pEntity ;

	if (TSUCCEEDED (lispMachineCode_Featurep (pLM, pEntFeature)))
		return	TRUE ;

	pEntFeatures	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_FEATURES) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntFeatures, &pValFeatures)) ||
		TSUCCEEDED (lispEntity_Voidp (pLispMgr, pValFeatures))) 
		lispMgr_CreateNil (pLispMgr, &pValFeatures) ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntFeature, pValFeatures, &pEntity)))
		return	FALSE ;
	return	lispMachine_SetCurrentSymbolValue (pLM, pEntFeatures, pEntity) ;
}

BOOL
lispMachineCode_PushState (
	register TLispMachine*	pLM,
	register TLMRESULT		(*pState)(TLispMachine*))
{
	TNotLispValue	val ;

	ASSERT (pLM != NULL) ;

	/*
	 *	NextState �� Interactiveness �� Stack �ɐς�ŕۑ�����B
	 */
	val.m_pState	= pState ;
	if (TFAILED (Vstack_Push (&pLM->m_vstNonLispObj, &val)))
		return	FALSE ;
	val.m_lValue	= (((pLM->m_fInteractive) ? 1 : 0) |
					   ((pLM->m_fCalledInteractively)? 2 : 0)) ;
	if (TFAILED (Vstack_Push (&pLM->m_vstNonLispObj, &val))) {
		/*	��ɐς�ł������̂𖳌�������B*/
		(void) Vstack_Pop (&pLM->m_vstNonLispObj, &val) ;
		return	FALSE ;
	}
	return	TRUE ;
}

BOOL
lispMachineCode_PopState (
	register TLispMachine* pLM)
{
	TNotLispValue	valState ;
	TNotLispValue	valInteractive ;

	ASSERT (pLM != NULL) ;

	if (TFAILED (Vstack_Pop (&pLM->m_vstNonLispObj, &valInteractive)) ||
		TFAILED (Vstack_Pop (&pLM->m_vstNonLispObj, &valState)))
		return	FALSE ;
	
	pLM->m_fInteractive			= (valInteractive.m_lValue & 1)? TRUE : FALSE ;
	pLM->m_fCalledInteractively	= (valInteractive.m_lValue & 2)? TRUE : FALSE ;
	pLM->m_pState				= valState.m_pState ;
	return	TRUE ;
}

BOOL
lispMachineCode_PushLReg (
	register TLispMachine*	pLM,
	register int			nReg)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_LISPOBJ_REGS) ;

	if (pLM->m_apLREGS [nReg] != NULL &&
		TFAILED (lispEntity_AddRef (pLM->m_pLispMgr, pLM->m_apLREGS [nReg])))
		return	FALSE ;
#if defined (DEBUG_LV99)
	fprintf (stderr, "Vstack = u=%d/s=%d\n", pLM->m_vstLispObj.m_nUsage, pLM->m_vstLispObj.m_nSize) ;
#endif
	return	Vstack_Push (&pLM->m_vstLispObj, &pLM->m_apLREGS [nReg]) ;

}

BOOL
lispMachineCode_PopLReg (
	register TLispMachine*	pLM,
	register int			nReg)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_LISPOBJ_REGS) ;

	if (pLM->m_apLREGS [nReg] != NULL)
		lispEntity_Release (pLM->m_pLispMgr, pLM->m_apLREGS [nReg]) ;
#if defined (DEBUG_LV99)
	fprintf (stderr, "Vstack = u=%d/s=%d\n", pLM->m_vstLispObj.m_nUsage, pLM->m_vstLispObj.m_nSize) ;
#endif
	return	Vstack_Pop (&pLM->m_vstLispObj, &pLM->m_apLREGS [nReg]) ;
}

BOOL
lispMachineCode_SetLReg (
	register TLispMachine*	pLM,
	register int			nReg,
	register TLispEntity*	pEntValue)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_LISPOBJ_REGS) ;

	if (pEntValue != NULL)
		lispEntity_AddRef (pLM->m_pLispMgr, pEntValue) ;
	if (pLM->m_apLREGS [nReg] != NULL)
		lispEntity_Release (pLM->m_pLispMgr, pLM->m_apLREGS [nReg]) ;
	pLM->m_apLREGS [nReg]	= pEntValue ;
	return	TRUE ;
}

BOOL
lispMachineCode_GetLReg (
	register TLispMachine*	pLM,
	register int			nReg,
	register TLispEntity**	phValue)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_LISPOBJ_REGS) ;
	ASSERT (phValue != NULL) ;

	*phValue	= pLM->m_apLREGS [nReg] ;
	return	TRUE ;
}

BOOL
lispMachineCode_MoveLReg (
	register TLispMachine*	pLM,
	register int			nDestReg,
	register int			nSrcReg)
{
	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nDestReg && nDestReg < MAX_LISPOBJ_REGS) ;
	ASSERT (0 <= nSrcReg  && nSrcReg  < MAX_LISPOBJ_REGS) ;

	if (pLM->m_apLREGS [nDestReg] != NULL)
		lispEntity_Release (pLM->m_pLispMgr, pLM->m_apLREGS [nDestReg]) ;
	if (pLM->m_apLREGS [nSrcReg] != NULL)
		lispEntity_AddRef (pLM->m_pLispMgr, pLM->m_apLREGS [nSrcReg]) ;
	pLM->m_apLREGS [nDestReg]	= pLM->m_apLREGS [nSrcReg] ;
	return	TRUE ;
}

BOOL
lispMachineCode_Cdr (
	register TLispMachine*	pLM,
	register int			nDestReg,
	register int			nSrcReg)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pCDR ;

	ASSERT (pLM != NULL) ;
	ASSERT (0 <= nDestReg && nDestReg < MAX_LISPOBJ_REGS) ;
	ASSERT (0 <= nSrcReg  && nSrcReg  < MAX_LISPOBJ_REGS) ;

	pLispMgr	= pLM->m_pLispMgr ;
	if (TFAILED (lispEntity_GetCdr (pLispMgr, pLM->m_apLREGS [nSrcReg], &pCDR)) ||
		pCDR == NULL)
		return	FALSE ;
	lispEntity_AddRef (pLispMgr, pCDR) ;
	if (pLM->m_apLREGS [nDestReg] != NULL)
		lispEntity_Release (pLispMgr, pLM->m_apLREGS [nDestReg]) ;
	pLM->m_apLREGS [nDestReg]	= pCDR ;
	return	TRUE ;
}

BOOL
lispMachineCode_SetInteractive (
	register TLispMachine*	pLM,
	register BOOL			fInteractive)
{
	ASSERT (pLM != NULL) ;
	ASSERT (fInteractive == TRUE || fInteractive == FALSE) ;

	pLM->m_fInteractive			= pLM->m_fCalledInteractively ;
	pLM->m_fCalledInteractively	= fInteractive ;
	return	TRUE ;
}

BOOL
lispMachineCode_GetInteractive (
	register TLispMachine*	pLM,
	register BOOL*			pfInteractive)
{
	ASSERT (pLM != NULL) ;
	ASSERT (pfInteractive != NULL) ;

	*pfInteractive	= pLM->m_fInteractive ;
	return	TRUE ;
}

BOOL
lispMachineCode_UnsetInteractive (
	register TLispMachine*	pLM,
	register BOOL			fInteractive)
{
	ASSERT (pLM != NULL) ;
	ASSERT (fInteractive == TRUE || fInteractive == FALSE) ;

	pLM->m_fCalledInteractively	= pLM->m_fInteractive	;
	pLM->m_fInteractive			= fInteractive ;
	return	TRUE ;
}

BOOL
lispMachine_LocalVariablep (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol)
{
	TLispEntity*	pEntValue ;
	ASSERT (pLM != NULL) ;
	ASSERT (pEntSymbol != NULL) ;
	if (TFAILED (lispMachine_GetCurrentBufferLocalSymbolValue (pLM, pEntSymbol, &pEntValue)) ||
		TSUCCEEDED (lispEntity_Voidp (pLM->m_pLispMgr, pEntValue)))
		return	FALSE ;
	return	TRUE ;
}

BOOL
lispMachine_LocalVariableIfSetp (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol)
{
	TLispEntity*	pEntValue	= NULL ;
	ASSERT (pLM != NULL) ;
	ASSERT (pEntSymbol != NULL) ;
	if (TFAILED (lispMachine_GetCurrentBufferLocalSymbolValue (pLM, pEntSymbol, &pEntValue)) ||
		pEntValue == NULL)
		return	FALSE ;
	return	TRUE ;
}

BOOL
lispMachineCode_SetTail (
	register TLispMachine*	pLM, 
	register int			nRegHead,
	register int			nRegTail,
	register TLispEntity*	pEntNewTail)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*			pEntTail ;

	lispMachineCode_GetLReg (pLM, nRegTail, &pEntTail) ;
	if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntTail))) {
		lispMachineCode_SetLReg (pLM, nRegHead, pEntNewTail) ;
	} else {
		if (TFAILED (lispEntity_SetCdr (pLispMgr, pEntTail, pEntNewTail)))
			return	FALSE ;
	}
	lispMachineCode_SetLReg (pLM, nRegTail, pEntNewTail) ;
	return	TRUE ;
}

BOOL
lispMachineCode_SetState (
	register TLispMachine*	pLM,
	register TLMRESULT		(*pState)(TLispMachine*))
{
	ASSERT (pLM    != NULL) ;
	ASSERT (pState != NULL) ;
	pLM->m_pState	= pState ;
	return	TRUE ;
}

void
lispMachineCode_ClearQuitFlag (
	register TLispMachine*		pLM)
{
	register TLispManager*		pLispMgr ;
	register TLispEntity*		pEntQuitFlag ;
	register TLispEntity*		pEntInhibitQuit ;
	register TLispEntity*		pEntNil ;

	ASSERT (pLM != NULL) ;
	pLispMgr		= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;
	pEntQuitFlag	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_QUIT_FLAG) ;
	pEntInhibitQuit	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_INHIBIT_QUIT) ;
	pEntNil			= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_NIL) ;
	ASSERT (pEntQuitFlag != NULL) ;
	ASSERT (pEntInhibitQuit != NULL) ;
	ASSERT (pEntNil != NULL) ;
	lispMachine_SetCurrentSymbolValue (pLM, pEntQuitFlag,    pEntNil) ;
	lispMachine_SetCurrentSymbolValue (pLM, pEntInhibitQuit, pEntNil) ;
	return ;
}

/*	private functions */
BOOL
lispMachine_addTail (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntElement,
	register TLispEntity**	ppEntTop,
	register TLispEntity**	ppEntTail)
{
	register TLispEntity*	pEntTail ;
	TLispEntity*			pEntNil ;
	TLispEntity*			pEntNewTail ;

	ASSERT (pLispMgr    != NULL) ;
	ASSERT (pEntElement != NULL) ;
	ASSERT (ppEntTop    != NULL) ;
	ASSERT (ppEntTail   != NULL) ;

	lispMgr_CreateNil (pLispMgr, &pEntNil) ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntElement, pEntNil, &pEntNewTail)))
		return	FALSE ;
	pEntTail	= *ppEntTail ;
	if (pEntTail == NULL) {
		ASSERT (*ppEntTop == NULL) ;
		*ppEntTop	= pEntNewTail ;
		lispEntity_AddRef (pLispMgr, pEntNewTail) ;
	} else {
		if (TFAILED (lispEntity_SetCdr (pLispMgr, pEntTail, pEntNewTail)))
			return	FALSE ;
	}
	*ppEntTail	= pEntNewTail ;
	return	TRUE ;
}

void
cputstr (
	register FILE*			pFile,
	register const Char*	pString,
	register int			nLength)
{
	KANJISTATEMACHINE	ksm ;
	int					n ;
	char				achBuf [16] ;

	InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_SHIFTJIS) ;
	while (nLength > 0) {
		n	= RtransferKanjiFiniteStateMachine (&ksm, *pString ++, achBuf) ;
		achBuf [n]	= '\0' ;
		fprintf (pFile, "%s", achBuf) ;
		nLength	-- ;
	}
	return ;
}

