#if !defined (genericjisyo_h)
#define	genericjisyo_h

#include "Char.h"
#include "varbuffer.h"

typedef struct tagSkkGenericJisyo {
	TCHAR		m_tszPath [PATH_MAX + 1] ;
	struct tagSkkGenericJisyo*	m_pNext ;
}	SkkGenericJisyo ;

/*	prototypes */
SkkJisyo*	SkkGenericJisyo_Create	(const Char*, int) ;
SkkJisyo*	SkkGenericJisyo_CreateT	(LPCTSTR) ;

#endif

