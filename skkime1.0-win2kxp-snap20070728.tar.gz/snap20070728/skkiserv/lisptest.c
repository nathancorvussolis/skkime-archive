#include "local.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "kstring.h"
#include "lisp\lispmgr.h"
#include "lisp\lmachine.h"
#undef	DEBUGPRINTF
#define	DEBUGPRINTF(x)	_tprintf##x

static	BOOL	lisp_eval	(LPCWSTR) ;

static	TLispManager*		spSkkiservLispMgr		= NULL ;
static	TLispMachine*		spSkkiservLispMachine	= NULL ;

int
_tmain (int nArgc, TCHAR* rpArgv [])
{
	TCHAR				szBuffer [256] ;
	register int		nwKey ;

	if (TFAILED (TLispMgr_Create (&spSkkiservLispMgr)) ||
		TFAILED (TLispMachine_Create (spSkkiservLispMgr, NULL, &spSkkiservLispMachine))) {
		DEBUGPRINTF ((TEXT ("lisp initialize failed\n"))) ;
		return	EXIT_FAILURE ;
	}
	while (! feof (stdin)) {
		_tprintf (TEXT ("> ")) ;
		fflush (stdout) ;
		if (_fgetts (szBuffer, ARRAYSIZE (szBuffer), stdin) == NULL)
			break ;
		nwKey	= lstrlen (szBuffer) ;
		while (nwKey > 0 &&
			   (szBuffer [nwKey - 1] == TEXT ('\n') ||
				szBuffer [nwKey - 1] == TEXT ('\r')))
			nwKey	-- ;
		if (nwKey <= 0)
			continue ;
		lisp_eval (szBuffer) ;
	}
	return	EXIT_SUCCESS ;
}

BOOL
lisp_eval (
	register LPCWSTR		pwWord)
{
	Char					rCWord [512] ;
	TVarbuffer				vbuf ;
	TCHAR					szBuffer [256] ;
	register int			nChar, nwWord, nCWord, n ;
	register const Char*	pChar ;
	register TLispEntity*	pEntTarget ;

	/*	�����̌����B*/
	nwWord	= lstrlen (pwWord) ;
	nCWord	= wstr2internal (rCWord, ARRAYSIZE (rCWord), pwWord, nwWord) ;
	if (nCWord >= ARRAYSIZE (rCWord)) {
		DEBUGPRINTF ((TEXT ("Too long input word: \"%s\"\n"), pwWord)) ;
		return	FALSE ;
	}
	if (nCWord < 0) {
		DEBUGPRINTF ((TEXT ("Convert failed.\n"), pwWord)) ;
		return	FALSE ;
	}

	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (Char)))) 
		return	FALSE ;

	pEntTarget	= lispMgr_ParseString (spSkkiservLispMgr, rCWord, nCWord, NULL) ;
	if (TFAILED (TLispMachine_Test (spSkkiservLispMachine, pEntTarget, &vbuf))) {
		DEBUGPRINTF ((TEXT ("lisp_test failed\n"))) ;
		goto	exit_func ;

	}
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;
	n			= internal2wstr (szBuffer, ARRAYSIZE (szBuffer), pChar, nChar) ;
	if (n >= ARRAYSIZE (szBuffer)) {
		_tprintf (TEXT ("Result is long(%d/%d) ... \n"), n, nChar) ;
		szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
	} else {
		szBuffer [n]	= TEXT ('\0') ;
	}
	_tprintf (TEXT ("200 OK \"%s\"\n"), szBuffer) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbuf) ;
	return	TRUE ;
}

