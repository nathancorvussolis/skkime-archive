#if !defined (user_h)
#define	user_h

#include "jisyo.h"
#include "varbuffer.h"

#define	MAX_USER_JISYOS		(10)

typedef struct tagSkkImeUser {
	TCHAR					m_tszUserName [UNLEN + 1] ;
	SkkJisyo*				m_pLocalJisyo ;
	SkkJisyo*				m_rpJisyo    [MAX_USER_JISYOS] ;
	int						m_rnPriority [MAX_USER_JISYOS] ;
}	SkkImeUser ;

SkkImeUser*	SkkImeUser_Create	(LPCTSTR, int) ;
void		SkkImeUser_Destroy	(SkkImeUser*) ;

BOOL		SkkImeUser_Search	(SkkImeUser*, const Char*, int, BOOL, TVarbuffer*) ;
BOOL		SkkImeUser_SearchEx	(SkkImeUser*, const Char*, int, BOOL, int, TVarbuffer*, int*) ;
BOOL		SkkImeUser_Record	(SkkImeUser*, const Char*, int, BOOL, const Char*, int) ;
BOOL		SkkImeUser_Purge	(SkkImeUser*, const Char*, int, BOOL, const Char*, int) ;
BOOL		SkkImeUser_Save		(SkkImeUser*) ;
BOOL		SkkImeUser_TryCompletion	(SkkImeUser*, const Char*, int, TVarbuffer*) ;
BOOL		SkkImeUser_Update	(SkkImeUser*) ;

#endif

