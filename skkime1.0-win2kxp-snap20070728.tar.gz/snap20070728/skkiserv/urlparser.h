#if !defined (url_h)
#define	url_h

BOOL	URLParser_Process (LPCTSTR, int, LPTSTR, int, LPTSTR, int, LPTSTR, int, LPTSTR, int) ;
BOOL	URLParser_strcpy  (LPTSTR, int, LPCTSTR, int) ;

#endif
