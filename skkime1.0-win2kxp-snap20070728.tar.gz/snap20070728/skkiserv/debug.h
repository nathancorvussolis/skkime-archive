#if !defined (debug_h)
#define debug_h

#include <tchar.h>
#include "Char.h"

#if !defined (DEBUG_LV)
#define	DEBUG_LV	(1)
#endif

void	DebugPrintf			(LPCTSTR, ...) ;
void	DebugPrintfToFile	(LPCTSTR, ...) ;
int		ConvertCStrToTStr	(const Char*, int, LPTSTR, int) ;

#if defined (DEBUG)
#define	ASSERT(expression)			assert(expression)
#define	DEBUGPRINTF(arg)			DebugPrintf##arg
#define	DEBUGPRINTFEX(level,arg)	DebugPrintf##arg
//if((level) >= DEBUG_LV) DebugPrintfToFile##arg
#else
#define	ASSERT(expression)			/* expression */
#define	DEBUGPRINTF(arg)			/* arg */
#define	DEBUGPRINTFEX(level,arg)	/* level arg */
#endif
#endif

