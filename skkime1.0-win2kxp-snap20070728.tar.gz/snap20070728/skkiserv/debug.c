#include "local.h"
#include <shlwapi.h>
#include "debug.h"
#include "kanji.h"
#include <stdio.h>

#define	DEBUGFILENAME	TEXT("skkiserv.log")

void
DebugPrintf (
	LPCTSTR	ptszFormat,
	...)
{
	TCHAR	szBuffer [2048] ;
	va_list	vl ;
	
	va_start (vl, ptszFormat) ;
	_vsntprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, ptszFormat, vl) ;
	va_end (vl) ;
	szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
	OutputDebugString (szBuffer) ;
	return ;
}

void	PASCAL
DebugPrintfToFile (
	LPCTSTR	ptszFormat,
	...)
{
	TCHAR	szBuffer [2048] ;
	va_list	vl ;
	HANDLE	hFile		= INVALID_HANDLE_VALUE ;
	DWORD	dwWritten	= 0, dwFileName = 0 ;
	TCHAR	szPath [MAX_PATH + 1] ;
	int		n ;
	
	/*	�f�o�b�O���O�̏o�̓p�X��ݒ肷��B*/
	dwFileName	= GetTempPath (MAX_PATH, szBuffer) ;
	if (dwFileName <= 0 || dwFileName >= MAX_PATH)
		return ;
	szBuffer [dwFileName]	= TEXT ('\0') ;
	n	= wnsprintf (szPath, MAX_PATH, TEXT ("%s%s"), szBuffer, DEBUGFILENAME) ;
	if (n < 0 || n >= MAX_PATH)
		return ;
	szPath [n]	= TEXT ('\0') ;

	/*	�o�͂��钆�g��ݒ肷��B*/
	va_start (vl, ptszFormat) ;
	n	= wvnsprintf (szBuffer, ARRAYSIZE (szBuffer), ptszFormat, vl) ;
	va_end (vl) ;
	if (n < 0)
		return ;

	/*	�t�@�C�����쐬����B*/
	hFile	= CreateFile (szPath, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE)
		return ;
	/*	�t�@�C���Ƀf�[�^��ǉ�����B*/
	/*	�G���[���������Ă����ɉ����ł��Ȃ��̂ŁA���̂܂ܗ����B*/
	SetFilePointer (hFile, 0, NULL, FILE_END) ;
	WriteFile (hFile, szBuffer, n * sizeof (TCHAR), &dwWritten, NULL) ;
	CloseHandle (hFile) ;
	return ;
}

int
ConvertCStrToTStr (
	register const Char*	pCstr,
	register int			nCstr,
	register LPTSTR			wpDest,
	register int			nwDest)
{
	char				buf [32] ;
	KANJISTATEMACHINE	ksm ;
	register int		nbuf, nconv, nUsage ;

	InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_SHIFTJIS) ;
	nUsage	= 0 ;
	while (nwDest > 0 && nCstr > 0) {
		nbuf	= RtransferKanjiFiniteStateMachine (&ksm, *pCstr, buf) ;
		if (nbuf > 0) {
#if defined (UNICODE) || defined (_UNICODE)
			nconv	= MultiByteToWideChar (CP_OEMCP, MB_ERR_INVALID_CHARS | MB_PRECOMPOSED, buf, nbuf, wpDest, nwDest) ;
			if (nconv <= 0)
				return	-1 ;
#else
			/*	���ꂾ�� ShiftJis �̓r���ŏI���\��������
			 *	�̂����B*/
			nconv	= (nbuf > nwDest)? : nwDest : nbuf ;
			memcpy (wpDest, buf, sizeof (TCHAR) * nconv) ;
#endif
			wpDest	+= nconv ;
			nwDest	-= nconv ;
			nUsage	+= nconv ;
		}
		pCstr	++ ;
		nCstr	-- ;
	}
	return	nUsage ;
}

