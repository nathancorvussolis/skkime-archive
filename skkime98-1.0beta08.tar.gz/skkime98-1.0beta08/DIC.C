/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * DIC.C
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"
#include "skkui.h"
#include "skksubs.h" 
#include "vksub.h"

/*
 *	���ݓ��͂���Ă��� Composition String ���t���b�V������֐��B
 */
void	PASCAL	SKKFlushText (HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	LPCANDIDATEINFO		lpCandInfo ;
	GENEMSG				GnMsg ;

	if (!SKKIsCompStr(hIMC))
		return ;

	lpIMC	= ImmLockIMC(hIMC) ;
	if (!lpIMC)
		return ;

	if (IsCandidate (lpIMC)){
		lpCandInfo		= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
		ClearCandidate (lpCandInfo) ;
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
		GnMsg.msg		= WM_IME_NOTIFY ;
		GnMsg.wParam	= IMN_CLOSECANDIDATE ;
		GnMsg.lParam	= 1 ;
		GenerateMessage (hIMC, lpIMC, lpdwCurTransKey, (LPGENEMSG)&GnMsg) ;
	}
	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC(lpIMC->hCompStr) ;
	if (lpCompStr){
		LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR)lpCompStr ;
		if (lpMyCompStr->dwMinibufStrLen){
			lpMyCompStr->dwMinibufStrLen	= 0 ;
			lpMyCompStr->dwMinibufCurPos	= -1 ;
		}
		lpMyCompStr->dwMinibufRegionStartPos	= -1 ;
		lpMyCompStr->dwMinibufRegionEndPos		= -1 ;

		GnMsg.msg		= WM_IME_NOTIFY ;
		GnMsg.wParam	= IMN_PRIVATE ;
		GnMsg.lParam	= IMN_PRIVATE_CLOSEMINIBUF ;
		GenerateMessage (hIMC, lpIMC, lpdwCurTransKey, (LPGENEMSG)&GnMsg) ;

		ClearCompStr (lpCompStr, CLR_RESULT_AND_UNDET) ;
		SKKClearBuffers ((LPSKKCOMPSTR)lpMyCompStr->skkStr, 8) ;
		lpMyCompStr->iLastBuffer			= 0 ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;

		GnMsg.msg		= WM_IME_COMPOSITION ;
		GnMsg.wParam	= 0 ;
		GnMsg.lParam	= 0 ;
		GenerateMessage (hIMC, lpIMC, lpdwCurTransKey, (LPGENEMSG)&GnMsg) ;

		GnMsg.msg		= WM_IME_ENDCOMPOSITION ;
		GnMsg.wParam	= 0 ;
		GnMsg.lParam	= 0 ;
		GenerateMessage (hIMC, lpIMC, lpdwCurTransKey, (LPGENEMSG)&GnMsg) ;
	}
	ImmUnlockIMC (hIMC) ;
	return ;
}

/*
 *
 *	  MakeGuideLine()
 *
 *	  Update the transrate key buffer.
 *
 */
BOOL PASCAL MakeGuideLine(HIMC hIMC, DWORD dwID)
{
	LPINPUTCONTEXT	lpIMC ;
	LPGUIDELINE		lpGuideLine ;
	GENEMSG			GnMsg ;
	DWORD			dwSize	= sizeof(GUIDELINE) + (MAXGLCHAR + sizeof(MYCHAR)) * 2 * sizeof(MYCHAR);
	LPMYSTR			lpStr ;
#ifdef SKKIME98M
	char			szBuf [MAXGLCHAR + 1] ;
#endif

	lpIMC				= ImmLockIMC (hIMC) ;
	lpIMC->hGuideLine	= ImmReSizeIMCC (lpIMC->hGuideLine,dwSize) ;
	lpGuideLine			= (LPGUIDELINE)ImmLockIMCC (lpIMC->hGuideLine) ;


	lpGuideLine->dwSize		= dwSize;
	lpGuideLine->dwLevel	= glTable[dwID].dwLevel;
	lpGuideLine->dwIndex	= glTable[dwID].dwIndex;
	lpGuideLine->dwStrOffset = sizeof(GUIDELINE);
	lpStr = (LPMYSTR)(((LPSTR)lpGuideLine) + lpGuideLine->dwStrOffset);
#ifdef SKKIME98M
	LoadString(hInst, glTable[dwID].dwStrID, szBuf, MAXGLCHAR);
	MultiByteToWideChar(CP_ACP, 0, szBuf, -1, lpStr, MAXGLCHAR);
#else
	LoadString(hInst,glTable[dwID].dwStrID,lpStr, MAXGLCHAR);
#endif
	lpGuideLine->dwStrLen = Mylstrlen(lpStr);

	if (glTable[dwID].dwPrivateID){
		lpGuideLine->dwPrivateOffset = sizeof(GUIDELINE) + (MAXGLCHAR + 1) * sizeof(MYCHAR);
		lpStr = (LPMYSTR)(((LPSTR)lpGuideLine) + lpGuideLine->dwPrivateOffset);
#ifdef SKKIME98M
		LoadString(hInst, glTable[dwID].dwStrID, szBuf, MAXGLCHAR);
		MultiByteToWideChar(CP_ACP, 0, szBuf, -1, lpStr, MAXGLCHAR);
#else
		LoadString(hInst,glTable[dwID].dwStrID,lpStr, MAXGLCHAR);
#endif
		lpGuideLine->dwPrivateSize = Mylstrlen(lpStr) * sizeof(MYCHAR);
	}
	else
	{
		lpGuideLine->dwPrivateOffset = 0L;
		lpGuideLine->dwPrivateSize = 0L;
	}

	GnMsg.msg = WM_IME_NOTIFY;
	GnMsg.wParam = IMN_GUIDELINE;
	GnMsg.lParam = 0;
	GenerateMessage(hIMC, lpIMC, lpdwCurTransKey,(LPGENEMSG)&GnMsg);

	ImmUnlockIMCC(lpIMC->hGuideLine);
	ImmUnlockIMC(hIMC);

	return TRUE;
}

/*
 *
 *	  GenerateMessage()
 *
 *	  Update the transrate key buffer.
 *
 */
BOOL PASCAL GenerateMessage (HIMC hIMC, LPINPUTCONTEXT lpIMC, LPDWORD lpdwTransKey, LPGENEMSG lpGeneMsg)
{
	if (lpdwTransKey)
		return	GenerateMessageToTransKey (lpdwTransKey, lpGeneMsg) ;

	if (IsWindow(lpIMC->hWnd)){
		LPDWORD	lpdw ;
		if (!(lpIMC->hMsgBuf = ImmReSizeIMCC (lpIMC->hMsgBuf, sizeof(DWORD) * (lpIMC->dwNumMsgBuf +1) * 3)))
			return	FALSE ;

		if (!(lpdw = (LPDWORD)ImmLockIMCC(lpIMC->hMsgBuf)))
			return	FALSE ;

		lpdw				+= (lpIMC->dwNumMsgBuf) * 3 ;
		*((LPGENEMSG)lpdw)	= *lpGeneMsg ;
		ImmUnlockIMCC (lpIMC->hMsgBuf) ;
		lpIMC->dwNumMsgBuf	++ ;

		ImmGenerateMessage (hIMC) ;
	}
	return TRUE;
}

