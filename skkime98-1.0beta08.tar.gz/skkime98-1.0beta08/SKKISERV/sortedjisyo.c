/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * sortedjisyo.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "mylocale.h"
#include "skkiserv.h"
#include "jisyo.h"
#include "mystring.h"
#include "unicode.h"

#define	BUFSIZE				(512)
#define	SJIS_KANA_START		(0x829f)
#define	SJIS_KANA_END		(0x82f1)
#define	UNICODE_KANA_START	(0x3041)
#define	UNICODE_KANA_END	(0x3093)
#define	MYCHAR_KANA_START	SJIS_KANA_START
#define	MYCHAR_KANA_END		SJIS_KANA_END
#define AFTER_KANA			(MYCHAR_KANA_END - MYCHAR_KANA_START + 1)
#define EOL					(0x0a)

#define	STR1				";; okuri-ari entries."
#define	STR2				" okuri-nasi entries."
#define	MYSTR1				MYTEXT(";; okuri-ari entries.")
#define	MYSTR2				MYTEXT(" okuri-nasi entries.")
#define	STRMARK				(';' << 8 | ';')

/*
 *	Prototypes
 */
static	LPSKKSORTEDJISYO	j_find_sorted_jisyo (LPCTSTR lpString) ;
static	BOOL				j_make_jisyo_tab (LPSKKSORTEDJISYO lpjisyo) ;
static	BOOL				j_make_old_jisyo_tab (LPSKKSORTEDJISYO lpjisyo, unsigned char* pString) ;
static	BOOL				j_make_new_jisyo_tab (LPSKKSORTEDJISYO lpjisyo) ;
static	BOOL				j_make_new_euc_jisyo_tab (LPSKKSORTEDJISYO lpjisyo) ;
static	BOOL				j_make_new_jis_jisyo_tab (LPSKKSORTEDJISYO lpjisyo) ;
static	BOOL				j_make_new_sjis_jisyo_tab (LPSKKSORTEDJISYO lpjisyo) ;
static	LPLISTBUFFER		j_search_sorted_jisyo_sub (LPSKKSORTEDJISYO lpjisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, BOOL fOkuri) ;
static	LPLISTBUFFER		j_search_sorted_jis_jisyo_sub (LPSKKSORTEDJISYO lpjisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, int sstyle, long lEndPosition) ;
static	LPLISTBUFFER		j_search_sorted_euc_jisyo_sub (LPSKKSORTEDJISYO lpjisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, int sstyle, long lEndPosition) ;
static	LPLISTBUFFER		j_search_sorted_sjis_jisyo_sub (LPSKKSORTEDJISYO lpjisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, int sstyle, long lEndPosition) ;
static	int					j_cand_compare (int c1, int c2, int f) ;
static	LPLISTBUFFER		j_search_sorted_jisyo_find (LPSKKSORTEDJISYO lpjisyo, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_search_sorted_euc_jisyo_find (LPSKKSORTEDJISYO lpjisyo, LPISO2022STATE lpState, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_search_sorted_jis_jisyo_find (LPSKKSORTEDJISYO lpjisyo, LPISO2022STATE lpState, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_search_sorted_sjis_jisyo_find (LPSKKSORTEDJISYO lpjisyo, LPLISTBUFFER lpListBuffer) ;

/*
 *	Global Variables
 */
static	LPSKKSORTEDJISYO	lpSortedjisyosTop ;

/*
 *	Global Functions
 */
BOOL	j_init_sorted_jisyos (void)
{
	lpSortedjisyosTop	= NULL ;
	return	TRUE ;
}

BOOL	j_close_sorted_jisyos (void)
{
	LPSKKSORTEDJISYO	lpjisyo ;
	LPSKKSORTEDJISYO	lpNextjisyo ;
	lpjisyo	= lpSortedjisyosTop ;
	while (lpjisyo){
		lpNextjisyo	= lpjisyo->m_lpNext ;
		winfclose ((LPWINFILE)&(lpjisyo->m_JisyoFile)) ;
		HeapFree (GetProcessHeap (), 0, lpjisyo) ;
		lpjisyo		= lpNextjisyo ;
	}
	lpSortedjisyosTop	= NULL ;
	return	TRUE ;
}

/*
 *	�\�[�g�ςݎ�����o�^����֐��B
 */
LPSKKSORTEDJISYO	j_register_sorted_jisyo (LPCTSTR lpString, int iCodingSystem)
{
	LPSKKSORTEDJISYO	lpJisyo ;
	LPSKKSORTEDJISYO	lpPrevJisyo ;
	LPSKKSORTEDJISYO	lpNewJisyo ;
	long		lResult ;
	/* ���ɓo�^����Ă��鎫���ł��邩���ׂ�B*/
	lpJisyo		= lpSortedjisyosTop ;
	lpPrevJisyo	= NULL ;
	while (lpJisyo){
		lResult	= lstrcmp (lpJisyo->m_Path, lpString) ;
		if (!lResult)
			return	lpJisyo ;
		if (lResult > 0)
			break ;
		lpPrevJisyo	= lpJisyo ;
		lpJisyo		= lpJisyo->m_lpNext ;
	}
	/* �����t�@�C�����Ǘ����邽�߂̃f�[�^�̈���m�ۂ���B*/
	lpNewJisyo	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (SKKSORTEDJISYO)) ;
	if (!lpNewJisyo)
		return	NULL ;
	lstrcpy (lpNewJisyo->m_Path, lpString) ;
	winfileinit ((LPWINFILE)&(lpNewJisyo->m_JisyoFile)) ;
	/* �����t�@�C�������݂��Ȃ���΁A�o�^���邱�Ƃ͏o���Ȃ��B*/
	if (!winfopen ((LPWINFILE)&(lpNewJisyo->m_JisyoFile), lpNewJisyo->m_Path, GENERIC_READ, OPEN_EXISTING)){
		HeapFree (GetProcessHeap (), 0, lpJisyo) ;
		return	NULL ;
	}
	/* �����̕�����������@�����o����B*/
	if (iCodingSystem < 0){
		lpNewJisyo->m_iCodingSystem	= j_detect_coding_system ((LPWINFILE)&(lpNewJisyo->m_JisyoFile), 1024) ;
	} else {
		lpNewJisyo->m_iCodingSystem	= iCodingSystem ;
	}
	lpNewJisyo->m_lFormat		= 0 ;
	/* �������Ǘ����X�g�ɉ�����B*/
	lpNewJisyo->m_lpNext		= lpJisyo ;
	if (!lpPrevJisyo){
		lpSortedjisyosTop		= lpNewJisyo ;
	} else {
		lpPrevJisyo->m_lpNext	= lpNewJisyo ;
	}
	/* �����^�O���쐬����B*/
	j_make_jisyo_tab (lpNewJisyo) ;
	return	lpNewJisyo ;
}

/*
 *	�\�[�g�ςݎ������Ǘ�������O���֐��B
 */
BOOL	j_unregister_sorted_jisyo (LPCTSTR lpString)
{
	LPSKKSORTEDJISYO	lpJisyo ;
	LPSKKSORTEDJISYO	lpPrevJisyo ;
	long		lResult ;
	lpJisyo		= lpSortedjisyosTop ;
	lpPrevJisyo	= NULL ;
	while (lpJisyo){
		lResult	= lstrcmp (lpJisyo->m_Path, lpString) ;
		if (!lResult){
			if (!lpPrevJisyo){
				lpSortedjisyosTop		= lpJisyo->m_lpNext ;
			} else {
				lpPrevJisyo->m_lpNext	= lpJisyo->m_lpNext ;
			}
			winfclose ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			HeapFree (GetProcessHeap (), 0, lpJisyo) ;
			return	TRUE ;
		}
		if (lResult > 0)
			return	FALSE ;
		lpPrevJisyo	= lpJisyo ;
		lpJisyo		= lpJisyo->m_lpNext ;
	}
	return	FALSE ;
}

LPLISTBUFFER	j_search_sorted_jisyo (LPCTSTR lpJisyoName, int iCodingSystem, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer, BOOL fOkuri)
{
	LPSKKSORTEDJISYO	lpJisyo ;
	/* ���̎������o�^����Ă��Ȃ����������Ă݂�B*/
	lpJisyo	= j_find_sorted_jisyo (lpJisyoName) ;
	if (!lpJisyo){
		/* �o�^����Ă��Ȃ��̂ŁA�V�K�o�^����B*/
		lpJisyo	= j_register_sorted_jisyo (lpJisyoName, iCodingSystem) ;
		if (!lpJisyo)
			return	lpListBuffer ;
	}
	/* ��������������B*/
	return	j_search_sorted_jisyo_sub (lpJisyo, lpListBuffer, lpKey, fOkuri) ;
 	UNREFERENCED_PARAMETER (iCodingSystem) ;
 	UNREFERENCED_PARAMETER (fOkuri) ;
}

/*
 *	Private Functions
 */
LPSKKSORTEDJISYO	j_find_sorted_jisyo (LPCTSTR lpString)
{
	LPSKKSORTEDJISYO	lpJisyo ;
	long		lResult ;
	lpJisyo		= lpSortedjisyosTop ;
	while (lpJisyo){
		lResult	= lstrcmp (lpJisyo->m_Path, lpString) ;
		if (!lResult)
			return	lpJisyo ;
		if (lResult > 0)
			return	NULL ;
		lpJisyo		= lpJisyo->m_lpNext ;
	}
	return	NULL ;
}

BOOL	j_make_jisyo_tab (LPSKKSORTEDJISYO lpJisyo)
{
	MYCHAR	buf [BUFSIZE] ;
again:
	if (!j_read_one_line (buf, BUFSIZE, (LPWINFILE)&(lpJisyo->m_JisyoFile), lpJisyo->m_iCodingSystem))
		return	FALSE ;
	lpJisyo->m_lFormat	= Mylstrncmp (buf, MYSTR1, Mylstrlen (MYSTR1)) ;
	if (!lpJisyo->m_lFormat){
		j_make_new_jisyo_tab (lpJisyo) ;
	} else if (buf [0] == MYTEXT (';') && buf [1] == MYTEXT (';')){
		goto	again ;
	} else {
#if 0
		j_make_old_jisyo_tab (lpJisyo, buf) ;
#endif
	}
	return	TRUE ;
}

#if 0
BOOL	j_make_old_jisyo_tab (LPSKKSORTEDJISYO lpJisyo, unsigned char* pString)
{
	long*	pjtab ;
	int		c ;					/* one character */
	int		code ;				/* compared code */
	int		target ;			/* target code (2 bytes) */
	long	lFilePos ;

	pjtab		= lpJisyo->m_jtab2 ;
	code		= KANA_START ;
	target		= (*pString & 0xff) << 8 ;
	target		|= *++pString & 0xff ;

	while (target >= code && code <= KANA_END){
		*pjtab	++	= 0 ;
		code	++ ;
	}
    
	while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
		target		= ((c & 0xff) << 8) | (winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) & 0xff) ;
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		while (target >= code && code <= KANA_END) {
			*pjtab	++	= lFilePos - 2 ;
			code	++ ;
		}
		while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
			if (c == EOL)
				break ;
			if (code > KANA_END) {
				lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				*pjtab	++	= lFilePos ;
				code	++ ;
				break;
			}
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code <= KANA_END + 1) {
		*pjtab	++ = lFilePos ;
		code	++ ;
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	*pjtab		= lFilePos ;		/* size of jisyo */
	winrewind ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	return	TRUE ;
}
#endif

BOOL	j_make_new_jisyo_tab (LPSKKSORTEDJISYO lpJisyo)
{
	switch (lpJisyo->m_iCodingSystem){
	case	KANJI_CODE_EUC:
		return	j_make_new_euc_jisyo_tab (lpJisyo) ;
	case	KANJI_CODE_JIS:
		return	j_make_new_jis_jisyo_tab (lpJisyo) ;
	case	KANJI_CODE_SJIS:
		return	j_make_new_sjis_jisyo_tab (lpJisyo) ;
	default:
		return	FALSE ;
	}
}

BOOL	j_make_new_euc_jisyo_tab (LPSKKSORTEDJISYO lpJisyo)
{
	LPCSTR			lpptr ;
	int				iChara ;
	int				code ;			/* compared code */
	int				target ;		/* target code (2 bytes) */
	long*			pjtab ;
	long			lFilePos ;
	ISO2022STATE	eucjpState ;
	int				iRet ;
	WORD			woChara ;

	pjtab	= lpJisyo->m_jtab1 ;
	code	= MYCHAR_KANA_END ;
	eucjp_init (&eucjpState) ;
	while (1){
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		/*
		 *	�s���̂P�����𔲂��o���B
		 */
		do {
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			iRet	= eucjp_charA (&eucjpState, iChara, &woChara) ;
		} while (iRet <= 0 && iChara != EOF) ;

		if (iChara == EOF)
			break ;

		/*
		 *	�s�����R�����g�̊J�n���Ӗ�����Z�~�R�������H
		 */
		if (woChara == ';'){
			/*
			 *	�����P�������X�ɃZ�~�R�������ǂ����`�F�b�N����B
			 */
			do {
				iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				iRet	= eucjp_charA (&eucjpState, iChara, &woChara) ;
			} while (iRet <= 0 && iChara != EOF) ;

			if (woChara == ';'){
				/*
				 *	���̏ꍇ�ɂ͑��艼���������̊J�n�ʒu���ǂ������`�F�b�N����B
				 */
				lpptr	= STR2 ;
				while (1){
					iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
					iRet	= eucjp_charA (&eucjpState, iChara, &woChara) ;
					if (iChara == EOF || iChara == EOL || iRet < 0)
						break ;
					if (iRet > 0){
						if (woChara > 0x0100 || (unsigned char)*lpptr != woChara)
							break ;
						lpptr	++ ;
					}
				}
				if (!*lpptr)
					break ;
				/*
				 *	���艼���������̊J�n�ʒu�ł͖��������̂ŁA���̍s�͖�������B
				 */
				while (iChara != EOF && iChara != EOL)
					iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				eucjp_init (&eucjpState) ;
				continue ;
			}			
		}
		/*
		 *	���̉������� �` code �܂ł̃^�O�����݂̍s���ɐݒ肷��B
		 */
		target	= woChara ;
		while (target <= code && MYCHAR_KANA_START <= code){ 
			*pjtab	++	= lFilePos ;
			code	-- ;
		}
		/*
		 *	�s���܂ŃX�L�b�v����B
		 */
		while ((iChara = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF)
			if (iChara == EOL)
				break ;
		eucjp_init (&eucjpState) ;
		/*
		 *	�����̊J�n�R�[�h�܂ŗ����ꍇ�ɂ͔�����B
		 */
		if (code < MYCHAR_KANA_START){
			lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			*pjtab	++	= lFilePos ;
			code	++ ;
			break ;
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code >= MYCHAR_KANA_START - 1) {
		*pjtab	++	= lFilePos ;
		code	-- ;
	}
	*pjtab				= lFilePos ;
	lpJisyo->m_lFormat	= lFilePos ;

	pjtab	= lpJisyo->m_jtab2 ;
	code	= MYCHAR_KANA_START ;
	for (; ;){
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		/*
		 *	�s���̂P�����𔲂��o���B
		 */
		do {
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			iRet	= eucjp_charA (&eucjpState, iChara, &woChara) ;
		} while (iRet <= 0 && iChara != EOF) ;

		if (iChara == EOF)
			break ;

		target	= woChara ;
		while (code <= target && code <= MYCHAR_KANA_END) { 
			*pjtab	++	= lFilePos ;
			code	++ ;
		}
		while ((iChara = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF)
			if (iChara == EOL)
				break ;
		eucjp_init (&eucjpState) ;
		if (code > MYCHAR_KANA_END){
			lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			*pjtab	++	= lFilePos ;
			code	++ ;
			break;
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code <= MYCHAR_KANA_END + 1) {
		*pjtab	++	= lFilePos ;
		code	++ ;
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	*pjtab		= lFilePos ;
	winrewind ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	return	TRUE ;
}

/*
 *	JUNET Encoding ���ꂽ�\�[�g���ꂽ�����̃^�O���쐬����֐��B
 */
BOOL	j_make_new_jis_jisyo_tab (LPSKKSORTEDJISYO lpJisyo)
{
	LPCSTR			lpptr ;
	int				iChara ;
	int				code ;			/* compared code */
	int				target ;		/* target code (2 bytes) */
	long*			pjtab ;
	long			lFilePos ;
	ISO2022STATE	iso2022jpState ;
	int				iRet ;
	WORD			woChara ;

	pjtab	= lpJisyo->m_jtab1 ;
	code	= MYCHAR_KANA_END ;
	iso2022jp_init (&iso2022jpState) ;
	for (; ;){
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		/*
		 *	�s���̂P�����𔲂��o���B
		 */
		do {
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			iRet	= iso2022jp_charA (&iso2022jpState, iChara, &woChara) ;
		} while (iRet <= 0 && iChara != EOF) ;

		if (iChara == EOF)
			break ;

		/*
		 *	�s�����R�����g�̊J�n���Ӗ�����Z�~�R�������H
		 */
		if (woChara == ';'){
			/*
			 *	�����P�������X�ɃZ�~�R�������ǂ����`�F�b�N����B
			 */
			do {
				iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				iRet	= iso2022jp_charA (&iso2022jpState, iChara, &woChara) ;
			} while (iRet <= 0 && iChara != EOF) ;

			if (woChara == ';'){
				/*
				 *	���̏ꍇ�ɂ͑��艼���������̊J�n�ʒu���ǂ������`�F�b�N����B
				 */
				lpptr	= STR2 ;
				while (1){
					iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
					iRet	= iso2022jp_charA (&iso2022jpState, iChara, &woChara) ;
					if (iChara == EOF || iChara == EOL || iRet < 0)
						break ;
					if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						if (*lpptr != woChara)
							break ;
#else
						if (woChara > 0x0100 || (unsigned char)*lpptr != woChara)
							break ;
#endif
						lpptr	++ ;
					}
				}
				if (!*lpptr)
					break ;
				/*
				 *	���艼���������̊J�n�ʒu�ł͖��������̂ŁA���̍s�͖�������B
				 */
				while (iChara != EOF && iChara != EOL)
					iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				iso2022jp_init (&iso2022jpState) ;
				continue ;
			}			
		}
		/*
		 *	���̉������� �` code �܂ł̃^�O�����݂̍s���ɐݒ肷��B
		 */
		target	= woChara ;
		while (target <= code && MYCHAR_KANA_START <= code){ 
			*pjtab	++	= lFilePos ;
			code	-- ;
		}
		/*
		 *	�s���܂ŃX�L�b�v����B
		 */
		while ((iChara = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF)
			if (iChara == EOL)
				break ;
		iso2022jp_init (&iso2022jpState) ;
		/*
		 *	�����̊J�n�R�[�h�܂ŗ����ꍇ�ɂ͔�����B
		 */
		if (code < MYCHAR_KANA_START){
			lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			*pjtab	++	= lFilePos ;
			code	++ ;
			break ;
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code >= MYCHAR_KANA_START - 1) {
		*pjtab	++	= lFilePos ;
		code	-- ;
	}
	*pjtab				= lFilePos ;
	lpJisyo->m_lFormat	= lFilePos ;

	pjtab	= lpJisyo->m_jtab2 ;
	code	= MYCHAR_KANA_START ;
	for (; ;){
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		/*
		 *	�s���̂P�����𔲂��o���B
		 */
		do {
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			iRet	= iso2022jp_charA (&iso2022jpState, iChara, &woChara) ;
		} while (iRet <= 0 && iChara != EOF) ;

		if (iChara == EOF)
			break ;

		target	= woChara ;
		while (code <= target && code <= MYCHAR_KANA_END) { 
			*pjtab	++	= lFilePos ;
			code	++ ;
		}
		while ((iChara = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF)
			if (iChara == EOL)
				break ;
		iso2022jp_init (&iso2022jpState) ;
		if (code > MYCHAR_KANA_END){
			lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			*pjtab	++	= lFilePos ;
			code	++ ;
			break;
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code <= MYCHAR_KANA_END + 1) {
		*pjtab	++	= lFilePos ;
		code	++ ;
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	*pjtab		= lFilePos ;
	winrewind ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	return	TRUE ;
}

BOOL	j_make_new_sjis_jisyo_tab (LPSKKSORTEDJISYO lpJisyo)
{
	int				c ;				/* one character */
	int				code ;			/* compared code */
	int				target ;		/* target code (2 bytes) */
	long*			pjtab ;
	unsigned char	buf [BUFSIZE] ;
	long			lFilePos ;

	pjtab	= lpJisyo->m_jtab1 ;
	code	= SJIS_KANA_END ;
	while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
		target = ((c & 0xff) << 8) | (winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) & 0xff) ;
		if (target == STRMARK){
			winfgets ((char*)buf, BUFSIZE, (LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			if (!strncmp ((char*)buf, STR2, strlen(STR2)) == 0){
				break ;
			} else {
				continue ;
			}
		}
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		while (target <= code && SJIS_KANA_START <= code){ 
			*pjtab	++	= lFilePos - 2 ;
			code	-- ;
		}
		while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF)
			if (c == EOL)
				break ;
		if (code < SJIS_KANA_START){
			lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			*pjtab	++	= lFilePos ;
			code	++ ;
			break ;
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code >= SJIS_KANA_START - 1) {
		*pjtab	++	= lFilePos - 2 ;
		code	-- ;
	}
	lFilePos			= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	*pjtab				= lFilePos - 2 ;
	lpJisyo->m_lFormat	= lFilePos ;

	pjtab	= lpJisyo->m_jtab2 ;
	code	= SJIS_KANA_START ;
	while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
		target		= ((c & 0xff) << 8) | (winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) & 0xff) ;
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		while (code <= target && code <= SJIS_KANA_END) { 
			*pjtab	++	= lFilePos - 2 ;
			code	++ ;
		}
		while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF)
			if (c == EOL)
				break ;
		if (code > SJIS_KANA_END){
			lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			*pjtab	++	= lFilePos ;
			code	++ ;
			break;
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code <= SJIS_KANA_END + 1) {
		*pjtab	++	= lFilePos ;
		code	++ ;
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	*pjtab		= lFilePos ;
	winrewind ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	return	TRUE ;
}

LPLISTBUFFER	j_search_sorted_jisyo_sub (LPSKKSORTEDJISYO lpJisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, BOOL fOkuri)
{
	long		lStartPosition ;
	long		lEndPosition ;
	int			iCode ;
	int			iSearchStyle ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	char		buf [2] ;
#endif

	if (!lpKey || !*lpKey)
		return	lpListBuffer ;

	if (lpJisyo->m_lFormat == 0){
		iSearchStyle	= 0 ;
	} else {
		iSearchStyle		= (fOkuri)? 1 : 2 ;
	}
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	MystrToShiftJis (buf, 2, lpKey, 1) ;
	if (IsDBCSLeadByte (buf [0])){
		iCode	= ((buf [0] & 0x00FF) << 8) | (buf [1] & 0x00FF) ;
	} else {
		iCode	= buf [0] & 0x00FF ;
	}
#else
	if (IsDBCSLeadByte (lpKey [0])){
		iCode	= ((lpKey [0] & 0x00FF) << 8) | (lpKey [1] & 0x00FF) ;
	} else {
		iCode	= lpKey [0] & 0x00FF ;
	}
#endif
	if ((iSearchStyle == 0) || (iSearchStyle == 2)) {
		if (iCode < MYCHAR_KANA_START){
			if (iSearchStyle == 0){
				lStartPosition	= 0 ;
			} else { 
				lStartPosition	= lpJisyo->m_lFormat ;
			}
			lEndPosition	= lpJisyo->m_jtab2 [0] ;
		} else if (iCode > MYCHAR_KANA_END){
			lStartPosition	= lpJisyo->m_jtab2 [AFTER_KANA] ;
			lEndPosition	= lpJisyo->m_jtab2 [AFTER_KANA + 1] ;
		} else {
			lStartPosition	= lpJisyo->m_jtab2 [iCode - MYCHAR_KANA_START] ;
			lEndPosition	= lpJisyo->m_jtab2 [iCode - MYCHAR_KANA_START + 1] ;
		} 
	} else {
		if (iCode < MYCHAR_KANA_START) {
			lStartPosition	= lpJisyo->m_jtab1 [AFTER_KANA] ;
			lEndPosition	= lpJisyo->m_jtab1 [AFTER_KANA + 1] ;
		} else if (iCode > MYCHAR_KANA_END){
			lStartPosition	= 0 ;
			lEndPosition	= lpJisyo->m_jtab1 [0] ;
		} else {
			lStartPosition	= lpJisyo->m_jtab1[MYCHAR_KANA_END - iCode] ;
			lEndPosition	= lpJisyo->m_jtab1[MYCHAR_KANA_END - iCode + 1] ;
		}
	}
	winfseek ((LPWINFILE)&(lpJisyo->m_JisyoFile), lStartPosition, FILE_BEGIN) ;
	switch (lpJisyo->m_iCodingSystem){
	case	KANJI_CODE_EUC:
		return	j_search_sorted_euc_jisyo_sub (lpJisyo, lpListBuffer, lpKey, iSearchStyle, lEndPosition) ;
	case	KANJI_CODE_JIS:
		return	j_search_sorted_jis_jisyo_sub (lpJisyo, lpListBuffer, lpKey, iSearchStyle, lEndPosition) ;
	case	KANJI_CODE_SJIS:
		return	j_search_sorted_sjis_jisyo_sub (lpJisyo, lpListBuffer, lpKey, iSearchStyle, lEndPosition) ;
	default:
		break ;
	}
	return	lpListBuffer ;
}
  
LPLISTBUFFER	j_search_sorted_euc_jisyo_sub (LPSKKSORTEDJISYO lpJisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, int sstyle, long lEndPosition)
{
	LPCMYSTR				lpMyptr ;
	long					lFilePos ;
	int						iChara ;
	ISO2022STATE			eucjpState ;
	int						iRet ;
	WORD					woChara ;

	iChara	= '\0' ;
	while (iChara != EOF){
		eucjp_init (&eucjpState) ;
		lpMyptr	= lpKey ;
		while (*lpMyptr){
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			if (iChara == EOF)
				break ;
			iRet	= MyEucJpChar (&eucjpState, iChara, &woChara) ;
			if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (*lpMyptr != woChara || woChara == MYTEXT (' ') || woChara == EOL)
					break ;
				lpMyptr	++ ;
#else
				if (woChara > 0x100){
					if ((unsigned char)*lpMyptr != (woChara >> 8))
						break ;
					woChara	= woChara & 0x00FF ;
					lpMyptr	++ ;
				} else if (woChara == MYTEXT (' ') || woChara == EOL){
					break ;
				}
				if ((unsigned char)*lpMyptr != woChara)
					break ;
				lpMyptr	++ ;
#endif
			}
		}
		if (!*lpMyptr){
			do {
				iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				iRet	= MyEucJpChar (&eucjpState, iChara, &woChara) ;
			}	while (!iRet && iChara != EOF) ;

			if (iRet > 0 && woChara == MYTEXT (' '))
				return	j_search_sorted_euc_jisyo_find (lpJisyo, &eucjpState, lpListBuffer) ;
		}
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (j_cand_compare (*lpMyptr, woChara, sstyle))
			break ; 
#else
		if (j_cand_compare ((unsigned char)*lpMyptr, woChara, sstyle))
			break ; 
#endif

		while ((iChara = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
			if (iChara == EOL)
				break ;
		}
		lFilePos		= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		if (lFilePos >= lEndPosition)
			break ;
	}
	return	lpListBuffer ;
}

LPLISTBUFFER	j_search_sorted_jis_jisyo_sub (LPSKKSORTEDJISYO lpJisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, int sstyle, long lEndPosition)
{
	LPCMYSTR				lpMyptr ;
	long					lFilePos ;
	int						iChara ;
	ISO2022STATE			iso2022jpState ;
	int						iRet ;
	WORD					woChara ;

	iChara	= '\0' ;
	while (iChara != EOF){
		iso2022jp_init (&iso2022jpState) ;
		lpMyptr	= lpKey ;
		while (*lpMyptr){
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			if (iChara == EOF)
				break ;
			iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
			if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (*lpMyptr != woChara || woChara == MYTEXT (' ') || woChara == EOL)
					break ;
				lpMyptr	++ ;
#else
				if (woChara > 0x100){
					if ((unsigned char)*lpMyptr != (woChara >> 8))
						break ;
					woChara	= woChara & 0x00FF ;
					lpMyptr	++ ;
				} else if (woChara == MYTEXT (' ') || woChara == EOL){
					break ;
				}
				if ((unsigned char)*lpMyptr != woChara)
					break ;
				lpMyptr	++ ;
#endif
			}
		}
		if (!*lpMyptr){
			do {
				iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
			}	while (!iRet && iChara != EOF) ;

			if (iRet > 0 && woChara == MYTEXT (' '))
				return	j_search_sorted_jis_jisyo_find (lpJisyo, &iso2022jpState, lpListBuffer) ;
		}
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (j_cand_compare (*lpMyptr, woChara, sstyle))
			break ; 
#else
		if (j_cand_compare ((unsigned char)*lpMyptr, woChara, sstyle))
			break ; 
#endif

		while ((iChara = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
			if (iChara == EOL)
				break ;
		}
		lFilePos		= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		if (lFilePos >= lEndPosition)
			break ;
	}
	return	lpListBuffer ;
}

LPLISTBUFFER	j_search_sorted_sjis_jisyo_sub (LPSKKSORTEDJISYO lpJisyo, LPLISTBUFFER lpListBuffer, LPCMYSTR lpKey, int sstyle, long lEndPosition)
{
	LPCMYSTR				lpMyptr ;
	long					lFilePos ;
	int						iChara ;
	int						iLeadChara ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	unsigned char			c1, c2 ;
#endif

	iChara	= '\0' ;
	while (iChara != EOF){
		lpMyptr		= lpKey ;
		iLeadChara	= '\0' ;
		while (*lpMyptr){
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			if (iChara == ' ' || iChara == EOL || iChara == EOF)
				break ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iLeadChara){
				c1	= (unsigned char)iLeadChara ;
				c2	= (unsigned char)iChara ;
				c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
				c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
				if (c2 >= 0x7F){
					c2	-= 0x5E ;
				} else {
					c1	-- ;
				}
				if (*lpMyptr != UNICODE_JISX0208 ((c1 << 8) | c2))
					break ;
				lpMyptr	++ ;
				iLeadChara	= '\0' ;
			} else {
				if (IsDBCSLeadByte ((char)iChara)){
					iLeadChara	= iChara ;
				} else if (iChara < 0x80){
					if (*lpMyptr != (WORD)iChara)
						break ;
					lpMyptr	++ ;
				} else {
					if (*lpMyptr != UNICODE_JISX0201 (iChara))
						break ;
					lpMyptr	++ ;
				}
			}
#else
			if ((unsigned char)*lpMyptr != iChara)
				break ;
			lpMyptr	++ ;
#endif
		}
		if (!*lpMyptr){
			iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
			if (iChara == ' ')
				return	j_search_sorted_sjis_jisyo_find (lpJisyo, lpListBuffer) ;
		}
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (j_cand_compare (*lpMyptr, iChara, sstyle))
			break ; 
#else
		if (j_cand_compare ((unsigned char)*lpMyptr, iChara, sstyle))
			break ; 
#endif

		while ((iChara = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
			if (iChara == EOL)
				break ;
		}
		lFilePos		= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		if (lFilePos >= lEndPosition)
			break ;
	}
	return	lpListBuffer ;
}

int	j_cand_compare (int c1, int c2, int f)
{
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	BYTE		byMap1,		byMap2 ;
	WORD		woCode1,	woCode2 ;
#endif
	if (c1 == MYTEXT (' ') || c1 == MYTEXT ('\n'))
		c1	= 0 ;
	if (c2 == ' ')
		c2	= 0 ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	if (c2 > 0x0100)
		c2	= c2 >> 8 ;
	if (f != 1){
		return	(c1 < c2) ;
	} else {
		return	(c1 > c2) ;
	}
#else
	if (c1 < 0x7F){
		byMap1	= MYCODEMAP_ASCII ;
		woCode1	= c1 ;
	} else {
		byMap1	= GetOriginalCode (&woCode1, (wchar_t)c1) ;
	}
	if (c2 < 0x7F){
		byMap2	= MYCODEMAP_ASCII ;
		woCode2	= c2 ;
	} else {
		byMap2	= GetOriginalCode (&woCode2, (wchar_t)c2) ;
	}
	if (f != 1){
		return	(byMap1 == byMap2)? (woCode1 < woCode2) : (byMap1 < byMap2) ;
	} else {
		return	(byMap1 == byMap2)? (woCode1 > woCode2) : (byMap1 > byMap2) ;
	}
#endif
}

LPLISTBUFFER	j_search_sorted_euc_jisyo_find (LPSKKSORTEDJISYO lpJisyo, LPISO2022STATE lpState, LPLISTBUFFER lpListBuffer)
{
	MYCHAR			buffer [BUFSIZE] ;
	int				iChara ;
	int				iRet ;
	WORD			woChara ;
	LPMYSTR			pbuf ;
	long			lRest ;

	pbuf		= buffer ;
	lRest		= BUFSIZE ;
	while (TRUE){
		iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		iRet	= MyEucJpChar (lpState, iChara, &woChara) ;
		if (iRet < 0 || iChara == EOL || iChara == EOF)
			break ;
		if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iRet < 1){
				lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
				pbuf			= buffer ;
				lRest			= BUFSIZE ;
			}
			*pbuf	++		= woChara ;
			lRest	-- ;
#else
			if (woChara > 0x0100){
				if (lRest < 2){
					lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
					pbuf			= buffer ;
					lRest			= BUFSIZE ;
				}
				*pbuf	++	= (woChara >> 8) ;
				lRest	-- ;
				*pbuf	++	= (woChara & 0x00FF) ;
				lRest	-- ;
			} else {
				if (lRest < 1){
					lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
					pbuf			= buffer ;
					lRest			= BUFSIZE ;
				}
				*pbuf	++	= (woChara & 0x00FF) ;
				lRest	-- ;
			}
#endif
		}
	}

	if (lRest < BUFSIZE){
		lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
		lRest			= BUFSIZE ;
	}
	return	lpListBuffer ;
}

LPLISTBUFFER	j_search_sorted_jis_jisyo_find (LPSKKSORTEDJISYO lpJisyo, LPISO2022STATE lpState, LPLISTBUFFER lpListBuffer)
{
	MYCHAR			buffer [BUFSIZE] ;
	int				iChara ;
	int				iRet ;
	WORD			woChara ;
	LPMYSTR			pbuf ;
	long			lRest ;

	pbuf		= buffer ;
	lRest		= BUFSIZE ;
	while (TRUE){
		iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		iRet	= MyIso2022JpChar (lpState, iChara, &woChara) ;
		if (iRet < 0 || iChara == EOF || iChara == EOL)
			break ;
		if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iRet < 1){
				lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
				pbuf			= buffer ;
				lRest			= BUFSIZE ;
			}
			*pbuf	++		= woChara ;
			lRest	-- ;
#else
			if (woChara > 0x0100){
				if (lRest < 2){
					lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
					pbuf			= buffer ;
					lRest			= BUFSIZE ;
				}
				*pbuf	++	= (woChara >> 8) ;
				lRest	-- ;
				*pbuf	++	= (woChara & 0x00FF) ;
				lRest	-- ;
			} else {
				if (lRest < 1){
					lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
					pbuf			= buffer ;
					lRest			= BUFSIZE ;
				}
				*pbuf	++	= (woChara & 0x00FF) ;
				lRest	-- ;
			}
#endif
		}
	}

	if (lRest < BUFSIZE){
		lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
		lRest			= BUFSIZE ;
	}
	return	lpListBuffer ;
}

LPLISTBUFFER	j_search_sorted_sjis_jisyo_find (LPSKKSORTEDJISYO lpJisyo, LPLISTBUFFER lpListBuffer)
{
	MYCHAR			buffer [BUFSIZE] ;
	int				iChara ;
	int				iLeadChara ;
	LPMYSTR			pbuf ;
	long			lRest ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	unsigned char	c1, c2 ;
#endif

	pbuf		= buffer ;
	lRest		= BUFSIZE ;
	iLeadChara	= '\0' ;
	while (1){
		iChara	= winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		if (iChara == EOF || iChara == EOL)
			break ;
		if (iLeadChara){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			c1	= (unsigned char)iLeadChara ;
			c2	= (unsigned char)iChara ;
			c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
			c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			*pbuf	++	= UNICODE_JISX0208 ((c1 << 8) | c2) ;
			lRest	-- ;
#else
			*pbuf	++	= iLeadChara & 0x00FF ;
			lRest	-- ;
			*pbuf	++	= iChara & 0x00FF ;
			lRest	-- ;
#endif
			iLeadChara	= '\0' ;
		} else {
			if (IsDBCSLeadByte ((char)iChara)){
				iLeadChara	= iChara ;
			} else if (iChara < 0x80){
				*pbuf	++	= iChara & 0x00FF ;
				lRest	-- ;
			} else {
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				*pbuf	++	= UNICODE_JISX0201 (iChara) ;
#else
				*pbuf	++	= iChara & 0x00FF ;
#endif
				lRest	-- ;
			}
		}
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (lRest < 1){
			lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
			pbuf			= buffer ;
			lRest			= BUFSIZE ;
		}
#else
		if (lRest < 2){
			lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
			pbuf			= buffer ;
			lRest			= BUFSIZE ;
		}
#endif
	}
	if (lRest < BUFSIZE){
		lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, BUFSIZE - lRest, NULL, NULL) ;
		lRest			= BUFSIZE ;
	}
	return	lpListBuffer ;
}

