/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * UICOMP.C
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"

/*************************************************************************
 *	Composition Window �� WINDOWPROC�B
 *(�R�����g)
 *	Composition Window ����Window Message�͂��̊֐��ɑ����ė��܂��̂ŁA
 *	Window Message �ɑΉ������������s���܂��B���̊֐����̂� Window
 *	Message �̐U�蕪�������ł����ǁB
 *(����)
 *	hWnd	Window Message ���󂯎���� Composition Window �� Handle
 *	message	Window Message
 *	wParam	Window Message �̈�������1
 *	lParam	Window Message �̈�������2
 *************************************************************************/
LRESULT	CALLBACK	CompStrWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND	hUIWnd ;

	switch (message){
	case WM_PAINT:
		PaintCompWindow (hWnd) ;
		break ;

	case WM_SETCURSOR:
	case WM_MOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		if ((message == WM_SETCURSOR) &&
			(HIWORD(lParam) != WM_LBUTTONDOWN) &&
			(HIWORD(lParam) != WM_RBUTTONDOWN)) 
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;

	case WM_MOVE:
		hUIWnd = (HWND)GetWindowLong (hWnd, FIGWL_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_DEFCOMPMOVE, wParam, lParam) ;
		break ;

	default:
		if (!MyIsIMEMessage(message))
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return 0;
}

/*
 *	IME �����͒��̕������\������ۂɗ��p���� Composition Window ���쐬��
 *	��֐��B
 */
void	PASCAL	CreateCompWindow (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	int						i ;
	RECT					rc ;
	LONG					lInst ;

	lpUIExtra->dwCompStyle	= lpIMC->cfCompForm.dwStyle ;
	/*
	 *	hInst �� hUIWnd �� INSTANCE ���قȂ�\��������̂ŁA������
	 *	hUIWnd �� INSTANCE ����蒼���B
	 */
	lInst					= GetWindowLong (hUIWnd, GWL_HINSTANCE) ;
	/*
	 *	Composition Window ���쐬����B�쐬�Ɠ����Ɉʒu����t�H���g
	 *	�������������Ă܂��B
	 */
	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (!IsWindow (lpUIExtra->uiComp[i].hWnd)){
			/* hInst �Ɨ^����ꂽ hUIWnd �� hInstance �̒l���قȂ�? */
			lpUIExtra->uiComp[i].hWnd = 
				CreateWindowEx (0,
							 (LPSTR)szCompStrClassName, NULL,
							 WS_COMPNODEFAULT,
							 0, 0, 1, 1,
							 hUIWnd, NULL, (HINSTANCE)lInst, NULL) ;
		}
		lpUIExtra->uiComp[i].rc.left	= 0 ;
		lpUIExtra->uiComp[i].rc.top		= 0 ;
		lpUIExtra->uiComp[i].rc.right	= 1 ;
		lpUIExtra->uiComp[i].rc.bottom	= 1 ;
		SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_FONT,			(DWORD)lpUIExtra->hFont) ;
		SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_SVRWND,		(DWORD)hUIWnd) ;
		SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_PREVCURSOR,	(DWORD)0) ;
		ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_HIDE) ;
		lpUIExtra->uiComp[i].bShow = FALSE ;
	}
	if (lpUIExtra->uiDefComp.pt.x == -1){
		GetWindowRect (lpIMC->hWnd, &rc) ;
		lpUIExtra->uiDefComp.pt.x	= rc.left ;
		lpUIExtra->uiDefComp.pt.y	= rc.bottom + 1 ;
	}
	/* Root Window Style �̏ꍇ�� Window ���쐬����B*/
	if (!IsWindow (lpUIExtra->uiDefComp.hWnd)){
		lpUIExtra->uiDefComp.hWnd = 
			CreateWindowEx (WS_EX_WINDOWEDGE,
						 (LPSTR)szCompStrClassName, NULL,
						 WS_COMPDEFAULT | WS_DLGFRAME,
						 lpUIExtra->uiDefComp.pt.x,
						 lpUIExtra->uiDefComp.pt.y,
						 1, 1,
						 hUIWnd, NULL, (HINSTANCE)lInst, NULL) ;
	}
	//SetWindowLong (lpUIExtra->uiDefComp.hWnd, FIGWL_FONT,(DWORD)lpUIExtra->hFont) ;
	SetWindowLong (lpUIExtra->uiDefComp.hWnd, FIGWL_SVRWND,			(DWORD)hUIWnd) ;
	SetWindowLong (lpUIExtra->uiDefComp.hWnd, FIGWL_PREVCURSOR, 	(DWORD)0) ;
	ShowWindow (lpUIExtra->uiDefComp.hWnd, SW_HIDE) ;
	lpUIExtra->uiDefComp.bShow	= FALSE ;
	return ;
}

/*
 *	Window �ɕ\���\�ȕ����̐������肷��֐��B
 *(����)
 *	hDC			Handle Device Context
 *	lp			��ʂɕ\��������������
 *	iLength		������̒���
 *	dx			Window �̉����B
 *(���l)
 *	���s�Ɉ˂炸��ʂŐ܂�Ԃ����s�����ɂ́Abackslash ��\�����������H
 */
int	PASCAL	NumCharInDX (HDC hDC, LPMYSTR lp, int iLength, int dx, BOOL FAR* lpfNewline)
{
	SIZE		sz;
	BOOL		fNewline ;
	int width	= 0 ;
	int num		= 0 ;
	int numT	= 0 ;

	if (!*lp){
		if (lpfNewline)
			*lpfNewline	= FALSE ;
		return 0 ;
	}
	fNewline	= FALSE ;
	while ((width < dx) && numT < iLength && *(lp + numT)){
		/* DOS ���s�R�[�h�����t�����ꍇ�̏����B*/
		if ((numT + 1) < iLength &&
			(*(lp + numT) == MYTEXT ('\n') && *(lp + numT + 1) == MYTEXT ('\r')) ||
			(*(lp + numT) == MYTEXT ('\r') && *(lp + numT + 1) == MYTEXT ('\n'))){
			fNewline	= TRUE ;
			numT		+= 2 ;
			break ;
		}
		num = numT ;

		/*
		 *	Unicode �̏ꍇ�ɂ� LeadByte ���l���Ȃ��ėǂ����c ShiftJIS
		 *	�̏ꍇ�ɂ� 1 �o�C�g������ 2 �o�C�g�����ɂ���ď����𕪂��Ȃ�
		 *	�Ƃ����Ȃ��B
		 */
#ifdef SKKIME98M
		numT ++ ;
		GetTextExtentPoint32W (hDC, lp, numT, &sz) ;
#else
		if (IsDBCSLeadByte (*(lp + numT))){
			numT += 2 ;
		} else {
			numT ++ ;
		}		
		GetTextExtentPoint32 (hDC, lp, numT, &sz) ;
#endif
		width	= sz.cx ;
	}

	if (width < dx)
		num		= numT ;
	if (lpfNewline)
		*lpfNewline	= fNewline ;

	return	num ;
}

int	PASCAL	NumCharInDY (HDC hDC, LPMYSTR lp, int iLength, int dy, BOOL FAR* lpfNewline)
{
	SIZE	sz ;
	BOOL	fNewline ;
	int		width = 0 ;
	int		num ;
	int 	numT = 0 ;

	if (!*lp){
		if (lpfNewline)
			*lpfNewline	= FALSE ;
		return 0 ;
	}
	fNewline	= FALSE ;

	while ((width < dy) && numT < iLength && *(lp + numT)){
		/* DOS ���s�R�[�h�����t�����ꍇ�̏����B*/
		if ((numT + 1) < iLength &&
			(*(lp + numT) == MYTEXT ('\n') && *(lp + numT + 1) == MYTEXT ('\r')) ||
			(*(lp + numT) == MYTEXT ('\r') && *(lp + numT + 1) == MYTEXT ('\n'))){
			fNewline	= TRUE ;
			numT		+= 2 ;
			break ;
		}
		num		= numT ;

#ifdef SKKIME98M
		numT	++ ;
		GetTextExtentPoint32W (hDC, lp, numT, &sz) ;
#else
		if (IsDBCSLeadByte(*(lp + numT))){
			numT	+= 2 ;
		} else {
			numT	++ ;
		}
		GetTextExtentPoint32 (hDC, lp, numT, &sz) ;
#endif
		width	= sz.cx ;
	}
	if (width < dy)
		num		= numT ;
	if (lpfNewline)
		*lpfNewline	= fNewline ;

	return	num ;
}

void	PASCAL	MoveUiCompWindowHorz (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC, LPCOMPOSITIONSTRING lpCompStr, RECT* pRcSrc, POINT* pPtSrc)
{
	LPMYSTR		lpt ;
	LPMYSTR		lpstr ;
	HDC			hDC ;
	HFONT		hFont		= NULL ;
	HFONT		hOldFont 	= NULL ;
	RECT		oldrc ;
	RECT		irc ;
	SIZE		sz ;
	SIZE		isz ;
	int	 		i ;
	int			num ;
	int			numT ;
	int			dx ;
	int			curx, cury ;
	int			iLength ;
	int			iPosition ;
	int			iPrevCursor ;
	int			iCursor ;
	int			iDeltaPoint ;
	BOOL		fNeedNext ;
	BOOL		fNewline ;
	BOOL		fCursorMove ;

	lpt 		= GETLPCOMPSTR (lpCompStr) ;
	lpstr		= lpt ;
	iLength		= lpCompStr->dwCompStrLen ;
	iDeltaPoint	= lpCompStr->dwDeltaStart ;
	iCursor		= lpCompStr->dwCursorPos ;
	fNeedNext	= FALSE ;
	iPosition	= 0 ;

	dx			= pRcSrc->right - pPtSrc->x ;
	curx		= pPtSrc->x ;
	cury		= pPtSrc->y ;

	/*
	 * Set the composition string to each composition window.
	 * The composition windows that are given the compostion string
	 * will be moved and shown.
	 */
	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (!IsWindow (lpUIExtra->uiComp [i].hWnd))
			continue ;
		iPrevCursor	= (int)GetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_PREVCURSOR) ;
		fCursorMove	= (iPrevCursor != iCursor && (((LPMYCOMPSTR)lpCompStr)->dwUpdateFlag & SKKUI_UPDATE_CURSOR)) ;

		hDC	= GetDC (lpUIExtra->uiComp [i].hWnd) ;

		if (hFont = (HFONT)GetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_FONT))
			hOldFont = SelectObject (hDC, hFont) ;

		sz.cy	= 0 ;
		oldrc	= lpUIExtra->uiComp [i].rc ;

		num		= NumCharInDX (hDC, lpt, iLength, dx, &fNewline) ;
		if (num){
			numT	= num ;
			if (fNewline){
				/* DOS ���s�R�[�h�� 0x0D 0x0A �Ȃ̂ŁA2 �������J�E���g�����炷�B*/
				numT		-= 2 ;
				fNeedNext	= TRUE ;
			} else {
				fNeedNext	= FALSE ;
			}
			if (numT > 0){
				/* ���s�����ł͂Ȃ����炩�̕������\�������ꍇ�B*/
				MyGetTextExtentPoint (hDC, lpt, numT, &sz) ;
			} else {
				/* ���s�����̍s�������ꍇ�B*/
				MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
				sz.cx		= UI_CURSORWIDTH ;
				numT		= 0 ;
			}
			lpUIExtra->uiComp[i].rc.left	= curx ;
			lpUIExtra->uiComp[i].rc.top	 	= cury ;
			lpUIExtra->uiComp[i].rc.right   = sz.cx ;
			lpUIExtra->uiComp[i].rc.bottom  = sz.cy ;
			SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_COMPSTARTSTR, (lpt - lpstr)) ;
			SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_COMPSTARTNUM, numT) ;
			MoveWindow (lpUIExtra->uiComp [i].hWnd, curx, cury, sz.cx, sz.cy, TRUE) ;
			ShowWindow (lpUIExtra->uiComp [i].hWnd, SW_SHOWNOACTIVATE) ;
			lpUIExtra->uiComp [i].bShow		= TRUE ;

			/*
			 *	�X�V�̈���v�Z����B
			 */
			irc.top		= 0 ;
			irc.bottom	= sz.cy ;
			irc.right	= 0 ;
			irc.left	= sz.cx ;
			if (iDeltaPoint <= iPosition){
				irc.left	= 0 ;
				irc.right	= sz.cx ;
			} else if (iDeltaPoint <= (iPosition + num)){
				MyGetTextExtentPoint (hDC, lpt, iDeltaPoint - iPosition, &isz) ;
				irc.left	= isz.cx ;
				irc.right	= sz.cx ;
			}
			if (fCursorMove){
				if (iPosition <= iPrevCursor && iPrevCursor <= (iPosition + num)){
					MyGetTextExtentPoint (hDC, lpt, iPrevCursor - iPosition, &isz) ;
					if (isz.cx < irc.left)
						irc.left	= isz.cx ;
					if (irc.right < (isz.cx + UI_CURSORWIDTH))
						irc.right	= isz.cx + UI_CURSORWIDTH ;
				}
				if (iPosition <= iCursor && iCursor <= (iPosition + num)){
					MyGetTextExtentPoint (hDC, lpt, iCursor - iPosition, &isz) ;
					if (isz.cx < irc.left)
						irc.left	= isz.cx ;
					if (irc.right < (isz.cx + UI_CURSORWIDTH))
						irc.right	= isz.cx + UI_CURSORWIDTH ;
				}
			}
			if (irc.left < irc.right)
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, &irc, FALSE) ;

			lpt			+= num ;
			iLength 	-= num ;
		} else {
			MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
			if (fNeedNext && (int)lpCompStr->dwCompStrLen == iCursor){
				lpUIExtra->uiComp [i].rc.left	= curx ;
				lpUIExtra->uiComp [i].rc.top 	= cury ;
				lpUIExtra->uiComp [i].rc.right	= UI_CURSORWIDTH ;
				lpUIExtra->uiComp [i].rc.bottom	= sz.cy ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTSTR, lpCompStr->dwCompStrLen) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTNUM, 0L) ;
				MoveWindow (lpUIExtra->uiComp[i].hWnd, curx, cury, UI_CURSORWIDTH, sz.cy, TRUE) ;
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_SHOWNOACTIVATE) ;
				lpUIExtra->uiComp [i].bShow		= TRUE ;
				fNeedNext						= FALSE ;
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, NULL, FALSE) ;
			} else {
				lpUIExtra->uiComp[i].rc.left	= 0 ;
				lpUIExtra->uiComp[i].rc.top	 	= 0 ;
				lpUIExtra->uiComp[i].rc.right   = 0 ;
				lpUIExtra->uiComp[i].rc.bottom  = 0 ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTSTR, 0L) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTNUM, 0L) ;
				ShowWindow (lpUIExtra->uiComp [i].hWnd, SW_HIDE) ;
				lpUIExtra->uiComp[i].bShow		= FALSE ;
			}
			sz.cx	= 0 ;
		}
		dx		= pRcSrc->right - pRcSrc->left ;
		curx	= pRcSrc->left ;
		cury	+= sz.cy ;

		if (hOldFont)
			SelectObject (hDC, hOldFont) ;
		ReleaseDC (lpUIExtra->uiComp [i].hWnd, hDC) ;
		SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_PREVCURSOR, (DWORD)iCursor) ;
		iPosition	+= num ;
	}
	return ;
}

void	PASCAL	MoveUiCompWindowVert (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC, LPCOMPOSITIONSTRING lpCompStr, RECT* pRcSrc, POINT* pPtSrc)
{
	LPMYSTR		lpt ;
	LPMYSTR		lpstr ;
	HDC			hDC ;
	HFONT		hFont		= NULL ;
	HFONT		hOldFont 	= NULL ;
	RECT		oldrc ;
	RECT		irc ;
	SIZE		sz ;
	SIZE		isz ;
	int	 		i ;
	int			num ;
	int			numT ;
	int			dy ;
	int			curx, cury ;
	int			iLength ;
	int			iPosition ;
	int			iPrevCursor ;
	int			iCursor ;
	int			iDeltaPoint ;
	BOOL		fNeedNext ;
	BOOL		fNewline ;
	BOOL		fCursorMove ;

	lpt 		= GETLPCOMPSTR (lpCompStr) ;
	lpstr		= lpt ;
	iLength		= lpCompStr->dwCompStrLen ;
	iDeltaPoint	= lpCompStr->dwDeltaStart ;
	iCursor		= lpCompStr->dwCursorPos ;

	dy 			= pRcSrc->bottom - pPtSrc->y ;
	curx 		= pPtSrc->x ;
	cury 		= pPtSrc->y ;
	iPosition	= 0 ;

	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (!IsWindow(lpUIExtra->uiComp[i].hWnd))
			continue ;

		iPrevCursor	= (int)GetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_PREVCURSOR) ;
		fCursorMove	= (iPrevCursor != iCursor && (((LPMYCOMPSTR)lpCompStr)->dwUpdateFlag & SKKUI_UPDATE_CURSOR)) ;

		hDC = GetDC (lpUIExtra->uiComp [i].hWnd) ;

		if (hFont = (HFONT)GetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_FONT))
			hOldFont = SelectObject (hDC, hFont) ;

		sz.cy	= 0 ;
		num		= NumCharInDY (hDC, lpt, iLength, dy, &fNewline) ;
		if (num){
			numT	= num ;
			if (fNewline){
				numT		-= 2 ;
				fNeedNext	= TRUE ;
			} else {
				fNeedNext	= FALSE ;
			}
			if (numT > 0){
				MyGetTextExtentPoint (hDC, lpt, num, &sz) ;
			} else {
				MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
				sz.cx	= UI_CURSORWIDTH ;
				numT	= 0 ;
			}
			lpUIExtra->uiComp[i].rc.left	= curx - sz.cy ;
			lpUIExtra->uiComp[i].rc.top		= cury ;
			lpUIExtra->uiComp[i].rc.right	= sz.cy ;
			lpUIExtra->uiComp[i].rc.bottom	= sz.cx ;
			SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTSTR, (lpt - lpstr));
			SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTNUM, numT) ;
			MoveWindow (lpUIExtra->uiComp[i].hWnd, curx - sz.cy, cury, sz.cy, sz.cx, TRUE) ;
			ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_SHOWNOACTIVATE) ;
			lpUIExtra->uiComp[i].bShow		= TRUE ;

			/*
			 *	�X�V�̈���v�Z����B
			 */
			irc.left	= 0 ;
			irc.right	= sz.cy ;
			irc.top		= sz.cx ;
			irc.bottom	= 0 ;
			if (iDeltaPoint <= iPosition){
				irc.top		= 0 ;
				irc.bottom	= sz.cx ;
			} else if (iDeltaPoint <= (iPosition + num)){
				MyGetTextExtentPoint (hDC, lpt, iDeltaPoint - iPosition, &isz) ;
				irc.top		= isz.cx ;
				irc.bottom	= sz.cx ;
			}
			if (fCursorMove){
				if (iPosition <= iPrevCursor && iPrevCursor <= (iPosition + num)){
					MyGetTextExtentPoint (hDC, lpt, iPrevCursor - iPosition, &isz) ;
					if (isz.cx < irc.top)
						irc.top	= isz.cx ;
					if (irc.bottom < (isz.cx + UI_CURSORWIDTH))
						irc.bottom	= isz.cx + UI_CURSORWIDTH ;
				}
				if (iPosition <= iCursor && iCursor <= (iPosition + num)){
					MyGetTextExtentPoint (hDC, lpt, iCursor - iPosition, &isz) ;
					if (isz.cx < irc.top)
						irc.top	= isz.cx ;
					if (irc.bottom < (isz.cx + UI_CURSORWIDTH))
						irc.bottom	= isz.cx + UI_CURSORWIDTH ;
				}
			}
			if (irc.top < irc.bottom)
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, &irc, FALSE) ;

			lpt		+= num ;
			iLength	-= num ;
		} else {
			MyGetTextExtentPoint (hDC, MYTEXT ("|"), 1, &sz) ;
			sz.cx	= 1 ;
			if (fNeedNext && (int)lpCompStr->dwCompStrLen == iCursor){
				lpUIExtra->uiComp[i].rc.left	= curx - sz.cy ;
				lpUIExtra->uiComp[i].rc.top	 	= cury ;
				lpUIExtra->uiComp[i].rc.right   = sz.cy ;
				lpUIExtra->uiComp[i].rc.bottom  = sz.cx ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTSTR, lpCompStr->dwCompStrLen) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTNUM, 0L) ;
				MoveWindow (lpUIExtra->uiComp[i].hWnd, curx - sz.cy, cury, sz.cy, sz.cx, TRUE) ;
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_SHOWNOACTIVATE) ;
				lpUIExtra->uiComp[i].bShow		= TRUE ;
				fNeedNext						= FALSE ;
				InvalidateRect (lpUIExtra->uiComp [i].hWnd, NULL, FALSE) ;
			} else {
				lpUIExtra->uiComp[i].rc.left	= 0 ;
				lpUIExtra->uiComp[i].rc.top		= 0 ;
				lpUIExtra->uiComp[i].rc.right   = 0 ;
				lpUIExtra->uiComp[i].rc.bottom	= 0 ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTSTR, 0L) ;
				SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_COMPSTARTNUM, 0L) ;
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_HIDE) ;
				lpUIExtra->uiComp[i].bShow		= FALSE ;
			}
			sz.cx	= 0 ;
		}

		dy		= pRcSrc->bottom - pRcSrc->top ;
		cury	= pRcSrc->top ;
		curx	-= sz.cy ;

		if (hOldFont)
			SelectObject (hDC, hOldFont) ;
		ReleaseDC (lpUIExtra->uiComp [i].hWnd, hDC) ;
		SetWindowLong (lpUIExtra->uiComp [i].hWnd, FIGWL_PREVCURSOR, (DWORD)iCursor) ;
		iPosition	+= num ;
	}
	return ;
}

void	PASCAL	MoveUiCompWindow (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;
	POINT				ptSrc ;
	RECT				rcSrc ;
	int					dx ;
	int					dy ;
	int					num ;
	int					curx ;
	int					cury ;

	ptSrc		= lpIMC->cfCompForm.ptCurrentPos ;
	/*
	 * Lock the COMPOSITIONSTRING structure.
	 */
	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (!lpCompStr)
		return ;

	/*
	 * If there is no composition string, don't display anything.
	 */
	if ((lpCompStr->dwSize <= sizeof(COMPOSITIONSTRING)) ||
		(lpCompStr->dwCompStrLen == 0)){
		ImmUnlockIMCC (lpIMC->hCompStr) ;
		return ;
	}

	/*
	 * Set the rectangle for the composition string.
	 */
	if ((lpIMC->cfCompForm.dwStyle & CFS_RECT) &&
		(lpIMC->cfCompForm.rcArea.left < lpIMC->cfCompForm.rcArea.right &&
		 lpIMC->cfCompForm.rcArea.top  < lpIMC->cfCompForm.rcArea.bottom)){
		rcSrc	= lpIMC->cfCompForm.rcArea ;
	} else {
		GetClientRect (lpIMC->hWnd, (LPRECT)&rcSrc) ;
	}

	ClientToScreen (lpIMC->hWnd, &ptSrc) ;
	ClientToScreen (lpIMC->hWnd, (LPPOINT)&rcSrc.left) ;
	ClientToScreen (lpIMC->hWnd, (LPPOINT)&rcSrc.right) ;

	/*
	 * Check the start position.
	 */
	if (!PtInRect((LPRECT)&rcSrc, ptSrc)){
		ImmUnlockIMCC (lpIMC->hCompStr) ;
		return ;
	}

	/*
	 * Hide the default composition window.
	 */
	if (IsWindow (lpUIExtra->uiDefComp.hWnd)){
		ShowWindow (lpUIExtra->uiDefComp.hWnd, SW_HIDE) ;
		lpUIExtra->uiDefComp.bShow	= FALSE ;
	}
	if (!lpUIExtra->bVertical){
		MoveUiCompWindowHorz (hUIWnd, lpUIExtra, lpIMC, lpCompStr, &rcSrc, &ptSrc) ;
	} else  {
		MoveUiCompWindowVert (hUIWnd, lpUIExtra, lpIMC, lpCompStr, &rcSrc, &ptSrc) ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return ;
}

void	PASCAL	MoveDefUiCompWindow (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;
	HDC					hDC ;
	LPMYSTR				lpstr ;
	RECT				rc ;
	SIZE				sz ;
	int					width, height ;
	int					i ;

	/*
	 * When the style is DEFAULT, show the default composition window.
	 */
	width	= 0 ;
	height	= 0 ;
	if (IsWindow (lpUIExtra->uiDefComp.hWnd)){
		for (i = 0 ; i < MAXCOMPWND ; i++){
			if (IsWindow (lpUIExtra->uiComp[i].hWnd)){
				ShowWindow (lpUIExtra->uiComp[i].hWnd, SW_HIDE) ;
				lpUIExtra->uiComp[i].bShow	= FALSE;
			}
		}
		hDC			= GetDC (lpUIExtra->uiDefComp.hWnd) ;
		lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpCompStr){
			if ((lpCompStr->dwSize > sizeof(COMPOSITIONSTRING)) &&
				(lpCompStr->dwCompStrLen > 0)){
				lpstr = GETLPCOMPSTR(lpCompStr) ;
				MyGetTextExtentPoint (hDC, lpstr, Mylstrlen (lpstr), &sz) ;
				width	= sz.cx ;
				height	= sz.cy ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ReleaseDC (lpUIExtra->uiDefComp.hWnd, hDC) ;
		
		GetWindowRect (lpUIExtra->uiDefComp.hWnd, &rc) ;
		lpUIExtra->uiDefComp.pt.x	= rc.left ;
		lpUIExtra->uiDefComp.pt.y	= rc.top ;
		MoveWindow (lpUIExtra->uiDefComp.hWnd,
					rc.left,
					rc.top,
					width  + 2 * GetSystemMetrics (SM_CXEDGE),
					height + 2 * GetSystemMetrics (SM_CYEDGE),
					TRUE) ;
		if (width > 0 && height > 0){
			ShowWindow (lpUIExtra->uiDefComp.hWnd, SW_SHOWNOACTIVATE) ;
			lpUIExtra->uiDefComp.bShow	= TRUE ;
			InvalidateRect (lpUIExtra->uiDefComp.hWnd, NULL, FALSE) ;
		}
	}
	return ;
}

void	PASCAL	MoveCompWindow (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	lpUIExtra->dwCompStyle	= lpIMC->cfCompForm.dwStyle ;
	if (lpIMC->cfCompForm.dwStyle){
		MoveUiCompWindow (hUIWnd, lpUIExtra, lpIMC) ;
	} else {
		MoveDefUiCompWindow (hUIWnd, lpUIExtra, lpIMC) ;
	}
	return ;
}

/*
 *	�e�L�X�g����s�\������֐��B
 *(����)
 *	hCompWnd		�e�L�X�g��\������ Window �� Handle
 *	hDC				hCompWnd �� Device Context Handle
 */
void PASCAL DrawTextOneLine (HWND hCompWnd, HDC hDC, LPMYSTR lpstr, LPBYTE lpattr, int num, int iCursorPos, BOOL fVert)
{
	LPMYSTR 	lpStart	;
	LPMYSTR 	lpEnd ;
	COLORREF	colForeground ;
	COLORREF	colBackground ;
	COLORREF	colConverted ;
	int			x,y ;
	RECT		rc ;
	int			cnt ;
	BYTE		bAttr ;
	SIZE		sz ;
	HPEN		hPen ;
	HPEN		hOldPen ;
	RECT		invRect ;

	if (num <= 0)
		return ;

	lpStart				= lpstr ;
	lpEnd				= lpstr + num - 1 ;

	/*
	 *	�\���F�̐ݒ�B
	 */
	switch (skkinput_background.m_bType){
	case	MYCOLORTYPE_RGB:
		colBackground	= PALETTERGB (
			skkinput_background.m_bRed,
			skkinput_background.m_bGreen,
			skkinput_background.m_bBlue) ;
		SetBkColor (hDC, colBackground) ;
		break ;
	case	MYCOLORTYPE_AUTO:
	case	MYCOLORTYPE_UNDERLINE:
	default:
		colBackground	= GetBkColor   (hDC) ;
		break ;
	}
	switch (skkinput_foreground.m_bType){
	case	MYCOLORTYPE_RGB:
		colForeground	= PALETTERGB (
			skkinput_foreground.m_bRed,
			skkinput_foreground.m_bGreen,
			skkinput_foreground.m_bBlue) ;
		SetTextColor (hDC, colForeground) ;
		break ;
	case	MYCOLORTYPE_AUTO:
	case	MYCOLORTYPE_UNDERLINE:
	default:
		colForeground		= GetTextColor (hDC) ;
		if (colForeground == colBackground){
			colForeground	= PALETTERGB (
				~GetRValue (colBackground), 
				~GetGValue (colBackground), 
				~GetBValue (colBackground)) ;
			SetTextColor (hDC, colForeground) ;
		}
		break ;
	}

	DEBUGPRINTF ((MYTEXT ("foreground (%x, %x, %x, %d)\n"),
				  skkinput_foreground.m_bType,
				  skkinput_foreground.m_bRed,
				  skkinput_foreground.m_bGreen,
				  skkinput_foreground.m_bBlue)) ;

	switch (skkinput_henkan_face.m_bType){
	case	MYCOLORTYPE_RGB:
		colConverted		= PALETTERGB (
			skkinput_henkan_face.m_bRed,
			skkinput_henkan_face.m_bGreen,
			skkinput_henkan_face.m_bBlue) ;
		break ;
	case	MYCOLORTYPE_UNDERLINE:
		break ;
	case	MYCOLORTYPE_AUTO:
	default:
		colConverted		= PALETTERGB (
			 GetRValue (colForeground), 
			~GetGValue (colForeground), 
			~GetBValue (colForeground)) ;
		break ;
	}

	/*
	 *	�\���̈�̑傫���𓾂�B
	 */
	GetClientRect (hCompWnd, &rc) ;

	if (!fVert){
		/*
		 *	�����̏ꍇ�̏����B
		 *-----
		 *	�����̏ꍇ(ESCAPEMENT==0)�̏ꍇ�ɂ́A�����͍�����E�ցA�ォ�牺��
		 *	�Ɨ����B���̂��߂ɁAWindow �̍���[���珑���o���Ȃ���΂Ȃ�Ȃ��B
		 */
		x = 0 ;
		y = 0 ;
	} else {
		/*
		 *	�c�����̏ꍇ�̏���
		 *-----
		 *	�c�����̏ꍇ(ESCAPEMENT==2700)�̏ꍇ�ɂ́A�����͏ォ�牺�ցA�E���獶��
		 *	�Ɨ����B���̂��߂ɁAWindow �̉E��[���珑���o���Ȃ���΂Ȃ�Ȃ��B
		 */
		x = rc.right ;
		y = 0 ;
	}
	while (lpstr <= lpEnd){
		cnt		= 0 ;
		bAttr	= *lpattr ;
		while ((bAttr == *lpattr) && (cnt < num)){
			lpattr		++ ;
			cnt			++ ;
		}
		switch (bAttr){
		case ATTR_TARGET_CONVERTED:
			if (skkinput_henkan_face.m_bType != MYCOLORTYPE_UNDERLINE){
				SetBkColor   (hDC, colConverted) ;
				MyTextOut (hDC, x, y, lpstr, cnt) ;
				SetBkColor   (hDC, colBackground) ;
			} else {
				MyTextOut (hDC, x, y, lpstr, cnt) ;
				MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
				if (!fVert){
					invRect.left	= x ;
					invRect.right	= x + sz.cx ;
					invRect.top		= rc.bottom - UI_CURSORWIDTH ;
					invRect.bottom	= rc.bottom ;
				} else {
					invRect.left	= rc.right - UI_CURSORWIDTH ;
					invRect.right	= rc.right ;
					invRect.top		= y ;
					invRect.bottom	= y + sz.cx ;
				}
				InvertRect (hDC, &invRect) ;
			}
			break ;

		case ATTR_TARGET_NOTCONVERTED:
		case ATTR_CONVERTED:
		case ATTR_INPUT:
		default:
			MyTextOut (hDC, x, y, lpstr, cnt) ;
			break ;
		}
		if (0 <= iCursorPos && iCursorPos < cnt){
			if (iCursorPos > 0){
				MyGetTextExtentPoint (hDC, lpstr, iCursorPos, &sz) ;
				/*
				 *	�������̏ꍇ�ɂ́AGetTextExtentPoint32 �̕Ԃ��l sz ��
				 *	sz.cx	�\���̈�̉����B
				 *	sz.cy	�\���̈�̏c���B
				 *	���������邪�A�c�����̏ꍇ�ɂ́c
				 *	sz.cx	�\���̈�̏c���B(�������A�E�ɂł͂Ȃ����ɐ�߂�)
				 *	sz.cy	�\���̈�̉����B
				 *	�� cx, cy �̉��߂��t�ɂȂ�B����́AlfEscapement == 2700
				 *	�̉e���ł���B
				 */
				if (!fVert){
					invRect.left	= x + sz.cx ;
					invRect.right	= x + sz.cx + UI_CURSORWIDTH ;
					invRect.top		= y ;
					invRect.bottom	= y + sz.cy ;
				} else {
					invRect.left	= x ;
					invRect.right	= x - sz.cy ;
					invRect.top		= y + sz.cx ;
					invRect.bottom	= y + sz.cx + UI_CURSORWIDTH ;
				}
				MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
			} else {
				MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
				if (!fVert){
					invRect.left	= x ;
					invRect.right	= x + UI_CURSORWIDTH ;
					invRect.top		= y ;
					invRect.bottom	= y + sz.cy ;
				} else {
					invRect.left	= x ;
					invRect.right	= x - sz.cy ;
					invRect.top		= y ;
					invRect.bottom	= y + UI_CURSORWIDTH ;
				}
			}
			InvertRect (hDC, &invRect) ;
		} else {
			MyGetTextExtentPoint (hDC, lpstr, cnt, &sz) ;
		}
		lpstr		+= cnt ;
		iCursorPos	-= cnt ;
		num			-= cnt ;
		if (!fVert){
			x += sz.cx ;
		} else {
			y += sz.cx ;
		}
	}
	/* �J�[�\����\������ׂ����ۂ��B*/
	if (iCursorPos == 0){
		if (!fVert){
			invRect.left	= x - UI_CURSORWIDTH ;
			invRect.right	= x ;
			invRect.top		= y ;
			invRect.bottom	= y + sz.cy ;
		} else {
			invRect.left	= x ;
			invRect.right	= x - sz.cy ;
			invRect.top		= y - UI_CURSORWIDTH ;
			invRect.bottom	= y ;
		}
		InvertRect (hDC, &invRect) ;
	}
	return ;
}

void	PASCAL	PaintUiCompWindow (HWND hCompWnd, HDC hDC, HFONT hFont, LPINPUTCONTEXT lpIMC, LPCOMPOSITIONSTRING lpCompStr, LONG lstart, LONG num)
{
	LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR)lpCompStr ;
	LPMYSTR		lpstr ;
	LPBYTE		lpattr ;
	BOOL		fVert = FALSE ;
	int			iCursorPos ;
	HDC			hPDC ;
	RECT		rc ;

	if (lpCompStr->dwCompStrLen <= 0)
		return ;

	if (hFont)
		fVert = (lpIMC->lfFont.A.lfEscapement == 2700) ;

	SetBkMode (hDC, TRANSPARENT) ;

	lpstr	= GETLPCOMPSTR (lpCompStr) ;
	lpattr	= GETLPCOMPATTR (lpCompStr) ;

	if (lpIMC->cfCompForm.dwStyle){
		/* 
		 * �eWindow �̔w�i�F�����o���B
		 * �eWindow �̔w�i�F = Composition Window �̔w�i�F�B
		 */
		hPDC = GetDC (GetParent (hCompWnd)) ;
		SetBkColor (hDC, GetBkColor(hPDC)) ;
		SetBkMode (hDC, OPAQUE) ;

		if (!num && (DWORD)lstart == lpCompStr->dwCursorPos && lpMyCompStr->skkStr [0].cur_exist){
			GetClientRect (hCompWnd, &rc) ;
			MoveToEx (hDC, rc.left, rc.top, NULL) ;
			LineTo   (hDC, rc.left, rc.bottom) ;
		} else {
			if (!num || ((lstart + num) > Mylstrlen(lpstr))){
				ReleaseDC (GetParent (hCompWnd), hPDC) ;
				return ;
			}
			lpstr		+= lstart ;
			lpattr		+= lstart ;
			iCursorPos	= (lpMyCompStr->skkStr [0].cur_exist)? lpCompStr->dwCursorPos - lstart : -1 ;
			DrawTextOneLine (hCompWnd, hDC, lpstr, lpattr, num, iCursorPos, fVert) ;
		}
		ReleaseDC (GetParent (hCompWnd), hPDC) ;
	} else {
		num			= Mylstrlen (lpstr) ;
		iCursorPos	= (lpMyCompStr->skkStr [0].cur_exist)? lpCompStr->dwCursorPos : -1 ;
		DrawTextOneLine (hCompWnd, hDC, lpstr, lpattr, num, iCursorPos, fVert) ;
	}
	return ;
}

void	PASCAL	PaintCompWindowSub (HWND hCompWnd, HDC hDC, HFONT hFont, LPINPUTCONTEXT lpIMC, LPCOMPOSITIONSTRING lpCompStr)
{
	LONG		lstart ;
	LONG		num ;
	lstart		= (long)GetWindowLong (hCompWnd, FIGWL_COMPSTARTSTR) ;
	num			= (long)GetWindowLong (hCompWnd, FIGWL_COMPSTARTNUM) ;
	PaintUiCompWindow (hCompWnd, hDC, hFont, lpIMC, lpCompStr, lstart, num) ;
	return ;
}

void	PASCAL	PaintCompWindow (HWND hCompWnd)
{
	PAINTSTRUCT			ps ;
	HIMC				hIMC ;
	LPINPUTCONTEXT 		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	HDC					hDC ;
	RECT				rc ;
	HFONT				hFont		= (HFONT)NULL ;
	HFONT				hOldFont	= (HFONT)NULL ;
	HWND				hSvrWnd ;

	hDC	= BeginPaint (hCompWnd, &ps) ;

	if (hFont = (HFONT)GetWindowLong (hCompWnd, FIGWL_FONT))
		hOldFont = SelectObject (hDC, hFont) ;

	hSvrWnd = (HWND)GetWindowLong (hCompWnd, FIGWL_SVRWND) ;
	hIMC	= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;
	if (hIMC){
		lpIMC		= ImmLockIMC (hIMC) ;
		lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpCompStr){
			if (lpCompStr->dwSize > sizeof(COMPOSITIONSTRING)){
				PaintCompWindowSub (hCompWnd, hDC, hFont, lpIMC, lpCompStr) ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	if (hFont && hOldFont)
		SelectObject (hDC, hOldFont) ;
	EndPaint (hCompWnd, &ps) ;
	return ;
}

void PASCAL HideCompWindow (LPUIEXTRA lpUIExtra)
{
	int		i ;
	RECT	rc ;

	if (IsWindow(lpUIExtra->uiDefComp.hWnd)){
		if (!lpUIExtra->dwCompStyle)
			GetWindowRect(lpUIExtra->uiDefComp.hWnd,(LPRECT)&rc);

		ShowWindow(lpUIExtra->uiDefComp.hWnd, SW_HIDE);
		lpUIExtra->uiDefComp.bShow = FALSE;
	}
	for (i = 0 ; i < MAXCOMPWND ; i++){
		if (IsWindow (lpUIExtra->uiComp[i].hWnd)){
			ShowWindow(lpUIExtra->uiComp[i].hWnd, SW_HIDE) ;
			lpUIExtra->uiComp[i].bShow	= FALSE ;
		}
	}
	return ;
}

void	PASCAL	SetFontCompWindow (LPUIEXTRA lpUIExtra)
{
	int i ;
	for (i = 0 ; i < MAXCOMPWND ; i++)
		if (IsWindow (lpUIExtra->uiComp[i].hWnd))
			SetWindowLong (lpUIExtra->uiComp[i].hWnd, FIGWL_FONT, (DWORD)lpUIExtra->hFont) ;
	return ;
}

