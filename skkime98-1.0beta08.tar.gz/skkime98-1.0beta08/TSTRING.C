/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * tstring.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"
#include "unicode.h"

/*
 *
 *	lmemset ()
 *
 */
void	PASCAL	lmemset (LPSTR lp, BYTE b, UINT cnt)
{
	register UINT	i ;
	register BYTE	bt = b ;
	for (i = 0 ; i < cnt ; i++)
		*lp ++ = bt;
	return ;
}

void	PASCAL	Myltoa (LPMYSTR lp, long lValue)
{
	long	lMaxDigit, lDigit ;
	long	ll ;
	if (lValue < 0){
		*lp	++	= MYTEXT ('-') ;
		lValue	= lValue * (-1) ;
	}
	if (lValue != 0){
		ll	= lValue ;
		for (lMaxDigit = 0 ; ll != 0 ; lMaxDigit ++)
			ll	= ll / 10 ;
		for (lDigit = 0 ; lDigit < lMaxDigit ; lDigit ++){
			lp [lMaxDigit - lDigit - 1]	= MYTEXT ('0') + lValue % 10 ;
			lValue						= lValue / 10 ;
		}
		lp [lMaxDigit] = MYTEXT ('\0') ;
	} else {
		*lp	++ = MYTEXT ('0') ;
		*lp	++ = MYTEXT ('\0') ;
	}
	return ;
}

void	PASCAL	Myltoax (LPMYSTR lp, long lValue)
{
	int	iDigit ;
	if (!lp)
		return ;
	iDigit	= (lValue >> 28) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 24) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 20) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 16) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >> 12) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >>  8) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >>  4) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	iDigit	= (lValue >>  0) & 0x0F ;
	*lp ++	= ((iDigit >= 10)? MYTEXT ('A') :  MYTEXT ('0')) + iDigit ;
	*lp		= MYTEXT ('\0') ;
	return ;
}

long	PASCAL	Myatol (LPMYSTR lpString)
{
	long	lValue ;
	long	lSign ;

	lValue	= 0 ;
	if (!lpString || !*lpString)
		return	lValue ;
	if (*lpString == MYTEXT ('+')){
		lSign	= 1 ;
		lpString	++ ;
	} else if (*lpString == MYTEXT ('-')){
		lSign	= -1 ;
		lpString	++ ;
	} else {
		lSign	= 1 ;
	}
	while (*lpString && MYTEXT ('0') <= *lpString && *lpString <= MYTEXT ('9')){
		lValue	= lValue * 10 + (*lpString - MYTEXT ('0')) ;
		lpString	++ ;
	}
	return	lSign * lValue ;
}

LPMYSTR	PASCAL	Myctime (LPSYSTEMTIME lpsystime)
{
	static	MYCHAR	ctimebuf [25] ;
	static	LPMYSTR	ctimeWeekTbl []	= {
		MYTEXT ("Sun"),	MYTEXT ("Mon"),	MYTEXT ("Tue"),	MYTEXT ("Wed"),
		MYTEXT ("Thr"),	MYTEXT ("Fri"),	MYTEXT ("Sat"),
	} ;
	static	LPMYSTR	ctimeMonthTbl []	= {
		MYTEXT ("Jan"),	MYTEXT ("Feb"),	MYTEXT ("Mar"),	MYTEXT ("Apr"),
		MYTEXT ("May"),	MYTEXT ("Jun"),	MYTEXT ("Jul"),	MYTEXT ("Aug"),
		MYTEXT ("Sep"),	MYTEXT ("Oct"),	MYTEXT ("Nov"),	MYTEXT ("Dec"),
	} ;
	ctimebuf [0]	= MYTEXT ('\0') ;
	Mylstrcat (ctimebuf, ctimeWeekTbl [lpsystime->wDayOfWeek]) ;
	Mylstrcat (ctimebuf, MYTEXT (" ")) ;
	Mylstrcat (ctimebuf, ctimeMonthTbl [lpsystime->wMonth - 1]) ;
	Mylstrcat (ctimebuf, MYTEXT (" ")) ;
	ctimebuf [8]	= (lpsystime->wDay / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [9]	= lpsystime->wDay % 10 + MYTEXT ('0') ;
	ctimebuf [10]	= MYTEXT (' ') ;
	ctimebuf [11]	= (lpsystime->wHour / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [12]	= lpsystime->wHour % 10 + MYTEXT ('0') ;
	ctimebuf [13]	= MYTEXT (':') ;
	ctimebuf [14]	= (lpsystime->wMinute / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [15]	= lpsystime->wMinute % 10 + MYTEXT ('0') ;
	ctimebuf [16]	= MYTEXT (':') ;
	ctimebuf [17]	= (lpsystime->wSecond / 10) % 10 + MYTEXT ('0') ;
	ctimebuf [18]	= lpsystime->wSecond % 10 + MYTEXT ('0') ;
	ctimebuf [19]	= MYTEXT (' ') ;
	ctimebuf [20]	= (lpsystime->wYear / 1000) % 10 + MYTEXT ('0') ;
	ctimebuf [21]	= (lpsystime->wYear /  100) % 10 + MYTEXT ('0') ;
	ctimebuf [22]	= (lpsystime->wYear /   10) % 10 + MYTEXT ('0') ;
	ctimebuf [23]	=  lpsystime->wYear         % 10 + MYTEXT ('0') ;
	ctimebuf [24]	= MYTEXT ('\0') ;
	return	(LPMYSTR)ctimebuf ;
}

#ifdef SKKIME98M
int	PASCAL	MylstrcmpW (LPCWSTR lp0, LPCWSTR lp1)
{
	while(*lp0 && *lp1 && (*lp0 == *lp1)) {
		lp0++;
		lp1++;
	}
	return (*lp0 - *lp1);
}

int PASCAL MylstrncmpW (LPCWSTR lp0, LPCWSTR lp1, int iNum)
{
	while(iNum > 0 && *lp0 && *lp1 && (*lp0 == *lp1)){
		lp0 ++ ;
		lp1 ++ ;
		iNum -- ;
	}
	return (iNum > 0)? (*lp0 - *lp1) : 0 ;
}

int	PASCAL	MylstrcpyW (LPWSTR lp0, LPCWSTR lp1)
{
	int n	= 0 ;

	while(*lp1){
		*lp0	= *lp1 ;
		lp0 ++ ;
		lp1 ++ ;
		n ++ ;
	}
	*lp0	= *lp1 ;
	return	n ;
}

int	PASCAL	MylstrncpyW (LPWSTR lp0, LPCWSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

int	PASCAL	MylstrcatW (LPWSTR lp0, LPCWSTR lp1)
{
	int n	= 0 ;
	while (*lp0)
		lp0 ++ ;
	while(*lp1){
		*lp0	= *lp1 ;
		lp0 ++ ;
		lp1 ++ ;
		n ++ ;
	}
	*lp0	= *lp1 ;
	return	n ;
}

int	PASCAL	MylstrncatW (LPWSTR lp0, LPCWSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (*lp0)
		lp0	++ ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

LPWSTR PASCAL MyCharPrevW(LPWSTR lpStart, LPWSTR lpCur)
{
	LPWSTR lpRet = lpStart;
	if (lpCur > lpStart)
		lpRet = lpCur - 1;

	return lpRet;
}

LPWSTR	PASCAL MyCharNextW(LPWSTR lp)
{
	return lp++;
}

LPWSTR	PASCAL MylstrcpynW(LPWSTR lp0, LPWSTR lp1, int nCount)
{
	int	n ;
	for (n = 0 ; *lp1 && n < nCount - 1; *lp0++ = *lp1++, n++)
		;
	*lp0 = L'\0' ;
	return	lp0 ;
}

/*
 *	���������R�[�h (UNICODE) ����SHIFTJIS �����R�[�h�ɕϊ�����֐��B
 *(����)
 *	lpDest		�ϊ����ʂ��i�[����o�b�t�@�B
 *	iDestSize	�ϊ����ʂ��i�[����o�b�t�@�̑傫���B
 *	lpSrc		�ϊ������w���|�C���^�B
 *	iSrcSize	�ϊ����̒����B(NUL �����ŏI�[����邩�A���̒��������ϊ�����ΏI��)
 */
int	PASCAL	MystrToShiftJis (LPTSTR lpDest, int iDestSize, LPCMYSTR lpSrc, int iSrcSize)
{
	BYTE			bCodeMap ;
	unsigned char	buf [4] ;
	int				iCopy ;
	int				iDestSizeBackup ;
	unsigned short	sCode ;
	unsigned short	c1, c2 ;
	iDestSizeBackup	= iDestSize ;
	while (*lpSrc && iSrcSize > 0 && iDestSize > 0){
		bCodeMap	= GetOriginalCode (&sCode, *lpSrc) ;
		switch (bCodeMap){
		case MYCODEMAP_JISX0208:
			c1		= (sCode >> 8) & 0x00FF ;
			c2		= (sCode     ) & 0x00FF ;
			c1		= ((c1 - 0x7F) >> 1) + 0x70 ;
			buf [0]	= (c1 >= 0xA0)? c1 + 0x40 : c1 ;
			c2		= c2 - (sCode & 0x0100)? 0x61 : 0x03 ;
			buf [1]	= (c2 >= 0x7F)? c2 + 1 : c2 ;
			iCopy	= 2 ;
			break ;
		case MYCODEMAP_JISX0201:
		case MYCODEMAP_ASCII:
			buf [0]	= (sCode     ) & 0x00FF ;
			iCopy	= 1 ;
			break ;
		case MYCODEMAP_JISX0212:
		default:
			iCopy	= 0 ;
			break ;
		}
		if (iCopy > 0){
			if (iDestSize < iCopy)
				break ;
			memcpy (lpDest, buf, sizeof (char) * iCopy) ;
			lpDest		+= iCopy ;
			iDestSize	-= iCopy ;
		}
		iSrcSize	-- ;
		lpSrc		++ ;
	}
	return	iDestSizeBackup - iDestSize ;
}

/*
 *	SHIFTJIS �����R�[�h������������R�[�h (UNICODE) �ɕϊ�����֐��B
 *(����)
 *	lpDest		�ϊ����ʂ��i�[����o�b�t�@�B
 *	iDestSize	�ϊ����ʂ��i�[����o�b�t�@�̑傫���B
 *	lpSrc		�ϊ������w���|�C���^�B
 *	iSrcSize	�ϊ����̒����B(NUL �����ŏI�[����邩�A���̒��������ϊ�����ΏI��)
 */
int	PASCAL	shiftJisToMystr (LPMYSTR lpDest, int iDestSize, LPCSTR lpSrc, int iSrcSize)
{
	unsigned short	c1, c2 ;
	int				iLeadChar ;
	int				iSizeBackup ;
	if (!lpDest || !lpSrc)
		return	0 ;
	iLeadChar	= '\0' ;
	iSizeBackup	= iDestSize ;
	while (*lpSrc && iSrcSize > 0 && iDestSize > 0){
		if (iLeadChar){
			c1	= iLeadChar ;
			c2	= *lpSrc & 0x00FF ;
			c1	= (char)((c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1) ;
			c2	= (char)(c2 -  ((c2 >= 0x80)? 0x20 : 0x1F)) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			if (iDestSize > 0){
				*lpDest ++	= UNICODE_JISX0208 (((c1 & 0xFF) << 8) | (c2 & 0xFF)) ;
				iDestSize	-- ;
			}
			iLeadChar	= 0 ;
		} else {
			if (IsDBCSLeadByte (*lpSrc)){
				iLeadChar	= *lpSrc & 0x00FF ;
			} else if (0xA1 <= (unsigned char)*lpSrc && (unsigned char)*lpSrc <= 0xDF){
				if (iDestSize > 0){
					*lpDest ++	= UNICODE_JISX0201 (*lpSrc) ;
					iDestSize	-- ;
				}
			} else {
				if (iDestSize > 0){
					*lpDest ++	= *lpSrc & 0x00FF ;
					iDestSize	-- ;
				}
			}
		}
		lpSrc		++ ;
		iSrcSize	-- ;
	}
	return	iSizeBackup - iDestSize ;
}

#else

int PASCAL MylstrncmpA (LPMYSTR lp0, LPMYSTR lp1, int iNum)
{
	while(iNum > 0 && *lp0 && *lp1 && (*lp0 == *lp1)){
		lp0 ++ ;
		lp1 ++ ;
		iNum -- ;
	}
	return (iNum > 0)? (*lp0 - *lp1) : 0 ;
}

int	PASCAL	MylstrncpyA (LPMYSTR lp0, LPMYSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

int	PASCAL	MylstrncatA (LPMYSTR lp0, LPMYSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (*lp0)
		lp0	++ ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

#endif

