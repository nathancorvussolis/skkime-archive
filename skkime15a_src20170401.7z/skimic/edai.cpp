#include "globals.h"
#include "edai.h"
#include "dai.h"

CEnumDisplayAttributeInfo::CEnumDisplayAttributeInfo ()
{
    DllAddRef () ;

    _iIndex	= 0 ;
    _cRef	= 1 ;
}

CEnumDisplayAttributeInfo::~CEnumDisplayAttributeInfo ()
{
    DllRelease () ;
}

STDAPI
CEnumDisplayAttributeInfo::QueryInterface (
	REFIID		riid,
	void**		ppvObj)
{
    if (ppvObj == NULL)
        return	E_INVALIDARG ;

    *ppvObj = NULL;

    if (IsEqualIID(riid, IID_IUnknown) ||
        IsEqualIID(riid, IID_IEnumTfDisplayAttributeInfo)) {
        *ppvObj = (IEnumTfDisplayAttributeInfo *) this ;
    }

    if (*ppvObj) {
        AddRef () ;
        return	S_OK ;
    }
    return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CEnumDisplayAttributeInfo::AddRef (void)
{
    return	++ _cRef ;
}

STDAPI_(ULONG)
CEnumDisplayAttributeInfo::Release (void)
{
    LONG	cr = --_cRef ;

    assert (_cRef >= 0) ;

    if (_cRef == 0) {
        delete	this ;
    }
    return	cr ;
}

STDAPI
CEnumDisplayAttributeInfo::Clone (
	IEnumTfDisplayAttributeInfo**	ppEnum)
{
    CEnumDisplayAttributeInfo*	pClone ;

    if (ppEnum == NULL)
        return	E_INVALIDARG ;

    *ppEnum	= NULL ;

    if ((pClone = new CEnumDisplayAttributeInfo) == NULL)
        return	E_OUTOFMEMORY ;

    // the clone should match this object's state
    pClone->_iIndex	= _iIndex ;
    *ppEnum	= pClone ;
    return S_OK;
}

STDAPI
CEnumDisplayAttributeInfo::Next (
	ULONG						ulCount,
	ITfDisplayAttributeInfo**	rgInfo,
	ULONG*						pcFetched)
{
	ITfDisplayAttributeInfo*	pDisplayAttributeInfo	= NULL ;
    ULONG	cFetched ;

	cFetched	= 0 ;
    if (ulCount == 0)
        return	S_OK ;

	while (cFetched < ulCount) {
		if (_iIndex > 1)
			break ;

		if (_iIndex == 0) {
			pDisplayAttributeInfo	= new CDisplayAttributeInfoInput () ;
			if (pDisplayAttributeInfo == NULL)
				return	E_OUTOFMEMORY ;
			DEBUGPRINTF ((TEXT ("CDisplayAttributeInfoInput was created.\n"))) ;
		} else if (_iIndex == 1) {
			pDisplayAttributeInfo	= new CDisplayAttributeInfoConverted () ;
			if (pDisplayAttributeInfo == NULL)
				return	E_OUTOFMEMORY ;
			DEBUGPRINTF ((TEXT ("CDisplayAttributeInfoConverted was created.\n"))) ;
		}
		*rgInfo 	++ = pDisplayAttributeInfo ;
		cFetched	++ ;
		_iIndex		++ ;
	}
	if (pcFetched != NULL)
		*pcFetched	= cFetched ;

    return (cFetched == ulCount) ? S_OK : S_FALSE ;
}

STDAPI
CEnumDisplayAttributeInfo::Reset ()
{
    _iIndex	= 0 ;
    return	S_OK ;
}

STDAPI
CEnumDisplayAttributeInfo::Skip (
	ULONG	ulCount)
{
	if (ulCount > 0 && _iIndex == 0) {
		_iIndex	++ ;
	}
	return	S_OK ;
}

