#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "CandListUI.h"
#include "ToolTipUI.h"
#include "IME/ImeDoc.h"
#include "IME/ImeConfig.h"
#include "../common/nfunc.h"
//#include "daiparam.h"
#include "editsess.h"
#include "resource.h"

/*========================================================================
 *	structures
 */
struct MYMENUITEMINFO {
	UINT				m_fMask ;
	UINT				m_fType ;
	DWORD				m_wID ;
	LPTSTR				m_dwTypeData ;
} ;

/*========================================================================
 *	prototypes
 */
static	COLORREF	_GetImeColor		(HWND hwnd, int nColor) ;
static	HBRUSH		_GetImeLineBrush	(HWND, int, int, COLORREF*, HBITMAP*, int*) ;

/*========================================================================
 *	class CSkkImeCandidateListUIElement
 */
// {B6B9EEB4-5FCD-496f-A4A2-56B1372F70CF}
const GUID	CSkkImeCandidateListUIElement::m_guidSkkImeCandidateListUIElement = {
	0xb6b9eeb4, 0x5fcd, 0x496f, { 0xa4, 0xa2, 0x56, 0xb1, 0x37, 0x2f, 0x70, 0xcf }
};

CSkkImeCandidateListUIElement::CSkkImeCandidateListUIElement (
	CSkkImeTextService*		pTSF)
{
	m_pTSF	= pTSF ;

	m_dwElementId		= (DWORD)-1 ;
	m_bOpen				= FALSE ;
	m_bShow				= FALSE ;
	m_hWnd				= NULL ;
	m_iStyle			= IMECANDSTYLE_UNUSED ;
	m_bufAnnotation		= NULL ;
	m_iNumAnnotation	= 0 ;
	m_nTextLen			= 0 ;
	m_iCursorPos		= -1 ;
	m_bRegionSelected	= FALSE ;
	m_cRef				= 1 ;
	m_bConsole			= FALSE ;
	m_bButtonPressed	= FALSE ;
	memset (&m_ToolTipInfo, 0, sizeof (m_ToolTipInfo)) ;
	DllAddRef () ;
	return ;
}

CSkkImeCandidateListUIElement::~CSkkImeCandidateListUIElement ()
{
	DllRelease () ;
	return ;
}

HRESULT
CSkkImeCandidateListUIElement::QueryInterface (
	REFIID		riid,
	void**		ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
#if defined (__ITfCandidateListUIElementBehavior_INTERFACE_DEFINED__)
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfCandidateListUIElementBehavior)) {
		*ppvObj	= (ITfCandidateListUIElementBehavior *)this ;
	} else if (IsEqualIID (riid, IID_ITfCandidateListUIElement)) {
		*ppvObj	= (ITfCandidateListUIElement *)this ;
#else
	if (IsEqualIID (riid, IID_IUnknown)) {
		*ppvObj	= (IUnknown*) this ;
#endif
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfUIElement)) {
		*ppvObj	= (ITfUIElement *)this ;
#endif
	}
	if (*ppvObj) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

ULONG
CSkkImeCandidateListUIElement::AddRef ()
{
	m_cRef	++ ;
	return	m_cRef ;
}

ULONG
CSkkImeCandidateListUIElement::Release ()
{
	ULONG	cRef	= -- m_cRef ;

	if (cRef == 0)
		delete	this ;
	return	cRef ;
}

HRESULT
CSkkImeCandidateListUIElement::GetDescription (
	BSTR*				pbstrDescription)
{
	if (pbstrDescription == NULL)
		return	E_INVALIDARG ;
	return	E_NOTIMPL ;
}

HRESULT
CSkkImeCandidateListUIElement::GetGUID (
	GUID*				pguid)
{
	if (pguid == NULL)
		return	E_INVALIDARG ;

	memcpy (pguid, &m_guidSkkImeCandidateListUIElement, sizeof (m_guidSkkImeCandidateListUIElement)) ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::Show (BOOL bShow)
{
	if (bShow) {
		if (! m_bOpen) {
			return	E_FAIL ;	/* ... */
		}
		if (! m_bShow) {
#if !defined (not_use_for_x_mouse)
			SetWindowPos (m_hWnd, HWND_TOPMOST, 0, 0, 1, 1, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE | SWP_NOSENDCHANGING | SWP_NOREDRAW | SWP_DEFERERASE | SWP_ASYNCWINDOWPOS) ;
#endif
			ShowWindow (m_hWnd, SW_SHOWNOACTIVATE) ;
		}
		m_bShow	= bShow ;
	} else {
		if (m_bShow)
			ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShow	= FALSE ;
	}
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::IsShown (BOOL* pbShow)
{
	if (pbShow == NULL)
		return	E_INVALIDARG ;
	*pbShow	= m_bOpen && m_bShow ;	/* m_bShow �̂݁H */
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetUpdatedFlags (DWORD* pdwFlags)
{
	if (pdwFlags == NULL)
		return	E_INVALIDARG ;
	*pdwFlags		= m_dwUpdateFlags ;
	m_dwUpdateFlags	= 0 ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetDocumentMgr (ITfDocumentMgr** ppdim)
{
	if (ppdim == NULL)
		return	E_INVALIDARG ;

	return	_GetDocumentMgr (ppdim) ;
}

HRESULT
CSkkImeCandidateListUIElement::GetCount (UINT* puCount)
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL)
		return	E_FAIL ;

	if (puCount == NULL)
		return	E_INVALIDARG ;

	*puCount	= pMyCand->m_iCount ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetSelection (UINT* puIndex)
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL)
		return	E_FAIL ;

	if (puIndex == NULL)
		return	E_INVALIDARG ;
	*puIndex	= pMyCand->m_iSelection ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetString (UINT uIndex, BSTR* pstr)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	BSTR	pbResult	= NULL ;
	LPCWSTR	pwResult ;

	if (pstr == NULL)
		return	E_INVALIDARG ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL)
		return	E_FAIL ;
	if (uIndex >= pMyCand->m_iCount)
		return	E_INVALIDARG ;

	pwResult	= (LPCWSTR)pMyCand->m_vbufCandidate.pGetBuffer () + *(pMyCand->m_vbufCandidateIndex.pGetBuffer () + uIndex) ;
	*pstr		= NULL ;
	if ((pbResult = SysAllocString (pwResult)) == NULL)
		return	E_OUTOFMEMORY ;

	*pstr	= pbResult ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::GetPageIndex (UINT* pIndex, UINT uSize, UINT* puPageCnt)
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || ! pMyCand->bIsEnabledp ())
		return	E_FAIL ;

	/* Set number of pages */
	if (puPageCnt != NULL)
		*puPageCnt	= pMyCand->m_vbufPageIndex.iGetUsage () ;

	/* Set an array of the indexes that each page starts from. */
	if (pIndex != NULL) {
		const UINT*	puPageIndex ;
		UINT		iMaxPage, i ;

		puPageIndex	= pMyCand->m_vbufPageIndex.pGetBuffer () ;
		iMaxPage	= pMyCand->m_vbufPageIndex.iGetUsage () ;
		for (i = 0 ; i < uSize && i < iMaxPage ; i ++) {
			pIndex [i]	= puPageIndex [i] ;
		}
	}
	return	S_OK ;
}

/*	PageIndex �̐ݒ�c���B
 */
HRESULT
CSkkImeCandidateListUIElement::SetPageIndex (UINT* pIndex, UINT uPageCnt)
{
	return	E_NOTIMPL ;
	UNREFERENCED_PARAMETER (pIndex) ;
	UNREFERENCED_PARAMETER (uPageCnt) ;
}

/*	����́cSetPageIndex/GetPageIndex �ō��ꂽ PageStart Index[] �̉�������
 *	�Ԃ��̂��c�B
 */
HRESULT
CSkkImeCandidateListUIElement::GetCurrentPage (UINT* pPage)
{
	const IMECANDIDATES*	pMyCand ;
	CImeDoc*				pDoc ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;
	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || ! pMyCand->bIsEnabledp ())
		return	E_FAIL ;
	if (pPage == NULL)
		return	E_INVALIDARG ;
	*pPage	= pMyCand->m_iCurrentPage ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::SetSelection (UINT nIndex)
{
	return	E_NOTIMPL ;
	UNREFERENCED_PARAMETER (nIndex) ;
}

HRESULT
CSkkImeCandidateListUIElement::Finalize ()
{
	/*	current selection �Ŋm�肷��B-> candidate-list �����Bminibuffer-text ����
	 *	�������H
	 */
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;

	if (! m_bOpen)
		return	E_FAIL ;
	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;

	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || ! pMyCand->bIsEnabledp ()) {
		if (m_bShow) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShow	= FALSE ;
		}
		m_pTSF->_EndCandidateListUI () ;
		m_bOpen	= FALSE ;
		return	S_OK ;
	}
	switch (pMyCand->m_iStyle) {
	case	IMECANDSTYLE_READ:
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		return	_SendCommandToContext ((WPARAM) NFUNC_IME_FINALIZE_CANDIDATELIST, (LPARAM) 0) ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
	default:
		return	_SendCommandToContext ((WPARAM) NFUNC_EXIT_RECURSIVE_EDIT, (LPARAM) 0) ;
	}
}

HRESULT
CSkkImeCandidateListUIElement::Abort ()
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;

	if (! m_bOpen)
		return	E_FAIL ;

	if (FAILED (_GetDocument (&pDoc)))
		return	E_FAIL ;

	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || ! pMyCand->bIsEnabledp ()) {
		if (m_bShow) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShow	= FALSE ;
		}
		m_pTSF->_EndCandidateListUI () ;
		m_bOpen	= FALSE ;
		return	S_OK ;
	}
	switch (pMyCand->m_iStyle) {
	case	IMECANDSTYLE_READ:
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		return	_SendCommandToContext ((WPARAM)NFUNC_IME_ABORT_CANDIDATELIST, (LPARAM) 0) ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
	default:
		return	_SendCommandToContext ((WPARAM) NFUNC_ABORT_RECURSIVE_EDIT, (LPARAM) 0) ;
	}
}


/*========================================================================
 *	library internal public methos
 */
TCHAR	CSkkImeCandidateListUIElement::m_szWndClass []	= TEXT ("SkkImeTextService CandidateListUI Wnd Class") ;

BOOL CSkkImeCandidateListUIElement::_Register()
{
	WNDCLASS wc;
	memset(&wc, 0, sizeof(wc));

#ifdef WINDOW_CLASS_AUX
	// SKKFEP
#endif	// WINDOW_CLASS_AUX
	wc.lpfnWndProc = CSkkImeCandidateListUIElement::_WndProc;
	wc.hInstance = g_hInst;
	wc.lpszClassName = CSkkImeCandidateListUIElement::m_szWndClass;

	if (::RegisterClass(&wc) == 0) {
		DWORD dwError = ::GetLastError();
		if (dwError != ERROR_CLASS_ALREADY_EXISTS) {
			DEBUGPRINTF((TEXT("CSkkImeCandidateListUIElement::_Register(0x%lx) failed.\n"), dwError));
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CSkkImeCandidateListUIElement::_Init(BOOL bConsole)
{
	m_bufAnnotation = new TEXTREGION[MAX_ANNOTATION];
	if (m_bufAnnotation == NULL)
		return FALSE;

	m_bConsole = bConsole;
	m_bButtonPressed = FALSE;
	memset(&m_ToolTipInfo, 0, sizeof(m_ToolTipInfo));
	return TRUE;
}

void CSkkImeCandidateListUIElement::_Uninit()
{
	if (m_bufAnnotation) {
		delete[] m_bufAnnotation;
		m_bufAnnotation = NULL;
	}

	_Close();
}

BOOL
CSkkImeCandidateListUIElement::_Open (
	DWORD		dwElementId,
	BOOL		bShow)
{
	if (m_bOpen)
		return	FALSE ;

	if (m_bConsole == FALSE && m_hWnd == NULL) {
		// CandidateList�����쐬
#ifdef WINDOW_CLASS_AUX
		_Register();
#endif	// WINDOW_CLASS_AUX
#ifdef MICROSOFT_METRO
		HWND hParent = ::GetFocus();
#else	// MICROSOFT_METRO
		HWND hParent = NULL;
#endif	// MICROSOFT_METRO
		m_hWnd = ::CreateWindowEx(
			WS_EX_DLGMODALFRAME | WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
			m_szWndClass,
			TEXT("SkkImeTextService CandidateListUI Wnd"),
			WS_DISABLED | WS_POPUP,
			0, 0, 100, 32, hParent, NULL, g_hInst, this);
		if (m_hWnd == NULL || !::IsWindow(m_hWnd)) {
			DEBUGPRINTF((TEXT("CSkkImeCandidateListUIElement::_Open() failed.\n")));
			return FALSE;
		}
		if (bShow == FALSE)
			::ShowWindow(m_hWnd, SW_HIDE);
	}

	m_dwElementId	= dwElementId ;
	m_bShow			= bShow ;
	m_bOpen			= TRUE ;

	if (bShow) {
		if (m_hWnd == NULL || ! IsWindow (m_hWnd))
			return	FALSE ;
#if !defined (not_use_for_x_mouse)
		SetWindowPos (m_hWnd, HWND_TOPMOST, 0, 0, 1, 1, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE | SWP_NOSENDCHANGING | SWP_NOREDRAW | SWP_DEFERERASE | SWP_ASYNCWINDOWPOS) ;
#endif
		_UpdateText () ;
		ShowWindow (m_hWnd, SW_SHOWNOACTIVATE) ;
	}
	return	TRUE ;
}

void CSkkImeCandidateListUIElement::_Close()
{
	if (m_hWnd) {
		::DestroyWindow(m_hWnd);
		m_hWnd = NULL;
	}
	m_bOpen = FALSE;
	m_bShow = FALSE;
}

BOOL
CSkkImeCandidateListUIElement::_Update ()
{
	/*
	 *	TF_CLUIE_DOCUMENTMGR	The target document manager was changed.
	 *	TF_CLUIE_COUNT			The count of the candidate string was changed.
	 *	TF_CLUIE_SELECTION		The selection of the candidate was changed.
	 *	TF_CLUIE_STRING			Some strings in the list were changed.
	 *	TF_CLUIE_PAGEINDEX		The current page index or some page index was changed.
	 *	TF_CLUIE_CURRENTPAGE	The page was changed.
	 */
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	DWORD	dwUpdateFlags ;

	if (FAILED (_GetDocument (&pDoc)))
		return	FALSE ;

	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || ! pMyCand->bIsEnabledp ()) {
		m_nTextLen			= 0 ;
		m_iNumAnnotation	= 0 ;
		return	FALSE ;
	}

#if defined (__ITfCandidateListUIElement_INTERFACE_DEFINED__)
	dwUpdateFlags	= 0 ;
	if (pMyCand->m_dwUpdate & IMECANDUPDATE_SELECTION) {
		dwUpdateFlags	|= TF_CLUIE_SELECTION ;
	}
	if (pMyCand->m_dwUpdate & IMECANDUPDATE_CURRENT_PAGE) {
		dwUpdateFlags	|= TF_CLUIE_CURRENTPAGE ;
	}
	if (pMyCand->m_dwUpdate & IMECANDUPDATE_COUNT) {
		dwUpdateFlags	|= TF_CLUIE_COUNT ;
	}
	if (pMyCand->m_dwUpdate & IMECANDUPDATE_STRING) {
		dwUpdateFlags	|= TF_CLUIE_STRING ;
	}
	if (pMyCand->m_dwUpdate & IMECANDUPDATE_PAGE_INDEX) {
		dwUpdateFlags	|= TF_CLUIE_PAGEINDEX ;
	}
	if (m_iStyle != pMyCand->m_iStyle || m_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		m_iStyle		= pMyCand->m_iStyle ;
		/* �����̔���͔��������c�B*/
		dwUpdateFlags	|= TF_CLUIE_STRING ;
	}
#else
	dwUpdateFlags	= pMyCand->m_dwUpdate ;
	if (m_iStyle != pMyCand->m_iStyle || m_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		m_iStyle		= pMyCand->m_iStyle ;
		/* �����̔���͔��������c�B*/
		dwUpdateFlags	|= IMECANDUPDATE_STRING ;
	}
#endif
	/* string �� update �����Ƃ�Ȃ��c�B*/
	m_dwUpdateFlags	|= dwUpdateFlags ;

	if (m_bShow && dwUpdateFlags != 0) {
		_UpdateText () ;
		InvalidateRect (m_hWnd, NULL, FALSE) ;
	}
	return	TRUE ;
}

BOOL
CSkkImeCandidateListUIElement::_IsActivep (BOOL* pbShow) const
{
	if (pbShow != NULL)
		*pbShow	= m_bShow ;

	return	m_bOpen ;
}

DWORD
CSkkImeCandidateListUIElement::_GetUIElementId () const
{
	return	m_dwElementId ;
}

BOOL
CSkkImeCandidateListUIElement::_MoveWindow (
	int				iX,
	int				iY,
	int				iWidth,
	int				iHeight)
{
	m_rcWnd.left	= iX ;
	m_rcWnd.top		= iY ;
	if (iWidth != 0)
		m_rcWnd.right	= iWidth ;
	if (iHeight != 0)
		m_rcWnd.bottom	= iHeight ;
	if (m_hWnd != NULL && IsWindow (m_hWnd))
		MoveWindow (m_hWnd, m_rcWnd.left, m_rcWnd.top, m_rcWnd.right, m_rcWnd.bottom, TRUE) ;
	return	TRUE ;
}

void
CSkkImeCandidateListUIElement::_Popup (BOOL bFocus)
{
	if (m_bOpen && m_bShow && m_hWnd != NULL && IsWindow (m_hWnd)) {
#if !defined (not_use_for_x_mouse)
		if (bFocus) {
			SetWindowPos (m_hWnd, HWND_TOPMOST, 0, 0, 1, 1, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE | SWP_NOSENDCHANGING | SWP_NOREDRAW | SWP_DEFERERASE | SWP_ASYNCWINDOWPOS) ;
		}
#endif
		ShowWindow (m_hWnd, bFocus? SW_SHOWNOACTIVATE : SW_HIDE) ;
	}
	return ;
}

/*================================================================
 *	private methods
 */
HRESULT
CSkkImeCandidateListUIElement::_GetDocumentMgr (
	ITfDocumentMgr**	ppdim)
{
	ITfThreadMgr*	pThreadMgr ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pThreadMgr	= m_pTSF->_GetThreadMgr () ;
	if (pThreadMgr == NULL)
		return	E_FAIL ;
	return	pThreadMgr->GetFocus (ppdim) ;
}

HRESULT
CSkkImeCandidateListUIElement::_GetDocument (
	CImeDoc**			ppDoc)
{
	CSkkImeMgr*	pIME ;
	CImeDoc*	pDoc ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pIME	= m_pTSF->_GetCurrentIME () ;
	if (pIME == NULL)
		return	E_FAIL ;

	pDoc	= pIME->GetDocument () ;
	if (pDoc == NULL)
		return	E_FAIL ;

	if (ppDoc != NULL)
		*ppDoc	= pDoc ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::_GetToolTipUI (
	CSkkImeToolTipUIElement**	ppToolTipUI)
{
	CSkkImeToolTipUIElement*	pToolTipUI ;

	if (m_pTSF == NULL)
		return	E_FAIL ;

	pToolTipUI	= m_pTSF->_GetToolTipUI () ;
	if (pToolTipUI == NULL)
		return	E_FAIL ;
	if (ppToolTipUI != NULL)
		*ppToolTipUI	= pToolTipUI ;
	return	S_OK ;
}

HRESULT
CSkkImeCandidateListUIElement::_SendCommandToContext (
	WPARAM			wParam,
	LPARAM			lParam)
{
	HRESULT			hr;
	ITfDocumentMgr	*pFocusDoc;

	hr	= _GetDocumentMgr (&pFocusDoc) ;
	if (SUCCEEDED (hr)) {
		ITfContext*	pContext ;

		hr	= pFocusDoc->GetTop (&pContext) ;
		if (SUCCEEDED (hr)) {
			CSkkImeMgr*	pIME	= m_pTSF->_GetCurrentIME () ;
			BOOL	fToggle, fCMode, fEaten ;

			if (pIME != NULL) {
				hr	= pIME->OnEditSession (WM_LM_COMMAND, wParam, lParam, 0, &fToggle, &fCMode, &fEaten) ;
				hr	= m_pTSF->_SyncComposition (pContext, fToggle, fCMode) ;
			}
			pContext->Release () ;
		}
		pFocusDoc->Release () ;
	}
	return	hr ;
}

void
CSkkImeCandidateListUIElement::_UpdateText ()
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	DCHAR					bufDText [1024] ;
	int						nDTextLen ;

	if (FAILED (_GetDocument (&pDoc)))
		return ;

	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || pMyCand->m_iStyle == IMECANDSTYLE_UNUSED || pMyCand->m_iCount <= 0) {
		m_nTextLen			= 0 ;
		m_iNumAnnotation	= 0 ;
		return ;
	}

	m_iNumAnnotation	= 0 ;
	switch (pMyCand->m_iStyle) {
	case	IMECANDSTYLE_READ:
		{
			m_iNumAnnotation	= (m_bufAnnotation != NULL)? MAX_ANNOTATION : 0 ;
			nDTextLen	= pDoc->iGetCandidateText (bufDText, MYARRAYSIZE (bufDText), m_bufAnnotation, &m_iNumAnnotation, pMyCand) ;

			m_nTextLen	= dcstowcs (m_wszText, MYARRAYSIZE (m_wszText), bufDText, nDTextLen) ;
			if (m_iNumAnnotation > 0) {
				TEXTREGION*	p	= m_bufAnnotation ;
				int			i ;
				for (i = 0 ; i < m_iNumAnnotation ; i ++) {
					int	iOffset	= p->m_nOffset ;
					int	iLength	= p->m_nLength ;
					if (iOffset > 0)
						p->m_nOffset	= dcstowcs (NULL, 0, bufDText, iOffset) ;
					if (iLength > 0)
						p->m_nLength	= dcstowcs (NULL, 0, bufDText + iOffset, iLength) ;
					p	++ ;
				}
			}
//			pDoc->iGetCandidateText (m_wszText, MYARRAYSIZE (m_wszText), m_bufAnnotation, &m_iNumAnnotation, pMyCand) ;
			_ConfigureAnnotation (m_bufAnnotation, m_iNumAnnotation) ;
		}
		break ;
	case	IMECANDSTYLE_CODE0:
		{
			nDTextLen	= pDoc->iGetCodeMenuJumpText (bufDText, MYARRAYSIZE (bufDText), pMyCand) ;
			m_nTextLen	= dcstowcs (m_wszText, MYARRAYSIZE (m_wszText), bufDText, nDTextLen) ;
		}
		break ;
	case	IMECANDSTYLE_CODE1:
		{
			nDTextLen	= pDoc->iGetCodeMenu1Text (bufDText, MYARRAYSIZE (bufDText), pMyCand) ;
			m_nTextLen	= dcstowcs (m_wszText, MYARRAYSIZE (m_wszText), bufDText, nDTextLen) ;
		}
		break ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
		{
			m_nTextLen	= _GetMinibufferText (m_wszText, MYARRAYSIZE (m_wszText), pMyCand) ;
		}
		break ;
	default:
		m_nTextLen	= 0 ;
		break ;
	}
	return ;
}


int
CSkkImeCandidateListUIElement::_GetMinibufferText (
	LPWSTR					pwText,
	int						iTextSize,
	const IMECANDIDATES*	pMyCand)
{
	CImeDoc*	pDoc ;
	int			nRegionDStart = -1, nRegionDEnd = -1, nDText ;
	int			iCursorDPos, iResult ;
	int			iCursorWPos = -1, nRegionStart = 0, nRegionEnd = 0 ;
	LPCDSTR		pdSText ;
	BOOL		fRegionSelected ;

	if (FAILED (_GetDocument (&pDoc)))
		return	0 ;
	if (pMyCand == NULL || pMyCand->m_iCount != 1 || pMyCand->m_iStyle != IMECANDSTYLE_MINIBUFFERTEXT)
		return	0 ;

	pdSText			= pMyCand->m_vbufCandidate.pGetBuffer () + *(pMyCand->m_vbufCandidateIndex.pGetBuffer () + 0) ;
	nDText			= dcslen (pdSText) ;

	iCursorDPos		= -1 ;
	fRegionSelected	= FALSE ;
	if (! pDoc->bGetStatusCursor (&iCursorDPos))
		iCursorDPos	= -1 ;

	if (iCursorDPos >= 0) {
		fRegionSelected	= pDoc->bGetSelectedRegion (&nRegionDStart, &nRegionDEnd) ;

		if (iCursorDPos < nDText && pdSText [iCursorDPos] == L'|') {
			LPWSTR	pwDest, pwDestLast ;
			LPCDSTR	pdSrc,	pdSrcLast ;
			int		n ;

			pwDest		= pwText ;
			pwDestLast	= pwDest + iTextSize ;
			pdSrc		= pdSText ;
			pdSrcLast	= pdSText + nDText ;
			iCursorWPos	= dcstowcs (pwDest, pwDestLast - pwDest, pdSrc, iCursorDPos) ;

			pwDest	+= iCursorWPos ;
			pdSrc	+= iCursorDPos + 1 ;
			if (pwDest < pwDestLast && pdSrc < pdSrcLast) {
				n	= dcstowcs (pwDest, pwDestLast - pwDest, pdSrc, pdSrcLast - pdSrc) ;
				pwDest	+= n ;
			}
			iResult		= pwDest - pwText ;
		} else {
			iResult		= dcstowcs (pwText, iTextSize, pdSText, nDText) ;
			iCursorWPos	= iResult ;	//?
		}
		if (fRegionSelected) {
			nRegionStart	= (0 <= nRegionDStart && nRegionDStart <= nDText)? dcstowcs (NULL, 0, pdSText, nRegionDStart) : 0 ;
			nRegionEnd		= (0 <= nRegionDStart && nRegionDStart <= nDText)? dcstowcs (NULL, 0, pdSText, nRegionDEnd) : 0 ;
		}
	} else {
		iResult		= dcstowcs (pwText, iTextSize, pdSText, nDText) ;
	}
	m_iCursorPos		= iCursorWPos ;
	m_bRegionSelected	= fRegionSelected ;
	m_iRegionStart		= nRegionStart ;
	m_iRegionEnd		= nRegionEnd ;
	return	iResult ;
}

/*================================================================
 *	Window Message Handlers
 */
LRESULT	CALLBACK
CSkkImeCandidateListUIElement::_WndProc (
	HWND			hWnd,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_CREATE:
		SetWindowLongPtr (hWnd, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCT *)lParam)->lpCreateParams) ;
		return	0L ;

	case	WM_SETCURSOR:
		{
			CSkkImeCandidateListUIElement*	pThis ;

			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnSetCursor (wParam, lParam) ;
			}
		}
		break ;

	case	WM_MOUSEMOVE:
		{
			CSkkImeCandidateListUIElement*	pThis ;

			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnMouseMove (wParam, lParam) ;
			}
		}
		break ;

	case	WM_LBUTTONDOWN:
	case	WM_RBUTTONDOWN:
		{
			CSkkImeCandidateListUIElement*	pThis ;

			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnButtonDown (uMessage, wParam, lParam) ;
			}
		}
		break ;

	case	WM_LBUTTONUP:
	case	WM_RBUTTONUP:
		{
			CSkkImeCandidateListUIElement*	pThis ;

			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnButtonUp (uMessage, wParam, lParam) ;
			}
		}
		break ;

	case	WM_TIMER:
		{
			CSkkImeCandidateListUIElement*	pThis ;

			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnTimer (wParam, lParam) ;
			}
		}
		break ;

	case	WM_PAINT:
		{
			CSkkImeCandidateListUIElement*	pThis ;
			HDC			hDC ;
			PAINTSTRUCT	ps ;

			hDC		= BeginPaint (hWnd, &ps) ;
			pThis	= reinterpret_cast <CSkkImeCandidateListUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) {
				pThis->_OnPaint (hDC) ;
			}
			EndPaint (hWnd, &ps) ;
		}
		break ;

	default:
		return	DefWindowProc (hWnd, uMessage, wParam, lParam) ;
	}
	return	0L ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnSetCursor (
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	BOOL					bMinibuffered ;

	if (FAILED (_GetDocument (&pDoc)))
		return	0L ;

	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || pMyCand->m_iStyle == IMECANDSTYLE_UNUSED)
		return	0L ;

	bMinibuffered	= (pMyCand->m_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) ;
	if (bMinibuffered) {
		switch (HIWORD (lParam)) {
		case	WM_LBUTTONDOWN:
		case	WM_RBUTTONDOWN:
			_OnButtonDown (HIWORD(lParam), 0, 0) ;
			break ;
		case	WM_LBUTTONUP:
		case	WM_RBUTTONUP:
			_OnButtonUp (HIWORD(lParam), 0, 0) ;
			break ;
		default:
			_OnMouseMove (0, 0) ;
			break ;
		}
	} else {
		/* tooltip �̏����B*/
		_HideToolTip () ;

		if (HIWORD (lParam) != WM_LBUTTONDOWN && HIWORD (lParam) != WM_RBUTTONDOWN && m_iNumAnnotation > 0) {
			CImeConfig*	pConfig	= m_pTSF->_GetIMEConfig () ;
			UINT		uHoverTime ;
			if (CImeConfig::iGetSkkShowAnnotationType (pConfig) == SHOW_ANNOTATION_IN_CANDLIST ||
				CImeConfig::iGetSkkShowAnnotationType (pConfig) == SHOW_ANNOTATION_ALWAYS) {
				if (! SystemParametersInfo (SPI_GETMOUSEHOVERTIME, 0, &uHoverTime, 0))
					uHoverTime	= SKKIME_DEFAULT_HOVERTIME ;
				SetTimer (m_hWnd, TIMEEV_SHOWANNOTATION, uHoverTime, NULL) ;
			}
		}
	}
	return	0L ;
	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnMouseMove (
	WPARAM		wParam,
	LPARAM		lParam)
{
	return	0L ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnButtonDown (
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	CImeDoc*				pDoc ;
	const IMECANDIDATES*	pMyCand ;
	POINT					pos ;

	if (FAILED (_GetDocument (&pDoc)))
		return	0L ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (m_hWnd, &pos))
		return	0L ;

	pMyCand	= pDoc->pGetStatusText () ;
	if (pMyCand != NULL && pMyCand->m_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
		int		nDummy, iCursorPos ;

		if (pDoc->bGetStatusCursor (&nDummy)) {
			/*	���������B�����A�J�[�\���̈ړ��ƃ}�[�N�̐ݒ�Ƃ����Ƃ��B
			 *	�J�[�\���ʒu�𓾂āABUTTONDOWN �𑗐M����B
			 */
			if (uMessage == WM_LBUTTONDOWN) {
				if (_GetTextPosition (&pos, &iCursorPos))
					_SendCommandToContext ((WPARAM) NFUNC_MOUSE_DRAG_REGION, (LPARAM) iCursorPos) ;
			}
			m_bButtonPressed	= TRUE ;
			SetCapture (m_hWnd) ;
		}
	}
	return	0L ;
	UNREFERENCED_PARAMETER (uMessage) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnButtonUp (
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	/*
	 * �}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 * �ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (! m_bButtonPressed)
		return	0L ;

	ReleaseCapture () ;	/* ReleaseCapture �����͕K�{�B*/
	m_bButtonPressed	= FALSE ;

	switch (uMessage) {
	case	WM_LBUTTONUP:
		{
			CImeDoc*				pDoc ;
			POINT					pos ;
			const IMECANDIDATES*	pMyCand ;

			GetCursorPos (&pos) ;
			if (! ScreenToClient (m_hWnd, &pos))
				return	0L ;

			if (FAILED (_GetDocument (&pDoc)))
				return	0L ;

			pMyCand	= pDoc->pGetStatusText () ;
			if (pMyCand != NULL && pMyCand->m_iStyle == IMECANDSTYLE_MINIBUFFERTEXT) {
				int				nDummy, iCursorPos ;

				/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
				if (pDoc->bGetStatusCursor (&nDummy)){
					if (_GetTextPosition (&pos, &iCursorPos))
						_SendCommandToContext ((WPARAM) NFUNC_MOUSE_DRAG_REGION_END, (LPARAM) iCursorPos) ;
				}
			}
		}
		break ;
	case	WM_RBUTTONUP:
		_HandleMinibufferContextMenu () ;
		break ;
	default:
		break ;
	}
	return	0L ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
CSkkImeCandidateListUIElement::_OnTimer (
	WPARAM		wParam,
	LPARAM		lParam)
{
	KillTimer (m_hWnd, wParam) ;

	if (m_iNumAnnotation > 0) {
		CImeConfig*	pConfig	= m_pTSF->_GetIMEConfig () ;
		CImeDoc*	pDoc ;

		if (FAILED (_GetDocument (&pDoc)))
			return	0L ;

		if (pDoc != NULL &&
			(CImeConfig::iGetSkkShowAnnotationType (pConfig) == SHOW_ANNOTATION_IN_CANDLIST ||
			(CImeConfig::iGetSkkShowAnnotationType (pConfig) == SHOW_ANNOTATION_ALWAYS))) {
			const IMECANDIDATES*	pMyCand	= pDoc->pGetStatusText () ;

			if (pMyCand != NULL && pMyCand->m_iStyle == IMECANDSTYLE_READ) {
				POINT		pt ;

				GetCursorPos (&pt) ;
				ScreenToClient (m_hWnd, &pt) ;
				_HitTestAnnotation (&pt) ;
			}
		}
	}
	return	0L ;
	UNREFERENCED_PARAMETER (lParam) ;
}

void
CSkkImeCandidateListUIElement::_OnPaint (
	HDC			hDC)
{
	CImeDoc*	pDoc	= NULL ;
	HFONT		hOldFont ;
	const IMECANDIDATES*	pMyCand ;
	RECT		rc ;

	if (FAILED (_GetDocument (&pDoc)))
		return ;

	pMyCand		= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || pMyCand->m_iStyle == IMECANDSTYLE_UNUSED) {
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShow	= FALSE ;
		return ;
	}

	hOldFont	= (HFONT) SelectObject (hDC, _GetDefaultFont (hDC)) ;
	GetClientRect (m_hWnd, &rc) ;
	switch (pMyCand->m_iStyle) {
	case	IMECANDSTYLE_READ:
		_PaintCandidateList (hDC, &rc) ;
		break ;
	case	IMECANDSTYLE_CODE0:
	case	IMECANDSTYLE_CODE1:
		_PaintCodeList (hDC, &rc) ;
		break ;
	case	IMECANDSTYLE_MINIBUFFERTEXT:
		_PaintMinibufferText (hDC, &rc) ;
		break ;
	default:
		break ;
	}
	SelectObject (hDC, hOldFont) ;
	return ;
}

BOOL
CSkkImeCandidateListUIElement::_PaintCandidateList (
	HDC						hDC,
	LPRECT					prcDraw)
{
	HBRUSH			hULBrush = NULL, hOldBrush = NULL ;
	HBRUSH			hBrushBg = NULL ;
	HBRUSH			hBrushFg = NULL ;
	HBITMAP			hbmUL = NULL ;
	int				nULHeight, nText ;
	COLORREF		colUL ;
	SIZE			sz ;
	const TEXTREGION*	pbufAnnot ;
	int				nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
	LPCWSTR			pwText ;
	const TEXTREGION*	pAnnot ;
	TEXTMETRIC		tm ;

	if (m_nTextLen <= 0)
		return	TRUE ;

#if defined (DEBUG) || defined (_DEBUG)
	/*	default �� System �t�H���g�ł� Unicode ��������ƕ\������Ȃ��B
	 *	���ӂ��邱�ƁB
	 */
	{
		TCHAR	buf [256] ;
		int		n ;
		n	= GetTextFace (hDC, MYARRAYSIZE (buf)-1, buf) ;
		buf [n]	= TEXT ('\0') ;
		OutputDebugString (buf) ;
	}
#endif
	hBrushBg	= (HBRUSH) CreateSolidBrush (GetBkColor (hDC)) ;
	hBrushFg	= (HBRUSH) CreateSolidBrush (GetTextColor (hDC)) ;
	hULBrush	= _GetImeLineBrush (m_hWnd, MYCOLOR_TEXTAUTO, MYLINE_THIN_DITHER, &colUL, &hbmUL, &nULHeight) ;
	if (hULBrush)
		hOldBrush	= (HBRUSH) SelectObject (hDC, hULBrush) ;

	pbufAnnot	= m_bufAnnotation ;
	GetTextMetrics (hDC, &tm) ;
	nDefaultDY	= tm.tmHeight ;

	y			= prcDraw->top ;
	pwText		= m_wszText ;
	nTextPos	= 0 ;
	nText		= m_nTextLen ;
	sz.cx		= 0 ;
	sz.cy		= 0 ;
	nDY			= nDefaultDY ;

	while (y < prcDraw->bottom && 0 < nText) {
		/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
		x			= prcDraw->left ;

		{
			int	nPrevChar ;
			nPrevChar	= 0 ;
			nChar		= 1 ;
			while (nChar <= nText) {
				int	n ;
				/*	SURROGATE PAIR �̏ꍇ�A2�Z�b�g�Ōv�Z���Ȃ���΂Ȃ�Ȃ��B*/
				if (nChar < nText && IS_SURROGATE_PAIR (pwText [nChar-1], pwText [nChar])) {
					n	= 1 ;
				} else {
					n	= 0 ;
				}
				GetTextExtentPoint32W (hDC, pwText, nChar+n, &sz) ;
				if ((x + sz.cx) > prcDraw->right)
					break ;
				nPrevChar	= nChar ;
				nChar		+= (n+1) ;
			}
			nChar	= nPrevChar ;
		}
		if (nChar <= 0)
			break ;

		/* ���̍s�ɂ� nChar �����\������B*/
		TextOutW (hDC, x, y, pwText, nChar) ;
		GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
		nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
		x	+= sz.cx ;

		/* �܂�Ԃ�������\������B*/
		if (nChar < nText) {
			POINT	rPT [3] ;
			RECT	rc ;
			HBRUSH	hOldBrush ;

			rc.left	= x ;	rc.right	= prcDraw->right ;
			rc.top	= y ;	rc.bottom	= y + nDY ;
			FillRect (hDC, &rc, hBrushBg) ;

			hOldBrush	= (HBRUSH) SelectObject (hDC, hBrushFg) ;
			rPT [0].x	= x ;					rPT [0].y	= y ;
			rPT [1].x	= prcDraw->right-1 ;	rPT [1].y	= y ;
			rPT [2].x	= prcDraw->right-1 ;	rPT [2].y	= y + nDY ;
			Polygon (hDC, rPT, 3) ;
			(void) SelectObject (hDC, hOldBrush) ;
		} else {
			RECT	rc ;
			rc.left	= x ;	rc.right	= prcDraw->right ;
			rc.top	= y ;	rc.bottom	= y + nDY ;
			FillRect (hDC, &rc, hBrushBg) ;
		}

#define	IsTextRegionCrossp(text1,ntext1,text2,ntext2)	(!((((text1)+(ntext1))<=(text2)||(text1)>=((text2)+(ntext2)))))
		for (nAnnot = 0 ; nAnnot < m_iNumAnnotation ; nAnnot ++) {
			int	nOffset, nLength ;

			pAnnot	= m_bufAnnotation + nAnnot ;
			if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
				continue ;
			nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
			nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
			if (nLength > nChar)
				nLength	= nChar ;

			if (nOffset > 0) {
				GetTextExtentPoint32W (hDC, pwText, nOffset, &sz) ;
				nAnnotX	= prcDraw->left + sz.cx ;
			} else {
				nAnnotX	= prcDraw->left ;
			}
			GetTextExtentPoint32W (hDC, pwText + nOffset, nLength, &sz) ;
			nAnnotWidth	= sz.cx ;

			if (hULBrush)
				PatBlt (hDC, nAnnotX, y + nDY - nULHeight, nAnnotWidth, nULHeight, PATCOPY) ;
		}
		pwText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		y			+= nDY ;
	}
	if (y < prcDraw->bottom) {
		RECT	rc ;
		rc.left	= prcDraw->left ;	rc.right	= prcDraw->right ;
		rc.top	= y ;				rc.bottom	= y + nDY ;
		FillRect (hDC, &rc, hBrushBg) ;
	}

	if (hULBrush) {
		(void) SelectObject (hDC, hOldBrush) ;
		DeleteObject (hULBrush) ;
	}
	if (hBrushBg)
		DeleteObject (hBrushBg) ;
	if (hBrushFg)
		DeleteObject (hBrushFg) ;
	if (hbmUL)
		DeleteObject (hbmUL) ;
	return	TRUE ;
}

BOOL
CSkkImeCandidateListUIElement::_PaintCodeList (
	HDC						hDC,
	LPRECT					prcDraw)
{
	int			nText ;
	int			nDY, nDefaultDY, x, y, nChar ;
	LPCWSTR		pwText ;
	TEXTMETRIC	tm ;
	SIZE		sz ;
	HBRUSH		hBrushBg ;

	if (m_nTextLen <= 0)
		return	TRUE ;

	GetTextMetrics (hDC, &tm) ;
	nDefaultDY	= tm.tmHeight ;
	hBrushBg	= (HBRUSH) CreateSolidBrush (GetBkColor (hDC)) ;

	y			= prcDraw->top ;
	pwText		= m_wszText ;
	nText		= m_nTextLen ;
	sz.cx	= sz.cy	= 0 ;
	while (y < prcDraw->bottom && 0 < nText) {
		/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
		x	= prcDraw->left ;
		{
			int	nPrevChar ;

			nPrevChar	= 0 ;
			nChar		= 1 ;
			while (nChar <= nText) {
				int	n ;
				/*	SURROGATE PAIR �̏ꍇ�A2�Z�b�g�Ōv�Z���Ȃ���΂Ȃ�Ȃ��B*/
				if (nChar < nText && IS_SURROGATE_PAIR (pwText [nChar-1], pwText [nChar])) {
					n	= 1 ;
				} else {
					n	= 0 ;
				}
				GetTextExtentPoint32W (hDC, pwText, nChar, &sz) ;
				if ((x + sz.cx) > prcDraw->right)
					break ;
				nPrevChar	= nChar ;
				nChar		+= (n+1) ;
			}
			nChar	= nPrevChar ;
		}
		if (nChar <= 0)
			break ;

		/* ���̍s�ɂ� nChar �����\������B*/
		TextOutW (hDC, x, y, pwText, nChar) ;
		nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
		x	+= sz.cx ;

		/* �܂�Ԃ�������\������B*/
		if (nChar < nText) {
			SIZE	szBackslash ;
			TextOutW (hDC, x, y, L"\\", 1) ;
			GetTextExtentPoint32W (hDC, L"\\", 1, &szBackslash) ;
			x	+= szBackslash.cx ;
		} else {
			RECT	rc ;
			rc.left	= x ;	rc.right	= prcDraw->right ;
			rc.top	= y ;	rc.bottom	= y + nDY ;
			FillRect (hDC, &rc, hBrushBg) ;
		}
		pwText		+= nChar ;
		nText		-= nChar ;
		y			+= nDY ;
	}
	if (y < prcDraw->bottom) {
		RECT	rc ;
		rc.left	= prcDraw->left ;	rc.right	= prcDraw->right ;
		rc.top	= y ;				rc.bottom	= y + nDefaultDY ;
		FillRect (hDC, &rc, hBrushBg) ;
	}
	if (hBrushBg)
		DeleteObject (hBrushBg) ;
	return	TRUE ;
}

BOOL
CSkkImeCandidateListUIElement::_PaintMinibufferText (
	HDC						hDC,
	LPRECT					prcDraw)
{
	CImeDoc*		pDoc ;
//	HBRUSH			hbr ;
	int				nRegionStart, nRegionEnd ;
	int				x, y, nDY, nText, nTextPos ;
	LPCWSTR			pwSText, pText ;
	int				iCursorPos ;
	BOOL			fRegionSelected ;
	TEXTMETRIC		tm ;
	BOOL			bCursorPos ;
	HBRUSH			hBrushBg ;

	if (FAILED (_GetDocument (&pDoc)))
		return	FALSE ;

	pwSText			= m_wszText ;
	iCursorPos		= m_iCursorPos ;
	fRegionSelected	= m_bRegionSelected ;
	nRegionStart	= m_bRegionSelected? m_iRegionStart : -1 ;
	nRegionEnd		= m_bRegionSelected? m_iRegionEnd   : -1 ;

	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;
	hBrushBg	= (HBRUSH) CreateSolidBrush (GetBkColor (hDC)) ;

	SetBkMode (hDC, OPAQUE) ;
	//	�F�̑���c�ǂ����悤���Bfocus ���Ă��� Window �̔w�i�F�Ȃ�ĕs�������B
//	SetBkColor (hDC, GetBkColor (hPDC)) ;
//	SetTextColor (hDC, RGB (0, 0, 0)) ;

	pText		= pwSText ;
	nText		= m_nTextLen ;
	nTextPos	= 0 ;
	y			= prcDraw->top ;
	x			= prcDraw->left ;
	bCursorPos	= FALSE ;
	while (y < prcDraw->bottom && 0 < nText) {
		int		nChar, iSX ;
		BOOL	bCRLF ;
		SIZE	sz ;

		bCRLF	= FALSE ;
		iSX		= x ;

		{
			int	nPrevChar ;

			nPrevChar	= 0 ;
			nChar		= 1 ;
			while (nChar <= nText) {
				int	n ;
				/*	SURROGATE PAIR �̏ꍇ�A2�Z�b�g�Ōv�Z���Ȃ���΂Ȃ�Ȃ��B*/
				if (nChar < nText && IS_SURROGATE_PAIR (pText [nChar-1], pText [nChar])) {
					n	= 1 ;
				} else {
					n	= 0 ;
				}
				GetTextExtentPoint32W (hDC, pText, nChar+n, &sz) ;
				if ((x + sz.cx) >= prcDraw->right) {
					bCRLF	= TRUE ;
					break ;
				}
				nPrevChar	= nChar ;
				nChar	+= (n+1) ;
			}
			nChar	= nPrevChar ;
		}
		if (nChar <= 0)
			break ;

		if (fRegionSelected && !(nRegionEnd <= nTextPos || (nTextPos + nChar) <= nRegionStart)) {
			int	nStart, nEnd ;

			if (nTextPos < nRegionStart) {
				TextOutW (hDC, x, y, pText, nRegionStart - nTextPos) ;
				GetTextExtentPoint32W (hDC, pText, nRegionStart - nTextPos, &sz) ;
				x	+= sz.cx ;
			}
			nStart	= (nRegionStart < nTextPos)? nTextPos : nRegionStart ;
			nEnd	= (nRegionEnd   >= (nTextPos + nChar))? (nTextPos + nChar) : nRegionEnd ;
			if (nStart < nEnd) {
				COLORREF	colBack	= GetBkColor (hDC) ;
				SetBkColor (hDC, RGB (192, 192, 224)) ;
				TextOutW (hDC, x, prcDraw->top, pwSText + nStart, nEnd - nStart) ;
				GetTextExtentPoint32W (hDC, pwSText + nStart, nEnd - nStart, &sz) ;
				SetBkColor (hDC, colBack) ;
				x	+= sz.cx ;
			}
			if (nEnd < (nTextPos + nChar)) {
				TextOutW (hDC, x, prcDraw->top, pwSText + nEnd, nTextPos + nChar - nEnd) ;
				GetTextExtentPoint32W (hDC, pwSText + nEnd, nTextPos + nChar - nEnd, &sz) ;
				x	+= sz.cx ;
			}
		} else {
			/* �e�L�X�g��\������B*/
			TextOutW (hDC, x, y, pText, nChar) ;
			GetTextExtentPoint32W (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
		}

		if (bCRLF) {
			/*	�܂�Ԃ��L����\������B*/
			TextOutW (hDC, x, y, L"\\", 1) ;
			GetTextExtentPoint32W (hDC, L"\\", 1, &sz) ;
			x	+= sz.cx ;
		}
		if (bCRLF || nChar == nText)
			PatBlt (hDC, x, y, prcDraw->right - x, nDY, PATCOPY) ;

		/* �K�v�Ȃ�J�[�\����\������B*/
		if (nTextPos <= iCursorPos && iCursorPos <= (nTextPos + nChar)) {
			RECT			invRect ;

			if (iCursorPos > nTextPos) {
				GetTextExtentPoint32W (hDC, pText, iCursorPos - nTextPos, &sz) ;
				invRect.left	= iSX + sz.cx ;
				invRect.right	= iSX + sz.cx + UI_CURSORWIDTH ;
			} else {
				invRect.left	= iSX ;
				invRect.right	= iSX + UI_CURSORWIDTH ;
			}
			invRect.top		= y ;
			invRect.bottom	= y + nDY ;
			InvertRect (hDC, &invRect) ;
		}
		pText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		if (bCRLF) {
			y		+= nDY ;
			x		= prcDraw->left ;
		}
	}
	if (y < prcDraw->bottom) {
		RECT	rc ;
		rc.left	= x ;		rc.right	= prcDraw->right ;
		rc.top	= y + nDY ;	rc.bottom	= prcDraw->bottom ;
		if (rc.top < rc.bottom)
			FillRect (hDC, &rc, hBrushBg) ;
	}
	return	TRUE ;
}


BOOL
CSkkImeCandidateListUIElement::_GetTextPosition (
	const POINT*			pPoint,
	int*					piCursorPos)
{
	HDC			hDC ;
	LPCWSTR		pText ;
	int			nText, iCursorPos, nDY, y ;
	RECT		rc ;
	TEXTMETRIC	tm ;

	pText		= m_wszText ;
	nText		= m_nTextLen ;
	hDC			= GetDC (m_hWnd) ;
	if (!hDC)
		return	FALSE ;

	GetClientRect (m_hWnd, &rc) ;
	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	iCursorPos	= 0 ;
	y			= 0 ;
	while (y < pPoint->y) {
		int		nChar ;
		SIZE	sz ;

		{
			int	nPrevChar ;

			nPrevChar	= 0 ;
			nChar		= 1 ;
			while (nChar <= nText) {
				int	n ;
				/*	SURROGATE PAIR �̏ꍇ�A2�Z�b�g�Ōv�Z���Ȃ���΂Ȃ�Ȃ��B*/
				if (nChar < nText && IS_SURROGATE_PAIR (pText [nChar-1], pText [nChar])) {
					n	= 1 ;
				} else {
					n	= 0 ;
				}
				GetTextExtentPoint32W (hDC, pText, nChar+n, &sz) ;
				if (pPoint->x < sz.cx && y <= pPoint->y && pPoint->y < (y + sz.cy)) {
					/* found */
					iCursorPos	= (pText + nPrevChar) - m_wszText ;
					goto	exit_loop ;
				}
				if (sz.cx >= rc.right) {
					break ;
				}
				nPrevChar	= nChar ;
				nChar		+= (n+1) ;
			}
			nChar	= nPrevChar ;
		}
		if (nChar <= 0)
			break ;
		y		+= nDY ;
		pText	+= nChar ;
		nText	-= nChar ;
	}
	iCursorPos	= pText - m_wszText ;
exit_loop:
	ReleaseDC (m_hWnd, hDC) ;
	if (piCursorPos != NULL)
		*piCursorPos	= iCursorPos ;
	return	TRUE ;
}

void
CSkkImeCandidateListUIElement::_HitTestAnnotation (
	const POINT*	pPT)
{
	CSkkImeToolTipUIElement*	pToolTipUI ;
	int		nTool ;

	if (FAILED (_GetToolTipUI (&pToolTipUI)))
		return ;
	for (nTool = 0 ; nTool < m_ToolTipInfo.m_nCount ; nTool ++) {
		if (m_ToolTipInfo.m_rrcHitArea [nTool].left <= pPT->x && pPT->x < m_ToolTipInfo.m_rrcHitArea [nTool].right &&
			m_ToolTipInfo.m_rrcHitArea [nTool].top  <= pPT->y && pPT->y < m_ToolTipInfo.m_rrcHitArea [nTool].bottom) {
			POINT	pt ;
			RECT	rc ;
			BOOL	bShow ;

			/* hit */
			pt.x	= pPT->x ;
			pt.y	= pPT->y ;
			ClientToScreen (m_hWnd, &pt) ;
			m_ToolTipInfo.m_ptLastPos.x	= pt.x ;
			m_ToolTipInfo.m_ptLastPos.y	= pt.y ;
			if (! GetWindowRect (m_hWnd, &rc))
				rc.bottom	= pt.y + GetSystemMetrics (SM_CYCURSOR) / 2 ;

			if (!pToolTipUI->_IsActivep(&bShow)) {
				DWORD dwElementId;
				HRESULT hr = m_pTSF->_BeginToolTipUI(&dwElementId, &bShow);
				if (FAILED(hr)) {
					if (hr != E_NOINTERFACE)
						break;
					dwElementId = (DWORD)-1;
					bShow = TRUE;
				}
				pToolTipUI->_Open(dwElementId, bShow);
			}

			pToolTipUI->_MoveWindow (pt.x, rc.bottom, 0, 0) ;
			pToolTipUI->_SetText (m_ToolTipInfo.m_bufText + m_ToolTipInfo.m_rnOffsets [nTool]) ;
			DEBUGPRINTF ((TEXT ("Annotation: x:%d, y:%d, text:%d\n"), pt.x, rc.bottom, lstrlenW (m_ToolTipInfo.m_bufText + m_ToolTipInfo.m_rnOffsets [nTool]))) ;

			if (bShow)
				pToolTipUI->_Update();
			m_pTSF->_UpdateToolTipUI();
			break;
		}
	}
	return ;
}

BOOL
CSkkImeCandidateListUIElement::_ConfigureAnnotation (
	const TEXTREGION*		pAnnotation,
	int						iNumAnnotation)
{
	CImeDoc*				pDoc		= NULL ;
	const IMECANDIDATES*	pMyCand		= NULL ;
	HFONT					hOldFont	= NULL ;
	HDC						hDC			= NULL ;
	RECT					rcDraw ;
	int						nText ;
	SIZE					sz ;
	MYTOOLTIPINFO*			pToolTipInfo ;
	BOOL					bRetval			= FALSE ;

/*	if (_hwnd == NULL || ! IsWindow (_hwnd) || _hwndTT == NULL || ! IsWindow (_hwndTT))
		return	FALSE ;
	ShowWindow (_hwndTT, SW_HIDE) ;*/

	if (FAILED (_GetDocument (&pDoc)))
		return	FALSE ;
	pMyCand		= pDoc->pGetStatusText () ;
	if (pMyCand == NULL || pMyCand->m_iStyle != IMECANDSTYLE_READ)
		return	FALSE ;

	hDC			= GetDC (m_hWnd) ;
	if (!hDC)
		return	FALSE ;

	hOldFont	= (HFONT) SelectObject (hDC, _GetDefaultFont (hDC)) ;
	GetClientRect (m_hWnd, &rcDraw) ;

	/*	TOOL ��ǉ�����B*/
	pToolTipInfo	= &m_ToolTipInfo ;
	nText			= m_nTextLen ;
	if (nText > 0) {
		int					nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPCWSTR				pwText ;
		const TEXTREGION*	pAnnot ;
		TEXTMETRIC			tm ;
		int					nTool, nLeft ;
		WCHAR*				pwDest ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= rcDraw.top ;
		pwText		= m_wszText ;
		nTextPos	= 0 ;
		nTool		= 0 ;
		pwDest		= pToolTipInfo->m_bufText ;
		nLeft		= NBUFFER_ANNOTATION_TEXT ;
		sz.cx = sz.cy	= 0 ;

		while (y < rcDraw.bottom && 0 < nText && nLeft > 0 && nTool < MAX_ANNOTATION) {
			int	nPrevChar ;
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x			= rcDraw.left ;
			nPrevChar	= 0 ;
			nChar		= 1 ;
			while (nChar <= nText) {
				int	n ;
				if (nChar < nText && IS_SURROGATE_PAIR (pwText [nChar-1], pwText [nChar])) {
					n	= 1 ;
				} else {
					n	= 0 ;
				}
				GetTextExtentPoint32W (hDC, pwText, nChar+n, &sz) ;
				if ((x + sz.cx) > rcDraw.right)
					break ;
				nPrevChar	= nChar ;
				nChar		+= (n+1) ;
			}
			nChar	= nPrevChar ;
			if (nChar <= 0)
				break ;

			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;

			/* ���̍s�� hit ����BTEXTREGION �𗘗p����B*/
			pAnnot	= pAnnotation ;
			for (nAnnot = 0 ; nAnnot < iNumAnnotation && nLeft > 0 && nTool < MAX_ANNOTATION ; nAnnot ++, pAnnot ++) {
				LPCDSTR		pdstr ;
				int			nOffset, nLength, nIndex ;

				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32W (hDC, pwText, nOffset, &sz) ;
					nAnnotX	= rcDraw.left + sz.cx ;
				} else {
					nAnnotX	= rcDraw.left ;
				}
				GetTextExtentPoint32W (hDC, pwText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				/* �O�̂��߂Ɍ�₪���݂��邩�`�F�b�N����B*/
				if (pAnnot->m_nCandidate >= (int)pMyCand->m_iCount || pAnnot->m_nCandidate >= pMyCand->m_vbufAnnotationIndex.iGetUsage ())
					continue ;

				nIndex		= *(pMyCand->m_vbufAnnotationIndex.pGetBuffer () +  pAnnot->m_nCandidate) ;
				if (nIndex <= 0 || nIndex >= pMyCand->m_vbufCandidate.iGetUsage ())
					continue ;

				pdstr		= pMyCand->m_vbufCandidate.pGetBuffer () + nIndex ;
				nLength		= dcslen (pdstr) ;
				if (nLength <= 0)
					continue ;

				/*	(nAnnotX, y) - (nAnnotX + nAnnotWidth, y + nDY)
				 */
				pToolTipInfo->m_rrcHitArea [nTool].left		= nAnnotX ;
				pToolTipInfo->m_rrcHitArea [nTool].right	= nAnnotX + nAnnotWidth ;
				pToolTipInfo->m_rrcHitArea [nTool].top		= y ;
				pToolTipInfo->m_rrcHitArea [nTool].bottom	= y + nDY ;
				pToolTipInfo->m_rnOffsets  [nTool]			= pwDest - pToolTipInfo->m_bufText ;

				if (nLeft > 0) {
					int	n	= dcstowcs (pwDest, nLeft-1, pdstr, nLength) ;
					pwDest [n]	= L'\0' ;
					pwDest	+= n + 1 ;
					nLeft	-= n + 1 ;
					pToolTipInfo->m_rnLengths [nTool]	= nLength ;
				} else {
					pToolTipInfo->m_rnLengths [nTool]	= 0 ;
				}
				nTool	++ ;
			}
			x			+= sz.cx ;
			pwText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
		pToolTipInfo->m_nCount	= nTool ;
	} else {
		pToolTipInfo->m_nCount	= 0 ;
	}
	bRetval	= TRUE ;

	if (hDC != NULL) {
		SelectObject (hDC, hOldFont) ;
		ReleaseDC (m_hWnd, hDC) ;
	}
	return	bRetval ;
}

BOOL
CSkkImeCandidateListUIElement::_HandleMinibufferContextMenu ()
{
	int				nCmd ;
	unsigned int	uVK ;

	nCmd	= _PopupMinibufferContextMenu () ;
	switch (nCmd){
	case	IDM_CUT:
		uVK	= NFUNC_MOUSE_CUT ;
		break ;
	case	IDM_PASTE:
		uVK	= NFUNC_MOUSE_PASTE ;
		break ;
	case	IDM_COPY:
		uVK	= NFUNC_MOUSE_COPY ;
		break ;
	case	IDM_DELETE:
		uVK	= NFUNC_MOUSE_DELETE ;
		break ;
	default:
		uVK	= 0 ;
		break ;
	}
	if (uVK != 0) {
		HRESULT	hr	= _SendCommandToContext ((WPARAM) uVK, (LPARAM) 0) ;
		if (FAILED (hr))
			return	FALSE ;
	}
	return	TRUE ;
}

int
CSkkImeCandidateListUIElement::_PopupMinibufferContextMenu ()
{
	HMENU		hMenu ;
	int			nCmd ;
	POINT		pos ;
	HCURSOR		hCursor ;

	hMenu		= 0 ;
	nCmd		= -1 ;
	GetCursorPos ((LPPOINT)&pos) ;

	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	hMenu	= _CreateClipboardMenu () ;
	if (hMenu != NULL){
		/* ���j���[��\�����āA�I��������B*/
		hCursor	= SetCursor (LoadCursor (NULL, IDC_ARROW)) ;
		nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, pos.x, pos.y, 0, m_hWnd, NULL) ;
		DestroyMenu (hMenu) ;
		(void)SetCursor (hCursor) ;
	}
	return	nCmd ;
}

HMENU
CSkkImeCandidateListUIElement::_CreateClipboardMenu ()
{
	static	MYMENUITEMINFO	myClipboardMenuItemInfoTbl []	= {
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_CUT,	TEXT ("�؂���"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_PASTE,	TEXT ("�\��t��"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_COPY,	TEXT ("�R�s�["), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_DELETE,	TEXT ("�폜"), },
	  { MIIM_TYPE,							MFT_SEPARATOR,	0,			NULL, },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDCANCEL,	TEXT ("�L�����Z��"), },
	} ;
	CImeDoc*				pDoc ;
	HMENU					hMenu ;
	MYMENUITEMINFO*			lpMyMenu ;
	MENUITEMINFO			menuItemInfo ;
	int						i, nStartPos, nEndPos ;
	BOOL					f ;

	if (FAILED (_GetDocument (&pDoc)))
		return	NULL ;

	hMenu		= CreatePopupMenu () ;
	if (!hMenu)
		return	NULL ;

	/* �܂����j���[�̍��ڂ�ݒ肷��B*/
	lpMyMenu	= myClipboardMenuItemInfoTbl ;
	for (i = 0 ; i < MYARRAYSIZE (myClipboardMenuItemInfoTbl) ; i ++){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= lpMyMenu->m_fMask ;
		menuItemInfo.fType			= lpMyMenu->m_fType ;
		menuItemInfo.wID			= lpMyMenu->m_wID ;
		menuItemInfo.fState			= MFS_ENABLED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		//menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= lpMyMenu->m_dwTypeData ;
		menuItemInfo.cch			= lstrlen (menuItemInfo.dwTypeData) ;
		InsertMenuItem (hMenu, i, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		lpMyMenu	++ ;
	}
	/* �̈�I�����L���ł��邩�ǂ����𔻒肷��B*/
	f			= pDoc->bGetSelectedRegion (&nStartPos, &nEndPos) ;
	if (!f || nStartPos == nEndPos) {
		EnableMenuItem (hMenu, 0, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 2, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 3, MF_BYPOSITION | MF_GRAYED) ;
	}
	/* �N���b�v�{�[�h�Ƀe�L�X�g�����݂��邩�ǂ����`�F�b�N����B*/
	if (!IsClipboardFormatAvailable (CF_TEXT))
		EnableMenuItem (hMenu, 1, MF_BYPOSITION | MF_GRAYED) ;
	return	hMenu ;
}

void
CSkkImeCandidateListUIElement::_HideToolTip ()
{
	CSkkImeToolTipUIElement*	pToolTipUI ;
	BOOL	bShow ;
	POINT	pt ;

	if (FAILED (_GetToolTipUI (&pToolTipUI)))
		return ;
	if (pToolTipUI->_IsActivep (&bShow)) {
		GetCursorPos (&pt) ;
		if (pt.x != m_ToolTipInfo.m_ptLastPos.x || pt.y != m_ToolTipInfo.m_ptLastPos.y) {
			if (bShow)
				pToolTipUI->_Close () ;
			m_pTSF->_EndToolTipUI () ;
		}
	}
	return ;
}

HFONT
CSkkImeCandidateListUIElement::_GetDefaultFont (HDC hDC)
{
	CImeConfig*	pConfig ;

	if (m_pTSF == NULL)
		return	NULL;
	pConfig	= m_pTSF->_GetIMEConfig () ;
	if (pConfig == NULL)
		return	NULL ;
	return	CImeConfig::hGetDefaultFont (pConfig, hDC) ;
}

////////////////////////////////////////////////////////////////////////
//	private functions

static	int		srnMyColorIndex2SysColorIndexTbl []	= {
	COLOR_BTNFACE,
	COLOR_BTNTEXT,
	COLOR_ACTIVEBORDER,
	COLOR_ACTIVECAPTION,
	COLOR_CAPTIONTEXT,
	COLOR_APPWORKSPACE,
	COLOR_WINDOW,
	COLOR_WINDOWTEXT,
	COLOR_DESKTOP,
	COLOR_INFOBK,
	COLOR_INFOTEXT,
	COLOR_WINDOWTEXT,
	COLOR_MENU,
	COLOR_MENUTEXT,
	COLOR_HIGHLIGHTTEXT,
	COLOR_HIGHLIGHT,
	COLOR_INACTIVEBORDER,
	COLOR_INACTIVECAPTION,
	COLOR_INACTIVECAPTIONTEXT,
} ;

/*	�_���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDottedBrush [8]	= {
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
} ;

/*	�f�B�U���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDitherBrush [8]	= {
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
} ;

COLORREF
_GetImeColor (
	HWND	hwnd,
	int	nColor)
{
	HDC		hdc ;
	COLORREF	col ;

	switch (nColor) {
	case	MYCOLOR_TEXTAUTO:
	case	MYCOLOR_BACKAUTO:
		hdc	= GetDC (hwnd) ;
		col	= GetBkColor (hdc) ;
		ReleaseDC (hwnd, hdc) ;
		return	(nColor == MYCOLOR_BACKAUTO)? col : ~col ;
	case	MYCOLOR_BLACK:
		return	PALETTERGB (  0,   0,   0) ;
	case	MYCOLOR_DARKRED:
		return	PALETTERGB (128,   0,   0) ;
	case	MYCOLOR_DARKGREEN:
		return	PALETTERGB (  0, 128,   0) ;
	case	MYCOLOR_DARKYELLOW:
		return	PALETTERGB (128, 128,   0) ;
	case	MYCOLOR_DARKBLUE:
		return	PALETTERGB (  0,   0, 128) ;
	case	MYCOLOR_DARKPURPLE:
		return	PALETTERGB (128,   0, 128) ;
	case	MYCOLOR_DARKLIGHTBLUE:
		return	PALETTERGB (0,   128, 128) ;
	case	MYCOLOR_DARKGRAY:
		return	PALETTERGB (128, 128, 128) ;
	case	MYCOLOR_LIGHTGRAY:
		return	PALETTERGB (192, 192, 192) ;
	case	MYCOLOR_RED:
		return	PALETTERGB (255,   0,   0) ;
	case	MYCOLOR_GREEN:
		return	PALETTERGB (  0, 255,   0) ;
	case	MYCOLOR_YELLOW:
		return	PALETTERGB (255, 255,   0) ;
	case	MYCOLOR_BLUE:
		return	PALETTERGB (  0,   0, 255) ;
	case	MYCOLOR_PURPLE:
		return	PALETTERGB (255,   0, 255) ;
	case	MYCOLOR_LIGHTBLUE:
		return	PALETTERGB (  0, 255, 255) ;
	case	MYCOLOR_WHITE:
		return	PALETTERGB (255, 255, 255) ;
	default:
		if (MYCOLOR_SYSTEM <= nColor && nColor < MAX_MYCOLOR) {
			nColor	-= MYCOLOR_SYSTEM ;
			return	GetSysColor (srnMyColorIndex2SysColorIndexTbl [nColor]) ;
		}
		break ;
	}
	return	PALETTERGB (0, 0, 0) ;
}

HBRUSH
_GetImeLineBrush (
	HWND				hwnd,		/* [in] */
	int					nLineColor,	/* [in] */
	int					nLineType,	/* [in] */
	COLORREF*			pColBrush,	/* [out] */
	HBITMAP*			phBm,		/* [out] */
	int*				pnWidth)	/* [out] */
{
	COLORREF	colBrush ;
	HBRUSH		hBrush	= NULL ;
	HBITMAP	hBitmap	= NULL ;

	if (pColBrush == NULL || phBm == NULL || pnWidth == NULL) {
		return	NULL ;
	}

	colBrush	= _GetImeColor (hwnd, nLineColor) ;
	switch (nLineType) {
	case	MYLINE_SOLID:
		*pnWidth	= 1 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_DOTTED:
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDottedBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		*pnWidth	= 1 ;
		break ;
	case	MYLINE_THICK_SOLID:
		*pnWidth	= 2 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_THIN_DITHER:
		*pnWidth	= 2 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_THICK_DITHER:
		*pnWidth	= 3 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_NO:
	default:
		*pnWidth	= 0 ;
		break ;
	}
	*pColBrush	= colBrush ;
	*phBm		= hBitmap ;
	return	hBrush ;
}
