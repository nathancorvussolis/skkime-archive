// #if !defined (UNITTEST)
#include "globals.h"
// #else
// #include "StdAfx.h"
// #endif

#include "ImeDoc.h"
#include "ImeBuffer.h"
// #include "TMarker.h"	// ImeBuffer.h �ƘA��
// #include "RuleTreeNode.h"
// #include "../../common/keymap.h"
// #include "TMSG.h"	// ImeDoc.h �ƘA��
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "TLispSession.h"
#include "jstring.h"
// #include "ImeConfig.h"	// ImeBuffer.h �ƘA��

/*=================================================================================
 *	prototypes
 */

/*================================================================ skk-pre-command
 */
int
CImeDoc::LM_bSkkToday (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pBuffer->bSkkGetSkkMode ()) {
		if (! pThis->bCall (LM_bSkkModeAdJisx0201, LM_bSkkToday_1))
			return	LMR_ERROR ;
	} else {
		pThis->vJump (LM_bSkkToday_1) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkToday_1 (
	CImeDoc*		pThis)
{
	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	if (! pThis->bCall (LM_bSkkSetHenkanPointSubr, LM_bSkkToday_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkToday_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bInsertAndInherit (L"today", 5)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pThis->vJump (LM_bSkkStartHenkan) ;
	return	LMR_CONTINUE ;
}


