/*
 *	configuration �� update �������������ɂ��̒��g���Q�Ƃ���Ă����
 *	application ��������c���� rule-tree �̓r�������Ă��邱�Ƃ͂��蓾��B
 *	�����͉��Ƃ����Ȃ��Ƃ����Ȃ��Ǝv���B(�܂胁�b�Z�[�W���[�v�̂ǂ̈ʒu�ŁA��)
 */

// #if !defined (UNITTEST)
#include "globals.h"
// #else
// #include "StdAfx.h"
// #endif

#include "../../common/nfunc.h"
#include "../../common/keymask.h"
#include "RuleTreeNode.h"		///< @note ImeBuffer.h ���o�R����ׂ���
#include "jstring.h"
#include "ImeConfig.h"

/*========================================================================
 *	Registry-related definitions
 */
/* generic configs */
#include "../../common/regpath.h"
#define	REGINFO_KANAMODEWHENOPEN			TEXT("KanaModeWhenOpen")
#define	REGINFO_ECHO						TEXT("Echo")
#define	REGINFO_AUTOINSERTPAREN				TEXT("AutoInsertParen")
#define	REGINFO_COMPOSITIONAUTOSHIFT		TEXT("CompTextAutoShift")
#define	REGINFO_DELETEIMPLIESKAKUTEI		TEXT("DeleteImpliesKakutei")
#define	REGINFO_DATEAD						TEXT("DateAd")
#define	REGINFO_NUMBERSTYLE					TEXT("NumberStyle")
#define	REGINFO_BRACKETPARENS				TEXT("CustomBracketParens")
#define	REGINFO_KUTOUTENTYPE				TEXT("KutoutenType")
#define	REGINFO_KUTOUTENS					TEXT("CustomKutoutens")
#define	REGINFO_KAKUTEIEARLY				TEXT("KakuteiEarly")
#define	REGINFO_OKURICHARALISTTYPE			TEXT("OkuriCharAlistType")
#define	REGINFO_OKURICHARALIST				TEXT("OkuriCharAlist")
#define	REGINFO_TICK						TEXT("Tick")
#define	REGINFO_TSFKEYDOWNEATENDOESNOTWORK	TEXT("TSFKeyDownEatenDoesNotWork")

/* key related */
#define	REGPATH_KEYMAP						REGPATH_GENERIC
#define	REGINFO_MAJORMODEMAP				TEXT("MajorModeMap")
#define	REGINFO_JMODEMAP					TEXT("JModeMap")
#define	REGINFO_LATINMODEMAP				TEXT("LatinModeMap")
#define	REGINFO_ZENKAKUMODEMAP				TEXT("Jisx0208LatinModeMap")
#define	REGINFO_ABBREVMODEMAP				TEXT("AbbrevModeMap")

#define	REGINFO_MAJORMODEMAP_EX				TEXT("MajorModeMapEx")
#define	REGINFO_JMODEMAP_EX					TEXT("JModeMapEx")
#define	REGINFO_LATINMODEMAP_EX				TEXT("LatinModeMapEx")
#define	REGINFO_ZENKAKUMODEMAP_EX			TEXT("Jisx0208LatinModeMapEx")
#define	REGINFO_ABBREVMODEMAP_EX			TEXT("AbbrevModeMapEx")

#define	REGINFO_KEYMAP_TYPE					TEXT("KeymapType")
#define	REGINFO_STARTHENKANKEY_TYPE			TEXT("StartHenkanKeyType")
#define	REGINFO_STARTHENKANKEY				TEXT("StartHenkanKey")
#define	REGINFO_COMPLETIONRELATEDKEY_TYPE	TEXT("CompletionRelatedKeyType")
#define	REGINFO_TRYCOMPLETIONKEY			TEXT("TryCompletionKey")
#define	REGINFO_PREVIOUSCOMPLETIONKEY		TEXT("PreviousCompletionKey")
#define	REGINFO_NEXTCOMPLETIONKEY			TEXT("NextCompletionKey")
#define	REGINFO_SETHENKANPOINTSUBRKEY_TYPE	TEXT("SetHenkanPointSubrKeyType")
#define	REGINFO_SETHENKANPOINTSUBRKEY		TEXT("SetHenkanPointSubrKey")
#define	REGINFO_SPECIALMIDASHICHAR_TYPE		TEXT("SpecialMidashiCharType")
#define	REGINFO_SPECIALMIDASHICHAR			TEXT("SpecialMidashiChar")
#define	REGINFO_EGGLIKENEWLINE				TEXT("EggLikeNewline")
#define	REGINFO_NEWLINEKAKUTEIALL			TEXT("NewlineKakuteiAll")

#define	REGPATH_ROMAKANARULE				REGPATH_GENERIC
#define	REGINFO_ROMAKANARULE_TYPE			TEXT("RomaKanaRuleType")
#define	REGINFO_ROMAKANARULE				TEXT("RomaKanaRule")
#define	REGINFO_ROMAKANARULE1				TEXT("RomaKanaRule1")
#define	REGINFO_ROMAKANARULE2				TEXT("RomaKanaRule2")
#define	REGINFO_ROMAKANARULE3				TEXT("RomaKanaRule3")
#define	REGINFO_JISX0201RULE				TEXT("Jisx0201Rule")
#define	REGINFO_JISX0201RULE1				TEXT("Jisx0201Rule1")
#define	REGINFO_JISX0201RULE2				TEXT("Jisx0201Rule2")
#define	REGINFO_JISX0201RULE3				TEXT("Jisx0201Rule3")
#define	REGINFO_JISX0201ROMANRULE			TEXT("Jisx0201RomanRule")
#define	REGINFO_JISX0201ROMANRULE1			TEXT("Jisx0201RomanRule1")
#define	REGINFO_JISX0201ROMANRULE2			TEXT("Jisx0201RomanRule2")
#define	REGINFO_JISX0201ROMANRULE3			TEXT("Jisx0201RomanRule3")

#define	REGPATH_ZENKAKUVECTOR				REGPATH_GENERIC
#define	REGINFO_ZENKAKUVECTOR_TYPE			TEXT("ZenkakuVectorType")
#define	REGINFO_ZENKAKUVECTOR				TEXT("ZenkakuVector")
#define	SIZE_INPUTVECTOR					128

/* conversion config */
#define	REGPATH_CONVERSION					REGPATH_GENERIC
#define	REGINFO_CANDLISTKEYASSIGN			TEXT("CandidateListKeyAssign")
#define	REGINFO_SHOWCANDIDATEKEYS			TEXT("ShowCandidateKeys")
#define	REGINFO_INPUTCODEMENU1KEYS			TEXT("InputCodeMenu1Keys")
#define	REGINFO_INPUTCODEMENU2KEYS			TEXT("InputCodeMenu2Keys")
#define	REGINFO_SHOWCANDIDATELISTCOUNT		TEXT("ShowCandidateListCount")
#define	REGINFO_HENKANOKURISTRICTLY			TEXT("HenkanOkuriStrictly")
#define	REGINFO_PROCESSOKURIEARLY			TEXT("ProcessOkuriEarly")
#define	REGINFO_HENKANSTRICTOKURIPRECEDENCE	TEXT("HenkanStrictOkuriPrecedence")
#define	REGINFO_AUTOOKURIPROCESS			TEXT("AutoOkuriProcess")
#define	REGINFO_AUTOSTARTHENKAN				TEXT("AutoStartHenkan")
#define	REGINFO_AUTOSTARTHENKANKEYWORD		TEXT("AutoStartHenkanKeyword")
#define	REGINFO_DELETEOKURIWHENQUIT			TEXT("DeleteOkuriWhenQuit")
#define	REGINFO_SHOWANNOTATIONTYPE			TEXT("ShowAnnotationType")
#define	REGINFO_NUMERICCONVERSION			TEXT("NumericConversion")
#define	REGINFO_NUMERICFLOAT				TEXT("NumericFloat")

/* style */
#define	REGPATH_STYLE						REGPATH_SKKIME TEXT("\\Style")
#define	REGSUBKEY_COLORFACE					TEXT("Color")
#define	REGSUBKEY_DEFAULTFONT				TEXT("Font")
#define	REGSUBKEY_DEFAULTFONTSIZE			TEXT("Size")

/*========================================================================
 *	definitions
 */
enum {
	KEYBINDTP_DEFAULT		= 0,
	KEYBINDTP_USERDEFINED,
} ;

enum {
	REGKEYTYPE_UNKNOWN	= -1,
	REGKEYTYPE_BOOL		= 0,
	REGKEYTYPE_INT,
} ;

enum {
	KUTOUTEN_TYPE_JP	= 0,
	KUTOUTEN_TYPE_EN,
	KUTOUTEN_TYPE_CUSTOM,
} ;

enum {
	BRACKETPARENTP_NONE	= 0,
	BRACKETPARENTP_DEFAULT,
	BRACKETPARENTP_USERDEFINED,
} ;

enum {
	OKURICHARTP_NONE	= 0,
	OKURICHARTP_DEFAULT,
	OKURICHARTP_USERDEFINED,
} ;

enum {
	CANDLIST_KEYASSIGN_DEFAULT			= 0,
	CANDLIST_KEYASSIGN_01234567890,
	CANDLIST_KEYASSIGN_USERDEFINED		= 65535,
} ;

#define	SEPCHAR	TEXT(',')

/*========================================================================
 *	structures
 */
struct MYCOLORDEF {
	LPCDSTR		m_strText ;
	int			m_nType ;
} ;

/*========================================================================
 *	global variables (default settings)
 */
static const DCHAR	c_Zero	= 0 ;
static const DCHAR	c_Period []	= { L'.', L'\0' } ;
static const DCHAR	c_Comma []	= { L',', L'\0' } ;

#include "../../common/jisx0208_vector.h"
#include "../../common/kana_roma.h"

static TF_PRESERVEDKEY _rDefaultToggleImeKeys[] = {
	{ VK_KANJI,	TF_MOD_IGNORE_ALL_MODIFIER },	///< ALT + ����
	{ 0xF3,		TF_MOD_IGNORE_ALL_MODIFIER },	///< ���p/�S�p (���p��)
	{ 0xF4,		TF_MOD_IGNORE_ALL_MODIFIER },	///< ���p/�S�p (�S�p��)
//	{ 0xC0,		TF_MOD_ALT },					///< �@�\�����B�폜
};

CImeConfig::~CImeConfig ()
{
	_vUninit () ;
	return ;
}

CImeConfig*
CImeConfig::pCreateInstance ()
{
	return	new CImeConfig () ;
}

BOOL
CImeConfig::bTSFKeyDownEatenDoesNotWorkp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bTSFKeyDownEatenDoesNotWorkp () : TRUE ;
}

BOOL
CImeConfig::bKanaModeWhenOpenp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bKanaModeWhenOpenp () : TRUE ;
}

CSkkRuleTreeNode*
CImeConfig::pGetSkkRuleTree (CImeConfig* pThis, int iRule)
{
	return	(pThis != NULL)? pThis->_pGetSkkRuleTree (iRule) : NULL ;
}

BOOL
CImeConfig::bSkkKakuteiEarlyp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkKakuteiEarlyp () : TRUE ;
}

BOOL
CImeConfig::bSkkProcessOkuriEarlyp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkProcessOkuriEarlyp () : FALSE ;
}

BOOL
CImeConfig::bSkkEchop (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkEchop () : TRUE ;
}

BOOL
CImeConfig::bSkkTryCompletionCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkTryCompletionCharp (nCH) : (nCH == '\t') ;
}

BOOL
CImeConfig::bSkkPreviousCompletionCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkPreviousCompletionCharp (nCH) : (nCH == ',') ;
}

BOOL
CImeConfig::bSkkNextCompletionCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkNextCompletionCharp (nCH) : (nCH == '.') ;
}

BOOL
CImeConfig::bSkkAutoStartHenkanp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkAutoStartHenkanp () : FALSE ;
}

BOOL
CImeConfig::bSkkAutoStartHenkanKeywordp (CImeConfig* pThis, LPCDSTR pwString, int iStringLength)
{
	return	pThis != NULL? pThis->_bSkkAutoStartHenkanKeywordp (pwString, iStringLength) : FALSE ;
}

BOOL
CImeConfig::bSkkSpecialMidashiCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkSpecialMidashiCharp (nCH) : FALSE ;
}

BOOL
CImeConfig::bSkkSetHenkanPointKeyp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkSetHenkanPointKeyp (nCH) : FALSE ;
}

void
CImeConfig::vMaskSkkSetHenkanPointKey (CImeConfig* pThis, BOOL bMask)
{
	if (pThis != NULL)
		pThis->_vMaskSkkSetHenkanPointKey (bMask) ;
}

BOOL
CImeConfig::bSkkSetHenkanPointKeyMaskedp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkSetHenkanPointKeyMaskedp () : FALSE ;
}

BOOL
CImeConfig::bSkkStartHenkanCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkStartHenkanCharp (nCH) : (nCH == ' ') ;
}

int
CImeConfig::iSkkARefSkkKanaRomVector (
	CImeConfig*				pThis,
	int						nCH,
	LPDSTR					pOkuri,
	int						nOkuri)
{
	return	pThis != NULL? pThis->_iSkkARefSkkKanaRomVector (nCH, pOkuri, nOkuri) : 0 ;
}

int
CImeConfig::iGetSkkShowAnnotationType (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_iGetSkkShowAnnotationType () : SHOW_NO_ANNOTATION ;
}

BOOL
CImeConfig::bSkkEggLikeNewline (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkEggLikeNewline () : TRUE ;
}

BOOL
CImeConfig::bSkkDeleteOkuriWhenQuit (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkDeleteOkuriWhenQuit () : FALSE ;
}

BOOL
CImeConfig::bSkkDeleteImplesKakuteip (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkDeleteImplesKakuteip () : TRUE ;
}

LPCDSTR
CImeConfig::pGetSkkHenkanShowCandidatesKeys (CImeConfig* pThis, int* pnKeys)
{
	if (pThis != NULL)
		return	pThis->_pGetSkkHenkanShowCandidatesKeys (pnKeys) ;

	if (pnKeys != NULL)
		*pnKeys	= 0 ;
	return	&c_Zero ;
}

BOOL
CImeConfig::bSkkNumericConversionp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkNumericConversionp () : FALSE ;
}

BOOL
CImeConfig::bSkkNumConvertFloatp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkNumConvertFloatp () : FALSE ;
}

BOOL
CImeConfig::bSkkCompCirculatep (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkCompCirculatep () : FALSE ;
}

int
CImeConfig::iGetSkkKcodeCharset (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_iGetSkkKcodeCharset () : KCODE_CHARSET_JAPANESE_JISX0208 ;
}

LPCDSTR
CImeConfig::pGetSkkInputByCodeMenuKeys1 (CImeConfig* pThis, int* pnKeys)
{
	if (pThis != NULL)
		return	pThis->_pGetSkkInputByCodeMenuKeys1 (pnKeys) ;

	if (pnKeys != NULL)
		*pnKeys	= 0 ;
	return	&c_Zero ;
}

LPCDSTR
CImeConfig::pGetSkkInputByCodeMenuKeys2 (CImeConfig* pThis, int* pnKeys)
{
	if (pThis != NULL)
		return	pThis->_pGetSkkInputByCodeMenuKeys2 (pnKeys) ;

	if (pnKeys != NULL)
		*pnKeys	= 0 ;
	return	&c_Zero ;
}

int
CImeConfig::iGetSkkOkuriChar (
	CImeConfig*		pThis,
	LPCDSTR			pwSrc,
	int				iSrcLength,
	LPDSTR			pwDest,
	int				iDestLength)
{
	if (pThis != NULL)
		return	pThis->_iGetSkkOkuriChar (pwSrc, iSrcLength, pwDest, iDestLength) ;
	return	0 ;
}

BOOL
CImeConfig::bSkkHenkanOkuriStrictlyp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkHenkanOkuriStrictlyp () : FALSE ;
}

BOOL
CImeConfig::bSkkHenkanStrictOkuriPrecedencep (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkHenkanStrictOkuriPrecedencep () : FALSE ;
}

BOOL
CImeConfig::bSkkAutoOkuriProcessp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkAutoOkuriProcessp () : FALSE ;
}

int
CImeConfig::iSkkARefSkkJisx0208LatinVector (
	CImeConfig*				pThis,
	int						nCH,
	LPDSTR					pResult,
	int						nResultSize)
{
	return	pThis != NULL? pThis->_iSkkARefSkkJisx0208LatinVector (nCH, pResult, nResultSize) : -1 ;
}

int
CImeConfig::iSkkRevRefSkkJisx0208LatinVector (
	CImeConfig*				pThis,
	int						nCH,
	LPDSTR					pResult,
	int						nResultSize)
{
	return	pThis != NULL? pThis->_iSkkRevRefSkkJisx0208LatinVector (nCH, pResult, nResultSize) : -1 ;
}

BOOL
CImeConfig::bSkkAutoInsertParen (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkAutoInsertParen () : FALSE ;
}

int
CImeConfig::iSkkAssocSkkAutoParenStringAlist (
	CImeConfig*				pThis,
	LPCDSTR					pwString,
	int						nStringLen,
	LPDSTR					pwResult,
	int						nResultSize)
{
	return	pThis != NULL? pThis->_iSkkAssocSkkAutoParenStringAlist (pwString, nStringLen, pwResult, nResultSize) : -1 ;
}

BOOL
CImeConfig::bSkkAllowsSpacesNewlinesAndTabs (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkAllowsSpacesNewlinesAndTabs () : FALSE ;
}

LPCDSTR
CImeConfig::pGetCurrentTouten (
	CImeConfig*						pThis,
	int								iKutoutenType,
	int*							pnLength)
{
	if (pThis != NULL)
		return	pThis->_pGetCurrentTouten (iKutoutenType, pnLength) ;

	if (pnLength != NULL)
		*pnLength	= 1 ;
	return	c_Period ;
}

LPCDSTR
CImeConfig::pGetCurrentKuten (
	CImeConfig*						pThis,
	int								iKutenType,
	int*							pnLength)
{
	if (pThis != NULL)
		return	pThis->_pGetCurrentKuten (iKutenType, pnLength) ;

	if (pnLength != NULL)
		*pnLength	= 1 ;
	return	c_Comma ;
}

int
CImeConfig::iGetNumberOfKutotens (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_iGetNumberOfKutotens () : 1 ;
}

BOOL
CImeConfig::bSkkIsNewlineKakuteiAllp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkIsNewlineKakuteiAllp () : FALSE ;
}

BOOL
CImeConfig::bSkkCompositionAutoShiftp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkCompositionAutoShiftp () : TRUE ;
}

const struct CImeKeymap*
CImeConfig::pGetMajorModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetMajorModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkJModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkJModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkLatinModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkLatinModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkJisx0208LatinModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkJisx0208LatinModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkAbbrevModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkAbbrevModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetMinibufferMinorModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetMinibufferMinorModeMap () : NULL ;
}

const struct MYCOLORFACESET*
CImeConfig::pGetColorFaceSet (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetColorFaceSet () : NULL ;
}

int
CImeConfig::iGetCountHenkanShowChange (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_iGetCountHenkanShowChange () : 3 ;
}

HFONT
CImeConfig::hGetDefaultFont (CImeConfig* pThis, HDC hDC)
{
	return	pThis != NULL? pThis->_hGetDefaultFont (hDC) : NULL ;
}

const TF_PRESERVEDKEY*
CImeConfig::pGetToggleImeKeys (CImeConfig* pThis, UINT* pnPreservedKeys)
{
	if (pThis != NULL) {
		return	pThis->_pGetToggleImeKeys (pnPreservedKeys) ;
	} else {
		if (pnPreservedKeys != NULL)
			*pnPreservedKeys	= ARRAYSIZE (_rDefaultToggleImeKeys) ;
		return	_rDefaultToggleImeKeys ;
	}
}

const TF_PRESERVEDKEY*
CImeConfig::pGetImeOnKeys (CImeConfig* pThis, UINT* pnPreservedKeys)
{
	if (pThis != NULL) {
		return	pThis->_pGetImeOnKeys (pnPreservedKeys) ;
	} else {
		if (pnPreservedKeys != NULL)
			*pnPreservedKeys	= 0 ;
		return	NULL ;
	}
}

const TF_PRESERVEDKEY*
CImeConfig::pGetImeOffKeys (CImeConfig* pThis, UINT* pnPreservedKeys)
{
	if (pThis != NULL) {
		return	pThis->_pGetImeOffKeys (pnPreservedKeys) ;
	} else {
		if (pnPreservedKeys != NULL)
			*pnPreservedKeys	= 0 ;
		return	NULL ;
	}
}

/*========================================================================
 */
ULONG
CImeConfig::AddRef (void)
{
	return	++ m_cRef ;
}

ULONG
CImeConfig::Release (void)
{
	ULONG	cRef	= -- m_cRef ;

	if (m_cRef == 0) {
		delete	this ;
	}
	return	cRef ;
}

void
CImeConfig::vUpdate ()
{
	HKEY	hSubKey ;
	DWORD	cbData, dwType, dwTick ;
	BOOL	bUpdate ;
	LONG	lResult ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
		bUpdate	= ! m_bHaveSyncTick ;
		dwTick	= 0 ;
	} else {
		bUpdate	= FALSE ;
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bUpdate	= ! m_bHaveSyncTick || (m_dwSyncTick != dwTick) ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! bUpdate)
		return ;

	_vUninit () ;
	_vInit () ;
	m_bHaveSyncTick	= TRUE ;
	m_dwSyncTick	= dwTick ;
	return ;
}

/*========================================================================
�C���X�^���X1�������Ȃ��Ȃ� bss �Ɋm�ۂ��ă��[�_��0���������Ă�������ق����悳����
 */
CImeConfig::CImeConfig ()
{
	int		i ;

	m_iRomaKanaRuleListType			= KEYBINDTP_DEFAULT ;
	m_iKeybindType					= KEYBINDTP_DEFAULT ;
	m_iStartHenkanKeyType			= KEYBINDTP_DEFAULT ;
	m_iCompletionRelatedKeyType		= KEYBINDTP_DEFAULT ;
	m_iSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
	m_iSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;

	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		m_rpSkkRuleTree	[i]					= NULL ;
		m_rpSkkJisx0201RomanRuleTree [i]	= NULL ;
		m_rpSkkJisx0201RuleTree [i]			= NULL ;
	}
	for (i = 0 ; i < MYARRAYSIZE (m_rstrJisx0208LatinVector) ; i ++)
		m_rstrJisx0208LatinVector [i]	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (m_MajorModeMap.m_rbyBaseMap) ; i ++) {
		m_MajorModeMap.m_rbyBaseMap [i]				= NFUNC_INVALID_CHAR ;
		m_SkkJModeMap.m_rbyBaseMap [i]				= NFUNC_INVALID_CHAR ;
		m_SkkLatinModeMap.m_rbyBaseMap [i]			= NFUNC_INVALID_CHAR ;
		m_SkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
		m_SkkAbbrevModeMap.m_rbyBaseMap [i]			= NFUNC_INVALID_CHAR ;
		m_MinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	m_MajorModeMap.m_pKeyBinds		= m_SkkJModeMap.m_pKeyBinds				= NULL ;
	m_MajorModeMap.m_nKeyBinds		= m_SkkJModeMap.m_nKeyBinds				= 0 ;
	m_SkkLatinModeMap.m_pKeyBinds	= m_SkkJisx0208LatinModeMap.m_pKeyBinds	= NULL ;
	m_SkkLatinModeMap.m_nKeyBinds	= m_SkkJisx0208LatinModeMap.m_nKeyBinds	= 0 ;
	m_SkkAbbrevModeMap.m_pKeyBinds	= m_MinibufferMinorModeMap.m_pKeyBinds	= NULL ;
	m_SkkAbbrevModeMap.m_nKeyBinds	= m_MinibufferMinorModeMap.m_nKeyBinds	= 0 ;

	m_pToggleImeKeys		= _rDefaultToggleImeKeys ;
	m_iNumberOfToggleImeKeys	= ARRAYSIZE (_rDefaultToggleImeKeys) ;
	m_pImeOnKeys			= NULL ;
	m_iNumberOfImeOnKeys	= 0 ;
	m_pImeOffKeys			= NULL ;
	m_iNumberOfImeOffKeys	= 0 ;

	m_StartHenkanKeys.m_iKeys			= 0 ;
	m_TryCompletionKeys.m_iKeys			= 0 ;
	m_PreviousCompletionKeys.m_iKeys	= 0 ;
	m_NextCompletionKeys.m_iKeys		= 0 ;
	m_SetHenkanPointSubrKeys.m_iKeys	= 0 ;
	m_SpecialMidashiCharKeys.m_iKeys	= 0 ;
	m_bMaskSkkSetHenkanPointKey			= FALSE ;

	m_bEggLikeNewline				= TRUE ;
	m_bNewlineKakuteiAll			= FALSE ;

	// Generic
	m_iKutoutenType					= KUTOUTEN_TYPE_JP ;
	m_Kutouten.m_iCount				= 0 ;
	m_iBracketParenType				= BRACKETPARENTP_NONE ;
	m_BracketParen.m_iCount			= 0 ;
	m_iOkuriCharAlistType			= OKURICHARTP_NONE ;
	m_OkuriCharAlist.m_iCount		= 0 ;

	m_bKanaModeWhenOpen				= TRUE ;
	m_bEcho							= TRUE ;
	m_bCompositionAutoShift			= TRUE ;
	m_bDeleteImpliesKakutei			= TRUE ;
	m_bKakuteiEarly					= TRUE ;

	m_bDateAd						= FALSE ;
	m_iNumberStyle					= 0 ;
	m_bTSFKeyDownEatenDoesNotWork	= TRUE ;

	m_nCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;
	m_nNumShowCandidateKeys			= 0 ;
	m_nNumInputCodeMenu1Keys		= 0 ;
	m_nNumInputCodeMenu2Keys		= 0 ;
	m_nNumShowCandidateKeys			= 0 ;
	for (i = 0 ; i < MAX_NUMMENUKEYS ; i ++) {	// memcpy���ł�������
		m_rwchShowCandidateKeys [i]		= 0 ;
		m_rwchInputCodeMenu1Keys [i]	= 0 ;
		m_rwchInputCodeMenu2Keys [i]	= 0 ;
	}
	m_nShowCandListCount			= SHOWCANDLIST_COUNT_ZERO + 3 ;

	m_bHenkanOkuriStrictly			= FALSE ;
	m_bProcessOkuriEarly			= FALSE ;
	m_bHenkanStrictOkuriPrecedence	= FALSE ;
	m_bAutoOkuriProcess				= FALSE ;
	m_bAutoStartHenkan				= FALSE ;
	m_bDeleteOkuriWhenQuit			= FALSE ;

	m_bNumericConversion			= FALSE ;
	m_bNumericFloat					= FALSE ;

	m_nShowAnnotationType			= SHOW_NO_ANNOTATION ;

	m_iNumAutoStartHenkanKeywords	= 0 ;		// ���݂̃R�[�h�Ȃ珉���l�s��
	m_pAutoStartHenkanKeywords		= NULL ;	// num�ƃ|�C���^�Ńy�A�ɂ��Ă���悤��

	m_bAllowsSpacesNewlinesAndTabs	= FALSE ;
	m_iKanjiCodeCharset				= KCODE_CHARSET_JAPANESE_JISX0208 ;
	m_bCompCirculate				= FALSE ;

	memset (&m_lfDefault, 0, sizeof (LOGFONT)) ;
	m_iDefaultFontSize				= 0 ;
	m_hDefaultFont					= NULL ;

	m_bHaveSyncTick					= FALSE ;
	m_dwSyncTick					= 0 ;

	/*	Reference Count
	 */
	m_cRef							= 1 ;
	return ;
}

/*
 */
BOOL
CImeConfig::_bTSFKeyDownEatenDoesNotWorkp () const
{
	return	m_bTSFKeyDownEatenDoesNotWork ;
}

BOOL
CImeConfig::_bKanaModeWhenOpenp () const
{
	return	m_bKanaModeWhenOpen ;
}

CSkkRuleTreeNode*
CImeConfig::_pGetSkkRuleTree (int iRule)
{
	if (RULETREENO_SKK_BASE <= iRule && iRule < (RULETREENO_SKK_BASE + NUM_ROMAKANARULE))
		return	m_rpSkkRuleTree [iRule - RULETREENO_SKK_BASE] ;
	if (RULETREENO_SKK_JISX0201_ROMAN <= iRule && iRule < (RULETREENO_SKK_JISX0201_ROMAN + NUM_ROMAKANARULE))
		return	m_rpSkkJisx0201RomanRuleTree [iRule - RULETREENO_SKK_JISX0201_ROMAN] ;
	if (RULETREENO_SKK_JISX0201_BASE <= iRule && iRule < (RULETREENO_SKK_JISX0201_BASE + NUM_ROMAKANARULE))
		return	m_rpSkkJisx0201RuleTree [iRule - RULETREENO_SKK_JISX0201_BASE] ;
	return	NULL ;
}

BOOL
CImeConfig::_bSkkKakuteiEarlyp () const
{
	DEBUGPRINTF ((TEXT ("CImeConfig::_bSkkKakuteiEarlyp (this:%p) return %d\n"), this, m_bKakuteiEarly)) ;
	return	m_bKakuteiEarly ;
}

BOOL
CImeConfig::_bSkkProcessOkuriEarlyp ()  const
{
	return	m_bProcessOkuriEarly ;
}

BOOL
CImeConfig::_bSkkEchop () const
{
	return	m_bEcho ;
}

BOOL
CImeConfig::_bSkkTryCompletionCharp (int nCH) const
{
	if (m_iCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'\t')? TRUE : FALSE ;
	} else {
		return	(memchr (m_TryCompletionKeys.m_rbKeys, nCH, m_TryCompletionKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
CImeConfig::_bSkkPreviousCompletionCharp (int nCH) const
{
	if (m_iCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'.')? TRUE : FALSE ;
	} else {
		return	(memchr (m_PreviousCompletionKeys.m_rbKeys, nCH, m_PreviousCompletionKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
CImeConfig::_bSkkNextCompletionCharp (int nCH) const
{
	if (m_iCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L',')? TRUE : FALSE ;
	} else {
		return	(memchr (m_NextCompletionKeys.m_rbKeys, nCH, m_NextCompletionKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
CImeConfig::_bSkkAutoStartHenkanp () const
{
	return	m_bAutoStartHenkan ;	//FALSE
}

BOOL
CImeConfig::_bSkkAutoStartHenkanKeywordp (
	LPCDSTR						pwString,
	int							nStringLength) const
{
	/*	�����ϊ��X�^�[�g�L�[���[�h�Ƃ����̂��������̂�Y��Ă����c�B����̓J�X�^�}�C�Y���ڂ��B
	static	LPCDSTR		_rstrSkkAutoStartHenkanKeywords []	= {
		L"��", L"�A", L"�B", L"�D", L"�C", L"�H", L"�v",  L"�I", L"�G", L"�F", L")", L";", L":",
		L"�j", L"�h", L"�z", L"�x", L"�t", L"�r", L"�p",  L"�n", L"�l", L"}",  L"]", L"?", L".",
		L",",  L"!",
	} ;
	 */
	LPCDSTR		pKeywords ;
	int			i ;

	if (pwString == NULL || nStringLength <= 0)
		return	FALSE ;
	if (m_pAutoStartHenkanKeywords == NULL)
		return	FALSE ;
	pKeywords	= m_pAutoStartHenkanKeywords ;
	for (i = 0 ; i < m_iNumAutoStartHenkanKeywords && *pKeywords != L'\0' ; i ++) {
		if (! dcsncmp (pKeywords, pwString, nStringLength) && pKeywords [nStringLength] == L'\0')
			return	TRUE ;
		pKeywords	+= dcslen (pKeywords) + 1 ;
	}
	return	FALSE ;
}

BOOL
CImeConfig::_bSkkSpecialMidashiCharp (int nCH) const
{
	if (m_iSpecialMidashiCharKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'?' || nCH == L'>' || nCH == L'<')? TRUE : FALSE ;
	} else {
		int		i ;
		for (i = 0 ; i < m_SpecialMidashiCharKeys.m_iKeys && i < MYARRAYSIZE (m_SpecialMidashiCharKeys.m_rbKeys) ; i ++) {
			if (m_SpecialMidashiCharKeys.m_rbKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
CImeConfig::_bSkkSetHenkanPointKeyp (int nCH)  const
{
	/*	Mask ����Ă�����A��� FALSE ��Ԃ��B
	 */
	if (m_bMaskSkkSetHenkanPointKey) {
		return	FALSE ;
	}
	if (m_iSetHenkanPointSubrKeyType == KEYBINDTP_DEFAULT) {
		/* (?A ?B ?C ?D ?E ?F ?G ?H ?I ?J ?K ?M ?N ?O ?P ?R ?S ?T ?U ?V ?W ?Y ?Z) */
		return	(L'A' <= nCH && nCH <= L'Z' && nCH != L'L' && nCH != L'Q' && nCH != L'X')? TRUE : FALSE ;
	} else {
		int	i ;
		for (i = 0 ; i < m_SetHenkanPointSubrKeys.m_iKeys && i < MYARRAYSIZE (m_SetHenkanPointSubrKeys.m_rbKeys) ; i ++) {
			if (m_SetHenkanPointSubrKeys.m_rbKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
CImeConfig::_bSkkSetHenkanPointKeyMaskedp () const
{
	return	m_bMaskSkkSetHenkanPointKey ;
}

void
CImeConfig::_vMaskSkkSetHenkanPointKey (BOOL bMask)
{
	m_bMaskSkkSetHenkanPointKey	= bMask ;
	return ;
}

BOOL
CImeConfig::_bSkkStartHenkanCharp (
	int						nCH) const
{
	/* ���[�ށA����͂ǂ�����ׂ����B��͂� j-mode-map �Ń`�F�b�N���B
	 *	... space �� skk-insert �Ȃ̂��B����� skk-insert ������ start-henkan ���ƌ������߂ɂ���̂��c
	 *	����͂܂����ȁBkeyfunc �����|���� skk-insert �����ǁc�ɂ��Ȃ��Ƃ��߂��B
	 *	����̓L�[�̒ǉ��̂Ƃ���Őݒ肳���邵���Ȃ��ȁB
	 */
	if (m_iStartHenkanKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L' ')? TRUE : FALSE ;
	} else {
		return	(memchr (m_StartHenkanKeys.m_rbKeys, nCH, m_StartHenkanKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

int
CImeConfig::_iSkkARefSkkKanaRomVector (
	int						nCH,
	LPDSTR					pOkuri,
	int						nOkuri) const
{
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (_rDefaultKanaRomaVector) ; i ++) {
		if (nCH == _rDefaultKanaRomaVector [i].m_nKana) {
			int		n ;

			n	= lstrlenW (_rDefaultKanaRomaVector [i].m_wstrRom) ;
			if (n > 0) {
				n	= wcstodcs (pOkuri, nOkuri, _rDefaultKanaRomaVector [i].m_wstrRom, n) ;
			}
			return	n ;
		}
	}
	return	0 ;
}

int
CImeConfig::_iGetSkkShowAnnotationType () const
{
	return	m_nShowAnnotationType ;
}

BOOL
CImeConfig::_bSkkEggLikeNewline ()  const
{
	return	m_bEggLikeNewline ;
}

BOOL
CImeConfig::_bSkkDeleteOkuriWhenQuit () const
{
	return	m_bDeleteOkuriWhenQuit ;
}

BOOL
CImeConfig::_bSkkDeleteImplesKakuteip ()  const
{
	return	m_bDeleteImpliesKakutei ;
}

LPCDSTR
CImeConfig::_pGetSkkHenkanShowCandidatesKeys (int* pnKeys) const
{
	if (pnKeys != NULL)
		*pnKeys	= m_nNumShowCandidateKeys ;
	return	m_rwchShowCandidateKeys ;
}

BOOL
CImeConfig::_bSkkNumericConversionp () const
{
	return	m_bNumericConversion ;
}

BOOL
CImeConfig::_bSkkNumConvertFloatp () const
{
	return	m_bNumericFloat ;
}

BOOL
CImeConfig::_bSkkCompCirculatep () const
{
	return	m_bCompCirculate ;
}

int
CImeConfig::_iGetSkkKcodeCharset () const
{
	return	m_iKanjiCodeCharset ;
}

LPCDSTR
CImeConfig::_pGetSkkInputByCodeMenuKeys1 (int* pnKeys) const
{
	if (pnKeys != NULL) {
		*pnKeys	= m_nNumInputCodeMenu1Keys ;
	}
	return	m_rwchInputCodeMenu1Keys ;
}

LPCDSTR
CImeConfig::_pGetSkkInputByCodeMenuKeys2 (int* pnKeys) const
{
	if (pnKeys != NULL) {
		*pnKeys	= m_nNumInputCodeMenu2Keys ;
	}
	return	m_rwchInputCodeMenu2Keys ;
}

int
CImeConfig::_iGetSkkOkuriChar (
	LPCDSTR					pwOkuriChar,
	int						nOkuriCharLen,
	LPDSTR					pwDest,
	int						nDestSize) const
{
	int		i, nLen ;

	if (m_iOkuriCharAlistType == OKURICHARTP_NONE)
		return	0 ;

	for (i = 0 ; i < m_OkuriCharAlist.m_iCount ; i ++) {
		if (dcsncmp (pwOkuriChar, m_OkuriCharAlist.m_rStringPair [i].m_bufLeft, nOkuriCharLen) == 0 &&
			m_OkuriCharAlist.m_rStringPair [i].m_bufLeft [nOkuriCharLen] == L'\0') {
			/*	hit */
			nLen	= MIN (nDestSize, (int) dcslen (m_OkuriCharAlist.m_rStringPair  [i].m_bufRight)) ;

			dcsncpy (pwDest, m_OkuriCharAlist.m_rStringPair [i].m_bufRight, nLen) ;
			return	nLen ;
		}
	}
	return	0 ;
}

BOOL
CImeConfig::_bSkkHenkanOkuriStrictlyp () const
{
	return	m_bHenkanOkuriStrictly ;
}

BOOL
CImeConfig::_bSkkHenkanStrictOkuriPrecedencep () const
{
	return	m_bHenkanStrictOkuriPrecedence ;
}

/*	auto-okuri-process �𗘗p����̂́Askkiserv ���ł���Ǝv���邪�A�ꉞ���̋L�q�͓���Ă����B
 */
BOOL
CImeConfig::_bSkkAutoOkuriProcessp () const
{
	return	m_bAutoOkuriProcess ;
}

int
CImeConfig::_iSkkARefSkkJisx0208LatinVector (
	int						nCH,
	LPDSTR					pResult,
	int						nResultSize) const
{
	if (0 <= nCH && nCH < MYARRAYSIZE (m_rstrJisx0208LatinVector) &&
		m_rstrJisx0208LatinVector [nCH] != NULL) {
		int		n ;
		n	= dcslen (m_rstrJisx0208LatinVector [nCH]) ;
		n	= (n > nResultSize)? nResultSize : n ;
		if (n > 0) {
			dcsncpy (pResult, m_rstrJisx0208LatinVector [nCH], n) ;
		}
		return	n ;
	}
	return	-1 ;	/* not hit */
}

/*	�t�����B
 */
int
CImeConfig::_iSkkRevRefSkkJisx0208LatinVector (
	int						nCH,
	LPDSTR					pResult,
	int						nResultSize) const
{
	int		i ;

	for (i = 0 ; i < sizeof (m_rstrJisx0208LatinVector) / sizeof (m_rstrJisx0208LatinVector [0]) ; i ++) {
		if (m_rstrJisx0208LatinVector [i] != NULL &&
			*(m_rstrJisx0208LatinVector [i] + 0) == (DCHAR)nCH &&
			*(m_rstrJisx0208LatinVector [i] + 1) == L'\0') {
			if (nResultSize > 0)
				*pResult	= i ;
			return	1 ;
		}
	}
	return	-1 ;	/* not hit */
}

/// �����ʂ̎����}�����L���Ȃ� TRUE
BOOL CImeConfig::_bSkkAutoInsertParen() const
{
	return m_iBracketParenType != BRACKETPARENTP_NONE;
}

int
CImeConfig::_iSkkAssocSkkAutoParenStringAlist (
	LPCDSTR					pwString,
	int						nStringLen,
	LPDSTR					pwResult,
	int						nResultSize) const
{
	int		i ;

	for (i = 0 ; i < m_BracketParen.m_iCount ; i ++) {
		if (! dcsncmp (pwString, m_BracketParen.m_rStringPair [i].m_bufLeft, nStringLen) &&
			m_BracketParen.m_rStringPair [i].m_bufLeft [nStringLen]	== L'\0') {
			int		n ;
			n	= dcslen (m_BracketParen.m_rStringPair [i].m_bufRight) ;
			n	= (n > nResultSize)? nResultSize : n ;
			if (n > 0) {
				dcsncpy (pwResult, m_BracketParen.m_rStringPair [i].m_bufRight, n) ;
			}
			return	n ;
		}
	}
	return	-1 ;	/* not hit */
}

/*	���̐ݒ�͍��̂Ƃ���J�X�^�}�C�Y�ł��Ȃ��B��� FALSE �ɂ��Ă������A����ł����̂��c�H
 */
BOOL
CImeConfig::_bSkkAllowsSpacesNewlinesAndTabs	() const
{
	return	m_bAllowsSpacesNewlinesAndTabs ;
}

LPCDSTR
CImeConfig::_pGetCurrentTouten (
	int								iKutoutenType,
	int*							pnLength) const
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % m_Kutouten.m_iCount ;
	if (pnLength != NULL)
		*pnLength	= dcslen (m_Kutouten.m_rStringPair [nIndex].m_bufLeft) ;
	return	m_Kutouten.m_rStringPair [nIndex].m_bufLeft ;
}

LPCDSTR
CImeConfig::_pGetCurrentKuten (
	int								iKutoutenType,
	int*							pnLength) const
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % m_Kutouten.m_iCount ;
	if (pnLength != NULL)
		*pnLength	= dcslen (m_Kutouten.m_rStringPair [nIndex].m_bufRight) ;
	return	m_Kutouten.m_rStringPair [nIndex].m_bufRight ;
}

int
CImeConfig::_iGetNumberOfKutotens () const
{
	return	m_Kutouten.m_iCount ;
}

/*	Newline -> Kakutei �̌�Apoint-marker �� buffer �̍Ō�ֈړ������邩�ۂ��B
 *	shift-count �̐�����A���ꂪ TRUE ���ƁuComposition �̑S�m��v�Ɍ�����B
 */
BOOL
CImeConfig::_bSkkIsNewlineKakuteiAllp () const
{
	return	m_bNewlineKakuteiAll ;
}

/*	�����I�� CompositionString ���m��ς݂Ƃ��đ����邩�ǂ��������肷��B
 *	��{�I�Ɂu�o�b�t�@�̐擪�v����upoint-marker�̈ʒu�v�u�ϊ��J�n�ʒu�v
 *	�u�����J�n�ʒu�v�̒��ōŏ��̈ʒu�܂ŃV�t�g�����B
 */
BOOL
CImeConfig::_bSkkCompositionAutoShiftp () const
{
	return	m_bCompositionAutoShift ;
}

const struct CImeKeymap*
CImeConfig::_pGetMajorModeMap ()  const
{
	return	&m_MajorModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkJModeMap () const
{
	return	&m_SkkJModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkLatinModeMap () const
{
	return	&m_SkkLatinModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkJisx0208LatinModeMap () const
{
	return	&m_SkkJisx0208LatinModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkAbbrevModeMap () const
{
	return	&m_SkkAbbrevModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetMinibufferMinorModeMap () const
{
	return	&m_MinibufferMinorModeMap ;
}

const MYCOLORFACESET*
CImeConfig::_pGetColorFaceSet () const
{
	return	m_rImeColorFaces ;
}

int
CImeConfig::_iGetCountHenkanShowChange () const
{
	return	m_nShowCandListCount ;
}

HFONT
CImeConfig::_hGetDefaultFont (HDC hdc)
{
	int	lfHeight ;

	lfHeight	= (m_iDefaultFontSize < 0)? m_iDefaultFontSize : -MulDiv (m_iDefaultFontSize, GetDeviceCaps(hdc, LOGPIXELSY), 72) ;
	if (m_hDefaultFont == NULL || m_lfDefault.lfHeight != lfHeight) {
		m_lfDefault.lfHeight	= lfHeight ;
		m_lfDefault.lfWidth		= 0 ;
		if (m_hDefaultFont != NULL)
			DeleteObject (m_hDefaultFont) ;
		m_hDefaultFont	= CreateFontIndirect (&m_lfDefault) ;
	}
	return	(m_hDefaultFont == NULL)? (HFONT)GetStockObject (DEFAULT_GUI_FONT) : m_hDefaultFont ;
}

const TF_PRESERVEDKEY*
CImeConfig::_pGetToggleImeKeys (UINT* pnPreservedKeys) const
{
	if (pnPreservedKeys != NULL)
		*pnPreservedKeys	= m_iNumberOfToggleImeKeys ;
	return	m_pToggleImeKeys ;
}

const TF_PRESERVEDKEY*
CImeConfig::_pGetImeOnKeys (UINT* pnPreservedKeys) const
{
	if (pnPreservedKeys != NULL)
		*pnPreservedKeys	= m_iNumberOfImeOnKeys ;
	return	m_pImeOnKeys ;
}

const TF_PRESERVEDKEY*
CImeConfig::_pGetImeOffKeys (UINT* pnPreservedKeys) const
{
	if (pnPreservedKeys != NULL)
		*pnPreservedKeys	= m_iNumberOfImeOffKeys ;
	return	m_pImeOffKeys ;
}

/*========================================================================
 *	private functions (for ZenkakuVector)
 */
void
CImeConfig::_vInit ()
{
	HKEY	hSubKey ;
	DWORD	dwTick		= 0 ;
	BOOL	bHaveTick	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData ;
		LONG	lResult ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bHaveTick	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	_vLoadZenkakuVector () ;
	_bLoadRomaKanaRuleList () ;
	_bLoadKeymaps () ;
	_bLoadGenericSetting () ;
	_bLoadConversionSetting () ;
	_bLoadColorfaceSetting () ;
	_vInitializeDefaultFont () ;

	m_bHaveSyncTick	= bHaveTick ;
	m_dwSyncTick	= dwTick ;
	return ;
}

void
CImeConfig::_vUninit ()
{
	_vClearZenkakuVector () ;
	_vClearRomaKanaRuleList () ;
	_vClearKeymaps () ;

	delete[]	m_pAutoStartHenkanKeywords ;
	m_pAutoStartHenkanKeywords	= NULL ;
	// m_iNumAutoStartHenkanKeywords	= 0 ;	// �I���l�s��

	if (m_hDefaultFont != NULL) {
		DeleteObject (m_hDefaultFont) ;
		m_hDefaultFont	= NULL ;
	}
	memset (&m_lfDefault, 0, sizeof (LOGFONT)) ;
	m_iDefaultFontSize	= 0 ;

	m_bHaveSyncTick	= FALSE ;
	m_dwSyncTick		= 0 ;
	return ;
}

/// �S�p�x�N�^�̓ǂݍ���
void CImeConfig::_vLoadZenkakuVector()
{
	HKEY hSubKey;
	if (RegOpenKeyEx(HKEY_CURRENT_USER, REGPATH_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) goto skip_default;

	DWORD dwType, dwValue, cbData;
	cbData = sizeof(DWORD);
	LONG lResult;
	lResult = RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData);
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD || dwValue == KEYBINDTP_DEFAULT) goto skip_scope1;

	lResult = RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, NULL, &cbData);
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ) goto skip_scope1;

	LPTSTR pwData;
	pwData = (LPTSTR)new BYTE[cbData];
	if (pwData == NULL) {
	skip_scope1:
		RegCloseKey(hSubKey);
		goto skip_default;
	}

	RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, (BYTE*)pwData, &cbData);
	RegCloseKey(hSubKey);

	_vClearZenkakuVector();

	LPCTSTR pwSrc;
	pwSrc = pwData;
	while (*pwSrc) {
		// �ΏۃL�����N�^�ǂݍ���
		TCHAR c;
		c = *pwSrc++;
		if (c < TEXT(' ') || c >= SIZE_INPUTVECTOR) goto skip_scope2;

		LPCTSTR pwBase;
		pwBase = pwSrc;
		while (*pwSrc++);		// ��r���Z�q�͐�΂ɏ��������Ȃ��ł�����
		size_t nTemp;
		nTemp = pwSrc - pwBase - 1;

		delete[] m_rstrJisx0208LatinVector[c];
		m_rstrJisx0208LatinVector[c] = NULL;
		size_t n;
		n = wcstodcs(NULL, 0, pwBase, nTemp);	// ���W�X�g���i�[���e�̓m�[�}���C�Y�ς��O��
		if (n == 0) goto skip_scope2;

		LPDSTR p;
		p = new DCHAR[n + 1];
		if (p == NULL) {
		skip_scope2:
			delete[] pwData;
			goto skip_default;
		}
		wcstodcs(p, n, pwBase, nTemp);
		p[n] = TEXT('\0');
		m_rstrJisx0208LatinVector[c] = p;
	}
	delete[] pwData;
	return;

skip_default:
	// �f�t�H���g�l���g�p����
	// �G���[�ł͂Ȃ����������n
	for (UINT i = 0; i < SIZE_INPUTVECTOR; i++) {
		LPDSTR p = NULL;
		TCHAR c = i < TEXT(' ') ? TEXT('\0') : _rcDefaultJisx0208LatinVector[i - TEXT(' ')];
		if (c) {
			p = new DCHAR[2];	// �f�t�H���g�l�͕K��1����+�I�[
			if (p) {
				wcstodcs(p, 1, &c, 1);
				p[1] = TEXT('\0');
			}
		}
		m_rstrJisx0208LatinVector[i] = p;
	}
}

void
CImeConfig::_vClearZenkakuVector ()
{
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (m_rstrJisx0208LatinVector) ; i ++) {
//		if (m_rstrJisx0208LatinVector [i] != NULL) {
			delete[]	m_rstrJisx0208LatinVector [i] ;
			m_rstrJisx0208LatinVector [i]	= NULL ;
//		}
	}
	return ;
}

/*========================================================================
 *	private functions (for Keybind)
 */
BOOL
CImeConfig::_bLoadKeymaps ()
{
	HKEY	hSubKey ;
	BOOL	bRetval	= FALSE ;
	BOOL	bExistUserDefinedKeymap					= FALSE ;
	BOOL	bExistUserDefinedStartHenkanKey			= FALSE ;
	BOOL	bExistUserDefinedCompletionKey			= FALSE ;
	BOOL	bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
	BOOL	bExistUserDefinedSpecialMidashiCharKey	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData, dwValue ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_KEYMAP_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		m_iKeybindType	= (int) dwValue ;

		if (_bLoadKeymap (hSubKey, REGINFO_MAJORMODEMAP,	REGINFO_MAJORMODEMAP_EX,	&m_MajorModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_JMODEMAP,		REGINFO_JMODEMAP_EX,		&m_SkkJModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_LATINMODEMAP,	REGINFO_LATINMODEMAP_EX,	&m_SkkLatinModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_ZENKAKUMODEMAP,	REGINFO_ZENKAKUMODEMAP_EX,	&m_SkkJisx0208LatinModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_ABBREVMODEMAP,	REGINFO_ABBREVMODEMAP_EX,	&m_SkkAbbrevModeMap))
			bExistUserDefinedKeymap	= TRUE ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_STARTHENKANKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		m_iStartHenkanKeyType	= (int) dwValue ;
		cbData	= sizeof (m_StartHenkanKeys.m_rbKeys) ;
		if (RegQueryValueExW (hSubKey, REGINFO_STARTHENKANKEY, NULL, &dwType, (BYTE*)m_StartHenkanKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedStartHenkanKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_StartHenkanKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedStartHenkanKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		m_iCompletionRelatedKeyType	= (int) dwValue ;
		if (RegQueryValueExW (hSubKey, REGINFO_TRYCOMPLETIONKEY, NULL, &dwType, (BYTE*)m_TryCompletionKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_TryCompletionKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, NULL, &dwType, (BYTE*)m_PreviousCompletionKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_PreviousCompletionKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGINFO_NEXTCOMPLETIONKEY, NULL, &dwType, (BYTE*)m_NextCompletionKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_NextCompletionKeys.m_iKeys	= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		m_iSetHenkanPointSubrKeyType	= (int) dwValue ;
		cbData	= sizeof (m_SetHenkanPointSubrKeys.m_rbKeys) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, NULL, &dwType, (BYTE*)m_SetHenkanPointSubrKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_SetHenkanPointSubrKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		m_iSpecialMidashiCharKeyType	= (int) dwValue ;
		cbData	= sizeof (m_SpecialMidashiCharKeys.m_rbKeys) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SPECIALMIDASHICHAR, NULL, &dwType, (BYTE*)m_SpecialMidashiCharKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSpecialMidashiCharKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_SpecialMidashiCharKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_EGGLIKENEWLINE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			m_bEggLikeNewline	= (dwValue != 0) ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_NEWLINEKAKUTEIALL, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			m_bNewlineKakuteiAll	= (dwValue != 0) ;
		}
		bRetval	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}

	/* �f�[�^���ςłȂ����A�X�̗v�f���`�F�b�N����B*/
	if (bRetval) {
		_vValidateKeymap (&m_MajorModeMap) ;
		_vValidateKeymap (&m_SkkJModeMap) ;
		_vValidateKeymap (&m_SkkLatinModeMap) ;
		_vValidateKeymap (&m_SkkJisx0208LatinModeMap) ;
		_vValidateKeymap (&m_SkkAbbrevModeMap) ;
		if (m_iKeybindType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedKeymap)
			m_iKeybindType	= KEYBINDTP_DEFAULT ;
		if (m_iStartHenkanKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedStartHenkanKey)
			m_iStartHenkanKeyType	= KEYBINDTP_DEFAULT ;
		if (m_iCompletionRelatedKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedCompletionKey)
			m_iCompletionRelatedKeyType	= KEYBINDTP_DEFAULT ;
		if (m_iSetHenkanPointSubrKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSetHenkanPointSubrKey)
			m_iSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		if (m_iSpecialMidashiCharKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSpecialMidashiCharKey)
			m_iSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;
	} else {
		/* ���[�h�Ɏ��s�����̂ŁA�f�t�H���g�̐ݒ�ɂ���B*/
		m_iKeybindType					= KEYBINDTP_DEFAULT ;
		m_iStartHenkanKeyType			= KEYBINDTP_DEFAULT ;
		m_iCompletionRelatedKeyType		= KEYBINDTP_DEFAULT ;
		m_iSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		m_iSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;

		m_bEggLikeNewline				= TRUE ;
		m_bNewlineKakuteiAll			= FALSE ;
	}
	_InitializePreservedKeys (&m_MajorModeMap) ;

	/*	�L�[�}�b�v�̏������B*/
	if (m_iKeybindType == KEYBINDTP_DEFAULT) {
		_vInitializeMajorModeMap () ;
		_vInitializeSkkJModeMap () ;
		_vInitializeSkkLatinModeMap () ;
		_vInitializeSkkJisx0208LatinModeMap () ;
		_vInitializeSkkAbbrevModeMap () ;
	}
	_vInitializeMinibufferMinorModeMap () ;
	return	TRUE ;
}

BOOL
CImeConfig::_bLoadKeymap (
	HKEY				hSubKey,
	LPCWSTR				strRegistryName,
	LPCWSTR				strRegisterExtraName,
	struct CImeKeymap*	pKeymap)
{
	BOOL				bRetval	= FALSE ;
	LONG				lResult ;
	DWORD				dwType, cbData ;
	BYTE				rbBuffer [512] ;
	BYTE*				pbBuffer	= NULL ;
	DWORD				iBufSize ;
	int					iNumKeyBinds, j ;
	const BYTE*			pbData ;
	struct CImeKeyBind*	pKeyBind ;

	lResult	= RegQueryValueExW (hSubKey, strRegistryName, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS)
		return	TRUE ;
	if (dwType != REG_BINARY || cbData != MAX_KEYBINDS)
		return	TRUE ;

	(void) RegQueryValueExW (hSubKey, strRegistryName, NULL, &dwType, (BYTE*)pKeymap->m_rbyBaseMap, &cbData) ;

	/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
	pKeymap->m_nKeyBinds	= 0 ;
	pKeymap->m_pKeyBinds	= NULL ;

	/*	����L�[�̓o�^�B
	 */
	pbBuffer	= rbBuffer ;
	iBufSize	= sizeof (rbBuffer) ;
	/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
	lResult	= RegQueryValueEx (hSubKey, strRegisterExtraName, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY)
		return	TRUE ;

	if (cbData > iBufSize) {
		if (pbBuffer != rbBuffer) {
			delete[]	pbBuffer ;
		}
		pbBuffer	= new BYTE [cbData] ;
		if (pbBuffer == NULL)
			goto	exit_func ;
		iBufSize	= cbData ;
	}
	(void) RegQueryValueEx (hSubKey, strRegisterExtraName, NULL, &dwType, pbBuffer, &cbData) ;

	/*
	 */
	iNumKeyBinds	= cbData / (4 + 2 + 2) ;	/* VKEY(4), MODIFIER(2), FUNCNO(2) */
	if (iNumKeyBinds <= 0)
		goto	exit_func ;

	pKeymap->m_pKeyBinds	= new CImeKeyBind [iNumKeyBinds] ;
	if (pKeymap->m_pKeyBinds == NULL)
		goto	exit_func ;

	pKeymap->m_nKeyBinds	= iNumKeyBinds ;
	pbData		= pbBuffer ;
	pKeyBind	= pKeymap->m_pKeyBinds ;
	for (j = 0 ; j < iNumKeyBinds ; j ++) {
		unsigned int	uVKey, uModifier ;
		int				iFuncNo ;

		uVKey		= (unsigned int) *pbData ++ ;
		uVKey		= uVKey | ((unsigned int) *pbData ++ <<  8) ;
		uVKey		= uVKey | ((unsigned int) *pbData ++ << 16) ;
		uVKey		= uVKey | ((unsigned int) *pbData ++ << 24) ;
		uModifier	= (unsigned int) *pbData ++ ;
		uModifier	= uModifier | ((unsigned int) *pbData ++ << 8) ;
		iFuncNo		= (unsigned int) *pbData ++ ;
		pbData++;	// iFuncNo		= iFuncNo | ((unsigned int) *pbData ++ << 8) ;
		if (iFuncNo >= NUM_SELECTABLE_FUNCTIONS)
			continue ;	/* skip */
		pKeyBind->m_nKeyCode		= (short) uVKey ;
		pKeyBind->m_uKeyMask		= (unsigned short) uModifier ;
		pKeyBind->m_nKeyFunction	= iFuncNo ;
		pKeyBind	++ ;
	}
	/* realloc �������Ƃ��낾���ǁc */
	pKeymap->m_nKeyBinds	= pKeyBind - pKeymap->m_pKeyBinds ;
	bRetval	= TRUE ;
exit_func:
	if (pbBuffer != rbBuffer && pbBuffer != NULL) {
		delete[]	pbBuffer ;
		pbBuffer	= NULL ;
	}
	return	TRUE ;
}

void
CImeConfig::_vValidateKeymap (
	struct CImeKeymap*		pKeymap)
{
	int		j ;

	for (j = 0 ; j < MAX_KEYBINDS ; j ++) {
		if (pKeymap->m_rbyBaseMap [j] < 0 || pKeymap->m_rbyBaseMap [j] >= NUM_SELECTABLE_FUNCTIONS) {
			pKeymap->m_rbyBaseMap [j]	= NFUNC_INVALID_CHAR ;
		}
	}
	return ;
}

void
CImeConfig::_vInitializeMajorModeMap ()
{
	#include "../../common/major.h"

	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		m_MajorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	for (i = 0 ; i < MYARRAYSIZE (_srbDefaultMajorModeMap) ; i ++)
		m_MajorModeMap.m_rbyBaseMap [i]	= _srbDefaultMajorModeMap [i] ;
	for (i = 32 ; i < 127 ; i ++)
		m_MajorModeMap.m_rbyBaseMap [i]	= NFUNC_SELF_INSERT_CHARACTER ;

	m_MajorModeMap.m_pKeyBinds	= NULL ;
	m_MajorModeMap.m_nKeyBinds	= 0 ;
}

void
CImeConfig::_vInitializeSkkJModeMap ()
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		m_SkkJModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 32 ; i < 127 ; i ++) {
		m_SkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_INSERT ;
	}
	m_SkkJModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	m_SkkJModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_KATAKANA ;

	/*	previous-candidate-char ���ɂ���ׂ����Akeybind ���� previous-candidate-char ��
	 *	���߂�悤�ɂ���ׂ����B�ǂ��炪�������̂��B��҂��I������Ȃ��������R�́A�ǂ�
	 *	minor-mode-map �𗘗p����Ηǂ��̂�������Ȃ��������炩�H
	 */
	m_SkkJModeMap.m_rbyBaseMap ['x']	= NFUNC_SKK_PREVIOUS_CANDIDATE ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			m_SkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	/*	try-completion-char �� skk-insert �ɂ��킹��B
	 *	try-completion-char �� keybind ����ɂ��邩�c�B���[��A�ł� try-completion �̓���
	 *	�� skk-insert �Ɠ����ɂ��Ă����� (function code �͈Ⴄ���ǁA����͓�����)�A
	 *	keybind �� try-completion �Ȃ� try-completion-charp �� t ��Ԃ��Ƃ����̂́H
	 *
	 *	�����Aabbrev-map �͑f���� try-completion �Ȃ̂ɁA������� skk-insert �o�R�Ƃ����̂�
	 *	�C�ɂȂ�c�B����������闝�R���l�������� try-completion ������̂͊댯���B
	 */
	m_SkkJModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_INSERT ;

	m_SkkJModeMap.m_pKeyBinds	= NULL ;
	m_SkkJModeMap.m_nKeyBinds	= 0 ;
}

void
CImeConfig::_vInitializeSkkLatinModeMap ()
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		m_SkkLatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkLatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;

	m_SkkLatinModeMap.m_pKeyBinds	= NULL ;
	m_SkkLatinModeMap.m_nKeyBinds	= 0 ;
}

void
CImeConfig::_vInitializeSkkJisx0208LatinModeMap ()
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		m_SkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	for (i = 0 ; i < 128 ; i ++) {
		/*	LatinVector �̏���������ɍs���Ă��Ȃ���΂Ȃ�Ȃ��B*/
		if (m_rstrJisx0208LatinVector [i] != NULL)
			m_SkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_JISX0208_LATIN_INSERT ;
	}
	m_SkkJisx0208LatinModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_LATIN_HENKAN ;	/* \C-q */

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkJisx0208LatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-backward-and-set-henkan-point-char �́c 2stroke key �͎������ĂȂ�����c�B*/

	m_SkkJisx0208LatinModeMap.m_pKeyBinds	= NULL ;
	m_SkkJisx0208LatinModeMap.m_nKeyBinds	= 0 ;
}

void
CImeConfig::_vInitializeSkkAbbrevModeMap ()
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		m_SkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	m_SkkAbbrevModeMap.m_rbyBaseMap ['.']	= NFUNC_SKK_ABBREV_PERIOD ;
	m_SkkAbbrevModeMap.m_rbyBaseMap [',']	= NFUNC_SKK_ABBREV_COMMA ;
	m_SkkAbbrevModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_CHARACTERS ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkAbbrevModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-start-henkan-char �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkAbbrevModeMap.m_rbyBaseMap [' ']	= NFUNC_SKK_START_HENKAN ;

	/*	�{���� m_pKeyBinds �����āANFUNC_SKK_DELETE_BACKWARD_CHAR �̐ݒ������
	 *	���Ƃ����Ȃ��̂����B
	 */
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			m_SkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	m_SkkAbbrevModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_TRY_COMPLETION ;

	m_SkkAbbrevModeMap.m_pKeyBinds	= NULL ;
	m_SkkAbbrevModeMap.m_nKeyBinds	= 0 ;
}

void
CImeConfig::_vInitializeMinibufferMinorModeMap ()
{
	struct CImeKeyBind*	pKeyBind ;
	int	i ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		m_MinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	m_MinibufferMinorModeMap.m_pKeyBinds	= NULL ;
	m_MinibufferMinorModeMap.m_nKeyBinds	= 0 ;

	/*	MajorModeMap, JModeMap �����āAKey ��ݒ肷��B
	 */
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_NEWLINE) {
			_bDefineKey (&m_MinibufferMinorModeMap, i, 0, FALSE, NFUNC_EXIT_RECURSIVE_EDIT) ;
		} else if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_KEYBOARD_QUIT) {
			_bDefineKey (&m_MinibufferMinorModeMap, i, 0, FALSE, NFUNC_ABORT_RECURSIVE_EDIT) ;
		}

		if (m_SkkJModeMap.m_rbyBaseMap [i] == NFUNC_SKK_KAKUTEI)
			_bDefineKey (&m_MinibufferMinorModeMap, i, 0, FALSE, NFUNC_SKK_KAKUTEI) ;
	}

	pKeyBind	= m_MajorModeMap.m_pKeyBinds ;
	for (i = 0 ; i < m_MajorModeMap.m_nKeyBinds ; i ++) {
		if (pKeyBind->m_nKeyFunction  == NFUNC_NEWLINE) {
			_bDefineKey (&m_MinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, TRUE, NFUNC_EXIT_RECURSIVE_EDIT) ;
		} else if (pKeyBind->m_nKeyFunction == NFUNC_KEYBOARD_QUIT) {
			_bDefineKey (&m_MinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, TRUE, NFUNC_ABORT_RECURSIVE_EDIT) ;
		}
		pKeyBind	++ ;
	}

	pKeyBind	= m_SkkJModeMap.m_pKeyBinds ;
	for (i = 0 ; i < m_SkkJModeMap.m_nKeyBinds ; i ++) {
		if (pKeyBind->m_nKeyFunction == NFUNC_SKK_KAKUTEI)
			_bDefineKey (&m_MinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, TRUE, NFUNC_SKK_KAKUTEI) ;
		pKeyBind	++ ;
	}
}

BOOL
CImeConfig::_bDefineKey (
	struct CImeKeymap*	pKeymap,
	int					nKeyCode,
	unsigned int		uKeyMask,
	BOOL				bExtended,
	int					nKeyFunction)
{
	struct CImeKeyBind*	pKeyBind ;
	struct CImeKeyBind*	pNewKeyBind ;
	int		i ;

	if (pKeymap == NULL)
		return	FALSE ;

	if (! bExtended) {
		if (uKeyMask != 0 || nKeyCode < 0 || nKeyCode >= MAX_KEYBINDS)
			return	FALSE ;
		pKeymap->m_rbyBaseMap [nKeyCode]	= (BYTE) nKeyFunction ;
	} else {
		pKeyBind	= pKeymap->m_pKeyBinds ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
			if (pKeyBind->m_nKeyCode == nKeyCode && pKeyBind->m_uKeyMask == uKeyMask) {
				/* found */
				pKeyBind->m_nKeyFunction	= nKeyFunction ;
				return	TRUE ;
			}
			pKeyBind	++ ;
		}

		pNewKeyBind	= new CImeKeyBind [pKeymap->m_nKeyBinds + 1] ;
		if (pNewKeyBind == NULL)
			return	FALSE ;
		if (pKeymap->m_nKeyBinds > 0)
			memcpy (pNewKeyBind, pKeymap->m_pKeyBinds, sizeof (struct CImeKeyBind) * pKeymap->m_nKeyBinds) ;
		if (pKeymap->m_pKeyBinds != NULL)
			delete[]	pKeymap->m_pKeyBinds ;
		pKeymap->m_pKeyBinds	= pNewKeyBind ;
		pNewKeyBind [pKeymap->m_nKeyBinds].m_nKeyCode	= (short) nKeyCode ;
		pNewKeyBind [pKeymap->m_nKeyBinds].m_uKeyMask	= (unsigned short) uKeyMask ;
		pNewKeyBind [pKeymap->m_nKeyBinds].m_nKeyFunction	= nKeyFunction ;
		pKeymap->m_nKeyBinds	++ ;
	}
	return	TRUE ;
}

/*========================================================================
 *	private functions (for Keybind/���[�}�����ȃ��[��)
 */
BOOL
CImeConfig::_bLoadRomaKanaRuleList ()
{
	BOOL	bRetval ;
	int		i ;

	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		m_rpSkkRuleTree [i]					= NULL ;
		m_rpSkkJisx0201RomanRuleTree [i]	= NULL ;
		m_rpSkkJisx0201RuleTree [i]			= NULL ;
	}
	bRetval	= _bLoadRomaKanaRuleListFromRegistry () ;
	if (! bRetval || m_iRomaKanaRuleListType == KEYBINDTP_DEFAULT) {
		m_iRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
		_bInitializeDefaultRomaKanaRuleTree () ;
	}
	return	TRUE ;
}

void
CImeConfig::_vClearRomaKanaRuleList ()
{
	int		i ;

	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		if (m_rpSkkRuleTree [i] != NULL) {
			CSkkRuleTreeNode::vDestroyTree (m_rpSkkRuleTree [i]) ;
			m_rpSkkRuleTree [i]	= NULL ;
		}
		if (m_rpSkkJisx0201RomanRuleTree [i] != NULL) {
			CSkkRuleTreeNode::vDestroyTree (m_rpSkkJisx0201RomanRuleTree [i]) ;
			m_rpSkkJisx0201RomanRuleTree [i]	= NULL ;
		}
		if (m_rpSkkJisx0201RuleTree [i] != NULL) {
			CSkkRuleTreeNode::vDestroyTree (m_rpSkkJisx0201RuleTree [i]) ;
			m_rpSkkJisx0201RuleTree [i]	= NULL ;
		}
	}
	return ;
}

BOOL
CImeConfig::_bLoadRomaKanaRuleListFromRegistry ()
{
	HKEY	hSubKey ;
	BOOL	bExistUserDefinedRomaKanaRule	= FALSE ;
	BOOL	bRetval	= TRUE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_ROMAKANARULE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData, dwValue ;

		/* rule-list-type (default or custom) */
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_ROMAKANARULE_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) {
			bRetval	= FALSE ;
			goto	skip_error ;
		}
		m_iRomaKanaRuleListType	= (int) dwValue ;

		if (m_iRomaKanaRuleListType != KEYBINDTP_DEFAULT) {
			static LPCWSTR	srRomaKanaRuleTbl [NUM_ROMAKANARULE]	= {
				REGINFO_ROMAKANARULE,	REGINFO_ROMAKANARULE1,	REGINFO_ROMAKANARULE2,	REGINFO_ROMAKANARULE3,
			} ;
			static LPCWSTR	srJisx0201RomanRuleTbl [NUM_ROMAKANARULE]	= {
				REGINFO_JISX0201ROMANRULE,	REGINFO_JISX0201ROMANRULE1,	REGINFO_JISX0201ROMANRULE2,	REGINFO_JISX0201ROMANRULE3,
			} ;
			static LPCWSTR	srJisx0201RuleTbl [NUM_ROMAKANARULE]	= {
				REGINFO_JISX0201RULE,	REGINFO_JISX0201RULE1,	REGINFO_JISX0201RULE2,	REGINFO_JISX0201RULE3,
			} ;
			if (_bParseRomaKanaRules (m_rpSkkRuleTree, hSubKey, srRomaKanaRuleTbl, RULETREENO_SKK_BASE, NUM_ROMAKANARULE))
				bExistUserDefinedRomaKanaRule	= TRUE ;
			if (_bParseRomaKanaRules (m_rpSkkJisx0201RomanRuleTree, hSubKey, srJisx0201RomanRuleTbl, RULETREENO_SKK_JISX0201_ROMAN, NUM_ROMAKANARULE))
				bExistUserDefinedRomaKanaRule	= TRUE ;
			if (_bParseRomaKanaRules (m_rpSkkJisx0201RuleTree, hSubKey, srJisx0201RuleTbl, RULETREENO_SKK_JISX0201_BASE, NUM_ROMAKANARULE))
				bExistUserDefinedRomaKanaRule	= TRUE ;
		}
		if (! bExistUserDefinedRomaKanaRule) {
			m_iRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
		}
skip_error:
		RegCloseKey (hSubKey) ;
	}
	if (! bRetval)
		goto	error_exit ;
	return	TRUE ;

error_exit:
	return	FALSE ;
}

BOOL
CImeConfig::_bParseRomaKanaRules (
	CSkkRuleTreeNode**		ppTree,
	HKEY					hSubKey,
	LPCWSTR*				ppwRuleName,
	int						nRuleBase,
	int						nRule)
{
	LPWSTR				pwData	= NULL ;
	CSkkRuleTreeNode*	pRoot ;
	int					i ;
	BOOL				bRetval ;
	LONG				lResult ;
	DWORD				dwType, cbData ;

	bRetval	= FALSE ;
	for (i = 0 ; i < nRule ; i ++) {
		/* roma-kana-rule �{�́B*/
		lResult	= RegQueryValueExW (hSubKey, ppwRuleName [i], NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) {
			ppTree [i]	= NULL ;
			continue ;
		}
		if (dwType != REG_MULTI_SZ) {
			ppTree [i]	= NULL ;
			continue ;
		}
		pwData	= (LPWSTR) new WCHAR [cbData] ;
		if (pwData == NULL)
			continue ;

		(void) RegQueryValueExW (hSubKey, ppwRuleName [i], NULL, &dwType, (BYTE*)pwData, &cbData) ;
		pRoot	= NULL ;
		if (_bParseRomaKanaRule (&pRoot, nRuleBase, i, pwData, cbData)) {
			ppTree [i]	= pRoot ;
			bRetval		= TRUE ;
		} else {
			ppTree [i]	= NULL ;
		}
		delete[]	pwData ;
		pwData	= NULL ;
	}
	return	bRetval ;
}

BOOL
CImeConfig::_bParseRomaKanaRule (
	CSkkRuleTreeNode**		ppTree,
	int						nRuleBase,
	int						nRule,
	LPCWSTR					pwData,
	int						cbData)
{
	CSkkRuleTreeNode*	pRoot	= NULL ;
	LPCWSTR		pwSrc, pwSrcEnd ;
	WCHAR		bufState [128], bufNext [128], bufNextRule [32], bufHira [128], bufKata [128] ;
	// WCHAR	bufRule [32] ;
	DCHAR		bufDState [128] ;
	int			nNextRule, nStateLen ;

	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	while (*pwSrc != L'\0' && pwSrc < pwSrcEnd) {
		int							nType ;
		LPCWSTR						pwNext ;

		nType	= *pwSrc ++ ;
		if (_bParseBSEncodedString(&pwSrc, bufState, countof(bufState)))
			goto	next_entry ;
		if (_bParseBSEncodedString(&pwSrc, bufNext, countof(bufNext)))
			goto	next_entry ;
		if (_bParseBSEncodedString(&pwSrc, bufNextRule, countof(bufNextRule)))
			goto	next_entry ;
		// bufState		[MYARRAYSIZE (bufState) - 1]	= L'\0' ;
		// bufRule		[MYARRAYSIZE (bufRule)  - 1]	= L'\0' ;
		// bufNext		[MYARRAYSIZE (bufNext)  - 1]	= L'\0' ;
		// bufNextRule	[MYARRAYSIZE (bufNextRule) - 1]	= L'\0' ;
		pwNext	= (bufNext [0] != L'\0')? bufNext : NULL ;
#if defined (__STDC_WANT_SECURE_LIB__)
		if (_snwscanf_s (bufNextRule, MYARRAYSIZE (bufNextRule), L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#else
		if (swscanf (bufNextRule, L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#endif

		switch (nType) {
		case	TEXT ('1'):
			if (_bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
				goto	next_entry ;
			if (!_bParseBSEncodedString(&pwSrc, bufKata, countof(bufKata)))
				goto	next_entry ;

			// bufHira [MYARRAYSIZE (bufHira) - 1]		= L'\0' ;
			// bufKata [MYARRAYSIZE (bufKata)  - 1]	= L'\0' ;

			nStateLen	= wcstodcs_n (bufDState, MYARRAYSIZE (bufDState), bufState, lstrlenW (bufState)) ;
			if (! CSkkRuleTreeNode::bAddRule (&pRoot, nRule + nRuleBase, bufDState, nStateLen, pwNext, lstrlenW (bufNext), nNextRule + nRuleBase, bufHira, lstrlenW (bufHira), bufKata, lstrlenW (bufKata))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('2'):
			if (!_bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
				goto	next_entry ;
			// bufHira [MYARRAYSIZE (bufHira) - 1]	= L'\0' ;

			nStateLen	= wcstodcs_n (bufDState, MYARRAYSIZE (bufDState), bufState, lstrlenW (bufState)) ;
			if (! CSkkRuleTreeNode::bAddRule (&pRoot, nRule + nRuleBase, bufDState, nStateLen, pwNext, lstrlenW (bufNext), nNextRule + nRuleBase, bufHira, lstrlenW (bufHira))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('3'):
			{
				int		nFuncNo	= 0 ;

				if (!_bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
					goto	next_entry ;
				// bufHira [MYARRAYSIZE (bufHira) - 1]	= L'\0' ;

#if defined (__STDC_WANT_SECURE_LIB__)
				if (_snwscanf_s (bufHira, MYARRAYSIZE (bufHira), L"%d", &nFuncNo) != 1)
					goto	next_entry ;
#else
				if (swscanf (bufHira, L"%d", &nFuncNo) != 1)
					goto	next_entry ;
#endif
				nStateLen	= wcstodcs_n (bufDState, MYARRAYSIZE (bufDState), bufState, lstrlenW (bufState)) ;
				if (! CSkkRuleTreeNode::bAddRule (&pRoot, nRule + nRuleBase, bufDState, nStateLen, pwNext, lstrlenW (bufNext), nNextRule + nRuleBase, nFuncNo)) {
					goto	error_exit ;
				}
			}
			break ;
		default:
			break ;
		}
next_entry:
		/* parse �Ɏ��s�����G���g���̏ꍇ nul �ɓ��B���Ă��Ȃ��̂ŁAnul �܂Ői�߂�B*/
		while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
			pwSrc ++ ;
		pwSrc	++ ;	/* nul �� skip */
	}
	if (ppTree != NULL) {
		*ppTree	= pRoot ;
	} else {
		CSkkRuleTreeNode::vDestroyTree (pRoot) ;
	}
	return	TRUE ;

error_exit:
	CSkkRuleTreeNode::vDestroyTree (pRoot) ;
	return	FALSE ;
}

void
CImeConfig::_vClearKeymaps ()
{
	_vClearKeymap (&m_MajorModeMap) ;
	_vClearKeymap (&m_SkkJModeMap) ;
	_vClearKeymap (&m_SkkLatinModeMap) ;
	_vClearKeymap (&m_SkkJisx0208LatinModeMap) ;
	_vClearKeymap (&m_SkkAbbrevModeMap) ;
	_vClearKeymap (&m_MinibufferMinorModeMap) ;

	if (m_pToggleImeKeys != _rDefaultToggleImeKeys && m_pToggleImeKeys != NULL)
		delete[]	m_pToggleImeKeys ;
	delete[]	m_pImeOnKeys ;
	delete[]	m_pImeOffKeys ;
	m_pToggleImeKeys	= NULL ;
	m_pImeOnKeys	= NULL ;
	m_pImeOffKeys	= NULL ;
	m_iNumberOfToggleImeKeys	= 0 ;
	m_iNumberOfImeOnKeys	= 0 ;
	m_iNumberOfImeOffKeys	= 0 ;
	return ;
}

void
CImeConfig::_vClearKeymap (struct CImeKeymap* pKeymap)
{
	if (pKeymap == NULL)
		return ;
	if (pKeymap->m_nKeyBinds > 0 && pKeymap->m_pKeyBinds != NULL)
		delete[]	pKeymap->m_pKeyBinds ;
	pKeymap->m_pKeyBinds	= NULL ;
	pKeymap->m_nKeyBinds	= 0 ;
	return ;
}

static void	setPreservedKeyWithChar (TF_PRESERVEDKEY* pDest, TCHAR ch)
{
	UINT	uVkKey ;

	switch (ch) {
	case	3:	// Control-C
		uVkKey	= (UINT)'C' | (1 << (8+1)) ;
		break ;
	case	8:	// Control-H
		uVkKey	= (UINT)'H' | (1 << (8+1)) ;
		break ;
	case	9:	// Control-I
		uVkKey	= (UINT)'I' | (1 << (8+1)) ;
		break ;
	case	10:	// Control-J
		uVkKey	= (UINT)'J' | (1 << (8+1)) ;
		break ;
	case	13:	// Control-M
		uVkKey	= (UINT)'M' | (1 << (8+1)) ;
		break ;
	case	27:	// Control-[
		uVkKey	= VkKeyScan ('[') ;
		uVkKey	|= (1 << (8+1)) ;
		break ;
	default:
		uVkKey = VkKeyScan (ch) ;
		break ;
	}
	pDest->uVKey		= uVkKey & 0x00FF ;
	pDest->uModifiers	= 0 ;
	if ((uVkKey & (1 << (8+0))) != 0)
		pDest->uModifiers	|= TF_MOD_SHIFT ;
	if ((uVkKey & (1 << (8+1))) != 0)
		pDest->uModifiers	|= TF_MOD_CONTROL ;
	if ((uVkKey & (1 << (8+2))) != 0)
		pDest->uModifiers	|= TF_MOD_ALT ;
	return ;
}

static void setPreservedKeyWithBind (TF_PRESERVEDKEY* pDest, const struct CImeKeyBind* pBind)
{
	pDest->uVKey	= pBind->m_nKeyCode ;
	pDest->uModifiers	= 0 ;
	if ((pBind->m_uKeyMask & (KEYMASK_LCONTROL | KEYMASK_RCONTROL)) == (KEYMASK_LCONTROL | KEYMASK_RCONTROL)) {
		pDest->uModifiers	|= TF_MOD_CONTROL ;
	} else {
		if ((pBind->m_uKeyMask & KEYMASK_LCONTROL) != 0)
			pDest->uModifiers	|= TF_MOD_LCONTROL ;
		if ((pBind->m_uKeyMask & KEYMASK_RCONTROL) != 0)
			pDest->uModifiers	|= TF_MOD_RCONTROL ;
	}
	if ((pBind->m_uKeyMask & (KEYMASK_LMENU | KEYMASK_RMENU)) == (KEYMASK_LMENU | KEYMASK_RMENU)) {
		pDest->uModifiers |= TF_MOD_ALT ;
	} else {
		if ((pBind->m_uKeyMask & KEYMASK_LMENU) != 0)
			pDest->uModifiers	|= TF_MOD_LALT ;
		if ((pBind->m_uKeyMask & KEYMASK_RMENU) != 0)
			pDest->uModifiers	|= TF_MOD_RALT ;
	}
	if ((pBind->m_uKeyMask & (KEYMASK_LSHIFT | KEYMASK_RSHIFT)) == (KEYMASK_LSHIFT | KEYMASK_RSHIFT)) {
		pDest->uModifiers |= TF_MOD_SHIFT ;
	} else {
		if ((pBind->m_uKeyMask & KEYMASK_LSHIFT) != 0)
			pDest->uModifiers	|= TF_MOD_LSHIFT ;
		if ((pBind->m_uKeyMask & KEYMASK_RSHIFT) != 0)
			pDest->uModifiers	|= TF_MOD_RSHIFT ;
	}
	return ;
}

void
CImeConfig::_InitializePreservedKeys (struct CImeKeymap* pKeymap)
{
	int	iNumberOfToggleImeKey, iNumberOfImeOnKey, iNumberOfImeOffKey ;
	const struct CImeKeyBind*	pBind ;
	TF_PRESERVEDKEY*	pToggleImeKey = NULL;
	TF_PRESERVEDKEY*	pImeOnKey = NULL;
	TF_PRESERVEDKEY*	pImeOffKey = NULL;
	int	i ;

	iNumberOfToggleImeKey = iNumberOfImeOnKey = iNumberOfImeOffKey = 0 ;
	if (pKeymap != NULL) {
		for (i = 0 ; i < SIZE_IMEDOC_KEYMAP ; i ++) {
			if (pKeymap->m_rbyBaseMap [i] == NFUNC_TOGGLE_IME)
				iNumberOfToggleImeKey	++ ;
			if (pKeymap->m_rbyBaseMap[i] == NFUNC_IMEMODE_ON)
				iNumberOfImeOnKey	++ ;
			if (pKeymap->m_rbyBaseMap[i] == NFUNC_IMEMODE_OFF)
				iNumberOfImeOffKey	++ ;
		}
		pBind	= pKeymap->m_pKeyBinds ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++, pBind ++) {
			if ((pBind->m_uKeyMask & (KEYMASK_SCROLL | KEYMASK_NUMLOCK)) == 0) {
				if (pBind->m_nKeyFunction == NFUNC_TOGGLE_IME)
					iNumberOfToggleImeKey	++ ;
				if (pBind->m_nKeyFunction == NFUNC_IMEMODE_ON)
					iNumberOfImeOnKey	++ ;
				if (pBind->m_nKeyFunction == NFUNC_IMEMODE_OFF)
					iNumberOfImeOffKey	++ ;
			}
		}
	}
	if (iNumberOfToggleImeKey <= 0) {
		m_iNumberOfToggleImeKeys	= ARRAYSIZE (_rDefaultToggleImeKeys) ;
		m_pToggleImeKeys			= _rDefaultToggleImeKeys ;
	} else {
		m_iNumberOfToggleImeKeys	= iNumberOfToggleImeKey + ARRAYSIZE (_rDefaultToggleImeKeys);
		m_pToggleImeKeys			= new TF_PRESERVEDKEY[m_iNumberOfToggleImeKeys] ;

		/* default �̐ݒ���R�s�[���Ă����B*/
		pToggleImeKey				= m_pToggleImeKeys ;
		memcpy (pToggleImeKey, _rDefaultToggleImeKeys, sizeof (_rDefaultToggleImeKeys)) ;
		pToggleImeKey				+= ARRAYSIZE (_rDefaultToggleImeKeys) ;
	}
	if (iNumberOfImeOnKey > 0) {
		m_iNumberOfImeOnKeys		= iNumberOfImeOnKey ;
		m_pImeOnKeys				= new TF_PRESERVEDKEY[iNumberOfImeOnKey] ;
		pImeOnKey					= m_pImeOnKeys ;
	} else {
		m_iNumberOfImeOnKeys		= 0 ;
		m_pImeOnKeys				= NULL ;
	}
	if (iNumberOfImeOffKey > 0) {
		m_iNumberOfImeOffKeys		= iNumberOfImeOffKey ;
		m_pImeOffKeys				= new TF_PRESERVEDKEY[iNumberOfImeOffKey] ;
		pImeOffKey					= m_pImeOffKeys ;
	} else {
		m_iNumberOfImeOffKeys		= 0 ;
		m_pImeOffKeys				= NULL ;
	}
	if (iNumberOfImeOnKey > 0 || iNumberOfImeOffKey > 0 || iNumberOfToggleImeKey > 0) {
		for (i = 0 ; i < SIZE_IMEDOC_KEYMAP ; i ++) {
			if (pKeymap->m_rbyBaseMap [i] == NFUNC_TOGGLE_IME) {
				setPreservedKeyWithChar(pToggleImeKey ++, (TCHAR)i) ;
			} else if (pKeymap->m_rbyBaseMap [i] == NFUNC_IMEMODE_ON) {
				setPreservedKeyWithChar(pImeOnKey ++, (TCHAR)i) ;
			} else if (pKeymap->m_rbyBaseMap [i] == NFUNC_IMEMODE_OFF) {
				setPreservedKeyWithChar(pImeOffKey ++, (TCHAR)i) ;
			}
		}
		pBind	= pKeymap->m_pKeyBinds ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++, pBind ++) {
			if (pBind->m_nKeyFunction == NFUNC_TOGGLE_IME) {
				setPreservedKeyWithBind (pToggleImeKey ++, pBind) ;
			} else if (pBind->m_nKeyFunction == NFUNC_IMEMODE_ON) {
				setPreservedKeyWithBind (pImeOnKey ++, pBind) ;
			} else if (pBind->m_nKeyFunction == NFUNC_IMEMODE_OFF) {
				setPreservedKeyWithBind (pImeOffKey ++, pBind) ;
			}
		}
	}
	return ;
}

/*========================================================================
 *	private functions (for Keybind)
 */

/// Generic�ݒ�̓ǂݍ���
/**
�Y�����郌�W�X�g���G���g��������Βl��ǂݍ��݁A�Ȃ��ꍇ�̓f�t�H���g�l��ݒ肷��B
�����I�ɃG���g�������݂���ꍇ�͓ǂ߂镔�������ǂݍ��ށB
*/
BOOL CImeConfig::_bLoadGenericSetting()
{
	/// �Œ蒷�G���g���ǂݍ��ݗp�e�[�u��
	static const struct {
		LPCTSTR info;
		DWORD* dest;
	} _srRegNumber[] = {
		{ REGINFO_KANAMODEWHENOPEN,		(DWORD*)&m_bKanaModeWhenOpen },
		{ REGINFO_ECHO,					(DWORD*)&m_bEcho },
		{ REGINFO_COMPOSITIONAUTOSHIFT,	(DWORD*)&m_bCompositionAutoShift },
		{ REGINFO_DELETEIMPLIESKAKUTEI,	(DWORD*)&m_bDeleteImpliesKakutei },
		{ REGINFO_KAKUTEIEARLY,			(DWORD*)&m_bKakuteiEarly },

		{ REGINFO_DATEAD,				(DWORD*)&m_bDateAd },
		{ REGINFO_NUMBERSTYLE,			(DWORD*)&m_iNumberStyle },

		{ REGINFO_KUTOUTENTYPE,			(DWORD*)&m_iKutoutenType },
		{ REGINFO_AUTOINSERTPAREN,		(DWORD*)&m_iBracketParenType },
		{ REGINFO_OKURICHARALISTTYPE,	(DWORD*)&m_iOkuriCharAlistType },
	};

	/// �ϒ��G���g���ǂݍ��ݗp�e�[�u��
	static const struct {
		LPCTSTR info;
		CTStringPairArray<1>* dest;
		int size;
	} _srRegString[] = {
		{ REGINFO_KUTOUTENS,		(CTStringPairArray<1>*)&m_Kutouten,			countof(m_Kutouten.m_rStringPair) },
		{ REGINFO_BRACKETPARENS ,	(CTStringPairArray<1>*)&m_BracketParen,		countof(m_BracketParen.m_rStringPair) },
		{ REGINFO_OKURICHARALIST,	(CTStringPairArray<1>*)&m_OkuriCharAlist,	countof(m_OkuriCharAlist.m_rStringPair) },
	};

	#include "../../common/kutouten.h"
	#include "../../common/bracket.h"

	HKEY hSubKey;
	int i;

	// �f�t�H���g�l�ݒ�
	m_bKanaModeWhenOpen		= TRUE;
	m_bEcho					= TRUE;
	m_bCompositionAutoShift	= TRUE;
	m_bDeleteImpliesKakutei	= TRUE;
	m_bKakuteiEarly			= TRUE;

	m_bDateAd				= FALSE;
	m_iNumberStyle			= 0;

	m_iKutoutenType			= KUTOUTEN_TYPE_JP;
	m_iBracketParenType		= BRACKETPARENTP_NONE;
	m_iOkuriCharAlistType	= OKURICHARTP_NONE;

	m_Kutouten.m_iCount			= 0;
	m_BracketParen.m_iCount		= 0;
	m_OkuriCharAlist.m_iCount	= 0;

	if (RegOpenKeyEx(HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS)
		goto skip_assume;

	// �Œ蒷�G���g��
	for (i = 0; i < countof(_srRegNumber); i++) {
		DWORD dwType, cbData = sizeof(DWORD);
		DWORD dwValue;
		LONG lResult = RegQueryValueEx(hSubKey, _srRegNumber[i].info, NULL, &dwType, (BYTE*)&dwValue, &cbData);
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			ASSERT(sizeof(DWORD) == sizeof(int) && sizeof(DWORD) == sizeof(BOOL));
			*_srRegNumber[i].dest = dwValue;	// BOOL�����̂܂܂ł����񂿂Ⴄ
		}
	}

	// �ϒ��G���g��
	for (i = 0; i < countof(_srRegString); i++) {
		DWORD dwType, cbData = 0;
		LONG lResult = RegQueryValueEx(hSubKey, _srRegString[i].info, NULL, &dwType, NULL, &cbData);
		if (lResult == ERROR_SUCCESS && dwType == REG_MULTI_SZ) {
			LPTSTR p = (LPTSTR)new BYTE[cbData];	// @memo ��������]���Ɋm�ۂ��Ă���o�O���C��
			if (p == NULL) continue;
			RegQueryValueEx(hSubKey, _srRegString[i].info, NULL, &dwType, (BYTE*)p, &cbData);
			_srRegString[i].dest->m_iCount = _iDecodeStringPairList(p, _srRegString[i].dest->m_rStringPair, _srRegString[i].size);
			delete[] p;
		}
	}

	RegCloseKey(hSubKey);
skip_assume:

	// ��Ǔ_����
	switch (m_iKutoutenType) {
	case KUTOUTEN_TYPE_JP:
		m_Kutouten.m_iCount = _iDecodeStringPairList(_srDefaultKutoutenJP, m_Kutouten.m_rStringPair, countof(m_Kutouten.m_rStringPair));
		break;
	case KUTOUTEN_TYPE_EN:
		m_Kutouten.m_iCount = _iDecodeStringPairList(_srDefaultKutoutenEN, m_Kutouten.m_rStringPair, countof(m_Kutouten.m_rStringPair));
		break;
	}

	// ���ʒ���
	switch (m_iBracketParenType) {
	case BRACKETPARENTP_DEFAULT:
		m_BracketParen.m_iCount = _iDecodeStringPairList(_srDefaultBracketParen, m_BracketParen.m_rStringPair, countof(m_BracketParen.m_rStringPair));
		break;
	}

	return TRUE;
}

/*========================================================================
 *	private functions for conversion
 */
BOOL
CImeConfig::_bLoadConversionSetting ()
{
	_bLoadConversionSettingFromRegistry();

	#include "../../common/menu_keys.h"

	int i;
	#define B2D(n, d, s) n = countof(s); for (i = 0; i < n; i++) d[i] = (DCHAR)s[i];

	// �Ȃ����̏����͏�̏������֐��ƕ����˂΂Ȃ�Ȃ������̂��H���Ƃō\����������
	switch (m_nCandListKeyAssign) {
	case	CANDLIST_KEYASSIGN_DEFAULT:
		/*
		m_nNumShowCandidateKeys		= MYARRAYSIZE (_srbDefaultCandidateKeys) ;
		m_nNumInputCodeMenu1Keys	= MYARRAYSIZE (_srbDefaultMenu1Keys) ;
		m_nNumInputCodeMenu2Keys	= MYARRAYSIZE (_srbDefaultMenu2Keys) ;
		memcpy (m_rwchShowCandidateKeys,	_srbDefaultCandidateKeys,	sizeof (_srbDefaultCandidateKeys)) ;
		memcpy (m_rwchInputCodeMenu1Keys,	_srbDefaultMenu1Keys,		sizeof (_srbDefaultMenu1Keys)) ;
		memcpy (m_rwchInputCodeMenu2Keys,	_srbDefaultMenu2Keys,		sizeof (_srbDefaultMenu2Keys)) ;
		*/
		B2D(m_nNumShowCandidateKeys, m_rwchShowCandidateKeys, _srbDefaultCandidateKeys);
		B2D(m_nNumInputCodeMenu1Keys, m_rwchInputCodeMenu1Keys, _srbDefaultMenu1Keys);
		B2D(m_nNumInputCodeMenu2Keys, m_rwchInputCodeMenu2Keys, _srbDefaultMenu2Keys);
		break ;
	case	CANDLIST_KEYASSIGN_01234567890:
		/*
		m_nNumShowCandidateKeys		= MYARRAYSIZE (_srb10Keys) ;
		m_nNumInputCodeMenu1Keys	= MYARRAYSIZE (_srb10Keys) ;
		m_nNumInputCodeMenu2Keys	= MYARRAYSIZE (_srb10Keys) ;
		memcpy (m_rwchShowCandidateKeys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (m_rwchInputCodeMenu1Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (m_rwchInputCodeMenu2Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		*/
		B2D(m_nNumShowCandidateKeys, m_rwchShowCandidateKeys, _srb10Keys);
		B2D(m_nNumInputCodeMenu1Keys, m_rwchInputCodeMenu1Keys, _srb10Keys);
		B2D(m_nNumInputCodeMenu2Keys, m_rwchInputCodeMenu2Keys, _srb10Keys);
		break ;
	}

/*
	// ���g�̏������O��num�ɒl���ݒ肳��Ă���(���̏㒆�g�̏�������ɂ�num�̒l���ω�����)�͔̂������Ȃ��̂ŏ���������ύX
	if (m_iNumAutoStartHenkanKeywords < 0) {
		_vInitAutoStartHenkanKeywords (_srDefaultAutoStartHenkanKeywords, MYARRAYSIZE (_srDefaultAutoStartHenkanKeywords)) ;
	}
*/
	return	TRUE ;
}

/// Conversion�Ɋւ���ݒ�����W�X�g������ǂݍ���
/**
m_iNumAutoStartHenkanKeywords�̏������Ƃ����ꂽ�ꏊ�ōs�Ȃ��Ă���悤�Ɍ����ēǂނ̂��h���̂�
�G���[�������̏����l�ݒ�͂��̊֐����Ɉړ������B
*/
BOOL
CImeConfig::_bLoadConversionSettingFromRegistry ()
{
	HKEY	hSubKey ;
	LONG	lResult ;
	DWORD	dwType, cbData, dwValue ;
	int		i ;
	BYTE	rbBuffer [MAX_NUMMENUKEYS] ;
	// BOOL	bRetval	= FALSE ;	// �X�e�[�g�ۑ��̓������̖���

	// �Ƃɂ����܂��͏�����
	m_nCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;
	m_nNumShowCandidateKeys			= 0 ;
	m_nNumInputCodeMenu1Keys		= 0 ;
	m_nNumInputCodeMenu2Keys		= 0 ;
	m_nShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;
	m_bHenkanOkuriStrictly			= FALSE ;
	m_bProcessOkuriEarly			= FALSE ;
	m_bHenkanStrictOkuriPrecedence	= FALSE ;
	m_bAutoStartHenkan				= TRUE ;
	m_bDeleteOkuriWhenQuit			= FALSE ;
	m_bAutoOkuriProcess				= FALSE ;
	m_nShowAnnotationType			= SHOW_NO_ANNOTATION ;

	// �������������� init �Ƃ��̒��ł��ׂ�
	// delete []	m_pAutoStartHenkanKeywords ;
	// m_pAutoStartHenkanKeywords		= NULL ;

	#include "../../common/auto_henkan.h"

	// ���g�̏������O��num�ɒl���ݒ肳��Ă���(���̏㒆�g�̏�������ɂ�num�̒l���ω�����)�͔̂������Ȃ��̂ŏ���������ύX
	// m_iNumAutoStartHenkanKeywords	= -1 ;
	_vInitAutoStartHenkanKeywords (_srDefaultAutoStartHenkanKeywords, MYARRAYSIZE (_srDefaultAutoStartHenkanKeywords)) ;

	// ���W�X�g������ǂݍ��� (���W�X�g���ɖ�肪�������ꍇ�͐ݒ�L�����Z��)
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_CONVERSION, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS)
		goto	skip_error_abort ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_CANDLISTKEYASSIGN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	int temp /* m_nCandListKeyAssign */	= (/*CANDLIST_KEYASSIGN_DEFAULT <= dwValue && */dwValue <= CANDLIST_KEYASSIGN_01234567890)? (int) dwValue : CANDLIST_KEYASSIGN_USERDEFINED ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_SHOWCANDIDATELISTCOUNT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;

	// ���W�X�g������ǂݍ��� (���������̓��W�X�g���ɖ�肪�����Ă��m���X�g�b�v)
	m_nCandListKeyAssign	= temp;
	m_nShowCandListCount	= (int) dwValue ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_HENKANOKURISTRICTLY, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bHenkanOkuriStrictly	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_PROCESSOKURIEARLY, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bProcessOkuriEarly	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_HENKANSTRICTOKURIPRECEDENCE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bHenkanStrictOkuriPrecedence	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_AUTOSTARTHENKAN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bAutoStartHenkan	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_DELETEOKURIWHENQUIT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bDeleteOkuriWhenQuit	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_AUTOOKURIPROCESS, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bAutoOkuriProcess	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_NUMERICCONVERSION, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bNumericConversion = (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_NUMERICFLOAT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bNumericFloat	= (dwValue != 0) ;

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (m_nCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			m_nCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		// m_nNumShowCandidateKeys	= 0 ;
	} else {
		(void) RegQueryValueExW (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++)
			m_rwchShowCandidateKeys [i]	= (DCHAR) rbBuffer [i] ;
//		memcpy(m_rwchShowCandidateKeys, rbBuffer, cbData);
		m_nNumShowCandidateKeys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (m_nCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			m_nCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		// m_nNumInputCodeMenu1Keys	= 0 ;
	} else {
		(void) RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++)
			m_rwchInputCodeMenu1Keys [i]	= (DCHAR) rbBuffer [i] ;
//		memcpy(m_rwchInputCodeMenu1Keys, rbBuffer, cbData);
		m_nNumInputCodeMenu1Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (m_nCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			m_nCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		// m_nNumInputCodeMenu2Keys	= 0 ;
	} else {
		(void) RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++)
			m_rwchInputCodeMenu2Keys [i]	= (DCHAR) rbBuffer [i] ;
//		memcpy(m_rwchInputCodeMenu2Keys, rbBuffer, cbData);
		m_nNumInputCodeMenu2Keys	= (int) cbData ;
	}

	// �������������� init �Ƃ��̒��ł��ׂ�
	// delete[]	m_pAutoStartHenkanKeywords ;
	// m_pAutoStartHenkanKeywords	= NULL ;

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ || cbData <= 0) {
		/* default �̐ݒ�B*/
		// ���g�̏������O��num�ɒl���ݒ肳��Ă���(���̏㒆�g�̏�������ɂ�num�̒l���ω�����)�͔̂������Ȃ��̂ŏ���������ύX
		// m_iNumAutoStartHenkanKeywords	= -1 ;	// �f�t�H���g�l�͐ݒ�ς�	// �����̋L�q�����͐ݒ萬�����A���s���̃f�t�H���g�ݒ�(�s�v�Ȃ珑���Ȃ��Ă���)�̏��ɋL�q���邩�A�������Ńf�t�H���g�l�������Ă���if��ʂ��ق������R�Ȃ̂ł�
	} else {
		LPWSTR	pwBuffer ;

		pwBuffer	= new WCHAR [cbData] ;
		if (pwBuffer != NULL) {
			(void) RegQueryValueExW (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, (BYTE*) pwBuffer, &cbData) ;

			_vInitAutoStartHenkanKeywords (pwBuffer, cbData) ;
			delete[]	pwBuffer ;
		}
	}

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD) {
		// m_nShowAnnotationType	= SHOW_NO_ANNOTATION ;
	} else {
		DWORD	dwValue ;
		(void) RegQueryValueExW (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;

		if (dwValue == (DWORD)DISABLE_ANNOTATION) {
			m_nShowAnnotationType	= DISABLE_ANNOTATION ;
		} else if (0 <= dwValue && dwValue <= SHOW_ANNOTATION_ALWAYS) {
			m_nShowAnnotationType	= (int) dwValue ;
		} else {
			m_nShowAnnotationType	= SHOW_NO_ANNOTATION ;
		}
	}

skip_error:
	RegCloseKey (hSubKey) ;
skip_error_abort:

	// �����Ɏc��̋��ʃ��[�g���ڐA

	return TRUE;

/*
skip_error:
	RegCloseKey (hSubKey) ;
skip_error_abort:
	return FALSE;	// �N�����ʂ��C�ɂ����Ⴂ�Ȃ�
*/
}

void
CImeConfig::_vInitAutoStartHenkanKeywords (LPCWSTR pwText, int nTextLen)
{
	LPCWSTR	pSrc, pSrcLast ;
	int		iNumKeywords ;
	int	nNeed, n ;

	pSrc			= pwText ;
	pSrcLast		= pwText + nTextLen ;
	nNeed			= 0 ;
	iNumKeywords	= 0 ;
	while (pSrc < pSrcLast && *pSrc != TEXT ('\0')) {
		n		= lstrlenW (pSrc) ;
		if (n > 0) {
			nNeed	+= wcstodcs_n (NULL, 0, pSrc, n) + 1 ;
			iNumKeywords	++ ;
		}
		pSrc	+= n + 1 ;
	}

	// �ȑO�̐ݒ���J��
	delete[]	m_pAutoStartHenkanKeywords ;
	m_pAutoStartHenkanKeywords	= NULL ;
	m_iNumAutoStartHenkanKeywords	= 0 ;

	// �V�����l��ݒ�
	if (iNumKeywords > 0) {
		m_pAutoStartHenkanKeywords	= new DCHAR [nNeed+1] ;

		if (m_pAutoStartHenkanKeywords != NULL) {
			LPDSTR	pwDest		= m_pAutoStartHenkanKeywords ;
			LPCDSTR	pwDestEnd	= pwDest + nNeed + 1 ;

			pSrc		= pwText ;
			pSrcLast	= pwText + nTextLen ;
			while (pSrc < pSrcLast && *pSrc != TEXT ('\0')) {
				n		= lstrlenW (pSrc) ;
				if (n > 0) {
					int	nDest ;

					nDest	= wcstodcs_n (pwDest, pwDestEnd - pwDest, pSrc, n) ;
					pwDest	+= nDest ;
					if (pwDest < pwDestEnd)
						*pwDest ++	= L'\0' ;
				}
				pSrc	+= n + 1 ;
			}
			if (pwDest < pwDestEnd)
				*pwDest ++	= L'\0' ;
			m_iNumAutoStartHenkanKeywords	= iNumKeywords ;
//		} else {
//			m_iNumAutoStartHenkanKeywords	= 0 ;
		}
//	} else {
//		m_pAutoStartHenkanKeywords	= NULL ;
//		m_iNumAutoStartHenkanKeywords	= 0 ;
	}
	return ;
}

/*========================================================================
 *	private functions for colorface
 */
static	BOOL	bIsValidColor		(int) ;
static	BOOL	bIsValidLineType	(int) ;

BOOL
CImeConfig::_bLoadColorfaceSetting ()
{
	#include "../../common/colorfaces.h"

	if (! _bLoadColorfaceSettingFromRegistry (_srDefaultColorFaces))
		memcpy (m_rImeColorFaces, _srDefaultColorFaces, sizeof (m_rImeColorFaces)) ;
	return	TRUE ;
}

BOOL
CImeConfig::_bLoadColorfaceSettingFromRegistry (
	const MYCOLORFACESET*	pDefaultColorFaces)
{
	HKEY	hSubKey ;
	BOOL	bRetval	= FALSE ;
	BYTE	rbStyles [MYARRAYSIZE (m_rImeColorFaces) * 4] ;
	int		i ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_STYLE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG		lResult ;
		DWORD		dwType, cbData ;
		const BYTE*	pbData ;

		lResult	= RegQueryValueExW (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData != sizeof (rbStyles))
			goto	skip_error ;

		(void) RegQueryValueExW (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, (BYTE*)rbStyles, &cbData) ;

		pbData	= rbStyles ;
		for (i = 0 ; i < MYARRAYSIZE (m_rImeColorFaces) ; i ++) {
			int		nTextColor, nBackColor, nUnderLineColor, nUnderLineType ;

			nTextColor		= *pbData ++ ;
			nTextColor		= bIsValidColor (nTextColor)? nTextColor : pDefaultColorFaces [i].m_nTextColor ;
			m_rImeColorFaces [i].m_nTextColor		= nTextColor ;
			nBackColor		= *pbData ++ ;
			nBackColor		= bIsValidColor (nBackColor)? nBackColor : pDefaultColorFaces [i].m_nBackColor ;
			m_rImeColorFaces [i].m_nBackColor		= nBackColor ;
			nUnderLineColor	= *pbData ++ ;
			nUnderLineColor	= bIsValidColor (nUnderLineColor)? nUnderLineColor : pDefaultColorFaces [i].m_nUnderLineColor ;
			m_rImeColorFaces [i].m_nUnderLineColor	= nUnderLineColor ;
			nUnderLineType	= *pbData ++ ;
			nUnderLineType	=  bIsValidLineType (nUnderLineType)? nUnderLineType : pDefaultColorFaces [i].m_nUnderLineType ;
			m_rImeColorFaces [i].m_nUnderLineType	= nUnderLineType ;
		}
		bRetval		= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	return	bRetval ;
}

void
CImeConfig::_vInitializeDefaultFont ()
{
	HKEY	hSubKey ;
	LOGFONT	lf ;
	NONCLIENTMETRICS	param ;

	// SPI_GETNONCLIENTMETRICS��_WIN32_WINNT >= 0x600�ō\���̃T�C�Y���ς��

	// m_iDefaultFontSize	= 0 ;	// �R���X�g���N�^�ȊO�ł͘M�炸�����ŃN���A���ׂ�

	// memset (&param, 0, sizeof (param)) ;	// �K�v�H
	param.cbSize	= sizeof (param) ;
	if (SystemParametersInfo (SPI_GETNONCLIENTMETRICS, param.cbSize, &param, 0)) {
		memcpy (&lf, &param.lfMessageFont, sizeof (LOGFONT)) ;
		m_iDefaultFontSize	= lf.lfHeight ;
	} else {
		memset (&lf, 0, sizeof (LOGFONT)) ;
		if (GetObject (GetStockObject (DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf) > 0) {
			m_iDefaultFontSize	= lf.lfHeight ;
		}
	}

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_STYLE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG	lResult ;
		DWORD	dwType, cbData ;
		WCHAR	bufFaceName [LF_FACESIZE] ;
		DWORD	dwFontSize ;

		cbData	= 0 ;
		lResult	= RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_SZ && cbData <= sizeof (bufFaceName)) {
			cbData	= sizeof (bufFaceName) ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, (BYTE*)bufFaceName, &cbData) ;

			memcpy (lf.lfFaceName, bufFaceName, LF_FACESIZE * sizeof (WCHAR)) ;
		}
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			cbData	= sizeof (DWORD) ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, (BYTE*)&dwFontSize, &cbData) ;

			m_iDefaultFontSize = (int) dwFontSize ;
		}
		RegCloseKey (hSubKey) ;
	}

	m_lfDefault = lf;	// memcpy (&m_lfDefault, &lf, sizeof (LOGFONT)) ;
	return ;
}

BOOL
bIsValidColor (int nColorType)
{
	return	(nColorType < 0 || nColorType >= MAX_MYCOLOR) ? FALSE : TRUE ;
}

BOOL
bIsValidLineType (int nLineType)
{
	return	(nLineType < 0 || nLineType >= MAX_MYLINE)? FALSE : TRUE ;
}

/// ���W�X�g���Ɋi�[���ꂽ�[���I�[������̈ꕔ���G�X�P�[�v�V�[�P���X���f�R�[�h���擾
/**
�f�R�[�h����G�X�P�[�v�V�[�P���X�� '\\' '0' �̂݁B����ȊO�̕����͂��̂܂܉��߂���B
�]�����̕����񂪓]����̃o�b�t�@��蒷���ꍇ�A�|�C���^�͍Ō�ɓ]�����������̒�����w���B���̏�ԂɊׂ�Ȃ��͈͂Ŏg�����Ƃ𐄏��B

����ƈقȂ�_
pbTerminated��p�~���Ԃ�l��p����
�o�b�t�@�T�C�Y��1�o�C�g�ȏ゠��ꍇ�A�K���I�[�����B1�������炵�Ĕԕ������Ȃ����K�v�Ȃ��B
��؂蕶���� ',' ��ǉ��B�z��O�̃G�X�P�[�v�V�[�P���X�̏ꍇ�ł��|�C���^���������i�ނ悤�C���B
*/
BOOL CImeConfig::_bParseBSEncodedString(
	LPCTSTR*	ppwSrc,
	LPTSTR		pwDest,
	int			nDestSize)
{
	LPCTSTR pwSrc = *ppwSrc;
	LPTSTR pwDestLast = pwDest + nDestSize - 1;
	while (*pwSrc && pwDest < pwDestLast) {
		TCHAR c = *pwSrc;
		if (c == SEPCHAR) {
			pwSrc++;
			break;
		}
		if (c == TEXT('\\')) {
			c = *++pwSrc;
			if (c == TEXT('0')) {
				pwSrc++;
				break;
			}
			if (c == TEXT('\0')) break;		// ��m��
		}
		*pwDest++ = c;
		pwSrc++;
	}
	if (pwDest <= pwDestLast) *pwDest = TEXT('\0');
	*ppwSrc = pwSrc;

	return *pwSrc == TEXT('\0');
}

/// ���W�X�g���Ɋi�[���ꂽMULTI_SZ�𕶎���y�A�Ƃ��Ď擾
/**
����A\\0����B\\0\0
����C\\0����D\\0\0\0
�Ƃ���'\\' '0'�̃G�X�P�[�v�V�[�P���X�ŋ�؂�ꂽMULTI_SZ������
�s�����O�̃Z�p���[�^�͏ȗ��\(������)

�����ł̒ǉ��@�\�Ƃ��Ĉȉ��̃p�^�[�������e��1�����Z�k�\�Ƃ���
����A,����B\0
����C,����D\0\0

�s���ȃf�[�^��ǂ݂��񂾏ꍇ�͏����𒆒f����B����ɓǂݍ��߂������͏������Ɏc���B
*/
int CImeConfig::_iDecodeStringPairList(
	LPCTSTR					pwEncodedString,
	struct TStringPair*		pDestBuffer,
	int						iBufferSize)
{
	struct TStringPair*		pDest ;
	struct TStringPair*		pDestEnd ;
	LPCTSTR	pwSrc ;
	TCHAR	bufLeft [BUFSIZE_STRPAIR], bufRight [BUFSIZE_STRPAIR] ;
	size_t n;

	pwSrc			= pwEncodedString ;
	pDest			= pDestBuffer ;
	pDestEnd		= pDestBuffer + iBufferSize ;
	while (*pwSrc && pDest < pDestEnd) {
		if (_bParseBSEncodedString(&pwSrc, bufLeft, countof(bufLeft))) {
			break ;
		}
		// bufLeft [MYARRAYSIZE (bufLeft) - 1]	= L'\0' ;
		if (!_bParseBSEncodedString(&pwSrc, bufRight, countof(bufRight))) {
			break ;
		}
		// bufRight [MYARRAYSIZE (bufRight) - 1]	= L'\0' ;

		n = wcstodcs(pDest->m_bufLeft, countof(pDest->m_bufLeft), bufLeft, lstrlen(bufLeft));
		pDest->m_bufLeft[n] = L'\0';
		n = wcstodcs(pDest->m_bufRight, countof(pDest->m_bufRight), bufRight, lstrlen(bufRight));
		pDest->m_bufRight[n] = L'\0';

		// MULTI_SZ�s���`�F�b�N�ς݂̂��ߕs�v
		// if (*pwSrc) break;
		pwSrc	++ ;
		pDest	++ ;
	}
	return	pDest - pDestBuffer ;
}

/*========================================================================
 *	private functions for RuleTreeNode
 */

/// char�����񂩂�wchar������֕ϊ����T�C�Y��Ԃ� (1�o�C�g������p, �I�[�����͂��Ȃ�)
static sizet alnumtowcs(wchar* wsz, sizet n, const char* sz)
{
	sizet i = 0;
	ASSERT(wsz);
	if (sz) {
		for (; i < n; i++) {
			if (sz[i] == '\0') break;
			wsz[i] = sz[i];
		}
	}
	return i;
}

/// �f�t�H���g�̃��[�}�����ȕϊ����[����ݒ肷��
BOOL CImeConfig::_bInitializeDefaultRomaKanaRuleTree()
{
	#include "../../common/roma_kana.h"

	// ������
	for (sizet i = 0 ; i < NUM_ROMAKANARULE; i++) {
		m_rpSkkRuleTree[i] = NULL;
		m_rpSkkJisx0201RuleTree[i] = NULL;
		m_rpSkkJisx0201RomanRuleTree[i] = NULL;
	}

	// �o�^
	for (TSkkBaseRule* p = _rDefaultRomaKanaRule; p < _rDefaultRomaKanaRule + countof(_rDefaultRomaKanaRule); p++) {
		wchar wszRule[16];
		wchar wszNext[16];
		DCHAR wszPrefix[16];
		sizet nRuleLen, nNextLen, nPrefixLen;
		sizet n;

		nRuleLen = alnumtowcs(wszRule, countof(wszRule), p->szRule);
		nNextLen = alnumtowcs(wszNext, countof(wszNext), p->szNext);
		nPrefixLen = wcstodcs(wszPrefix, countof(wszPrefix), wszRule, nRuleLen);
		n = p->nRule;
		ASSERT(n < NUM_ROMAKANARULE);
		if (p->nFunc == 0) {
			// �����o�^
			if (p->wszOut) {
				sizet nOut = lstrlenW(p->wszOut);
				if (p->wszKata) {
					sizet nKata = lstrlenW(p->wszKata);
					if (!CSkkRuleTreeNode::bAddRule(&m_rpSkkRuleTree[n], 0, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext, p->wszOut, nOut, p->wszKata, nKata)) {
					InitializeDefaultRomaKanaRuleTreeAbort:
						CSkkRuleTreeNode::vDestroyTree(m_rpSkkRuleTree[n]);
						m_rpSkkRuleTree[n] = NULL;
						CSkkRuleTreeNode::vDestroyTree(m_rpSkkJisx0201RuleTree[n]);
						m_rpSkkJisx0201RuleTree[n] = NULL;
						return FALSE;
					}
				} else {
					if (!CSkkRuleTreeNode::bAddRule(&m_rpSkkRuleTree[n], 0, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext, p->wszOut, nOut))
						goto InitializeDefaultRomaKanaRuleTreeAbort;
				}
			}
			if (p->wszKana) {	// JIS X 0201�������݂���ꍇ�͓o�^
				sizet nKana = lstrlenW(p->wszKana);
				if (!CSkkRuleTreeNode::bAddRule(&m_rpSkkJisx0201RuleTree[n], RULETREENO_SKK_JISX0201_BASE, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext + RULETREENO_SKK_JISX0201_BASE, p->wszKana, nKana))
					goto InitializeDefaultRomaKanaRuleTreeAbort;
			}
		} else {
			// �֐��o�^
			if (!CSkkRuleTreeNode::bAddRule(&m_rpSkkRuleTree[n], 0, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext, p->nFunc))
				goto InitializeDefaultRomaKanaRuleTreeAbort;
			if (p->wszKana == NULL) {	// JIS X 0201�������݂���ꍇ�͓o�^
				if (!CSkkRuleTreeNode::bAddRule(&m_rpSkkJisx0201RuleTree[n], RULETREENO_SKK_JISX0201_BASE, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext + RULETREENO_SKK_JISX0201_BASE, p->nFunc))
					goto InitializeDefaultRomaKanaRuleTreeAbort;
			}
		}
	}

	return TRUE;
}

