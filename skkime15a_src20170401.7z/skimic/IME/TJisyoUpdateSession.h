#pragma once

#include "dchar.h"
#include "TCommuSession.h"

class CTRecordSession : public CTCommunicateSession {
public:
	static	BOOL		bUpdate	(LPCDSTR, int, LPCDSTR, int, LPCDSTR, int, BOOL) ;
} ;

class CTPurgeSession : public CTCommunicateSession {
public:
	static	BOOL		bUpdate	(LPCDSTR, int, LPCDSTR, int, LPCDSTR, int, BOOL) ;
} ;

class	CTJisyoSaveSession : public CTCommunicateSession {
public:
	static	BOOL		bSynchronize () ;
} ;

class	CTRecordKakuteiHistorySession : public CTCommunicateSession {
public:
	static	BOOL		bUpdate (LPCDSTR, int, LPCDSTR, int) ;
} ;



