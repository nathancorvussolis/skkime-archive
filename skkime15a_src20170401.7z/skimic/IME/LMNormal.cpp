// #if !defined (UNITTEST)
#include "globals.h"
// #else
// #include "StdAfx.h"
// #endif

#include "ImeDoc.h"
#include "ImeBuffer.h"
// #include "TMarker.h"	// ImeBuffer.h �ƘA��
// #include "../../common/keymap.h"	// ImeBuffer.h �ƘA��

#define	IS_BLANKCHAR(ch)	((ch) == L' ' || (ch) == L'\t' || (ch) == '\n' || (ch) == '\r')
#define	IS_ASCIICHAR(ch)	(32 <= (ch) && (ch) < 128)

/*======================================================================== message-loop
 */
int
CImeDoc::LM_iMessageLoop (
	CImeDoc*			pThis)
{
	struct TMSG*	pMSG ;
	int				nFuncNo ;
	PLMFUNC			pPC	= NULL ;

	/*	MessageLoop �ɖ߂��Ă������� Recursive Edit �𔲂��鏈�������Ă����ꍇ�ɂ́A
	 *	�c
	 *	����A�����ŏ�������K�v������̂��l���Ȃ���΁B
	if (pThis->m_bExitReEdit) {
	}
	 */

	if (pThis->m_nUnreadMessages <= 0) {
		return	LMR_STOP ;
	}
	pThis->m_nUnreadMessages -- ;
	pMSG	= pThis->m_rMessages + pThis->m_nUnreadMessages ;
	if (pThis->bIgnoreMessagep (pMSG))
		return	LMR_CONTINUE ;

	pThis->m_iLastCommandChar	= pThis->iGetCharFromEvent (pMSG) ;
	if (! pThis->bLookupKeymap (pMSG, &nFuncNo)) 
		nFuncNo	= NFUNC_INVALID_CHAR ;

	pPC		= pThis->pLookupLMState (nFuncNo) ;
	if (pPC == NULL)
		return	LMR_CONTINUE ;	/* �������삪���蓖�Ă��ĂȂ��ꍇ�B*/

	/*	MessageLoop �� error �� quit �� signal �������B*/
	pThis->vClearSignals () ;
	pThis->m_iThisCommand	= nFuncNo ;
	pThis->m_LastEvent		= *pMSG ;

	if (pThis->m_pPreCommandHook != NULL) {
		if (! pThis->bPushReg (LMREG_0))
			return	LMR_ERROR ;
		pThis->vSetRegInteger (LMREG_0, nFuncNo) ;
		if (! pThis->bCall (pThis->m_pPreCommandHook, LM_iMessageLoop_1))
			return	LMR_ERROR ;
	} else {
		/* call-interactively �̐^�����B*/
		pThis->vSetRegNil (LMREGARG_0) ;
		if (! pThis->bCall (pPC, LM_iPostMessageLoop))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_iMessageLoop_1 (
	CImeDoc*			pThis)
{
	PLMFUNC	pPC ;
	int		nFuncNo ;

	if (! pThis->bGetRegInteger (LMREG_0, &nFuncNo)) 
		nFuncNo	= NFUNC_INVALID_CHAR ;

	pThis->vPopReg (LMREG_0) ;
	pPC		= pThis->pLookupLMState (nFuncNo) ;
	if (pPC == NULL) {
		/* �����ɗ��邱�Ƃ͖{�����肦�Ȃ��Ǝv���̂ł͂��邪�B*/
		pThis->vJump (LM_iPostMessageLoop) ;
		return	LMR_CONTINUE ;
	}
	/* call-interactively �̐^�����B*/
	pThis->vSetRegNil (LMREGARG_0) ;
	if (! pThis->bCall (pPC, LM_iPostMessageLoop))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_iPostMessageLoop (
	CImeDoc*			pThis)
{
	/* last-command �̍X�V�B*/
	pThis->m_iLastCommand	= pThis->m_iThisCommand ;

	/*	post-command-hook �̃^�C�~���O�͂������낤���H */
	if (pThis->m_pPostCommandHook != NULL) {
		if (! pThis->bPushReg (LMREG_0))
			return	LMR_ERROR ;

		pThis->vSetRegInteger (LMREG_0, pThis->nGetSignal ()) ;
		pThis->vClearSignals  () ;
		if (! pThis->bCall (pThis->m_pPostCommandHook, LM_iPostMessageLoop_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else {
		pThis->vJump (LM_iPostMessageLoop_2) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_iPostMessageLoop_1 (
	CImeDoc*			pThis)
{
	int		nSignal ;

	if (! pThis->bGetRegInteger (LMREG_0, &nSignal))
		nSignal	= LMSIGNAL_NONE ;
	pThis->vSetSignal (nSignal) ;
	pThis->vPopReg (LMREG_0) ;
	pThis->vJump (LM_iPostMessageLoop_2) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_iPostMessageLoop_2 (
	CImeDoc*			pThis)
{
	/*	������ minibuffer �𔲂��鏈��������B*/
	if (pThis->bSignalMinibuffp ()) {
		CImeBuffer*	pBuffer ;

		if (pThis->nGetSignal () == LMSIGNAL_EXIT_MINIBUFFER) {
			pThis->vClearSignals () ;
		} else {
			pThis->vSetSignal (LMSIGNAL_QUIT) ;
		}
		pBuffer	= pThis->pGetCurrentBuffer () ;
		if (pBuffer != NULL && pBuffer->pGetParent () != NULL)
			return	LMR_RETURN ;
	}
	pThis->vJump (LM_iMessageLoop) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== next-command-event
 */
int
CImeDoc::LM_bNextCommandEvent (
	CImeDoc*			pThis)
{
	struct TMSG*	pMSG ;

	if (pThis->m_nUnreadMessages <= 0) {
		return	LMR_STOP ;
	}
	pThis->m_nUnreadMessages -- ;
	pMSG	= pThis->m_rMessages + pThis->m_nUnreadMessages ;

	pThis->vSetRegMsg (LMREGARG_RETVAL, pMSG) ;
	return	LMR_RETURN ;
}

/*======================================================================== read-from-minibuffer
 */
int
CImeDoc::LM_bReadFromMinibuffer (
	CImeDoc*			pThis)
{
	CImeBuffer*	pNewBuffer ;
	CImeBuffer*	pCurBuffer ;
	LPCDSTR		pwText ;
	int			nText ;
	BOOL		bSkkModeOn ;

	if (! pThis->bGetRegConstString (LMREGARG_0, &pwText,   &nText)) {
		pwText		= NULL ;
		nText		= 0 ;
	}
	if (! pThis->bGetRegBool (LMREGARG_1, &bSkkModeOn))
		bSkkModeOn	= FALSE ;

	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}

	pNewBuffer	= pThis->pCreateBuffer (pwText, nText, bSkkModeOn) ;
	if (pNewBuffer == NULL) {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}
	pNewBuffer->vSetParent (pCurBuffer) ;

	pThis->vSetCurrentBuffer (pNewBuffer) ;
	pThis->vClearMessage () ;

	if (! pThis->bCall (LM_iMessageLoop, LM_bReadFromMinibuffer_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bReadFromMinibuffer_Exit (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	CImeBuffer*	pPrevBuffer ;
	LPDSTR				pwResult	= NULL ;
	int					nText ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}

	/*	current-buffer �����ɖ߂��B
	 */
	pPrevBuffer	= pBuffer->pGetParent () ;
	if (pPrevBuffer != NULL) {
		pThis->vSetCurrentBuffer (pPrevBuffer) ;
		/*	�s�v�ɂȂ��� buffer ���폜����B*/
		pThis->bDeleteBuffer (pBuffer) ;
	} else {
		/* ... fatal */
	}

	if (pThis->nGetSignal () == LMSIGNAL_QUIT) {
		/* abort �����̂Ȃ�A���͂����e�L�X�g�͂Ȃ��B���[��Asignal �͎c���ׂ��Ȃ̂��H */
		nText	= 0 ;
		pThis->vSetSignal (LMSIGNAL_QUIT) ;
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
	} else {
		LPCDSTR	pwText ;
		int		nResultSize ;

		pwResult	= pThis->pGetReturnBuffer (&nResultSize) ;
		if (pwResult != NULL) {
			pwText		= pBuffer->pBufferString (&nText) ;
			if (nText > 0) {
				nText	= MIN (nResultSize, nText) ;
				if (nText > 0) {
					memcpy (pwResult, pwText, nText * sizeof (DCHAR)) ;
				}
			} 
		} else {
			nText	= 0 ;
		}
		pThis->vSetRegConstString (LMREGARG_RETVAL, pwResult, nText) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== yes-or-no-p
 */
int
CImeDoc::LM_bYesOrNop (
	CImeDoc*		pThis)
{
	LPCDSTR		pwText ;
	int			nText ;

	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;

	if (! pThis->bGetRegConstString (LMREGARG_0, &pwText, &nText)) {
		pwText	= NULL ;
		nText	= 0 ;
	}
	pThis->vSetRegConstString (LMREG_0, pwText, nText) ;
	pThis->vJump (LM_bYesOrNop_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bYesOrNop_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pNewBuffer ;
	CImeBuffer*	pCurBuffer ;
	LPCDSTR		pwText ;
	int			nText ;

	if (! pThis->bGetRegConstString (LMREG_0, &pwText, &nText)) {
		pwText		= NULL ;
		nText		= 0 ;
	}
	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		pThis->vJump (LM_bYesOrNop_Exit) ;
		return	LMR_CONTINUE ;
	}

	pNewBuffer	= pThis->pCreateBuffer (pwText, nText, FALSE) ;
	if (pNewBuffer == NULL) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		pThis->vJump (LM_bYesOrNop_Exit) ;
		return	LMR_CONTINUE ;
	}
	pNewBuffer->vSetParent ( pCurBuffer) ;

	if (! pThis->bPushReg (LMREG_0)) {
		pThis->bDeleteBuffer (pNewBuffer) ;
		return	LMR_ERROR ;
	}
	pThis->vSetCurrentBuffer (pNewBuffer) ;
	pThis->vClearMessage () ;

	if (! pThis->bCall (LM_iMessageLoop, LM_bYesOrNop_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bYesOrNop_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	CImeBuffer*	pPrevBuffer ;
	BOOL				bRetval	= FALSE ;
	BOOL				bRetry	= FALSE ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}

	if (pThis->nGetSignal () == LMSIGNAL_QUIT) {
		/* abort �����̂Ȃ�A���͂����e�L�X�g�͂Ȃ��B���[��Asignal �͎c���ׂ��Ȃ̂��H */
		pThis->vSetSignal (LMSIGNAL_QUIT) ;
		bRetry	= FALSE ;
	} else {
		LPCDSTR	pwText ;
		int		nText ;

		pwText	= pBuffer->pBufferString ( &nText) ;
		if (nText > 0) {
			static const DCHAR	c_bufYes []	= { L'y', L'e', L's', L'\0' } ;
			static const DCHAR	c_bufNo  []	= { L'n', L'o', L'\0' } ;
			LPCDSTR	ptrLast, ptrTop ;

			ptrLast	= pwText + nText - 1 ;
			while (ptrLast >= pwText && isdspace (*ptrLast))
				ptrLast	-- ;
			ptrTop	= pwText ;
			while (ptrTop <= ptrLast && isdspace (*ptrTop))
				ptrTop	++ ;
			nText	= ptrLast - ptrTop + 1 ;
			pwText	= ptrTop ;

			if (! dcsnicmp (pwText, c_bufYes, nText)) {
				bRetval	= TRUE ;
			} else if (! dcsnicmp (pwText, c_bufNo, nText)) {
				bRetval	= FALSE ;
			} else {
				/* retry */
				bRetry	= TRUE ;
			}
		} else {
			bRetry	= TRUE ;
		}
	}
	/*	current-buffer �����ɖ߂��B
	 */
	pPrevBuffer	= pBuffer->pGetParent () ;
	if (pPrevBuffer != NULL) {
		pThis->vSetCurrentBuffer (pPrevBuffer) ;
		/*	�s�v�ɂȂ��� buffer ���폜����B*/
		pThis->bDeleteBuffer (pBuffer) ;
	} else {
		/* ... fatal */
	}
	if (bRetry) {
		pThis->vJump (LM_bYesOrNop_1) ;
		return	LMR_CONTINUE ;
	} 
exit_func:
	pThis->vSetRegBool (LMREGARG_RETVAL, bRetval) ;
	pThis->vJump (LM_bYesOrNop_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bYesOrNop_Exit (
	CImeDoc*			pThis)
{
	pThis->vPopReg (LMREG_0) ;
	return	LMR_RETURN ;
}

/*======================================================================== self-insert-character
 */
int
CImeDoc::LM_bSelfInsertCharacter (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR				wCH ;
	CTMarker*		pmkPoint ;

	/*	signal ���ݒ肳��Ă���Γ��삵�Ȃ��B
	 *	�Ƃ������A���̔���𖈉�Ă΂ꂽ���ɏ����̂͂Ȃ��c�B
	 */
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	/*	printable �ȃC�x���g���ǂ����`�F�b�N����B
	 */
	if (! pThis->bGetLastCommandChar (&wCH)) {
		return	LMR_RETURN ;
	}
	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->iInsert ( pmkPoint, &wCH, 1) <= 0) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== backward-char
 */
int
CImeDoc::LM_bBackwardChar (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkTop ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pmkTop->iGetPosition () < pmkPoint->iGetPosition ()) {
		if (! pmkPoint->bBackward (1)) {
			pThis->vSetSignalError () ;
		}
	} else {
		/*	�����ŃG���[�t���b�O�𗧂Ă邩�ǂ����́A�󋵎��悾���c�B
		 */
		pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== forward-char
 */
int
CImeDoc::LM_bForwardChar (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkEnd ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pmkPoint->iGetPosition () < pmkEnd->iGetPosition ()) {
		if (! pmkPoint->bForward (1)) {
			pThis->vSetSignalError () ;
		}
	} else {
		/*	�����ŃG���[�t���b�O�𗧂Ă邩�ǂ����́A�󋵎��悾���c�B
		 */
		pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== delete-char
 */
int
CImeDoc::LM_bDeleteChar (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkEnd ;
	int					nPoint ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	nPoint	= pmkPoint->iGetPosition () ;
	if (nPoint < pmkEnd->iGetPosition ()) {
		if (! pBuffer->bDeleteRegion (nPoint, nPoint + 1)) {
			pThis->vSetSignalError () ;
		}
	} else {
		pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
} 

/*======================================================================== backward-delete-char
 */
int
CImeDoc::LM_bBackwardDeleteChar (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkTop ;
	int					nPoint ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	nPoint	= pmkPoint->iGetPosition () ;
	if (nPoint > 0 && nPoint > pmkTop->iGetPosition ()) {
		if (! pBuffer->bDeleteRegion ( nPoint - 1, nPoint)) {
			pThis->vSetSignalError () ;
		}
	} else {
		pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== transpose-chars
 */
int
CImeDoc::LM_bTransposeChars (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkTop ;
	CTMarker*		pmkEnd ;
	int				nPoint, nBufferTop, nBufferEnd, nLength ;
	DCHAR			wch ;
	LPCDSTR			wstrText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL || 
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	nPoint		= pmkPoint->iGetPosition () ;
	nBufferEnd	= pmkEnd->iGetPosition () ;
	nBufferTop	= pmkTop->iGetPosition () ;
	if (nPoint >= nBufferEnd || nPoint < (nBufferTop + 1)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	wstrText	= pBuffer->pBufferString (&nLength) ;
	wch			= wstrText [nPoint - 1] ;
	if (! pBuffer->bDeleteRegion (nPoint - 1, nPoint) || 
		! pmkPoint->bForward (1) ||
		pBuffer->iInsert (pmkPoint, &wch, 1) <= 0) {
		pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== end-of-line
 */
BOOL
CImeDoc::LM_bEndOfLine (
	CImeDoc*				pThis)
{
	CImeBuffer*		pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkEnd ;
	int				nPoint, nBufferEnd, nPointBak, nLength ;
	LPCDSTR			wstrText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	nPoint		= pmkPoint->iGetPosition () ;
	nBufferEnd	= pmkEnd->iGetPosition () ;
	wstrText	= pBuffer->pBufferRawString ( &nLength) ;
	nPointBak	= nPoint ;
	while (nPoint < nBufferEnd && nPoint < nLength) {
		if (wstrText [nPoint] == L'\n') 
			break ;
		nPoint	++ ;
	}
	if (! pmkPoint->bForward (nPoint - nPointBak)) {
		pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== beginning-of-line
 */
BOOL
CImeDoc::LM_bBeginningOfLine (
	CImeDoc*				pThis)
{
	CImeBuffer*	pCurBuffer ;
	CTMarker*	pmkPoint ;
	CTMarker*	pmkTop ;
	CTMarker*	pmkEnd ;
	int			nPoint, nTop, nBufferEnd ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	nBufferEnd		= pmkEnd->iGetPosition () ;
	if (pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nTop	= pmkTop->iGetPosition () ;
	} else {
		nTop	= 0 ;
	}
	nPoint	= pmkPoint->iGetPosition () ;
	if (nPoint > nTop) {
		LPCDSTR	wstrText	= pCurBuffer->pBufferRawString ( NULL) ;
		nPoint	-- ;
		while (nPoint > nTop) {
			if (wstrText [nPoint] == L'\n') {
				nPoint	++ ;
				break ;
			}
			nPoint	-- ;
		}
		pmkPoint->bBackward (pmkPoint->iGetPosition () - nPoint) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== set-mark-command
 */
BOOL
CImeDoc::LM_bSetMarkCommand (
	CImeDoc*				pThis)
{
	CImeBuffer*	pCurBuffer ;
	CTMarker*	pmkPoint ;
	CTMarker*	pmkMark ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_MARK, &pmkMark)) {
		pmkMark	= NULL ;
	}
	if (! pThis->bSetMessage (L"Mark Set") || 
		! pCurBuffer->bSetMarker (&pmkMark, CImeBuffer::MARKER_MARK, pmkPoint)) {
		pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== keyboard-quit
 */
int
CImeDoc::LM_bKeyboardQuit (
	CImeDoc*				pThis)
{
	CImeBuffer*	pCurBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL) {
		pThis->vSetSignal (LMSIGNAL_QUIT) ;
		return	LMR_RETURN ;
	}
	if (! pThis->bCall (LM_bSkkAdKeyboardQuit, LM_bKeyboardQuit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bKeyboardQuit_1 (
	CImeDoc*				pThis)
{
	BOOL	bDone ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bGetRegBool (LMREGARG_RETVAL, &bDone))
		bDone	= FALSE ;
	if (! bDone) {
		/*	inhibit-quit ���Ȃ��Ƃ܂��������c�B
		 */
		/*	keyboard-quit ���N�ɂ��������ꂸ�ɗ���ė����ꍇ�A�Ăяo�����ɕԂ�
		 *	�K�v�����邩������Ȃ��B
		 */
		if (! pThis->bProcessEventp ()) {
			(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
			return	LMR_RETURN ;
		}
		pThis->vSetSignal (LMSIGNAL_QUIT) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== exit-recursive-edit
 */
int
CImeDoc::LM_bExitRecursiveEdit (
	CImeDoc*				pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}
	if (! pThis->bCall (LM_bSkkAdExitMinibuffer, LM_bExitRecursiveEdit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bExitRecursiveEdit_1 (
	CImeDoc*				pThis)
{
	BOOL	bDone ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bGetRegBool (LMREGARG_RETVAL, &bDone))
		bDone	= FALSE ;
	if (! bDone) {
		if (pThis->bRecursiveEditp ()) {
			pThis->vSetSignal (LMSIGNAL_EXIT_MINIBUFFER) ;
		}
	}
	return	LMR_RETURN ;
}

/*======================================================================== abort-recursive-edit
 */
int
CImeDoc::LM_bAbortRecursiveEdit (
	CImeDoc*				pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}
	if (! pThis->bCall (LM_bSkkAdAbortRecursiveEdit, LM_bAbortRecursiveEdit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bAbortRecursiveEdit_1 (
	CImeDoc*				pThis)
{
	BOOL	bDone ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bGetRegBool (LMREGARG_RETVAL, &bDone))
		bDone	= FALSE ;
	if (! bDone) {
		if (pThis->bRecursiveEditp ()) {
			pThis->vSetSignal (LMSIGNAL_ABORT_RECURSIVE_EDIT) ;
		}
	}
	return	LMR_RETURN ;
}

/*======================================================================== new-line
 */
int
CImeDoc::LM_bNewline (
	CImeDoc*				pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}
	if (! pThis->bCall (LM_bSkkAdNewline, LM_bNewline_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bNewline_1 (
	CImeDoc*				pThis)
{
	BOOL	bProcess ;

	if (! pThis->bGetRegBool (LMREGARG_RETVAL, &bProcess))
		bProcess	= FALSE ;
	if (! bProcess) 
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
	return	LMR_RETURN ;
}

/*======================================================================== next-line
 */
int
CImeDoc::LM_bNextLine (
	CImeDoc*				pThis)
{
	CImeBuffer*		pCurBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkEnd ;
	CTMarker*		pmkTop ;
	int				nPosition, nBufferEnd, nBufferTop, nPoint, nOffset, nText ;
	LPCDSTR			pwText, pwPos ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}
	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL) {
		pThis->vSetSignal (LMSIGNAL_QUIT) ;
		return	LMR_RETURN ;
	}
	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= pmkTop->iGetPosition () ;
	} else {
		nBufferTop	= 0 ;
	}
	nBufferEnd		= pmkEnd->iGetPosition () ;
	nPoint			= pmkPoint->iGetPosition () ;
	pwText			= pCurBuffer->pBufferRawString ( &nText) ;

	if (pThis->iGetLastCommand () != NFUNC_NEXT_LINE && pThis->iGetLastCommand () != NFUNC_PREVIOUS_LINE) {
		/*	�I�t�Z�b�g�̌v�Z�������B
		 */
		nPosition	= nPoint ;
		pwPos		= pwText + pmkPoint->iGetPosition () ;
		while (nPosition >= nBufferTop && *pwPos != L'\n') {
			pwPos		-- ;
			nPosition	-- ;
		}
		nOffset		= nPoint - nPosition ;
	} else {
		/*	�O��̃I�t�Z�b�g�̍ė��p�B
		 */
		nOffset		= pCurBuffer->iGetLineOffset () ;
	}

	/*	�ŏ��̈ʒu�ɖ߂��B
	 */
	nPosition	= nPoint ;
	pwPos		= pwText + pmkPoint->iGetPosition () ;
	while (nPosition < nBufferEnd) {
		if (*pwPos == L'\n') 
			break ;
		pwPos		++ ;
		nPosition	++ ;
	}
	if (nPosition < nBufferEnd && *pwPos == L'\n') {
		int			n	= nOffset ;
		nPosition	++ ;
		pwPos		++ ;
		while (nPosition < nBufferEnd && *pwPos != L'\n' && n > 0) {
			pwPos		++ ;
			nPosition	++ ;
			nOffset		-- ;
		}
	} else {
		nPosition	= nBufferEnd ;
	}

	/*	���ă}�[�J���ړ������悤�B
	 */
	if (nPosition > nPoint) {
		/* �o�b�t�@�̍Ō�܂ŗ��Ă�����A���s������Ƃ������V������̂����B*/
		pmkPoint->bForward (nPosition - nPoint) ;
	}

	/*	����̃I�t�Z�b�g���L�����Ă������B
	 */
	pCurBuffer->vSetLineOffset (nOffset) ;
	return	LMR_RETURN ;
}

/*======================================================================== new-line
 */
int
CImeDoc::LM_bPreviousLine (
	CImeDoc*				pThis)
{
	CImeBuffer*		pCurBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkEnd ;
	CTMarker*		pmkTop ;
	int				nPosition, nBufferEnd, nBufferTop, nPoint, nOffset, nText ;
	LPCDSTR			pwText, pwPos ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}
	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL) {
		pThis->vSetSignal (LMSIGNAL_QUIT) ;
		return	LMR_RETURN ;
	}
	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= pmkTop->iGetPosition () ;
	} else {
		nBufferTop	= 0 ;
	}
	nBufferEnd		= pmkEnd->iGetPosition () ;
	nPoint			= pmkPoint->iGetPosition () ;
	pwText			= pCurBuffer->pBufferRawString (&nText) ;

	if (pThis->iGetLastCommand () != NFUNC_NEXT_LINE && pThis->iGetLastCommand () != NFUNC_PREVIOUS_LINE) {
		/*	�I�t�Z�b�g�̌v�Z�������B
		 */
		nPosition	= nPoint ;
		pwPos		= pwText + pmkPoint->iGetPosition () ;
		while (nPosition >= nBufferTop && *pwPos != L'\n') {
			pwPos		-- ;
			nPosition	-- ;
		}
		nOffset		= nPoint - nPosition ;
	} else {
		/*	�O��̃I�t�Z�b�g�̍ė��p�B
		 */
		nOffset		= pCurBuffer->iGetLineOffset () ;
	}

	/*	�ŏ��̈ʒu�ɖ߂��B
	 */
	nPosition	= nPoint ;
	pwPos		= pwText + pmkPoint->iGetPosition () ;
	while (nBufferTop <= nPosition && *pwPos != L'\n') {
		pwPos		-- ;
		nPosition	-- ;
	}
	if (nBufferTop < nPosition && *pwPos == L'\n') {
		int		n ;

		pwPos		-- ;
		nPosition	-- ;
		while (nBufferTop <= nPosition && *pwPos != L'\n') {
			pwPos		-- ;
			nPosition	-- ;
		}
		if (nBufferTop <= nPosition && *pwPos == L'\n') {
			/* 1�߂��Ă���v�Z�B*/
			pwPos		++ ;
			nPosition	++ ;
		} else {
			/* buffer-top ����v�Z�B*/
			pwPos		= pwText + nBufferTop ;
			nPosition	= nBufferTop ;
		}

		/*	offset �ʒu�ɂ��킹��B
		 */
		n	= nOffset ;
		while (nPosition < nPoint && n > 0 && *pwPos != L'\n') {
			pwPos		++ ;
			nPosition	++ ;
			n			-- ;
		}
	} else {
		nPosition	= nBufferTop ;
	}

	/*	���ă}�[�J���ړ������悤�B
	 */
	if (nPosition < nPoint) {
		/* �o�b�t�@�̍Ō�܂ŗ��Ă�����A���s������Ƃ������V������̂����B*/
		pmkPoint->bBackward (nPoint - nPosition) ;
	}

	/*	����̃I�t�Z�b�g���L�����Ă������B
	 */
	pCurBuffer->vSetLineOffset (nOffset) ;
	return	LMR_RETURN ;
}

/*======================================================================== backward-word
 */
int
CImeDoc::LM_bBackwardWord (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkTop ;
	int				nBufferTop, nPoint, nPointBak, nText ;
	LPCDSTR			pwText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	nBufferTop		= pmkTop->iGetPosition () ;
	nPoint			= pmkPoint->iGetPosition () ;
	nPointBak		= nPoint ;
	pwText			= pBuffer->pBufferRawString (&nText) ;

	if (nBufferTop < nPoint) {
		nPoint	-- ;
		while (nBufferTop < nPoint && IS_BLANKCHAR (pwText [nPoint]))
			nPoint	-- ;
		if (nBufferTop < nPoint) {
			if (IS_ASCIICHAR (pwText [nPoint])) {
				while (nBufferTop <= nPoint) {
					if (IS_BLANKCHAR (pwText [nPoint]) || ! IS_ASCIICHAR (pwText [nPoint])) 
						break ;
					nPoint -- ;
				}
			} else {
				while (nBufferTop <= nPoint) {
					if (IS_BLANKCHAR (pwText [nPoint]) || IS_ASCIICHAR (pwText [nPoint])) 
						break ;
					nPoint -- ;
				}
			}
			nPoint	++ ;
		}
	}
	if (nPoint < nPointBak) {
		if (! pmkPoint->bBackward (nPointBak - nPoint)) 
			pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== forward-word
 */
int
CImeDoc::LM_bForwardWord (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkTop ;
	CTMarker*		pmkEnd ;
	int				nBufferTop, nBufferEnd, nPoint, nPointBak, nText ;
	LPCDSTR			pwText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bProcessEventp ()) {
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL ||
		! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	nBufferTop		= pmkTop->iGetPosition () ;
	nBufferEnd		= pmkEnd->iGetPosition () ;
	nPoint			= pmkPoint->iGetPosition () ;
	nPointBak		= nPoint ;
	pwText			= pBuffer->pBufferRawString (&nText) ;
	if (nPoint < nBufferEnd) {
		if (IS_ASCIICHAR (pwText [nPoint])) {
			while (nPoint < nBufferEnd && ! IS_BLANKCHAR (pwText [nPoint]) && IS_ASCIICHAR (pwText [nPoint]))
				nPoint	++ ;
		} else {
			while (nPoint < nBufferEnd && ! IS_BLANKCHAR (pwText [nPoint]) && ! IS_ASCIICHAR (pwText [nPoint]))
				nPoint	++ ;
		}
		while (nPoint < nBufferEnd && IS_BLANKCHAR (pwText [nPoint]))
			nPoint	++ ;
	}
	if (nPoint > nPointBak) {
		if (! pmkPoint->bForward (nPoint - nPointBak)) 
			pThis->vSetSignalError () ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== ...
 */
int
CImeDoc::LM_bUnprecessEvent (
	CImeDoc*				pThis)
{
	if (! pThis->bProcessEventp ()) {
		/*	��芸�����C�x���g�𑗂�Ԃ����Ƃɂ���B
		 */
		(void) pThis->bUnprocessEvent (pThis->pGetLastCommandEvent ()) ;
	}
	return	LMR_RETURN ;
}


