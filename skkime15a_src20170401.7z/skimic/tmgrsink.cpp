/*	tmgrsink.cpp
 *
 *	ITfThreadMgrEventSink implementation.
 */
#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"

/*	OnInitDocumentMgr
 *
 *	Sink called by the framework just before the first context is pushed onto
 *	a document.
 */
STDAPI
CSkkImeTextService::OnInitDocumentMgr (
	ITfDocumentMgr*		pDocMgr)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnInitDocumentMgr (%p)\n"), pDocMgr)) ;
#if defined (DEBUG) || defined (_DEBUG)
	if (pDocMgr != NULL) {
		ITfCompartmentMgr*	pCompMgr	= NULL ;
		HRESULT	hr ;

		hr	= pDocMgr->QueryInterface (IID_ITfCompartmentMgr, (void**)&pCompMgr) ;
		if (SUCCEEDED (hr)) {
			DumpCompartment (pCompMgr) ;
			pCompMgr->Release () ;
		}
	}
#endif
    return	S_OK ;
	UNREFERENCED_PARAMETER (pDocMgr) ;
}

/* OnUninitDocumentMgr
 *
 *	Sink called by the framework just after the last context is popped off a
 *	document.
 */
STDAPI
CSkkImeTextService::OnUninitDocumentMgr (
	ITfDocumentMgr*		pDocMgr)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnUninitDocumentMgr (%p)\n"), pDocMgr)) ;
    return	S_OK ;
	UNREFERENCED_PARAMETER (pDocMgr) ;
}

//+---------------------------------------------------------------------------
//
// OnSetFocus
//
// Sink called by the framework when focus changes from one document to
// another.  Either document may be NULL, meaning previously there was no
// focus document, or now no document holds the input focus.
//----------------------------------------------------------------------------
STDAPI
CSkkImeTextService::OnSetFocus (
	ITfDocumentMgr*		pDocMgrFocus, 
	ITfDocumentMgr*		pDocMgrPrevFocus)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnSetFocus (now:%p, prev:%p)\n"), pDocMgrFocus, pDocMgrPrevFocus)) ;

    // we'll track edit changes in the focus document, the only place we start compositions
    _InitTextEditSink (pDocMgrFocus) ;
	_UpdateLangBarItem () ;

#if defined (DEBUG) || defined (_DEBUG)
	if (pDocMgrFocus != NULL) {
		ITfCompartmentMgr*	pCompMgr	= NULL ;
		HRESULT	hr ;

		hr	= pDocMgrFocus->QueryInterface (IID_ITfCompartmentMgr, (void**)&pCompMgr) ;
		if (SUCCEEDED (hr)) {
			DumpCompartment (pCompMgr) ;
			pCompMgr->Release () ;
		}
	}
#endif
	return	S_OK ;
	UNREFERENCED_PARAMETER (pDocMgrPrevFocus) ;
}

//+---------------------------------------------------------------------------
//
// OnPushContext
//
// Sink called by the framework when a context is pushed.
//----------------------------------------------------------------------------

STDAPI
CSkkImeTextService::OnPushContext (
	ITfContext*			pContext)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnPushContext (%p)\n"), pContext)) ;

	// ignore new contexts that appear while were uninitializing
    if (!m_fCleaningUp) {
        _InitCleanupContextSink (pContext) ;
	}
    return	S_OK ;
}

//+---------------------------------------------------------------------------
//
// OnPopContext
//
// Sink called by the framework when a context is popped.
//----------------------------------------------------------------------------

STDAPI
CSkkImeTextService::OnPopContext (
	ITfContext*			pContext)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::OnPopContext (%p)\n"), pContext)) ;
    _UninitCleanupContextSink (pContext) ;
    return	S_OK ;
}

//+---------------------------------------------------------------------------
//
// _InitThreadMgrSink
//
// Advise our sink.
//----------------------------------------------------------------------------

BOOL
CSkkImeTextService::_InitThreadMgrSink ()
{
    return	AdviseSink (
		m_pThreadMgr,
		(ITfThreadMgrEventSink *)this,
		IID_ITfThreadMgrEventSink,
		&m_dwThreadMgrEventSinkCookie) ;
}

//+---------------------------------------------------------------------------
//
// _UninitThreadMgrSink
//
// Unadvise our sink.
//----------------------------------------------------------------------------
void
CSkkImeTextService::_UninitThreadMgrSink ()
{
    UnadviseSink (m_pThreadMgr, &m_dwThreadMgrEventSinkCookie) ;
	return ;
}
