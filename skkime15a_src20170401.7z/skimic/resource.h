#if !defined (RESOURCE_H)
#define	RESOURCE_H

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//

#define IDD_DIALOG_REGISTER_WORD		101

#define IDI_SKKIME						1
#define IDI_CMODE_HIRAGANA				2		// IMECMODE_HIRAGANA
#define IDI_CMODE_ZENKATA				3		// IMECMODE_KATAKANA
#define IDI_CMODE_ZENEI					4		// IMECMODE_ZENKAKU
#define IDI_CMODE_HANKATA				5		// IMECMODE_HANKANA
#define IDI_CMODE_HANROMA				6		// IMECMODE_HANKANA_ROMAN
#define IDI_CMODE_HANEI					7		// IMECMODE_ASCII
#define IDI_CMODE_DIRECT				8		// IMECMODE_OFF

#define IDC_EDIT_REGISTER_KEY			1001
#define IDC_COMBO_OKURI_MOJI			1002
#define IDC_RADIO_OKURI_ARI				1004
#define IDC_RADIO_OKURI_NASHI			1005
#define IDC_EDIT_REGISTER_WORD			1006
#define IDC_STATIC						-1

#define	IDM_CUT							40011
#define	IDM_PASTE						40012
#define	IDM_COPY						40013
#define	IDM_DELETE						40014

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE		136
#define _APS_NEXT_COMMAND_VALUE			40015
#define _APS_NEXT_CONTROL_VALUE			1007
#define _APS_NEXT_SYMED_VALUE			2000
#endif
#endif

#endif
