#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "CandListUI.h"
#include "ToolTipUI.h"

BOOL
CSkkImeTextService::_InitUIElements (DWORD dwFlags)
{
	if (m_pCandidateListUIElement == NULL) {
		m_pCandidateListUIElement	= new CSkkImeCandidateListUIElement (this) ;
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
		if (m_pCandidateListUIElement != NULL)
			m_pCandidateListUIElement->_Init ((dwFlags & TF_TMAE_CONSOLE) != 0) ;
#else
		if (m_pCandidateListUIElement != NULL)
			m_pCandidateListUIElement->_Init (FALSE) ;
#endif
	}
	if (m_pToolTipUIElement == NULL) {
		m_pToolTipUIElement			= new CSkkImeToolTipUIElement (this) ;
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
		if (m_pToolTipUIElement != NULL)
			m_pToolTipUIElement->_Init ((dwFlags & TF_TMAE_CONSOLE) != 0) ;
#else
		if (m_pToolTipUIElement != NULL)
			m_pToolTipUIElement->_Init (FALSE) ;
#endif
	}
	return	TRUE ;
}

void
CSkkImeTextService::_UninitUIElements ()
{
	if (m_pCandidateListUIElement != NULL) {
		m_pCandidateListUIElement->_Uninit () ;
		m_pCandidateListUIElement->Release () ;
		m_pCandidateListUIElement	= NULL ;
	}
	if (m_pToolTipUIElement != NULL) {
		m_pToolTipUIElement->_Uninit () ;
		m_pToolTipUIElement->Release () ;
		m_pToolTipUIElement	= NULL ;
	}
	return ;
}

HRESULT
CSkkImeTextService::_BeginToolTipUI (
	DWORD*				pdwToolTipId,
	BOOL*				pbShow)
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	DEBUGPRINTF ((TEXT ("[enter] CSkkImeTextService::_BeginToolTipUI ()\n"))) ;
	if (m_pThreadMgr == NULL || m_pToolTipUIElement == NULL) {
		DEBUGPRINTF ((TEXT ("[leave] CSkkImeTextService::_BeginToolTipUI () failed.\n"))) ;
		return	E_FAIL ;
	}
	hr	= m_pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr)) {
		DEBUGPRINTF ((TEXT ("[leave] CSkkImeTextService::_BeginToolTipUI () failed (hr:0x%0x).\n"), hr)) ;
		return	hr ;
	}
	hr	= pUIElementMgr->BeginUIElement (m_pToolTipUIElement, pbShow, pdwToolTipId) ;
	pUIElementMgr->Release () ;
	DEBUGPRINTF ((TEXT ("[leave] CSkkImeTextService::_BeginToolTipUI ()\n"))) ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_EndToolTipUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (m_pThreadMgr == NULL || m_pToolTipUIElement == NULL)
		return	E_FAIL ;
	if (! m_pToolTipUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= m_pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->EndUIElement (m_pToolTipUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_UpdateToolTipUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (m_pThreadMgr == NULL || m_pToolTipUIElement == NULL)
		return	E_FAIL ;
	if (! m_pToolTipUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= m_pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->UpdateUIElement (m_pToolTipUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_BeginCandidateListUI (
	DWORD*				pdwToolTipId,
	BOOL*				pbShow)
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (m_pThreadMgr == NULL || m_pCandidateListUIElement == NULL)
		return	E_FAIL ;
	hr	= m_pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;
	hr	= pUIElementMgr->BeginUIElement (m_pCandidateListUIElement, pbShow, pdwToolTipId) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_EndCandidateListUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (m_pThreadMgr == NULL || m_pCandidateListUIElement == NULL)
		return	E_FAIL ;
	if (! m_pCandidateListUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= m_pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->EndUIElement (m_pCandidateListUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

HRESULT
CSkkImeTextService::_UpdateCandidateListUI ()
{
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	ITfUIElementMgr*	pUIElementMgr	= NULL ;
	HRESULT				hr ;

	if (m_pThreadMgr == NULL || m_pCandidateListUIElement == NULL)
		return	E_FAIL ;
	if (! m_pCandidateListUIElement->_IsActivep (NULL))
		return	S_FALSE ;

	hr	= m_pThreadMgr->QueryInterface (IID_ITfUIElementMgr, (void**)&pUIElementMgr) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pUIElementMgr->UpdateUIElement (m_pCandidateListUIElement->_GetUIElementId ()) ;
	pUIElementMgr->Release () ;
	return	hr ;
#else
	return	E_NOINTERFACE ;
#endif
}

CSkkImeToolTipUIElement*
CSkkImeTextService::_GetToolTipUI () 
{
	return	m_pToolTipUIElement ;
}

CSkkImeCandidateListUIElement*
CSkkImeTextService::_GetCandidateListUI () 
{
	return	m_pCandidateListUIElement ;
}

