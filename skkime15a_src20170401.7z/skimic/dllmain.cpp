//
// dllmain.cpp
//
// DllMain module entry point.
//

#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "CandListUI.h"
#include "ToolTipUI.h"

//+---------------------------------------------------------------------------
//
// DllMain
//
//----------------------------------------------------------------------------

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	switch (dwReason) {
	case DLL_PROCESS_ATTACH:
		g_hInst = hInstance;
#ifndef WINDOW_CLASS_AUX
		CSkkImeCandidateListUIElement::_Register();
		CSkkImeToolTipUIElement::_Register();
#endif	// WINDOW_CLASS_AUX
		if (!::InitializeCriticalSectionAndSpinCount(&g_cs, 0))
			return FALSE;
		break;

	case DLL_PROCESS_DETACH:
		::DeleteCriticalSection(&g_cs);
		break;
	}
	return TRUE;

	UNREFERENCED_PARAMETER(pvReserved);
}
