/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * uinotify.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_5.h"

static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlGetCandidatePos 	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlGetCompositionFont	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlGetCompositionWindow(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlGetStatusWindowPos	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlSetCandidatePos		(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlSetStatusWindowPos	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlSetCompositionFont	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlSetCompositionWindow(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlCloseStatusWindow	(HIMC, HWND, UINT, WPARAM, LPARAM) ;
static	LRESULT	PASCAL	tSkkImeWnd_lOnImeControlOpenStatusWindow	(HIMC, HWND, UINT, WPARAM, LPARAM) ;

/*************************************************************************
 *	WM_IME_CONTROL
 *------------------------------------------------------------------------
 *(�R�����g)
 *	WM_IME_CONTROL �́c�B

#define IMC_GETCANDIDATEPOS             0x0007
#define IMC_SETCANDIDATEPOS             0x0008
#define IMC_GETCOMPOSITIONFONT          0x0009
#define IMC_SETCOMPOSITIONFONT          0x000A
#define IMC_GETCOMPOSITIONWINDOW        0x000B
#define IMC_SETCOMPOSITIONWINDOW        0x000C
#define IMC_GETSTATUSWINDOWPOS          0x000F
#define IMC_SETSTATUSWINDOWPOS          0x0010
#define IMC_CLOSESTATUSWINDOW           0x0021
#define IMC_OPENSTATUSWINDOW            0x0022

 *************************************************************************/
LONG	PASCAL
TSkkImeWnd_lOnImeControl (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	static	LRESULT	(PASCAL *rpImcFunctionTable [])(HIMC, HWND, UINT, WPARAM, LPARAM) = {
		NULL,											NULL,
		NULL,											NULL,
		NULL,											NULL,
		NULL,											tSkkImeWnd_lOnImeControlGetCandidatePos,
		tSkkImeWnd_lOnImeControlSetCandidatePos,		tSkkImeWnd_lOnImeControlGetCompositionFont,
		tSkkImeWnd_lOnImeControlSetCompositionFont,		tSkkImeWnd_lOnImeControlGetCompositionWindow,
		tSkkImeWnd_lOnImeControlSetCompositionWindow,	NULL,
		NULL,											tSkkImeWnd_lOnImeControlGetStatusWindowPos,
		tSkkImeWnd_lOnImeControlSetStatusWindowPos,		NULL,
		NULL,											NULL,
		NULL,											NULL,
		NULL,											NULL,
		NULL,											NULL,
		NULL,											NULL,
		NULL,											NULL,
		NULL,											NULL,
		NULL,											tSkkImeWnd_lOnImeControlCloseStatusWindow,
		tSkkImeWnd_lOnImeControlOpenStatusWindow,		
	} ;
	int		nCommand	= (int) wParam ;

	if (nCommand < 0 ||
		nCommand >= ARRAYSIZE (rpImcFunctionTable) ||
		rpImcFunctionTable [nCommand] == NULL) {
		return	1L ;	/* �����łȂ���΁A��Z��Ԃ��B*/
	}
	return	(rpImcFunctionTable [nCommand])(hUICurIMC, hWnd, message, wParam, lParam) ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlGetCandidatePos (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPINPUTCONTEXT	lpIMC ;

	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;

	/* SKKIME has only one candidate list. */
	*(LPCANDIDATEFORM)lParam	= lpIMC->cfCandForm [0] ; 
	ImmUnlockIMC (hUICurIMC) ;
	return	0L ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlGetCompositionFont (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPINPUTCONTEXT	lpIMC ;
	LPLOGFONT		lpLogFont ;

	lpLogFont	= (LPLOGFONT) lParam ;
	if (! lpLogFont)
		return	1L ;

	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;
	*lpLogFont	= lpIMC->lfFont.W ;
	ImmUnlockIMC (hUICurIMC) ;
	return	0L ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlGetCompositionWindow (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONFORM	lpCOMPOSITIONFORM ;

	lpCOMPOSITIONFORM	= (LPCOMPOSITIONFORM) lParam ;
	if (! lpCOMPOSITIONFORM)
		return	1L ;

	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;

	*lpCOMPOSITIONFORM	= lpIMC->cfCompForm ;
	ImmUnlockIMC (hUICurIMC) ;
	return	0L ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlGetStatusWindowPos (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPINPUTCONTEXT	lpIMC ;
	POINTS			pt ;

	pt.x	= -1 ;
	pt.y	= -1 ;
	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (lpIMC) {
		HGLOBAL		hUIExtra ;
		LPUIEXTRA	lpUIExtra ;

		hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		if (IsWindow (lpUIExtra->uiStatus.hWnd)) {
			pt.x	= (SHORT) lpUIExtra->uiStatus.pt.x ;
			pt.y	= (SHORT) lpUIExtra->uiStatus.pt.y ;
		}
		GlobalUnlock (hUIExtra) ;
	}
	ImmUnlockIMC (hUICurIMC) ;
	return	((WORD)pt.x | ((DWORD)((WORD)pt.y) << 16)) ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlSetCandidatePos (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	/*	The UI window does not receive this message. */
	return	1L ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlSetStatusWindowPos (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LRESULT			lRetval	= 1L ;
	LPINPUTCONTEXT	lpIMC ;
	HGLOBAL			hUIExtra ;
	LPUIEXTRA		lpUIExtra ;
	POINTS			ptsPT ;

	ptsPT.x	= (SHORT) LOWORD (lParam) ;
	ptsPT.y	= (SHORT) HIWORD (lParam) ;
	lpIMC	= ImmLockIMC (hUICurIMC) ;
	if (!lpIMC)
		return	1L ;

	hUIExtra	= (HGLOBAL)GetWindowLongPtr (hWnd, IMMGWLP_PRIVATE) ;
	lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra);
	UIStatus_Move (lpUIExtra, &ptsPT) ;
	GlobalUnlock (hUIExtra) ;
	ImmUnlockIMC (hUICurIMC) ;
	return	lRetval ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlSetCompositionFont (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	/*	The UI window does not receive this message. */
	return	1L ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlSetCompositionWindow (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	/*	The UI window does not receive this message. */
	return	1L ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlCloseStatusWindow (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	/*	what to do? */
	return	1L ;
}

LRESULT	PASCAL
tSkkImeWnd_lOnImeControlOpenStatusWindow (
	HIMC		hUICurIMC,
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	/*	what to do? */
	return	1L ;
}


