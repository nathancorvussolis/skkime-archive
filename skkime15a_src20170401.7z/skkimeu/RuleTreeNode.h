#pragma once

enum {
	NTYPE_MACRO,
	NTYPE_STRING,
	NTYPE_STRINGPAIR,
} ;

struct	CSkkRuleTreeNode ;
struct	CSkkRuleTreeNodeOutput ;

/* */
BOOL	TSkkRuleTreeNode_bAddRuleSP		(struct CSkkRuleTreeNode**, int, LPCDSTR, int, LPCWSTR, int, int, LPCWSTR, int, LPCWSTR, int) ;
BOOL	TSkkRuleTreeNode_bAddRuleS		(struct CSkkRuleTreeNode**, int, LPCDSTR, int, LPCWSTR, int, int, LPCWSTR, int) ;
BOOL	TSkkRuleTreeNode_bAddRuleM		(struct CSkkRuleTreeNode**, int, LPCDSTR, int, LPCWSTR, int, int, int) ;

void	TSkkRuleTreeNode_vDestroyTree	(struct CSkkRuleTreeNode*) ;
LPCDSTR	TSkkRuleTreeNode_pGetPrefix		(const struct CSkkRuleTreeNode*, int*) ;
struct CSkkRuleTreeNode*				TSkkRuleTreeNode_pSelectBranch	(struct CSkkRuleTreeNode*, int) ;
LPCDSTR	TSkkRuleTreeNode_pGetNextState	(const struct CSkkRuleTreeNode*, int*, int*) ;
struct CSkkRuleTreeNode*				TSkkRuleTreeNode_pGetBranchList (struct CSkkRuleTreeNode*) ;

const struct CSkkRuleTreeNodeOutput*	TSkkRuleTreeNode_pGetOutput		(const struct CSkkRuleTreeNode*) ;

/* */
struct CSkkRuleTreeNodeOutput*			TSkkRuleTreeNodeOutput_pCreateStringPairInstance	(LPCDSTR, int, LPCDSTR, int) ;
struct CSkkRuleTreeNodeOutput*			TSkkRuleTreeNodeOutput_pCreateMacroInstance			(int) ;
struct CSkkRuleTreeNodeOutput*			TSkkRuleTreeNodeOutput_pCreateStringInstance		(LPCDSTR, int) ;
void	TSkkRuleTreeNodeOutput_vDestroy		(struct CSkkRuleTreeNodeOutput*) ;

int		TSkkRuleTreeNodeOutput_iGetType		(const struct CSkkRuleTreeNodeOutput*) ;
BOOL	TSkkRuleTreeNodeOutput_bGetMacro	(const struct CSkkRuleTreeNodeOutput*, int* pnFuncNo) ;
BOOL	TSkkRuleTreeNodeOutput_bGetString	(const struct CSkkRuleTreeNodeOutput*, LPCDSTR*, int*) ;
BOOL	TSkkRuleTreeNodeOutput_bGetLString	(const struct CSkkRuleTreeNodeOutput*, LPCDSTR*, int*) ;
BOOL	TSkkRuleTreeNodeOutput_bGetRString	(const struct CSkkRuleTreeNodeOutput*, LPCDSTR*, int*) ;

