/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * subs.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_5.h"
#include "resource.h"
#include "ImeConfig.h"

void	PASCAL
TSkkIme_vInitCompStr (
	LPCOMPOSITIONSTRING		lpCompStr,
	DWORD					dwClrFlag)
{
	lpCompStr->dwSize = sizeof (MYCOMPSTR) ;

	if (dwClrFlag & CLR_UNDET){
		lpCompStr->dwCompReadAttrOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->bCompReadAttr - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwCompReadClauseOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->dwCompReadClause - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwCompReadStrOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->szCompReadStr - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwCompAttrOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->bCompAttr - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwCompClauseOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->dwCompClause - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwCompStrOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->szCompStr - (LONG_PTR)lpCompStr) ;

		lpCompStr->dwCompStrLen			= 0 ;
		lpCompStr->dwCompReadStrLen		= 0 ;
		lpCompStr->dwCompAttrLen		= 0 ;
		lpCompStr->dwCompReadAttrLen	= 0 ;
		lpCompStr->dwCompClauseLen		= 0 ;
		lpCompStr->dwCompReadClauseLen	= 0 ;

		*GETLPCOMPSTR (lpCompStr)		= MYTEXT('\0') ;
		*GETLPCOMPREADSTR (lpCompStr)	= MYTEXT('\0') ;

		lpCompStr->dwCursorPos			= 0 ;
	}
	if (dwClrFlag & CLR_RESULT){
		lpCompStr->dwResultStrOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->szResultStr - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwResultClauseOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->dwResultClause - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwResultReadStrOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->szResultReadStr - (LONG_PTR)lpCompStr) ;
		lpCompStr->dwResultReadClauseOffset = 
			(DWORD)((LONG_PTR)((LPMYCOMPSTR)lpCompStr)->dwResultReadClause - (LONG_PTR)lpCompStr) ;

		lpCompStr->dwResultStrLen			= 0 ;
		lpCompStr->dwResultClauseLen		= 0 ;
		lpCompStr->dwResultReadStrLen		= 0 ;
		lpCompStr->dwResultReadClauseLen	= 0 ;

		*GETLPRESULTSTR(lpCompStr)			= MYTEXT ('\0') ;
		*GETLPRESULTREADSTR(lpCompStr)		= MYTEXT ('\0') ;
	}
	((LPMYCOMPSTR)lpCompStr)->dwShowStyle	= 0 ;
	((LPMYCOMPSTR)lpCompStr)->_fComposing	= FALSE ;
	return ;
}

void	PASCAL
TSkkIme_vClearCompStr (
	LPCOMPOSITIONSTRING			lpCompStr,
	DWORD						dwClrFlag)
{
	lpCompStr->dwSize	= sizeof(MYCOMPSTR) ;

	if (dwClrFlag & CLR_UNDET){
		lpCompStr->dwCompStrOffset						= 0 ;
		lpCompStr->dwCompClauseOffset					= 0 ;
		lpCompStr->dwCompAttrOffset						= 0 ;
		lpCompStr->dwCompReadStrOffset					= 0 ;
		lpCompStr->dwCompReadClauseOffset				= 0 ;
		lpCompStr->dwCompReadAttrOffset					= 0 ;
		lpCompStr->dwCompStrLen							= 0 ;
		lpCompStr->dwCompClauseLen 						= 0 ;
		lpCompStr->dwCompAttrLen 						= 0 ;
		lpCompStr->dwCompReadStrLen 					= 0 ;
		lpCompStr->dwCompReadClauseLen 					= 0 ;
		lpCompStr->dwCompReadAttrLen 					= 0 ;
		((LPMYCOMPSTR)lpCompStr)->szCompStr[0] 			= MYTEXT ('\0') ;
		((LPMYCOMPSTR)lpCompStr)->szCompReadStr[0]		= MYTEXT ('\0') ;
		lpCompStr->dwCursorPos							= 0 ;
	}
	if (dwClrFlag & CLR_RESULT){
		lpCompStr->dwResultStrOffset					= 0 ;
		lpCompStr->dwResultClauseOffset					= 0 ;
		lpCompStr->dwResultReadStrOffset				= 0 ;
		lpCompStr->dwResultReadClauseOffset				= 0 ;
		lpCompStr->dwResultStrLen						= 0 ;
		lpCompStr->dwResultClauseLen					= 0 ;
		lpCompStr->dwResultReadStrLen					= 0 ;
		lpCompStr->dwResultReadClauseLen				= 0 ;
		((LPMYCOMPSTR)lpCompStr)->szResultStr[0]		= MYTEXT ('\0') ;
		((LPMYCOMPSTR)lpCompStr)->szResultReadStr[0]	= MYTEXT ('\0') ;
	}
	return ;
}

void	PASCAL TSkkIme_vClearCandidate (LPCANDIDATEINFO lpCandInfo)
{
	lpCandInfo->dwSize			= 0L ;
	lpCandInfo->dwCount			= 0L ;
	lpCandInfo->dwOffset[0]		= 0L ;
	
	((LPMYCAND)lpCandInfo)->cl.dwSize		= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwStyle		= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwCount		= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwSelection	= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwPageStart	= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwPageSize	= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwOffset[0]	= 0L ;
	return ;
}

/*
 *
 *	TSkkIme_bHasCompStrp (hIMC)
 *
 */
BOOL	PASCAL TSkkIme_bHasCompStrp(HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	BOOL				fRet	= FALSE ;

	lpIMC	= ImmLockIMC(hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize(lpIMC->hCompStr) < sizeof (COMPOSITIONSTRING)){
		ImmUnlockIMC (hIMC) ;
		return	FALSE ;
	}

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC(lpIMC->hCompStr) ;
	fRet		= (lpCompStr->dwCompStrLen > 0) ;

	ImmUnlockIMCC (lpIMC->hCompStr) ;
	ImmUnlockIMC (hIMC) ;

	return	fRet ;
}

BOOL PASCAL TSkkIme_bHasConvertedCompStrp (HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	BOOL				fRet	= FALSE ;

	lpIMC	= ImmLockIMC(hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR)){
		ImmUnlockIMC (hIMC) ;
		return	FALSE ;
	}

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;

	if (lpCompStr->dwCompStrLen > 0)
		fRet	= (((LPMYCOMPSTR)lpCompStr)->bCompAttr[0] > 0) ;

	ImmUnlockIMCC (lpIMC->hCompStr) ;
	ImmUnlockIMC (hIMC) ;

	return	fRet ;
}

BOOL PASCAL 
TSkkIme_bHasCandidateListp (
	LPINPUTCONTEXT		lpIMC)
{
	LPCANDIDATEINFO	lpCandInfo ;
	BOOL			fRet	= FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCandInfo) < sizeof (CANDIDATEINFO)){
		return	FALSE ;
	}
	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	fRet		= (lpCandInfo->dwCount > 0) ;
	ImmUnlockIMCC (lpIMC->hCandInfo) ;
	return	fRet ;
}

/*
 *
 *	  TSkkIme_hGetHKL()
 *
 */
HKL PASCAL
TSkkIme_hGetHKL (void)
{
	DWORD	dwSize ;
	DWORD	dwi ;
	HKL		hKL	= 0 ;
	HKL*	lphkl ;

	dwSize	= GetKeyboardLayoutList (0, NULL) ;
	lphkl	= (HKL *)GlobalAlloc (GPTR, dwSize * sizeof (HKL)) ;
	if (!lphkl)
		return NULL ;
	GetKeyboardLayoutList (dwSize, lphkl) ;
	for (dwi = 0 ; dwi < dwSize ; dwi++){
		TCHAR	szFile [32] ;
		HKL		hKLTemp	= *(lphkl + dwi) ;
		ImmGetIMEFileName (hKLTemp, szFile, sizeof (szFile) / sizeof (TCHAR)) ;

		if (!lstrcmpi (szFile, MyFileName)){
			 hKL	= hKLTemp ;
			 goto	exit ;
		}
	}
exit:
	GlobalFree ((HANDLE)lphkl) ;
	return	hKL ;
}

#ifdef TARGET_WIN2K
/*
 *
 *	TSkkIme_vUpdateIndicIcon (hIMC)
 *
 */
void	PASCAL
TSkkIme_vUpdateIndicIcon (HIMC hIMC)
{
	HWND			hwndIndicate ;
	LPINPUTCONTEXT	lpIMC ;
	ATOM			atomTip ;
	int				iMode ;
	int				iIconIndex ;
	LPCTSTR			pTipTable [NUM_IMECMODE + 1]		= {
		TEXT ("���ȓ���"),
		TEXT ("�J�i����"),
		TEXT ("�S�p"),
		TEXT ("���p�J�i"),
		TEXT ("���p�p��"),
		TEXT ("�A�X�L�[����"),
		TEXT ("���ړ���"),	
		TEXT ("����"),
	} ;
	HWND			hwndFore ;
	DWORD			dwProcessId ;

	/*	���\�[�X�t�@�C�� (SKKI1_5U.RC) �ɓo�^����Ă��鏇�Ԃ� CMODEINDEX_ �̑Ή���
	 *	�Ƃ邽�߂̃e�[�u���D
	 */
	int				iIconIndexTbl [NUM_IMECMODE + 1]	= {
		3,	/* INDICICONC	ICON	DISCARDABLE		"..\\kanaindi.ico" �� index */
		4,	/* INDICICOND	ICON	DISCARDABLE		"..\\kataindi.ico" �� index */
		7,	/* �ȉ��C���l�ɑ����c */
		5,
		6,
		2,
		8,	/* INDICICONH	ICON	DISCARDABLE		"..\\direindi.ico" �� index */ 
		9,
	} ;
	if (!g_hMyKL){
	   g_hMyKL	= TSkkIme_hGetHKL () ;
	   if (!g_hMyKL) {
		   DEBUGPRINTFEX (99, (TEXT ("TSkkIme_vUpdateIndicIcon (hIMC:%p) failed\n"), hIMC)) ;
		   return ;
	   }
	}
	DEBUGPRINTFEX (99, (TEXT ("TSkkIme_vUpdateIndicIcon (hIMC:%p)\n"), hIMC)) ;

	hwndIndicate	= FindWindow (INDICATOR_CLASS, NULL) ;
	if (!IsWindow (hwndIndicate))
		return ;
	hwndFore = GetForegroundWindow () ;
	if (! IsWindow (hwndFore))
		return ;
	GetWindowThreadProcessId (hwndFore, &dwProcessId) ;
	if (dwProcessId != GetCurrentProcessId ())
		return ;

	iMode			= IMECMODE_OFF ;
	if (hIMC){
		if (ImmGetOpenStatus (hIMC)){
			lpIMC = ImmLockIMC (hIMC) ;
			if (lpIMC)
				iMode	= iGetConversionModeFromLPIMC (lpIMC) ;
			ImmUnlockIMC (hIMC) ;
		}
	} else {
		iMode	= TSkkIme_bIsHideToolbarp ()? NUM_IMECMODE : IMECMODE_OFF ;
	}
	if (! TSkkIme_bIsHideToolbarp ()){
		iIconIndex	= (iMode != 0)? 1 : (-1) ;
		PostMessage (hwndIndicate,					INDICM_SETIMEICON,
					 iIconIndex,					(LPARAM)g_hMyKL) ;
	} else {
		iIconIndex	= iIconIndexTbl [iMode] ;
		PostMessage (hwndIndicate,					INDICM_SETIMEICON,
					 iIconIndex,					(LPARAM)g_hMyKL) ;
	}
	PostMessage (hwndIndicate,						INDICM_REMOVEDEFAULTMENUITEMS,
				 (WPARAM)(TSkkIme_bIsHideToolbarp ())? (RDMI_LEFT | RDMI_RIGHT) : 0,
				 (LPARAM)g_hMyKL) ;
	return ;
}
#endif

/*
 *	�N���b�v�{�[�h����Ɋւ��� Context Menu ���쐬����֐��B
 */
HMENU	PASCAL
TSkkIme_hCreateClipboardMenu (LPMYCOMPSTR lpMyCompStr)
{
	static	MYMENUITEMINFO	myClipboardMenuItemInfoTbl []	= {
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_CUT,	TEXT ("�؂���"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDM_PASTE,	TEXT ("�\��t��"), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_COPY,	TEXT ("�R�s�["), },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING, 0,				IDM_DELETE,	TEXT ("�폜"), },
	  { MIIM_TYPE,							MFT_SEPARATOR,	0,			NULL, },
	  { MIIM_STATE | MIIM_ID | MIIM_STRING,	0,				IDCANCEL,	TEXT ("�L�����Z��"), },
	} ;
	HMENU					hMenu ;
	LPMYMENUITEMINFO		lpMyMenu ;
	MENUITEMINFO			menuItemInfo ;
	int						i, nStartPos, nEndPos ;
	long					lMinibufLen ;
	BOOL					f ;

	/* �����̐������`�F�b�N�B*/
	if (!lpMyCompStr)
		return	0 ;
	hMenu		= CreatePopupMenu () ;
	if (!hMenu)
		return	0 ;
	/* �܂����j���[�̍��ڂ�ݒ肷��B*/
	lpMyMenu	= myClipboardMenuItemInfoTbl ;
	for (i = 0 ; i < 6 ; i ++){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= lpMyMenu->m_fMask ;
		menuItemInfo.fType			= lpMyMenu->m_fType ;
		menuItemInfo.wID			= lpMyMenu->m_wID ;
		menuItemInfo.fState			= MFS_ENABLED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		//menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= lpMyMenu->m_dwTypeData ;
		menuItemInfo.cch			= lstrlen (menuItemInfo.dwTypeData) ;
		InsertMenuItem (hMenu, i, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		lpMyMenu	++ ;
	}
	/* �̈�I�����L���ł��邩�ǂ����𔻒肷��B*/	
	f			= ImeDoc_bGetSelectedRegion (&lpMyCompStr->_Doc, &nStartPos, &nEndPos) ;
	if (!f || nStartPos == nEndPos || nStartPos < 0 || nEndPos < 0){
		EnableMenuItem (hMenu, 0, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 2, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 3, MF_BYPOSITION | MF_GRAYED) ;
	}
	/* �N���b�v�{�[�h�Ƀe�L�X�g�����݂��邩�ǂ����`�F�b�N����B*/
	if (!IsClipboardFormatAvailable (CF_TEXT))
		EnableMenuItem (hMenu, 1, MF_BYPOSITION | MF_GRAYED) ;
	return	hMenu ;
}

HFONT
TSkkIme_hCheckNativeCharset (
	HDC			hDC,
	BOOL*		pbFontCreated)
{
	HFONT				hFont	= NULL ;
	HFONT				hOldFont ;
	LOGFONT				lf ;

	ImeConfig_vGetDefaultFont (&lf, hDC) ;
	hFont	= CreateFontIndirect (&lf) ;
	if (hFont != NULL) {
		hOldFont		= (HFONT) SelectObject (hDC, hFont) ;
		*pbFontCreated	= TRUE ;
	} else {
		hOldFont		= (HFONT) SelectObject (hDC, (HFONT) GetStockObject (DEFAULT_GUI_FONT)) ;
		*pbFontCreated	= FALSE ;
	}
	return	hOldFont ;
}

static	int		srnMyColorIndex2SysColorIndexTbl []	= {
	COLOR_BTNFACE,
	COLOR_BTNTEXT,
	COLOR_ACTIVEBORDER,
	COLOR_ACTIVECAPTION,
	COLOR_CAPTIONTEXT,
	COLOR_APPWORKSPACE,
	COLOR_WINDOW,
	COLOR_WINDOWTEXT,
	COLOR_DESKTOP,
	COLOR_INFOBK,
	COLOR_INFOTEXT,
	COLOR_WINDOWTEXT,
	COLOR_MENU,
	COLOR_MENUTEXT,
	COLOR_HIGHLIGHTTEXT,
	COLOR_HIGHLIGHT,
	COLOR_INACTIVEBORDER,
	COLOR_INACTIVECAPTION,
	COLOR_INACTIVECAPTIONTEXT,
} ;

COLORREF
TSkkIme_crGetImeColor (
	HWND	hwnd,
	int	nColor)
{
	HDC		hdc ;
	COLORREF	col ;

	switch (nColor) {
	case	MYCOLOR_TEXTAUTO:
	case	MYCOLOR_BACKAUTO:
		hdc	= GetDC (hwnd) ;
		col	= GetBkColor (hdc) ;
		ReleaseDC (hwnd, hdc) ;
		return	(nColor == MYCOLOR_BACKAUTO)? col : ~col ;
	case	MYCOLOR_BLACK:
		return	PALETTERGB (  0,   0,   0) ;
	case	MYCOLOR_DARKRED:
		return	PALETTERGB (128,   0,   0) ;
	case	MYCOLOR_DARKGREEN:
		return	PALETTERGB (  0, 128,   0) ;
	case	MYCOLOR_DARKYELLOW:
		return	PALETTERGB (128, 128,   0) ;
	case	MYCOLOR_DARKBLUE:
		return	PALETTERGB (  0,   0, 128) ;
	case	MYCOLOR_DARKPURPLE:
		return	PALETTERGB (128,   0, 128) ;
	case	MYCOLOR_DARKLIGHTBLUE:
		return	PALETTERGB (0,   128, 128) ;
	case	MYCOLOR_DARKGRAY:
		return	PALETTERGB (128, 128, 128) ;
	case	MYCOLOR_LIGHTGRAY:
		return	PALETTERGB (192, 192, 192) ;
	case	MYCOLOR_RED:
		return	PALETTERGB (255,   0,   0) ;
	case	MYCOLOR_GREEN:
		return	PALETTERGB (  0, 255,   0) ;
	case	MYCOLOR_YELLOW:
		return	PALETTERGB (255, 255,   0) ;
	case	MYCOLOR_BLUE:
		return	PALETTERGB (  0,   0, 255) ;
	case	MYCOLOR_PURPLE:
		return	PALETTERGB (255,   0, 255) ;
	case	MYCOLOR_LIGHTBLUE:
		return	PALETTERGB (  0, 255, 255) ;
	case	MYCOLOR_WHITE:
		return	PALETTERGB (255, 255, 255) ;
	default:
		if (MYCOLOR_SYSTEM <= nColor && nColor < MAX_MYCOLOR) {
			nColor	-= MYCOLOR_SYSTEM ;
			return	GetSysColor (srnMyColorIndex2SysColorIndexTbl [nColor]) ;
		}
		break ;
	}
	return	PALETTERGB (0, 0, 0) ;
}

/*	�_���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDottedBrush [8]	= {
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
	0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA,
} ;

/*	�f�B�U���̕`��Ɏg���p�^�[���B*/
static const UINT		srbDitherBrush [8]	= {
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
	0xAAAA5555, 0x5555AAAA, 0xAAAA5555, 0x5555AAAA,
} ;

HBRUSH
TSkkIme_hbrGetImeLineBrush (
	HWND				hwnd,		/* [in] */
	int					nLineColor,	/* [in] */
	int					nLineType,	/* [in] */
	COLORREF*			pColBrush,	/* [out] */
	HBITMAP*			phBm,		/* [out] */
	int*				pnWidth)	/* [out] */
{
	COLORREF	colBrush ;
	HBRUSH		hBrush	= NULL ;
	HBITMAP	hBitmap	= NULL ;

	if (pColBrush == NULL || phBm == NULL || pnWidth == NULL) {
		return	NULL ;
	}

	colBrush	= TSkkIme_crGetImeColor (hwnd, nLineColor) ;
	switch (nLineType) {
	case	MYLINE_SOLID:
		*pnWidth	= 1 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_DOTTED:
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDottedBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		*pnWidth	= 1 ;
		break ;
	case	MYLINE_THICK_SOLID:
		*pnWidth	= 2 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_THIN_DITHER:
		*pnWidth	= 2 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_THICK_DITHER:
		*pnWidth	= 3 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_NO:
	default:
		*pnWidth	= 0 ;
		break ;
	}
	*pColBrush	= colBrush ;
	*phBm		= hBitmap ;
	return	hBrush ;
}

/*************************************************************************
 *	IsCrossRectangle
 *		�Q�̗̈�(Rectangle)���������邩�ǂ������肷��B
 *************************************************************************/
BOOL	PASCAL
IsCrossRectangle (
	LPPOINT	lpPoint,
	LPSIZE		lpSize,
	LPRECT		lpRect)
{
	if (lpRect->right <= lpPoint->x)
		return	FALSE ;
	if ((lpPoint->x + lpSize->cx) < lpRect->left)
		return	FALSE ;
	if (lpRect->bottom <= lpPoint->y)
		return	FALSE ;
	if ((lpPoint->y + lpSize->cy) < lpRect->top)
		return	FALSE ;
	return	TRUE ;
}

/*	Imm �𗘗p���āC�����̏�Ԃ𑪂��Ă݂�D
 */
int PASCAL
iGetConversionModeFromHIMC (
	HIMC	hIMC)
{
	DWORD	dwConversion, dwSentense ;

	if (! hIMC)
		return	IMECMODE_OFF ;

	if (! ImmGetOpenStatus (hIMC)) 
		return	IMECMODE_OFF ;

	if (! ImmGetConversionStatus (hIMC, &dwConversion, &dwSentense))
		return	IMECMODE_OFF ;

	if (dwConversion & IME_CMODE_FULLSHAPE){
		if (!(dwConversion & IME_CMODE_LANGUAGE)){
			return	IMECMODE_ZENKAKU ;
		} else if ((dwConversion & IME_CMODE_LANGUAGE) == IME_CMODE_NATIVE){
			return	IMECMODE_HIRAGANA ;
		} else {
			return	IMECMODE_KATAKANA ;
		}
	} else {
		if (dwConversion & IME_CMODE_NATIVE){
			return	(dwConversion & IME_CMODE_KATAKANA)? IMECMODE_HANKANA : IMECMODE_HANKANA_ROMAN ;
		} else {
			return	IMECMODE_ASCII ;
		}
	}
}

/*	LPINPUTCONTEXT �̒��g�����āC�����̏�Ԃ𑪂��Ă݂�D
 */
int PASCAL
iGetConversionModeFromLPIMC (
	LPINPUTCONTEXT		lpIMC)
{
	/*
	 *	IME �o�R�̓��͂łȂ� ---> ���ړ��̓��[�h�ł���B
	 *	IME �o�R�̓��͂ł��� ---> fdwConversion ������B
	*/
	if (!lpIMC->fOpen)
		return	IMECMODE_OFF ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
		return	IMECMODE_HIRAGANA ;

	if (lpIMC->fdwConversion & IME_CMODE_FULLSHAPE){
		if (!(lpIMC->fdwConversion & IME_CMODE_LANGUAGE)){
			return	IMECMODE_ZENKAKU ;
		} else if ((lpIMC->fdwConversion & IME_CMODE_LANGUAGE) == IME_CMODE_NATIVE){
			return	IMECMODE_HIRAGANA ;
		} else {
			return	IMECMODE_KATAKANA ;
		}
	} else {
		if (lpIMC->fdwConversion & IME_CMODE_NATIVE){
			return	(lpIMC->fdwConversion & IME_CMODE_KATAKANA)? IMECMODE_HANKANA : IMECMODE_HANKANA_ROMAN ;
		} else {
			return	IMECMODE_ASCII ;
		}
	}
}

/*
 *	�ϊ����[�h��؂�ւ���֐��B
 *	���͂� ConversionMode �� ImeDoc.h �Œ�`���Ă��� IMECMODE_XXX �ōs���D
 */
BOOL	PASCAL
ChangeConversionMode (
	HIMC		hIMC,
	int			nConversionMode)
{
	DWORD		fdwConversion ;

	if (nConversionMode == IMECMODE_OFF) {
		if (ImmGetOpenStatus (hIMC)) 
			ImmSetOpenStatus (hIMC, FALSE) ;
	} else {
		switch (nConversionMode){
		case	IMECMODE_ASCII:
			fdwConversion	= 0 ;
			break ;
		case	IMECMODE_HIRAGANA:
			fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_FULLSHAPE ;
			break ;
		case	IMECMODE_KATAKANA:
			fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_KATAKANA | IME_CMODE_FULLSHAPE ;
			break ;
		case	IMECMODE_ZENKAKU:
			fdwConversion	= IME_CMODE_FULLSHAPE ;
			break ;
		case	IMECMODE_HANKANA:
			fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_KATAKANA ;
			break ;
		case	IMECMODE_HANKANA_ROMAN:
			fdwConversion	= IME_CMODE_JAPANESE ;
			break ;
		default:
			return	FALSE ;
		}
		if (! ImmGetOpenStatus (hIMC)) 
			ImmSetOpenStatus (hIMC, TRUE) ;
		ImmSetConversionStatus (hIMC, fdwConversion, 0) ;
	}
	return	TRUE ;
}

BOOL	PASCAL
ChangeConversionModeWithIDM (
	HIMC		hIMC,
	int			nMenuID)
{
	BOOL	fOpen ;

	if (nMenuID < 0 || nMenuID == IDCANCEL)
		return	TRUE ;

	switch (nMenuID) {
	case	IDM_CMODE_TO_ASCII:
		ChangeConversionMode (hIMC, IMECMODE_ASCII) ;
		break ;
	case	IDM_CMODE_TO_ROMANHIRA:
		ChangeConversionMode (hIMC, IMECMODE_HIRAGANA) ;
		break ;
	case	IDM_CMODE_TO_ROMANKATA:
		ChangeConversionMode (hIMC, IMECMODE_KATAKANA) ;
		break ;
	case	IDM_CMODE_TO_ZENEI:
		ChangeConversionMode (hIMC, IMECMODE_ZENKAKU) ;
		break ;
	case	IDM_CMODE_TO_JISX0201KANA:
		ChangeConversionMode (hIMC, IMECMODE_HANKANA) ;
		break ;
	case	IDM_CMODE_TO_JISX0201ROMAN:
		ChangeConversionMode (hIMC, IMECMODE_HANKANA_ROMAN) ;
		break ;
	case	IDM_CMODE_TO_DIRECTINPUT:
		fOpen	= ImmGetOpenStatus (hIMC) ;
		if (fOpen)
			ImmSetOpenStatus (hIMC, FALSE) ;
		break ;
	default:
		if (nMenuID < 0 || nMenuID == IDCANCEL)
			break ;
		return	FALSE ;
	}
	return	TRUE ;
}

/*
 *	�R�����g�A�E�g�̂܂܎c���Ă������A���̊֐����g���� Context �� Active ���ꂽ����
 *	���� Window ������̂� Suspend ���Ă��� Process ������Ƃ��ɑS�̂� lock �����
 *	�Ő����������ł͂Ȃ��B
 *
struct tagHideOtherWindowsInfo {
	LPCTSTR		_strClassName ;
	LPCTSTR		_strWindowName ;
	HWND		_hwndException ;
} ;

static	BOOL	CALLBACK
hideOtherWindowsEnumProc (
	HWND		hwnd,
	LPARAM		lParam)
{
	struct tagHideOtherWindowsInfo*	pInfo	= (struct tagHideOtherWindowsInfo*) lParam ;
	TCHAR	szBuffer [256] ;

	if (pInfo == NULL)
		return	FALSE ;
	if (hwnd == pInfo->_hwndException)
		return	TRUE ;
	if (GetClassName (hwnd, szBuffer, sizeof (szBuffer) - 1) == 0)
		return	TRUE ;
	if (lstrcmp (szBuffer, pInfo->_strClassName))
		return	TRUE ;
	ShowWindow (hwnd, SW_HIDE) ;
	return	TRUE ;
}

void	PASCAL
HideOtherWindows (
	LPCTSTR	strClassName,
	LPCTSTR	strWindowName,
	HWND		hwnd)
{
	struct tagHideOtherWindowsInfo	info ;

	info._strClassName	= strClassName ;
	info._strWindowName	= strWindowName ;
	info._hwndException	= hwnd ;
	EnumWindows (hideOtherWindowsEnumProc, (LPARAM)&info) ;
	return ;
}

struct tagHideOtherWindowsInfo {
	LPCTSTR		_strClassName ;
	LPCTSTR		_strWindowName ;
	HWND		_hwndException ;
} ;

static	BOOL	CALLBACK
hideOtherWindowsEnumProc (
	HWND		hwnd,
	LPARAM		lParam)
{
	struct tagHideOtherWindowsInfo*	pInfo	= (struct tagHideOtherWindowsInfo*) lParam ;
	TCHAR	szBuffer [256] ;

	if (pInfo == NULL)
		return	FALSE ;
	if (hwnd == pInfo->_hwndException)
		return	TRUE ;
	if (GetClassName (hwnd, szBuffer, sizeof (szBuffer) - 1) == 0)
		return	TRUE ;
	if (lstrcmp (szBuffer, pInfo->_strClassName))
		return	TRUE ;
	PostMessage (hwnd, WM_UI_HIDE, (WPARAM) 0, (LPARAM) 0) ;
	return	TRUE ;
}

void	PASCAL
HideOtherWindows (
	LPCTSTR	strClassName,
	LPCTSTR	strWindowName,
	HWND		hwnd)
{
	struct tagHideOtherWindowsInfo	info ;

	info._strClassName	= strClassName ;
	info._strWindowName	= strWindowName ;
	info._hwndException	= hwnd ;
	EnumWindows (hideOtherWindowsEnumProc, (LPARAM)&info) ;
	return ;
}

*/
