/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * skkui.h
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#pragma once

#define	J_MINIBUFF_NOT_USING			(0)
#define	J_HENKAN_IN_MINIBUFF_MODE		(1)
#define	J_INPUT_BY_CODE_OR_MENU_MODE	(2)
#define	J_PURGE_YES_OR_NO_P				(3)

#define	SKKUI_UPDATE_CURSOR				(0x00000001L)
#define	SKKUI_UPDATE_COMPOSITIONSTRING	(0x00000002L)
#define	SKKUI_UPDATE_RESULT				(0x00000004L)
#define	SKKUI_SENDBACK_KEYDOWN			(0x00000008L)
#define SKKUI_CREATE_CANDIDATELIST		(0x00000010L)
#define SKKUI_UPDATE_CANDIDATELIST		(0x00000020L)
#define SKKUI_CLOSE_CANDIDATELIST		(0x00000040L)
#define	SKKUI_UPDATE_CONVERSIONMODE		(0x00000080L)
#define	SKKUI_CHECK_NEWLINE				(0x00000100L)

#define	MAX_SKKCANDPAGESIZE				(7)

