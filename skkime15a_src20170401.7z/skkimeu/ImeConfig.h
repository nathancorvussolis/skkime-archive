#pragma once

#include "dchar.h"

/*========================================================================
 *	definitions
 */
/* for show annotation */
enum {
	DISABLE_ANNOTATION					= -1,
	SHOW_NO_ANNOTATION					= 0,
	SHOW_ANNOTATION_IN_CANDLIST,
	SHOW_ANNOTATION_ALWAYS,
} ;

#define	SIZE_IMEDOC_KEYMAP	256

enum {
	SHOWCANDLIST_COUNT_ZERO				= 0,

	SHOWCANDLIST_COUNT_NOSHOW			= 65534,
	SHOWCANDLIST_COUNT_USERDEFINED		= 65535,
} ;

/*================================================================
 *	keybind �Ɋւ����`�B
 */
enum {
	KEYMASK_LCONTROL	= 1 << 0,
	KEYMASK_RCONTROL	= 1 << 1,
	KEYMASK_LMENU		= 1 << 2,
	KEYMASK_RMENU		= 1 << 3,
	KEYMASK_LSHIFT		= 1 << 4,
	KEYMASK_RSHIFT		= 1 << 5,
	KEYMASK_SCROLL		= 1 << 6,
	KEYMASK_NUMLOCK		= 1 << 7,
	NBITS_KEYMASK		= 8,
} ;


struct CImeKeyBind {
	short				m_nKeyCode ;
	unsigned short		m_uKeyMask ;		/* CONTROL | SHIFT | ALT ���炢���H */
	int					m_nKeyFunction ;	/* �@�\�B*/
} ;

struct CImeKeymap {
	BYTE				m_rbyBaseMap [SIZE_IMEDOC_KEYMAP] ;	/* 128 ���Bdefault */
	int					m_nKeyBinds ;	/* �ǉ��B�������݂���΁B*/
	struct CImeKeyBind*	m_pKeyBinds ;
} ;

#if defined (UNITTEST)
typedef struct tagMYCOLORFACESET {
	int				m_nTextColor ;
	int				m_nBackColor ;
	int				m_nUnderLineColor ;
	int				m_nUnderLineType ;
}	MYCOLORFACESET ;
#endif

/*================================================================
 *	roma-kana-rule �Ɋւ����`�B
 */
enum {
	RULETREENO_SKK_BASE				= 0,
	RULETREENO_SKK_JISX0201_ROMAN	= 256,
	RULETREENO_SKK_JISX0201_BASE	= 512,
	NUM_ROMAKANARULE				= 4,
} ;

/*========================================================================
 *	prototypes
 */

#if defined (__cplusplus)
extern "C" {
#endif

void						ImeConfig_vLoad		(void) ;
void						ImeConfig_vUnload	(void) ;
void						ImeConfig_vUpdate	(void) ;

BOOL						ImeConfig_bKanaModeWhenOpenp				(void) ;
struct CSkkRuleTreeNode*	ImeConfig_pGetSkkRuleTree					(int) ;
BOOL						ImeConfig_bSkkKakuteiEarlyp					(void) ;
BOOL						ImeConfig_bSkkProcessOkuriEarlyp			(void) ;
BOOL						ImeConfig_bSkkEchop							(void) ;
BOOL						ImeConfig_bSkkTryCompletionCharp			(int) ;
BOOL						ImeConfig_bSkkPreviousCompletionCharp		(int) ;
BOOL						ImeConfig_bSkkNextCompletionCharp			(int) ;
BOOL						ImeConfig_bSkkAutoStartHenkanp				(void) ;
BOOL						ImeConfig_bSkkAutoStartHenkanKeywordp		(LPCDSTR, int) ;
BOOL						ImeConfig_bSkkSpecialMidashiCharp			(int) ;
BOOL						ImeConfig_bSkkSetHenkanPointKeyp			(int) ;
BOOL						ImeConfig_bSkkSetHenkanPointKeyMaskedp		(void) ;
void						ImeConfig_vMaskSkkSetHenkanPointKey			(BOOL) ;
BOOL						ImeConfig_bSkkStartHenkanCharp				(int) ;
int							ImeConfig_iSkkARefSkkKanaRomVector			(int, LPDSTR, int) ;
int							ImeConfig_iGetSkkShowAnnotationType			(void) ;
BOOL						ImeConfig_bSkkEggLikeNewline				(void) ;
BOOL						ImeConfig_bSkkDeleteOkuriWhenQuit			(void) ;
BOOL						ImeConfig_bSkkDeleteImplesKakuteip			(void) ;
LPCDSTR						ImeConfig_pGetSkkHenkanShowCandidatesKeys	(int*) ;
BOOL						ImeConfig_bSkkNumericConversionp			(void) ;
BOOL						ImeConfig_bSkkNumConvertFloatp				(void) ;
BOOL						ImeConfig_bSkkCompCirculatep				(void) ;
int							ImeConfig_iGetSkkKcodeCharset				(void) ;
LPCDSTR						ImeConfig_pGetSkkInputByCodeMenuKeys1		(int*) ;
LPCDSTR						ImeConfig_pGetSkkInputByCodeMenuKeys2		(int*) ;
int							ImeConfig_iGetSkkOkuriChar					(LPCDSTR, int, LPDSTR, int) ;
BOOL						ImeConfig_bSkkHenkanOkuriStrictlyp			(void) ;
BOOL						ImeConfig_bSkkHenkanStrictOkuriPrecedencep	(void) ;
BOOL						ImeConfig_bSkkAutoOkuriProcessp				(void) ;
// const struct CSkkRuleTreeNodeOutput*	ImeConfig_pGetOhRuleTreeNodeOutput	(void) ;
int							ImeConfig_iSkkARefSkkJisx0208LatinVector	(int, LPDSTR, int) ;
int							ImeConfig_iSkkRevRefSkkJisx0208LatinVector	(int, LPDSTR, int) ;
BOOL						ImeConfig_bSkkAutoInsertParen				(void) ;
int							ImeConfig_iSkkAssocSkkAutoParenStringAlist	(LPCDSTR, int, LPDSTR, int) ;
BOOL						ImeConfig_bSkkAllowsSpacesNewlinesAndTabs	(void) ;
int							ImeConfig_iGetNumberOfKutotens				(void) ;
LPCDSTR						ImeConfig_pGetCurrentTouten					(int, int*) ;
LPCDSTR						ImeConfig_pGetCurrentKuten					(int, int*) ;
BOOL						ImeConfig_bSkkIsNewlineKakuteiAllp			(void) ;
BOOL						ImeConfig_bSkkCompositionAutoShiftp			(void) ;

const struct CImeKeymap*	ImeConfig_pGetMajorModeMap					(void) ;
const struct CImeKeymap*	ImeConfig_pGetSkkJModeMap					(void) ;
const struct CImeKeymap*	ImeConfig_pGetSkkLatinModeMap				(void) ;
const struct CImeKeymap*	ImeConfig_pGetSkkJisx0208LatinModeMap		(void) ;
const struct CImeKeymap*	ImeConfig_pGetSkkAbbrevModeMap				(void) ;
const struct CImeKeymap*	ImeConfig_pGetMinibufferMinorModeMap		(void) ;

const MYCOLORFACESET*		ImeConfig_pGetColorFaceSet					(void) ;
int							ImeConfig_iGetCountHenkanShowChange			(void) ;
void						ImeConfig_vGetDefaultFont					(LOGFONT*, HDC) ;

#if defined (__cplusplus)
}
#endif


