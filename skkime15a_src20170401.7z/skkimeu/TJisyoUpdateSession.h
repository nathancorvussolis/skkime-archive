#pragma once

#include "dchar.h"

BOOL	TRecordSession_bUpdate	(LPCDSTR, int, LPCDSTR, int, LPCDSTR, int, BOOL) ;
BOOL	TPurgeSession_bUpdate	(LPCDSTR, int, LPCDSTR, int, LPCDSTR, int, BOOL) ;
BOOL	TJisyoSaveSession_bSynchronize			(void)  ;
BOOL	TRecordKakuteiHistorySession_bUpdate	(LPCDSTR, int, LPCDSTR, int) ;

