#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDoc.h"
#include "ImeBufferP.h"
#include "TSearchSession.h"
#include "keymap.h"
#include "TMarker.h"
#include "lmstate.h"
#include "ImeConfig.h"
#include "jstring.h"

/*================================================================ skk-comp
 */
int
LM_bSkkComp (
	struct CImeDoc*			pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	ImeDoc_bSetThisCommand (pDoc, NFUNC_SKK_COMP_DO) ;
	ImeDoc_vJump (pDoc, LM_bSkkCompDo) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-comp-do
 */
static	int	LM_bSkkCompDo_1		(struct CImeDoc*) ;

/*	LMREGARG_0:	bFirst
 */
int
LM_bSkkCompDo (
	struct CImeDoc*			pDoc)
{
	BOOL	bFirst ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bPushReg (pDoc, LMREG_0))
		return	LMR_ERROR ;
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_0, &bFirst))
		bFirst	= FALSE ;
	ImeDoc_vSetRegBool (pDoc, LMREG_0, bFirst) ;
	ImeDoc_vSetRegBool (pDoc, LMREGARG_0, TRUE) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkKanaCleanup, LM_bSkkCompDo_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkCompDo_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int		nStart, nEnd ;
	LPCDSTR	pCWord ;
	LPCDSTR	pSkkCompKey ;
	int		nSkkCompKey ;
	BOOL	bFirst ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREG_0, &bFirst))
		bFirst	= FALSE ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_pmkSkkHenkanStartPoint == NULL || pBuffer->m_pmkPoint == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	nStart	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
	nEnd	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
	if (nEnd < nStart || nEnd < 0 || nStart > pBuffer->m_nbufComp || (nEnd > nStart && nStart == pBuffer->m_nbufComp)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (bFirst) {
		if (pBuffer->m_pSkkCompSession != NULL) {
			TSearchSession_vDestroy (pBuffer->m_pSkkCompSession) ;
			pBuffer->m_pSkkCompSession	= NULL ;
		}

		if (nStart == nEnd) {
			/* kakutei-history ����̌����͉ۑ�Ƃ��Ďc���Ă����B
			 */
			pBuffer->m_pSkkCompSession	= TKakuteiHistoryCompletionSession_pCreate () ;
		} else {
			pBuffer->m_pSkkCompSession	= TCompletionSession_pCreate (pBuffer->m_bufComp + nStart, nEnd - nStart) ;
		}
		if (pBuffer->m_pSkkCompSession == NULL) {
			ImeDoc_vSetSignalError (pDoc) ;
			return	LMR_RETURN ;
		}

		pCWord	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCompSession) ;
	} else {
		if (! TSearchSession_bNextCandidate (pBuffer->m_pSkkCompSession)) {
			pCWord	= NULL ;
			if (ImeConfig_bSkkCompCirculatep ()) {
				if (TSearchSession_bRewind (pBuffer->m_pSkkCompSession)) {
					pCWord	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCompSession) ;
				}
			}
		} else {
			pCWord	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCompSession) ;
		}
	}
	if (pCWord == NULL) {
		pSkkCompKey	= TSearchSession_pGetKeyword (pBuffer->m_pSkkCompSession, &nSkkCompKey) ;
		if (ImeConfig_bSkkCompCirculatep ()) {
			ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;
			ImeBuffer_iInsert (pBuffer, pBuffer->m_pmkPoint, pSkkCompKey, nSkkCompKey) ;
		} else {
			if (nSkkCompKey > 0 && pSkkCompKey != NULL) {
				DCHAR	buf [MAXCOMPLEN] ;
				LPDSTR	pdDest		= buf ;
				LPCDSTR	pdDestEnd	= buf + ARRAYSIZE (buf) ;

//				n	= wnsprintfW (buf, ARRAYSIZE (buf), L"No %scompleitions for \"%s\"", (bFirst? L"" : L"more "), bufSkkCompKey) ;
				if (! bFirst) {
					vCopyStringW (&pdDest, pdDestEnd, L"No more completions for \"") ;
				} else {
					vCopyStringW (&pdDest, pdDestEnd, L"No completions for \"") ;
				}
				vCopyStringN (&pdDest, pdDestEnd, pSkkCompKey, nSkkCompKey) ;
				vCopyStringW (&pdDest, pdDestEnd, L"\"") ;
				ImeDoc_bSetMessageN (pDoc, buf, pdDest - buf) ;
			} else {
				ImeDoc_bSetMessageW (pDoc, L"No more words in history") ;
			}
		}
	} else {
		ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;
		ImeBuffer_iInsert (pBuffer, pBuffer->m_pmkPoint, pCWord, dcslen (pCWord)) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-comp-previous
 */
int
LM_bSkkCompPrevious (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int		nStart, nEnd ;
	LPCDSTR	pCWord ;
	LPCDSTR	pSkkCompKey ;
	int		nSkkCompKey ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_pSkkCompSession == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_pmkSkkHenkanStartPoint == NULL || pBuffer->m_pmkPoint == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	nStart	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
	nEnd	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
	if (nEnd < nStart || nEnd < 0 || nStart >= pBuffer->m_nbufComp) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (! TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCompSession)) {
		if (ImeConfig_bSkkCompCirculatep ()) {
			while (TSearchSession_bNextCandidate (pBuffer->m_pSkkCompSession))
				;
			pCWord	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCompSession) ;
		} else {
			pCWord	= NULL ;
		}
	} else {
		pCWord	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCompSession) ;
	}
	if (pCWord == NULL) {
		pSkkCompKey	= TSearchSession_pGetKeyword (pBuffer->m_pSkkCompSession, &nSkkCompKey) ;
		if (ImeConfig_bSkkCompCirculatep ()) {
			ImeBuffer_bDeleteRegion (pBuffer, nStart, nEnd) ;
			ImeBuffer_iInsertByPosition (pBuffer, nStart, pSkkCompKey, nSkkCompKey) ;
		} else {
			DCHAR	buf [MAXCOMPLEN] ;
			int		n ;
			if (nSkkCompKey > 0 && pSkkCompKey != NULL) {
				LPDSTR	pdDest		= buf ;
				LPCDSTR	pdDestEnd	= buf + ARRAYSIZE (buf) ;

				vCopyStringW (&pdDest, pdDestEnd, L"No previous compleitions for \"") ;
				vCopyStringN (&pdDest, pdDestEnd, pSkkCompKey, nSkkCompKey) ;
				vCopyStringW (&pdDest, pdDestEnd, L"\"") ;
				ImeDoc_bSetMessageN (pBuffer->m_pDoc, buf, pdDest - buf) ;
			} else {
				ImeDoc_bSetMessageW (pBuffer->m_pDoc, L"No previous words in history") ;
			}
		}
	} else {
		ImeBuffer_bDeleteRegion (pBuffer, nStart, nEnd) ;
		ImeBuffer_iInsertByPosition (pBuffer, nStart, pCWord, dcslen (pCWord)) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-comp-previous-next
 */
/*
(defun skk-comp-previous/next (ch)
  (setq this-command 'skk-comp-do)
  (cond ((eq ch skk-next-completion-char)
	 (skk-comp-do nil))
	((eq ch skk-previous-completion-char)
	 (skk-previous-completion))))
*/
int
LM_bSkkCompPreviousNext (
	struct CImeDoc*			pDoc)
{
	int		nCH ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bGetRegInteger (pDoc, LMREGARG_0, &nCH)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	ImeDoc_bSetThisCommand (pDoc, NFUNC_SKK_COMP_DO) ;
	if (ImeConfig_bSkkNextCompletionCharp (nCH)) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_0, FALSE) ;
		ImeDoc_vJump (pDoc, LM_bSkkCompDo) ;
		return	LMR_CONTINUE ;
	} else if (ImeConfig_bSkkPreviousCompletionCharp (nCH)) {
		ImeDoc_vJump (pDoc, LM_bSkkCompPrevious) ;
		return	LMR_CONTINUE ;
	} else {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}
}



