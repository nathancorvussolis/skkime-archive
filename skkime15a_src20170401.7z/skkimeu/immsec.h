#if !defined (IMMSEC_H)
#define	IMMSEC_H

PSECURITY_ATTRIBUTES	CreateSecurityAttributes () ;
VOID					FreeSecurityAttributes (PSECURITY_ATTRIBUTES psa) ;
BOOL					IsNT () ;

#endif
