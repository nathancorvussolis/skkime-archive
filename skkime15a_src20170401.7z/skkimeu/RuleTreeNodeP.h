#pragma once

#include "RuleTreeNode.h"

struct CSkkRuleTreeNodeOutput {
	int			m_nType ;
	union {
		struct {
			LPDSTR	m_strHira ;
			int		m_nHira ;
			LPDSTR	m_strKata ;
			int		m_nKata ;
		}	m_stringpair ;
		struct {
			LPDSTR	m_strValue ;
			int		m_nValue ;
		}	m_string ;
		int		m_nMacro ;
	}	m_uValue ;
} ;

struct CSkkRuleTreeNode {
	int						_nCH ;
	LPDSTR					_pPrefix ;			/* ����ԁB*/
	int						_nPrefix ;
	LPDSTR					_pNextState ;		/* ����ԁB*/
	int						_nNextState ;
	int						_nNextRule ;

	struct CSkkRuleTreeNodeOutput*	_pOutput ;

	struct CSkkRuleTreeNode*		_pChild ;		/* �q���B*/
	struct CSkkRuleTreeNode*		_pBrother ;		/* �Z��B*/
} ;

#define	TSkkRuleTreeNode_pGetChild(pNode)	((pNode)->_pChild)
#define	TSkkRuleTreeNode_iGetChar(pNode)	((pNode)->_nCH)
#define	TSkkRuleTreeNode_pGetBrother(pNode)	((pNode)->_pBrother)

