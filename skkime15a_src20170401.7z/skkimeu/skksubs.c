/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * skksubs.c
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "immdev.h"
#include "skki1_5.h"
#include "skkui.h"
#include "tmalloc.h"
#include "resource.h"

static	void	tSkkIme_vFlushTextSub	(HIMC) ;
static	BOOL	tSkkIme_bFilterMessage	(HIMC, LPINPUTCONTEXT, struct TMSG*) ;

BOOL	PASCAL
TSkkIme_bSetConversionMode (
	HIMC			hIMC,
	DWORD			fdwConversion)
{
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR	lpMyCompStr ;
	int			nMode ;
	BOOL			f	= FALSE ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
		goto	exit_func ;

	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL)
		goto	exit_func ;

	if (fdwConversion & IME_CMODE_JAPANESE){
		if (!(fdwConversion & IME_CMODE_FULLSHAPE)){
			nMode	= (fdwConversion & IME_CMODE_KATAKANA)? IMECMODE_HANKANA : IMECMODE_HANKANA_ROMAN ;
		} else {
			nMode	= (fdwConversion & IME_CMODE_KATAKANA)? IMECMODE_KATAKANA : IMECMODE_HIRAGANA ;
		}
	} else {
		nMode	= (fdwConversion & IME_CMODE_FULLSHAPE)? IMECMODE_ZENKAKU : IMECMODE_ASCII ;
	}
	f	= ImeDoc_bSetConversionMode (&lpMyCompStr->_Doc, nMode) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
  exit_func:
	ImmUnlockIMC (hIMC) ;
	return	f ;
}

DWORD	PASCAL
TSkkIme_dwGetConversionMode (
	HIMC			hIMC)
{
	DWORD			fdwConversion ;
	LPINPUTCONTEXT	lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	struct CImeDoc*		pDoc ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	0L ;

	fdwConversion	= 0L ;
	lpCompStr		= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpCompStr == NULL) 
		goto	exit_func ;

	pDoc	= GetDocumentFromCompStr (lpCompStr) ;
	switch (ImeDoc_iGetConversionMode (pDoc)) {
	case	IMECMODE_HIRAGANA:
		fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_FULLSHAPE ;
		break ;
	case	IMECMODE_KATAKANA:
		fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_FULLSHAPE | IME_CMODE_KATAKANA ;
		break ;
	case	IMECMODE_ZENKAKU:
		fdwConversion	= IME_CMODE_ALPHANUMERIC | IME_CMODE_FULLSHAPE ;
		break ;
	case	IMECMODE_HANKANA:
		fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_KATAKANA ;
		break ;
	case	IMECMODE_HANKANA_ROMAN:
		fdwConversion	= IME_CMODE_JAPANESE | IME_CMODE_ALPHANUMERIC ;
		break ;
	case	IMECMODE_ASCII:
		fdwConversion	= IME_CMODE_ALPHANUMERIC ;
		break ;
	default:
		fdwConversion	= 0 ;
		break ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
  exit_func:
	ImmUnlockIMC (hIMC) ;
	return	fdwConversion ;
}

BOOL	PASCAL
TSkkIme_bUpdateConversionMode (
	HIMC		hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	struct CImeDoc*		pDoc ;
	BOOL				fOpen ;
	int					nMode	= -1 ;

	nMode	= iGetConversionModeFromHIMC (hIMC) ;
	fOpen	= ImmGetOpenStatus (hIMC) ;
	if (!fOpen)
		ImmSetOpenStatus (hIMC, TRUE) ;

	lpIMC 	= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL)
		return	FALSE ;

	TSkkIme_bStartConversion (hIMC, lpIMC) ;
	lpCompStr		= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	pDoc			= GetDocumentFromCompStr (lpCompStr) ;
	if (0 <= nMode && nMode < NUM_IMECMODE) {
		ImeDoc_bSetConversionMode (pDoc, nMode) ;
		TSkkIme_bUpdateComposition (hIMC, lpIMC, lpCompStr) ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	ImmUnlockIMC (hIMC) ;
	return	(0 <= nMode) ;
}

BOOL	PASCAL
TSkkIme_bNotifyChangeConversionMode (
	HIMC			hIMC)
{
	LPINPUTCONTEXT	lpIMC ;
	DWORD			fdwConversion ;
	TRANSMSG		GnMsg ;

	fdwConversion	= TSkkIme_dwGetConversionMode (hIMC) ;
	lpIMC			= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	0L ;

	if (lpIMC->fdwConversion != fdwConversion){
		/*	���̃��b�Z�[�W�͒��ŕ��ĂȂ���΂Ȃ�Ȃ��B�̂ŁA
		 *	PRIVATE �ɂ���B*/
		lpIMC->fdwConversion	= fdwConversion ;
		GnMsg.message			= WM_IME_NOTIFY ;
		GnMsg.wParam			= IMN_SETCONVERSIONMODE ;
		GnMsg.lParam			= 0 ;
		GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
	}
	ImmUnlockIMC (hIMC) ;
	return	TRUE ;	
}

/*	���߂� Annotation ��ێ����Ă��邩�ǂ����𔻒肷��B
 *	Annotation �͎��̌`���� Word �̒��ɑ��݂���B
 *
 *		�P��;Annotation
 *
 *	``;'' ����ؕ����ł���B
 */
int		// PASCAL
TSkkIme_bHasWordAnnotationp (
	LPCMYSTR		pWord,
	int				nWord)
{
	LPCMYSTR	ptr ;

	if (pWord == NULL || nWord <= 0)
		return	-1 ;

	ptr	= pWord ;
	while (nWord > 0 && *ptr != MYTEXT ('\0')) {
		if (*ptr == MYTEXT (';'))
			return	(ptr - pWord) ;
		nWord	-- ;
		ptr		++ ;
	}
	return	-1 ;	/* Not found */
}

/*
BOOL	PASCAL
SKKRecursiveEditEnablep (
	LPCOMPOSITIONSTRING	lpCompStr)
{
	LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR) lpCompStr ;
	BOOL			fRetval ;

	if (lpCompStr == NULL)
		return	FALSE ;
	switch (skkinput_recursive_edit) {
	case	RECURSIVE_EDIT_UICAND_IS_ENABLE:
		fRetval	= (lpMyCompStr->dwShowStyle & ISC_SHOWUICANDIDATEWINDOW) != 0 ;
		break ;
	case	RECURSIVE_EDIT_UICOMP_IS_ENABLE:
		fRetval	= (lpMyCompStr->dwShowStyle & ISC_SHOWUICOMPOSITIONWINDOW) != 0 ;
		break ;
	case	RECURSIVE_EDIT_BOTH_ENABLE:
		fRetval	= ((lpMyCompStr->dwShowStyle & ISC_SHOWUICANDIDATEWINDOW)   != 0 &&
				   (lpMyCompStr->dwShowStyle & ISC_SHOWUICOMPOSITIONWINDOW) != 0) ;
		break ;
	case	RECURSIVE_EDIT_NEVER:
		fRetval	= FALSE ;
		break ;
	default:
	case	RECURSIVE_EDIT_ALWAYS:
		fRetval	= TRUE ;
		break ;
	}
	return	fRetval ;
}
*/

BOOL
TSkkIme_bSetReconvertStr	(
	HIMC					hIMC,
	LPINPUTCONTEXT			lpIMC, 
	LPCOMPOSITIONSTRING		lpCompStr,
	LPRECONVERTSTRING		pRStr,
	BOOL					f) 
{
	LPMYCOMPSTR	lpMyCompStr ;
	struct CImeDoc*		pDoc ;
	LPMYSTR		pText ;
	int			nText, ndText ;
	DCHAR		bufDText [256] ;
	BOOL		fEaten, fRetval ;

	lpMyCompStr		= (LPMYCOMPSTR)lpCompStr ;
	pDoc	= &lpMyCompStr->_Doc ;
	pText	= (LPMYSTR)((LPBYTE)pRStr + pRStr->dwStrOffset + pRStr->dwCompStrOffset) ;
	nText	= pRStr->dwCompStrLen ;

	ndText	= wcstodcs_n (bufDText, ARRAYSIZE (bufDText), pText, nText) ;
	fRetval	= ImeDoc_bSetConversionString (pDoc, bufDText, ndText) ;

	TSkkIme_bUpdateComposition (hIMC, lpIMC, lpCompStr) ;
	return	fRetval ;
}

BOOL
TSkkIme_bConvertString (
	HIMC					hIMC,
	LPINPUTCONTEXT			lpIMC)
{
	struct TMSG		msg ;

	msg.m_nMessage	= WM_LM_COMMAND ;
	msg.m_wParam	= NFUNC_IME_CONVERT ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime	= GetTickCount () ;
	msg.m_pt.x	= 0 ;
	msg.m_pt.y	= 0 ;
	return	tSkkIme_bFilterMessage (hIMC, lpIMC, &msg) ;
}

BOOL
TSkkIme_bOpenCandidate (
	HIMC					hIMC,
	LPINPUTCONTEXT			lpIMC)
{
	struct TMSG	msg ;

	msg.m_nMessage	= WM_LM_COMMAND ;
	msg.m_wParam	= NFUNC_IME_OPENCANDIDATE ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= 0 ;
	msg.m_pt.y		= 0 ;
	return	tSkkIme_bFilterMessage (hIMC, lpIMC, &msg) ;
}

BOOL
TSkkIme_bCompleteString	(
	HIMC					hIMC,
	LPINPUTCONTEXT			lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;
	LPMYCOMPSTR			lpMyCompStr ;
	BOOL				fEaten, fRetval ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
		return	FALSE ;

	lpCompStr		= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpCompStr == NULL) 
		return	FALSE ;

	lpMyCompStr		= (LPMYCOMPSTR) lpCompStr ;
	if (lpCompStr->dwCompStrLen > 0 ||
		lpMyCompStr->_fComposing) {
		fRetval	= ImeDoc_bCompleteText (&lpMyCompStr->_Doc) ;
		TSkkIme_bUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr) ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	fRetval ;
}

BOOL
TSkkIme_bRevertString (
	HIMC					hIMC,
	LPINPUTCONTEXT			lpIMC)
{
	LPMYCOMPSTR		lpMyCompStr ;
	BOOL			fEaten, fRetval ;

	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
		return	FALSE ;

	lpMyCompStr		= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		return	FALSE ;

	fRetval	= ImeDoc_bRevertText (&lpMyCompStr->_Doc) ;
	TSkkIme_bUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	fRetval ;
}

BOOL
TSkkIme_bSelectCandidateStr (
	HIMC					hIMC,
	LPINPUTCONTEXT			lpIMC,
	int						nIndex)
{
	struct TMSG	msg ;

	msg.m_nMessage	= WM_LM_COMMAND ;
	msg.m_wParam	= NFUNC_IME_SELECTCANDIDATESTR ;
	msg.m_lParam	= nIndex ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= 0 ;
	msg.m_pt.y		= 0 ;
	return	tSkkIme_bFilterMessage (hIMC, lpIMC, &msg) ;
}

BOOL
TSkkIme_bSetCandidatePageStart (
	HIMC					hIMC,
	LPINPUTCONTEXT			lpIMC,
	int						nIndex)
{
	struct TMSG	msg ;

	msg.m_nMessage	= WM_LM_COMMAND ;
	msg.m_wParam	= NFUNC_IME_SETCANDIDATEPAGESTART ;
	msg.m_lParam	= nIndex ;
	msg.m_rParam	= 0 ;
	msg.m_nTime	= GetTickCount () ;
	msg.m_pt.x	= 0 ;
	msg.m_pt.y	= 0 ;
	return	tSkkIme_bFilterMessage (hIMC, lpIMC, &msg) ;
}

/*
 *	���ݓ��͂���Ă��� Composition String ���t���b�V������֐��B
 */
void	PASCAL
TSkkIme_vFlushText (HIMC hIMC)
{
#if defined (not_imp)
	if (!TSkkIme_bHasCompStrp (hIMC))
		return ;
#endif
	tSkkIme_vFlushTextSub (hIMC) ;
	return ;
}

void	PASCAL
TSkkIme_vCloseText (HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return ;
	if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR)){
		ImmUnlockIMC (hIMC) ;
		return ;
	}
	ImmUnlockIMC (hIMC) ;
	tSkkIme_vFlushTextSub (hIMC) ;
	return ;
}

/*========================================================================*
 */
void	// PASCAL
tSkkIme_vFlushTextSub (
	HIMC		hIMC)
{
	LPINPUTCONTEXT			lpIMC ;
	LPCOMPOSITIONSTRING		lpCompStr ;
	LPCANDIDATEINFO			lpCandInfo ;
	TRANSMSG				GnMsg ;
	BOOL					fComposing	= FALSE ;

	DEBUGPRINTF ((TEXT ("TSkkIme_vFlushText: (%ld)\n"), hIMC)) ;

	lpIMC	= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL)
		return ;

	if (TSkkIme_bHasCandidateListp (lpIMC)){
		lpCandInfo		= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
		TSkkIme_vClearCandidate (lpCandInfo) ;
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
		GnMsg.message	= WM_IME_NOTIFY ;
		GnMsg.wParam	= IMN_CLOSECANDIDATE ;
		GnMsg.lParam	= 1 ;
		GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
	}

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC(lpIMC->hCompStr) ;
	if (lpCompStr){
		LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR)lpCompStr ;
		int						nLength ;
		int						nCMode ;
		DWORD					dwCompStrLen ;

		MakeInfoGuideLine (hIMC, NULL, 0, -1) ;

		fComposing		= lpMyCompStr->_fComposing ;
		dwCompStrLen	= lpCompStr->dwCompStrLen ;
		TSkkIme_vInitCompStr (lpCompStr, CLR_RESULT_AND_UNDET) ;

		/*	conversion mode �͈ێ�����B*/
		nCMode	= ImeDoc_iGetConversionMode (&lpMyCompStr->_Doc) ;
		ImeDoc_vClear (&lpMyCompStr->_Doc) ;
		ImeDoc_bSetConversionMode (&lpMyCompStr->_Doc, nCMode) ;

		lpCompStr->dwCompStrLen			= 0 ;
		lpCompStr->dwCursorPos			= 0 ;
		lpCompStr->dwDeltaStart			= 0 ;
		lpCompStr->dwCompReadStrLen		= 0 ;
		lpCompStr->dwCompClauseLen		= 0 ;
		lpCompStr->dwCompReadClauseLen	= 0 ;
		lpCompStr->dwResultStrLen		= 0 ;
		lpCompStr->dwResultClauseLen	= 0 ;
		lpCompStr->dwResultReadClauseLen= 0 ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;

		if (dwCompStrLen  > 0) {
			GnMsg.message	= WM_IME_COMPOSITION ;
			GnMsg.wParam	= 0 ;
			GnMsg.lParam	= GCS_COMPALL | GCS_CURSORPOS | GCS_DELTASTART ;
			GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
		}
	}
	if (fComposing) {
		GnMsg.message	= WM_IME_ENDCOMPOSITION ;
		GnMsg.wParam	= 0 ;
		GnMsg.lParam	= 0 ;
		GenerateMessage (hIMC, lpIMC, g_lpCurTransKey, (LPTRANSMSG)&GnMsg) ;
	}
	ImmUnlockIMC (hIMC) ;
	return ;
}

BOOL
tSkkIme_bFilterMessage (
	HIMC				hIMC,
	LPINPUTCONTEXT		lpIMC,
	struct TMSG*		pMSG)
{
	LPCOMPOSITIONSTRING		lpCompStr ;
	struct CImeDoc*			pDoc ;

	if (pMSG == NULL || hIMC == NULL || pMSG == NULL)
		return	FALSE ;
	lpCompStr		= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpCompStr == NULL) 
		return	FALSE ;

	pDoc		= GetDocumentFromCompStr (lpCompStr) ;
	ImeDoc_bFilterEvent (pDoc, pMSG) ;
	TSkkIme_bUpdateComposition (hIMC, lpIMC, lpCompStr) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	TRUE ;
}

