#define SKKISERVER_PIPE_BASENAME TEXT("\\\\.\\pipe\\skkiserv_pipe_%s")
