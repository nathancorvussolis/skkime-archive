/// @see IME/ImeConfig.cpp
/// @see dlgconversion.cpp

static const BYTE _srbDefaultCandidateKeys[] = {
	'A', 'S', 'D', 'F', 'J', 'K', 'L',	// 'Q', 'W', 'U', 'I', 'O', 'Z', 'C', 'V', 'B', 'M',
} ;

static const BYTE _srbDefaultMenu1Keys[] = {
	'A', 'S', 'D', 'F', 'G', 'H', 'Q', 'W', 'E', 'R', 'T', 'Y',
} ;

static const BYTE _srbDefaultMenu2Keys[] = {
	'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U',
} ;

static const BYTE _srb10Keys[] = {
	'1', '2', '3', '4', '5', '6', '7', '8', '9', '0',
} ;
