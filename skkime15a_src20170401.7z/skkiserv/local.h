/**
���ʐݒ�
*/

#pragma once

#if defined _WIN95 || defined _WIN32_WINDOWS
#pragma message("�ΏۊO�̊��ł��B") warning
#endif

#if defined WIN2K || defined WINXP		///< Windows 2000 / Windows XP
#define NTVER 0x0500
#define IEVER 0x0501
#elif defined WINVISTA || defined WIN7	///< Windows Vista / Windows 7
#define NTVER 0x0600
#define IEVER 0x0700
#endif

#ifdef NTVER
#ifndef WINVER
#define WINVER NTVER
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT NTVER
#endif
#ifndef _WIN32_IE
#define _WIN32_IE IEVER
#endif
#else
#pragma message("�ŐV�̊����g�p���܂��B") warning
#include <SDKDDKVer.h>
#endif

#define WIN32_LEAN_AND_MEAN

// Windows
#include <winsock2.h>			///< Winsock �֘A
#include <windows.h>			///< Windows �֘A

// C�����^�C��
#include <stdio.h>
#include <stddef.h>				///< offsetof ��`
#define countof _countof		///< countof ��`

// ���̑�
#include <lmcons.h>
#include <shlwapi.h>

// TCHAR
#include <tchar.h>
#include "Char.h"
typedef TCHAR tchar;
typedef WCHAR wchar;

// ASSERT
#include <assert.h>
#include "debug.h"
#ifdef _DEBUG
#define ASSERT assert
#else
#undef ASSERT
#define ASSERT __assume
#endif
#define NODEFAULT ASSERT(0)

// MALLOC / FREE
#include <malloc.h>
#define MALLOC malloc
#define FREE free

////////////////////////////////////////////////////////////////////

#if !defined (ARRAYSIZE)
#define ARRAYSIZE countof
#endif

#if !defined (TFAILED)
#define	TFAILED(x)			(!(x))
#endif
#if !defined (TSUCCEEDED)
#define	TSUCCEEDED(x)		(x)
#endif

#if !defined (PATH_MAX)
#define	PATH_MAX			MAX_PATH
#endif

#if !defined(DEBUG) && !defined(_DEBUG)
#define printf ERROR::printf
#define fprintf ERROR::fprintf
#define wprintf ERROR::wprintf

#undef _tprintf
#undef _sntprintf
#undef _ftprintf
#undef _vsntprintf
#undef _vsntprintf_s

#define _tprintf ERROR::_tprintf
#define _sntprintf ERROR::_sntprintf
#define _ftprintf ERROR::_ftprintf
#define _vsntprintf WARNING::_vsntprintf
#define _vsntprintf_s WARNING::_vsntprintf_s
#endif
