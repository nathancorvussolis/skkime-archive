#if !defined (kfile_h)
#define	kfile_h

// #include "Char.h"
// #include <stdio.h>
#include "kanji.h"

typedef struct tagKFILE {
	FILE*				m_pf ;
	KANJISTATEMACHINE	m_ksm ;
	int					m_iCodingSystem ;
	Char				m_buf [4] ;
	int					m_nBufUsage ;
}	KFILE ;

typedef struct tagKFILEPOS {
	long				m_lPosition ;
	KANJISTATEMACHINE	m_ksm ;
	Char				m_buf [4] ;
	int					m_nBufUsage ;
}	KFILEPOS ;

#define	KFILEPOS_POSITION(pos)	((pos).m_lPosition)
#define	KFILEPOS_STATE(pos)		((pos).m_ksm)

/*	Prototypes */
BOOL	KFile_Init	(KFILE*) ;
BOOL	KFile_Open	(KFILE*, LPCTSTR, int) ;
BOOL	KFile_Close	(KFILE*) ;
Char	KFile_Getc	(KFILE*) ;
BOOL	KFile_FindsAtBeginningOfLine  (KFILE*, const Char*) ;
BOOL	KFile_FindsAtBeginningOfLineA (KFILE*, const char*) ;
BOOL	KFile_Cmps					(KFILE*, const Char*) ;
BOOL	KFile_Cmpsn					(KFILE*, const Char*, int) ;
BOOL	KFile_Nextline				(KFILE*) ;
BOOL	KFile_Tell					(KFILE*, KFILEPOS*) ;
BOOL	KFile_Seek					(KFILE*, KFILEPOS*) ;
BOOL	KFile_Seekn					(KFILE*, long, int) ;
BOOL	KFile_Rewind				(KFILE*) ;
int		KFile_GetCodingSystem		(KFILE*) ;
int		KFile_DetectCodingSystem	(KFILE*) ;

#endif

