/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#pragma once

/*
#include "../local.h"
#include "lispmgr.h"
#include "lbind.h"
#include "lbuffer.h"
#include "lmarker.h"
*/

typedef enum {
	LISPENTITY_BAD		= -1,
	LISPENTITY_INTEGER	= 0,
	LISPENTITY_FLOAT,
	LISPENTITY_CONSCELL,
	LISPENTITY_VECTOR,
	LISPENTITY_STRING,
	LISPENTITY_SYMBOL,
	LISPENTITY_MARKER,
	LISPENTITY_BUFFER,
	LISPENTITY_SUBR,
	LISPENTITY_EMPTY,
	LISPENTITY_VOID,
	LISPENTITY_BOOLVECTOR,
	LISPENTITY_CHARTABLE,
	MAX_LISPENTITY,
}	LISPENTITYTYPE ;

#define	MAX_LISPENTITY_TYPE	(LISPENTITY_VOID + 1)

struct tagTLispEntity {
	LISPENTITYTYPE			m_iType ;
	long					m_lReferCount ;
	int						m_iMarker ;
	struct tagTLispEntity*	m_pLeft ;
	struct tagTLispEntity*	m_pRight ;
} ;

struct tagTLispConscell {
	struct tagTLispEntity*	m_pCar ;
	struct tagTLispEntity*	m_pCdr ;
} ;

struct tagTLispVector {
	int						m_nElement ;
	struct tagTLispEntity*	m_apElement [1] ;
} ;

struct tagTLispString {
	int						m_nLength ;
	Char					m_achString [1] ;
} ;

struct tagTLispSymbol {
	struct tagTLispEntity*	m_pParent ;
	int						m_nLength ;
	Char					m_achName [1] ;
} ;

struct tagTLispBoolVector {
	int						m_nLength ;
	unsigned int			m_auBitArray [1] ;
} ;

struct tagLMCMDINFO ;

typedef struct tagTLispConscell		TLispConscell ;
typedef struct tagTLispVector		TLispVector ;
typedef struct tagTLispString		TLispString ;
typedef struct tagTLispSymbol		TLispSymbol ;
typedef struct tagTLispEntity		TLispEntity ;
typedef struct tagTLispSubr			TLispSubr ;
typedef struct tagTLispMutex		TLispMutex ;
typedef struct tagTLispXEventInt	TLispXEventInt ;

#define	TLispEntity_GetValue(ptr)	((struct tagTLispEntity *)(ptr) + 1)

