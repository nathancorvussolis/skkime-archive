/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "lmachinep.h"
#include "../kstring.h"
/*
#include "local.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "lmachinep.h"
#include "lmstate.h"
#include "kfile.h"
#include "kanji.h"
#include "kstring.h"
#include "cstring.h"
*/

static	TLMRESULT	lispMachineState_loadStep1		(TLispMachine*) ;
static	TLMRESULT	lispMachineState_loadFinalize	(TLispMachine*) ;

/*
 *	(load-file FILE)
 *
 *	load-file �� interactive �� lisp function �ł���A`file' ����
 *	��`����Ă���B
 *	���̂Ƃ���Ainteractive �̕����͔����Ă���B����� buffer ��
 *	�p�ӂ���K�v������B�����A�����̂��߂ɂ� load-file ������̂�
 *	�֗��Ȃ̂ŁB
 */
TLMRESULT
lispMachineState_LoadFile (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pArglist ;
	TLispEntity*	pFile ;
	TLispEntity*	pRetval ;
	const Char*		pFileName ;
	int				nFileNameLen ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;
	
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pArglist, &pFile)) ||
		TFAILED (lispEntity_Stringp (pLispMgr, pFile))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispEntity_GetStringValue (pLispMgr, pFile, &pFileName, &nFileNameLen) ;
	if (pFileName == NULL || nFileNameLen <= 0) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (TFAILED (lispMgr_Load (pLispMgr, pFileName, nFileNameLen, &pRetval))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pRetval) ;
	lispEntity_Release (pLispMgr, pRetval) ;
	/*	�ȉ� progn �Ƃ��ē��삵�Ă��炤�B*/
	lispMachineCode_SetState (pLM, &lispMachineState_Progn) ;
	return	LMR_CONTINUE ;
}

/*
  load is a built-in function.
  (load FILE &optional NOERROR NOMESSAGE NOSUFFIX MUST-SUFFIX)

  NOSUFFIX �� MUST-SUFFIX �͓��삵�Ȃ��B����ĂȂ��̂ŁB������A
  default �� MUST-SUFFIX �ɂȂ��Ă���B

  Execute a file of Lisp code named FILE.
  First try FILE with `.elc' appended, then try with `.el',
  then try FILE unmodified.  Environment variable references in FILE
  are replaced with their values by calling `substitute-in-file-name'.
  This function searches the directories in `load-path'.
  If optional second arg NOERROR is non-nil,
  report no error if FILE doesn't exist.
  Print messages at start and end of loading unless
  optional third arg NOMESSAGE is non-nil.
  If optional fourth arg NOSUFFIX is non-nil, don't try adding
  suffixes `.elc' or `.el' to the specified name FILE.
  If optional fifth arg MUST-SUFFIX is non-nil, insist on
  the suffix `.elc' or `.el'; don't accept just FILE unless
  it ends in one of those suffixes or includes a directory name.
  Return t if file exists. */
TLMRESULT
lispMachineState_Load (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntArgtop ;
	TLispEntity*	pEntFile ;
	TLispEntity*	pEntNoMsg ;
	TLispEntity*	pEntNoError ;

	ASSERT (pLM != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	pEntArgtop	= pEntArglist ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntFile)) ||
		TFAILED (lispEntity_Stringp (pLispMgr, pEntFile))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispEntity_GetCdr (pLispMgr, pEntArglist, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntNoError) ;
	lispEntity_GetCdr (pLispMgr, pEntArglist, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntNoMsg) ;

	lispMachineCode_PushLReg (pLM, LM_LREG_1) ;
	lispMachineCode_PushLReg (pLM, LM_LREG_2) ;
	lispMachineCode_PushLReg (pLM, LM_LREG_3) ;
	lispMachineCode_PushLReg (pLM, LM_LREG_4) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_1, pEntFile) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_2, pEntNoError) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_3, pEntNoMsg) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_4, pEntArglist) ;
	lispMachineCode_SetState (pLM, lispMachineState_loadStep1) ;
	return	LMR_CONTINUE ;
}

/*	private functions */
TLMRESULT
lispMachineState_loadStep1 (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*			pEntFile ;
	const Char*				pFileName ;
	int						nFileNameLen ;
	register TLispEntity*	pEntLoadPath ;
	TLispEntity*			pValDirList ;
	TLispEntity*			pEntRetval	= NULL ;
	register BOOL		fResult ;
	static const Char		chDelimitar	= '/' ;
	TVarbuffer				vbufFileName ;

	lispMachineCode_GetLReg (pLM, LM_LREG_1, &pEntFile) ;
	lispEntity_GetStringValue (pLispMgr, pEntFile, &pFileName, &nFileNameLen) ;
	if (pFileName == NULL || nFileNameLen <= 0) {
		lispMachineCode_SetError (pLM) ;
		lispMachineCode_SetState (pLM, lispMachineState_loadFinalize) ;
		return	LMR_CONTINUE ;
	}

	/*	load-path �����ԂɌ�������B*/
	pEntLoadPath	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_LOAD_PATH) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntLoadPath, &pValDirList)))
		lispMgr_CreateNil (pLispMgr, &pValDirList) ;

	if (TFAILED (TVarbuffer_Initialize (&vbufFileName, sizeof (Char))))
		return	LMR_ERROR ;

	fResult	= FALSE ;
	while (!fResult && TFAILED (lispEntity_Nullp (pLispMgr, pValDirList))) {
		TLispEntity*	pValDir ;
		TLispEntity*	pEntCdr ;
		const Char*		strDir ;
		int				nstrDir ;
		const Char*		strPath ;
		int				nstrPath ;
		
		if (TFAILED (lispEntity_GetCar (pLispMgr, pValDirList, &pValDir)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pValDirList, &pEntCdr))  ||
			TFAILED (lispEntity_GetStringValue (pLispMgr, pValDir, &strDir, &nstrDir)))
			break ;
		if (TFAILED (TVarbuffer_Add (&vbufFileName, strDir, nstrDir)) ||
			TFAILED (TVarbuffer_Add (&vbufFileName, &chDelimitar, 1)) ||
			TFAILED (TVarbuffer_Add (&vbufFileName, pFileName, nFileNameLen))) 
			return	LMR_ERROR ;
		
		strPath		= TVarbuffer_GetBuffer (&vbufFileName) ;
		nstrPath	= TVarbuffer_GetUsage  (&vbufFileName) ;
		fResult		= lispMgr_Load (pLispMgr, strPath, nstrPath, &pEntRetval) ;
		TVarbuffer_Clear (&vbufFileName) ;
		pValDirList	= pEntCdr ;
	}
	TVarbuffer_Uninitialize (&vbufFileName) ;

	if (TFAILED (fResult)) 
		fResult		= lispMgr_Load (pLispMgr, pFileName, nFileNameLen, &pEntRetval) ;

	if (TFAILED (fResult)) {
		TLispEntity*	pEntNoError ;
		/*	noerror �� t �Ȃ�t�@�C�������������ꍇ�ɃG���[�ɂȂ�Ȃ��B*/
		lispMachineCode_GetLReg (pLM, LM_LREG_2, &pEntNoError) ;
		if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntNoError))) 
			lispMachineCode_SetError (pLM) ;
		lispMachineCode_SetState (pLM, lispMachineState_loadFinalize) ;
		return	LMR_CONTINUE ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	lispEntity_Release (pLispMgr, pEntRetval) ;
	lispMachineCode_PushState (pLM, lispMachineState_loadFinalize) ;
	lispMachineCode_SetState  (pLM, lispMachineState_Progn) ;
	return	LMR_CONTINUE ;
}

TLMRESULT
lispMachineState_loadFinalize (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntNoMessage ;

	if (LISPMACHINE_EXCEPTIONORSIGNALP (pLM)) 
		goto	exit_finalize ;

	lispMachineCode_GetLReg (pLM, LM_LREG_3, &pEntNoMessage) ;
	if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntNoMessage))) 
		goto	exit_finalize ;

exit_finalize:
	lispMachineCode_PopLReg (pLM, LM_LREG_4) ;
	lispMachineCode_PopLReg (pLM, LM_LREG_3) ;
	lispMachineCode_PopLReg (pLM, LM_LREG_2) ;
	lispMachineCode_PopLReg (pLM, LM_LREG_1) ;
	return	LMR_RETURN ;
}

/*	built-in function:
 *		(insert-file-contents FILENAME &optional VISIT BEG END REPLACE)
 *
 *	�ł͂��邪�AFILENAME �� VISIT �ȊO�������������͍��̂Ƃ���Ȃ��B
 *	�Â� emacs �ł� FILENAME �� VISIT �̑����Ƃ邱�Ƃ͂ł��Ȃ������悤�B
 *
 *	VISIT �� non-nil �̏ꍇ�ɂ́A�ǂݍ��� FILE �� VISIT �t�@�C������
 *	�X�V���āATIMESTAMP ���X�V���āAmodified �� nil �ɂ���B�t�@�C����
 *	���݂��Ȃ��ꍇ�ł� visiting �͊�������B
 */
TLMRESULT
lispMachineState_InsertFileContents (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntFileName ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	apEntity [2] ;
	TLispEntity*	pEntRetval ;
	const Char*		pStrFileName ;
	int				nStrFileName ;
	TCHAR			rchPath [PATH_MAX + 1] ;
	KFILE			kfile ;
	int				nReadCount ;
	int				nPoint, n ;

	ASSERT (pLM != NULL) ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	ASSERT (pEntBuffer != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntFileName) ;
	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntFileName, &pStrFileName, &nStrFileName))) 
		goto	error ;

	n	= internal2wstr (rchPath, PATH_MAX, pStrFileName, nStrFileName) ;
	if (n > PATH_MAX)
		goto	error ;
	rchPath [n]	= TEXT ('\0') ;	

	lispBuffer_Point (pLispMgr, pEntBuffer, &nPoint) ;
	nReadCount	= 0 ;

	if (!KFile_Open (&kfile, rchPath, KCODING_SYSTEM_UNKNOWN)) {
#if defined (DEBUG) || defined (_DEBUG)
		fprintf (stderr, "Can't open file: \"%s\"\n", rchPath) ;
#endif
		goto	result ;
	}
	KFile_Rewind (&kfile) ;
	lispBuffer_InsertFileContents (pLispMgr, pEntBuffer, nPoint, &kfile, &nReadCount) ;
	KFile_Close (&kfile) ;

  result:
	if (TFAILED (lispMgr_CreateInteger (pLispMgr, nReadCount, &apEntity [1])))
		return	LMR_ERROR ;
	apEntity [0]	= pEntFileName ;
	if (TFAILED (lispMgr_CreateList (pLispMgr, apEntity, 2, &pEntRetval)))
		return	LMR_ERROR ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;

  error:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

