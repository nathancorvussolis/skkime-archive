/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "lmachinep.h"
/*
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"
*/

static	BOOL	lispMachine_putAlist (TLispManager*, TLispEntity*, TLispEntity*, TLispEntity*, TLispEntity**) ;
static	BOOL	lispMachine_modifyAlist	(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity**) ;

/*
 *	(put-alist ITEM VALUE ALIST)
 *
 *	ITEM �� VALUE ���Z�b�g����悤�� ALIST ���C������B
 *	���� car �� ITEM �ł��� pair �����݂�����A���� cdr �� VALUE ��
 *	�u��������B
 *	��������ȃy�A���Ȃ���΁A(ITEM . VALUE) �Ƃ����V�����y�A�����
 *	car ���V�����y�A�� cdr �� ALIST �ł���V�������X�g������ĕԂ��B
 */
TLMRESULT
lispMachineState_PutAlist (
	register TLispMachine*	pLM)
{
	register TLispManager*		pLispMgr ;
	TLispEntity*		pArglist ;
	TLispEntity*		pItem ;
	TLispEntity*		pValue ;
	TLispEntity*		pAlist ;
	TLispEntity*		pRetval ;
	TLispEntity*		pCdr ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pArglist, &pItem))  ||
		TFAILED (lispEntity_GetCdr  (pLispMgr, pArglist, &pCdr))   ||
		TFAILED (lispEntity_GetCar  (pLispMgr, pCdr,     &pValue)) ||
		TFAILED (lispEntity_GetCadr (pLispMgr, pCdr,     &pAlist)) ||
		TFAILED (lispEntity_Listp   (pLispMgr, pAlist))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (TFAILED (lispMachine_putAlist (pLispMgr, pItem, pValue, pAlist, &pRetval))) {
		lispMachineCode_SetError (pLM) ;
	} else {
		lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pRetval) ;
	}
	return	LMR_RETURN ;
}

/*
 *
 */
TLMRESULT
lispMachineState_ModifyAlist (
	register TLispMachine*	pLM)
{
	register TLispManager*		pLispMgr ;
	TLispEntity*		pEntArglist ;
	TLispEntity*		pEntModifier ;
	TLispEntity*		pEntDefault ;
	TLispEntity*		pEntRetval ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntModifier)) ||
		TFAILED (lispEntity_GetCdr  (pLispMgr, pEntArglist, &pEntArglist)) ||
		TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntDefault)) ||
		TFAILED (lispMachine_modifyAlist (pLispMgr, pEntModifier, pEntDefault, &pEntRetval))) {
		lispMachineCode_SetError (pLM) ;
	} else {
		lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	}
	return	LMR_RETURN ;
}

/*
 *	(set-modified-alist SYMBOL MODIFIER)
 *
 *	alist MODIFIER �̒��̗v�f�� SYMBOL �� bound ���ꂽ alist �̒���
 *	store ����B���� SYMBOL �� bound ����Ă��Ȃ���΁A�ŏ��� nil ��
 *	set �����B
 */
TLMRESULT
lispMachineState_SetModifiedAlist (
	register TLispMachine*	pLM)
{
	register TLispManager*		pLispMgr ;
	TLispEntity*		pEntArglist ;
	TLispEntity*		pEntSymbol ;
	TLispEntity*		pEntModifier ;
	TLispEntity*		pEntValue ;
	TLispEntity*		pEntRetval ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntSymbol)) ||
		TFAILED (lispEntity_Symbolp (pLispMgr, pEntSymbol)) ||
		TFAILED (lispEntity_GetCdr  (pLispMgr, pEntArglist, &pEntArglist)) ||
		TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntModifier))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_ERROR ;
	}
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntSymbol, &pEntValue)) ||
		TSUCCEEDED (lispEntity_Voidp (pLispMgr, pEntValue))) {
		lispMgr_CreateNil (pLispMgr, &pEntValue) ;
		lispMachine_SetCurrentSymbolValue (pLM, pEntSymbol, pEntValue) ;
	}
	if (TFAILED (lispMachine_modifyAlist (pLispMgr, pEntModifier, pEntValue, &pEntRetval))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_ERROR ;
	}
	lispMachine_SetCurrentSymbolValue (pLM, pEntSymbol, pEntRetval) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

BOOL
lispMachine_putAlist (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntItem,
	register TLispEntity*	pEntValue,
	register TLispEntity*	pEntAlist,
	register TLispEntity**	ppEntRetval)
{
	TLispEntity*	pEntAlistBack ;
	TLispEntity*	pEntNextAlist ;
	TLispEntity*	pEntNewPair ;
	TLispEntity*	pEntNewAlist ;
	TLispEntity*	pEntPair ;
	BOOL			fResult ;

	pEntAlistBack	= pEntAlist ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntAlist))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntAlist, &pEntPair))) {
			return	FALSE ;
		}
		if (TSUCCEEDED (lispEntity_Consp (pLispMgr, pEntPair))) {
			TLispEntity*	pEntCar ;
			(void) lispEntity_GetCar (pLispMgr, pEntPair, &pEntCar) ;
			if (TSUCCEEDED (lispEntity_Equal (pLispMgr, pEntCar, pEntItem))) {
				lispEntity_SetCdr (pLispMgr, pEntPair, pEntValue) ;
				*ppEntRetval	= pEntAlistBack ;
				return	TRUE ;
			}
		}
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntAlist, &pEntNextAlist))) 
			return	FALSE ;
		pEntAlist	= pEntNextAlist ;
	}
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntItem, pEntValue, &pEntNewPair)) ||
		pEntNewPair == NULL)
		return	FALSE ;
	lispEntity_AddRef (pLispMgr, pEntNewPair) ;
	fResult	= lispMgr_CreateConscell (pLispMgr, pEntNewPair, pEntAlistBack, &pEntNewAlist) ;
	lispEntity_Release (pLispMgr, pEntNewPair) ;
	*ppEntRetval	= pEntNewAlist ;
	return	fResult ;
}

BOOL
lispMachine_modifyAlist (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntModifier,
	register TLispEntity*	pEntDefault,
	register TLispEntity**	ppEntRetval)
{
	TLispEntity*	pEntItem ;
	TLispEntity*	pEntValue ;
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntCdr ;
	TLispEntity*	pEntAlist ;
	TLispEntity*	pEntNewAlist ;

	pEntAlist	= pEntDefault ;
	lispEntity_AddRef (pLispMgr, pEntAlist) ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntModifier))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntModifier, &pEntCar)))
			return	FALSE ;
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntCar, &pEntItem)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntCar, &pEntValue))) 
			return	FALSE ;
		lispMachine_putAlist (pLispMgr, pEntItem, pEntValue, pEntAlist, &pEntNewAlist) ;
		lispEntity_AddRef  (pLispMgr, pEntNewAlist) ;
		lispEntity_Release (pLispMgr, pEntAlist) ;
		pEntAlist	= pEntNewAlist ;
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntModifier, &pEntCdr)))
			return	FALSE ;
		pEntModifier	= pEntCdr ;
	}
	*ppEntRetval	= pEntAlist ;
	return	TRUE ;
}

