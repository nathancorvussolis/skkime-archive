#include "lmachinep.h"
/*
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "vstack.h"
*/

BOOL
Vstack_Initialize   (VStack* pStack, int nWidth)
{
	assert (pStack != NULL) ;
	assert (nWidth >  0) ;

	pStack->m_pBuffer	= pStack->m_achInternal ;
	pStack->m_nSize		= DEFAULT_VSTACK_SIZE / nWidth ;
	pStack->m_nUsage	= 0 ;
	pStack->m_nWidth	= nWidth ;
	return	TRUE ;
}

BOOL
Vstack_Uninitialize (VStack* pStack)
{
	assert (pStack != NULL) ;

	if (pStack->m_pBuffer != pStack->m_achInternal) {
		FREE (pStack->m_pBuffer) ;
		pStack->m_pBuffer	= pStack->m_achInternal ;
	}
	pStack->m_nUsage	= 0 ;
	pStack->m_nSize		= 0 ;
	pStack->m_nWidth	= 0 ;
	return	TRUE ;
}

BOOL
Vstack_Push         (VStack* pStack, const void* pData)
{
	int		nPosition ;

	assert (pStack != NULL) ;
	assert (pData  != NULL) ;

	nPosition	= pStack->m_nWidth * pStack->m_nUsage ;

	if ((pStack->m_nUsage + 1) > pStack->m_nSize) {
		unsigned char*	pNewBuffer ;
		int				nNewSize ;

		nNewSize	= (pStack->m_nUsage + 1 + DEFAULT_VSTACK_SIZE) ;
		nNewSize	= nNewSize - nNewSize % DEFAULT_VSTACK_SIZE ;
 
		pNewBuffer	= MALLOC (nNewSize * pStack->m_nWidth) ;
		if (pNewBuffer == NULL) 
			return	FALSE ;

		assert (pNewBuffer != NULL) ;
		if (pStack->m_pBuffer != pStack->m_achInternal) {
			memcpy (pNewBuffer, pStack->m_pBuffer, nPosition) ;
			FREE (pStack->m_pBuffer) ;
		} else {
			memcpy (pNewBuffer, pStack->m_achInternal, nPosition) ;
		}
		pStack->m_pBuffer	= pNewBuffer ;
		pStack->m_nSize		= nNewSize ;
	}
	memcpy ((unsigned char*)pStack->m_pBuffer + nPosition, pData, pStack->m_nWidth) ;
	pStack->m_nUsage	++ ;
	return	TRUE ;
}

BOOL
Vstack_Pop          (VStack* pStack, void* pData)
{
	int			nPos ;

	assert (pStack != NULL) ;

	if (pStack->m_nUsage <= 0)
		return	FALSE ;

	pStack->m_nUsage	-- ;
	if (pData == NULL) 
		return	TRUE ;

	nPos	= pStack->m_nWidth * pStack->m_nUsage ;
	memcpy (pData, (unsigned char*)pStack->m_pBuffer + nPos, pStack->m_nWidth) ;
	return	TRUE ;
}


BOOL
Vstack_Clear        (VStack* pStack)
{
	pStack->m_nUsage	= 0 ;
	return	TRUE ;
}

BOOL
Vstack_Emptyp       (VStack* pStack)
{
	return	(pStack->m_nUsage == 0)? TRUE : FALSE ;
}

BOOL
Vstack_GetHead		(VStack* pStack, void* pData)
{
	int		nPosition ;

	if (pStack->m_nUsage <= 0)
		return	FALSE ;
	
	nPosition	= pStack->m_nWidth * (pStack->m_nUsage - 1) ;
	memcpy (pData, (unsigned char *)pStack->m_pBuffer + nPosition, pStack->m_nWidth) ;
	return	TRUE ;
}

int
Vstack_GetUsage		(VStack* pStack)
{
	return	pStack->m_nUsage ;
}

void
Vstack_DropN		(VStack* pStack, int nLength)
{
	pStack->m_nUsage	-= nLength ;
	if (pStack->m_nUsage <= 0)
		pStack->m_nUsage	= 0 ;
	return ;
}





