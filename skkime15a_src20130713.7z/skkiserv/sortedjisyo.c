#include "local.h"
#include "jisyo.h"
#include "sortedjisyo.h"
#include "kanji.h"
// #include "varbuffer.h"
#include "cstring.h"
#include "kstring.h"

#define	BUFSIZE				(4096)
#define	KEOF				((Char)-1)

/* '��' ���� '��' �܂ŁB*/
#define	MYCHAR_KANA_START	(Char_Make (KCHARSET_JISX0208_1983, 0x2421))
#define	MYCHAR_KANA_END		(Char_Make (KCHARSET_JISX0208_1983, 0x2473))
#define AFTER_KANA			(MYCHAR_KANA_END - MYCHAR_KANA_START + 1)
#define EOL					(0x0a)

#define	MYSTR1				";; okuri-ari entries."
#define	MYSTR2				";; okuri-nasi entries."

/*
 *	Prototypes
 */
static	SkkJisyo*	skkSortedJisyo_create	(LPCTSTR, int) ;
static	BOOL		skkSortedJisyo_search 	(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
static	BOOL		skkSortedJisyo_destroy	(SkkJisyo*) ;
static	LPCTSTR		skkSortedJisyo_getPath	(SkkJisyo*) ;

static	int		skkSortedJisyo_lookupIndexPosition(Char ch) ;
static	BOOL	skkSortedJisyo_makeTab (HANDLE hFile, int nCodingSystem, DWORD* pTab1, DWORD* pTab2) ;
static	BOOL	skkSortedJisyo_searchRange (SkkSortedJisyo*, const Char*, int, int, long, long, TVarbuffer*) ;
static	int		skkSortedJisyo_compare (Char, Char, int) ;
static	BOOL	skkSortedJisyo_find (HANDLE hFile, KANJISTATEMACHINE* pKSM, TVarbuffer* pvbuf, TVarbuffer* pvbufResult) ;

/*
 *	Global Variables
 */
static SkkJisyoFunc		sSortedJisyoProcTbl	= {
	skkSortedJisyo_search,
	NULL,
	NULL,
	NULL,
	NULL,
	skkSortedJisyo_destroy,
	skkSortedJisyo_getPath,
} ;

SkkJisyo*
SkkSortedJisyo_Create (
	register const Char*	pFileName,
	register int			nFileName,
	register int			nCodingSystem)
{
	TCHAR				strPath [PATH_MAX + 1] ;
	register SkkJisyo*	pJisyo ;

	if (nFileName > PATH_MAX)
		return	NULL ;

#if defined (UNICODE)
	internal2wstr (strPath, ARRAYSIZE (strPath) - 1, pFileName, nFileName) ;
#else
	cstrtostr (strPath, pFileName, nFileName) ;
#endif
	strPath [nFileName]	= TEXT('\0') ;

	/* �����t�@�C�����Ǘ����邽�߂̃f�[�^�̈���m�ۂ���B*/
	pJisyo	= skkSortedJisyo_create (strPath, nCodingSystem) ;
	return	pJisyo ;
}

SkkJisyo*
SkkSortedJisyo_CreateT (
	register LPCTSTR		pFileName,
	register int			nCodingSystem)
{
	register int		nFileName ;

	if (pFileName == NULL)
		return	NULL ;

	nFileName	= lstrlen (pFileName) ;
	if (nFileName >= PATH_MAX)
		return	NULL ;

	/* �����t�@�C�����Ǘ����邽�߂̃f�[�^�̈���m�ۂ���B*/
	return	skkSortedJisyo_create (pFileName, nCodingSystem) ;
}

/*
 *	Private Functions
 */
SkkJisyo*
skkSortedJisyo_create (
	register LPCTSTR	strPath,
	register int		nCodingSystem)
{
	SkkJisyo*			pSkkJisyo ;
	SkkSortedJisyo*	pJisyo ;
	HANDLE	hFile = INVALID_HANDLE_VALUE ;

	DEBUGPRINTF ((TEXT ("SkkSortedJisyo_Create (jisyo => \"%s\")\n"), strPath)) ;

	pSkkJisyo	= MALLOC (sizeof (SkkJisyo) + sizeof (SkkSortedJisyo)) ;
	if (pSkkJisyo == NULL)
		return	NULL ;
	memset (pSkkJisyo, 0, (sizeof (SkkJisyo) + sizeof (SkkSortedJisyo))) ;

	pSkkJisyo->m_pVtbl	= &sSortedJisyoProcTbl ;
	pJisyo				= (SkkSortedJisyo *)(pSkkJisyo + 1) ;

	{
		LPCTSTR pSrc ;
		LPTSTR pDest ;
		int	cc, nDest;

		pSrc	= strPath ;
		pDest	= pJisyo->m_tszPath ;
		nDest	= MAX_PATH ;
		while (cc = *pSrc ++, cc != TEXT ('\0') && nDest -- > 0) 
			*pDest ++	= (TCHAR)((cc == TEXT ('/'))? TEXT ('\\') : (TCHAR) cc) ;
		*pDest	= TEXT ('\0') ;
	}
	hFile	= CreateFile (pJisyo->m_tszPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE) 
		goto	exit_func ;


	{
		DWORD	dwFileSize, dwFileSizeHigh, dwRead ;
		char	buf[BUFSIZE] ;

		dwFileSize = GetFileSize (hFile, &dwFileSizeHigh) ;
		/* �����̕�����������@�����o����B*/
		if (! ReadFile (hFile, buf, sizeof(buf), &dwRead, NULL))
			goto	exit_func ;
		SetFilePointer (hFile, 0, NULL, FILE_BEGIN) ;
		pJisyo->m_nCodingSystem	= DetectKanjiCodingSystem (buf, dwRead, NULL) ;
		pJisyo->m_nBufferSize = dwFileSize ;
	}
	pJisyo->m_lFormat		= 1 ;
	
	/* �����^�O���쐬����B*/
	if (TFAILED (skkSortedJisyo_makeTab (hFile, pJisyo->m_nCodingSystem, pJisyo->m_jtab1, pJisyo->m_jtab2))) {
		DEBUGPRINTF ((TEXT ("MakeTab failed\n"))) ;
		goto	exit_func ;
	}
	CloseHandle (hFile) ;
	return	pSkkJisyo ;

  exit_func:
	if (hFile != INVALID_HANDLE_VALUE && hFile != NULL)
		CloseHandle (hFile) ;
	FREE (pSkkJisyo) ;
	return	NULL ;
	UNREFERENCED_PARAMETER(nCodingSystem);
}

BOOL
skkSortedJisyo_search (
	SkkJisyo*		pSkkJisyo,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	TVarbuffer*		pvbuf)
{
	SkkSortedJisyo*	pJisyo	= (SkkSortedJisyo *)(pSkkJisyo + 1) ;
	Char		cc ;
	long		lStartPosition ;
	long		lEndPosition ;
	int			iSearchStyle, index ;

	if (pKey == NULL || nKey <= 0 || Char_IsNul (*pKey))
		return	TRUE ;

	if (pJisyo->m_lFormat == 0){
		iSearchStyle	= 0 ;
	} else {
		iSearchStyle	= (nOkuriType != SEARCH_OKURI_NASHI)? 2 : 1 ;
	}
	cc	= *pKey ;
	if ((iSearchStyle == 0) || (iSearchStyle == 2)) {
		index = skkSortedJisyo_lookupIndexPosition(cc) ;
		lStartPosition	= pJisyo->m_jtab1 [index] ;
		lEndPosition	= index > 0? pJisyo->m_jtab1 [index-1] : pJisyo->m_jtab2[0] ;
	} else {
		index = skkSortedJisyo_lookupIndexPosition(cc) ;
		lStartPosition	= pJisyo->m_jtab2 [index] ;
		lEndPosition	= pJisyo->m_jtab2 [index+1] ;
	}
	return	skkSortedJisyo_searchRange (pJisyo, pKey, nKey, iSearchStyle, lStartPosition, lEndPosition, pvbuf) ;
	UNREFERENCED_PARAMETER (pOkurigana) ;
	UNREFERENCED_PARAMETER (nOkurigana) ;
}

BOOL
skkSortedJisyo_destroy (
	register SkkJisyo*	pSkkJisyo)
{
	if (pSkkJisyo == NULL) 
		return	TRUE ;
	FREE (pSkkJisyo) ;
	return	TRUE ;
}

LPCTSTR
skkSortedJisyo_getPath	(
	register SkkJisyo*		pSkkJisyo)
{
	register SkkSortedJisyo*	pJisyo	= (SkkSortedJisyo *)(pSkkJisyo + 1) ;

	return	pJisyo->m_tszPath ;
}

/*========================================================================
 *	private functions
 */
BOOL
skkSortedJisyo_searchRange (
	register SkkSortedJisyo*	pJisyo,
	register const Char*		pKey,
	register int				nKey,
	register int				iSearchStyle,
	register long				lStartPosition,
	register long				lEndPosition,
	register TVarbuffer*		pvbuf)
{
	BYTE buf[BUFSIZE] ;
	Char cc ;
	const Char* pKeyEnd ;
	HANDLE	hFile ;
	KANJISTATEMACHINE	ksm ;
	DWORD	dwRead ;
	BOOL bRetval = TRUE ;
	long lPosition ;
	TVarbuffer vbuf ;
	const Char* pSearch ;
	BOOL	bNeedEOL ;

	if (lStartPosition >= lEndPosition || lStartPosition >= (long)pJisyo->m_nBufferSize)
		return	TRUE ;

	cc			= '\0' ;
	hFile	= CreateFile (pJisyo->m_tszPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE) 
		return	FALSE ;

	SetFilePointer (hFile, lStartPosition, NULL, FILE_BEGIN) ;

	pSearch = pKey ;
	pKeyEnd = pKey + nKey ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;
	InitializeKanjiFiniteStateMachine(&ksm, pJisyo->m_nCodingSystem) ;
	lPosition = lStartPosition ;
	bNeedEOL = FALSE ;
	do {
		DWORD	dwToRead ;
		const BYTE* ptr ;
		const BYTE* pEnd ;

		dwToRead = (lEndPosition - lStartPosition) ;
		dwToRead = (dwToRead >= sizeof(buf))? sizeof(buf) : dwToRead ;
		if (! ReadFile(hFile, buf, dwToRead, &dwRead, NULL)) 
			goto	exit_func ;

		ptr  = buf ;
		pEnd = buf + dwRead ;
		while (ptr < pEnd) {
			if (! bNeedEOL) {
				//	�P��̐؂�o���B
				while (ptr < pEnd) {
					Char bufCH[16] ;
					int	i, n ;

					n	= TransferKanjiFiniteStateMachine (&ksm, *ptr ++, bufCH) ;
					if (n > 0) {
						BOOL	bFound = FALSE ;

						if (pSearch == pKeyEnd) {
							if (n == 1 && ! Char_DifferenceAscii(bufCH[0], ' ')) {
								bFound = TRUE ;
							} else {
								bNeedEOL = TRUE ;
								goto	not_found ;
							}
						} else {
							for (i = 0 ; i < n && pSearch < pKeyEnd ; i ++) {
								Char cc = *pSearch ++ ;

								if (Char_Difference(bufCH[i], cc) != 0) {
									if (skkSortedJisyo_compare (bufCH[i], cc, iSearchStyle))
										goto	exit_func ;
									bNeedEOL = TRUE ;
									goto	not_found ;
								}
							}
							if (i < n && ! Char_DifferenceAscii(bufCH[i], ' ') && pSearch == pKeyEnd) {
								bFound = TRUE ;
							}
						}
						if (bFound) {
							//	bufCH �ɕ������c���Ă��Ă��A
							//	�u���炩�̃R�[�h -> �����̓���Char�v�ɓW�J�����
							//	�X�Ɂu�Ō�̕��ɃX�y�[�X������v�ȂǂƂ����ϊ��͂Ȃ��c���B
							while (ptr < pEnd) {
								n	= TransferKanjiFiniteStateMachine (&ksm, *ptr ++, bufCH) ;
								if (n > 0) {
									if (TFAILED (TVarbuffer_Add (&vbuf, bufCH, n))) {
										bRetval	= FALSE ;
										goto	exit_func ;
									}
									for (i = 0 ; i < n ; i ++)
										if (bufCH[i] == EOL)
											goto	found_eol ;
								}
							}
found_eol:
							bRetval = skkSortedJisyo_find (hFile, &ksm, &vbuf, pvbuf) ;
							goto	exit_func ;
						}
					}
				}
			}
not_found:
			if (bNeedEOL) {
				//	not found
				while (ptr < pEnd) {
					Char bufCH[16] ;
					int	i, n ;
					n	= TransferKanjiFiniteStateMachine (&ksm, *ptr ++, bufCH) ;
					if (n > 0) {
						for (i = 0 ; i < n && bufCH[i] != EOL ; i ++)
							;
						if (i < n && bufCH[i] == EOL) {
							pSearch = pKey ;
							bNeedEOL = FALSE ;
							break ;
						}
					}
				}
			}
		}
		lPosition += dwRead ;
	}	while (lPosition < lEndPosition && dwRead == sizeof(buf)) ;

exit_func:
	CloseHandle (hFile) ;
	TVarbuffer_Uninitialize(&vbuf) ;
	return	bRetval ;
}

BOOL
skkSortedJisyo_find (HANDLE hFile, KANJISTATEMACHINE* pKSM, TVarbuffer* pvbuf, TVarbuffer* pvbufResult)
{
	BYTE	buf [4096] ;
	DWORD	dwRead ;

	//	�s����T���B
	do {
		const BYTE*	pBuf ;
		const BYTE* pBufEnd ;

		if (! ReadFile (hFile, buf, sizeof(buf), &dwRead, NULL))
			return	FALSE ;
		pBuf = buf ;
		pBufEnd = buf + dwRead ;
		while (pBuf < pBufEnd) {
			Char bufCH [16] ;
			int	i, n ;

			n	= TransferKanjiFiniteStateMachine (pKSM, *pBuf ++, bufCH) ;
			if (n > 0) {
				for (i = 0 ; i < n && bufCH[i] != EOL ; i ++)
					;
				if (i > 0 && TFAILED (TVarbuffer_Add (pvbuf, bufCH, i)))
					return	FALSE ;
				if (i < n)
					goto	found ;
			}
		}
	} while (dwRead == sizeof(buf)) ;

	//	�s�������t����Ȃ������ꍇ�B
	return	TRUE ;
found:
	{
		const Char* pText = TVarbuffer_GetBuffer(pvbuf) ;
		int nText = TVarbuffer_GetUsage(pvbuf) ;
		const Char* pTextEnd = pText + nText ;
		const Char* pTextStart ;
		BOOL bDuringAnnotation ;
		Char chPrev ;

		while (pText < pTextEnd && ! Char_DifferenceAscii(*pText, ' '))
			pText ++ ;

		chPrev				= '\0' ;
		bDuringAnnotation	= FALSE ;

		pTextStart = pText ;
		while (pText < pTextEnd) {
			/*	����ϊ������Ȃ��̂ŁA'[' �ȍ~�͖������Ȃ���΂Ȃ�Ȃ��B���Aannotated �Ȏ����̏ꍇ
			 *	���߂� '[' �����p����邱�Ƃ����肦��B[�L�F����17�N2��14��(��)]
			 */
			switch (*pText) {
				case	EOL:
				case	KEOF:
					goto	exit_loop ;
				case	'[':
					if (chPrev == '/' && ! bDuringAnnotation)
						goto	exit_loop ;
					break ;
				case	'/':
					bDuringAnnotation	= FALSE ;
					break ;
				case	';':
					if (! bDuringAnnotation)
						bDuringAnnotation	= TRUE ;
					break ;
				default:
					break ;
			}
			chPrev	= *pText ;
			pText ++ ;
		}
exit_loop:
		if (pText > pTextStart && TFAILED (TVarbuffer_Add(pvbufResult, pTextStart, pText - pTextStart)))
			return	FALSE ;
	}
	return	TRUE ;
}


int
skkSortedJisyo_compare (
	register Char	c1,
	register Char	c2,
	register int	f)
{
	if (c1 == ' ' || c1 == '\n')
		c1	= 0 ;
	if (c2 == ' ')
		c2	= 0 ;
	if (f != 1) {
		return	(c1 < c2) ;
	} else {
		return	(c1 > c2) ;
	}
}

int
skkSortedJisyo_lookupIndexPosition(Char ch)
{
	if (ch < MYCHAR_KANA_START)
		return 0 ;
	if (ch > MYCHAR_KANA_END)
		return	AFTER_KANA + 1 ;
	return (ch - MYCHAR_KANA_START) + 1 ;
}

enum {
	SEEKING_OKURIARI	= 0,
	PROCESS_OKURIARI,
	PROCESS_OKURINASI,
} ;

BOOL
skkSortedJisyo_makeTab (HANDLE hFile, int nCodingSystem, DWORD* pTab1, DWORD* pTab2)
{
	BYTE	buf[BUFSIZE] ;
	TVarbuffer	vbuf ;
	KANJISTATEMACHINE	ksm ;
	DWORD	dwFilePosition, dwLineTopPosition, dwState, dwRead ;
	int	i ;
	BOOL	bRetval = FALSE ;

	//	index �̏������B
	for (i = 0 ; i < KANAMOJI ; i ++) 
		pTab1 [i] = pTab2 [i] = (DWORD) -1 ;

	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;
	InitializeKanjiFiniteStateMachine(&ksm, nCodingSystem) ;
	dwLineTopPosition = 0 ;
	dwFilePosition = 0 ;

	dwState = SEEKING_OKURIARI ;
	do {
		DWORD dwPos ;

		if (! ReadFile (hFile, buf, sizeof (buf), &dwRead, 0))
			goto	exit_func ;

		dwPos = 0 ;
		while (dwPos < dwRead) {
			Char bufChar[32] ;
			int	n ;

			//	�����̏����� Unicode ���Ƃ����͂����Ȃ��B
			while (dwPos < dwRead && buf[dwPos] != 0x0A) {
				n = TransferKanjiFiniteStateMachine(&ksm, buf [dwPos], bufChar) ;
				if (n > 0 && TFAILED (TVarbuffer_Add(&vbuf, bufChar, n)))
					goto	exit_func ;
				dwPos ++ ;
			}
			if (dwPos < dwRead) {
				const Char*	pText = (Char*) TVarbuffer_GetBuffer(&vbuf) ;
				int nText = TVarbuffer_GetUsage(&vbuf) ;

				if (nText > 0) {
					int	index ;

					switch (dwState) {
					case	SEEKING_OKURIARI:
						if (! Cstrnccmp (pText, MYSTR1, lstrlenA(MYSTR1))) 
							dwState = PROCESS_OKURIARI ;
						//	�R�����g�̏����B
						if (! Char_DifferenceAscii (*pText, ';') || ! Char_DifferenceAscii (*pText, ' '))
							break ;
						break ;
					case	PROCESS_OKURIARI:
						if (! Cstrnccmp (pText, MYSTR2, lstrlenA(MYSTR2))) {
							for (i = 0 ; i < KANAMOJI && pTab1 [i] == (DWORD)-1 ; i ++) 
								pTab1 [i] = dwLineTopPosition ;
							dwState = PROCESS_OKURINASI ;
							break ;
						}
						//	�R�����g�̏����B
						if (! Char_DifferenceAscii (*pText, ';') || ! Char_DifferenceAscii (*pText, ' '))
							break ;
						index = skkSortedJisyo_lookupIndexPosition(*pText) ;
						while (index < KANAMOJI && pTab1 [index] == (DWORD)-1) {
							pTab1 [index ++] = dwLineTopPosition ;
						}
						break ;
					case	PROCESS_OKURINASI:
						//	�R�����g�̏����B
						if (! Char_DifferenceAscii (*pText, ';') || ! Char_DifferenceAscii (*pText, ' '))
							break ;
						index = skkSortedJisyo_lookupIndexPosition(*pText) ;
						while (index >= 0 && pTab2 [index] == (DWORD)-1) {
							pTab2 [index --] = dwLineTopPosition ;
						}
						break ;
					default:
						break ;
					}
				}
				TVarbuffer_Clear(&vbuf) ;
				InitializeKanjiFiniteStateMachine(&ksm, nCodingSystem) ;

				dwPos ++ ;	// skip 0x0A
				dwLineTopPosition = dwFilePosition + dwPos ;	// update line top position
			}
		}
		dwFilePosition += dwRead ;
	} while (dwRead == sizeof (buf)) ;

	for (i = KANAMOJI-1 ; i >= 0 && pTab1 [i] == (DWORD)-1 ; i --) 
		pTab1 [i] = dwFilePosition ;
	for (i = KANAMOJI-1 ; i >= 0 && pTab2 [i] == (DWORD)-1 ; i --) 
		pTab2 [i] = dwFilePosition ;
	bRetval	= TRUE ;

exit_func:
	TVarbuffer_Uninitialize(&vbuf) ;
	return	bRetval ;
}
