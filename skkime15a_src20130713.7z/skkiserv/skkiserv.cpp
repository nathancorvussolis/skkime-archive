// skkiserv.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
// #include "skkiserv.h"

#if defined (USE_LISPEVAL)
#include <shlobj.h>
#include "lisp/lispmgr.h"
#include "lisp/lmachine.h"
#endif

// #include "varbuffer.h"
#include "user.h"
#include "packet.h"
#include "protocol.h"
#include "immsec.h"
#include "kstring.h"

#include "../common/regpath.h"
#include "../common/pipename.h"

/*
/// @note ���̃R�[�h��L��������ƃA���C���X�g�[�����Ɋ����v���Z�X�̍폜�Ɏ��s����̂Œ���
#ifdef WINVER >= 0x0600
#define GORGEOUS
#endif	// WINVER
*/

#define	SKKISERV_CLASSNAME		TEXT("Skkiserv010500Class")
#define	SKKISERV_WNDNAME		TEXT("Skkiserv010500Wnd")

#define	BUFSIZE					2048
#define	PIPE_TIMEOUT			5000
#define	MAX_PIPENAME			256
#define	MAX_PIPE_INSTANCES		4

// Global Variables:
static	HINSTANCE			hInst ;								// current instance
static	HWND				_hwndSkkiserv				= NULL ;
static	HANDLE				_hSkkiservMutex				= NULL ;
static	HANDLE				_hEvQuitRequest				= NULL ;
static	HANDLE				_hEvQuit					= NULL ;
static	CRITICAL_SECTION	_csService ;
static	TCHAR				_srSkkiservPipeName	[MAX_PIPENAME] ;
static	SkkImeUser*			_pSkkiservUser			= NULL ;
#if defined (USE_LISPEVAL)
static	TLispManager*		_pSkkiservLispMgr		= NULL ;
static	TLispMachine*		_pSkkiservLispMachine	= NULL ;
#endif

// Forward declarations of functions included in this code module:
static	ATOM				MyRegisterClass		(HINSTANCE hInstance) ;
static	BOOL				InitInstance		(HINSTANCE, int) ;
static	LRESULT CALLBACK	WndProc				(HWND, UINT, WPARAM, LPARAM) ;

static	LRESULT				skkiserv_onCreate				(HWND, WPARAM, LPARAM) ;
static	LRESULT				skkiserv_onQueryEndSession	(HWND, WPARAM, LPARAM) ;
#ifdef GORGEOUS
static	LRESULT				skkiserv_onEndSession			(HWND, WPARAM, LPARAM) ;
#endif	// GORGEOUS
static	LRESULT				skkiserv_onSettingChange		(HWND, WPARAM, LPARAM) ;

static	unsigned int __stdcall	skkiserv_pipeServerMain	(void*) ;
static	unsigned int __stdcall	skkiserv_pipeMain		(void*) ;
static	unsigned int __stdcall	skkiserv_serviceMain	(void*) ;
static	void	skkiserv_service				(HANDLE) ;
static	BOOL	skkiserv_serviceOpen			(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceSearch			(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceRecord			(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_servicePurge			(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceTryCompletion	(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceEval			(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceSetCutbuffer	(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceGetCutbuffer	(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceUpdate			(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceSearchEx		(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceSetJNumList		(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceSaveLocalJisyo	(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceRecordKakuteiHistory	(HANDLE, int, int, BYTE*, int) ;
static	BOOL	skkiserv_serviceGetKakuteiHistroy	(HANDLE, int, int, BYTE*, int) ;

static	BOOL	skkiserv_replyPacket			(HANDLE, TVarbuffer*) ;
static	BOOL	skkiserv_replyErrorPacket		(HANDLE, int, int, int) ;
static	BOOL	skkiserv_sendPacket				(HANDLE, BYTE*, int) ;
static	BOOL	skkiserv_getClipboardText		(TVarbuffer*) ;

#if defined (USE_LISPEVAL)
static	BOOL	skkiserv_bInitLispMachine		(TLispMachine*, TLispManager*) ;
#endif

int APIENTRY
_tWinMain (
	HINSTANCE		hInstance,
	HINSTANCE		hPrevInstance,
	LPTSTR			lpCmdLine,
	int				nCmdShow)
{
	MSG			msg ;
	HANDLE		hPipeThread ;
	unsigned	nThreadId ;

	_tsetlocale (LC_ALL, TEXT ("japanese")) ;
	ImmDisableIME ((DWORD)-1) ;

	// Initialize global strings
	MyRegisterClass (hInstance) ;

	// Perform application initialization:
	if (!InitInstance (hInstance, SW_HIDE)) {
		return	FALSE ;
	}

	InitializeCriticalSection (&_csService) ;
	hPipeThread	= (HANDLE)_beginthreadex (NULL, 0, skkiserv_pipeServerMain,	NULL, 0, &nThreadId) ;
	if (hPipeThread == INVALID_HANDLE_VALUE)
		goto	_exit_main ;

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage (&msg) ;
		DispatchMessage (&msg) ;
	}

	(void) WaitForSingleObject (hPipeThread, INFINITE) ;
_exit_main:
	CloseHandle (_hEvQuitRequest) ;
	CloseHandle (_hEvQuit) ;
	DeleteCriticalSection (&_csService) ;

	if (_hSkkiservMutex != NULL) {
		ReleaseMutex (_hSkkiservMutex) ;
		CloseHandle (_hSkkiservMutex) ;
		_hSkkiservMutex	= NULL ;
	}
	WSACleanup () ;
	ExitProcess ((UINT)msg.wParam) ;
//	return (int) msg.wParam ;

	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);
	UNREFERENCED_PARAMETER(nCmdShow);
}

//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM
MyRegisterClass (
	HINSTANCE		hInstance)
{
	WNDCLASSEX	wcex ;

	wcex.cbSize			= sizeof (WNDCLASSEX) ;

	wcex.style			= CS_HREDRAW | CS_VREDRAW ;
	wcex.lpfnWndProc	= WndProc ;
	wcex.cbClsExtra		= 0 ;
	wcex.cbWndExtra		= 0 ;
	wcex.hInstance		= hInstance ;
	wcex.hIcon			= NULL ;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW) ;
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1) ;
	wcex.lpszMenuName	= NULL ;
	wcex.lpszClassName	= SKKISERV_CLASSNAME ;
	wcex.hIconSm		= NULL ;

	return	RegisterClassEx (&wcex) ;
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL
InitInstance (
	HINSTANCE		hInstance,
	int				nCmdShow)
{
	HWND hWnd;

	hInst = hInstance; // Store instance handle in our global variable

	hWnd = CreateWindowEx (WS_EX_TOOLWINDOW, SKKISERV_CLASSNAME, SKKISERV_WNDNAME, WS_DISABLED, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if (! hWnd) {
		return	FALSE ;
	}

	ShowWindow (hWnd, nCmdShow) ;
	UpdateWindow (hWnd) ;
	_hwndSkkiserv	= hWnd ;
	return	TRUE ;
}

#define FASTCALL __fastcall

/// �������J���̂��߂̃^�C�}����
class timer_controller_t {
private:
	HWND m_hWnd;

public:
	void FASTCALL set_handle(HWND hWnd)
	{
		ASSERT(this);
		m_hWnd = hWnd;
	}

	/// �ҋ@����ʒm
	void FASTCALL enter()
	{
		ASSERT(this);
		::SendMessage(m_hWnd, WM_USER, 0, 0);
	}

	/// ��������ʒm
	void FASTCALL leave()
	{
		ASSERT(this);
		// ::SendMessage(m_hWnd, WM_USER + 1, 0, 0);
	}
};

/// �������J���̂��߂̃^�C�}���� ����
static timer_controller_t tctrl;

/// �E�B���h�E�v���V�[�W��
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (message == WM_TIMER) {
#if 1
		::SetTimer(hWnd, 0, 60 * 1000, NULL);	// �C�x���g���Ȃ����͊Ԋu��20�{(1��)�ɊJ����
#else
		::KillTimer(hWnd, wParam);				// �^�C�}��~
		if (wParam == 0) ::SetTimer(hWnd, 1, 3 * 60 * 1000, NULL);	// ����̂�3����Ɏd�|����
#endif
		::SetProcessWorkingSetSize(GetCurrentProcess(), (SIZE_T)-1, (SIZE_T)-1);
		return 0;
	}
	::SetTimer(hWnd, 0, 3 * 1000, NULL);		// �C�x���g������������3�b��Ɏd�|����

	switch (message) {
	case WM_CREATE:
		tctrl.set_handle(hWnd);
		return skkiserv_onCreate(hWnd, wParam, lParam);

	case WM_QUERYENDSESSION:
		return skkiserv_onQueryEndSession(hWnd, wParam, lParam);

	case WM_SETTINGCHANGE:
		return skkiserv_onSettingChange(hWnd, wParam, lParam);

	case WM_ENDSESSION:
#ifdef GORGEOUS
		return skkiserv_onEndSession(hWnd, wParam, lParam);
#endif	// GORGEOUS
	case WM_DESTROY:
		::PostQuitMessage(0);
		return 0;
	}

	return ::DefWindowProc(hWnd, message, wParam, lParam);
}

LRESULT
skkiserv_onCreate (
	HWND				hWnd,
	WPARAM				wParam,
	LPARAM				lParam)
{
	WSADATA			wsaData ;
	register WORD	wVersion ;
	TCHAR			rszMutexName [MAX_PATH + 1] ;
	register HANDLE	hMutex ;
	register DWORD	dwResult ;
	TCHAR			rszUserName [UNLEN + 1] ;
	ULONG			ulUserNameLen ;
	LPTSTR			ptr ;

	ulUserNameLen	= sizeof (rszUserName) / sizeof (rszUserName [0]) - 1 ;
	if (! GetUserName (rszUserName, &ulUserNameLen))
		return	-1 ;

	rszUserName [UNLEN]	= TEXT ('\0') ;
	/*	�V�X�e�����[�U�͍��Ȃ��c�Ƃ���B*/
	if (! lstrcmpi (rszUserName, TEXT ("system"))) {
		return	-1 ;
	}
	ptr	= rszUserName ;
	while (*ptr != TEXT('\0')) {
		/*	�p�X�����Ƃ��Ďg�p�ł��Ȃ����͎̂̂Ă�B*/
		if (*ptr == TEXT('\\') || *ptr == TEXT('*') || *ptr == TEXT('?') ||
			*ptr == TEXT(':')  || *ptr == TEXT('.') || *ptr == TEXT('/')) {
			*ptr = TEXT('-') ;
		}
		ptr	++ ;
	}

#if defined (USE_LISPEVAL)
	if (TFAILED (TLispMgr_Create (&_pSkkiservLispMgr)) ||
		TFAILED (TLispMachine_Create (_pSkkiservLispMgr, NULL, &_pSkkiservLispMachine))) {
		return	-1 ;
	}
	/*	Lisp �̏������t�@�C����ǂݍ��ށB�������t�@�C���̏ꏊ�̓��W�X�g���ɋL�ڂ���Ă���B
	 *	���W�X�g���ɃL�[���Ȃ���΁Adefault ����B
	 */
	(void) skkiserv_bInitLispMachine (_pSkkiservLispMachine, _pSkkiservLispMgr) ;
#endif

	wVersion	= MAKEWORD (2, 0) ;
	if (WSAStartup (wVersion, &wsaData) != 0)
		return	-1 ;
	if (LOBYTE (wsaData.wVersion) != 2 || HIBYTE (wsaData.wVersion) < 0) {
		WSACleanup () ;
		return	-1 ;
	}

	// skkiserv �̃o�[�W�����܂ōl�����Ȃ��B�ǂ���1���[�U1��ނ����C���X�g�[�����Ȃ���
	wnsprintf (rszMutexName, MAX_PATH, TEXT ("mskkiserv-%s"), rszUserName) ;
	rszMutexName [MAX_PATH-1]	= TEXT ('\0') ;
	hMutex	= CreateMutex (NULL, FALSE, rszMutexName) ;
	if (hMutex == NULL) {
		return	-1 ;
	}
	dwResult	= WaitForSingleObject (hMutex, 0) ;
	if (dwResult != WAIT_OBJECT_0 && dwResult != WAIT_ABANDONED) {
		CloseHandle (hMutex) ;
		return	-1 ;
	}
	_hSkkiservMutex	= hMutex ;
	wnsprintf (_srSkkiservPipeName, MAX_PIPENAME, SKKISERVER_PIPE_BASENAME, rszUserName) ;
	_srSkkiservPipeName [MAX_PIPENAME-1]	= TEXT ('\0') ;

	_hEvQuitRequest	= CreateEvent (NULL, TRUE, FALSE, NULL) ;
	_hEvQuit		= CreateEvent (NULL, TRUE, FALSE, NULL) ;
	if (_hEvQuitRequest == NULL || _hEvQuit == NULL)
		return	-1 ;

	return	0 ;
	UNREFERENCED_PARAMETER (hWnd) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
skkiserv_onQueryEndSession (HWND hWnd, WPARAM wParam, LPARAM lParam)
{
#ifdef GORGEOUS
	if (! ShutdownBlockReasonCreate (hWnd, L"A transaction is in progress.")) {
	}
	return	TRUE ;
#else	// GORGEOUS
	DWORD		dwResult ;
	int			i ;

	/*	�I���v���C�x���g���t���O����B*/
	if (_hEvQuitRequest == NULL || _hEvQuit == NULL) {
		return	TRUE ;
	}

	SetEvent (_hEvQuitRequest) ;
	dwResult	= WaitForSingleObject (_hEvQuit, 0) ;
	if (dwResult == WAIT_TIMEOUT) {
		register HANDLE	hPipe ;

		/*	client �� pipe �ڑ��҂��ł������Ă���\��������
		 *	�̂ŁA�����̏����𔲂�������B
		 */
		for (i = 0 ; i < MAX_PIPE_INSTANCES ; i ++) {
			hPipe = CreateFile(
				_srSkkiservPipeName,
				GENERIC_READ | GENERIC_WRITE,
				0, NULL, OPEN_EXISTING, 0, NULL) ;
			if (hPipe == INVALID_HANDLE_VALUE)
				break ;
			CloseHandle (hPipe) ;
		}
		/*	�����ōēx 4 �b���҂�Ƃɓ���B���� 4 �b�̊Ԃ�
		 *	�Z�[�u����������� TRUE ���Ԃ����B*/
		dwResult	= WaitForSingleObject (_hEvQuit, 1 * 1000) ;
		if (dwResult == WAIT_TIMEOUT) {
			return	FALSE ;
		}
	}
	return	TRUE ;
	UNREFERENCED_PARAMETER (hWnd) ;
#endif	// GORGEOUS
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

#ifdef GORGEOUS
LRESULT
skkiserv_onEndSession (HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	EnterCriticalSection (&_csService) ;
	if (_pSkkiservUser != NULL) {
		(void) SkkImeUser_Save (_pSkkiservUser) ;
	}
	LeaveCriticalSection (&_csService) ;
	ShutdownBlockReasonDestroy (hWnd) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}
#endif	// GORGEOUS

LRESULT
skkiserv_onSettingChange (
	HWND		hWnd,
	WPARAM		wParam,
	LPARAM		lParam)
{
	LPCTSTR		strKey ;

	/*	Application Message �łȂ��Ȃ�΁AwParam �� non-NULL �ł���B
	 *	���E�������̂́A���O�ő����� WM_SETTINGCHANGE �Ȃ̂ŁAnon-NULL �͈���Ȃ��B
	 */
	if (wParam != (WPARAM) NULL)
		return	1 ;

	/// @warning ���g�p�����H������|�C���^���E�B���h�E���b�Z�[�W�œn���̂͂��@�x�ł�

	strKey	= (LPCTSTR) lParam ;
	if (strKey == NULL || _tcscmp (strKey, REGPATH_GENERIC) != 0)
		return	1 ;

	/*	�ݒ���X�V���Ȃ���΂Ȃ�Ȃ��B
	 */
	EnterCriticalSection (&_csService) ;
	if (_pSkkiservUser != NULL)
		SkkImeUser_Update (_pSkkiservUser) ;
	LeaveCriticalSection (&_csService) ;
	return	0 ;
	UNREFERENCED_PARAMETER (hWnd) ;
}

unsigned int __stdcall
skkiserv_pipeServerMain (
	void*		pvParam)
{
	TCHAR		rszUserName [UNLEN + 1] ;
	DWORD		dwUserName ;
	HANDLE		rhThreads [MAX_PIPE_INSTANCES] ;
	int			i ;
	unsigned	nThreadId ;
	DWORD		dw ;

	dwUserName	= UNLEN ;
	if (! GetUserName (rszUserName, &dwUserName))
		return	FALSE ;

	_pSkkiservUser	= SkkImeUser_Create (rszUserName, dwUserName) ;
	if (_pSkkiservUser == NULL)
		return	FALSE ;

	PSECURITY_ATTRIBUTES psa = CreateSecurityAttributes();

	memset (rhThreads, 0, sizeof (rhThreads)) ;
	for (i = 0 ; i < MAX_PIPE_INSTANCES ; i ++) {
		rhThreads [i]	= (HANDLE)_beginthreadex (NULL, 0, skkiserv_pipeMain, psa, 0, &nThreadId) ;
		if (rhThreads[i] == INVALID_HANDLE_VALUE) goto _exit_servermain;
	}
	dw		= WaitForMultipleObjects (MAX_PIPE_INSTANCES, rhThreads, TRUE, INFINITE) ;
_exit_servermain:
	for (i = 0 ; i < MAX_PIPE_INSTANCES ; i ++) {
		CloseHandle (rhThreads [i]) ;
	}

	FreeSecurityAttributes(psa);

#ifdef GORGEOUS
#else	// GORGEOUS
	/*	�����Ŏ����̃Z�[�u�̏���������B
	 */
	if (_pSkkiservUser != NULL) {
		(void) SkkImeUser_Save (_pSkkiservUser) ;
	}
#endif	// GORGEOUS
	SetEvent (_hEvQuit) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pvParam) ;
}

unsigned int __stdcall
skkiserv_pipeMain (
	void*			pvParam)
{
	register HANDLE					hPipe ;
	register BOOL					fConnected ;

	while (WaitForSingleObject (_hEvQuitRequest, 0) == WAIT_TIMEOUT) {
		hPipe 	= CreateNamedPipe(
			_srSkkiservPipeName,		// pipe name
			PIPE_ACCESS_DUPLEX,			// read/write access
			PIPE_TYPE_MESSAGE |			// message type pipe
			PIPE_WAIT,					// blocking mode
			PIPE_UNLIMITED_INSTANCES,	// max. instances
			BUFSIZE,					// output buffer size
			BUFSIZE,					// input buffer size
			PIPE_TIMEOUT,				// client time-out
			(PSECURITY_ATTRIBUTES)pvParam);	// security attribute

		if (hPipe == INVALID_HANDLE_VALUE) {
#if defined (DEBUG) || defined (_DEBUG)
			DWORD	dwError	= GetLastError () ;
			DEBUGPRINTFEX (103, (TEXT ("CreatePipe failed. (error:0x%lx)\n"), dwError)) ;
#endif
			break ;
		}

		// Wait for the client to connect; if it succeeds,
		// the function returns a nonzero value. If the function returns
		// zero, GetLastError returns ERROR_PIPE_CONNECTED.
		tctrl.enter();
		fConnected = ConnectNamedPipe (hPipe, NULL) ?
			TRUE : (GetLastError() == ERROR_PIPE_CONNECTED) ;
		tctrl.leave();

		if (fConnected){
			HANDLE			hThread ;
			unsigned		nThreadId ;

			hThread	= (HANDLE)_beginthreadex (
				NULL, 0, skkiserv_serviceMain,	(LPVOID) hPipe, 0, &nThreadId) ;
			if (hThread != 0) {
				CloseHandle (hThread) ;
			} else {
				CloseHandle (hPipe) ;
			}
		} else {
			CloseHandle (hPipe) ;
		}
	}

	return	TRUE ;
	UNREFERENCED_PARAMETER (pvParam) ;
}

unsigned int __stdcall
skkiserv_serviceMain (
	register void*		lpvParam)
{
	register HANDLE		hPipe	= (HANDLE) lpvParam ;

	EnterCriticalSection (&_csService) ;
	skkiserv_service (hPipe) ;
	FlushFileBuffers (hPipe) ;
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	LeaveCriticalSection (&_csService) ;
	_endthreadex (0) ;
	return	0 ;
}

void
skkiserv_service (
	register HANDLE		hPipe)
{
	static	BOOL	(*rpServiceFunction [])(HANDLE, int, int, BYTE*, int)	= {
		skkiserv_serviceSearch,
		skkiserv_serviceRecord,
		skkiserv_servicePurge,
		skkiserv_serviceTryCompletion,
		skkiserv_serviceEval,
		skkiserv_serviceSetCutbuffer,
		skkiserv_serviceGetCutbuffer,
		skkiserv_serviceUpdate,
		skkiserv_serviceSearchEx,
		skkiserv_serviceSetJNumList,
		skkiserv_serviceSaveLocalJisyo,
		skkiserv_serviceRecordKakuteiHistory,
		skkiserv_serviceGetKakuteiHistroy,
	} ;
	BYTE	rbyBuffer [2048] ;
	DWORD	dwRead ;
	register int			nMajor, nMinor, nLength, nPos ;

	if (!ReadFile (hPipe, rbyBuffer, sizeof (rbyBuffer), &dwRead, NULL)) {
#if defined (DEBUG) || defined (_DEBUG)
		DWORD	dwError	= GetLastError () ;
		DEBUGPRINTFEX (103, (TEXT ("skkiserv_service(): fail in reading client packet(%ld)\n"), dwError)) ;
#endif
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_READ) ;
		return ;
	}

	if (dwRead < SKKISERV_PROTO_HEADER_SIZE) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET) ;
		DEBUGPRINTFEX (103, (TEXT ("Packet is broken: Read(%ld) < %d\n"),
							 dwRead, SKKISERV_PROTO_HEADER_SIZE)) ;
		return ;
	}

	/*	�p�P�b�g�ɂ́uMajor�ԍ��AMinor�ԍ��A�p�P�b�g�T�C�Y�v��
	 *	�����Ă���B�p�P�b�g�̑傫���� 2k �ȏ�ɂ͂Ȃ�Ȃ��B��
	 *	��𒴂�����͎̂̂Ă�B
	 *
	 *	���ƁA4�o�C�g���E�ɒ��ӁA�ƁB
	 */
	nMajor	= rbyBuffer [0] ;
	nMinor	= rbyBuffer [1] ;
	nLength	= bytep2word (&rbyBuffer [2]) ;
	if ((DWORD)nLength != dwRead) {
		DEBUGPRINTFEX (103, (TEXT ("Packet is broken: Length(%d) != Read(%ld)\n"),
							 nLength, dwRead)) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET) ;
		DEBUGPRINTFEX (103, (TEXT ("Packet is broken: Length(%d) != Read(%ld)\n"),
							 nLength, dwRead)) ;
		return ;
	}
	DEBUGPRINTFEX (103, (TEXT ("Packet(Major:%d, Minor:%d, Length:%d)\n"), nMajor, nMinor, nLength)) ;

	if (nMajor < 0 || nMajor > sizeof (rpServiceFunction) / sizeof (rpServiceFunction [0]))
		return ;

	/*	�o�C�g���E�ɒ��ӂ��� LPCTSTR �ɂ��킹��B*/
	nPos	= SKKISERV_PROTO_HEADER_SIZE ;
	(rpServiceFunction [nMajor])(hPipe, nMajor, nMinor, &rbyBuffer [nPos], nLength - nPos) ;
	return ;
}

/*
 */
BOOL
skkiserv_serviceSearch (
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData)
{
	LPCWSTR			pwKey, pwOkuriChar ;
	int				nOkuriType ;
	Char			rkey [1024] ;
	Char			rOkuriChar [256] ;
	TVarbuffer		vbuf ;
	TVarbuffer		vbufPacket ;
	int				nChar, nwKey, nCkey, nwOkuriChar, nCOkuriChar ;
	BOOL			fResult	= FALSE ;
	const Char*		pChar ;
#if defined (DEBUG) || defined (_DEBUG)
	TCHAR	rszBuffer [1024] ;
#endif

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTFEX (103, (TEXT ("skkiserv_serviceSearch (%p, %d, %d, %p, %d)\n"),
						 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nOkuriType	= nMinor ;
	nwKey		= bytep2word (pData) ;
	pwKey		= (LPCWSTR) &pData [2] ;
	pData		= pData + MAKEPAD(2 + nwKey  * sizeof (wchar_t)) ;
	nwOkuriChar	= bytep2word (pData) ;
	pwOkuriChar	= (LPCWSTR) &pData [2] ;

	if ((int)((nwKey + nwOkuriChar) * sizeof (wchar_t)) > nData) {
		DEBUGPRINTF ((TEXT ("skkiserv_serviceSearch (): �p�P�b�g�����Ă���.\n"))) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}
#if defined (DEBUG) || defined (_DEBUG)
	{
		TCHAR	rszBuffer [1024] ;

		lstrcpyn (rszBuffer, pwKey, 1023) ;
		rszBuffer [1023]	= TEXT ('\0') ;
		DEBUGPRINTF ((TEXT ("key = \"%s\"\n"), rszBuffer)) ;
	}
#endif

	/*	�����̌����B*/
	nCkey	= wstr2internal (rkey, ARRAYSIZE (rkey), pwKey, nwKey) ;
	if (nCkey < 0) {
		DEBUGPRINTF ((TEXT ("skkiserv_serviceSearch (): �s���Ȍ����L�[.\n"))) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
		return	FALSE ;
	}
	if (nOkuriType != SEARCH_OKURI_NASHI && nwOkuriChar > 0) {
		nCOkuriChar	= wstr2internal (rOkuriChar, ARRAYSIZE (rOkuriChar), pwOkuriChar, nwOkuriChar) ;
		if (nCOkuriChar < 0) {
			DEBUGPRINTF ((TEXT ("skkiserv_serviceSearch (): �s���ȑ��艼��.\n"))) ;
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			return	FALSE ;
		}
	} else {
		nCOkuriChar	= 0 ;
	}

	DEBUGPRINTF ((TEXT ("skkiserv_serviceSearch (): �����J�n(%ld).\n"), GetTickCount ())) ;
	SkkImeUser_Search (_pSkkiservUser, rkey, nCkey, rOkuriChar, nCOkuriChar, nOkuriType, &vbuf) ;
	DEBUGPRINTF ((TEXT ("skkiserv_serviceSearch (): �����I��(%ld).\n"), GetTickCount ())) ;

	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= (const Char*) TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SEARCH_REPLY, 0)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
#if defined (DEBUG) || defined (_DEBUG)
	{
		const BYTE*	pwResult	= (BYTE *)TVarbuffer_GetBuffer (&vbufPacket) + SKKISERV_PROTO_HEADER_SIZE ;
		int			nbResult	= TVarbuffer_GetUsage (&vbufPacket) - SKKISERV_PROTO_HEADER_SIZE ;
		register LPCTSTR	pwstr ;
		register int		nwstr ;
		register int		n ;

		pwstr	= (LPCTSTR) pwResult ;
		nwstr	= nbResult / sizeof (TCHAR) ;
		while (nwstr > 0) {
			n	= (nwstr > 1023)? 1023 : nwstr ;
#if defined (_MSC_VER) && (_MSC_VER >= 1400) && !defined (WIN64)
			memcpy (rszBuffer, pwstr, n * sizeof (TCHAR)) ;
#else
			_tcsncpy (rszBuffer, pwstr, n) ;
#endif
			rszBuffer [n]	= TEXT ('\0') ;
			DEBUGPRINTF ((TEXT ("%s"), rszBuffer)) ;
			nwstr	-= n ;
			pwstr	+= n ;
		}
		DEBUGPRINTF ((TEXT ("\n"))) ;
	}
#endif
	DEBUGPRINTF ((TEXT ("skkiserv_serviceSearch (): ���v���C�p�P�b�g���o.\n"))) ;
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
skkiserv_serviceRecord (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	TVarbuffer	vbufPacket ;
	Char		rkey  [1024] ;
	Char		rcand [1024] ;
	Char		rOkurigana [64] ;
	LPCWSTR		pwKey, pwCand, pwOkurigana ;
	int			nwKey, nCkey, nwCand, nCCand, nwOkurigana, nCOkurigana ;
	BOOL		fResult	= FALSE ;
	BOOL		bOkuri ;

	DEBUGPRINTF ((TEXT ("skkiserv_serviceRecordEx (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	bOkuri		= (nMinor != 0) ;
	nwKey		= bytep2word (pData) ;
	pwKey		= (LPCWSTR) &pData [2] ;
	pData		= pData + MAKEPAD(2 + nwKey  * sizeof (wchar_t)) ;
	nwCand		= bytep2word (pData) ;
	pwCand		= (LPCWSTR) &pData [2] ;
	pData		= pData + MAKEPAD(2 + nwCand * sizeof (wchar_t)) ;
	nwOkurigana	= bytep2word (pData) ;
	pwOkurigana	= (LPCWSTR) &pData [2] ;

	if (nData < (int)((nwKey + nwCand + nwOkurigana) * sizeof (wchar_t) + 2 + 2 + 2)) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}

	nCkey	= wstr2internal (rkey,  ARRAYSIZE (rkey),  pwKey,  nwKey) ;
	nCCand	= wstr2internal (rcand, ARRAYSIZE (rcand), pwCand, nwCand) ;
	if (nCkey <= 0 || nCCand <= 0) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
		return	FALSE ;
	}
	/* ����ϊ��łȂ���Γ��R okurigana �͂Ȃ��B*/
	if (bOkuri && nwOkurigana > 0) {
		nCOkurigana	= wstr2internal (rOkurigana, ARRAYSIZE (rOkurigana), pwOkurigana, nwOkurigana) ;
		if (nCOkurigana <= 0) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			return	FALSE ;
		}
	} else {
		nCOkurigana	= 0 ;
	}
	fResult	= SkkImeUser_Record (_pSkkiservUser, rkey, nCkey, rcand, nCCand, rOkurigana, nCOkurigana, bOkuri) ;

	DEBUGPRINTF ((TEXT ("skkiserv: create return packet (result:%d)\n"), fResult)) ;

	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_RECORD_REPLY, !fResult)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
	DEBUGPRINTF ((TEXT ("skkiserv: sent reply packet (result:%d)\n"), fResult)) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	DEBUGPRINTF ((TEXT ("skkiserv: exit skkiserv_serviceRecord ()\n"))) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
skkiserv_servicePurge (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	TVarbuffer	vbufPacket ;
	Char		rkey  [1024] ;
	Char		rcand [1024] ;
	Char		rOkurigana [64] ;
	LPCWSTR		pwKey, pwCand, pwOkurigana ;
	int			nwKey, nCkey, nwCand, nCCand, nwOkurigana, nCOkurigana ;
	BOOL		fResult	= FALSE ;
	BOOL		bOkuri ;

	DEBUGPRINTF ((TEXT ("skkiserv_servicePurgeEx (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	bOkuri		= (nMinor != 0) ;
	nwKey		= bytep2word (pData) ;
	pwKey		= (LPCWSTR) &pData [2] ;
	pData		= pData + MAKEPAD(2 + nwKey * sizeof (wchar_t)) ;
	nwCand		= bytep2word (pData) ;
	pwCand		= (LPCWSTR) &pData [2] ;
	pData		= pData + MAKEPAD(2 + nwCand * sizeof (wchar_t)) ;
	nwOkurigana	= bytep2word (pData) ;
	pwOkurigana	= (LPCWSTR) &pData [2] ;

	if (nData < (int)((nwKey + nwCand + nwOkurigana) * sizeof (wchar_t) + 2 + 2 + 2)) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}

	nCkey	= wstr2internal (rkey,  ARRAYSIZE (rkey),  pwKey,  nwKey) ;
	nCCand	= wstr2internal (rcand, ARRAYSIZE (rcand), pwCand, nwCand) ;
	if (nCkey <= 0 || nCCand <= 0) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
		return	FALSE ;
	}
	/* ����ϊ��łȂ���Γ��R okurigana �͂Ȃ��B*/
	if (bOkuri && nwOkurigana > 0) {
		nCOkurigana	= wstr2internal (rOkurigana, ARRAYSIZE (rOkurigana), pwOkurigana, nwOkurigana) ;
		if (nCOkurigana <= 0) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			return	FALSE ;
		}
	} else {
		nCOkurigana	= 0 ;
	}
	fResult	= SkkImeUser_Purge (_pSkkiservUser, rkey, nCkey, rcand, nCCand, rOkurigana, nCOkurigana, bOkuri) ;

	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_PURGE_REPLY, !fResult)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
skkiserv_serviceTryCompletion (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	register LPCWSTR		pwKey ;
	Char					rkey [1024] ;
	TVarbuffer				vbuf ;
	TVarbuffer				vbufPacket ;
	register int			nChar, nwKey, nCkey ;
	register BOOL			fResult	= FALSE ;
	register const Char*	pChar ;
#if defined (DEBUG) || defined (_DEBUG)
	TCHAR	rszBuffer [1024] ;
#endif

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTF ((TEXT ("skkiserv_serviceTryCompletion (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwKey	= bytep2word (pData) ;
	if ((int)(nwKey * sizeof (wchar_t)) > nData) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}
	pwKey	= (LPCWSTR) &pData [2] ;

#if defined (DEBUG) || defined (_DEBUG)
	{
#if defined (_MSC_VER) && (_MSC_VER >= 1400) && !defined (WIN64)
		_tcsncpy_s (rszBuffer, ARRAYSIZE (rszBuffer), pwKey, nwKey) ;
#else
		_tcsncpy (rszBuffer, pwKey, nwKey) ;
#endif
		rszBuffer [nwKey]	= TEXT ('\0') ;
		DEBUGPRINTF ((TEXT("key = \"%s\"\n"), rszBuffer)) ;
	}
#endif

	/*	�����̌����B*/
	nCkey	= wstr2internal (rkey, ARRAYSIZE (rkey), pwKey, nwKey) ;
	if (nCkey < 0) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
		return	FALSE ;
	}
	if (TFAILED (SkkImeUser_TryCompletion (_pSkkiservUser, rkey, nCkey, &vbuf))) {
		DEBUGPRINTF ((TEXT ("SkkImeUser_Completion return FALSE\n"))) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}

	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= (const Char*) TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_COMPLETION_REPLY, 0)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
#if defined (DEBUG) || defined (_DEBUG)
	{
		const BYTE*	pwResult	= (BYTE *)TVarbuffer_GetBuffer (&vbufPacket) + SKKISERV_PROTO_HEADER_SIZE ;
		int			nbResult	= TVarbuffer_GetUsage (&vbufPacket) - SKKISERV_PROTO_HEADER_SIZE ;
		register LPCTSTR	pwstr ;
		register int		nwstr ;
		register int		n ;

		pwstr	= (LPCTSTR) pwResult ;
		nwstr	= nbResult / sizeof (TCHAR) ;
		while (nwstr > 0) {
			n	= (nwstr > 1023)? 1023 : nwstr ;
#if defined (_MSC_VER) && (_MSC_VER >= 1400) && !defined (WIN64)
			memcpy (rszBuffer, pwstr, n * sizeof (TCHAR)) ;
#else
			_tcsncpy (rszBuffer, pwstr, n) ;
#endif
			rszBuffer [n]	= TEXT ('\0') ;
			DEBUGPRINTF ((TEXT ("%s"), rszBuffer)) ;
			nwstr	-= n ;
			pwstr	+= n ;
		}
		DEBUGPRINTF ((TEXT ("\n"))) ;
	}
#endif
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
}

BOOL
skkiserv_serviceEval (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
#if defined (USE_LISPEVAL)
	register LPCWSTR		pwWord ;
	Char					rCWord [512] ;
	TVarbuffer				vbuf ;
	TVarbuffer				vbufPacket ;
	register int			nChar, nwWord, nCWord ;
	register const Char*	pChar ;
	register BOOL			fResult	= FALSE, fRet ;
	register TLispEntity*	pEntTarget ;

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTF ((TEXT ("skkiserv_serviceEval (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	nwWord	= bytep2word (pData) ;
	if ((int)(nwWord * sizeof (wchar_t)) > nData) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		goto	exit_func ;
	}
	pwWord	= (LPCWSTR) &pData [2] ;

	/*	�����̌����B*/
	nCWord	= wstr2internal (rCWord, ARRAYSIZE (rCWord), pwWord, nwWord) ;
	if (nCWord >= ARRAYSIZE (rCWord)) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	if (nCWord < 0) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
		goto	exit_func ;
	}
	pEntTarget	= lispMgr_ParseString (_pSkkiservLispMgr, rCWord, nCWord, NULL) ;
	if (pEntTarget != NULL) {
		fRet	= TLispMachine_Test (_pSkkiservLispMachine, pEntTarget, &vbuf) ;
		lispEntity_Release (_pSkkiservLispMgr, pEntTarget) ;
	} else {
		fRet	= FALSE ;
	}
	if (TFAILED (fRet)) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_EVAL_FAIL) ;
		goto	exit_func ;
	}
	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= (const Char*) TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_EVAL_REPLY, 0)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func_1 ;
	}
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
	lispMgr_CollectGarbage (_pSkkiservLispMgr) ;
	lispMgr_CollectGarbage (_pSkkiservLispMgr) ;
 exit_func_1:
	TVarbuffer_Uninitialize (&vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
#else
	skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_NOT_IMPLEMENTED) ;
	return	FALSE ;
	UNREFERENCED_PARAMETER (hPipe) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
#endif
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
}

/*
 *	(nMajor(1), nMinor(1), Length(2), String)
 *	String = (length(2), tchar(n))
 */
BOOL
skkiserv_serviceSetCutbuffer (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	TVarbuffer			vbufPacket ;
	TVarbuffer			vbufCutbuffer ;
	register LPWSTR		pString ;
	register int		nLength, nBaseLength ;
	register BOOL		fAppend ;
	register BOOL		fResult	= FALSE ;
	register HANDLE		hglbCopy ;
	register LPWSTR		lpstrCopy ;

	DEBUGPRINTF ((TEXT ("skkiserv_serviceSetCutbuffer (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	fAppend	= (nMinor != 0) ;

	if (nData < 2) {
		DEBUGPRINTF ((TEXT ("SetCutbuffer: empty string (%d)\n"),
					 nData)) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET) ;
		return	FALSE ;
	}

	pString	= (LPWSTR) &pData [2] ;
	nLength	= bytep2word (pData) ;
	if (nData < (int)(nLength * sizeof (wchar_t) + 2)) {
		DEBUGPRINTF ((TEXT ("SetCutbuffer: packet length(%d) < string length(%d/%d)\n"),
					 nData, (int)(nLength * sizeof (wchar_t) + 2), nLength)) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_BROKEN_PACKET) ;
		return	FALSE ;
	}

	TVarbuffer_Initialize (&vbufCutbuffer, sizeof (wchar_t)) ;
	nBaseLength	= 0 ;
	if (fAppend) {
		if (TSUCCEEDED (skkiserv_getClipboardText (&vbufCutbuffer)))
			nBaseLength	= TVarbuffer_GetUsage (&vbufCutbuffer) ;
	}

	if (!_hwndSkkiserv || !OpenClipboard (_hwndSkkiserv)) {
#if defined (DEBUG) || defined (_DEBUG)
		register DWORD	dwError	= GetLastError () ;
		DEBUGPRINTFEX (103, (TEXT ("SetCutbuffer: OpenClipboard(hwnd:%lx) failed(%lx)\n"), _hwndSkkiserv, dwError)) ;
#endif
		TVarbuffer_Uninitialize (&vbufCutbuffer) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		return	FALSE ;
	}

	EmptyClipboard () ;
 	hglbCopy = GlobalAlloc (GMEM_MOVEABLE, (nLength + nBaseLength + 1) * sizeof (wchar_t)) ;
	if (hglbCopy == NULL){
		CloseClipboard () ;
		TVarbuffer_Uninitialize (&vbufCutbuffer) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		return	FALSE ;
	}
	lpstrCopy			= (LPWSTR)GlobalLock (hglbCopy) ;
	if (nBaseLength > 0)
		memcpy (lpstrCopy, TVarbuffer_GetBuffer (&vbufCutbuffer), nBaseLength * sizeof (wchar_t)) ;
	memcpy (lpstrCopy + nBaseLength, pString, nLength * sizeof (wchar_t)) ;
	lpstrCopy [nBaseLength + nLength]	= L'\0' ;
	GlobalUnlock (hglbCopy) ;
	SetClipboardData (CF_UNICODETEXT, hglbCopy) ;
	CloseClipboard () ;
	TVarbuffer_Uninitialize (&vbufCutbuffer) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SETCUTBUFFER_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;

  exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
skkiserv_serviceGetCutbuffer (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	TVarbuffer			vbufPacket ;
	register int		nLength ;
	register BOOL		fResult ;
	register BOOL		fRetval	= FALSE ;

	DEBUGPRINTF ((TEXT ("skkiserv_serviceGetCutbuffer (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	if (!_hwndSkkiserv) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		return	FALSE ;
	}

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_GETCUTBUFFER_REPLY, 0))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}

	nLength	= 0 ;
	fResult	= FALSE ;
	if (IsClipboardFormatAvailable (CF_UNICODETEXT) &&
		OpenClipboard (_hwndSkkiserv)){
		register HANDLE	hglb ;

		hglb	= GetClipboardData (CF_UNICODETEXT) ;
		if (hglb != NULL){
			register LPCWSTR	lpstr ;

			lpstr	= (LPCWSTR)GlobalLock (hglb) ;
			if (lpstr != NULL){
				fResult	= TPacket_AddString (&vbufPacket, lpstr, lstrlen (lpstr)) ;
				GlobalUnlock (hglb) ;
			}
		}
	}
	CloseClipboard () ;

	if (! fResult) {
		/*	empty string ��������B*/
		if (! TPacket_AddString (&vbufPacket, NULL, 0)) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
			goto	exit_func ;
		}
	}
	if (TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fRetval	= skkiserv_replyPacket (hPipe, &vbufPacket) ;

  exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fRetval ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
}

BOOL
skkiserv_serviceUpdate (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	TVarbuffer			vbufPacket ;
	register BOOL		fRetval	= FALSE ;

	/*	Critical Section �̒��ɂ���̂ŁA�����ɕ����� thread ���������Ƃ�
	 *	�Ȃ��ƍl���ėǂ��B������A�v�����܂܂� update ����B
	 */
	DEBUGPRINTF ((TEXT ("skkiserv_serviceUpdate (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	if (_pSkkiservUser == NULL) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		return	FALSE ;
	}
	SkkImeUser_Update (_pSkkiservUser) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_UPDATE_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fRetval	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fRetval ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
}

/*
 */
BOOL
skkiserv_serviceSearchEx (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	BYTE*					pDataEnd ;
	LPCWSTR					pwKey, pwOkuriChar ;
	Char					rkey [1024] ;
	Char					rOkuriChar [256] ;
	TVarbuffer				vbuf ;
	TVarbuffer				vbufPacket ;
	register int			nChar, nwKey, nCkey, nwOkuriChar, nCOkuriChar, nOkuriType ;
	register BOOL			fResult	= FALSE ;
	register const Char*	pChar ;
	int						nNext	= -1 ;
	int						nSearchCount ;

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTFEX (103, (TEXT ("skkiserv_serviceSearchEx (%p, %d, %d, %p, %d)\n"),
						 hPipe, nMajor, nMinor, pData, nData)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	TVarbuffer_Initialize (&vbuf, sizeof (Char)) ;

	pDataEnd	= pData + nData ;
	if ((pData + 2 + 4 + 2) > pDataEnd) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}
	nOkuriType		= nMinor ;
	/* �܂� search count �� 4 byte */
	nSearchCount	= bytep2dword (pData) ;
	/* ���Ɍ����L�[�B*/
	pData			= pData + 4 ;
	nwKey			= bytep2word  (pData) ;
	pwKey			= (LPCWSTR) &pData [2] ;
	pData			= pData + MAKEPAD(2 + nwKey  * sizeof (wchar_t)) ;
	if (pData > pDataEnd) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}
	/* �X�ɑ��艼���B*/
	nwOkuriChar	= bytep2word (pData) ;
	pwOkuriChar	= (LPCWSTR) &pData [2] ;
	pData		= pData + MAKEPAD(2 + nwOkuriChar * sizeof (wchar_t)) ;
	if (pData > pDataEnd) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}

	/*	�����̌����B*/
	nCkey	= wstr2internal (rkey, ARRAYSIZE (rkey), pwKey, nwKey) ;
	if (nCkey < 0) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
		return	FALSE ;
	}
	if (nOkuriType != SEARCH_OKURI_NASHI) {
		nCOkuriChar	= wstr2internal (rOkuriChar, ARRAYSIZE (rOkuriChar), pwOkuriChar, nwOkuriChar) ;
		if (nCOkuriChar < 0) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			return	FALSE ;
		}
	} else {
		nCOkuriChar	= 0 ;
	}
	SkkImeUser_SearchEx (_pSkkiservUser, rkey, nCkey, rOkuriChar, nCOkuriChar, nOkuriType, nSearchCount, &vbuf, &nNext) ;
	DEBUGPRINTFEX (103, (TEXT ("skkiserv_serviceSearchEx: next = %d\n"), nNext)) ;

	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= (const Char*) TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SEARCH_REPLY, nNext)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
}

BOOL
skkiserv_serviceSetJNumList (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
#if defined (USE_LISPEVAL)
	static WCHAR			srwszLeft []	= L"(setq j-num-list (setq skk-num-list '(" ;
	static WCHAR			srwszRight []	= L")))" ;
	static WCHAR			srwszSetNil []	= L"(setq j-num-list nil)" ;
	register LPCWSTR		pwWord ;
	Char					rcWord [1024] ;
	TVarbuffer				vbuf ;
	TVarbuffer				vbufPacket ;
	register int			ndwDest, nwWord, n ;
	register BOOL			fResult	= FALSE, fError ;
	register Char*			pdwDest ;
	register TLispEntity*	pEntTarget ;

	DEBUGPRINTF ((TEXT ("skkiserv_serviceSetJNumList (%p, %d, %d, %p, %d)\n"),
				  hPipe, nMajor, nMinor, pData, nData)) ;

	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (Char))) ||
		TFAILED	(TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		return	FALSE ;
	}
	if (pData != NULL && nData > 0) {
		nwWord	= bytep2word (pData) ;
		if ((int)(nwWord * sizeof (wchar_t)) > nData) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
			goto	exit_func ;
		}

		pwWord	= (LPCWSTR) &pData [2] ;
		pdwDest	= rcWord ;
		ndwDest	= ARRAYSIZE (rcWord) ;

		n	= wstr2internal (pdwDest, ndwDest, srwszLeft, ARRAYSIZE (srwszLeft)) ;
		if (n <= 0) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			goto	exit_func ;
		}
		pdwDest	+= n ;
		ndwDest	-= n ;
		fError	= FALSE ;
		while (nwWord > 0) {
			if (L'0' <= *pwWord && *pwWord <= L'9') {
				*pdwDest ++	= '\"' ;
				ndwDest	-- ;
				while (nwWord > 0 && ndwDest > 0 && L'0' <= *pwWord && *pwWord <= L'9') {
					*pdwDest ++	= *pwWord ++ ;
					ndwDest	-- ;
					nwWord	-- ;
				}
				if (ndwDest <= 0) {
					fError	= TRUE ;
					break ;
				}
				*pdwDest ++	= '\"' ;
				ndwDest	-- ;
			} else if (*pwWord == L'/' || *pwWord == L'\0') {
				*pdwDest ++	= ' ' ;
				ndwDest	-- ;
				pwWord	++ ;
				nwWord	-- ;
			} else {
				fError	= TRUE ;
				break ;	/* invalid character */
			}
		}
		if (fError || ndwDest < ARRAYSIZE (srwszRight)) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
			goto	exit_func ;
		}
		n	= wstr2internal (pdwDest, ndwDest, srwszRight, ARRAYSIZE (srwszRight)) ;
		if (n <= 0) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			goto	exit_func ;
		}
		pdwDest	+= n ;
		ndwDest	-= n ;
	} else {
		pdwDest	= rcWord ;
		ndwDest	= ARRAYSIZE (rcWord) ;
		n	= wstr2internal (pdwDest, ndwDest, srwszSetNil, ARRAYSIZE (srwszSetNil)) ;
		if (n <= 0) {
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			goto	exit_func ;
		}
	}
#pragma warning (push)
#pragma warning (disable : 4244)
	pEntTarget	= lispMgr_ParseString (_pSkkiservLispMgr, rcWord, pdwDest - rcWord, NULL) ;
#pragma warning (pop)
	if (pEntTarget != NULL) {
		fError	= ! TLispMachine_Test (_pSkkiservLispMachine, pEntTarget, &vbuf) ;
		lispEntity_Release (_pSkkiservLispMgr, pEntTarget) ;
	} else {
		fError	= TRUE ;
	}
	if (fError) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_EVAL_FAIL) ;
		goto	exit_func ;
	}

	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SETJNUMLIST_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
	lispMgr_CollectGarbage (_pSkkiservLispMgr) ;
	lispMgr_CollectGarbage (_pSkkiservLispMgr) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
#else
	skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_NOT_IMPLEMENTED) ;
	return	FALSE ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
#endif
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
}

BOOL
skkiserv_serviceSaveLocalJisyo (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register BYTE*			pData,
	register int			nData)
{
	TVarbuffer			vbufPacket ;
	register BOOL		fRetval	= FALSE ;

	/*	Critical Section �̒��ɂ���̂ŁA�����ɕ����� thread ���������Ƃ�
	 *	�Ȃ��ƍl���ėǂ��B������A�v�����܂܂� update ����B
	 */
	DEBUGPRINTF ((TEXT ("skkiserv_serviceSaveLocalJisyo (%p, %d, %d, %p, %d)\n"),
				 hPipe, nMajor, nMinor, pData, nData)) ;

	if (_pSkkiservUser == NULL) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		return	FALSE ;
	}
	DEBUGPRINTFEX (103, (TEXT ("skkiserv: start to save localjisyo\n"))) ;
	fRetval	= SkkImeUser_Save (_pSkkiservUser) ;
	DEBUGPRINTFEX (103, (TEXT ("skkiserv: finished saving localjisyo ... %do\n"), fRetval)) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_SAVELOCALJISYO_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	fRetval	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fRetval ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
}

/*
 */
BOOL
skkiserv_serviceRecordKakuteiHistory (
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData)
{
	LPCWSTR			pwMidasi, pwWord ;
	Char			rMidasi [1024] ;
	Char			rWord   [1024] ;
	TVarbuffer		vbufPacket ;
	int				nwMidasiLen, nCMidasiLen, nwWordLen, nCWordLen ;
	BOOL			fResult	= FALSE ;

	assert (pData != NULL) ;
	assert (nData > 0) ;

	DEBUGPRINTFEX (103, (TEXT ("skkiserv_serviceRecordKakuteiHistory (%p, %d, %d, %p, %d)\n"),
						 hPipe, nMajor, nMinor, pData, nData)) ;

	nwMidasiLen	= bytep2word (pData) ;
	pwMidasi	= (LPCWSTR) &pData [2] ;
	pData		= pData + MAKEPAD(2 + nwMidasiLen  * sizeof (wchar_t)) ;
	nwWordLen	= bytep2word (pData) ;
	pwWord		= (LPCWSTR) &pData [2] ;

	if ((int)((nwMidasiLen + nwWordLen) * sizeof (wchar_t)) > nData) {
		DEBUGPRINTF ((TEXT ("skkiserv_serviceRecordKakuteiHistory (): �p�P�b�g�����Ă���.\n"))) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_UNEXPECTED_END_OF_PACKET) ;
		return	FALSE ;
	}

	/*	�����̌����B*/
	nCMidasiLen	= wstr2internal (rMidasi, ARRAYSIZE (rMidasi), pwMidasi, nwMidasiLen) ;
	if (nCMidasiLen < 0) {
		DEBUGPRINTF ((TEXT ("skkiserv_serviceRecordKakuteiHistory (): �s���Ȍ����L�[.\n"))) ;
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
		return	FALSE ;
	}
	if (nwWordLen > 0) {
		nCWordLen	= wstr2internal (rWord, ARRAYSIZE (rWord), pwWord, nwWordLen) ;
		if (nCWordLen < 0) {
			DEBUGPRINTF ((TEXT ("skkiserv_serviceRecordKakuteiHistory (): �s���ȑ��艼��.\n"))) ;
			skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INVALID_CHAR) ;
			return	FALSE ;
		}
	} else {
		nCWordLen	= 0 ;
	}

	DEBUGPRINTF ((TEXT ("skkiserv_serviceRecordKakuteiHistory (): �o�^�J�n(%ld).\n"), GetTickCount ())) ;
	SkkImeUser_RecordKakuteiHistory (_pSkkiservUser, rMidasi, nCMidasiLen, rWord, nCWordLen) ;
	DEBUGPRINTF ((TEXT ("skkiserv_serviceRecordKakuteiHistory (): �o�^�I��(%ld).\n"), GetTickCount ())) ;

	TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_RECORDKAKUTEIHISTORY_REPLY, 0)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	DEBUGPRINTF ((TEXT ("skkiserv_serviceRecordKakuteiHistory (): ���v���C�p�P�b�g���o.\n"))) ;
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
}

BOOL
skkiserv_serviceGetKakuteiHistroy (
	HANDLE			hPipe,
	int				nMajor,
	int				nMinor,
	BYTE*			pData,
	int				nData)
{
	TVarbuffer		vbuf ;
	TVarbuffer		vbufPacket ;
	BOOL			fResult	= FALSE ;
	const Char*		pChar ;
	int				nChar ;

	DEBUGPRINTFEX (103, (TEXT ("skkiserv_serviceGetKakuteiHistory (%p, %d, %d, %p, %d)\n"),
						 hPipe, nMajor, nMinor, pData, nData)) ;

	DEBUGPRINTF ((TEXT ("skkiserv_serviceGetKakuteiHistory (): �J�n(%ld).\n"), GetTickCount ())) ;
	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (Char))) ||
		TFAILED (TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE)))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		return	FALSE ;
	}
	if (TFAILED (SkkImeUser_GetKakuteiHistory (_pSkkiservUser, &vbuf))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	DEBUGPRINTF ((TEXT ("skkiserv_serviceGetKakuteiHistory (): �I��(%ld).\n"), GetTickCount ())) ;

	pChar	= (const Char*) TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, SKKISERV_PROTO_GETKAKUTEIHISTORY_REPLY, 0)) ||
		TFAILED (TPacket_AddKanji  (&vbufPacket, pChar, nChar)) ||
		TFAILED (TPacket_SetLength (&vbufPacket))) {
		skkiserv_replyErrorPacket (hPipe, SKKISERV_PROTO_ERROR, 0, SKKISERV_ERROR_INTERNAL_SERVER) ;
		goto	exit_func ;
	}
	DEBUGPRINTF ((TEXT ("skkiserv_serviceGetKakuteiHistory (): ���v���C�p�P�b�g���o.\n"))) ;
	fResult	= skkiserv_replyPacket (hPipe, &vbufPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fResult ;
	UNREFERENCED_PARAMETER (nMajor) ;
	UNREFERENCED_PARAMETER (nMinor) ;
	UNREFERENCED_PARAMETER (pData) ;
	UNREFERENCED_PARAMETER (nData) ;
}

BOOL
skkiserv_replyPacket (
	register HANDLE			hPipe,
	register TVarbuffer*	pvbufPacket)
{
	register BYTE*			pPacket ;
	register int			nPacket ;

	assert (pvbufPacket != NULL) ;

	pPacket	= (BYTE*) TVarbuffer_GetBuffer (pvbufPacket) ;
	nPacket	= TVarbuffer_GetUsage  (pvbufPacket) ;
	return	skkiserv_sendPacket (hPipe, pPacket, nPacket) ;
}

BOOL
skkiserv_replyErrorPacket (
	register HANDLE			hPipe,
	register int			nMajor,
	register int			nMinor,
	register int			nErrorCode)
{
	register BYTE*			pPacket ;
	register int			nPacket ;
	register BOOL			fResult	= FALSE ;
	TVarbuffer				vbufPacket ;

	/*	�p�P�b�g�̃w�b�_�𖄂߂�B
	 */
	if (TFAILED (TVarbuffer_Initialize (&vbufPacket, sizeof (BYTE))))
		return	FALSE ;
	if (TFAILED (TPacket_SetHeader (&vbufPacket, nMajor, nMinor))   ||
		TFAILED (TPacket_AddCard16 (&vbufPacket, (WORD)nErrorCode)) ||
		TFAILED (TPacket_AddPad    (&vbufPacket)) ||
		TFAILED (TPacket_SetLength (&vbufPacket)))
		goto	exit_func ;

	pPacket	= (BYTE*) TVarbuffer_GetBuffer (&vbufPacket) ;
	nPacket	= TVarbuffer_GetUsage  (&vbufPacket) ;
	fResult	= skkiserv_sendPacket (hPipe, pPacket, nPacket) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbufPacket) ;
	return	fResult ;
}

BOOL
skkiserv_sendPacket (
	register HANDLE			hPipe,
	register BYTE*			pPacket,
	register int			nPacket)
{
	while (nPacket > 0) {
		DWORD	dwWrite ;
		if (!WriteFile (hPipe, pPacket, nPacket, &dwWrite, NULL)) {
			DEBUGPRINTFEX (103, (TEXT ("skkiserv_sendPacket (): fail(%lx).\n"), GetLastError ())) ;
			return	FALSE ;
		}
		pPacket	+= dwWrite ;
		nPacket	-= dwWrite ;
	}
	return	TRUE ;
}

BOOL
skkiserv_getClipboardText (
	register TVarbuffer*	pvbufText)
{
	register BOOL	fResult	= FALSE ;

	if (IsClipboardFormatAvailable (CF_UNICODETEXT) &&
		OpenClipboard (_hwndSkkiserv)){
		register HANDLE	hglb ;

		hglb	= GetClipboardData (CF_UNICODETEXT) ;
		if (hglb != NULL){
			register LPCWSTR	lpstr ;

			lpstr	= (LPCWSTR)GlobalLock (hglb) ;
			if (lpstr != NULL){
				fResult	= TVarbuffer_Add (pvbufText, lpstr, lstrlen (lpstr)) ;
				GlobalUnlock (hglb) ;
			}
		}
	}
	CloseClipboard () ;
	return	fResult ;
}

#if defined (USE_LISPEVAL)
#define	REGINFO_INIFILE			L"SkkiservIniFile"

BOOL
skkiserv_bInitLispMachine (
	TLispMachine*		pLispMachine,
	TLispManager*		pLispMgr)
{
	WCHAR			bufIniPath [MAX_PATH+1] ;
	HKEY			hSubKey ;
	int				nLength		= 0 ;
	BOOL			bRetval		= FALSE ;

	bufIniPath [0]	= L'\0' ;
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;
		LONG	lResult ;

		cbData	= sizeof (bufIniPath) - sizeof (WCHAR) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_INIFILE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_SZ) {
			(void) RegQueryValueExW (hSubKey, REGINFO_INIFILE, NULL, &dwType, (LPBYTE)bufIniPath, &cbData) ;
			bufIniPath [MAX_PATH]	= L'\0' ;
			nLength	= lstrlenW (bufIniPath) ;
		}
		RegCloseKey (hSubKey) ;
	}
	/*	Default �� Application Data �̉��� init.el ��u���A�Ƃ������Ƃɂ���B
	 */
	if (bufIniPath [0] == L'\0') {
		WCHAR	bufPath [MAX_PATH + 1] ;

		if (FAILED (SHGetFolderPathW (NULL, CSIDL_APPDATA, NULL, SHGFP_TYPE_CURRENT, bufPath)))
			return	FALSE ;
		bufPath [MAX_PATH]	= TEXT ('\0') ;
		nLength	= wnsprintfW (bufIniPath, ARRAYSIZE (bufIniPath) - 1, TEXT ("%s\\skk\\skki1_5\\init.el"), bufPath) ;
		bufIniPath [nLength]	= L'\0' ;
	}
	/*	(load-file "init.el") �� LispMachine �Ɏ��s������B
	 *	���̂��߂ɁAstring ������R�[�h�ɕϊ�������Alist �ɕϊ�����B
	 */
	if (nLength > 0) {
		Char	rCWord [512] ;
		int		nCWord ;

		nCWord	= wstr2internal (rCWord, ARRAYSIZE (rCWord), bufIniPath, nLength) ;
		if (nCWord <= 0)
			return	FALSE ;
		/*	LispMachine �Ɏ��s������B
		 */
		bRetval	= TLispMachine_LoadFile (pLispMachine, rCWord, nCWord) ;
	}
	return	bRetval ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}
#endif

