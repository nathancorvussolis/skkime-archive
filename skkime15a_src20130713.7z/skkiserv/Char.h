#pragma once

#include "charset.h"

typedef unsigned long	Char ;

/*	Prototypes */
int		Char_Charset (Char) ;
unsigned int	Char_Code (Char) ;
int		Char_ToAscii (Char) ;
int		Char_IsAscii (Char) ;
int		Char_Difference (Char, Char) ;
Char	Char_Make (int, unsigned int) ;
Char	Char_MakeAscii (int) ;
int		Char_DifferenceAscii (Char, int) ;
int		Char_IsEqual (Char, Char) ;
int		Char_IsEqualAscii (Char, Char);
int		Char_IsNul (Char) ;
int		Char_IsAlpha (Char) ;
int		Char_IsDigitNum (Char) ;
int		Char_IsAlphaNum (Char) ;
int		Char_IsSpace (Char) ;
int		Char_Is2ByteChara (Char) ;
Char	Char_ToLower (Char) ;
Char	Char_ToUpper (Char) ;

