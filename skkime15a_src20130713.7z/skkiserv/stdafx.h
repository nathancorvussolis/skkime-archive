/**
���ʐݒ�
*/

#pragma once

#include "local.h"

#include <locale.h>
#include <process.h>
