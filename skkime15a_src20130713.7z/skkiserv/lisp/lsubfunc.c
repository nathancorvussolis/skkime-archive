/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "lmachinep.h"
#include "../kstring.h"
/*
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lispmgrp.h"
#include "cstring.h"
#include "kstring.h"
#include "varbuffer.h"
*/

static	BOOL	appendList		(TLispManager*, TLispEntity*, TLispEntity**, TLispEntity**) ;
static	BOOL	appendVector	(TLispManager*, TLispEntity*, TLispEntity**, TLispEntity**) ;
static	BOOL	appendString	(TLispManager*, TLispEntity*, TLispEntity**, TLispEntity**) ;
static	BOOL	lispMgr_deleteDelqCommon	(TLispManager*, TLispEntity*, TLispEntity*, BOOL (*)(TLispManager*, TLispEntity*, TLispEntity*), TLispEntity**) ;
static	BOOL	lispEntity_fakeEq	(TLispManager*, TLispEntity*, TLispEntity*) ;

/*	Library Global Function */	
/*
 *	�t�@�C����ǂݍ��݁A���߂�����A�Ԃ��B
 */
BOOL
lispMgr_Load (
	register TLispManager*			pLispMgr,
	register const Char*			pFileName,
	register int					nFileNameLen,
	register TLispEntity** const	ppReturn)
{
	TCHAR			szFileName [PATH_MAX + 1] ;
	register int	n ;
	TLispEntity*	pRetval ;
	
	n	= internal2wstr (szFileName, MAX_PATH, pFileName, nFileNameLen) ;
	if (n >= PATH_MAX)
		return	FALSE ;
	szFileName [n]	= TEXT ('\0') ;
	pRetval			= lispMgr_ParseFile (pLispMgr, szFileName) ;

	*ppReturn	= pRetval ;
	return	(pRetval == NULL)? FALSE : TRUE ;
}

BOOL
lispMgr_Append (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pSequence,
	register TLispEntity** const	ppReturn)
{
	TLispEntity*	pHead ;
	TLispEntity*	pTail ;
	int				iType ;

	pHead		= NULL ;
	pTail		= NULL ;

	if (TFAILED (lispEntity_Nullp (pLispMgr, pSequence))) {
		TLispEntity*	pArg ;
		TLispEntity*	pNextSequence ;

		pArg	= NULL ;
		for ( ; ; ) {
			if (TFAILED (lispEntity_GetCar    (pLispMgr, pSequence, &pArg)) ||
				TFAILED (lispEntity_Sequencep (pLispMgr, pArg)) ||
				TFAILED (lispEntity_GetCdr    (pLispMgr, pSequence, &pNextSequence))) {
				if (pHead != NULL)
					lispEntity_Release (pLispMgr, pHead) ;
				return	FALSE ;
			}
			if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pNextSequence))) 
				break ;
			lispEntity_GetType (pLispMgr, pArg, &iType) ;
			switch (iType) {
			case	LISPENTITY_CONSCELL:
				if (TFAILED (appendList (pLispMgr, pArg, &pHead, &pTail))) 
					goto	exit_loop ;
				break ;
			case	LISPENTITY_VECTOR:
				if (TFAILED (appendVector (pLispMgr, pArg, &pHead, &pTail)))
					goto	exit_loop ;
				break ;
			case	LISPENTITY_STRING:
				if (TFAILED (appendString (pLispMgr, pArg, &pHead, &pTail)))
					goto	exit_loop ;
				break ;
			default:
				break ;
			}
			pSequence	= pNextSequence ;
		}
	exit_loop:
		if (pHead == NULL && pTail == NULL && pArg != NULL &&
			TSUCCEEDED (lispEntity_Sequencep (pLispMgr, pArg))) {
			pHead	= pArg ;
			lispEntity_AddRef (pLispMgr, pHead) ;
		} else {
			if (pTail != NULL && pArg != NULL) {
				if (TFAILED (lispEntity_SetCdr (pLispMgr, pTail, pArg))) {
					if (pHead != NULL)
						lispEntity_Release (pLispMgr, pHead) ;
					return	FALSE ;
				}
			}
		}
	}
	if (pHead == NULL) {
		lispMgr_CreateNil (pLispMgr, &pHead) ;
	} else {
		lispEntity_Release (pLispMgr, pHead) ;
	}
	*ppReturn	= pHead ;
	return	TRUE ;
}

BOOL
lispMgr_Nreverse (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pList,
	register TLispEntity**	const	ppReturn)
{
	TVarbuffer		vbufEntity ;
	TLispEntity*	pRetval	= NULL ;
	TLispEntity*	pCar ;
	TLispEntity*	pNextList ;
	int				nEntity ;

	if (TFAILED (TVarbuffer_Initialize (&vbufEntity, sizeof (TLispEntity *))))
		return	FALSE ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pList, &pCar)) ||
			TFAILED (TVarbuffer_Add (&vbufEntity, &pCar, 1)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pList, &pNextList)))
			goto	error_occur ;
		pList	= pNextList ;
	}
	nEntity		= TVarbuffer_GetUsage (&vbufEntity) ;
	if (nEntity > 0) {
		TLispEntity*	pHead ;
		TLispEntity*	pTail ;
		TLispEntity*	pNewTail ;
		TLispEntity*	pNil ;
		TLispEntity**	ppEntity ;
		
		lispMgr_CreateNil (pLispMgr, &pNil) ;
		ppEntity	= (TLispEntity **)TVarbuffer_GetBuffer (&vbufEntity) + nEntity - 1 ;
		if (TFAILED (lispMgr_CreateConscell (pLispMgr, *ppEntity, pNil, &pHead))) {
			pHead	= NULL ;
			goto	create_error ;
		}
		lispEntity_AddRef (pLispMgr, pHead) ;
		ppEntity	-- ;
		nEntity		-- ;
		pTail		= pHead ;

		while (nEntity > 0) {
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, *ppEntity, pNil, &pNewTail))) {
				lispEntity_Release (pLispMgr, pHead) ;
				pHead	= NULL ;
				goto	create_error ;
			}
			lispEntity_SetCdr (pLispMgr, pTail, pNewTail) ;
			pTail	= pNewTail ;
			ppEntity	-- ;
			nEntity		-- ;
		}
	create_error:
		pRetval	= pHead ;
	} else {
		lispMgr_CreateNil (pLispMgr, &pRetval) ;
		lispEntity_AddRef (pLispMgr, pRetval) ;
	}
 error_occur:
	TVarbuffer_Uninitialize (&vbufEntity) ;
	*ppReturn	= pRetval ;
	if (pRetval != NULL) {
		lispEntity_Release (pLispMgr, pRetval) ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
lispMgr_Delete (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pElt,
	register TLispEntity*			pList,
	register TLispEntity**	const	ppReturn)
{
	return	lispMgr_deleteDelqCommon (pLispMgr, pElt, pList, &lispEntity_Equal, ppReturn) ;
}

BOOL
lispMgr_Delq (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pElt,
	register TLispEntity*			pList,
	register TLispEntity**	const	ppReturn)
{
	return	lispMgr_deleteDelqCommon (pLispMgr, pElt, pList, &lispEntity_fakeEq, ppReturn) ;
}

/*	�ȉ� private function */
BOOL
appendList (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispEntity**	ppListHead,
	register TLispEntity**	ppListTail)
{
	register TLispEntity*	pHead ;
	TLispEntity*	pTail ;
	TLispEntity*	pCar ;
	TLispEntity*	pCdr ;
	TLispEntity*	pNewTail ;
	TLispEntity*	pNil ;

	assert (pLispMgr   != NULL) ;
	assert (pEntity    != NULL) ;
	assert (ppListHead != NULL) ;
	assert (ppListTail != NULL) ;

	pHead	= *ppListHead ;
	pTail	= *ppListTail ;
	lispMgr_CreateNil (pLispMgr, &pNil) ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntity))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntity, &pCar)))
			return	FALSE ;
		if (TFAILED (lispMgr_CreateConscell (pLispMgr, pCar, pNil, &pNewTail)))
			return	FALSE ;
		if (pTail == NULL) {
			assert (pHead == NULL) ;
			lispEntity_AddRef (pLispMgr, pNewTail) ;
			pHead	= pNewTail ;
		} else {
			lispEntity_SetCdr (pLispMgr, pTail, pNewTail) ;
		}
		pTail	= pNewTail ;
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pCdr)))
			return	FALSE ;
		pEntity	= pCdr ;
	}
	*ppListHead	= pHead ;
	*ppListTail	= pTail ;
	return	TRUE ;
}

BOOL
appendVector (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispEntity**	ppListHead,
	register TLispEntity**	ppListTail)
{
	TLispEntity*	pHead ;
	TLispEntity*	pTail ;
	TLispEntity*	pNewTail ;
	TLispEntity*	pNil ;
	TLispEntity**	ppElements ;
	int				nElements ;

	assert (pLispMgr   != NULL) ;
	assert (pEntity    != NULL) ;
	assert (ppListHead != NULL) ;
	assert (ppListTail != NULL) ;

	lispMgr_CreateNil (pLispMgr, &pNil) ;
	if (TFAILED (lispEntity_GetVectorValue (pLispMgr, pEntity, &ppElements, &nElements)))
		return	FALSE ;

	if (ppElements != NULL && nElements > 0) {
		pHead	= *ppListHead ;
		pTail	= *ppListTail ;
		while (nElements > 0) {
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, *ppElements, pNil, &pNewTail)))
				break ;
			if (pTail == NULL) {
				assert (pHead == NULL) ;
				lispEntity_AddRef (pLispMgr, pNewTail) ;
				pHead	= pNewTail ;
			} else {
				lispEntity_SetCdr (pLispMgr, pTail, pNewTail) ;
			}
			pTail	= pNewTail ;
			ppElements	++ ;
			nElements	-- ;
		}
		*ppListHead	= pHead ;
		*ppListTail	= pTail ;
	}
	return	(nElements > 0)? FALSE : TRUE ;
}

BOOL
appendString (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispEntity**	ppListHead,
	register TLispEntity**	ppListTail)
{
	TLispEntity*	pHead ;
	TLispEntity*	pTail ;
	TLispEntity*	pNewTail ;
	TLispEntity*	pNil ;
	TLispEntity*	pInteger ;
	const Char*		pString ;
	int				nLength ;

	assert (pLispMgr   != NULL) ;
	assert (pEntity    != NULL) ;
	assert (ppListHead != NULL) ;
	assert (ppListTail != NULL) ;

	lispMgr_CreateNil (pLispMgr, &pNil) ;
	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntity, &pString, &nLength)))
		return	FALSE ;
	if (pString != NULL && nLength > 0) {
		pHead	= *ppListHead ;
		pTail	= *ppListTail ;
		while (nLength > 0) {
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, pNil, pNil, &pNewTail)))
				break ;
			if (pTail == NULL) {
				assert (pHead == NULL) ;
				lispEntity_AddRef (pLispMgr, pNewTail) ;
				pHead	= pNewTail ;
			} else {
				lispEntity_SetCdr (pLispMgr, pTail, pNewTail) ;
			}
			if (TFAILED (lispMgr_CreateInteger (pLispMgr, *pString, &pInteger)))
				break ;
			lispEntity_SetCar (pLispMgr, pNewTail, pInteger) ;
			pTail	= pNewTail ;
			pString	++ ;
			nLength	-- ;
		}
		*ppListHead	= pHead ;
		*ppListTail	= pTail ;
	}
	return	(nLength > 0)? FALSE : TRUE ;
}

BOOL
lispMgr_deleteDelqCommon (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pElt,
	register TLispEntity*	pList,
	register BOOL			(*pCompFunc)(TLispManager*, TLispEntity*, TLispEntity*),
	register TLispEntity**	ppReturn)
{
	TLispEntity*	pListElt ;
	TLispEntity*	pHead ;
	TLispEntity*	pPrevList ;
	TLispEntity*	pNextList ;

	assert (pLispMgr  != NULL) ;
	assert (pElt      != NULL) ;
	assert (pList     != NULL) ;
	assert (pCompFunc != NULL) ;
	assert (ppReturn  != NULL) ;

	if (TFAILED (lispEntity_Listp (pLispMgr, pList)))
		return	FALSE ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pList, &pListElt)))
			return	FALSE ;

		if (TFAILED ((*pCompFunc) (pLispMgr, pElt, pListElt)))
			break ;
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pList, &pNextList)))
			return	FALSE ;
		pList	= pNextList ;
	}
	pHead		= pList ;
	pPrevList	= NULL ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pList, &pListElt)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pList, &pNextList)))
			return	FALSE ;

		if (TSUCCEEDED ((*pCompFunc) (pLispMgr, pElt, pListElt))) {
			assert (pPrevList != NULL) ;
			lispEntity_SetCdr (pLispMgr, pPrevList, pNextList) ;
		} else {
			pPrevList	= pList ;
		}
		pList		= pNextList ;
	}
	*ppReturn	= pHead ;
	return	TRUE ;
}

BOOL
lispEntity_fakeEq (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pLeft,
	register TLispEntity*	pRight)
{
	return	(pLeft == pRight) ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

