/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "lmachinep.h"
/*
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"
*/

/*	function prototype */
static	BOOL	lispMachine_bsearchCommandInfo	(const Char*, int, LMCMDINFO const **) ;

#define	LM_NUM_FUNCTION		(ARRAYSIZE(saLispMachineBuiltinCmds) - 2)
#define	LM_INDEX_LAMBDA		(ARRAYSIZE(saLispMachineBuiltinCmds) - 2)
#define	LM_INDEX_MACRO		(ARRAYSIZE(saLispMachineBuiltinCmds) - 1)

static Char	_srRemainder			[] = 	{ '%', '\0', } ;
static Char	_srMultiply				[] = 	{ '*', '\0', } ;
static Char	_srPlus					[] = 	{ '+', '\0', } ;
static Char	_srMinus				[] = 	{ '-', '\0', } ;
static Char	_srDivide				[] = 	{ '/', '\0', } ;
static Char	_srSlashEqual			[] = 	{ '/', '=', '\0', } ;
static Char	_sr1Plus				[] = 	{ '1', '+', '\0', } ;
static Char _sr1Minus				[] = 	{ '1', '-', '\0', } ;
static Char _srMathLessThan			[] = 	{ '<', '\0', } ;
static Char _srMathLessEqual		[] = 	{ '<', '=', '\0', } ;
static Char _srMathEqual			[] = 	{ '=', '\0', } ;
static Char _srMathGreaterThan		[] = 	{ '>', '\0', } ;
static Char _srMathGreaterEqual		[] = 	{ '>', '=', '\0', } ;
static Char _srBackquote1			[] = 	{ '`', '\0', } ;
static Char _srAddHook				[] = 	{ 'a', 'd', 'd', '-', 'h', 'o', 'o', 'k', '\0', } ;
static Char _srAnd					[] = 	{ 'a', 'n', 'd', '\0', } ;
static Char _srAppend				[] = 	{ 'a', 'p', 'p', 'e', 'n', 'd', '\0', } ;
static Char _srApply				[] = 	{ 'a', 'p', 'p', 'l', 'y', '\0', } ;
static Char _srAref					[] = 	{ 'a', 'r', 'e', 'f', '\0', } ;
static Char _srArrayp				[] = 	{ 'a', 'r', 'r', 'a', 'y', 'p', '\0', } ;
static Char _srAset					[] = 	{ 'a', 's', 'e', 't', '\0', } ;
static Char _srAssoc				[] = 	{ 'a', 's', 's', 'o', 'c', '\0', } ;
static Char _srAssq					[] = 	{ 'a', 's', 's', 'q', '\0', } ;
static Char _srBackquote			[] = 	{ 'b', 'a', 'c', 'k', 'q', 'u', 'o', 't', 'e', '\0', } ;
static Char _srBackwardChar			[] = 	{ 'b', 'a', 'c', 'k', 'w', 'a', 'r', 'd', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srBackwardDeleteChar	[] = 	{ 'b', 'a', 'c', 'k', 'w', 'a', 'r', 'd', '-', 'd', 'e', 'l', 'e', 't', 'e', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srBeginningOfLine		[] = 	{ 'b', 'e', 'g', 'i', 'n', 'n', 'i', 'n', 'g', '-', 'o', 'f', '-', 'l', 'i', 'n', 'e', '\0', } ;
static Char _srBobp					[] = 	{ 'b', 'o', 'b', 'p', '\0', } ;
static Char _srBoundp				[] = 	{ 'b', 'o', 'u', 'n', 'd', 'p', '\0', } ;
static Char _srBufferModifiedp		[] = 	{ 'b', 'u', 'f', 'f', 'e', 'r', '-', 'm', 'o', 'd', 'i', 'f', 'i', 'e', 'd', '-', 'p', '\0', } ;
static Char _srBufferString			[] = 	{ 'b', 'u', 'f', 'f', 'e', 'r', '-', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srBufferSubstring		[] = 	{ 'b', 'u', 'f', 'f', 'e', 'r', '-', 's', 'u', 'b', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srByteCodeFunctionp	[] = 	{ 'b', 'y', 't', 'e', '-', 'c', 'o', 'd', 'e', '-', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', '-', 'p', '\0', } ;
static Char _srCar					[] = 	{ 'c', 'a', 'r', '\0', } ;
static Char _srCarSafe				[] = 	{ 'c', 'a', 'r', '-', 's', 'a', 'f', 'e', '\0', } ;
static Char _srCatch				[] = 	{ 'c', 'a', 't', 'c', 'h', '\0', } ;
static Char _srCdr					[] = 	{ 'c', 'd', 'r', '\0', } ;
static Char _srCharAfter			[] = 	{ 'c', 'h', 'a', 'r', '-', 'a', 'f', 't', 'e', 'r', '\0', } ;
static Char _srCharCharset			[] = 	{ 'c', 'h', 'a', 'r', '-', 'c', 'h', 'a', 'r', 's', 'e', 't', '\0', } ;
static Char _srCharToString			[] = 	{ 'c', 'h', 'a', 'r', '-', 't', 'o', '-', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srCommandExecute		[] = 	{ 'c', 'o', 'm', 'm', 'a', 'n', 'd', '-', 'e', 'x', 'e', 'c', 'u', 't', 'e', '\0', } ;
static Char _srCommandp				[] = 	{ 'c', 'o', 'm', 'm', 'a', 'n', 'd', 'p', '\0', } ;
static Char _srConcat				[] = 	{ 'c', 'o', 'n', 'c', 'a', 't', '\0', } ;
static Char _srCond					[] = 	{ 'c', 'o', 'n', 'd', '\0', } ;
static Char _srConditionCase		[] = 	{ 'c', 'o', 'n', 'd', 'i', 't', 'i', 'o', 'n', '-', 'c', 'a', 's', 'e', '\0', } ;
static Char _srCons					[] = 	{ 'c', 'o', 'n', 's', '\0', } ;
static Char _srConsp				[] = 	{ 'c', 'o', 'n', 's', 'p', '\0', } ;
static Char _srCopyKeymap			[] = 	{ 'c', 'o', 'p', 'y', '-', 'k', 'e', 'y', 'm', 'a', 'p', '\0', } ;
static Char _srCopyMarker			[] = 	{ 'c', 'o', 'p', 'y', '-', 'm', 'a', 'r', 'k', 'e', 'r', '\0', } ;
static Char _srCountLines			[] = 	{ 'c', 'o', 'u', 'n', 't', '-', 'l', 'i', 'n', 'e', 's', '\0', } ;
static Char _srCurrentBuffer		[] = 	{ 'c', 'u', 'r', 'r', 'e', 'n', 't', '-', 'b', 'u', 'f', 'f', 'e', 'r', '\0', } ;
static Char _srCurrentLocalMap		[] = 	{ 'c', 'u', 'r', 'r', 'e', 'n', 't', '-', 'l', 'o', 'c', 'a', 'l', '-', 'm', 'a', 'p', '\0', } ;
static Char _srCurrentMinorModeMaps	[] = 	{ 'c', 'u', 'r', 'r', 'e', 'n', 't', '-', 'm', 'i', 'n', 'o', 'r', '-', 'm', 'o', 'd', 'e', '-', 'm', 'a', 'p', 's', '\0', } ;
static Char _srCurrentTimeString	[] = 	{ 'c', 'u', 'r', 'r', 'e', 'n', 't', '-', 't', 'i', 'm', 'e', '-', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srDefaultValue			[] = 	{ 'd', 'e', 'f', 'a', 'u', 'l', 't', '-', 'v', 'a', 'l', 'u', 'e', '\0', } ;
static Char _srDefconst				[] = 	{ 'd', 'e', 'f', 'c', 'o', 'n', 's', 't', '\0', } ;
static Char _srDefineKey			[] = 	{ 'd', 'e', 'f', 'i', 'n', 'e', '-', 'k', 'e', 'y', '\0', } ;
static Char _srDefmacro				[] = 	{ 'd', 'e', 'f', 'm', 'a', 'c', 'r', 'o', '\0', } ;
static Char _srDefun				[] = 	{ 'd', 'e', 'f', 'u', 'n', '\0', } ;
static Char _srDefvar				[] = 	{ 'd', 'e', 'f', 'v', 'a', 'r', '\0', } ;
static Char _srDelete				[] = 	{ 'd', 'e', 'l', 'e', 't', 'e', '\0', } ;
static Char _srDeleteBackwardChar	[] = 	{ 'd', 'e', 'l', 'e', 't', 'e', '-', 'b', 'a', 'c', 'k', 'w', 'a', 'r', 'd', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srDeleteChar			[] = 	{ 'd', 'e', 'l', 'e', 't', 'e', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srDeleteRegion			[] = 	{ 'd', 'e', 'l', 'e', 't', 'e', '-', 'r', 'e', 'g', 'i', 'o', 'n', '\0', } ;
static Char _srDelq					[] = 	{ 'd', 'e', 'l', 'q', '\0', } ;
static Char _srDing					[] = 	{ 'd', 'i', 'n', 'g', '\0', } ;
static Char _srDocumentation		[] = 	{ 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't', 'a', 't', 'i', 'o', 'n', '\0', } ;
static Char _srDowncase				[] = 	{ 'd', 'o', 'w', 'n', 'c', 'a', 's', 'e', '\0', } ;
static Char _srEndOfLine			[] = 	{ 'e', 'n', 'd', '-', 'o', 'f', '-', 'l', 'i', 'n', 'e', '\0', } ;
static Char _srEobp					[] = 	{ 'e', 'o', 'b', 'p', '\0', } ;
static Char _srEolp					[] = 	{ 'e', 'o', 'l', 'p', '\0', } ;
static Char _srEq					[] = 	{ 'e', 'q', '\0', } ;
static Char _srEqual				[] = 	{ 'e', 'q', 'u', 'a', 'l', '\0', } ;
static Char _srEraseBuffer			[] = 	{ 'e', 'r', 'a', 's', 'e', '-', 'b', 'u', 'f', 'f', 'e', 'r', '\0', } ;
static Char _srError				[] = 	{ 'e', 'r', 'r', 'o', 'r', '\0', } ;
static Char _srEval					[] = 	{ 'e', 'v', 'a', 'l', '\0', } ;
static Char _srFboundp				[] = 	{ 'f', 'b', 'o', 'u', 'n', 'd', 'p', '\0', } ;
static Char _srFeaturep				[] = 	{ 'f', 'e', 'a', 't', 'u', 'r', 'e', 'p', '\0', } ;
static Char _srFloatp				[] = 	{ 'f', 'l', 'o', 'a', 't', 'p', '\0', } ;
static Char _srFmakunbound			[] = 	{ 'f', 'm', 'a', 'k', 'u', 'n', 'b', 'o', 'u', 'n', 'd', '\0', } ;
static Char _srFollowingChar		[] = 	{ 'f', 'o', 'l', 'l', 'o', 'w', 'i', 'n', 'g', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srFormat				[] = 	{ 'f', 'o', 'r', 'm', 'a', 't', '\0', } ;
static Char _srForwardChar			[] = 	{ 'f', 'o', 'r', 'w', 'a', 'r', 'd', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srForwardLine			[] = 	{ 'f', 'o', 'r', 'w', 'a', 'r', 'd', '-', 'l', 'i', 'n', 'e', '\0', } ;
static Char _srForwardWord			[] = 	{ 'f', 'o', 'r', 'w', 'a', 'r', 'd', '-', 'w', 'o', 'r', 'd', '\0', } ;
static Char _srFset					[] = 	{ 'f', 's', 'e', 't', '\0', } ;
static Char _srFuncall				[] = 	{ 'f', 'u', 'n', 'c', 'a', 'l', 'l', '\0', } ;
static Char _srFunction				[] = 	{ 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', '\0', } ;
static Char _srFunctionp			[] = 	{ 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 'p', '\0', } ;
static Char _srGenerateNewBuffer	[] = 	{ 'g', 'e', 'n', 'e', 'r', 'a', 't', 'e', '-', 'n', 'e', 'w', '-', 'b', 'u', 'f', 'f', 'e', 'r', '\0', } ;
static Char _srGenerateNewBufferName[] = 	{ 'g', 'e', 'n', 'e', 'r', 'a', 't', 'e', '-', 'n', 'e', 'w', '-', 'b', 'u', 'f', 'f', 'e', 'r', '-', 'n', 'a', 'm', 'e', '\0', } ;
static Char _srGet					[] = 	{ 'g', 'e', 't', '\0', } ;
static Char _srGetBuffer			[] = 	{ 'g', 'e', 't', '-', 'b', 'u', 'f', 'f', 'e', 'r', '\0', } ;
static Char _srGetBufferCreate		[] = 	{ 'g', 'e', 't', '-', 'b', 'u', 'f', 'f', 'e', 'r', '-', 'c', 'r', 'e', 'a', 't', 'e', '\0', } ;
static Char _srGetenv				[] = 	{ 'g', 'e', 't', 'e', 'n', 'v', '\0', } ;
static Char _srGotoChar				[] = 	{ 'g', 'o', 't', 'o', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srIdentity				[] = 	{ 'i', 'd', 'e', 'n', 't', 'i', 't', 'y', '\0', } ;
static Char _srIf					[] = 	{ 'i', 'f', '\0', } ;
static Char _srInsert				[] = 	{ 'i', 'n', 's', 'e', 'r', 't', '\0', } ;
static Char _srInsertChar			[] = 	{ 'i', 'n', 's', 'e', 'r', 't', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srInsertFileContents	[] = 	{ 'i', 'n', 's', 'e', 'r', 't', '-', 'f', 'i', 'l', 'e', '-', 'c', 'o', 'n', 't', 'e', 'n', 't', 's', '\0', } ;
static Char _srIntToString			[] = 	{ 'i', 'n', 't', '-', 't', 'o', '-', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srIntegerOrMarkerp		[] = 	{ 'i', 'n', 't', 'e', 'g', 'e', 'r', '-', 'o', 'r', '-', 'm', 'a', 'r', 'k', 'e', 'r', '-', 'p', '\0', } ;
static Char _srIntegerp				[] = 	{ 'i', 'n', 't', 'e', 'g', 'e', 'r', 'p', '\0', } ;
static Char _srInteractive			[] = 	{ 'i', 'n', 't', 'e', 'r', 'a', 'c', 't', 'i', 'v', 'e', '\0', } ;
static Char _srInteractivep			[] = 	{ 'i', 'n', 't', 'e', 'r', 'a', 'c', 't', 'i', 'v', 'e', '-', 'p', '\0', } ;
static Char _srIntern				[] = 	{ 'i', 'n', 't', 'e', 'r', 'n', '\0', } ;
static Char _srInternSoft			[] = 	{ 'i', 'n', 't', 'e', 'r', 'n', '-', 's', 'o', 'f', 't', '\0', } ;
static Char _srJKeyBinding			[] = 	{ 'j', '-', 'k', 'e', 'y', '-', 'b', 'i', 'n', 'd', 'i', 'n', 'g', '\0', } ;
static Char _srKeyBinding			[] = 	{ 'k', 'e', 'y', '-', 'b', 'i', 'n', 'd', 'i', 'n', 'g', '\0', } ;
static Char _srKeymapp				[] = 	{ 'k', 'e', 'y', 'm', 'a', 'p', 'p', '\0', } ;
static Char _srKillLine				[] = 	{ 'k', 'i', 'l', 'l', '-', 'l', 'i', 'n', 'e', '\0', } ;
static Char _srKillRegion			[] = 	{ 'k', 'i', 'l', 'l', '-', 'r', 'e', 'g', 'i', 'o', 'n', '\0', } ;
static Char _srLambda				[] = 	{ 'l', 'a', 'm', 'b', 'd', 'a', '\0', } ;
static Char _srLength				[] = 	{ 'l', 'e', 'n', 'g', 't', 'h', '\0', } ;
static Char _srLet					[] = 	{ 'l', 'e', 't', '\0', } ;
static Char _srLetStar				[] = 	{ 'l', 'e', 't', '*', '\0', } ;
static Char _srReturnOnly			[] = 	{ 'l', 'i', 's', 't', '\0', } ;
static Char _srListp				[] = 	{ 'l', 'i', 's', 't', 'p', '\0', } ;
static Char _srLoad					[] = 	{ 'l', 'o', 'a', 'd', '\0', } ;
static Char _srLoadFile				[] = 	{ 'l', 'o', 'a', 'd', '-', 'f', 'i', 'l', 'e', '\0', } ;
static Char _srLocalSetKey			[] = 	{ 'l', 'o', 'c', 'a', 'l', '-', 's', 'e', 't', '-', 'k', 'e', 'y', '\0', } ;
static Char _srLookupKey			[] = 	{ 'l', 'o', 'o', 'k', 'u', 'p', '-', 'k', 'e', 'y', '\0', } ;
static Char _srMakeCharacter		[] = 	{ 'm', 'a', 'k', 'e', '-', 'c', 'h', 'a', 'r', 'a', 'c', 't', 'e', 'r', '\0', } ;
static Char _srMakeKeymap			[] = 	{ 'm', 'a', 'k', 'e', '-', 'k', 'e', 'y', 'm', 'a', 'p', '\0', } ;
static Char _srMakeLocalHook		[] = 	{ 'm', 'a', 'k', 'e', '-', 'l', 'o', 'c', 'a', 'l', '-', 'h', 'o', 'o', 'k', '\0', } ;
static Char _srMakeLocalVariable	[] = 	{ 'm', 'a', 'k', 'e', '-', 'l', 'o', 'c', 'a', 'l', '-', 'v', 'a', 'r', 'i', 'a', 'b', 'l', 'e', '\0', } ;
static Char _srMakeMarker			[] = 	{ 'm', 'a', 'k', 'e', '-', 'm', 'a', 'r', 'k', 'e', 'r', '\0', } ;
static Char _srMakeSparseKeymap		[] = 	{ 'm', 'a', 'k', 'e', '-', 's', 'p', 'a', 'r', 's', 'e', '-', 'k', 'e', 'y', 'm', 'a', 'p', '\0', } ;
static Char _srMakeString			[] = 	{ 'm', 'a', 'k', 'e', '-', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srMakeSymbol			[] = 	{ 'm', 'a', 'k', 'e', '-', 's', 'y', 'm', 'b', 'o', 'l', '\0', } ;
static Char _srMakeVariableBufferLocal [] = 	{ 'm', 'a', 'k', 'e', '-', 'v', 'a', 'r', 'i', 'a', 'b', 'l', 'e', '-', 'b', 'u', 'f', 'f', 'e', 'r', '-', 'l', 'o', 'c', 'a', 'l', '\0', } ;
static Char _srMakunbound			[] = 	{ 'm', 'a', 'k', 'u', 'n', 'b', 'o', 'u', 'n', 'd', '\0', } ;
static Char _srMapcar				[] = 	{ 'm', 'a', 'p', 'c', 'a', 'r', '\0', } ;
static Char _srMapconcat			[] = 	{ 'm', 'a', 'p', 'c', 'o', 'n', 'c', 'a', 't', '\0', } ;
static Char _srMark					[] = 	{ 'm', 'a', 'r', 'k', '\0', } ;
static Char _srMarkerBuffer			[] = 	{ 'm', 'a', 'r', 'k', 'e', 'r', '-', 'b', 'u', 'f', 'f', 'e', 'r', '\0', } ;
static Char _srMarkerInsertionType	[] = 	{ 'm', 'a', 'r', 'k', 'e', 'r', '-', 'i', 'n', 's', 'e', 'r', 't', 'i', 'o', 'n', '-', 't', 'y', 'p', 'e', '\0', } ;
static Char _srMarkerPosition		[] = 	{ 'm', 'a', 'r', 'k', 'e', 'r', '-', 'p', 'o', 's', 'i', 't', 'i', 'o', 'n', '\0', } ;
static Char _srMarkerp				[] = 	{ 'm', 'a', 'r', 'k', 'e', 'r', 'p', '\0', } ;
#if defined (USE_REGEX)
static Char _srMatchBeginning		[] = 	{ 'm', 'a', 't', 'c', 'h', '-', 'b', 'e', 'g', 'i', 'n', 'n', 'i', 'n', 'g', '\0', } ;
static Char _srMatchData			[] = 	{ 'm', 'a', 't', 'c', 'h', '-', 'd', 'a', 't', 'a', '\0', } ;
static Char _srMatchEnd				[] = 	{ 'm', 'a', 't', 'c', 'h', '-', 'e', 'n', 'd', '\0', } ;
#endif
static Char _srMax					[] = 	{ 'm', 'a', 'x', '\0', } ;
static Char _srMember				[] = 	{ 'm', 'e', 'm', 'b', 'e', 'r', '\0', } ;
static Char _srMemq					[] = 	{ 'm', 'e', 'm', 'q', '\0', } ;
static Char _srMin					[] = 	{ 'm', 'i', 'n', '\0', } ;
static Char _srMod					[] = 	{ 'm', 'o', 'd', '\0', } ;
static Char _srModifyAlist			[] = 	{ 'm', 'o', 'd', 'i', 'f', 'y', '-', 'a', 'l', 'i', 's', 't', '\0', } ;
static Char _srMoveMarker			[] = 	{ 'm', 'o', 'v', 'e', '-', 'm', 'a', 'r', 'k', 'e', 'r', '\0', } ;
static Char _srNarrowToRegion		[] = 	{ 'n', 'a', 'r', 'r', 'o', 'w', '-', 't', 'o', '-', 'r', 'e', 'g', 'i', 'o', 'n', '\0', } ;
static Char _srNatnump				[] = 	{ 'n', 'a', 't', 'n', 'u', 'm', 'p', '\0', } ;
static Char _srNconc				[] = 	{ 'n', 'c', 'o', 'n', 'c', '\0', } ;
static Char _srNot					[] = 	{ 'n', 'o', 't', '\0', } ;
static Char _srNreverse				[] = 	{ 'n', 'r', 'e', 'v', 'e', 'r', 's', 'e', '\0', } ;
static Char _srNth					[] = 	{ 'n', 't', 'h', '\0', } ;
static Char _srNthcdr				[] = 	{ 'n', 't', 'h', 'c', 'd', 'r', '\0', } ;
static Char _srNull					[] = 	{ 'n', 'u', 'l', 'l', '\0', } ;
static Char _srNumberToString		[] = 	{ 'n', 'u', 'm', 'b', 'e', 'r', '-', 't', 'o', '-', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srNumberp				[] = 	{ 'n', 'u', 'm', 'b', 'e', 'r', 'p', '\0', } ;
static Char _srOr					[] = 	{ 'o', 'r', '\0', } ;
static Char _srPlistGet				[] = 	{ 'p', 'l', 'i', 's', 't', '-', 'g', 'e', 't', '\0', } ;
static Char _srPlistPut				[] = 	{ 'p', 'l', 'i', 's', 't', '-', 'p', 'u', 't', '\0', } ;
static Char _srPoint				[] = 	{ 'p', 'o', 'i', 'n', 't', '\0', } ;
static Char _srPointMarker			[] = 	{ 'p', 'o', 'i', 'n', 't', '-', 'm', 'a', 'r', 'k', 'e', 'r', '\0', } ;
static Char _srPointMax				[] = 	{ 'p', 'o', 'i', 'n', 't', '-', 'm', 'a', 'x', '\0', } ;
static Char _srPointMin				[] = 	{ 'p', 'o', 'i', 'n', 't', '-', 'm', 'i', 'n', '\0', } ;
static Char _srPrecedingChar		[] = 	{ 'p', 'r', 'e', 'c', 'e', 'd', 'i', 'n', 'g', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srPrefixNumericValue	[] = 	{ 'p', 'r', 'e', 'f', 'i', 'x', '-', 'n', 'u', 'm', 'e', 'r', 'i', 'c', '-', 'v', 'a', 'l', 'u', 'e', '\0', } ;
static Char _srPrinc				[] = 	{ 'p', 'r', 'i', 'n', 'c', '\0', } ;
static Char _srProg1				[] = 	{ 'p', 'r', 'o', 'g', '1', '\0', } ;
static Char _srProg2				[] = 	{ 'p', 'r', 'o', 'g', '2', '\0', } ;
static Char _srProgn				[] = 	{ 'p', 'r', 'o', 'g', 'n', '\0', } ;
static Char _srProvide				[] = 	{ 'p', 'r', 'o', 'v', 'i', 'd', 'e', '\0', } ;
static Char _srPut					[] = 	{ 'p', 'u', 't', '\0', } ;
static Char _srPutAlist				[] = 	{ 'p', 'u', 't', '-', 'a', 'l', 'i', 's', 't', '\0', } ;
static Char _srQueueAll				[] = 	{ 'q', 'u', 'e', 'u', 'e', '-', 'a', 'l', 'l', '\0', } ;
static Char _srQueueCreate			[] = 	{ 'q', 'u', 'e', 'u', 'e', '-', 'c', 'r', 'e', 'a', 't', 'e', '\0', } ;
static Char _srQueueEnqueue			[] = 	{ 'q', 'u', 'e', 'u', 'e', '-', 'e', 'n', 'q', 'u', 'e', 'u', 'e', '\0', } ;
static Char _srQuote				[] = 	{ 'q', 'u', 'o', 't', 'e', '\0', } ;
static Char _srRassoc				[] = 	{ 'r', 'a', 's', 's', 'o', 'c', '\0', } ;
#if defined (USE_REGEX)
static Char	_srReSearchBackward		[] =	{ 'r', 'e', '-', 's', 'e', 'a', 'r', 'c', 'h', '-', 'b', 'a', 'c', 'k', 'w', 'a', 'r', 'd', '\0', } ;
static Char	_srReSearchForward		[] =	{ 'r', 'e', '-', 's', 'e', 'a', 'r', 'c', 'h', '-', 'f', 'o', 'r', 'e', 'w', 'a', 'r', 'd', '\0', } ;
#endif
static Char _srReadFromString		[] = 	{ 'r', 'e', 'a', 'd', '-', 'f', 'r', 'o', 'm', '-', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
#if defined (USE_REGEX)
static Char	_srRegexpQuote			[] =	{ 'r', 'e', 'g', 'e', 'x', 'p', '-', 'q', 'u', 'o', 't', 'e', '\0' } ;
#endif
static Char _srRplaca				[] = 	{ 'r', 'p', 'l', 'a', 'c', 'a', '\0', } ;
static Char _srRunHooks				[] = 	{ 'r', 'u', 'n', '-', 'h', 'o', 'o', 'k', 's', '\0', } ;
static Char _srSaveCurrentBuffer	[] = 	{ 's', 'a', 'v', 'e', '-', 'c', 'u', 'r', 'r', 'e', 'n', 't', '-', 'b', 'u', 'f', 'f', 'e', 'r', '\0', } ;
static Char _srSaveExcursion		[] = 	{ 's', 'a', 'v', 'e', '-', 'e', 'x', 'c', 'u', 'r', 's', 'i', 'o', 'n', '\0', } ;
static Char _srSaveRestriction		[] = 	{ 's', 'a', 'v', 'e', '-', 'r', 'e', 's', 't', 'r', 'i', 'c', 't', 'i', 'o', 'n', '\0', } ;
#if defined (USE_REGEX)
static Char	_srSearchBackward		[] =	{ 's', 'e', 'a', 'r', 'c', 'h', '-', 'b', 'a', 'c', 'k', 'w', 'a', 'r', 'd', '\0' } ;
static Char	_srSearchForward		[] =	{ 's', 'e', 'a', 'r', 'c', 'h', '-', 'f', 'o', 'r', 'w', 'a', 'r', 'd', '\0' } ;
#endif
static Char _srSelfInsertCommand	[] = 	{ 's', 'e', 'l', 'f', '-', 'i', 'n', 's', 'e', 'r', 't', '-', 'c', 'o', 'm', 'm', 'a', 'n', 'd', '\0', } ;
static Char _srSequencep			[] = 	{ 's', 'e', 'q', 'u', 'e', 'n', 'c', 'e', 'p', '\0', } ;
static Char _srSet					[] = 	{ 's', 'e', 't', '\0', } ;
static Char _srSetBuffer			[] = 	{ 's', 'e', 't', '-', 'b', 'u', 'f', 'f', 'e', 'r', '\0', } ;
static Char _srSetBufferModifiedp	[] = 	{ 's', 'e', 't', '-', 'b', 'u', 'f', 'f', 'e', 'r', '-', 'm', 'o', 'd', 'i', 'f', 'i', 'e', 'd', '-', 'p', '\0', } ;
static Char _srSetMark				[] = 	{ 's', 'e', 't', '-', 'm', 'a', 'r', 'k', '\0', } ;
static Char _srSetMarker			[] = 	{ 's', 'e', 't', '-', 'm', 'a', 'r', 'k', 'e', 'r', '\0', } ;
#if defined (USE_REGEX)
static Char	_srSetMatchData			[] =	{ 's', 'e', 't', '-', 'm', 'a', 't', 'c', 'h', '-', 'd', 'a', 't', 'a', '\0' } ;
#endif
static Char _srSetModifiedAlist		[] = 	{ 's', 'e', 't', '-', 'm', 'o', 'd', 'i', 'f', 'i', 'e', 'd', '-', 'a', 'l', 'i', 's', 't', '\0', } ;
static Char _srSetcar				[] = 	{ 's', 'e', 't', 'c', 'a', 'r', '\0', } ;
static Char _srSetcdr				[] = 	{ 's', 'e', 't', 'c', 'd', 'r', '\0', } ;
static Char _srSetplist				[] = 	{ 's', 'e', 't', 'p', 'l', 'i', 's', 't', '\0', } ;
static Char _srSetq					[] = 	{ 's', 'e', 't', 'q', '\0', } ;
static Char _srSetqDefault			[] = 	{ 's', 'e', 't', 'q', '-', 'd', 'e', 'f', 'a', 'u', 'l', 't', '\0', } ;
static Char _srSignal				[] = 	{ 's', 'i', 'g', 'n', 'a', 'l', '\0', } ;
static Char _srString				[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srStringEqual			[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 'e', 'q', 'u', 'a', 'l', '\0', } ;
static Char _srStringLessp			[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 'l', 'e', 's', 's', 'p', '\0', } ;
#if defined (USE_REGEX)
static Char _srStringMatch			[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 'm', 'a', 't', 'c', 'h', '\0', } ;
#endif
static Char _srStringToChar			[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 't', 'o', '-', 'c', 'h', 'a', 'r', '\0', } ;
static Char _srStringToCharList		[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 't', 'o', '-', 'c', 'h', 'a', 'r', '-', 'l', 'i', 's', 't', '\0', } ;
static Char _srStringToInt			[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 't', 'o', '-', 'i', 'n', 't', '\0', } ;
static Char _srStringToIntList		[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 't', 'o', '-', 'i', 'n', 't', '-', 'l', 'i', 's', 't', '\0', } ;
static Char _srStringToNumber		[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '-', 't', 'o', '-', 'n', 'u', 'm', 'b', 'e', 'r', '\0', } ;
static Char _srStringLessp1			[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '<', '\0', } ;
static Char _srStringEqual1			[] = 	{ 's', 't', 'r', 'i', 'n', 'g', '=', '\0', } ;
static Char _srStringp				[] = 	{ 's', 't', 'r', 'i', 'n', 'g', 'p', '\0', } ;
static Char _srSubrp				[] = 	{ 's', 'u', 'b', 'r', 'p', '\0', } ;
static Char _srSubstring			[] = 	{ 's', 'u', 'b', 's', 't', 'r', 'i', 'n', 'g', '\0', } ;
static Char _srSymbolFunction		[] = 	{ 's', 'y', 'm', 'b', 'o', 'l', '-', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', '\0', } ;
static Char _srSymbolName			[] = 	{ 's', 'y', 'm', 'b', 'o', 'l', '-', 'n', 'a', 'm', 'e', '\0', } ;
static Char _srSymbolPlist			[] = 	{ 's', 'y', 'm', 'b', 'o', 'l', '-', 'p', 'l', 'i', 's', 't', '\0', } ;
static Char _srSymbolValue			[] = 	{ 's', 'y', 'm', 'b', 'o', 'l', '-', 'v', 'a', 'l', 'u', 'e', '\0', } ;
static Char _srSymbolp				[] = 	{ 's', 'y', 'm', 'b', 'o', 'l', 'p', '\0', } ;
static Char _srThrow				[] = 	{ 't', 'h', 'r', 'o', 'w', '\0', } ;
static Char _srTryCompletion		[] = 	{ 't', 'r', 'y', '-', 'c', 'o', 'm', 'p', 'l', 'e', 't', 'i', 'o', 'n', '\0', } ;
static Char _srUnintern				[] = 	{ 'u', 'n', 'i', 'n', 't', 'e', 'r', 'n', '\0', } ;
static Char _srUnwindProtect		[] = 	{ 'u', 'n', 'w', 'i', 'n', 'd', '-', 'p', 'r', 'o', 't', 'e', 'c', 't', '\0', } ;
static Char _srUpcase				[] = 	{ 'u', 'p', 'c', 'a', 's', 'e', '\0', } ;
static Char _srUseLocalMap			[] = 	{ 'u', 's', 'e', '-', 'l', 'o', 'c', 'a', 'l', '-', 'm', 'a', 'p', '\0', } ;
static Char _srVconcat				[] = 	{ 'v', 'c', 'o', 'n', 'c', 'a', 't', '\0', } ;
static Char _srVector				[] = 	{ 'v', 'e', 'c', 't', 'o', 'r', '\0', } ;
static Char _srVectorp				[] = 	{ 'v', 'e', 'c', 't', 'o', 'r', 'p', '\0', } ;
static Char _srWhile				[] = 	{ 'w', 'h', 'i', 'l', 'e', '\0', } ;
static Char _srWiden				[] = 	{ 'w', 'i', 'd', 'e', 'n', '\0', } ;
static Char _srYank					[] = 	{ 'y', 'a', 'n', 'k', '\0', } ;
static Char _srZerop				[] = 	{ 'z', 'e', 'r', 'o', 'p', '\0', } ;

static	Char	_srArgUpperP			[]	=	{ 'P', '\0' } ;
static	Char	_srArgLowerP			[]	=	{ 'p', '\0' } ;
static	Char	_srArgLowerR			[]	=	{ 'r', '\0' } ;
static	Char	_srArgLowerS			[]	=	{ 's', '\0' } ;
static	Char	_srArgGotoChar			[]	=	{ 'n', 'G', 'o', 't', 'o', ' ', 'c', 'h', 'a', 'r', ':', ' ', '\0' } ;
static	Char	_srArgSetKeyLocally	[]	=	{ 'K', 'S', 'e', 't', ' ', 'k', 'e', 'y', ' ', 'l', 'o', 'c', 'a', 'l', 'l', 'y', ':', ' ', '\n', 'C', 'S', 'e', 't', ' ', 'k', 'e', 'y', ' ', '%', 's', ' ', 'l', 'o', 'c', 'a', 'l', 'l', 'y', ' ', 't', 'o', ' ', 'c', 'o', 'm', 'm', 'a', 'n', 'd', ':', '\0' } ;
static	Char	_srArgMakeLocalVariable[]	=	{ 'v', 'M', 'a', 'k', 'e', ' ', 'L', 'o', 'c', 'a', 'l', ' ', 'V', 'a', 'r', 'i', 'a', 'b', 'l', 'e', ' ', ':', '\0' } ;
static	Char	_srArgMakeVariableBufferLocal []	= { 'v', 'M', 'a', 'k', 'e', ' ', 'V', 'a', 'r', 'i', 'a', 'b', 'l', 'e', ' ', 'B', 'u', 'f', 'f', 'e', 'r', ' ', 'L', 'o', 'c', 'a', 'l', ' ', ':', '\0' } ;
static	Char	_srArgNul				[]	=	{ '\0' } ;

/*	builtin function */
static	const LMCMDINFO	saLispMachineBuiltinCmds []	= {
	{	_srRemainder,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Remainder, },
	{	_srMultiply,				NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Multiply, },
	{	_srPlus,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Plus, },
	{	_srMinus,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Minus, },
	{	_srDivide,					NULL,
		LISPCMD_ARGTYPE_LOWER,		1,	1,	lispMachineState_Divide, },
	{	_srSlashEqual,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_SlashEqual, },
	{	_sr1Plus,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_1Plus, },
	{	_sr1Minus,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_1Minus, },
	{	_srMathLessThan,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_MathLessThan, },
	{	_srMathLessEqual,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_MathLessEqual, },
	{	_srMathEqual,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_MathEqual, },
	{	_srMathGreaterThan,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_MathGreaterThan, },
	{	_srMathGreaterEqual,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_MathGreaterEqual, },
	{	_srBackquote1,				NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Backquote, },
	{	_srAddHook,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	4,	lispMachineState_AddHook, },
	{	_srAnd,						NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_And, },
	{	_srAppend,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Append, },
	{	_srApply,					NULL,
		LISPCMD_ARGTYPE_LOWER,		1,	1,	lispMachineState_Apply, },
	{	_srAref,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Aref, },
	{	_srArrayp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Arrayp, },
	{	_srAset,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		3,	3,	lispMachineState_Aset, },
	{	_srAssoc,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Assoc, },
	{	_srAssq,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Assq, },
	{	_srBackquote,				NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Backquote, },
	{	_srBackwardChar,			_srArgUpperP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_BackwardChar, },
	{	_srBackwardDeleteChar,		_srArgLowerP,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_DeleteBackwardChar, },
	{	_srBeginningOfLine,			_srArgUpperP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_BeginningOfLine, },
	{	_srBobp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_Bobp, },
	{	_srBoundp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Boundp, },
	{	_srBufferModifiedp,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_BufferModifiedp, },
	{	_srBufferString,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_BufferString, },
	{	_srBufferSubstring,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_BufferSubstring, },
	{	_srByteCodeFunctionp,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_ByteCodeFunctionp, },
	{	_srCar,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Car, },
	{	_srCarSafe,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_CarSafe, },
	{	_srCatch,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Catch, },
	{	_srCdr,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Cdr, },
	{	_srCharAfter,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_CharAfter, },
	{	_srCharCharset,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_CharCharset, },
	{	_srCharToString,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_CharToString, },
	{	_srCommandExecute,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	4,	lispMachineState_CommandExecute, },
	{	_srCommandp,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Commandp, },
	{	_srConcat,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Concat, },
	{	_srCond,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Cond, },
	{	_srConditionCase,			NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_ConditionCase, },
	{	_srCons,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Cons, },
	{	_srConsp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Consp, },
	{	_srCopyKeymap,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_CopyKeymap, },
	{	_srCopyMarker,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_CopyMarker, },
	{	_srCountLines,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_CountLines, },
	{	_srCurrentBuffer,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_CurrentBuffer, },
	{	_srCurrentLocalMap,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_CurrentLocalMap, },
	{	_srCurrentMinorModeMaps,	NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_CurrentMinorModeMaps, },
	{	_srCurrentTimeString,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_CurrentTimeString, },
	{	_srDefaultValue,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_DefaultValue, },
	{	_srDefconst,				NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Defvar, },
	{	_srDefineKey,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		3,	3,	lispMachineState_DefineKey, },
	{	_srDefmacro,				NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Defmacro, },
	{	_srDefun,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Defun, },
	{	_srDefvar,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Defvar, },
	{	_srDelete,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Delete, },
	{	_srDeleteBackwardChar,		_srArgLowerP,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_DeleteBackwardChar, },
	{	_srDeleteChar,				_srArgLowerP,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_DeleteChar, },
	{	_srDeleteRegion,			_srArgLowerR,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_DeleteRegion, },
	{	_srDelq,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Delq, },
	{	_srDing,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_Ding, },
	{	_srDocumentation,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_Documentation, },
	{	_srDowncase,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Downcase, },
	{	_srEndOfLine,				_srArgUpperP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_EndOfLine, },
	{	_srEobp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_Eobp, },
	{	_srEolp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_Eolp, },
	{	_srEq,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Eq, },
	{	_srEqual,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Equal, },
	{	_srEraseBuffer,				_srArgNul,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_EraseBuffer, },
	{	_srError,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Error, },
	{	_srEval,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Eval },
	{	_srFboundp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Fboundp, },
	{	_srFeaturep,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Featurep, },
	{	_srFloatp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Floatp, },
	{	_srFmakunbound,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Fmakunbound, },
	{	_srFollowingChar,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_FollowingChar, },
	{	_srFormat,					NULL,
		LISPCMD_ARGTYPE_LOWER,		1,	0,	lispMachineState_Format, },
	{	_srForwardChar,				_srArgUpperP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_ForwardChar, },
	{	_srForwardLine,				_srArgUpperP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_ForwardLine, },
	{	_srForwardWord,				_srArgLowerP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_ForwardWord, },
	{	_srFset,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Fset, },
	{	_srFuncall,					NULL,
		LISPCMD_ARGTYPE_LOWER,		1,	1,	lispMachineState_Funcall, },
	{	_srFunction,				NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Quote, },
	{	_srFunctionp,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Functionp, },
	{	_srGenerateNewBuffer,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_GenerateNewBuffer, },
	{	_srGenerateNewBufferName,	NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_GenerateNewBufferName, },
	{	_srGet,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Get, },
	{	_srGetBuffer,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_GetBuffer, },
	{	_srGetBufferCreate,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_GetBufferCreate, },
	{	_srGetenv,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Getenv, },
	{	_srGotoChar,				_srArgGotoChar,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_GotoChar, },
	{	_srIdentity,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Identity, },
	{	_srIf,						NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_If, },
	{	_srInsert,					NULL,
		LISPCMD_ARGTYPE_LOWER,		0,	0,	lispMachineState_Insert, },
	{	_srInsertChar,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	3,	lispMachineState_InsertChar, },
	{	_srInsertFileContents,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	5,	lispMachineState_InsertFileContents, },
	{	_srIntToString,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_NumberToString, },
	{	_srIntegerOrMarkerp,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_IntegerOrMarkerp, },
	{	_srIntegerp,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Integerp, },
	{	_srInteractive,				NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Interactive, },
	{	_srInteractivep,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_Interactivep, },
	{	_srIntern,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_Intern, },
	{	_srInternSoft,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_InternSoft, },
#if 1
	{	_srJKeyBinding,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_JKeyBinding, },
#endif
	{	_srKeyBinding,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_KeyBinding, },
	{	_srKeymapp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Keymapp, },
	{	_srKillLine,				_srArgUpperP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_KillLine, },
	{	_srKillRegion,				_srArgLowerR,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_KillRegion, },
	{	_srLambda,					NULL,
		LISPCMD_ARGTYPE_SPECIAL,	1,	1,	lispMachineState_Lambda, },
	{	_srLength,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Length, },
	{	_srLet,						NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Let, },
	{	_srLetStar,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_LetStar, },
	{	_srReturnOnly,				NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_ReturnOnly, },
	{	_srListp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Listp, },
	{	_srLoad,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	5,	lispMachineState_Load, },
	{	_srLoadFile,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_LoadFile, },
	{	_srLocalSetKey,				_srArgSetKeyLocally,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_LocalSetKey, },
	{	_srLookupKey,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	3,	lispMachineState_LookupKey, },
	{	_srMakeCharacter,			NULL,
		LISPCMD_ARGTYPE_LOWER,		2,	0,	lispMachineState_MakeCharacter, },
	{	_srMakeKeymap,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_MakeKeymap, },
	{	_srMakeLocalHook,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MakeLocalHook, },
	{	_srMakeLocalVariable,		_srArgMakeLocalVariable,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MakeLocalVariable, },
	{	_srMakeMarker,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_MakeMarker, },
	{	_srMakeSparseKeymap,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_MakeSparseKeymap, },
	{	_srMakeString,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_MakeString, },
	{	_srMakeSymbol,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MakeSymbol, },
	{	_srMakeVariableBufferLocal,	_srMakeVariableBufferLocal,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MakeVariableBufferLocal, },
	{	_srMakunbound,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Makunbound, },
	{	_srMapcar,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Mapcar, },
	{	_srMapconcat,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		3,	3,	lispMachineState_Mapconcat, },
	{	_srMark,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_Mark, },
	{	_srMarkerBuffer,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MarkerBuffer, },
	{	_srMarkerInsertionType,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MarkerInsertionType, },
	{	_srMarkerPosition,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MarkerPosition, },
	{	_srMarkerp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Markerp, },
#if defined (USE_REGEX)
	{	_srMatchBeginning,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MatchBeginning, },
	{	_srMatchData,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	2,	lispMachineState_MatchData, },
	{	_srMatchEnd,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_MatchEnd, },
#endif
	{	_srMax,						NULL,
		LISPCMD_ARGTYPE_LOWER,		1,	0,	lispMachineState_Max, },
	{	_srMember,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Member, },
	{	_srMemq,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Memq, },
	{	_srMin,						NULL,
		LISPCMD_ARGTYPE_LOWER,		1,	0,	lispMachineState_Min, },
	{	_srMod,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Mod, },
	{	_srModifyAlist,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_ModifyAlist, },
	{	_srMoveMarker,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	3,	lispMachineState_SetMarker, },
	{	_srNarrowToRegion,			_srArgLowerR,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_NarrowToRegion, },
	{	_srNatnump,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Natnump, },
	{	_srNconc,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Nconc, },
	{	_srNot,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Null, },
	{	_srNreverse,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Nreverse, },
	{	_srNth,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Nth, },
	{	_srNthcdr,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Nthcdr, },
	{	_srNull,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Null, },
	{	_srNumberToString,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_NumberToString, },
	{	_srNumberp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Numberp, },
	{	_srOr,						NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Or, },
	{	_srPlistGet,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_PlistGet, },
	{	_srPlistPut,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		3,	3,	lispMachineState_PlistPut, },
	{	_srPoint,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_Point, },
	{	_srPointMarker,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_PointMarker, },
	{	_srPointMax,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_PointMax, },
	{	_srPointMin,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_PointMin, },
	{	_srPrecedingChar,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_PrecedingChar, },
	{	_srPrefixNumericValue,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_PrefixNumericValue, },
	{	_srPrinc,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Princ, },
	{	_srProg1,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Prog1, },
	{	_srProg2,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Prog2, },
	{	_srProgn,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Progn, },
	{	_srProvide,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Provide, },
	{	_srPut,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		3,	3,	lispMachineState_Put, },
	{	_srPutAlist,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		3,	3,	lispMachineState_PutAlist, },
	{	_srQueueAll,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_QueueAll, },
	{	_srQueueCreate,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_QueueCreate, },
	{	_srQueueEnqueue,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_QueueEnqueue, },
	{	_srQuote,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_Quote, },
	{	_srRassoc,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Rassoc, },
#if defined (USE_REGEX)
	{	_srReSearchBackward,		_srArgLowerS,
		LISPCMD_ARGTYPE_NORMAL,		1,	4,	lispMachineState_ReSearchBackward, },
	{	_srReSearchForward,			_srArgLowerS,
		LISPCMD_ARGTYPE_NORMAL,		1,	4,	lispMachineState_ReSearchForward, },
#endif
	{	_srReadFromString,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	3,	lispMachineState_ReadFromString, },
#if defined (USE_REGEX)
	{	_srRegexpQuote,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_RegexpQuote, },
#endif
	{	_srRplaca,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Setcar, },
	{	_srRunHooks,				NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_RunHooks, },
	{	_srSaveCurrentBuffer,		NULL,
		LISPCMD_ARGTYPE_CDR,		0,	0,	lispMachineState_SaveCurrentBuffer, },
	{	_srSaveExcursion,			NULL,
		LISPCMD_ARGTYPE_CDR,		0,	0,	lispMachineState_SaveExcursion, },
	{	_srSaveRestriction,			NULL,
		LISPCMD_ARGTYPE_CDR,		0,	0,	lispMachineState_SaveRestriction, },
#if defined (USE_REGEX)
	{	_srSearchBackward,			_srArgLowerS,
		LISPCMD_ARGTYPE_NORMAL,		1,	4, 	lispMachineState_SearchBackward, },
	{	_srSearchForward,			_srArgLowerS,
		LISPCMD_ARGTYPE_NORMAL,		1,	4, 	lispMachineState_SearchForward, },
#endif
	{	_srSelfInsertCommand,		_srArgLowerP,
		LISPCMD_ARGTYPE_NORMAL,		1, 1,	lispMachineState_SelfInsertCommand, },
	{	_srSequencep ,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Sequencep },
	{	_srSet,						NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Set, },
	{	_srSetBuffer,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SetBuffer, },
	{	_srSetBufferModifiedp,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SetBufferModifiedp, },
	{	_srSetMark,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SetMark, },
	{	_srSetMarker,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	3,	lispMachineState_SetMarker, },
#if defined (USE_REGEX)
	{	_srSetMatchData,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SetMatchData, },
#endif
	{	_srSetModifiedAlist,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_SetModifiedAlist, },
	{	_srSetcar,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Setcar, },
	{	_srSetcdr,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Setcdr, },
	{	_srSetplist,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Setplist, },
	{	_srSetq,					NULL,
		LISPCMD_ARGTYPE_CDR,		2,	2,	lispMachineState_Setq, },
	{	_srSetqDefault,				NULL,
		LISPCMD_ARGTYPE_CDR,		2,	2,	lispMachineState_SetqDefault, },
	{	_srSignal,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Signal, },
	{	_srString,					NULL,
		LISPCMD_ARGTYPE_LOWER,		1,	1,	lispMachineState_String, },
	{	_srStringEqual,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_StringEqual, },
	{	_srStringLessp,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_StringLessp, },
#if defined (USE_REGEX)
	{	_srStringMatch,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	3,	lispMachineState_StringMatch, },
#endif
	{	_srStringToChar,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_StringToChar, },
	{	_srStringToCharList,		NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_StringToCharList, },
	{	_srStringToInt,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_StringToNumber, },
	{	_srStringToIntList,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_StringToCharList, },
	{	_srStringToNumber,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_StringToNumber, },
	{	_srStringLessp1,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_StringLessp, },
	{	_srStringEqual1,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_StringEqual, },
	{	_srStringp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Stringp, },
	{	_srSubrp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Subrp, },
	{	_srSubstring,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	3,	lispMachineState_Substring, },
	{	_srSymbolFunction,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SymbolFunction, },
	{	_srSymbolName,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SymbolName, },
	{	_srSymbolPlist,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SymbolPlist, },
	{	_srSymbolValue,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_SymbolValue, },
	{	_srSymbolp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Symbolp, },
	{	_srThrow,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	2,	lispMachineState_Throw, },
	{	_srTryCompletion,			NULL,
		LISPCMD_ARGTYPE_NORMAL,		2,	3,	lispMachineState_TryCompletion, },
	{	_srUnintern,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	2,	lispMachineState_Unintern, },
	{	_srUnwindProtect,			NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_UnwindProtect, },
	{	_srUpcase,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Upcase, },
	{	_srUseLocalMap,				NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_UseLocalMap, },
	{	_srVconcat,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Vconcat, },
	{	_srVector,					NULL,
		LISPCMD_ARGTYPE_NOBOUND,	0,	0,	lispMachineState_Vector, },
	{	_srVectorp,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Vectorp, },
	{	_srWhile,					NULL,
		LISPCMD_ARGTYPE_CDR,		1,	1,	lispMachineState_While, },
	{	_srWiden,					_srArgNul,
		LISPCMD_ARGTYPE_NORMAL,		0,	0,	lispMachineState_Widen, },
	{	_srYank,					_srArgUpperP,
		LISPCMD_ARGTYPE_NORMAL,		0,	1,	lispMachineState_Yank, },
	{	_srZerop,					NULL,
		LISPCMD_ARGTYPE_NORMAL,		1,	1,	lispMachineState_Zerop, },
	{	NULL,						NULL,
		LISPCMD_ARGTYPE_LAMBDA,		1,	1,	lispMachineState_EvalLambdaForm, },
	{	NULL,						NULL,
		LISPCMD_ARGTYPE_MACRO,		1,	1,	lispMachineState_EvalMacro, },
} ;

/*	subroutine entities */
static	TLispEntity*	sapEntSubrTable [ARRAYSIZE (saLispMachineBuiltinCmds)] = {
	NULL,
} ;


BOOL
lispMachine_SearchBuiltinFunction (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pTarget,
	register LMCMDINFO const**	ppCmdInfo)
{
	int				iType ;
	const Char*		pName ;
	TLispEntity*	pCar ;
	int				nName ;

	assert (pLispMgr     != NULL) ;
	assert (pTarget      != NULL) ;
	assert (ppCmdInfo    != NULL) ;
	
	if (TFAILED (lispEntity_GetType (pLispMgr, pTarget, &iType)))
		return	FALSE ;
	
	switch (iType) {
	case	LISPENTITY_SYMBOL:
		lispEntity_GetSymbolName (pLispMgr, pTarget, &pName, &nName) ;
		return	lispMachine_bsearchCommandInfo (pName, nName, ppCmdInfo) ;

	case	LISPENTITY_CONSCELL:
		if (TFAILED (lispEntity_GetCar (pLispMgr, pTarget, &pCar)))
			break ;
		if (TSUCCEEDED (lispEntity_Lambdap (pLispMgr, pCar))) {
			*ppCmdInfo	= &saLispMachineBuiltinCmds [LM_INDEX_LAMBDA] ;
		} else if (TSUCCEEDED (lispEntity_Macrop (pLispMgr, pCar))) {
			*ppCmdInfo	= &saLispMachineBuiltinCmds [LM_INDEX_MACRO] ;
		} else {
			break ;
		}
		return	TRUE ;
		
	default:
		return	FALSE ;
	}
	return	FALSE ;
}

BOOL	lispMachine_GetSubr (
	register LMCMDINFO const*	pCmdInfo, 
	register TLispEntity**		ppEntReturn)
{
	register int	nIndex ;

	assert (pCmdInfo    != NULL) ;
	assert (ppEntReturn != NULL) ;

	nIndex	= pCmdInfo - saLispMachineBuiltinCmds ;
	if (nIndex < 0 || nIndex >= ARRAYSIZE (saLispMachineBuiltinCmds))
		return	FALSE ;
	*ppEntReturn	= sapEntSubrTable [nIndex] ;
	return	TRUE ;
}


BOOL	lispMachine_RegisterSubr (
	register LMCMDINFO const*	pCmdInfo,
	register TLispEntity*		pEntity)
{
	register int	nIndex ;

	assert (pCmdInfo != NULL) ;
	assert (pEntity  != NULL) ;

	nIndex	= pCmdInfo - saLispMachineBuiltinCmds ;
	if (nIndex < 0 || nIndex >= ARRAYSIZE (saLispMachineBuiltinCmds))
		return	FALSE ;
	assert (sapEntSubrTable [nIndex] == NULL) ;
	sapEntSubrTable [nIndex]	= pEntity ;
	return	TRUE ;
}

/*	private functions */
BOOL
lispMachine_bsearchCommandInfo (
	register const Char*		pName,
	register int				nName,
	register LMCMDINFO const**	ppCmdInfo)
{
	register LMCMDINFO const*	pTarget ;
	register const Char*		pLeft ;
	register const Char*		pRight ;
	register int				nTop, nBottom, nTarget, nDiff, nLen ;
	
	assert (pName != NULL) ;

	nTop	= 0 ;
	nBottom	= LM_NUM_FUNCTION - 1 ;
	while (nTop <= nBottom) {
		nTarget	= (nTop + nBottom) / 2 ;
		pTarget	= &saLispMachineBuiltinCmds [nTarget] ;

		pLeft	= pName ;
		pRight	= pTarget->m_pName ;
		nLen	= nName ;
		nDiff	= 0 ;
		while (nLen > 0 && *pRight != '\0') {
			nDiff	= (*pLeft - *pRight) ;
			if (nDiff != 0)
				break ;
			pLeft	++ ;
			pRight	++ ;
			nLen	-- ;
		}
		if (nDiff > 0 || (nDiff == 0 && nLen > 0)) {
			nTop	= nTarget + 1 ;
		} else if (nDiff < 0 || (nDiff == 0 && nLen == 0 && *pRight != '\0')) {
			nBottom	= nTarget - 1 ;
		} else {
			/*	found */
			*ppCmdInfo	= pTarget ;
			return	TRUE ;
		}
	}
	return	FALSE ;
}

