/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "lmachinep.h"
/*
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"
#include "lmstate.h"
*/

static	BOOL	lispMachine_makeLocalHook (TLispMachine*, TLispEntity*, TLispEntity*) ;

TLMRESULT
lispMachineState_Nth (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pArglist ;
	TLispEntity*	pN ;
	TLispEntity*	pList ;
	TLispEntity*	pRetval ;
	long			lN ;
	
	pLispMgr	= pLM->m_pLispMgr ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pArglist, &pN)) ||
		TFAILED (lispEntity_GetCadr (pLispMgr, pArglist, &pList)) ||
		TFAILED (lispEntity_GetIntegerValue (pLispMgr, pN, &lN)) ||
		TFAILED (lispEntity_Listp    (pLispMgr, pList))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	while (lN > 0 && TFAILED (lispEntity_Nullp (pLispMgr, pList))) {
		lispEntity_GetCdr (pLispMgr, pList, &pList) ;
		lN	-- ;
	}
	lispEntity_GetCar (pLispMgr, pList, &pRetval) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pRetval) ;
	return	LMR_RETURN ;
}

/*
 *	(local-set-key KEY COMMAND)
 *
 *	interactive function:
 *	"KSet key locally: \nCSet key %s locally to command: "
 *
  (let ((map (current-local-map)))
    (or map
	(use-local-map (setq map (make-sparse-keymap))))
    (or (vectorp key) (stringp key)
	(signal 'wrong-type-argument (list 'arrayp key)))
    (define-key map key command)))
 */
TLMRESULT
lispMachineState_LocalSetKey (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntCurBuffer ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntKey ;
	TLispEntity*	pEntCommand ;
	TLispEntity*	pEntKeymap ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	assert (pEntArglist != NULL) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntKey)) ||
		TFAILED (lispEntity_GetCdr  (pLispMgr, pEntArglist, &pEntArglist)) ||
		TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntCommand))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntCurBuffer))) {
#if defined (DEBUG) || defined (_DEBUG)
		fprintf (stderr, "current buffer doesn't exist.\n") ;
#endif
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	(void) lispBuffer_GetKeymap (pEntCurBuffer, &pEntKeymap) ;
	if (pEntKeymap == NULL ||
		TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntKeymap))) {
		if (TFAILED (lispMgr_CreateSparseKeymap (pLispMgr, NULL, &pEntKeymap)))
			return	LMR_ERROR ;
		lispBuffer_SetKeymap (pLispMgr, pEntCurBuffer, pEntKeymap) ;
#if defined (DEBUG) || defined (_DEBUG)
		fprintf (stderr, "set current buffer keymap.\n") ;
#endif
	}
	if (TSUCCEEDED (lispEntity_Vectorp (pLispMgr, pEntKey))) {
		TLispEntity**	ppEntKeySeq ;
		int				nKeySeq ;

		(void) lispEntity_GetVectorValue (pLispMgr, pEntKey, &ppEntKeySeq, &nKeySeq) ;
		if (TFAILED (lispKeymap_DefineKeyWithVector (pLispMgr, pEntKeymap, ppEntKeySeq, nKeySeq, pEntCommand)))
			lispMachineCode_SetError (pLM) ;
	} else if (TSUCCEEDED (lispEntity_Stringp (pLispMgr, pEntKey))) {
		const Char*		pString ;
		int				nString ;

		(void) lispEntity_GetStringValue (pLispMgr, pEntKey, &pString, &nString) ;
		if (TFAILED (lispKeymap_DefineKey (pLispMgr, pEntKeymap, pString, nString, pEntCommand))) 
			lispMachineCode_SetError (pLM) ;
	} else {
		register TLispEntity*	pEntSignal ;
		TLispEntity*	pEntSigValue ;

		pEntSignal	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_WRONG_TYPE_ARGUMENT) ;
		/*	�����B�{���� nil ����Ȃ��񂾂��c�B*/
		lispMgr_CreateNil (pLispMgr, &pEntSigValue) ;
		lispMachineCode_SetSignal (pLM, pEntSignal, pEntSigValue) ;
	}
	return	LMR_RETURN ;
}

TLMRESULT
lispMachineState_Functionp (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*			pEntArglist ;
	TLispEntity*			pEntObject ;
	TLispEntity*			pFunc ;
	TLispEntity*			pEntRetval ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	assert (pEntArglist != NULL) ;
	lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntObject) ;

	/*	���[�U��`�֐��ɂȂ������ׂ�B*/
	if (TSUCCEEDED (lispMachine_GetSymbolFunctionValue (pLM, pEntObject, &pFunc))) {
		lispMgr_CreateT   (pLispMgr, &pEntRetval) ;
	} else {
		lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*
 *	(error &rest ARGS)
 *
 *	`subr' ���Œ�`����Ă��� Lisp �֐��ł���B�G���[�� Signal ���āA
 *	�G���[���b�Z�[�W�� `format' �Ɉ�����S�ēn�����ƂŐ�������B
 *	���̂Ƃ���A�G���[���b�Z�[�W�͉����\������Ȃ��B���R�� `format'
 *	������ĂȂ�����B
 */
TLMRESULT
lispMachineState_Error (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntError ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntFormat ;
	TLispEntity*	pEntObjects ;
	TLispEntity*	pEntRetval ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntFormat) ;
	lispEntity_GetCdr (pLispMgr, pEntArglist, &pEntObjects) ;
	if (TFAILED (lispEntity_Nullp (pLispMgr, pEntFormat))) {
		const Char*	pStrFormat ;
		int			nStrFormat ;
		if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntFormat, &pStrFormat, &nStrFormat))) {
			lispMachineCode_SetError (pLM) ;
			return	LMR_RETURN ;
		}
		lispEntity_Format (pLispMgr, pStrFormat, nStrFormat, pEntObjects, &pEntRetval) ;
	} else {
		lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
#if defined (DEBUG) || defined (_DEBUG)
	fprintf (stderr, "error = ") ;
	lispEntity_Print (pLispMgr, pEntRetval) ;
	fprintf (stderr, "\n") ;
#endif
	pEntError	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_ERROR) ;
	lispMachineCode_SetSignal (pLM, pEntError, pEntRetval) ;
	return	LMR_RETURN ;
}

/*
 *	(make-local-hook HOOK)
 *
 *	�J�����g�o�b�t�@�ɑ΂��� hook HOOK �����[�J���ɍ쐬����B�Ԃ�l��
 *	HOOK �ł���B
 */
TLMRESULT
lispMachineState_MakeLocalHook (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntHook ;
	TLispEntity*	pEntBuffer ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	assert (pEntArglist != NULL) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntHook)) ||
		TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispMachine_makeLocalHook (pLM, pEntBuffer, pEntHook))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntHook) ;
	return	LMR_RETURN ;
}

/*
 *	(add-hook HOOK FUNCTION &optional APPEND LOCAL)
 *
 *	HOOK �̒l�� function FUNCTION ��ǉ�����B���� FUNCTION ��
 *	���ɑ��݂��Ă�����ǉ��͂���Ȃ��Boptional ������ APPEND ��
 *	nil �łȂ���΁AFUNCTION �� hook list �̐擪�ɒǉ������B
 *	FUNCTION is added (if necessary) at the beginning of the hook list
 *	unless the optional argument APPEND is non-nil, in which case
 *	FUNCTION is added at the end.
 *	
 *	The optional fourth argument, LOCAL, if non-nil, says to modify
 *	the hook's buffer-local value rather than its default value.
 *	This makes the hook buffer-local if needed.
 *	To make a hook variable buffer-local, always use
 *	`make-local-hook', not `make-local-variable'.
 *	
 *	HOOK should be a symbol, and FUNCTION may be any valid function.  If
 *	HOOK is void, it is first set to nil.  If HOOK's value is a single
 *	function, it is changed to a list of functions.
 */
TLMRESULT
lispMachineState_AddHook (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntHook ;
	TLispEntity*	pEntValue ;
	TLispEntity*	pEntGlobalValue ;
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntFunction ;
	TLispEntity*	pEntAppend ;
	TLispEntity*	pEntLocal ;
	TLispEntity*	pEntBuffer ;
	register TLispEntity*	pEntNil ;
	register TLispEntity*	pEntT ;
	TLispEntity*	pEntRetval ;
	BOOL			fAlreadyHave ;
	BOOL			fLocal ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	if (TFAILED (lispEntity_GetCar (pLispMgr, pEntArglist, &pEntHook)) ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pEntArglist, &pEntArglist)) ||
		TFAILED (lispEntity_GetCar (pLispMgr, pEntArglist, &pEntFunction)) ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pEntArglist, &pEntArglist)) ||
		TFAILED (lispEntity_GetCar (pLispMgr, pEntArglist, &pEntAppend)) ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pEntArglist, &pEntArglist)) ||
		TFAILED (lispEntity_GetCar (pLispMgr, pEntArglist, &pEntLocal)) ||
		TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	pEntNil	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_NIL) ;
	pEntT	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_T) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntHook, &pEntValue)) ||
		TSUCCEEDED (lispEntity_Voidp (pLispMgr, pEntValue))) {
		if (TFAILED (lispMachine_SetCurrentSymbolValue (pLM, pEntHook, pEntNil)))
			return	LMR_ERROR ;
		pEntValue	= pEntNil ;
	}
	if (TFAILED (lispMachine_GetGlobalSymbolValue (pLM, pEntHook, &pEntGlobalValue)) ||
		TSUCCEEDED (lispEntity_Voidp (pLispMgr, pEntGlobalValue))) {
		if (TFAILED (lispMachine_SetGlobalSymbolValue (pLM, pEntHook, pEntNil)))
			return	LMR_ERROR ;
		pEntGlobalValue	= pEntNil ;
	}
	if (TFAILED (lispEntity_Listp (pLispMgr, pEntValue)) ||
		(TSUCCEEDED (lispEntity_GetCar (pLispMgr, pEntValue, &pEntCar)) &&
		 TSUCCEEDED (lispEntity_Lambdap (pLispMgr, pEntCar)))) {
		TLispEntity*	pEntTemp ;
		if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntValue, pEntNil, &pEntTemp)))
			return	LMR_ERROR ;
		lispMachine_SetCurrentSymbolValue (pLM, pEntHook, pEntTemp) ;
		pEntValue	= pEntTemp ;
	}
	if (TFAILED (lispEntity_Nullp (pLispMgr, pEntLocal)) ||
		(TSUCCEEDED (lispMachine_LocalVariableIfSetp (pLM, pEntHook)) &&
		 TFAILED (lispEntity_Memq (pLispMgr, pEntT, pEntValue, &pEntRetval)))) {
		pEntValue	= pEntValue ;
		fLocal		= TRUE ;
	} else {
		pEntValue	= pEntGlobalValue ;
		fLocal		= FALSE ;
	}
	if (TFAILED (lispEntity_Consp (pLispMgr, pEntValue))) {
		if (TFAILED (lispEntity_Member (pLispMgr, pEntFunction, pEntValue, &pEntRetval)))
			goto	error_exit ;
		fAlreadyHave	= TFAILED (lispEntity_Nullp (pLispMgr, pEntRetval)) ;
	} else {
		if (TFAILED (lispEntity_Memq (pLispMgr, pEntFunction, pEntValue, &pEntRetval)))
			goto	error_exit ;
		fAlreadyHave	= TFAILED (lispEntity_Nullp (pLispMgr, pEntRetval)) ;
	}

	lispEntity_AddRef (pLispMgr, pEntValue) ;
	if (TFAILED (fAlreadyHave)) {
		TLispEntity*	pEntNewValue ;

		if (TFAILED (lispEntity_Nullp (pLispMgr, pEntAppend))) {
			TLispEntity*	pEntTemp ;
			TLispEntity*	pEntSequence ;
			TLispEntity*	apEntTbl [2] ;

			/*	pEntTemp <- (function . nil)
			 */
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntFunction, pEntNil, &pEntTemp)))
				return	LMR_ERROR ;
			lispEntity_AddRef  (pLispMgr, pEntTemp) ;
			/*	pEntSequence <- (value function)
			 */
			apEntTbl [0]	= pEntValue ;
			apEntTbl [1]	= pEntTemp ;
			if (TFAILED (lispMgr_CreateList     (pLispMgr, apEntTbl, 2, &pEntSequence)))
				return	LMR_ERROR ;
			lispEntity_AddRef  (pLispMgr, pEntSequence) ;
			lispEntity_Release (pLispMgr, pEntTemp) ;
			lispMgr_Append (pLispMgr, pEntSequence, &pEntNewValue) ;
			lispEntity_Release (pLispMgr, pEntSequence) ;
		} else {
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntFunction, pEntValue, &pEntNewValue)))
				return	LMR_ERROR ;
		}
		lispEntity_AddRef  (pLispMgr, pEntNewValue) ;
		lispEntity_Release (pLispMgr, pEntValue) ;
		pEntValue	= pEntNewValue ;
	}
	if (fLocal) {
		if (TFAILED (lispMachine_SetCurrentSymbolValue (pLM, pEntHook, pEntValue))) 
			goto	error_exit ;
	} else {
		if (TFAILED (lispMachine_SetGlobalSymbolValue (pLM, pEntHook, pEntValue))) 
			goto	error_exit ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntValue) ;
	lispEntity_Release (pLispMgr, pEntValue) ;
	return	LMR_RETURN ;

  error_exit:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

BOOL
lispMachine_makeLocalHook (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntBuffer,
	register TLispEntity*	pEntHook)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntT ;
	TLispEntity*	pEntNil ;
	TLispEntity*	pEntValue	= NULL ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;

	lispMgr_CreateNil (pLispMgr, &pEntNil) ;
	if (TFAILED (lispMachine_GetCurrentBufferLocalSymbolValue (pLM, pEntHook, &pEntValue)) ||
		pEntValue == NULL) {
		if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntHook, &pEntValue)) ||
			TSUCCEEDED (lispEntity_Voidp (pLispMgr, pEntValue))) 
			lispMachine_SetCurrentSymbolValue (pLM, pEntHook, pEntNil) ;

		if (TFAILED (lispBuffer_MakeSymbolValue (pLispMgr, pEntBuffer, pEntHook)) ||
			TFAILED (lispMgr_CreateT (pLispMgr, &pEntT)) ||
			TFAILED (lispMgr_CreateConscell (pLispMgr, pEntT, pEntNil, &pEntValue)))
			return	FALSE ;
		lispBuffer_SetSymbolValue (pLispMgr, pEntBuffer, pEntHook, pEntValue) ;
	}
	return	TRUE ;
}

/*
 *	This function does not work well.
 */
TLMRESULT
lispMachineState_Documentation (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntRetval ;

	lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

