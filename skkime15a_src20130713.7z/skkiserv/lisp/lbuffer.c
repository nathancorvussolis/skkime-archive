/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "lmachinep.h"
/*
#include "local.h"
#include <stdio.h>
#include "lispmgrp.h"
#include "cstring.h"
#include "kanji.h"
*/

#define	lispEntity_GetBufferPtr(ptr)	((TLispBuffer *)((TLispEntity *)(ptr) + 1))

static	BOOL			lispBuffer_initialize	(TLispManager*, TLispEntity*) ;
static	BOOL			lispBuffer_uninitialize (TLispManager*, TLispEntity*) ;
static	TLispEntity*	lispBuffer_getMarker	(TLispEntity*, int) ;
static	BOOL			lispBuffer_getMarkerPosition (TLispManager*, TLispEntity*, int, int*) ;

/*	buffer entity ���쐬����B
 */
BOOL
lispMgr_CreateBuffer (
	register TLispManager*			pLispMgr,
	register TLispEntity** const	ppEntityRet)
{
	TLispEntity*			pEntity ;
	register TLispBuffer*	pBuffer ;
	register int			i ;
	TLispEntity**			ppEntSymbol ;
	int						nEntSymbol ;
	TLispEntity*			pEntEmpty ;

	ASSERT (pLispMgr    != NULL) ;
	ASSERT (ppEntityRet != NULL) ;

#if defined (DEBUG_LV99)
	fprintf (stderr, "Garbage collecting ...") ;
	fflush (stderr) ;
	lispMgr_CollectGarbage (pLispMgr) ;
	fprintf (stderr, "done.\n") ;
#endif
	/*	�G���e�B�e�B�Ƃ��ĕK�v�ȃ������̈���m�ۂ���B*/
	if (TFAILED (lispMgr_AllocateEntity (pLispMgr, sizeof (TLispBuffer), &pEntity))) 
		return	FALSE ;

	/*	�G���e�B�e�B�Ƃ��ď���������B*/
	pEntity->m_iType	= LISPENTITY_BUFFER ;
	pBuffer				= lispEntity_GetBufferPtr (pEntity) ;

	/*	�o�b�t�@���[�J���̃V���{���͂Ȃ��B*/
	for (i = 0 ; i < SIZE_LISP_BIND_TABLE ; i ++) {
		pBuffer->m_apVariableTable [i]	= NULL ;
	}
	/*	�����O���X�g�ɂȂ��Ă���B*/
	pBuffer->m_pNextBuffer		= pEntity ;
	pBuffer->m_pPrevBuffer		= pEntity ;
	pBuffer->m_pEntKeymap		= NULL ;
	pBuffer->m_pEntName			= NULL ;
	pBuffer->m_fModified		= FALSE ;
	pBuffer->m_nTick			= 0 ;
	
	/*	�o�b�t�@�ɂ͈�؂̃}�[�J���Ȃ���Ă��Ȃ��B*/
	pBuffer->m_lstMarkers		= NULL ;
	for (i = 0 ; i < NUM_BUFFER_MUST_MARKERS ; i ++) 
		pBuffer->m_apMustMarkers [i]	= NULL ;

	/*	�G���e�B�e�B���X�g�ɂȂ��B*/
	(void) lispMgr_RegisterMisc (pLispMgr, pEntity) ;

	/*	�o�b�t�@������������B*/
	if (TFAILED (lispBuffer_initialize (pLispMgr, pEntity))) {
		lispMgr_DestroyEntity (pLispMgr, pEntity) ;
		return	FALSE ;
	}

	/*	�f�t�H���g�̃��[�J���ϐ����쐬����B�l�͂Ȃ��B*/
	(void) lispMgr_GetLocalSymbols (pLispMgr, &ppEntSymbol, &nEntSymbol) ;
	(void) lispMgr_CreateEmpty (pLispMgr, &pEntEmpty) ;
	while (nEntSymbol -- > 0) {
#if defined (DEBUG)
		fprintf (stderr, "Symbol(") ;
		lispEntity_Print (pLispMgr, *ppEntSymbol) ;
		fprintf (stderr, ") <-- nil\n") ;
#endif
		lispBuffer_MakeSymbolValue (pLispMgr, pEntity, *ppEntSymbol) ;
		lispBuffer_SetSymbolValue  (pLispMgr, pEntity, *ppEntSymbol, pEntEmpty) ;
		ppEntSymbol	++ ;
	}

	*ppEntityRet	= pEntity ;
	return	TRUE ;
}

void
lispMgr_DestroyBuffer (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pEntBuffer     != NULL) ;
#if defined (DEBUG)
	fprintf (stderr, "lispMgr_DestroyBuffer (%p, %p)\n", pLispMgr, pEntBuffer) ;
#endif
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (pBuffer->m_pEntKeymap != NULL)
		lispEntity_Release (pLispMgr, pBuffer->m_pEntKeymap) ;
	pBuffer->m_pEntKeymap	= NULL ;

	/*	�}�[�J��������Ă����K�v������B*/
	lispBuffer_uninitialize (pLispMgr, pEntBuffer) ;
	return ;
}

/*
 *[�@�\]
 *	�o�b�t�@��������Ԃɖ߂��B���Ȃ킿�c
 *	�o�b�t�@�ŕҏW����Ă���������S�ď������A�o�b�t�@���[�J����
 *	�ϐ���S�ĉ�����A�}�[�J��������Ԃɖ߂��B
 */
BOOL
lispBuffer_Clear (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer)
{
	if (TFAILED (lispBuffer_uninitialize (pLispMgr, pEntBuffer)) ||
		TFAILED (lispBuffer_initialize   (pLispMgr, pEntBuffer)))
		return	FALSE ;
	return	TRUE ;
}

BOOL
lispBuffer_SetNext (
	register TLispEntity* pEntBuffer,
	register TLispEntity* pEntNextBuffer)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	ASSERT ((pEntNextBuffer != NULL &&
			 pEntNextBuffer->m_iType == LISPENTITY_BUFFER) ||
			(pEntNextBuffer == NULL)) ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	pBuffer->m_pNextBuffer	= pEntNextBuffer ;
	return	TRUE ;
}

BOOL
lispBuffer_GetNext (
	register TLispEntity*			pEntBuffer,
	register TLispEntity** const	ppReturn)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	ASSERT (ppReturn != NULL) ;

	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	*ppReturn	= pBuffer->m_pNextBuffer ;
	return	TRUE ;
}

BOOL
lispBuffer_SetPrevious (
	register TLispEntity*	pEntBuffer,
	register TLispEntity*	pEntPrevBuffer)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	ASSERT ((pEntPrevBuffer != NULL &&
			 pEntPrevBuffer->m_iType == LISPENTITY_BUFFER) ||
			(pEntPrevBuffer == NULL)) ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	pBuffer->m_pPrevBuffer	= pEntPrevBuffer ;
	return	TRUE ;
}

BOOL
lispBuffer_GetPrevious (
	register TLispEntity*			pEntBuffer,
	register TLispEntity** const	ppReturn)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	ASSERT (ppReturn != NULL) ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	*ppReturn	= pBuffer->m_pPrevBuffer ;
	return	TRUE ;
}

BOOL
lispBuffer_MakeSymbolValue (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register TLispEntity*	pSymbol)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pLispMgr != NULL) ;
	ASSERT (pEntBuffer  != NULL) ;
	ASSERT (pSymbol  != NULL) ;
	
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;

	return	lispBindTable_MakeEntry (pLispMgr, pBuffer->m_apVariableTable, ARRAYSIZE (pBuffer->m_apVariableTable), pSymbol, NULL) ;
}

/*
 *	����ɃV���{�������킯�ɂ͂����Ȃ��c�B
 */
BOOL
lispBuffer_SetSymbolValue (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register TLispEntity*	pSymbol,
	register TLispEntity*	pValue)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pSymbol    != NULL) ;
	/*ASSERT (hValue  != NULL) ;*/

	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;

	return	lispBindTable_SetEntryValue (pLispMgr, pBuffer->m_apVariableTable, ARRAYSIZE (pBuffer->m_apVariableTable), pSymbol, pValue) ;
}

BOOL
lispBuffer_SetSymbolValueWithName (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register const Char*	pName,
	register const int		nName,
	register TLispEntity*	pValue)
{
	register TLispBuffer*	pBuffer ;
	TLispEntity*	pEntSymbol ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pName != NULL && nName > 0) ;
	/*ASSERT (hValue  != NULL) ;*/

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;

	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;

	return	lispBindTable_SetEntryValue (pLispMgr, pBuffer->m_apVariableTable, ARRAYSIZE (pBuffer->m_apVariableTable), pEntSymbol, pValue) ;
}

BOOL
lispBuffer_GetSymbolValue (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntBuffer,
	register TLispEntity*			pSymbol,
	register TLispEntity** const	ppReturn)
{
	register TLispBuffer*	pBuffer ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pSymbol    != NULL) ;
	/*ASSERT (hValue  != NULL) ;*/

	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	return	lispBindTable_GetEntryValue (pLispMgr, pBuffer->m_apVariableTable, ARRAYSIZE (pBuffer->m_apVariableTable), pSymbol, ppReturn) ;
}

BOOL
lispBuffer_GetSymbolValueWithName (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntBuffer,
	register const Char*			pName,
	register const int				nName,
	register TLispEntity** const	ppReturn)
{
	register TLispBuffer*	pBuffer ;
	TLispEntity*	pEntSymbol ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pName != NULL && nName > 0) ;
	/*ASSERT (hValue  != NULL) ;*/

	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	return	lispBindTable_GetEntryValue (pLispMgr, pBuffer->m_apVariableTable, ARRAYSIZE (pBuffer->m_apVariableTable), pEntSymbol, ppReturn) ;
}


/*
 *	�}�[�J���o�b�t�@�̊Ǘ����ɒu���B���̗��R�́A�o�b�t�@��j��������
 *	���̃o�b�t�@���w��������}�[�J�����݂���̂͂܂�������B
 *	���̃o�b�t�@���w���Ă����}�[�J�͔j�������悤�ɂ��Ȃ��Ƃ����Ȃ�
 *	�̂ł͂Ȃ��낤���A�ƁB
 *	���ƁA���̃o�b�t�@�ɑ����Ă����}�[�J�͑}���Ƃ��̑���ňړ����Ȃ�
 *	�Ƃ����Ȃ�����B
 */
BOOL
lispBuffer_AddMarker (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register TLispEntity*	pEntMarker)
{
	TLispEntity*	pEntPrevBuffer ;
	register TLispBuffer*	pBuffer ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntMarker != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;

	/*	�}�[�J�Ƃ��Ă̓����𔲂��o���B*/
	if (TFAILED (lispMarker_GetBufferPosition (pLispMgr, pEntMarker, &pEntPrevBuffer, NULL))) {
#if defined (DEBUG)
		fprintf (stderr, "[buffer] This marker has no buffer.\n") ;
#endif
		return	FALSE ;
	}

	/*	���ɂ��̃o�b�t�@�ɂȂ���Ă����ꍇ�ɂ͖��Ȃ��B*/
	if (pEntPrevBuffer == pEntBuffer) {
#if defined (DEBUG)
		fprintf (stderr, "[buffer] This marker has already been inserted.\n") ;
#endif
		return	TRUE ;
	}
	if (pEntPrevBuffer != NULL) 
		lispBuffer_RemoveMarker (pLispMgr, pEntMarker) ;
	/*	�}�[�J�̃o�b�t�@�ƈʒu��ύX����B*/
	lispMarker_SetBufferPosition (pLispMgr, pEntMarker, pEntBuffer, 1) ;
	
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	/*	�o�b�t�@�̃}�[�J�����N���Ȃ������B*/
	if (pBuffer->m_lstMarkers == NULL) {
		pBuffer->m_lstMarkers	= pEntMarker ;
		lispMarker_SetNext (pLispMgr, pEntMarker, NULL) ;
	} else {
		lispMarker_SetPrevious (pLispMgr, pBuffer->m_lstMarkers, pEntMarker) ;
		lispMarker_SetNext (pLispMgr, pEntMarker, pBuffer->m_lstMarkers) ;
		pBuffer->m_lstMarkers	= pEntMarker ;
	}
	lispMarker_SetPrevious (pLispMgr, pEntMarker, NULL) ;
	return	TRUE ;
}

BOOL
lispBuffer_RemoveMarker (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntMarker)
{
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntPrevMarker ;
	TLispEntity*	pEntNextMarker ;
	register TLispBuffer*	pBuffer ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntMarker != NULL) ;

	/*	�}�[�J�Ƃ��Ă̓����𔲂��o���B*/
	if (TFAILED (lispMarker_GetBufferPosition (pLispMgr, pEntMarker, &pEntBuffer, NULL)) ||
		pEntBuffer == NULL)
		return	FALSE ;
	
	/*	�}�[�J�̃o�b�t�@�ƈʒu��ύX����B*/
	lispMarker_SetBufferPosition (pLispMgr, pEntMarker, NULL, 0) ;
	
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	/*	�o�b�t�@�̃}�[�J�����N���Ȃ������B*/
	lispMarker_GetPrevious (pLispMgr, pEntMarker, &pEntPrevMarker) ;
	lispMarker_GetNext (pLispMgr, pEntMarker, &pEntNextMarker) ;
	
	if (pEntPrevMarker != NULL) {
		lispMarker_SetNext (pLispMgr, pEntPrevMarker, pEntNextMarker) ;
	} else {
		pBuffer->m_lstMarkers	= pEntNextMarker ;
	}
	if (pEntNextMarker != NULL) {
		lispMarker_SetPrevious (pLispMgr, pEntNextMarker, pEntPrevMarker) ;
	}
	return	TRUE ;
}

BOOL
lispBuffer_SetKeymap (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register TLispEntity*	pEntKeymap)
{
	register TLispBuffer*	pBuffer ;
	ASSERT (pLispMgr       != NULL) ;
	ASSERT (pEntBuffer     != NULL) ;
	ASSERT (pEntKeymap     != NULL) ;
	lispEntity_AddRef (pLispMgr, pEntKeymap) ;
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (pBuffer->m_pEntKeymap != NULL)
		lispEntity_Release (pLispMgr, pBuffer->m_pEntKeymap) ;
	pBuffer->m_pEntKeymap	= pEntKeymap ;
	return	TRUE ;
}

BOOL
lispBuffer_GetKeymap (
	register TLispEntity*	pEntBuffer,
	register TLispEntity**	ppEntKeymapRet)
{
	register TLispBuffer*	pBuffer ;
	ASSERT (pEntBuffer     != NULL) ;
	ASSERT (ppEntKeymapRet != NULL) ;
	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	*ppEntKeymapRet	= pBuffer->m_pEntKeymap ;
	return	TRUE ;
}

BOOL
lispBuffer_SetPrompt (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register const Char*	pString,
	register int			nString)
{
	register TLispBuffer*	pBuffer ;
	int						nBufferTop, nBufferEnd ;
	TBufStringMarker		mk ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pString    != NULL || nString == 0) ;

	if (nString <= 0)
		return	TRUE ;

	lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nBufferTop) ; 
	lispBuffer_PointBufferEnd (pLispMgr, pEntBuffer, &nBufferEnd) ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, nBufferTop - 1, &mk))) {
#if defined (DEBUG)
		fprintf (stderr, "lispBuffer_SetPrompt () : SolveMarker error!\n") ;
#endif
		return	FALSE ;
	}
	if (TFAILED (TBufStringMarker_InsertString (&mk, pString, nString))) {
#if defined (DEBUG)
		fprintf (stderr, "lispBuffer_SetPrompt () : InsertString error!\n") ;
#endif
		return	FALSE ;
	}
	/*	�J�[�\�����ړ�������B*/
	lispBuffer_MoveMarkerWithInsertion (pLispMgr, pEntBuffer, nBufferTop - 1, nString) ;
	pBuffer->m_nTick	++ ;
	return	TRUE ;
}

/*
 *	�}�[�J�̃J�[�\���̈ʒu��Ԃ��B
 */
BOOL
lispBuffer_Point (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int*			pnPoint)
{
	return	lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_POINT, pnPoint) ;
}

BOOL
lispBuffer_PointBufferEnd (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int*			pnPoint)
{
	return	lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, pnPoint) ;
}

/*
 *	�ҏW�\�ȗ̈�̐擪�ʒu��Ԃ��B
 */
BOOL
lispBuffer_PointMax (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int*			pnPoint)
{
	return	lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ELAST, pnPoint) ;
}

BOOL
lispBuffer_PointBufferTop (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int*			pnPoint)
{
	return	lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BTOP, pnPoint) ;
}

/*
 *	�ҏW�\�ȗ̈�̍ŏI�ʒu��Ԃ��B
 */
BOOL
lispBuffer_PointMin (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int*			pnPoint)
{
	return	lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ETOP, pnPoint) ;
}

BOOL
lispBuffer_PointMarker (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntBuffer,
	register TLispEntity** const	ppMarkerReturn)
{
	ASSERT (pLispMgr       != NULL) ;
	ASSERT (pEntBuffer  != NULL) ;
	ASSERT (ppMarkerReturn != NULL) ;
	*ppMarkerReturn	= lispBuffer_getMarker (pEntBuffer, MARKER_POINT) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

/*
 *	�}�[�N�̈ʒu��Ԃ��B
 */
BOOL
lispBuffer_MarkMarker (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntBuffer,
	register TLispEntity** const	ppMarkerReturn)
{
	ASSERT (pLispMgr       != NULL) ;
	ASSERT (pEntBuffer  != NULL) ;
	ASSERT (ppMarkerReturn != NULL) ;
	*ppMarkerReturn	= lispBuffer_getMarker (pEntBuffer, MARKER_MARK) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispBuffer_SetName (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntBuffer,
	register TLispEntity*		pEntName)
{
	register TLispBuffer*	pBuffer ;
	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (pBuffer->m_pEntName != NULL) 
		lispEntity_Release (pLispMgr, pBuffer->m_pEntName) ;
	pBuffer->m_pEntName	= pEntName ;
	if (pEntName != NULL)
		lispEntity_AddRef (pLispMgr, pEntName) ;
	return	TRUE ;
}

BOOL
lispBuffer_GetName (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntBuffer,
	register TLispEntity**		ppEntReturn)
{
	register TLispBuffer*	pBuffer ;
	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;

	pBuffer			= lispEntity_GetBufferPtr (pEntBuffer) ;
	*ppEntReturn	= pBuffer->m_pEntName ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

/*
 *	�o�b�t�@�ɓ���/�ҏW����Ă���e�L�X�g�𔲂��o�����߂̃}�[�J�𓾂�B
 *	���ǃA�N�Z�X�ɂ̓}�[�J���K�v�Ȃ̂ŁB
 */
BOOL
lispBuffer_GetString (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntBuffer,
	register TBufStringMarker*	pMarker,
	register int* const			pnLength)
{
	register TLispBuffer*	pBuffer ;
	int				nTop, nLast ;

	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pMarker       != NULL) ;
	ASSERT (pnLength      != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	
	/*	�o�b�t�@�̐擪����Ō�܂ł𕶎���Ƃ��Ĕ����o���Bnarrowing ��
	 *	���ʂɒ��ӂ��邱�ƁB*/
	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, &nLast)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BTOP,  &nTop)))
		return	FALSE ;
	ASSERT (nTop > 0 && nLast > 0) ;
	ASSERT (nTop <= nLast) ;
	
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, nTop - 1, pMarker)))
		return	FALSE ;
	*pnLength	= nLast - nTop ;
	return	TRUE ;
}

/*
 *	�o�b�t�@�̕ҏW�\�łȂ��G���A�Ɋ܂܂�镶����(�v�����v�g�Ƃ�)��
 *	�܂񂾃g�[�^���̕������Ԃ��BNarrowing �̉e���͓��R�󂯂Ȃ��B
 *(����)
 *	�o�b�t�@�̍Ō�ɉ����������Ă���ꍇ�ɂ͍��̎����ł͑Ή��ł���
 *	���B�g�[�^���̕��������J�E���g���Ă��Ȃ��̂ŁB
 */
BOOL
lispBuffer_GetFullString (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntBuffer,
	register TBufStringMarker*	pMarker,
	register int* const			pnLength)
{
	register TLispBuffer*	pBuffer ;
	int				nLast ;

	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pMarker       != NULL) ;
	ASSERT (pnLength      != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	
	/*	�o�b�t�@�̐擪����Ō�܂ł𕶎���Ƃ��Ĕ����o���Bnarrowing ��
	 *	���ʂɒ��ӂ��邱�ƁB*/
	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, &nLast)))
		return	FALSE ;
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, 0, pMarker)))
		return	FALSE ;
	*pnLength	= nLast - 1 ;	/* marker �� 1 ���炾���� - 1 ����B*/
	return	TRUE ;
}

/*
 *	�o�b�t�@�̕ҏW�\�̈�� nStartPos ���� nEndPos �Ɍ��肷��B
 *	�������A�o�b�t�@�̂��Ƃ��Ƃ̑傫����
 */
BOOL
lispBuffer_Narrow (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nStartPos,
	register int			nEndPos)
{
	register TLispBuffer*	pBuffer ;
	int				nBufferTop, nBufferLast ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	
	/*	narrowing ����̈�̊J�n�ʒu�͏I���ʒu��菬���������ė~�����B*/
	if (nStartPos > nEndPos)
		return	FALSE ;

	/*	�o�b�t�@�͈̔͂𓾂�B*/
	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BTOP,  &nBufferTop)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, &nBufferLast)))
		return	FALSE ;
	/*	narrowing ����͈͂��o�b�t�@�̊O��������G���[�ɂ���B*/
	if (nStartPos < nBufferTop || nEndPos > nBufferLast)
		return	FALSE ;
	
	/*	�ҏW�\�̈������킷�}�[�J���ړ�������B*/
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (TFAILED (lispMarker_SetBufferPosition (pLispMgr, pBuffer->m_apMustMarkers [MARKER_ETOP],  pEntBuffer, nStartPos)) ||
		TFAILED (lispMarker_SetBufferPosition (pLispMgr, pBuffer->m_apMustMarkers [MARKER_ELAST], pEntBuffer, nEndPos)))
		return	FALSE ;
	pBuffer->m_nTick	++ ;
	return	TRUE ;
}

BOOL
lispBuffer_Widen (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer)
{
	register TLispBuffer*	pBuffer ;
	int				nBufferTop, nBufferLast ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	
	/*	�o�b�t�@�͈̔͂𓾂�B*/
	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BTOP,  &nBufferTop)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, &nBufferLast)))
		return	FALSE ;

	/*	�ҏW�\�̈������킷�}�[�J���o�b�t�@�̐擪�ƍŌ�Ɉړ�������B*/
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (TFAILED (lispMarker_SetBufferPosition (pLispMgr, pBuffer->m_apMustMarkers [MARKER_ETOP],  pEntBuffer, nBufferTop)) ||
		TFAILED (lispMarker_SetBufferPosition (pLispMgr, pBuffer->m_apMustMarkers [MARKER_ELAST], pEntBuffer, nBufferLast)))
		return	FALSE ;
	pBuffer->m_nTick	++ ;
	return	TRUE ;
}

BOOL
lispBuffer_InsertFileContents (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nPosition,
	register KFILE*			pFile,
	register int*			pnReadCount)
{
	register TLispBuffer*	pBuffer ;
	int					nEditLast, nEditTop, nBufferLast ;
	TBufStringMarker	mk ;
	register Char		cc ;
	register int		nReadCount	= 0 ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	ASSERT (pFile      != NULL) ;

	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ETOP,  &nEditTop)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ELAST, &nEditLast)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, &nBufferLast)) ||
		nEditTop > nPosition || nPosition > nEditLast) {
#if defined (DEBUG)
		fprintf (stderr, "[buffer] Bad Marker Position.\n") ;
#endif
		return	FALSE ;
	}

	ASSERT (nEditTop  <= nEditLast) ;
	ASSERT (nEditLast <= nBufferLast) ;

	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, nPosition - 1, &mk)))
		return	FALSE ;

	while (cc = KFile_Getc (pFile), cc != EOF) {
		if (TFAILED (TBufStringMarker_InsertChar (&mk, cc, 1)))
			break ;
		nReadCount	++ ;
	}

	/*	�}�[�J���ړ�������K�v������B*/
	lispBuffer_MoveMarkerWithInsertion (pLispMgr, pEntBuffer, nPosition, nReadCount) ;
	pBuffer->m_fModified	= TRUE ;
	pBuffer->m_nTick	++ ;

	if (pnReadCount != NULL)
		*pnReadCount			= nReadCount ;
	return	(cc == EOF)? TRUE : FALSE ;
}

/*
 *	�o�b�t�@�ɕ����� nCount ��}������B
 */
BOOL
lispBuffer_InsertChar (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nPosition,
	register const Char		cc,
	register int			nCount)
{
	register TLispBuffer*	pBuffer ;
	int				nEditLast, nEditTop, nBufferLast ;
	TBufStringMarker	mk ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;

	if (nCount <= 0)
		return	TRUE ;
	
	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ETOP,  &nEditTop)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ELAST, &nEditLast)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, &nBufferLast))) {
#if defined (DEBUG)
		fprintf (stderr, "[buffer] Bad Marker Position.\n") ;
#endif
		return	FALSE ;
	}
	
	ASSERT (nEditTop  <= nEditLast) ;
	ASSERT (nEditLast <= nBufferLast) ;
	
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (nEditTop <= nPosition && nPosition <= nEditLast) {
		if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, nPosition - 1, &mk)))
			return	FALSE ;
		if (TFAILED (TBufStringMarker_InsertChar (&mk, cc, nCount)))
			return	FALSE ;

		/*	�}�[�J���ړ�������K�v������B*/
		lispBuffer_MoveMarkerWithInsertion (pLispMgr, pEntBuffer, nPosition, nCount) ;
		pBuffer->m_fModified	= TRUE ;
		pBuffer->m_nTick	++ ;
	}
	return	TRUE ;
}

/*
 *	���� delete-char �̓o�b�t�@�� narrow ��
 */
BOOL
lispBuffer_DeleteChar (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nPosition,
	register int			nCount)
{
	register TLispBuffer*	pBuffer ;
	int						nEditTop, nEditLast ;
	TBufStringMarker	mk ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;
	
	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ETOP,  &nEditTop)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ELAST, &nEditLast)))
		return	FALSE ;
	
	ASSERT (nEditTop  <= nEditLast) ;

	if (nEditTop > nPosition || (nPosition + nCount) > nEditLast)
		return	FALSE ;
	if (nCount <= 0)
		return	TRUE ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, nPosition - 1, &mk)))
		return	FALSE ;
	if (TFAILED (TBufStringMarker_DeleteChar (&mk, nCount)))
		return	FALSE ;
	/*	�}�[�J���ړ�������K�v������B*/
	lispBuffer_MoveMarkerWithDeletion (pLispMgr, pEntBuffer, nPosition, nCount) ;
	pBuffer->m_fModified	= TRUE ;
	pBuffer->m_nTick	++ ;
	return	TRUE ;
}

BOOL
lispBuffer_InsertString (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nPosition,
	register const Char*	pString,
	register int			nLength)
{
	register TLispBuffer*	pBuffer ;
	int						nEditLast, nEditTop, nBufferLast ;
	TBufStringMarker		mk ;
	
	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;

	if (nLength <= 0)
		return	TRUE ;

	ASSERT (pString    != NULL) ;
	
	if (TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ETOP,  &nEditTop)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_ELAST, &nEditLast)) ||
		TFAILED (lispBuffer_getMarkerPosition (pLispMgr, pEntBuffer, MARKER_BLAST, &nBufferLast)))
		return	FALSE ;
	
	ASSERT (nEditTop  <= nEditLast) ;
	ASSERT (nEditLast <= nBufferLast) ;
	
#if defined (DEBUG) || defined (_DEBUG)
	lispBuffer_Print (pLispMgr, pEntBuffer) ;
#endif
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	if (nEditTop <= nPosition && nPosition <= nEditLast) {
		if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, nPosition - 1, &mk)))
			return	FALSE ;
		if (TFAILED (TBufStringMarker_InsertString (&mk, pString, nLength)))
			return	FALSE ;

		/*	�}�[�J���ړ�������K�v������B*/
		lispBuffer_MoveMarkerWithInsertion (pLispMgr, pEntBuffer, nPosition, nLength) ;
		pBuffer->m_fModified	= TRUE ;
		pBuffer->m_nTick	++ ;
	}
#if defined (DEBUG) || defined (_DEBUG)
	lispBuffer_Print (pLispMgr, pEntBuffer) ;
#endif
	return	TRUE ;
}

/*	buffer �� modified flag ���Q�Ƃ���B
 */
BOOL
lispBuffer_GetModifiedp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer)
{
	register TLispBuffer*	pBuffer ;
	
	ASSERT (pLispMgr != NULL) ;
	ASSERT (pEntBuffer != NULL) ;

	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	return	pBuffer->m_fModified ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

/*	buffer �� modified flag ��ݒ肷��Bmodified flag �͒��ڂ͏C���ł��Ȃ��B
 *	���̊֐����o�R���邱�ƁB
 */
void
lispBuffer_SetModifiedp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register BOOL			fModified)
{
	register TLispBuffer*	pBuffer ;
	
	ASSERT (pLispMgr != NULL) ;
	ASSERT (pEntBuffer != NULL) ;

	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	pBuffer->m_fModified	= fModified ;
	pBuffer->m_nTick	++ ;
	return ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

/*
 *	�o�b�t�@�e�L�X�g���ʒu nPosition ���� nCount ���������}�������ꍇ��
 *	�}�[�J�̓����͕킷��B
 *	���ۂ̑}����Ƃ͂����ł͉����l���Ȃ��B
 */
BOOL
lispBuffer_MoveMarkerWithInsertion (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nPosition,
	register int			nCount)
{
	register TLispBuffer*	pBuffer ;
	register TLispEntity*	pEntMarker ;
	TLispEntity*			pEntNextMarker ;
#if defined (DEBUG_LV99)
	register int			i = 0 ;
#endif

	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	pEntMarker	= pBuffer->m_lstMarkers ;
	
#if defined (DEBUG_LV99)
	fprintf (stderr, "move-marker-with-insertion (%d, %d)\n", nPosition, nCount) ;
#endif
	while (pEntMarker != NULL) {
#if defined (DEBUG_LV99)
		fprintf (stderr, "(%d) ", i ++) ;
#endif
		lispMarker_MoveWithInsertion (pLispMgr, pEntMarker, nPosition, nCount) ;
		lispMarker_GetNext (pLispMgr, pEntMarker, &pEntNextMarker) ;
		pEntMarker	= pEntNextMarker ;
	}
	return	TRUE ;
}

/*
 *	�o�b�t�@�e�L�X�g���ʒu nPosition ���� nCount ���������폜�����ꍇ��
 *	�}�[�J�̓����͕킷��B
 *	���ۂ̑}����Ƃ͂����ł͉����l���Ȃ��B
 */
BOOL
lispBuffer_MoveMarkerWithDeletion (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nPosition,
	register int			nCount)
{
	TLispEntity*	pEntMarker ;
	TLispEntity*	pEntNextMarker ;
	TLispBuffer*	pBuffer ;

	pBuffer			= lispEntity_GetBufferPtr (pEntBuffer) ;
	pEntMarker	= pBuffer->m_lstMarkers ;
	
	/*	�o�b�t�@�ɂȂ���Ă���}�[�J�����ԂɈړ�������c�B
	 *	���̕��@�ł̓}�[�J�̐�����������ƂƂ��Ă����x���c������B
	 *	�܂��A�Q�Ƃ���Ȃ��}�[�J�̓Q�V�Q�V���\��Ȃ̂Łc�B*/
	while (pEntMarker != NULL) {
		lispMarker_MoveWithDeletion (pLispMgr, pEntMarker, nPosition, nCount) ;
		lispMarker_GetNext (pLispMgr, pEntMarker, &pEntNextMarker) ;
		pEntMarker	= pEntNextMarker ;
	}
	return	TRUE ;
}

/*	lbuffer.c */
int
lispBuffer_GetTick (
	register TLispEntity*	pEntBuffer)
{
	register TLispBuffer*	pBuffer ;
	ASSERT (pEntBuffer != NULL) ;
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	return	pBuffer->m_nTick ;
}

#if defined (DEBUG) || defined (_DEBUG)
/*
 *	�f�o�b�O�p�̊֐��B
 *	�o�b�t�@�̒��g�����S�ɕ\������B
 */
BOOL
lispBuffer_Print (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer)
{
	TLispEntity*		pEntMarker ;
	TLispEntity*		pEntNextMarker ;
	TLispBuffer*		pBuffer ;
	KANJISTATEMACHINE	ksm ;
	int					n, i, nLength ;
	char				achBuf [16] ;
	static char*		apMarkerName []	= {
		"BTOP", "ETOP", "POINT", "ELAST", "BLAST", "MARK",
	} ;
	TBufStringMarker	mk ;
	Char				cc ;

	ASSERT (pLispMgr   != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	fprintf (stderr, "buffer(%p) ---\n", pEntBuffer) ;
	pBuffer		= lispEntity_GetBufferPtr (pEntBuffer) ;
	pEntMarker	= pBuffer->m_lstMarkers ;
	for (i = 0 ; i < NUM_BUFFER_MUST_MARKERS ; i ++) {
		fprintf (stderr, "(%5s) ", apMarkerName [i]) ;
		if (pBuffer->m_apMustMarkers [i] == NULL) {
			fprintf (stderr, "no-exist\n") ;
		} else {
			lispMarker_Print (pLispMgr, pBuffer->m_apMustMarkers [i]) ;
			fprintf (stderr, "\n") ;
		}
	}
	i			= 0 ;
	while (pEntMarker != NULL) {
		fprintf (stderr, "(%d) ", i ++) ;
		lispMarker_Print (pLispMgr, pEntMarker) ;
		fprintf (stderr, "\n") ;
		lispMarker_GetNext (pLispMgr, pEntMarker, &pEntNextMarker) ;
		pEntMarker	= pEntNextMarker ;
	}

	if (TFAILED (TBufString_SolveMarker (&pBuffer->m_Text, 0, &mk)))
		return	FALSE ;

	lispBuffer_PointBufferEnd (pLispMgr, pEntBuffer, &nLength) ;
	nLength		-- ;
	fprintf (stderr, "buffer-string(%d) = \"", nLength) ;
	InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_SHIFTJIS) ;
	while (nLength > 0) {
		cc	= TBufStringMarker_GetChar (&mk) ;
		n	= RtransferKanjiFiniteStateMachine (&ksm, cc, achBuf) ;
		achBuf [n]	= '\0' ;
		fprintf (stderr, "%s", achBuf) ;
		TBufStringMarker_Forward (&mk, 1) ;
		nLength	-- ;
	}
	fprintf (stderr, "\"\n") ;
	return	TRUE ;
}
#endif

/*	private functions */
/*
 *	�o�b�t�@�Ƀ}�[�J(�K�����݂������)������t�����肷��B
 */
BOOL
lispBuffer_initialize (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer)
{
	register TLispBuffer*	pBuffer ;
	BOOL			afInsertionType [NUM_BUFFER_MUST_MARKERS - 1]	= {
		FALSE,	/* buffer top */
		FALSE,	/* edit   top */
		TRUE,	/* point */
		TRUE,	/* edit   end */
		TRUE,	/* buffer end */
	} ;
	TLispEntity*	pEntMarker ;
	register int	i ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	
	pBuffer			= lispEntity_GetBufferPtr (pEntBuffer) ;

	if (TFAILED (TBufString_Initialize (&pBuffer->m_Text)))
		return	FALSE ;

	/*	�o�b�t�@�ɕK�����݂���}�[�J���쐬����B*/
	for (i = 0 ; i < NUM_BUFFER_MUST_MARKERS - 1 ; i ++) {
		if (TFAILED (lispMgr_CreateMarker (pLispMgr, &pEntMarker)))
			return	FALSE ;
		lispEntity_AddRef (pLispMgr, pEntMarker) ;
		lispMarker_SetInsertionType (pLispMgr, pEntMarker, afInsertionType [i]) ;
		/*	�}�[�J���o�b�t�@�̊Ǘ����ɒǉ��B*/
		lispBuffer_AddMarker (pLispMgr, pEntBuffer, pEntMarker) ;
		pBuffer->m_apMustMarkers [i]	= pEntMarker ;
	}
	/*	�o�b�t�@�����w���Ȃ��}�[�J�����B*/
	if (TFAILED (lispMgr_CreateMarker (pLispMgr, &pEntMarker)))
		return	FALSE ;
	lispEntity_AddRef (pLispMgr, pEntMarker) ;
	lispMarker_SetInsertionType (pLispMgr, pEntMarker, FALSE) ;
	pBuffer->m_apMustMarkers [i]	= pEntMarker ;
	pBuffer->m_nTick	++ ;
	return	TRUE ;
}

BOOL
lispBuffer_uninitialize (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer)
{
	register TLispBuffer*	pBuffer ;
	register TLispEntity*	pEntMarker ;
	register TLispEntity**	ppEntMustMarker ;
	register int			i ;

	pBuffer	= lispEntity_GetBufferPtr (pEntBuffer) ;

	/*	�o�b�t�@���[�J���ϐ����������B*/
	lispBindTable_Destroy (pLispMgr, pBuffer->m_apVariableTable, SIZE_LISP_BIND_TABLE) ;
	pEntMarker	= pBuffer->m_lstMarkers ;
	/*	�K�{�}�[�J�ȊO�������B*/
	while (pEntMarker != NULL) {
		TLispEntity*	pEntNextMarker ;
		lispMarker_GetNext (pLispMgr, pEntMarker, &pEntNextMarker) ;
		lispBuffer_RemoveMarker (pLispMgr, pEntMarker) ;
		pEntMarker	= pEntNextMarker ;
	}
	/*	�K�{�}�[�J���������B*/
	ppEntMustMarker	= pBuffer->m_apMustMarkers ;
	for (i = 0 ; i < NUM_BUFFER_MUST_MARKERS ; i ++) {
		if (*ppEntMustMarker != NULL) {
			lispEntity_Release (pLispMgr, *ppEntMustMarker) ;
			*ppEntMustMarker = NULL ;
		}
		ppEntMustMarker	++ ;
	}
	TBufString_Uninitialize (&pBuffer->m_Text) ;
	pBuffer->m_nTick	++ ;
	return	TRUE ;
}

TLispEntity*
lispBuffer_getMarker (
	register TLispEntity*	pEntBuffer,
	register int			nMarker)
{
	register TLispBuffer*	pBuffer ;
	
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (MARKER_BTOP <= nMarker && nMarker < NUM_BUFFER_MUST_MARKERS) ;

	pBuffer			= lispEntity_GetBufferPtr (pEntBuffer) ;
	return	pBuffer->m_apMustMarkers [nMarker] ;
}

BOOL
lispBuffer_getMarkerPosition (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntBuffer,
	register int			nMarker,
	register int*			pnRetval)
{
	TLispEntity*	pMarkerBuffer ;
	TLispEntity*	pMarker ;
	
	ASSERT (pLispMgr      != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (MARKER_BTOP <= nMarker && nMarker < NUM_BUFFER_MUST_MARKERS) ;
	ASSERT (pnRetval      != NULL) ;

	pMarker			= lispBuffer_getMarker (pEntBuffer, nMarker) ;
	if (pMarker == NULL)
		return	FALSE ;
	if (TSUCCEEDED (lispMarker_GetBufferPosition (pLispMgr, pMarker, &pMarkerBuffer, pnRetval)) &&
		pMarkerBuffer == pEntBuffer) 
		return	TRUE ;
	return	FALSE ;
}

