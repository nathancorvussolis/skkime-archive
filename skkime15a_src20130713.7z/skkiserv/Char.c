#include "local.h"
// #include "Char.h"

int
Char_Charset (register Char cc)
{
	return	((cc) >> 24) & 0x7F ;
}

unsigned int
Char_Code (register Char cc)
{
	return	(cc) & 0x00FFFFFFUL ;
}

int
Char_ToAscii (register Char cc)
{
	return	(KCHARSET_ASCII << 24) | Char_Code ((Char)(cc)) ;
}

int
Char_IsAscii (register Char cc)
{
	return	(KCHARSET_ASCII <= Char_Charset (cc) &&
			 Char_Charset (cc) < KCHARSET_2BYTES_CHARACTER &&
			 Char_Code (cc) < 0x80) ;
}

int
Char_Difference (register Char chLeft, register Char chRight)
{
	if (Char_IsAscii (chLeft)) {
		chLeft	= Char_ToAscii (chLeft) ;
#if 0
	} else {
		int	iCharset	= Char_Charset (chLeft) ;

		/*	JISX0208-1978, JISX0208-1983, JISX0213-2000-PLANE1, JISX0213-2004-PLANE1 ��
		 *	�����Ɉ����B(�{���͓����ɏo���Ȃ��R�[�h���܂����Ă��邪�A�����ł͖�������)
		 *
		 *	�܂��AJISX0212-1990 �� JISX0213-2000-PLANE2 �������Ɉ����B
		 */
		if (KCHARSET_JISX0208_1978 <= iCharset && iCharset <= KCHARSET_JISX0213_2004_PLANE1) {
			chLeft	= Char_Make (KCHARSET_JISX0213_2004_PLANE1, Char_Code (chLeft)) ;
		} else if (KCHARSET_JISX0212_1990 <= iCharset && iCharset <= KCHARSET_JISX0213_2000_PLANE2) {
			chLeft	= Char_Make (KCHARSET_JISX0213_2000_PLANE2, Char_Code (chLeft)) ;
		}
#endif
	}

	if (Char_IsAscii (chRight)) {
		chRight	= Char_ToAscii (chRight) ;
#if 0
	} else {
		int	iCharset	= Char_Charset (chLeft) ;

		if (KCHARSET_JISX0208_1978 <= iCharset && iCharset <= KCHARSET_JISX0213_2004_PLANE1) {
			chRight	= Char_Make (KCHARSET_JISX0213_2004_PLANE1, Char_Code (chRight)) ;
		} else if (KCHARSET_JISX0212_1990 <= iCharset && iCharset <= KCHARSET_JISX0213_2000_PLANE2) {
			chRight	= Char_Make (KCHARSET_JISX0213_2000_PLANE2, Char_Code (chRight)) ;
		}
#endif
	}
	return	(chLeft - chRight) ;
}

Char
Char_Make (register int nSet, register unsigned int uCode)
{
	return	((nSet & 0x7F) << 24) | uCode ;
}

Char
Char_MakeAscii (register int ch)
{
	return	Char_Make (KCHARSET_ASCII, ch & 0x7F) ;
}

int
Char_DifferenceAscii (register Char cc, register int ch)
{
	return	Char_Difference (cc, Char_MakeAscii (ch)) ;
}

int
Char_IsEqual (register Char chl, register Char chr)
{
	return	!Char_Difference (chl, chr) ;
}

int
Char_IsEqualAscii (register Char chl, register Char chr)
{
	return	!Char_DifferenceAscii (chl, chr) ;
}

int
Char_IsNul (register Char cc)
{
	return	(Char_Code (cc) == '\0' && Char_IsAscii (cc)) ;
}

int
Char_IsAlpha (register Char cc)
{
	return	(Char_IsAscii (cc) && (('a' <= cc && cc <= 'z') || ('A' <= cc && cc <= 'Z'))) ;
}

int
Char_IsDigitNum (register Char cc)
{
	return	(Char_IsAscii (cc) && (('0' <= cc && cc <= '9') || cc == '-' || cc == '+')) ;
}

int
Char_IsAlphaNum (register Char cc)
{
	return	Char_IsAlpha (cc) || Char_IsDigitNum (cc) ;
}

int
Char_IsSpace (register Char cc)
{
	return	Char_IsAscii (cc) && (cc == ' ' || cc == '\t') ;
}

int
Char_Is2ByteChara (register Char cc)
{
	register int		nSet ;
	nSet	= Char_Charset (cc) ;
	return	(KCHARSET_2BYTES_CHARACTER <= nSet && nSet < MAX_CHARSET) ;
}

Char
Char_ToLower (register Char cc)
{
	if (Char_IsAscii (cc) && ('A' <= Char_Code (cc) && Char_Code (cc) <= 'Z'))
		return	Char_MakeAscii ((char)(Char_Code (cc) + 'a' - 'A')) ;
	return	cc ;
}

Char
Char_ToUpper (register Char cc)
{
	if (Char_IsAscii (cc) && ('a' <= Char_Code (cc) && Char_Code (cc) <= 'z'))
		return	Char_MakeAscii ((char)(Char_Code (cc) + 'A' - 'a')) ;
	return	cc ;
}

