#include "stdafx.h"
#include "skimconf.h"
#include "resource.h"

#define	MAX(left,right)		(((left)<(right))? (right) : (left))

/*========================================================================
 *	Registry Keys
 */

/* style */
#define	REGPATH_STYLE						REGPATH_SKKIME TEXT("\\Style")
#define	REGSUBKEY_COLORFACE					TEXT("Color")
#define	REGSUBKEY_DEFAULTFONT				TEXT("Font")
#define	REGSUBKEY_DEFAULTFONTSIZE			TEXT("Size")

/*========================================================================
 *	Other definitions
 */
enum {
	MYCOLOR_TEXTAUTO	= 0,	MYCOLOR_BACKAUTO,			MYCOLOR_BLACK,
	MYCOLOR_DARKRED,			MYCOLOR_DARKGREEN,			MYCOLOR_DARKYELLOW,
	MYCOLOR_DARKBLUE,			MYCOLOR_DARKPURPLE,			MYCOLOR_DARKLIGHTBLUE,
	MYCOLOR_DARKGRAY,			MYCOLOR_LIGHTGRAY,			MYCOLOR_RED,
	MYCOLOR_GREEN,				MYCOLOR_YELLOW,				MYCOLOR_BLUE,
	MYCOLOR_PURPLE,				MYCOLOR_LIGHTBLUE,			MYCOLOR_WHITE,
	MYCOLOR_SYSTEM,
	MYCOLOR_BTNFACE		= MYCOLOR_SYSTEM,
	MYCOLOR_BTNTEXT,			MYCOLOR_ACTIVEBORDER,		MYCOLOR_ACTIVECAPTION,
	MYCOLOR_CAPTIONTEXT,		MYCOLOR_APPWORKSPACE,		MYCOLOR_WINDOW,
	MYCOLOR_WINDOWTEXT,			MYCOLOR_DESKTOP,			MYCOLOR_INFOBK,
	MYCOLOR_INFOTEXT,			MYCOLOR_MSGBOXTEXT,			MYCOLOR_MENU,
	MYCOLOR_MENUTEXT,			MYCOLOR_HIGHLIGHTTEXT,		MYCOLOR_HIGHLIGHT,
	MYCOLOR_INACTIVEBORDER,		MYCOLOR_INACTIVECAPTION,	MYCOLOR_INACTIVECAPTIONTEXT,
	MAX_MYCOLOR,
} ;

enum {
	MYLINE_NO	= 0,	MYLINE_SOLID,		MYLINE_DOTTED,
	MYLINE_THICK_SOLID,	MYLINE_THIN_DITHER,	MYLINE_THICK_DITHER,
	MAX_MYLINE,
} ;

enum {
	MYCOLORFACE_INDEX_MIHENKANMOJIRETSU	= 0,
	MYCOLORFACE_INDEX_HENKANMOJIRETSU	= 1,
} ;

/*========================================================================
 *	Structures
 */
struct MYCOLORDEF {
	LPCTSTR		m_strText ;
	int			m_nType ;
} ;

struct MYCOLORFACESET {
	int				m_nTextColor ;
	int				m_nBackColor ;
	int				m_nUnderLineColor ;
	int				m_nUnderLineType ;
} ;

/*========================================================================
 *	Prototypes
 */
static	INT_PTR		dlgColor_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgColor_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgColor_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgColor_iOnDrawItem	(HWND, WPARAM, LPARAM) ;
static	void		dlgColor_vSyncControls	(HWND) ;

static	BOOL		dlgColor_bLoadRegistrySetting	(void) ;
static	BOOL		dlgColor_bSaveSettingToRegistry	(void) ;
static	void		dlgColor_vLoadDefaultSetting	(void) ;
static	void		dlgColor_vInitializeDefaultFontSetting	(HWND hDlg) ;
static	BOOL		bIsValidColor			(int) ;
static	BOOL		bIsValidLineType		(int) ;
static	int			iFontHeight2PointSize	(HWND hWnd, int iFontHeight) ;
static	int			iPointSize2FontHeight	(HWND hWnd, int iFontHeight) ;

static	void		vDrawTextWithColorFace	(HDC, int, int, LPCTSTR, int, HWND, struct MYCOLORFACESET*) ;
static	COLORREF	crGetImeColor			(HWND, int) ;
static	HBRUSH		hbrGetImeLineBrush		(HWND, int, int, COLORREF*, HBITMAP*, int*) ;

/*========================================================================
 *	global variables
 */
static	struct MYCOLORDEF	_srColorDefinitions []	= {
	{ TEXT ("����(����)"),							MYCOLOR_TEXTAUTO, },
	{ TEXT ("����(�w�i)"),							MYCOLOR_BACKAUTO, },
	{ TEXT ("��"),									MYCOLOR_BLACK, },
	{ TEXT ("�Â���"),								MYCOLOR_DARKRED, },
	{ TEXT ("�Â���"),								MYCOLOR_DARKGREEN, },
	{ TEXT ("�Â����F"),							MYCOLOR_DARKYELLOW, },
	{ TEXT ("�Â���"),								MYCOLOR_DARKBLUE, },
	{ TEXT ("�Â���"),								MYCOLOR_DARKPURPLE, },
	{ TEXT ("�Â����F"),							MYCOLOR_DARKLIGHTBLUE, },
	{ TEXT ("�Â��D�F"),							MYCOLOR_DARKGRAY, },
	{ TEXT ("���邢�D�F"),							MYCOLOR_LIGHTGRAY, },
	{ TEXT ("��"),									MYCOLOR_RED, },
	{ TEXT ("��"),									MYCOLOR_GREEN, },
	{ TEXT ("���F"),								MYCOLOR_YELLOW, },
	{ TEXT ("��"),									MYCOLOR_BLUE, },
	{ TEXT ("��"),									MYCOLOR_PURPLE, },
	{ TEXT ("���F"),								MYCOLOR_LIGHTBLUE, },
	{ TEXT ("��"),									MYCOLOR_WHITE, },
	{ TEXT ("3D�I�u�W�F�N�g"),						MYCOLOR_BTNFACE, },
	{ TEXT ("3D�I�u�W�F�N�g�̕���"),				MYCOLOR_BTNTEXT, },
	{ TEXT ("�A�N�e�B�u �E�B���h�E�̋��E"),			MYCOLOR_ACTIVEBORDER, },
	{ TEXT ("�A�N�e�B�u �^�C�g�� �o�["),			MYCOLOR_ACTIVECAPTION, },
	{ TEXT ("�A�N�e�B�u �^�C�g�� �o�[�̕���"),		MYCOLOR_CAPTIONTEXT, },
	{ TEXT ("�A�v���P�[�V������ƈ�"),				MYCOLOR_APPWORKSPACE, },
	{ TEXT ("�E�B���h�E"),							MYCOLOR_WINDOW, },
	{ TEXT ("�E�B���h�E�̕���"),					MYCOLOR_WINDOWTEXT, },
	{ TEXT ("�f�X�N�g�b�v"),						MYCOLOR_DESKTOP, },
	{ TEXT ("�q���g"),								MYCOLOR_INFOBK, },
	{ TEXT ("�q���g�̕���"),						MYCOLOR_INFOTEXT, },
	{ TEXT ("���b�Z�[�W�{�b�N�X�̕���"),			MYCOLOR_MSGBOXTEXT, },
	{ TEXT ("���j���["),							MYCOLOR_MENU, },
	{ TEXT ("���j���[�̕���"),						MYCOLOR_MENUTEXT, },
	{ TEXT ("�I������(����)"),						MYCOLOR_HIGHLIGHTTEXT, },
	{ TEXT ("�I������(�w�i)"),						MYCOLOR_HIGHLIGHT, },
	{ TEXT ("��A�N�e�B�u �E�B���h�E�̋��E"),		MYCOLOR_INACTIVEBORDER, },
	{ TEXT ("��A�N�e�B�u �^�C�g�� �o�["),			MYCOLOR_INACTIVECAPTION, },
	{ TEXT ("��A�N�e�B�u �^�C�g�� �o�[�̕���"),	MYCOLOR_INACTIVECAPTIONTEXT, },
} ;

static LPCTSTR		_srLineStyles []	= {
	TEXT ("�Ȃ�"),	TEXT ("����"),			TEXT ("�_��"),
	TEXT ("����"),	TEXT ("�f�B�U�א�"),	TEXT ("�f�B�U����"),
} ;

#include "../common/colorfaces.h"

/// ���݂̐ݒ�
static struct MYCOLORFACESET _srImeColorFaces[2];

/// ���݂̕\��
static	int			_siSelectedColorFace ;

static	HPEN		_shPen	= NULL ;

static	TCHAR		_sbufDefaultFont [LF_FACESIZE]	= TEXT ("") ;
static	int			_siDefaultFontSize				= -1 ;

/*========================================================================
 *	public	functions
 */
INT_PTR	CALLBACK
DlgColorProc (
	HWND			hDlg,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgColor_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgColor_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgColor_iOnNotify (hDlg, wParam, lParam) ;
	case	WM_DRAWITEM:
		return	dlgColor_iOnDrawItem (hDlg, wParam, lParam) ;
	case	WM_DESTROY:
		{
			if (_shPen != NULL) {
				DeleteObject (_shPen) ;
				_shPen	= NULL ;
			}
		}
		break ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgColor_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	static struct {
		int		m_iWidth ;
		LPCTSTR	m_strCaption ;
	}	srColumnDef []	= {
		{ 120,	TEXT ("�ύX��"),		},
		{ 60,	TEXT ("�v���r���["),	},	/*	preview �� owner-draw �̕K�v���肩�H */
	} ;
	static int		srCombos []	= {
		IDC_COMBO_FORECOLOR,	IDC_COMBO_BACKCOLOR,	IDC_COMBO_ULCOLOR,
	} ;
	static LPCTSTR				srColorFaceTitle []	= {
		TEXT ("���͕���"),	TEXT ("�ϊ�����"),
	} ;
	HWND			hwndControl ;
	PROPSHEETPAGE*	pPropPage	= (PROPSHEETPAGE*) lParam ;
	int				i ;
	LRESULT			nIndex ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pPropPage->lParam) ;
	_siSelectedColorFace	= 0 ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SELECTFACE) ;
	if (hwndControl != NULL) {
		LV_COLUMN			lvColumn;
		LVITEM				lvi ;

		ListView_DeleteAllItems (hwndControl) ;
		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;
		memset (&lvColumn, 0, sizeof (lvColumn)) ;
		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		for (i = 0 ; i < ARRAYSIZE (srColumnDef) ; i ++) {
			lvColumn.cx			= srColumnDef [i].m_iWidth ;
			lvColumn.pszText	= (LPTSTR) srColumnDef [i].m_strCaption ;
			ListView_InsertColumn (hwndControl, i, &lvColumn) ;
		}

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask			= LVIF_PARAM | LVIF_TEXT ;
		for (i = 0 ; i < ARRAYSIZE (srColorFaceTitle) ; i ++) {
			int		nItem ;
			lvi.iItem			= i ;
			lvi.lParam			= (LPARAM) i ;
			lvi.pszText			= (LPTSTR) srColorFaceTitle [i] ;
			nItem				= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				ListView_SetItemText (hwndControl, nItem, 1, TEXT ("��������")) ;
			}
		}
	}

	for (i = 0 ; i < ARRAYSIZE (srCombos) ; i ++) {
		int		j ;

		hwndControl	= GetDlgItem (hDlg, srCombos [i]) ;
		if (hwndControl != NULL) {
			for (j = 0 ; j < ARRAYSIZE (_srColorDefinitions) ; j ++) {
				nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) j, (LPARAM) _srColorDefinitions [j].m_strText) ;
				if (nIndex != CB_ERR)
					SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) j) ;
			}
		}
	}
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_UNDERLINE) ;
	if (hwndControl != NULL) {
		for (i = 0 ; i < ARRAYSIZE (_srLineStyles) ; i ++) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) i, (LPARAM) _srLineStyles [i]) ;
			if (nIndex != CB_ERR)
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) i) ;
		}
	}

	_shPen	= CreatePen (PS_SOLID, 2, PALETTERGB (255, 0, 0)) ;

	if (! dlgColor_bLoadRegistrySetting ())
		dlgColor_vLoadDefaultSetting () ;
	dlgColor_vInitializeDefaultFontSetting (hDlg) ;

	dlgColor_vSyncControls (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgColor_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;
	int*	pnData ;

	switch (woControl) {
	case	IDC_COMBO_FORECOLOR:
		pnData	= &_srImeColorFaces [_siSelectedColorFace].m_nTextColor ;
		goto	common ;
	case	IDC_COMBO_BACKCOLOR:
		pnData	= &_srImeColorFaces [_siSelectedColorFace].m_nBackColor ;
		goto	common ;
	case	IDC_COMBO_ULCOLOR:
		pnData	= &_srImeColorFaces [_siSelectedColorFace].m_nUnderLineColor ;
		goto	common ;
	case	IDC_COMBO_UNDERLINE:
		pnData	= &_srImeColorFaces [_siSelectedColorFace].m_nUnderLineType ;
common:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl, hwndPreview, hwndList ;
			LRESULT	nCurSel, nData ;

			hwndControl	= GetDlgItem (hDlg, woControl) ;
			if (hwndControl == NULL)
				break ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel == CB_ERR)
				break ;
			nData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
			if (nData == CB_ERR)
				break ;
			*pnData	= nData ;

			hwndList	= GetDlgItem (hDlg, IDC_LIST_SELECTFACE) ;
			if (hwndList != NULL)
				InvalidateRect (hwndList, NULL, TRUE) ;
			hwndPreview	= GetDlgItem (hDlg, IDC_BUTTON_PREVIEW) ;
			if (hwndPreview != NULL)
				InvalidateRect (hwndPreview, NULL, TRUE) ;

			PropSheet_Changed (GetParent (hDlg), hDlg) ;
		}
		break ;
	case	IDC_BUTTON_CHANGE_MINIBUFFERFONT:
		/*
			font: 0x470(1136), CBS_SIMPLE
			size: 0x472(1138), CBS_SIMPLE
			charset: 0x474(1140), CBS_DROPDOWNLIST
			sample(static): 0x444(1092),static
		*/
		if (woNotification == BN_CLICKED) {
			CHOOSEFONT	cf ;
			LOGFONT		lf ;
			memset (&cf, 0, sizeof (cf)) ;
			cf.lStructSize	= sizeof (cf) ;
			cf.hwndOwner	= hDlg ;
			memset (&lf, 0, sizeof (lf)) ;
			_tcsncpy (lf.lfFaceName, _sbufDefaultFont, LF_FACESIZE) ;
			lf.lfHeight			= iPointSize2FontHeight (hDlg, _siDefaultFontSize) ;
			cf.lpLogFont		= &lf ;
			cf.Flags			= CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT ;
			cf.hInstance		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
			cf.nFontType		= REGULAR_FONTTYPE | SCREEN_FONTTYPE ;
			if (ChooseFont (&cf)) {
				_tcsncpy (_sbufDefaultFont, lf.lfFaceName, LF_FACESIZE) ;
				_siDefaultFontSize	= cf.iPointSize / 10 ;
				dlgColor_vSyncControls (hDlg) ;
				PropSheet_Changed (GetParent (hDlg), hDlg) ;
			}
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgColor_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_BUTTON_PREVIEW:
		if (pNMHDR->code == NM_CUSTOMDRAW) {
//			LPNMCUSTOMDRAW	lpLVCD	= (LPNMCUSTOMDRAW) lParam ;

			return	(INT_PTR) CDRF_SKIPDEFAULT ;
		}
		break ;
	case	IDC_LIST_SELECTFACE:
//		if (pNMHDR->code == NM_CLICK || pNMHDR->code == NM_RCLICK || pNMHDR->code == NM_SETFOCUS) {
		if (pNMHDR->code == LVN_ITEMCHANGED || pNMHDR->code == NM_CLICK || pNMHDR->code == NM_RCLICK) {
			HWND				hwndControl ;
			int					iItem ;

			iItem	= ListView_GetSelectionMark (pNMHDR->hwndFrom) ;
			if (iItem != _siSelectedColorFace && 0 <= iItem && iItem < ARRAYSIZE (_srImeColorFaces)) {
				SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_FORECOLOR,	_srImeColorFaces [iItem].m_nTextColor) ;
				SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_BACKCOLOR,	_srImeColorFaces [iItem].m_nBackColor) ;
				SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_ULCOLOR,		_srImeColorFaces [iItem].m_nUnderLineColor) ;
				SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_UNDERLINE,	_srImeColorFaces [iItem].m_nUnderLineType) ;

				hwndControl	= GetDlgItem (hDlg, IDC_BUTTON_PREVIEW) ;
				if (hwndControl != NULL)
					InvalidateRect (hwndControl, NULL, TRUE) ;

				_siSelectedColorFace	= iItem ;
			}
			break ;
		}
		if (pNMHDR->code == NM_CUSTOMDRAW) {
			LPNMLVCUSTOMDRAW	lpLVCD	= (LPNMLVCUSTOMDRAW) lParam ;
			LRESULT				lResult ;
			int					iItem, iSubItem ;

			switch (lpLVCD->nmcd.dwDrawStage) {
			case	CDDS_PREPAINT:
				lResult	= CDRF_NOTIFYITEMDRAW ;
				break ;
			case	CDDS_ITEMPREPAINT:
				lResult	= CDRF_NOTIFYSUBITEMDRAW ;
				break ;
			case	CDDS_ITEMPREPAINT | CDDS_SUBITEM:
				iItem		= lpLVCD->nmcd.lItemlParam ;
				iSubItem	= lpLVCD->iSubItem ;
				lResult		= CDRF_DODEFAULT ;
				if (0 <= iItem && iItem < ARRAYSIZE (_srImeColorFaces) && iSubItem == 1) {
					struct MYCOLORFACESET*	pColor ;
					HWND		hwnd ;
					HDC			hDC ;
					RECT		rc ;
					SIZE		sz ;
					HBRUSH		hBrush ;
					HBITMAP		hBitmap ;
					int			nWidth, nBkMode ;
					COLORREF	colLine, colTextBak, colBkBak ;
					static LPCTSTR	str	= TEXT ("��������") ;

					pColor		= &_srImeColorFaces [iItem] ;
//					if (ListView_GetSubItemRect (pNMHDR->hwndFrom, iItem, lpLVCD->iSubItem, LVIR_BOUNDS, &rc)) {
//						TextOut (lpLVCD->nmcd.hdc, rc.left, rc.top, TEXT ("������"), 3) ;

					/*	�T���v�������u���������v��`�悷��B
					 */
					hwnd		= pNMHDR->hwndFrom ;
					hDC			= lpLVCD->nmcd.hdc ;

					colTextBak	= SetTextColor (hDC, crGetImeColor (hwnd, pColor->m_nTextColor)) ;
					colBkBak	= SetBkColor   (hDC, crGetImeColor (hwnd, pColor->m_nBackColor)) ;
					nBkMode		= SetBkMode	 (hDC, OPAQUE) ;
					ListView_GetItemRect (hwnd, iItem, &rc, LVIR_BOUNDS) ;
					rc.left		= lpLVCD->nmcd.rc.left ;
					rc.right	= lpLVCD->nmcd.rc.right ;
					DrawText (hDC, str, lstrlen (str), &rc, DT_LEFT | DT_TOP) ;
					
					/*	�T���v�������u���������v�ɉ����������B
					 */
					GetTextExtentPoint32 (hDC, str, lstrlen (str), &sz) ;
					hBrush	= hbrGetImeLineBrush (hwnd, pColor->m_nUnderLineColor, pColor->m_nUnderLineType, &colLine, &hBitmap, &nWidth) ;
					if (hBrush != NULL) {
						register HBRUSH	hOldBrush ;
						register int		nCX, nX, nY ;

						nX	= rc.left ;
						nCX	= ((nX + sz.cx) > rc.right)? (rc.right - nX) : sz.cx ;
						nY	= ((rc.top + sz.cy) > rc.bottom)? rc.bottom : (rc.top + sz.cy) ;
						nY	-= nWidth ;
						hOldBrush		= (HBRUSH) SelectObject (hDC, hBrush) ;
						SetTextColor (hDC, colLine) ;
						PatBlt (hDC, nX, nY, nCX, nWidth, PATCOPY) ;
						(void) SelectObject (hDC, hOldBrush) ;
						DeleteObject (hBrush) ;
					}
					if (hBitmap != NULL)
						DeleteObject (hBitmap) ;
					SetTextColor	(hDC, colTextBak) ;
					SetBkColor		(hDC, colBkBak) ;
					SetBkMode		(hDC, nBkMode) ;
					lResult	= CDRF_SKIPDEFAULT ;
				}
				break ;
			default:
				lResult	= CDRF_DODEFAULT ;
				break ;
			}
// �ŋ߂�SDK�Ȃ��{���ł��� (�Â�SDK�̏ꍇ�͕ʂ̏ꏊ�Œ�`�����}�N���őΉ����ׂ�)
// #if defined (_WIN64)
			SetWindowLongPtr (hDlg, DWLP_MSGRESULT, (LONG_PTR) lResult);
// #else
// 			SetWindowLong (hDlg, DWL_MSGRESULT, (LONG) lResult);
// #endif
			return TRUE;
		}
		break ;

	default:
		switch (pNMHDR->code) {
		case	PSN_APPLY:
			if (dlgColor_bSaveSettingToRegistry ())
				vUpdateTick () ;
			break ;
		case	PSN_RESET:
			if (! dlgColor_bLoadRegistrySetting ())
				dlgColor_vLoadDefaultSetting () ;
			dlgColor_vSyncControls (hDlg) ;
			break ;
		default:
			break ;
		}
		break ;
	}
	return	(INT_PTR) 0 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

/*	�ɂイ��傭����
 * ������������������
 *
 *	���ϊ�����
 *  ��������
 */
INT_PTR
dlgColor_iOnDrawItem (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	LPDRAWITEMSTRUCT	lpDrawItem	= (LPDRAWITEMSTRUCT) lParam ;
	HWND		hWnd, hwndControl ;
	HDC			hDC ;
	int			nCenterX, nCenterY, nX, nY ;
	HPEN		hOldPen ;

	if (lpDrawItem->CtlType != ODT_BUTTON || lpDrawItem->CtlID != IDC_BUTTON_PREVIEW)
		return	(INT_PTR) FALSE ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SELECTFACE) ;
	if (hwndControl == NULL)
		return	(INT_PTR) FALSE ;

	hDC			= lpDrawItem->hDC ;
	hWnd		= lpDrawItem->hwndItem ;
	nCenterX	= (lpDrawItem->rcItem.left + lpDrawItem->rcItem.right)  / 2 ;
	nCenterY	= (lpDrawItem->rcItem.top  + lpDrawItem->rcItem.bottom) / 2 ;
	switch (_siSelectedColorFace) {
	case	0:
		{
			static const TCHAR	bufText []	= TEXT ("�ɂイ��傭����") ;
			SIZE		sz ;

			GetTextExtentPoint32 (hDC, bufText, ARRAYSIZE (bufText) - 1, &sz) ;
			nX			= nCenterX - sz.cx / 2 ;
			nY			= nCenterY - sz.cy / 2 ;
			vDrawTextWithColorFace (hDC, nX, nY,bufText, ARRAYSIZE (bufText) - 1, hWnd, &_srImeColorFaces [0]) ;

			hOldPen		= (HPEN) SelectObject (hDC, _shPen) ;
			MoveToEx (hDC, nX - 2, nY + sz.cy + 2, NULL) ;
			LineTo   (hDC, nX - 2, nY + sz.cy + 6) ;
			LineTo   (hDC, nX + sz.cx + 2, nY + sz.cy + 6) ;
			LineTo   (hDC, nX + sz.cx + 2, nY + sz.cy + 2) ;
			(void) SelectObject (hDC, hOldPen) ;
		}
		break ;
	case	1:
		{
			static const TCHAR	bufText1 []	= TEXT ("��") ;
			static const TCHAR	bufText2 []	= TEXT ("�ϊ�") ;
			static const TCHAR	bufText3 []	= TEXT ("����") ;
			SIZE	sz1, sz2, sz3 ;
			int		nHeight ;

			GetTextExtentPoint32 (hDC, bufText1, ARRAYSIZE (bufText1) - 1, &sz1) ;
			GetTextExtentPoint32 (hDC, bufText2, ARRAYSIZE (bufText2) - 1, &sz2) ;
			GetTextExtentPoint32 (hDC, bufText3, ARRAYSIZE (bufText3) - 1, &sz3) ;
			nHeight		= MAX (MAX (sz1.cy, sz2.cy), sz3.cy) ;
			nX			= nCenterX - (sz1.cx + sz2.cx + sz3.cx) / 2 ;
			nY			= nCenterY - nHeight / 2 ;
			vDrawTextWithColorFace (hDC, nX,					nY + nHeight - sz1.cy, bufText1, ARRAYSIZE (bufText1) - 1, hWnd, &_srImeColorFaces [0]) ;
			vDrawTextWithColorFace (hDC, nX + sz1.cx,			nY + nHeight - sz2.cy, bufText2, ARRAYSIZE (bufText2) - 1, hWnd, &_srImeColorFaces [1]) ;
			vDrawTextWithColorFace (hDC, nX + sz1.cx + sz2.cx,	nY + nHeight - sz3.cy, bufText3, ARRAYSIZE (bufText3) - 1, hWnd, &_srImeColorFaces [0]) ;

			hOldPen		= (HPEN) SelectObject (hDC, _shPen) ;
			MoveToEx (hDC, nX + sz1.cx - 2,				nY + nHeight + 2, NULL) ;
			LineTo   (hDC, nX + sz1.cx - 2,				nY + nHeight + 6) ;
			LineTo   (hDC, nX + sz1.cx + sz2.cx + 2,	nY + nHeight + 6) ;
			LineTo   (hDC, nX + sz1.cx + sz2.cx + 2,	nY + nHeight + 2) ;
			(void) SelectObject (hDC, hOldPen) ;
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgColor_vSyncControls (
	HWND			hDlg)
{
	HWND	hwndControl ;
	TCHAR	bufText [256] ;
	int		n;

	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_FORECOLOR,	_srImeColorFaces [_siSelectedColorFace].m_nTextColor) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_BACKCOLOR,	_srImeColorFaces [_siSelectedColorFace].m_nBackColor) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_ULCOLOR,		_srImeColorFaces [_siSelectedColorFace].m_nUnderLineColor) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_UNDERLINE,	_srImeColorFaces [_siSelectedColorFace].m_nUnderLineType) ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SELECTFACE) ;
	if (hwndControl != NULL) {
		ListView_SetSelectionMark (hwndControl, _siSelectedColorFace) ;
		ListView_SetItemState (hwndControl, _siSelectedColorFace, LVIS_SELECTED, LVIS_SELECTED) ;

		InvalidateRect (hwndControl, NULL, TRUE) ;
	}

	hwndControl	= GetDlgItem (hDlg, IDC_BUTTON_PREVIEW) ;
	if (hwndControl != NULL) {
		InvalidateRect (hwndControl, NULL, TRUE) ;
	}

	n	= _sntprintf (bufText, ARRAYSIZE(bufText)-1, TEXT("%s, %d point"), _sbufDefaultFont, _siDefaultFontSize) ;
	bufText [n]	= TEXT ('\0') ;
	SetDlgItemText (hDlg, IDC_EDIT_MINIBUFFERFONT, bufText) ;
	return ;
}

BOOL
dlgColor_bLoadRegistrySetting (void)
{
	HKEY	hSubKey ;
	BOOL	bRetval	= FALSE ;
	BYTE	rbStyles [ARRAYSIZE (_srImeColorFaces) * 4] ;
	int		i ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_STYLE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 		lResult ;
		DWORD		dwType, cbData ;
		const BYTE*	pbData ;

		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData != sizeof (rbStyles))
			goto	skip_error ;

		(void) RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, (BYTE*)rbStyles, &cbData) ;

		pbData	= rbStyles ;
		for (i = 0 ; i < ARRAYSIZE (_srImeColorFaces) ; i ++) {
			int		nTextColor, nBackColor, nUnderLineColor, nUnderLineType ;

			nTextColor		= *pbData ++ ;
			nTextColor		= bIsValidColor (nTextColor)? nTextColor : _srDefaultColorFaces [i].m_nTextColor ;
			_srImeColorFaces [i].m_nTextColor		= nTextColor ;
			nBackColor		= *pbData ++ ;
			nBackColor		= bIsValidColor (nBackColor)? nBackColor : _srDefaultColorFaces [i].m_nBackColor ;
			_srImeColorFaces [i].m_nBackColor		= nBackColor ;
			nUnderLineColor	= *pbData ++ ;
			nUnderLineColor	= bIsValidColor (nUnderLineColor)? nUnderLineColor : _srDefaultColorFaces [i].m_nUnderLineColor ;
			_srImeColorFaces [i].m_nUnderLineColor	= nUnderLineColor ;
			nUnderLineType	= *pbData ++ ;
			nUnderLineType	=  bIsValidLineType (nUnderLineType)? nUnderLineType : _srDefaultColorFaces [i].m_nUnderLineType ;
			_srImeColorFaces [i].m_nUnderLineType	= nUnderLineType ;
		}

		bRetval		= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	return	bRetval ;
}

void
dlgColor_vInitializeDefaultFontSetting (HWND hDlg)
{
	HKEY	hSubKey ;
//	BOOL	bRetval	= FALSE ;
	TCHAR	bufFace [LF_FACESIZE+1] ;
	int		iFontSize ;

	memset (bufFace, 0, sizeof (bufFace)) ;
	iFontSize	= 0 ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_STYLE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 		lResult ;
		DWORD		dwType, cbData ;

		cbData	= sizeof (bufFace) ;
		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_SZ && cbData < sizeof (bufFace)) {
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, (BYTE*)bufFace, &cbData) ;
			bufFace [LF_FACESIZE]	= TEXT ('\0') ;
		}
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			DWORD		dwFontSize ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, (BYTE*)&dwFontSize, &cbData) ;
			iFontSize	= (int) dwFontSize ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (bufFace [0] == TEXT ('\0') || iFontSize <= 0) {
		NONCLIENTMETRICS	param ;

		memset (&param, 0, sizeof (param)) ;
		param.cbSize	= sizeof (param) ;
		if (SystemParametersInfo (SPI_GETNONCLIENTMETRICS, param.cbSize, &param, 0)) {
			if (bufFace [0] == TEXT ('\0')) {
				memcpy (bufFace, param.lfMessageFont.lfFaceName, sizeof (TCHAR) * LF_FACESIZE) ;
				bufFace [LF_FACESIZE]	= TEXT ('\0') ;
			}
			if (iFontSize <= 0)
				iFontSize	= param.lfMessageFont.lfHeight ;
		} else {
			LOGFONT	lf ;

			memset (&lf, 0, sizeof (LOGFONT)) ;
			if (GetObject (GetStockObject (DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf) > 0) {
				if (bufFace [0] == TEXT ('\0')) {
					memcpy (bufFace, lf.lfFaceName, sizeof (TCHAR) * LF_FACESIZE) ;
					bufFace [LF_FACESIZE]	= TEXT ('\0') ;
				}
				if (iFontSize <= 0)
					iFontSize	= lf.lfHeight ;
			}
		}
	}
	/*	�|�C���g�T�C�Y�ɒ����B
	 */
	if (iFontSize < 0)
		iFontSize	= iFontHeight2PointSize (hDlg, iFontSize) ;
	lstrcpyn (_sbufDefaultFont, bufFace, LF_FACESIZE) ;
	_siDefaultFontSize	= iFontSize ;
	return ;
}

BOOL
dlgColor_bSaveSettingToRegistry (void)
{
	HKEY	hSubKey ;
	BYTE	rbStyles [ARRAYSIZE (_srImeColorFaces) * 4] ;
	int		i ;
	BOOL	bRetval	= FALSE ;
	BYTE*	pbData ;
	DWORD	dwPointSize ;

	pbData	= rbStyles ;
	for (i = 0 ; i < ARRAYSIZE (_srImeColorFaces) ; i ++) {
		*pbData ++	= (BYTE)_srImeColorFaces [i].m_nTextColor ;
		*pbData ++	= (BYTE)_srImeColorFaces [i].m_nBackColor ;
		*pbData ++	= (BYTE)_srImeColorFaces [i].m_nUnderLineColor ;
		*pbData ++	= (BYTE)_srImeColorFaces [i].m_nUnderLineType ;
	}

	if (! bCreateRegistryKey (REGPATH_STYLE, FALSE, &hSubKey))
		return	FALSE ;

	if (! RegSetValueEx (hSubKey, REGSUBKEY_COLORFACE, 0, REG_BINARY, (BYTE*) rbStyles, sizeof (rbStyles)) != ERROR_SUCCESS)
		bRetval	= FALSE ;
	if (_sbufDefaultFont [0] != TEXT ('\0')) {
		if (! RegSetValueEx (hSubKey, REGSUBKEY_DEFAULTFONT, 0, REG_SZ, (BYTE*) _sbufDefaultFont, (lstrlen (_sbufDefaultFont)+1) * sizeof (TCHAR)) != ERROR_SUCCESS)
			bRetval	= FALSE ;
	} else {
		RegDeleteKey (hSubKey, REGSUBKEY_DEFAULTFONT) ;
	}
	dwPointSize	= (DWORD) _siDefaultFontSize ;
	if (dwPointSize != 0) {
		if (! RegSetValueEx (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, 0, REG_DWORD, (BYTE*) &dwPointSize, sizeof (DWORD)) != ERROR_SUCCESS)
			bRetval	= FALSE ;
	} else {
		RegDeleteKey (hSubKey, REGSUBKEY_DEFAULTFONTSIZE) ;
	}
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

void
dlgColor_vLoadDefaultSetting (void)
{
	memcpy (_srImeColorFaces, _srDefaultColorFaces, sizeof (_srImeColorFaces)) ;
	return ;
}

BOOL
bIsValidColor (int nColorType)
{
	return	(nColorType < 0 || nColorType >= MAX_MYCOLOR) ? FALSE : TRUE ;
}

BOOL
bIsValidLineType (int nLineType)
{
	return	(nLineType < 0 || nLineType >= MAX_MYLINE)? FALSE : TRUE ;
}

/*
 */
void
vDrawTextWithColorFace (
	HDC			hDC,
	int			nX,
	int			nY,
	LPCTSTR		strText,
	int			nTextLen,
	HWND		hWnd,
	struct MYCOLORFACESET*	pColor)
{
	COLORREF	crForeColor, crBackColor, crTextBack, crBkBack, crLine ;
	HBITMAP		hLineBitmap ;
	HBRUSH		hBrush ;
	int			nLineWidth, nBkMode ;
	SIZE		sz ;

	crForeColor	= crGetImeColor (hWnd, pColor->m_nTextColor) ;
	crBackColor	= crGetImeColor (hWnd, pColor->m_nBackColor) ;

	crTextBack	= SetTextColor (hDC, crForeColor) ;
	crBkBack	= SetBkColor   (hDC, crBackColor) ;
	nBkMode		= SetBkMode	 (hDC, OPAQUE) ;
	GetTextExtentPoint32 (hDC, strText, nTextLen, &sz) ;
	TextOut (hDC, nX, nY, strText, nTextLen) ;

	hBrush	= hbrGetImeLineBrush (hWnd, pColor->m_nUnderLineColor, pColor->m_nUnderLineType, &crLine, &hLineBitmap, &nLineWidth) ;
	if (hBrush != NULL) {
		HBRUSH	hOldBrush ;

		hOldBrush		= (HBRUSH) SelectObject (hDC, hBrush) ;
		SetTextColor (hDC, crLine) ;
		PatBlt (hDC, nX, nY + sz.cy - nLineWidth, sz.cx, nLineWidth, PATCOPY) ;
		(void) SelectObject (hDC, hOldBrush) ;
		DeleteObject (hBrush) ;
	}
	if (hLineBitmap != NULL)
		DeleteObject (hLineBitmap) ;

	(void) SetTextColor (hDC, crTextBack) ;
	(void) SetBkColor   (hDC, crBkBack) ;
	(void) SetBkMode	(hDC, nBkMode) ;
	return ;
}

COLORREF
crGetImeColor (
	HWND	hwnd,
	int		nColor)
{
	static	const int		srnMyColorIndex2SysColorIndexTbl []	= {
		COLOR_BTNFACE,
		COLOR_BTNTEXT,
		COLOR_ACTIVEBORDER,
		COLOR_ACTIVECAPTION,
		COLOR_CAPTIONTEXT,
		COLOR_APPWORKSPACE,
		COLOR_WINDOW,
		COLOR_WINDOWTEXT,
		COLOR_DESKTOP,
		COLOR_INFOBK,
		COLOR_INFOTEXT,
		COLOR_WINDOWTEXT,
		COLOR_MENU,
		COLOR_MENUTEXT,
		COLOR_HIGHLIGHTTEXT,
		COLOR_HIGHLIGHT,
		COLOR_INACTIVEBORDER,
		COLOR_INACTIVECAPTION,
		COLOR_INACTIVECAPTIONTEXT,
	} ;
	HDC			hdc ;
	COLORREF	col ;

	switch (nColor) {
	case	MYCOLOR_TEXTAUTO:
	case	MYCOLOR_BACKAUTO:
		hdc	= GetDC (hwnd) ;
		col	= GetBkColor (hdc) ;
		ReleaseDC (hwnd, hdc) ;
		return	(nColor == MYCOLOR_BACKAUTO)? col : ~col ;
	case	MYCOLOR_BLACK:
		return	PALETTERGB (  0,   0,   0) ;
	case	MYCOLOR_DARKRED:
		return	PALETTERGB (128,   0,   0) ;
	case	MYCOLOR_DARKGREEN:
		return	PALETTERGB (  0, 128,   0) ;
	case	MYCOLOR_DARKYELLOW:
		return	PALETTERGB (128, 128,   0) ;
	case	MYCOLOR_DARKBLUE:
		return	PALETTERGB (  0,   0, 128) ;
	case	MYCOLOR_DARKPURPLE:
		return	PALETTERGB (128,   0, 128) ;
	case	MYCOLOR_DARKLIGHTBLUE:
		return	PALETTERGB (0,   128, 128) ;
	case	MYCOLOR_DARKGRAY:
		return	PALETTERGB (128, 128, 128) ;
	case	MYCOLOR_LIGHTGRAY:
		return	PALETTERGB (192, 192, 192) ;
	case	MYCOLOR_RED:
		return	PALETTERGB (255,   0,   0) ;
	case	MYCOLOR_GREEN:
		return	PALETTERGB (  0, 255,   0) ;
	case	MYCOLOR_YELLOW:
		return	PALETTERGB (255, 255,   0) ;
	case	MYCOLOR_BLUE:
		return	PALETTERGB (  0,   0, 255) ;
	case	MYCOLOR_PURPLE:
		return	PALETTERGB (255,   0, 255) ;
	case	MYCOLOR_LIGHTBLUE:
		return	PALETTERGB (  0, 255, 255) ;
	case	MYCOLOR_WHITE:
		return	PALETTERGB (255, 255, 255) ;
	default:
		if (MYCOLOR_SYSTEM <= nColor && nColor < MAX_MYCOLOR) {
			nColor	-= MYCOLOR_SYSTEM ;
			return	GetSysColor (srnMyColorIndex2SysColorIndexTbl [nColor]) ;
		}
		break ;
	}
	return	PALETTERGB (0, 0, 0) ;
}

HBRUSH
hbrGetImeLineBrush (
	HWND				hwnd,		/* [in] */
	int					nLineColor,	/* [in] */
	int					nLineType,	/* [in] */
	COLORREF*			pColBrush,	/* [out] */
	HBITMAP*			phBm,		/* [out] */
	int*				pnWidth)	/* [out] */
{
	/*	�_���̕`��Ɏg���p�^�[���B*/
	static const BYTE		srbDottedBrush []	= {
		0xAA, 0x00, 0xAA, 0x00, 0xAA, 0x00, 0xAA, 0x00,
		0xAA, 0x00, 0xAA, 0x00, 0xAA, 0x00, 0xAA, 0x00,
	} ;
	/*	�f�B�U���̕`��Ɏg���p�^�[���B*/
	static const BYTE		srbDitherBrush []	= {
		0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00,
		0xAA, 0x00, 0x55, 0x00, 0xAA, 0x00, 0x55, 0x00,
	} ;
	COLORREF	colBrush ;
	HBRUSH		hBrush	= NULL ;
	HBITMAP		hBitmap	= NULL ;

	if (pColBrush == NULL || phBm == NULL || pnWidth == NULL) {
		return	NULL ;
	}

	colBrush	= crGetImeColor (hwnd, nLineColor) ;
	switch (nLineType) {
	case	MYLINE_SOLID:
		*pnWidth	= 1 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_DOTTED:
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDottedBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		*pnWidth	= 1 ;
		break ;
	case	MYLINE_THICK_SOLID:
		*pnWidth	= 2 ;
		hBrush		= CreateSolidBrush (colBrush) ;
		break ;
	case	MYLINE_THIN_DITHER:
		*pnWidth	= 2 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_THICK_DITHER:
		*pnWidth	= 3 ;
		hBitmap		= CreateBitmap (8, 8, 1, 1, (LPBYTE)srbDitherBrush) ;
		hBrush		= CreatePatternBrush (hBitmap) ;
		break ;
	case	MYLINE_NO:
	default:
		*pnWidth	= 0 ;
		break ;
	}
	*pColBrush	= colBrush ;
	*phBm		= hBitmap ;
	return	hBrush ;
}

int
iPointSize2FontHeight (HWND hWnd, int iPointSize)
{
	int	iFontHeight	= 0 ;
	HDC	hDC ;

	if (iPointSize < 0)
		return	iPointSize ;

	hDC	= GetDC (hWnd) ;
	if (hDC != NULL) {
		iFontHeight = -MulDiv (iPointSize, GetDeviceCaps(hDC, LOGPIXELSY), 72) ;
		ReleaseDC (hWnd, hDC) ;
	}
	return	iFontHeight ;
}

int
iFontHeight2PointSize (HWND hWnd, int iFontHeight)
{
	int	iPointSize	= 0 ;
	HDC	hDC ;

	if (iFontHeight > 0)
		return	iFontHeight ;

	hDC	= GetDC (hWnd) ;
	if (hDC != NULL) {
		iPointSize	= -iFontHeight * 72 / GetDeviceCaps(hDC, LOGPIXELSY) ;
		ReleaseDC (hWnd, hDC) ;
	}
	return	iPointSize ;
}
