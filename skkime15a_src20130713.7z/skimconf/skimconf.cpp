// skimconf.cpp : �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//
#include "stdafx.h"
#include "skimconf.h"
#include "resource.h"
#include "../common/nfunc.h"
#include "../common/keymask.h"
#include "TCommuSession.h"
#include "version.h"

#if !defined (ICC_STANDARD_CLASSES)
#define	ICC_STANDARD_CLASSES	0x4000
#endif

#define	MAX_PAGES		16

#define	SEPCHAR	TEXT(',')

extern	INT_PTR	CALLBACK	DlgGenericProc		(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgKeybindProc		(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgConversionProc	(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgDictioanryProc	(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgColorProc		(HWND, UINT, WPARAM, LPARAM) ;
extern	BOOL				dlgDictionary_bSyncSkkiserv (void) ;


static	struct TPropPageSheetConfig			_srPageSheetTbl []	= {
	{ _T("�S��"),						DlgGenericProc,			IDD_PROPPAGE_GENERIC, },
	{ _T("�L�[�ݒ�"),					DlgKeybindProc,			IDD_PROPPAGE_KEYBIND, },
	{ _T("�ϊ��ݒ�"),					DlgConversionProc,		IDD_PROPPAGE_CONVERSION, },
	{ _T("�����ݒ�"),					DlgDictioanryProc,		IDD_PROPPAGE_DICTIONARY, },
	{ _T("�O��"),						DlgColorProc,			IDD_PROPPAGE_COLOR, },
} ;

static	DWORD	_dwTick	= 0 ;

/*
 */
int	APIENTRY
_tWinMain (
	HINSTANCE	hInstance,
	HINSTANCE	hPrevInstance,
	LPTSTR		lpCmdLine,
	int			nCmdShow)
{
	UNREFERENCED_PARAMETER (hPrevInstance) ;
	UNREFERENCED_PARAMETER (lpCmdLine) ;
	UNREFERENCED_PARAMETER (nCmdShow) ;

	// TODO: �����ɃR�[�h��}�����Ă��������B
	INITCOMMONCONTROLSEX	initCtrls ;
	HPROPSHEETPAGE	rPages [MAX_PAGES] ;
	PROPSHEETHEADER	psh ;
	int		i ;
	HKEY	hSubKey ;
	DWORD	dwTick ;
	HWND	hWnd ;

	/*	�Q�d�N���̃`�F�b�N�B
	 */
	hWnd	= FindWindow (TEXT ("#32770"), SKKIME_VERSION TEXT("�̃v���p�e�B")) ;
	if (hWnd != NULL) {
		SetForegroundWindow (hWnd) ;
		return	0 ;
	}

//	memset (&initCtrls, 0, sizeof (initCtrls)) ;
	initCtrls.dwSize	= sizeof (initCtrls) ;
	initCtrls.dwICC		= ICC_WIN95_CLASSES ;	// ICC_LISTVIEW_CLASSES | ICC_STANDARD_CLASSES ;
	InitCommonControlsEx (&initCtrls) ;

//	memset(&psh, 0, sizeof(psh));
	psh.dwSize		= sizeof (psh) ;
	psh.dwFlags		= PSH_PROPTITLE ;	// PSH_PROPTITLE | PSH_USECALLBACK ;
	psh.hwndParent	= NULL ;

	psh.hInstance	= hInstance ;
//	psh.pszIcon		= NULL ;
	psh.pszCaption	= SKKIME_VERSION ;
	psh.nPages		= 0 ;
	psh.nStartPage	= 0 ;
	psh.phpage		= rPages ;

	for (i = 0 ; i < ARRAYSIZE (_srPageSheetTbl) ; i ++) {
		if (! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [i], NULL))
			return	FALSE ;
	}

	dwTick	= 0 ;
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData ;
		LONG	lResult ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		RegCloseKey (hSubKey) ;
	}
	_dwTick	= dwTick ;

	(void) TCommunicateSession_bClassInit () ;
	if (psh.nPages > 0) {
		/* Tick �� update ����B*/
		INT_PTR	n = PropertySheet (&psh) ;

		if (n > 0) {
			vUpdateTick () ;
			dlgDictionary_bSyncSkkiserv () ;
		}
	}
	return	0 ;
}

BOOL
bNewPageSheet (
	LPPROPSHEETHEADER				ppsh,
	HINSTANCE						hInstance,
	struct TPropPageSheetConfig*	pConfig,
	void*							pvParam)
{
	PROPSHEETPAGE		psp ;

	/* �����̃`�F�b�N�B*/
	if (ppsh == NULL || pConfig == NULL)
		return	FALSE ;
	if (ppsh->nPages >= MAX_PAGES)
		return	FALSE ;

	/* �v���p�e�B�V�[�g�Ƀy�[�W��ǉ�����B*/
	psp.dwSize		= sizeof (psp) ;
	psp.dwFlags		= PSP_DEFAULT | PSP_USETITLE ;
	psp.hInstance	= hInstance ;
	psp.pszTemplate	= MAKEINTRESOURCE(pConfig->m_nResId) ;
	psp.pszIcon		= 0 ;
	psp.pfnDlgProc	= pConfig->m_pDialogProc ;
	psp.pfnCallback	= 0 ;
	psp.pszTitle	= pConfig->m_ptszTitle ;
	psp.lParam		= (LPARAM) pvParam ;
	ppsh->phpage [ppsh->nPages]	= CreatePropertySheetPage (&psp) ;
	if (ppsh->phpage [ppsh->nPages]){
		ppsh->nPages	++ ;
		return	TRUE ;
	}
	return FALSE ;
}

/*========================================================================
 *	public functions
 */
static LPCTSTR _srpFunctionNameTable[NUM_SELECTABLE_FUNCTIONS] = {
#ifndef ENGLISH_MESSAGE
	// ����p�̓��ʂȒl
	TEXT("-"),											// 0x00 (invalid-char)

	// ��{�R�}���h
	TEXT("���ړ��� (self-insert-character)"),			// 0x01

	TEXT("�͈͎w��J�n (set-mark-command)"),			// 0x02 ^@
	TEXT("�s���� (beginning-of-line)"),					// 0x03 ^A
	TEXT("�O�̕����� (backward-char)"),					// 0x04 ^B
	NULL,	// TEXT("mode-specific-command-prefix"),	// 0x05 ^C	���g�p
	TEXT("�폜 (delete-char)"),							// 0x06 ^D
	TEXT("�s���� (end-of-line)"),						// 0x07 ^E
	TEXT("���̕����� (foward-char)"),					// 0x08 ^F
	TEXT("���f (keyboard-quit)"),						// 0x09 ^G
	TEXT("��� (backward-delete-char)"),				// 0x0A ^H
	NULL,	// TEXT("indent-for-tab-command"),			// 0x0B ^I	���g�p
	NULL,	// TEXT("newline-and-indent"),				// 0x0C ^J	���g�p
	TEXT("�s���܂ō폜 (kill-line)"),					// 0x0D ^K
	NULL,	// TEXT("recenter"),						// 0x0E ^L	���g�p
	TEXT("���s (newline)"),								// 0x0F ^M
	NULL,	// TEXT("next-line"),						// 0x10 ^N	���g�p
	NULL,	// TEXT("open-line"),						// 0x11 ^O	���g�p
	NULL,	// TEXT("previous-line"),					// 0x12 ^P	���g�p
	NULL,	// TEXT("quated-insert"),					// 0x13 ^Q	���g�p
	NULL,	// TEXT("isearch-backward"),				// 0x14 ^R	���g�p
	NULL,	// TEXT("isearch-forward"),					// 0x15 ^S	���g�p
	TEXT("�������� (transpose-chars)"),					// 0x16 ^T
	NULL,	// TEXT("universal-argument"),				// 0x17 ^U	���g�p
	NULL,	// TEXT("scroll-up"),						// 0x18 ^V	���g�p
	TEXT("�؂��� (kill-region)"),						// 0x19 ^W
	TEXT("�R�s�[ (kill-ring-save)"),					// 0x1A M-w
	NULL,	// TEXT("control-x-prefix"),				// 0x1B ^X	���g�p
	TEXT("����t�� (yank)"),							// 0x1C ^Y
	NULL,	// TEXT("scroll-down"),						// 0x1D M-v	���g�p
	NULL,	// TEXT("prefix-command"),					// 0x1E ^[	���g�p
	TEXT("�ҏW�I�� (exit-recursive-edit)"),				// 0x1F
	TEXT("�ҏW���f (abort-recursive-edit)"),			// 0x20 ^]
	NULL,	// TEXT("���ɖ߂� (undo)"),					// 0x21 ^_	���g�p
	TEXT("��P��߂� (backward-word)"),					// 0x22
	TEXT("��P��i�� (forward-word)"),					// 0x23

	TEXT("���{����͂̐ؑ� (toggle-ime)"),				// 0x24 ^'\\'
	TEXT("���{����̓I�� (imemode-on)"),				// 0x25
	TEXT("���{����̓I�t (imemode-off)"),				// 0x26

	NULL,												// 0x27
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x28 - 0x2F

	// non-interactive functions
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x30 - 0x37
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x38 - 0x3F

	// SKK�� ��{�R�}���h
	TEXT("���͏��� (skk-insert)"),						// 0x40
	TEXT("�m�� (skk-kakutei)"),							// 0x41
	TEXT("�ϊ� (skk-start-henkan)"),					// 0x42
	TEXT("�P���� (skk-try-completion)"),				// 0x43
	TEXT("��� (skk-delete-backward-char)"),			// 0x44
	TEXT("�O��� (skk-previous-candidate)"),			// 0x45
	TEXT("�Ђ炪��/�J�^�J�i (skk-toggle-char)"),		// 0x46
	TEXT("�Ђ炪�ȃ��[�h (skk-mode)"),					// 0x47
	TEXT("�p�����[�h (skk-latin-mode)"),				// 0x48
	TEXT("�S�p�p�����[�h (skk-jisx0208-lat)"),			// 0x49
	TEXT("�ڈ�ڒn (skk-set-henkan-point)"),			// 0x4A
	TEXT("�P��폜 (skk-purge-from-jisyo)"),			// 0x4B
	TEXT("�p�P��ϊ����[�h (skk-abbrev-mode)"),			// 0x4C
	TEXT("�����R�[�h�\�� (skk-display-code)"),			// 0x4D
	TEXT("���t���� (skk-today)"),						// 0x4E
	TEXT("�����R�[�h���� (skk-input-by-code)"),			// 0x4F
	NULL,	// TEXT("���ɖ߂� (skk-undo)"),				// 0x50	���g�p
	TEXT("�⊮���s (skk-comp-do)"),						// 0x51
	TEXT("�m��ϊ� (skk-kakutei-henkan)"),				// 0x52
	NULL,	// TEXT("skk-undo-kakutei-henkan"),			// 0x53	���g�p
	TEXT("�S�p�p������ (skk-jisx0208-latin-i)"),		// 0x54
	TEXT("�p���ɕϊ� (skk-latin-henkan)"),				// 0x55
	TEXT("�J���}���� (skk-abbrev-comma)"),				// 0x56
	TEXT("�s���I�h���� (skk-abbrev-period)"),			// 0x57
	TEXT("��Ǔ_�؂�ւ� (skk-toggle-kutouten)"),		// 0x58
	TEXT("�Ђ炪��/���p�J�i (skk-toggle-kata)"),		// 0x59
	TEXT("���p�J�i�ɕϊ� (skk-jisx0201-henkan)"),		// 0x5A
	TEXT("���p�J�i���[�h (skk-jisx0201-mode)"),			// 0x5B
	TEXT("���p�J�i/����p�� (skk-toggle-jisx0201)"),	// 0x5C

	NULL, NULL, NULL,									// 0x5D - 0x5F
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x60 - 0x67
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x68 - 0x6F

	// SKK�� non-interactive functions
	TEXT("�ہE��_���� (skk-current-kuten)"),			// 0x70
	TEXT("�_�E�Ǔ_���� (skk-current-touten)"),			// 0x71

	NULL, NULL, NULL, NULL, NULL, NULL,					// 0x72 - 0x77
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x78 - 0x7F
#else
	// ����p�̓��ʂȒl
	TEXT("-"),											// 0x00 (invalid-char)

	// ��{�R�}���h
	TEXT("self-insert-character"),						// 0x01 (���ڕ�������)

	TEXT("set-mark-command"),							// 0x02 ^@
	TEXT("beginning-of-line"),							// 0x03 ^A
	TEXT("backward-char"),								// 0x04 ^B
	NULL,	// TEXT("mode-specific-command-prefix"),	// 0x05 ^C	���g�p
	TEXT("delete-char"),								// 0x06 ^D
	TEXT("end-of-line"),								// 0x07 ^E
	TEXT("foward-char"),								// 0x08 ^F
	TEXT("keyboard-quit"),								// 0x09 ^G
	TEXT("backward-delete-char"),						// 0x0A ^H
	NULL,	// TEXT("indent-for-tab-command"),			// 0x0B ^I	���g�p
	NULL,	// TEXT("newline-and-indent"),				// 0x0C ^J	���g�p
	TEXT("kill-line"),									// 0x0D ^K
	NULL,	// TEXT("recenter"),						// 0x0E ^L	���g�p
	TEXT("newline"),									// 0x0F ^M
	NULL,	// TEXT("next-line"),						// 0x10 ^N	���g�p
	NULL,	// TEXT("open-line"),						// 0x11 ^O	���g�p
	NULL,	// TEXT("previous-line"),					// 0x12 ^P	���g�p
	NULL,	// TEXT("quated-insert"),					// 0x13 ^Q	���g�p
	NULL,	// TEXT("isearch-backward"),				// 0x14 ^R	���g�p
	NULL,	// TEXT("isearch-forward"),					// 0x15 ^S	���g�p
	TEXT("transpose-chars"),							// 0x16 ^T
	NULL,	// TEXT("universal-argument"),				// 0x17 ^U	���g�p
	NULL,	// TEXT("scroll-up"),						// 0x18 ^V	���g�p
	TEXT("kill-region"),								// 0x19 ^W
	TEXT("kill-ring-save"),								// 0x1A M-w
	NULL,	// TEXT("control-x-prefix"),				// 0x1B ^X	���g�p
	TEXT("yank"),										// 0x1C ^Y
	NULL,	// TEXT("scroll-down"),						// 0x1D M-v	���g�p
	NULL,	// TEXT("prefix-command"),					// 0x1E ^[	���g�p
	TEXT("exit-recursive-edit"),						// 0x1F
	TEXT("abort-recursive-edit"),						// 0x20 ^]
	NULL,	// TEXT("undo"),							// 0x21 ^_	���g�p
	TEXT("backward-word"),								// 0x22
	TEXT("forward-word"),								// 0x23

	TEXT("toggle-ime"),									// 0x24 ^'\\'
	TEXT("imemode-on"),									// 0x25
	TEXT("imemode-off"),								// 0x26

	NULL,												// 0x27
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x28 - 0x2F

	// non-interactive functions
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x30 - 0x37
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x38 - 0x3F

	// SKK�� ��{�R�}���h
	TEXT("skk-insert"),									// 0x40
	TEXT("skk-kakutei"),								// 0x41
	TEXT("skk-start-henkan"),							// 0x42
	TEXT("skk-try-completion"),							// 0x43
	TEXT("skk-delete-backward-char"),					// 0x44
	TEXT("skk-previous-candidate"),						// 0x45
	TEXT("skk-toggle-characters"),						// 0x46
	TEXT("skk-mode"),									// 0x47
	TEXT("skk-latin-mode"),								// 0x48
	TEXT("skk-jisx0208-latin-mode"),					// 0x49
	TEXT("skk-set-henkan-point-subr"),					// 0x4A
	TEXT("skk-purge-from-jisyo"),						// 0x4B
	TEXT("skk-abbrev-mode"),							// 0x4C
	TEXT("skk-display-code-for-char-at-point"),			// 0x4D
	TEXT("skk-today"),									// 0x4E
	TEXT("skk-input-by-code-or-menu"),					// 0x4F
	NULL,	// TEXT("skk-undo"),						// 0x50	���g�p
	TEXT("skk-comp-do"),								// 0x51
	TEXT("skk-kakutei-henkan"),							// 0x52	�H
	NULL,	// TEXT("skk-undo-kakutei-henkan"),			// 0x53	���g�p
	TEXT("skk-jisx0208-latin-insert"),					// 0x54
	TEXT("skk-latin-henkan"),							// 0x55
	TEXT("skk-abbrev-comma"),							// 0x56
	TEXT("skk-abbrev-period"),							// 0x57
	TEXT("skk-toggle-kutouten"),						// 0x58
	TEXT("skk-toggle-katakana"),						// 0x59
	TEXT("skk-jisx0201-henkan"),						// 0x5A
	TEXT("skk-jisx0201-mode"),							// 0x5B
	TEXT("skk-toggle-jisx0201"),						// 0x5C

	NULL, NULL, NULL,									// 0x5D - 0x5F
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x60 - 0x67
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x68 - 0x6F

	// SKK�� non-interactive functions
	TEXT("skk-current-kuten"),							// 0x70
	TEXT("skk-current-touten"),							// 0x71

	NULL, NULL, NULL, NULL, NULL, NULL,					// 0x72 - 0x77
	NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,		// 0x78 - 0x7F
#endif
};

static LPCTSTR _rVirtualKeyCodeNames[] = {
	NULL /* 00 */,			TEXT("LButton"),		TEXT("RButton"),		TEXT("Cancel"),
	TEXT("MButton"),		TEXT("XButton1"),		TEXT("XButton2"),		NULL /* 07 */,
	TEXT("Backspace"),		TEXT("Tab"),			NULL /* Reserved 0A */,	NULL /* Reserved 0B */,
	TEXT("Clear"),			TEXT("Enter"),			NULL /* 0E */,			NULL /* 0F */,
	TEXT("Shift"),			TEXT("Ctrl"),			TEXT("Alt"),			TEXT("Pause"),
	TEXT("Caps Lock"),		TEXT("Kana"),			NULL /* 16 */,			TEXT("Junja"),
	TEXT("Final"),			TEXT("Alt-Kanji"),		NULL /* 1A */,			TEXT("Esc"),
	TEXT("Henkan"),			TEXT("Muhenkan"),		TEXT("Accept"),			TEXT("Mode Change"),
	TEXT("Space"),			TEXT("Page Up"),		TEXT("Page Down"),		TEXT("End"),
	TEXT("Home"),			TEXT("Left"),			TEXT("Up"),				TEXT("Right"),
	TEXT("Down"),			TEXT("Select"),			TEXT("Print"),			TEXT("Execute"),
	TEXT("Print Screen"),	TEXT("Insert"),			TEXT("Delete"),			TEXT("Help"),
	TEXT("0"),				TEXT("1"),				TEXT("2"),				TEXT("3"),
	TEXT("4"),				TEXT("5"),				TEXT("6"),				TEXT("7"),
	TEXT("8"),				TEXT("9"),				NULL /* 3A */,			NULL /* 3B */,
	NULL /* 3C */,			NULL /* 3D */,			NULL /* 3E */,			NULL /* 3F */,
	NULL /* 40 */,			TEXT("A"),				TEXT("B"),				TEXT("C"),
	TEXT("D"),				TEXT("E"),				TEXT("F"),				TEXT("G"),
	TEXT("H"),				TEXT("I"),				TEXT("J"),				TEXT("K"),
	TEXT("L"),				TEXT("M"),				TEXT("N"),				TEXT("O"),
	TEXT("P"),				TEXT("Q"),				TEXT("R"),				TEXT("S"),
	TEXT("T"),				TEXT("U"),				TEXT("V"),				TEXT("W"),
	TEXT("X"),				TEXT("Y"),				TEXT("Z"),				TEXT("Left Windows"),
	TEXT("Right Windows"),	TEXT("Applications"),	NULL /* Reserved 5E */,	TEXT("Sleep"),
	TEXT("Numpad 0"),		TEXT("Numpad 1"),		TEXT("Numpad 2"),		TEXT("Numpad 3"),
	TEXT("Numpad 4"),		TEXT("Numpad 5"),		TEXT("Numpad 6"),		TEXT("Numpad 7"),
	TEXT("Numpad 8"),		TEXT("Numpad 9"),		TEXT("Numpad *"),		TEXT("Numpad +"),
	TEXT("Numpad Enter"),	TEXT("Numpad -"),		TEXT("Numpad ."),		TEXT("Numpad /"),
	TEXT("F1"),				TEXT("F2"),				TEXT("F3"),				TEXT("F4"),
	TEXT("F5"),				TEXT("F6"),				TEXT("F7"),				TEXT("F8"),
	TEXT("F9"),				TEXT("F10"),			TEXT("F11"),			TEXT("F12"),
	TEXT("F13"),			TEXT("F14"),			TEXT("F15"),			TEXT("F16"),
	TEXT("F17"),			TEXT("F18"),			TEXT("F19"),			TEXT("F20"),
	TEXT("F21"),			TEXT("F22"),			TEXT("F23"),			TEXT("F24"),
	NULL /* 88 */,			NULL /* 89 */,			NULL /* 8A */,			NULL /* 8B */,
	NULL /* 8C */,			NULL /* 8D */,			NULL /* 8E */,			NULL /* 8F */,
	TEXT("Num Lock"),		TEXT("Scroll Lock"),	NULL /* OEM 92 */,		NULL /* OEM 93 */,
	NULL /* OEM 94 */,		NULL /* OEM 95 */,		NULL /* OEM 96 */,		NULL /* 97 */,
	NULL /* 98 */,			NULL /* 99 */,			NULL /* 9A */,			NULL /* 9B */,
	NULL /* 9C */,			NULL /* 9D */,			NULL /* 9E */,			NULL /* 9F */,
	TEXT("Left Shift"),		TEXT("Right Shift"),	TEXT("Left Ctrl"),		TEXT("Right Ctrl"),
	TEXT("Left Alt"),		TEXT("Right Alt"),		TEXT("Browser Back"),	TEXT("Browser Forward"),
	TEXT("Browser Refresh"),	TEXT("Browser Stop"),	TEXT("Browser Search"),	TEXT("Browser Favorites"),
	TEXT("Browser Home"),	TEXT("Volume Mute"),	TEXT("Volume Down"),	TEXT("Volume Up"),
	TEXT("Next Track"),		TEXT("Previous Track"),	TEXT("Media Stop"),		TEXT("Media Play/Pause"),
	TEXT("Launch Mail"),	TEXT("Launch Select Media"),	TEXT("Launch Application 1"),	TEXT("Launch Application 2"),
	NULL /* Reserved B8 */,	NULL /* Reserved B9 */,	TEXT("OEM 1 (;:)"),		TEXT("OEM +"),
	TEXT("OEM ,"),			TEXT("OEM -"),			TEXT("OEM ."),			TEXT("OEM 2 (/?)"),
	TEXT("OEM 3 (`~)"),		NULL /* Reserved C1 */,	NULL /* Reserved C2 */,	NULL /* Reserved C3 */,
	NULL /* Reserved C4 */,	NULL /* Reserved C5 */,	NULL /* Reserved C6 */,	NULL /* Reserved C7 */,
	NULL /* Reserved C8 */,	NULL /* Reserved C9 */,	NULL /* Reserved CA */,	NULL /* Reserved CB */,
	NULL /* Reserved CC */,	NULL /* Reserved CD */,	NULL /* Reserved CE */,	NULL /* Reserved CF */,
	NULL /* Reserved D0 */,	NULL /* Reserved D1 */,	NULL /* Reserved D2 */,	NULL /* Reserved D3 */,
	NULL /* Reserved D4 */,	NULL /* Reserved D5 */,	NULL /* Reserved D6 */,	NULL /* Reserved D7 */,
	NULL /* D8 */,			NULL /* D9 */,			NULL /* DA */,			TEXT("OEM 4 ([{)"),
	TEXT("OEM 5 (\\|)"),	TEXT("OEM 6 (]})"),		TEXT("OEM 7 (\'\")"),	TEXT("OEM 8"),
	NULL /* Reserved E0 */,	TEXT("OEM AX"),			TEXT("OEM 102"),		TEXT("ICO Help"),
	TEXT("ICO 00"),			TEXT("Process"),		TEXT("ICO Clear"),		TEXT("Packet"),
	NULL /* E8 */,			TEXT("OEM Reset"),		TEXT("OEM Jump"),		TEXT("OEM PA1"),
	TEXT("OEM PA2"),		TEXT("OEM PA3"),		TEXT("OEM Wsctrl"),		TEXT("OEM Cusel"),
	TEXT("OEM Attn"),		TEXT("OEM Finish"),		TEXT("OEM Copy"),		TEXT("Hankaku"),
	TEXT("Zenkaku"),		TEXT("OEM Backtab"),	TEXT("Attn"),			TEXT("CrSel"),
	TEXT("ExSel"),			TEXT("Erase EOF"),		TEXT("Play"),			TEXT("Zoom"),
	NULL /* Reserved FC */,	TEXT("PA1"),			TEXT("OEM Clear"),		NULL /* FF */,
};

int
iShortStringCopy (
	LPWSTR		pszBuffer,
	int			nBufferSize,
	LPCWSTR		pwString,
	int			nStringLen)
{
	LPWSTR	pwDest, pwDestEnd ;
	LPCWSTR	pwSrc,	pwSrcEnd ;

	pwDest		= pszBuffer ;
	pwSrc		= pwString ;
	pwSrcEnd	= pwString + nStringLen ;
	if (nBufferSize < nStringLen) {
		pwDestEnd	= pszBuffer + nBufferSize - 3 ;
		while (pwDest < pwDestEnd && pwSrc < pwSrcEnd)
			*pwDest ++	= *pwSrc ++ ;
		pwDestEnd	= pszBuffer + nBufferSize ;
		pwSrc		= L"..." ;
		while (pwDest < pwDestEnd && *pwSrc != L'\0')
			*pwDest ++	= *pwSrc ++ ;
	} else {
		pwDestEnd	= pszBuffer + nBufferSize ;
		while (pwDest < pwDestEnd && pwSrc < pwSrcEnd)
			*pwDest ++	= *pwSrc ++ ;
	}
	return	pwDest - pszBuffer ;
}

int
iString2PrintableString (
	LPTSTR		pszBuffer,
	int			nBufferSize,
	LPCWSTR		pwString,
	int			nStringLen)
{
	LPCWSTR	pwSrc,  pwSrcEnd ;
	LPTSTR	pwDest, pwDestEnd ;

	pwDest		= pszBuffer ;
	pwDestEnd	= pszBuffer + nBufferSize ;
	pwSrc		= pwString ;
	pwSrcEnd	= pwString + nStringLen ;
#define	SAFE_COPY(dest,destend,chara)	if ((dest)<(destend)) { *(dest) = (chara) ; (dest) ++ ; }
	while (pwDest < pwDestEnd && pwSrc < pwSrcEnd) {
		if (*pwSrc <= 0x20 || *pwSrc == 0x7F) {
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('\\')) ;
			if (*pwSrc >= 64)
				SAFE_COPY (pwDest, pwDestEnd, TEXT ('0') + (*pwSrc / 64)) ;
			if (*pwSrc >= 8)
				SAFE_COPY (pwDest, pwDestEnd, TEXT ('0') + (0x07 & (*pwSrc / 8))) ;
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('0') + (0x07 & *pwSrc)) ;
		} else if (*pwSrc == TEXT ('\\')) {
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('\\')) ;
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('\\')) ;
		} else {
			SAFE_COPY (pwDest, pwDestEnd, *pwSrc) ;
		}
		pwSrc	++ ;
	}
#undef	SAFE_COPY
	if (pwDest < pwDestEnd)
		*pwDest	= TEXT ('\0') ;
	return	pwDest - pszBuffer ;
}


/*
int
TestConfig_iKeyList2String (
	LPTSTR		pstrBuffer,
	int			nBufferSize,
	LPCWSTR		pwKey)
{
	TCHAR	szBuffer [64] ;
	LPTSTR	pDest ;
	LPCTSTR	pDestEnd ;
	LPTSTR	pSrc ;

	if (pwKey == NULL || pstrBuffer == NULL || nBufferSize <= 0)
		return	0 ;

	pDest		= pstrBuffer ;
	pDestEnd	= pstrBuffer + nBufferSize ;
	while (pDest < pDestEnd && *pwKey != TEXT ('\0')) {
		vKey2String (szBuffer, ARRAYSIZE (szBuffer), *pwKey) ;
		szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;

		pSrc	= szBuffer ;
		while (pSrc != TEXT ('\0') && pDest < pDestEnd) {
			*pDest ++	= *pSrc ++ ;
		}
		pwKey	++ ;
	}
	if (pDest < pDestEnd)
		*pDest	= TEXT ('\0') ;
	return	pDest - pstrBuffer ;
}
*/

void
vKey2String (
	LPTSTR		pstrBuffer,
	int			nBufferSize,
	UINT		uKey)
{
	/*
	static LPCTSTR	rpFormat []	= {
		TEXT ("[%s]"), TEXT ("[C-%s]"), TEXT ("[S-%s]"),
	} ;
	*/

	if (/*0 <= uKey &&*/ uKey < 0x20) {
		wnsprintf (pstrBuffer, nBufferSize, TEXT ("\\C-%c"), TEXT ("@abcdefghijklmnopqrstuvwxyz[\\]^_") [uKey]) ;
		return ;
	}
	if (uKey == 0x20) {
		lstrcpyn (pstrBuffer, TEXT ("\\0x20"), nBufferSize) ;
		return ;
	}
	if (0x20 < uKey && uKey < 0x7F) {
		wnsprintf (pstrBuffer, nBufferSize, TEXT ("%c"), uKey) ;
		return ;
	}
	if (uKey == 0x7F) {
		lstrcpyn (pstrBuffer, TEXT ("\\x7F"), nBufferSize) ;
		return ;
	}
	/*
	if (0x80 <= uKey && uKey < SIZE_MYKEYMAP) {
		register int	nMajor, nMinor ;
		nMajor	= (uKey - 0x80) / NUM_BIND_PER_MYSPECIAL_KEY ;
		nMinor	= (uKey - 0x80) % NUM_BIND_PER_MYSPECIAL_KEY ;
		wsprintf (pstrBuffer, nBufferSize, rpFormat [nMinor], srVkKeyBinds [nMajor].m_pszText) ;
		return ;
	}
	*/
	lstrcpyn (pstrBuffer, TEXT ("undefined"), nBufferSize) ;
	return ;
}

void
vKey2StringEx (
	LPTSTR		pstrBuffer,
	int			nBufferSize,
	UINT		uKeyCode,
	UINT		uKeyMask)
{
	TCHAR	buf [256] ;
	TCHAR*	pbuf ;
	UINT	uMask ;

	pbuf	= buf ;
	if (uKeyMask & KEYMASK_CONTROL) {
		uMask	= uKeyMask & KEYMASK_CONTROL ;
		if (uMask == KEYMASK_CONTROL) {
			lstrcpy (pbuf, TEXT ("Ctrl-")) ;
		} else if (uMask == KEYMASK_LCONTROL) {
			lstrcpy (pbuf, TEXT ("Left Ctrl-")) ;
		} else {
			lstrcpy (pbuf, TEXT ("Right Ctrl-")) ;
		}
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & KEYMASK_SHIFT) {
		uMask	= uKeyMask & KEYMASK_SHIFT ;
		if (uMask == KEYMASK_SHIFT) {
			lstrcpy (pbuf, TEXT ("Shift-")) ;
		} else if (uMask == KEYMASK_LSHIFT) {
			lstrcpy (pbuf, TEXT ("Left Shift-")) ;
		} else {
			lstrcpy (pbuf, TEXT ("Right Shift-")) ;
		}
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & (KEYMASK_LMENU | KEYMASK_RMENU)) {
		uMask	= uKeyMask & KEYMASK_MENU ;
		if (uMask == KEYMASK_MENU) {
			lstrcpy (pbuf, TEXT ("Alt-")) ;
		} else if (uMask == KEYMASK_LMENU) {
			lstrcpy (pbuf, TEXT ("Left Alt-")) ;
		} else {
			lstrcpy (pbuf, TEXT ("Right Alt-")) ;
		}
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & KEYMASK_NUMLOCK) {
		lstrcpy (pbuf, TEXT ("NumLock-")) ;
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & KEYMASK_SCROLL) {
		lstrcpy (pbuf, TEXT ("ScrollLock-")) ;
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyCode >= ARRAYSIZE (_rVirtualKeyCodeNames) || _rVirtualKeyCodeNames [uKeyCode] == NULL) {
		TCHAR	buf2 [32] ;
		int		n ;
		n	= wnsprintf (buf2, ARRAYSIZE (buf2) - 1, TEXT ("\\x%02X"), uKeyCode) ;
		buf2 [n]	= TEXT ('\0') ;
		lstrcpy (pbuf, buf2) ;
	} else {
		lstrcpy (pbuf, _rVirtualKeyCodeNames [uKeyCode]) ;
	}
	lstrcpyn (pstrBuffer, buf, nBufferSize) ;
	return ;
}

BOOL
bGetKeyFuncName (
	LPTSTR		pBuffer,
	int			nBufferSize,
	int			nFuncNo)
{
	if (pBuffer == NULL || nBufferSize <= 0)
		return	FALSE ;

	if (0 <= nFuncNo && nFuncNo < ARRAYSIZE (_srpFunctionNameTable)) {
		int		n ;

		if (_srpFunctionNameTable [nFuncNo] == NULL)
			return	FALSE ;

		n	= lstrlen (_srpFunctionNameTable [nFuncNo]) ;
		if (n >= nBufferSize) {
			LPTSTR	pDest, pDestEnd ;
			LPCTSTR	pSrc ;

			pDest		= pBuffer ;
			pDestEnd	= pBuffer + nBufferSize - 4 ;
			pSrc		= _srpFunctionNameTable [nFuncNo] ;
			while (pDest < pDestEnd && *pSrc != TEXT ('\0'))
				*pDest ++	= *pSrc ++ ;

			pSrc		= TEXT ("...") ;
			pDestEnd	= pBuffer + nBufferSize ;
			while (pDest < pDestEnd && *pSrc != TEXT ('\0'))
				*pDest ++	= *pSrc ++ ;
			if (pDest < pDestEnd)
				*pDest = TEXT ('\0') ;
		} else {
			lstrcpyn (pBuffer, _srpFunctionNameTable [nFuncNo], nBufferSize) ;
		}
	}  else {
		if (nFuncNo != NFUNC_INVALID_CHAR) {
			pBuffer [0]	= TEXT ('\0') ;
		} else {
			lstrcpyn (pBuffer, TEXT ("-"), nBufferSize) ;
		}
	}
	return	TRUE ;
}

BOOL
EnableDlgItem (
	HWND		hDlg,
	int			nResId,
	BOOL		fEnable)
{
	HWND	hwndCtl ;

	hwndCtl	= GetDlgItem (hDlg, nResId) ;
	if (hwndCtl == NULL)
		return	FALSE ;
	EnableWindow (hwndCtl, fEnable) ;
	return	TRUE ;
}

BOOL
SetDropDownListCurrentSelectionByData (
	HWND		hDlg,
	int			nResId,
	int			nData)
{
	HWND	hwndControl ;
	LRESULT	nItemCount, i, nValue ;

	hwndControl	= GetDlgItem (hDlg, nResId) ;
	if (hwndControl == NULL)
		return	FALSE ;
	nItemCount	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
	if (nItemCount == CB_ERR)
		return	FALSE ;
	for (i = 0 ; i < nItemCount ; i ++) {
		nValue	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
		if (nValue != CB_ERR && nValue == nData) {
			return	(SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) != CB_ERR) ;
		}
	}
	SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
	return	FALSE ;
}

BOOL
IsRadioButtonChecked (
	HWND		hDlg,
	int			nRadioIdStart,
	int			nRadioIdEnd,
	int			nRadioId)
{
	int		nIDButton ;

	for (nIDButton = nRadioIdStart ; nIDButton <= nRadioIdEnd ; nIDButton ++) {
		if (nIDButton == nRadioId)
			continue ;
		if (IsDlgButtonChecked (hDlg, nIDButton) != BST_UNCHECKED)
			return	FALSE ;
	}
	return	TRUE ;
}

BOOL
bCreateRegistryKey (
	LPCTSTR		pstrSubKey,
	BOOL		fClean,
	HKEY*		phKey)
{
	HKEY	hSubKey ;
	DWORD	dwDispose ;
	LONG	lResult ;

	if (pstrSubKey == NULL || phKey == NULL)
		return	FALSE ;

	if (fClean) {
		lResult	= RegDeleteKey (HKEY_CURRENT_USER, pstrSubKey) ;
	}
	if (RegCreateKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, NULL, &hSubKey, &dwDispose) != ERROR_SUCCESS) {
		return	FALSE ;
	}
	*phKey	= hSubKey ;
	return	TRUE ;
}

int
iPopupMenu (
	HWND					hwndOwner,
	const struct TMENUITEM*	pMenuItem,
	int						nMenuItem)
{
	HMENU				hMenu	= CreatePopupMenu () ;
	static MENUITEMINFO	mmi ;
	POINT				pt ;
	int					i, n ;

	memset (&mmi, 0, sizeof (mmi)) ;
	mmi.cbSize	= sizeof (mmi) ;
	for (i = 0 ; i < nMenuItem ; i ++) {
#if(WINVER >= 0x0500)
		mmi.fMask		= pMenuItem->m_fMask ;
#else
		mmi.fMask		= pMenuItem->m_fMask | 0x00000140 ;
#endif
		mmi.fType		= pMenuItem->m_fType ;
		mmi.dwTypeData	= (LPTSTR) pMenuItem->m_strText ;
		mmi.wID			= pMenuItem->m_wID ;
		mmi.fState		= pMenuItem->m_fState ;
		mmi.cch			= lstrlen (pMenuItem->m_strText) ;
		InsertMenuItem (hMenu, i, TRUE, &mmi) ;
		pMenuItem	++ ;
	}
	if (! GetCursorPos (&pt))
		pt.x	= pt.y	= 0 ;
	n	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwndOwner, NULL) ;
	DestroyMenu (hMenu) ;
	return	n ;
}

/// ���W�X�g���Ɋi�[���ꂽ�[���I�[������̈ꕔ���G�X�P�[�v�V�[�P���X���f�R�[�h���擾
/**
�f�R�[�h����G�X�P�[�v�V�[�P���X�� '\\' '0' �̂݁B����ȊO�̕����͂��̂܂܉��߂���B
�]�����̕����񂪓]����̃o�b�t�@��蒷���ꍇ�A�|�C���^�͍Ō�ɓ]�����������̒�����w���B���̏�ԂɊׂ�Ȃ��͈͂Ŏg�����Ƃ𐄏��B

����ƈقȂ�_
pbTerminated��p�~���Ԃ�l��p����
�o�b�t�@�T�C�Y��1�o�C�g�ȏ゠��ꍇ�A�K���I�[�����B1�������炵�Ĕԕ������Ȃ����K�v�Ȃ��B
��؂蕶���� ',' ��ǉ��B�z��O�̃G�X�P�[�v�V�[�P���X�̏ꍇ�ł��|�C���^���������i�ނ悤�C���B
*/
BOOL bParseBSEncodedString(
	LPCTSTR*	ppwSrc,
	LPTSTR		pwDest,
	int			nDestSize)
{
	LPCTSTR pwSrc = *ppwSrc;
	LPTSTR pwDestLast = pwDest + nDestSize - 1;
	while (*pwSrc && pwDest < pwDestLast) {
		TCHAR c = *pwSrc;
		if (c == SEPCHAR) {
			pwSrc++;
			break;
		}
		if (c == TEXT('\\')) {
			c = *++pwSrc;
			if (c == TEXT('0')) {
				pwSrc++;
				break;
			}
			if (c == TEXT('\0')) break;		// ��m��
		}
		*pwDest++ = c;
		pwSrc++;
	}
	if (pwDest <= pwDestLast) *pwDest = TEXT('\0');
	*ppwSrc = pwSrc;

	return *pwSrc == TEXT('\0');
}

/// �G���R�[�h�K�p��̕����������O�ɐ�����
int iCountBSEncodedString(LPCTSTR pwSrc)
{
	if (pwSrc == NULL) return 0;

	int n = 0;
	while (*pwSrc) {
		n += (*pwSrc == SEPCHAR || *pwSrc == TEXT('\\')) ? 2 : 1;
		pwSrc++;
	}
	return n;
}

/// ������̃G���R�[�h
LPTSTR iBSEncodeString(LPTSTR pwDest, LPCTSTR pwSrc)
{
	if (pwSrc == NULL) return pwDest;

	while (*pwSrc) {
		if (*pwSrc == SEPCHAR || *pwSrc == TEXT('\\')) {
			*pwDest++ = TEXT('\\');
		}
		*pwDest++ = *pwSrc++;
	}
	return pwDest;
}

/// �G���R�[�h�K�p��̕����������O�ɐ�����
int iCountBSEncodedInteger(int iValue)
{
	TCHAR	bufText [64] ;
	int		nText ;

	nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d"), iValue) ;
	bufText [nText]	= TEXT ('\0') ;
	return	iCountBSEncodedString (bufText) ;
}

/// ���l�̃G���R�[�h
LPTSTR iBSEncodeInteger(LPTSTR pwDest, int iValue)
{
	TCHAR	bufText [64] ;
	int		nText ;

	nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d"), iValue) ;
	bufText [nText]	= TEXT ('\0') ;
	return	iBSEncodeString (pwDest, bufText) ;
}

void
vUpdateTick (void)
{
	HKEY	hKey ;

	_dwTick	++ ;
	if (bCreateRegistryKey (REGPATH_GENERIC, FALSE, &hKey)) {
		(void) RegSetValueEx (hKey, REGINFO_TICK, 0, REG_DWORD, (BYTE*) &_dwTick, sizeof (DWORD)) ;
		RegCloseKey (hKey) ;
	}
	return ;
}

