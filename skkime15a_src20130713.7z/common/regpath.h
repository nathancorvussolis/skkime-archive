#define	REGPATH_SKKIME			TEXT("Software\\SKKIME\\1.5")
#define	REGPATH_GENERIC			TEXT("Software\\SKKIME\\1.5")
