#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#include "jstring.h"
#endif
#include "ImeBufferP.h"
#include "ImeDoc.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "TLispSession.h"
#include "keymap.h"
#include "ImeConfig.h"

/*========================================================================
 *	public functions
 */
static	int		imeBuffer_iGetShiftCount		(struct CImeBuffer*) ;
static	BOOL	imeBuffer_bRegisterProperty		(struct CImeBuffer*, struct CImeBufferProperty*) ;
static	BOOL	imeBuffer_bUnregisterProperty	(struct CImeBuffer*, struct CImeBufferProperty*) ;
static	void	imeBuffer_vClearProperty		(struct CImeBuffer*) ;
static	void	imeBuffer_vUpdateProperty		(struct CImeBuffer*) ;
static	void	imeBuffer_vCopyProperty			(struct CImeBuffer*, const struct CImeBufferProperty*) ;

/*========================================================================
 *	public functions
 */
struct CImeBuffer*
ImeBuffer_pCreate (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	pBuffer	= (struct CImeBuffer*) MALLOC (sizeof (struct CImeBuffer)) ;
	if (pBuffer == NULL)
		return	NULL ;

	pBuffer->m_pDoc							= pDoc ;
	pBuffer->m_pParent						= NULL ;
	pBuffer->m_nbufComp						= 0 ;
	pBuffer->m_nMarker						= 0 ;
	SkkRuleTreeIterator_vInit (&pBuffer->m_iteSkkRuleTree) ;
//	pBuffer->m_pSkkCurrentRuleTree			= NULL ;
	pBuffer->m_pmkPoint						= NULL ;
	pBuffer->m_pmkSkkKanaStartPoint			= NULL ;
	pBuffer->m_pmkSkkPreviousPoint			= NULL ;
	pBuffer->m_pmkSkkHenkanStartPoint		= NULL ;
	pBuffer->m_pmkSkkHenkanEndPoint			= NULL ;
	pBuffer->m_pmkSkkOkuriganaStartPoint	= NULL ;
	pBuffer->m_bSkkModeInvoked				= LFALSE ;
	pBuffer->m_bSkkAfterPrefix				= LFALSE ;
	pBuffer->m_bSkkOkurigana				= LFALSE ;
	pBuffer->m_iSkkHenkanCount				= 0 ;
	pBuffer->m_bSkkHenkanMode				= LFALSE ;

	pBuffer->m_nSkkPrefixLen				= 0 ;
	pBuffer->m_nSkkHenkanKeyLen				= 0 ;
	pBuffer->m_nSkkHenkanOkuriganaLen		= 0 ;
	pBuffer->m_nSkkOkuriCharLen				= 0 ;
	pBuffer->m_iSkkOkuriIndexMin			= -1 ;
	pBuffer->m_iSkkOkuriIndexMax			= -1 ;
	pBuffer->m_nKakuteiMidasiLen			= 0 ;
	pBuffer->m_nKakuteiWordLen				= 0 ;

	pBuffer->m_bSkkMode						= LTRUE ;
	pBuffer->m_bSkkJMode					= LTRUE ;
	pBuffer->m_bSkkLatinMode				= LFALSE ;
	pBuffer->m_bSkkJisx0208LatinMode		= LFALSE ;
	pBuffer->m_bSkkAbbrevMode				= LFALSE ;
	pBuffer->m_bSkkJisx0201Mode				= LFALSE ;
	pBuffer->m_bSkkJisx0201Roman			= LFALSE ;
	pBuffer->m_bSkkKakuteiFlag				= LFALSE ;
	pBuffer->m_bSkkHenkanInMinibuffFlag		= LFALSE ;
	pBuffer->m_bSkkExitShowCandidates		= LFALSE ;
	pBuffer->m_bSkkAfterPrefix				= LFALSE ;

	pBuffer->m_pSkkCurrentSearchProgSession	= NULL ;
	pBuffer->m_pSkkCompSession				= NULL ;
	pBuffer->m_plstSkkS4NumericMapping		= NULL ;

	pBuffer->m_nLineOffset					= -1 ;

	pBuffer->m_bSkkCurrentKutotenType		= LFALSE ;

	pBuffer->m_bSkkHenkanShowCandidatesMode	= FALSE ;
	pBuffer->m_bSkkInputByCodeOrMenuMode	= FALSE ;
	pBuffer->m_bSkkInputByCodeOrMenu1Mode	= FALSE ;
	pBuffer->m_nLatestShiftTextLen			= 0 ;

	pBuffer->m_plstProperty					= NULL ;
	return	pBuffer ;
}

void
ImeBuffer_vDestroy (
	struct CImeBuffer*		pBuffer)
{
	if (pBuffer == NULL)
		return ;
	DEBUGPRINTFEX (99, (TEXT ("ImeBuffer_vDestroy(pBuffer:%p)\n"), pBuffer)) ;
	ImeBuffer_vUninit (pBuffer) ;
	FREE (pBuffer) ;
	return ;
}

BOOL
ImeBuffer_bInit (
	struct CImeBuffer*		pBuffer,
	LPCDSTR					wstrMessage,
	int						nstrMessage,
	BOOL					bSkkModeOn)
{
	/* cursor marker �̊T�O�͂ǂ��Ȃ����̂��낤�H skk-previous-point �́c�H */
	static BOOL		rfMarkerCursor [MAX_RESERVED_MARKERS]	= {
		/*	���݂̐ݒ�́A
		 *	MARKER_POINT:						TRUE
		 *	MARKER_BUFFERTOP:					FALSE
		 *	MARKER_BUFFEREND:					TRUE
		 *	MARKER_MARK:						FALSE
		 *	MARKER_SKK_PREVIOUS_POINT:			FALSE
		 *	MARKER_SKK_KANA_START_POINT:		FALSE
		 *	MARKER_SKK_HENKAN_START_POINT:		FALSE
		 *	MARKER_SKK_HENKAN_END_POINT:		FALSE
		 *	MARKER_SKK_OKURIGANA_START_POINT:	FALSE
		 */
//		TRUE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE,
		TRUE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
		/* skk-henkan-end-point �� marker-insertion-type ����cursor���H*/
	} ;
	register int	i ;

	for (i = 0 ; i < ARRAYSIZE (pBuffer->m_rpmkMarker) ; i ++) 
		pBuffer->m_rpmkMarker [i]	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (rfMarkerCursor) ; i ++) 
		pBuffer->m_rpmkMarker [i]	= ImeBuffer_pMakeMarker (pBuffer, rfMarkerCursor [i]) ;
	pBuffer->m_nMarker	= MAX_RESERVED_MARKERS ;

	/*	�K�{�}�[�J�ł���|�C���g(�J�[�\��)���쐬����B*/
	pBuffer->m_pmkPoint						= pBuffer->m_rMarker + MARKER_POINT ;
	pBuffer->m_pmkMark						= NULL ;
	pBuffer->m_pmkSkkKanaStartPoint			= NULL ;
	pBuffer->m_pmkSkkPreviousPoint			= NULL ;
	pBuffer->m_pmkSkkHenkanStartPoint		= NULL ;
	pBuffer->m_pmkSkkHenkanEndPoint			= NULL ;
	pBuffer->m_pmkSkkOkuriganaStartPoint	= NULL ;
	pBuffer->m_bSkkHenkanMode				= LFALSE ;
	pBuffer->m_bSkkHenkanInMinibuffFlag		= LFALSE ;
	pBuffer->m_bSkkAfterPrefix				= LFALSE ;
	pBuffer->m_bSkkAbbrevMode				= LFALSE ;
	pBuffer->m_bSkkKatakana					= LFALSE ;
	pBuffer->m_bSkkOkurigana				= LFALSE ;
	pBuffer->m_iSkkHenkanCount				= 0 ;
	pBuffer->m_bSkkAfterPrefix				= LFALSE ;
	pBuffer->m_nSkkPrefixLen				= 0 ;
	pBuffer->m_nLatestShiftTextLen			= 0 ;
	pBuffer->m_bSkkHenkanShowCandidatesMode	= FALSE ;
	pBuffer->m_bSkkInputByCodeOrMenuMode	= FALSE ;
	pBuffer->m_bSkkInputByCodeOrMenu1Mode	= FALSE ;
	pBuffer->m_nKakuteiMidasiLen			= 0 ;
	pBuffer->m_nKakuteiWordLen				= 0 ;

	pBuffer->m_bSkkMode						= LTRUE ;
	pBuffer->m_bSkkJMode					= LTRUE ;
	pBuffer->m_bSkkLatinMode				= LFALSE ;
	pBuffer->m_bSkkJisx0208LatinMode		= LFALSE ;
	pBuffer->m_bSkkJisx0201Mode				= LFALSE ;
	pBuffer->m_bSkkJisx0201Roman			= LFALSE ;

	SkkRuleTreeIterator_vInit (&pBuffer->m_iteSkkRuleTree) ;
	imeBuffer_vClearProperty (pBuffer) ;

	if (nstrMessage > 0) {
		ImeBuffer_iInsert (pBuffer, pBuffer->m_rpmkMarker [MARKER_POINT], wstrMessage, nstrMessage) ;
		TMarker_bSetPosition (pBuffer->m_rpmkMarker [MARKER_BUFFERTOP], pBuffer->m_rpmkMarker [MARKER_POINT]) ;
	}
	return	TRUE ;
}

void
ImeBuffer_vUninit (struct CImeBuffer* pBuffer)
{
	int		i ;

	pBuffer->m_nbufComp	= 0 ;
	for (i = 0 ; i < ARRAYSIZE (pBuffer->m_rpmkMarker) ; i ++) 
		pBuffer->m_rpmkMarker [i]	= NULL ;
	pBuffer->m_nMarker	= 0 ;
	if (pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
		TSearchSession_vDestroy (pBuffer->m_pSkkCurrentSearchProgSession) ;
		pBuffer->m_pSkkCurrentSearchProgSession	= NULL ;
	}
	if (pBuffer->m_pSkkCompSession != NULL) {
		TSearchSession_vDestroy (pBuffer->m_pSkkCompSession) ;
		pBuffer->m_pSkkCompSession	= NULL ;
	}
	if (pBuffer->m_plstSkkS4NumericMapping != NULL) {
		TS4Mapping_vClearList (pBuffer->m_plstSkkS4NumericMapping) ;
		pBuffer->m_plstSkkS4NumericMapping	= NULL ;
	}
	imeBuffer_vClearProperty (pBuffer) ;
	return ;
}

/*	������Ԃɖ߂��B*/
BOOL
ImeBuffer_bClear (struct CImeBuffer* pBuffer)
{
	BOOL	bSkkMode				= pBuffer->m_bSkkMode ;
	BOOL	bLatinMode				= pBuffer->m_bSkkLatinMode ;
	BOOL	bSkkJisx0208LatinMode	= pBuffer->m_bSkkJisx0208LatinMode ;
	BOOL	bSkkJisx0201Mode		= pBuffer->m_bSkkJisx0201Mode ;
	BOOL	bSkkJisx0201Roman		= pBuffer->m_bSkkJisx0201Roman ;
	BOOL	bRetval ;

	ImeBuffer_vUninit (pBuffer) ;
	bRetval	= ImeBuffer_bInit (pBuffer, NULL, 0, pBuffer->m_bSkkMode && pBuffer->m_bSkkJMode) ;

	pBuffer->m_bSkkMode					= bSkkMode ;
	pBuffer->m_bSkkLatinMode			= bLatinMode ;
	pBuffer->m_bSkkJisx0208LatinMode	= bSkkJisx0208LatinMode ;
	pBuffer->m_bSkkJisx0201Mode			= bSkkJisx0201Mode ;
	pBuffer->m_bSkkJisx0201Roman		= bSkkJisx0201Roman ;
	return	bRetval ;
}

void
ImeBuffer_vSetParent (
	struct CImeBuffer*			pBuffer,
	struct CImeBuffer*			pParentBuffer)
{
	pBuffer->m_pParent	= pParentBuffer ;
	return ;
}

struct CImeBuffer*
ImeBuffer_pGetParent (
	struct CImeBuffer*			pBuffer)
{
	return	pBuffer->m_pParent ;
}

LPCDSTR
ImeBuffer_pBufferRawString (
	const struct CImeBuffer*	pBuffer,
	int*						pnLength)
{
	if (pnLength != NULL)
		*pnLength	= pBuffer->m_nbufComp ;
	return	pBuffer->m_bufComp ;
}

LPCDSTR
ImeBuffer_pBufferString (
	const struct CImeBuffer*	pBuffer,
	int*						pnLength)
{
	struct TMarker*	pmkTop ;
	struct TMarker*	pmkEnd ;
	int		nTop, nEnd ;

	pmkTop	= pBuffer->m_rpmkMarker [MARKER_BUFFERTOP] ;
	pmkEnd	= pBuffer->m_rpmkMarker [MARKER_BUFFEREND] ;
	if (pmkTop != NULL && TMarker_bIsValidp (pmkTop)) {
		nTop	= MAX (TMarker_iGetPosition (pmkTop), 0) ;
	} else {
		nTop	= 0 ;
	}
	if (pmkEnd != NULL && TMarker_bIsValidp (pmkEnd)) {
		nEnd	= MIN (TMarker_iGetPosition (pmkEnd), pBuffer->m_nbufComp) ;
	} else {
		nEnd	= pBuffer->m_nbufComp ;
	}
	if (pnLength != NULL)
		*pnLength	= nEnd - nTop ;
	return	pBuffer->m_bufComp + nTop ;
}

int
ImeBuffer_iGetConversionMode	(
	struct CImeBuffer*			pBuffer)
{
	ASSERT (pBuffer != NULL) ;

	if (! ImeBuffer_bJModep (pBuffer)) {
		if (pBuffer->m_bSkkJisx0201Mode)
			return	pBuffer->m_bSkkJisx0201Roman? IMECMODE_HANKANA_ROMAN : IMECMODE_HANKANA ;
		return	ImeBuffer_bJisx0208LatinModep (pBuffer)? IMECMODE_ZENKAKU : IMECMODE_ASCII ;
	} else {
		return	pBuffer->m_bSkkKatakana? IMECMODE_KATAKANA : IMECMODE_HIRAGANA ;
	}
}

BOOL
ImeBuffer_bSetConversionMode	(
	struct CImeBuffer*			pBuffer,
	int							nMode)
{
	switch (nMode) {
	case	IMECMODE_ASCII:
		return	imeBuffer_bSkkLatinModeOn (pBuffer) ;

	case	IMECMODE_ZENKAKU:
		return	imeBuffer_bSkkJisx0208LatinModeOn (pBuffer) ;

	case	IMECMODE_HIRAGANA:
		return	imeBuffer_bSkkJModeOn (pBuffer, LFALSE) ;

	case	IMECMODE_KATAKANA:
		return	imeBuffer_bSkkJModeOn (pBuffer, LTRUE) ;

	case	IMECMODE_HANKANA:
		return	imeBuffer_bSkkJisx0201ModeOn (pBuffer, LFALSE) ;

	case	IMECMODE_HANKANA_ROMAN:
		return	imeBuffer_bSkkJisx0201ModeOn (pBuffer, LTRUE) ;

	default:
		return	FALSE ;
	}
}

BOOL
ImeBuffer_bSetConversionString (
	struct CImeBuffer*			pBuffer,
	LPCDSTR						pwText,
	int							nTextLen,
	BOOL						bConv)
{
	struct TMarker*	pmkBufferTop	= NULL ;
	BOOL			bAbbrev			= TRUE ;

	if (pBuffer == NULL)
		return	FALSE ;

	/*	�{���͂����Ə�Ԃ𐧌����Ȃ��Ƃ����Ȃ��̂����B��芸�����ݒ肷��ɂӂ��킵���Ȃ��󋵂���
	 *	�p���Bdocument �� clear ���Ă���ĂԂ��ƁB
	 */
	if (pBuffer->m_bSkkHenkanShowCandidatesMode	|| 
		pBuffer->m_bSkkHenkanMode				||
		pBuffer->m_bSkkInputByCodeOrMenuMode	||
		pBuffer->m_nSkkPrefixLen > 0)
		return	FALSE ;

	/*
	 */
	if (bConv) {
		LPCDSTR	pwptr, pwEnd ;

		pwptr	= pwText ;
		pwEnd	= pwText + nTextLen ;
		while (pwptr < pwEnd) {
			if (! iswalnum (*pwptr)) {
				bAbbrev	= FALSE ;
				break ;
			}
			pwptr	++ ;
		}
	}
	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkBufferTop) || pmkBufferTop == NULL)
		return	FALSE ;
	TMarker_bSetPosition (pBuffer->m_pmkPoint, pmkBufferTop) ;
	(void) ImeBuffer_iInsert (pBuffer, pBuffer->m_pmkPoint, pwText, nTextLen) ;
	if (bConv) {
		ImeBuffer_iInsertW (pBuffer, pmkBufferTop, L"��", 1) ;
		if (! ImeBuffer_bSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanStartPoint, MARKER_SKK_HENKAN_START_POINT, pmkBufferTop) ||
			! TMarker_bForward (pBuffer->m_pmkSkkHenkanStartPoint, 1))
			return	FALSE ;
		/*	�����[�h�� LACTIVE �ł͂Ȃ��CLON �ł���D(fix: ����20�N4��25��(��))
		 */
		pBuffer->m_bSkkHenkanMode	= LON ;
		pBuffer->m_bSkkAbbrevMode	= bAbbrev ;
	} 
	pBuffer->m_nLatestShiftTextLen	= 0 ;
	return	TRUE ;
}


BOOL
ImeBuffer_bQueryUpdateContext (
	struct CImeBuffer*			pBuffer,
	int*						pnShift,
	int*						pnCursor,
	BOOL*						pfContinue)
{
	int		nCursor, nShift ;
	BOOL	bContinue ;

	ASSERT (pBuffer != NULL) ;

	bContinue	= pBuffer->m_bSkkInputByCodeOrMenuMode || pBuffer->m_bSkkHenkanShowCandidatesMode || ImeDoc_bIsStatusActivep (pBuffer->m_pDoc) ;
	nCursor	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
	nShift	= imeBuffer_iGetShiftCount (pBuffer) ;
	if (! ImeBuffer_bJModep (pBuffer) && ! ImeBuffer_bAbbrevModep (pBuffer) && (! ImeBuffer_bJisx0201Modep (pBuffer) || ImeBuffer_bJisx0201Romanp (pBuffer))) {
		/*	�������[�h�łȂ��ꍇ�B�V�t�g����̂̓J�[�\���ʒu�܂ŁB*/
		*pnShift	= nShift ;
		*pnCursor	= 0 ;	/* �V�t�g��̃J�[�\���ʒu�B*/
		*pfContinue	= bContinue || (nShift < pBuffer->m_nbufComp) ;
	} else {
		*pnShift	= nShift ;
		*pnCursor	= nCursor - nShift ;

		/*	modified Fri Sep 02 11:17:12 2005
		 *		PSO ... �̃R�����g�̈Ӗ���Y��Ă���c�BGUIDE Window ������� CANCEL ��
		 *		�A�ł��铮��ɂ��Ă��낤���H
#if 0
#if 0
		// PSO
		*pfContinue	= pBuffer->_fJHenkanOn || (nShift < pBuffer->_nbufComp) || ImeBuffer_IsJInputByCodeOrMenuModep (pBuffer) || (pBuffer->_nbufJPrefix > 0) ;
#else
		*pfContinue	= pBuffer->_fJHenkanOn || (nShift < pBuffer->_nbufComp) || ImeBuffer_IsJInputByCodeOrMenuModep (pBuffer) ;
#endif
#endif
		 */
		*pfContinue	= bContinue || pBuffer->m_bSkkHenkanMode || (nShift < pBuffer->m_nbufComp) ;
	}
	return	TRUE ;
}

BOOL
ImeBuffer_bUpdateContext (
	struct CImeBuffer*			pBuffer)
{
	int		nShift, nCursor ;
	BOOL	fContinue ;

	ASSERT (pBuffer != NULL) ;

	if (! ImeBuffer_bQueryUpdateContext (pBuffer, &nShift, &nCursor, &fContinue))
		return	FALSE ;

	/*	�V�t�g�������� latest-shift �ɒ@�����ށB
	 *	0 shift �͉������Ȃ��c�ŗǂ��Ǝv���B�����A�}�E�X�ɂ��ړ��Ƃ��J�[�\���ɂ��ړ���
	 *	���O�̃V�t�g�̏�Ԃ��ω�����\�����c�B������ǂ��������͓�B���܂� depend �ł���
	 *	���B
	 */
	if (nShift > 0) {
		memcpy (pBuffer->m_bufLatestShiftText, pBuffer->m_bufComp, nShift * sizeof (DCHAR)) ;
		pBuffer->m_nLatestShiftTextLen	= nShift ;
	}
	ImeBuffer_bDeleteRegion (pBuffer, 0, nShift) ;
	return	TRUE ;
}

BOOL
ImeBuffer_bGetSelectedRegion (
	struct CImeBuffer*		pBuffer,
	int*					pnStart,
	int*					pnEnd)
{
	struct TMarker*	pmkMark ;
	int		nPoint, nMark, nCmd ;

	ASSERT (pBuffer != NULL) ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_MARK, &pmkMark) || pmkMark == NULL)
		return	FALSE ;

	nCmd	= ImeDoc_iGetLastCommand (pBuffer->m_pDoc) ;
	if (nCmd != NFUNC_MOUSE_DRAG_REGION && nCmd != NFUNC_MOUSE_DRAG_REGION_END)
		return	FALSE ;

	nPoint	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
	nMark	= TMarker_iGetPosition (pmkMark) ;
	if (pnStart != NULL)
		*pnStart	= (nPoint < nMark)? nPoint : nMark ;
	if (pnEnd != NULL)
		*pnEnd		= (nPoint < nMark)? nMark  : nPoint ;
	return	TRUE ;
}

BOOL
ImeBuffer_bGetConvertedRegion (
	struct CImeBuffer*	pBuffer,
	int*				pnStart,
	int*				pnEnd)
{
	if (! pBuffer->m_bSkkHenkanMode)
		return	FALSE ;
	if (pBuffer->m_pmkSkkHenkanStartPoint == NULL ||
		pBuffer->m_pmkSkkHenkanEndPoint   == NULL)
		return	FALSE ;
	if (pnStart != NULL)
		*pnStart	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
	if (pnEnd != NULL)
		*pnEnd		= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint) ;
	return	TRUE ;
}

BOOL
ImeBuffer_bGetMarker (
	struct CImeBuffer*		pBuffer,
	int						nMarker,
	struct TMarker**		ppMarker)
{
	if (pBuffer == NULL || nMarker < 0 || nMarker >= MAXBUFMARKER)
		return	FALSE ;
	if (pBuffer->m_rpmkMarker [nMarker] == NULL || ! TMarker_bIsValidp (pBuffer->m_rpmkMarker [nMarker]))
		return	FALSE ;
	if (ppMarker != NULL)
		*ppMarker	= pBuffer->m_rpmkMarker [nMarker] ;
	return	TRUE ;
}

BOOL
ImeBuffer_bSetMarker (
	struct CImeBuffer*			pBuffer,
	struct TMarker**			ppMarker,
	int							nMarkerIndex,
	const struct TMarker*		pSource)
{
	if (pBuffer == NULL || ppMarker == NULL || pSource == NULL)
		return	FALSE ;
	if (! (0 <= nMarkerIndex && nMarkerIndex < MAXBUFMARKER))
		return	FALSE ;

	if (*ppMarker == NULL) 
		*ppMarker	= &pBuffer->m_rMarker [nMarkerIndex] ;
	return	TMarker_bSetPosition (*ppMarker, pSource) ;
}

BOOL
ImeBuffer_bForwardChar (
	struct CImeBuffer*			pBuffer,
	int							nCount)
{
	struct TMarker*	pmkBufferEnd ;
	struct TMarker*	pmkPoint ;
	int				nBufferEnd, nPosition, n ;

	if (pBuffer == NULL || nCount < 0)
		return	FALSE ;
	pmkBufferEnd	= pBuffer->m_rpmkMarker [MARKER_BUFFEREND] ;
	if (pmkBufferEnd != NULL && TMarker_bIsValidp (pmkBufferEnd)) {
		nBufferEnd	= TMarker_iGetPosition (pmkBufferEnd) ;
	} else {
		nBufferEnd	= pBuffer->m_nbufComp ;
	}
	pmkPoint	= pBuffer->m_pmkPoint ;
	if (pmkPoint == NULL || ! TMarker_bIsValidp (pmkPoint))
		return	FALSE ;
	nPosition	= TMarker_iGetPosition (pmkPoint) ;
	n			= MIN (nBufferEnd - nPosition, nCount) ;
	if (! TMarker_bForward (pmkPoint, n))
		return	FALSE ;
	/* buffer-top �ɂЂ�������ƑʖځB*/
	if (n != nCount)
		return	FALSE ;
	return	TRUE ;
}

BOOL
ImeBuffer_bBackwardChar (
	struct CImeBuffer*			pBuffer,
	int							nCount)
{
	struct TMarker*	pmkBufferTop ;
	struct TMarker*	pmkPoint ;
	int				nBufferTop, nPosition, n ;

	if (pBuffer == NULL || nCount < 0)
		return	FALSE ;
	pmkBufferTop	= pBuffer->m_rpmkMarker [MARKER_BUFFERTOP] ;
	if (pmkBufferTop != NULL && TMarker_bIsValidp (pmkBufferTop)) {
		nBufferTop	= TMarker_iGetPosition (pmkBufferTop) ;
	} else {
		nBufferTop	= 0 ;
	}
	pmkPoint	= pBuffer->m_pmkPoint ;
	if (pmkPoint == NULL || ! TMarker_bIsValidp (pmkPoint))
		return	FALSE ;
	nPosition	= TMarker_iGetPosition (pmkPoint) ;
	n			= MIN (nPosition - nBufferTop, nCount) ;
	if (! TMarker_bBackward (pmkPoint, n))
		return	FALSE ;
	/* buffer-top �ɂЂ�������ƑʖځB*/
	if (n != nCount)
		return	FALSE ;
	return	TRUE ;
}

BOOL
ImeBuffer_bFollowingStringEqualp (
	struct CImeBuffer*			pBuffer,
	LPCDSTR						pdString,
	int							nStringLen)
{
	struct TMarker*	pmkBufferEnd ;
	struct TMarker*	pmkPoint ;
	int				nBufferEnd, nPosition ;

	if (pBuffer == NULL)
		return	FALSE ;
	if (pdString == NULL || nStringLen <= 0) 
		return	TRUE ;

	pmkBufferEnd	= pBuffer->m_rpmkMarker [MARKER_BUFFEREND] ;
	if (pmkBufferEnd != NULL && TMarker_bIsValidp (pmkBufferEnd)) {
		nBufferEnd	= TMarker_iGetPosition (pmkBufferEnd) ;
	} else {
		nBufferEnd	= pBuffer->m_nbufComp ;
	}
	pmkPoint	= pBuffer->m_pmkPoint ;
	if (pmkPoint == NULL || ! TMarker_bIsValidp (pmkPoint))
		return	FALSE ;
	nPosition	= TMarker_iGetPosition (pmkPoint) ;
	if ((nPosition + nStringLen) > nBufferEnd)
		return	FALSE ;
	if (! dcsncmp (pBuffer->m_bufComp + nPosition, pdString, nStringLen))
		return	TRUE ;
	return	FALSE ;
}

int
ImeBuffer_iInsert (
	struct CImeBuffer*		pBuffer,
	struct TMarker*			pMarker,
	LPCDSTR					pdString,
	int						nStringLen)
{
	if (pMarker == NULL || pBuffer == NULL)
		return	0 ;

	return	ImeBuffer_iInsertByPosition (pBuffer, TMarker_iGetPosition (pMarker), pdString, nStringLen) ;
}

int
ImeBuffer_iInsertW (
	struct CImeBuffer*		pBuffer,
	struct TMarker*			pMarker,
	LPCWSTR					pwString,
	int						nStringLen)
{
	DCHAR	buf [32] ;
	DCHAR*	pDest ;
	DCHAR*	pDestEnd ;
	LPCWSTR	ptr ;
	LPCWSTR	ptrEnd ;
	int		iPosition, nInsert ;

	if (pMarker == NULL || ! TMarker_bIsValidp (pMarker) || pwString == NULL || nStringLen <= 0)
		return	0 ;

	nInsert		= 0 ;
	iPosition	= TMarker_iGetPosition (pMarker) ;
	pDest		= buf ;
	pDestEnd	= buf + ARRAYSIZE (buf) ;
	ptr			= pwString ;
	ptrEnd		= pwString + nStringLen ;
	while (ptr < ptrEnd) {
		if (ptr < ptrEnd && IS_SURROGATE_PAIR (*ptr, *(ptr+1))) {
			*pDest ++	= MAKE_DCHAR_FROM_SURROGATE_PAIR (*ptr, *(ptr+1)) ;
			ptr	+= 2 ;
		} else {
			*pDest ++	= MAKE_DCHAR(0, *ptr) ;
			ptr	++ ;
		}
		if (pDest >= pDestEnd) {
			int	n	= ImeBuffer_iInsertByPosition (pBuffer, iPosition, buf, pDest - buf) ;
			iPosition	+= n ;
			nInsert		+= n ;
		}
	}
	if (pDest > buf) {
		int	n	= ImeBuffer_iInsertByPosition (pBuffer, iPosition, buf, pDest - buf) ;
		nInsert	+= n ;
	}
	return	nInsert ;
}

int
ImeBuffer_iInsertBeforeMarkers (
	struct CImeBuffer*		pBuffer,
	struct TMarker*			pMarker,
	LPCDSTR					pdString,
	int						nStringLen)
{
	if (pMarker == NULL || pBuffer == NULL)
		return	0 ;

	return	ImeBuffer_iInsertBeforeMarkersByPosition (pBuffer, TMarker_iGetPosition (pMarker), pdString, nStringLen) ;
}

int
ImeBuffer_iInsertByPosition (
	struct CImeBuffer*		pBuffer,
	int						nPosition, 
	LPCDSTR					pdString,
	int						nStringLen)
{
	int		i ;

	if ( pBuffer == NULL)
		return	0 ;

	if (nPosition < 0 || nPosition >= MAXCOMPLEN || nStringLen <= 0)
		return	0 ;
	if ((pBuffer->m_nbufComp + nStringLen) > MAXCOMPLEN)
		nStringLen	= MAXCOMPLEN - pBuffer->m_nbufComp ;
	if ((nPosition + nStringLen) > MAXCOMPLEN) 
		nStringLen	= MAXCOMPLEN - nPosition ;
	if (nStringLen <= 0)
		return	0 ;
	if ((nPosition + nStringLen) < MAXCOMPLEN && nPosition < pBuffer->m_nbufComp) 
		memmove (pBuffer->m_bufComp + nPosition + nStringLen, pBuffer->m_bufComp + nPosition, sizeof (DCHAR) * (pBuffer->m_nbufComp - nPosition)) ;
	memmove (pBuffer->m_bufComp + nPosition, pdString, sizeof (DCHAR) * nStringLen) ;

	/*	�}�[�J�̈ړ��B
	 */
	pBuffer->m_nbufComp	+= nStringLen ;
	for (i = 0 ; i < pBuffer->m_nMarker ; i ++) {
		if ((nPosition < TMarker_iGetPosition (&pBuffer->m_rMarker [i]) ||
			 (nPosition == TMarker_iGetPosition (&pBuffer->m_rMarker [i]) && TMarker_bIsCursor (&pBuffer->m_rMarker [i]))) &&
			TMarker_iGetPosition (&pBuffer->m_rMarker [i]) < pBuffer->m_nbufComp)
			TMarker_bForward (&pBuffer->m_rMarker [i], nStringLen) ;
	}

	/*	�v���p�e�B���̃}�[�J�̈ړ��B
	 *
	 *	��J�[�\���}�[�J�Ƃ���B
	 */
	{
		struct CImeBufferProperty*	pNode	= pBuffer->m_plstProperty ;

		while (pNode != NULL) {
			if (nPosition < pNode->m_nBegin && pNode->m_nBegin < pBuffer->m_nbufComp) 
				pNode->m_nBegin	+= nStringLen ;
			if (nPosition < pNode->m_nEnd   && pNode->m_nEnd   < pBuffer->m_nbufComp) 
				pNode->m_nEnd	+= nStringLen ;
			pNode	= pNode->m_pNext ;
		}
	}
	return	nStringLen ;
}

int
ImeBuffer_iInsertBeforeMarkersByPosition (
	struct CImeBuffer*		pBuffer,
	int						nPosition, 
	LPCDSTR					pdString,
	int						nStringLen)
{
	int		i ;

	if ( pBuffer == NULL)
		return	0 ;

	if (nPosition < 0 || nPosition >= MAXCOMPLEN || nStringLen <= 0)
		return	0 ;
	if ((pBuffer->m_nbufComp + nStringLen) > MAXCOMPLEN)
		nStringLen	= MAXCOMPLEN - pBuffer->m_nbufComp ;
	if ((nPosition + nStringLen) > MAXCOMPLEN) 
		nStringLen	= MAXCOMPLEN - nPosition ;
	if (nStringLen <= 0)
		return	0 ;
	if ((nPosition + nStringLen) < MAXCOMPLEN && nPosition < pBuffer->m_nbufComp) 
		memmove (pBuffer->m_bufComp + nPosition + nStringLen, pBuffer->m_bufComp + nPosition, sizeof (DCHAR) * (pBuffer->m_nbufComp - nPosition)) ;
	memmove (pBuffer->m_bufComp + nPosition, pdString, sizeof (DCHAR) * nStringLen) ;

	/*	�}�[�J�̈ړ��B
	 */
	pBuffer->m_nbufComp	+= nStringLen ;
	for (i = 0 ; i < pBuffer->m_nMarker ; i ++) {
		if (nPosition <= TMarker_iGetPosition (&pBuffer->m_rMarker [i]) &&
			TMarker_iGetPosition (&pBuffer->m_rMarker [i]) < pBuffer->m_nbufComp)
			TMarker_bForward (&pBuffer->m_rMarker [i], nStringLen) ;
	}

	/*	�v���p�e�B���̃}�[�J�̈ړ��B
	 */
	{
		struct CImeBufferProperty*	pNode	= pBuffer->m_plstProperty ;

		while (pNode != NULL) {
			if (nPosition <= pNode->m_nBegin && pNode->m_nBegin < pBuffer->m_nbufComp) 
				pNode->m_nBegin	+= nStringLen ;
			if (nPosition <= pNode->m_nEnd   && pNode->m_nEnd   < pBuffer->m_nbufComp) 
				pNode->m_nEnd	+= nStringLen ;
			pNode	= pNode->m_pNext ;
		}
	}
	return	nStringLen ;
}

int
ImeBuffer_iOverwriteByPosition (
	struct CImeBuffer*		pBuffer,
	int						nPosition, 
	LPCDSTR					pdString,
	int						nStringLen)
{
	int		i ;

	if ( pBuffer == NULL)
		return	0 ;

	if (nPosition < 0 || nPosition >= MAXCOMPLEN || nStringLen <= 0)
		return	0 ;
	if ((nPosition + nStringLen) > MAXCOMPLEN) {
		nStringLen	= MAXCOMPLEN - nPosition ;
	}
	if ((nPosition + nStringLen) > pBuffer->m_nbufComp) {
		nStringLen	= pBuffer->m_nbufComp - nPosition ;
	}
	if (nStringLen <= 0)
		return	0 ;

	memmove (pBuffer->m_bufComp + nPosition, pdString, sizeof (DCHAR) * nStringLen) ;
	return	nStringLen ;
}

BOOL
ImeBuffer_bInsertAndInherit (
	struct CImeBuffer*		pBuffer,
	LPCDSTR					pdString,
	int						nString)
{
	return	ImeBuffer_iInsert (pBuffer, pBuffer->m_pmkPoint, pdString, nString) == nString ;
}

BOOL
ImeBuffer_bInsertAndInheritW (
	struct CImeBuffer*		pBuffer,
	LPCWSTR					pwString,
	int						nString)
{
	return	ImeBuffer_iInsertW (pBuffer, pBuffer->m_pmkPoint, pwString, nString) == nString ;
}

BOOL
ImeBuffer_bInsertBeforeMarkers (
	struct CImeBuffer*		pBuffer,
	LPCDSTR					pwString,
	int						nString)
{
	return	ImeBuffer_iInsertBeforeMarkers (pBuffer, pBuffer->m_pmkPoint, pwString, nString) == nString ;
}

BOOL
ImeBuffer_bDeleteBackwardChar (
	struct CImeBuffer*		pBuffer,
	int						nChar) 
{
	int		nPosition ;

	if (nChar <= 0 || pBuffer->m_pmkPoint == NULL)
		return	FALSE ;

	nPosition	= TMarker_iGetPosition (pBuffer->m_pmkPoint) - nChar ;
	if (nPosition < 0 || (nPosition + nChar) > pBuffer->m_nbufComp) 
		return	FALSE ;
	return	ImeBuffer_bDeleteRegion (pBuffer, nPosition, nPosition + nChar) ;
}

BOOL
ImeBuffer_bDeleteRegion (
	struct CImeBuffer*			pBuffer,
	int							nStartPoint,
	int							nEndPoint)
{
	int	nMove, i ;

	if (nStartPoint > nEndPoint) {
		int	nTmp ;
		nTmp		= nStartPoint ;
		nStartPoint	= nEndPoint ;
		nEndPoint	= nTmp ;
	}

	nMove	= nEndPoint - nStartPoint ;
	if (nMove == 0)
		return	TRUE ;

	/*	�s���ȗ̈�̍폜�͎̂Ă�B
	 */
	if (nStartPoint < 0 || nEndPoint > MAXCOMPLEN)
		return	FALSE ;

	if (pBuffer->m_nbufComp > nEndPoint) 
		memmove (pBuffer->m_bufComp + nStartPoint, pBuffer->m_bufComp + nEndPoint, sizeof (DCHAR) * (pBuffer->m_nbufComp - nEndPoint)) ;
	pBuffer->m_nbufComp	-= (nEndPoint - nStartPoint) ;

	/*	�����Ń}�[�J�̈ړ�������B
	 */
	for (i = 0 ; i < pBuffer->m_nMarker ; i ++) {
		if (nStartPoint < TMarker_iGetPosition (&pBuffer->m_rMarker [i])) {
			if (TMarker_iGetPosition (&pBuffer->m_rMarker [i]) < nEndPoint) {
				TMarker_bBackward (&pBuffer->m_rMarker [i], TMarker_iGetPosition (&pBuffer->m_rMarker [i]) - nStartPoint) ;
			} else {
				TMarker_bBackward (&pBuffer->m_rMarker [i], nMove) ;
			}
		}
	}

	/*	property ���̃}�[�J�̈ړ��B
	 */
	{
		struct CImeBufferProperty*	pNode	= pBuffer->m_plstProperty ;

		while (pNode != NULL) {
			if (nStartPoint < pNode->m_nBegin) {
				if (pNode->m_nBegin < nEndPoint) {
					pNode->m_nBegin	= nStartPoint ;
				} else {
					pNode->m_nBegin	-= nMove ;
				}
			}
			if (nStartPoint < pNode->m_nEnd) {
				if (pNode->m_nEnd < nEndPoint) {
					pNode->m_nEnd	= nStartPoint ;
				} else {
					pNode->m_nEnd	-= nMove ;
				}
			}
			pNode	= pNode->m_pNext ;
		}
	}
	/* region �폜�ɑΉ����� property �� update ��������B�����̑}���� update �������邱�Ƃ͂Ȃ��B*/
	imeBuffer_vUpdateProperty (pBuffer) ;
	return	TRUE ;
}

struct TMarker*
ImeBuffer_pMakeMarker (
	struct CImeBuffer*		pBuffer,
	BOOL					fCursor)
{
	struct TMarker*	pMarker ;
	int				nMarker ;

	/*	�\�񂳂�Ă���}�[�J�̎����猟�����J�n����B
	 */
	pMarker	= pBuffer->m_rMarker ;
	nMarker	= pBuffer->m_nMarker ;
	while (nMarker -- > 0) {
		if (! TMarker_bIsValidp (pMarker)) 
			break ;
		pMarker	++ ;
	}

	/*	���݂̃}�[�J�̒��ɋ�(���ԂƂ������H)���Ȃ�
	 *	�̂ŐV�����m�ہB
	 */
	if (nMarker <= 0) {
		if (pBuffer->m_nMarker >= MAXBUFMARKER) 
			return	FALSE ;
		pMarker	= pBuffer->m_rMarker + pBuffer->m_nMarker ;
		pBuffer->m_nMarker	++ ;
	}
	TMarker_bInit (pMarker, fCursor) ;
	return	pMarker ;
}

BOOL
ImeBuffer_bDeleteMarker (
	struct CImeBuffer*		pBuffer,
	struct TMarker*			pMarker)
{
	struct TMarker*		pmkLast ;

	if (pBuffer == NULL || pMarker == NULL)
		return	FALSE ;
	if (! (pBuffer->m_rMarker <= pMarker && pMarker < (pBuffer->m_rMarker + MAXBUFMARKER)))
		return	FALSE ;

	pmkLast	= pBuffer->m_rMarker + pBuffer->m_nMarker ;
	if (pmkLast == pMarker) 
		pBuffer->m_nMarker	-- ;
	TMarker_vInvalidate (pMarker) ;
	return	TRUE ;
}

BOOL
ImeBuffer_bJModep (const struct CImeBuffer* pBuffer)
{
	return pBuffer->m_bSkkJMode ;
}

BOOL
ImeBuffer_bLatinModep (const struct CImeBuffer* pBuffer)
{ 
	return pBuffer->m_bSkkLatinMode ;
}

BOOL
ImeBuffer_bJisx0208LatinModep (const struct CImeBuffer* pBuffer)
{ 
	return pBuffer->m_bSkkJisx0208LatinMode ;
}

BOOL
ImeBuffer_bAbbrevModep (const struct CImeBuffer* pBuffer)
{
	return pBuffer->m_bSkkAbbrevMode ;
}

BOOL
ImeBuffer_bKatakanaModep (const struct CImeBuffer* pBuffer)
{
	return	pBuffer->m_bSkkKatakana ;
}

BOOL
ImeBuffer_bJisx0201Modep (const struct CImeBuffer* pBuffer)
{
	return	pBuffer->m_bSkkJisx0201Mode ;
}

BOOL
ImeBuffer_bJisx0201Romanp (const struct CImeBuffer* pBuffer)
{
	return	pBuffer->m_bSkkJisx0201Roman ;
}

BOOL
ImeBuffer_bKeyboardQuit (
	struct CImeBuffer*			pBuffer)
{
	return	FALSE ;
}

BOOL
ImeBuffer_bExitMinibuffer (
	struct CImeBuffer*			pBuffer)
{
	return	FALSE ;
}

BOOL
ImeBuffer_bAbortRecursiveEdit (
	struct CImeBuffer*			pBuffer)
{
	return	FALSE ;
}

BOOL
ImeBuffer_bNewline (
	struct CImeBuffer*			pBuffer)
{
	return	FALSE ;
}

BOOL
ImeBuffer_bSkkHenkanActivep (
	const struct CImeBuffer*	pBuffer)
{
	return	pBuffer->m_bSkkHenkanMode ;
}

struct CSkkRuleTreeIterator*
ImeBuffer_pSkkGetSkkRuleTreeIterator (
	struct CImeBuffer*			pBuffer) 
{
	return	&pBuffer->m_iteSkkRuleTree ;
}

BOOL
ImeBuffer_bShowHenkanCandidatesModep (
	const struct CImeBuffer*	pBuffer)
{
	return	pBuffer->m_bSkkHenkanShowCandidatesMode ;
}

BOOL
ImeBuffer_bInputByCodeOrMenuModep (
	const struct CImeBuffer*	pBuffer)
{
	return	pBuffer->m_bSkkInputByCodeOrMenuMode ;
}

BOOL
ImeBuffer_bInputByCodeOrMenu1Modep (
	const struct CImeBuffer*	pBuffer)
{
	return	pBuffer->m_bSkkInputByCodeOrMenuMode && pBuffer->m_bSkkInputByCodeOrMenu1Mode ;
}

BOOL
ImeBuffer_bHavePrefixp (
	const struct CImeBuffer*	pBuffer)
{
	if (pBuffer == NULL)
		return	FALSE ;

	/*	skk-current-rule-tree �� non-nil �ł���΁Askk-pre-command �͉��炩�̏���������K�v
	 *	������Ƃ������ƂŁAhave-prefix-p �� t ��Ԃ����Ƃɂ���B
	 *
	 *	have-prefix-p => event �� process ���邩�ۂ��ɉe���B
	 */
	return	SkkRuleTreeIterator_bHavePrefixp (&pBuffer->m_iteSkkRuleTree) ;
}

int
ImeBuffer_iGetLineOffset (
	const struct CImeBuffer*	pBuffer)
{
	return	pBuffer->m_nLineOffset ;
}

void
ImeBuffer_vSetLineOffset (
	struct CImeBuffer*			pBuffer,
	int							nOffset)
{
	pBuffer->m_nLineOffset	= nOffset ;
	return ;
}

BOOL
ImeBuffer_bSetReadingProperty (
	struct CImeBuffer*		pBuffer,
	const struct TMarker*	pmkRegionBegin,
	const struct TMarker*	pmkRegionEnd,
	LPCDSTR					strReadingText,
	int						nReadingTextLen)
{
	struct CImeBufferProperty*	pProperty ;
	LPDSTR			pwReadingText ;
	int				nSize ;

	if (pBuffer == NULL || pmkRegionBegin == NULL || pmkRegionEnd == NULL)
		return	FALSE ;
	/*	�̈�`�F�b�N�B
	 */
	if (TMarker_iGetPosition (pmkRegionBegin) >= TMarker_iGetPosition (pmkRegionEnd))
		return	FALSE ;

	/*	property �� (begin-point, end-point, property) ��3�g�Ƃ���B
	 */

	/*	���̓}�[�J�̐��c�B�ǂ̒��x�̐� property ���ݒ肳���̂��Ɉˑ����邪�c�B
	 */
	nSize			= sizeof (struct CImeBufferProperty) + sizeof (DCHAR) * nReadingTextLen ;
	pProperty		= (struct CImeBufferProperty*) MALLOC (nSize) ;
	if (pProperty == NULL) {
		return	FALSE ;
	}
	pwReadingText			= (LPDSTR)(pProperty + 1) ;

	pProperty->m_nBegin		= TMarker_iGetPosition (pmkRegionBegin) ;
	pProperty->m_nEnd		= TMarker_iGetPosition (pmkRegionEnd) ;
	memcpy (pwReadingText, strReadingText, sizeof (DCHAR) * nReadingTextLen) ;
	pProperty->m_pwText		= pwReadingText ;
	pProperty->m_nTextLen	= nReadingTextLen ;
	pProperty->m_pNext		= NULL ;

	/*	�o�b�t�@�ɓo�^����B
	 */
	if (! imeBuffer_bRegisterProperty (pBuffer, pProperty)) {
		FREE (pProperty) ;
		return	FALSE ;
	}
//	pProperty->m_pNext		= pBuffer->m_plstProperty ;
//	pBuffer->m_plstProperty	= pProperty ;
	return	TRUE ;
}

/*	shift �ʂ������ɂƂ�Ȃ��ƍ��邩�c�B
 */
int
ImeBuffer_iGetReadingText (
	struct CImeBuffer*		pBuffer,
	LPDSTR					pDestBuffer,
	int						nDestSize,
	int						nCompPosition,		/* Composition �̒��ł̈ʒu [in] */
	int*					pnReadingPosition)	/* �ǂ݉����̒��ł̈ʒu [out] */
{
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pSrc,  pSrcEnd, pSrcBreak, pSrcCompPos ;
	int		nBufferTop, nBufferEnd, nReadingPosition ;
	struct CImeBufferProperty*	pProperty ;
	struct CImeBufferProperty	propDuringHenkan ;
	struct CImeBufferProperty	propKanaPrefix ;
	struct CImeBufferProperty	propOkuriMarker ;
	BOOL	bErasePrefix		= FALSE ;
	BOOL	bEraseOkuriMarker	= FALSE ;


	nBufferTop	= 0 ;
	nBufferEnd	= pBuffer->m_nbufComp ;
	if (pBuffer->m_rpmkMarker [MARKER_BUFFERTOP] != NULL && TMarker_bIsValidp (pBuffer->m_rpmkMarker [MARKER_BUFFERTOP])) 
		nBufferTop	= TMarker_iGetPosition (pBuffer->m_rpmkMarker [MARKER_BUFFERTOP]) ;
	if (pBuffer->m_rpmkMarker [MARKER_BUFFEREND] != NULL && TMarker_bIsValidp (pBuffer->m_rpmkMarker [MARKER_BUFFEREND])) 
		nBufferEnd	= TMarker_iGetPosition (pBuffer->m_rpmkMarker [MARKER_BUFFEREND]) ;

	/*	�ϊ����쒆�A���ڃR�[�h���͒��͒��ӂ��K�v�B
	 *	- ���m��̕ϊ�������� Property �̐ݒ肪����Ă��Ȃ��B(property ���\�[�g����Ă���̂�
	 *	  ���X�g�����ԂɌ��ăR�s�[����Ηǂ��Ƃ������z�̔j��)
	 *	- ���⁤�̏������K�v�B
	 *	- ���ړ��͂��ꂽ�����ɓǂ݉����͂���̂��H ���̂܂܂Ȃ̂��H
	 */
	if (pBuffer->m_bSkkHenkanMode) {
		int		nHenkanStartPoint ;

		/*	���}�[�N�⁥�}�[�N�̃`�F�b�N�B
		 */
		nHenkanStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
		if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
			int		nHenkanEndPoint ;

			if (pBuffer->m_pmkSkkHenkanEndPoint != NULL && TMarker_bIsValidp (pBuffer->m_pmkSkkHenkanEndPoint)) {
				nHenkanEndPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint) ;
				if (nHenkanStartPoint > nBufferTop && 
					pBuffer->m_bufComp [nHenkanStartPoint - 1] == L'��') {
					/*	���}�[�N�⁥�}�[�N��ǂ݉����Ɋ܂߂Ȃ��悤�ɒ��ӂ���B
					 */
					nHenkanStartPoint	-- ;
				} else {
					/*	���}�[�N�⁥�}�[�N�͉��炩�̕s�K�ō폜����Ă��܂����̂ŁA���̂܂܂� region �ݒ�
					 *	�Ői�߂�B
					 */
				}
			} else {
				/*	�ϊ��G���h�|�C���g���Ȃ��H�ϊ��X�^�[�g�|�C���g�Ɠ����Ƃ��Ă����D
				 */
				nHenkanEndPoint	= nHenkanStartPoint ;
			}

			/*	�ǂ݉����ɂ� skk-henkan-key �𗘗p����c�B���l�ϊ��̏����ɂ����
			 *	�u#�v�ɒu���������Ă��܂������e���܂܂�Ă��Ȃ����A�`�F�b�N���邱�ƁB
			 */
			propDuringHenkan.m_nBegin	= nHenkanStartPoint ;
			propDuringHenkan.m_nEnd		= nHenkanEndPoint ;
			propDuringHenkan.m_pwText	= pBuffer->m_bufSkkHenkanKey ;

			if (pBuffer->m_nSkkOkuriCharLen > 0) {
				LPCDSTR	wptr, wptrLast ;
				wptrLast	= pBuffer->m_bufSkkHenkanKey + pBuffer->m_nSkkHenkanKeyLen - 1 ;
				wptr		= wptrLast ;
				while (wptr >= pBuffer->m_bufSkkHenkanKey && (L'a' <= *wptr && *wptr <= L'z'))
					wptr	-- ;
				propDuringHenkan.m_nTextLen	= wptr - pBuffer->m_bufSkkHenkanKey + 1 ;
			} else {
				propDuringHenkan.m_nTextLen	= pBuffer->m_nSkkHenkanKeyLen ;
			}
			/*	�ꎞ�I�� stack ��Ɋm�ۂ��ꂽ struct CImeBufferProperty �� list �ɒǉ����邩�H
			 *	���ꂪ��ԃ�������H��Ȃ����Asort �̏�����j�󂵂Ȃ��Ǝv�����c�B
			 *	����A���ꂾ�ƃ}�[�J����x backward ���Ȃ��Ƃ����Ȃ��̂��c�B����ł��������c�B
			 *
			 *	���[�ށAproperty �� marker �����Ɖ��肵�ď���ɓ����������Ȃ����B
			 */
			(void) imeBuffer_bRegisterProperty (pBuffer, &propDuringHenkan) ;
		} else {
			if (nHenkanStartPoint > nBufferTop && pBuffer->m_bufComp [nHenkanStartPoint - 1] == L'��') {
				propDuringHenkan.m_nBegin	= nHenkanStartPoint - 1 ;
				propDuringHenkan.m_nEnd		= nHenkanStartPoint ;
				propDuringHenkan.m_pwText	= NULL ;
				propDuringHenkan.m_nTextLen	= 0 ;
				(void) imeBuffer_bRegisterProperty (pBuffer, &propDuringHenkan) ;
			}
		}
	} else {
		/*	�ϊ��̈�̓ǂݑւ��̕K�v�͂Ȃ��B
		memset (&propDuringHenkan, 0, sizeof (propDuringHenkan)) ;
		 */
	}
	if (pBuffer->m_nSkkPrefixLen > 0 && ImeConfig_bSkkEchop () && pBuffer->m_pmkSkkKanaStartPoint != NULL) {
		propKanaPrefix.m_nBegin		= TMarker_iGetPosition (pBuffer->m_pmkSkkKanaStartPoint) ;
		propKanaPrefix.m_nEnd		= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
		propKanaPrefix.m_pwText		= NULL ;
		propKanaPrefix.m_nTextLen	= 0 ;
		(void) imeBuffer_bRegisterProperty (pBuffer, &propKanaPrefix) ;
		bErasePrefix	= TRUE ;
	}
	if (pBuffer->m_bSkkOkurigana && pBuffer->m_pmkSkkOkuriganaStartPoint != NULL) {
		int	nOkuriStartPos	= TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint) ;
		if (nBufferTop <= nOkuriStartPos && nOkuriStartPos < nBufferEnd && pBuffer->m_bufComp [nOkuriStartPos] == L'*') {
			propOkuriMarker.m_nBegin	= nOkuriStartPos ;
			propOkuriMarker.m_nEnd		= nOkuriStartPos + 1 ;
			propOkuriMarker.m_pwText	= NULL ;
			propOkuriMarker.m_nTextLen	= 0 ;
			(void) imeBuffer_bRegisterProperty (pBuffer, &propOkuriMarker) ;
			bEraseOkuriMarker	= TRUE ;
		}
	}

	pSrc		= pBuffer->m_bufComp + nBufferTop ;
	pSrcEnd		= pBuffer->m_bufComp + nBufferEnd ;
	pSrcCompPos	= pBuffer->m_bufComp + nCompPosition ;
	nReadingPosition	= pBuffer->m_nbufComp ;

	pDest		= pDestBuffer ;
	pDestEnd	= pDestBuffer + nDestSize ;
	pProperty	= pBuffer->m_plstProperty ;		/*	Property ���X�g�̓\�[�g���Ă���Ƃ���B */

	while (pDest < pDestEnd && pProperty != NULL) {
		LPDSTR	pDestBak ;
		LPCDSTR	pReading, pSrcBak ;
		int		nReading, nNewPos ;

		/*	Reading Property �ɂ������ĂȂ��̈���R�s�[����B
		 */
		pSrcBreak	= pBuffer->m_bufComp + pProperty->m_nBegin ;
		pSrcBak		= pSrc ;
		pDestBak	= pDest ;
		while (pDest < pDestEnd && pSrc < pSrcEnd && pSrc < pSrcBreak) 
			*pDest ++	= *pSrc ++ ;

		if (pSrcCompPos != NULL && pSrcCompPos <= pSrc) {
			nReadingPosition	= (pSrc - pSrcBak) + (pDestBak - pDestBuffer) ;
			pSrcCompPos			= NULL ;
		}

		/*	Reading Text ���R�s�[����B���� Reading Text �̓r���� nPosition ���w���Ă���
		 *	�ꍇ�ɂ́A���̉������͕�����Ȃ��̂ŁAReading Text �R�s�[���Ԃ��B
		 *	(�ǂ݉����̋�؂�̏��͒N�������ĂȂ����番����Ȃ�)
		 */
		pReading	= pProperty->m_pwText ;
		nReading	= pProperty->m_nTextLen ;
		while (pDest < pDestEnd && nReading > 0) {
			*pDest ++	= *pReading ++ ;
			nReading	-- ;
		}

		/*	- ���� Reading Property ���w���B
		 *	- pSrc �� Reading Text �Ŕ�΂��ꂽ��̏ꏊ���w������B
		 */
		nNewPos		= pProperty->m_nEnd ;
		pSrc		= pBuffer->m_bufComp + nNewPos ;
		if (pSrcCompPos != NULL && pSrcCompPos <= pSrc) {
			nReadingPosition	= pDest - pDestBuffer ;
			pSrcCompPos			= NULL ;
		}

		do {
			pProperty	= pProperty->m_pNext ;
			/*	���� property �� region-end ������ region-end �����O����
			 *	pSrc �������߂���Ă��܂��̂ŁA�p������B�ǂ݉����� overwrapped ��
			 *	�Ȃ邱�Ƃ͋����Ȃ��Ƃ���������u���Ă���B
			 */
		}	while (pProperty != NULL && pProperty->m_nEnd < nNewPos) ;
	}
	while (pDest < pDestEnd && pSrc < pSrcEnd) 
		*pDest ++	= *pSrc ++ ;

	/*	�ϊ������Ƃ������Ƃŉ��ǉ����ꂽ property ���폜����B���ƁAhenkan-start-point
	 *	�� backward ���Ă�����A1 �� forward ����B
	 */
	if (pBuffer->m_bSkkHenkanMode) {
		(void) imeBuffer_bUnregisterProperty (pBuffer, &propDuringHenkan) ;
	}
	if (bErasePrefix) {
		(void) imeBuffer_bUnregisterProperty (pBuffer, &propKanaPrefix) ;
	}
	if (bEraseOkuriMarker) {
		(void) imeBuffer_bUnregisterProperty (pBuffer, &propOkuriMarker) ;
	}
	if (pnReadingPosition != NULL)
		*pnReadingPosition	= nReadingPosition ;
	return	pDest - pDestBuffer ;
}

/*========================================================================
 */
void
ImeBuffer_vCopyState (
	struct CImeBuffer*			pThis,
	const struct CImeBuffer*	pBuffer)
{
	int		i ;

	if (pThis == NULL || pBuffer == NULL)
		return ;

	pThis->m_pDoc					= pBuffer->m_pDoc ;
	pThis->m_pParent				= pBuffer->m_pParent ;
	memcpy (pThis->m_bufComp, pBuffer->m_bufComp, pBuffer->m_nbufComp * sizeof (DCHAR)) ;
	pThis->m_nbufComp				= pBuffer->m_nbufComp ;
	pThis->m_iteSkkRuleTree			= pBuffer->m_iteSkkRuleTree ;
	for (i = 0 ; i < MAX_RESERVED_MARKERS ; i ++) {
		if (pBuffer->m_rpmkMarker [i] != NULL) {
			if (pThis->m_rpmkMarker [i] != NULL) {
				TMarker_bSetPosition (pThis->m_rpmkMarker [i], pBuffer->m_rpmkMarker [i]) ;
			} else {
				pThis->m_rpmkMarker [i]	= NULL ;
			}
		}
	}
	if (pBuffer->m_pmkPoint != NULL) {
		pThis->m_pmkPoint			= pThis->m_rpmkMarker [MARKER_POINT] ;
	} else {
		pThis->m_pmkPoint			= NULL ;
	}
	if (pBuffer->m_pmkSkkKanaStartPoint != NULL) {
		pThis->m_pmkSkkKanaStartPoint	= pThis->m_rpmkMarker [MARKER_SKK_KANA_START_POINT] ;
	} else {
		pThis->m_pmkSkkKanaStartPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkPreviousPoint != NULL) {
		pThis->m_pmkSkkPreviousPoint	= pThis->m_rpmkMarker [MARKER_SKK_PREVIOUS_POINT] ;
	} else {
		pThis->m_pmkSkkPreviousPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkHenkanStartPoint != NULL) {
		pThis->m_pmkSkkHenkanStartPoint	= pThis->m_rpmkMarker [MARKER_SKK_HENKAN_START_POINT] ;
	} else {
		pThis->m_pmkSkkHenkanStartPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkHenkanEndPoint != NULL) {
		pThis->m_pmkSkkHenkanEndPoint	= pThis->m_rpmkMarker [MARKER_SKK_HENKAN_END_POINT] ;
	} else {
		pThis->m_pmkSkkHenkanEndPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkOkuriganaStartPoint != NULL) {
		pThis->m_pmkSkkOkuriganaStartPoint	= pThis->m_rpmkMarker [MARKER_SKK_OKURIGANA_START_POINT] ;
	} else {
		pThis->m_pmkSkkOkuriganaStartPoint	= NULL ;
	}
	if (pBuffer->m_nSkkPrefixLen > 0)
		memcpy (pThis->m_bufSkkPrefix, pBuffer->m_bufSkkPrefix, sizeof (DCHAR) * pBuffer->m_nSkkPrefixLen) ;
	pThis->m_nSkkPrefixLen				= pBuffer->m_nSkkPrefixLen ;
	if (pBuffer->m_nSkkHenkanKeyLen > 0)
		memcpy (pThis->m_bufSkkHenkanKey, pBuffer->m_bufSkkHenkanKey, sizeof (DCHAR) * pBuffer->m_nSkkHenkanKeyLen) ;
	pThis->m_nSkkHenkanKeyLen			= pBuffer->m_nSkkHenkanKeyLen ;
	pThis->m_bSkkModeInvoked			= pBuffer->m_bSkkModeInvoked ;
	pThis->m_bSkkMode					= pBuffer->m_bSkkMode ;
	pThis->m_bSkkLatinMode				= pBuffer->m_bSkkLatinMode ;
	pThis->m_bSkkJMode					= pBuffer->m_bSkkJMode ;
	pThis->m_bSkkJisx0208LatinMode		= pBuffer->m_bSkkJisx0208LatinMode ;
	pThis->m_bSkkAbbrevMode				= pBuffer->m_bSkkAbbrevMode ;
	pThis->m_bSkkJisx0201Mode			= pBuffer->m_bSkkJisx0201Mode ;
	pThis->m_bSkkKatakana				= pBuffer->m_bSkkKatakana ;
	pThis->m_bSkkHenkanMode				= pBuffer->m_bSkkHenkanMode ;
	pThis->m_bSkkKakuteiFlag			= pBuffer->m_bSkkKakuteiFlag ;
	pThis->m_bSkkAfterPrefix			= pBuffer->m_bSkkAfterPrefix ;
	pThis->m_bSkkHenkanInMinibuffFlag	= pBuffer->m_bSkkHenkanInMinibuffFlag ;
	pThis->m_iSkkHenkanCount			= pBuffer->m_iSkkHenkanCount ;
	pThis->m_bSkkExitShowCandidates		= pBuffer->m_bSkkExitShowCandidates ;
	if (pBuffer->m_nSkkHenkanOkuriganaLen > 0)
		memcpy (pThis->m_bufSkkHenkanOkurigana, pBuffer->m_bufSkkHenkanOkurigana, sizeof (DCHAR) * pBuffer->m_nSkkHenkanOkuriganaLen) ;
	pThis->m_nSkkHenkanOkuriganaLen		= pBuffer->m_nSkkHenkanOkuriganaLen ;
	if (pBuffer->m_nSkkOkuriCharLen > 0)
		memcpy (pThis->m_bufSkkOkuriChar, pBuffer->m_bufSkkOkuriChar, sizeof (DCHAR) * pBuffer->m_nSkkOkuriCharLen) ;
	pThis->m_nSkkOkuriCharLen			= pBuffer->m_nSkkOkuriCharLen ;
	pThis->m_bSkkOkurigana				= pBuffer->m_bSkkOkurigana ;
	pThis->m_iSkkOkuriIndexMin			= pBuffer->m_iSkkOkuriIndexMin ;
	pThis->m_iSkkOkuriIndexMax			= pBuffer->m_iSkkOkuriIndexMax ;

	if (pBuffer->m_nKakuteiMidasiLen > 0)
		memcpy (pThis->m_bufKakuteiMidasi, pBuffer->m_bufKakuteiMidasi, sizeof (DCHAR) * pBuffer->m_nKakuteiMidasiLen) ;
	pThis->m_nKakuteiMidasiLen			= pBuffer->m_nKakuteiMidasiLen ;
	if (pBuffer->m_nKakuteiWordLen > 0)
		memcpy (pThis->m_bufKakuteiWord, pBuffer->m_bufKakuteiWord, sizeof (DCHAR) * pBuffer->m_nKakuteiWordLen) ;
	pThis->m_nKakuteiWordLen			= pBuffer->m_nKakuteiWordLen ;
	pThis->m_bSkkCurrentKutotenType		= pBuffer->m_bSkkCurrentKutotenType ;
	if (pBuffer->m_nLatestShiftTextLen > 0)
		memcpy (pThis->m_bufLatestShiftText, pBuffer->m_bufLatestShiftText, sizeof (DCHAR) * pBuffer->m_nLatestShiftTextLen) ;
	pThis->m_nLatestShiftTextLen		= pBuffer->m_nLatestShiftTextLen ;

	pThis->m_bSkkHenkanShowCandidatesMode	= pBuffer->m_bSkkHenkanShowCandidatesMode ;
	pThis->m_bSkkInputByCodeOrMenuMode		= pBuffer->m_bSkkInputByCodeOrMenuMode ;
	pThis->m_bSkkInputByCodeOrMenu1Mode		= pBuffer->m_bSkkInputByCodeOrMenu1Mode ;
	pThis->m_nLineOffset					= pBuffer->m_nLineOffset ;

	if (pBuffer->m_plstProperty != NULL) {
		imeBuffer_vCopyProperty (pThis, pBuffer->m_plstProperty) ;
	} else {
		imeBuffer_vClearProperty (pThis) ;
	}
	return ;
}

/*========================================================================
 */
BOOL
imeBuffer_bSkkKakuteiCleanupBuffer (
	struct CImeBuffer*	pBuffer)
{
	if (pBuffer->m_bSkkOkurigana) {
		imeBuffer_bSkkDeleteOkuriMark (pBuffer) ;
	}
	imeBuffer_bSkkDeleteHenkanMarkers (pBuffer, FALSE) ;
	return	TRUE ;
}

BOOL
imeBuffer_bSkkKakuteiInitialize (
	struct CImeBuffer*	pBuffer,
	LPCDSTR				wstrKakuteiWord,
	int					nKakuteiWordLen)
{
	pBuffer->m_bSkkAbbrevMode			= LFALSE ;
	pBuffer->m_bSkkExitShowCandidates	= LFALSE ;
	pBuffer->m_iSkkHenkanCount			= -1 ;
	pBuffer->m_bSkkHenkanInMinibuffFlag	= LFALSE ;
	pBuffer->m_nSkkHenkanKeyLen			= 0 ;
	pBuffer->m_nSkkHenkanOkuriganaLen	= 0 ;
	/* skk-henkan-list�H �����Ǘ����郊�X�g���낤�H */
	pBuffer->m_bSkkHenkanMode			= LFALSE ;
	pBuffer->m_bSkkKakuteiFlag			= LFALSE ;
	pBuffer->m_nSkkOkuriCharLen			= 0 ;
	pBuffer->m_iSkkOkuriIndexMin		= -1 ;
	pBuffer->m_iSkkOkuriIndexMax		= -1 ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wstrKakuteiWord) ;
	UNREFERENCED_PARAMETER (nKakuteiWordLen) ;
}

BOOL
imeBuffer_bSkkInsertStr (
	struct CImeBuffer*	pBuffer,
	LPCDSTR				pwString,
	int					nString)
{
	if (! ImeBuffer_bInsertAndInherit (pBuffer, pwString, nString))
		return	FALSE ;
	if (pBuffer->m_bSkkHenkanMode ==LON) {
		if (ImeConfig_bSkkAutoStartHenkanp () && ! pBuffer->m_bSkkOkurigana) {
			/* bSkkAutoStartHenkan (pwString, nString) ; */
		}
	} else {
		/* �I���W�i���� self-insert-after-hook ���Ăяo���Ă��邪�A�������ɂ��̎����̓p�X����B*/
		/* overwrite-mode �͑��݂��Ȃ��̂ŁA���̑�����Ȃ��B*/
	}
	if (pBuffer->m_bSkkJMode && ! pBuffer->m_bSkkHenkanMode) {
		/* skk-do-auto-fill �͑��݂��Ȃ��̂ŁA���̒��g�͋�ł���B*/
	}
	return	TRUE ;
}

BOOL
imeBuffer_bSkkModeInvoke (struct CImeBuffer* pBuffer)
{
	/*	�������͂��s���ꍇ�̏����ݒ�A���B�Ȃ�قǁB���̓p�X�B�������ł������Ȃ̂́A
	 *	�c�Ȃ����ȁB���̊֐��̓X���[����B*/
	pBuffer->m_bSkkModeInvoked	= LTRUE ;
	return	TRUE ;
}

BOOL
imeBuffer_bSkkModeOff (struct CImeBuffer* pBuffer)
{
	pBuffer->m_bSkkMode					= LFALSE ;
	pBuffer->m_bSkkAbbrevMode			= LFALSE ;
	pBuffer->m_bSkkLatinMode			= LFALSE ;
	pBuffer->m_bSkkJMode				= LFALSE ;
	pBuffer->m_bSkkJisx0208LatinMode	= LFALSE ;
	pBuffer->m_bSkkJisx0201Mode			= LFALSE ;
	pBuffer->m_bSkkKatakana				= LFALSE ;
	/* skk-cursor-off? */
	/* remove-hook �͕s�v�B*/
	return	TRUE ;
}

BOOL
imeBuffer_bSkkJModeOn (
	struct CImeBuffer*	pBuffer,
	int					nKatakana)
{
	pBuffer->m_bSkkMode					= LTRUE ;
	pBuffer->m_bSkkAbbrevMode			= LFALSE ;
	pBuffer->m_bSkkLatinMode			= LFALSE ;
	pBuffer->m_bSkkJMode				= LTRUE ;
	pBuffer->m_bSkkJisx0208LatinMode	= LFALSE ;
	pBuffer->m_bSkkJisx0201Mode			= LFALSE ;
	pBuffer->m_bSkkKatakana				= nKatakana ;
//	imeBuffer_bSkkSetupKeymap (pBuffer) ;	/* keymap �̐ݒ肩�c�ǂ��������̂��B*/
	return	TRUE ;
}

BOOL
imeBuffer_bSkkLatinModeOn (struct CImeBuffer* pBuffer)
{
	pBuffer->m_bSkkMode					= LTRUE ;
	pBuffer->m_bSkkAbbrevMode			= LFALSE ;
	pBuffer->m_bSkkLatinMode			= LTRUE ;
	pBuffer->m_bSkkJMode				= LFALSE ;
	pBuffer->m_bSkkJisx0208LatinMode	= LFALSE ;
	pBuffer->m_bSkkJisx0201Mode			= LFALSE ;
	pBuffer->m_bSkkKatakana				= LFALSE ;
//	imeBuffer_bSkkSetupKeymap (pBuffer) ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

BOOL
imeBuffer_bSkkJisx0208LatinModeOn (struct CImeBuffer* pBuffer)
{
	pBuffer->m_bSkkMode					= LTRUE ;
	pBuffer->m_bSkkAbbrevMode			= LFALSE ;
	pBuffer->m_bSkkLatinMode			= LFALSE ;
	pBuffer->m_bSkkJMode				= LFALSE ;
	pBuffer->m_bSkkJisx0208LatinMode	= LTRUE ;
	pBuffer->m_bSkkJisx0201Mode			= LFALSE ;
	pBuffer->m_bSkkKatakana				= LFALSE ;
//	imeBuffer_bSkkSetupKeymap (pBuffer) ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

BOOL
imeBuffer_bSkkAbbrevModeOn (struct CImeBuffer* pBuffer)
{
	pBuffer->m_bSkkMode					= LTRUE ;
	pBuffer->m_bSkkAbbrevMode			= LTRUE ;
	pBuffer->m_bSkkLatinMode			= LFALSE ;
	pBuffer->m_bSkkJMode				= LFALSE ;
	pBuffer->m_bSkkJisx0208LatinMode	= LFALSE ;
	pBuffer->m_bSkkJisx0201Mode			= LFALSE ;
	pBuffer->m_bSkkKatakana				= LFALSE ;
//	imeBuffer_bSkkSetupKeymap (pBuffer) ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

BOOL
imeBuffer_bSkkJisx0201ModeOn (
	struct CImeBuffer*		pBuffer,
	BOOL					bRoman)
{
	pBuffer->m_bSkkMode					= LTRUE ;
	pBuffer->m_bSkkJisx0201Mode			= LTRUE ;
	pBuffer->m_bSkkJisx0201Roman		= bRoman? LTRUE : LFALSE ;
	pBuffer->m_bSkkAbbrevMode			= LFALSE ;
	pBuffer->m_bSkkLatinMode			= LFALSE ;
	pBuffer->m_bSkkJMode				= LFALSE ;
	pBuffer->m_bSkkJisx0208LatinMode	= LFALSE ;
	pBuffer->m_bSkkKatakana				= LFALSE ;

	// skk-rule-tree...
	SkkRuleTreeIterator_vMoveTree (&pBuffer->m_iteSkkRuleTree, bRoman? RULETREENO_SKK_JISX0201_ROMAN : RULETREENO_SKK_JISX0201_BASE) ;
//	_bSkkSetupKeymap () ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

BOOL
imeBuffer_bSkkSetMarker (
	struct CImeBuffer*			pBuffer,
	struct TMarker**			ppMarker,
	int							nMarkerIndex,
	const struct TMarker*		pSource)
{
	return	ImeBuffer_bSetMarker (pBuffer, ppMarker, nMarkerIndex, pSource) ;
}

BOOL
imeBuffer_bSkkErasePrefix (
	struct CImeBuffer*	pBuffer,
	BOOL				bClean)
{
	int		nStart ;

	if (ImeConfig_bSkkEchop () && pBuffer->m_pmkSkkKanaStartPoint != NULL && pBuffer->m_nSkkPrefixLen > 0) {
		nStart	= TMarker_iGetPosition (pBuffer->m_pmkSkkKanaStartPoint) ;
		if (! ImeBuffer_bDeleteRegion (pBuffer, nStart, nStart + pBuffer->m_nSkkPrefixLen)) {
			pBuffer->m_nSkkPrefixLen		= 0 ;
			SkkRuleTreeIterator_vReset (&pBuffer->m_iteSkkRuleTree) ;
//			pBuffer->m_pSkkCurrentRuleTree	= NULL ;
		}
	}
	if (bClean) {
		pBuffer->m_nSkkPrefixLen			= 0 ;
		SkkRuleTreeIterator_vReset (&pBuffer->m_iteSkkRuleTree) ;
//		pBuffer->m_pSkkCurrentRuleTree	= NULL ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_bSkkInsertPrefix (
	struct CImeBuffer*	pBuffer,
	LPCDSTR				wstrPrefix,
	int					nstrPrefixLen)
{
	if (ImeConfig_bSkkEchop ()) {
		if (wstrPrefix != NULL && nstrPrefixLen > 0) {
			return	ImeBuffer_bInsertAndInherit (pBuffer, wstrPrefix, nstrPrefixLen) ;
		} else {
			return	ImeBuffer_bInsertAndInherit (pBuffer, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;
		}
	} else {
		return	TRUE ;
	}
}

BOOL
imeBuffer_bSkkChangeMarkerToWhite (
	struct CImeBuffer*			pBuffer)
{
	struct TMarker*	pmkMark ;
	int			nPos ;

	pmkMark		= ImeBuffer_pMakeMarker (pBuffer, TRUE) ;
	if (pmkMark == NULL)
		return	FALSE ;

	if (pBuffer->m_pmkSkkHenkanStartPoint != NULL) {
		TMarker_bSetPosition (pBuffer->m_pmkPoint, pBuffer->m_pmkSkkHenkanStartPoint) ;
		TMarker_bBackward (pBuffer->m_pmkPoint, 1) ;
		nPos	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
		if (0 <= nPos && nPos < pBuffer->m_nbufComp && pBuffer->m_bufComp [nPos] == L'��') {
			ImeBuffer_bInsertAndInheritW (pBuffer, L"��", 1) ;
			ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint) + 1) ;
		} else {
			TMarker_bSetPosition (pBuffer->m_pmkPoint, pBuffer->m_pmkSkkHenkanStartPoint) ;
			ImeBuffer_bInsertAndInheritW (pBuffer, L"��", 1) ;
			imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanStartPoint, MARKER_SKK_HENKAN_START_POINT, pBuffer->m_pmkPoint) ;
			/* (skk-message It semms .. */
		}
	}
	pBuffer->m_pmkSkkHenkanEndPoint	= NULL ;
	pBuffer->m_bSkkHenkanMode		= LON ;
	TMarker_bSetPosition (pBuffer->m_pmkPoint, pmkMark) ;
	ImeBuffer_bDeleteMarker (pBuffer, pmkMark) ;
	return	TRUE ;
}

BOOL
imeBuffer_bSkkUpdateKakuteiHistory (
	struct CImeBuffer*	pBuffer,
	LPCDSTR				pMidashi,
	int					nMidashiLen,
	LPCDSTR				pWord,
	int					nWordLen)
{
	LPCDSTR	ptr, ptrEnd ;

	pBuffer->m_nKakuteiMidasiLen	= MIN (nMidashiLen, ARRAYSIZE (pBuffer->m_bufKakuteiMidasi)) ;
	if (pBuffer->m_nKakuteiMidasiLen <= 0)
		return	FALSE ;
	memcpy (pBuffer->m_bufKakuteiMidasi, pMidashi, pBuffer->m_nKakuteiMidasiLen * sizeof (DCHAR)) ;

	/*	annotation ���O���ēo�^���Ă����H ���ꂼ��̒P��� annotation ��A���������̂��A�A�����ʂ� annotation
	 *	�Ƃ��ēK�؂��ǂ����͕�����Ȃ��̂ŁB
	 */
	if (nWordLen > 0) {
		ptr		= pWord ;
		ptrEnd	= pWord + nWordLen ;
		while (ptr < ptrEnd && *ptr != L';')
			ptr	++ ;
		nWordLen	= ptr - pWord ;

		pBuffer->m_nKakuteiWordLen	= MIN (nWordLen, ARRAYSIZE (pBuffer->m_bufKakuteiWord)) ;
		if (pBuffer->m_nKakuteiWordLen > 0) 
			memcpy (pBuffer->m_bufKakuteiWord, pWord, pBuffer->m_nKakuteiWordLen * sizeof (DCHAR)) ;
	} else {
		pBuffer->m_nKakuteiWordLen	= 0 ;
	}
	TRecordKakuteiHistorySession_bUpdate (pBuffer->m_bufKakuteiMidasi, pBuffer->m_nKakuteiMidasiLen, pBuffer->m_bufKakuteiWord, pBuffer->m_nKakuteiWordLen) ;
	return	TRUE ;
}


BOOL
imeBuffer_bSkkDeleteHenkanMarkers (
	struct CImeBuffer*	pBuffer,
	BOOL				bNoMsg)
{
	int		nPos ;

	if (pBuffer->m_pmkSkkHenkanStartPoint != NULL) {
		nPos	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) - 1 ;
		if (pBuffer->m_bSkkHenkanMode ==LACTIVE) {
			if (0 <= nPos && nPos < pBuffer->m_nbufComp && pBuffer->m_bufComp [nPos] == L'��') {
				ImeBuffer_bDeleteRegion (pBuffer, nPos, nPos + 1) ;
			} else {
				if (! bNoMsg) {
					/* (skk-message "It seems that you have deleted ��") */
					ImeDoc_bSetMessageW (pBuffer->m_pDoc, L"It seems that you have deleted ��") ;
				}
			}
		} else if (0 <= nPos && nPos < pBuffer->m_nbufComp && pBuffer->m_bufComp [nPos] == L'��') {
			ImeBuffer_bDeleteRegion (pBuffer, nPos, nPos + 1) ;
		} else if (! bNoMsg) {
			/* (skk-message "It seems that you have deleted ��") */
			ImeDoc_bSetMessageW (pBuffer->m_pDoc, L"It seems that you have deleted ��") ;
		}
	}
	return	TRUE ;
}

BOOL
imeBuffer_bSkkDeleteOkuriMark (struct CImeBuffer* pBuffer)
{
	int		nPos ;

	if (pBuffer->m_bSkkOkurigana && pBuffer->m_pmkSkkOkuriganaStartPoint != NULL) {
		nPos	= TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint) ;
		if (0 <= nPos && nPos < pBuffer->m_nbufComp && pBuffer->m_bufComp [nPos] == L'*') {
			ImeBuffer_bDeleteRegion (pBuffer, nPos, nPos + 1) ;
		}
		pBuffer->m_bSkkOkurigana			= LFALSE ;
		pBuffer->m_nSkkOkuriCharLen			= 0 ;
		pBuffer->m_nSkkHenkanOkuriganaLen	= 0 ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_bSkkInsertNewWord (
	struct CImeBuffer*	pBuffer,
	LPCDSTR				wstrNewWord,
	int					nNewWordLen)
{
	LPCDSTR			wstrNote, wstrWord ;
	int				nNoteLen, nWordLen ;
	DCHAR			bufTemp [MAXCOMPLEN] ;
	int				iShowAnnotationType ;
	BOOL			bRetval ;

	iShowAnnotationType	= ImeConfig_iGetSkkShowAnnotationType () ;
	wstrNote			= NULL ;
	nNoteLen			= 0 ;

	/* Annotation �̃`�F�b�N�B*/
	wstrWord	= wstrNewWord ;
	nWordLen	= nNewWordLen ;
	wstrNote	= NULL ;
	nNoteLen	= 0 ;
	if (iShowAnnotationType != DISABLE_ANNOTATION) {
		LPCDSTR	wptr, wptrEnd ;

		wptr	= wstrNewWord ;
		wptrEnd	= wstrNewWord + nNewWordLen ;
		while (wptr < wptrEnd && *wptr != L';')
			wptr	++ ;
		if (wptr < wptrEnd) {
			wstrNote	= wptr + 1 ;
			nNoteLen	= wptrEnd - wstrNote ;
			wstrWord	= wstrNewWord ;
			nWordLen	= wptr - wstrWord ;
		}
	}

	/*	word �̐擪�ƍŌオ ( �� ) �Ȃ� eval ���Ă݂�B
	 *	�{���� Annotation �� eval ���Ȃ��Ƃ����Ȃ��c�B���̂Ȃ� Annotation �� ; �� / �� [
	 *	�Ȃǂ̕������g���������R�����邩������Ȃ�����B
	 */
	if (nWordLen > 1 && wstrWord [0] == L'(' && wstrWord [nWordLen - 1] == L')') {
		/* Numeric List �� Count �� bSetNumberList ���Ŏ��s����B*/
		if (pBuffer->m_pSkkCurrentSearchProgSession != NULL && TSearchSession_bNumericp (pBuffer->m_pSkkCurrentSearchProgSession)) {
			TLispSession_bSetNumberList (TSearchSession_pGetNumericList (pBuffer->m_pSkkCurrentSearchProgSession)) ;
		} else {
			TLispSession_bSetNumberList (NULL) ;
		}
		if (TLispSession_bEval (wstrWord, nWordLen, bufTemp, ARRAYSIZE (bufTemp) - 1)) {
			bufTemp [ARRAYSIZE (bufTemp) - 1]	= L'\0' ;
			wstrWord	= bufTemp ;
			nWordLen	= dcslen (bufTemp) ;
		}
	}

	/* (skk-lisp-prog-p word) �͍��̂Ƃ��� FALSE */
	if (pBuffer->m_pmkSkkHenkanStartPoint == NULL || pBuffer->m_pmkSkkHenkanEndPoint == NULL)
		return	FALSE ;
	/*	DeleteRegion ���Ă��܂��ƁA��J�[�\���}�[�J�̈ʒu�������\���������B
	 *	�u�ꎞ�I�ɃJ�[�\���}�[�J�ɕύX����v���A
	 *	�u�㏑�����ė]��������A�㏑�����đ���Ȃ�������}������v��
	 *	�������A��҂̏ꍇ�A�ϊ����ʂ��Ȃ��Ȃ��Ă��܂��i����Ȃ��Ƃ�����̂��A�����j
	 */
	(void) TMarker_bSetCursor (pBuffer->m_pmkSkkKanaStartPoint,			TRUE) ;
	(void) TMarker_bSetCursor (pBuffer->m_pmkSkkOkuriganaStartPoint,	TRUE) ;
	ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint)) ;
	TMarker_bSetPosition (pBuffer->m_pmkPoint, pBuffer->m_pmkSkkHenkanStartPoint) ;
	bRetval	= ImeBuffer_bInsertAndInherit (pBuffer, wstrWord, nWordLen) ;
	(void) TMarker_bSetCursor (pBuffer->m_pmkSkkKanaStartPoint,			FALSE) ;
	(void) TMarker_bSetCursor (pBuffer->m_pmkSkkOkuriganaStartPoint,	FALSE) ;
	if (! bRetval)
		return	FALSE ;
	if (! imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, pBuffer->m_pmkPoint))
		return	FALSE ;

	/*	��⃊�X�g���炱���͌Ă΂�Ȃ��Ǝv���̂ŁAALWAYS �ȊO�Ȃ�\���̕K�v�͂Ȃ��B*/
	if (! pBuffer->m_bSkkKakuteiFlag && iShowAnnotationType == SHOW_ANNOTATION_ALWAYS && nNoteLen > 0) {
		/* (skk-annotation-show note) */
		DCHAR	bufTempAnnot [MAXCOMPLEN] ;
		if (nNoteLen > 1 && wstrNote [0] == L'(' && wstrNote [nNoteLen - 1] == L')') {
			if (TLispSession_bEval (wstrNote, nNoteLen, bufTempAnnot, ARRAYSIZE (bufTempAnnot) - 1)) {
				bufTempAnnot [ARRAYSIZE (bufTempAnnot) - 1]	= L'\0' ;
				wstrNote	= bufTempAnnot ;
				nNoteLen	= dcslen (bufTempAnnot) ;
			}
		}
		ImeDoc_bSetMessageN (pBuffer->m_pDoc, wstrNote, nNoteLen) ;
	}
	/* skk-insert-new-word-function �̎����͂Ȃ��B*/
	return	TRUE ;
}

BOOL
imeBuffer_bSkkNumUpdateJisyo (
	struct CImeBuffer*	pBuffer)
{
	struct CTS4Candidate*	pNumCand ;
	int		n ;
	BOOL	bRetval ;

	/*	���o���B
	 */
	if (pBuffer->m_pSkkCurrentSearchProgSession == NULL)
		return	FALSE ;
	TSearchSession_bRewind (pBuffer->m_pSkkCurrentSearchProgSession) ;
	for (n = 0 ; n < pBuffer->m_iSkkHenkanCount ; n ++) {
		if (! TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession))
			return	FALSE ;
	}

	/*	#4 �̕ϊ����ʂ̎��� update ������B
	 */
	bRetval		= TRUE ;
	pNumCand	= TSearchSession_pGetNumericLink (pBuffer->m_pSkkCurrentSearchProgSession) ;
	while (pNumCand != NULL) {
		LPCDSTR		pwKey, pwResult ;
		int			nKeyLen, nResultLen ;

		pwKey		= TSearchSession_pGetNumericKeyword (pBuffer->m_pSkkCurrentSearchProgSession, pNumCand, &nKeyLen) ;
		pwResult	= TSearchSession_pGetNumericResult  (pBuffer->m_pSkkCurrentSearchProgSession, pNumCand, &nResultLen) ;

		/*	pwKey, nKeyLen, pwResult, nResultLen �� update ��������B
		 *	���艼���͂Ȃ��B
		 */
		if (nKeyLen > 0 && nResultLen > 0) {
			if (! TRecordSession_bUpdate (pwKey, nKeyLen, pwResult, nResultLen, NULL, 0, FALSE)) {
				bRetval	= FALSE ;
				break ;
			}
		}
		pNumCand	= TSearchSession_pGetNextNumericLink (pBuffer->m_pSkkCurrentSearchProgSession, pNumCand) ;
	}
	return	bRetval ;
}

/*	
 */
int
imeBuffer_iSkkOkuriganaPrefix (
	struct CImeBuffer*	pBuffer,
	LPCDSTR				strOkurigana,
	int					nOkuriganaLen,
	LPDSTR				pOkuriganaPrefix,
	int					nOkuriganaPrefixSize)
{
	int		nHeadChar ;

	if (nOkuriganaLen <= 0 || strOkurigana == NULL) 
		return	0 ;

	nHeadChar	= strOkurigana [0] ;
	if (nHeadChar == L'��') {
		if (nOkuriganaPrefixSize > 0) {
			*pOkuriganaPrefix	= L'n' ;
			return	1 ;
		} else {
			return	0 ;
		}
	} else if (nHeadChar == L'��' && nOkuriganaLen != 1) {
		return	ImeConfig_iSkkARefSkkKanaRomVector (strOkurigana [1], pOkuriganaPrefix, nOkuriganaPrefixSize) ;
	} else {
		return	ImeConfig_iSkkARefSkkKanaRomVector (strOkurigana [0], pOkuriganaPrefix, nOkuriganaPrefixSize) ;
	}
}

LPCDSTR
imeBuffer_pSkkGetCurrentCandidate (struct CImeBuffer* pBuffer)
{
	int		n ;

	if (pBuffer->m_pSkkCurrentSearchProgSession == NULL)
		return	NULL ;
	TSearchSession_bRewind (pBuffer->m_pSkkCurrentSearchProgSession) ;
	for (n = 0 ; n < pBuffer->m_iSkkHenkanCount ; n ++) {
		if (! TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession))
			return	NULL ;
	}
	return	TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
}

BOOL
imeBuffer_bValidRegionp (struct CImeBuffer* pBuffer, int nStartPos, int nEndPos)
{
	struct TMarker*	pmkBufferTop	= NULL ;
	struct TMarker*	pmkBufferEnd	= NULL ;
	int		nBufferTop, nBufferEnd ;

	if (ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkBufferTop) && pmkBufferTop != NULL) {
		nBufferTop	= TMarker_iGetPosition (pmkBufferTop) ;
	} else {
		nBufferTop	= 0 ;
	}
	if (ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkBufferEnd) && pmkBufferEnd != NULL) {
		nBufferEnd	= TMarker_iGetPosition (pmkBufferEnd) ;
	} else {
		nBufferEnd	= pBuffer->m_nbufComp ;
	}
	if (nStartPos > nEndPos || nEndPos < nBufferTop || nStartPos >= nBufferEnd) {
		return	FALSE ;
	}
	return	TRUE ;
}

/*========================================================================
 *	private functions
 */
int
imeBuffer_iGetShiftCount (
	struct CImeBuffer*			pBuffer)
{
	register int	nCursor, nShift ;
	register int	nKanaStartPoint, nHenkanStartPoint, nHenkanEndPoint ;
	register int	nOkuriStartPoint ;

	nCursor	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;

	if (! ImeBuffer_bJModep (pBuffer) && ! ImeBuffer_bAbbrevModep (pBuffer) && 
		(! ImeBuffer_bJisx0201Modep (pBuffer) || ImeBuffer_bJisx0201Romanp (pBuffer)))
		return	nCursor ;

	nKanaStartPoint		= (pBuffer->m_nSkkPrefixLen > 0 && pBuffer->m_pmkSkkKanaStartPoint      != NULL)? TMarker_iGetPosition (pBuffer->m_pmkSkkKanaStartPoint)			: MAXCOMPLEN ;
	nHenkanStartPoint	= (pBuffer->m_bSkkHenkanMode    && pBuffer->m_pmkSkkHenkanStartPoint    != NULL)? TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) - 1	: MAXCOMPLEN ;
	nHenkanEndPoint		= (pBuffer->m_bSkkHenkanMode    && pBuffer->m_pmkSkkHenkanEndPoint      != NULL)? TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint)			: MAXCOMPLEN ;
	nOkuriStartPoint	= (pBuffer->m_bSkkOkurigana     && pBuffer->m_pmkSkkOkuriganaStartPoint != NULL)? TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint)	: MAXCOMPLEN ;
	
	nShift	= nCursor ;
	nShift	= (nShift > nKanaStartPoint)?   nKanaStartPoint :   nShift ;
	nShift	= (nShift > nHenkanStartPoint)? nHenkanStartPoint : nShift ;
	nShift	= (nShift > nHenkanEndPoint)?   nHenkanEndPoint :   nShift ;
	nShift	= (nShift > nOkuriStartPoint)?  nOkuriStartPoint :  nShift ;
	return	nShift ;
}

BOOL
imeBuffer_bRegisterProperty (
	struct CImeBuffer*			pBuffer,
	struct CImeBufferProperty*	pProperty)
{
	struct CImeBufferProperty*	pNode ;
	struct CImeBufferProperty*	pPrevNode ;

	if (pProperty == NULL || pBuffer == NULL)
		return	FALSE ;

	pNode		= pBuffer->m_plstProperty ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		if (pNode->m_nBegin >= pProperty->m_nBegin)
			break ;
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
	}
	if (pPrevNode == NULL) {
		pProperty->m_pNext		= pBuffer->m_plstProperty ;
		pBuffer->m_plstProperty	= pProperty ;
	} else {
		pPrevNode->m_pNext		= pProperty ;
		pProperty->m_pNext		= pNode ;
	}
	return	TRUE ;
}

BOOL
imeBuffer_bUnregisterProperty (
	struct CImeBuffer*			pBuffer,
	struct CImeBufferProperty*	pProperty)
{
	struct CImeBufferProperty*	pNode ;
	struct CImeBufferProperty*	pPrevNode ;

	if (pProperty == NULL || pBuffer == NULL)
		return	FALSE ;

	pNode		= pBuffer->m_plstProperty ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		if (pNode == pProperty) {
			if (pPrevNode == NULL) {
				pBuffer->m_plstProperty	= pNode->m_pNext ;
			} else {
				pPrevNode->m_pNext		= pNode->m_pNext ;
			}
			pNode->m_pNext	= NULL ;
			return	TRUE ;
		}
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
	}
	return	FALSE ;
}

void
imeBuffer_vClearProperty (struct CImeBuffer* pBuffer)
{
	struct CImeBufferProperty*	pNode ;
	struct CImeBufferProperty*	pNextNode ;

	if (pBuffer == NULL || pBuffer->m_plstProperty == NULL) 
		return ;

	pNode	= pBuffer->m_plstProperty ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		/*	�����j���Ȃ̂� marker �̔j���͂��Ȃ��c�B
		 */
		FREE (pNode) ;
		pNode		= pNextNode ;
	}
	pBuffer->m_plstProperty	= NULL ;
	return ;
}

void
imeBuffer_vUpdateProperty (struct CImeBuffer* pBuffer)
{
	struct CImeBufferProperty*	pNode ;
	struct CImeBufferProperty*	pNextNode ;
	struct CImeBufferProperty*	pPrevNode ;

	if (pBuffer == NULL || pBuffer->m_plstProperty == NULL) 
		return ;

	pNode		= pBuffer->m_plstProperty ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		/*	�̈悪��ɂȂ�����A���� property �͔j�������B*/
		if (pNode->m_nBegin >= pNode->m_nEnd) {
			FREE (pNode) ;

			if (pPrevNode != NULL) {
				pPrevNode->m_pNext	= pNextNode ;
			} else {
				pBuffer->m_plstProperty	= pNextNode ;
			}
			/*	���̏ꍇ�ANode �͔j�����ꂽ�̂ŁA���O�� Node �͂��̂܂܂ł���B*/
		} else {
			/*	���̏ꍇ�APrevNode �� update */
			pPrevNode	= pNode ;
		}
		pNode		= pNextNode ;
	}
	return ;
}

void
imeBuffer_vCopyProperty (
	struct CImeBuffer*					pBuffer,
	const struct CImeBufferProperty*	pSrc)
{
	struct CImeBufferProperty*	pProperty ;
	struct CImeBufferProperty*	pPrevNode ;

	if (pBuffer == NULL)
		return ;
	imeBuffer_vClearProperty (pBuffer) ;

	pProperty	= NULL ;
	pPrevNode	= NULL ;
	while (pSrc != NULL) {
		LPCDSTR	strReadingText ;
		LPDSTR	pwReadingText ;
		int		nReadingTextLen, nSize ;

		nReadingTextLen	= pSrc->m_nTextLen ;
		strReadingText	= pSrc->m_pwText ;

		nSize			= sizeof (struct CImeBufferProperty) + sizeof (DCHAR) * nReadingTextLen ;
		pProperty		= (struct CImeBufferProperty*) MALLOC (nSize) ;
		if (pProperty == NULL) {
			imeBuffer_vClearProperty (pBuffer) ;
			return ;
		}
		pwReadingText			= (LPDSTR)(pProperty + 1) ;
		pProperty->m_nBegin		= pSrc->m_nBegin ;
		pProperty->m_nEnd		= pSrc->m_nEnd ;
		memcpy (pwReadingText, strReadingText, sizeof (DCHAR) * nReadingTextLen) ;
		pProperty->m_pwText		= pwReadingText ;
		pProperty->m_nTextLen	= nReadingTextLen ;
		pProperty->m_pNext		= NULL ;
		if (pPrevNode != NULL) {
			pPrevNode->m_pNext	= pProperty ;
		} else {
			pBuffer->m_plstProperty	= pProperty ;
		}
		pPrevNode			= pProperty ;
		pSrc	= pSrc->m_pNext ;
	}
	return ;
}

/*========================================================================
 *	Windows �� IME �� CANDIDATELIST �Ɠ����I�� Candidate-List ���Ȃ��B
 */
#if !defined (UNITTEST)
#define	MAX_CANDLEN		(512)

BOOL
imeBuffer_bCreateHenkanCandidateList (
	struct CImeBuffer*		pBuffer,
	int						nPageStart)
{
	TVarbuffer*			pvbufCandInfo ;
	LPCANDIDATEINFO		pCandInfo ;
	LPMYCAND			pMyCand ;
	LPCANDIDATELIST		pCandList ;
	DWORD*				pCandidateOffset ;
	DWORD*				pAnnotationOffset ;
	LPMYSTR				pCandidateStr ;
	LPCDSTR				wstrResult ;
	int					nCandidate, nNeedLength, nHCount, i, nRealCand, nPageSize ;
	BOOL				bContinue ;
	DCHAR				bufTemp  [MAXCOMPLEN] ;
	DWORD				dwSize ;
	int					iAnnotationType ;

	DEBUGPRINTFEX (99, (TEXT ("imeBuffer_bCreateHenkanCandidateList (Buf:%p, s:%d)\n"), pBuffer, nPageStart)) ;

	iAnnotationType	= ImeConfig_iGetSkkShowAnnotationType () ;

	/*	�K�v�ȃ������T�C�Y�����߂�B*/
	ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint)) ;

	/*	�S�Ă̎������������āA����S����x�Ɉ����o����悤�ɂ��Ă����B*/
	(void) ImeConfig_pGetSkkHenkanShowCandidatesKeys (&nPageSize) ;
	if (nPageSize <= 0)
		return	FALSE ;
	nPageSize	= (nPageSize < IMEDOC_MAXCANDPAGESIZE)? nPageSize : IMEDOC_MAXCANDPAGESIZE ;

	nNeedLength	= 0 ;
	for (nHCount = 0 ; nHCount < nPageSize ; nHCount ++) {
		if (! TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) 
			break ;
	}
	while (nHCount -- > 0)
		TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;

	nCandidate	= TSearchSession_iGetNumberOfCandidate (pBuffer->m_pSkkCurrentSearchProgSession, &bContinue) ;
	nRealCand	= 0 ;
	TSearchSession_bRewind (pBuffer->m_pSkkCurrentSearchProgSession) ;

	/*	#4 expand �� HenkanSession ���������ŉ������Ă���Ă���̂Ŗ��ɂ��Ȃ��B
	*	Lisp Eval (�{�� + Annotation) ���Ȃ��Ǝ��ۂ̕K�v�ȕ����񒷂�������Ȃ����c�B
	 */
	do {
#if 0
		wstrResult	= TSearchSession_pGetReferCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
		if (wstrResult == NULL)
			wstrResult	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
#else
		/*	�ϊ���(or �W�J��ƌ����ׂ���)�̃��X�g���o���̂ł����āA#4 �Ƃ����ɕ\������
		 *	�̂ł͂Ȃ��Ƃ����C������B
		 */
		wstrResult	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
#endif
		if (wstrResult != NULL) {
			int			nResultLen ;
			int			nRequired ;

			/*	Lisp Eval ���K�v���ǂ������`�F�b�N���邽�߂� Annotation �Ɩ{�̂𕪗�����B
			 */
			nResultLen	= dcslen (wstrResult) ;
			if (iAnnotationType != DISABLE_ANNOTATION) {
				LPCDSTR	pwSrc, pwNote ;
				int		nWordLen, nNoteLen ;
				int		nNoteLenW = 0, nWordLenW = 0 ;

				pwSrc	= wstrResult + nResultLen - 1 ;
				while (pwSrc >= wstrResult && *pwSrc != L';') 
					pwSrc	-- ;
				if (pwSrc >= wstrResult && *pwSrc == L';') {
					pwNote		= pwSrc + 1 ;
					nNoteLen	= nResultLen - (pwNote - wstrResult) ;
					nWordLen	= pwSrc - wstrResult ;

					nNoteLenW	= dcstowcs (NULL, 0, pwNote, nNoteLen) ;
				} else {
					nNoteLen	= 0 ;
					nWordLen	= nResultLen ;
				}
				nWordLenW	= dcstowcs (NULL, 0, wstrResult, nWordLen) ;

				if (nWordLen > 1 && wstrResult [0] == L'(' && wstrResult [nWordLen - 1] == L')') {
					if (TLispSession_bEval (wstrResult, nWordLen, bufTemp, ARRAYSIZE (bufTemp) - 1)) {
						bufTemp [ARRAYSIZE (bufTemp) - 1]	= L'\0' ;
						nWordLenW	= dcstowcs (NULL, 0, bufTemp, dcslen (bufTemp)) ;
					}
				}
				if (nNoteLen > 1 && pwNote [0] == L'(' && pwNote [nNoteLen - 1] == L')') {
					if (TLispSession_bEval (pwNote, nNoteLen, bufTemp, ARRAYSIZE (bufTemp) - 1)) {
						bufTemp [ARRAYSIZE (bufTemp) - 1]	= L'\0' ;
						nNoteLenW	= dcstowcs (NULL, 0, bufTemp, dcslen (bufTemp)) ;
					}
				}
				nRequired	= nWordLenW + nNoteLenW + ((nNoteLenW > 0)? 1 : 0)  ;
			} else {
				nRequired	= dcstowcs (NULL, 0, wstrResult, nResultLen) ;
			}
			nNeedLength	+= nRequired + 1 ;
			nRealCand	++ ;
		}
	}	while (TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) ;

	/*	#4 expand ���l������
	 */
	nCandidate	= TSearchSession_iGetNumberOfCandidate (pBuffer->m_pSkkCurrentSearchProgSession, &bContinue)  ;
	if (nCandidate <= 0) 
		return	FALSE ;
	TSearchSession_bRewind (pBuffer->m_pSkkCurrentSearchProgSession) ;

	DEBUGPRINTFEX (99, (TEXT ("nCand = %d, nRealCand = %d, nPageStart=%d\n"),
						nCandidate, nRealCand, nPageStart)) ;

	dwSize			= sizeof (MYCAND) + sizeof (DWORD) * nCandidate + sizeof (MYCHAR) * nNeedLength ;
	pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pBuffer->m_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	TVarbuffer_Clear (pvbufCandInfo) ;
	if (! TVarbuffer_Require (pvbufCandInfo, dwSize))
		return	FALSE ;

	pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandInfo->dwSize		= dwSize ;
	pCandInfo->dwCount		= 1 ;
	pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
	pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
	pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * nCandidate * 2 + sizeof (MYCHAR) * nNeedLength ;
	pCandList->dwStyle		= IME_CAND_READ ;
	pCandList->dwCount		= (DWORD)nCandidate ;

	/*	PageSize �����̂Ƃ낱 7 ������ɂȂ��Ă���̂����A10 �ɂ͏o���Ȃ����̂��낤���H
	*	�� (>0����)�ɂ͂ł��Ȃ����H 1 �͌������ɂ��Ă��B
	 */
	pCandList->dwPageSize	= (nCandidate < nPageSize)? nCandidate : nPageSize ;
	pCandList->dwSelection	= nPageStart ;
	pCandList->dwPageStart	= nPageStart ;

	pCandidateStr			= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * nCandidate * 2) ;
	pCandidateOffset		= pCandList->dwOffset ;
	pAnnotationOffset		= pCandidateOffset + pCandList->dwCount ;

	for (i = 0 ; i < nCandidate ; i ++) {
		*pCandidateOffset	= (DWORD)((LPSTR)pCandidateStr - (LPSTR)pCandList) ;
		*pAnnotationOffset	= 0 ;

#if 0
		wstrResult	= TSearchSession_pGetReferCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
		if (wstrResult == NULL)
			wstrResult	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
#else
		/*	�ϊ���(or �W�J��ƌ����ׂ���)�̃��X�g���o���̂ł����āA#4 �Ƃ����ɕ\������
		 *	�̂ł͂Ȃ��Ƃ����C������B
		 */
		wstrResult	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
#endif
		if (wstrResult != NULL) {
			int			nResultLen ;

			/*	Lisp Eval ���K�v���ǂ������`�F�b�N���邽�߂� Annotation �Ɩ{�̂𕪗�����B
			 */
			nResultLen	= dcslen (wstrResult) ;
			if (iAnnotationType != DISABLE_ANNOTATION) {
				LPCDSTR	pwSrc, pwNote, pwWord ;
				int		nWordLen, nNoteLen ;

				pwSrc	= wstrResult + nResultLen - 1 ;
				pwWord	= wstrResult ;
				while (pwSrc >= wstrResult && *pwSrc != L';') 
					pwSrc	-- ;
				if (pwSrc >= wstrResult && *pwSrc == L';') {
					pwNote		= pwSrc + 1 ;
					nNoteLen	= nResultLen - (pwNote - wstrResult) ;
					nWordLen	= pwSrc - wstrResult ;
				} else {
					nNoteLen	= 0 ;
					nWordLen	= nResultLen ;
				}
				/* Word �� Eval ����K�v�����邩�ǂ����`�F�b�N����B*/
				if (nWordLen > 1 && wstrResult [0] == L'(' && wstrResult [nWordLen - 1] == L')') {
					if (TLispSession_bEval (wstrResult, nWordLen, bufTemp, ARRAYSIZE (bufTemp) - 1)) {
						bufTemp [ARRAYSIZE (bufTemp) - 1]	= L'\0' ;
						nWordLen	= dcslen (bufTemp) ;
						pwWord		= bufTemp ;
					}
				}
				DEBUGPRINTFEX (103, (TEXT ("candidate (%d) -> \"%s\"(%d)\n"), i, pwWord, nWordLen)) ;
				if (nWordLen > 0) {
					int	nWordLenW	= dcstowcs (pCandidateStr, MAX_CANDLEN, pwWord, nWordLen) ;
					pCandidateStr [nWordLenW]	= L'\0' ;
					pCandidateStr				+= nWordLenW + 1 ;
				}

				/* Annotation �� Eval ����K�v�����邩�ǂ����`�F�b�N����B*/
				if (nNoteLen > 1 && pwNote [0] == L'(' && pwNote [nNoteLen - 1] == L')') {
					if (TLispSession_bEval (pwNote, nNoteLen, bufTemp, ARRAYSIZE (bufTemp) - 1)) {
						bufTemp [ARRAYSIZE (bufTemp) - 1]	= L'\0' ;
						nNoteLen	= dcslen (bufTemp) ;
						pwNote		= bufTemp ;
					}
				}
				if (nNoteLen > 0) {
					int	nNoteLenW	= dcstowcs (pCandidateStr, MAX_CANDLEN, pwNote, nNoteLen) ;
					pCandidateStr [nNoteLenW]	= L'\0' ;
					*pAnnotationOffset			= (DWORD)((LPSTR)pCandidateStr - (LPSTR)pCandList) ;
					pCandidateStr				+= nNoteLenW + 1 ;
				}
			} else {
				int	nWordLenW ;

				DEBUGPRINTFEX (103, (TEXT ("candidate (%d) -> \"%s\"(%d)\n"), i, wstrResult, nResultLen)) ;
				nWordLenW	= dcstowcs (pCandidateStr, MAX_CANDLEN, wstrResult, nResultLen) ;
				pCandidateStr [nWordLenW]	= L'\0' ;
				pCandidateStr		+= nWordLenW + 1 ;
			}
			pCandidateOffset	++ ;
			pAnnotationOffset	++ ;
		}
		TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
	}

	/*	���ʒu��߂��BSequential �Ȃ̂��h�����B*/
	TSearchSession_bRewind (pBuffer->m_pSkkCurrentSearchProgSession) ;
	for (i = 0 ; i < nPageStart ; i ++) 
		if (! TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) 
			break ;
	ImeDoc_vSetUpdateFlag (pBuffer->m_pDoc, IMEDOC_CREATE_CANDIDATELIST) ;
	return	TRUE ;
}

BOOL
imeBuffer_bInitializeHenkanCandidateList (
	struct CImeBuffer*		pBuffer,
	int						nPageStart)
{
	TVarbuffer*			pvbufCandInfo ;
	LPMYCAND			pMyCand ;
	LPCANDIDATEINFO		pCandInfo ;
	LPCANDIDATELIST		pCandList ;
	BOOL				bNeedReconstruct ;
	int					nCandidate, nCount ;
	BOOL				bContinue ;

	ImeDoc_vClearMessage (pBuffer->m_pDoc) ;

	pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pBuffer->m_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	if (TVarbuffer_GetUsage (pvbufCandInfo) <= sizeof (MYCAND)) {
		bNeedReconstruct	= TRUE ;
		goto	exit_func ;
	}
	pMyCand		= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo	= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandList	= (LPCANDIDATELIST)&(pMyCand->cl) ;
	if (pCandInfo->dwCount == 0 || (int)pCandList->dwCount < pBuffer->m_iSkkHenkanCount) {
		bNeedReconstruct	= TRUE ;
		goto	exit_func ;
	}
	bNeedReconstruct	= FALSE ;
	if (pCandList->dwCount <= pCandList->dwPageStart) {
		nCandidate	= TSearchSession_iGetNumberOfCandidate (pBuffer->m_pSkkCurrentSearchProgSession, &bContinue) ;
		if (pCandList->dwCount < (DWORD)nCandidate) {
			/*	CandidateList ���č\������K�v������B*/
			bNeedReconstruct	= TRUE ;
		} else {
			/*	�ԈႢ�Ȃ��G���[�B*/
		}
	} else {
		/*	���̏ꍇ�ɂ͓��ɉ���������K�v�͂Ȃ��B*/
		pCandList->dwPageStart	= nPageStart ;
	}
  exit_func:
  	if (bNeedReconstruct) 
		return	imeBuffer_bCreateHenkanCandidateList (pBuffer, nPageStart) ;
	return	TRUE ;
}
#endif

/*========================================================================
 *	Windows �� IME �� CANDIDATELIST �� skk-input-by-code-or-menu-jump ���Ȃ��B
 */
#if !defined (UNITTEST)
BOOL
imeBuffer_bShowInputByCodeOrMenuJump (
	struct CImeBuffer*	pBuffer,
	int					iKcodeCharset,
	int					n1,
	int					nCodeMin,
	int					nCodeMax,
	int					nSkkCodeN1Min,
	int					nSkkCodeN1Max,
	int					nSkkCodeN2Min,
	int					nSkkCodeN2Max)
{
	TVarbuffer*		pvbufCandInfo ;
	LPMYCAND		pMyCand ;
	LPCANDIDATEINFO	pCandInfo ;
	LPCANDIDATELIST	pCandList ;
	LPMYSTR			pDest ;
	DWORD*			pOffset ;
	DWORD			dwSize ;
	int 			i, ch ;
	int				nCodeMaxHI, nCodeMaxLO, nCodeMinHI, nCodeMinLO, nNumCode ;
	int				n2, n1Orig, n2Orig, nKeys1 ;

	if (pBuffer == NULL || pBuffer->m_pDoc == NULL)
		return	FALSE ;
	if (ImeConfig_pGetSkkInputByCodeMenuKeys1 (&nKeys1) == NULL || nKeys1 <= 0 || nKeys1 >= 256) {
		return	FALSE ;
	}

	if (nCodeMax < nCodeMin)
		return	FALSE ;
	if (nCodeMax > ((nSkkCodeN1Max << 8)| nSkkCodeN2Max))
		nCodeMax	= (nSkkCodeN1Max << 8)| nSkkCodeN2Max ;
	if (nCodeMin < ((nSkkCodeN1Min << 8) | nSkkCodeN2Min))
		nCodeMin	= (nSkkCodeN1Min << 8) | nSkkCodeN2Min ;

	nCodeMaxHI	= (nCodeMax >> 8) & 0xFF ;
	nCodeMaxLO	= (nCodeMax >> 0) & 0xFF ;
	nCodeMinHI	= (nCodeMin >> 8) & 0xFF ;
	nCodeMinLO	= (nCodeMin >> 0) & 0xFF ;

	if (! ((nSkkCodeN1Max >= nCodeMaxHI && nCodeMaxHI >= nSkkCodeN1Min) &&
		   (nSkkCodeN1Max >= nCodeMinHI && nCodeMinHI >= nSkkCodeN1Min) &&
		   (nSkkCodeN2Max >= nCodeMinLO && nCodeMinLO >= nSkkCodeN2Min) &&
		   (nSkkCodeN2Max >= nCodeMinLO && nCodeMinLO >= nSkkCodeN2Min))) 
		return	FALSE ;

	if (MIN (nSkkCodeN1Max, nCodeMaxHI) == MAX (nSkkCodeN1Min, nCodeMinHI)) {
		nNumCode	= 1 * (MIN (nSkkCodeN2Max, nCodeMaxLO) - MAX (nSkkCodeN2Min, nCodeMinLO)) / 16 ;
	} else if (MIN (nSkkCodeN1Max, nCodeMaxHI) > MAX (nSkkCodeN1Min, nCodeMinHI)) {
		nNumCode	= (MIN (nSkkCodeN1Max, nCodeMaxHI) - MAX (nSkkCodeN1Min, nCodeMinHI) - 1) * ((nSkkCodeN2Max - nSkkCodeN2Min + 16) / 16) ;
		nNumCode	+= (nSkkCodeN2Max - nCodeMinLO    + 16) / 16 ;
		nNumCode	+= (nCodeMaxLO    - nSkkCodeN1Min + 16) / 16 ;
	} else {
		return	FALSE ;
	}
	if (n1 < nSkkCodeN1Min) {
		n1	= nSkkCodeN1Min ;	/* skk-input-by-code-or-menu-jump-default */ ;
	} else {
		if (n1 >= nSkkCodeN1Max) {
			n1	= nSkkCodeN1Max ;
		}
	}
	n2	= nSkkCodeN2Min ;
	if (((n1 << 8) | n2) < nCodeMin) {
		n1	= nCodeMinHI ;
		n2	= nCodeMinLO ;
	}
	if (((n1 << 8) | n2) >= nCodeMax) {
		n1	= nCodeMaxHI ;
		n2	= nCodeMaxLO ;
	}

	dwSize			= sizeof (MYCAND) + sizeof (DWORD) * nNumCode + sizeof (DCHAR) * 2 * nNumCode ;
	pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pBuffer->m_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	/* ��⃊�X�g�\���̂��m�ۂ��A����������B*/
	TVarbuffer_Clear (pvbufCandInfo) ;
	if (! TVarbuffer_Require (pvbufCandInfo, dwSize))
		return	FALSE ;

	pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandInfo->dwSize		= dwSize ;
	pCandInfo->dwCount		= 1 ;
	pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
	pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
	pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumCode + sizeof (DCHAR) * 2 * nNumCode ;
	pCandList->dwStyle		= IME_CAND_CODE ;	/* ���[�ށA�܂��ACODE �ł������B*/
	pCandList->dwCount		= (DWORD) nNumCode ;
	pCandList->dwPageSize	= nKeys1 ;	/* �y�[�W�T�C�Y�͉ςɂ���H */

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pDest		= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumCode) ;
	pOffset		= pCandList->dwOffset ;

	n1Orig		= n1 ;
	n2Orig		= n2 ;
	do	{
		*pOffset	= (DWORD)((LPSTR)pDest - (LPSTR)pCandList) ;

		if (! bMakeUnicodeChar (iKcodeCharset, n1, n2, &ch)) {
			ch		= L'��' ;
		}
		*pDest	++	= (MYCHAR) ch ;
		*pDest ++	= MYTEXT ('\0') ;
		pOffset	++ ;

		n2	+= 16 ;
		if (n2 > nSkkCodeN2Max) {
			n1	++ ;
			if (n1 > nSkkCodeN1Max)
				n1	= nSkkCodeN1Min ;
			n2	=	nSkkCodeN2Min ;
		}
		if (((n1 << 8) | n2) > nCodeMax) {
			n1	= nCodeMinHI ;
			n2	= nCodeMinLO ;
		}
	}	while (n1 != n1Orig || n2 != n2Orig) ;

	/*	n ������ׂĂ���̂ŁAPageStart �͏�ɗ�ŗǂ����B
	 */
	pCandList->dwPageStart	= 0 ;
	pCandList->dwSelection	= pCandList->dwPageStart ;

	ImeDoc_vSetUpdateFlag (pBuffer->m_pDoc, IMEDOC_CREATE_CANDIDATELIST) ;
	return	TRUE ;
}


BOOL
imeBuffer_bShowInputByCodeOrMenu1Jump (
	struct CImeBuffer*	pBuffer,
	int					iKcodeCharset,
	int					n1,
	int					n2,
	int					nCodeMin,
	int					nCodeMax,
	int					nSkkCodeN1Min,
	int					nSkkCodeN1Max,
	int					nSkkCodeN2Min,
	int					nSkkCodeN2Max)
{
	TVarbuffer*		pvbufCandInfo ;
	LPMYCAND		pMyCand ;
	LPCANDIDATEINFO	pCandInfo ;
	LPCANDIDATELIST	pCandList ;
	LPMYSTR			pDest ;
	DWORD*			pOffset ;
	DWORD			dwSize ;
	int 			i, ch ;
	int				nCodeMaxHI, nCodeMaxLO, nCodeMinHI, nCodeMinLO, nNumCode ;
	int				n1Orig, n2Orig, nKeys2 ;

	if (pBuffer == NULL || pBuffer->m_pDoc == NULL)
		return	FALSE ;
	/*	nKeys2 upper limit = 256? */
	if (ImeConfig_pGetSkkInputByCodeMenuKeys2 (&nKeys2) == NULL || nKeys2 <= 0 || nKeys2 >= 256) {
		return	FALSE ;
	}

	if (nCodeMax < nCodeMin)
		return	FALSE ;

	if (nCodeMax > ((nSkkCodeN1Max << 8)| nSkkCodeN2Max))
		nCodeMax	= (nSkkCodeN1Max << 8)| nSkkCodeN2Max ;
	if (nCodeMin < ((nSkkCodeN1Min << 8) | nSkkCodeN2Min))
		nCodeMin	= (nSkkCodeN1Min << 8) | nSkkCodeN2Min ;

	nCodeMaxHI	= (nCodeMax >> 8) & 0xFF ;
	nCodeMaxLO	= (nCodeMax >> 0) & 0xFF ;
	nCodeMinHI	= (nCodeMin >> 8) & 0xFF ;
	nCodeMinLO	= (nCodeMin >> 0) & 0xFF ;

	if (! ((nSkkCodeN1Max >= nCodeMaxHI && nCodeMaxHI >= nSkkCodeN1Min) &&
		   (nSkkCodeN1Max >= nCodeMinHI && nCodeMinHI >= nSkkCodeN1Min) &&
		   (nSkkCodeN2Max >= nCodeMinLO && nCodeMinLO >= nSkkCodeN2Min) &&
		   (nSkkCodeN2Max >= nCodeMinLO && nCodeMinLO >= nSkkCodeN2Min))) 
		return	FALSE ;

	if (MIN (nSkkCodeN1Max, nCodeMaxHI) == MAX (nSkkCodeN1Min, nCodeMinHI)) {
		nNumCode	= 1 * (MIN (nSkkCodeN2Max, nCodeMaxLO) - MAX (nSkkCodeN2Min, nCodeMinLO)) ;
	} else if (MIN (nSkkCodeN1Max, nCodeMaxHI) > MAX (nSkkCodeN1Min, nCodeMinHI)) {
		nNumCode	= (MIN (nSkkCodeN1Max, nCodeMaxHI) - MAX (nSkkCodeN1Min, nCodeMinHI) - 1) * (nSkkCodeN2Max - nSkkCodeN2Min + 1) ;
		nNumCode	+= (nSkkCodeN2Max - nCodeMinLO    + 1) ;
		nNumCode	+= (nCodeMaxLO    - nSkkCodeN1Min + 1) ;
	} else {
		return	FALSE ;
	}

	/* n1, n2 �̏����l�̊m�F�B*/
	if (((n1 << 8) | n2) < nCodeMin) {
		n1	= nCodeMinHI ;
		n2	= nCodeMinLO ;
	}
	if (((n1 << 8) | n2) >= nCodeMax) {
		n1	= nCodeMaxHI ;
		n2	= nCodeMaxLO ;
	}
	if (n1 < nSkkCodeN1Min) {
		n1	= nSkkCodeN1Min ;	/* skk-input-by-code-or-menu-jump-default */ ;
	} else {
		if (n1 >= nSkkCodeN1Max) {
			n1	= nSkkCodeN1Max ;
		}
	}
	if (n2 < nSkkCodeN2Min) {
		n2	= nSkkCodeN2Min ;
	} else {
		if (n2 >= nSkkCodeN2Max) {
			n2	= nSkkCodeN2Max ;
		}
	}

	dwSize			= sizeof (MYCAND) + sizeof (DWORD) * nNumCode + sizeof (DCHAR) * 2 /* length (CHAR + NUL) */ * nNumCode ;
	pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pBuffer->m_pDoc) ;
	if (pvbufCandInfo == NULL)
		return	FALSE ;

	TVarbuffer_Clear (pvbufCandInfo) ;
	if (! TVarbuffer_Require (pvbufCandInfo, dwSize))
		return	FALSE ;

	pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
	pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
	pCandInfo->dwSize		= dwSize ;
	pCandInfo->dwCount		= 1 ;
	pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
	pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
	pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumCode + sizeof (DCHAR) * 2 * nNumCode ;
	pCandList->dwStyle		= IME_CAND_CODE ;	/* ���[�ށA�܂��ACODE �ł������B*/
	pCandList->dwCount		= (DWORD) nNumCode ;
	pCandList->dwPageSize	= nKeys2 ;	/* �y�[�W�T�C�Y�͉ςɂ���H */

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pDest		= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * nNumCode) ;
	pOffset		= pCandList->dwOffset ;

	n1Orig		= n1 ;
	n2Orig		= n2 ;
	do	{
		*pOffset	= (DWORD)((LPSTR)pDest - (LPSTR)pCandList) ;

		if (! bMakeUnicodeChar (iKcodeCharset, n1, n2, &ch)) {
			ch		= L'��' ;
		}
		*pDest	++	= (MYCHAR) ch ;
		*pDest ++	= MYTEXT ('\0') ;
		pOffset	++ ;

		n2	++ ;
		if (n2 > nSkkCodeN2Max) {
			n1	++ ;
			if (n1 > nSkkCodeN1Max)
				n1	= nSkkCodeN1Min ;
			n2	=	nSkkCodeN2Min ;
		}
		if (((n1 << 8) | n2) > nCodeMax) {
			n1	= nCodeMinHI ;
			n2	= nCodeMinLO ;
		}
	}	while (n1 != n1Orig || n2 != n2Orig) ;

	/*	n ������ׂĂ���̂ŁAPageStart �͏�ɗ�ŗǂ����B
	 */
	pCandList->dwPageStart	= 0 ;
	pCandList->dwSelection	= pCandList->dwPageStart ;

	ImeDoc_vSetUpdateFlag (pBuffer->m_pDoc, IMEDOC_CREATE_CANDIDATELIST) ;
	return	TRUE ;
}
#endif


