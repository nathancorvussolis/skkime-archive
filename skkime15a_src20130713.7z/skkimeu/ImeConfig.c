/*
 *	configuration �� update �������������ɂ��̒��g���Q�Ƃ���Ă����
 *	application ��������c���� rule-tree �̓r�������Ă��邱�Ƃ͂��蓾��B
 *	�����͉��Ƃ����Ȃ��Ƃ����Ȃ��Ǝv���B(�܂胁�b�Z�[�W���[�v�̂ǂ̈ʒu�ŁA��)
 */

#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "RuleTreeNode.h"
#include "keymap.h"
#include "jstring.h"
#include "ImeConfig.h"

/*========================================================================
 *	Registry-related definitions
 */
/* generic configs */
#include "../common/regpath.h"
#define	REGINFO_KANAMODEWHENOPEN			TEXT("KanaModeWhenOpen")
#define	REGINFO_ECHO						TEXT("Echo")
#define	REGINFO_EGGLIKENEWLINE				TEXT("EggLikeNewline")
#define	REGINFO_NEWLINEKAKUTEIALL			TEXT("NewlineKakuteiAll")
#define	REGINFO_AUTOINSERTPAREN				TEXT("AutoInsertParen")
#define	REGINFO_COMPOSITIONAUTOSHIFT		TEXT("CompTextAutoShift")
#define	REGINFO_DELETEIMPLIESKAKUTEI		TEXT("DeleteImpliesKakutei")
#define	REGINFO_DATEAD						TEXT("DateAd")
#define	REGINFO_NUMBERSTYLE					TEXT("NumberStyle")
#define	REGINFO_BRACKETPARENS				TEXT("CustomBracketParens")
#define	REGINFO_KUTOUTENTYPE				TEXT("KutoutenType")
#define	REGINFO_KUTOUTENS					TEXT("CustomKutoutens")
#define	REGINFO_KAKUTEIEARLY				TEXT("KakuteiEarly")
#define	REGINFO_OKURICHARALISTTYPE			TEXT("OkuriCharAlistType")
#define	REGINFO_OKURICHARALIST				TEXT("OkuriCharAlist")
#define	REGINFO_TICK						TEXT("Tick")

/* key related */
#define	REGPATH_KEYMAP						REGPATH_GENERIC
#define	REGINFO_MAJORMODEMAP				TEXT("MajorModeMap")
#define	REGINFO_JMODEMAP					TEXT("JModeMap")
#define	REGINFO_LATINMODEMAP				TEXT("LatinModeMap")
#define	REGINFO_ZENKAKUMODEMAP				TEXT("Jisx0208LatinModeMap")
#define	REGINFO_ABBREVMODEMAP				TEXT("AbbrevModeMap")

#define	REGINFO_MAJORMODEMAP_EX				TEXT("MajorModeMapEx")
#define	REGINFO_JMODEMAP_EX					TEXT("JModeMapEx")
#define	REGINFO_LATINMODEMAP_EX				TEXT("LatinModeMapEx")
#define	REGINFO_ZENKAKUMODEMAP_EX			TEXT("Jisx0208LatinModeMapEx")
#define	REGINFO_ABBREVMODEMAP_EX			TEXT("AbbrevModeMapEx")

#define	REGINFO_KEYMAP_TYPE					TEXT("KeymapType")
#define	REGINFO_STARTHENKANKEY_TYPE			TEXT("StartHenkanKeyType")
#define	REGINFO_STARTHENKANKEY				TEXT("StartHenkanKey")
#define	REGINFO_COMPLETIONRELATEDKEY_TYPE	TEXT("CompletionRelatedKeyType")
#define	REGINFO_TRYCOMPLETIONKEY			TEXT("TryCompletionKey")
#define	REGINFO_PREVIOUSCOMPLETIONKEY		TEXT("PreviousCompletionKey")
#define	REGINFO_NEXTCOMPLETIONKEY			TEXT("NextCompletionKey")
#define	REGINFO_SETHENKANPOINTSUBRKEY_TYPE	TEXT("SetHenkanPointSubrKeyType")
#define	REGINFO_SETHENKANPOINTSUBRKEY		TEXT("SetHenkanPointSubrKey")
#define	REGINFO_SPECIALMIDASHICHAR_TYPE		TEXT("SpecialMidashiCharType")
#define	REGINFO_SPECIALMIDASHICHAR			TEXT("SpecialMidashiChar")

#define	REGPATH_ROMAKANARULE				REGPATH_GENERIC
#define	REGINFO_ROMAKANARULE_TYPE			TEXT("RomaKanaRuleType")
#define	REGINFO_ROMAKANARULE				TEXT("RomaKanaRule")
#define	REGINFO_ROMAKANARULE1				TEXT("RomaKanaRule1")
#define	REGINFO_ROMAKANARULE2				TEXT("RomaKanaRule2")
#define	REGINFO_ROMAKANARULE3				TEXT("RomaKanaRule3")
#define	REGINFO_JISX0201RULE				TEXT("Jisx0201Rule")
#define	REGINFO_JISX0201RULE1				TEXT("Jisx0201Rule1")
#define	REGINFO_JISX0201RULE2				TEXT("Jisx0201Rule2")
#define	REGINFO_JISX0201RULE3				TEXT("Jisx0201Rule3")
#define	REGINFO_JISX0201ROMANRULE			TEXT("Jisx0201RomanRule")
#define	REGINFO_JISX0201ROMANRULE1			TEXT("Jisx0201RomanRule1")
#define	REGINFO_JISX0201ROMANRULE2			TEXT("Jisx0201RomanRule2")
#define	REGINFO_JISX0201ROMANRULE3			TEXT("Jisx0201RomanRule3")

#define	REGPATH_ZENKAKUVECTOR				REGPATH_GENERIC
#define	REGINFO_ZENKAKUVECTOR_TYPE			TEXT("ZenkakuVectorType")
#define	REGINFO_ZENKAKUVECTOR				TEXT("ZenkakuVector")
#define	SIZE_INPUTVECTOR					128

/* conversion config */
#define	REGPATH_CONVERSION					REGPATH_GENERIC
#define	REGINFO_CANDLISTKEYASSIGN			TEXT("CandidateListKeyAssign")
#define	REGINFO_SHOWCANDIDATEKEYS			TEXT("ShowCandidateKeys")
#define	REGINFO_INPUTCODEMENU1KEYS			TEXT("InputCodeMenu1Keys")
#define	REGINFO_INPUTCODEMENU2KEYS			TEXT("InputCodeMenu2Keys")
#define	REGINFO_SHOWCANDIDATELISTCOUNT		TEXT("ShowCandidateListCount")
#define	REGINFO_HENKANOKURISTRICTLY			TEXT("HenkanOkuriStrictly")
#define	REGINFO_PROCESSOKURIEARLY			TEXT("ProcessOkuriEarly")
#define	REGINFO_HENKANSTRICTOKURIPRECEDENCE	TEXT("HenkanStrictOkuriPrecedence")
#define	REGINFO_AUTOOKURIPROCESS			TEXT("AutoOkuriProcess")
#define	REGINFO_AUTOSTARTHENKAN				TEXT("AutoStartHenkan")
#define	REGINFO_AUTOSTARTHENKANKEYWORD		TEXT("AutoStartHenkanKeyword")
#define	REGINFO_DELETEOKURIWHENQUIT			TEXT("DeleteOkuriWhenQuit")
#define	REGINFO_SHOWANNOTATIONTYPE			TEXT("ShowAnnotationType")
#define	REGINFO_NUMERICCONVERSION			TEXT("NumericConversion")
#define	REGINFO_NUMERICFLOAT				TEXT("NumericFloat")

/* style */
#define	REGPATH_STYLE						REGPATH_SKKIME TEXT("\\Style")
#define	REGSUBKEY_COLORFACE					TEXT("Color")
#define	REGSUBKEY_DEFAULTFONT				TEXT("Font")
#define	REGSUBKEY_DEFAULTFONTSIZE			TEXT("Size")

/*========================================================================
 *	definitions
 */
#define	MAX_KEYBINDS					SIZE_IMEDOC_KEYMAP
#define	MAX_SPECIALKEYS					64

enum {
	KEYBINDTP_DEFAULT		= 0,
	KEYBINDTP_USERDEFINED,
} ;

enum {
	REGKEYTYPE_UNKNOWN	= -1,
	REGKEYTYPE_BOOL		= 0,
	REGKEYTYPE_INT,
} ;

enum {
	KUTOUTEN_TYPE_JP	= 0,
	KUTOUTEN_TYPE_EN,
	KUTOUTEN_TYPE_CUSTOM,
} ;

enum {
	BRACKETPARENTP_NONE	= 0,
	BRACKETPARENTP_DEFAULT,
	BRACKETPARENTP_USERDEFINED,
} ;

enum {
	OKURICHARTP_NONE	= 0,
	OKURICHARTP_DEFAULT,
	OKURICHARTP_USERDEFINED,
} ;

#define	SEPCHAR	TEXT(',')

#define	BUFSIZE_STRPAIR					32

#define	MAX_NUMKUTOUTENS				32
#define	MAX_NUMBRACKETPARENS			32
#define	MAX_NUMOKURICHARPAIR			32

/* for menu-keys (show-candidates-list-keys, input-by-code-or-menu1/2-keys */
#define	MAX_NUMMENUKEYS					256

enum {
	CANDLIST_KEYASSIGN_DEFAULT			= 0,
	CANDLIST_KEYASSIGN_01234567890,
	CANDLIST_KEYASSIGN_USERDEFINED		= 65535,
} ;

/* for colorface */
#define	MAX_NUMCOLORFACES	2

#if defined (UNITTEST)
enum {
	MYCOLOR_TEXTAUTO	= 0,	MYCOLOR_BACKAUTO,			MYCOLOR_BLACK,
	MYCOLOR_DARKRED,			MYCOLOR_DARKGREEN,			MYCOLOR_DARKYELLOW,
	MYCOLOR_DARKBLUE,			MYCOLOR_DARKPURPLE,			MYCOLOR_DARKLIGHTBLUE,
	MYCOLOR_DARKGRAY,			MYCOLOR_LIGHTGRAY,			MYCOLOR_RED,
	MYCOLOR_GREEN,				MYCOLOR_YELLOW,				MYCOLOR_BLUE,
	MYCOLOR_PURPLE,				MYCOLOR_LIGHTBLUE,			MYCOLOR_WHITE,
	MYCOLOR_SYSTEM,
	MYCOLOR_BTNFACE		= MYCOLOR_SYSTEM,
	MYCOLOR_BTNTEXT,			MYCOLOR_ACTIVEBORDER,		MYCOLOR_ACTIVECAPTION,
	MYCOLOR_CAPTIONTEXT,		MYCOLOR_APPWORKSPACE,		MYCOLOR_WINDOW,
	MYCOLOR_WINDOWTEXT,			MYCOLOR_DESKTOP,			MYCOLOR_INFOBK,
	MYCOLOR_INFOTEXT,			MYCOLOR_MSGBOXTEXT,			MYCOLOR_MENU,
	MYCOLOR_MENUTEXT,			MYCOLOR_HIGHLIGHTTEXT,		MYCOLOR_HIGHLIGHT,
	MYCOLOR_INACTIVEBORDER,		MYCOLOR_INACTIVECAPTION,	MYCOLOR_INACTIVECAPTIONTEXT,
	MAX_MYCOLOR,
} ;

enum {
	MYLINE_NO	= 0,	MYLINE_SOLID,		MYLINE_DOTTED,
	MYLINE_THICK_SOLID,	MYLINE_THIN_DITHER,	MYLINE_THICK_DITHER,
	MAX_MYLINE,
} ;

enum {
	MYCOLORFACE_INDEX_MIHENKANMOJIRETSU	= 0,
	MYCOLORFACE_INDEX_HENKANMOJIRETSU	= 1,
} ;
#endif

/*========================================================================
 *	structures
 */
struct TStringPair {
	DCHAR	m_bufLeft  [BUFSIZE_STRPAIR] ;
	DCHAR	m_bufRight [BUFSIZE_STRPAIR] ;
} ;

struct MYCOLORDEF {
	LPCTSTR		m_strText ;
	int			m_nType ;
} ;

/*========================================================================
 *	prototypes
 */
static	void	imeConfig_vLoadZenkakuVector		(void) ;
static	void	imeConfig_vClearZenkakuVector		(void) ;
static	BOOL	imeConfig_bLoadRomaKanaRuleList		(void) ;
static	void	imeConfig_vClearRomaKanaRuleList	(void) ;
static	BOOL	imeConfig_bLoadKeymap				(void) ;
static	BOOL	imeConfig_bLoadGenericSetting		(void) ;
static	BOOL	imeConfig_bLoadConversionSetting	(void) ;
static	BOOL	imeConfig_bLoadColorfaceSetting		(void) ;
static	void	imeConfig_vInitializeDefaultFontSetting	(void) ;
static	BOOL	imeConfig_bParseBSEncodedString		(LPCTSTR*, LPTSTR, int) ;
static	int		imeConfig_iDecodeStringPairList		(LPCTSTR, struct TStringPair*, int) ;
static	BOOL	imeConfig_bDefineKey				(struct CImeKeymap*, int, unsigned int, int) ;

static	void	imeConfig_vInitAutoStartHenkanKeys	(LPCWSTR pwKeys, int nKeyLen) ;

/*========================================================================
 *	global variables (default settings)
 */
#include "../common/jisx0208_vector.h"

/*========================================================================
 *	global variables (current settings)
 */
/* key related config */
static	int			_siRomaKanaRuleListType ;
static	int			_siKeybindType ;
static	int			_siStartHenkanKeyType ;
static	int			_siCompletionRelatedKeyType ;
static	int			_siSetHenkanPointSubrKeyType ;
static	int			_siSpecialMidashiCharKeyType ;

static	struct CSkkRuleTreeNode*	_rpSkkRuleTree [NUM_ROMAKANARULE] ;					// = { NULL } ;
static	struct CSkkRuleTreeNode*	_rpSkkJisx0201RomanRuleTree [NUM_ROMAKANARULE] ;	// = { NULL } ;
static	struct CSkkRuleTreeNode*	_rpSkkJisx0201RuleTree [NUM_ROMAKANARULE] ;			// = { NULL } ;
static	LPDSTR						_rstrJisx0208LatinVector [128] ;		// = { NULL } ;	///< �[����������OS�ɔC���� @todo ���̉ӏ���
static	struct CImeKeymap			_sMajorModeMap ;
static	struct CImeKeymap			_sSkkJModeMap ;
static	struct CImeKeymap			_sSkkLatinModeMap ;
static	struct CImeKeymap			_sSkkJisx0208LatinModeMap ;
static	struct CImeKeymap			_sSkkAbbrevModeMap ;
static	struct CImeKeymap			_sMinibufferMinorModeMap ;
static	BOOL						_bOHHenkan ;

/* skk-insert ���œ���ȓ��������L�[�̐ݒ�B(�ǂ����� rule �ɏ����Ȃ��񂾂낤�H) */
static	int			_siNumStartHenkanKeys ;
static	BYTE		_srbyStartHenkanKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumTryCompletionKeys ;
static	BYTE		_srbyTryCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumPreviousCompletionKeys ;
static	BYTE		_srbyPreviousCompletionKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumNextCompletionKeys ;
static	BYTE		_srbyNextCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumSetHenkanPointSubrKeys ;
static	BYTE		_srbySetHenkanPointSubrKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumSpecialMidashiCharKeys ;
static	BYTE		_srbySpecialMidashiCharKeys		[MAX_SPECIALKEYS] ;

static	BOOL		_bMaskSkkSetHenkanPointKey	= FALSE ;
static	BOOL		_bEggLikeNewline		= TRUE ;
static	BOOL		_bNewlineKakuteiAll		= FALSE ;

/* generic config */
static	BOOL		_bKanaModeWhenOpen		= TRUE ;
static	BOOL		_bEcho					= TRUE ;
static	BOOL		_bCompositionAutoShift	= TRUE ;
static	BOOL		_bDeleteImpliesKakutei	= TRUE ;
static	BOOL		_bKakuteiEarly			= TRUE ;

/* date & number style */
static	int			_bDateAd				= FALSE ;
static	int			_iNumberStyle			= 0 ;

/* kutouten & bracket settins */
static	int						_iKutoutenType			= KUTOUTEN_TYPE_JP ;
static	int						_iBracketParenType		= BRACKETPARENTP_NONE ;
static	int						_iOkuriCharAlistType	= OKURICHARTP_NONE ;
static	int						_iNumKutouten			= 0 ;
static	int						_iNumBracketParen		= 0 ;
static	int						_iNumOkuriCharAlist		= 0 ;
static	struct TStringPair		_srKutouten			[MAX_NUMKUTOUTENS] ;
static	struct TStringPair		_srBracketParen		[MAX_NUMBRACKETPARENS] ;
static	struct TStringPair		_srOkuriCharAlist	[MAX_NUMOKURICHARPAIR] ;

/* conversion settings */
static	int			_snCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;

static	int			_snNumShowCandidateKeys ;
static	int			_snNumInputCodeMenu1Keys ;
static	int			_snNumInputCodeMenu2Keys ;
static	DCHAR		_srdchShowCandidateKeys  [MAX_NUMMENUKEYS]	= { 0 } ;
static	DCHAR		_srdchInputCodeMenu1Keys [MAX_NUMMENUKEYS]	= { 0 } ;
static	DCHAR		_srdchInputCodeMenu2Keys [MAX_NUMMENUKEYS]	= { 0 } ;
static	int			_snShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;

static	BOOL		_sbHenkanOkuriStrictly			= FALSE ;
static	BOOL		_sbProcessOkuriEarly			= FALSE ;
static	BOOL		_sbHenkanStrictOkuriPrecedence	= FALSE ;
static	BOOL		_sbAutoOkuriProcess				= FALSE ;
static	BOOL		_sbAutoStartHenkan				= FALSE ;
static	BOOL		_sbDeleteOkuriWhenQuit			= FALSE ;

static	BOOL		_sbNumericConversion			= FALSE ;
static	BOOL		_sbNumericFloat					= FALSE ;

static	int			_snShowAnnotationType			= SHOW_NO_ANNOTATION ;

static	int			_siNumAutoStartHenkanKeywords		= 0 ;
static	DCHAR		_srAutoStartHenkanKeywords [512]	= { TEXT ('\0') } ;

/* colorface settings */
static	MYCOLORFACESET	_srImeColorFaces [MAX_NUMCOLORFACES] ;

/*	Dialog �ɂȂ�(�ݒ荀�ڂ����Y��Ă����㕨)
 *	completion �� 1property sheet page ����Ă��ǂ��Ǝv���B
 */
static	BOOL		_bAllowsSpacesNewlinesAndTabs	= FALSE ;
/* ���ڃR�[�h���͂� default kanji-code charset */
static	int			_iKanjiCodeCharset				= KCODE_CHARSET_JAPANESE_JISX0208 ;
static	BOOL		_bCompCirculate					= FALSE ;

/* minibuffer �̕\���ɗp����f�t�H���g�̃t�H���g�̐ݒ�B*/
static	LOGFONT		_slfDefaultFont ;
static	int			_siDefaultFontSize				= -1 ;

/*	�����ɖ�����������́B
 *	ImeDoc_bSkkTryCompletionCharp (const struct CImeDoc* pDoc, int nCH)
 *	BOOL	ImeConfig_bSkkStartHenkanCharp (int						nCH)
 *	���̂�����B
 */
/*	�ݒ�� sync �Ɏg���B
 */
static	BOOL	_bHaveSyncTick	= FALSE ;
static	DWORD	_dwSyncTick		= 0 ;

/*========================================================================
 *	public functions
 */
void
ImeConfig_vLoad (void)
{
	HKEY	hSubKey ;
	DWORD	dwTick		= 0 ;
	BOOL	bHaveTick	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData ;
		LONG	lResult ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bHaveTick	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}

	imeConfig_vLoadZenkakuVector () ;
	imeConfig_bLoadRomaKanaRuleList () ;
	imeConfig_bLoadKeymap () ;
	_bMaskSkkSetHenkanPointKey	= FALSE ;
	imeConfig_bLoadGenericSetting () ;
	imeConfig_bLoadConversionSetting () ;
	imeConfig_bLoadColorfaceSetting () ;
	imeConfig_vInitializeDefaultFontSetting () ;

	_bHaveSyncTick	= bHaveTick ;
	_dwSyncTick		= dwTick ;
	return ;
}

void
ImeConfig_vUnload (void)
{
	imeConfig_vClearZenkakuVector () ;
	imeConfig_vClearRomaKanaRuleList () ;

	_bHaveSyncTick	= FALSE ;
	_dwSyncTick		= 0 ;
	return ;
}

void
ImeConfig_vUpdate (void)
{
	HKEY	hSubKey ;
	DWORD	cbData, dwType, dwTick ;
	BOOL	bUpdate ;
	LONG	lResult ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
		bUpdate	= ! _bHaveSyncTick ;
		dwTick	= 0 ;
	} else {
		bUpdate	= FALSE ;
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bUpdate	= ! _bHaveSyncTick || (_dwSyncTick != dwTick) ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! bUpdate)
		return ;

	ImeConfig_vUnload () ;
	ImeConfig_vLoad () ;
	_bHaveSyncTick	= TRUE ;
	_dwSyncTick		= dwTick ;
	return ;
}

/*
 */
BOOL
ImeConfig_bKanaModeWhenOpenp (void)
{
	return	_bKanaModeWhenOpen ;
}

struct CSkkRuleTreeNode*
ImeConfig_pGetSkkRuleTree (int iRule)
{
	if (RULETREENO_SKK_BASE <= iRule && iRule < (RULETREENO_SKK_BASE + NUM_ROMAKANARULE))
		return	_rpSkkRuleTree [iRule - RULETREENO_SKK_BASE] ;
	if (RULETREENO_SKK_JISX0201_ROMAN <= iRule && iRule < (RULETREENO_SKK_JISX0201_ROMAN + NUM_ROMAKANARULE))
		return	_rpSkkJisx0201RomanRuleTree [iRule - RULETREENO_SKK_JISX0201_ROMAN] ;
	if (RULETREENO_SKK_JISX0201_BASE <= iRule && iRule < (RULETREENO_SKK_JISX0201_BASE + NUM_ROMAKANARULE))
		return	_rpSkkJisx0201RuleTree [iRule - RULETREENO_SKK_JISX0201_BASE] ;
	return	NULL ;
}

BOOL
ImeConfig_bSkkKakuteiEarlyp (void)
{
	return	_bKakuteiEarly ;
}

BOOL
ImeConfig_bSkkProcessOkuriEarlyp (void)
{
	return	_sbProcessOkuriEarly ;
}

BOOL
ImeConfig_bSkkEchop (void)
{
	return	_bEcho ;
}

BOOL
ImeConfig_bSkkTryCompletionCharp (int nCH)
{
	if (_siCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'\t')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyTryCompletionKeys, nCH, _siNumTryCompletionKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
ImeConfig_bSkkPreviousCompletionCharp (int nCH)
{
	if (_siCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'.')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyPreviousCompletionKeys, nCH, _siNumPreviousCompletionKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
ImeConfig_bSkkNextCompletionCharp (int nCH)
{
	if (_siCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L',')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyNextCompletionKeys, nCH, _siNumNextCompletionKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
ImeConfig_bSkkAutoStartHenkanp (void)
{
	return	_sbAutoStartHenkan ;	//FALSE
}

BOOL
ImeConfig_bSkkAutoStartHenkanKeywordp (
	LPCDSTR						pwString,
	int							nStringLength)
{
	/*	�����ϊ��X�^�[�g�L�[���[�h�Ƃ����̂��������̂�Y��Ă����c�B����̓J�X�^�}�C�Y���ڂ��B
	static	LPCDSTR		_rstrSkkAutoStartHenkanKeywords []	= {
		L"��", L"�A", L"�B", L"�D", L"�C", L"�H", L"�v",  L"�I", L"�G", L"�F", L")", L";", L":",
		L"�j", L"�h", L"�z", L"�x", L"�t", L"�r", L"�p",  L"�n", L"�l", L"}",  L"]", L"?", L".",
		L",",  L"!",
	} ;
	 */
	LPCDSTR		pKeywords ;
	int			i ;

	if (pwString == NULL || nStringLength <= 0)
		return	FALSE ;

	pKeywords	= _srAutoStartHenkanKeywords ;
	for (i = 0 ; i < _siNumAutoStartHenkanKeywords && *pKeywords != L'\0' ; i ++) {
		if (! dcsncmp (pKeywords, pwString, nStringLength) && pKeywords [nStringLength] == L'\0')
			return	TRUE ;
		pKeywords	+= dcslen (pKeywords) + 1 ;
	}
	return	FALSE ;
}

BOOL
ImeConfig_bSkkSpecialMidashiCharp (int nCH)
{
	if (_siSpecialMidashiCharKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'?' || nCH == L'>' || nCH == L'<')? TRUE : FALSE ;
	} else {
		int		i ;
		for (i = 0 ; i < _siNumSpecialMidashiCharKeys && i < ARRAYSIZE (_srbySpecialMidashiCharKeys) ; i ++) {
			if (_srbySpecialMidashiCharKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
ImeConfig_bSkkSetHenkanPointKeyp (int nCH)
{
	if (_bMaskSkkSetHenkanPointKey)
		return	FALSE ;

	if (_siSetHenkanPointSubrKeyType == KEYBINDTP_DEFAULT) {
		/* (?A ?B ?C ?D ?E ?F ?G ?H ?I ?J ?K ?M ?N ?O ?P ?R ?S ?T ?U ?V ?W ?Y ?Z) */
		return	(L'A' <= nCH && nCH <= L'Z' && nCH != L'L' && nCH != L'Q' && nCH != L'X')? TRUE : FALSE ;
	} else {
		int	i ;
		for (i = 0 ; i < _siNumSetHenkanPointSubrKeys && i < ARRAYSIZE (_srbySetHenkanPointSubrKeys) ; i ++) {
			if (_srbySetHenkanPointSubrKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
ImeConfig_bSkkSetHenkanPointKeyMaskedp (void)
{
	return	_bMaskSkkSetHenkanPointKey ;
}

void
ImeConfig_vMaskSkkSetHenkanPointKey (BOOL bValue)
{
	_bMaskSkkSetHenkanPointKey	= bValue ;
	return ;
}

BOOL
ImeConfig_bSkkStartHenkanCharp (
	int						nCH)
{
	/* ���[�ށA����͂ǂ�����ׂ����B��͂� j-mode-map �Ń`�F�b�N���B
	 *	... space �� skk-insert �Ȃ̂��B����� skk-insert ������ start-henkan ���ƌ������߂ɂ���̂��c
	 *	����͂܂����ȁBkeyfunc �����|���� skk-insert �����ǁc�ɂ��Ȃ��Ƃ��߂��B
	 *	����̓L�[�̒ǉ��̂Ƃ���Őݒ肳���邵���Ȃ��ȁB
	 */
	if (_siStartHenkanKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L' ')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyStartHenkanKeys, nCH, _siNumStartHenkanKeys) != NULL)? TRUE : FALSE ;
	}
}

int
ImeConfig_iSkkARefSkkKanaRomVector (
	int						nCH,
	LPDSTR					pOkuri,
	int						nOkuri)
{
	typedef struct {
		int				nKana ;
		LPCWSTR			wstrRom ;
	} CTKanaRomaPair ;
	#include "../common/kana_roma.h"

	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rDefaultKanaRomaVector) ; i ++) {
		if (nCH == _rDefaultKanaRomaVector [i].nKana) {
			int		nLength, n ;

			nLength	= lstrlenW (_rDefaultKanaRomaVector [i].wstrRom) ;
			if (nLength > 0) {
				n	= wcstodcs (pOkuri, nOkuri, _rDefaultKanaRomaVector [i].wstrRom, nLength) ;
			} else {
				n	= 0 ;
			}
			return	n ;
		}
	}
	return	0 ;
}

int
ImeConfig_iGetSkkShowAnnotationType (void)
{
	return	_snShowAnnotationType ;
}

BOOL
ImeConfig_bSkkEggLikeNewline (void)
{
	return	_bEggLikeNewline ;
}

BOOL
ImeConfig_bSkkDeleteOkuriWhenQuit (void)
{
	return	_sbDeleteOkuriWhenQuit ;
}

BOOL
ImeConfig_bSkkDeleteImplesKakuteip (void)
{
	return	_bDeleteImpliesKakutei ;
}

LPCDSTR
ImeConfig_pGetSkkHenkanShowCandidatesKeys (int* pnKeys)
{
	if (pnKeys != NULL)
		*pnKeys	= _snNumShowCandidateKeys ;
	return	_srdchShowCandidateKeys ;
}

BOOL
ImeConfig_bSkkNumericConversionp (void)
{
	return	_sbNumericConversion ;
}

BOOL
ImeConfig_bSkkNumConvertFloatp (void)
{
	return	_sbNumericFloat ;
}

BOOL
ImeConfig_bSkkCompCirculatep (void)
{
	return	_bCompCirculate ;
}

int
ImeConfig_iGetSkkKcodeCharset (void)
{
	return	_iKanjiCodeCharset ;
}

LPCDSTR
ImeConfig_pGetSkkInputByCodeMenuKeys1 (int* pnKeys)
{
	if (pnKeys != NULL) {
		*pnKeys	= _snNumInputCodeMenu1Keys ;
	}
	return	_srdchInputCodeMenu1Keys ;
}

LPCDSTR
ImeConfig_pGetSkkInputByCodeMenuKeys2 (int* pnKeys)
{
	if (pnKeys != NULL) {
		*pnKeys	= _snNumInputCodeMenu2Keys ;
	}
	return	_srdchInputCodeMenu2Keys ;
}

int
ImeConfig_iGetSkkOkuriChar (
	LPCDSTR					pwOkuriChar,
	int						nOkuriCharLen,
	LPDSTR					pwDest,
	int						nDestSize)
{
	int		i, nLen ;

	if (_iOkuriCharAlistType != OKURICHARTP_USERDEFINED)
		return	0 ;

	for (i = 0 ; i < _iNumOkuriCharAlist ; i ++) {
		if (dcsncmp (pwOkuriChar, _srOkuriCharAlist [i].m_bufLeft, nOkuriCharLen) == 0 &&
			_srOkuriCharAlist [i].m_bufLeft [nOkuriCharLen] == L'\0') {
			/*	hit */
			nLen	= MIN (nDestSize, dcslen (_srOkuriCharAlist [i].m_bufRight)) ;
			if (nLen > 0)
				dcsncpy (pwDest, _srOkuriCharAlist [i].m_bufRight, nLen) ;
			return	nLen ;
		}
	}
	return	0 ;
}

BOOL
ImeConfig_bSkkHenkanOkuriStrictlyp (void)
{
	return	_sbHenkanOkuriStrictly ;
}

BOOL
ImeConfig_bSkkHenkanStrictOkuriPrecedencep (void)
{
	return	_sbHenkanStrictOkuriPrecedence ;
}

/*	auto-okuri-process �𗘗p����̂́Askkiserv ���ł���Ǝv���邪�A�ꉞ���̋L�q�͓���Ă����B
 */
BOOL
ImeConfig_bSkkAutoOkuriProcessp (void)
{
	return	_sbAutoOkuriProcess ;
}

int
ImeConfig_iSkkARefSkkJisx0208LatinVector (
	int						nCH,
	LPDSTR					pResult,
	int						nResultSize)
{
	if (0 <= nCH && nCH < ARRAYSIZE (_rstrJisx0208LatinVector)  &&
		_rstrJisx0208LatinVector [nCH] != NULL) {
		int		n ;
		n	= dcslen (_rstrJisx0208LatinVector [nCH]) ;
		n	= (n > nResultSize)? nResultSize : n ;
		if (n > 0)
			dcsncpy (pResult, _rstrJisx0208LatinVector [nCH], n) ;
		return	n ;
	}
	return	-1 ;	/* not hit */
}

/*	�t�����B
 */
int
ImeConfig_iSkkRevRefSkkJisx0208LatinVector (
	int						nCH,
	LPDSTR					pResult,
	int						nResultSize)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rstrJisx0208LatinVector) ; i ++) {
		if (_rstrJisx0208LatinVector [i] != NULL &&
			*(_rstrJisx0208LatinVector [i] + 0) == (DCHAR)nCH &&
			*(_rstrJisx0208LatinVector [i] + 1) == L'\0') {
			if (nResultSize > 0)
				*pResult	= i ;
			return	1 ;
		}
	}
	return	-1 ;	/* not hit */
}

/// �����ʂ̎����}�����L���Ȃ� TRUE
BOOL ImeConfig_bSkkAutoInsertParen()
{
	return _iBracketParenType != BRACKETPARENTP_NONE;
}

int
ImeConfig_iSkkAssocSkkAutoParenStringAlist	(
	LPCDSTR					pwString,
	int						nStringLen,
	LPDSTR					pwResult,
	int						nResultSize)
{
	int		i ;

	for (i = 0 ; i < _iNumBracketParen ; i ++) {
		if (! dcsncmp (pwString, _srBracketParen [i].m_bufLeft, nStringLen) &&
			_srBracketParen [i].m_bufLeft [nStringLen]	== L'\0') {
			int		n ;
			n	= dcslen (_srBracketParen [i].m_bufRight) ;
			n	= (n > nResultSize)? nResultSize : n ;
			if (n > 0)
				dcsncpy (pwResult, _srBracketParen [i].m_bufRight, n) ;
			return	n ;
		}
	}
	return	-1 ;	/* not hit */
}

/*	���̐ݒ�͍��̂Ƃ���J�X�^�}�C�Y�ł��Ȃ��B��� FALSE �ɂ��Ă������A����ł����̂��c�H
 */
BOOL
ImeConfig_bSkkAllowsSpacesNewlinesAndTabs	(void)
{
	return	_bAllowsSpacesNewlinesAndTabs ;
}

int
ImeConfig_iGetNumberOfKutotens (void)
{
	return	_iNumKutouten ;
}

LPCDSTR
ImeConfig_pGetCurrentTouten (
	int					iKutoutenType,
	int*				pnLength)
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % _iNumKutouten ;
	if (pnLength != NULL)
		*pnLength	= dcslen (_srKutouten [nIndex].m_bufLeft) ;
	return	_srKutouten [nIndex].m_bufLeft ;
}

LPCDSTR
ImeConfig_pGetCurrentKuten (
	int					iKutoutenType,
	int*				pnLength)
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % _iNumKutouten ;
	if (pnLength != NULL)
		*pnLength	= dcslen (_srKutouten [nIndex].m_bufRight) ;
	return	_srKutouten [nIndex].m_bufRight ;
}

/*	Newline -> Kakutei �̌�Apoint-marker �� buffer �̍Ō�ֈړ������邩�ۂ��B
 *	shift-count �̐�����A���ꂪ TRUE ���ƁuComposition �̑S�m��v�Ɍ�����B
 */
BOOL
ImeConfig_bSkkIsNewlineKakuteiAllp (void)
{
	return	_bNewlineKakuteiAll ;
}

/*	�����I�� CompositionString ���m��ς݂Ƃ��đ����邩�ǂ��������肷��B
 *	��{�I�Ɂu�o�b�t�@�̐擪�v����upoint-marker�̈ʒu�v�u�ϊ��J�n�ʒu�v
 *	�u�����J�n�ʒu�v�̒��ōŏ��̈ʒu�܂ŃV�t�g�����B
 */
BOOL
ImeConfig_bSkkCompositionAutoShiftp (void)
{
	return	_bCompositionAutoShift ;
}

const struct CImeKeymap*
ImeConfig_pGetMajorModeMap (void)
{
	return	&_sMajorModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkJModeMap (void)
{
	return	&_sSkkJModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkLatinModeMap (void)
{
	return	&_sSkkLatinModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkJisx0208LatinModeMap (void)
{
	return	&_sSkkJisx0208LatinModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkAbbrevModeMap (void)
{
	return	&_sSkkAbbrevModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetMinibufferMinorModeMap (void)
{
	return	&_sMinibufferMinorModeMap ;
}

const MYCOLORFACESET*
ImeConfig_pGetColorFaceSet (void)
{
	return	_srImeColorFaces ;
}

int
ImeConfig_iGetCountHenkanShowChange (void)
{
	return	_snShowCandListCount ;
}

void
ImeConfig_vGetDefaultFont (LOGFONT* plf, HDC hDC)
{
	if (plf == NULL)
		return ;

	memcpy (plf, &_slfDefaultFont, sizeof (LOGFONT)) ;
	if (_siDefaultFontSize >= 0) {
		plf->lfWidth	= 0 ;
		plf->lfHeight	= -MulDiv (_siDefaultFontSize, GetDeviceCaps (hDC, LOGPIXELSY), 72) ;
	}
	return ;
}

/*========================================================================
 *	private functions (for ZenkakuVector)
 */

/// �S�p�x�N�^�̓ǂݍ���
void imeConfig_vLoadZenkakuVector()
{
	HKEY hSubKey;
	DWORD dwType, dwValue, cbData;
	LONG lResult;
	LPTSTR pwData;
	LPCTSTR pwSrc;
	UINT i;

	if (RegOpenKeyEx(HKEY_CURRENT_USER, REGPATH_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) goto skip_default;

	cbData = sizeof(DWORD);
	lResult = RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData);
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD || dwValue == KEYBINDTP_DEFAULT) goto skip_scope1;

	lResult = RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, NULL, &cbData);
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ) goto skip_scope1;

	pwData = (LPTSTR)MALLOC(cbData);
	if (pwData == NULL) {
	skip_scope1:
		RegCloseKey(hSubKey);
		goto skip_default;
	}

	RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, (BYTE*)pwData, &cbData);
	RegCloseKey(hSubKey);

	imeConfig_vClearZenkakuVector();

	pwSrc = pwData;
	while (*pwSrc) {
		TCHAR c;
		LPCTSTR pwBase;
		size_t n, nTemp;
		LPDSTR p;

		// �ΏۃL�����N�^�ǂݍ���
		c = *pwSrc++;
		if (c < TEXT(' ') || c >= SIZE_INPUTVECTOR) goto skip_scope2;

		pwBase = pwSrc;
		while (*pwSrc++);		// ��r���Z�q�͐�΂ɏ��������Ȃ��ł�����
		nTemp = pwSrc - pwBase - 1;

		FREE(_rstrJisx0208LatinVector[c]);
		_rstrJisx0208LatinVector[c] = NULL;
		n = wcstodcs(NULL, 0, pwBase, nTemp);	// ���W�X�g���i�[���e�̓m�[�}���C�Y�ς��O��
		if (n == 0) goto skip_scope2;

		p = (LPDSTR)MALLOC((n + 1) * sizeof(DCHAR));
		if (p == NULL) {
		skip_scope2:
			FREE(pwData);
			goto skip_default;
		}
		wcstodcs(p, n, pwBase, nTemp);
		p[n] = TEXT('\0');
		_rstrJisx0208LatinVector[c] = p;
	}
	FREE(pwData);
	return;

skip_default:
	// �f�t�H���g�l���g�p����
	// �G���[�ł͂Ȃ����������n
	for (i = 0; i < SIZE_INPUTVECTOR; i++) {
		LPDSTR p = NULL;
		TCHAR c = i < TEXT(' ') ? TEXT('\0') : _rcDefaultJisx0208LatinVector[i - TEXT(' ')];
		if (c) {
			p = (LPDSTR)MALLOC(sizeof(DCHAR) * 2);	// �f�t�H���g�l�͕K��1����+�I�[
			if (p) {
				wcstodcs(p, 1, &c, 1);
				p[1] = TEXT('\0');
			}
		}
		_rstrJisx0208LatinVector[i] = p;
	}
}

void
imeConfig_vClearZenkakuVector (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rstrJisx0208LatinVector) ; i ++) {
//		if (_rstrJisx0208LatinVector [i] != NULL) {
			FREE (_rstrJisx0208LatinVector [i]) ;
			_rstrJisx0208LatinVector [i]	= NULL ;
//		}
	}
	return ;
}

/*========================================================================
 *	private functions (for Keybind)
 */
static	void	imeConfig_vInitializeMajorModeMap			(void) ;
static	void	imeConfig_vInitializeSkkJModeMap			(void) ;
static	void	imeConfig_vInitializeSkkLatinModeMap		(void) ;
static	void	imeConfig_vInitializeSkkJisx0208LatinModeMap(void) ;
static	void	imeConfig_vInitializeSkkAbbrevModeMap		(void) ;
static	void	imeConfig_vInitializeMinibufferMinorModeMap (void) ;

BOOL
imeConfig_bLoadKeymap (void)
{
	static	LPCTSTR	srKeymapRegistryNames []	= {
		REGINFO_MAJORMODEMAP,
		REGINFO_JMODEMAP,
		REGINFO_LATINMODEMAP,
		REGINFO_ZENKAKUMODEMAP,	/* jisx0208-latin-mode-map */
		REGINFO_ABBREVMODEMAP,
	} ;
	static	struct CImeKeymap*	rpKeymaps []	= {
		&_sMajorModeMap,
		&_sSkkJModeMap,
		&_sSkkLatinModeMap,
		&_sSkkJisx0208LatinModeMap,
		&_sSkkAbbrevModeMap,
	} ;
	/*	����L�[�̈����BControl + F1 �Ƃ��B(VKEYCODE, MODIFIER, FUNCTION) �̃y�A��
	 *	�Ȃ�B
	 */
	static	LPCTSTR	srKeymapExtraRegisterNames []	= {
		REGINFO_MAJORMODEMAP_EX,
		REGINFO_JMODEMAP_EX,
		REGINFO_LATINMODEMAP_EX,
		REGINFO_ZENKAKUMODEMAP_EX,	/* jisx0208-latin-mode-map */
		REGINFO_ABBREVMODEMAP_EX,
	} ;
	HKEY	hSubKey ;
	int		i ;
	BOOL	bRetval	= FALSE ;
	BOOL	bExistUserDefinedKeymap					= FALSE ;
	BOOL	bExistUserDefinedStartHenkanKey			= FALSE ;
	BOOL	bExistUserDefinedCompletionKey			= FALSE ;
	BOOL	bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
	BOOL	bExistUserDefinedSpecialMidashiCharKey	= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		struct CImeKeymap*	pKeymap ;
		LONG	lResult ;
		DWORD	dwType, cbData, dwValue ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_KEYMAP_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siKeybindType	= (int) dwValue ;

		for (i = 0 ; i < ARRAYSIZE (srKeymapRegistryNames) ; i ++) {
			lResult	= RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			if (dwType != REG_BINARY || cbData != MAX_KEYBINDS)
				goto	skip_error ;

			pKeymap	= rpKeymaps [i] ;
			(void) RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, (BYTE*)pKeymap->m_rbyBaseMap, &cbData) ;

			pKeymap->m_nKeyBinds	= 0 ;
			pKeymap->m_pKeyBinds	= NULL ;
		}
		if (i >= ARRAYSIZE (srKeymapRegistryNames))
			bExistUserDefinedKeymap	= TRUE ;

		if (bExistUserDefinedKeymap) {
			BYTE	rbBuffer [512] ;
			BYTE*	pbBuffer	= NULL ;
			DWORD	iBufSize ;

			pbBuffer	= rbBuffer ;
			iBufSize	= sizeof (rbBuffer) ;
			for (i = 0 ; i < ARRAYSIZE (srKeymapExtraRegisterNames) ; i ++) {
				int				iNumKeyBinds, j ;
				const BYTE*		pbData ;
				struct CImeKeyBind*	pKeyBind ;

				/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
				lResult	= RegQueryValueEx (hSubKey, srKeymapExtraRegisterNames [i], NULL, &dwType, NULL, &cbData) ;
				if (lResult != ERROR_SUCCESS || dwType != REG_BINARY)
					continue ;
				if (cbData > iBufSize) {
					if (pbBuffer != rbBuffer) {
						FREE (pbBuffer) ;
					}
					pbBuffer	= MALLOC (cbData) ;
					if (pbBuffer == NULL) {
						/* error */
						break ;
					}
					iBufSize	= cbData ;
				}
				(void) RegQueryValueEx (hSubKey, srKeymapExtraRegisterNames [i], NULL, &dwType, pbBuffer, &cbData) ;

				/*
				 */
				iNumKeyBinds	= cbData / (4 + 2 + 2) ;	/* VKEY(4), MODIFIER(2), FUNCNO(2) */
				if (iNumKeyBinds <= 0)
					continue ;

				rpKeymaps [i]->m_pKeyBinds	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * iNumKeyBinds) ;
				if (rpKeymaps [i]->m_pKeyBinds == NULL) {
					/* error */
					break ;
				}
				rpKeymaps [i]->m_nKeyBinds	= iNumKeyBinds ;

				pbData		= pbBuffer ;
				pKeyBind	= rpKeymaps [i]->m_pKeyBinds ;
				for (j = 0 ; j < iNumKeyBinds ; j ++) {
					unsigned int	uVKey, uModifier ;
					int				iFuncNo ;

					uVKey		= (unsigned int) *pbData ++ ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ <<  8) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 16) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 24) ;
					uModifier	= (unsigned int) *pbData ++ ;
					uModifier	= uModifier | ((unsigned int) *pbData ++ << 8) ;
					iFuncNo		= (unsigned int) *pbData ++ ;
					pbData++;	// iFuncNo		= iFuncNo | ((unsigned int) *pbData ++ << 8) ;
					if (iFuncNo >= NUM_SELECTABLE_FUNCTIONS)
						continue ;	/* skip */
					pKeyBind->m_nKeyCode		= uVKey ;
					pKeyBind->m_uKeyMask		= uModifier ;
					pKeyBind->m_nKeyFunction	= iFuncNo ;
					pKeyBind	++ ;
				}
				/* realloc �������Ƃ��낾���ǁc */
				rpKeymaps [i]->m_nKeyBinds	= pKeyBind - rpKeymaps [i]->m_pKeyBinds ;
			}
			if (pbBuffer != rbBuffer && pbBuffer != NULL) {
				FREE (pbBuffer) ;
				pbBuffer	= NULL ;
			}
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siStartHenkanKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbyStartHenkanKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY, NULL, &dwType, (BYTE*)_srbyStartHenkanKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedStartHenkanKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumStartHenkanKeys			= (int) cbData ;
			bExistUserDefinedStartHenkanKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siCompletionRelatedKeyType	= (int) dwValue ;
		if (RegQueryValueEx (hSubKey, REGINFO_TRYCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyTryCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumTryCompletionKeys			= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyPreviousCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumPreviousCompletionKeys	= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_NEXTCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyNextCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumNextCompletionKeys		= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siSetHenkanPointSubrKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySetHenkanPointSubrKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, NULL, &dwType, (BYTE*)_srbySetHenkanPointSubrKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSetHenkanPointSubrKeys			= (int) cbData ;
			bExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siSpecialMidashiCharKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySpecialMidashiCharKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR, NULL, &dwType, (BYTE*)_srbySpecialMidashiCharKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSpecialMidashiCharKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSpecialMidashiCharKeys			= (int) cbData ;
			bExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_EGGLIKENEWLINE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_bEggLikeNewline	= (dwValue != 0) ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_NEWLINEKAKUTEIALL, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_bNewlineKakuteiAll	= (dwValue != 0) ;
		}
		bRetval	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}

	/* �f�[�^���ςłȂ����A�X�̗v�f���`�F�b�N����B*/
	if (bRetval) {
		for (i = 0 ; i < ARRAYSIZE (rpKeymaps) ; i ++) {
			struct CImeKeymap*	pKeymap ;
			int		j ;

			pKeymap	= rpKeymaps [i] ;
			for (j = 0 ; j < MAX_KEYBINDS ; j ++) {
				if (pKeymap->m_rbyBaseMap [j] < 0 || pKeymap->m_rbyBaseMap [j] >= NUM_SELECTABLE_FUNCTIONS) {
					pKeymap->m_rbyBaseMap [j]	= NFUNC_INVALID_CHAR ;
				}
			}
		}
		if (_siKeybindType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedKeymap)
			_siKeybindType	= KEYBINDTP_DEFAULT ;
		if (_siStartHenkanKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedStartHenkanKey)
			_siStartHenkanKeyType	= KEYBINDTP_DEFAULT ;
		if (_siCompletionRelatedKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedCompletionKey)
			_siCompletionRelatedKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSetHenkanPointSubrKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSetHenkanPointSubrKey)
			_siSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSpecialMidashiCharKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSpecialMidashiCharKey)
			_siSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;
	} else {
		/* ���[�h�Ɏ��s�����̂ŁA�f�t�H���g�̐ݒ�ɂ���B*/
		_siKeybindType					= KEYBINDTP_DEFAULT ;
		_siStartHenkanKeyType			= KEYBINDTP_DEFAULT ;
		_siCompletionRelatedKeyType		= KEYBINDTP_DEFAULT ;
		_siSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		_siSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;

		_bEggLikeNewline				= TRUE ;
		_bNewlineKakuteiAll				= FALSE ;
	}
	/*	�L�[�}�b�v�̏������B*/
	if (_siKeybindType == KEYBINDTP_DEFAULT) {
		imeConfig_vInitializeMajorModeMap () ;
		imeConfig_vInitializeSkkJModeMap () ;
		imeConfig_vInitializeSkkLatinModeMap () ;
		imeConfig_vInitializeSkkJisx0208LatinModeMap () ;
		imeConfig_vInitializeSkkAbbrevModeMap () ;
	}
	imeConfig_vInitializeMinibufferMinorModeMap () ;

	// ���p/�S�p�L�[��ǉ�
	imeConfig_bDefineKey(&_sMajorModeMap, 0xF3, 0, NFUNC_TOGGLE_IME);
	imeConfig_bDefineKey(&_sMajorModeMap, 0xF4, 0, NFUNC_TOGGLE_IME);

	return	TRUE ;
}

void
imeConfig_vInitializeMajorModeMap (void)
{
	#include "../common/major.h"

	int	i ;
	// struct CImeKeyBind*	pKeyBinds ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		_sMajorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	for (i = 0 ; i < ARRAYSIZE (_srbDefaultMajorModeMap) ; i ++)
		_sMajorModeMap.m_rbyBaseMap [i]	= _srbDefaultMajorModeMap [i] ;
	for (i = 32 ; i < 127 ; i ++)
		_sMajorModeMap.m_rbyBaseMap [i]	= NFUNC_SELF_INSERT_CHARACTER ;

	_sMajorModeMap.m_pKeyBinds	= NULL ;
	_sMajorModeMap.m_nKeyBinds	= 0 ;
}

void
imeConfig_vInitializeSkkJModeMap (void)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		_sSkkJModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 32 ; i < 127 ; i ++) {
		_sSkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_INSERT ;
	}
	_sSkkJModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	_sSkkJModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_KATAKANA ;

	/*	previous-candidate-char ���ɂ���ׂ����Akeybind ���� previous-candidate-char ��
	 *	���߂�悤�ɂ���ׂ����B�ǂ��炪�������̂��B��҂��I������Ȃ��������R�́A�ǂ�
	 *	minor-mode-map �𗘗p����Ηǂ��̂�������Ȃ��������炩�H
	 */
	_sSkkJModeMap.m_rbyBaseMap ['x']	= NFUNC_SKK_PREVIOUS_CANDIDATE ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			_sSkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	/*	try-completion-char �� skk-insert �ɂ��킹��B
	 *	try-completion-char �� keybind ����ɂ��邩�c�B���[��A�ł� try-completion �̓���
	 *	�� skk-insert �Ɠ����ɂ��Ă����� (function code �͈Ⴄ���ǁA����͓�����)�A
	 *	keybind �� try-completion �Ȃ� try-completion-charp �� t ��Ԃ��Ƃ����̂́H
	 *
	 *	�����Aabbrev-map �͑f���� try-completion �Ȃ̂ɁA������� skk-insert �o�R�Ƃ����̂�
	 *	�C�ɂȂ�c�B����������闝�R���l�������� try-completion ������̂͊댯���B
	 */
	_sSkkJModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_INSERT ;

	_sSkkJModeMap.m_pKeyBinds	= NULL ;
	_sSkkJModeMap.m_nKeyBinds	= 0 ;
}

void
imeConfig_vInitializeSkkLatinModeMap (void)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		_sSkkLatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkLatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;

	_sSkkLatinModeMap.m_pKeyBinds	= NULL ;
	_sSkkLatinModeMap.m_nKeyBinds	= 0 ;
}

void
imeConfig_vInitializeSkkJisx0208LatinModeMap (void)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		_sSkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	for (i = 0 ; i < 128 ; i ++) {
		/*	LatinVector �̏���������ɍs���Ă��Ȃ���΂Ȃ�Ȃ��B*/
		if (_rstrJisx0208LatinVector [i] != NULL)
			_sSkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_JISX0208_LATIN_INSERT ;
	}
	_sSkkJisx0208LatinModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_LATIN_HENKAN ;	/* \C-q */

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkJisx0208LatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-backward-and-set-henkan-point-char �́c 2stroke key �͎������ĂȂ�����c�B*/

	_sSkkJisx0208LatinModeMap.m_pKeyBinds	= NULL ;
	_sSkkJisx0208LatinModeMap.m_nKeyBinds	= 0 ;
}

void
imeConfig_vInitializeSkkAbbrevModeMap (void)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		_sSkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	_sSkkAbbrevModeMap.m_rbyBaseMap ['.']	= NFUNC_SKK_ABBREV_PERIOD ;
	_sSkkAbbrevModeMap.m_rbyBaseMap [',']	= NFUNC_SKK_ABBREV_COMMA ;
	_sSkkAbbrevModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_CHARACTERS ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkAbbrevModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-start-henkan-char �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkAbbrevModeMap.m_rbyBaseMap [' ']	= NFUNC_SKK_START_HENKAN ;

	/*	�{���� m_pKeyBinds �����āANFUNC_SKK_DELETE_BACKWARD_CHAR �̐ݒ������
	 *	���Ƃ����Ȃ��̂����B
	 */
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			_sSkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	_sSkkAbbrevModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_TRY_COMPLETION ;

	_sSkkAbbrevModeMap.m_pKeyBinds	= NULL ;
	_sSkkAbbrevModeMap.m_nKeyBinds	= 0 ;
}

void
imeConfig_vInitializeMinibufferMinorModeMap (void)
{
	struct CImeKeyBind*	pKeyBind ;
	int	i ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	_sMinibufferMinorModeMap.m_pKeyBinds	= NULL ;
	_sMinibufferMinorModeMap.m_nKeyBinds	= 0 ;

	/*	MajorModeMap, JModeMap �����āAKey ��ݒ肷��B
	 */
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_NEWLINE) {
			_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_EXIT_RECURSIVE_EDIT ;
		} else if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_KEYBOARD_QUIT) {
			_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_ABORT_RECURSIVE_EDIT ;
		}

		if (_sSkkJModeMap.m_rbyBaseMap [i] == NFUNC_SKK_KAKUTEI) {
			_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_KAKUTEI ;
		}
	}

	pKeyBind	= _sMajorModeMap.m_pKeyBinds ;
	for (i = 0 ; i < _sMajorModeMap.m_nKeyBinds ; i ++) {
		if (pKeyBind->m_nKeyFunction == NFUNC_NEWLINE) {
			imeConfig_bDefineKey (&_sMinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, NFUNC_EXIT_RECURSIVE_EDIT) ;
		} else if (pKeyBind->m_nKeyFunction == NFUNC_KEYBOARD_QUIT) {
			imeConfig_bDefineKey (&_sMinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, NFUNC_ABORT_RECURSIVE_EDIT) ;
		}
		pKeyBind	++ ;
	}

	pKeyBind	= _sSkkJModeMap.m_pKeyBinds ;
	for (i = 0 ; i < _sSkkJModeMap.m_nKeyBinds ; i ++) {
		if (pKeyBind->m_nKeyFunction == NFUNC_SKK_KAKUTEI)
			imeConfig_bDefineKey (&_sMinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, NFUNC_SKK_KAKUTEI) ;
		pKeyBind	++ ;
	}
}

BOOL
imeConfig_bDefineKey (
	struct CImeKeymap*		pKeymap,
	int						nKeyCode,
	unsigned int			uKeyMask,
	int						nKeyFunction)
{
	struct CImeKeyBind*	pKeyBind ;
	struct CImeKeyBind*	pNewBind ;
	int	i ;

	if (pKeymap == NULL)
		return	FALSE ;

	pKeyBind	= pKeymap->m_pKeyBinds ;
	for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
		if (pKeyBind->m_nKeyCode == nKeyCode && pKeyBind->m_uKeyMask == uKeyMask) {
			pKeyBind->m_nKeyFunction	= nKeyFunction ;
			return	TRUE ;
		}
		pKeyBind	++ ;
	}

	/* Not Found */
	pNewBind	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * (pKeymap->m_nKeyBinds + 1)) ;
	if (pNewBind == NULL)
		return	FALSE ;
	if (pKeymap->m_nKeyBinds > 0)
		memcpy (pNewBind, pKeymap->m_pKeyBinds, sizeof (struct CImeKeyBind) * pKeymap->m_nKeyBinds) ;
	if (pKeymap->m_pKeyBinds != NULL)
		FREE (pKeymap->m_pKeyBinds) ;
	pKeymap->m_pKeyBinds	= pNewBind ;
	pNewBind [pKeymap->m_nKeyBinds].m_nKeyCode	= nKeyCode ;
	pNewBind [pKeymap->m_nKeyBinds].m_uKeyMask	= uKeyMask ;
	pNewBind [pKeymap->m_nKeyBinds].m_nKeyFunction	= nKeyFunction ;
	pKeymap->m_nKeyBinds	++ ;
	return	TRUE ;
}

/*========================================================================
 *	private functions (for Keybind/���[�}�����ȃ��[��)
 */
static	BOOL	imeConfig_bLoadRomaKanaRuleListFromRegistry (void) ;
static	BOOL	imeConfig_bParseRomaKanaRuleLists (HKEY, LPCTSTR*, int, int, struct CSkkRuleTreeNode**, int, BOOL*) ;
static	BOOL	imeConfig_bParseRomaKanaRuleList (LPCTSTR, DWORD, int, int, struct CSkkRuleTreeNode**) ;

typedef WCHAR wchar;
typedef unsigned int sizet;
#define countof ARRAYSIZE

/// char�����񂩂�wchar������֕ϊ����T�C�Y��Ԃ� (1�o�C�g������p, �I�[�����͂��Ȃ�)
static sizet alnumtowcs(wchar* wsz, sizet n, const char* sz)
{
	sizet i = 0;
	ASSERT(wsz);
	if (sz) {
		for (; i < n; i++) {
			if (sz[i] == '\0') break;
			wsz[i] = sz[i];
		}
	}
	return i;
}

/// �f�t�H���g�̃��[�}�����ȕϊ����[����ݒ肷��
static BOOL imeConfig_bLoadRomaKanaRuleList()
{
	int i;
	struct TSkkBaseRule* p;

	#include "../common/roma_kana.h"

	// ������
	for (i = 0; i < NUM_ROMAKANARULE; i++) {
		_rpSkkRuleTree[i] = NULL;
		_rpSkkJisx0201RuleTree[i] = NULL;
		_rpSkkJisx0201RomanRuleTree[i] = NULL;
	}

	// ���W�X�g������o�^
	if (imeConfig_bLoadRomaKanaRuleListFromRegistry() &&
		_siRomaKanaRuleListType != KEYBINDTP_DEFAULT) return TRUE;

	// ���W�X�g������ǂ߂Ȃ��������A�ǂ񂾌��ʃf�t�H���g�l�̎w�肾�����ꍇ�̓e�[�u������\�z
	_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT;

	// �o�^
	for (p = _rDefaultRomaKanaRule; p < _rDefaultRomaKanaRule + countof(_rDefaultRomaKanaRule); p++) {
		wchar wszRule[16];
		wchar wszNext[16];
		DCHAR wszPrefix[16];
		sizet nRuleLen, nNextLen, nPrefixLen;
		sizet n;

		nRuleLen = alnumtowcs(wszRule, countof(wszRule), p->szRule);
		nNextLen = alnumtowcs(wszNext, countof(wszNext), p->szNext);
		nPrefixLen = wcstodcs(wszPrefix, countof(wszPrefix), wszRule, nRuleLen);
		n = p->nRule;
		ASSERT(n < NUM_ROMAKANARULE);
		if (p->nFunc == 0) {
			// �����o�^
			if (p->wszOut) {
				sizet nOut = lstrlenW(p->wszOut);
				if (p->wszKata) {
					sizet nKata = lstrlenW(p->wszKata);
					if (!TSkkRuleTreeNode_bAddRuleSP(&_rpSkkRuleTree[n], 0, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext, p->wszOut, nOut, p->wszKata, nKata)) {
					InitializeDefaultRomaKanaRuleTreeAbort:
						TSkkRuleTreeNode_vDestroyTree(_rpSkkRuleTree[n]);
						_rpSkkRuleTree[n] = NULL;
						TSkkRuleTreeNode_vDestroyTree(_rpSkkJisx0201RuleTree[n]);
						_rpSkkJisx0201RuleTree[n] = NULL;
						return FALSE;
					}
				} else {
					if (!TSkkRuleTreeNode_bAddRuleS(&_rpSkkRuleTree[n], 0, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext, p->wszOut, nOut))
						goto InitializeDefaultRomaKanaRuleTreeAbort;
				}
			}
			if (p->wszKana) {	// JIS X 0201�������݂���ꍇ�͓o�^
				sizet nKana = lstrlenW(p->wszKana);
				if (!TSkkRuleTreeNode_bAddRuleS(&_rpSkkJisx0201RuleTree[n], RULETREENO_SKK_JISX0201_BASE, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext + RULETREENO_SKK_JISX0201_BASE, p->wszKana, nKana))
					goto InitializeDefaultRomaKanaRuleTreeAbort;
			}
		} else {
			// �֐��o�^
			if (!TSkkRuleTreeNode_bAddRuleM(&_rpSkkRuleTree[n], 0, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext, p->nFunc))
				goto InitializeDefaultRomaKanaRuleTreeAbort;
			if (p->wszKana == NULL) {	// JIS X 0201�������݂���ꍇ�͓o�^
				if (!TSkkRuleTreeNode_bAddRuleM(&_rpSkkJisx0201RuleTree[n], RULETREENO_SKK_JISX0201_BASE, wszPrefix, nPrefixLen, wszNext, nNextLen, p->nNext + RULETREENO_SKK_JISX0201_BASE, p->nFunc))
					goto InitializeDefaultRomaKanaRuleTreeAbort;
			}
		}
	}

	return TRUE;
}

void
imeConfig_vClearRomaKanaRuleList (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rpSkkRuleTree) ; i ++) {
		TSkkRuleTreeNode_vDestroyTree (_rpSkkRuleTree [i]) ;
		TSkkRuleTreeNode_vDestroyTree (_rpSkkJisx0201RomanRuleTree [i]) ;
		TSkkRuleTreeNode_vDestroyTree (_rpSkkJisx0201RuleTree [i]) ;
		_rpSkkRuleTree				[i]	= NULL ;
		_rpSkkJisx0201RomanRuleTree	[i]	= NULL ;
		_rpSkkJisx0201RuleTree		[i]	= NULL ;
	}
	return ;
}

BOOL
imeConfig_bLoadRomaKanaRuleListFromRegistry (void)
{
	HKEY	hSubKey ;
	BOOL	bExistUserDefinedRomaKanaRule	= FALSE ;
	BOOL	bRetval	= TRUE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_ROMAKANARULE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		// LONG	lResult ;
		DWORD	dwType, cbData, dwValue ;

		/* rule-list-type (default or custom) */
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_ROMAKANARULE_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) {
			bRetval	= FALSE ;
			goto	skip_error ;
		}
		_siRomaKanaRuleListType	= (int) dwValue ;

		if (_siRomaKanaRuleListType != KEYBINDTP_DEFAULT) {
			static	LPCTSTR	srRomaKanaRuleTbl []	= {
				REGINFO_ROMAKANARULE,		REGINFO_ROMAKANARULE1,
				REGINFO_ROMAKANARULE2,		REGINFO_ROMAKANARULE3,
			} ;
			static	LPCTSTR	srJisx0201RomanRuleTbl []	= {
				REGINFO_JISX0201ROMANRULE,		REGINFO_JISX0201ROMANRULE1,
				REGINFO_JISX0201ROMANRULE2,		REGINFO_JISX0201ROMANRULE3,
			} ;
			static	LPCTSTR	srJisx0201RuleTbl []	= {
				REGINFO_JISX0201RULE,		REGINFO_JISX0201RULE1,
				REGINFO_JISX0201RULE2,		REGINFO_JISX0201RULE3,
			} ;
			BOOL	bExist1, bExist2, bExist3 ;

			bExist1 = bExist2 = bExist3 = FALSE ;
			if (! imeConfig_bParseRomaKanaRuleLists (hSubKey, srRomaKanaRuleTbl,		ARRAYSIZE (srRomaKanaRuleTbl),		RULETREENO_SKK_BASE,			_rpSkkRuleTree,					ARRAYSIZE (_rpSkkRuleTree), &bExist1) ||
				! imeConfig_bParseRomaKanaRuleLists (hSubKey, srJisx0201RomanRuleTbl,	ARRAYSIZE (srJisx0201RomanRuleTbl),	RULETREENO_SKK_JISX0201_ROMAN,	_rpSkkJisx0201RomanRuleTree,	ARRAYSIZE (_rpSkkJisx0201RomanRuleTree), &bExist2) ||
				! imeConfig_bParseRomaKanaRuleLists (hSubKey, srJisx0201RuleTbl,		ARRAYSIZE (srJisx0201RuleTbl),		RULETREENO_SKK_JISX0201_BASE,	_rpSkkJisx0201RuleTree,			ARRAYSIZE (_rpSkkJisx0201RuleTree), &bExist3))
				bRetval	= FALSE ;
			bExistUserDefinedRomaKanaRule	= bExist1 || bExist2 || bExist3 ;
		}
skip_error:
		RegCloseKey (hSubKey) ;
	}
	if (! bExistUserDefinedRomaKanaRule)
		_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;

	if (! bRetval)
		goto	error_exit ;
	return	TRUE ;

error_exit:
	return	FALSE ;
}

BOOL
imeConfig_bParseRomaKanaRuleLists (
	HKEY						hSubKey,
	LPCTSTR*					ppRomaKanaRuleTbl,
	int							iRomaKanaRuleTblSize,
	int							iRuleBaseOffset,
	struct CSkkRuleTreeNode**	ppRoot,
	int							iRuleSize,
	BOOL*						pbExist)
{
	LPTSTR	pwData	= NULL ;
	LONG	lResult ;
	DWORD	dwType, cbData ;
	BOOL	bExistUserDefinedRomaKanaRule ;
	int		i ;
	BOOL	bRetval ;

	bExistUserDefinedRomaKanaRule	= FALSE ;
	bRetval	= TRUE ;
	for (i = 0 ; i < MIN (iRuleSize, iRomaKanaRuleTblSize) ; i ++) {
		/* roma-kana-rule �{�́B*/
		lResult	= RegQueryValueEx (hSubKey, ppRomaKanaRuleTbl [i], NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS)
			continue ;
		if (dwType != REG_MULTI_SZ) {
			bRetval	= FALSE ;
			continue ;
		}
		pwData	= (LPTSTR) MALLOC (cbData) ;
		if (pwData == NULL)
			continue ;
		(void) RegQueryValueEx (hSubKey, ppRomaKanaRuleTbl [i], NULL, &dwType, (BYTE*)pwData, &cbData) ;

		if (imeConfig_bParseRomaKanaRuleList (pwData, cbData, iRuleBaseOffset, i, &ppRoot [i])) {
			bExistUserDefinedRomaKanaRule	= TRUE ;
		} else {
			ppRoot [i]	= NULL ;
		}
		FREE (pwData) ;
	}
	for ( ; i < iRuleSize ; i ++)
		ppRoot [i]	= NULL ;

	if (pbExist)
		*pbExist	= bExistUserDefinedRomaKanaRule ;
	return	bRetval ;
}

BOOL
imeConfig_bParseRomaKanaRuleList (
	LPCTSTR						pwData,
	DWORD						cbData,
	int							iRuleBaseOffset,
	int							iRule,
	struct CSkkRuleTreeNode**	ppRoot)
{
	LPCTSTR	pwSrc, pwSrcEnd ;
	TCHAR	bufState [128], bufNext [128], bufHira [128], bufKata [128] ;
	DCHAR	bufDState [128] ;
	TCHAR	bufNextRule [32] ;
	struct CSkkRuleTreeNode*	pRoot	= NULL ;

	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	while (*pwSrc != TEXT ('\0') && pwSrc < pwSrcEnd) {
		int			nType, nStateLen ;
		LPCWSTR		pwNext ;
		int			nNextRule ;

		nType	= *pwSrc ++ ;
		if (imeConfig_bParseBSEncodedString(&pwSrc, bufState, countof(bufState)))
			goto	next_entry ;
		if (imeConfig_bParseBSEncodedString(&pwSrc, bufNext, countof(bufNext)))
			goto	next_entry ;
		if (imeConfig_bParseBSEncodedString(&pwSrc, bufNextRule, countof(bufNextRule)))
			goto	next_entry ;

		// bufState	[ARRAYSIZE (bufState)		- 1]	= TEXT ('\0') ;
		nStateLen	= wcstodcs_n (bufDState, ARRAYSIZE (bufDState), bufState, lstrlen (bufState)) ;

		// bufNext		[ARRAYSIZE (bufNext)		- 1]	= TEXT ('\0') ;
		// bufNextRule	[ARRAYSIZE (bufNextRule)	- 1]	= TEXT ('\0') ;
		pwNext	= (bufNext [0] != TEXT ('\0'))? bufNext : NULL ;
#if TARGET_WIN2K
		if (_stscanf (bufNextRule, TEXT ("%d"), &nNextRule) != 1)
			nNextRule	= 0 ;
#else
		if (_sntscanf (bufNextRule, ARRAYSIZE (bufNextRule) - 1, TEXT ("%d"), &nNextRule) != 1)
			nNextRule	= 0 ;
#endif
		switch (nType) {
		case	TEXT ('1'):
			if (imeConfig_bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
				goto	next_entry ;
			if (!imeConfig_bParseBSEncodedString(&pwSrc, bufKata, countof(bufKata)))
				goto	next_entry ;

			// bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;
			// bufKata [ARRAYSIZE (bufKata)  - 1]	= TEXT ('\0') ;
			if (! TSkkRuleTreeNode_bAddRuleSP (&pRoot, iRuleBaseOffset + iRule, bufDState, nStateLen, pwNext, lstrlen (bufNext), iRuleBaseOffset + nNextRule, bufHira, lstrlen (bufHira), bufKata, lstrlen (bufKata))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('2'):
			if (!imeConfig_bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
				goto	next_entry ;
			// bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;
			if (! TSkkRuleTreeNode_bAddRuleS (&pRoot, iRuleBaseOffset + iRule, bufDState, nStateLen, pwNext, lstrlen (bufNext), iRuleBaseOffset + nNextRule, bufHira, lstrlen (bufHira))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('3'):
			{
				LPCTSTR	pwTemp ;
				int		nFuncNo	= 0 ;

				if (!imeConfig_bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
					goto	next_entry ;
				// bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;

				pwTemp	= bufHira ;
				while (*pwTemp != TEXT ('\0')) {
					int		nCH	;
					nCH	= *pwTemp ++ ;
					if (TEXT ('0') <= nCH && nCH <= TEXT ('9')) {
						nFuncNo	= nFuncNo * 10 + (nCH - TEXT ('0')) ;
					} else {
						goto	error_exit ;
					}
				}
				if (! TSkkRuleTreeNode_bAddRuleM (&pRoot, iRuleBaseOffset + iRule, bufDState, nStateLen, pwNext, lstrlen (bufNext), iRuleBaseOffset + nNextRule, nFuncNo)) {
					goto	error_exit ;
				}
			}
			break ;
		default:
			break ;
		}
next_entry:
		/* parse �Ɏ��s�����G���g���̏ꍇ nul �ɓ��B���Ă��Ȃ��̂ŁAnul �܂Ői�߂�B*/
		while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
			pwSrc ++ ;
		pwSrc	++ ;	/* nul �� skip */
	}
	if (ppRoot != NULL)
		*ppRoot	= pRoot ;
	return	TRUE ;
error_exit:
	TSkkRuleTreeNode_vDestroyTree (pRoot) ;
	return	FALSE ;
}

/*========================================================================
 *	private functions (for Keybind)
 */

/// Generic�ݒ�̓ǂݍ���
/**
�Y�����郌�W�X�g���G���g��������Βl��ǂݍ��݁A�Ȃ��ꍇ�̓f�t�H���g�l��ݒ肷��B
�����I�ɃG���g�������݂���ꍇ�͓ǂ߂镔�������ǂݍ��ށB
*/
BOOL imeConfig_bLoadGenericSetting()
{
	/// �Œ蒷�G���g���ǂݍ��ݗp�e�[�u��
	static const struct {
		LPCTSTR info;
		DWORD* dest;
	} _srRegNumber[] = {
		{ REGINFO_KANAMODEWHENOPEN,		(DWORD*)&_bKanaModeWhenOpen },
		{ REGINFO_ECHO,					(DWORD*)&_bEcho },
		{ REGINFO_COMPOSITIONAUTOSHIFT,	(DWORD*)&_bCompositionAutoShift },
		{ REGINFO_DELETEIMPLIESKAKUTEI,	(DWORD*)&_bDeleteImpliesKakutei },
		{ REGINFO_KAKUTEIEARLY,			(DWORD*)&_bKakuteiEarly },

		{ REGINFO_DATEAD,				(DWORD*)&_bDateAd },
		{ REGINFO_NUMBERSTYLE,			(DWORD*)&_iNumberStyle },

		{ REGINFO_KUTOUTENTYPE,			(DWORD*)&_iKutoutenType },
		{ REGINFO_AUTOINSERTPAREN,		(DWORD*)&_iBracketParenType },
		{ REGINFO_OKURICHARALISTTYPE,	(DWORD*)&_iOkuriCharAlistType },
	};

	/// �ϒ��G���g���ǂݍ��ݗp�e�[�u��
	static const struct {
		LPCTSTR info;
		int* num;
		void* dest;
		int size;
	} _srRegString[] = {
		{ REGINFO_KUTOUTENS,		&_iNumKutouten,			_srKutouten,		countof(_srKutouten) },
		{ REGINFO_BRACKETPARENS ,	&_iNumBracketParen,		_srBracketParen,	countof(_srBracketParen) },
		{ REGINFO_OKURICHARALIST,	&_iNumOkuriCharAlist,	_srOkuriCharAlist,	countof(_srOkuriCharAlist) },
	};

	#include "../common/kutouten.h"
	#include "../common/bracket.h"

	HKEY hSubKey;
	int i;

	// �f�t�H���g�l�ݒ�
	_bKanaModeWhenOpen		= TRUE;
	_bEcho					= TRUE;
	_bCompositionAutoShift	= TRUE;
	_bDeleteImpliesKakutei	= TRUE;
	_bKakuteiEarly			= TRUE;

	_bDateAd				= FALSE;
	_iNumberStyle			= 0;

	_iKutoutenType			= KUTOUTEN_TYPE_JP;
	_iBracketParenType		= BRACKETPARENTP_NONE;
	_iOkuriCharAlistType	= OKURICHARTP_NONE;

	_iNumKutouten = 0;
	_iNumBracketParen = 0;
	_iNumOkuriCharAlist = 0;

	if (RegOpenKeyEx(HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS)
		goto skip_assume;

	// �Œ蒷�G���g��
	for (i = 0; i < countof(_srRegNumber); i++) {
		DWORD dwType, cbData = sizeof(DWORD);
		DWORD dwValue;
		LONG lResult = RegQueryValueEx(hSubKey, _srRegNumber[i].info, NULL, &dwType, (BYTE*)&dwValue, &cbData);
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			ASSERT(sizeof(DWORD) == sizeof(int) && sizeof(DWORD) == sizeof(BOOL));
			*_srRegNumber[i].dest = dwValue;	// BOOL�����̂܂܂ł����񂿂Ⴄ
		}
	}

	// �ϒ��G���g��
	for (i = 0; i < countof(_srRegString); i++) {
		DWORD dwType, cbData = 0;
		LONG lResult = RegQueryValueEx(hSubKey, _srRegString[i].info, NULL, &dwType, NULL, &cbData);
		if (lResult == ERROR_SUCCESS && dwType == REG_MULTI_SZ) {
			LPTSTR p = (LPTSTR)MALLOC(cbData);
			if (p == NULL) continue;
			RegQueryValueEx(hSubKey, _srRegString[i].info, NULL, &dwType, (BYTE*)p, &cbData);
			*_srRegString[i].num = imeConfig_iDecodeStringPairList(p, _srRegString[i].dest, _srRegString[i].size);
			FREE(p);
		}
	}

	RegCloseKey(hSubKey);
skip_assume:

	// ��Ǔ_����
	switch (_iKutoutenType) {
	case KUTOUTEN_TYPE_JP:
		_iNumKutouten = imeConfig_iDecodeStringPairList(_srDefaultKutoutenJP, _srKutouten, countof(_srKutouten));
		break;
	case KUTOUTEN_TYPE_EN:
		_iNumKutouten = imeConfig_iDecodeStringPairList(_srDefaultKutoutenEN, _srKutouten, countof(_srKutouten));
		break;
	}

	// ���ʒ���
	switch (_iBracketParenType) {
	case BRACKETPARENTP_DEFAULT:
		_iNumBracketParen = imeConfig_iDecodeStringPairList(_srDefaultBracketParen, _srBracketParen, countof(_srDefaultBracketParen));
		break;
	}

	return TRUE;
}

/*========================================================================
 *	private functions for conversion
 */
static	BOOL	imeConfig_bLoadConversionSettingFromRegistry (void) ;

BOOL
imeConfig_bLoadConversionSetting (void)
{
	#include "../common/menu_keys.h"
	#include "../common/auto_henkan.h"

	int i;
	#define B2D(n, d, s) n = countof(s); for (i = 0; i < n; i++) d[i] = (DCHAR)s[i];

	if (! imeConfig_bLoadConversionSettingFromRegistry ()) {
		_snCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumShowCandidateKeys			= 0 ;
		_snNumInputCodeMenu1Keys		= 0 ;
		_snNumInputCodeMenu2Keys		= 0 ;

		_snShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;
		_sbHenkanOkuriStrictly			= FALSE ;
		_sbProcessOkuriEarly			= FALSE ;
		_sbHenkanStrictOkuriPrecedence	= FALSE ;
		_sbAutoStartHenkan				= TRUE ;
		_sbDeleteOkuriWhenQuit			= FALSE ;
		_sbAutoOkuriProcess				= FALSE ;
		_snShowAnnotationType			= SHOW_NO_ANNOTATION ;

		_siNumAutoStartHenkanKeywords	= -1 ;
	}
	switch (_snCandListKeyAssign) {
	case	CANDLIST_KEYASSIGN_DEFAULT:
		/*
		_snNumShowCandidateKeys		= ARRAYSIZE (_srbDefaultCandidateKeys) ;
		_snNumInputCodeMenu1Keys	= ARRAYSIZE (_srbDefaultMenu1Keys) ;
		_snNumInputCodeMenu2Keys	= ARRAYSIZE (_srbDefaultMenu2Keys) ;
		memcpy (_srdchShowCandidateKeys,	_srbDefaultCandidateKeys,	sizeof (_srbDefaultCandidateKeys)) ;
		memcpy (_srdchInputCodeMenu1Keys,	_srbDefaultMenu1Keys,		sizeof (_srbDefaultMenu1Keys)) ;
		memcpy (_srdchInputCodeMenu2Keys,	_srbDefaultMenu2Keys,		sizeof (_srbDefaultMenu2Keys)) ;
		*/
		B2D(_snNumShowCandidateKeys, _srdchShowCandidateKeys, _srbDefaultCandidateKeys);
		B2D(_snNumInputCodeMenu1Keys, _srdchInputCodeMenu1Keys, _srbDefaultMenu1Keys);
		B2D(_snNumInputCodeMenu2Keys, _srdchInputCodeMenu2Keys, _srbDefaultMenu2Keys);
		break ;
	case	CANDLIST_KEYASSIGN_01234567890:
		/*
		_snNumShowCandidateKeys		= ARRAYSIZE (_srb10Keys) ;
		_snNumInputCodeMenu1Keys	= ARRAYSIZE (_srb10Keys) ;
		_snNumInputCodeMenu2Keys	= ARRAYSIZE (_srb10Keys) ;
		memcpy (_srdchShowCandidateKeys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (_srdchInputCodeMenu1Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (_srdchInputCodeMenu2Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		*/
		B2D(_snNumShowCandidateKeys, _srdchShowCandidateKeys, _srb10Keys);
		B2D(_snNumInputCodeMenu1Keys, _srdchInputCodeMenu1Keys, _srb10Keys);
		B2D(_snNumInputCodeMenu2Keys, _srdchInputCodeMenu2Keys, _srb10Keys);
		break ;
	}

	if (_siNumAutoStartHenkanKeywords < 0) {
		imeConfig_vInitAutoStartHenkanKeys (_srDefaultAutoStartHenkanKeywords, ARRAYSIZE (_srDefaultAutoStartHenkanKeywords)) ;
	}
	return	TRUE ;
}

BOOL
imeConfig_bLoadConversionSettingFromRegistry (void)
{
	static struct {
		LPCTSTR		m_strInfoKey ;
		BOOL*		m_pbData ;
	}	_srRegBoolValues []	= {
		{	REGINFO_HENKANOKURISTRICTLY,			&_sbHenkanOkuriStrictly,	},
		{	REGINFO_PROCESSOKURIEARLY,				&_sbProcessOkuriEarly,		},
		{	REGINFO_HENKANSTRICTOKURIPRECEDENCE,	&_sbHenkanStrictOkuriPrecedence,	},
		{	REGINFO_AUTOSTARTHENKAN,				&_sbAutoStartHenkan,		},
		{	REGINFO_DELETEOKURIWHENQUIT,			&_sbDeleteOkuriWhenQuit,	},
		{	REGINFO_AUTOOKURIPROCESS,				&_sbAutoOkuriProcess,		},
		/* NumericConversion, NumericFloat ��ǉ��B(2008/07/18) */
		{	REGINFO_NUMERICCONVERSION,				&_sbNumericConversion,		},
		{	REGINFO_NUMERICFLOAT,					&_sbNumericFloat,			},
	} ;
	HKEY	hSubKey ;
	LONG	lResult ;
	DWORD	dwType, cbData, dwValue ;
	int		i ;
	BYTE	rbBuffer [MAX_NUMMENUKEYS] ;
	BOOL	bRetval	= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_CONVERSION, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS)
		return	FALSE ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_CANDLISTKEYASSIGN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	_snCandListKeyAssign	= (/*CANDLIST_KEYASSIGN_DEFAULT <= dwValue && */dwValue <= CANDLIST_KEYASSIGN_01234567890)? (int) dwValue : CANDLIST_KEYASSIGN_USERDEFINED ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATELISTCOUNT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	_snShowCandListCount	= (int) dwValue ;

	for (i = 0 ; i < ARRAYSIZE (_srRegBoolValues) ; i ++) {
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueEx (hSubKey, _srRegBoolValues [i].m_strInfoKey, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		*(BOOL*)(_srRegBoolValues [i].m_pbData)	= (dwValue != 0) ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumShowCandidateKeys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++)
			_srdchShowCandidateKeys [i]	= (DCHAR) rbBuffer [i] ;
		_snNumShowCandidateKeys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumInputCodeMenu1Keys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++)
			_srdchInputCodeMenu1Keys [i]	= (DCHAR) rbBuffer [i] ;
		_snNumInputCodeMenu1Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumInputCodeMenu2Keys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++)
			_srdchInputCodeMenu2Keys [i]	= (DCHAR) rbBuffer [i] ;
		_snNumInputCodeMenu2Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ || cbData <= 0 || cbData >= sizeof (_srAutoStartHenkanKeywords)) {
		/* default �̐ݒ�B*/
		_srAutoStartHenkanKeywords [0]	= L'\0' ;
		_siNumAutoStartHenkanKeywords	= -1 ;
	} else {
		LPWSTR	pwBuffer ;

		pwBuffer	= MALLOC (sizeof (WCHAR) * cbData) ;
		if (pwBuffer != NULL) {
			(void) RegQueryValueEx (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, (BYTE*) pwBuffer, &cbData) ;

			imeConfig_vInitAutoStartHenkanKeys (pwBuffer, cbData) ;
			FREE (pwBuffer) ;
		}
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD) {
		_snShowAnnotationType	= SHOW_NO_ANNOTATION ;
	} else {
		DWORD	dwValue ;
		(void) RegQueryValueEx (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;

		if (dwValue == (DWORD)DISABLE_ANNOTATION) {
			_snShowAnnotationType	= DISABLE_ANNOTATION ;
		} else if (/*0 <= dwValue && */dwValue <= SHOW_ANNOTATION_ALWAYS) {
			_snShowAnnotationType	= (int) dwValue ;
		} else {
			_snShowAnnotationType	= SHOW_NO_ANNOTATION ;
		}
	}
	bRetval	= TRUE ;

skip_error:
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

static	void
imeConfig_vInitAutoStartHenkanKeys (LPCWSTR pwKeys, int nKeyLen)
{
	LPDSTR	pDest, pDestEnd ;
	LPCWSTR	pSrc, pSrcEnd ;
	int		iNumKeywords ;

	/* ���𐔂���B*/
	iNumKeywords	= 0 ;
	pDest			= _srAutoStartHenkanKeywords ;
	pDestEnd		= _srAutoStartHenkanKeywords + ARRAYSIZE (_srAutoStartHenkanKeywords) - 1 ;
	pSrc			= pwKeys ;
	pSrcEnd			= pwKeys + nKeyLen ;

	while (pSrc < pSrcEnd && *pSrc != L'\0' && pDest < pDestEnd) {
		int	nKeywordLen	= lstrlenW (pSrc) ;

		if (nKeywordLen > 0) {
			int		n ;

			n		= wcstodcs_n (pDest, pDestEnd - pDest, pSrc, nKeywordLen) ;
			if ((pDest + n) >= pDestEnd) {
				*pDest ++	= L'\0' ;
				break ;
			}
			pDest	+= n ;
			*pDest ++	= L'\0' ;
			iNumKeywords ++ ;
		}
		pSrc	+= nKeywordLen + 1 ;
	}
	if (pDest < pDestEnd)
		*pDest ++	= L'\0' ;

	_siNumAutoStartHenkanKeywords	= iNumKeywords ;
	return ;
}

/*========================================================================
 *	private functions for colorface
 */
static	BOOL	imeConfig_bLoadColorfaceSettingFromRegistry (const MYCOLORFACESET*) ;
static	BOOL	bIsValidColor		(int) ;
static	BOOL	bIsValidLineType	(int) ;

BOOL
imeConfig_bLoadColorfaceSetting (void)
{
	#include "../common/colorfaces.h"

	if (! imeConfig_bLoadColorfaceSettingFromRegistry (_srDefaultColorFaces))
		memcpy (_srImeColorFaces, _srDefaultColorFaces, sizeof (_srImeColorFaces)) ;
	return	TRUE ;
}

BOOL
imeConfig_bLoadColorfaceSettingFromRegistry (
	const MYCOLORFACESET*	pDefaultColorFaces)
{
	HKEY	hSubKey ;
	BOOL	bRetval	= FALSE ;
	BYTE	rbStyles [ARRAYSIZE (_srImeColorFaces) * 4] ;
	int		i ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_STYLE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG		lResult ;
		DWORD		dwType, cbData ;
		const BYTE*	pbData ;

		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData != sizeof (rbStyles))
			goto	skip_error ;

		(void) RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, (BYTE*)rbStyles, &cbData) ;

		pbData	= rbStyles ;
		for (i = 0 ; i < ARRAYSIZE (_srImeColorFaces) ; i ++) {
			int		nTextColor, nBackColor, nUnderLineColor, nUnderLineType ;

			nTextColor		= *pbData ++ ;
			nTextColor		= bIsValidColor (nTextColor)? nTextColor : pDefaultColorFaces [i].m_nTextColor ;
			_srImeColorFaces [i].m_nTextColor		= nTextColor ;
			nBackColor		= *pbData ++ ;
			nBackColor		= bIsValidColor (nBackColor)? nBackColor : pDefaultColorFaces [i].m_nBackColor ;
			_srImeColorFaces [i].m_nBackColor		= nBackColor ;
			nUnderLineColor	= *pbData ++ ;
			nUnderLineColor	= bIsValidColor (nUnderLineColor)? nUnderLineColor : pDefaultColorFaces [i].m_nUnderLineColor ;
			_srImeColorFaces [i].m_nUnderLineColor	= nUnderLineColor ;
			nUnderLineType	= *pbData ++ ;
			nUnderLineType	=  bIsValidLineType (nUnderLineType)? nUnderLineType : pDefaultColorFaces [i].m_nUnderLineType ;
			_srImeColorFaces [i].m_nUnderLineType	= nUnderLineType ;
		}
		bRetval		= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	return	bRetval ;
}

BOOL
bIsValidColor (int nColorType)
{
	return	(nColorType < 0 || nColorType >= MAX_MYCOLOR) ? FALSE : TRUE ;
}

BOOL
bIsValidLineType (int nLineType)
{
	return	(nLineType < 0 || nLineType >= MAX_MYLINE)? FALSE : TRUE ;
}

static	void
imeConfig_vInitializeDefaultFontSetting (void)
{
	HKEY	hSubKey ;
	LOGFONT	lf ;

	memset (&lf, 0, sizeof (lf)) ;
	{
		NONCLIENTMETRICS	param ;

		memset (&param, 0, sizeof (param)) ;
		param.cbSize	= sizeof (param) ;
		if (SystemParametersInfo (SPI_GETNONCLIENTMETRICS, param.cbSize, &param, 0)) {
			memcpy (&lf, &param.lfMessageFont, sizeof (LOGFONT)) ;
		}
	}
	_siDefaultFontSize	= -1 ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_STYLE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG		lResult ;
		DWORD		dwType, cbData ;

		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD && cbData == sizeof (DWORD)) {
			DWORD	dwValue ;

			(void) RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
			_siDefaultFontSize	= (int) dwValue ;
		}
		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_SZ && cbData <= sizeof (TCHAR) * LF_FACESIZE) {
			memset (&lf.lfFaceName, 0, sizeof (TCHAR) * LF_FACESIZE) ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, (BYTE*)&lf.lfFaceName, &cbData) ;
		}
		RegCloseKey (hSubKey) ;
	}
	memcpy (&_slfDefaultFont, &lf, sizeof (LOGFONT)) ;
	return ;
}

/// ���W�X�g���Ɋi�[���ꂽ�[���I�[������̈ꕔ���G�X�P�[�v�V�[�P���X���f�R�[�h���擾
/**
�f�R�[�h����G�X�P�[�v�V�[�P���X�� '\\' '0' �̂݁B����ȊO�̕����͂��̂܂܉��߂���B
�]�����̕����񂪓]����̃o�b�t�@��蒷���ꍇ�A�|�C���^�͍Ō�ɓ]�����������̒�����w���B���̏�ԂɊׂ�Ȃ��͈͂Ŏg�����Ƃ𐄏��B

����ƈقȂ�_
pbTerminated��p�~���Ԃ�l��p����
�o�b�t�@�T�C�Y��1�o�C�g�ȏ゠��ꍇ�A�K���I�[�����B1�������炵�Ĕԕ������Ȃ����K�v�Ȃ��B
��؂蕶���� ',' ��ǉ��B�z��O�̃G�X�P�[�v�V�[�P���X�̏ꍇ�ł��|�C���^���������i�ނ悤�C���B
*/
BOOL imeConfig_bParseBSEncodedString(
	LPCTSTR*	ppwSrc,
	LPTSTR		pwDest,
	int			nDestSize)
{
	LPCTSTR pwSrc = *ppwSrc;
	LPTSTR pwDestLast = pwDest + nDestSize - 1;
	while (*pwSrc && pwDest < pwDestLast) {
		TCHAR c = *pwSrc;
		if (c == SEPCHAR) {
			pwSrc++;
			break;
		}
		if (c == TEXT('\\')) {
			c = *++pwSrc;
			if (c == TEXT('0')) {
				pwSrc++;
				break;
			}
			if (c == TEXT('\0')) break;		// ��m��
		}
		*pwDest++ = c;
		pwSrc++;
	}
	if (pwDest <= pwDestLast) *pwDest = TEXT('\0');
	*ppwSrc = pwSrc;

	return *pwSrc == TEXT('\0');
}

/// ���W�X�g���Ɋi�[���ꂽMULTI_SZ�𕶎���y�A�Ƃ��Ď擾
/**
����A\\0����B\\0\0
����C\\0����D\\0\0\0
�Ƃ���'\\' '0'�̃G�X�P�[�v�V�[�P���X�ŋ�؂�ꂽMULTI_SZ������
�s�����O�̃Z�p���[�^�͏ȗ��\(������)

�����ł̒ǉ��@�\�Ƃ��Ĉȉ��̃p�^�[�������e��1�����Z�k�\�Ƃ���
����A,����B\0
����C,����D\0\0

�s���ȃf�[�^��ǂ݂��񂾏ꍇ�͏����𒆒f����B����ɓǂݍ��߂������͏������Ɏc���B
*/
int imeConfig_iDecodeStringPairList(
	LPCTSTR					pwEncodedString,
	struct TStringPair*		pDestBuffer,
	int						iBufferSize)
{
	struct TStringPair*		pDest ;
	struct TStringPair*		pDestEnd ;
	LPCTSTR	pwSrc ;
	TCHAR	bufLeft [BUFSIZE_STRPAIR], bufRight [BUFSIZE_STRPAIR] ;
	size_t n;

	pwSrc			= pwEncodedString ;
	pDest			= pDestBuffer ;
	pDestEnd		= pDestBuffer + iBufferSize ;
	while (*pwSrc && pDest < pDestEnd) {
		if (imeConfig_bParseBSEncodedString(&pwSrc, bufLeft, countof(bufLeft))) {
			break ;
		}
		// bufLeft [ARRAYSIZE (bufLeft) - 1]	= TEXT ('\0') ;
		if (!imeConfig_bParseBSEncodedString(&pwSrc, bufRight, countof(bufRight))) {
			break ;
		}
		// bufRight [ARRAYSIZE (bufRight) - 1]	= TEXT ('\0') ;

		n = wcstodcs(pDest->m_bufLeft, countof(pDest->m_bufLeft), bufLeft, lstrlen(bufLeft));
		pDest->m_bufLeft[n] = L'\0';
		n = wcstodcs(pDest->m_bufRight, countof(pDest->m_bufRight), bufRight, lstrlen(bufRight));
		pDest->m_bufRight[n] = L'\0';

		// MULTI_SZ�s���`�F�b�N�ς݂̂��ߕs�v
		// if (*pwSrc) break;
		pwSrc	++ ;
		pDest	++ ;
	}
	return	pDest - pDestBuffer ;
}

