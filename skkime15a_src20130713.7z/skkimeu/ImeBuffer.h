#pragma once

#include "dchar.h"

struct CImeBuffer ;
struct TMarker ;

enum {
	MARKER_POINT	= 0,
	MARKER_BUFFERTOP,
	MARKER_BUFFEREND,
	MARKER_MARK,
	MARKER_SKK_PREVIOUS_POINT,
	MARKER_SKK_KANA_START_POINT,
	MARKER_SKK_HENKAN_START_POINT,
	MARKER_SKK_HENKAN_END_POINT,
	MARKER_SKK_OKURIGANA_START_POINT,
	MAX_RESERVED_MARKERS
} ;

#define	MAXCOMPLEN		(256)

struct CImeBuffer*	ImeBuffer_pCreate				(struct CImeDoc*) ;
BOOL				ImeBuffer_bInit					(struct CImeBuffer*, LPCDSTR, int, BOOL) ;
void				ImeBuffer_vUninit				(struct CImeBuffer*) ;
void				ImeBuffer_vDestroy				(struct CImeBuffer*) ;
BOOL				ImeBuffer_bClear				(struct CImeBuffer*) ;
void				ImeBuffer_vSetParent			(struct CImeBuffer*, struct CImeBuffer*) ;
struct CImeBuffer*	ImeBuffer_pGetParent			(struct CImeBuffer*) ;
LPCDSTR				ImeBuffer_pBufferRawString		(const struct CImeBuffer*, int*) ;
LPCDSTR				ImeBuffer_pBufferString			(const struct CImeBuffer*, int*) ;
BOOL				ImeBuffer_bHavePrefixp			(const struct CImeBuffer*) ;

BOOL				ImeBuffer_bSetConversionString	(struct CImeBuffer*, LPCDSTR, int, BOOL) ;
int					ImeBuffer_iGetConversionMode	(struct CImeBuffer*) ;
BOOL				ImeBuffer_bSetConversionMode	(struct CImeBuffer*, int) ;
BOOL				ImeBuffer_bQueryUpdateContext	(struct CImeBuffer*, int*, int*, BOOL*) ;
BOOL				ImeBuffer_bUpdateContext		(struct CImeBuffer*) ;
BOOL				ImeBuffer_bGetSelectedRegion	(struct CImeBuffer*, int*, int*) ;
BOOL				ImeBuffer_bGetConvertedRegion	(struct CImeBuffer*, int*, int*) ;
int					ImeBuffer_iGetReadingText		(struct CImeBuffer*, LPDSTR, int, int, int*) ;

BOOL				ImeBuffer_bGetMarker			(struct CImeBuffer*, int, struct TMarker**) ;
BOOL				ImeBuffer_bForwardChar			(struct CImeBuffer*, int) ;
BOOL				ImeBuffer_bBackwardChar			(struct CImeBuffer*, int) ;
BOOL				ImeBuffer_bFollowingStringEqualp(struct CImeBuffer*, LPCDSTR, int) ;
int					ImeBuffer_iInsert				(struct CImeBuffer*, struct TMarker*, LPCDSTR, int) ;
int					ImeBuffer_iInsertW				(struct CImeBuffer*, struct TMarker*, LPCWSTR, int) ;
int					ImeBuffer_iInsertBeforeMarkers	(struct CImeBuffer*, struct TMarker*, LPCDSTR, int) ;
int					ImeBuffer_iInsertByPosition		(struct CImeBuffer*, int, LPCDSTR, int) ;
int					ImeBuffer_iInsertBeforeMarkersByPosition	(struct CImeBuffer*, int, LPCDSTR, int) ;
int					ImeBuffer_iOverwriteByPosition	(struct CImeBuffer*, int, LPCDSTR, int) ;
BOOL				ImeBuffer_bInsertAndInherit		(struct CImeBuffer*, LPCDSTR, int) ;
BOOL				ImeBuffer_bInsertAndInheritW	(struct CImeBuffer*, LPCWSTR, int) ;
BOOL				ImeBuffer_bInsertBeforeMarkers	(struct CImeBuffer*, LPCDSTR, int) ;
BOOL				ImeBuffer_bDeleteRegion			(struct CImeBuffer*, int, int) ;
BOOL				ImeBuffer_bDeleteBackwardChar	(struct CImeBuffer*, int) ;
struct TMarker*		ImeBuffer_pMakeMarker			(struct CImeBuffer*, BOOL) ;
BOOL				ImeBuffer_bDeleteMarker			(struct CImeBuffer*, struct TMarker*) ;
BOOL				ImeBuffer_bSetMarker			(struct CImeBuffer*, struct TMarker**, int, const struct TMarker*) ;

BOOL				ImeBuffer_bJModep				(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bLatinModep			(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bJisx0208LatinModep	(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bAbbrevModep			(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bJModep				(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bKatakanaModep		(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bJisx0201Modep		(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bJisx0201Romanp		(const struct CImeBuffer*) ;

BOOL				ImeBuffer_bKeyboardQuit			(struct CImeBuffer*) ;
BOOL				ImeBuffer_bExitMinibuffer		(struct CImeBuffer*) ;
BOOL				ImeBuffer_bAbortRecursiveEdit	(struct CImeBuffer*) ;
BOOL				ImeBuffer_bNewline				(struct CImeBuffer*) ;

BOOL				ImeBuffer_bSkkHenkanActivep				(const struct CImeBuffer*) ;
struct CSkkRuleTreeIterator*	ImeBuffer_pSkkGetSkkRuleTreeIterator (struct CImeBuffer*) ;
BOOL				ImeBuffer_bShowHenkanCandidatesModep	(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bInputByCodeOrMenuModep		(const struct CImeBuffer*) ;
BOOL				ImeBuffer_bInputByCodeOrMenu1Modep		(const struct CImeBuffer*) ;

int					ImeBuffer_iGetLineOffset		(const struct CImeBuffer*) ;
void				ImeBuffer_vSetLineOffset		(struct CImeBuffer*, int) ;

BOOL				ImeBuffer_bSetReadingProperty	(struct CImeBuffer*, const struct TMarker*, const struct TMarker*, LPCDSTR, int) ;

void				ImeBuffer_vCopyState			(struct CImeBuffer*, const struct CImeBuffer*) ;


