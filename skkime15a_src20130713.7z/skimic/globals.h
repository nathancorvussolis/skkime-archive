/**
���ʐݒ�
*/

#pragma once

#if defined _WIN95 || defined _WIN32_WINDOWS
#pragma message("�ΏۊO�̊��ł��B") warning
#endif

#if defined WIN2K || defined WINXP		///< Windows 2000 / Windows XP
#define NTVER 0x0500
#define IEVER 0x0501
#elif defined WINVISTA || defined WIN7	///< Windows Vista / Windows 7
#define NTVER 0x0600
#define IEVER 0x0700
#endif

#ifdef NTVER
#ifndef WINVER
#define WINVER NTVER
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT NTVER
#endif
#ifndef _WIN32_IE
#define _WIN32_IE IEVER
#endif
#else
#pragma message("�ŐV�̊����g�p���܂��B") warning
#include <SDKDDKVer.h>
#endif

#define WIN32_LEAN_AND_MEAN

// Windows
#include <windows.h>			///< Windows �֘A

// C �����^�C��
#include <stddef.h>				///< offsetof ��`
#define countof _countof		///< countof ��`

// ���̑�
#include <shlwapi.h>
#include <ole2.h>
#include <olectl.h>

// TCHAR
#include <tchar.h>
typedef TCHAR tchar;
typedef WCHAR wchar;

// ASSERT
#include <assert.h>
#ifdef _DEBUG
#define ASSERT assert
#else
#define ASSERT __assume
#endif
#define NODEFAULT ASSERT(0)

////////////////////////////////////////////////////////////////////

#ifdef UNITTEST
#include "stdafx.h"
#else	// UNITTEST

#include <msctf.h>
#include <ctffunc.h>
#include "skimic_config.h"

/*	function prototypes
 */
LONG	DllAddRef () ;
LONG	DllRelease () ;

void	InsertTextAtSelection	(TfEditCookie ec, ITfContext *pContext, const WCHAR *pchText, ULONG cchText) ;
BOOL	AdviseSink				(IUnknown *pSource, IUnknown *pSink, REFIID riid, DWORD *pdwCookie) ;
void	UnadviseSink			(IUnknown *pSource, DWORD *pdwCookie) ;
BOOL	AdviseSingleSink		(TfClientId tfClientId, IUnknown *pSource, IUnknown *pSink, REFIID riid) ;
void	UnadviseSingleSink		(TfClientId tfClientId, IUnknown *pSource, REFIID riid) ;
BOOL	IsRangeCovered			(TfEditCookie ec, ITfRange *pRangeTest, ITfRange *pRangeCover) ;
BOOL	GetGUIDAtomFromGUID		(REFGUID refguid, DWORD* pdw) ;

#if defined (DEBUG) || defined (_DEBUG)
void	DebugPrintf	(LPCTSTR strFormat, ...) ;
void	DebugPrintfW(LPCWSTR strFormat, ...) ;
void	vDebugPrintfToFile (LPCTSTR strFormat, ...) ;
#endif

#undef	DEBUGLOGFILE_ENABLE
#define	DEBUGFILENAME		TEXT("skimic.log")

#if !defined (MYARRAYSIZE)
#define	MYARRAYSIZE(myarray)		(sizeof(myarray)/sizeof(myarray[0]))
#endif
#if !defined (ASSERT)
#if defined (DEBUG) || defined (_DEBUG)
#define	ASSERT(x)	assert(x)
#else
#define	ASSERT(x)	/*(x)*/
#endif
#endif
#if defined (NOALIGNOF)
#define	__alignof(sometype)		my_alignof(sizeof(sometype))

__inline	int	my_alignof (int iSize) {
	/* 4byte alignment? */
	switch (iSize) {
		case	1:
		case	2:
			return	iSize ;
		case	3:
		case	4:
			return	4 ;
		case	5:
		case	6:
		case	7:
		case	8:
			return	8 ;
		default:
			return	16 ;	/* ... */
	}
}
#endif

/*	�ނށALANGID�c����� SKKIME �� LANGID �ƈ�v������
 *	���Ƃ��K�v�Ȃ̂��H
 *
 *       +-----------------------+-------------------------+
 *       |     Sublanguage ID    |   Primary Language ID   |
 *       +-----------------------+-------------------------+
 *        15                   10 9                       0   bit
 */
#define	SKKIME_LANGID			MAKELANGID(LANG_JAPANESE, SUBLANG_DEFAULT)
#define	SKKIME_KEYBOARDLAYOUT	TEXT("E0110411")

#define	SKKIME_DESC				TEXT("SKKIME")	// �C��
#define	SKKIME_MODEL			TEXT("Apartment")

//#define LANGBAR_ITEM_DESC	L"���̓��[�h" // max 32 chars! �ށA�ő�32�����������B

#define SKKIME_ICON_INDEX  7

#define SafeRelease(punk)       \
{                               \
    if ((punk) != NULL)         \
    {                           \
        (punk)->Release();      \
    }                           \
}

#define SafeReleaseClear(punk)  \
{                               \
    if ((punk) != NULL)         \
    {                           \
        (punk)->Release();      \
        (punk) = NULL;          \
    }                           \
}

#if defined (DEBUG) || defined (_DEBUG)
#define	DEBUGPRINTF(text)	DebugPrintf##text
#define	DEBUGPRINTFW(text)	DebugPrintfW##text
#else
#define	DEBUGPRINTF(text)	/*text*/
#define	DEBUGPRINTFW(text)	/*text*/
#endif

#if !defined (MIN)
#define	MIN(lvalue,rvalue)	(((lvalue) < (rvalue))? (lvalue) : (rvalue))
#endif
#if !defined (MAX)
#define	MAX(lvalue,rvalue)	(((lvalue) > (rvalue))? (lvalue) : (rvalue))
#endif

//+---------------------------------------------------------------------------
//
// SafeStringCopy
//
// Copies a string from one buffer to another.  wcsncpy does not always
// null-terminate the destination buffer; this function does.
//----------------------------------------------------------------------------

inline void SafeStringCopy (WCHAR *pchDst, ULONG cchMax, const WCHAR *pchSrc)
{
//#if !defined(WIN64) && defined (_MSC_VER) && (_MSC_VER >= 1400)
#if __STDC_WANT_SECURE_LIB__
	wcscpy_s(pchDst, cchMax, pchSrc);
#else
	_ERROR;
    if (cchMax > 0) {
		wcsncpy(pchDst, pchSrc, cchMax) ;
		pchDst[cchMax-1] = '\0';
	}
#endif
}

/*========================================================================
 *	global variables
 */
extern HINSTANCE		g_hInst ;
extern LONG				g_cRefDll ;
extern CRITICAL_SECTION	g_cs ;
extern const CLSID		c_clsidSkkImeTextService ;
extern const GUID		c_guidSkkImeProfile ;
extern const GUID		c_guidConversionModeItemButton ;
extern const GUID		c_guidToolItemButton ;
extern const GUID		c_guidSkkImeDisplayAttribute ;
extern const GUID		c_guidSkkImeDisplayAttributeInput ;
extern const GUID		c_guidSkkImeDisplayAttributeTargetConverted ;
extern const GUID		c_guidSkkImePreservedKeyToggleIME ;
extern const GUID		c_guidSkkImePreservedKeyImeOn ;
extern const GUID		c_guidSkkImePreservedKeyImeOff ;

#endif	// UNITTEST
