// #if !defined (UNITTEST)
#include "globals.h"
// #else
// #include "StdAfx.h"
// #endif

#include "jstring.h"
#include "ImeBuffer.h"
#include "ImeDoc.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "TLispSession.h"
// #include "../../common/keymap.h"	// ImeBuffer.h �ƘA��
// #include "ImeConfig.h"	// ImeBuffer.h �ƘA��

class CImeBufferProperty {
private:
	int							m_nBegin ;
	int							m_nEnd ;
	DCHAR						m_bufText [MAXCOMPLEN] ;
	int							m_nTextLen ;
	CImeBufferProperty*			m_pNext ;
public:
	CImeBufferProperty () : m_nBegin (0), m_nEnd (0), m_nTextLen (0), m_pNext (NULL) {
		return ;
	}
	virtual	~CImeBufferProperty () {
		return ;
	}

	virtual	BOOL		bInitialize (int nBeginPoint, int nEndPoint, LPCDSTR pwText, int nTextLen) {
		m_nBegin	= nBeginPoint ;
		m_nEnd		= nEndPoint ;
		if (pwText != NULL && nTextLen > 0) {
			nTextLen	= MIN (MAXCOMPLEN, nTextLen) ;
			dcsncpy (m_bufText, pwText, nTextLen) ;
			m_nTextLen	= nTextLen ;
		} else {
			m_nTextLen	= 0 ;
		}
		return	TRUE ;
	}

	virtual	LPCDSTR		pGetText (int* pnLength) const {
		if (pnLength != NULL)
			*pnLength	= m_nTextLen ;
		return	m_bufText ;
	}

	virtual	int			iGetBeginPoint () const {
		return	m_nBegin ;
	}

	virtual void		vSetBeginPoint (int iPoint) {
		m_nBegin	= iPoint ;
		return ;
	}

	virtual	int			iGetEndPoint () const {
		return	m_nEnd ;
	}

	virtual	void		vSetEndPoint (int iPoint) {
		m_nEnd		= iPoint ;
		return ;
	}

	virtual void		vSetNext (CImeBufferProperty* pNext) {
		m_pNext	= pNext ;
		return ;
	}

	virtual	CImeBufferProperty*	pGetNext () {
		return	m_pNext ;
	}

	virtual	const CImeBufferProperty*	pGetNext () const {
		return	m_pNext ;
	}

private:
	CImeBufferProperty (const CImeBufferProperty& that) {
		return ;
		UNREFERENCED_PARAMETER (that) ;
	}
} ;

/*========================================================================
 *	
 */
CImeBuffer::CImeBuffer () :
	m_pDoc (NULL),
	m_pParent (NULL),
	m_nbufComp (0),
	m_nMarker (0),
	m_iteSkkRuleTree (),
//	m_pSkkCurrentRuleTree (NULL),
	m_pmkPoint (NULL),
	m_pmkSkkKanaStartPoint (NULL),
	m_pmkSkkPreviousPoint (NULL),
	m_pmkSkkHenkanStartPoint (NULL),
	m_pmkSkkHenkanEndPoint (NULL),
	m_pmkSkkOkuriganaStartPoint (NULL),
	m_bSkkModeInvoked (LFALSE),
	m_bSkkAfterPrefix (LFALSE),
	m_bSkkOkurigana (LFALSE),
	m_nSkkPrefixLen (0),
	m_iSkkHenkanCount (0),
	m_bSkkHenkanMode (LFALSE),
	m_nSkkHenkanKeyLen (0),
	m_nSkkHenkanOkuriganaLen (0),
	m_nSkkOkuriCharLen (0),
	m_iSkkOkuriIndexMin (-1),
	m_iSkkOkuriIndexMax (-1),
	m_nKakuteiMidasiLen (0),
	m_bSkkMode (LTRUE),
	m_bSkkJMode (LTRUE),
	m_bSkkLatinMode (LFALSE),
	m_bSkkJisx0208LatinMode (LFALSE),
	m_bSkkJisx0201Roman (LFALSE),
	m_bSkkJisx0201Mode (LFALSE),
	m_bSkkAbbrevMode (LFALSE),
	m_bSkkKakuteiFlag (LFALSE),
	m_bSkkHenkanInMinibuffFlag (LFALSE),
	m_bSkkExitShowCandidates (LFALSE),
	m_pSkkCurrentSearchProgSession (NULL),
	m_pSkkCompSession (NULL),
	m_plstSkkS4NumericMapping (NULL),
	m_nLineOffset (-1),
	m_iSkkCurrentKutotenType (0),
	m_bSkkHenkanShowCandidatesMode (FALSE),
	m_bSkkInputByCodeOrMenuMode (FALSE),
	m_bSkkInputByCodeOrMenu1Mode (FALSE),
	m_nLatestShiftTextLen (0),
	m_nKakuteiWordLen (0),
	m_plstProperty (NULL)
{
	return ;
}

CImeBuffer::CImeBuffer (CImeDoc* pDoc) :
	m_pDoc (pDoc),
	m_pParent (NULL),
	m_nbufComp (0),
	m_nMarker (0),
	m_iteSkkRuleTree (),
//	m_pSkkCurrentRuleTree (NULL),
	m_pmkPoint (NULL),
	m_pmkSkkKanaStartPoint (NULL),
	m_pmkSkkPreviousPoint (NULL),
	m_pmkSkkHenkanStartPoint (NULL),
	m_pmkSkkHenkanEndPoint (NULL),
	m_pmkSkkOkuriganaStartPoint (NULL),
	m_bSkkModeInvoked (LFALSE),
	m_bSkkAfterPrefix (LFALSE),
	m_bSkkOkurigana (LFALSE),
	m_iSkkHenkanCount (0),
	m_bSkkHenkanMode (LFALSE),
	m_nSkkHenkanKeyLen (0),
	m_nSkkHenkanOkuriganaLen (0),
	m_nSkkOkuriCharLen (0),
	m_iSkkOkuriIndexMin (-1),
	m_iSkkOkuriIndexMax (-1),
	m_nKakuteiMidasiLen (0),
	m_bSkkMode (LTRUE),
	m_bSkkJMode (LTRUE),
	m_bSkkLatinMode (LFALSE),
	m_bSkkJisx0208LatinMode (LFALSE),
	m_bSkkAbbrevMode (LFALSE),
	m_bSkkJisx0201Mode (LFALSE),
	m_bSkkJisx0201Roman (LFALSE),
	m_bSkkKakuteiFlag (LFALSE),
	m_bSkkHenkanInMinibuffFlag (LFALSE),
	m_bSkkExitShowCandidates (LFALSE),
	m_pSkkCurrentSearchProgSession (NULL),
	m_pSkkCompSession (NULL),
	m_plstSkkS4NumericMapping (NULL),
	m_nLineOffset (-1),
	m_iSkkCurrentKutotenType (0),
	m_bSkkHenkanShowCandidatesMode (FALSE),
	m_bSkkInputByCodeOrMenuMode (FALSE),
	m_bSkkInputByCodeOrMenu1Mode (FALSE),
	m_nLatestShiftTextLen (0),
	m_nSkkPrefixLen (0),
	m_nKakuteiWordLen (0),
	m_plstProperty (NULL)
{
	return ;
}

CImeBuffer::~CImeBuffer ()
{
	vUninit () ;
	return ;
}

BOOL
CImeBuffer::bInit (
	LPCDSTR					wstrMessage,
	int						nstrMessage,
	BOOL					bSkkModeOn)
{
	/* cursor marker �̊T�O�͂ǂ��Ȃ����̂��낤�H skk-previous-point �́c�H */
	static BOOL		rfMarkerCursor [MAX_RESERVED_MARKERS]	= {
//		TRUE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, FALSE,
		TRUE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,	/* skk-henkan-end-point �� marker-insertion-type ����cursor���H*/
	} ;
	register int	i ;

	for (i = 0 ; i < MYARRAYSIZE (m_rpmkMarker) ; i ++) 
		m_rpmkMarker [i]	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (rfMarkerCursor) ; i ++) 
		m_rpmkMarker [i]	= pMakeMarker (rfMarkerCursor [i]) ;
	m_nMarker	= MAX_RESERVED_MARKERS ;

	/*	�K�{�}�[�J�ł���|�C���g(�J�[�\��)���쐬����B*/
	m_pmkPoint						= m_rMarker + MARKER_POINT ;
	m_pmkSkkKanaStartPoint			= NULL ;
	m_pmkSkkPreviousPoint			= NULL ;
	m_pmkSkkHenkanStartPoint		= NULL ;
	m_pmkSkkHenkanEndPoint			= NULL ;
	m_pmkSkkOkuriganaStartPoint		= NULL ;
	m_bSkkHenkanMode				= LFALSE ;
	m_bSkkHenkanInMinibuffFlag		= LFALSE ;
	m_bSkkAfterPrefix				= LFALSE ;
	m_bSkkAbbrevMode				= LFALSE ;
	m_bSkkKatakana					= LFALSE ;
	m_bSkkOkurigana					= LFALSE ;
	m_iSkkHenkanCount				= 0 ;
	m_bSkkAfterPrefix				= LFALSE ;
	m_nSkkPrefixLen					= 0 ;
	m_iteSkkRuleTree.vReset () ;
//	m_pSkkCurrentRuleTree			= NULL ;

	/*	UpdateCompose �̂��ƁATermicateComposition -> OnClearSession ���� CImeDoc::vClear �o�R��
	 *	CImeBuffer::bClear ���Ăяo����A�����ɗ���B���A���̒l���N���A�����ƍ���B
	 *	m_nLatestShiftTextLen			= 0 ;
	 */
	m_bSkkHenkanShowCandidatesMode	= FALSE ;
	m_bSkkInputByCodeOrMenuMode		= FALSE ;
	m_bSkkInputByCodeOrMenu1Mode	= FALSE ;
	m_nKakuteiMidasiLen				= 0 ;
	m_nKakuteiWordLen				= 0 ;


	m_bSkkMode						= LTRUE ;
	m_bSkkJMode						= bSkkModeOn? LTRUE : LFALSE ;
	m_bSkkLatinMode					= LFALSE ;
	m_bSkkJisx0208LatinMode			= LFALSE ;
	m_bSkkJisx0201Mode				= LFALSE ;
	m_bSkkJisx0201Roman				= LFALSE ;

	_vClearProperty () ;

	if (nstrMessage > 0) {
		iInsert (m_rpmkMarker [MARKER_POINT], wstrMessage, nstrMessage) ;
		m_rpmkMarker [MARKER_BUFFERTOP]->bSetPosition (m_rpmkMarker [MARKER_POINT]) ;
	}
	return	TRUE ;
}

void
CImeBuffer::vUninit ()
{
	int		i ;

	m_nbufComp	= 0 ;
	for (i = 0 ; i < MYARRAYSIZE (m_rpmkMarker) ; i ++) {
		m_rpmkMarker [i]	= NULL ;
	}
	m_nMarker	= 0 ;
	if (m_pSkkCurrentSearchProgSession != NULL) {
		delete	m_pSkkCurrentSearchProgSession ;
		m_pSkkCurrentSearchProgSession	= NULL ;
	}
	if (m_pSkkCompSession != NULL) {
		delete	m_pSkkCompSession ;
		m_pSkkCompSession	= NULL ;
	}
	if (m_plstSkkS4NumericMapping != NULL) {
		CTS4Mapping::vClearList (m_plstSkkS4NumericMapping) ;
		m_plstSkkS4NumericMapping	= NULL ;
	}
	_vClearProperty () ;
	return ;
}

/*	������Ԃɖ߂��B*/
BOOL
CImeBuffer::bClear (BOOL bFullClear)
{
	BOOL	bSkkMode				= m_bSkkMode ;
	BOOL	bLatinMode				= m_bSkkLatinMode ;
	BOOL	bSkkJisx0208LatinMode	= m_bSkkJisx0208LatinMode ;
	BOOL	bSkkJisx0201Mode		= m_bSkkJisx0201Mode ;
	BOOL	bSkkJisx0201Roman		= m_bSkkJisx0201Roman ;
	BOOL	bRetval ;

	vUninit () ;
	bRetval	= bInit (NULL, 0, m_bSkkMode && m_bSkkJMode) ;

	m_bSkkMode						= bSkkMode ;
	m_bSkkLatinMode					= bLatinMode ;
	m_bSkkJisx0208LatinMode			= bSkkJisx0208LatinMode ;
	m_bSkkJisx0201Mode				= bSkkJisx0201Mode ;
	m_bSkkJisx0201Roman				= bSkkJisx0201Roman ;

	if (bFullClear) {
		m_nLatestShiftTextLen		= 0 ;
		if (m_bSkkJisx0201Mode) {
			m_iteSkkRuleTree.vMoveTree (m_bSkkJisx0201Roman? CImeConfig::RULETREENO_SKK_JISX0201_ROMAN : CImeConfig::RULETREENO_SKK_JISX0201_BASE) ;
		} else {
			m_iteSkkRuleTree.vMoveTree (CImeConfig::RULETREENO_SKK_BASE) ;	// default rule �ɖ߂��B
		}
	}
	return	bRetval ;
}

void
CImeBuffer::vSetParent (
	CImeBuffer*			pParentBuffer)
{
	m_pParent	= pParentBuffer ;
	return ;
}

CImeBuffer*
CImeBuffer::pGetParent ()
{
	return	m_pParent ;
}

LPCDSTR
CImeBuffer::pBufferRawString (
	int*						pnLength) const
{
	if (pnLength != NULL)
		*pnLength	= m_nbufComp ;
	return	m_bufComp ;
}

LPCDSTR
CImeBuffer::pBufferString (
	int*						pnLength) const
{
	CTMarker*	pmkTop ;
	CTMarker*	pmkEnd ;
	int		nTop, nEnd ;

	pmkTop	= m_rpmkMarker [MARKER_BUFFERTOP] ;
	pmkEnd	= m_rpmkMarker [MARKER_BUFFEREND] ;
	if (pmkTop != NULL && pmkTop->bIsValidp ()) {
		nTop	= MAX (pmkTop->iGetPosition (), 0) ;
	} else {
		nTop	= 0 ;
	}
	if (pmkEnd != NULL && pmkEnd->bIsValidp ()) {
		nEnd	= MIN (pmkEnd->iGetPosition (), m_nbufComp) ;
	} else {
		nEnd	= m_nbufComp ;
	}
	if (pnLength != NULL)
		*pnLength	= nEnd - nTop ;
	return	m_bufComp + nTop ;
}

int
CImeBuffer::iGetConversionMode	()
{
	if (! bJModep ()) {
		if (m_bSkkJisx0201Mode)
			return	m_bSkkJisx0201Roman? IMECMODE_HANKANA_ROMAN : IMECMODE_HANKANA ;
		return	bJisx0208LatinModep ()? IMECMODE_ZENKAKU : IMECMODE_ASCII ;
	} else {
		return	m_bSkkKatakana? IMECMODE_KATAKANA : IMECMODE_HIRAGANA ;
	}
}

BOOL
CImeBuffer::bSetConversionMode	(
	int							nMode)
{
	switch (nMode) {
	case	IMECMODE_ASCII:
		return	bSkkLatinModeOn () ;

	case	IMECMODE_ZENKAKU:
		return	bSkkJisx0208LatinModeOn () ;

	case	IMECMODE_HIRAGANA:
		return	bSkkJModeOn (LFALSE) ;

	case	IMECMODE_KATAKANA:
		return	bSkkJModeOn (LTRUE) ;

	case	IMECMODE_HANKANA_ROMAN:
		return	bSkkJisx0201ModeOn (LTRUE) ;

	case	IMECMODE_HANKANA:
		return	bSkkJisx0201ModeOn (LFALSE) ;

	default:
		return	FALSE ;
	}
}

BOOL
CImeBuffer::bSetConversionString (
	LPCDSTR						pwText,
	int							nTextLen,
	BOOL						bConv)
{
	CTMarker*	pmkBufferTop	= NULL ;
	BOOL		bAbbrev			= TRUE ;

	/*	�{���͂����Ə�Ԃ𐧌����Ȃ��Ƃ����Ȃ��̂����B��芸�����ݒ肷��ɂӂ��킵���Ȃ��󋵂���
	 *	�p���Bdocument �� clear ���Ă���ĂԂ��ƁB
	 */
	if (m_bSkkHenkanShowCandidatesMode	|| 
		m_bSkkHenkanMode				||
		m_bSkkInputByCodeOrMenuMode		||
		m_nSkkPrefixLen > 0)
		return	FALSE ;

	/*
	 */
	if (bConv) {
		LPCDSTR	pwptr, pwEnd ;

		pwptr	= pwText ;
		pwEnd	= pwText + nTextLen ;
		while (pwptr < pwEnd) {
			if (! isdalnum (*pwptr)) {
				bAbbrev	= FALSE ;
				break ;
			}
			pwptr	++ ;
		}
	}
	if (! bGetMarker (MARKER_BUFFERTOP, &pmkBufferTop) || pmkBufferTop == NULL)
		return	FALSE ;
	m_pmkPoint->bSetPosition (pmkBufferTop) ;
	(void) iInsert (m_pmkPoint, pwText, nTextLen) ;
	if (bConv) {
		iInsert (pmkBufferTop, L"��", 1) ;
		if (! bSetMarker (&m_pmkSkkHenkanStartPoint, MARKER_SKK_HENKAN_START_POINT, pmkBufferTop) ||
			! m_pmkSkkHenkanStartPoint->bForward (1))
			return	FALSE ;
		/*	LACTIVE �͊ԈႢ�DLON ���������D(����20�N4��25��(��))
		 */
		m_bSkkHenkanMode	= LON ;
		m_bSkkAbbrevMode	= bAbbrev ;
	} 
	m_nLatestShiftTextLen	= 0 ;
	return	TRUE ;
}

BOOL
CImeBuffer::bSetReconvertText (
	LPCDSTR		wstrTEXT,
	int			nstrTEXT)
{
	if (nstrTEXT > 0 && wstrTEXT == NULL)
		return	FALSE ;

	(void) bClear () ;
	(void) bSkkKakuteiInitialize (NULL, 0) ;
	m_nLatestShiftTextLen	= 0 ;

	if (nstrTEXT > 0) {
		if (CImeConfig::bSkkCompositionAutoShiftp (m_pDoc->pGetConfig ())) {
			BOOL	bAbbrev ;
			int		i ;

			/* wstrTEXT ���A���t�@�x�b�g�݂̂�����ȊO���œ��삪�Ⴄ�B*/
			bAbbrev	= TRUE ;
			for (i = 0 ; i < nstrTEXT ; i ++) {
				if (! (0x20 <= wstrTEXT [i] && wstrTEXT [i] < 0x7F)) {
					bAbbrev	= FALSE ;
					break ;
				}
			}
			bInsertAndInherit (L"��", 1) ;
			vSkkSetSkkHenkanMode (LON) ;
			vSkkClearSkkHenkanEndPoint () ;
			bSkkSetSkkHenkanStartPointToPoint () ;
			if (bAbbrev)
				bSkkAbbrevModeOn () ;
		}
		bInsertAndInherit (wstrTEXT, nstrTEXT) ;
		(void) bSkkSetSkkPreviousPointToPoint () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::bQueryUpdateContext (
	int*						pnShift,
	int*						pnCursor,
	BOOL*						pfContinue)
{
	int	nCursor, nShift ;

	nCursor	= m_pmkPoint->iGetPosition () ;
	nShift	= _iGetShiftCount () ;
	if (! bJModep () && ! bAbbrevModep () && (! bJisx0201Modep () || bJisx0201Romanp ())) {
		/*	�������[�h�łȂ��ꍇ�B�V�t�g����̂̓J�[�\���ʒu�܂ŁB*/
		*pnShift	= nShift ;
		*pnCursor	= 0 ;	/* �V�t�g��̃J�[�\���ʒu�B*/
		*pfContinue	= m_bSkkInputByCodeOrMenuMode ||
			m_bSkkHenkanShowCandidatesMode ||
			m_pDoc->bIsStatusActivep () ||
			(nShift < m_nbufComp) ;
	} else {
		*pnShift	= nShift ;
		*pnCursor	= nCursor - nShift ;

		/*	modified Fri Sep 02 11:17:12 2005
		 *		PSO ... �̃R�����g�̈Ӗ���Y��Ă���c�BGUIDE Window ������� CANCEL ��
		 *		�A�ł��铮��ɂ��Ă��낤���H
#if 0
#if 0
		// PSO
		*pfContinue	= _fJHenkanOn || (nShift < _nbufComp) || ImeBuffer_IsJInputByCodeOrMenuModep (pBuffer) || (_nbufJPrefix > 0) ;
#else
		*pfContinue	= _fJHenkanOn || (nShift < _nbufComp) || ImeBuffer_IsJInputByCodeOrMenuModep (pBuffer) ;
#endif
#endif
		 */
		*pfContinue	= m_bSkkInputByCodeOrMenuMode ||
			m_bSkkHenkanShowCandidatesMode ||
			m_pDoc->bIsStatusActivep () ||
			m_bSkkHenkanMode || (nShift < m_nbufComp) ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::bUpdateContext ()
{
	int		nShift, nCursor ;
	BOOL	fContinue ;

	if (! bQueryUpdateContext (&nShift, &nCursor, &fContinue))
		return	FALSE ;

	/*	�V�t�g�������� latest-shift �ɒ@�����ށB
	 *	0 shift �͉������Ȃ��c�ŗǂ��Ǝv���B�����A�}�E�X�ɂ��ړ��Ƃ��J�[�\���ɂ��ړ���
	 *	���O�̃V�t�g�̏�Ԃ��ω�����\�����c�B������ǂ��������͓�B���܂� depend �ł���
	 *	���B
	 */
	if (nShift > 0) {
		dcsncpy (m_bufLatestShiftText, m_bufComp, nShift) ;
		m_nLatestShiftTextLen	= nShift ;
	}
	bDeleteRegion (0, nShift) ;
	return	TRUE ;
}

BOOL
CImeBuffer::bGetSelectedRegion (
	int*					pnStart,
	int*					pnEnd)
{
	CTMarker*	pmkMark ;
	int		nPoint, nMark, nCmd ;

	if (! bGetMarker (CImeBuffer::MARKER_MARK, &pmkMark) || pmkMark == NULL)
		return	FALSE ;

	nCmd	= m_pDoc->iGetLastCommand () ;
	if (nCmd != NFUNC_MOUSE_DRAG_REGION && nCmd != NFUNC_MOUSE_DRAG_REGION_END)
		return	FALSE ;

	nPoint	= m_pmkPoint->iGetPosition () ;
	nMark	= pmkMark->iGetPosition () ;
	if (pnStart != NULL)
		*pnStart	= (nPoint < nMark)? nPoint : nMark ;
	if (pnEnd != NULL)
		*pnEnd		= (nPoint < nMark)? nMark  : nPoint ;
	return	TRUE ;
}

BOOL
CImeBuffer::bGetConvertedRegion (
	int*				pnStart,
	int*				pnEnd)
{
	if (! m_bSkkHenkanMode)
		return	FALSE ;
	if (m_pmkSkkHenkanStartPoint == NULL ||
		m_pmkSkkHenkanEndPoint   == NULL)
		return	FALSE ;
	if (pnStart != NULL)
		*pnStart	= m_pmkSkkHenkanStartPoint->iGetPosition () ;
	if (pnEnd != NULL)
		*pnEnd		= m_pmkSkkHenkanEndPoint->iGetPosition () ;
	return	TRUE ;
}

BOOL
CImeBuffer::bGetMarker (
	int				nMarker,
	CTMarker**		ppMarker)
{
	if (nMarker < 0 || nMarker >= MAXBUFMARKER)
		return	FALSE ;
	if (m_rpmkMarker [nMarker] == NULL || ! m_rpmkMarker [nMarker]->bIsValidp ())
		return	FALSE ;
	if (ppMarker != NULL)
		*ppMarker	= m_rpmkMarker [nMarker] ;
	return	TRUE ;
}

BOOL
CImeBuffer::bSetMarker (
	CTMarker**			ppMarker,
	int					nMarkerIndex,
	const CTMarker*		pSource)
{
	if (ppMarker == NULL || pSource == NULL)
		return	FALSE ;
	if (! (0 <= nMarkerIndex && nMarkerIndex < MAXBUFMARKER))
		return	FALSE ;

	if (*ppMarker == NULL) 
		*ppMarker	= &m_rMarker [nMarkerIndex] ;
	return	(*ppMarker)->bSetPosition (pSource) ;
}

BOOL
CImeBuffer::bForwardChar (
	int					nCount)
{
	CTMarker*	pmkBufferEnd ;
	CTMarker*	pmkPoint ;
	int			nBufferEnd, nPosition, n ;

	if (nCount < 0)
		return	FALSE ;
	pmkBufferEnd	= m_rpmkMarker [MARKER_BUFFEREND] ;
	if (pmkBufferEnd != NULL && pmkBufferEnd->bIsValidp ()) {
		nBufferEnd	= pmkBufferEnd->iGetPosition () ;
	} else {
		nBufferEnd	= m_nbufComp ;
	}
	pmkPoint	= m_pmkPoint ;
	if (pmkPoint == NULL || ! pmkPoint->bIsValidp ())
		return	FALSE ;
	nPosition	= pmkPoint->iGetPosition () ;
	n			= MIN (nBufferEnd - nPosition, nCount) ;
	if (! pmkPoint->bForward (n))
		return	FALSE ;
	/* buffer-top �ɂЂ�������ƑʖځB*/
	if (n != nCount)
		return	FALSE ;
	return	TRUE ;
}

BOOL
CImeBuffer::bBackwardChar (
	int						nCount)
{
	CTMarker*	pmkBufferTop ;
	CTMarker*	pmkPoint ;
	int			nBufferTop, nPosition, n ;

	if (nCount < 0)
		return	FALSE ;
	pmkBufferTop	= m_rpmkMarker [MARKER_BUFFERTOP] ;
	if (pmkBufferTop != NULL && pmkBufferTop->bIsValidp ()) {
		nBufferTop	= pmkBufferTop->iGetPosition () ;
	} else {
		nBufferTop	= 0 ;
	}
	pmkPoint	= m_pmkPoint ;
	if (pmkPoint == NULL || ! pmkPoint->bIsValidp ())
		return	FALSE ;
	nPosition	= pmkPoint->iGetPosition () ;
	n			= MIN (nPosition - nBufferTop, nCount) ;
	if (! pmkPoint->bBackward (n))
		return	FALSE ;
	/* buffer-top �ɂЂ�������ƑʖځB*/
	if (n != nCount)
		return	FALSE ;
	return	TRUE ;
}

BOOL
CImeBuffer::bFollowingStringEqualp (
	LPCDSTR						pwString,
	int							nStringLen)
{
	CTMarker*	pmkBufferEnd ;
	CTMarker*	pmkPoint ;
	int				nBufferEnd, nPosition ;

	if (pwString == NULL || nStringLen <= 0) 
		return	TRUE ;

	pmkBufferEnd	= m_rpmkMarker [MARKER_BUFFEREND] ;
	if (pmkBufferEnd != NULL && pmkBufferEnd->bIsValidp ()) {
		nBufferEnd	= pmkBufferEnd->iGetPosition () ;
	} else {
		nBufferEnd	= m_nbufComp ;
	}
	pmkPoint	= m_pmkPoint ;
	if (pmkPoint == NULL || ! pmkPoint->bIsValidp ())
		return	FALSE ;
	nPosition	= pmkPoint->iGetPosition () ;
	if ((nPosition + nStringLen) > nBufferEnd)
		return	FALSE ;
	if (! dcsncmp (m_bufComp + nPosition, pwString, nStringLen))
		return	TRUE ;
	return	FALSE ;
}

int
CImeBuffer::iInsert (
	CTMarker*			pMarker,
	LPCDSTR				pdString,
	int					nStringLen)
{
	if (pMarker == NULL || pdString == NULL || nStringLen <= 0)
		return	0 ;

	return	iInsertByPosition (pMarker->iGetPosition (), pdString, nStringLen) ;
}

int
CImeBuffer::iInsert (
	CTMarker*			pMarker,
	LPCWSTR				pwString,
	int					nStringLen)
{
	DCHAR	buf [32] ;
	DCHAR*	pDest ;
	DCHAR*	pDestEnd ;
	LPCWSTR	ptr ;
	LPCWSTR	ptrEnd ;
	int		iPosition, nInsert ;

	if (pMarker == NULL || pwString == NULL || nStringLen <= 0)
		return	0 ;

	nInsert		= 0 ;
	iPosition	= pMarker->iGetPosition () ;
	pDest		= buf ;
	pDestEnd	= buf + MYARRAYSIZE (buf) ;
	ptr			= pwString ;
	ptrEnd		= pwString + nStringLen ;
	while (ptr < ptrEnd) {
		if (ptr < ptrEnd && IS_SURROGATE_PAIR (*ptr, *(ptr+1))) {
			*pDest ++	= MAKE_DCHAR_FROM_SURROGATE_PAIR (*ptr, *(ptr+1)) ;
			ptr	+= 2 ;
		} else {
			*pDest ++	= MAKE_DCHAR(0, *ptr) ;
			ptr	++ ;
		}
		if (pDest >= pDestEnd) {
			int	n	= iInsertByPosition (iPosition, buf, pDest - buf) ;
			iPosition	+= n ;
			nInsert		+= n ;
		}
	}
	if (pDest > buf) {
		int	n	= iInsertByPosition (iPosition, buf, pDest - buf) ;
		nInsert	+= n ;
	}
	return	nInsert ;
}

int
CImeBuffer::iInsertByPosition (
	int						nPosition, 
	LPCDSTR					pwString,
	int						nStringLen)
{
	int		i ;

	if (nPosition < 0 || nPosition >= MAXCOMPLEN || nStringLen <= 0)
		return	0 ;
	if ((m_nbufComp + nStringLen) > MAXCOMPLEN)
		nStringLen	= MAXCOMPLEN - m_nbufComp ;
	if ((nPosition + nStringLen) > MAXCOMPLEN) 
		nStringLen	= MAXCOMPLEN - nPosition ;
	if (nStringLen <= 0)
		return	0 ;
	if ((nPosition + nStringLen) < MAXCOMPLEN && nPosition < m_nbufComp) 
		memmove (m_bufComp + nPosition + nStringLen, m_bufComp + nPosition, sizeof (DCHAR) * (m_nbufComp - nPosition)) ;
	memmove (m_bufComp + nPosition, pwString, sizeof (DCHAR) * nStringLen) ;

	/*	�}�[�J�̈ړ��B
	 */
	m_nbufComp	+= nStringLen ;
	for (i = 0 ; i < m_nMarker ; i ++) {
		if ((nPosition < m_rMarker [i].iGetPosition () ||
			 (nPosition == m_rMarker [i].iGetPosition () && m_rMarker [i].bIsCursor ())) &&
			m_rMarker [i].iGetPosition () < m_nbufComp)
			m_rMarker [i].bForward (nStringLen) ;
	}

	/*	�v���p�e�B���̃}�[�J�̈ړ��B
	 *
	 *	��J�[�\���}�[�J�Ƃ���B
	 */
	{
		CImeBufferProperty*	pNode	= m_plstProperty ;

		while (pNode != NULL) {
			if (nPosition < pNode->iGetBeginPoint () && pNode->iGetBeginPoint () < m_nbufComp) 
				pNode->vSetBeginPoint (pNode->iGetBeginPoint () + nStringLen) ;
			if (nPosition < pNode->iGetEndPoint ()   && pNode->iGetEndPoint ()   < m_nbufComp) 
				pNode->vSetEndPoint (pNode->iGetEndPoint () + nStringLen) ;
			pNode	= pNode->pGetNext () ;
		}
	}
	return	nStringLen ;
}

int
CImeBuffer::iInsertBeforeMarkers (
	CTMarker*			pMarker,
	LPCDSTR				pwString,
	int					nStringLen)
{
	if (pMarker == NULL || pwString == NULL || nStringLen <= 0)
		return	0 ;

	return	iInsertBeforeMarkersByPosition (pMarker->iGetPosition (), pwString, nStringLen) ;
}

int
CImeBuffer::iInsertBeforeMarkersByPosition (
	int						nPosition, 
	LPCDSTR					pwString,
	int						nStringLen)
{
	int		i ;

	if (nPosition < 0 || nPosition >= MAXCOMPLEN || nStringLen <= 0)
		return	0 ;
	if ((m_nbufComp + nStringLen) > MAXCOMPLEN)
		nStringLen	= MAXCOMPLEN - m_nbufComp ;
	if ((nPosition + nStringLen) > MAXCOMPLEN) 
		nStringLen	= MAXCOMPLEN - nPosition ;
	if (nStringLen <= 0)
		return	0 ;
	if ((nPosition + nStringLen) < MAXCOMPLEN && nPosition < m_nbufComp) 
		memmove (m_bufComp + nPosition + nStringLen, m_bufComp + nPosition, sizeof (DCHAR) * (m_nbufComp - nPosition)) ;
	memmove (m_bufComp + nPosition, pwString, sizeof (DCHAR) * nStringLen) ;

	/*	�}�[�J�̈ړ��B
	 */
	m_nbufComp	+= nStringLen ;
	for (i = 0 ; i < m_nMarker ; i ++) {
		/*	�S�ăJ�[�\���}�[�J�����ɂȂ�B
		 */
		if (nPosition <= m_rMarker [i].iGetPosition () && m_rMarker [i].iGetPosition () < m_nbufComp)
			m_rMarker [i].bForward (nStringLen) ;
	}

	/*	�v���p�e�B���̃}�[�J�̈ړ��B
	 *
	 *	��������J�[�\���}�[�J�Ƃ��Ĉ����ėǂ��̂��낤���H
	 *	(�v���p�e�B���̃}�[�J�͑S�Ĕ�J�[�\���}�[�J�̈���)
	 */
	{
		CImeBufferProperty*	pNode	= m_plstProperty ;

		while (pNode != NULL) {
			if (nPosition <= pNode->iGetBeginPoint () && pNode->iGetBeginPoint () < m_nbufComp) 
				pNode->vSetBeginPoint (pNode->iGetBeginPoint () + nStringLen) ;
			if (nPosition <= pNode->iGetEndPoint ()   && pNode->iGetEndPoint ()   < m_nbufComp) 
				pNode->vSetEndPoint (pNode->iGetEndPoint () + nStringLen) ;
			pNode	= pNode->pGetNext () ;
		}
	}
	return	nStringLen ;
}

int
CImeBuffer::iOverwriteByPosition (
	int						nPosition, 
	LPCDSTR					pwString,
	int						nStringLen)
{
	if (nPosition < 0 || nPosition >= MAXCOMPLEN)
		return	0 ;
	if ((nPosition + nStringLen) > MAXCOMPLEN) {
		nStringLen	= MAXCOMPLEN - nPosition ;
	}
	if ((nPosition + nStringLen) > m_nbufComp) {
		nStringLen	= m_nbufComp - nPosition ;
	}
	if (nStringLen <= 0)
		return	0 ;

	/*	�u�������邾���Ȃ̂ŁA�}�[�J�̈ړ����v���p�e�B�̕ω����Ȃ��B
	 */
	memcpy (m_bufComp + nPosition, pwString, sizeof (DCHAR) * nStringLen) ;
	return	nStringLen ;
}

BOOL
CImeBuffer::bInsertAndInherit (
	LPCDSTR					pdString,
	int						nString)
{
	return	iInsert (m_pmkPoint, pdString, nString) == nString ;
}

BOOL
CImeBuffer::bInsertAndInherit (
	LPCWSTR					pwString,
	int						nString)
{
	return	iInsert (m_pmkPoint, pwString, nString) == nString ;
}

BOOL
CImeBuffer::bInsertBeforeMarkers (
	LPCDSTR					pwString,
	int						nString)
{
	return	iInsertBeforeMarkers (m_pmkPoint, pwString, nString) == nString ;
}

BOOL
CImeBuffer::bDeleteBackwardChar (
	int						nChar) 
{
	int		nPosition ;

	if (nChar <= 0 || m_pmkPoint == NULL)
		return	FALSE ;

	nPosition	= m_pmkPoint->iGetPosition () - nChar ;
	if (nPosition < 0 || (nPosition + nChar) > m_nbufComp) 
		return	FALSE ;
	return	bDeleteRegion (nPosition, nPosition + nChar) ;
}

BOOL
CImeBuffer::bDeleteRegion (
	int							nStartPoint,
	int							nEndPoint)
{
	int	nMove, i ;

	if (nStartPoint > nEndPoint) {
		int	nTmp ;
		nTmp		= nStartPoint ;
		nStartPoint	= nEndPoint ;
		nEndPoint	= nTmp ;
	}

	nMove	= nEndPoint - nStartPoint ;
	if (nMove == 0)
		return	TRUE ;

	/*	�s���ȗ̈�̍폜�͎̂Ă�B
	 */
	if (nStartPoint < 0 || nEndPoint > MAXCOMPLEN)
		return	FALSE ;

	if (m_nbufComp > nEndPoint) 
		memmove (m_bufComp + nStartPoint, m_bufComp + nEndPoint, sizeof (DCHAR) * (m_nbufComp - nEndPoint)) ;
	m_nbufComp	-= (nEndPoint - nStartPoint) ;

	/*	�����Ń}�[�J�̈ړ�������B
	 */
	for (i = 0 ; i < m_nMarker ; i ++) {
		if (nStartPoint < m_rMarker [i].iGetPosition ()) {
			if (m_rMarker [i].iGetPosition () < nEndPoint) {
				m_rMarker [i].bBackward (m_rMarker [i].iGetPosition () - nStartPoint) ;
			} else {
				m_rMarker [i].bBackward (nMove) ;
			}
		}
	}

	/*	property ���̃}�[�J�̈ړ��B
	 */
	{
		CImeBufferProperty*	pNode	= m_plstProperty ;

		while (pNode != NULL) {
			if (nStartPoint < pNode->iGetBeginPoint ()) {
				if (pNode->iGetBeginPoint () < nEndPoint) {
					pNode->vSetBeginPoint (nStartPoint) ;
				} else {
					pNode->vSetBeginPoint (pNode->iGetBeginPoint () - nMove) ;
				}
			}
			if (nStartPoint < pNode->iGetEndPoint ()) {
				if (pNode->iGetEndPoint () < nEndPoint) {
					pNode->vSetEndPoint (nStartPoint) ;
				} else {
					pNode->vSetEndPoint (pNode->iGetEndPoint () - nMove) ;
				}
			}
			pNode	= pNode->pGetNext () ;
		}
	}
	/* region �폜�ɑΉ����� property �� update ��������B�����̑}���� update �������邱�Ƃ͂Ȃ��B*/
	_vUpdateProperty () ;
	return	TRUE ;
}

CTMarker*
CImeBuffer::pMakeMarker (
	BOOL					fCursor)
{
	CTMarker*	pMarker ;
	int			nMarker ;

	/*	�\�񂳂�Ă���}�[�J�̎����猟�����J�n����B
	 */
	pMarker	= m_rMarker ;
	nMarker	= m_nMarker ;
	while (nMarker -- > 0) {
		if (! pMarker->bIsValidp ()) 
			break ;
		pMarker	++ ;
	}

	/*	���݂̃}�[�J�̒��ɋ�(���ԂƂ������H)���Ȃ�
	 *	�̂ŐV�����m�ہB
	 */
	if (nMarker <= 0) {
		if (m_nMarker >= MAXBUFMARKER) 
			return	FALSE ;
		pMarker	= m_rMarker + m_nMarker ;
		m_nMarker	++ ;
	}
	pMarker->bInit (fCursor) ;
	return	pMarker ;
}

BOOL
CImeBuffer::bDeleteMarker (
	CTMarker*			pMarker)
{
	CTMarker*		pmkLast ;

	if (pMarker == NULL)
		return	FALSE ;
	if (! (m_rMarker <= pMarker && pMarker < (m_rMarker + MAXBUFMARKER)))
		return	FALSE ;

	pmkLast	= m_rMarker + m_nMarker ;
	if (pmkLast == pMarker) 
		m_nMarker	-- ;
	pMarker->vInvalidate () ;
	return	TRUE ;
}

BOOL
CImeBuffer::bJModep () const
{
	return	m_bSkkJMode ;
}

BOOL
CImeBuffer::bLatinModep () const
{ 
	return	m_bSkkLatinMode ;
}

BOOL
CImeBuffer::bJisx0208LatinModep () const
{ 
	return	m_bSkkJisx0208LatinMode ;
}

BOOL
CImeBuffer::bAbbrevModep () const
{
	return	m_bSkkAbbrevMode ;
}

BOOL
CImeBuffer::bKatakanaModep () const
{
	return	m_bSkkKatakana ;
}

BOOL
CImeBuffer::bJisx0201Modep () const
{
	return	m_bSkkJisx0201Mode ;
}

BOOL
CImeBuffer::bJisx0201Romanp () const
{
	return	m_bSkkJisx0201Roman ;
}

BOOL
CImeBuffer::bShowHenkanCandidatesModep () const
{
	return	m_bSkkHenkanShowCandidatesMode ;
}

BOOL
CImeBuffer::bInputByCodeOrMenuModep () const
{
	return	m_bSkkInputByCodeOrMenuMode ;
}

BOOL
CImeBuffer::bInputByCodeOrMenu1Modep () const
{
	return	m_bSkkInputByCodeOrMenuMode && m_bSkkInputByCodeOrMenu1Mode ;
}

BOOL
CImeBuffer::bHavePrefixp () const
{
	/*	skk-current-rule-tree �� non-nil �ł���΁Askk-pre-command �͉��炩�̏���������K�v
	 *	������Ƃ������ƂŁAhave-prefix-p �� t ��Ԃ����Ƃɂ���B
	 *
	 *	have-prefix-p => event �� process ���邩�ۂ��ɉe���B
	 */
	return	m_iteSkkRuleTree.bHavePrefixp () ;
//	return	(m_pSkkCurrentRuleTree != NULL)? TRUE : FALSE ;
}

int
CImeBuffer::iGetLineOffset () const
{
	return	m_nLineOffset ;
}

void
CImeBuffer::vSetLineOffset (
	int							nOffset)
{
	m_nLineOffset	= nOffset ;
	return ;
}

BOOL
CImeBuffer::bSetReadingProperty (
	const CTMarker*			pmkRegionBegin,
	const CTMarker*			pmkRegionEnd,
	LPCDSTR					strReadingText,
	int						nReadingTextLen)
{
	CImeBufferProperty*	pProperty ;

	if (pmkRegionBegin == NULL || pmkRegionEnd == NULL)
		return	FALSE ;

	/*	�̈�`�F�b�N�B
	 */
	if (pmkRegionBegin->iGetPosition () >= pmkRegionEnd->iGetPosition ())
		return	FALSE ;

	/*	property �� (begin-point, end-point, property) ��3�g�Ƃ���B
	 */

	/*	���̓}�[�J�̐��c�B�ǂ̒��x�̐� property ���ݒ肳���̂��Ɉˑ����邪�c�B
	 */
	pProperty		= new CImeBufferProperty () ;
	if (pProperty == NULL) 
		return	FALSE ;
	if (! pProperty->bInitialize (pmkRegionBegin->iGetPosition (), pmkRegionEnd->iGetPosition (), strReadingText, nReadingTextLen)) {
		delete	pProperty ;
		return	FALSE ;
	}

	/*	�o�b�t�@�ɓo�^����B
	 */
	if (! _bRegisterProperty (pProperty)) {
		delete	pProperty ;
		return	FALSE ;
	}
//	pProperty->m_pNext		= pBuffer->m_plstProperty ;
//	pBuffer->m_plstProperty	= pProperty ;
	return	TRUE ;
}

/*	shift �ʂ������ɂƂ�Ȃ��ƍ��邩�c�B
 */
int
CImeBuffer::iGetReadingText (
	LPDSTR					pDestBuffer,
	int						nDestSize,
	int						nCompPosition,		/* Composition �̒��ł̈ʒu [in] */
	int*					pnReadingPosition)	/* �ǂ݉����̒��ł̈ʒu [out] */
{
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pSrc,  pSrcEnd, pSrcBreak, pSrcCompPos ;
	int		nBufferTop, nBufferEnd, nReadingPosition ;
	CImeBufferProperty*	pProperty ;
	CImeBufferProperty	propDuringHenkan ;
	CImeBufferProperty	propKanaPrefix ;
	CImeBufferProperty	propOkuriMarker ;
	BOOL	bErasePrefix		= FALSE ;
	BOOL	bEraseOkuriMarker	= FALSE ;


	nBufferTop	= 0 ;
	nBufferEnd	= m_nbufComp ;
	if (m_rpmkMarker [MARKER_BUFFERTOP] != NULL && m_rpmkMarker [MARKER_BUFFERTOP]->bIsValidp ()) 
		nBufferTop	= m_rpmkMarker [MARKER_BUFFERTOP]->iGetPosition () ;
	if (m_rpmkMarker [MARKER_BUFFEREND] != NULL && m_rpmkMarker [MARKER_BUFFEREND]->bIsValidp ()) 
		nBufferEnd	= m_rpmkMarker [MARKER_BUFFEREND]->iGetPosition () ;

	/*	�ϊ����쒆�A���ڃR�[�h���͒��͒��ӂ��K�v�B
	 *	- ���m��̕ϊ�������� Property �̐ݒ肪����Ă��Ȃ��B(property ���\�[�g����Ă���̂�
	 *	  ���X�g�����ԂɌ��ăR�s�[����Ηǂ��Ƃ������z�̔j��)
	 *	- ���⁤�̏������K�v�B
	 *	- ���ړ��͂��ꂽ�����ɓǂ݉����͂���̂��H ���̂܂܂Ȃ̂��H
	 */
	if (m_bSkkHenkanMode) {
		int		nHenkanStartPoint ;

		/*	���}�[�N�⁥�}�[�N�̃`�F�b�N�B
		 */
		nHenkanStartPoint	= m_pmkSkkHenkanStartPoint->iGetPosition () ;
		if (m_bSkkHenkanMode == LACTIVE) {
			int		nHenkanEndPoint, nTextLen ;

			if (m_pmkSkkHenkanEndPoint != NULL && m_pmkSkkHenkanEndPoint->bIsValidp ()) {
				nHenkanEndPoint	= m_pmkSkkHenkanEndPoint->iGetPosition () ;
				if (nHenkanStartPoint > nBufferTop && m_bufComp [nHenkanStartPoint - 1] == L'��') {
					/*	���}�[�N�⁥�}�[�N��ǂ݉����Ɋ܂߂Ȃ��悤�ɒ��ӂ���B
					 */
					nHenkanStartPoint	-- ;
				} else {
					/*	���}�[�N�⁥�}�[�N�͉��炩�̕s�K�ō폜����Ă��܂����̂ŁA���̂܂܂� region �ݒ�
					 *	�Ői�߂�B
					 */
				}
			} else {
				nHenkanEndPoint	= nHenkanStartPoint ;
			}

			/*	�ǂ݉����ɂ� skk-henkan-key �𗘗p����c�B���l�ϊ��̏����ɂ����
			 *	�u#�v�ɒu���������Ă��܂������e���܂܂�Ă��Ȃ����A�`�F�b�N���邱�ƁB
			 */
			if (m_nSkkOkuriCharLen > 0) {
				LPCDSTR	wptr, wptrLast ;
				wptrLast	= m_bufSkkHenkanKey + m_nSkkHenkanKeyLen - 1 ;
				wptr		= wptrLast ;
				while (wptr >= m_bufSkkHenkanKey && (L'a' <= *wptr && *wptr <= L'z'))
					wptr	-- ;
				nTextLen	= wptr - m_bufSkkHenkanKey + 1 ;
			} else {
				nTextLen	= m_nSkkHenkanKeyLen ;
			}
			propDuringHenkan.bInitialize (nHenkanStartPoint, nHenkanEndPoint, m_bufSkkHenkanKey, nTextLen) ;

			/*	�ꎞ�I�� stack ��Ɋm�ۂ��ꂽ CImeBufferProperty �� list �ɒǉ����邩�H
			 *	���ꂪ��ԃ�������H��Ȃ����Asort �̏�����j�󂵂Ȃ��Ǝv�����c�B
			 *	����A���ꂾ�ƃ}�[�J����x backward ���Ȃ��Ƃ����Ȃ��̂��c�B����ł��������c�B
			 *
			 *	���[�ށAproperty �� marker �����Ɖ��肵�ď���ɓ����������Ȃ����B
			 */
			(void) _bRegisterProperty (&propDuringHenkan) ;
		} else {
			if (nHenkanStartPoint > nBufferTop && m_bufComp [nHenkanStartPoint - 1] == L'��') {
				propDuringHenkan.bInitialize (nHenkanStartPoint - 1, nHenkanStartPoint, NULL, 0) ;
				(void) _bRegisterProperty (&propDuringHenkan) ;
			}
		}
	} else {
		/*	�ϊ��̈�̓ǂݑւ��̕K�v�͂Ȃ��B
		memset (&propDuringHenkan, 0, sizeof (propDuringHenkan)) ;
		 */
	}
	if (m_nSkkPrefixLen > 0 && CImeConfig::bSkkEchop (m_pDoc->pGetConfig ()) && m_pmkSkkKanaStartPoint != NULL) {
		propKanaPrefix.bInitialize (m_pmkSkkKanaStartPoint->iGetPosition (), m_pmkPoint->iGetPosition (), NULL, 0) ;
		(void) _bRegisterProperty (&propKanaPrefix) ;
		bErasePrefix	= TRUE ;
	}
	if (m_bSkkOkurigana && m_pmkSkkOkuriganaStartPoint != NULL) {
		int	nOkuriStartPos	= m_pmkSkkOkuriganaStartPoint->iGetPosition () ;
		if (nBufferTop <= nOkuriStartPos && nOkuriStartPos < nBufferEnd && m_bufComp [nOkuriStartPos] == L'*') {
			propOkuriMarker.bInitialize (nOkuriStartPos, nOkuriStartPos + 1, NULL, 0) ;
			(void) _bRegisterProperty (&propOkuriMarker) ;
			bEraseOkuriMarker	= TRUE ;
		}
	}

	pSrc		= m_bufComp + nBufferTop ;
	pSrcEnd		= m_bufComp + nBufferEnd ;
	pSrcCompPos	= m_bufComp + nCompPosition ;
	nReadingPosition	= m_nbufComp ;

	pDest		= pDestBuffer ;
	pDestEnd	= pDestBuffer + nDestSize ;
	pProperty	= m_plstProperty ;		/*	Property ���X�g�̓\�[�g���Ă���Ƃ���B */

	while (pDest < pDestEnd && pProperty != NULL) {
		LPDSTR	pDestBak ;
		LPCDSTR	pReading, pSrcBak ;
		int		nReading, nNewPos ;

		/*	Reading Property �ɂ������ĂȂ��̈���R�s�[����B
		 */
		pSrcBreak	= m_bufComp + pProperty->iGetBeginPoint () ;
		pSrcBak		= pSrc ;
		pDestBak	= pDest ;
		while (pDest < pDestEnd && pSrc < pSrcEnd && pSrc < pSrcBreak) 
			*pDest ++	= *pSrc ++ ;

		if (pSrcCompPos != NULL && pSrcCompPos <= pSrc) {
			nReadingPosition	= (pSrc - pSrcBak) + (pDestBak - pDestBuffer) ;
			pSrcCompPos			= NULL ;
		}

		/*	Reading Text ���R�s�[����B���� Reading Text �̓r���� nPosition ���w���Ă���
		 *	�ꍇ�ɂ́A���̉������͕�����Ȃ��̂ŁAReading Text �R�s�[���Ԃ��B
		 *	(�ǂ݉����̋�؂�̏��͒N�������ĂȂ����番����Ȃ�)
		 */
		pReading	= pProperty->pGetText (&nReading) ;
		while (pDest < pDestEnd && nReading > 0) {
			*pDest ++	= *pReading ++ ;
			nReading	-- ;
		}

		/*	- ���� Reading Property ���w���B
		 *	- pSrc �� Reading Text �Ŕ�΂��ꂽ��̏ꏊ���w������B
		 */
		nNewPos		= pProperty->iGetEndPoint () ;
		pSrc		= m_bufComp + nNewPos ;
		if (pSrcCompPos != NULL && pSrcCompPos <= pSrc) {
			nReadingPosition	= pDest - pDestBuffer ;
			pSrcCompPos			= NULL ;
		}

		do {
			pProperty	= pProperty->pGetNext () ;
			/*	���� property �� region-end ������ region-end �����O����
			 *	pSrc �������߂���Ă��܂��̂ŁA�p������B�ǂ݉����� overwrapped ��
			 *	�Ȃ邱�Ƃ͋����Ȃ��Ƃ���������u���Ă���B
			 */
		}	while (pProperty != NULL && pProperty->iGetEndPoint () < nNewPos) ;
	}
	while (pDest < pDestEnd && pSrc < pSrcEnd) 
		*pDest ++	= *pSrc ++ ;

	/*	�ϊ������Ƃ������Ƃŉ��ǉ����ꂽ property ���폜����B���ƁAhenkan-start-point
	 *	�� backward ���Ă�����A1 �� forward ����B
	 */
	if (m_bSkkHenkanMode) {
		(void) _bUnregisterProperty (&propDuringHenkan) ;
	}
	if (bErasePrefix) {
		(void) _bUnregisterProperty (&propKanaPrefix) ;
	}
	if (bEraseOkuriMarker) {
		(void) _bUnregisterProperty (&propOkuriMarker) ;
	}
	if (pnReadingPosition != NULL)
		*pnReadingPosition	= nReadingPosition ;
	return	pDest - pDestBuffer ;
}

/*========================================================================
 */
int
CImeBuffer::iGetPoint () const
{
	return	(m_pmkPoint != NULL)? m_pmkPoint->iGetPosition () : 0 ;
}

CTMarker*
CImeBuffer::pGetPointMarker ()
{
	return	m_pmkPoint ;
}

BOOL
CImeBuffer::bEobp () const
{
	return	iGetPoint () == m_nbufComp ;
}

int
CImeBuffer::iGetPointMax () const
{
	return	m_nbufComp ;
}

int
CImeBuffer::iGetCharAt (int iPosition) const
{
	if (iPosition < 0 || iPosition > m_nbufComp)
		return	-1 ;

	return	m_bufComp [iPosition] ;
}

/*========================================================================
 */
BOOL
CImeBuffer::bSkkErasePrefix (
	BOOL				bClean)
{
	int		nStart ;

	if (CImeConfig::bSkkEchop (m_pDoc->pGetConfig ()) && m_pmkSkkKanaStartPoint != NULL && m_nSkkPrefixLen > 0) {
		nStart	= m_pmkSkkKanaStartPoint->iGetPosition () ;
		if (! bDeleteRegion (nStart, nStart + m_nSkkPrefixLen)) {
			m_nSkkPrefixLen			= 0 ;
			m_iteSkkRuleTree.vReset () ;
//			m_pSkkCurrentRuleTree	= NULL ;
		}
	}
	if (bClean) {
		m_nSkkPrefixLen			= 0 ;
//		m_pSkkCurrentRuleTree	= NULL ;
		m_iteSkkRuleTree.vReset () ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkSetMarker (
	CTMarker**			ppMarker,
	int					nMarkerIndex,
	const CTMarker*		pSource)
{
	return	bSetMarker (ppMarker, nMarkerIndex, pSource) ;
}

BOOL
CImeBuffer::bSkkSetSkkPreviousPoint (
	const CTMarker*		pSource)
{
	return	bSkkSetMarker (&m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pSource) ;
}

BOOL
CImeBuffer::bSkkSetSkkPreviousPointToPoint ()
{
	return	bSkkSetMarker (&m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, m_pmkPoint) ;
}

BOOL
CImeBuffer::bSkkSetSkkHenkanEndPointToPoint ()
{
	return	bSkkSetMarker (&m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, m_pmkPoint) ;
}

BOOL
CImeBuffer::bSkkSetSkkHenkanEndPoint (const CTMarker* pSource)
{
	return	bSkkSetMarker (&m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, pSource) ;
}

BOOL
CImeBuffer::bSkkSetSkkKanaStartPointToPoint ()
{
	return	bSkkSetMarker (&m_pmkSkkKanaStartPoint, MARKER_SKK_KANA_START_POINT, m_pmkPoint) ;
}

BOOL
CImeBuffer::bSkkSetSkkHenkanStartPointToPoint ()
{
	return	bSkkSetMarker (&m_pmkSkkHenkanStartPoint, MARKER_SKK_HENKAN_START_POINT, m_pmkPoint) ;
}

CTMarker*
CImeBuffer::pSkkGetSkkPreviousPointMarker () 
{
	return	m_pmkSkkPreviousPoint ;
}

int
CImeBuffer::iSkkGetSkkHenkanStartPoint () const 
{
	return	(m_pmkSkkHenkanStartPoint != NULL && m_pmkSkkHenkanStartPoint->bIsValidp ())? m_pmkSkkHenkanStartPoint->iGetPosition () : -1 ;
}

CTMarker*
CImeBuffer::pSkkGetSkkHenkanStartPointMarker ()
{
	return	m_pmkSkkHenkanStartPoint ;
}

int
CImeBuffer::iSkkGetSkkHenkanEndPoint () const
{
	return	(m_pmkSkkHenkanEndPoint != NULL && m_pmkSkkHenkanEndPoint->bIsValidp ())? m_pmkSkkHenkanEndPoint->iGetPosition () : -1 ;
}

CTMarker*
CImeBuffer::pSkkGetSkkHenkanEndPointMarker ()
{
	return	m_pmkSkkHenkanEndPoint ;
}

void
CImeBuffer::vSkkClearSkkHenkanEndPoint ()
{
	m_pmkSkkHenkanEndPoint	= NULL ;
	return ;
}

CTMarker*
CImeBuffer::pSkkGetSkkKanaStartPointMarker ()
{
	return	m_pmkSkkKanaStartPoint ;
}

int
CImeBuffer::iSkkGetSkkKanaStartPoint () const 
{
	return	(m_pmkSkkKanaStartPoint != NULL && m_pmkSkkKanaStartPoint->bIsValidp ())? m_pmkSkkKanaStartPoint->iGetPosition () : -1 ;
}

void
CImeBuffer::vSkkClearSkkKanaStartPoint ()
{
	m_pmkSkkKanaStartPoint	= NULL ;
	return ;
}

int
CImeBuffer::iSkkGetSkkOkuriganaStartPoint () const
{
	return	(m_pmkSkkOkuriganaStartPoint != NULL && m_pmkSkkOkuriganaStartPoint->bIsValidp ())? m_pmkSkkOkuriganaStartPoint->iGetPosition () : -1 ;
}

CTMarker*
CImeBuffer::pSkkGetSkkOkuriganaStartPointMarker () 
{
	return	m_pmkSkkOkuriganaStartPoint ;
}

BOOL
CImeBuffer::bSkkSetSkkOkuriganaStartPointToPoint ()
{
	return	bSkkSetMarker (&m_pmkSkkOkuriganaStartPoint, MARKER_SKK_OKURIGANA_START_POINT, m_pmkPoint) ;
}

BOOL
CImeBuffer::bSkkGetSkkMode () const
{
	return	m_bSkkMode ;
}

void
CImeBuffer::vSkkSetSkkMode (int iValue)
{
	m_bSkkMode	= iValue ;
	return ;
}

BOOL
CImeBuffer::bSkkGetSkkModeInvoked () const
{
	return	m_bSkkModeInvoked ;
}

void
CImeBuffer::vSkkSetSkkHenkanMode (int iValue)
{
	m_bSkkHenkanMode	= iValue ;
	return ;
}

int
CImeBuffer::bSkkGetSkkHenkanMode () const
{
	return	m_bSkkHenkanMode ;
}

void
CImeBuffer::vSkkSetSkkOkurigana (int iValue)
{
	m_bSkkOkurigana	= iValue ;
	return ;
}

int
CImeBuffer::bSkkGetSkkOkurigana () const
{
	return	m_bSkkOkurigana ;
}

void	
CImeBuffer::vSkkSetSkkKatakana (int iValue) 
{
	m_bSkkKatakana	= iValue ;
	return ;
}

int
CImeBuffer::bSkkGetSkkKatakana () const
{
	return	m_bSkkKatakana ;
}

BOOL
CImeBuffer::bSkkGetSkkAfterPrefix () const
{
	return	m_bSkkAfterPrefix ;
}

BOOL
CImeBuffer::bSkkGetSkkKakuteiFlag () const
{
	return	m_bSkkKakuteiFlag ;
}

void
CImeBuffer::vSkkSetSkkKakuteiFlag (BOOL bValue) 
{
	m_bSkkKakuteiFlag	= bValue ;
	return ;
}

int
CImeBuffer::iSkkGetSkkHenkanCount () const 
{
	return	m_iSkkHenkanCount ;
}

void
CImeBuffer::vSkkSetSkkHenkanCount (int iCount)
{
	m_iSkkHenkanCount	= iCount ;
	return ;
}

void
CImeBuffer::vSkkSetSkkHenkanKey (
	LPCDSTR			pwString,
	int				nLength)
{
	if (pwString != NULL && nLength > 0) {
		nLength	= (nLength > MAXLEN_HENKAN_KEY)? MAXLEN_HENKAN_KEY : nLength ;

		memmove (m_bufSkkHenkanKey, pwString, nLength * sizeof (DCHAR)) ;
		m_nSkkHenkanKeyLen	= nLength ;
	} else {
		m_nSkkHenkanKeyLen	= 0 ;
	}
	return ;
}

BOOL
CImeBuffer::bSkkAddSkkHenkanKey (
	LPCDSTR			pwString,
	int				nLength)
{
	int		nAdd ;

	if (pwString == NULL || nLength <= 0)
		return	TRUE ;

	nAdd	= MIN (MAXLEN_HENKAN_KEY - m_nSkkHenkanKeyLen, nLength) ;
	if (nAdd <= 0)
		return	FALSE ;
	memmove (m_bufSkkHenkanKey + m_nSkkHenkanKeyLen, pwString, nAdd * sizeof (DCHAR)) ;
	m_nSkkHenkanKeyLen	+= nAdd ;
	return	TRUE ;
}

LPCDSTR
CImeBuffer::pSkkGetSkkHenkanKey (int* pnLength) const
{
	if (pnLength != NULL)
		*pnLength	= m_nSkkHenkanKeyLen ;
	return	m_bufSkkHenkanKey ;
}

int
CImeBuffer::iSkkGetSkkHenkanKeyLength () const
{
	return	m_nSkkHenkanKeyLen ;
}

BOOL
CImeBuffer::bSkkValidSkkOkuriHenkanKeyp () const
{
	int		i ;

	for (i = m_nSkkHenkanKeyLen - 1 ; i >= 0 ; i --) {
		if (m_bufSkkHenkanKey [i] != L' ')
			break ;
	}
	if (i < 0 || m_bufSkkHenkanKey [i] == L'*') 
		return	FALSE ;
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkNormalizeHenkanKey (
	BOOL		bAllowNewlinesSpacesAndTabs)
{
	LPDSTR	wpSrc, wptrEnd ;

	if (bAllowNewlinesSpacesAndTabs) {
		LPDSTR	wpDest ;

		wpSrc	= m_bufSkkHenkanKey ;
		wpDest	= m_bufSkkHenkanKey ;
		wptrEnd	= m_bufSkkHenkanKey + m_nSkkHenkanKeyLen ;
		while (wpSrc < wptrEnd) {
			if (*wpSrc == L' ' || *wpSrc == L'\n' || *wpSrc == L'\r' || *wpSrc == L'\t') {
				while (wpSrc < wptrEnd && (*wpSrc == L' ' || *wpSrc == L'\n' || *wpSrc == L'\r' || *wpSrc == L'\t'))
					wpSrc	++ ;
				if (wpSrc >= wptrEnd)
					break ;
			}
			if (wpDest != wpSrc)
				*wpDest ++	= *wpSrc ++ ;
		}
		m_nSkkHenkanKeyLen	= wpDest - m_bufSkkHenkanKey ;
	} else {
		wpSrc	= m_bufSkkHenkanKey ;
		wptrEnd	= m_bufSkkHenkanKey + m_nSkkHenkanKeyLen ;
		while (wpSrc < wptrEnd && (*wpSrc != L'\n' && *wpSrc != L'\r'))
			wpSrc	++ ;
		if (wpSrc < wptrEnd) {
			return	FALSE ;
		}
		wpSrc	= m_bufSkkHenkanKey ;
		while (wpSrc < wptrEnd && (*wpSrc != L' ' && *wpSrc != L'\t'))
			wpSrc	++ ;
		m_nSkkHenkanKeyLen	= wpSrc - m_bufSkkHenkanKey ;
	}
	return	TRUE ;
}

void
CImeBuffer::vSkkSetSkkPrefix (
	LPCDSTR			pwString,
	int				nLength)
{
	if (pwString != NULL && nLength > 0) {
		nLength	= (nLength > MAXLEN_PREFIX)? MAXLEN_PREFIX : nLength ;
		memcpy (m_bufSkkPrefix, pwString, nLength * sizeof (DCHAR)) ;
		m_nSkkPrefixLen	= nLength ;
	} else {
		m_nSkkPrefixLen	= 0 ;
	}
	return ;
}

BOOL
CImeBuffer::bSkkAddSkkPrefix (
	int				iCH)
{
	if (m_nSkkPrefixLen < MAXLEN_PREFIX) {
		m_bufSkkPrefix [m_nSkkPrefixLen ++]	= (DCHAR) iCH ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

LPCDSTR
CImeBuffer::pSkkGetSkkPrefix (int* pnLength) const
{
	if (pnLength != NULL)
		*pnLength	= m_nSkkPrefixLen ;
	return	m_bufSkkPrefix ;
}

void
CImeBuffer::vSkkSetSkkAfterPrefix (int iValue)
{
	m_bSkkAfterPrefix	= iValue ;
	return ;
}

BOOL
CImeBuffer::bSkkTestOhConversion () const
{
	if (m_nSkkPrefixLen == 2 && m_bufSkkPrefix [0] == L'h' && (L'b' <= m_bufSkkPrefix [1] && m_bufSkkPrefix [1] <= L'z') &&
		m_bufSkkPrefix [1] != L'e' && m_bufSkkPrefix [1] != L'i' && m_bufSkkPrefix [1] != L'o' && m_bufSkkPrefix [1] != L'u') {
		/*	������ preceding-char �����邱�ƂɂȂ�B
		 */
		int		nPoint			= m_pmkPoint->iGetPosition () ;
		int		nPrecedingChar	= -1 ;

		if (0 < nPoint && nPoint <= m_nbufComp) {
			nPrecedingChar	= m_bufComp [nPoint - 1] ;
		} else if (nPoint == 0) {
			/*	���O�ɃA�v���P�[�V�����ɓn���������̍Ō�ƂƂ�B
			 *	�������A���́u���O�Ɂv���N���A������@�́c�p�ӂ��؂��̂��낤���H
			 */
			nPrecedingChar	= (m_nLatestShiftTextLen > 0)? m_bufLatestShiftText [m_nLatestShiftTextLen - 1] : -1 ;
		}
		return	(nPrecedingChar == L'��' || nPrecedingChar == L'�I')? TRUE : FALSE ;
	} else {
		return	FALSE ;
	}
}

void
CImeBuffer::vSkkSetSkkOkuriChar (
	LPCDSTR		pwString,
	int			nLength)
{
	if (pwString != NULL && nLength > 0) {
		nLength	= MIN (MYARRAYSIZE (m_bufSkkOkuriChar), nLength) ;
		memmove (m_bufSkkOkuriChar, pwString, nLength * sizeof (DCHAR)) ;
		m_nSkkOkuriCharLen	= nLength ;
	} else {
		m_nSkkOkuriCharLen	= 0 ;
	}
	return ;
}

LPCDSTR
CImeBuffer::pSkkGetSkkOkuriChar (int* pnLength) const
{
	if (pnLength != NULL)
		*pnLength	= m_nSkkOkuriCharLen ;
	return	m_bufSkkOkuriChar ;
}

int
CImeBuffer::iSkkGetSkkOkuriCharLength () const
{
	return	m_nSkkOkuriCharLen ;
}

void
CImeBuffer::vSkkSetSkkHenkanOkurigana (
	LPCDSTR		pwString,
	int			nLength)
{
	if (pwString != NULL && nLength > 0) {
		nLength	= MIN (MYARRAYSIZE (m_bufSkkHenkanOkurigana), nLength) ;
		memmove (m_bufSkkHenkanOkurigana, pwString, nLength * sizeof (DCHAR)) ;
		m_nSkkHenkanOkuriganaLen	= nLength ;
	} else {
		m_nSkkHenkanOkuriganaLen	= 0 ;
	}
	return ;
}

LPCDSTR
CImeBuffer::pSkkGetSkkHenkanOkurigana (int* pnLength) const 
{
	if (pnLength != NULL)
		*pnLength	= m_nSkkHenkanOkuriganaLen ;

	return	m_bufSkkHenkanOkurigana ;
}

int
CImeBuffer::iSkkGetSkkHenkanOkuriganaLength () const 
{
	return	m_nSkkHenkanOkuriganaLen ;
}

void
CImeBuffer::vSkkSetSkkHenkanInMinibuffFlag (int iValue)
{
	m_bSkkHenkanInMinibuffFlag	= iValue ;
	return ;
}

int
CImeBuffer::iSkkGetSkkHenkanInMinibuffFlag () const
{
	return	m_bSkkHenkanInMinibuffFlag ;
}

int
CImeBuffer::iSkkGetSkkOkuriIndexMin () const
{
	return	m_iSkkOkuriIndexMin  ;
}

int
CImeBuffer::iSkkGetSkkOkuriIndexMax () const
{
	return	m_iSkkOkuriIndexMax ;
}

void
CImeBuffer::vSkkSetSkkAbbrevMode (int iValue) 
{
	m_bSkkAbbrevMode	= iValue ;
	return ;
}

CTSearchSession*
CImeBuffer::pSkkGetSkkCurrentSearchProgSession () 
{
	return	m_pSkkCurrentSearchProgSession ;
}

void
CImeBuffer::vSkkSetSkkCurrentSearchProgSession (CTSearchSession* pSession) 
{
	m_pSkkCurrentSearchProgSession	= pSession ;
	return ;
}

CTS4Mapping*
CImeBuffer::pSkkGetSkkS4NumericMappingList () 
{
	return	m_plstSkkS4NumericMapping ;
}

void
CImeBuffer::vSkkSetSkkS4NumericMappingList (CTS4Mapping* pListTop) 
{
	m_plstSkkS4NumericMapping	= pListTop ;
	return ;
}

LPCDSTR
CImeBuffer::pSkkGetKakuteiMidasi (int* pnLength) const
{
	if (pnLength != NULL)
		*pnLength	= m_nKakuteiMidasiLen ;

	return	m_bufKakuteiMidasi ;
}

LPCDSTR
CImeBuffer::pSkkGetKakuteiWord (int* pnLength) const
{
	if (pnLength != NULL)
		*pnLength	= m_nKakuteiWordLen ;
	return	m_bufKakuteiWord ;
}

void
CImeBuffer::vSkkSetSkkHenkanShowCandidatesMode (BOOL bValue)
{
	m_bSkkHenkanShowCandidatesMode	= bValue ;
	return ;
}

void
CImeBuffer::vSkkSetSkkInputByCodeOrMenuMode (BOOL bValue)
{
	m_bSkkInputByCodeOrMenuMode	= bValue ;
	return ;
}

void
CImeBuffer::vSkkSetSkkInputByCodeOrMenu1Mode (BOOL bValue)
{
	m_bSkkInputByCodeOrMenu1Mode	= bValue ;
	return ;
}

CTSearchSession*
CImeBuffer::pSkkGetSkkCurrentCompletionSession () 
{
	return	m_pSkkCompSession ;
}

void
CImeBuffer::vSkkSetSkkCurrentCompletionSession (CTSearchSession* pSession) 
{
	m_pSkkCompSession	= pSession ;
	return ;
}

/*========================================================================
 */
BOOL
CImeBuffer::bSkkInsertPrefix (
	LPCDSTR				wstrPrefix,
	int					nstrPrefixLen)
{
	if (CImeConfig::bSkkEchop (m_pDoc->pGetConfig ())) {
		if (wstrPrefix != NULL && nstrPrefixLen > 0) {
			return	bInsertAndInherit (wstrPrefix, nstrPrefixLen) ;
		} else {
			return	bInsertAndInherit (m_bufSkkPrefix, m_nSkkPrefixLen) ;
		}
	} else {
		return	TRUE ;
	}
}

BOOL
CImeBuffer::bSkkModeInvoke ()
{
	/*	�������͂��s���ꍇ�̏����ݒ�A���B�Ȃ�قǁB���̓p�X�B�������ł������Ȃ̂́A
	 *	�c�Ȃ����ȁB���̊֐��̓X���[����B*/
	m_bSkkModeInvoked	= LTRUE ;
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkJModeOn (
	int					nKatakana)
{
	m_bSkkMode					= LTRUE ;
	m_bSkkAbbrevMode			= LFALSE ;
	m_bSkkLatinMode				= LFALSE ;
	m_bSkkJMode					= LTRUE ;
	m_bSkkJisx0208LatinMode		= LFALSE ;
	m_bSkkJisx0201Mode			= LFALSE ;
	m_bSkkKatakana				= nKatakana ;
//	_bSkkSetupKeymap () ;	/* keymap �̐ݒ肩�c�ǂ��������̂��B*/
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkModeOff ()
{
	m_bSkkMode					= LFALSE ;
	m_bSkkAbbrevMode			= LFALSE ;
	m_bSkkLatinMode				= LFALSE ;
	m_bSkkJMode					= LFALSE ;
	m_bSkkJisx0208LatinMode		= LFALSE ;
	m_bSkkJisx0201Mode			= LFALSE ;
	m_bSkkKatakana				= LFALSE ;
	/* skk-cursor-off? */
	/* remove-hook �͕s�v�B*/
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkLatinModeOn ()
{
	m_bSkkMode					= LTRUE ;
	m_bSkkAbbrevMode			= LFALSE ;
	m_bSkkLatinMode				= LTRUE ;
	m_bSkkJMode					= LFALSE ;
	m_bSkkJisx0208LatinMode		= LFALSE ;
	m_bSkkJisx0201Mode			= LFALSE ;
	m_bSkkKatakana				= LFALSE ;
//	_bSkkSetupKeymap () ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkJisx0208LatinModeOn ()
{
	m_bSkkMode					= LTRUE ;
	m_bSkkAbbrevMode			= LFALSE ;
	m_bSkkLatinMode				= LFALSE ;
	m_bSkkJMode					= LFALSE ;
	m_bSkkJisx0208LatinMode		= LTRUE ;
	m_bSkkJisx0201Mode			= LFALSE ;
	m_bSkkKatakana				= LFALSE ;
//	_bSkkSetupKeymap () ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkAbbrevModeOn ()
{
	m_bSkkMode					= LTRUE ;
	m_bSkkAbbrevMode			= LTRUE ;
	m_bSkkLatinMode				= LFALSE ;
	m_bSkkJMode					= LFALSE ;
	m_bSkkJisx0208LatinMode		= LFALSE ;
	m_bSkkJisx0201Mode			= LFALSE ;
	m_bSkkKatakana				= LFALSE ;
//	_bSkkSetupKeymap () ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkJisx0201ModeOn (BOOL bRoman)
{
	/*
		  (setq skk-mode t
				skk-jisx0201-mode t
				skk-jisx0201-roman arg
				skk-rule-tree (if arg
								  skk-jisx0201-roman-rule-tree
								skk-jisx0201-base-rule-tree)
				skk-abbrev-mode nil
				skk-latin-mode nil
				skk-j-mode nil
				skk-jisx0208-latin-mode nil
				skk-katakana nil)
				*/
	m_bSkkMode					= LTRUE ;
	m_bSkkJisx0201Mode			= LTRUE ;
	m_bSkkJisx0201Roman			= bRoman? LTRUE : LFALSE ;
	m_bSkkAbbrevMode			= LFALSE ;
	m_bSkkLatinMode				= LFALSE ;
	m_bSkkJMode					= LFALSE ;
	m_bSkkJisx0208LatinMode		= LFALSE ;
	m_bSkkKatakana				= LFALSE ;

	// skk-rule-tree...
	m_iteSkkRuleTree.vMoveTree (bRoman? CImeConfig::RULETREENO_SKK_JISX0201_ROMAN : CImeConfig::RULETREENO_SKK_JISX0201_BASE) ;
//	_bSkkSetupKeymap () ;	/* keymap �̐ݒ�c�B*/
	/* modeline �� update */
	return	TRUE ;
}

void
CImeBuffer::vSetSkkJisx0201Mode (int iValue)
{
	m_bSkkJisx0201Mode	= iValue ;
	return ;
}

void
CImeBuffer::vSetSkkJisx0201Roman (int iValue)
{
	m_bSkkJisx0201Roman	= iValue ;
	return ;
}

void
CImeBuffer::vSkkClearOkurigana ()
{
	m_nSkkOkuriCharLen		= 0 ;
	m_iSkkOkuriIndexMin		= -1 ;
	m_iSkkOkuriIndexMax		= -1 ;
	m_bSkkOkurigana			= LFALSE ;
	return ;
}

BOOL
CImeBuffer::bSkkChangeMarkerToWhite ()
{
	CTMarker*	pmkMark ;
	int			nPos ;

	pmkMark		= pMakeMarker (TRUE) ;
	if (pmkMark == NULL)
		return	FALSE ;

	if (m_pmkSkkHenkanStartPoint != NULL) {
		m_pmkPoint->bSetPosition (m_pmkSkkHenkanStartPoint) ;
		m_pmkPoint->bBackward (1) ;
		nPos	= m_pmkPoint->iGetPosition () ;
		if (0 <= nPos && nPos < m_nbufComp && m_bufComp [nPos] == L'��') {
			bInsertAndInherit (L"��", 1) ;
			bDeleteRegion (m_pmkPoint->iGetPosition (), m_pmkPoint->iGetPosition () + 1) ;
		} else {
			m_pmkPoint->bSetPosition (m_pmkSkkHenkanStartPoint) ;
			bInsertAndInherit (L"��", 1) ;
			bSkkSetMarker (&m_pmkSkkHenkanStartPoint, MARKER_SKK_HENKAN_START_POINT, m_pmkPoint) ;
			/* (skk-message It semms .. */
		}
	}
	m_pmkSkkHenkanEndPoint	= NULL ;
	m_bSkkHenkanMode		= LON ;
	m_pmkPoint->bSetPosition (pmkMark) ;
	bDeleteMarker (pmkMark) ;
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkInsertNewWord (
	LPCDSTR				wstrNewWord,
	int					nNewWordLen)
{
	LPCDSTR			wstrNote, wstrWord ;
	int				nNoteLen, nWordLen ;
	DCHAR			bufTemp [MAXCOMPLEN] ;
	int				iShowAnnotationType ;
	BOOL			bChangeKanaStartPoint, bChangeOkuriganaStartPoint, bInsertOk ;

	iShowAnnotationType	= CImeConfig::iGetSkkShowAnnotationType (m_pDoc->pGetConfig ()) ;

	wstrWord	= wstrNewWord ;
	nWordLen	= nNewWordLen ;
	wstrNote	= NULL ;
	nNoteLen	= 0 ;
	if (iShowAnnotationType != DISABLE_ANNOTATION) {
		LPCDSTR	wptr, wptrEnd ;

		wptr	= wstrNewWord ;
		wptrEnd	= wstrNewWord + nNewWordLen ;
		while (wptr < wptrEnd && *wptr != L';')
			wptr	++ ;
		if (wptr < wptrEnd) {
			wstrNote	= wptr + 1 ;
			nNoteLen	= wptrEnd - wstrNote ;
			wstrWord	= wstrNewWord ;
			nWordLen	= wptr - wstrWord ;
		}
	}

	/* word �̐擪�ƍŌオ ( �� ) �Ȃ� eval ���Ă݂�B*/
	if (nWordLen > 1 && wstrWord [0] == L'(' && wstrWord [nWordLen - 1] == L')') {
		/* Numeric List �� Count �� bSetNumberList ���Ŏ��s����B*/
		if (m_pSkkCurrentSearchProgSession != NULL && m_pSkkCurrentSearchProgSession->bNumericp ()) {
			CTLispSession::bSetNumberList (m_pSkkCurrentSearchProgSession->pGetNumericList ()) ;
		} else {
			CTLispSession::bSetNumberList (NULL) ;
		}
		if (CTLispSession::bEval (wstrWord, nWordLen, bufTemp, MYARRAYSIZE (bufTemp) /* - 1 */)) {
			/// @todo �o�b�t�@���[�܂Ŏg���؂��Ă����Ȃ����v����
			/* bufTemp [MYARRAYSIZE (bufTemp) - 1]	= L'\0' ; */
			wstrWord	= bufTemp ;
			nWordLen	= dcsnlen (bufTemp, countof(bufTemp)) ;
		}
	}

	/* (skk-lisp-prog-p word) �͍��̂Ƃ��� FALSE */
	if (m_pmkSkkHenkanStartPoint == NULL || m_pmkSkkHenkanEndPoint == NULL)
		return	FALSE ;

	/*	skk-process-okuri-early �̎��ɂ� kana-start-point ���������܂܁A�ϊ����s���
	 *	insert-new-word ���Ăяo����邱�ƂɂȂ�B
	 *	���̎��Akana-start-point �� cursor �ł͂Ȃ��̂ŁAdelete-region ���Ă��܂���
	 *	henkan-start-point �Ɉړ������܂ܖ߂�Ȃ��Ȃ�B
	 *	����͕ϊ����m�肵����ɁAkana-prefix �� erase ���鎞���ƂȂ�B
	 *	���̂��߁A�ꎞ�I�� kana-start-point �� cursor �ɕύX����B
	 */
	bChangeKanaStartPoint		= (m_pmkSkkKanaStartPoint      != NULL && m_pmkSkkKanaStartPoint->bIsValidp ()) ;
	bChangeOkuriganaStartPoint	= (m_pmkSkkOkuriganaStartPoint != NULL && m_pmkSkkOkuriganaStartPoint->bIsValidp ()) ;
	if (bChangeKanaStartPoint)
		m_pmkSkkKanaStartPoint->vSetCursor (TRUE) ;
	if (bChangeOkuriganaStartPoint)
		m_pmkSkkOkuriganaStartPoint->vSetCursor (TRUE) ;
	bDeleteRegion (m_pmkSkkHenkanStartPoint->iGetPosition (), m_pmkSkkHenkanEndPoint->iGetPosition ()) ;
	m_pmkPoint->bSetPosition (m_pmkSkkHenkanStartPoint) ;
	bInsertOk	= bInsertAndInherit (wstrWord, nWordLen) ;
	if (bChangeKanaStartPoint)
		m_pmkSkkKanaStartPoint->vSetCursor (FALSE) ;
	if (bChangeOkuriganaStartPoint)
		m_pmkSkkOkuriganaStartPoint->vSetCursor (FALSE) ;
	if (! bInsertOk)
		return	FALSE ;
	if (! bSkkSetMarker (&m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, m_pmkPoint))
		return	FALSE ;

	/*	��⃊�X�g���炱���͌Ă΂�Ȃ��Ǝv���̂ŁAALWAYS �ȊO�Ȃ�\���̕K�v�͂Ȃ��B*/
	if (! m_bSkkKakuteiFlag && CImeConfig::iGetSkkShowAnnotationType (m_pDoc->pGetConfig ()) == SHOW_ANNOTATION_ALWAYS && nNoteLen > 0) {
		DCHAR	bufTempAnnot [MAXCOMPLEN] ;

		if (nNoteLen > 1 && wstrNote [0] == L'(' && wstrNote [nNoteLen - 1] == L')') {
			CTLispSession::bSetNumberList (NULL) ;
			if (CTLispSession::bEval (wstrNote, nNoteLen, bufTempAnnot, MYARRAYSIZE (bufTempAnnot) /* - 1 */)) {
				/// @todo �o�b�t�@���[�܂Ŏg���؂��Ă����Ȃ����v����
				/* bufTemp [MYARRAYSIZE (bufTempAnnot) - 1]	= L'\0' ; */
				wstrNote	= bufTempAnnot ;
				nNoteLen	= dcsnlen (bufTempAnnot, countof(bufTempAnnot)) ;
			}
		}
		/* (skk-annotation-show note) */
		m_pDoc->bSetMessageN (wstrNote, nNoteLen) ;
	}
	/* skk-insert-new-word-function �̎����͂Ȃ��B*/
	return	TRUE ;
}

int
CImeBuffer::iSkkOkuriganaPrefix (
	LPCDSTR				strOkurigana,
	int					nOkuriganaLen,
	LPDSTR				pOkuriganaPrefix,
	int					nOkuriganaPrefixSize)
{
	int		nHeadChar ;

	if (nOkuriganaLen <= 0 || strOkurigana == NULL) 
		return	0 ;

	nHeadChar	= strOkurigana [0] ;
	if (nHeadChar == L'��') {
		if (nOkuriganaPrefixSize > 0) {
			*pOkuriganaPrefix	= L'n' ;
			return	1 ;
		} else {
			return	0 ;
		}
	} else if (nHeadChar == L'��' && nOkuriganaLen != 1) {
		return	CImeConfig::iSkkARefSkkKanaRomVector (m_pDoc->pGetConfig (), strOkurigana [1], pOkuriganaPrefix, nOkuriganaPrefixSize) ;
	} else {
		return	CImeConfig::iSkkARefSkkKanaRomVector (m_pDoc->pGetConfig (), strOkurigana [0], pOkuriganaPrefix, nOkuriganaPrefixSize) ;
	}
}

BOOL
CImeBuffer::bSkkDeleteOkuriMark ()
{
	int		nPos ;

	if (m_bSkkOkurigana && m_pmkSkkOkuriganaStartPoint != NULL) {
		nPos	= m_pmkSkkOkuriganaStartPoint->iGetPosition () ;
		if (0 <= nPos && nPos < m_nbufComp && m_bufComp [nPos] == L'*') {
			bDeleteRegion (nPos, nPos + 1) ;
		}
		m_bSkkOkurigana				= LFALSE ;
		m_nSkkOkuriCharLen			= 0 ;
		m_nSkkHenkanOkuriganaLen	= 0 ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkUpdateKakuteiHistory (
	LPCDSTR				pMidashi,
	int					nMidashiLen,
	LPCDSTR				pWord,
	int					nWordLen)
{
	LPCDSTR	ptr, ptrEnd ;

	m_nKakuteiMidasiLen	= MIN (nMidashiLen, MYARRAYSIZE (m_bufKakuteiMidasi)) ;
	if (m_nKakuteiMidasiLen <= 0)
		return	FALSE ;
	memcpy (m_bufKakuteiMidasi, pMidashi, m_nKakuteiMidasiLen * sizeof (DCHAR)) ;

	/*	annotation ���O���ēo�^���Ă����H ���ꂼ��̒P��� annotation ��A���������̂��A�A�����ʂ� annotation
	 *	�Ƃ��ēK�؂��ǂ����͕�����Ȃ��̂ŁB
	 */
	if (nWordLen > 0) {
		ptr		= pWord ;
		ptrEnd	= pWord + nWordLen ;
		while (ptr < ptrEnd && *ptr != L';')
			ptr	++ ;
		nWordLen	= ptr - pWord ;

		m_nKakuteiWordLen	= MIN (nWordLen, MYARRAYSIZE (m_bufKakuteiWord)) ;
		if (m_nKakuteiWordLen > 0) 
			memcpy (m_bufKakuteiWord, pWord, m_nKakuteiWordLen * sizeof (DCHAR)) ;
	} else {
		m_nKakuteiWordLen	= 0 ;
	}
	CTRecordKakuteiHistorySession::bUpdate (m_bufKakuteiMidasi, m_nKakuteiMidasiLen, m_bufKakuteiWord, m_nKakuteiWordLen) ;
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkKakuteiCleanupBuffer ()
{
	if (m_bSkkOkurigana) {
		bSkkDeleteOkuriMark () ;
	}
	_bSkkDeleteHenkanMarkers (FALSE) ;
	return	TRUE ;
}

BOOL
CImeBuffer::bSkkKakuteiInitialize (
	LPCDSTR				wstrKakuteiWord,
	int					nKakuteiWordLen)
{
	m_bSkkAbbrevMode			= LFALSE ;
	m_bSkkExitShowCandidates	= LFALSE ;
	m_iSkkHenkanCount			= -1 ;
	m_bSkkHenkanInMinibuffFlag	= LFALSE ;
	m_nSkkHenkanKeyLen			= 0 ;
	m_nSkkHenkanOkuriganaLen	= 0 ;
	/* skk-henkan-list�H �����Ǘ����郊�X�g���낤�H */
	m_bSkkHenkanMode			= LFALSE ;
	m_bSkkKakuteiFlag			= LFALSE ;
	m_nSkkOkuriCharLen			= 0 ;
	m_iSkkOkuriIndexMin			= -1 ;
	m_iSkkOkuriIndexMax			= -1 ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wstrKakuteiWord) ;
	UNREFERENCED_PARAMETER (nKakuteiWordLen) ;
}

BOOL
CImeBuffer::bSkkNumUpdateJisyo ()
{
	CTS4Candidate*	pNumCand ;
	int		n ;
	BOOL	bRetval ;

	/*	���o���B
	 */
	if (m_pSkkCurrentSearchProgSession == NULL)
		return	FALSE ;
	m_pSkkCurrentSearchProgSession->bRewind () ;
	for (n = 0 ; n < m_iSkkHenkanCount ; n ++) {
		if (! m_pSkkCurrentSearchProgSession->bNextCandidate ())
			return	FALSE ;
	}

	/*	#4 �̕ϊ����ʂ̎��� update ������B
	 */
	bRetval		= TRUE ;
	pNumCand	= m_pSkkCurrentSearchProgSession->pGetNumericLink () ;
	while (pNumCand != NULL) {
		LPCDSTR		pwKey, pwResult ;
		int			nKeyLen, nResultLen ;

		pwKey		= m_pSkkCurrentSearchProgSession->pGetNumericKeyword (pNumCand, &nKeyLen) ;
		pwResult	= m_pSkkCurrentSearchProgSession->pGetNumericResult  (pNumCand, &nResultLen) ;

		/*	pwKey, nKeyLen, pwResult, nResultLen �� update ��������B
		 *	���艼���͂Ȃ��B
		 */
		if (nKeyLen > 0 && nResultLen > 0) {
			if (! CTRecordSession::bUpdate (pwKey, nKeyLen, pwResult, nResultLen, NULL, 0, FALSE)) {
				bRetval	= FALSE ;
				break ;
			}
		}
		pNumCand	= m_pSkkCurrentSearchProgSession->pGetNextNumericLink (pNumCand) ;
	}
	return	bRetval ;
}

BOOL
CImeBuffer::bValidRegionp (int nStartPos, int nEndPos)
{
	CTMarker*	pmkBufferTop	= NULL ;
	CTMarker*	pmkBufferEnd	= NULL ;
	int		nBufferTop, nBufferEnd ;

	if (bGetMarker (MARKER_BUFFERTOP, &pmkBufferTop) && pmkBufferTop != NULL) {
		nBufferTop	= pmkBufferTop->iGetPosition () ;
	} else {
		nBufferTop	= 0 ;
	}
	if (bGetMarker (MARKER_BUFFEREND, &pmkBufferEnd) && pmkBufferEnd != NULL) {
		nBufferEnd	= pmkBufferEnd->iGetPosition () ;
	} else {
		nBufferEnd	= m_nbufComp ;
	}
	if (nStartPos > nEndPos || nEndPos < nBufferTop || nStartPos >= nBufferEnd) {
		return	FALSE ;
	}
	return	TRUE ;
}

int
CImeBuffer::iSkkGetSkkCurrentKutotenType () const
{
	return	m_iSkkCurrentKutotenType ;
}

void
CImeBuffer::vSkkSetSkkCurrentKutotenType (int iValue)
{
	m_iSkkCurrentKutotenType	= iValue ;
	return ;
}

int
CImeBuffer::bSkkHenkanActivep () const 
{
	return	m_bSkkHenkanMode ;
}

BOOL
CImeBuffer::bInitializeHenkanCandidateList (
	int					iPageStart)			/* nHenkanCount �Ƃ������B*/
{
	IMECANDIDATES*		pMyCand ;
	BOOL				bNeedReconstruct = FALSE ;
	int					nCandidate, i, nCurPage = 0 ;
	UINT*				puPageIndex ;
	BOOL				bContinue ;

	m_pDoc->vClearMessage () ;

	pMyCand	= m_pDoc->pGetCandidateInfo () ;
	if (pMyCand == NULL)
		return	FALSE ;

	if (! pMyCand->bIsEnabledp () || 
		pMyCand->m_iStyle != IMECANDSTYLE_READ ||
		pMyCand->m_iCount == 0 ||
		pMyCand->m_iCount < (UINT)iPageStart ||
		pMyCand->m_vbufPageIndex.iGetUsage () <= 0) {
		bNeedReconstruct	= TRUE ;
		goto	exit_func_1 ;
	}
	nCandidate	= m_pSkkCurrentSearchProgSession->iGetNumberOfCandidate (&bContinue) ;
	if (pMyCand->m_iCount != (UINT)nCandidate) {
		/*	CandidateList ���č\������K�v������B*/
		bNeedReconstruct	= TRUE ;
		goto	exit_func_1 ;
	}
	puPageIndex		= pMyCand->m_vbufPageIndex.pGetBuffer () ;
	nCurPage		= -1 ;
	for (i = 0 ; i < (pMyCand->m_vbufPageIndex.iGetUsage () - 1) ; i ++) {
		if (puPageIndex [i] <= (UINT)iPageStart && (UINT)iPageStart < puPageIndex [i + 1]) {
			nCurPage	= i ;
			break ;
		}
	}
	if (nCurPage == -1) {
		int		iNumHenkanShowCandidates ;

		(void) CImeConfig::pGetSkkHenkanShowCandidatesKeys (m_pDoc->pGetConfig (), &iNumHenkanShowCandidates) ;
		if (((UINT)iPageStart - puPageIndex [i]) >= (UINT)iNumHenkanShowCandidates) {
			bNeedReconstruct	= TRUE ;
		} else {
			nCurPage	= i ;
		}
	}
  exit_func_1:
	if (bNeedReconstruct) {
		return	_bCreateHenkanCandidateList (iPageStart) ;
	} else {
		pMyCand->m_iCurrentPage	= nCurPage ;
		return	TRUE ;
	}
}

BOOL
CImeBuffer::_bCreateHenkanCandidateList (
	int					iPageStart)
{
	IMECANDIDATES*		pCandInfo ;
	UINT*				pCandidateOffset ;
	UINT*				pAnnotationOffset ;
	UINT*				pPageIndex ;
	LPDSTR				pCandidateStr ;
	LPDSTR				pCandidateBase ;
	LPCDSTR				wstrResult ;
	int					nCandidate, nNeedLength, nHCount, i, nRealCand, nPages, nPageSize ;
	BOOL				bContinue ;
	DCHAR				bufTemp  [MAXCOMPLEN] ;
	const DCHAR			bufTempNote []	= { 0 } ;
	int					iAnnotationType, iCountHenkanShowChange, iNumHenkanShowCandidates ;

	iAnnotationType	= CImeConfig::iGetSkkShowAnnotationType (m_pDoc->pGetConfig ()) ;
	iCountHenkanShowChange	= CImeConfig::iGetCountHenkanShowChange (m_pDoc->pGetConfig ()) ;
	(void) CImeConfig::pGetSkkHenkanShowCandidatesKeys (m_pDoc->pGetConfig (), &iNumHenkanShowCandidates) ;
	if (iNumHenkanShowCandidates <= 0)
		return	FALSE ;

	/*	�K�v�ȃ������T�C�Y�����߂�B*/
	bDeleteRegion (m_pmkSkkHenkanStartPoint->iGetPosition (), m_pmkSkkHenkanEndPoint->iGetPosition ()) ;

	/*	�S�Ă̎������������āA����S����x�Ɉ����o����悤�ɂ��Ă����B*/
	nNeedLength	= 0 ;
	for (nHCount = 0 ; nHCount < iNumHenkanShowCandidates ; nHCount ++) {
		if (! m_pSkkCurrentSearchProgSession->bNextCandidate ()) 
			break ;
	}
	while (nHCount -- > 0)
		m_pSkkCurrentSearchProgSession->bPreviousCandidate () ;

	nCandidate	= m_pSkkCurrentSearchProgSession->iGetNumberOfCandidate (&bContinue) ;
	nRealCand	= 0 ;
	m_pSkkCurrentSearchProgSession->bRewind () ;

	/*	#4 expand �� HenkanSession ���������ŉ������Ă���Ă���̂Ŗ��ɂ��Ȃ��B
	*	Lisp Eval (�{�� + Annotation) ���Ȃ��Ǝ��ۂ̕K�v�ȕ����񒷂�������Ȃ����c�B
	 */
	do {
#if 0
		wstrResult	= m_pSkkCurrentSearchProgSession->pGetReferCandidate () ;
		if (wstrResult == NULL)
			wstrResult	= m_pSkkCurrentSearchProgSession->pGetCandidate () ;
#else
		/*	�ϊ���(or �W�J��ƌ����ׂ���)�̃��X�g���o���̂ł����āA#4 �Ƃ����ɕ\������
		 *	�̂ł͂Ȃ��Ƃ����C������B
		 */
		wstrResult	= m_pSkkCurrentSearchProgSession->pGetCandidate () ;
#endif
		if (wstrResult != NULL) {
			int			nResultLen ;

			/*	Lisp Eval ���K�v���ǂ������`�F�b�N���邽�߂� Annotation �Ɩ{�̂𕪗�����B
			 */
			nResultLen	= dcsnlen (wstrResult, MAXKEYWORDLEN) ;	///< @todo ���̃T�C�Y�Ŗ��Ȃ����v�m�F
			if (iAnnotationType != DISABLE_ANNOTATION) {
				LPCDSTR	pwSrc, pwNote = bufTempNote ;
				int		nWordLen, nNoteLen ;

				pwSrc	= wstrResult + nResultLen - 1 ;
				while (pwSrc >= wstrResult && *pwSrc != L';') 
					pwSrc	-- ;
				if (pwSrc >= wstrResult && *pwSrc == L';') {
					pwNote		= pwSrc + 1 ;
					nNoteLen	= nResultLen - (pwNote - wstrResult) ;
					nWordLen	= pwSrc - wstrResult ;
				} else {
					nNoteLen	= 0 ;
					nWordLen	= nResultLen ;
				}
				if (nWordLen > 1 && wstrResult [0] == L'(' && wstrResult [nWordLen - 1] == L')') {
					if (CTLispSession::bEval (wstrResult, nWordLen, bufTemp, MYARRAYSIZE (bufTemp) /* - 1 */)) {
						/// @todo �o�b�t�@���[�܂Ŏg���؂��Ă����Ȃ����v����
						/* bufTemp [MYARRAYSIZE (bufTemp) - 1]	= L'\0' ; */
						nWordLen	= dcsnlen (bufTemp, countof(bufTemp)) ;
					}
				}
				if (nNoteLen > 1 && pwNote [0] == L'(' && pwNote [nNoteLen - 1] == L')') {
					if (CTLispSession::bEval (pwNote, nNoteLen, bufTemp, MYARRAYSIZE (bufTemp) /* - 1 */)) {
						/// @todo �o�b�t�@���[�܂Ŏg���؂��Ă����Ȃ����v����
						/* bufTemp [MYARRAYSIZE (bufTemp) - 1]	= L'\0' ; */
						nNoteLen	= dcsnlen (bufTemp, countof(bufTemp)) ;
					}
				}
				nResultLen	= nWordLen + nNoteLen + ((nNoteLen > 0)? 1 : 0)  ;
			}
			nNeedLength	+= nResultLen + 1 ;
			nRealCand	++ ;
		}
	}	while (m_pSkkCurrentSearchProgSession->bNextCandidate ()) ;

	/*	#4 expand ���l������
	 */
	nCandidate	= m_pSkkCurrentSearchProgSession->iGetNumberOfCandidate (&bContinue)  ;
	if (nCandidate <= 0) 
		return	FALSE ;
	if (iCountHenkanShowChange >= SHOWCANDLIST_COUNT_NOSHOW || nCandidate <= iCountHenkanShowChange)
		return	FALSE ;
	iCountHenkanShowChange	++ ;

	m_pSkkCurrentSearchProgSession->bRewind () ;

	pCandInfo	= m_pDoc->pGetCandidateInfo () ;
	if (pCandInfo == NULL)
		return	FALSE ;
	pCandInfo->vClear () ;

	nPageSize				= (nCandidate < iNumHenkanShowCandidates)? nCandidate : iNumHenkanShowCandidates ;
	nPages					= (nCandidate - iCountHenkanShowChange + nPageSize - 1) / nPageSize ;

	pCandInfo->m_iStyle		= IMECANDSTYLE_READ ;
	pCandInfo->m_iCount		= nCandidate ;
	if (! pCandInfo->m_vbufCandidate.bRequire (nNeedLength) ||
		! pCandInfo->m_vbufCandidateIndex.bRequire (nCandidate) ||
		! pCandInfo->m_vbufAnnotationIndex.bRequire (nCandidate) ||
		! pCandInfo->m_vbufPageIndex.bRequire (nPages)) {
		return	FALSE ;
	}
	pCandInfo->m_iSelection		= iPageStart ;

	pPageIndex					= pCandInfo->m_vbufPageIndex.pGetBuffer () ;
	for (i = 0 ; i < nPages ; i ++) 
		pPageIndex [i]			= iCountHenkanShowChange + nPageSize * i ;

	pCandidateOffset			= pCandInfo->m_vbufCandidateIndex.pGetBuffer () ;
	pAnnotationOffset			= pCandInfo->m_vbufAnnotationIndex.pGetBuffer () ;
	pCandidateBase				= pCandInfo->m_vbufCandidate.pGetBuffer () ;
	pCandidateStr				= pCandidateBase ;

	for (i = 0 ; i < nCandidate ; i ++) {
		*pCandidateOffset	= pCandidateStr - pCandidateBase ;
		*pAnnotationOffset	= 0 ;

#if 0
		wstrResult	= m_pSkkCurrentSearchProgSession->pGetReferCandidate () ;
		if (wstrResult == NULL)
			wstrResult	= m_pSkkCurrentSearchProgSession->pGetCandidate () ;
#else
		/*	�ϊ���(or �W�J��ƌ����ׂ���)�̃��X�g���o���̂ł����āA#4 �Ƃ����ɕ\������
		 *	�̂ł͂Ȃ��Ƃ����C������B
		 */
		wstrResult	= m_pSkkCurrentSearchProgSession->pGetCandidate () ;
#endif
		if (wstrResult != NULL) {
			int			nResultLen ;

			/*	Lisp Eval ���K�v���ǂ������`�F�b�N���邽�߂� Annotation �Ɩ{�̂𕪗�����B
			 */
			nResultLen	= dcsnlen (wstrResult, MAXKEYWORDLEN) ;	///< @todo �ő啶����������Ő��������v����
			if (iAnnotationType != DISABLE_ANNOTATION) {
				LPCDSTR	pwSrc, pwNote = bufTempNote, pwWord ;
				int		nWordLen, nNoteLen ;

				pwSrc	= wstrResult + nResultLen - 1 ;
				pwWord	= wstrResult ;
				while (pwSrc >= wstrResult && *pwSrc != L';') 
					pwSrc	-- ;
				if (pwSrc >= wstrResult && *pwSrc == L';') {
					pwNote		= pwSrc + 1 ;
					nNoteLen	= nResultLen - (pwNote - wstrResult) ;
					nWordLen	= pwSrc - wstrResult ;
				} else {
					nNoteLen	= 0 ;
					nWordLen	= nResultLen ;
				}
				/* Word �� Eval ����K�v�����邩�ǂ����`�F�b�N����B*/
				if (nWordLen > 1 && wstrResult [0] == L'(' && wstrResult [nWordLen - 1] == L')') {
					if (CTLispSession::bEval (wstrResult, nWordLen, bufTemp, MYARRAYSIZE (bufTemp) /* - 1 */)) {
						/// @todo �㑱�� dcsncpy_s �̎��_�Œ��ڃo�b�t�@�T�C�Y���w�肷�ׂ�
						/* bufTemp [MYARRAYSIZE (bufTemp) - 1]	= L'\0' ; */
						nWordLen	= dcsnlen (bufTemp, countof(bufTemp)) ;
						pwWord		= bufTemp ;
					}
				}
				if (nWordLen > 0) 
					dcsncpy (pCandidateStr, pwWord, nWordLen) ;
				pCandidateStr [nWordLen]	= L'\0' ;
				pCandidateStr				+= nWordLen + 1 ;

				/* Annotation �� Eval ����K�v�����邩�ǂ����`�F�b�N����B*/
				if (nNoteLen > 1 && pwNote [0] == L'(' && pwNote [nNoteLen - 1] == L')') {
					if (CTLispSession::bEval (pwNote, nNoteLen, bufTemp, MYARRAYSIZE (bufTemp) /* - 1 */)) {
						/// @todo �㑱�� dcsncpy_s �̎��_�Œ��ڃo�b�t�@�T�C�Y���w�肷�ׂ�
						/* bufTemp [MYARRAYSIZE (bufTemp) - 1]	= L'\0' ; */
						nNoteLen	= dcsnlen (bufTemp, countof(bufTemp)) ;
						pwNote		= bufTemp ;
					}
				}
				if (nNoteLen > 0) {
					dcsncpy (pCandidateStr, pwNote, nNoteLen) ;
					pCandidateStr [nNoteLen]	= L'\0' ;
					*pAnnotationOffset			= pCandidateStr - pCandidateBase ;
					pCandidateStr				+= nNoteLen + 1 ;
				}
			} else {
				dcsncpy (pCandidateStr, wstrResult, nResultLen) ;
				pCandidateStr [nResultLen]	= L'\0' ;
				pCandidateStr		+= nResultLen + 1 ;
			}
			pCandidateOffset	++ ;
			pAnnotationOffset	++ ;
		}
		(void) m_pSkkCurrentSearchProgSession->bNextCandidate () ;
	}

	/*	���ʒu��߂��BSequential �Ȃ̂��h�����B*/
	m_pSkkCurrentSearchProgSession->bRewind () ;
	for (i = 0 ; i < iPageStart ; i ++) 
		if (! m_pSkkCurrentSearchProgSession->bNextCandidate ()) 
			break ;

	pCandInfo->m_iCurrentPage	=  (iPageStart - iCountHenkanShowChange) / nPageSize ;
	pCandInfo->m_dwUpdate		= IMECANDUPDATE_COUNT | IMECANDUPDATE_STRING | IMECANDUPDATE_CURRENT_PAGE | IMECANDUPDATE_PAGE_INDEX ;
	m_pDoc->vSetUpdateFlag (IMEDOC_CREATE_CANDIDATELIST) ;
	return	TRUE ;
}

/*========================================================================
 */
BOOL
CImeBuffer::_bSkkInsertStr (
	LPCDSTR				pwString,
	int					nString)
{
	if (! bInsertAndInherit (pwString, nString))
		return	FALSE ;
	if (m_bSkkHenkanMode ==LON) {
		if (CImeConfig::bSkkAutoStartHenkanp (m_pDoc->pGetConfig ()) && ! m_bSkkOkurigana) {
			/* bSkkAutoStartHenkan (pwString, nString) ; */
		}
	} else {
		/* �I���W�i���� self-insert-after-hook ���Ăяo���Ă��邪�A�������ɂ��̎����̓p�X����B*/
		/* overwrite-mode �͑��݂��Ȃ��̂ŁA���̑�����Ȃ��B*/
	}
	if (m_bSkkJMode && ! m_bSkkHenkanMode) {
		/* skk-do-auto-fill �͑��݂��Ȃ��̂ŁA���̒��g�͋�ł���B*/
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_bSkkDeleteHenkanMarkers (
	BOOL				bNoMsg)
{
	int		nPos ;

	if (m_pmkSkkHenkanStartPoint != NULL) {
		nPos	= m_pmkSkkHenkanStartPoint->iGetPosition () - 1 ;
		if (m_bSkkHenkanMode == LACTIVE) {
			if (0 <= nPos && nPos < m_nbufComp && m_bufComp [nPos] == L'��') {
				bDeleteRegion (nPos, nPos + 1) ;
			} else {
				if (! bNoMsg) {
					/* (skk-message "It seems that you have deleted ��") */
					m_pDoc->bSetMessage (L"It seems that you have deleted ��") ;
				}
			}
		} else if (0 <= nPos && nPos < m_nbufComp && m_bufComp [nPos] == L'��') {
			bDeleteRegion (nPos, nPos + 1) ;
		} else if (! bNoMsg) {
			/* (skk-message "It seems that you have deleted ��") */
			m_pDoc->bSetMessage (L"It seems that you have deleted ��") ;
		}
	}
	return	TRUE ;
}

CSkkRuleTreeIterator*
CImeBuffer::pSkkGetSkkRuleTreeIterator ()
{
	return	&m_iteSkkRuleTree ;
}

/*	
const CSkkRuleTreeNode*
CImeBuffer::pSkkGetSkkCurrentRuleTree () const
{
	return	m_pSkkCurrentRuleTree ;
}

void
CImeBuffer::vSkkSetSkkCurrentRuleTree (const CSkkRuleTreeNode* pNode)
{
	m_pSkkCurrentRuleTree	= pNode ;
	return ;
}
 */

/*========================================================================
 */
void
CImeBuffer::vCopyState (
	const CImeBuffer*		pBuffer)
{
	int		i ;

	if (pBuffer == NULL)
		return ;

	m_pDoc					= pBuffer->m_pDoc ;
	m_pParent				= pBuffer->m_pParent ;
	dcsncpy (m_bufComp, pBuffer->m_bufComp, pBuffer->m_nbufComp) ;
	m_nbufComp				= pBuffer->m_nbufComp ;
	m_iteSkkRuleTree		= pBuffer->m_iteSkkRuleTree ;
//	m_pSkkCurrentRuleTree	= pBuffer->m_pSkkCurrentRuleTree ;
	for (i = 0 ; i < MAX_RESERVED_MARKERS ; i ++) {
		if (pBuffer->m_rpmkMarker [i] != NULL) {
			if (m_rpmkMarker [i] != NULL) {
				m_rpmkMarker [i]->bSetPosition (pBuffer->m_rpmkMarker [i]) ;
			} else {
				m_rpmkMarker [i]	= NULL ;
			}
		}
	}
	if (pBuffer->m_pmkPoint != NULL) {
		m_pmkPoint			= m_rpmkMarker [MARKER_POINT] ;
	} else {
		m_pmkPoint			= NULL ;
	}
	if (pBuffer->m_pmkSkkKanaStartPoint != NULL) {
		m_pmkSkkKanaStartPoint	= m_rpmkMarker [MARKER_SKK_KANA_START_POINT] ;
	} else {
		m_pmkSkkKanaStartPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkPreviousPoint != NULL) {
		m_pmkSkkPreviousPoint	= m_rpmkMarker [MARKER_SKK_PREVIOUS_POINT] ;
	} else {
		m_pmkSkkPreviousPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkHenkanStartPoint != NULL) {
		m_pmkSkkHenkanStartPoint	= m_rpmkMarker [MARKER_SKK_HENKAN_START_POINT] ;
	} else {
		m_pmkSkkHenkanStartPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkHenkanEndPoint != NULL) {
		m_pmkSkkHenkanEndPoint	= m_rpmkMarker [MARKER_SKK_HENKAN_END_POINT] ;
	} else {
		m_pmkSkkHenkanEndPoint	= NULL ;
	}
	if (pBuffer->m_pmkSkkOkuriganaStartPoint != NULL) {
		m_pmkSkkOkuriganaStartPoint	= m_rpmkMarker [MARKER_SKK_OKURIGANA_START_POINT] ;
	} else {
		m_pmkSkkOkuriganaStartPoint	= NULL ;
	}
	if (pBuffer->m_nSkkPrefixLen > 0)
		dcsncpy (m_bufSkkPrefix, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;
	m_nSkkPrefixLen					= pBuffer->m_nSkkPrefixLen ;
	if (pBuffer->m_nSkkHenkanKeyLen > 0)
		dcsncpy (m_bufSkkHenkanKey, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen) ;
	m_nSkkHenkanKeyLen				= pBuffer->m_nSkkHenkanKeyLen ;
	m_bSkkModeInvoked				= pBuffer->m_bSkkModeInvoked ;
	m_bSkkMode						= pBuffer->m_bSkkMode ;
	m_bSkkLatinMode					= pBuffer->m_bSkkLatinMode ;
	m_bSkkJMode						= pBuffer->m_bSkkJMode ;
	m_bSkkJisx0208LatinMode			= pBuffer->m_bSkkJisx0208LatinMode ;
	m_bSkkAbbrevMode				= pBuffer->m_bSkkAbbrevMode ;
	m_bSkkJisx0201Mode				= pBuffer->m_bSkkJisx0201Mode ;
	m_bSkkKatakana					= pBuffer->m_bSkkKatakana ;
	m_bSkkHenkanMode				= pBuffer->m_bSkkHenkanMode ;
	m_bSkkKakuteiFlag				= pBuffer->m_bSkkKakuteiFlag ;
	m_bSkkAfterPrefix				= pBuffer->m_bSkkAfterPrefix ;
	m_bSkkHenkanInMinibuffFlag		= pBuffer->m_bSkkHenkanInMinibuffFlag ;
	m_iSkkHenkanCount				= pBuffer->m_iSkkHenkanCount ;
	m_bSkkExitShowCandidates		= pBuffer->m_bSkkExitShowCandidates ;
	if (pBuffer->m_nSkkHenkanOkuriganaLen > 0)
		dcsncpy (m_bufSkkHenkanOkurigana, pBuffer->m_bufSkkHenkanOkurigana, pBuffer->m_nSkkHenkanOkuriganaLen) ;
	m_nSkkHenkanOkuriganaLen		= pBuffer->m_nSkkHenkanOkuriganaLen ;
	if (pBuffer->m_nSkkOkuriCharLen > 0)
		dcsncpy (m_bufSkkOkuriChar, pBuffer->m_bufSkkOkuriChar, pBuffer->m_nSkkOkuriCharLen) ;
	m_nSkkOkuriCharLen				= pBuffer->m_nSkkOkuriCharLen ;
	m_bSkkOkurigana					= pBuffer->m_bSkkOkurigana ;
	m_iSkkOkuriIndexMin				= pBuffer->m_iSkkOkuriIndexMin ;
	m_iSkkOkuriIndexMax				= pBuffer->m_iSkkOkuriIndexMax ;

	if (pBuffer->m_nKakuteiMidasiLen > 0)
		dcsncpy (m_bufKakuteiMidasi, pBuffer->m_bufKakuteiMidasi, pBuffer->m_nKakuteiMidasiLen) ;
	m_nKakuteiMidasiLen				= pBuffer->m_nKakuteiMidasiLen ;
	if (pBuffer->m_nKakuteiWordLen > 0)
		dcsncpy (m_bufKakuteiWord, pBuffer->m_bufKakuteiWord, pBuffer->m_nKakuteiWordLen) ;
	m_nKakuteiWordLen				= pBuffer->m_nKakuteiWordLen ;
	m_iSkkCurrentKutotenType		= pBuffer->m_iSkkCurrentKutotenType ;
	if (pBuffer->m_nLatestShiftTextLen > 0)
		dcsncpy (m_bufLatestShiftText, pBuffer->m_bufLatestShiftText, pBuffer->m_nLatestShiftTextLen) ;
	m_nLatestShiftTextLen			= pBuffer->m_nLatestShiftTextLen ;

	m_bSkkHenkanShowCandidatesMode	= pBuffer->m_bSkkHenkanShowCandidatesMode ;
	m_bSkkInputByCodeOrMenuMode		= pBuffer->m_bSkkInputByCodeOrMenuMode ;
	m_bSkkInputByCodeOrMenu1Mode	= pBuffer->m_bSkkInputByCodeOrMenu1Mode ;
	m_nLineOffset					= pBuffer->m_nLineOffset ;

	if (pBuffer->m_plstProperty != NULL) {
		_vCopyProperty (pBuffer->m_plstProperty) ;
	} else {
		_vClearProperty () ;
	}
	return ;
}

/*========================================================================
 *	private functions
 */
int
CImeBuffer::_iGetShiftCount ()
{
	register int	nCursor, nShift ;
	register int	nKanaStartPoint, nHenkanStartPoint, nHenkanEndPoint ;
	register int	nOkuriStartPoint ;

	nCursor	= m_pmkPoint->iGetPosition () ;

	if (! bJModep () && ! bAbbrevModep () && (! bJisx0201Modep () || bJisx0201Romanp ()))
		return	nCursor ;

	nKanaStartPoint		= (m_nSkkPrefixLen > 0 && m_pmkSkkKanaStartPoint      != NULL)? m_pmkSkkKanaStartPoint->iGetPosition ()			: MAXCOMPLEN ;
	nHenkanStartPoint	= (m_bSkkHenkanMode    && m_pmkSkkHenkanStartPoint    != NULL)? m_pmkSkkHenkanStartPoint->iGetPosition () - 1	: MAXCOMPLEN ;
	nHenkanEndPoint		= (m_bSkkHenkanMode    && m_pmkSkkHenkanEndPoint      != NULL)? m_pmkSkkHenkanEndPoint->iGetPosition ()			: MAXCOMPLEN ;
	nOkuriStartPoint	= (m_bSkkOkurigana     && m_pmkSkkOkuriganaStartPoint != NULL)? m_pmkSkkOkuriganaStartPoint->iGetPosition ()	: MAXCOMPLEN ;
	
	nShift	= nCursor ;
	nShift	= (nShift > nKanaStartPoint)?   nKanaStartPoint :   nShift ;
	nShift	= (nShift > nHenkanStartPoint)? nHenkanStartPoint : nShift ;
	nShift	= (nShift > nHenkanEndPoint)?   nHenkanEndPoint :   nShift ;
	nShift	= (nShift > nOkuriStartPoint)?  nOkuriStartPoint :  nShift ;
	return	nShift ;
}

BOOL
CImeBuffer::_bRegisterProperty (
	CImeBufferProperty*	pProperty)
{
	CImeBufferProperty*	pNode ;
	CImeBufferProperty*	pPrevNode ;

	if (pProperty == NULL)
		return	FALSE ;

	pNode		= m_plstProperty ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		if (pNode->iGetBeginPoint () >= pProperty->iGetBeginPoint ())
			break ;
		pPrevNode	= pNode ;
		pNode		= pNode->pGetNext () ;
	}
	if (pPrevNode == NULL) {
		pProperty->vSetNext (m_plstProperty) ;
		m_plstProperty		= pProperty ;
	} else {
		pPrevNode->vSetNext (pProperty) ;
		pProperty->vSetNext (pNode) ;
	}
	return	TRUE ;
}

BOOL
CImeBuffer::_bUnregisterProperty (
	CImeBufferProperty*	pProperty)
{
	CImeBufferProperty*	pNode ;
	CImeBufferProperty*	pPrevNode ;

	if (pProperty == NULL)
		return	FALSE ;

	pNode		= m_plstProperty ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		if (pNode == pProperty) {
			if (pPrevNode == NULL) {
				m_plstProperty	= pNode->pGetNext () ;
			} else {
				pPrevNode->vSetNext (pNode->pGetNext ()) ;
			}
			pNode->vSetNext (NULL) ;
			return	TRUE ;
		}
		pPrevNode	= pNode ;
		pNode		= pNode->pGetNext () ;
	}
	return	FALSE ;
}

void
CImeBuffer::_vClearProperty ()
{
	CImeBufferProperty*	pNode ;
	CImeBufferProperty*	pNextNode ;

	if (m_plstProperty == NULL) 
		return ;

	pNode	= m_plstProperty ;
	while (pNode != NULL) {
		pNextNode	= pNode->pGetNext () ;
		/*	�����j���Ȃ̂� marker �̔j���͂��Ȃ��c�B
		 */
		delete	pNode ;
		pNode		= pNextNode ;
	}
	m_plstProperty	= NULL ;
	return ;
}

void
CImeBuffer::_vCopyProperty (
	const CImeBufferProperty*	pSrc)
{
	CImeBufferProperty*	pProperty ;
	CImeBufferProperty*	pPrevNode ;

	_vClearProperty () ;

	pPrevNode	= NULL ;
	while (pSrc != NULL) {
		LPCDSTR	strReadingText ;
		int		nReadingTextLength ;

		pProperty		= new CImeBufferProperty () ;
		if (pProperty == NULL) 
			goto	error ;
		strReadingText	= pSrc->pGetText (&nReadingTextLength) ;
		if (! pProperty->bInitialize (pSrc->iGetBeginPoint (), pSrc->iGetEndPoint (), strReadingText, nReadingTextLength)) {
			delete	pProperty ;
			goto	error ;
		}
		if (pPrevNode != NULL) {
			pPrevNode->vSetNext (pProperty) ;
			pPrevNode	= pProperty ;
		} else {
			m_plstProperty	= pProperty ;
			pPrevNode	= pProperty ;
		}
		pSrc	= pSrc->pGetNext () ;
	}
	return ;
error:
	_vClearProperty () ;
	return ;
}

void
CImeBuffer::_vUpdateProperty ()
{
	CImeBufferProperty*	pNode ;
	CImeBufferProperty*	pNextNode ;
	CImeBufferProperty*	pPrevNode ;

	if (m_plstProperty == NULL) 
		return ;

	pNode		= m_plstProperty ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		pNextNode	= pNode->pGetNext () ;
		/*	�̈悪��ɂȂ�����A���� property �͔j�������B*/
		if (pNode->iGetBeginPoint () >= pNode->iGetEndPoint ()) {
			delete	pNode ;

			if (pPrevNode != NULL) {
				pPrevNode->vSetNext (pNextNode) ;
			} else {
				m_plstProperty	= pNextNode ;
			}
			/*	���̏ꍇ�ANode �͔j�����ꂽ�̂ŁA���O�� Node �͂��̂܂܂ł���B*/
		} else {
			/*	���̏ꍇ�APrevNode �� update */
			pPrevNode	= pNode ;
		}
		pNode		= pNextNode ;
	}
	return ;
}

