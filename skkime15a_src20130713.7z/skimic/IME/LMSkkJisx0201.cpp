// #if !defined (UNITTEST)
#include "globals.h"
// #else
// #include "StdAfx.h"
// #endif

#include "ImeDoc.h"
#include "ImeBuffer.h"
// #include "TMarker.h"	// ImeBuffer.h �ƘA��
// #include "RuleTreeNode.h"
// #include "../../common/keymap.h"
// #include "TMSG.h"	// ImeDoc.h �ƘA��
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "TLispSession.h"
#include "jstring.h"
// #include "ImeConfig.h"	// ImeBuffer.h �ƘA��

/*=================================================================================
 *	prototypes
 */

/*================================================================ skk-mode-jisx0201
 */
int
CImeDoc::LM_bSkkJisx0201ModeOn ( 
	CImeDoc*		pThis)
{
	/*
		(defsubst skk-jisx0201-mode-on (&optional arg)
		  "SKK JIS X 0201 (�J�i) ���[�h���N������B"
		  (make-local-variable 'skk-rule-tree)
		  (setq skk-mode t
				skk-jisx0201-mode t
				skk-jisx0201-roman arg
				skk-rule-tree (if arg
								  skk-jisx0201-roman-rule-tree
								skk-jisx0201-base-rule-tree)
				skk-abbrev-mode nil
				skk-latin-mode nil
				skk-j-mode nil
				skk-jisx0208-latin-mode nil
				skk-katakana nil)
		  (skk-update-modeline 'jisx0201)
		  (skk-cursor-set))
	 */
	CImeBuffer*		pBuffer ;
	int				bRoman ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &bRoman))
		bRoman	= FALSE ;

	pBuffer->bSkkJisx0201ModeOn (bRoman) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-mode-jisx0201
 */
int
CImeDoc::LM_bSkkModeAdJisx0201 ( 
	CImeDoc*		pThis)
{
	/*
		(defadvice skk-mode (before skk-jisx0201-ad activate)
		  (setq skk-jisx0201-mode nil)
		  (kill-local-variable 'skk-rule-tree))
	 */
	CImeBuffer*				pBuffer ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSetSkkJisx0201Mode (LFALSE) ;

	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	piteSkkRuleTree->vReset () ;
	piteSkkRuleTree->vMoveTree (CImeConfig::RULETREENO_SKK_BASE) ;
	pThis->vJump (LM_bSkkMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kakutei-jisx0201
 */
int
CImeDoc::LM_bSkkKakuteiAdJisx0201 ( 
	CImeDoc*		pThis)
{
	/*
	(defadvice skk-kakutei (around skk-jisx0201-ad activate)
	  (let ((jisx0201 skk-jisx0201-mode))
		ad-do-it
		(when jisx0201
		  (skk-jisx0201-mode-on skk-jisx0201-roman))))
	*/
	CImeBuffer*	pBuffer ;
	BOOL		bJisx0201 ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	bJisx0201	= pBuffer->bJisx0201Modep () ;
	if (! pThis->bPushReg (LMREG_1))
		return	LMR_ERROR ;
	pThis->vSetRegInteger (LMREG_1, bJisx0201) ;
	if (! pThis->bCall (LM_bSkkKakutei, LM_bSkkKakuteiAdJisx0201_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKakuteiAdJisx0201_Exit (
	CImeDoc*		pThis)
{
	/*
	(defadvice skk-kakutei (around skk-jisx0201-ad activate)
	  (let ((jisx0201 skk-jisx0201-mode))
		ad-do-it
		(when jisx0201
		  (skk-jisx0201-mode-on skk-jisx0201-roman))))
	*/
	CImeBuffer*	pBuffer ;
	int			bJisx0201 ;

	if (! pThis->bGetRegInteger (LMREG_1, &bJisx0201))
		bJisx0201	= LFALSE ;
	pThis->vPopReg (LMREG_1) ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (bJisx0201) {
		pThis->vSetRegInteger (LMREGARG_0, pBuffer->bJisx0201Romanp ()) ;
		pThis->vJump (LM_bSkkJisx0201ModeOn) ;
		return	LMR_CONTINUE ;
	}
	/*	\C-j �� kana-prefix ��������悤�ɂ��邽�߂̃e�X�g�R�[�h�B���݂���ő��v��
	 *	�e�X�g���B
	 */
	if (pThis->bInteractivep ()) {
		pBuffer->bSkkErasePrefix (TRUE) ;
		pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-latin-mode-jisx0201
 */
int
CImeDoc::LM_bSkkLatinModeAdJisx0201 (
	CImeDoc*		pThis)
{
	/*
	(defadvice skk-latin-mode (before skk-jisx0201-ad activate)
	  (setq skk-jisx0201-mode nil)
	  (kill-local-variable 'skk-rule-tree))
	*/
	CImeBuffer*				pBuffer ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSetSkkJisx0201Mode (LFALSE) ;

	/*	(kill-local-variable 'skk-rule-tree) �����Brule-tree �� jisx0201-roman �� jisx0201-base
	 *	��ݒ肷�鑀��� Tree Rule �̐؂�ւ��Ŏ�������B
	 */
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	piteSkkRuleTree->vReset () ;
	piteSkkRuleTree->vMoveTree (CImeConfig::RULETREENO_SKK_BASE) ;
	pThis->vJump (LM_bSkkLatinMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-jisx0208-latin-mode-jisx0201
 */
int
CImeDoc::LM_bSkkJisx0208LatinModeAdJisx0201 (
	CImeDoc*		pThis)
{
	/*
	(defadvice skk-latin-mode (before skk-jisx0201-ad activate)
	  (setq skk-jisx0201-mode nil)
	  (kill-local-variable 'skk-rule-tree))
	*/
	CImeBuffer*				pBuffer ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSetSkkJisx0201Mode (LFALSE) ;

	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	piteSkkRuleTree->vReset () ;
	piteSkkRuleTree->vMoveTree (CImeConfig::RULETREENO_SKK_BASE) ;
	pThis->vJump (LM_bSkkJisx0208LatinMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-abbrev-mode-jisx0201
 */
int
CImeDoc::LM_bSkkAbbrevModeAdJisx0201 (
	CImeDoc*		pThis)
{
	/*
		(defadvice skk-abbrev-mode (before skk-jisx0201-ad activate)
		  (setq skk-jisx0201-mode nil)
		  (kill-local-variable 'skk-rule-tree))
	*/
	CImeBuffer*				pBuffer ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSetSkkJisx0201Mode (LFALSE) ;

	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	piteSkkRuleTree->vReset () ;
	piteSkkRuleTree->vMoveTree (CImeConfig::RULETREENO_SKK_BASE) ;
	pThis->vJump (LM_bSkkAbbrevMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-set-okurigana-jisx0201
 */
int
CImeDoc::LM_bSkkSetOkuriganaAdJisx0201 (
	CImeDoc*		pThis)
{
	CImeBuffer*				pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->bJisx0201Modep ()) {
		CTMarker*	pmkHenkanStartPoint ;
		CTMarker*	pmkOkuriganaStartPoint ;
		int			iOkuriganaStartPoint ;
		LPCDSTR		pwBufferString ;
		int			nBufferLength ;

		pmkOkuriganaStartPoint	= pBuffer->pSkkGetSkkOkuriganaStartPointMarker () ;
		if (pmkOkuriganaStartPoint == NULL) {
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
		iOkuriganaStartPoint	= pmkOkuriganaStartPoint->iGetPosition () ;
		pwBufferString			= pBuffer->pBufferRawString (&nBufferLength) ;
		if (iOkuriganaStartPoint < 0 || iOkuriganaStartPoint >= (nBufferLength - 1)) {
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
		if (pwBufferString [iOkuriganaStartPoint + 1] == L'*') {
			pBuffer->bDeleteRegion (iOkuriganaStartPoint, iOkuriganaStartPoint + 1) ;
		}
		pmkHenkanStartPoint	= pBuffer->pSkkGetSkkHenkanStartPointMarker () ;
		if (pmkHenkanStartPoint == NULL) {
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
		pThis->vSetRegInteger (LMREGARG_0, pmkHenkanStartPoint->iGetPosition ()) ;
		pThis->vSetRegInteger (LMREGARG_1, pmkOkuriganaStartPoint->iGetPosition ()) ;
		if (! pThis->bCall (LM_bSkkJisx0201ZenkakuRegion, LM_bSkkSetOkuriganaAdJisx0201_1))
			return	LMR_ERROR ;
	} else {
		/* ad-do-it */
		pThis->vJump (LM_bSkkSetOkurigana) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkSetOkuriganaAdJisx0201_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	LPCDSTR			pwBufferString ;
	int				iPoint, iBufferTop, iBufferEnd, nBufferLength ;
	DCHAR			rszOkuri [32] ;
	int				nOkuriLen ;
	BOOL			bSokuon = FALSE ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	iPoint			= pBuffer->iGetPoint () ;

	{
		CTMarker*	pmkBufferTop ;
		CTMarker*	pmkBufferEnd ;

		if (! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkBufferEnd) || pmkBufferEnd == NULL) {
			iBufferEnd	= pBuffer->iGetPointMax () ;
		} else {
			iBufferEnd	= pmkBufferEnd->iGetPosition () ;
		}
		if (! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkBufferTop) || pmkBufferTop == NULL) {
			iBufferTop	= 0 ;
		} else {
			iBufferTop	= pmkBufferTop->iGetPosition () ;
		}
	}
	pwBufferString	= pBuffer->pBufferRawString (&nBufferLength) ;

	/*	buffer-top, buffer-end �Ƃ̔�r���K�v�ł���悤�Ɏv����B
	 */
	if (iPoint <= iBufferTop || iPoint >= iBufferEnd || iPoint >= nBufferLength) {
		nOkuriLen	= 0 ;
	} else {
		rszOkuri [0]	= pwBufferString [iPoint - 1] ;
		nOkuriLen	= 1 ;
	}
	if (nOkuriLen > 0) {
		if (rszOkuri [0] == L'�' || rszOkuri [0] == L'�') {
			rszOkuri [1]	= rszOkuri [0] ;
			rszOkuri [0]	= pwBufferString [iPoint - 2] ;
			nOkuriLen		= 2 ;
			bSokuon			= TRUE ;
		} else {
			if (! (iPoint >= (iBufferTop + 2) && pwBufferString [iPoint - 2] == L'�')) {
				bSokuon		= FALSE ;
			}
		}
	}
	if (nOkuriLen > 0) {
		DCHAR		bufTemp [32], bufTemp2 [32], bufSkkOkuriChar [32] ;
		int			nZenkakuOkuriLen, nHiraganaOkuriLen, nSkkOkuriCharLen ;
		int			iSkkKatakana ;
		CTMarker*	pmkOkuriganaStartPoint ;

		if (! pBuffer->bSkkSetSkkOkuriganaStartPointToPoint ()) {
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
		pmkOkuriganaStartPoint	= pBuffer->pSkkGetSkkOkuriganaStartPointMarker () ;
		pmkOkuriganaStartPoint->bBackward (bSokuon? 2 : 1) ;

		nZenkakuOkuriLen	= iSkkJisx0201Zenkaku (bufTemp, MYARRAYSIZE (bufTemp), rszOkuri, nOkuriLen) ;
		nHiraganaOkuriLen	= iSkkKatakanaToHiragana (bufTemp2, MYARRAYSIZE (bufTemp2), bufTemp, nZenkakuOkuriLen, FALSE) ;
		nSkkOkuriCharLen	= pBuffer->iSkkOkuriganaPrefix (bufTemp2, nHiraganaOkuriLen, bufSkkOkuriChar, MYARRAYSIZE (bufSkkOkuriChar)) ;

		pBuffer->vSkkSetSkkOkuriChar (bufSkkOkuriChar, nSkkOkuriCharLen) ;

		/*	���Ƃ��Ƃ� skk-katakana �̒l���o���āASetOkurigana ���Ăяo���B
		 */
		iSkkKatakana	= pBuffer->bSkkGetSkkKatakana () ;
		if (! pThis->bPushReg (LMREG_1))
			return	LMR_ERROR ;
		pThis->vSetRegInteger (LMREG_1, iSkkKatakana) ;
		pBuffer->vSkkSetSkkKatakana (TRUE) ;
		if (! pThis->bCall (LM_bSkkSetOkurigana, LM_bSkkSetOkuriganaAdJisx0201_2))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkSetOkuriganaAdJisx0201_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	int				iSkkKatakana ;

	/*	(let (skk-katakana) ...) �� skk-katakana �� local-scope �ł��邱�Ƃ�
	 *	�Ή�����㏈���B
	 */
	if (! pThis->bGetRegInteger (LMREG_1, &iSkkKatakana))
		iSkkKatakana	= FALSE ;
	pThis->vPopReg (LMREG_1) ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSkkSetSkkKatakana (iSkkKatakana) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-insert-jisx0201
 */
int
CImeDoc::LM_bSkkInsertAdJisx0201 (
	CImeDoc*		pThis)
{
	CImeBuffer*				pBuffer ;
	DCHAR					wch ;
	CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;
	int						nPrefix ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pBuffer->bJisx0201Modep ()) {
		pThis->vJump (LM_bSkkInsert) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetLastCommandChar (&wch)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;

	/*
       ((or (and (not skk-jisx0201-roman)
                 (memq ch skk-set-henkan-point-key)
                 (or skk-okurigana
                     (not (skk-get-prefix skk-current-rule-tree))
                     (not (skk-select-branch
                           skk-current-rule-tree ch))))
            (and skk-henkan-mode
                 (memq ch skk-special-midashi-char-list)))
        ad-do-it)
		*/
	if ((! pBuffer->bJisx0201Romanp () && 
			CImeConfig::bSkkSetHenkanPointKeyp (pThis->m_pConfig, wch) &&
			(pBuffer->bSkkGetSkkOkurigana () ||
			 piteSkkRuleTree->pGetPrefix (&nPrefix) == NULL ||
			 ! piteSkkRuleTree->bHaveSelectBranchp (wch))) ||
		(pBuffer->bSkkGetSkkHenkanMode () && 
		CImeConfig::bSkkSpecialMidashiCharp (pThis->m_pConfig, wch))) {
		pThis->vJump (LM_bSkkInsert) ;
		return	LMR_CONTINUE ;
	}
	/*
       ((and skk-henkan-mode
             (eq ch skk-start-henkan-char))
        (skk-kana-cleanup 'force)
        (unless (or skk-okurigana
                    skk-okuri-char)
          (let ((jisx0201 (buffer-substring-no-properties
                           skk-henkan-start-point
                           (point)))
                jisx0208)
            (when (and jisx0201
                       (setq jisx0208
                             (skk-jisx0201-zenkaku jisx0201)))
              (insert-before-markers jisx0208)
              (delete-region skk-henkan-start-point
                             (- (point) (length jisx0208))))))
        (let ((skk-katakana t))
          (skk-start-henkan arg))
        (skk-cursor-set))
		*/
	if (pBuffer->bSkkGetSkkHenkanMode () && CImeConfig::bSkkStartHenkanCharp (pThis->m_pConfig, wch)) {
		pThis->vSetRegBool (LMREGARG_0, TRUE) ;
		if (! pThis->bCall (LM_bSkkKanaCleanup, LM_bSkkInsertAdJisx0201_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	/*
      (skk-jisx0201-roman
        (let (skk-set-henkan-point-key)
          ad-do-it))
		  */
	if (pBuffer->bJisx0201Romanp ()) {
		/*	(let (skk-set-henkan-point-key) �ɑ����B
		 */
		BOOL	bMask	= CImeConfig::bSkkSetHenkanPointKeyMaskedp (pThis->m_pConfig) ;
		if (! pThis->bPushReg (LMREG_0))
			return	LMR_ERROR ;
		CImeConfig::vMaskSkkSetHenkanPointKey (pThis->m_pConfig, FALSE) ;
		pThis->vSetRegInteger (LMREG_0, bMask) ;

		/*	ad-do-it
		 */
		if (! pThis->bCall (LM_bSkkInsert, LM_bSkkInsertAdJisx0201_3))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	pThis->vJump (LM_bSkkInsert) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInsertAdJisx0201_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR		pwJisx0201 ;
	DCHAR		bufJisx0208 [MAXCOMPLEN] ;
	int			iJisx0201Len, iJisx0208Len ;
	int			iSkkKatakana ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	/*
	    (unless (or skk-okurigana
                    skk-okuri-char)
          (let ((jisx0201 (buffer-substring-no-properties
                           skk-henkan-start-point
                           (point)))
                jisx0208)
            (when (and jisx0201
                       (setq jisx0208
                             (skk-jisx0201-zenkaku jisx0201)))
              (insert-before-markers jisx0208)
              (delete-region skk-henkan-start-point
                             (- (point) (length jisx0208))))))
 		*/
	if (! (pBuffer->bSkkGetSkkOkurigana () || pBuffer->iSkkGetSkkOkuriCharLength () > 0)) {
		LPCDSTR	pwBufferString ;
		int		nLength ;
		int		iSkkHenkanStartPoint ;
		int		iPoint ;

		pwBufferString			= pBuffer->pBufferRawString (&nLength) ;
		iSkkHenkanStartPoint	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
		iPoint					= pBuffer->iGetPoint () ;
		if (iSkkHenkanStartPoint >= 0 && iPoint >= 0 && iPoint >= iSkkHenkanStartPoint) {
			iJisx0201Len	= iPoint - iSkkHenkanStartPoint ;
			pwJisx0201		= pwBufferString + iSkkHenkanStartPoint ;
		} else {
			iJisx0201Len	= 0 ;
			pwJisx0201		= NULL ;
		}
		if (iJisx0201Len > 0) {
			iJisx0208Len	= iSkkJisx0201Zenkaku (bufJisx0208, MYARRAYSIZE (bufJisx0208), pwJisx0201, iJisx0201Len) ;
			if (iJisx0208Len > 0) {
				/*	insert-before-markers �łȂ���΁Ahenkan-end-point �� henkan-start-point �Ɉ�v���Ă��܂��B
				 *	�ꎞ�I�� marker ��S�� cursor marker �������Ă� insert ���K�v�B
				 */
				pBuffer->bInsertBeforeMarkers (bufJisx0208, iJisx0208Len) ;
				pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iGetPoint () - iJisx0208Len) ;
			}
		}
	}

	/*
       (let ((skk-katakana t))
          (skk-start-henkan arg))
        (skk-cursor-set))
		*/
	if (! pThis->bPushReg (LMREG_1))
		return	LMR_ERROR ;

	iSkkKatakana	= pBuffer->bSkkGetSkkKatakana () ;
	pThis->vSetRegInteger (LMREG_1, iSkkKatakana) ;
	pBuffer->vSkkSetSkkKatakana (LTRUE) ;
	if (! pThis->bCall (LM_bSkkStartHenkan, LM_bSkkInsertAdJisx0201_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInsertAdJisx0201_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	int			iSkkKatakana ;

	if (pThis->bGetRegInteger (LMREG_1, &iSkkKatakana))
		iSkkKatakana	= LFALSE ;
	pThis->vPopReg (LMREG_1) ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSkkSetSkkKatakana (iSkkKatakana) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkInsertAdJisx0201_3 (
	CImeDoc*		pThis)
{
	int			iMask ;

	/*	skk-set-henkan-point-key �� mask �����ɖ߂��B
	 */
	if (pThis->bGetRegInteger (LMREG_1, &iMask))
		iMask	= FALSE ;
	pThis->vPopReg (LMREG_1) ;
	CImeConfig::vMaskSkkSetHenkanPointKey (pThis->m_pConfig, (BOOL) iMask) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-zenkaku-region
 */
int
CImeDoc::LM_bSkkJisx0201ZenkakuRegion (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pwBufferString ;
	int		nStartPos, nEndPos ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	int		nLength, nReplaceText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &nStartPos) || ! pThis->bGetRegInteger (LMREGARG_1, &nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bValidRegionp (nStartPos, nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pwBufferString	= pBuffer->pBufferRawString (NULL) ;
	nReplaceText	= nEndPos - nStartPos ;
	nLength			= iSkkJisx0201Zenkaku (bufTemp, MYARRAYSIZE (bufTemp), pwBufferString + nStartPos, nReplaceText) ;
	if (nLength < nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
		pBuffer->bDeleteRegion (nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nReplaceText) ;
		pBuffer->iInsertByPosition (nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-region
 */
int
CImeDoc::LM_bSkkJisx0201Region (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pwBufferString ;
	int		nStartPos, nEndPos ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	int		nLength, nReplaceText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &nStartPos) || ! pThis->bGetRegInteger (LMREGARG_1, &nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bValidRegionp (nStartPos, nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pwBufferString	= pBuffer->pBufferRawString (NULL) ;
	nReplaceText	= nEndPos - nStartPos ;
	nLength			= iSkkJisx0201Hankaku (bufTemp, MYARRAYSIZE (bufTemp), pwBufferString + nStartPos, nReplaceText) ;
	if (nLength < nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
		pBuffer->bDeleteRegion (nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nReplaceText) ;
		pBuffer->iInsertByPosition (nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-henkan
 */
int
CImeDoc::LM_bSkkJisx0201Henkan (
	CImeDoc*			pThis)
{
	/*
		  "�����[�h�ł���΁A�̈�̂Ђ炪��/�J�^�J�i�� �ݶ����� �ɕϊ�����B
		�����[�h�ł͉������Ȃ��B
		���̑��̃��[�h�ł́A�I���W�i���̃L�[����t���Ńo�C���h����Ă���R�}���h�����s
		����B"
		  (interactive "*P")
		  (skk-henkan-skk-region-by-func #'skk-jisx0201-region arg))
	 */
	pThis->vSetRegPointer (LMREGARG_0, LM_bSkkJisx0201Region) ;
	pThis->vSetRegBool (LMREGARG_1, LFALSE) ;
	pThis->vJump (LM_bSkkHenkanSkkRegionByFunc) ;
	return	LMR_CONTINUE ;
}


/*================================================================ skk-toggle-katakana
 */
int
CImeDoc::LM_bSkkToggleKatakana (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		pThis->vJump (LM_bSkkJisx0201Henkan) ;
		return	LMR_CONTINUE ;
	} else if (pBuffer->bJisx0201Modep ()) {
		if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
			if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkToggleKatakana_1))
				return	LMR_ERROR ;
		} else {
			pThis->vJump (LM_bSkkToggleKatakana_1) ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
			if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkToggleKatakana_2))
				return	LMR_ERROR ;
		} else {
			pThis->vJump (LM_bSkkToggleKatakana_2) ;
		}
		return	LMR_CONTINUE ;
	}
}

int
CImeDoc::LM_bSkkToggleKatakana_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*				pBuffer ;
	CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSetSkkJisx0201Mode (LFALSE) ;
	pBuffer->bSkkJModeOn (pBuffer->bSkkGetSkkKatakana ()) ;

	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	piteSkkRuleTree->vReset () ;
	piteSkkRuleTree->vMoveTree (CImeConfig::RULETREENO_SKK_BASE) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkToggleKatakana_2 (
	CImeDoc*			pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pThis->vSetRegNil (LMREGARG_0) ;
	pThis->vJump (LM_bSkkJisx0201ModeOn) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-toggle-jisx0201
 */
int
CImeDoc::LM_bSkkToggleJisx0201 (
	CImeDoc*			pThis)
{
	CImeBuffer*				pBuffer ;
	CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		pThis->vJump (LM_bSkkJisx0201Henkan) ;
		return	LMR_CONTINUE ;
	} else if (pBuffer->bJisx0201Romanp ()) {
		piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
		piteSkkRuleTree->vReset () ;
		piteSkkRuleTree->vMoveTree (CImeConfig::RULETREENO_SKK_JISX0201_BASE) ;
		pBuffer->vSetSkkJisx0201Roman (LFALSE) ;
	} else {
		piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
		piteSkkRuleTree->vReset () ;
		piteSkkRuleTree->vMoveTree (CImeConfig::RULETREENO_SKK_JISX0201_ROMAN) ;
		pBuffer->vSetSkkJisx0201Roman (LTRUE) ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-mode
 */
int
CImeDoc::LM_bSkkJisx0201Mode (
	CImeDoc*			pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkJisx0201Mode_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkJisx0201Mode_Exit (
	CImeDoc*			pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pThis->vSetRegNil (LMREGARG_0) ;
	pThis->vJump (LM_bSkkJisx0201ModeOn) ;
	return	LMR_CONTINUE ;
}





