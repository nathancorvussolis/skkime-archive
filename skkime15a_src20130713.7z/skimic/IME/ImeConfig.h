#pragma once

#include "dchar.h"

class CSkkRuleTreeNode ;
class CSkkRuleTreeNodeOutput ;

/*========================================================================
 *	definitions
 */

/* for show annotation */
enum {
	DISABLE_ANNOTATION					= -1,
	SHOW_NO_ANNOTATION					= 0,
	SHOW_ANNOTATION_IN_CANDLIST,
	SHOW_ANNOTATION_ALWAYS,
} ;

#define	SIZE_IMEDOC_KEYMAP	256

enum {
	MYCOLOR_TEXTAUTO	= 0,	MYCOLOR_BACKAUTO,
	MYCOLOR_BLACK,				MYCOLOR_DARKRED,
	MYCOLOR_DARKGREEN,			MYCOLOR_DARKYELLOW,
	MYCOLOR_DARKBLUE,			MYCOLOR_DARKPURPLE,
	MYCOLOR_DARKLIGHTBLUE,		MYCOLOR_DARKGRAY,
	MYCOLOR_LIGHTGRAY,			MYCOLOR_RED,
	MYCOLOR_GREEN,				MYCOLOR_YELLOW,
	MYCOLOR_BLUE,				MYCOLOR_PURPLE,
	MYCOLOR_LIGHTBLUE,			MYCOLOR_WHITE,
	MYCOLOR_SYSTEM,
	MYCOLOR_BTNFACE		= MYCOLOR_SYSTEM,
	MYCOLOR_BTNTEXT,			MYCOLOR_ACTIVEBORDER,
	MYCOLOR_ACTIVECAPTION,		MYCOLOR_CAPTIONTEXT,
	MYCOLOR_APPWORKSPACE,		MYCOLOR_WINDOW,
	MYCOLOR_WINDOWTEXT,			MYCOLOR_DESKTOP,
	MYCOLOR_INFOBK,				MYCOLOR_INFOTEXT,
	MYCOLOR_MSGBOXTEXT,			MYCOLOR_MENU,
	MYCOLOR_MENUTEXT,			MYCOLOR_HIGHLIGHTTEXT,
	MYCOLOR_HIGHLIGHT,			MYCOLOR_INACTIVEBORDER,
	MYCOLOR_INACTIVECAPTION,	MYCOLOR_INACTIVECAPTIONTEXT,
	MAX_MYCOLOR,
} ;

enum {
	MYLINE_NO	= 0,	MYLINE_SOLID,		MYLINE_DOTTED,
	MYLINE_THICK_SOLID,	MYLINE_THIN_DITHER,	MYLINE_THICK_DITHER,
	MAX_MYLINE,
} ;

enum {
	MYCOLORFACE_INDEX_MIHENKANMOJIRETSU	= 0,
	MYCOLORFACE_INDEX_HENKANMOJIRETSU	= 1,
} ;

enum {
	SHOWCANDLIST_COUNT_ZERO				= 0,

	SHOWCANDLIST_COUNT_NOSHOW			= 65534,
	SHOWCANDLIST_COUNT_USERDEFINED		= 65535,
} ;

/*================================================================
 *	keybind �Ɋւ����`�B
 */
/*
enum {
	KEYMASK_LCONTROL	= 1 << 0,
	KEYMASK_RCONTROL	= 1 << 1,
	KEYMASK_LMENU		= 1 << 2,
	KEYMASK_RMENU		= 1 << 3,
	KEYMASK_LSHIFT		= 1 << 4,
	KEYMASK_RSHIFT		= 1 << 5,
	KEYMASK_SCROLL		= 1 << 6,
	KEYMASK_NUMLOCK		= 1 << 7,
	NBITS_KEYMASK		= 8,
} ;
*/

struct CImeKeyBind {
	short				m_nKeyCode ;
	unsigned short		m_uKeyMask ;		/* CONTROL | SHIFT | ALT ���炢���H */
	int					m_nKeyFunction ;	/* �@�\�B*/
} ;

struct CImeKeymap {
	BYTE				m_rbyBaseMap [SIZE_IMEDOC_KEYMAP] ;	/* 128 ���Bdefault */
	int					m_nKeyBinds ;	/* �ǉ��B�������݂���΁B*/
	struct CImeKeyBind*	m_pKeyBinds ;
} ;

struct MYCOLORFACESET {
	int				m_nTextColor ;
	int				m_nBackColor ;
	int				m_nUnderLineColor ;
	int				m_nUnderLineType ;
} ;

#define	MAX_KEYBINDS					SIZE_IMEDOC_KEYMAP
#define	MAX_LENGTH_INPUTVECTOR			128
#define	MAX_SPECIALKEYS					64

#define	BUFSIZE_STRPAIR					32

#define	MAX_NUMKUTOUTENS				32
#define	MAX_NUMBRACKETPARENS			32
#define	MAX_NUMOKURICHARPAIR			32

#define	MAX_NUMMENUKEYS					256
/* for colorface */
#define	MAX_NUMCOLORFACES	2

struct TStringPair {
	DCHAR			m_bufLeft  [BUFSIZE_STRPAIR] ;
	DCHAR			m_bufRight [BUFSIZE_STRPAIR] ;
} ;

struct CTKanaRomaPair {
	int				m_nKana ;
	LPCWSTR			m_wstrRom ;
	// �݊����̂��߃R���X�g���N�^���폜
} ;

template<int S> struct CTKeyArray {
	int				m_iKeys ;
	BYTE			m_rbKeys [S] ;
	// CImeConfig�̃R���X�g���N�^���ŕK�������������̂ŃR���X�g���N�^���폜
} ;

template<int S> struct CTStringPairArray {
	int					m_iCount ;
	struct TStringPair	m_rStringPair [S] ;
} ;

class CImeConfig {
public:
	enum {
		NUM_ROMAKANARULE				= 4,
		RULETREENO_SKK_BASE				= 0,
		RULETREENO_SKK_JISX0201_ROMAN	= 256,	// ����B
		RULETREENO_SKK_JISX0201_BASE	= 512,	// ����B
	} ;
private:
/*
	/// ���Ƌ��ʂɂȂ肻���Ȓ萔�̓N���X�O�Ɉړ� (�������܂����Ȃ����Ǘ����y�ɂ��邽��)
	static	LPCWSTR			m_rstrDefaultJisx0208LatinVector [] ;
	static	CTKanaRomaPair	m_rSkkKanaRomVector [] ;
	static	TF_PRESERVEDKEY	m_rDefaultToggleImeKeys [] ;
*/

	int						m_iRomaKanaRuleListType ;
	int						m_iKeybindType ;
	int						m_iStartHenkanKeyType ;
	int						m_iCompletionRelatedKeyType ;
	int						m_iSetHenkanPointSubrKeyType ;
	int						m_iSpecialMidashiCharKeyType ;
	BOOL					m_bMaskSkkSetHenkanPointKey ;

	CSkkRuleTreeNode*		m_rpSkkRuleTree [NUM_ROMAKANARULE] ;
	CSkkRuleTreeNode*		m_rpSkkJisx0201RomanRuleTree [NUM_ROMAKANARULE] ;
	CSkkRuleTreeNode*		m_rpSkkJisx0201RuleTree [NUM_ROMAKANARULE] ;

	LPDSTR					m_rstrJisx0208LatinVector [128] ;
	struct CImeKeymap		m_MajorModeMap ;
	struct CImeKeymap		m_SkkJModeMap ;
	struct CImeKeymap		m_SkkLatinModeMap ;
	struct CImeKeymap		m_SkkJisx0208LatinModeMap ;
	struct CImeKeymap		m_SkkAbbrevModeMap ;
	struct CImeKeymap		m_MinibufferMinorModeMap ;
	TF_PRESERVEDKEY*		m_pToggleImeKeys ;
	int						m_iNumberOfToggleImeKeys ;
	TF_PRESERVEDKEY*		m_pImeOnKeys ;
	int						m_iNumberOfImeOnKeys ;
	TF_PRESERVEDKEY*		m_pImeOffKeys ;
	int						m_iNumberOfImeOffKeys ;

	CTKeyArray<MAX_SPECIALKEYS>	m_StartHenkanKeys ;
	CTKeyArray<MAX_SPECIALKEYS>	m_TryCompletionKeys ;
	CTKeyArray<MAX_SPECIALKEYS>	m_PreviousCompletionKeys ;
	CTKeyArray<MAX_SPECIALKEYS>	m_NextCompletionKeys ;
	CTKeyArray<MAX_SPECIALKEYS>	m_SetHenkanPointSubrKeys ;
	CTKeyArray<MAX_SPECIALKEYS>	m_SpecialMidashiCharKeys ;

	BOOL					m_bEggLikeNewline ;
	BOOL					m_bNewlineKakuteiAll ;

	BOOL					m_bKanaModeWhenOpen ;
	BOOL					m_bEcho ;
	BOOL					m_bCompositionAutoShift ;
	BOOL					m_bDeleteImpliesKakutei ;
	BOOL					m_bKakuteiEarly ;

	/* date & number style */
	int						m_bDateAd ;
	int						m_iNumberStyle ;

	int						m_iKutoutenType ;
	int						m_iBracketParenType ;
	int						m_iOkuriCharAlistType ;
	CTStringPairArray<MAX_NUMKUTOUTENS>		m_Kutouten ;
	CTStringPairArray<MAX_NUMBRACKETPARENS>	m_BracketParen ;
	CTStringPairArray<MAX_NUMOKURICHARPAIR>	m_OkuriCharAlist ;

	int						m_nCandListKeyAssign ;

	int						m_nNumShowCandidateKeys ;
	int						m_nNumInputCodeMenu1Keys ;
	int						m_nNumInputCodeMenu2Keys ;
	DCHAR					m_rwchShowCandidateKeys  [MAX_NUMMENUKEYS] ;
	DCHAR					m_rwchInputCodeMenu1Keys [MAX_NUMMENUKEYS] ;
	DCHAR					m_rwchInputCodeMenu2Keys [MAX_NUMMENUKEYS] ;
	int						m_nShowCandListCount ;

	BOOL					m_bHenkanOkuriStrictly ;
	BOOL					m_bProcessOkuriEarly ;
	BOOL					m_bHenkanStrictOkuriPrecedence ;
	BOOL					m_bAutoOkuriProcess ;
	BOOL					m_bAutoStartHenkan ;
	BOOL					m_bDeleteOkuriWhenQuit ;
	BOOL					m_bNumericConversion ;
	BOOL					m_bNumericFloat ;
	int						m_nShowAnnotationType ;
	int						m_iNumAutoStartHenkanKeywords ;
	DCHAR*					m_pAutoStartHenkanKeywords ;
	MYCOLORFACESET			m_rImeColorFaces [MAX_NUMCOLORFACES] ;
	BOOL					m_bAllowsSpacesNewlinesAndTabs ;
	int						m_iKanjiCodeCharset ;
	BOOL					m_bCompCirculate ;

	/* font/size */
	LOGFONT					m_lfDefault ;
	int						m_iDefaultFontSize ;
	HFONT					m_hDefaultFont ;

	BOOL					m_bTSFKeyDownEatenDoesNotWork ;

	BOOL					m_bHaveSyncTick ;
	DWORD					m_dwSyncTick ;

	ULONG					m_cRef ;

public:
	virtual							~CImeConfig () ;

    STDMETHODIMP_(ULONG)			AddRef (void) ;
    STDMETHODIMP_(ULONG)			Release (void) ;
	void							vUpdate () ;

	static	CImeConfig*				pCreateInstance () ;

	static	BOOL					bTSFKeyDownEatenDoesNotWorkp (CImeConfig* pThis) ;
	static	BOOL					bKanaModeWhenOpenp (CImeConfig* pThis) ;
	static	CSkkRuleTreeNode*		pGetSkkRuleTree (CImeConfig* pThis, int iRule) ;
	static	BOOL					bSkkKakuteiEarlyp (CImeConfig* pThis) ;
	static	BOOL					bSkkProcessOkuriEarlyp (CImeConfig* pThis) ;
	static	BOOL					bSkkEchop (CImeConfig* pThis) ;
	static	BOOL					bSkkTryCompletionCharp (CImeConfig* pThis, int) ;
	static	BOOL					bSkkPreviousCompletionCharp (CImeConfig* pThis, int) ;
	static	BOOL					bSkkNextCompletionCharp (CImeConfig* pThis, int) ;
	static	BOOL					bSkkAutoStartHenkanp (CImeConfig* pThis) ;
	static	BOOL					bSkkAutoStartHenkanKeywordp (CImeConfig* pThis, LPCDSTR, int) ;
	static	BOOL					bSkkSpecialMidashiCharp (CImeConfig* pThis, int) ;
	static	BOOL					bSkkSetHenkanPointKeyp (CImeConfig* pThis, int)  ;
	static	void					vMaskSkkSetHenkanPointKey (CImeConfig* pThis, BOOL bMask) ;
	static	BOOL					bSkkSetHenkanPointKeyMaskedp (CImeConfig* pThis) ;
	static	BOOL					bSkkStartHenkanCharp (CImeConfig* pThis, int) ;
	static	int						iSkkARefSkkKanaRomVector (CImeConfig* pThis, int, LPDSTR, int) ;
	static	int						iGetSkkShowAnnotationType (CImeConfig* pThis) ;
	static	BOOL					bSkkEggLikeNewline (CImeConfig* pThis) ;
	static 	BOOL					bSkkDeleteOkuriWhenQuit (CImeConfig* pThis) ;
	static 	BOOL					bSkkDeleteImplesKakuteip (CImeConfig* pThis) ;
	static 	LPCDSTR					pGetSkkHenkanShowCandidatesKeys (CImeConfig* pThis, int*) ;
	static 	BOOL					bSkkNumericConversionp (CImeConfig* pThis) ;
	static 	BOOL					bSkkNumConvertFloatp (CImeConfig* pThis) ;
	static 	BOOL					bSkkCompCirculatep (CImeConfig* pThis) ;
	static 	int						iGetSkkKcodeCharset (CImeConfig* pThis) ;
	static 	LPCDSTR					pGetSkkInputByCodeMenuKeys1 (CImeConfig* pThis, int*) ;
	static 	LPCDSTR					pGetSkkInputByCodeMenuKeys2 (CImeConfig* pThis, int*) ;
	static 	int						iGetSkkOkuriChar (CImeConfig* pThis, LPCDSTR, int, LPDSTR, int) ;
	static 	BOOL					bSkkHenkanOkuriStrictlyp (CImeConfig* pThis) ;
	static 	BOOL					bSkkHenkanStrictOkuriPrecedencep (CImeConfig* pThis) ;
	static 	BOOL					bSkkAutoOkuriProcessp (CImeConfig* pThis) ;
	static 	int								iSkkARefSkkJisx0208LatinVector (CImeConfig* pThis, int, LPDSTR, int) ;
	static 	int								iSkkRevRefSkkJisx0208LatinVector (CImeConfig* pThis, int, LPDSTR, int) ;
	static 	BOOL							bSkkAutoInsertParen (CImeConfig* pThis) ;
	static 	int								iSkkAssocSkkAutoParenStringAlist (CImeConfig* pThis, LPCDSTR, int, LPDSTR, int) ;
	static 	BOOL							bSkkAllowsSpacesNewlinesAndTabs (CImeConfig* pThis) ;
	static 	LPCDSTR							pGetCurrentTouten (CImeConfig* pThis, int, int*) ;
	static 	LPCDSTR							pGetCurrentKuten (CImeConfig* pThis, int, int*) ;
	static 	int								iGetNumberOfKutotens (CImeConfig* pThis) ;
	static 	BOOL							bSkkIsNewlineKakuteiAllp (CImeConfig* pThis) ;
	static 	BOOL							bSkkCompositionAutoShiftp (CImeConfig* pThis) ;
	static 	const struct CImeKeymap*		pGetMajorModeMap (CImeConfig* pThis) ;
	static 	const struct CImeKeymap*		pGetSkkJModeMap (CImeConfig* pThis) ;
	static 	const struct CImeKeymap*		pGetSkkLatinModeMap (CImeConfig* pThis) ;
	static 	const struct CImeKeymap*		pGetSkkJisx0208LatinModeMap (CImeConfig* pThis) ;
	static 	const struct CImeKeymap*		pGetSkkAbbrevModeMap (CImeConfig* pThis) ;
	static 	const struct CImeKeymap*		pGetMinibufferMinorModeMap (CImeConfig* pThis) ;
	static 	const struct MYCOLORFACESET*	pGetColorFaceSet (CImeConfig* pThis) ;
	static 	int								iGetCountHenkanShowChange (CImeConfig* pThis) ;
	static	HFONT					hGetDefaultFont (CImeConfig* pThis, HDC hDC) ;
	static	const TF_PRESERVEDKEY*	pGetToggleImeKeys (CImeConfig* pThis, UINT* pnPreservedKeys) ;
	static	const TF_PRESERVEDKEY*	pGetImeOnKeys (CImeConfig* pThis, UINT* pnPreservedKeys) ;
	static	const TF_PRESERVEDKEY*	pGetImeOffKeys (CImeConfig* pThis, UINT* pnPreservedKeys) ;

private:
	CImeConfig () ;

	BOOL					_bTSFKeyDownEatenDoesNotWorkp () const ;
	BOOL					_bKanaModeWhenOpenp () const ;
	CSkkRuleTreeNode*		_pGetSkkRuleTree (int iRule) ;
	BOOL					_bSkkKakuteiEarlyp () const ;
	BOOL					_bSkkProcessOkuriEarlyp () const ;
	BOOL					_bSkkEchop () const ;
	BOOL					_bSkkTryCompletionCharp (int) const ;
	BOOL					_bSkkPreviousCompletionCharp (int) const ;
	BOOL					_bSkkNextCompletionCharp (int) const ;
	BOOL					_bSkkAutoStartHenkanp () const ;
	BOOL					_bSkkAutoStartHenkanKeywordp (LPCDSTR, int) const ;
	BOOL					_bSkkSpecialMidashiCharp (int) const ;
	BOOL					_bSkkSetHenkanPointKeyp (int)  const ;
	void					_vMaskSkkSetHenkanPointKey (BOOL bMask) ;
	BOOL					_bSkkSetHenkanPointKeyMaskedp () const ;
	BOOL					_bSkkStartHenkanCharp (int) const ;
	int						_iSkkARefSkkKanaRomVector (int, LPDSTR, int) const ;
	int						_iGetSkkShowAnnotationType () const ;
	BOOL					_bSkkEggLikeNewline () const ;
	BOOL					_bSkkDeleteOkuriWhenQuit () const ;
	BOOL					_bSkkDeleteImplesKakuteip () const ;
	LPCDSTR					_pGetSkkHenkanShowCandidatesKeys (int*) const ;
	BOOL					_bSkkNumericConversionp () const ;
	BOOL					_bSkkNumConvertFloatp () const ;
	BOOL					_bSkkCompCirculatep () const ;
	int						_iGetSkkKcodeCharset () const ;
	LPCDSTR					_pGetSkkInputByCodeMenuKeys1 (int*) const ;
	LPCDSTR					_pGetSkkInputByCodeMenuKeys2 (int*) const ;
	int						_iGetSkkOkuriChar (LPCDSTR, int, LPDSTR, int) const ;
	BOOL					_bSkkHenkanOkuriStrictlyp () const ;
	BOOL					_bSkkHenkanStrictOkuriPrecedencep () const ;
	BOOL					_bSkkAutoOkuriProcessp () const ;
	int								_iSkkARefSkkJisx0208LatinVector (int, LPDSTR, int) const ;
	int								_iSkkRevRefSkkJisx0208LatinVector (int, LPDSTR, int) const ;
	BOOL							_bSkkAutoInsertParen () const ;
	int								_iSkkAssocSkkAutoParenStringAlist (LPCDSTR, int, LPDSTR, int) const ;
	BOOL							_bSkkAllowsSpacesNewlinesAndTabs () const ;
	LPCDSTR							_pGetCurrentTouten (int, int*) const ;
	LPCDSTR							_pGetCurrentKuten (int, int*) const ;
	int								_iGetNumberOfKutotens () const ;
	BOOL							_bSkkIsNewlineKakuteiAllp () const ;
	BOOL							_bSkkCompositionAutoShiftp () const ;
	const struct CImeKeymap*		_pGetMajorModeMap () const ;
	const struct CImeKeymap*		_pGetSkkJModeMap () const ;
	const struct CImeKeymap*		_pGetSkkLatinModeMap () const ;
	const struct CImeKeymap*		_pGetSkkJisx0208LatinModeMap () const ;
	const struct CImeKeymap*		_pGetSkkAbbrevModeMap () const ;
	const struct CImeKeymap*		_pGetMinibufferMinorModeMap () const ;
	const struct MYCOLORFACESET*	_pGetColorFaceSet () const ;
	int								_iGetCountHenkanShowChange () const ;
	HFONT					_hGetDefaultFont (HDC hdc) ;
	const TF_PRESERVEDKEY*	_pGetToggleImeKeys (UINT* pnPreservedKeys) const ;
	const TF_PRESERVEDKEY*	_pGetImeOnKeys (UINT* pnPreservedKeys) const ;
	const TF_PRESERVEDKEY*	_pGetImeOffKeys (UINT* pnPreservedKeys) const ;

	void					_vInit () ;
	void					_vUninit () ;
	void	_vLoadZenkakuVector () ;
	void	_vClearZenkakuVector () ;
	BOOL	_bLoadKeymaps () ;
	BOOL	_bLoadKeymap (HKEY hSubKey, LPCWSTR strRegistryName, LPCWSTR strRegisterExtraName, struct CImeKeymap* pKeymap) ;
	void	_vInitializeMajorModeMap () ;
	void	_vInitializeSkkJModeMap () ;
	void	_vInitializeSkkLatinModeMap () ;
	void	_vInitializeSkkJisx0208LatinModeMap () ;
	void	_vInitializeSkkAbbrevModeMap () ;
	void	_vInitializeMinibufferMinorModeMap () ;
	void	_vInitAutoStartHenkanKeywords (LPCWSTR pwText, int nTextLen) ;
	void	_vValidateKeymap (struct CImeKeymap* pKeymap) ;
	BOOL	_bDefineKey (struct CImeKeymap*	pKeymap, int nKeyCode, unsigned int uKeyMask, BOOL bExtended, int nKeyFunction) ;
	BOOL	_bLoadRomaKanaRuleList () ;
	void	_vClearRomaKanaRuleList () ;
	BOOL	_bLoadRomaKanaRuleListFromRegistry () ;
	BOOL	_bParseRomaKanaRules (CSkkRuleTreeNode** ppTree, HKEY hSubKey, LPCWSTR* ppwRuleName, int nRuleBase, int nRule) ;
	BOOL	_bParseRomaKanaRule (CSkkRuleTreeNode** ppTree, int nRuleBase, int nRule, LPCWSTR pwData, int cbData) ;
	void	_vClearKeymaps () ;
	void	_vClearKeymap (struct CImeKeymap* pKeymap) ;
	void	_InitializePreservedKeys (struct CImeKeymap* pKeymap) ;

	BOOL	_bLoadGenericSetting () ;
	BOOL	_bLoadGenericSettingFromRegistry () ;
	BOOL	_bLoadConversionSetting () ;
	BOOL	_bLoadConversionSettingFromRegistry () ;
	BOOL	_bLoadColorfaceSetting () ;
	BOOL	_bLoadColorfaceSettingFromRegistry (const MYCOLORFACESET* pDefaultColorFaces) ;
	BOOL	_bParseBSEncodedString (LPCTSTR* ppwSrc, LPTSTR pwDest, int nDestSize) ;
	int		_iDecodeStringPairList (LPCTSTR pwEncodedString, struct TStringPair* pDestBuffer, int iBufferSize) ;
	BOOL	_bInitializeDefaultRomaKanaRuleTree () ;
	void	_vInitializeDefaultFont () ;
} ;

/*========================================================================
 *	prototypes
 */

#if defined (__cplusplus)
extern "C" {
#endif

#if defined (__cplusplus)
}
#endif

