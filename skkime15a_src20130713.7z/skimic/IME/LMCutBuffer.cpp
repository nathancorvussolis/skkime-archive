// #if !defined (UNITTEST)
#include "globals.h"
// #else
// #include "StdAfx.h"
// #endif

#include "ImeDoc.h"
#include "ImeBuffer.h"
// #include "TMarker.h"	// ImeBuffer.h �ƘA��
#include "TCutBufferSession.h"
// #include "../../common/keymap.h"	// ImeBuffer.h �ƘA��

/*======================================================================== kill-ring-save
 */
int
CImeDoc::LM_bKillRingSave (
	CImeDoc*		pThis)
{
	if (! pThis->bCall (CImeDoc::LM_bKillRegion, CImeDoc::LM_bKillRingSave_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bKillRingSave_Exit (
	CImeDoc*		pThis)
{
	pThis->vJump (CImeDoc::LM_bYank) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== kill-region
 */
int
CImeDoc::LM_bKillRegion (
	CImeDoc*		pThis)
{
	CImeBuffer*	pCurBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkEnd ;
	CTMarker*		pmkTop ;
	CTMarker*		pmkMark ;
	int			nLastCmd, nBufferTop, nBufferEnd, nStart, nEnd ;
	BOOL		fAppend ;
	DCHAR		rszBuffer [MAXCOMPLEN] ;
	LPCDSTR		pwText ;
	int			nText ;
	LPCDSTR		pSrc ;
	LPDSTR		pDest ;
	int			nSrc, nDest ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL ||
		! pCurBuffer->bGetMarker (CImeBuffer::MARKER_MARK,      &pmkMark)  || pmkMark  == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= pmkTop->iGetPosition () ;
	} else {
		nBufferTop	= 0 ;
	}
	nStart			= pmkPoint->iGetPosition () ;
	nEnd			= pmkMark->iGetPosition () ;
	if (nStart > nEnd) {
		int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}

	nBufferEnd		= pmkEnd->iGetPosition () ;
	if (nStart == nEnd || nStart < nBufferTop || nEnd > nBufferEnd) {
		return	LMR_RETURN ;
	}

	nLastCmd	= pThis->iGetLastCommand () ;
	fAppend		= (nLastCmd == NFUNC_KILL_REGION)? TRUE : FALSE ;

	/*	�����ŊO�E�����ɉ��s�R�[�h�� \n �������� 0x0D, 0x0A
	 *	�ɕϊ�����K�v������B
	 */
	pwText	= pCurBuffer->pBufferRawString (&nText) ;
	if (nStart > nText || nEnd > nText) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pSrc	= pwText + nStart ;
	nSrc	= nEnd - nStart ;
	pDest	= rszBuffer ;
	nDest	= MYARRAYSIZE (rszBuffer) ;

	while (nSrc > 0 && nDest > 0) {
		if (*pSrc == L'\n') {
			/*	0x0D, 0x0A �Ƒ�������̂łȂ����
			 *	1����������Ȃ����Ƃɂ���B*/
			if (nDest > 1) {
				*pDest ++	= 0x0D ;					
				*pDest ++	= 0x0A ;
				nDest  -= 2 ;
			}
		} else {
			*pDest ++	= *pSrc ;
			nDest -- ;
		}
		pSrc ++ ;
		nSrc -- ;
	}
	if (! CTCutBufferSession::bSet (rszBuffer, pDest - rszBuffer, fAppend)) {
		/* ... */
	}
	if (! pCurBuffer->bDeleteRegion (nStart, nEnd)) {
	}
	pThis->bSetThisCommand (NFUNC_KILL_REGION) ;
	return	LMR_RETURN ;
}

/*======================================================================== yank
 */
int
CImeDoc::LM_bYank (
	CImeDoc*		pThis)
{
	CImeBuffer*	pCurBuffer ;
	DCHAR		rszBuffer [MAXCOMPLEN] ;
	LPCDSTR		pwSrc, pwSrcBase ;
	int			n ;

	/*	signal ���ݒ肳��Ă���Γ��삵�Ȃ��B
	 *	�Ƃ������A���̔���𖈉�Ă΂ꂽ���ɏ����̂͂Ȃ��c�B
	 */
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	n	= CTCutBufferSession::iGet (rszBuffer, MYARRAYSIZE (rszBuffer)) ;
	if (n > 0) {
		pwSrc	= rszBuffer ;
		while (n > 0) {
			pwSrcBase	= pwSrc ;
			while (n > 0 && *pwSrc != 0x0D) {
				pwSrc	++ ;
				n		-- ;
			}
			if (! pCurBuffer->bInsertAndInherit (pwSrcBase, pwSrc - pwSrcBase)) {
				pThis->vSetSignalError () ;
				return	LMR_RETURN ;
			}

			/*	�O�E�Ƃ̃C���^�[�t�F�[�X�ł��邱�̕����ŉ��s�R�[�h��
			 *	0x0D, 0x0A �Ƃ��Ă���ė���\��������B
			 */
			if (*pwSrc == 0x0D) {
				if (n > 1 && *(pwSrc + 1) == 0x0A) {
					while (n > 1 && *pwSrc == 0x0D && *(pwSrc + 1) == 0x0A) {
						if (! pCurBuffer->bInsertAndInherit (L"\n", 1)) {
							pThis->vSetSignalError () ;
							return	LMR_RETURN ;
						}
						pwSrc	+= 2 ;
						n		-= 2 ;
					}
				} else {
					/*	0x0D �����̏o���͂��̂܂ܒʂ��B
					 */
					if (! pCurBuffer->bInsertAndInherit (pwSrc, 1)) {
						pThis->vSetSignalError () ;
						return	LMR_RETURN ;
					}
					pwSrc	++ ;
					n		-- ;
				}
			}
		}
	}
	return	LMR_RETURN ;
}
