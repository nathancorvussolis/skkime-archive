#include "globals.h"
#include "skimic.h"
#include "dai.h"
#include "daiparam.h"

#include "../common/regpath.h"
#define	REGPATH_STYLE				REGPATH_SKKIME TEXT("\\Style")
#define	REGSUBKEY_COLORFACE			TEXT("Color")

// �ȉ���TSF�֘A�̕�����ł����ă��W�X�g���L�[�ł͂Ȃ�
#define	REGSUBKEY_VALUEINPUT		TEXT("DisplayAttributeInput")
#define	REGSUBKEY_VALUECONVERTED	TEXT("DisplayAttributeConverted")

/*========================================================================*
 */

/*	���ϊ�������B*/
const TF_DISPLAYATTRIBUTE	CDisplayAttributeInfoInput::_s_DefaultDisplayAttribute = {
	{ TF_CT_SYSCOLOR,	COLOR_WINDOWTEXT },	// text color
	{ TF_CT_NONE,		0 },				// background color (TF_CT_NONE => app default)
	TF_LS_DASH,								// underline style
	FALSE,									// underline boldness
	{ TF_CT_SYSCOLOR,	COLOR_WINDOWTEXT },	// underline color
	TF_ATTR_INPUT                           // attribute info
} ;

/*	�ϊ�������B*/
const TF_DISPLAYATTRIBUTE	CDisplayAttributeInfoConverted::_s_DefaultDisplayAttribute = {
	{ TF_CT_SYSCOLOR,	COLOR_HIGHLIGHTTEXT },
	{ TF_CT_SYSCOLOR,	COLOR_HIGHLIGHT },
	TF_LS_NONE,
	FALSE,
	{ TF_CT_NONE,		0 },
	TF_ATTR_TARGET_CONVERTED
} ;

const WCHAR	CDisplayAttributeInfoInput::_s_szDescription []	= L"SKKIME Display Attribute for input string" ;
const WCHAR	CDisplayAttributeInfoConverted::_s_szDescription []	= L"SKKIME Display Attribute for target converted string" ;

const TCHAR	CDisplayAttributeInfoInput::_s_szValueName []	= REGSUBKEY_VALUEINPUT ;
const TCHAR	CDisplayAttributeInfoConverted::_s_szValueName []	= REGSUBKEY_VALUECONVERTED ;


/*
 */
CDisplayAttributeInfo::CDisplayAttributeInfo ()
{
	DllAddRef () ;

	_pGUID						= NULL ;
	_pDefaultDisplayAttribute	= NULL ;
	_wstrDescription			= NULL ;
	_tstrValueName				= NULL ;
	_bAttr						= TF_ATTR_OTHER ;
	_nStyleOffset				= 0;

	_cRef						= 1 ;
	return ;
}

CDisplayAttributeInfo::~CDisplayAttributeInfo ()
{
	DllRelease () ;
	return ;
}

STDAPI
CDisplayAttributeInfo::QueryInterface (
	REFIID		riid,
	void**		ppvObj)
{
    if (ppvObj == NULL)
        return	E_INVALIDARG ;

    *ppvObj	= NULL ;
    if (IsEqualIID(riid, IID_IUnknown) ||
        IsEqualIID(riid, IID_ITfDisplayAttributeInfo)) {
        *ppvObj	= (ITfDisplayAttributeInfo *)this ;
    }
    if (*ppvObj) {
        AddRef () ;
        return	S_OK ;
    }
    return	E_NOINTERFACE ;
}

ULONG
CDisplayAttributeInfo::AddRef (void)
{
	return	++ _cRef ;
}

ULONG
CDisplayAttributeInfo::Release (void)
{
	LONG	cr	= -- _cRef ;

	assert (_cRef >= 0) ;
	if (_cRef == 0)
		delete	this ;
	return	cr ;
}

STDAPI
CDisplayAttributeInfo::GetGUID (
	GUID*	pguid)
{
    if (pguid == NULL)
        return	E_INVALIDARG ;
	if (_pGUID == NULL)
		return	E_FAIL ;

    *pguid	= *_pGUID ;
    return	S_OK ;
}

STDAPI
CDisplayAttributeInfo::GetDescription (
	BSTR*	pbstrDesc)
{
    BSTR	bstrDesc ;

	DEBUGPRINTF ((TEXT ("CDisplayAttributeInfo::GetDescription ()\n"))) ;

    if (pbstrDesc == NULL)
        return	E_INVALIDARG ;
	if (_wstrDescription == NULL)
		return	E_FAIL ;

    *pbstrDesc	= NULL ;
    if ((bstrDesc = SysAllocString(_wstrDescription)) == NULL)
        return	E_OUTOFMEMORY ;

    *pbstrDesc	= bstrDesc ;
    return	S_OK ;
}

STDAPI
CDisplayAttributeInfo::GetAttributeInfo (
	TF_DISPLAYATTRIBUTE*	ptfDisplayAttr)
{
	HKEY	hSubKey ;
	BYTE	rbyStyle [SIZE_SKKIME_COLORFACE * NITEM_SKKIME_COLORFACE] ;
	BOOL	fFound	= FALSE ;

	DEBUGPRINTF ((TEXT ("CDisplayAttributeInfo::GetAttributeInfo (%s)\n"), _tstrValueName)) ;

    if (ptfDisplayAttr == NULL)
        return	E_INVALIDARG ;
	if (_tstrValueName == NULL || _pDefaultDisplayAttribute == NULL)
		return	E_FAIL ;

	/*[���j]
	 *	�܂� Text Service Framework ���̐F�ݒ肪���邩�ǂ������`�F�b�N����B
	 *	���݂��Ȃ���΁ASKKIME ���̐ݒ��Ⴄ�B
	 *	������Ȃ���΁Adefault �𗘗p����B
	 */

	/*	Text Service Framework ���̐F�ݒ�B
	 */
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_STYLE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;

		/*	Text Service Framework ���̓Ǝ��̐F�ݒ�𔲂��o���B
		 */
		cbData	= sizeof (*ptfDisplayAttr) ;
		if (RegQueryValueEx (hSubKey, _tstrValueName, NULL, &dwType, (LPBYTE) ptfDisplayAttr, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == sizeof (*ptfDisplayAttr)) {
			DEBUGPRINTF ((TEXT ("CDisplayAttributeInfo::GetAttributeInfo: find original one.\n"))) ;
			fFound	= TRUE ;
			goto	skip ;
		}

		/*	SKKIME ���̐F�ݒ�𔲂��o���B
		 */
		cbData	= sizeof (rbyStyle) ;
		if (RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, rbyStyle, &cbData) == ERROR_SUCCESS &&
			dwType == REG_BINARY &&
			cbData == sizeof (rbyStyle)) {
			DEBUGPRINTF ((TEXT ("CDisplayAttributeInfo::GetAttributeInfo: find skkime one.\n"))) ;
			_ConvertSkkImeColorFace2TfDisplayAttribute (ptfDisplayAttr, rbyStyle + _nStyleOffset) ;
			ptfDisplayAttr->bAttr	= _bAttr ;
			fFound	= TRUE ;
			goto	skip ;
		}
	  skip:
		RegCloseKey (hSubKey) ;
	}
	if (! fFound) {
		DEBUGPRINTF ((TEXT ("CDisplayAttributeInfo::GetAttributeInfo: default value.\n"))) ;
		*ptfDisplayAttr	= *_pDefaultDisplayAttribute ;
	}
    return	S_OK ;
}

STDAPI
CDisplayAttributeInfo::SetAttributeInfo (
	const TF_DISPLAYATTRIBUTE*	ptfDisplayAttr)
{
    HKEY	hKeyAttributeInfo;
    LONG	lResult;

	DEBUGPRINTF ((TEXT ("CDisplayAttributeInfo::SetAttributeInfo ()\n"))) ;

	if (ptfDisplayAttr == NULL)
		return	E_INVALIDARG ;

    lResult	= RegCreateKeyEx (HKEY_CURRENT_USER, REGPATH_STYLE, 0, TEXT(""), REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &hKeyAttributeInfo, NULL) ;
    if (lResult != ERROR_SUCCESS)
        return	E_FAIL ;

    lResult = RegSetValueEx (hKeyAttributeInfo, _tstrValueName, 0, REG_BINARY, (const BYTE *)ptfDisplayAttr, sizeof (*ptfDisplayAttr)) ;
    RegCloseKey (hKeyAttributeInfo) ;

    return	(lResult == ERROR_SUCCESS) ? S_OK : E_FAIL ;
}

STDAPI
CDisplayAttributeInfo::Reset()
{
	DEBUGPRINTF ((TEXT ("CDisplayAttributeInfo::Reset() \n"))) ;

	if (_pDefaultDisplayAttribute == NULL)
		return	E_FAIL ;

    return	SetAttributeInfo (_pDefaultDisplayAttribute) ;
}

/*	SKKIME ���̐ݒ�� skimic ���̐ݒ�ɕϊ�����B
 */
BOOL
CDisplayAttributeInfo::_ConvertSkkImeColorFace2TfDisplayAttribute (
	TF_DISPLAYATTRIBUTE*	pAttr,
	LPBYTE					pData)
{
	_ConvertSkkImeColor2TfDaColor (&pAttr->crText, *pData ++) ;
	_ConvertSkkImeColor2TfDaColor (&pAttr->crBk,   *pData ++) ;
	_ConvertSkkImeColor2TfDaColor (&pAttr->crLine, *pData ++) ;
	_ConvertSkkImeLineStyle2TfDaLineStyle (&pAttr->lsStyle, &pAttr->fBoldLine, *pData ++) ;
	return	TRUE ;
}

BOOL
CDisplayAttributeInfo::_ConvertSkkImeColor2TfDaColor (
	TF_DA_COLOR*			pColor,
	int						nType)
{
	static	struct {
		TF_DA_COLORTYPE _nType ;
		int				_nIndex ;
		COLORREF		_cr ;
	}	srColorTable []	= {
		{	TF_CT_NONE,		0,	PALETTERGB (0,   0,   0) },
		{	TF_CT_NONE,		0,	PALETTERGB (0,   0,   0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (0,   0,   0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (128, 0,   0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (0,   128, 0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (128, 128, 0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (0,   0,   128) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (128, 0,   128) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (0,   128, 128) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (128, 128, 128) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (192, 192, 192) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (255, 0,   0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (0,   255, 0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (255, 255, 0) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (0,   0,   255) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (255, 0,   255) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (0,   255, 255) },
		{	TF_CT_COLORREF,	0,	PALETTERGB (255, 255, 255) },
		{	TF_CT_SYSCOLOR,	COLOR_BTNFACE,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_BTNTEXT,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_ACTIVEBORDER,	PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_ACTIVECAPTION,PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_CAPTIONTEXT,	PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_APPWORKSPACE,	PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_WINDOW,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_WINDOWTEXT,	PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_DESKTOP,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_INFOBK,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_INFOTEXT,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_WINDOWTEXT,	PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_MENU,			PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_MENUTEXT,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_HIGHLIGHTTEXT,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_HIGHLIGHT,			PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_INACTIVEBORDER,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_INACTIVECAPTION,		PALETTERGB (0, 0, 0) },
		{	TF_CT_SYSCOLOR,	COLOR_INACTIVECAPTIONTEXT,	PALETTERGB (0, 0, 0) },
	} ;

	DEBUGPRINTF ((TEXT ("_ConvertSkkImeColor2TfDaColor (type:%d)\n"), nType)) ;

	if (nType < 0 || nType >= MYARRAYSIZE (srColorTable))
		return	FALSE ;

	pColor->type	= srColorTable [nType]._nType ;
	if (srColorTable [nType]._nType == TF_CT_COLORREF) {
		pColor->cr		= srColorTable [nType]._cr ;
	} else {
		pColor->nIndex	= srColorTable [nType]._nIndex ;
	}
	return	TRUE ;
}

BOOL
CDisplayAttributeInfo::_ConvertSkkImeLineStyle2TfDaLineStyle(
	TF_DA_LINESTYLE*	pLineStyle,
	BOOL*				pfBoldLine,
	int					nLineType)
{
	DEBUGPRINTF ((TEXT ("_ConvertSkkImeLineStyle2TfDaLineStyle (type:%d)\n"), nLineType)) ;

	switch (nLineType) {
	case	MYLINE_SOLID:
		*pLineStyle	= TF_LS_SOLID ;
		*pfBoldLine	= FALSE ;
		break ;
	case	MYLINE_THICK_SOLID:
		*pLineStyle	= TF_LS_SOLID ;
		*pfBoldLine	= TRUE ;
		break ;
	case	MYLINE_DOTTED:
		*pLineStyle	= TF_LS_DOT ;
		*pfBoldLine	= FALSE ;
		break ;
	case	MYLINE_THIN_DITHER:
		*pLineStyle	= TF_LS_DASH ;
		*pfBoldLine	= FALSE ;
		break ;
	case	MYLINE_THICK_DITHER:
		*pLineStyle	= TF_LS_DASH ;
		*pfBoldLine	= TRUE ;
		break ;
	case	MYLINE_NO:
	default:
		*pLineStyle	= TF_LS_NONE ;
		*pfBoldLine	= FALSE ;
		break ;
	}
	return	TRUE ;
}

