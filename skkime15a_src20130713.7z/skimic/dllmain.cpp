//
// dllmain.cpp
//
// DllMain module entry point.
//

#include "globals.h"

//+---------------------------------------------------------------------------
//
// DllMain
//
//----------------------------------------------------------------------------

BOOL WINAPI
DllMain (
	HINSTANCE	hInstance,
	DWORD		dwReason,
	LPVOID		pvReserved)
{
    switch (dwReason) {
	case DLL_PROCESS_ATTACH:
// dp("skimic: process attach %p\n", hInstance);
		g_hInst	= hInstance ;
		if (!InitializeCriticalSectionAndSpinCount(&g_cs, 0))
			return	FALSE ;
		break ;

	case DLL_PROCESS_DETACH:
// dp("skimic: process detach\n");
		DeleteCriticalSection (&g_cs) ;
		break ;
    }
    return	TRUE ;

	UNREFERENCED_PARAMETER (pvReserved) ;
}
