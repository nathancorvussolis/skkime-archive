/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Ui.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"
#include "skksubs.h" 

/*
 *	�v���g�^�C�v�錾�B
 */
static	void	PASCAL	ShowUIWindows (HWND hWnd, BOOL fFlag) ;
static	LRESULT	PASCAL	OnImeSetContext (HIMC hUICurIMC, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
static	LRESULT	PASCAL	OnImeSelect (HIMC hUICurIMC, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
#ifdef DEBUG
static	void	PASCAL	DumpUIExtra (LPUIEXTRA lpUIExtra) ;
#endif

#define CS_SKKIME98	(CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS | CS_IME)

/*************************************************************************
 *
 * IMERegisterClass()
 *
 * This function is called by IMMInquire.
 *	Register the classes for the child windows.
 *	Create global GDI objects.
 *
 *************************************************************************/
BOOL	PASCAL	IMERegisterClass (HANDLE hInstance)
{
	WNDCLASSEX wc ;

	/*
	 * register class of UI window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME98 ;
	wc.lpfnWndProc		= SKKIME98WndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= 8 ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPSTR)NULL ;
	wc.lpszClassName	= (LPSTR)szUIClassName ;
	wc.hbrBackground	= NULL ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	/*
	 * register class of composition window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME98 ;
	wc.lpfnWndProc		= CompStrWndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UIEXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPSTR)NULL ;
	wc.lpszClassName	= (LPSTR)szCompStrClassName ;
	wc.hbrBackground	= (HBRUSH)(COLOR_WINDOW + 1) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	/*
	 * register class of composition window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME98 ;
	wc.lpfnWndProc		= MinibufWndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UIEXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPSTR)NULL ;
	wc.lpszClassName	= (LPSTR)szMinibufClassName ;
	wc.hbrBackground	= (HBRUSH)(COLOR_WINDOW + 1) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	/*
	 * register class of candidate window.
	 */
	wc.cbSize			= sizeof(WNDCLASSEX) ;
	wc.style			= CS_SKKIME98 ;
	wc.lpfnWndProc		= CandWndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UIEXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPSTR)NULL ;
	wc.lpszClassName	= (LPSTR)szCandClassName ;
	wc.hbrBackground	= GetStockObject (LTGRAY_BRUSH) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return FALSE;

	/*
	 * register class of status window.
	 */
	wc.cbSize			= sizeof(WNDCLASSEX) ;
	wc.style			= CS_SKKIME98 ;
	wc.lpfnWndProc		= StatusWndProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= UIEXTRASIZE ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPSTR)NULL ;
	wc.lpszClassName	= (LPSTR)szStatusClassName ;
	wc.hbrBackground	= NULL ;
	wc.hbrBackground	= (HBRUSH)GetStockObject(LTGRAY_BRUSH) ;
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	/*
	 * register class of guideline window.
	 */
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_SKKIME98 ;
	wc.lpfnWndProc		= GuideWndProc ;
	wc.cbClsExtra	 	= 0 ;
	wc.cbWndExtra	 	= UIEXTRASIZE;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPSTR)NULL ;
	wc.lpszClassName	= (LPSTR)szGuideClassName ;
	wc.hbrBackground	= NULL ;
	/*wc.hbrBackground	= GetStockObject (LTGRAY_BRUSH) ;*/
	wc.hIconSm			= NULL ;

	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;

	return	TRUE ;
}

/*************************************************************************
 *
 * SKKIME98WndProc()
 *
 * IME UI window procedure
 *
 *************************************************************************/
LRESULT	CALLBACK	SKKIME98WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HIMC			hUICurIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPUIEXTRA		lpUIExtra ;
	HGLOBAL			hUIExtra ;
	LONG			lRet		= 0L ;
	int				i ;
	LOGFONT			lf ;

	hUICurIMC	= (HIMC)GetWindowLong (hWnd, IMMGWL_IMC) ;
#if defined (DEBUG)
	DebugTextOut (0, 20, MYTEXT ("SKKIME98WndProc... HWND: %lx, Msg: %lx, WPARAM: %lx, LPARAM: %lx"), 
				  hWnd, message, wParam, lParam) ;
#endif
	/*
	 * Even if there is no current UI. these messages should not be pass to 
	 * DefWindowProc().
	 */
	if (!hUICurIMC){
		switch (message){
		case WM_IME_STARTCOMPOSITION:
		case WM_IME_ENDCOMPOSITION:
		case WM_IME_COMPOSITION:
		case WM_IME_CONTROL:
		case WM_IME_COMPOSITIONFULL:
		case WM_IME_SELECT:
		case WM_IME_CHAR:
			return	0L ;
		case WM_IME_NOTIFY:
			return	OnUINotifyCommand (hUICurIMC, hWnd, message, wParam, lParam) ;
		default:
			break ;
		}
	}

	switch (message){
	case WM_CREATE:
		/*
		 * Allocate UI's extra memory block.
		 */
		hUIExtra	= GlobalAlloc (GHND, sizeof(UIEXTRA)) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;

		/*
		 * Initialize the extra memory block.
		 */
		lpUIExtra->uiStatus.pt.x	= -1 ;
		lpUIExtra->uiStatus.pt.y	= -1 ;
		lpUIExtra->uiDefComp.pt.x	= -1 ;
		lpUIExtra->uiDefComp.pt.y	= -1 ;
		lpUIExtra->uiCand.pt.x		= -1 ;
		lpUIExtra->uiCand.pt.y		= -1 ;
		lpUIExtra->uiMinibuf.pt.x	= -1 ;
		lpUIExtra->uiMinibuf.pt.y	= -1 ;
		lpUIExtra->uiGuide.pt.x		= -1 ;
		lpUIExtra->uiGuide.pt.y		= -1 ;
		lpUIExtra->hFont			= (HFONT)NULL ;
		GlobalUnlock (hUIExtra) ;
		SetWindowLong (hWnd, IMMGWL_PRIVATE, (DWORD)hUIExtra) ;
		break ;

	case WM_IME_SETCONTEXT:
		return	OnImeSetContext (hUICurIMC, hWnd, message, wParam, lParam) ;

	case WM_IME_STARTCOMPOSITION:
		//
		// Start composition! Ready to display the composition string.
		//
		hUIExtra	= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpIMC		= ImmLockIMC (hUICurIMC) ;
		if (!lpUIExtra->hFont){
#ifdef SKKIME98M
			lf.lfHeight			= lpIMC->lfFont.W.lfHeight ;
			lf.lfWidth			= lpIMC->lfFont.W.lfWidth ;
			lf.lfEscapement		= lpIMC->lfFont.W.lfEscapement ;
			lf.lfOrientation	= lpIMC->lfFont.W.lfOrientation ;
			lf.lfWeight			= lpIMC->lfFont.W.lfWeight ;
			lf.lfItalic			= lpIMC->lfFont.W.lfItalic ;
			lf.lfUnderline		= lpIMC->lfFont.W.lfUnderline ;
			lf.lfStrikeOut		= lpIMC->lfFont.W.lfStrikeOut ;
			lf.lfCharSet		= lpIMC->lfFont.W.lfCharSet ;
			lf.lfOutPrecision	= lpIMC->lfFont.W.lfOutPrecision ;
			lf.lfClipPrecision	= lpIMC->lfFont.W.lfClipPrecision ;
			lf.lfQuality		= lpIMC->lfFont.W.lfQuality ;
			lf.lfPitchAndFamily	= lpIMC->lfFont.W.lfPitchAndFamily ;
			i = MystrToShiftJis (lf.lfFaceName,					LF_FACESIZE,
								 lpIMC->lfFont.W.lfFaceName,	LF_FACESIZE) ;
			lf.lfFaceName [i]	= _T ('\0') ;
#else
			lf	= lpIMC->lfFont.A ;
#endif
			if (lf.lfEscapement == 2700){
				lpUIExtra->bVertical	= TRUE ;
			} else {
				lf.lfEscapement			= 0 ;
				lpUIExtra->bVertical	= FALSE ;
			}
			lpUIExtra->hFont	= CreateFontIndirect ((LPLOGFONT)&lf) ;
			SetFontCompWindow (lpUIExtra) ;
		}
		CreateCompWindow (hWnd, lpUIExtra, lpIMC) ;
		CreateMinibufWindow (hWnd, lpUIExtra, lpIMC) ;
		ImmUnlockIMC (hUICurIMC) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_IME_COMPOSITION:
		/*
		 * Update to display the composition string.
		 */
		lpIMC		= ImmLockIMC (hUICurIMC) ;
		hUIExtra	= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		MoveCompWindow (hWnd, lpUIExtra, lpIMC) ;
		MoveCandWindow (hWnd, lpIMC, lpUIExtra, TRUE) ;
		MoveMinibufWindow (hWnd, lpUIExtra, lpIMC) ;
		GlobalUnlock (hUIExtra) ;
		ImmUnlockIMC (hUICurIMC) ;
		break ;

	case WM_IME_ENDCOMPOSITION:
		/*
		 * Finish to display the composition string.
		 */
		hUIExtra	= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		HideCompWindow (lpUIExtra) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_IME_COMPOSITIONFULL:
		break ;

	case WM_IME_SELECT:
		return	OnImeSelect (hUICurIMC, hWnd, message, wParam, lParam) ;

	case WM_IME_CONTROL:
		lRet = ControlCommand (hUICurIMC, hWnd, message, wParam, lParam) ;
		break;


	case WM_IME_NOTIFY:
		return	OnUINotifyCommand (hUICurIMC, hWnd, message, wParam, lParam) ;

	case WM_DESTROY:
		lpIMC		= ImmLockIMC (hUICurIMC) ;
		SKKClearPrivate (lpIMC) ;
		ImmUnlockIMC (hUICurIMC) ;

		hUIExtra	= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;

		if (IsWindow (lpUIExtra->uiStatus.hWnd))
			DestroyWindow (lpUIExtra->uiStatus.hWnd) ;

		if (IsWindow (lpUIExtra->uiCand.hWnd))
			DestroyWindow (lpUIExtra->uiCand.hWnd) ;

		if (IsWindow (lpUIExtra->uiDefComp.hWnd))
			DestroyWindow (lpUIExtra->uiDefComp.hWnd) ;

		for (i = 0 ; i < MAXCOMPWND ; i++){
			if (IsWindow(lpUIExtra->uiComp[i].hWnd))
				DestroyWindow(lpUIExtra->uiComp[i].hWnd) ;
		}
		if (IsWindow (lpUIExtra->uiMinibuf.hWnd))
			DestroyWindow (lpUIExtra->uiMinibuf.hWnd) ;

		if (IsWindow (lpUIExtra->uiGuide.hWnd))
			DestroyWindow (lpUIExtra->uiGuide.hWnd) ;

		if (lpUIExtra->hFont)
			DeleteObject (lpUIExtra->hFont) ;

		GlobalUnlock (hUIExtra) ;
		GlobalFree (hUIExtra) ;
		break ;

	case WM_UI_STATEHIDE:
		hUIExtra					= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra					= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		if (IsWindow (lpUIExtra->uiStatus.hWnd))
			ShowWindow (lpUIExtra->uiStatus.hWnd, SW_HIDE) ;
		lpUIExtra->uiStatus.bShow	= FALSE ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_STATEMOVE:
		hUIExtra					= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra					= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->uiStatus.pt.x	= (long)LOWORD(lParam) ;
		lpUIExtra->uiStatus.pt.y	= (long)HIWORD(lParam) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_DEFCOMPMOVE:
		//
		// Set the position of the composition window to UIExtra.
		// This message is sent by the composition window.
		//
		hUIExtra	= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		if (!lpUIExtra->dwCompStyle){
			lpUIExtra->uiDefComp.pt.x = (long)LOWORD(lParam);
			lpUIExtra->uiDefComp.pt.y = (long)HIWORD(lParam);
		}
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_CANDMOVE:
		//
		// Set the position of the candidate window to UIExtra.
		// This message is sent by the candidate window.
		//
		hUIExtra				= (HGLOBAL)GetWindowLong(hWnd,IMMGWL_PRIVATE);
		lpUIExtra				= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->uiCand.pt.x	= (long)LOWORD(lParam) ;
		lpUIExtra->uiCand.pt.y	= (long)HIWORD(lParam) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	case WM_UI_GUIDEMOVE:
		//
		// Set the position of the status window to UIExtra.
		// This message is sent by the status window.
		//
		hUIExtra				= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
		lpUIExtra				= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->uiGuide.pt.x	= (long)LOWORD (lParam) ;
		lpUIExtra->uiGuide.pt.y	= (long)HIWORD (lParam) ;
		GlobalUnlock (hUIExtra) ;
		break ;

	default:
		if (!MyIsIMEMessage (message))
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	lRet ;
}

#define lpcfCandForm ((LPCANDIDATEFORM)lParam)
LONG	PASCAL	ControlCommand (HIMC hUICurIMC, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LONG			lRet	= 1L ;
	LPINPUTCONTEXT	lpIMC ;
	HGLOBAL			hUIExtra ;
	LPUIEXTRA		lpUIExtra ;
	LOGFONT			lf ;

	if (!(lpIMC = ImmLockIMC(hUICurIMC)))
		return	1L ;

	hUIExtra	= (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE) ;
	lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra);
#if defined (DEBUG)
	DebugTextOut (0, 60, MYTEXT ("WM_IME_CONTROL: %lx, %lx, %lx"), message, wParam, lParam) ;
#endif
	switch (wParam){
	case IMC_GETCANDIDATEPOS:
		if (IsWindow(lpUIExtra->uiCand.hWnd)){
			/* SKKIME98 has only one candidate list. */
			*(LPCANDIDATEFORM)lParam	= lpIMC->cfCandForm [0] ; 
			lRet						= 0 ;
		}
		break;

	case IMC_GETCOMPOSITIONWINDOW:
		*(LPCOMPOSITIONFORM)lParam	= lpIMC->cfCompForm ;
		lRet						= 0 ;
		break ;

	case IMC_GETSTATUSWINDOWPOS:
		lRet	= (lpUIExtra->uiStatus.pt.x  << 16) & lpUIExtra->uiStatus.pt.x ;
		break ;

	default:
		break ;
	}
	GlobalUnlock (hUIExtra) ;
	ImmUnlockIMC (hUICurIMC) ;
	return lRet ;
}

/*************************************************************************
 *	WM_IME_SETCONTEXT
 *------------------------------------------------------------------------
 *		WM_IME_SETCONTEXT ���b�Z�[�W�̓A�v���P�[�V�����E�B���h�E���A�N�e�B
 *		�u�ɂȂ낤�Ƃ��鎞�ɃA�v���P�[�V�����֑����܂��B�����A�v���P�[
 *		�V������ IME �E�B���h�E�������Ă��Ȃ���΁A�A�v���P�[�V�����͂���
 *		���b�Z�[�W�� DefWindowProc �ɓn���Ȃ���΂Ȃ�܂���B�����āA
 *		DefWindowProc �̕Ԃ�l��Ԃ��Ȃ���΂Ȃ�܂���B
 *		�����A�v���P�[�V������ IME �E�B���h�E�������Ă���΁A�A�v���P�[�V��
 *		���� ImmIsUIMessage ���Ă΂Ȃ���΂Ȃ�܂���B
 *
 *		WM_IME_SETCONTEXT �́A
 *			fSet		= (BOOL)wParam ;
 *			lISCBits	= lParam ;
 *		(�p�����[�^)
 *			fSet
 *				�A�v���P�[�V������Input Context ���A�N�e�B�u�ɂȂ鎞�� fSet
 *				�� TRUE�̒l�����܂��BFALSE �̎���Input Context �͔�A�N�e�B
 *				�u�ɂȂ�܂��B
 *			lISCBits
 *				���̃r�b�g�̑g�ݍ��킹����Ȃ�܂��B
 *				+-----------------------------------+--------------------------------
 *				|�l									|�Ӗ�
 *				|ISC_SHOWUICOMPOSITIONWINDOW		|Composition Window ��\�����܂��B
 *				|ISC_SHOWUIGUIDWINDOW				|Guide Window ��\�����܂��B
 *				|ISC_SHOWUICANDIDATEWINDOW			|Candidate Window Index 0 ��\�����܂��B
 *				|(ISC_SHOWUICANDIDATEWINDOW << 1)	|Candidate Window Index 1 ��\�����܂��B
 *				|(ISC_SHOWUICANDIDATEWINDOW << 2)	|Candidate Window Index 2 ��\�����܂��B
 *				|(ISC_SHOWUICANDIDATEWINDOW << 3)	|Candidate Window Index 3 ��\�����܂��B
 *		(�Ԃ�l)
 *			�Ԃ�l�� DefWindowProc �܂��� ImmIsUIMessage �̕Ԃ�l�ɂȂ��
 *			���B
 *		(�R�����g)
 *			�A�v���P�[�V������ DefWindowProc (���� ImmIsUIMessage)���Ăяo��
 *			����ŁAUI window �� WM_IME_SETCONTEXT ���󂯎��܂��B�����r�b
 *			�g�� ON �Ȃ�AUI window ��lParam �̃r�b�g�̏�Ԃɏ]����
 *			composition, guide, candidate window ��\�����Ȃ���΂Ȃ�܂���B
 *			�����A�v���P�[�V�������g�� composition window ��`���Ă���̂ł�
 *			����AUI window �� composition window ��\������K�v�͂���܂���B
 *			�A�v���P�[�V�����͂��̎� ISC_SHOWUICOMPOSITIONWINDOW �r�b�g���N��
 *			�A���Ă���ADefWindowProc �������� ImmIsUIMessage ���Ă΂Ȃ����
 *			�Ȃ�܂���B
 *************************************************************************/
LRESULT	PASCAL	OnImeSetContext (HIMC hUICurIMC, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LPINPUTCONTEXT		lpIMC ;
	LPUIEXTRA			lpUIExtra ;
	HGLOBAL				hUIExtra ;
	LPINPUTCONTEXT		lpIMCT ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	LPCANDIDATEINFO		lpCandInfo ;

	lpIMCT		= NULL ;
	hUIExtra	= (HGLOBAL)GetWindowLong (hwnd, IMMGWL_PRIVATE) ;
	lpUIExtra	= (LPUIEXTRA)GlobalLock (hUIExtra) ;
	if (wParam){
		lpUIExtra->hIMC	= hUICurIMC ;
		if (hUICurIMC){
			lpIMC	= ImmLockIMC (hUICurIMC) ;
			if (lpIMC){
				lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
				lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
				if (IsWindow (lpUIExtra->uiCand.hWnd))
					HideCandWindow (lpUIExtra) ;
				if (lParam & ISC_SHOWUICANDIDATEWINDOW){
					if (lpCandInfo->dwCount){
						CreateCandWindow (hwnd, lpUIExtra, lpIMC) ;
						MoveCandWindow (hwnd, lpIMC, lpUIExtra, FALSE) ;
					}
				}
				if (IsWindow (lpUIExtra->uiDefComp.hWnd))
					HideCompWindow (lpUIExtra) ;
				if (lParam & ISC_SHOWUICANDIDATEWINDOW){
					if (lpCompStr->dwCompStrLen){
						CreateCompWindow (hwnd, lpUIExtra, lpIMC) ;
						MoveCompWindow (hwnd, lpUIExtra, lpIMC) ;
					}
					if (((LPMYCOMPSTR)lpCompStr)->dwMinibufStrLen > 0){
						CreateMinibufWindow (hwnd, lpUIExtra, lpIMC) ;
						MoveMinibufWindow (hwnd, lpUIExtra, lpIMC) ;
					}
				}
				ImmUnlockIMCC (lpIMC->hCompStr) ;
				ImmUnlockIMCC (lpIMC->hCandInfo) ;
			} else {
				HideCandWindow (lpUIExtra) ;
				HideCompWindow (lpUIExtra) ;
				HideMinibufWindow (lpUIExtra) ;
			}
			UpdateStatusWindow (lpUIExtra) ;
			ImmUnlockIMC (hUICurIMC) ;
		} else {
			HideCandWindow (lpUIExtra) ;
			HideCompWindow (lpUIExtra) ;
			HideMinibufWindow (lpUIExtra) ;
			UpdateStatusWindow (lpUIExtra) ;
		}
		UpdateIndicIcon (hUICurIMC) ;
	} else {
		HideCandWindow (lpUIExtra) ;
		HideCompWindow (lpUIExtra) ;
		HideMinibufWindow (lpUIExtra) ;
	}
	GlobalUnlock (hUIExtra) ;
	return	0L ;
}

/*************************************************************************
 *	WM_IME_SELECT
 *		WM_IME_SELECT ���b�Z�[�W�̓V�X�e���� current IME ��ύX���悤�Ƃ�
 *		�鎞�� UI window �ɑ����܂��B
 *	WM_IME_SELECT
 *		fSelect	= (BOOL)wParam ;
 *		hKL		= lParam ;
 *	(�p�����[�^)
 *		fSelect
 *			���� IME ���V�����I�������̂Ȃ� TRUE�B�����Ȃ��΁A����IME��
 *			�I������O�����̂Ȃ�FALSE�B
 *		hKL
 *			IME �� Input language handle
 *	(�Ԃ�l)
 *		�Ȃ�
 *	(�R�����g)
 *		�V�X�e��IME class �͂��̃��b�Z�[�W��V���� UI window ���������
 *		�Â� UI window ��j������̂Ɏg���܂��BDefWindowProc �͂��̃��b
 *		�Z�[�W���������Ă��̏��� default IME window �ɓn���܂��B
 *		default IME window �͂��̃��b�Z�[�W�� UI window �ɑ���܂��B
 *************************************************************************/
LRESULT	PASCAL	OnImeSelect (HIMC hUICurIMC, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LPINPUTCONTEXT	lpIMC ;
	LPUIEXTRA		lpUIExtra ;
	HGLOBAL			hUIExtra ;
	if (wParam){
		hUIExtra		= (HGLOBAL)GetWindowLong (hwnd, IMMGWL_PRIVATE) ;
		lpUIExtra		= (LPUIEXTRA)GlobalLock (hUIExtra) ;
		lpUIExtra->hIMC = hUICurIMC ;
		GlobalUnlock (hUIExtra) ;
	} else {
		ShowUIWindows (hwnd, FALSE) ; /* ? */
	}
	return	0L ;
}

/*
 *	Composition Font �̃��g���b�N�𓾂�֐��B
 *-----
 */
BOOL	PASCAL	GetCompFontMetrics (LPUIEXTRA lpUIExtra, LPTEXTMETRIC lpTextMetric)
{
	HDC		hIC ;
	HFONT	hOldFont	= 0 ;
	SIZE	sz ;
	BOOL	fRetvalue ;
	/* Device Context ���쐬����B*/
	hIC = CreateIC ("DISPLAY", NULL, NULL, NULL) ;
	if (!hIC)
		return	FALSE ;
	if (lpUIExtra->hFont)
		hOldFont	= SelectObject (hIC, lpUIExtra->hFont) ;
	fRetvalue	= GetTextMetrics (hIC, lpTextMetric) ;
	if (hOldFont)
		SelectObject (hIC, hOldFont) ;
	DeleteDC (hIC) ;
	return	fRetvalue ;
}

/*************************************************************************
 *
 * DrawUIBorder()
 *
 * When draging the child window, this function draws the border.
 *
 *************************************************************************/
void	PASCAL	DrawUIBorder (LPRECT lprc)
{
	HDC	hDC ;
	int	sbx, sby ;

	hDC = CreateDC( "DISPLAY", NULL, NULL, NULL );
	SelectObject( hDC, GetStockObject( GRAY_BRUSH ) );
	sbx = GetSystemMetrics( SM_CXBORDER );
	sby = GetSystemMetrics( SM_CYBORDER );
	PatBlt (hDC, lprc->left, 
				 lprc->top, 
				 lprc->right - lprc->left-sbx, 
				 sby, PATINVERT );
	PatBlt (hDC, lprc->right - sbx, 
				 lprc->top, 
				 sbx, 
				 lprc->bottom - lprc->top-sby, PATINVERT );
	PatBlt (hDC, lprc->right, 
				 lprc->bottom-sby, 
				 -(lprc->right - lprc->left-sbx), 
				 sby, PATINVERT );
	PatBlt (hDC, lprc->left, 
				 lprc->bottom, 
				 sbx, 
				 -(lprc->bottom - lprc->top-sby), PATINVERT );
	DeleteDC (hDC) ;
	return ;
}

/*************************************************************************
 *
 *	DragUI(hWnd,message,wParam,lParam)
 *
 *	Handling mouse messages for the child windows.
 *
 *************************************************************************/
void	PASCAL	DragUI (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT	 pt;
	static	POINT ptdif;
	static	RECT drc;
	static	RECT rc;
	DWORD  dwT;

	switch (message){
	case WM_SETCURSOR:
		if (HIWORD(lParam) == WM_LBUTTONDOWN || HIWORD(lParam) == WM_RBUTTONDOWN){
			GetCursorPos (&pt) ;
			SetCapture (hWnd) ;
			GetWindowRect (hWnd, &drc) ;
			ptdif.x		= pt.x - drc.left ;
			ptdif.y		= pt.y - drc.top ;
			rc			= drc ;
			rc.right	-= rc.left ;
			rc.bottom	-= rc.top ;
			SetWindowLong(hWnd,FIGWL_MOUSE,FIM_CAPUTURED) ;
		}
		break ;

	case WM_MOUSEMOVE:
		dwT = GetWindowLong(hWnd,FIGWL_MOUSE);
		if (dwT & FIM_MOVED){
			DrawUIBorder (&drc) ;
			GetCursorPos (&pt) ;
			drc.left	= pt.x - ptdif.x ;
			drc.top		= pt.y - ptdif.y ;
			drc.right	= drc.left + rc.right ;
			drc.bottom	= drc.top + rc.bottom ;
			DrawUIBorder(&drc);
		} else if (dwT & FIM_CAPUTURED){
			DrawUIBorder(&drc);
			SetWindowLong(hWnd,FIGWL_MOUSE,dwT | FIM_MOVED);
		}
		break;

	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		dwT = GetWindowLong(hWnd,FIGWL_MOUSE);

		if (dwT & FIM_CAPUTURED){
			ReleaseCapture();
			if (dwT & FIM_MOVED){
				DrawUIBorder(&drc);
				GetCursorPos( &pt );
				MoveWindow(hWnd,pt.x - ptdif.x,
								pt.y - ptdif.y,
								rc.right,
								rc.bottom,TRUE);
			}
		}
	default:
		break ;
	}
	return ;
}

/*************************************************************************
 *
 *	MyIsIMEMessage(message)
 *
 * Any UI window should not pass the IME messages to DefWindowProc. 
 *
 *************************************************************************/
BOOL PASCAL MyIsIMEMessage(UINT message)
{
	switch(message){
	case WM_IME_STARTCOMPOSITION:
	case WM_IME_ENDCOMPOSITION:
	case WM_IME_COMPOSITION:
	case WM_IME_NOTIFY:
	case WM_IME_SETCONTEXT:
	case WM_IME_CONTROL:
	case WM_IME_COMPOSITIONFULL:
	case WM_IME_SELECT:
	case WM_IME_CHAR:
		return	TRUE ;
	}
	return	FALSE ;
}

/*************************************************************************
 *
 *	ShowUIWindows (hWnd, fFlag)
 *
 *************************************************************************/
void	PASCAL	ShowUIWindows (HWND hWnd, BOOL fFlag)
{
	HGLOBAL hUIExtra;
	LPUIEXTRA lpUIExtra;
	int nsw = fFlag ? SW_SHOWNOACTIVATE : SW_HIDE;

	if (!(hUIExtra = (HGLOBAL)GetWindowLong (hWnd, IMMGWL_PRIVATE)))
		return;

	if (!(lpUIExtra = (LPUIEXTRA)GlobalLock(hUIExtra)))
		return;

	if (IsWindow (lpUIExtra->uiStatus.hWnd)){
		HIMC	hIMC ;
		ShowWindow (lpUIExtra->uiStatus.hWnd, nsw) ;
		lpUIExtra->uiStatus.bShow	= fFlag ;
		hIMC	= (HIMC)GetWindowLong (hWnd, IMMGWL_IMC) ;
		UpdateIndicIcon (hIMC) ;
	}

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		ShowWindow (lpUIExtra->uiCand.hWnd, nsw) ;
		lpUIExtra->uiCand.bShow		= fFlag ;
	}

	if (IsWindow(lpUIExtra->uiDefComp.hWnd)){
		ShowWindow (lpUIExtra->uiDefComp.hWnd, nsw) ;
		lpUIExtra->uiDefComp.bShow	= fFlag ;
	}

	if (IsWindow(lpUIExtra->uiGuide.hWnd)){
		ShowWindow (lpUIExtra->uiGuide.hWnd, nsw) ;
		lpUIExtra->uiGuide.bShow	= fFlag ;
	}

	GlobalUnlock(hUIExtra);
	return ;
}

#ifdef DEBUG
void PASCAL DumpUIExtra(LPUIEXTRA lpUIExtra)
{
	char szDev[80];
	int i;

	wsprintf((LPSTR)szDev,"Status hWnd %lX  [%d,%d]\r\n",
											   lpUIExtra->uiStatus.hWnd,
											   lpUIExtra->uiStatus.pt.x,
											   lpUIExtra->uiStatus.pt.y);
	OutputDebugString((LPSTR)szDev);

	wsprintf((LPSTR)szDev,"Cand hWnd %lX  [%d,%d]\r\n",
											   lpUIExtra->uiCand.hWnd,
											   lpUIExtra->uiCand.pt.x,
											   lpUIExtra->uiCand.pt.y);
	OutputDebugString((LPSTR)szDev);

	wsprintf((LPSTR)szDev,"CompStyle hWnd %lX]\r\n", lpUIExtra->dwCompStyle);
	OutputDebugString((LPSTR)szDev);

	wsprintf((LPSTR)szDev,"DefComp hWnd %lX  [%d,%d]\r\n",
											   lpUIExtra->uiDefComp.hWnd,
											   lpUIExtra->uiDefComp.pt.x,
											   lpUIExtra->uiDefComp.pt.y);
	OutputDebugString((LPSTR)szDev);

	for (i=0;i<5;i++){
		wsprintf((LPSTR)szDev,"Comp hWnd %lX  [%d,%d]-[%d,%d]\r\n",
											   lpUIExtra->uiComp[i].hWnd,
											   lpUIExtra->uiComp[i].rc.left,
											   lpUIExtra->uiComp[i].rc.top,
											   lpUIExtra->uiComp[i].rc.right,
											   lpUIExtra->uiComp[i].rc.bottom);
		OutputDebugString((LPSTR)szDev);
	}
}
#endif

