/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Fdebug.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <windows.h>
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"

void	PASCAL	DebugTextOut (int x, int y, LPCMYSTR lpszFormat, ...)
{
	HDC		hDC ;
	MYCHAR	buf [1024] ;
	va_list	marker ;
	int		nCount ;
	va_start (marker, lpszFormat) ;
#if defined (SKKIME98M)
	nCount	= wvsprintfW (buf, lpszFormat, marker) ;
#else
	nCount	= wvsprintfA (buf, lpszFormat, marker) ;
#endif
	va_end (marker) ;
	hDC	= GetDC (0) ;
	MyTextOut (hDC, x, y, buf, Mylstrlen (buf)) ;
	ReleaseDC (0, hDC) ;
	return ;
}

#if defined(DEBUG)

void PASCAL ImeLogFile (LPSTR lpszFormat, ...)
{
	char 	szBuf [2048] ;
	HANDLE	hFile ;
	va_list	marker ;
	int		nCount ;
	DWORD	dwWrite ;
	va_start (marker, lpszFormat) ;
	nCount = wvsprintf(szBuf, lpszFormat, marker);
	va_end (marker) ;
	hFile	= CreateFile ("C:\\windows\\temp\\skkime.log", GENERIC_WRITE, 0, 0, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0) ;
	if (hFile != INVALID_HANDLE_VALUE){
		SetFilePointer (hFile, 0, 0, FILE_END) ;
		dwWrite	= 0 ;
		WriteFile (hFile, szBuf, sizeof (char) * lstrlen (szBuf), &dwWrite, 0) ;
		CloseHandle (hFile) ;
	}
	return ;
}

#endif

