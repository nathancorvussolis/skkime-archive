/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * localjisyo.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "mylocale.h"
#include "mystring.h"
#include "skkiserv.h"
#include "unicode.h"
#include "winfile.h"
#include "charset.h"
#include "jisyo.h"

/*
 *	Private Prototypes
 */
static	LPSKKJISYO		j_find_local_jisyo (LPCTSTR lpString) ;
static	LPSKKJISYO		j_register_local_jisyo (LPCTSTR lpString, int iCodingSystem) ;
static	LPLISTBUFFER	j_search_local_euc_jisyo (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER hVectorTop, BOOL fOkuri) ;
static	LPLISTBUFFER	j_search_local_sjis_jisyo (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER hVectorTop, BOOL fOkuri) ;
static	LPLISTBUFFER	j_search_local_jis_jisyo (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER hVectorTop, BOOL fOkuri) ;
static	LPLISTBUFFER	j_try_completion_local_jis_jisyo (LPCSTR lpJisyoPath, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_try_completion_local_sjis_jisyo (LPCSTR lpJisyoPath, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_try_completion_local_euc_jisyo (LPCSTR lpJisyoPath, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_try_completion_local_euc_jisyo_sub (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_try_completion_local_sjis_jisyo_sub (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer) ;
static	LPLISTBUFFER	j_try_completion_local_jis_jisyo_sub (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer) ;

/*
 *	Global Variables
 */
static	LPSKKJISYO	lpLocalJisyosTop ;

/*
 *	Functions 
 */

BOOL	j_init_local_jisyo_table (void)
{
	lpLocalJisyosTop	= NULL ;
	return	TRUE ;
}

BOOL	j_clear_local_jisyo_table (void)
{
	LPSKKJISYO	lpJisyo ;
	LPSKKJISYO	lpNextJisyo ;
	lpJisyo	= lpLocalJisyosTop ;
	while (lpJisyo){
		lpNextJisyo	= lpJisyo->m_lpNext ;
		HeapFree (GetProcessHeap (), 0, lpJisyo) ;
		lpJisyo		= lpNextJisyo ;
	}
	lpLocalJisyosTop	= NULL ;
	return	TRUE ;
}

/*
 *	�w�肳�ꂽ�p�X�̎������w�肳�ꂽ������������@�Ƃ��ēo�^����֐��B
 */
LPSKKJISYO	j_register_local_jisyo (LPCTSTR lpString, int iCodingSystem)
{
	LPSKKJISYO	lpJisyo ;
	LPSKKJISYO	lpPrevJisyo ;
	LPSKKJISYO	lpNewJisyo ;
	long		lResult ;
	WINFILE		winfile ;
	/* ���ɓo�^����Ă��鎫���ł��邩���ׂ�B*/
	lpJisyo		= lpLocalJisyosTop ;
	lpPrevJisyo	= NULL ;
	while (lpJisyo){
		lResult	= lstrcmp (lpJisyo->m_tszPath, lpString) ;
		if (!lResult)
			return	lpJisyo ;
		if (lResult > 0)
			break ;
		lpPrevJisyo	= lpJisyo ;
		lpJisyo		= lpJisyo->m_lpNext ;
	}
	/* �����t�@�C�����Ǘ����邽�߂̃f�[�^�̈���m�ۂ���B*/
	lpNewJisyo	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (SKKJISYO)) ;
	if (!lpNewJisyo)
		return	NULL ;
	lstrcpy (lpNewJisyo->m_tszPath, lpString) ;
	/* �����t�@�C�������݂��Ȃ���΁A�o�^���邱�Ƃ͏o���Ȃ��B*/
	if (!winfopen ((LPWINFILE)&winfile, lpNewJisyo->m_tszPath, GENERIC_READ, OPEN_EXISTING)){
		HeapFree (GetProcessHeap (), 0, lpJisyo) ;
		return	NULL ;
	}
	/* �����̕�����������@�����o����B*/
	if (iCodingSystem < 0){
		lpNewJisyo->m_iCodingSystem	= j_detect_coding_system ((LPWINFILE)&winfile, 1024) ;
	} else {
		lpNewJisyo->m_iCodingSystem	= iCodingSystem ;
	}
	winfclose (&winfile) ;
	/* �������Ǘ����X�g�ɉ�����B*/
	lpNewJisyo->m_lpNext		= lpJisyo ;
	if (!lpPrevJisyo){
		lpLocalJisyosTop		= lpNewJisyo ;
	} else {
		lpPrevJisyo->m_lpNext	= lpNewJisyo ;
	}
	return	lpNewJisyo ;
}

/*
 *	�w�肳�ꂽ�p�X�̎������폜����֐��B
 */
BOOL	j_unregister_local_jisyo (LPCTSTR lpString)
{
	LPSKKJISYO	lpJisyo ;
	LPSKKJISYO	lpPrevJisyo ;
	long		lResult ;
	lpJisyo		= lpLocalJisyosTop ;
	lpPrevJisyo	= NULL ;
	while (lpJisyo){
		lResult	= lstrcmp (lpJisyo->m_tszPath, lpString) ;
		if (!lResult){
			if (!lpPrevJisyo){
				lpLocalJisyosTop		= lpJisyo->m_lpNext ;
			} else {
				lpPrevJisyo->m_lpNext	= lpJisyo->m_lpNext ;
			}
			HeapFree (GetProcessHeap (), 0, lpJisyo) ;
			return	TRUE ;
		}
		if (lResult > 0)
			return	FALSE ;
		lpPrevJisyo	= lpJisyo ;
		lpJisyo		= lpJisyo->m_lpNext ;
	}
	return	FALSE ;
}

/*
 *	�^����ꂽ�L�[�Ń��[�U��������������֐��B
 */
LPLISTBUFFER	j_search_local_jisyo (LPCTSTR lpPath, int iCodingSystem, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer, BOOL fOkuri)
{
	WINFILE		winFile ;
	LPSKKJISYO	lpJisyo ;
	/* �����������̃p�X���^�����Ă��邩�`�F�b�N����B*/
	if (!lpPath)
		return	lpListBuffer ;
	/* �o�^����Ă��鎫���ł��邩�ǂ����`�F�b�N����B*/
	lpJisyo	= j_find_local_jisyo (lpPath) ;
	if (!lpJisyo){
		/* ���o�^�ł���΁A������o�^����B*/
		lpJisyo	= j_register_local_jisyo (lpPath, iCodingSystem) ;
		if (!lpJisyo)
			return	lpListBuffer ;
	}
	/* �������J���B�J���Ȃ�������A�G���[�B*/
	if (!winfopen ((LPWINFILE)&winFile, lpJisyo->m_tszPath, GENERIC_READ, OPEN_EXISTING))
		return	lpListBuffer ;
	lpListBuffer	= j_search_skkinput_jisyo_with_fileptr (&winFile, lpJisyo->m_iCodingSystem, lpKey, lpListBuffer, fOkuri) ;
	winfclose ((LPWINFILE)&winFile) ;
	return	lpListBuffer ;
}

LPLISTBUFFER	j_search_skkinput_jisyo_with_fileptr (LPWINFILE lpFile, int iCodingSystem, LPMYSTR lpKey, LPLISTBUFFER lpVectorTop, BOOL fOkuri)
{
	switch (iCodingSystem){
	case	KANJI_CODE_JIS:
		return	j_search_local_jis_jisyo (lpFile, lpKey, lpVectorTop, fOkuri) ;
	case	KANJI_CODE_SJIS:
		return	j_search_local_sjis_jisyo (lpFile, lpKey, lpVectorTop, fOkuri) ;
	case	KANJI_CODE_EUC:
	default:
		return	j_search_local_euc_jisyo (lpFile, lpKey, lpVectorTop, fOkuri) ;
	}
}

/*
 *	�^����ꂽ�L�[�ŕ⊮�ł��Ȃ������[�U��������������֐��B
 */
LPLISTBUFFER	j_try_completion_local_jisyo (LPMYSTR lpKey, LPLISTBUFFER lpListBuffer)
{
	LPSKKJISYO		lpJisyo ;
#if defined (MIXED_UNICODE_ANSI)
	MYCHAR			szMybuf [MAX_PATH + 1] ;
	int				iLength ;
#endif
	TCHAR			szPath [MAX_PATH] ;
	int				iCodingSystem ;
	LPLISTBUFFER	(*j_completion_func_tbl [])(LPCSTR, LPMYSTR, LPLISTBUFFER) = {
		j_try_completion_local_jis_jisyo,
		j_try_completion_local_sjis_jisyo,
		j_try_completion_local_euc_jisyo,
	} ;

	lpJisyo			= 0 ;
	/* skkinput-jisyo �̊����R�[�h�𓾂�B*/
	iCodingSystem	= j_get_coding_system (MYTEXT ("skkinput-jisyo-code")) ;

	/* �Ǐ������̃p�X���y�уo�b�N�A�b�v�����̃p�X���𓾂�B*/
#if defined (MIXED_UNICODE_ANSI)
	if (skkiserv_eval (MYTEXT ("skkinput-jisyo"), szMybuf, MAX_PATH)){
		szMybuf [MAX_PATH]	= MYTEXT ('\0') ;
		iLength				= MystrToShiftJis (szPath, MAX_PATH, szMybuf, MAX_PATH) ;
		if (iLength > 0){
			szPath [iLength]	= '\0' ;
			lpJisyo				= j_find_local_jisyo (szPath) ;
			if (!lpJisyo){
				/* ���o�^�ł���΁A������o�^����B*/
				lpJisyo			= j_register_local_jisyo (szPath, iCodingSystem) ;
			}
			if (lpJisyo)
				lpListBuffer	= (j_completion_func_tbl [lpJisyo->m_iCodingSystem])(szPath, lpKey, lpListBuffer) ;
		}
	}
#else
	if (skkiserv_eval (MYTEXT ("skkinput-jisyo"), szPath, MAX_PATH)){
		lpJisyo				= j_find_local_jisyo (szPath) ;
		if (!lpJisyo){
			/* ���o�^�ł���΁A������o�^����B*/
			lpJisyo			= j_register_local_jisyo (szPath, iCodingSystem) ;
		}
		if (lpJisyo)
			lpListBuffer	= (j_completion_func_tbl [lpJisyo->m_iCodingSystem])(szPath, lpKey, lpListBuffer) ;
	}
#endif
	/* skk-jisyo �̊����R�[�h�𓾂�B*/
	iCodingSystem	= j_get_coding_system (MYTEXT ("skk-jisyo-code")) ;
#if defined (MIXED_UNICODE_ANSI)
	if (skkiserv_eval (MYTEXT ("skk-jisyo"), szMybuf, MAX_PATH)){
		szMybuf [MAX_PATH]	= MYTEXT ('\0') ;
		iLength				= MystrToShiftJis (szPath, MAX_PATH, szMybuf, MAX_PATH) ;
		if (iLength > 0){
			szPath [iLength]	= '\0' ;
			lpJisyo				= j_find_local_jisyo (szPath) ;
			if (!lpJisyo){
				/* ���o�^�ł���΁A������o�^����B*/
				lpJisyo			= j_register_local_jisyo (szPath, iCodingSystem) ;
			}
			if (lpJisyo)
				lpListBuffer	= (j_completion_func_tbl [iCodingSystem])(szPath, lpKey, lpListBuffer) ;
		}
	}
#else
	if (skkiserv_eval (MYTEXT ("skk-jisyo"), szPath, MAX_PATH)){
		lpJisyo				= j_find_local_jisyo (szPath) ;
		if (!lpJisyo){
			/* ���o�^�ł���΁A������o�^����B*/
			lpJisyo			= j_register_local_jisyo (szPath, iCodingSystem) ;
		}
		if (lpJisyo)
			lpListBuffer	= (j_completion_func_tbl [iCodingSystem])(szPath, lpKey, lpListBuffer) ;
	}
#endif
	return	lpListBuffer ;
}

int		j_get_coding_system (LPCMYSTR lpCodingSystemVar)
{
	MYCHAR	szCode [64] ;
	int		iCodingSystem ;
	iCodingSystem	= KANJI_CODE_UNKNOWN ;
	if (skkiserv_eval (lpCodingSystemVar, szCode, sizeof (szCode) / sizeof (MYCHAR))){
		if (!Mylstrcmp (szCode, MYTEXT ("*euc-japan*"))){
			iCodingSystem	= KANJI_CODE_EUC ;
		} else if (!Mylstrcmp (szCode, MYTEXT ("*junet*"))){
			iCodingSystem	= KANJI_CODE_JIS ;
		} else if (!Mylstrcmp (szCode, MYTEXT ("*sjis*"))){
			iCodingSystem	= KANJI_CODE_SJIS ;
		}
	}
	return	iCodingSystem ;
}

/*
 *	Private Functions
 */

LPSKKJISYO	j_find_local_jisyo (LPCTSTR lpString)
{
	LPSKKJISYO	lpJisyo ;
	long		lResult ;
	lpJisyo		= lpLocalJisyosTop ;
	while (lpJisyo){
		lResult	= lstrcmp (lpJisyo->m_tszPath, lpString) ;
		if (!lResult)
			return	lpJisyo ;
		if (lResult > 0)
			return	NULL ;
		lpJisyo		= lpJisyo->m_lpNext ;
	}
	return	NULL ;
}

/*
 *	EUC-JP ���������ꂽ���[�U������������ɗ^����ꂽ��������L�[�ɂ��ĕϊ�����T���֐��B
 */
LPLISTBUFFER	j_search_local_euc_jisyo (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpVectorTop, BOOL fOkuri)
{
	LPMYSTR				lpptr ;
	char*				lpcptr ;
	int					iChara ;
	int					iRest ;
	BOOL				fFound ;
	MYCHAR				buffer [TEXTBUFSIZE] ;
	ISO2022STATE		eucjpState ;
	WORD				woChara ;
	int					iRet ;

	if (!lpFile || !lpKey || !*lpKey)
		return	lpVectorTop ;
	winrewind (lpFile) ;
	if (fOkuri){
		j_skip_euc_file_until (lpFile, MYTEXT (";; okuri-ari entries.")) ;
	} else {
		j_skip_euc_file_until (lpFile, MYTEXT (";; okuri-nasi entries.")) ;
	}
	fFound		= FALSE ;
	for (; ;){
		eucjp_init (&eucjpState) ;
		lpptr		= (LPMYSTR)lpKey ;
		/* ���̈ʒu�ł͍s���ɗ��Ă�����̂ƍl����B*/
		iChara		= winfgetc (lpFile) ;
		if (iChara != ';'){
			iRet	= MyEucJpChar (&eucjpState, iChara, &woChara) ;
			while (iChara != EOF &&
				   iChara != '\n' &&
				   iChara != '\r' &&
				   *lpptr != MYTEXT ('\0')){
				if (iRet < 0)
					break ;
				if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
					if (*lpptr != woChara)
						break ;
					lpptr	++ ;
#else
					if (woChara > 0x100){
						if ((unsigned char)*lpptr != (woChara >> 8))
							break ;
						lpptr	++ ;
					}
					if ((unsigned char)*lpptr != (woChara & 0x00FF))
						break ;
					lpptr	++ ;
#endif
				}
				iChara	= winfgetc (lpFile) ;
				iRet	= MyEucJpChar (&eucjpState, iChara, &woChara) ;
			}
			if (!*lpptr){
				if (!iRet){
					do {
						iChara	= winfgetc (lpFile) ;
						iRet	= MyIso2022JpChar (&eucjpState, iChara, &woChara) ;
					} while (!iRet) ;
				}
				if (iRet > 0 && woChara == MYTEXT (' ')){
					/* ���̏ꍇ�ɂ͌��������񂪃q�b�g�������ƂɂȂ�B*/
					fFound	= TRUE ;
					break ;
				}
			}
		} else {
			/* ���������āA���艼������G���g���܂ŗ��Ă��܂����̂��H*/
			lpcptr	= (fOkuri)? ";; okuri-nasi entries." : ";; okuri-ari entries." ;
			while (*lpcptr && iChara == *lpcptr){
				iChara	= winfgetc (lpFile) ;
				lpcptr	++ ;
			}
			/* ����ȏ�̃G���g�����������邱�Ƃ͖����B*/
			if (!*lpcptr && iChara == '\n')
				iChara	= EOF ;
		}
		/* �s���܂œǂݔ�΂��B*/
		while (iChara != EOF && iChara != '\n' && iChara != '\r')
			iChara	= winfgetc (lpFile) ;
		/* �t�@�C���̍Ō�ɗ��Ă����ꍇ�ɂ͌������I����B*/
		if (iChara == EOF)
			break ;
	}
	/* ������Ȃ������ꍇ�ɂ͉������Ȃ��B*/
	if (!fFound)
		return	lpVectorTop ;
	lpptr		= buffer ;
	iRest		= TEXTBUFSIZE ;
	for (; ;){
		iChara	= winfgetc (lpFile) ;
		if (iChara == EOF || iChara == '\n' || iChara == '\r' || iChara == '[')
			break ;
		iRet	= MyEucJpChar (&eucjpState, iChara, &woChara) ;
		if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iRest < 1){
				lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
				lpptr		= buffer ;
				iRest		= TEXTBUFSIZE ;
			}
			*lpptr	++	= woChara ;
			iRest	-- ;
#else
			if (woChara > 0x100){
				if (iRest < 2){
					lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
					lpptr		= buffer ;
					iRest		= TEXTBUFSIZE ;
				}
				*lpptr	++	= (woChara >> 8) ;
				iRest	-- ;
				*lpptr	++	= (woChara & 0x00FF) ;
				iRest	-- ;
			} else {
				if (iRest < 1){
					lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
					lpptr		= buffer ;
					iRest		= TEXTBUFSIZE ;
				}
				*lpptr	++	= (woChara & 0x00FF) ;
				iRest	-- ;
			}
#endif
		}
	}
	if (iRest < TEXTBUFSIZE)
		lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
	return	lpVectorTop ;
}

/*
 *	SJIS ���������ꂽ���[�U������������ɗ^����ꂽ��������L�[�ɂ��ĕϊ�����T���֐��B
 */
LPLISTBUFFER	j_search_local_sjis_jisyo (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpVectorTop, BOOL fOkuri)
{
	LPMYSTR				lpptr ;
	char*				lpcptr ;
	int					iLeadChara ;
	int					iChara ;
	int					iRest ;
	BOOL				fFound ;
	MYCHAR				buffer [TEXTBUFSIZE] ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	unsigned char		c1, c2 ;
#endif

	if (!lpFile || !lpKey || !*lpKey)
		return	lpVectorTop ;
	winrewind (lpFile) ;
	if (fOkuri){
		j_skip_sjis_file_until (lpFile, MYTEXT (";; okuri-ari entries.")) ;
	} else {
		j_skip_sjis_file_until (lpFile, MYTEXT (";; okuri-nasi entries.")) ;
	}
	fFound		= FALSE ;
	for (; ;){
		lpptr	= lpKey ;
		/* ���̈ʒu�ł͍s���ɗ��Ă�����̂ƍl����B*/
		iChara		= winfgetc (lpFile) ;
		iLeadChara	= '\0' ;
		if (iChara != ';'){
			while (iChara != EOF  &&
				   iChara != '\n' &&
				   iChara != '\r' &&
				   *lpptr){
				if (iLeadChara){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
					c1	= (unsigned char)iLeadChara ;
					c2	= (unsigned char)iChara ;
					c2	= iChara & 0x00FF ;
					c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
					c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
					if (c2 >= 0x7F){
						c2	-= 0x5E ;
					} else {
						c1	-- ;
					}
					if ((unsigned short)*lpptr != UNICODE_JISX0208 ((c1 << 8) | c2))
						break ;
					lpptr	++ ;
#else
					if ((unsigned char)*lpptr != iLeadChara)
						break ;
					lpptr	++ ;
					if ((unsigned char)*lpptr != iChara)
						break ;
					lpptr	++ ;
#endif
					iLeadChara	= '\0' ;
				} else {
					if (IsDBCSLeadByte ((char)iChara)){
						iLeadChara	= iChara & 0x00FF ;
					} else {
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						if (iChara < 0 || iChara > 127)
							iChara	= UNICODE_JISX0201 (iChara) ;
						if ((unsigned short)*lpptr != iChara)
							break ;
#else
						if ((unsigned char)*lpptr != iChara)
							break ;
#endif
						lpptr	++ ;
					}
				}
				iChara	= winfgetc (lpFile) ;
			}
			if (!*lpptr && iChara == ' '){
				/* ���̏ꍇ�ɂ͌��������񂪃q�b�g�������ƂɂȂ�B*/
				fFound	= TRUE ;
				break ;
			}
		} else {
			/* ���������āA���艼������G���g���܂ŗ��Ă��܂����̂��H*/
			lpcptr	= (fOkuri)? ";; okuri-ari entries." : ";; okuri-nasi entries." ;
			while (*lpcptr && iChara == *lpcptr){
				iChara	= winfgetc (lpFile) ;
				lpcptr	++ ;
			}
			/* ����ȏ�̃G���g�����������邱�Ƃ͖����B*/
			if (!*lpcptr)
				iChara	= EOF ;
		}
		/* �s���܂œǂݔ�΂��B*/
		while (iChara != EOF && iChara != '\n' && iChara != '\r')
			iChara	= winfgetc (lpFile) ;
		/* �t�@�C���̍Ō�ɗ��Ă����ꍇ�ɂ͌������I����B*/
		if (iChara == EOF)
			break ;
	}
	/* ������Ȃ������ꍇ�ɂ͉������Ȃ��B*/
	if (!fFound)
		return	lpVectorTop ;
	lpptr		= buffer ;
	iRest		= TEXTBUFSIZE ;
	iLeadChara	= '\0' ;		/* �󔒂Ő؂�Ă���̂� LeadByte �͖����B*/
	for (; ;){
		iChara	= winfgetc (lpFile) ;
		if (iChara == EOF || iChara == '\n' || iChara == '\r' || iChara == '[')
			break ;
		if (iLeadChara){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iRest < 1){
				lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
				lpptr		= buffer ;
				iRest		= TEXTBUFSIZE ;
			}
			c1	= (unsigned char)iLeadChara ;
			c2	= (unsigned char)iChara ;
			c2	= iChara & 0x00FF ;
			c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
			c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			*lpptr	++	= UNICODE_JISX0208 ((c1 << 8) | c2) ;
			iRest	-- ;
#else
			if (iRest < 2){
				lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
				lpptr		= buffer ;
				iRest		= TEXTBUFSIZE ;
			}
			*lpptr	++	= (unsigned char)iLeadChara ;
			iRest	-- ;
			*lpptr	++	= (unsigned char)iChara ;
			iRest	-- ;
#endif
			iLeadChara	= '\0' ;
		} else {
			if (IsDBCSLeadByte ((char)iChara)){
				iLeadChara	= iChara & 0x00FF ;
			} else {
				if (iRest < 1){
					lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
					lpptr		= buffer ;
					iRest		= TEXTBUFSIZE ;
				}
				if (fOkuri && iChara == '[')
					break ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (iChara < 0 || iChara > 127){
					*lpptr	++	= UNICODE_JISX0201 (iChara) ;
				} else {
					*lpptr	++	= iChara ;
				}
				iRest	-- ;
#else
				*lpptr	++	= (unsigned char)iChara ;
				iRest	-- ;
#endif
			}
		}
	}
	if (iRest < TEXTBUFSIZE)
		lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
	return	lpVectorTop ;
}

/*
 *	ISO-2022-JP ���������ꂽ���[�U������������ɗ^����ꂽ��������L�[�ɂ��ĕϊ�����T���֐��B
 */
LPLISTBUFFER	j_search_local_jis_jisyo (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpVectorTop, BOOL fOkuri)
{
	LPMYSTR				lpptr ;
	int					iChara ;
	int					iRest ;
	BOOL				fFound ;
	MYCHAR				buffer [TEXTBUFSIZE] ;
	BOOL				fLineTop ;
	BOOL				fNotMatch ;
	ISO2022STATE		iso2022jpState ;
	WORD				woChara ;
	int					iRet ;

	if (!lpFile || !lpKey || !*lpKey)
		return	lpVectorTop ;

	winrewind (lpFile) ;
	if (fOkuri){
		j_skip_jis_file_until (lpFile, MYTEXT (";; okuri-ari entries.")) ;
	} else {
		j_skip_jis_file_until (lpFile, MYTEXT (";; okuri-nasi entries.")) ;
	}

	fFound				= FALSE ;
	/*
	 *	iso2022jp �ł� GL �� G0 ���Ăяo����Ă���Ƃ���B
	 * �iG0 �� GL �ɌĂяo�����f�t�H���g�̃o�b�t�@�ł���)
	 */
	while (!fFound){
		/* �s���ł̉���B*/
		iso2022jp_init (&iso2022jpState) ;
		lpptr		= lpKey ;
		fLineTop	= TRUE ;
		fNotMatch	= FALSE ;
		while (*lpptr){
			iChara	= winfgetc (lpFile) ;
			iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
			if (iChara == EOF || iChara == '\n' || iChara == '\r' || iRet < 0)
				break ;
			if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (*lpptr != woChara)
					break ;
				lpptr	++ ;
#else
				if (woChara > 0x100){
					if ((unsigned char)*lpptr != (woChara >> 8))
						break ;
					lpptr	++ ;
				}
				if ((unsigned char)*lpptr != (woChara & 0x00FF))
					break ;
				lpptr	++ ;
#endif
			}
		}
		/* �Y�������₪���݂��邩�ǂ����B*/
		if (!*lpptr){
			/*
			 *	���̎��_�ł́AwoChara �͈�v�������_�̕����R�[�h�������Ă���B
			 *	�ł��A�~�����̂͂��̎��̕����R�[�h�B
			 *	���̕������X�y�[�X��������A�����L�[�Ƀq�b�g����ϊ����ʂ����݂���B
			 */
			do {
				iChara	= winfgetc (lpFile) ;
				iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
			} while (!iRet && iChara != EOF) ;

			if (iRet > 0 && woChara == ' '){
				fFound	= TRUE ;
				break ;
			}
		}
		/* �s���܂œǂݔ�΂��B*/
		while (iChara != EOF && iChara != '\n' && iChara != '\r')
			iChara	= winfgetc (lpFile) ;
		/* �t�@�C���̍Ō�ɗ��Ă����ꍇ�ɂ͌������I����B*/
		if (iChara == EOF)
			break ;
	}
	if (!fFound)
		return	lpVectorTop ;
	lpptr		= buffer ;
	iRest		= TEXTBUFSIZE ;
	for (; ;){
		iChara	= winfgetc (lpFile) ;
		iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
		if (iChara == EOF || iChara == '\n' || iChara == '\r' || iChara == '[' || iRet < 0)
			break ;
		if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iRest < 1){
				lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
				lpptr		= buffer ;
				iRest		= TEXTBUFSIZE ;
			}
			*lpptr	++	= woChara ;
			iRest	-- ;
#else
			if (woChara > 0x100){
				if (iRest < 2){
					lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
					lpptr		= buffer ;
					iRest		= TEXTBUFSIZE ;
				}
				*lpptr	++	= (woChara >> 8) ;
				iRest	-- ;
				*lpptr	++	= (woChara & 0x00FF) ;
				iRest	-- ;
			} else {
				if (iRest < 1){
					lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
					lpptr		= buffer ;
					iRest		= TEXTBUFSIZE ;
				}
				*lpptr	++	= (woChara & 0x00FF) ;
				iRest	-- ;
			}
#endif
		}
	}
	if (iRest < TEXTBUFSIZE)
		lpVectorTop	= SKKAddListBuffer (lpVectorTop, buffer, TEXTBUFSIZE - iRest, NULL, NULL) ;
	return	lpVectorTop ;
}

LPLISTBUFFER	j_try_completion_local_jis_jisyo (LPCSTR lpJisyoPath, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer)
{
	WINFILE	winFile ;
	if (!lpJisyoPath)
		return	lpListBuffer ;
	if (!winfopen ((LPWINFILE)&winFile, lpJisyoPath, GENERIC_READ, OPEN_EXISTING))
		return	lpListBuffer ;
	lpListBuffer	= j_try_completion_local_jis_jisyo_sub ((LPWINFILE)&winFile, lpKey, lpListBuffer) ;
	winfclose ((LPWINFILE)&winFile) ;
	return	lpListBuffer ;
}

LPLISTBUFFER	j_try_completion_local_sjis_jisyo (LPCSTR lpJisyoPath, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer)
{
	WINFILE	winFile ;
	if (!lpJisyoPath)
		return	lpListBuffer ;
	if (!winfopen ((LPWINFILE)&winFile, lpJisyoPath, GENERIC_READ, OPEN_EXISTING))
		return	lpListBuffer ;
	lpListBuffer	= j_try_completion_local_sjis_jisyo_sub ((LPWINFILE)&winFile, lpKey, lpListBuffer) ;
	winfclose ((LPWINFILE)&winFile) ;
	return	lpListBuffer ;
}

LPLISTBUFFER	j_try_completion_local_euc_jisyo (LPCSTR lpJisyoPath, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer)
{
	WINFILE	winFile ;
	if (!lpJisyoPath)
		return	lpListBuffer ;
	if (!winfopen ((LPWINFILE)&winFile, lpJisyoPath, GENERIC_READ, OPEN_EXISTING))
		return	lpListBuffer ;
	lpListBuffer	= j_try_completion_local_euc_jisyo_sub ((LPWINFILE)&winFile, lpKey, lpListBuffer) ;
	winfclose ((LPWINFILE)&winFile) ;
	return	lpListBuffer ;
}

LPLISTBUFFER	j_try_completion_local_euc_jisyo_sub (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer)
{
	LPMYSTR				lpptr ;
	char*				lpcptr ;
	int					iChara ;
	int					iCount ;
	BOOL				fFound ;
	MYCHAR				buffer [TEXTBUFSIZE] ;
	ISO2022STATE		eucjpState ;
	WORD				woChara ;
	int					iRet ;

	if (!lpFile || !lpKey || !*lpKey)
		return	lpListBuffer ;

	winrewind (lpFile) ;
	j_skip_euc_file_until (lpFile, MYTEXT (";; okuri-nasi entries.")) ;
	fFound		= FALSE ;
	while (1){
		eucjp_init (&eucjpState) ;
		lpptr		= lpKey ;
		/* ���̈ʒu�ł͍s���ɗ��Ă�����̂ƍl����B*/
		iChara		= winfgetc (lpFile) ;
		iRet		= MyEucJpChar (&eucjpState, iChara, &woChara) ;
		if (iChara != ';'){
			while (iChara != EOF && iChara != '\n' && iChara != '\r' && *lpptr != MYTEXT ('\0')){
				if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
					if (*lpptr != woChara)
						break ;
					lpptr	++ ;
#else
					if (woChara > 0x0100){
						if ((unsigned char)*lpptr != (woChara >> 8))
							break ;
						lpptr	++ ;
					}
					if ((unsigned char)*lpptr != (woChara & 0x00FF))
						break ;
					lpptr	++ ;
#endif
				}
				iChara	= winfgetc (lpFile) ;
				iRet	= MyEucJpChar (&eucjpState, iChara, &woChara) ;
			}
			if (!*lpptr && iChara != EOF && iChara != '\n' && iChara != '\r'){
				if (!fFound){
					buffer [0]	= MYTEXT ('/') ;
					Mylstrcpy (buffer + 1, lpKey) ;
					iCount		= lpptr - lpKey + 1 ;
					lpptr		= buffer + iCount ;
					fFound		= TRUE ;
				} else {
					Mylstrcpy (buffer, lpKey) ;
					iCount		= lpptr - lpKey ;
					lpptr		= buffer + iCount ;
				}
				/* ���̏ꍇ�ɂ͌��������񂪃q�b�g�������ƂɂȂ�B*/
				while (iChara != EOF  &&
					   iChara != '\n' &&
					   iChara != '\r' &&
					   iChara != ' '  &&
					   iCount < TEXTBUFSIZE - 3){
					if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						*lpptr	++	= woChara ;
						iCount	++ ;
#else
						if (woChara > 0x0100){
							*lpptr	++	= (woChara >> 8) ;
							iCount	++ ;
						}
						*lpptr	++	= (woChara & 0x00FF) ;
						iCount	++ ;
#endif
					}
					iChara	= winfgetc (lpFile) ;
					iRet	= MyEucJpChar (&eucjpState, iChara, &woChara) ;
				}
				*lpptr	++	= MYTEXT ('/') ;
				iCount	++ ;
				lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, iCount, NULL, NULL) ;
			}
		} else {
			/* ���������āA���艼������G���g���܂ŗ��Ă��܂����̂��H*/
			lpcptr	= ";; okuri-ari entries." ;
			while (*lpcptr && iChara == *lpcptr){
				iChara	= winfgetc (lpFile) ;
				lpcptr	++ ;
			}
			/* ����ȏ�̃G���g�����������邱�Ƃ͖����B*/
			if (!*lpcptr && iChara == '\n')
				iChara	= EOF ;
		}
		/* �s���܂œǂݔ�΂��B*/
		while (iChara != EOF && iChara != '\n' && iChara != '\r')
			iChara	= winfgetc (lpFile) ;
		/* �t�@�C���̍Ō�ɗ��Ă����ꍇ�ɂ͌������I����B*/
		if (iChara == EOF)
			break ;
	}
	return	lpListBuffer ;
}

LPLISTBUFFER	j_try_completion_local_sjis_jisyo_sub (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer)
{
	LPMYSTR				lpptr ;
	unsigned char FAR*	lpcptr ;
	int					iChara ;
	int					iCount ;
	unsigned char		cLeadChara ;
	BOOL				fFound ;
	MYCHAR				buffer [TEXTBUFSIZE] ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	unsigned char		c1, c2 ;
#endif

	if (!lpFile || !lpKey || !*lpKey)
		return	lpListBuffer ;

	winrewind (lpFile) ;
	j_skip_euc_file_until (lpFile, MYTEXT (";; okuri-nasi entries.")) ;

	fFound		= FALSE ;
	while (1){
		lpptr		= lpKey ;
		/* ���̈ʒu�ł͍s���ɗ��Ă�����̂ƍl����B*/
		iChara		= winfgetc (lpFile) ;
		cLeadChara	= '\0' ;
		if (iChara != ';'){
			while (iChara != EOF &&
				   iChara != MYTEXT ('\n') &&
				   iChara != MYTEXT ('\r') &&
				   *lpptr != MYTEXT ('\0')){
				if (cLeadChara != '\0'){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
					c1	= (unsigned char)cLeadChara ;
					c2	= (unsigned char)iChara ;
					c2	= iChara & 0x00FF ;
					c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
					c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
					if (c2 >= 0x7F){
						c2	-= 0x5E ;
					} else {
						c1	-- ;
					}
					if ((unsigned short)*lpptr != UNICODE_JISX0208 ((c1 << 8) | c2))
						break ;
					lpptr	++ ;
#else
					if ((unsigned char)*lpptr != cLeadChara)
						break ;
					lpptr	++ ;
					if ((unsigned char)*lpptr != iChara)
						break ;
					lpptr	++ ;
#endif
					cLeadChara	= '\0' ;
				} else {
					if (IsDBCSLeadByte ((char)iChara)){
						cLeadChara	= iChara ;
					} else {
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						if (iChara < 0 || iChara > 127){
							if ((unsigned short)*lpptr != UNICODE_JISX0201 (iChara))
								break ;
						} else {
							if ((unsigned short)*lpptr != iChara)
								break ;
						}
#else
						if ((unsigned char)*lpptr != iChara)
							break ;
#endif
						lpptr	++ ;
					}
				}
				iChara	= winfgetc (lpFile) ;
			}
			if (!*lpptr){
				if (!fFound){
					buffer [0]	= MYTEXT ('/') ;
					Mylstrcpy (buffer + 1, lpKey) ;
					iCount		= lpptr - lpKey + 1 ;
					lpptr		= buffer + iCount ;
					fFound		= TRUE ;
				} else {
					Mylstrcpy (buffer, lpKey) ;
					iCount		= lpptr - lpKey ;
					lpptr		= buffer + iCount ;
				}
				/* ���̏ꍇ�ɂ͌��������񂪃q�b�g�������ƂɂȂ�B*/
				while (iChara != EOF  &&
					   iChara != '\n' &&
					   iChara != '\r' &&
					   iChara != ' '  &&
					   iCount < TEXTBUFSIZE - 3){
					if (cLeadChara != '\0'){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						c1	= (unsigned char)cLeadChara ;
						c2	= (unsigned char)iChara ;
						c2	= iChara & 0x00FF ;
						c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
						c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
						if (c2 >= 0x7F){
							c2	-= 0x5E ;
						} else {
							c1	-- ;
						}
						*lpptr	++	= UNICODE_JISX0208 ((c1 << 8) | c2) ;
						iCount	++ ;
#else
						*lpptr	++	= cLeadChara ;
						iCount	++ ;
						*lpptr	++	= iChara ;
						iCount	++ ;
#endif
						cLeadChara	= '\0' ;
					} else {
						if (IsDBCSLeadByte ((char)iChara)){
							cLeadChara	= iChara ;
						} else {
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
							if (iChara < 0 || iChara > 127){
								*lpptr	++	= UNICODE_JISX0201 (iChara) ;
							} else {
								*lpptr	++	= iChara ;
							}
#else
							*lpptr	++	= iChara ;
#endif
							iCount	++ ;
						}
					}
					iChara	= winfgetc (lpFile) ;
				}
				*lpptr	++	= MYTEXT ('/') ;
				iCount	++ ;
				lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, iCount, NULL, NULL) ;
			}
		} else {
			/* ���������āA���艼������G���g���܂ŗ��Ă��܂����̂��H*/
			lpcptr	= ";; okuri-ari entries." ;
			while (*lpptr && iChara == *lpcptr){
				iChara	= winfgetc (lpFile) ;
				lpptr	++ ;
			}
			/* ����ȏ�̃G���g�����������邱�Ƃ͖����B*/
			if (!*lpptr && iChara == '\n')
				iChara	= EOF ;
		}
		/* �s���܂œǂݔ�΂��B*/
		while (iChara != EOF && iChara != '\n' && iChara != '\r')
			iChara	= winfgetc (lpFile) ;
		/* �t�@�C���̍Ō�ɗ��Ă����ꍇ�ɂ͌������I����B*/
		if (iChara == EOF)
			break ;
	}
	return	lpListBuffer ;
}

LPLISTBUFFER	j_try_completion_local_jis_jisyo_sub (LPWINFILE lpFile, LPMYSTR lpKey, LPLISTBUFFER lpListBuffer)
{
	LPMYSTR				lpptr ;
	int					iChara ;
	int					iCount ;
	BOOL				fFound ;
	MYCHAR				buffer [TEXTBUFSIZE] ;
	ISO2022STATE		iso2022jpState ;
	WORD				woChara ;
	int					iRet ;

	if (!lpFile || !lpKey || !*lpKey)
		return	lpListBuffer ;

	winrewind (lpFile) ;
	j_skip_jis_file_until (lpFile, MYTEXT (";; okuri-nasi entries.")) ;
	fFound		= FALSE ;
	for (; ;){
		/* ���̈ʒu�ł͍s���ɗ��Ă�����̂ƍl����B*/
		iso2022jp_init (&iso2022jpState) ;
		lpptr		= lpKey ;
		while (*lpptr){
			iChara	= winfgetc (lpFile) ;
			iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
			if (iChara == EOF || iChara == '\n' || iChara == '\r' || iRet < 0)
				break ;
			if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (*lpptr != woChara)
					break ;
#else
				if (woChara > 0x100){
					if ((unsigned char)*lpptr != (woChara >> 8))
						break ;
					lpptr	++ ;
				}
				if ((unsigned char)*lpptr != (woChara & 0x00FF))
					break ;
				lpptr	++ ;
#endif
			}
		}
		if (!*lpptr){
			/*
			 *	���̎��_�ł́AwoChara �͈�v�������_�̕����R�[�h�������Ă���B
			 *	�ł��A�~�����̂͂��̎��̕����R�[�h�B
			 *	�����Ńt�@�C�����I����Ă�����s���������肵����A�⊮����킯�ɂ͂����Ȃ��B
			 */
			do {
				iChara	= winfgetc (lpFile) ;
				iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
			} while (!iRet) ;

			if (iChara != EOF && iChara != '\n' && iChara != '\r'){
				if (!fFound){
					buffer [0]	= MYTEXT ('/') ;
					Mylstrcpy (buffer + 1, lpKey) ;
					iCount		= lpptr - lpKey + 1 ;
					lpptr		= buffer + iCount ;
					fFound		= TRUE ;
				} else {
					Mylstrcpy (buffer, lpKey) ;
					iCount		= lpptr - lpKey ;
					lpptr		= buffer + iCount ;
				}
				/* ���̏ꍇ�ɂ͌��������񂪃q�b�g�������ƂɂȂ�B*/
				while (iChara != EOF  &&
					   iChara != '\n' &&
					   iChara != '\r' &&
					   iChara != ' '  &&
					   iCount < TEXTBUFSIZE - 3){
					if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						*lpptr	++	= woChara ;
						iCount	++ ;
#else
						if (iso2022jpState.m_iCharset [iso2022jpState.m_iGL [0]] >= KCHARSET_2BYTES_CHARACTER){
							*lpptr	++	= woChara >> 8 ;
							iCount	++ ;
						}
						*lpptr	++	= woChara & 0x00FF ;
						iCount	++ ;
#endif
					}
					iChara	= winfgetc (lpFile) ;
					iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
				}
				*lpptr	++	= MYTEXT ('/') ;
				iCount	++ ;
				lpListBuffer	= SKKAddListBuffer (lpListBuffer, buffer, iCount, NULL, NULL) ;
			}
		}
		/* �s���܂œǂݔ�΂��B*/
		while (iChara != EOF && iChara != '\n' && iChara != '\r')
			iChara	= winfgetc (lpFile) ;
		/* �t�@�C���̍Ō�ɗ��Ă����ꍇ�ɂ͌������I����B*/
		if (iChara == EOF)
			break ;
	}
	return	lpListBuffer ;
}

