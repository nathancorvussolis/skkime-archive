/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * quote.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "mylocale.h"
#include "skkiserv.h"
#include "mystring.h"
#include "charset.h"
#include "unicode.h"

static	int		j_quote_char_sub (LPMYSTR lpDest, LPMYSTR lpWord) ;

typedef struct _tagCHARSTRPAIR	{
	MYCHAR	m_chara ;
	LPMYSTR	m_lpString ;
} CHARSTRPAIR, NEAR *PCHARSTRPAIR, FAR *LPCHARSTRPAIR ;

/*
 * ���̂܂܎����o�^����Ă��܂��Ƃ܂����l�B��ϊ�����֐��B
 *----
 */
LPMYSTR	j_quote_char (LPMYSTR lpWord)
{
	LPMYSTR	lpQuotedWord ;
	LPMYSTR	lpSrc ;
	int		iLength ;
	/* �����ƁAlisp �̖��߂������ꍇ�ɂ͏C�����Ȃ��B�ł��Askkinput ���� *
	 * �߂ł��� lisp �̖��߂��ď��Ȃ�����c�B*/
	if (!lpWord || !*lpWord)
		return	NULL ;
	if (*lpWord == MYTEXT ('(')){
		iLength	= Mylstrlen (lpWord) ;
		if (iLength > 2 &&
			((MYTEXT ('a') <= lpWord [1] && lpWord [1] <= MYTEXT ('z')) ||
			 (MYTEXT ('A') <= lpWord [1] && lpWord [1] <= MYTEXT ('Z'))) &&
			lpWord [iLength - 1] == MYTEXT (')'))
			return	NULL ;
	}
	/* �����ɏC�����Ȃ��Ƃ����Ȃ������������Ă��邩�ǂ����`�F�b�N����B*/
	lpSrc	= lpWord ;
	while (!*lpSrc){
		if (0 <= *lpSrc && *lpSrc < 128){
			/* quote ���Ȃ���΂Ȃ�Ȃ����������t�������ۂ�? */
			if (*lpSrc == MYTEXT ('/') ||
				*lpSrc == MYTEXT ('\n') ||
				*lpSrc == MYTEXT ('\r') ||
				*lpSrc == MYTEXT ('\\') ||
				*lpSrc == MYTEXT ('[') ||
				*lpSrc == MYTEXT (']')){
				/* quote ����B*/
				iLength	= j_quote_char_sub (NULL, lpWord) ;
				if (iLength <= 0)
					return	NULL ;
				lpQuotedWord	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * iLength) ;
				if (!lpQuotedWord)
					return	NULL ;
				(void)j_quote_char_sub (lpQuotedWord, lpWord) ;
				return	lpQuotedWord ;
			}
		}
		lpSrc	++ ;
	}
	return	NULL ;
}

/*
 * ���̂܂܎����o�^����Ă��܂��Ƃ܂����l�B��ϊ�����֐��B
 *----
 * �̃T�u�����ǁB
 */
int		j_quote_char_sub (LPMYSTR lpDest, LPMYSTR lpWord)
{
	LPMYSTR		lpsptr ;
	int			iBufSize ;
	CHARSTRPAIR	convpattern []	= {
		{ MYTEXT ('\r'),	MYTEXT ("\\r") },
		{ MYTEXT ('\n'),	MYTEXT ("\\n") },
		{ MYTEXT ('/'),		MYTEXT ("\\057") },
		{ MYTEXT ('\\'),	MYTEXT ("\\\\") },
		{ MYTEXT ('['),		MYTEXT ("[") },
		{ MYTEXT ('\"'),	MYTEXT ("\\\"") },
	} ;
	LPCHARSTRPAIR	cptr ;
	int			i ;
#if !defined(MIXED_UNICODE_ANSI) && !defined (UNICODE)
	int			iLeadChar ;
	iLeadChar	= 0 ;
#endif
	/* �܂��͂��܂��Ȃ���p�ӂ���B*/
	iBufSize	= 0 ;
	if (lpDest){
		Mylstrcpy (lpDest, MYTEXT ("(concat \")")) ;
		iBufSize	= Mylstrlen (lpDest) ;
		lpDest		+= iBufSize ;
	} else {
		iBufSize	= Mylstrlen (MYTEXT ("(concat \")")) ;
	}
	lpsptr		= lpWord ;
	while (*lpsptr){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (0 <= *lpsptr && *lpsptr < 128){
			cptr	= convpattern ;
			i		= sizeof (convpattern) / sizeof (CHARSTRPAIR) ;
			while (i > 0){
				if (*lpsptr == cptr->m_chara){
					iBufSize	+= Mylstrlen (cptr->m_lpString) - 1 ;
					break ;
				}
				cptr	++ ;
				i 		-- ;
			}
		}
#else
		if (iLeadChar){
			iLeadChar	= MYTEXT ('\0') ;
		} else {
			if (IsDBCSLeadByte (*lpsptr)){
				iLeadChar	= *lpsptr ;
			} else {
				cptr	= convpattern ;
				i		= sizeof (convpattern) / sizeof (CHARSTRPAIR) ;
				while (i > 0){
					if (*lpsptr == cptr->m_chara){
						iBufSize	+= Mylstrlen (cptr->m_lpString) - 1 ;
						break ;
					}
					cptr	++ ;
					i 		-- ;
				}
			}
		}
#endif
		if (lpDest)
			*lpDest	++	= *lpsptr ;
		lpsptr		++ ;
		iBufSize	++ ;
	}
	if (lpDest){
		*lpDest	++	= MYTEXT ('\"') ;
		*lpDest	++	= MYTEXT (')') ;
		*lpDest		= MYTEXT ('\0') ;
	}
	iBufSize	+= 3 ;
	return	iBufSize ;
}

