#include <windows.h>
#include "mylocale.h"
#include "mystring.h"
#include "lisp.h"

/*
 *	Definitions
 */
#define	SKKLISP_STRING_NORMAL		(0)
#define	SKKLISP_STRING_BACKSLASH	(1)
#define	SKKLISP_STRING_HEX			(2)
#define	SKKLISP_STRING_OCT			(3)

/*
 *	Prototypes
 */
static	BOOL			skkinputlisp_ConsNodeStringIsIntegerP (LPMYSTR lpString) ;
static	int				char_to_number (int chara) ;

static	LPSKKLISPENTITY	skkinputlisp_ConsNodeString2Atom (LPMYSTR lpString) ;
static	LPSKKLISPENTITY	skkinputlisp_ConsNodeString2Integer (LPMYSTR lpString) ;
static	LPSKKLISPENTITY	skkinputlisp_ConsNodeString2String (LPMYSTR lpString) ;
static	LPSKKLISPENTITY	skkinputlisp_ConsNode2Array (LPCONSLIST lpConsListTop) ;
static	int				skkinputlisp_CountArraySizeFromConsList (LPCONSLIST lpConsListTop) ;

/*
 *	Global Functions
 */

LPSKKLISPENTITY	skkinputlisp_ConsNode2Entity (LPCONSNODE lpConsNode)
{
	if (!lpConsNode)
		return	NULL ;
	switch (lpConsNode->m_iType){
	case TYPE_CONSLIST_STRING:
		return	skkinputlisp_ConsNodeString2Atom (lpConsNode->m_lpValue) ;
	case TYPE_CONSLIST_CONSPAIR:
		return	skkinputlisp_ConsList2Entity (lpConsNode->m_lpValue) ;
	case TYPE_CONSLIST_ARRAY:
		return	skkinputlisp_ConsNode2Array (lpConsNode->m_lpValue) ;
	default:
		return	NULL ;
	}
}

LPSKKLISPENTITY	skkinputlisp_ConsList2Entity (LPCONSLIST lpConsList)
{
	SKKLISPENTITY	newEntity ;
	LPSKKLISPENTITY	lpLeftEntity ;
	LPSKKLISPENTITY	lpRightEntity ;
	if (!lpConsList)
		return	skkinputlisp_NilEntity () ;
	lpLeftEntity	= skkinputlisp_ConsNode2Entity (&lpConsList->m_left) ;
	if (!lpLeftEntity)
		return	NULL ;
	lpRightEntity	= skkinputlisp_ConsNode2Entity (&lpConsList->m_right) ;
	if (!lpRightEntity)
		return	NULL ;
	newEntity.m_iType								= ENTITY_CONS ;
	newEntity.m_data.m_conspair.m_lpLeftEntity		= lpLeftEntity ;
	newEntity.m_data.m_conspair.m_lpRightEntity		= lpRightEntity ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

/*
 *	Private Functions
 */
LPSKKLISPENTITY	skkinputlisp_ConsNodeString2Atom (LPMYSTR lpString)
{
	SKKLISPENTITY	newEntity ;
	if (!lpString)
		return	NULL ;
	if (*lpString == MYTEXT ('\x22')){
		return	skkinputlisp_ConsNodeString2String (lpString) ;
	} else if (skkinputlisp_ConsNodeStringIsIntegerP (lpString)){
		return	skkinputlisp_ConsNodeString2Integer (lpString) ;
	} else if (!Mylstrcmp (lpString, MYTEXT ("nil"))){
		return	skkinputlisp_NilEntity () ;
	} else if (!Mylstrcmp (lpString, MYTEXT ("t"))){
		return	skkinputlisp_TEntity () ;
	}
	newEntity.m_iType			= ENTITY_ATOM ;
	newEntity.m_data.m_lpString	= lpString ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

BOOL		skkinputlisp_ConsNodeStringIsIntegerP (LPMYSTR lpString)
{
	/* �擪�������������ꍇ�ɂ́A�����␔�l�ł͂Ȃ����Ƌ^���B*/
	if (*lpString < 0 || *lpString > 127)
		return	FALSE ;
	if (*lpString == MYTEXT ('?'))
		return	TRUE ;
	if (*lpString == MYTEXT ('+') || *lpString == MYTEXT ('-'))
		lpString	++ ;
	if (MYTEXT ('0') <= *lpString && *lpString <= MYTEXT ('9')){
		LPMYSTR	lpptr	= lpString ;
		while (*lpptr){
			if (MYTEXT ('0') > *lpString || *lpString > MYTEXT ('9'))
				break ;
			lpptr ++ ;
		}
		if (!*lpptr)
			return	TRUE ;
	}
	return	FALSE ;
}

/*
 * ���������l���ƍl���č��ꍇ�c�B
 */
LPSKKLISPENTITY	skkinputlisp_ConsNodeString2Integer (LPMYSTR lpString)
{
	SKKLISPENTITY	newEntity ;
	LPMYSTR			lpptr ;
	int				iValue ;
	int				iSign ;

	lpptr	= lpString ;
	iValue	= 0 ;
	iSign	= 1 ;
	if (*lpString == MYTEXT ('?')){
		lpptr	++ ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		iValue	= *lpptr ;
#else
		if (IsDBCSLeadByte (*lpptr)){
			iValue	= *lpptr & 0x00FF ;
			lpptr	++ ;
			iValue	= (iValue << 8) | (*lpptr & 0x00FF) ;
		} else {
			iValue	= *lpptr ;
		}
#endif
	} else {
		iSign	= 1 ;
		if (*lpptr == MYTEXT ('+')){
			lpptr	++ ;
		} else if (*lpptr == MYTEXT ('-')){
			lpptr	++ ;
			iSign	= -1 ;
		}
		while (*lpptr){
			iValue	= iValue * 10 + (*lpptr - MYTEXT ('0')) ;
			lpptr	++ ;
		}
		iValue	= iValue * iSign ;
	}
	newEntity.m_iType			= ENTITY_INTEGER ;
	newEntity.m_data.m_integer	= iValue ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

/*
 * �����ɗ^����ꂽ����������߂��� entity �ɕϊ�����֐��B
 */
LPSKKLISPENTITY	skkinputlisp_ConsNodeString2String (LPMYSTR lpString)
{
	LPSKKLISPENTITY	lpResult ;
	SKKLISPENTITY	newEntity ;
	LPMYSTR			lpDestString ;
	LPMYSTR			lpDestPtr ;
	int				iMode ;
	int				iNum ;
	int				iTempNum ;
	int				iLength ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	int				iPreviousChara ;
#endif
	int				chara ;

	lpString	++ ;
	lpDestString	= HeapAlloc (GetProcessHeap (), 0, sizeof (MYCHAR) * (Mylstrlen (lpString) + 1)) ;
	if (!lpDestString)
		return	NULL ;

	iNum			= 0 ;
	iLength			= 0 ;
	iMode			= SKKLISP_STRING_NORMAL ;
	lpDestPtr		= lpDestString ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	iPreviousChara	= MYTEXT ('\0') ;
#endif

	/* ������̃R�s�[���J�n����B*/
	while (*lpString && *lpString != MYTEXT ('\x22')){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		chara	= *lpString ++ ;
#else
		if (iPreviousChara){
			chara			= (iPreviousChara << 8) | (*lpString & 0x00FF) ;
			iPreviousChara	= MYTEXT ('\0') ;
		} else {
			if (IsDBCSLeadByte (*lpString)){
				iPreviousChara	= *lpString & 0x00FF ;
				lpString	++ ;
				continue ;
			}
			chara			= *lpString ;
		}
		lpString	++ ;
#endif
		switch (iMode){
		case	SKKLISP_STRING_NORMAL:
			if (chara == MYTEXT ('\\')){
				iMode		= SKKLISP_STRING_BACKSLASH ;
				iNum		= 0 ;
				continue ;
			}
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			*lpDestPtr ++	= chara ;
			iLength	++ ;
#else
			if (chara > 0x100){
				*lpDestPtr ++	= (char)((chara >> 8) & 0x00FF) ;
				iLength ++ ;
			}
			*lpDestPtr ++	= (char)(chara & 0x00FF) ;
			iLength ++ ;
#endif
			break ;
		case	SKKLISP_STRING_BACKSLASH :
			if (chara > 127){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				*lpDestPtr ++	= chara ;
				iLength	++ ;
#else
				if (chara > 0x100){
					*lpDestPtr ++	= (char)((chara >> 8) & 0x00FF) ;
					iLength ++ ;
				}
				*lpDestPtr ++	= (char)(chara & 0x00FF) ;
				iLength ++ ;
#endif
				iMode			= SKKLISP_STRING_NORMAL ;
			} else {
				if (chara == MYTEXT ('x')){
					iMode	= SKKLISP_STRING_HEX ;
				} else if ((MYTEXT ('a') <= chara && chara <= MYTEXT ('f')) ||
						   (MYTEXT ('A') <= chara && chara <= MYTEXT ('F'))){
					/* �����������A���t�@�x�b�g�� a ���� f �̒��ɂ���΁B*/
					iMode	= SKKLISP_STRING_HEX ;
					iNum	= char_to_number (chara) ;
				} else if (MYTEXT ('0') <= chara && chara <= MYTEXT ('7')){
					/* ���������������������ꍇ�ɂ� 8 �i�����Ǝv���Ċ��肷��B*/
					iMode	= SKKLISP_STRING_OCT ;
					iNum	= chara - MYTEXT ('0') ;
				} else {
					/* ����ȊO�̕����������ꍇ�̏����B*/
					switch (chara){
						/* ���s�R�[�h�͎c���B*/
					case MYTEXT ('r'):
					case MYTEXT ('n'):
						*lpDestPtr ++	= MYTEXT ('\x0D') ;
						iLength ++ ;
						*lpDestPtr ++	= MYTEXT ('\x0A') ;
						iLength ++ ;
						break ;
						/* �ʓ|�Ȃ̂Ń^�u�̓X�y�[�X��ɕϊ�����B*/
					case MYTEXT ('t'):
						*lpDestPtr ++	= MYTEXT (' ') ;
						iLength ++ ;
						iMode			= SKKLISP_STRING_NORMAL ;
						break ;
					default :
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						*lpDestPtr ++	= chara ;
						iLength	++ ;
#else
						if (chara > 0x100){
							*lpDestPtr ++	= (char)((chara >> 8) & 0x00FF) ;
							iLength ++ ;
						}
						*lpDestPtr ++	= (char)(chara & 0x00FF) ;
						iLength ++ ;
#endif
						iMode			= SKKLISP_STRING_NORMAL ;
						break ;
					}
				}
			}
			break ;

		case SKKLISP_STRING_HEX :
			iTempNum	= char_to_number (chara) ;
			if (iTempNum >= 0){
				iTempNum	+= (iNum << 4) ;
				if (iTempNum >= 0x80){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
					*lpDestPtr ++	= iNum ;
					iLength ++ ;
					*lpDestPtr ++	= chara ;
					iLength	++ ;
#else
					*lpDestPtr ++	= (char)iNum ;
					iLength ++ ;
					if (chara > 0x100){
						*lpDestPtr ++	= (char)((chara >> 8) & 0x00FF) ;
						iLength ++ ;
					}
					*lpDestPtr ++	= (char)(chara & 0x00FF) ;
					iLength ++ ;
#endif
					iMode			= SKKLISP_STRING_NORMAL ;
				} else {
					iNum			= iTempNum ;
				}
			} else {
				/* ���l�łȂ��Ȃ����̂Ȃ��~����B*/
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				*lpDestPtr ++	= iNum ;
				iLength ++ ;
				*lpDestPtr ++	= chara ;
				iLength	++ ;
#else
				*lpDestPtr ++	= (char)iNum ;
				iLength ++ ;
				if (chara > 0x100){
					*lpDestPtr ++	= (char)((chara >> 8) & 0x00FF) ;
					iLength ++ ;
				}
				*lpDestPtr ++	= (char)(chara & 0x00FF) ;
				iLength ++ ;
#endif
				iMode			= SKKLISP_STRING_NORMAL ;
			}
			break ;

		case SKKLISP_STRING_OCT :
			if (MYTEXT ('0') <= chara && chara <= MYTEXT ('7')){
				iTempNum	= (chara - MYTEXT ('0')) + iNum * 8 ;
				if (iTempNum >= 0x80){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
					*lpDestPtr ++	= iNum ;
					iLength ++ ;
					*lpDestPtr ++	= chara ;
					iLength	++ ;
#else
					*lpDestPtr ++	= (char)iNum ;
					iLength ++ ;
					if (chara > 0x100){
						*lpDestPtr ++	= (char)((chara >> 8) & 0x00FF) ;
						iLength ++ ;
					}
					*lpDestPtr ++	= (char)(chara & 0x00FF) ;
					iLength ++ ;
#endif
					iMode			= SKKLISP_STRING_NORMAL ;
				} else {
					iNum			= iTempNum ;
				}
			} else {
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				*lpDestPtr ++	= iNum ;
				iLength ++ ;
				*lpDestPtr ++	= chara ;
				iLength	++ ;
#else
				*lpDestPtr ++	= (char)iNum ;
				iLength ++ ;
				if (chara > 0x100){
					*lpDestPtr ++	= (char)((chara >> 8) & 0x00FF) ;
					iLength ++ ;
				}
				*lpDestPtr ++	= (char)(chara & 0x00FF) ;
				iLength ++ ;
#endif
				iMode			= SKKLISP_STRING_NORMAL ;
			}
			break ;
		default :
			break ;
		}
	}
	if (iMode == SKKLISP_STRING_OCT || iMode == SKKLISP_STRING_HEX){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		*lpDestPtr ++	= iNum ;
#else
		*lpDestPtr ++	= (char)iNum ;
#endif
	}
	*lpDestPtr	= MYTEXT ('\0') ;

	newEntity.m_iType			= ENTITY_STRING ;
	newEntity.m_data.m_lpString	= lpDestString ;
	lpResult					= skkinputlisp_CreateNewEntity (&newEntity) ;
	HeapFree (GetProcessHeap (), 0, lpDestString) ;
	return	lpResult ;
}

LPSKKLISPENTITY		skkinputlisp_ConsNode2Array (LPCONSLIST lpConsListTop)
{
	LPCONSLIST				lpConsList ;
	LPSKKLISPENTITY			lpEntity ;
	LPSKKLISPENTITY	FAR*	lpEntityPtr ;
	LPSKKLISPENTITY			lpRet ;
	SKKLISPENTITY			newEntity ;
	int						iNumberOfItems ;
	int						iCount ;

	iNumberOfItems		= skkinputlisp_CountArraySizeFromConsList (lpConsListTop) ;
	newEntity.m_iType	= ENTITY_ARRAY ;
	if (iNumberOfItems <= 0){
		newEntity.m_data.m_array.m_iLength	= 0 ;
		newEntity.m_data.m_array.m_lpArray	= NULL ;
	} else {
		newEntity.m_data.m_array.m_iLength	= iNumberOfItems ;
		newEntity.m_data.m_array.m_lpArray	= HeapAlloc (GetProcessHeap (), 0, sizeof (LPSKKLISPENTITY) * iNumberOfItems) ;
		if (!newEntity.m_data.m_array.m_lpArray)
			return	NULL ;
		lpEntityPtr	= newEntity.m_data.m_array.m_lpArray ;
		iCount		= 0 ;
		lpConsList	= lpConsListTop ;
		while (lpConsList && iCount < iNumberOfItems){
			switch (lpConsList->m_left.m_iType){
			case TYPE_CONSLIST_ARRAY:
				lpRet	= skkinputlisp_ConsNode2Array (lpConsList->m_left.m_lpValue) ;
				if (!lpRet)
					goto	conslist2array_error2 ;
				*lpEntityPtr	= lpRet ;
				break ;
			case TYPE_CONSLIST_CONSPAIR:
				if (!lpConsList->m_left.m_lpValue){
					lpRet	= skkinputlisp_NilEntity () ;
				} else {
					lpRet	= skkinputlisp_ConsList2Entity (lpConsList->m_left.m_lpValue) ;
				}
				if (!lpRet)
					goto	conslist2array_error2 ;
				*lpEntityPtr	= lpRet ;
				break ;
			case TYPE_CONSLIST_STRING:
				lpRet	= skkinputlisp_ConsNodeString2Atom (lpConsList->m_left.m_lpValue) ;
				if (!lpRet)
					goto	conslist2array_error2 ;
				*lpEntityPtr	= lpRet ;
				break ;
			default:
				break ;
			}
			lpEntityPtr	++ ;
			iCount		++ ;
			lpConsList	= lpConsList->m_right.m_lpValue ;
		}
	}
	lpEntity	= skkinputlisp_CreateNewEntity (&newEntity) ;
	if (newEntity.m_data.m_array.m_lpArray)
		HeapFree (GetProcessHeap (), 0, newEntity.m_data.m_array.m_lpArray) ;
	return	lpEntity ;

conslist2array_error2:
	HeapFree (GetProcessHeap (), 0, newEntity.m_data.m_array.m_lpArray) ;
	return	NULL ;
}

/*
 * �z��̑傫���𐔂���֐��B
 */
int			skkinputlisp_CountArraySizeFromConsList (LPCONSLIST lpConsListTop)
{
	LPCONSLIST	lpConsListNode ;
	int			iNumberOfItems ;

	lpConsListNode	= lpConsListTop ;
	if (!lpConsListNode)
		return	0 ;
	iNumberOfItems	= 1 ;
	while (lpConsListNode){
		if (lpConsListNode->m_right.m_iType != TYPE_CONSLIST_ARRAY ||
			!lpConsListNode->m_right.m_lpValue)
			break ;
		lpConsListNode		= lpConsListNode->m_right.m_lpValue ;
		iNumberOfItems	++ ;
	}
	return	iNumberOfItems ;
}

/*
 * �����𐔒l�ɒ����֐��B
 */
int		char_to_number (int chara)
{
	/* a ���� f �̊Ԃɓ���ꍇ�B*/
	if (MYTEXT ('a') <= chara && chara <= MYTEXT ('f'))
		return	(chara - MYTEXT ('a') + 10) ;
	/* A ���� F �̊Ԃɓ���ꍇ�B*/
	if (MYTEXT ('A') <= chara && chara <= MYTEXT ('F'))
		return	(chara - MYTEXT ('A') + 10) ;
	/* ����ȊO�͐��l�B*/
	if (MYTEXT ('0') <= chara && chara <= MYTEXT ('9'))
		return  (chara - MYTEXT ('0')) ;
	return	-1 ;
}


