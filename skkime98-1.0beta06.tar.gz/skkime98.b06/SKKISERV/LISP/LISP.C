#ifdef LISP_DEBUG
#include <stdio.h>
#include "windows.h"
#include "mylocale.h"
#include "lisp.h"
#include "mystring.h"

/*
 *
 */
static	SKKLISPENV	skkinputlispGlobalEnvironment ;

BOOL	skkiserv_LispInit  (void)
{
	/* Global ���̏������B*/
	skkinputlispGlobalEnvironment.m_lpVariableListTop	= NULL ;
	skkinputlispGlobalEnvironment.m_lpFunctionListTop	= NULL ;
	skkinputlispGlobalEnvironment.m_lpPrevious			= NULL ;
	skkinputlispGlobalEnvironment.m_lpNext				= NULL ;
	/* Entity List �̏������B*/
	skkinputlisp_InitEntity () ;
	return	TRUE ;
}

BOOL	skkiserv_LispClear (void)
{
	/* Global ���̉���B*/
	skkinputlisp_DestroyEnvironment (skkinputlispGlobalEnvironment.m_lpNext) ;
	skkinputlisp_DestroyVariables (&skkinputlispGlobalEnvironment) ;
	skkinputlisp_DestroyFunctions (&skkinputlispGlobalEnvironment) ;
	/* Entity List �̉���B*/
	skkinputlisp_ClearAllEntities () ;
	return	TRUE ;
}

BOOL	skkiserv_eval (LPMYSTR lpString, LPMYSTR lpBuffer, int iBufSize)
{
	LPSKKLISPENTITY	lpEntity ;
	BOOL			fRetValue ;
	lpEntity		= skkinputlisp_String2Entity (lpString) ;
	if (!lpEntity)
		return	FALSE ;
	lpEntity		= skkinputlisp_EvalEntity (lpEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity)
		return	FALSE ;
	/* ������łȂ���΂Ȃ�Ȃ��B*/
	if (lpEntity->m_iType == ENTITY_STRING){
		if (!lpEntity->m_data.m_lpString){
			if (lpBuffer && iBufSize > 0)
				*lpBuffer	= MYTEXT ('\0') ;
		} else {
			if (lpBuffer && iBufSize > 0){
				Mylstrncpy (lpBuffer, lpEntity->m_data.m_lpString, iBufSize) ;
				lpBuffer [iBufSize - 1]	= MYTEXT ('\0') ;
			}
		}
		fRetValue	= TRUE ;
	} else {
		fRetValue	= FALSE ;
	}
	return	fRetValue ;
}

/*
 * �e�X�g�Ȑl�̃��C���ł��B
 */
int main (int argc, char* argv[])
{
	LPSKKLISPENTITY	lpEntity ;
	MYCHAR			buffer [1024] ;
	int				iLength ;

	skkiserv_LispInit () ;
	/* ���C�����[�v�B*/
	while (1){
		printf ("> ") ;
		if (fgets (buffer, 1024, stdin) == NULL)
 			break ;
		iLength = Mylstrlen (buffer) ;
		if (buffer [iLength - 1] != MYTEXT ('\n') || buffer [0] == MYTEXT ('\n')){
			/* ���߂���s�͋p������B*/
			continue ;
		} else {
			buffer [iLength - 1]	= MYTEXT ('\0') ;
		}
		lpEntity	= skkinputlisp_String2Entity (buffer) ;
		lpEntity	= skkinputlisp_EvalEntity (lpEntity, &skkinputlispGlobalEnvironment) ;
		if (lpEntity){
			skkinputlisp_PrintEntity (lpEntity) ;
			printf( "\n" ) ;
		}
		skkinputlisp_GarbageCollection () ;
	}
	skkiserv_LispClear () ;
	return 0 ;
}

#endif 
