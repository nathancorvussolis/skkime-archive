/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * uirecord.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdio.h"
#include "windows.h"
#include "tchar.h"
#include "skkiserv.h"
#include "uirecord.h"
#include "charset.h"
#include "mystring.h"

/*
 *	Definitions
 */
#define	READBUFSIZE		(4096)

/*
 *	Prototypes
 */
static	int				SKKCandidateRecordHashFunction (LPMYSTR lpHenkanKey) ;
static	LPSKKCANDRECORD	SKKAllocNewCandidateRecordP (void) ;
static	LPSKKCANDRECORD	SKKAllocNewCandidateRecord (LPMYSTR lpHenkanKey) ;
static	int				CompareStringAndCandidate (LPMYSTR lpString, LPLISTBUFFER lpListBuffer, int iPosition, int iLength) ;
static	LPSKKCANDRECORD	SKKFindCandidateRecord (LPMYSTR lpHenkanKey, LPSKKCANDRECORD FAR* lppTable) ;
static	BOOL			SKKMakeServerResultFromRecord (LPMYSTR lpDest, int iDestSize, LPVECTORINDEX lpVectorIndex) ;
static	LPLISTBUFFER	SKKMakeServerResultListBufferFromRecord (LPLISTBUFFER lpListBuffer, LPVECTORINDEX lpVectorIndex) ;
static	BOOL			SKKRecordConversionHistory (LPSKKCANDRECORD FAR* lppConversionHistory, LPSKKCANDRECORD lpCandRec) ;
static	LPSKKCANDRECORD	SKKFindAndCreateCandidate (LPSKKCANDRECORD lpCandRec, LPMYSTR lpHenkanKey, LPSKKCANDRECORD lpProvideRec) ;
static	LPVECTORINDEX	SKKFindPastConversionResult (LPVECTORINDEX lpResultRecord, LPMYSTR lpCurrentResult) ;
static	BOOL			SKKMoveVectorIndexToHead (LPVECTORINDEX FAR* lppVectorIndexTop, LPVECTORINDEX lpVectorIndex) ;
static	BOOL			SKKFindCandidateRecordWithHenkanKey (LPSKKCANDRECORD FAR* lppRecordTop, LPMYSTR lpHenkanKey, LPMYSTR lpResultStr, LPSKKCANDRECORD FAR* lppPrevRecordRet, LPSKKCANDRECORD FAR* lppRecordRet, LPVECTORINDEX FAR* lppVectorIndexRet) ;
static	BOOL			SKKDeleteNodeInBinaryTree (LPSKKCANDRECORD FAR* lppRootNode, LPSKKCANDRECORD FAR* lppHeadNode, LPSKKCANDRECORD lpParentNode, LPSKKCANDRECORD lpDelCandRec) ;
static	void			SKKClearCandidateRecordSub (LPSKKCANDRECORD lpCandRec) ;
static	int				SKKMakeServerResultFromRecord2 (LPMYSTR lpDest, int iDestSize, LPVECTORINDEX lpVectorIndex) ;
static	long			SKKUpdateHenkanResult (LPWINFILE lpSrcWinFile, LPWINFILE lpDestWinFile, BOOL fOkuri, LPCMYSTR lpDaimoku, int iCodingSystem) ;
static	long			SKKWriteRecordCandidate (LPWINFILE lpDestWinFile, LPWINFILE lpSrcWinFile, BOOL fOkuri, int iCodingSystem) ;

#ifdef OBSOLETE
static	LPLISTBUFFER	SKKRecordCandidate (LPLISTBUFFER lpListBufferTop, LPVECTORINDEX lpVectorIndex) ;
static	BOOL			SKKFindCandidateRecordWithHenkanKey2 (LPSKKCANDRECORD FAR* lppRecordTop, LPMYSTR lpHenkanKey, LPVECTORINDEX lpKeyVI, LPSKKCANDRECORD FAR* lppPrevRecordRet, LPSKKCANDRECORD FAR* lppRecordRet, LPVECTORINDEX FAR* lppVectorIndexRet) ;
#endif

/*
 *	Global Variables
 */
static	LPLISTBUFFER	lpCandidateRecordListBuffer ;
static	LPSKKCANDRECORD	lpCandidateRecordList ;
static	LPSKKCANDRECORD	lpOkuriCandidateRecordList ;
static	LPSKKCANDRECORD	lpPurgeCandidateList ;
static	LPSKKCANDRECORD	lpPurgeOkuriCandidateList ;
static	LPSKKCANDRECORD	lpCandidateRecordHash [HENKANKAKUTEIHASHSIZE] ;
static	LPSKKCANDRECORD	lpOkuriCandidateRecordHash [HENKANKAKUTEIHASHSIZE] ;
static	LPSKKCANDRECORD	lpPurgeCandidateHash [HENKANKAKUTEIHASHSIZE] ;
static	LPSKKCANDRECORD	lpPurgeOkuriCandidateHash [HENKANKAKUTEIHASHSIZE] ;
#ifdef DEBUG
FILE*	debug_fp	= NULL ;
#endif

/*
 *	Global Functions
 */

void	SKKInitCandidateRecord (void)
{
	int	i ;
	/* �n�b�V���e�[�u�����̂̏������B*/
	for (i = 0 ; i < HENKANKAKUTEIHASHSIZE ; i ++){
		lpCandidateRecordHash [i]		= NULL ;
		lpOkuriCandidateRecordHash [i]	= NULL ;
		lpPurgeCandidateHash [i]			= NULL ;
		lpPurgeOkuriCandidateHash [i]	= NULL ;
	}
	/* ���̑��̃��X�g�̏������B*/
	lpCandidateRecordListBuffer			= NULL ;
	lpCandidateRecordList				= NULL ;
	lpOkuriCandidateRecordList			= NULL ;
	lpPurgeCandidateList				= NULL ;
	lpPurgeOkuriCandidateList			= NULL ;
	return ;
}

/*
 * �n�b�V���e�[�u�����N���A����֐��B
 */
void	SKKClearCandidateRecord (void)
{
	int i ;
	/* �n�b�V���e�[�u���𒭂߂āA���̗v�f��S�Ď̂Ă�B*/
	for (i = 0 ; i < HENKANKAKUTEIHASHSIZE ; i ++){
		if (lpCandidateRecordHash [i]){
			SKKClearCandidateRecordSub (lpCandidateRecordHash [i]) ;
			lpCandidateRecordHash [i]	= NULL ;
		}
		if (lpOkuriCandidateRecordHash [i]){
			SKKClearCandidateRecordSub (lpOkuriCandidateRecordHash [i]) ;
			lpOkuriCandidateRecordHash [i]	= NULL ;
		}
		if (lpPurgeCandidateHash [i]){
			SKKClearCandidateRecordSub (lpPurgeCandidateHash [i]) ;
			lpPurgeCandidateHash [i]	= NULL ;
		}
		if (lpPurgeOkuriCandidateHash [i]){
			SKKClearCandidateRecordSub (lpPurgeOkuriCandidateHash [i]) ;
			lpPurgeOkuriCandidateHash [i]	= NULL ;
		}
	}
	if (lpCandidateRecordListBuffer)
		SKKFreeListBuffer (&lpCandidateRecordListBuffer) ;
	lpCandidateRecordList		= NULL ;
	lpOkuriCandidateRecordList	= NULL ;
	lpPurgeCandidateList		= NULL ;
	lpPurgeOkuriCandidateList	= NULL ;
	return ;
}

BOOL	SKKSearchCandidateRecordList (LPMYSTR lpBuffer, int iBufSize, LPMYSTR lpHenkanKey, BOOL fOkuri)
{
	LPSKKCANDRECORD			lpCandRec ;
	LPSKKCANDRECORD FAR*	lpCandRecTable ;
	lpCandRecTable	= (fOkuri)? lpOkuriCandidateRecordHash : lpCandidateRecordHash ;
	lpCandRec		= SKKFindCandidateRecord (lpHenkanKey, lpCandRecTable) ;
	if (!lpCandRec)
		return	TRUE ;
	return	SKKMakeServerResultFromRecord (lpBuffer, iBufSize, lpCandRec->m_lpCandidate) ;
}

BOOL	SKKSearchCandidatePurgeList (LPMYSTR lpBuffer, int iBufSize, LPMYSTR lpHenkanKey, BOOL fOkuri)
{
	LPSKKCANDRECORD			lpCandRec ;
	LPSKKCANDRECORD FAR*	lpCandRecTable ;
	lpCandRecTable	= (fOkuri)? lpPurgeOkuriCandidateHash : lpPurgeCandidateHash ;
	lpCandRec		= SKKFindCandidateRecord (lpHenkanKey, lpCandRecTable) ;
	if (!lpCandRec)
		return	TRUE ;
	return	SKKMakeServerResultFromRecord (lpBuffer, iBufSize, lpCandRec->m_lpCandidate) ;
}

/*
 * ���ɕϊ��m��Ɏg��ꂽ�L�[�Ƃ��̕ϊ����ʏ��̒��ɐV�����ϊ��L�[��
 * ���̕ϊ����ʂ�������֐��B
 */
BOOL	SKKRecordNewCandidate (LPMYSTR lpHenkanKey, LPMYSTR lpResultStr, BOOL fOkuri)
{
	LPSKKCANDRECORD	FAR*	lppRecordTop ;
	LPSKKCANDRECORD	FAR*	lppPurgeTop ;
	LPSKKCANDRECORD	FAR*	lppRecordHistoryTop ;
	LPSKKCANDRECORD	FAR*	lppPurgeHistoryTop ;
	LPSKKCANDRECORD			lpCandRec ;
	LPSKKCANDRECORD			lpPurgeParentRec ;
	LPSKKCANDRECORD			lpPurgeRec ;
	LPVECTORINDEX			lpVectorIndex ;
	LPVECTORINDEX			lpPurgeVectorIndex ;
	BOOL					fFullRecycle ;
	int						iRet ;

	iRet			= SKKCandidateRecordHashFunction (lpHenkanKey) ;
	fFullRecycle	= FALSE ;

	if (fOkuri){
		lppRecordTop		= &lpOkuriCandidateRecordHash [iRet] ;
		lppPurgeTop			= &lpPurgeOkuriCandidateHash  [iRet] ;
		lppRecordHistoryTop	= &lpOkuriCandidateRecordList ;
		lppPurgeHistoryTop	= &lpPurgeOkuriCandidateList ;
	} else {
		lppRecordTop		= &lpCandidateRecordHash [iRet] ;
		lppPurgeTop			= &lpPurgeCandidateHash  [iRet] ;
		lppRecordHistoryTop	= &lpCandidateRecordList ;
		lppPurgeHistoryTop	= &lpPurgeCandidateList ;
	}

	/* Purge ���X�g�Ɋ��ɂ��̕ϊ��m�茋�ʂ͓����Ă��܂��Ă���̂���� *
	 * ���̂��ȁH ����ƁA����𖕏����Ȃ��Ɗ댯�ł���H */
	/* �ȑO�ϊ��������̂̒��ɑ��݂���H */
	if (SKKFindCandidateRecordWithHenkanKey (lppPurgeTop, lpHenkanKey, lpResultStr, &lpPurgeParentRec, &lpPurgeRec, &lpPurgeVectorIndex)){
		if (lpPurgeVectorIndex == lpPurgeRec->m_lpCandidate){
			lpPurgeRec->m_lpCandidate	= lpPurgeVectorIndex->lpNext ;
			if (!lpPurgeRec->m_lpCandidate){
				SKKDeleteNodeInBinaryTree (lppPurgeTop, lppPurgeHistoryTop, lpPurgeParentRec, lpPurgeRec) ;
				fFullRecycle	= TRUE ;
			} else {
				lpPurgeRec->m_lpCandidate->lpPrevious	= NULL ;
				fFullRecycle	= FALSE ;
			}
		} else {
			if (lpPurgeVectorIndex->lpNext){
				lpPurgeVectorIndex->lpNext->lpPrevious	= lpPurgeVectorIndex->lpPrevious ;
			}
			if (lpPurgeVectorIndex->lpPrevious){
				lpPurgeVectorIndex->lpPrevious->lpNext	= lpPurgeVectorIndex->lpNext ;
			}
			fFullRecycle	= FALSE ;
		}
		/* �����ŁAhPurgeVectorIndex �͗��p���l�����邩������Ȃ��̂ŉ�������Ɋm *
		 * �ۂ��Ă����B*/
	} else {
		lpPurgeRec			= NULL ;
		lpPurgeVectorIndex	= NULL ;
		fFullRecycle		= FALSE ;		
	}

	if (!*lppRecordTop){
		if (lpPurgeRec){
			if (fFullRecycle){
				lpCandRec					= lpPurgeRec ;
				lpCandRec->m_lpLeft			= NULL ;
				lpCandRec->m_lpRight		= NULL ;
				lpCandRec->m_lpPast			= NULL ;
				lpCandRec->m_lpFuture		= NULL ;
				lpCandRec->m_lpCandidate	= NULL ;
			} else {
				lpCandRec					= SKKAllocNewCandidateRecordP () ;
				lpCandRec->m_lpHenkanKey	= lpPurgeRec->m_lpHenkanKey ;
				lpCandRec->m_iPosition		= lpPurgeRec->m_iPosition ;
				lpCandRec->m_iLength		= lpPurgeRec->m_iLength ;
				lpCandRec->m_lpCandidate	= NULL ;
			}
		} else {
			lpCandRec	= SKKAllocNewCandidateRecord (lpHenkanKey) ;
		}
		*lppRecordTop	= lpCandRec ;
	} else {
		/* �񕪒T����p���āA����Ɠ����ϊ������݂��邩�ǂ����𒲂ׂ�B*/
		lpCandRec		= SKKFindAndCreateCandidate (*lppRecordTop, lpHenkanKey, lpPurgeRec) ;
		if (lpPurgeRec && fFullRecycle){
			HeapFree (GetProcessHeap (), 0, lpPurgeRec) ;
		}
	}

	/* �ϊ��L�[���ϊ����ꂽ���ʂ�����B*/
	lpVectorIndex	= lpCandRec->m_lpCandidate ;
	/* �ϊ����ꂽ���ʂƂ������̂����݂���́H ����Ȃ�A���[�v�B*/
	while (lpVectorIndex){
		if (!CompareStringAndCandidate (lpResultStr, lpVectorIndex->lpBuffer, lpVectorIndex->iPosition, lpVectorIndex->iLength)){
			SKKMoveVectorIndexToHead (&lpCandRec->m_lpCandidate, lpVectorIndex) ;
			if (lpPurgeVectorIndex){
				HeapFree (GetProcessHeap (), 0, lpPurgeVectorIndex) ;
				lpPurgeVectorIndex	= NULL ;
			}
			return	TRUE ;
		}
		lpVectorIndex	= lpVectorIndex->lpNext ;
	}
	/* �m�肳�ꂽ���̂����ԏ��ɓ���Ă��郊�X�g�ɉ�����B*/
	SKKRecordConversionHistory (lppRecordHistoryTop, lpCandRec) ;

	/* �����ɂ�����̂悤�ȕϊ��͂Ȃ������c���̏ꍇ�̏����B*/
	if (lpPurgeVectorIndex){
		lpVectorIndex	= lpPurgeVectorIndex ;
	} else {
		lpVectorIndex	= SKKAllocVectorIndex () ;
		if (lpVectorIndex){
			lpVectorIndex->iLength		= Mylstrlen (lpResultStr) ;
			lpCandidateRecordListBuffer	= SKKAddListBuffer (lpCandidateRecordListBuffer, lpResultStr, lpVectorIndex->iLength, &lpVectorIndex->lpBuffer, &lpVectorIndex->iPosition) ;
		}
	}
	if (!lpVectorIndex)
		return	FALSE ;
	lpVectorIndex->lpNext		= lpCandRec->m_lpCandidate ;
	lpVectorIndex->lpPrevious	= NULL ;
	if (lpCandRec->m_lpCandidate){
		lpCandRec->m_lpCandidate->lpPrevious	= lpVectorIndex ;
	}
	lpCandRec->m_lpCandidate	= lpVectorIndex ;
	return	TRUE ;
}

BOOL	SKKPurgeCandidate (LPMYSTR lpHenkanKey, LPMYSTR lpResultStr, BOOL fOkuri)
{
	LPSKKCANDRECORD	FAR*	lppRecordTop ;
	LPSKKCANDRECORD	FAR*	lppPurgeTop ;
	LPSKKCANDRECORD	FAR*	lppRecordHistoryTop ;
	LPSKKCANDRECORD	FAR*	lppPurgeHistoryTop ;
	LPSKKCANDRECORD			lpCandRec ;
	LPSKKCANDRECORD			lpParentCandRec ;
	LPSKKCANDRECORD			lpPurgeRec ;
	LPVECTORINDEX			lpVectorIndex ;
	LPVECTORINDEX			lpPurgeVectorIndex ;
	LPVECTORINDEX			lpPurgeVectorIndexPast ;
	BOOL					fFullRecycle ;
	int						iRet ;

	iRet			= SKKCandidateRecordHashFunction (lpHenkanKey) ;
	fFullRecycle	= FALSE ;

	/* ���艼���ϊ��Ȃ́H ����Ƃ��Ⴄ�́H */
	if (fOkuri){
		lppRecordTop		= &lpOkuriCandidateRecordHash [iRet] ;
		lppPurgeTop			= &lpPurgeOkuriCandidateHash  [iRet] ;
		lppRecordHistoryTop	= &lpOkuriCandidateRecordList ;
		lppPurgeHistoryTop	= &lpPurgeOkuriCandidateList ;
	} else {
		lppRecordTop		= &lpCandidateRecordHash [iRet] ;
		lppPurgeTop			= &lpPurgeCandidateHash  [iRet] ;
		lppRecordHistoryTop	= &lpCandidateRecordList ;
		lppPurgeHistoryTop	= &lpPurgeCandidateList ;
	}
	/* �ȑO�ϊ��������̂̒��ɑ��݂���H */
	if (SKKFindCandidateRecordWithHenkanKey (lppRecordTop, lpHenkanKey, lpResultStr, &lpParentCandRec, &lpCandRec, &lpVectorIndex)){
		if (lpVectorIndex == lpCandRec->m_lpCandidate){
			lpCandRec->m_lpCandidate	= lpVectorIndex->lpNext ;
			/* �S�Ă̕ϊ����ʂ��폜���ꂽ���ƂɂȂ�́H */
			if (!lpCandRec->m_lpCandidate){
				SKKDeleteNodeInBinaryTree (lppRecordTop, lppRecordHistoryTop, lpParentCandRec, lpCandRec) ;
				fFullRecycle	= TRUE ;
			} else {
				lpCandRec->m_lpCandidate->lpPrevious	= NULL ;
				fFullRecycle	= FALSE ;
			}
		} else {
			if (lpVectorIndex->lpNext)
				lpVectorIndex->lpNext->lpPrevious	= lpVectorIndex->lpPrevious ;
			if (lpVectorIndex->lpPrevious)
				lpVectorIndex->lpPrevious->lpNext	= lpVectorIndex->lpNext ;
			fFullRecycle	= FALSE ;
		}
	} else {
		lpVectorIndex	= NULL ;
		lpCandRec		= NULL ;
		fFullRecycle	= FALSE ;
	}
	/* �n�b�V�����q�b�g�������ǂ���������B*/
	if (!*lppPurgeTop){
		/* �n�b�V���̒��ɍ���̂悤�ȕϊ��͓o�^����Ă���܂���B*/
		if (lpCandRec){
			if (fFullRecycle){
				lpPurgeRec	= lpCandRec ;
				lpPurgeRec->m_lpLeft		= NULL ;
				lpPurgeRec->m_lpRight		= NULL ;
				lpPurgeRec->m_lpPast		= NULL ;
				lpPurgeRec->m_lpFuture		= NULL ;
				lpPurgeRec->m_lpCandidate	= NULL ;
			} else {
				lpPurgeRec	= SKKAllocNewCandidateRecordP () ;
				lpPurgeRec->m_lpHenkanKey	= lpCandRec->m_lpHenkanKey ;
				lpPurgeRec->m_iPosition		= lpCandRec->m_iPosition ;
				lpPurgeRec->m_iLength		= lpCandRec->m_iLength ;
				lpPurgeRec->m_lpCandidate	= NULL ;
			}
		} else {
			/* �Ƃ����킯�ŁA�V�����m�[�h���m�ۂ��܂��B*/
			lpPurgeRec	= SKKAllocNewCandidateRecord (lpHenkanKey) ;
		}
		*lppPurgeTop	= lpPurgeRec ;
	} else {
		/* �ȉ��A�񕪒T���œ����ϊ��L�[���g��ꂽ���Ƃ����邩�ǂ����� *
		 * �ׂ܂��B*/
		lpPurgeRec	= SKKFindAndCreateCandidate (*lppPurgeTop, lpHenkanKey, lpCandRec) ;
		if (lpCandRec && fFullRecycle)
			HeapFree (GetProcessHeap (), 0, lpCandRec) ;
	}
	/* �m�肳�ꂽ���̂����ԏ��ɓ���Ă��郊�X�g�ɉ�����B*/
	SKKRecordConversionHistory (lppPurgeHistoryTop, lpPurgeRec) ;
	lpPurgeVectorIndexPast	= SKKFindPastConversionResult (lpPurgeRec->m_lpCandidate, lpResultStr) ;
	/* ���ɓo�^����Ă��܂������H */
	if (lpPurgeVectorIndexPast){
		if (lpVectorIndex){
			HeapFree (GetProcessHeap (), 0, lpVectorIndex) ;
			lpVectorIndex	= NULL ;
		}
	} else {
		lpPurgeVectorIndex		= SKKAllocVectorIndex () ;
		if (lpPurgeVectorIndex){
			lpPurgeVectorIndex->iLength		= Mylstrlen (lpResultStr) ;
			lpCandidateRecordListBuffer		= SKKAddListBuffer (lpCandidateRecordListBuffer, lpResultStr, lpPurgeVectorIndex->iLength, &lpPurgeVectorIndex->lpBuffer, &lpPurgeVectorIndex->iPosition) ;

			lpPurgeVectorIndex->lpNext	= lpPurgeRec->m_lpCandidate ;
			lpPurgeRec->m_lpCandidate	= lpPurgeVectorIndex ;
		}
	}
	return	TRUE ;
}

/*
 * �ϊ��m�肳��ē����ɒ~�����Ă����₩�� completion ���悤�Ƃ���֐��B
 */
BOOL	j_try_completion_record (LPMYSTR lpBuffer, int iBufSize, LPMYSTR lpKey)
{
	LPSKKCANDRECORD	lpCandRec ;
	VECTORINDEX		vNode ;
	int				iLength ;
	int				iRetvalue ;
	int				iResult ;

	if (!lpCandidateRecordList || !lpKey || !*lpKey)
		return	FALSE ;

	lpCandRec	= lpCandidateRecordList ;
	iLength		= Mylstrlen (lpKey) ;

	/* ��₪�s����܂Ő��^�T���ꍇ�B*/
	while (lpCandRec && iBufSize > 0){
		/* �T���L�[���������Ȃ���΁A�ʖڂł���B*/
		if (lpCandRec->m_iLength > iLength){
			/* �T���L�[�ƑO����v���Ȃ���Αʖڂł���B*/
			iRetvalue	= CompareStringAndCandidate (lpKey, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, iLength) ;
			if (!iRetvalue){
				/* ���t�������ꍇ�̏����B*/
				vNode.lpBuffer		= lpCandRec->m_lpHenkanKey ;
				vNode.iPosition		= lpCandRec->m_iPosition ;
				vNode.iLength		= lpCandRec->m_iLength ;
				vNode.lpNext		= NULL ;
				vNode.lpPrevious	= NULL ;
				iResult				= SKKMakeServerResultFromRecord2 (lpBuffer, iBufSize, &vNode) ;
				if (iResult <= 0){
					*lpBuffer		= MYTEXT ('\0') ;
					iBufSize		= 0 ;
				} else {
					lpBuffer		+= iResult ;
					iBufSize		-= iResult ;
				}
			}
		}
		lpCandRec		= lpCandRec->m_lpPast ;
	}
	return	TRUE ;
}

/*
 * �ϊ��m�肳��ē����ɒ~�����Ă����₩�� completion ���悤�Ƃ���֐��B
 */
LPLISTBUFFER	j_try_completion_record2 (LPLISTBUFFER lpListBuffer, LPMYSTR lpKey)
{
	LPSKKCANDRECORD	lpCandRec ;
	VECTORINDEX		vNode ;
	int				iLength ;
	int				iRetvalue ;

	if (!lpCandidateRecordList || !lpKey || !*lpKey)
		return	lpListBuffer ;

	lpCandRec	= lpCandidateRecordList ;
	iLength		= Mylstrlen (lpKey) ;

	/* ��₪�s����܂Ő��^�T���ꍇ�B*/
	while (lpCandRec){
		/* �T���L�[���������Ȃ���΁A�ʖڂł���B*/
		if (lpCandRec->m_iLength > iLength){
			/* �T���L�[�ƑO����v���Ȃ���Αʖڂł���B*/
			iRetvalue	= CompareStringAndCandidate (lpKey, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, iLength) ;
			if (!iRetvalue){
				/* ���t�������ꍇ�̏����B*/
				vNode.lpBuffer		= lpCandRec->m_lpHenkanKey ;
				vNode.iPosition		= lpCandRec->m_iPosition ;
				vNode.iLength		= lpCandRec->m_iLength ;
				vNode.lpNext		= NULL ;
				vNode.lpPrevious	= NULL ;
				lpListBuffer		= SKKMakeServerResultListBufferFromRecord (lpListBuffer, &vNode) ;
			}
		}
		lpCandRec		= lpCandRec->m_lpPast ;
	}
	return	lpListBuffer ;
}

/*
 * 
 */
BOOL	j_try_completion_purge (LPMYSTR lpBuffer, int iBufSize, LPMYSTR lpKey)
{
	LPSKKCANDRECORD	lpCandRec ;
	VECTORINDEX		vNode ;
	int				iLength ;
	int				iRetvalue ;
	int				iResult ;

	if (!lpPurgeCandidateList || !lpKey || !*lpKey)
		return	FALSE ;

	lpCandRec	= lpPurgeCandidateList ;
	iLength		= Mylstrlen (lpKey) ;

	/* ��₪�s����܂Ő��^�T���ꍇ�B*/
	while (lpCandRec && iBufSize > 0){
		/* �T���L�[���������Ȃ���΁A�ʖڂł���B*/
		if (lpCandRec->m_iLength > iLength){
			/* �T���L�[�ƑO����v���Ȃ���Αʖڂł���B*/
			iRetvalue	= CompareStringAndCandidate (lpKey, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, iLength) ;
			if (!iRetvalue){
				/* ���t�������ꍇ�̏����B*/
				vNode.lpBuffer		= lpCandRec->m_lpHenkanKey ;
				vNode.iPosition		= lpCandRec->m_iPosition ;
				vNode.iLength		= lpCandRec->m_iLength ;
				vNode.lpNext		= NULL ;
				vNode.lpPrevious	= NULL ;
				iResult				= SKKMakeServerResultFromRecord2 (lpBuffer, iBufSize, &vNode) ;
				if (iResult <= 0){
					*lpBuffer		= MYTEXT ('\0') ;
					iBufSize		= 0 ;
				} else {
					lpBuffer		+= iResult ;
					iBufSize		-= iResult ;
				}
			}
		}
		lpCandRec		= lpCandRec->m_lpPast ;
	}
	return	TRUE ;
}

LPLISTBUFFER	j_try_completion_purge2 (LPLISTBUFFER lpListBuffer, LPMYSTR lpKey)
{
	LPSKKCANDRECORD	lpCandRec ;
	VECTORINDEX		vNode ;
	int				iLength ;
	int				iRetvalue ;

	if (!lpPurgeCandidateList || !lpKey || !*lpKey)
		return	lpListBuffer ;

	lpCandRec	= lpPurgeCandidateList ;
	iLength		= Mylstrlen (lpKey) ;

	/* ��₪�s����܂Ő��^�T���ꍇ�B*/
	while (lpCandRec){
		/* �T���L�[���������Ȃ���΁A�ʖڂł���B*/
		if (lpCandRec->m_iLength > iLength){
			/* �T���L�[�ƑO����v���Ȃ���Αʖڂł���B*/
			iRetvalue	= CompareStringAndCandidate (lpKey, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, iLength) ;
			if (!iRetvalue){
				/* ���t�������ꍇ�̏����B*/
				vNode.lpBuffer		= lpCandRec->m_lpHenkanKey ;
				vNode.iPosition		= lpCandRec->m_iPosition ;
				vNode.iLength		= lpCandRec->m_iLength ;
				vNode.lpNext		= NULL ;
				vNode.lpPrevious	= NULL ;
				lpListBuffer		= SKKMakeServerResultListBufferFromRecord (lpListBuffer, &vNode) ;
			}
		}
		lpCandRec		= lpCandRec->m_lpPast ;
	}
	return	lpListBuffer ;
}

/*
 * �����ɍ����ɕϊ��m�肵�Ă��������������ފ֐��B
 */
BOOL	SKKUpdateLocalJisho (void)
{
	WINFILE			winTempFile ;
	WINFILE			winSrcFile ;
	LPSTR			lpTempFileName ;
	long			lLines ;
	BOOL			fCreateBackupJisyo ;
	TCHAR			szSkkinputLocalJisho [MAX_PATH] ;
	TCHAR			szSkkinputBackupJisho [MAX_PATH] ;
#if defined (MIXED_UNICODE_ANSI)
	MYCHAR			szMycharBuffer [MAX_PATH + 1] ;
	int				iLength ;
#endif
	int				iSkkinputJishoCodingSystem ;

	/* skkinput-jisyo �̃p�X�𓾂�B*/
#if defined (MIXED_UNICODE_ANSI)
	if (!skkiserv_eval (MYTEXT ("skkinput-jisyo"), szMycharBuffer, MAX_PATH))
		return	FALSE ;
	szMycharBuffer [MAX_PATH]	= MYTEXT ('\0') ;
	iLength	= MystrToShiftJis (szSkkinputLocalJisho, MAX_PATH, szMycharBuffer, MAX_PATH) ;
	if (iLength <= 0)
		iLength	= 0 ;
	szSkkinputLocalJisho [iLength]	= '\0' ;
#else	// !defined (MIXED_UNICODE_ANSI)
	if (!skkiserv_eval (MYTEXT ("skkinput-jisyo"), szSkkinputLocalJisho, MAX_PATH))
		return	FALSE ;
#endif

	/* skkinput-jisyo �̊����R�[�h�𓾂�B*/
	iSkkinputJishoCodingSystem	= j_get_coding_system (MYTEXT ("skkinput-jisyo-code")) ;
	if (iSkkinputJishoCodingSystem < 0){
		/* skkinput-jisyo �̊����R�[�h���w�肳��Ă��Ȃ���΁A���݂���t�@�C�����瓾��B*/
		iSkkinputJishoCodingSystem	= j_detect_coding_system_with_filename (szSkkinputLocalJisho, 1024) ;
		/* �t�@�C�������݂��Ă��Ȃ������ꍇ�ɂ́AEUC-JP �ɂ���B*/
		if (iSkkinputJishoCodingSystem < 0)
			iSkkinputJishoCodingSystem	= KANJI_CODE_EUC ;
	}

	/* �o�b�N�A�b�v�������o�^����Ă��Ȃ�������A�o�b�N�A�b�v�͍��Ȃ��B*/
	fCreateBackupJisyo	= TRUE ;
#if defined (MIXED_UNICODE_ANSI)
	if (skkiserv_eval (MYTEXT ("skkinput-backup-jisyo"), szMycharBuffer, MAX_PATH)){
		szMycharBuffer [MAX_PATH]	= MYTEXT ('\0') ;
		iLength	= MystrToShiftJis (szSkkinputBackupJisho, MAX_PATH, szMycharBuffer, MAX_PATH) ;
		if (iLength <= 0)
			iLength	= 0 ;
		szSkkinputBackupJisho [iLength]	= _T('\0') ;
	} else {
		fCreateBackupJisyo	= FALSE ;
		szSkkinputBackupJisho [0]	= _T ('\0') ;
	}
#else
	if (!skkiserv_eval (MYTEXT ("skkinput-backup-jisyo"), szSkkinputBackupJisho, MAX_PATH)){
		fCreateBackupJisyo	= FALSE ;
		szSkkinputBackupJisho [0]	= _T ('\0') ;
	}
#endif
	lpTempFileName	= tmpnam (NULL) ;
	if (!winfopen (&winTempFile, lpTempFileName, GENERIC_WRITE, CREATE_ALWAYS))
		return	FALSE ;
	lLines	= 0 ;
	if (!winfopen (&winSrcFile,  szSkkinputLocalJisho, GENERIC_READ, OPEN_EXISTING)){
		/* ���艼���ϊ��̌��ʂ��������ށB*/
		lLines	+= SKKUpdateHenkanResult
			(NULL, &winTempFile, TRUE, MYTEXT (";; okuri-ari entries."), iSkkinputJishoCodingSystem) ;
		/* ���艼�������ϊ��̌��ʂ��������ށB*/
		lLines	+= SKKUpdateHenkanResult
			(NULL, &winTempFile, FALSE, MYTEXT (";; okuri-nasi entries."), iSkkinputJishoCodingSystem) ;
		winfclose (&winTempFile) ;
	} else {
		/* ���艼���ϊ��̌��ʂ��������ށB*/
		lLines	+= SKKUpdateHenkanResult
			(&winSrcFile, &winTempFile, TRUE, MYTEXT (";; okuri-ari entries."), iSkkinputJishoCodingSystem) ;
		/* ���艼�������ϊ��̌��ʂ��������ށB*/
		lLines	+= SKKUpdateHenkanResult
			(&winSrcFile, &winTempFile, FALSE, MYTEXT (";; okuri-nasi entries."), iSkkinputJishoCodingSystem) ;
		winfclose (&winSrcFile) ;
		winfclose (&winTempFile) ;
		/* �o�b�N�A�b�v�������쐬����ꍇ�A�o�b�N�A�b�v�����̍쐬�Ɏ��s������G���[�B*/
		if (fCreateBackupJisyo &&
			!MoveFile (szSkkinputLocalJisho, szSkkinputBackupJisho) &&
			!CopyFile (szSkkinputLocalJisho, szSkkinputBackupJisho, FALSE)){
			return	FALSE ;
		}
	}
	if (!MoveFile (lpTempFileName, szSkkinputLocalJisho) &&
		!CopyFile (lpTempFileName, szSkkinputLocalJisho, FALSE)){
		return	FALSE ;
	}
	DeleteFile (lpTempFileName) ;
	SKKClearVectorHashTable () ;
	SKKClearCandidateRecord () ;
	return	TRUE ;
}

/*
 *	Private Functions
 */

int	SKKCandidateRecordHashFunction (LPMYSTR lpHenkanKey)
{
	/* �����łȂ��ăA���t�@�x�b�g�H */
	if (*lpHenkanKey & 0x80){
		return	((*lpHenkanKey & 0x00FF) + Mylstrlen (lpHenkanKey) * 21 + HASHKEY_KANJI) % HENKANKAKUTEIHASHSIZE ;
	} else {
		if (MYTEXT ('a') <= *lpHenkanKey && *lpHenkanKey <= MYTEXT ('z'))
			return HASHKEY_ALPHABET - MYTEXT ('a') + *lpHenkanKey ;
		if (MYTEXT ('A') <= *lpHenkanKey && *lpHenkanKey <= MYTEXT ('Z'))
			return HASHKEY_ALPHABET - MYTEXT ('A') + *lpHenkanKey ;
		return HASHKEY_ASCIIETC ;
	}
}

LPSKKCANDRECORD	SKKAllocNewCandidateRecordP (void)
{
	LPSKKCANDRECORD	lpSkkCandRecord ;
	lpSkkCandRecord	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (SKKCANDRECORD)) ;
	if (lpSkkCandRecord == NULL)
		return	NULL ;
	lpSkkCandRecord->m_lpLeft		= NULL ;
	lpSkkCandRecord->m_lpRight		= NULL ;
	lpSkkCandRecord->m_lpPast		= NULL ;
	lpSkkCandRecord->m_lpFuture		= NULL ;
	lpSkkCandRecord->m_lpCandidate	= NULL ;
	return	lpSkkCandRecord ;
}

LPSKKCANDRECORD	SKKAllocNewCandidateRecord (LPMYSTR lpHenkanKey)
{
	LPSKKCANDRECORD	lpNewCandRecord ;
	LPLISTBUFFER	lpHenkanKeyRet ;
	int				iPositionRet ;
	int				iLength ;
	lpNewCandRecord					= SKKAllocNewCandidateRecordP () ;
	if (!lpNewCandRecord)
		return	NULL ;
	iLength							= Mylstrlen (lpHenkanKey) ;
	lpCandidateRecordListBuffer		= SKKAddListBuffer (lpCandidateRecordListBuffer, lpHenkanKey, iLength, &lpHenkanKeyRet, &iPositionRet) ;
	lpNewCandRecord->m_lpHenkanKey	= lpHenkanKeyRet ;
	lpNewCandRecord->m_iPosition	= iPositionRet ;
	lpNewCandRecord->m_iLength		= iLength ;
	return	lpNewCandRecord ;
}

int	CompareStringAndCandidate (LPMYSTR lpString, LPLISTBUFFER lpListBuffer, int iPosition, int iLength)
{
	LPLISTBUFFER	lpNode ;
	int				iRetvalue ;
	LPMYSTR			lpptr ;
	BOOL			fContinue ;

	lpNode		= lpListBuffer ;	
	fContinue	= TRUE ;
	iRetvalue	= (!lpString || !*lpString)? 0 : (int)*lpString ;
	while (fContinue && lpNode){
		lpptr	= lpNode->text  + iPosition ;
		while (iLength > 0){
			if (*lpString == MYTEXT ('\0')){
				iRetvalue	= -1 ;
				fContinue	= FALSE ;
				break ;
			}
			iRetvalue	= *lpString - *lpptr ;
			if (iRetvalue){
				fContinue	= FALSE ;
				break ;
			}
			lpString	++ ;
			lpptr		++ ;
			iLength		-- ;
		}
		if (!iLength){
			fContinue	= FALSE ;
			iRetvalue	= *lpString - MYTEXT ('\0') ;
		}
		lpNode		= lpNode->lpNext ;
		iPosition	= 0 ;
	}
	return	iRetvalue ;
}

LPSKKCANDRECORD	SKKFindCandidateRecord (LPMYSTR lpHenkanKey, LPSKKCANDRECORD FAR* lppTable)
{
	LPSKKCANDRECORD	lpResultCandRecord ;
	LPSKKCANDRECORD	lpCandRecord ;
	LPSKKCANDRECORD	lpNextCandRecord ;
	int				iHashKey ;
	int				iRetvalue ;

	iHashKey			= SKKCandidateRecordHashFunction (lpHenkanKey) ;
	lpCandRecord		= lppTable [iHashKey] ;
	if (!lpCandRecord)
		return	NULL ;

	lpResultCandRecord	= NULL ;
	while (lpCandRecord){
		iRetvalue		= CompareStringAndCandidate (lpHenkanKey, lpCandRecord->m_lpHenkanKey, lpCandRecord->m_iPosition, lpCandRecord->m_iLength) ;
		if (!iRetvalue){
			lpResultCandRecord	= lpCandRecord ;
			lpNextCandRecord	= NULL ;
		} else if (iRetvalue > 0){
			lpNextCandRecord	= lpCandRecord->m_lpRight ;
		} else {
			lpNextCandRecord	= lpCandRecord->m_lpLeft ;
		}
		lpCandRecord	= lpNextCandRecord ;
	}
	return	lpResultCandRecord ;
}

/*
 *
 */
BOOL	SKKMakeServerResultFromRecord (LPMYSTR lpDest, int iDestSize, LPVECTORINDEX lpVectorIndex)
{
	LPLISTBUFFER	lpBuffer ;
	int				iPosition ;
	int				iLength ;
	int				iPushLength ;

	while (lpVectorIndex && iDestSize > 0){
		/* ���̊Ԃ̋�؂蕶��������B*/
		*lpDest		++		= MYTEXT ('/') ;
		iDestSize	-- ;
		/* ���� 1 �o�^����B*/
		iPosition			= lpVectorIndex->iPosition ;
		iLength				= lpVectorIndex->iLength ;
		lpBuffer			= lpVectorIndex->lpBuffer ;
		if (iDestSize > iLength){
			while (iLength > 0 && lpBuffer){
				if ((iPosition + iLength) > lpBuffer->iUsed){
					iPushLength	= lpBuffer->iUsed - iPosition ;
				} else {
					iPushLength	= iLength ;
				}
				memcpy (lpDest, lpBuffer->text + iPosition, sizeof (MYCHAR) * iPushLength) ;
				lpDest		+= iPushLength ;
				iDestSize	-= iPushLength ;
				iLength		-= iPushLength ;
				if (iLength > 0){
					lpBuffer	= lpBuffer->lpNext ;
					iLength		-= iPushLength ;
				} else {
					lpBuffer	= 0 ;
				}
				iPosition		= 0 ;
			}
			lpVectorIndex		= lpVectorIndex->lpNext ;
		} else {
			lpVectorIndex		= NULL ;
		}
	}
	if (iDestSize > 0){
		*lpDest		++		= MYTEXT ('/') ;
		iDestSize	-- ;
	}
	*lpDest	= MYTEXT ('\0') ;
	return	TRUE ;
}

/*
 *
 */
LPLISTBUFFER	SKKMakeServerResultListBufferFromRecord (LPLISTBUFFER lpListBuffer, LPVECTORINDEX lpVectorIndex)
{
	LPLISTBUFFER	lpBuffer ;
	int				iPosition ;
	int				iLength ;
	int				iPushLength ;

	while (lpVectorIndex){
		/* ���̊Ԃ̋�؂蕶��������B*/
		lpListBuffer		= SKKAddListBuffer (lpListBuffer, MYTEXT ("/"), 1, NULL, NULL) ;
		/* ���� 1 �o�^����B*/
		iPosition			= lpVectorIndex->iPosition ;
		iLength				= lpVectorIndex->iLength ;
		lpBuffer			= lpVectorIndex->lpBuffer ;
		while (iLength > 0 && lpBuffer){
			if ((iPosition + iLength) > lpBuffer->iUsed){
				iPushLength	= lpBuffer->iUsed - iPosition ;
			} else {
				iPushLength	= iLength ;
			}
			lpListBuffer	= SKKAddListBuffer (lpListBuffer, lpBuffer->text + iPosition, iPushLength, NULL, NULL) ;
			iLength			-= iPushLength ;
			if (iLength > 0){
				lpBuffer	= lpBuffer->lpNext ;
				iLength		-= iPushLength ;
			} else {
				lpBuffer	= NULL ;
			}
			iPosition		= 0 ;
		}
		lpVectorIndex		= lpVectorIndex->lpNext ;
	}
	lpListBuffer	= SKKAddListBuffer (lpListBuffer, MYTEXT ("/"), 1, NULL, NULL) ;
	return	lpListBuffer ;
}

LPLISTBUFFER	SKKSearchCandidateRecordList2 (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri)
{
	LPSKKCANDRECORD			lpCandRec ;
	LPSKKCANDRECORD FAR*	lpCandRecTable ;
	lpCandRecTable	= (fOkuri)? lpOkuriCandidateRecordHash : lpCandidateRecordHash ;
	lpCandRec		= SKKFindCandidateRecord (lpHenkanKey, lpCandRecTable) ;
	if (!lpCandRec)
		return	lpListBuffer ;
	return	SKKMakeServerResultListBufferFromRecord (lpListBuffer, lpCandRec->m_lpCandidate) ;
}

LPLISTBUFFER	SKKSearchCandidatePurgeList2 (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri)
{
	LPSKKCANDRECORD			lpCandRec ;
	LPSKKCANDRECORD FAR*	lpCandRecTable ;
	lpCandRecTable	= (fOkuri)? lpPurgeOkuriCandidateHash : lpPurgeCandidateHash ;
	lpCandRec		= SKKFindCandidateRecord (lpHenkanKey, lpCandRecTable) ;
	if (!lpCandRec)
		return	lpListBuffer ;
	return	SKKMakeServerResultListBufferFromRecord (lpListBuffer, lpCandRec->m_lpCandidate) ;
}

BOOL	SKKRecordConversionHistory (LPSKKCANDRECORD FAR* lppConversionHistory, LPSKKCANDRECORD lpCandRec)
{
	if (!lppConversionHistory)
		return	FALSE ;
	if (*lppConversionHistory == lpCandRec)
		return	TRUE ;
	if (lpCandRec->m_lpPast){
		lpCandRec->m_lpPast->m_lpFuture	= lpCandRec->m_lpFuture ;
	}
	if (lpCandRec->m_lpFuture){
		lpCandRec->m_lpFuture->m_lpPast	= lpCandRec->m_lpPast ;
	}
	lpCandRec->m_lpPast		= *lppConversionHistory ;
	lpCandRec->m_lpFuture	= NULL ;
	if (*lppConversionHistory){
		(*lppConversionHistory)->m_lpFuture	= lpCandRec ;
	}
	(*lppConversionHistory) = lpCandRec ;
	return	TRUE ;
}

LPSKKCANDRECORD	SKKFindAndCreateCandidate (LPSKKCANDRECORD lpCandRec, LPMYSTR lpHenkanKey, LPSKKCANDRECORD lpProvideRec)
{
	LPSKKCANDRECORD	lpNewCandRec ;
	int				iRetvalue ;
	while (lpCandRec){
		iRetvalue	= CompareStringAndCandidate (lpHenkanKey, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, lpCandRec->m_iLength) ;
		if (!iRetvalue){
			/* �����ϊ��L�[�ł��B*/
			return	lpCandRec ;
		} else if (iRetvalue > 0){
			/* �E�̎q�������ǂ�ꍇ�B*/
			if (lpCandRec->m_lpRight){
				lpCandRec	= lpCandRec->m_lpRight ;
			} else {
				/* �E�ɂ͂���ȏ�q�������݂��Ȃ��ꍇ�B*/
				if (!lpProvideRec){
					lpNewCandRec	= SKKAllocNewCandidateRecord (lpHenkanKey) ;
					if (lpNewCandRec){
						lpCandRec->m_lpRight		= lpNewCandRec ;
						lpNewCandRec->m_lpCandidate	= NULL ;
					}
				} else {
					lpNewCandRec	= SKKAllocNewCandidateRecordP () ;
					if (lpNewCandRec){
						lpCandRec->m_lpRight		= lpNewCandRec ;
						lpNewCandRec->m_lpHenkanKey	= lpProvideRec->m_lpHenkanKey ;
						lpNewCandRec->m_iPosition	= lpProvideRec->m_iPosition ;
						lpNewCandRec->m_iLength		= lpProvideRec->m_iLength ;
						lpNewCandRec->m_lpCandidate	= NULL ;
					}
				}
				return	lpNewCandRec ;
			}
		} else {
			/* ���̎q�������ǂ�ꍇ�B*/
			if (lpCandRec->m_lpLeft){
				lpCandRec	= lpCandRec->m_lpLeft ;
			} else {
				if (!lpProvideRec){
					lpNewCandRec		= SKKAllocNewCandidateRecord (lpHenkanKey) ;
					if (lpNewCandRec){
						lpCandRec->m_lpLeft			= lpNewCandRec ;
						lpNewCandRec->m_lpCandidate	= NULL ;
					}
				} else {
					lpNewCandRec		= SKKAllocNewCandidateRecordP () ;
					if (lpNewCandRec){
						lpCandRec->m_lpLeft			= lpNewCandRec ;
						lpNewCandRec->m_lpHenkanKey	= lpProvideRec->m_lpHenkanKey ;
						lpNewCandRec->m_iPosition	= lpProvideRec->m_iPosition ;
						lpNewCandRec->m_iLength		= lpProvideRec->m_iLength ;
						lpNewCandRec->m_lpCandidate	= NULL ;
					}
				}
				return	lpNewCandRec ;
			}
		}
	}
	return	NULL ;
}

LPVECTORINDEX	SKKFindPastConversionResult (LPVECTORINDEX lpResultRecord, LPMYSTR lpCurrentResult)
{
	while (lpResultRecord){
		if (!CompareStringAndCandidate (lpCurrentResult, lpResultRecord->lpBuffer,  lpResultRecord->iPosition,  lpResultRecord->iLength))
			return	lpResultRecord ;
		lpResultRecord	= lpResultRecord->lpNext ;
	}
	return	NULL ;
}

BOOL	SKKMoveVectorIndexToHead (LPVECTORINDEX FAR* lppVectorIndexTop, LPVECTORINDEX lpVectorIndex)
{
	if (!lppVectorIndexTop)
		return	FALSE ;
	if (*lppVectorIndexTop == lpVectorIndex)
		return	TRUE ;
	if (lpVectorIndex->lpPrevious)
		lpVectorIndex->lpPrevious->lpNext	= lpVectorIndex->lpNext ;
	if (lpVectorIndex->lpNext)
		lpVectorIndex->lpNext->lpPrevious	= lpVectorIndex->lpPrevious ;
	lpVectorIndex->lpNext		= *lppVectorIndexTop ;
	lpVectorIndex->lpPrevious	= NULL ;
	if (*lppVectorIndexTop)
		(*lppVectorIndexTop)->lpPrevious	= lpVectorIndex ;
	*lppVectorIndexTop			= lpVectorIndex ;
	return	TRUE ;
}

BOOL	SKKFindCandidateRecordWithHenkanKey (LPSKKCANDRECORD FAR* lppRecordTop, LPMYSTR lpHenkanKey, LPMYSTR lpResultStr, LPSKKCANDRECORD FAR* lppPrevRecordRet, LPSKKCANDRECORD FAR* lppRecordRet, LPVECTORINDEX FAR* lppVectorIndexRet)
{
	LPSKKCANDRECORD	lpCandRec ;
	LPSKKCANDRECORD	lpParentCandRec ;
	LPVECTORINDEX	lpVectorIndex ;
	int				iRetvalue ;
	if (!lppRecordTop)
		return	FALSE ;
	lpCandRec		= *lppRecordTop ;
	lpParentCandRec	= NULL ;
	lpVectorIndex	= NULL ;
	while (lpCandRec){
		iRetvalue	= CompareStringAndCandidate (lpHenkanKey, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, lpCandRec->m_iLength) ;
		if (!iRetvalue){
			break ;
		} else if (iRetvalue > 0){
			lpParentCandRec	= lpCandRec ;
			lpCandRec		= lpCandRec->m_lpRight ;
		} else {
			lpParentCandRec	= lpCandRec ;
			lpCandRec		= lpCandRec->m_lpLeft ;
		}
	}
	if (!lpCandRec)
		return	FALSE ;
	lpVectorIndex	= lpCandRec->m_lpCandidate ;
	while (lpVectorIndex){
		if (!CompareStringAndCandidate (lpResultStr, lpVectorIndex->lpBuffer, lpVectorIndex->iPosition, lpVectorIndex->iLength))
			break ;
		lpVectorIndex	= lpVectorIndex->lpNext ;
	}
	if (!lpVectorIndex)
		return	FALSE ;
	*lppPrevRecordRet	= lpParentCandRec ;
	*lppRecordRet		= lpCandRec ;
	*lppVectorIndexRet	= lpVectorIndex ;
	return	TRUE ;
}

/*
 * �n�b�V���e�[�u���̓񕪖؂���ߓ_����폜����֐��B
 */
BOOL	SKKDeleteNodeInBinaryTree (LPSKKCANDRECORD FAR* lppRootNode, LPSKKCANDRECORD FAR* lppHeadNode, LPSKKCANDRECORD lpParentNode, LPSKKCANDRECORD lpDelCandRec)
{
	LPSKKCANDRECORD	lpNode ;
	
	if (!lpDelCandRec->m_lpLeft && !lpDelCandRec->m_lpRight){		/* �t���ρH */
		if (!lpParentNode)	    /* �������H */
			*lppRootNode	= NULL ;
		goto exit_delete_NodeInBinaryTree ;
	}

	if (!lpDelCandRec->m_lpLeft){		/* ���̎q�������Ȃ��H */
		if (!lpParentNode){
			*lppRootNode	= lpDelCandRec->m_lpRight ;
		} else {
			if (lpParentNode->m_lpRight == lpDelCandRec){
				lpParentNode->m_lpRight	= lpDelCandRec->m_lpRight ;
			} else {
				lpParentNode->m_lpLeft	= lpDelCandRec->m_lpRight ;
			}
		}
    	goto	exit_delete_NodeInBinaryTree ;
	}
	if (!lpDelCandRec->m_lpRight){		/* �E�̎q�������Ȃ��H */
		if (!lpParentNode){
			*lppRootNode	= lpDelCandRec->m_lpLeft ;
		} else {
			if (lpParentNode->m_lpRight == lpDelCandRec){
				lpParentNode->m_lpRight	= lpDelCandRec->m_lpLeft ;
			} else {
				lpParentNode->m_lpLeft	= lpDelCandRec->m_lpLeft ;
			}
		}
		goto	exit_delete_NodeInBinaryTree ;
	}

	/* ���E�̎q������������ꍇ�ɂ́c�ł��폜����悤�Ƃ��Ă���ߓ_�� *
	 * �e�ߓ_�̎��ԍ����傫�ȍł��߂��l���������t���ς�T���B*/
	lpNode	= lpDelCandRec->m_lpRight ;

	/* ���̉E�̎q���̂����ƍ��̍��́c���̎q���̗t���ς̎��l�́A�폜 *
	 * ����悤�Ƃ��Ă���ߓ_�̍��̎q���̒l���傫���B����͓񕪖؂� *
	 * �莩���ł���B*/
	while (lpNode->m_lpLeft)
		lpNode	= lpNode->m_lpLeft ;
	lpNode->m_lpLeft		= lpDelCandRec->m_lpLeft ;

	/* �폜����悤�Ƃ��Ă���ߓ_�̐e�̓��A���E�ǂ���̎q����������� *
	 * ���Ƃ��Ă���́H ����Ƃ��������Ȃ́H */
	if (!lpParentNode){
		*lppRootNode	= lpNode ;
	} else {
		if (lpParentNode->m_lpRight == lpDelCandRec){
			/* �E�̎q���ɐ���T���Ă����_���Ȃ��B*/
			lpParentNode->m_lpRight	= lpNode ;
		} else {
			/* ���̎q���ɐ���T���Ă����_���Ȃ��B*/
			lpParentNode->m_lpLeft	= lpNode ;
		}
	}

exit_delete_NodeInBinaryTree:
	if (lppHeadNode){
		/* ���݉ߋ������̃��X�g���C������B*/
		if (*lppHeadNode == lpDelCandRec){
			*lppHeadNode	= lpDelCandRec->m_lpPast ;
			if (lpDelCandRec->m_lpPast){
				lpDelCandRec->m_lpPast->m_lpFuture	= NULL ;
			}
		} else {
			if (lpDelCandRec->m_lpPast){
				lpDelCandRec->m_lpPast->m_lpFuture	= lpDelCandRec->m_lpFuture ;
			}
			if (lpDelCandRec->m_lpFuture){
				lpDelCandRec->m_lpFuture->m_lpPast	= lpDelCandRec->m_lpPast ;
			}
		}
	}
	lpDelCandRec->m_lpPast		= NULL ;
	lpDelCandRec->m_lpFuture	= NULL ;
	return	TRUE ;
}

/*
 * �؍\����H���āA�S�Ă̐ߓ_���������֐��B
 *-----
 * ���̊֐��͍ċA�I�ɌĂяo�����B
 */
void	SKKClearCandidateRecordSub (LPSKKCANDRECORD lpCandRec)
{
	LPSKKCANDRECORD	lpLeft ;
	LPSKKCANDRECORD	lpRight ;
	if (!lpCandRec)
		return ;
	SKKFreeVectorIndex (&lpCandRec->m_lpCandidate) ;
	lpLeft						= lpCandRec->m_lpLeft ;
	lpRight						= lpCandRec->m_lpRight ;
	lpCandRec->m_lpLeft			= NULL ;
	lpCandRec->m_lpRight		= NULL ;
	lpCandRec->m_lpHenkanKey	= NULL ;
	lpCandRec->m_lpFuture		= NULL ;
	lpCandRec->m_lpPast			= NULL ;
	HeapFree (GetProcessHeap (), 0, lpCandRec) ;
	if (lpLeft)
		SKKClearCandidateRecordSub (lpLeft) ;
	if (lpRight)
		SKKClearCandidateRecordSub (lpRight) ;
	return ;
}

/*
 *
 */
int	SKKMakeServerResultFromRecord2 (LPMYSTR lpDest, int iDestSize, LPVECTORINDEX lpVectorIndex)
{
	LPLISTBUFFER	lpBuffer ;
	int				iPosition ;
	int				iLength ;
	int				iPushLength ;
	int				iRest ;

	iLength				= lpVectorIndex->iLength ;
	if (iLength >= (iDestSize + 2))
		return	0 ;
	/* ���̊Ԃ̋�؂蕶��������B*/
	iRest				= iDestSize ;
	*lpDest ++			= MYTEXT ('/') ;
	iRest -- ;
	/* ���� 1 �o�^����B*/
	iPosition			= lpVectorIndex->iPosition ;
	lpBuffer			= lpVectorIndex->lpBuffer ;
	while (iLength > 0 && lpBuffer){
		if ((iPosition + iLength) > lpBuffer->iUsed){
			iPushLength	= lpBuffer->iUsed - iPosition ;
			memcpy (lpDest, lpBuffer->text + iPosition, iPushLength * sizeof (MYCHAR)) ;
			lpDest		+= iPushLength ;
			iRest		-= iPushLength ;
			iLength		-= iPushLength ;
			iPosition	= 0 ;
			lpBuffer	= lpBuffer->lpNext ;
		} else {
			memcpy (lpDest, lpBuffer->text + iPosition, iLength * sizeof (MYCHAR)) ;
			lpDest		+= iLength ;
			iRest		-= iLength ;
			iLength		= 0 ;
			break ;
		}
	}
	*lpDest ++			= MYTEXT ('/') ;
	iRest -- ;
	*lpDest				= MYTEXT ('\0') ;
	return	(iDestSize - iRest) ;
}

/*
 * �ϊ��̌��ʂ������o���֐�
 *-----
 * int okuri �� char *daimoku �ɂ���đ��肠��ƂȂ��̋�ʂ����Ă܂��B
 */
long	SKKUpdateHenkanResult (LPWINFILE lpSrcWinFile, LPWINFILE lpDestWinFile, BOOL fOkuri, LPCMYSTR lpDaimoku, int iCodingSystem)
{
	LPMYSTR			ptr ;
	LPLISTBUFFER	lpVectorTop ;
	LPVECTORINDEX	lpVectorIndex ;
	LPLISTBUFFER	lpPurgeVectorTop ;
	LPVECTORINDEX	lpPurgeVectorIndex ;
	MYCHAR			readBuffer [READBUFSIZE] ;
	int				iLength ;
	long			lCount ;
	BOOL			fContinue ;

	lCount	= 0 ;
	/* �܂��A����ڂ�������B�I���J�J�J�T���}�V�G�C�\���J�B*/
	j_put_string (lpDestWinFile, lpDaimoku, iCodingSystem) ;
	winfputc  ('\x0A', lpDestWinFile) ;
	lCount	++ ;

	/* �����Ɋ��ɓ����ɓo�^����Ă���ϊ��L�[������ׂ鏈��������B*/
	lCount	+= SKKWriteRecordCandidate (lpDestWinFile, lpSrcWinFile, fOkuri, iCodingSystem) ;

	/* �Q�l�ɂ���t�@�C���������񂾂�����A�ȉ��̏����͖����I ����K�v�͂Ȃ��I */
	if (!lpSrcWinFile)
		return	lCount ;

	/* �ꉞ�A�t�@�C���̐擪�܂Ŗ߂��Ă����B*/
	winrewind (lpSrcWinFile) ;

	/* ���艼���̊J�n�ʒu�܂Ŕ�ԁB(SJIS �̕�����Ɣ�r���ăX�L�b�v���Ă���...) */
	j_skip_file_until (lpSrcWinFile, lpDaimoku, iCodingSystem) ;

	/* �t�@�C���̏I���܂ŃX�L��������B*/
	fContinue	= TRUE ;
	while (fContinue){
		/* �����R�[�h�����āA����� SJIS �ւƕϊ�����B*/
		readBuffer [0]	= MYTEXT ('\0') ;
		fContinue	= j_read_one_line (readBuffer, READBUFSIZE, lpSrcWinFile, iCodingSystem) ;
		if (readBuffer [0] == MYTEXT (';')/* && !lstrcmp (readBuffer, lpDaimoku)*/)
			break ;
		/* �R�����g�̍s�������ꍇ�ɂ́A���s�܂œǂݔ�΂��B*/
		/* �܂��A���߂���ϊ��L�[�������Ƃ΂��B����Ȃ̎g���Ȃ�����I */
		if (!readBuffer [0] || 
			readBuffer [0] == MYTEXT (';')  ||
			readBuffer [0] == MYTEXT ('\n') ||
			readBuffer [0] == MYTEXT ('\r') ||
			readBuffer [0] == MYTEXT (' ')){
			readBuffer [0]	= MYTEXT ('\0') ;
			continue ;
		}
		for (ptr = readBuffer ; *ptr ; ptr ++){
			if (*ptr == MYTEXT (' ')){
				*ptr ++	= MYTEXT ('\0') ;
				break ;
			}
		}
		if (!*ptr || *ptr != MYTEXT ('/')){
			readBuffer [0]	= MYTEXT ('\0') ;
			ptr				= NULL ;
			continue ;
		}
		lpVectorTop	= NULL ;
		/* ���ɕϊ��m�肵�����̂����̒��ɑ��݂��邩�ǂ����`�F�b�N����B*/
		lpVectorTop		= SKKSearchCandidateRecordList2 (lpVectorTop, readBuffer, fOkuri) ;
		if (!lpVectorTop){
			lpPurgeVectorTop	= NULL ;
			lpPurgeVectorTop	= SKKSearchCandidatePurgeList2  (lpPurgeVectorTop, readBuffer, fOkuri) ;
			if (lpPurgeVectorTop){
				/* �ǂ����Apurge ���ꂽ���̂�����炵���B*/
				lpVectorTop			= SKKAddListBuffer (lpVectorTop, ptr, 0, NULL, NULL) ;
				lpPurgeVectorIndex	= SKKMakeSearchVectorIndex (lpPurgeVectorTop, NULL, FALSE) ;
				lpVectorIndex		= SKKMakeSearchVectorIndex (lpVectorTop, &iLength, TRUE) ;
				if (lpVectorIndex && iLength > 0){
					j_put_string (lpDestWinFile, readBuffer, iCodingSystem) ;
					winfputc (' ', lpDestWinFile) ;
					SKKWriteVectorIndexToFile (lpDestWinFile, iCodingSystem, lpVectorIndex) ;
					lCount	++ ;
				}
				SKKFreeVectorIndex (&lpVectorIndex) ;
				SKKFreeVectorIndex (&lpPurgeVectorIndex) ;
				SKKFreeListBuffer  (&lpVectorTop) ;
				SKKFreeListBuffer  (&lpPurgeVectorTop) ;
			} else {
				j_put_string (lpDestWinFile, readBuffer, iCodingSystem) ;
				winfputc (' ', lpDestWinFile) ;
				j_put_string (lpDestWinFile, ptr, iCodingSystem) ;
				winfputc ('\x0A', lpDestWinFile) ;
				lCount	++ ;
			}
		} else {
			/* ���ɕϊ��m�肵�Ă������̂͑ł��o����Ă���B������̂Ă�B*/
			SKKFreeListBuffer (&lpVectorTop) ;
		}
		readBuffer [0]	= MYTEXT ('\0') ;
		ptr				= NULL ;
	}
#ifdef DEBUG
	if (debug_fp){
		fclose (debug_fp) ;
		debug_fp	= NULL ;
	}
#endif
	return	lCount ;
}

/*
 * �ł��ŋߕϊ��Ɏg��ꂽ�L�[���珇�Ƀt�@�C���ɏ����o���֐��B
 */
long	SKKWriteRecordCandidate (LPWINFILE lpDestWinFile, LPWINFILE lpSrcWinFile, BOOL fOkuri, int iCodingSystem)
{
	LPSKKCANDRECORD	lpCandRec ;
	LPSKKCANDRECORD	lpNextCandRec ;
	LPLISTBUFFER	lpListBuffer ;
	LPVECTORINDEX	lpVectorIndex ;
	LPLISTBUFFER	lpPurgeListBuffer ;
	LPVECTORINDEX	lpPurgeVectorIndex ;
	long			lLines ;
	int				iLength ;
	MYCHAR			szSearchKey [MAXCOMPSIZE] ;

	/* ���艼���̗L���ɂ���Č���ׂ����X�g���قȂ�B*/
	if (fOkuri){
		lpCandRec	= lpOkuriCandidateRecordList ;
	} else {
		lpCandRec	= lpCandidateRecordList ;
	}
	lLines			= 0L ;
	/* �����ϊ��m�肳�ꂽ���Ƃ��Ȃ�������A���̂܂܋A��B*/
	if (!lpCandRec)
		return	lLines ;
	/* �Ǐ��ϐ��̏������B*/
	lpVectorIndex	= NULL ;
	while (lpCandRec){
		lpListBuffer	= NULL ;
		lpListBuffer	= SKKMakeServerResultListBufferFromRecord (lpListBuffer, lpCandRec->m_lpCandidate) ;
		CopyCandidate (szSearchKey, MAXCOMPSIZE, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, lpCandRec->m_iLength) ;
		lpNextCandRec	= lpCandRec->m_lpPast ;
		/* �ϊ��L�[�������̒��ɂ��邩�ǂ����𒲂ׂ�B
		 * �����ł��Ƃ̎����̃t�@�C���|�C���^�͔��ł��܂����Ƃɒ��ӁB*/
		if (lpSrcWinFile){
			lpListBuffer	= j_search_skkinput_jisyo_with_fileptr 
						(lpSrcWinFile, iCodingSystem, szSearchKey, lpListBuffer, fOkuri) ;
		}
		if (lpListBuffer){
			/* ��₪���݂����݂���������A�p�[�W���̌����ł����܂��傤���B*/
			lpPurgeListBuffer	= NULL ;
			lpPurgeVectorIndex	= NULL ;
			lpPurgeListBuffer	= SKKSearchCandidatePurgeList2 (lpPurgeListBuffer, szSearchKey, fOkuri) ;
			/* �p�[�W���̌������炩���߃n�b�V���ɂł��@�����݂܂��傤�B*/
			if (lpPurgeListBuffer){
				lpPurgeVectorIndex	= SKKMakeSearchVectorIndex (lpPurgeListBuffer, &iLength, FALSE) ;
			}
			lpVectorIndex	= SKKMakeSearchVectorIndex (lpListBuffer, &iLength, TRUE) ;
			if (lpVectorIndex){
				/* �ϊ��L�[�������ɏ����o���B*/
				j_put_string (lpDestWinFile, szSearchKey, iCodingSystem) ;
				winfputc (' ', lpDestWinFile) ;
				/* VectorIndex ���t�@�C���ɑ|���o���c���̐l�͍Ō��'\n' ��� *
				 * ��Ă����B*/
				SKKWriteVectorIndexToFile (lpDestWinFile, iCodingSystem, lpVectorIndex) ;
				lLines	++ ;
				/* �m�ۂ������������������B*/
				SKKFreeVectorIndex (&lpVectorIndex) ;
			}
			SKKFreeVectorIndex (&lpPurgeVectorIndex) ;
			SKKFreeListBuffer  (&lpPurgeListBuffer) ;
			SKKFreeListBuffer  (&lpListBuffer) ;
		}
		lpCandRec	= lpNextCandRec ;
	}
	return	lLines ;
}

/*
 *	obsolete
 */
#ifdef OBSOLETE
LPLISTBUFFER	SKKRecordCandidate (LPLISTBUFFER lpListBufferTop, LPVECTORINDEX lpVectorIndex)
{
	LPLISTBUFFER	lpNextBuffer ;
	LPLISTBUFFER	lpBuffer ;
	int				iPosition ;
	int				iLength ;
	int				iPushLength ;
	BOOL			fFirst ;
	LPLISTBUFFER	lpNewBuffer ;
	int				iNewPosition ;
	if (!lpVectorIndex)
		return	lpListBufferTop ;
	iPosition			= lpVectorIndex->iPosition ;
	iLength				= lpVectorIndex->iLength ;
	lpBuffer			= lpVectorIndex->lpBuffer ;
	fFirst				= TRUE ;
	while (iLength > 0 && lpBuffer){
		if ((iPosition + iLength) > lpBuffer->iUsed){
			iPushLength	= lpBuffer->iUsed - iPosition ;
			if (fFirst){
				lpListBufferTop	= SKKAddListBuffer
					 (lpListBufferTop, lpBuffer->text + iPosition, iPushLength, &lpNewBuffer, &iNewPosition) ;
				fFirst		= FALSE ;
			} else {
				lpListBufferTop	= SKKAddListBuffer
					 (lpListBufferTop, lpBuffer->text + iPosition, iPushLength, NULL, NULL) ;
			}
			lpNextBuffer	= lpBuffer->lpNext ;
			iLength			-= iPushLength ;
		} else {
			if (fFirst){
				lpListBufferTop	= SKKAddListBuffer
					 (lpListBufferTop, lpBuffer->text + iPosition, iLength, &lpNewBuffer, &iNewPosition) ;
				fFirst		= FALSE ;
			} else {
				lpListBufferTop	= SKKAddListBuffer
					 (lpListBufferTop, lpBuffer->text + iPosition, iLength, NULL, NULL) ;
			}
			iLength			= 0 ;
			lpNextBuffer	= NULL ;
		}
		lpBuffer		= lpNextBuffer ;
		iPosition		= 0 ;
	}
	if (!fFirst){
		lpVectorIndex->lpBuffer		= lpNewBuffer ;
		lpVectorIndex->iPosition	= iNewPosition ;
	}
	return	lpListBufferTop ;
}

/*
 * �ϊ��L�[�ł����ăe�[�u�����猟�����A���̌��ʂ������ɓ����֐��B
 */
BOOL	SKKFindCandidateRecordWithHenkanKey2 (LPSKKCANDRECORD FAR* lppRecordTop, LPMYSTR lpHenkanKey, LPVECTORINDEX lpKeyVI, LPSKKCANDRECORD FAR* lppPrevRecordRet, LPSKKCANDRECORD FAR* lppRecordRet, LPVECTORINDEX FAR* lppVectorIndexRet)
{
	LPSKKCANDRECORD	lpCandRec ;
	LPSKKCANDRECORD	lpPrevCandRec ;
	LPSKKCANDRECORD	lpNextCand ;
	LPVECTORINDEX	lpNextVectorIndex ;
	LPVECTORINDEX	lpVectorIndex ;
	int				iRetvalue ;
	BOOL			fFound ;

	lpCandRec		= *lppRecordTop ;
	if (!lpCandRec)
		return	FALSE ;

	lpPrevCandRec	= NULL ;			/* �e�m�[�h�B*/
	lpVectorIndex	= NULL ;
	fFound			= FALSE ;

	while (!fFound && lpCandRec){		/* �񕪒T������B*/
		iRetvalue	= CompareStringAndCandidate (lpHenkanKey, lpCandRec->m_lpHenkanKey, lpCandRec->m_iPosition, lpCandRec->m_iLength) ;
		if (!iRetvalue){
			lpNextCand		= lpCandRec ;
			lpVectorIndex	= lpCandRec->m_lpCandidate ;
			fFound			= TRUE ;
		} else if (iRetvalue > 0){
			lpNextCand		= lpCandRec->m_lpRight ;
			lpPrevCandRec	= lpCandRec ;
		} else {
			lpNextCand		= lpCandRec->m_lpLeft ;
			lpPrevCandRec	= lpCandRec ;
		}
		lpCandRec			= lpNextCand ;
	}
	if (!lpCandRec || !fFound)
	  	return	FALSE ;

	fFound	= FALSE ;
	while (!fFound && lpVectorIndex){
		if (!CompareCandidate (lpKeyVI->lpBuffer,       lpKeyVI->iPosition,       lpKeyVI->iLength,
							   lpVectorIndex->lpBuffer, lpVectorIndex->iPosition, lpVectorIndex->iLength)){
			lpNextVectorIndex	= lpVectorIndex ;
			fFound				= TRUE ;
		} else {
			lpNextVectorIndex	= lpVectorIndex->lpNext ;
		}
		lpVectorIndex	= lpNextVectorIndex ;
	}
	if (!lpVectorIndex || !fFound)
		return	FALSE ;
	*lppPrevRecordRet	= lpPrevCandRec ;
	*lppRecordRet		= lpCandRec ;
	*lppVectorIndexRet	= lpVectorIndex ;
	return	TRUE ;
}
#endif

