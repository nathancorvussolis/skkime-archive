/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * uiminibuf.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"
#include "keymap.h"
#include "resource.h"

/*
 *	�v���g�^�C�v�錾�B
 */
BOOL	PASCAL	GetCandPosFromCompWnd (LPUIEXTRA lpUIExtra, LPPOINT lppt) ;

static	void	PASCAL	paintMinibufWindow (HWND hMinibufWnd) ;
static	BOOL	PASCAL	moveMinibufWindowExclude (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC) ;
static	BOOL	PASCAL	moveMinibufWindowPosition (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC) ;
static	BOOL	PASCAL	moveMinibufWindowDefault (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC) ;
static	BOOL	PASCAL	minibufDragUI (HWND hWnd, UINT uMessage) ;
static	BOOL			minibufContextMenu (HWND hwnd, HIMC hIMC) ;
static	int				minibufPopupMenu (HWND hwnd, HIMC hIMC) ;
static	DWORD			minibufGetCursorPos (HDC hDC, LPCOMPOSITIONSTRING lpCompStr, LPPOINT lppoint) ;
static	BOOL			invalidateMinibuffer (LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC) ;

/*
 *	--- �������� �֐��̒�` --- �������� �֐��̒�` --- �������� �֐��̒�` ---
 */

LRESULT	CALLBACK	MinibufWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND	hUIWnd ;

	switch (message){
	case WM_CREATE:
		SetWindowLong (hWnd, FIGWL_MOUSE, 0L) ;
		break ;

	case WM_PAINT:
		paintMinibufWindow (hWnd) ;
		break;

	case WM_SETCURSOR:
		minibufDragUI (hWnd, HIWORD (lParam)) ;
		break ;

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MOUSEMOVE:
	case WM_NCMOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		minibufDragUI (hWnd, message) ;
		break ;

	case WM_MOVE:
		hUIWnd	= (HWND)GetWindowLong (hWnd, FIGWL_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_CANDMOVE, wParam, lParam) ;
		break;

	default:
		if (!MyIsIMEMessage (message))
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	0L ;
}

void	PASCAL	CreateMinibufWindow (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;
	POINT				pt ;
	LONG				lInst ;

	if (GetCandPosFromCompWnd (lpUIExtra, &pt)){
		lpUIExtra->uiMinibuf.pt.x	= pt.x ;
		lpUIExtra->uiMinibuf.pt.y	= pt.y ;
	}
	lInst	= GetWindowLong (hUIWnd, GWL_HINSTANCE) ;
	if (!IsWindow (lpUIExtra->uiMinibuf.hWnd)){
		lpUIExtra->uiMinibuf.hWnd = 
				CreateWindowEx (WS_EX_WINDOWEDGE,
								(LPSTR)szMinibufClassName, NULL,
								WS_COMPDEFAULT | WS_DLGFRAME,
								lpUIExtra->uiMinibuf.pt.x,
								lpUIExtra->uiMinibuf.pt.y,
								1, 1,
								hUIWnd, NULL, (HINSTANCE)lInst, NULL) ;
	}
	SetWindowLong (lpUIExtra->uiMinibuf.hWnd, FIGWL_SVRWND, 		(DWORD)hUIWnd) ;
	SetWindowLong (lpUIExtra->uiMinibuf.hWnd, FIGWL_PREVCURSOR,		0L) ;
	ShowWindow (lpUIExtra->uiMinibuf.hWnd, SW_HIDE) ;
	lpUIExtra->uiMinibuf.bShow	= FALSE ;
	return ;
}

void	PASCAL	HideMinibufWindow (LPUIEXTRA lpUIExtra)
{
	RECT	rc ;
	if (IsWindow (lpUIExtra->uiMinibuf.hWnd)){
		GetWindowRect (lpUIExtra->uiMinibuf.hWnd, (LPRECT)&rc) ;
		lpUIExtra->uiMinibuf.pt.x	= rc.left ;
		lpUIExtra->uiMinibuf.pt.y	= rc.top ;
		MoveWindow (lpUIExtra->uiMinibuf.hWnd, -1 , -1 , 0 , 0, TRUE) ;
		ShowWindow (lpUIExtra->uiMinibuf.hWnd, SW_HIDE) ;
		lpUIExtra->uiMinibuf.bShow	= FALSE ;
	}
	return ;
}

/*
 *	Minibuffer Window �̕\��(�I��/�I�t)�y�ѕ\���ʒu���C������֐��B
 *-----
 *	���Œ��ꒃ�������֐��BMoveCandWindow ����K���Ɉʒu�v�Z�̕������E���Ă��č�����B
 *	  Candidate Window �Ɠ����ʒu�� Minibuffer Window ���o�ė~������������B
 */
void	PASCAL	MoveMinibufWindow (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	HIMC				hIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	BOOL				fHide ;

	lpUIExtra->uiMinibuf.pt.x	= lpUIExtra->uiCand.pt.x ;
	lpUIExtra->uiMinibuf.pt.y	= lpUIExtra->uiCand.pt.y ;

	fHide		= FALSE ;
	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpCompStr){
		if (((LPMYCOMPSTR)lpCompStr)->dwMinibufStrLen <= 0){
			HideMinibufWindow (lpUIExtra) ;
			fHide	= TRUE ;
		}
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
	if (fHide)
		return ;

	if (!IsWindow (lpUIExtra->uiMinibuf.hWnd))
		return ;

	if (lpIMC->cfCandForm [0].dwStyle == CFS_EXCLUDE){
		moveMinibufWindowExclude (hUIWnd, lpUIExtra, lpIMC) ;
	}  else if (lpIMC->cfCandForm[0].dwStyle == CFS_CANDIDATEPOS){
		moveMinibufWindowPosition (hUIWnd, lpUIExtra, lpIMC) ;
	} else {
		moveMinibufWindowDefault (hUIWnd, lpUIExtra, lpIMC) ;
	}
	return ;
}

void	PASCAL	MinibufCompositionNotify (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	LPCOMPOSITIONSTRING	lpCompStr ;

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;

	if (((LPMYCOMPSTR)lpCompStr)->dwMinibufStrLen <= 0){
		HideMinibufWindow (lpUIExtra) ;
	} else {
		if (!IsWindow (lpUIExtra->uiMinibuf.hWnd))
			CreateMinibufWindow (hUIWnd, lpUIExtra, lpIMC) ;
		if (!lpUIExtra->uiMinibuf.bShow)
			MoveMinibufWindow (hUIWnd, lpUIExtra, lpIMC) ;
		invalidateMinibuffer (lpUIExtra, lpIMC) ;
		/*InvalidateRect (lpUIExtra->uiMinibuf.hWnd, NULL, FALSE) ;*/
	}
	return ;
}

/*
 *	--- �������� Private �֐��̒�` --- �������� Private �֐��̒�` --- �������� ---
 */

/*
 *	Minibuffer Window �� WM_PAINT ���b�Z�[�W����������֐��B
 *-----
 */
void	PASCAL	paintMinibufWindow (HWND hMinibufWnd)
{
	PAINTSTRUCT		ps ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR		lpMyCompStr ;
	HBRUSH			hbr ;
	HBRUSH			hBrushParent ;
	HDC				hDC ;
	HDC				hPDC ;
	RECT			rc ;
	LPMYSTR			lpstr ;
	SIZE			sz ;
	HWND			hSvrWnd ;
	RECT			invRect ;
	long			lRegionStart, lRegionEnd ;
	long			lLength ;
	long			lCursorPos ;

	hDC		= BeginPaint (hMinibufWnd, &ps) ;
	hSvrWnd	= (HWND)GetWindowLong (hMinibufWnd,	FIGWL_SVRWND) ;
	hIMC	= (HIMC)GetWindowLong (hSvrWnd,		IMMGWL_IMC) ;
	if (hIMC){
		lpIMC		= ImmLockIMC (hIMC) ;
		/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr){
			lRegionStart	= (long)lpMyCompStr->dwMinibufRegionStartPos ;
			lRegionEnd		= (long)lpMyCompStr->dwMinibufRegionEndPos ;
			lRegionStart	= min (lRegionStart, lRegionEnd) ;
			lRegionEnd		= max (lRegionStart, lRegionEnd) ;
			/* Minibuffer Window �̑傫���𓾂�B*/
			GetClientRect (hMinibufWnd, &rc) ;

			/* �eWindow �̔w�i�F�𓾂�B*/
			hPDC 			= GetDC (GetParent (hMinibufWnd)) ;
			hBrushParent	= CreateSolidBrush (GetBkColor (hPDC)) ;

			lpstr			= (LPMYSTR)lpMyCompStr->szMinibufStr ;
			lLength			= (long)lpMyCompStr->dwMinibufStrLen ;
			lCursorPos		= (long)lpMyCompStr->dwMinibufCurPos ;

			MyGetTextExtentPoint (hDC, lpstr, lLength, &sz) ;
			lpMyCompStr->szMinibufSize	= sz ;
			hbr				= SelectObject (hDC, hBrushParent) ;

			/* Minibuffer Window �̔w�i�͐e Window �̔w�i�F�ɁB*/
			PatBlt (hDC, sz.cx, 0, (rc.right - rc.left) - sz.cx, rc.bottom - rc.top, PATCOPY) ;
			SelectObject (hDC, hbr) ;
			DeleteObject (hBrushParent) ;

			SetBkMode (hDC, OPAQUE) ;
			SetBkColor (hDC, GetBkColor (hPDC)) ;
			SetTextColor (hDC, RGB (0, 0, 0)) ;

			if (0 <= lRegionStart && lRegionEnd <= lLength){
				int	x	= rc.left ;
				MyTextOut (hDC, x, rc.top, lpstr,					lRegionStart) ;
				MyGetTextExtentPoint (hDC, lpstr, lRegionStart, &sz) ;
				x	+= sz.cx ;
				if (lRegionStart < lRegionEnd){
					SetBkColor (hDC, RGB (192, 192, 224)) ;
					MyTextOut (hDC, x, rc.top, lpstr + lRegionStart, lRegionEnd - lRegionStart) ;
					MyGetTextExtentPoint (hDC, lpstr + lRegionStart, lRegionEnd - lRegionStart, &sz) ;
					SetBkColor (hDC, GetBkColor (hPDC)) ;
					x	+= sz.cx ;
				}
				MyTextOut (hDC, x, rc.top, lpstr + lRegionEnd,	lLength - lRegionEnd) ;
			} else {
				/* �e�L�X�g��\������B*/
				MyTextOut (hDC, rc.left, rc.top, lpstr, lLength) ;
			}
			/* �K�v�Ȃ�J�[�\����\������B*/
			if (0 <= lCursorPos && lCursorPos <= lLength){
				MyGetTextExtentPoint (hDC, lpstr, lCursorPos, &sz) ;
				invRect.left	= rc.left + sz.cx ;
				invRect.right	= rc.left + sz.cx + UI_CURSORWIDTH ;
				invRect.top		= rc.top ;
				invRect.bottom	= rc.bottom ;
				InvertRect (hDC, &invRect) ;
			}
			ReleaseDC (GetParent (hMinibufWnd), hPDC) ;
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	EndPaint (hMinibufWnd, &ps) ;
	return ;
}

BOOL	PASCAL	moveMinibufWindowExclude (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	RECT				rc ;
	RECT				rcUIWnd ;
	RECT				rcWork ;
	RECT				rcExclude ;
	POINT				pt ;
	SIZE				sizeMinibufWnd ;

	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
	GetClientRect (lpUIExtra->uiCand.hWnd, &rc) ;
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;
	pt.x	= lpIMC->cfCandForm [0].rcArea.left ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.top ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.left		= pt.x ;
	rcExclude.top		= pt.y ;
	pt.x	= lpIMC->cfCandForm [0].rcArea.right ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.bottom ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.right		= pt.x ;
	rcExclude.bottom	= pt.y ;

	/* �~�j�o�b�t�@�E�B���h�E�̑傫�����v�Z����B*/
	sizeMinibufWnd.cx	= rcUIWnd.right	- rcUIWnd.left	+ 2 * GetSystemMetrics (SM_CXBORDER) + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeMinibufWnd.cy	= rc.bottom		- rc.top		+ 2 * GetSystemMetrics (SM_CYBORDER) + 2 * GetSystemMetrics (SM_CYEDGE) ;
	AdjustCandidateWindowSize (hUIWnd, &sizeMinibufWnd) ;

	pt.x	= 0 ;
	pt.y	= rcUIWnd.bottom - rcUIWnd.top ;
	ClientToScreen (lpIMC->hWnd, &pt) ;

	/* �~�j�o�b�t�@�E�B���h�E�̈ʒu��␳����B*/
	if ((pt.x + sizeMinibufWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - sizeMinibufWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + sizeMinibufWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - sizeMinibufWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	/* �~�j�o�b�t�@�E�B���h�E���w�肵���̈�ɏd�Ȃ��Ă��Ȃ����`�F�b�N����B*/
	if (IsCrossRectangle (&pt, &sizeMinibufWnd, &rcExclude)){
		pt.y	= rcExclude.bottom ;
		if ((pt.y + rc.bottom) > rcWork.bottom)
			pt.y	= rcExclude.top - sizeMinibufWnd.cy ;
	}
	if (IsWindow(lpUIExtra->uiMinibuf.hWnd)){
		GetWindowRect (lpUIExtra->uiMinibuf.hWnd, &rc) ;
		MoveWindow (lpUIExtra->uiMinibuf.hWnd, pt.x, pt.y, sizeMinibufWnd.cx, sizeMinibufWnd.cy, TRUE) ;
		ShowWindow (lpUIExtra->uiMinibuf.hWnd, SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiMinibuf.bShow	= TRUE ;
		invalidateMinibuffer (lpUIExtra, lpIMC) ;
		/*InvalidateRect (lpUIExtra->uiMinibuf.hWnd, NULL, FALSE) ;*/
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL	moveMinibufWindowPosition (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	RECT	rcWork ;
	POINT	pt ;
	SIZE	sizeMinibufWnd ;

	/* Windows �̃��[�N�̈�̑傫���𓾂�B*/
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, &rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom = 0 ;
	}
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;

	pt.x	= lpIMC->cfCandForm[0].ptCurrentPos.x ;
	pt.y	= lpIMC->cfCandForm[0].ptCurrentPos.y ;
	ClientToScreen (lpIMC->hWnd, &pt) ;

	/* �~�j�o�b�t�@�E�B���h�E�̑傫�����v�Z����B*/
	sizeMinibufWnd.cx	= rcUIWnd.right	- rcUIWnd.left	+ 2 * GetSystemMetrics (SM_CXBORDER) + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeMinibufWnd.cy	= rc.bottom		- rc.top		+ 2 * GetSystemMetrics (SM_CYBORDER) + 2 * GetSystemMetrics (SM_CYEDGE) ;
	AdjustCandidateWindowSize (hUIWnd, &sizeMinibufWnd) ;

	/* Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B*/
	if ((pt.x + sizeMinibufWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - sizeMinibufWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + sizeMinibufWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - sizeMinibufWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	if (IsWindow (lpUIExtra->uiMinibuf.hWnd)){
		MoveWindow (lpUIExtra->uiMinibuf.hWnd, pt.x, pt.y, sizeMinibufWnd.cx, sizeMinibufWnd.cy, TRUE) ;
		ShowWindow (lpUIExtra->uiMinibuf.hWnd,SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiMinibuf.bShow	= TRUE ;
		invalidateMinibuffer (lpUIExtra, lpIMC) ;
		/*InvalidateRect (lpUIExtra->uiMinibuf.hWnd, NULL, FALSE) ;*/
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL	moveMinibufWindowDefault (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	RECT	rc ;
	SIZE	sizeMinibufWnd ;

	GetWindowRect (lpIMC->hWnd, &rc) ;
	sizeMinibufWnd.cx	= rc.right - rc.left 	+ 2 * GetSystemMetrics (SM_CXBORDER) + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeMinibufWnd.cy	= 20					+ 2 * GetSystemMetrics (SM_CYBORDER) + 2 * GetSystemMetrics (SM_CYEDGE) ;
	AdjustCandidateWindowSize (hUIWnd, &sizeMinibufWnd) ;

	if (IsWindow (lpUIExtra->uiMinibuf.hWnd)){
		MoveWindow (lpUIExtra->uiMinibuf.hWnd,
					lpUIExtra->uiMinibuf.pt.x,	lpUIExtra->uiMinibuf.pt.y,
					sizeMinibufWnd.cx,			sizeMinibufWnd.cy,
					TRUE) ;
		ShowWindow (lpUIExtra->uiMinibuf.hWnd, SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiMinibuf.bShow	= TRUE ;
		invalidateMinibuffer (lpUIExtra, lpIMC) ;
		/*InvalidateRect (lpUIExtra->uiMinibuf.hWnd, NULL, FALSE) ;*/
	}
	return	TRUE ;
}

BOOL	PASCAL	minibufDragUI (HWND hWnd, UINT uMessage)
{
	HWND			hSvrWnd ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR		lpMyCompStr ;
	HDC				hDC ;
	POINT			pos ;
	DWORD			dwCursor ;
	DWORD			dwButtonPressed ;
	SIZE			sz ;
	long			lRegionStart ;
	long			lRegionEnd ;

	dwButtonPressed	= (DWORD)GetWindowLong (hWnd, FIGWL_MOUSE) ;
	/*
	 * �}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 * �ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (uMessage != WM_RBUTTONDOWN && uMessage != WM_RBUTTONUP &&
		uMessage != WM_LBUTTONDOWN && !dwButtonPressed)
		return	TRUE ;
	GetCursorPos (&pos) ;
	if (!ScreenToClient (hWnd, &pos))
		return	FALSE ;
	hDC		= GetDC (hWnd) ;
	if (!hDC)
		return	FALSE ;
	hSvrWnd	= (HWND)GetWindowLong (hWnd, FIGWL_SVRWND) ;
	hIMC	= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;
	if (hIMC && uMessage != WM_RBUTTONUP && uMessage != WM_RBUTTONDOWN){
		lpIMC		= ImmLockIMC (hIMC) ;
		/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr){
			dwCursor	= minibufGetCursorPos (hDC, (LPCOMPOSITIONSTRING)lpMyCompStr, &pos) ;
			if (lpMyCompStr->dwMinibufCurPos >= 0 &&
				dwCursor != lpMyCompStr->dwMinibufCurPos){
				/* lCursor ���V�����J�[�\���̈ʒu�ɂȂ�̂����A�ǂ�����ē`���悤���H */
				lpMyCompStr->dwMinibufCurPos	= SKKSetCursorPosition (lpIMC, dwCursor) ;
				InvalidateRect (hWnd, NULL, FALSE) ;
			}
			/* �̈�I���J�n�ʒu���L������B*/
			switch (uMessage){
			case	WM_LBUTTONDOWN:
				/* �͈͑I���͑S���Ȃ���Ă��Ȃ��󋵂ł̏����B*/
				lpMyCompStr->dwMinibufRegionStartPos	= dwCursor ;
				lpMyCompStr->dwMinibufRegionEndPos		= dwCursor ;
				SKKSetRegionStartPoint (lpIMC) ;
				SKKSetRegionEndPoint (lpIMC) ;
				break ;

			case	WM_MOUSEMOVE:
			case	WM_NCMOUSEMOVE:
			case	WM_LBUTTONUP:
				if (dwButtonPressed){
					lpMyCompStr->dwMinibufRegionEndPos	= dwCursor ;
					SKKSetRegionEndPoint (lpIMC) ;
				}
				break ;
			default:
				break ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	ReleaseDC (hWnd, hDC) ;
	if (uMessage == WM_LBUTTONDOWN){
		SetWindowLong (hWnd, FIGWL_MOUSE, 1L) ;
		SetCapture (hWnd) ;
	}
	if (uMessage == WM_LBUTTONUP || uMessage == WM_RBUTTONUP){
		SetWindowLong (hWnd, FIGWL_MOUSE, 0L) ;
		ReleaseCapture () ;
		if (uMessage == WM_RBUTTONUP){
			minibufContextMenu (hWnd, hIMC) ;
		}
	}
	return	TRUE ;
}

/*
 *	�~�j�o�b�t�@���ŉE�N���b�N���ꂽ���� Context Menu �̏������s���֐��B
 */
BOOL	minibufContextMenu (HWND hwnd, HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	int					nCmd ;
	BOOL				fRedraw ;
	nCmd	= minibufPopupMenu (hwnd, hIMC) ;
	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;
	fRedraw	= TRUE ;
	switch (nCmd){
	case	IDM_CUT:
		SKKExecuteCommand (lpIMC, FUNCNO_J_KILL_REGION) ;
		break ;
	case	IDM_PASTE:
		SKKExecuteCommand (lpIMC, FUNCNO_J_YANK) ;
		break ;
	case	IDM_COPY:
		SKKExecuteCommand (lpIMC, FUNCNO_J_KILL_RING_SAVE) ;
		break ;
	case	IDM_DELETE:
		SKKExecuteCommand (lpIMC, FUNCNO_J_DELETE_REGION) ;
		break ;
	default:
		fRedraw	= FALSE ;
		break ;
	}
	if (fRedraw){
		lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpCompStr){
			SKKUpdateIMC (hIMC, lpIMC, lpCompStr) ;
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
	}
	ImmUnlockIMC (hIMC) ;
	return	TRUE ;
}

int		minibufPopupMenu (HWND hwnd, HIMC hIMC)
{
	HMENU			hMenu ;
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR		lpMyCompStr ;
	int				nCmd ;
	POINT			pos ;
	HCURSOR			hCursor ;
	hMenu		= 0 ;
	nCmd		= -1 ;
	GetCursorPos ((LPPOINT)&pos) ;
	lpIMC		= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	-1 ;
	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr){
		hMenu	= MyCreateClipboardMenu (lpMyCompStr) ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
	ImmUnlockIMC (hIMC) ;
	if (hMenu){
		/* ���j���[��\�����āA�I��������B*/
		hCursor	= SetCursor (LoadCursor (NULL, IDC_ARROW)) ;
		nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, pos.x, pos.y, 0, hwnd, NULL) ;
		DestroyMenu (hMenu) ;
		(void)SetCursor (hCursor) ;
	}
	return	nCmd ;
}

DWORD	minibufGetCursorPos (HDC hDC, LPCOMPOSITIONSTRING lpCompStr, LPPOINT lppoint)
{
	LPMYCOMPSTR	lpMyCompStr	= (LPMYCOMPSTR)lpCompStr ;
	LPMYSTR		lpstr ;
	DWORD		dwCursor ;
	int			nItems ;
	SIZE		sz ;

	/* �V�����J�[�\���ʒu�����߂�B*/
	lpstr		= (LPMYSTR)lpMyCompStr->szMinibufStr ;
	dwCursor	= 0 ;
	while (dwCursor < lpMyCompStr->dwMinibufStrLen){
#if defined (SKKIME98M)
		MyGetTextExtentPoint (hDC, lpstr, dwCursor + 1, &sz) ;
		if (lppoint->x < sz.cx)
			break ;
		dwCursor	++ ;
#else
		if (IsDBCSLeadByte (lpstr [dwCursor])){
			nItems	= 2 ;
		} else {
			nItems	= 1 ;
		}
		MyGetTextExtentPoint (hDC, lpstr, dwCursor + nItems, &sz) ;
		if (lppoint->x < sz.cx)
			break ;
		dwCursor	+= nItems ;
#endif
	}
	return	dwCursor ;
}

BOOL	invalidateMinibuffer (LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	LPMYCOMPSTR	lpMyCompStr ;
	HDC			hDC ;
	LPMYSTR		lpstr ;
	long		lDeltaStart ;
	long		lCursor ;
	long		lPrevCursor ;
	long		lLength ;
	int			x ;
	RECT		irc ;
	RECT		rc ;
	SIZE		sz ;
	BOOL		fRedraw ;

	hDC			= GetDC (lpUIExtra->uiMinibuf.hWnd) ;
	if (!hDC)
		return	FALSE ;
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (!lpMyCompStr){
		InvalidateRect (lpUIExtra->uiMinibuf.hWnd, NULL, FALSE) ;
		return	FALSE ;
	}
	lLength		= (long)lpMyCompStr->dwMinibufStrLen ;
	lDeltaStart	= (long)lpMyCompStr->dwMinibufDelta ;
	lpstr		= (LPMYSTR)lpMyCompStr->szMinibufStr ;
	lCursor		= (long)lpMyCompStr->dwMinibufCurPos ;
	lPrevCursor	= (long)GetWindowLong (lpUIExtra->uiMinibuf.hWnd, FIGWL_PREVCURSOR) ;

	GetClientRect (lpUIExtra->uiMinibuf.hWnd, &rc) ;
	irc.top		= rc.top ;
	irc.bottom	= rc.bottom ;
	irc.left	= rc.right ;
	irc.right	= rc.left ;
	if (lpMyCompStr->dwUpdateFlag & (SKKUI_UPDATE_COMPOSITIONSTRING << 16)){
		MyGetTextExtentPoint (hDC, lpstr, lDeltaStart, &sz) ;
		x		= rc.left + sz.cx ;
		if (x < irc.left)
			irc.left	= x ;
		if (irc.right < rc.right)
			irc.right	= rc.right ;
	}
	if ((lpMyCompStr->dwUpdateFlag & (SKKUI_UPDATE_CURSOR << 16)) && lCursor != lPrevCursor){
		if (0 <= lPrevCursor && lPrevCursor <= lLength){
			MyGetTextExtentPoint (hDC, lpstr, lPrevCursor, &sz) ;
			x	= rc.left + sz.cx ;
			if (x < irc.left)
				irc.left	= rc.left + sz.cx ;
			x	+= UI_CURSORWIDTH ;
			if (irc.right < x)
				irc.right	= x ;
		}
		if (0 <= lCursor && lCursor <= lLength){
			MyGetTextExtentPoint (hDC, lpstr, lCursor, &sz) ;
			x	= rc.left + sz.cx ;
			if (x < irc.left)
				irc.left	= rc.left + sz.cx ;
			x	+= UI_CURSORWIDTH ;
			if (irc.right < x)
				irc.right	= x ;
		}
		SetWindowLong (lpUIExtra->uiMinibuf.hWnd, FIGWL_PREVCURSOR, lCursor) ;
	}
	/*DebugTextOut (0, 0, TEXT ("RECT (%d, %d, %d, %d)"), irc.left, irc.top, irc.right, irc.bottom) ;*/
	if (irc.left < irc.right)
		InvalidateRect (lpUIExtra->uiMinibuf.hWnd, &irc, FALSE) ;
	ReleaseDC (lpUIExtra->uiMinibuf.hWnd, hDC) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	TRUE ;
}

