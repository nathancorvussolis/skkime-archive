#if !defined (dai_h)
#define	dai_h

#define	SIZE_SKKIME_COLORFACE	4
#define	NITEM_SKKIME_COLORFACE	2

class CDisplayAttributeInfo : public ITfDisplayAttributeInfo {
public:
	CDisplayAttributeInfo () ;
	~CDisplayAttributeInfo () ;

    // IUnknown
    STDMETHODIMP QueryInterface (REFIID riid, void **ppvObj) ;
    STDMETHODIMP_(ULONG) AddRef(void) ;
    STDMETHODIMP_(ULONG) Release(void) ;

    // ITfDisplayAttributeInfo
    STDMETHODIMP	GetGUID (GUID* pguid) ;
    STDMETHODIMP	GetDescription (BSTR* pbstrDesc) ;
    STDMETHODIMP	GetAttributeInfo (TF_DISPLAYATTRIBUTE* ptfDisplayAttr) ;
    STDMETHODIMP	SetAttributeInfo (const TF_DISPLAYATTRIBUTE* ptfDisplayAttr) ;
    STDMETHODIMP	Reset () ;

private:
	BOOL	_ConvertSkkImeColorFace2TfDisplayAttribute (TF_DISPLAYATTRIBUTE* pAttr, LPBYTE pData) ;
	BOOL	_ConvertSkkImeColor2TfDaColor (TF_DA_COLOR* pColor, int nType) ;
	BOOL	_ConvertSkkImeLineStyle2TfDaLineStyle (TF_DA_LINESTYLE* pLineStyle, BOOL* pfBoldLine, int nLineType) ;

protected:
	const GUID*						_pGUID ;
	const TF_DISPLAYATTRIBUTE*		_pDefaultDisplayAttribute ;
	const WCHAR*					_wstrDescription ;
	const TCHAR*					_tstrValueName ;
	TF_DA_ATTR_INFO					_bAttr ;
	int								_nStyleOffset ;

private:
	LONG	_cRef ;
} ;


/*========================================================================*
 */
class CDisplayAttributeInfoInput : public CDisplayAttributeInfo
{
public:
	CDisplayAttributeInfoInput () {
		_pGUID						= &c_guidSkkImeDisplayAttributeInput ;
		_pDefaultDisplayAttribute	= &_s_DefaultDisplayAttribute ;
		_wstrDescription			= _s_szDescription ;
		_tstrValueName				= _s_szValueName ;
		_bAttr						= TF_ATTR_INPUT ;
		_nStyleOffset				= SIZE_SKKIME_COLORFACE * 0 ;
	}

private:
    static const TF_DISPLAYATTRIBUTE	_s_DefaultDisplayAttribute ;
	static const WCHAR					_s_szDescription [] ;
	static const TCHAR					_s_szValueName [] ;
} ;


/*========================================================================*
 */
class CDisplayAttributeInfoConverted : public CDisplayAttributeInfo
{
public:
	CDisplayAttributeInfoConverted () {
		_pGUID						= &c_guidSkkImeDisplayAttributeTargetConverted ;
		_pDefaultDisplayAttribute	= &_s_DefaultDisplayAttribute ;
		_wstrDescription			= _s_szDescription ;
		_tstrValueName				= _s_szValueName ;
		_bAttr						= TF_ATTR_TARGET_CONVERTED ;
		_nStyleOffset				= SIZE_SKKIME_COLORFACE * 1 ;
	}

private:
    static const TF_DISPLAYATTRIBUTE	_s_DefaultDisplayAttribute ;
	static const WCHAR					_s_szDescription [] ;
	static const TCHAR					_s_szValueName [] ;
} ;

#endif

