/*	globals.cpp
 *
 *	Global variables.
 */
#include "globals.h"
#include <tchar.h>
#include <stdarg.h>
#include <shlwapi.h>

HINSTANCE			g_hInst ;

LONG				g_cRefDll	= -1 ;	// -1 /w no refs, for win95 InterlockedIncrement/Decrement compat

CRITICAL_SECTION	g_cs ;

/*	������ GUID �̐����ɂ� GUIDGEN.EXE ���g���B������ GUID ��
 *	���p/�Q��?�̂�����ɂ��ẮA�܂��������B
 */
// {7F9057A4-CBEF-49de-814C-584CA6C07DBD}
const CLSID	c_clsidSkkImeTextService	= {
	0x7f9057a4, 0xcbef, 0x49de, { 0x81, 0x4c, 0x58, 0x4c, 0xa6, 0xc0, 0x7d, 0xbd }
} ;

// {4920BE55-E37F-47eb-B868-2C4D6F5FB4B6}
const GUID	c_guidSkkImeProfile = {
	0x4920be55, 0xe37f, 0x47eb, { 0xb8, 0x68, 0x2c, 0x4d, 0x6f, 0x5f, 0xb4, 0xb6 }
} ;

// {3016F1C5-4185-4b62-8CB9-79362086A52F}
const GUID	c_guidConversionModeItemButton = {
	0x3016f1c5, 0x4185, 0x4b62, { 0x8c, 0xb9, 0x79, 0x36, 0x20, 0x86, 0xa5, 0x2f }
} ;

// {ADA0CD91-52FF-49fe-8242-7587B52A44E4}
const GUID	c_guidToolItemButton	= {
	0xada0cd91, 0x52ff, 0x49fe, { 0x82, 0x42, 0x75, 0x87, 0xb5, 0x2a, 0x44, 0xe4 }
} ;

// {FF976F3B-2060-4084-8F07-308DC9530C3F}
const GUID	c_guidSkkImeDisplayAttribute	= {
	0xff976f3b, 0x2060, 0x4084, { 0x8f, 0x7, 0x30, 0x8d, 0xc9, 0x53, 0xc, 0x3f }
} ;

// {C16938F3-9586-4e89-B58E-F0648A1EAE0A}
const GUID	c_guidSkkImeDisplayAttributeInput	= {
	0xc16938f3, 0x9586, 0x4e89, { 0xb5, 0x8e, 0xf0, 0x64, 0x8a, 0x1e, 0xae, 0xa }
} ;

// {4AEC39C3-D3C1-4c14-BD5F-9D7166BF374A}
const GUID	c_guidSkkImeDisplayAttributeTargetConverted	= {
	0x4aec39c3, 0xd3c1, 0x4c14, { 0xbd, 0x5f, 0x9d, 0x71, 0x66, 0xbf, 0x37, 0x4a }
} ;

// {F0054E62-34B7-4dab-AA30-DE0DD5E59FA1}
const GUID	c_guidSkkImePreservedKeyToggleIME = {
	0xf0054e62, 0x34b7, 0x4dab, { 0xaa, 0x30, 0xde, 0xd, 0xd5, 0xe5, 0x9f, 0xa1 }
} ;

/*========================================================================*
 *	global ``C'' functions
 */

/*	AdviseSink
 */
BOOL
AdviseSink (
	IUnknown*	pSourceIn,
	IUnknown*	pSink,
	REFIID		riid,
	DWORD*		pdwCookie)
{
    ITfSource*	pSource ;
    HRESULT		hr ;

	if (pSourceIn == NULL)
		return	FALSE ;
    if (pSourceIn->QueryInterface(IID_ITfSource, (void **)&pSource) != S_OK)
        return	FALSE ;

    hr = pSource->AdviseSink(riid, pSink, pdwCookie);

    pSource->Release () ;

    if (hr != S_OK) {
        // make sure we don't try to Unadvise pdwCookie later
        *pdwCookie = TF_INVALID_COOKIE;
        return	FALSE ;
    }

    return	TRUE ;
}

/*	UnadviseSink
 */
void
UnadviseSink (
	IUnknown*		pSourceIn,
	DWORD*			pdwCookie)
{
    ITfSource*		pSource ;

    if (*pdwCookie == TF_INVALID_COOKIE)
        return ; // never Advised

	if (pSourceIn == NULL)
		return ;

    if (pSourceIn->QueryInterface(IID_ITfSource, (void **)&pSource) == S_OK) {
        pSource->UnadviseSink (*pdwCookie) ;
        pSource->Release () ;
    }

    *pdwCookie	= TF_INVALID_COOKIE ;
	return ;
}

/*	AdviseSingleSink
 */
BOOL
AdviseSingleSink (
	TfClientId		tfClientId,
	IUnknown*		pSourceIn,
	IUnknown*		pSink,
	REFIID			riid)
{
    ITfSourceSingle*	pSource ;
    HRESULT				hr ;

    if (pSourceIn->QueryInterface(IID_ITfSourceSingle, (void **)&pSource) != S_OK)
        return	FALSE ;

    hr = pSource->AdviseSingleSink (tfClientId, riid, pSink) ;

    pSource->Release () ;

    return	(hr == S_OK);
}

/*	UnadviseSingleSink
 */
void
UnadviseSingleSink (
	TfClientId		tfClientId,
	IUnknown*		pSourceIn,
	REFIID			riid)
{
    ITfSourceSingle*	pSource ;

    if (pSourceIn->QueryInterface(IID_ITfSourceSingle, (void **)&pSource) == S_OK) {
        pSource->UnadviseSingleSink (tfClientId, riid) ;
        pSource->Release () ;
    }
}

void
InsertTextAtSelection (
	TfEditCookie		ec,
	ITfContext*			pContext,
	const WCHAR*		pchText,
	ULONG				cchText)
{
    ITfInsertAtSelection*	pInsertAtSelection ;
    ITfRange*				pRange ;
    TF_SELECTION			tfSelection ;

    // we need a special interface to insert text at the selection
    if (pContext->QueryInterface(IID_ITfInsertAtSelection, (void **)&pInsertAtSelection) != S_OK)
        return;

    // insert the text
    if (pInsertAtSelection->InsertTextAtSelection(ec, 0, pchText, cchText, &pRange) != S_OK)
        goto Exit;

    // update the selection, we'll make it an insertion point just past
    // the inserted text.
    pRange->Collapse(ec, TF_ANCHOR_END);

    tfSelection.range = pRange;
    tfSelection.style.ase = TF_AE_NONE;
    tfSelection.style.fInterimChar = FALSE;

    pContext->SetSelection(ec, 1, &tfSelection);

    pRange->Release();

Exit:
    pInsertAtSelection->Release();
}

BOOL
IsRangeCovered (TfEditCookie ec, ITfRange *pRangeTest, ITfRange *pRangeCover)
{
    LONG lResult;

    if (pRangeCover->CompareStart (ec, pRangeTest, TF_ANCHOR_START, &lResult) != S_OK ||
        lResult > 0) {
		DEBUGPRINTF ((TEXT ("pRangeCover->CompareStart (pRangeTest) = %ld\n"), lResult)) ;
        return	FALSE ;
    }

    if (pRangeCover->CompareEnd(ec, pRangeTest, TF_ANCHOR_END, &lResult) != S_OK ||
        lResult < 0) {
		DEBUGPRINTF ((TEXT ("pRangeCover->CompareEnd (pRangeTest) = %ld\n"), lResult)) ;
        return	FALSE ;
    }
    return	TRUE ;
}

BOOL
GetGUIDAtomFromGUID (
	REFGUID		refguid,
	DWORD*		pdw)
{
	ITfCategoryMgr*	pCategoryMgr ;
	HRESULT	hr ;

	hr = CoCreateInstance (CLSID_TF_CategoryMgr,
						   NULL, 
						   CLSCTX_INPROC_SERVER, 
						   IID_ITfCategoryMgr,
						   (void**)&pCategoryMgr) ;
	if (hr != S_OK)
        return	FALSE ;
	hr	= pCategoryMgr->RegisterGUID (refguid, pdw) ;
	pCategoryMgr->Release () ;
	return	(hr == S_OK) ;
}


void
DebugPrintf (
	LPCTSTR		strFormat,
	...)
{
	TCHAR		szBuffer [2048] ;
	va_list		vl ;

	if (strFormat == NULL)
		return ;

	va_start (vl, strFormat) ;
	wvnsprintf (szBuffer, sizeof (szBuffer) / sizeof (szBuffer [0]) - 1, strFormat, vl) ;
	va_end (vl) ;
	OutputDebugString (szBuffer) ;
	return ;
}

void
DebugPrintfW (
	LPCWSTR		strFormat,
	...)
{
	WCHAR		szBuffer [2048] ;
	va_list		vl ;

	if (strFormat == NULL)
		return ;

	va_start (vl, strFormat) ;
	wvnsprintfW (szBuffer, sizeof (szBuffer) / sizeof (szBuffer [0]) - 1, strFormat, vl) ;
	va_end (vl) ;
	OutputDebugStringW (szBuffer) ;
	return ;
}

void
vDebugPrintfToFile (
	LPCTSTR	strFormat,
	...)
{
	TCHAR	szBuffer [2048] ;
	va_list	vl ;
	HANDLE	hFile		= INVALID_HANDLE_VALUE ;
	DWORD	dwWritten	= 0, dwFileName = 0 ;
	TCHAR	szPath [MAX_PATH + 1] ;
	int		n ;

	/*	�f�o�b�O���O�̏o�̓p�X��ݒ肷��B*/
	dwFileName	= GetTempPath (MAX_PATH, szBuffer) ;
	if (dwFileName <= 0 || dwFileName >= MAX_PATH)
		return ;
	szBuffer [dwFileName]	= TEXT ('\0') ;
	n	= wnsprintf (szPath, MAX_PATH, TEXT ("%s%s"), szBuffer, DEBUGFILENAME) ;
	if (n < 0 || n >= MAX_PATH)
		return ;
	szPath [n]	= TEXT ('\0') ;

	va_start (vl, strFormat) ;
	n	= wvnsprintf (szBuffer, sizeof (szBuffer) / sizeof (szBuffer [0]), strFormat, vl) ;
	va_end (vl) ;
	if (n <= 0)
		return ;
	
	hFile	= CreateFile (szPath, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE) 
		return ;
	SetFilePointer (hFile, 0, NULL, FILE_END) ;
	(void) WriteFile (hFile, szBuffer, n * sizeof (TCHAR), &dwWritten, NULL) ;
	CloseHandle (hFile) ;
	return ;
}


