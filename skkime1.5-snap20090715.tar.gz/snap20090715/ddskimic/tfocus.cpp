/*	ITfThreadFocusSink implementation
 *
 */
#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "editsess.h"
#include "IME/ImeConfig.h"

STDAPI
CSkkImeTextService::OnSetThreadFocus ()
{
	DEBUGPRINTF ((TEXT ("OnSetThreadFocus (0x%lx)\n"), m_tfClientId)) ;
	if (m_pConfig != NULL) {
		m_pConfig->vUpdate () ;
	}
	if (m_pSkkIme != NULL) {
		_RestoreEditSession () ;
		_UpdateLangBarItem () ;
		m_pSkkIme->OnSetFocus (TRUE) ;
	}
    return S_OK;
}

/*	OnKillThreadFocus
 *
 *	Called by the system when the thread/appartment of this text service loses
 *	the ui focus.
 */
STDAPI
CSkkImeTextService::OnKillThreadFocus ()
{
	DEBUGPRINTF ((TEXT ("OnKillThreadFocus (0x%lx)\n"), m_tfClientId)) ;
	if (m_pSkkIme != NULL)
		m_pSkkIme->OnSetFocus (FALSE) ;
    return	S_OK ;
}

class CRestoreEditSession : public CEditSessionBase
{
public:
    CRestoreEditSession (ITfContext *pContext, CSkkImeMgr* pSkkIme) :
		CEditSessionBase(pContext)
	{
		m_pSkkIme	= pSkkIme ;
		return ;
	}
	
    // ITfEditSession
    STDMETHODIMP DoEditSession (TfEditCookie ec) ;
	
private:
	CSkkImeMgr*	m_pSkkIme ;
} ;

STDAPI
CRestoreEditSession::DoEditSession (
	TfEditCookie		ec)
{
	HRESULT	hr ;

	DEBUGPRINTF ((TEXT ("CRestoreEditSession::DoEditSession ()\n"))) ;

	hr	= m_pSkkIme->OnRestoreEditSession (m_pContext, ec) ;
	if (FAILED (hr)) {
		DEBUGPRINTF ((TEXT ("m_pSkkIme->OnRestoreEditSession failed(%0d).\n"), hr)) ;
	}
	return	hr ;
}

HRESULT
CSkkImeTextService::_RestoreEditSession ()
{
	CRestoreEditSession*	pEditSession	= NULL ;
	ITfContext*				pContext		= NULL ;
	HRESULT					hr ;
	HRESULT					hrEaten			= S_FALSE ;

	hr	= _GetFocusContext (&pContext) ;
	if (FAILED (hr))
		return	hr ;
	if (pContext == NULL)
		return	S_FALSE ;

	pEditSession = new CRestoreEditSession (pContext, m_pSkkIme) ;
    if (pEditSession == NULL) {
        hr	= E_OUTOFMEMORY ;
        goto	Exit ;
    }
	
	hr	= pContext->RequestEditSession(m_tfClientId, pEditSession, TF_ES_SYNC | TF_ES_READWRITE, &hrEaten) ;
    pEditSession->Release () ;
Exit:
	pContext->Release () ;
	return	hr ;
}

