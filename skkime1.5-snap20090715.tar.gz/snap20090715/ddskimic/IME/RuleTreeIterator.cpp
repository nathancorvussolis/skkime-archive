#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "ImeBuffer.h"
#include "RuleTreeIterator.h"
#include "RuleTreeNode.h"

/*	m_pSkkCurrentRuleTree �̑���́A������ method �o�R�ōs����B
 */
void
CSkkRuleTreeIterator::vReset () 
{
	m_pSkkRuleTree				= NULL ;
	m_nPrefixLength				= 0 ;
	m_iPreviousSelectBranchChar	= 0 ;
	return ;
}

/*	m_pSkkCurrentRuleTree �� Current-State �͌����Ȃ��BIterator ���ɊǗ�����
 *	��B(���R�͓���L���� RuleTree �� State �L�q�Ɋ܂܂��悤�ɂȂ�������)
 */
const DCHAR*
CSkkRuleTreeIterator::pGetPrefix (int* pnLength) const 
{
	/*
	 *	(pSkkCurrentRuleTree == NULL || 
	 *	CSkkRuleTreeNode::pGetPrefix (pSkkCurrentRuleTree, &nPrefix) == NULL)
	 *	CSkkRuleTreeNode::pGetPrefix() ���������ŗ��p����K�v������B
	 */
	if (pnLength != NULL)
		*pnLength	= m_nPrefixLength ;
	return	(m_nPrefixLength <= 0)? NULL : m_bufPrefix ;
}

BOOL	
CSkkRuleTreeIterator::bHavePrefixp () const
{
	return	(m_pSkkRuleTree != NULL)? TRUE : FALSE ;
}

int
CSkkRuleTreeIterator::iGetRuleTree () const
{
	return	m_iTree ;
}

BOOL
CSkkRuleTreeIterator::bRootp (CImeConfig* pConfig) 
{
	return	m_pSkkRuleTree == CImeConfig::pGetSkkRuleTree (pConfig, m_iTree) ;
}

void
CSkkRuleTreeIterator::vMoveToRoot (CImeConfig* pConfig)
{
	vReset () ;
	m_pSkkRuleTree	= CImeConfig::pGetSkkRuleTree (pConfig, m_iTree) ;
	return ;
}

void
CSkkRuleTreeIterator::vMoveTree (int iTree)
{
	m_iTree	= iTree ;
	return ;
}

BOOL
CSkkRuleTreeIterator::bHaveSelectBranchp (int wch)
{
	const CSkkRuleTreeNode*	pNode	= CSkkRuleTreeNode::pSelectBranch (m_pSkkRuleTree, wch) ;
	return	pNode != NULL ;
}

BOOL
CSkkRuleTreeIterator::bNextHasBranchListp (int wch)
{
	const CSkkRuleTreeNode*	pNext ;

	pNext	= CSkkRuleTreeNode::pSelectBranch (m_pSkkRuleTree, wch) ;
	if (pNext == NULL)
		return	FALSE ;
	return	CSkkRuleTreeNode::pGetBranchList (pNext) != NULL ;
}

const CSkkRuleTreeNodeOutput*
CSkkRuleTreeIterator::pGetOutput ()
{
	return	m_pSkkRuleTree != NULL? m_pSkkRuleTree->pGetOutput () : NULL ;
}

BOOL
CSkkRuleTreeIterator::bHaveNextState ()
{
	LPCDSTR	pwNextState ;
	int	nNextState, nNextTree ;

	if (m_pSkkRuleTree == NULL)
		return	FALSE ;
	pwNextState	= m_pSkkRuleTree->pGetNextState (&nNextState, &nNextTree) ;
	if (pwNextState != NULL && nNextState > 0)
		return	TRUE ;
	if (nNextTree != m_iTree)
		return	TRUE ;
	return	FALSE ;
}

int
CSkkRuleTreeIterator::iGetNextState (LPDSTR pwBuffer, int nBufferSize, int* pnNextTree)
{
	LPCDSTR	pNextState ;
	int		nNextState ;
	LPCDSTR	pwSrc ;
	LPCDSTR	pwSrcEnd ;

	if (m_pSkkRuleTree == NULL) {
		if (pnNextTree != NULL)
			*pnNextTree	= m_iTree ;
		return	0 ;
	}

	pNextState	= m_pSkkRuleTree->pGetNextState (&nNextState, pnNextTree) ;
	if (pNextState == NULL || nNextState <= 0)
		return	0 ;

	/*	pNextState �ɓ��ꕶ���͂���̂��H
	 */
	pwSrc		= pNextState ;
	pwSrcEnd	= pNextState + nNextState ;
	if (pwBuffer == NULL || nBufferSize <= 0) {
		int	nLength	= 0 ;
		while (pwSrc < pwSrcEnd) {
			if (*pwSrc == L'\\') {
				pwSrc	++ ;
				if (pwSrc >= pwSrcEnd)
					break ;
				switch (*pwSrc ++) {
				case	L'\\':
					nLength	++ ;
					break ;
				case	L'I':
					if (0x20 <= m_iPreviousSelectBranchChar && m_iPreviousSelectBranchChar < 128) {
						nLength	++ ;
					}
					break ;
				default:
					/* ��������B*/
					break ;
				}
			} else {
				nLength	++ ;
			}
		}
		return	nLength ;
	} else {
		LPDSTR	pwDest		= pwBuffer ;
		LPDSTR	pwDestEnd	= pwBuffer + nBufferSize ;
		while (pwDest < pwDestEnd && pwSrc < pwSrcEnd) {
			if (*pwSrc == L'\\') {
				pwSrc	++ ;
				if (pwSrc >= pwSrcEnd)
					break ;
				switch (*pwSrc ++) {
				case	L'\\':
					*pwDest ++	= L'\\' ;
					break ;
				case	L'I':
					if (0x20 <= m_iPreviousSelectBranchChar && m_iPreviousSelectBranchChar < 128) {
						*pwDest ++	= (DCHAR) m_iPreviousSelectBranchChar ;
					}
					break ;
				default:
					/* ��������B*/
					break ;
				}
			} else {
				*pwDest ++	= *pwSrc ++ ;
			}
		}
		return	pwDest - pwBuffer ;
	}
}

void
CSkkRuleTreeIterator::vWalk (int wch)
{
	const CSkkRuleTreeNode*	pNext ;

	pNext	= CSkkRuleTreeNode::pSelectBranch (m_pSkkRuleTree, wch) ;
	if (pNext == NULL) {
		vReset () ;
	} else {
		m_pSkkRuleTree						= pNext ;
		if (m_nPrefixLength < MAXLEN_PREFIX) {
			m_bufPrefix [m_nPrefixLength ++]	= (DCHAR) wch ;
		}
		m_iPreviousSelectBranchChar			= wch ;
	}
	return ;
}

