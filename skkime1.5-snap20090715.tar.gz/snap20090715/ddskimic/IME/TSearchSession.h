#pragma once

#include "dchar.h"
#include "varbuffer.h"
#include "TCommuSession.h"

enum {
	SEARCH_OKURI_NASHI	= 0,
	SEARCH_OKURI_ARI,
	SEARCH_OKURI_STRICT,
	SEARCH_OKURI_STRICT_PRECEDENCE,
	SEARCH_OKURI_AUTO,
} ;

/*	MAXKEYWORDLEN �� COMPSIZELEN �ȏ�ł���K�v������B
 *	(���������͓��͂ł��Ȃ��Ǝv�����c�B)
 */
#define	MAXKEYWORDLEN		(256)

/*	���� 37 �͓��ɍ���������킯�ł͂Ȃ��Bperformance �𓾂邽�߂ɂ�
 *	�����ɂ�钲�����K�v���B*/
#define	CANDIDATEHASHSIZE	(37)

class CTSearchSessionCandidate ;
class CTPacket ;
class CTS4Mapping ;
class CTS4Candidate ;

class CTSearchSession : public CTCommunicateSession {
protected:
	DCHAR							m_rszKeyword [MAXKEYWORDLEN] ;
	int								m_nwstrKeyword ;
	DCHAR							m_rszNumericList [MAXKEYWORDLEN] ;

	CTSearchSessionCandidate*		m_pCurCandidate ;
	CTSearchSessionCandidate*		m_pTopCandidate ;
	CTSearchSessionCandidate*		m_pLastCandidate ;

	/*	�P��̏d�Ȃ������邽�߂� hash table */
	CTSearchSessionCandidate*		m_rpTblCandidate [CANDIDATEHASHSIZE] ;

	/*	�P��̗���܂Ƃ߂ĕێ����Ă���o�b�t�@�B*/
	CVarbuffer <DCHAR, 256>			m_vbufCandidate ;
	int								m_nCandidate ;
	int								m_nSearchCount ;
	int								m_nParsePosition ;

public:
	CTSearchSession () ;
	CTSearchSession (LPCDSTR wstrKeyword, int nKeyword) ;
	virtual			~CTSearchSession () ;
	
	virtual	LPCDSTR						pGetKeyword (int* pnWord) ;
	virtual	LPCDSTR						pGetKeyword (int* pnWord) const ;
	virtual	LPCDSTR						pGetCandidate () ;
	virtual	LPCDSTR						pGetReferCandidate () ;
	virtual	BOOL						bInsertCandidate (LPCDSTR wstring, int nstring) ;
	virtual	BOOL						bInsertCandidateWithS4Mapping (LPCDSTR wstrCandidate, int nstrCandidate, const CTS4Mapping*	plstS4Mapping) ;
	virtual	BOOL						bRemoveCandidate () ;
	virtual	BOOL						bLinkCandidate (CTSearchSessionCandidate*) ;
	virtual	CTSearchSessionCandidate*	pGetCurrentPoint () ;
	virtual	int							iGetNumberOfCandidate (BOOL* pfContinue) ;
	virtual	BOOL						bNextCandidate () ;
	virtual	BOOL						bPreviousCandidate () ;
	virtual	BOOL						bRewind () ;

	virtual	BOOL						bNumericp () const ;
	virtual	LPCDSTR						pGetNumericList () const ;
	virtual	CTS4Candidate*				pGetNumericLink () ;
	virtual	LPCDSTR						pGetNumericKeyword (CTS4Candidate* pNumCand, int* pnKeywordLen) ;
	virtual	LPCDSTR						pGetNumericResult (CTS4Candidate* pNumCand, int* pnResultLen) ;
	virtual	CTS4Candidate*				pGetNextNumericLink (CTS4Candidate* pNumCand) ;

protected:
	virtual	BOOL						_bSearch () = 0 ;
	virtual	BOOL						_bNumericp () const ;
	virtual	BOOL						_bIsSeparateChar (DCHAR wch) const ;

protected:
	virtual	BOOL						_bUpdateCandidateList (int nPosition) ;
	virtual	CTSearchSessionCandidate*	_pCreateCandidate (int nPosition, int nCount, BOOL* pfRetval) ;
	virtual	BOOL						_bInsertCandidateLast (CTSearchSessionCandidate* pEntry) ;
	virtual	CTSearchSessionCandidate*	_pGetCandidate (LPCDSTR wstring, int nstring) ;
	virtual	BOOL						_bIsExistCandidatep (LPCDSTR wstring, int nstring) ;
	virtual	BOOL						_bRegisterCandidate (CTSearchSessionCandidate* pNewEntry) ;
	virtual	BOOL						_bCleanupHashTable () ;
	virtual	BOOL						_bCleanupHashTableSub (CTSearchSessionCandidate* pEntry) ;
	virtual	BOOL						_bRemoveCandidate (CTSearchSessionCandidate* pEntry) ;
	virtual	BOOL						_bInsertCandidateNext (CTSearchSessionCandidate* pNode, CTSearchSessionCandidate* pNewNode) ;

	virtual	BOOL						_bMultipleNumConvert () ;
	virtual	BOOL						_bNumConvert (CTSearchSessionCandidate* pEntry, LPCDSTR wstrNumList, const CTS4Mapping* plstS4Mapping, BOOL* pbConverted) ;
} ;

class CTHenkanSession : public CTSearchSession {
private:
	/*	���l�ϊ����L���ł����Ă��A�����ɐ��l�ϊ����Ȃ��������������Ƃ����ύX���ŐV�� ddskk �ł�
	 *	�ׂ���Ă���̂ŁA���Ƃ��Ƃ̃L�[���[�h���o����B
	 */
	DCHAR			m_rszNoConvKeyword [MAXKEYWORDLEN] ;
	int				m_nwstrNoConvKeyword ;
	int				m_iSearchType ;
	BOOL			m_bNumericConversion ;
	BOOL			m_bNumericFloat ;

public:
	CTHenkanSession (LPCDSTR wstrKeyword, int nKeyword, int iSearchType, BOOL bNumericConversion, BOOL bNumericFloat) ;
	virtual			~CTHenkanSession () {
		return ;
	}

protected:
	virtual	BOOL	_bSearch () ;
	virtual	BOOL	_bNumericp () const ;

private:
	BOOL			_bSearch (LPCDSTR pwKeyword, int nwKeyword) ;
} ;

class CTOkuriHenkanSession : public CTSearchSession {
private:
	DCHAR			m_rszOkuriChar [MAXKEYWORDLEN] ;
	int				m_nOkuriCharLen ;
	int				m_iSearchType ;
	BOOL			m_bNumericConversion ;
	BOOL			m_bNumericFloat ;

public:
	CTOkuriHenkanSession (LPCDSTR wstrKeyword, int nKeywordLen, LPCDSTR wstrOkuriChar, int nOkuriCharLen, int iSearchType, BOOL bNumericConversion, BOOL bNumericFloat) ;
	virtual			~CTOkuriHenkanSession () {
		return ;
	}

protected:
	virtual	BOOL	_bSearch () ;
} ;

class CTCompletionSession : public CTSearchSession {
public:
	CTCompletionSession (LPCDSTR wstrKeyword, int nKeyword) ;
	virtual			~CTCompletionSession () {
		return ;
	}

protected:
	virtual	BOOL	_bSearch () ;
	virtual	BOOL	_bIsSeparateChar (DCHAR wch) const ;
} ;

class CTKakuteiHistoryCompletionSession : public CTSearchSession {
public:
	CTKakuteiHistoryCompletionSession () ; 
	virtual			~CTKakuteiHistoryCompletionSession () {
		return ;
	}

protected:
	virtual	BOOL	_bSearch () ;
	virtual	BOOL	_bIsSeparateChar (DCHAR wch) const ;
} ;


class CTS4Mapping {
private:
	CTS4Mapping*		m_pNext ;
	LPDSTR				m_pwKeyword ;
	LPDSTR				m_pwResult ;
	int					m_nResultLen ;

public:
	CTS4Mapping () : m_pNext (NULL), m_pwKeyword (NULL), m_pwResult (NULL), m_nResultLen (0) {
		return ;
	}
	virtual	~CTS4Mapping () {
		if (m_pwKeyword != NULL) {
			delete[]	m_pwKeyword ;
			m_pwKeyword	= NULL ;
		}
		if (m_pwResult != NULL) {
			delete[]	m_pwResult ;
			m_pwResult	= NULL ;
		}
		m_nResultLen	= 0 ;
		m_pNext			= NULL ;
		return ;
	}

	virtual LPCDSTR	pGetKeyword () const {
		return	m_pwKeyword ;
	}

	virtual LPCDSTR	pGetResult () const {
		return	m_pwResult ;
	}

	virtual int		iGetResultLength () const {
		return	m_nResultLen ;
	}

	virtual CTS4Mapping*	pGetNext () {
		return	m_pNext ;
	}

	virtual const CTS4Mapping*	pGetNext () const {
		return	m_pNext ;
	}

public:
	static	CTS4Mapping*	pCreate (
		LPCDSTR			pwKeyword,
		LPCDSTR			pwResult,
		int				nResultLen) {
		CTS4Mapping*	pNode ;
		int				nKeywordLen ;

		/*	keyword �͋�ł����Ă͂Ȃ�Ȃ��B���ʂ���ł��邱�Ƃ͔F�߂邪�B
		 */
		if (pwKeyword == NULL)	/* error */
			return	NULL ;
		nKeywordLen	= dcslen (pwKeyword) ;
		if (nKeywordLen <= 0)
			return	NULL ;

		pNode		= new CTS4Mapping () ;
		if (pNode == NULL)
			return	NULL ;
		pNode->m_pwKeyword	= new DCHAR [nKeywordLen + 1] ;
		if (pNode->m_pwKeyword == NULL) {
			delete	pNode ;
			return	NULL ;
		}
		dcscpy (pNode->m_pwKeyword, pwKeyword) ;
		if (nResultLen > 0) {
			pNode->m_pwResult	= new DCHAR [nResultLen + 1] ;
			if (pNode->m_pwResult == NULL) {
				delete	pNode ;
				return	NULL ;
			}
			dcsncpy (pNode->m_pwResult, pwResult, nResultLen) ;
			pNode->m_pwResult [nResultLen]	= L'\0' ;
			pNode->m_nResultLen	= nResultLen ;
		} else {
			pNode->m_pwResult	= NULL ;
			pNode->m_nResultLen	= 0 ;
		}
		pNode->m_pNext		= NULL ;
		return	pNode ;
	}

	/*	#4 �̑Ή����X�g�͒����Ȃ�Ȃ��Ɖ��肵�Ă���̂� ok �Ƃ���B*/
	static	BOOL	bInsertLast (CTS4Mapping** plstTop, CTS4Mapping* pNewNode) {
		CTS4Mapping*	pNode ;
		CTS4Mapping*	pPrevNode ;

		if (plstTop == NULL || pNewNode == NULL)
			return	FALSE ;

		pNode		= *plstTop ;
		pPrevNode	= NULL ;
		while (pNode != NULL) {
			pPrevNode	= pNode ;
			pNode		= pNode->m_pNext ;
		}
		if (pPrevNode != NULL) {
			pPrevNode->m_pNext	= pNode ;
		} else {
			*plstTop	= pNewNode ;
		}
		return	TRUE ;
	}

	static	void	vClearList (CTS4Mapping* plstTop) {
		CTS4Mapping*		pNode ;
		CTS4Mapping*		pNextNode ;

		pNode	= plstTop ;
		while (pNode != NULL) {
			pNextNode	= pNode->m_pNext ;
			delete	pNode ;
			pNode		= pNextNode ;
		}
		return ;
	}
} ;

