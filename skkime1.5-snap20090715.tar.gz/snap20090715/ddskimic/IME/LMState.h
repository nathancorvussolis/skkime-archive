#pragma once

/*	state functions
 */
static	int		LM_iMessageLoop				(CImeDoc* pThis) ;
static	int		LM_bSelfInsertCharacter		(CImeDoc* pThis) ;
static	int		LM_bBackwardChar			(CImeDoc* pThis) ;
static	int		LM_bForwardChar				(CImeDoc* pThis) ;
static	int		LM_bDeleteChar				(CImeDoc* pThis) ;
static	int		LM_bBackwardDeleteChar		(CImeDoc* pThis) ;
static	int		LM_bTransposeChars			(CImeDoc* pThis) ;
static	int		LM_bEndOfLine				(CImeDoc* pThis) ;
static	int		LM_bBeginningOfLine			(CImeDoc* pThis) ;
static	int		LM_bSetMarkCommand			(CImeDoc* pThis) ;
static	int		LM_bKeyboardQuit			(CImeDoc* pThis) ;
static	int		LM_bNextCommandEvent		(CImeDoc* pThis) ;
static	int		LM_bReadFromMinibuffer		(CImeDoc* pThis) ;
static	int		LM_bYesOrNop				(CImeDoc* pThis) ;
static	int		LM_bAbortRecursiveEdit		(CImeDoc* pThis) ;
static	int		LM_bExitRecursiveEdit		(CImeDoc* pThis) ;
static	int		LM_bNewline					(CImeDoc* pThis) ;
static	int		LM_bNextLine				(CImeDoc* pThis) ;
static	int		LM_bPreviousLine			(CImeDoc* pThis) ;
static	int		LM_bBackwardWord			(CImeDoc* pThis) ;
static	int		LM_bForwardWord				(CImeDoc* pThis) ;
static	int		LM_bUnprecessEvent			(CImeDoc* pThis) ;

/*	skk-side
 */
static int		LM_bSkkPreCommand			(CImeDoc* pThis) ;
static int		LM_bSkkPostCommand			(CImeDoc* pThis) ;
static int		LM_bSkkMode					(CImeDoc* pThis) ;
static int		LM_bSkkLatinMode			(CImeDoc* pThis) ;
static int		LM_bSkkJisx0208LatinMode	(CImeDoc* pThis) ;
static int		LM_bSkkAbbrevMode			(CImeDoc* pThis) ;
static int		LM_bSkkInsert				(CImeDoc* pThis) ;

static int		LM_bSkkEmulateOriginalMap	(CImeDoc* pThis) ;
static int		LM_bSkkSetHenkanPoint		(CImeDoc* pThis) ;
static int		LM_bSkkKanaInput			(CImeDoc* pThis) ;
static int		LM_bSkkHenkan				(CImeDoc* pThis) ;
static int		LM_bSkkSetHenkanPointSubr	(CImeDoc* pThis) ;
static int		LM_bSkkKakutei				(CImeDoc* pThis) ;
static int		LM_bSkkStartHenkan			(CImeDoc* pThis) ;
static int		LM_bSkkSetOkurigana			(CImeDoc* pThis) ;
static int		LM_bSkkPreviousCandidate	(CImeDoc* pThis) ;
static int		LM_bSkkDeleteBackwardChar	(CImeDoc* pThis) ;
static int		LM_bSkkTryCompletion		(CImeDoc* pThis) ;
static int		LM_bSkkAbbrevComma			(CImeDoc* pThis) ;
static int		LM_bSkkAbbrevPeriod			(CImeDoc* pThis) ;
static int		LM_bSkkToggleCharacters		(CImeDoc* pThis) ;
static int		LM_bSkkHiraganaRegion		(CImeDoc* pThis) ;
static int		LM_bSkkKatakanaRegion		(CImeDoc* pThis) ;
static int		LM_bSkkJisx0208LatinRegion	(CImeDoc* pThis) ;
static int		LM_bSkkLatinRegion			(CImeDoc* pThis) ;
static int		LM_bSkkJisx0208LatinInsert	(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanInMinibuff		(CImeDoc* pThis) ;

static int		LM_bSkkAdKeyboardQuit		(CImeDoc* pThis) ;
static int		LM_bSkkAdAbortRecursiveEdit	(CImeDoc* pThis) ;
static int		LM_bSkkAdExitMinibuffer		(CImeDoc* pThis) ;

static int		LM_bSkkAdNextLine			(CImeDoc* pThis) ;
static int		LM_bSkkAdPreviousLine		(CImeDoc* pThis) ;
static int		LM_bSkkAdNewline			(CImeDoc* pThis) ;

static int		LM_bSkkAutoStartHenkan		(CImeDoc* pThis) ;
static int		LM_bSkkInsertStr			(CImeDoc* pThis) ;
static int		LM_bSkkKanaCleanup			(CImeDoc* pThis) ;
static int		LM_bSkkToggleKutouten		(CImeDoc* pThis) ;
static int		LM_bSkkCurrentKuten			(CImeDoc* pThis) ;
static int		LM_bSkkCurrentTouten		(CImeDoc* pThis) ;

static int		LM_bSkkPurgeFromJisyo		(CImeDoc* pThis) ;

/*	skk-comp-side
 */
static int		LM_bSkkComp					(CImeDoc* pThis) ;
static int		LM_bSkkCompDo				(CImeDoc* pThis) ;
static int		LM_bSkkCompPrevious			(CImeDoc* pThis) ;
static int		LM_bSkkCompPreviousNext		(CImeDoc* pThis) ;

/*	skk-kcode-side
 */
static int		LM_bSkkInputByCodeOrMenu	(CImeDoc* pThis) ;

/*	�ǉ�: 
 */
static int		LM_bSkkSetCharBeforeAsOkurigana	(CImeDoc* pThis) ;

/*	skk-jisx0201
 */
static	int		LM_bSkkModeAdJisx0201			(CImeDoc* pThis) ;
static	int		LM_bSkkKakuteiAdJisx0201		(CImeDoc* pThis) ;
static	int		LM_bSkkLatinModeAdJisx0201		(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0208LatinModeAdJisx0201	(CImeDoc* pThis) ;
static	int		LM_bSkkAbbrevModeAdJisx0201		(CImeDoc* pThis) ;
static	int		LM_bSkkSetOkuriganaAdJisx0201	(CImeDoc* pThis) ;
static	int		LM_bSkkInsertAdJisx0201			(CImeDoc* pThis) ;

static	int		LM_bSkkJisx0201ModeOn			(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0201ZenkakuRegion	(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0201Region			(CImeDoc* pThis) ;
static	int		LM_bSkkToggleKatakana			(CImeDoc* pThis) ;
static	int		LM_bSkkToggleJisx0201			(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0201Mode				(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0201Henkan			(CImeDoc* pThis) ;

private:
/* �J�ړr���̏�ԁB�J�ڂ̐擪�Ƃ��ČĂ΂�邱�Ƃ͂Ȃ��B*/
static	int		LM_iMessageLoop_1			(CImeDoc* pThis) ;
static	int		LM_iPostMessageLoop			(CImeDoc* pThis) ;
static	int		LM_iPostMessageLoop_1		(CImeDoc* pThis) ;
static	int		LM_iPostMessageLoop_2		(CImeDoc* pThis) ;

static	int		LM_bSkkKeyboardQuit_PostProcessPreviousCandidateForDeleteOkuriWhenQuit	(CImeDoc* pThis) ;
static	int		LM_bKeyboardQuit_1			(CImeDoc* pThis) ;
static	int		LM_bReadFromMinibuffer_Exit	(CImeDoc* pThis) ;
static	int		LM_bYesOrNop_1				(CImeDoc* pThis) ;
static	int		LM_bYesOrNop_2				(CImeDoc* pThis) ;
static	int		LM_bYesOrNop_Exit			(CImeDoc* pThis) ;
static	int		LM_bSkkAbortRecursiveEdit_PostProcessPreviousCandidateForDeleteOkuriWhenQuit	(CImeDoc* pThis) ;
static	int		LM_bAbortRecursiveEdit_1	(CImeDoc* pThis) ;
static	int		LM_bExitRecursiveEdit_1 	(CImeDoc* pThis) ;
static	int		LM_bNewline_1				(CImeDoc* pThis) ;

static int		LM_bSkkInsert_Exit			(CImeDoc* pThis) ; /* */

static	int		LM_bSkkProcessPrefixOrSuffix	(CImeDoc* pThis) ;
static	int		LM_bSkkProcessPrefixOrSuffix_1	(CImeDoc* pThis) ;
static	int		LM_bSkkProcessPrefixOrSuffix_2	(CImeDoc* pThis) ;
static	int		LM_bSkkProcessPrefixOrSuffix_3	(CImeDoc* pThis) ;

static	int		LM_bSkkKanaInput_1		(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_1_1	(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_3		(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_3_1	(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_3_2	(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_4		(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_4_0	(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_4_0_1	(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_4_1	(CImeDoc* pThis) ;
static	int		LM_bSkkKanaInput_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkStartHenkan_1	(CImeDoc* pThis) ;
static	int		LM_bSkkStartHenkan_2	(CImeDoc* pThis) ;

static	int		LM_bSkkPreviousCandidate_1		(CImeDoc* pThis) ;
static	int		LM_bSkkPreviousCandidate_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkHenkan_1		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkan_3		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkan_4		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkan_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkSetHenkanPointSubr_1 (CImeDoc* pThis) ;

static	int		LM_bSkkSetHenkanPoint_1		(CImeDoc* pThis) ;
static	int		LM_bSkkSetHenkanPoint_2		(CImeDoc* pThis) ;
static	int		LM_bSkkSetHenkanPoint_3		(CImeDoc* pThis) ;
static	int		LM_bSkkSetHenkanPoint_4		(CImeDoc* pThis) ;
static	int		LM_bSkkSetHenkanPoint_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkMode_1	(CImeDoc* pThis) ;

static	int		LM_bSkkModeExit_1	(CImeDoc* pThis) ;

static	int		LM_bSkkLatinMode_1 (CImeDoc* pThis) ;

static	int		LM_bSkkJisx0208LatinMode_1 (CImeDoc* pThis) ;

static	int		LM_bSkkAbbrevMode_1 (CImeDoc* pThis) ;
static	int		LM_bSkkAbbrevMode_2 (CImeDoc* pThis) ;

static	int		LM_bSkkSetOkurigana_1 (CImeDoc* pThis) ;

static	int		LM_bSkkDeleteBackwardChar_1		(CImeDoc* pThis) ;
static	int		LM_bSkkDeleteBackwardChar_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkKakutei_1 (CImeDoc* pThis) ;
static	int		LM_bSkkKakutei_2 (CImeDoc* pThis) ;
static	int		LM_bSkkKakutei_3 (CImeDoc* pThis) ;
static	int		LM_bSkkKakutei_4 (CImeDoc* pThis) ;
static	int		LM_bSkkKakutei_5 (CImeDoc* pThis) ;

static	int		LM_bSkkModeExit (CImeDoc* pThis) ;

static	int		LM_bSkkHenkan1 (CImeDoc* pThis) ;

static	int		LM_bSkkHenkanInMinibuff_1 (CImeDoc* pThis) ;
static	int		LM_bSkkHenkanInMinibuff_S2 (CImeDoc* pThis) ;
static	int		LM_bSkkHenkanInMinibuff_S3 (CImeDoc* pThis) ;
static	int		LM_bSkkHenkanInMinibuff_S4 (CImeDoc* pThis) ;
static	int		LM_bSkkHenkanInMinibuff_Exit (CImeDoc* pThis) ;

static	int		LM_bSkkTryCompletion_1		(CImeDoc* pThis) ;
static	int		LM_bSkkTryCompletion_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkToggleCharacters_1 (CImeDoc* pThis) ;
static	int		LM_bSkkToggleCharacters_2 (CImeDoc* pThis) ;

static	int		LM_bSkkHenkanSkkRegionByFunc	(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanSkkRegionByFunc_1		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanSkkRegionByFunc_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkJisx0208LatinInsert_1	(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0208LatinInsert_2	(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0208LatinInsert_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkKanaCleanup_1 (CImeDoc* pThis) ;
static	int		LM_bSkkKanaCleanup_2 (CImeDoc* pThis) ;

static	int		LM_bSkkAutoStartHenkan_1	(CImeDoc* pThis) ;
static	int		LM_bSkkAutoStartHenkan_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkChangeMarker	 (CImeDoc* pThis) ;
static	int		LM_bSkkChangeMarker_1 (CImeDoc* pThis) ;

static	int		LM_bSkkPurgeFromJisyo_1		(CImeDoc* pThis) ;
static	int		LM_bSkkPurgeFromJisyo_2		(CImeDoc* pThis) ;
static	int		LM_bSkkPurgeFromJisyo_3		(CImeDoc* pThis) ;
static	int		LM_bSkkPurgeFromJisyo_4		(CImeDoc* pThis) ;
static	int		LM_bSkkPurgeFromJisyo_5		(CImeDoc* pThis) ;
static	int		LM_bSkkPurgeFromJisyo_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkUpdateJisyo		(CImeDoc* pThis) ;
static	int		LM_bSkkUpdateJisyo_1	(CImeDoc* pThis) ;
static	int		LM_bSkkUpdateJisyo_2	(CImeDoc* pThis) ;
static	int		LM_bSkkUpdateJisyo_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkRemoveCommon				(CImeDoc* pThis) ;
static	int		LM_bSkkRemoveCommon_1			(CImeDoc* pThis) ;

static	int		LM_bSkkHenkanShowCandidates		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanShowCandidates_1		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanShowCandidates_2		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanShowCandidates_3		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanShowCandidates_4		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanShowCandidates_5		(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanShowCandidates_Exit_0	(CImeDoc* pThis) ;
static	int		LM_bSkkHenkanShowCandidates_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkKeyboardQuit_1 (CImeDoc* pThis) ;

static	int		LM_bSkkAbortRecursiveEdit_1		(CImeDoc* pThis) ;

static	int		LM_bSkkExitMinibuffer_1		(CImeDoc* pThis) ;

static	int		LM_bSkkAdNewline_1		(CImeDoc* pThis) ;
static	int		LM_bSkkAdNewline_Exit	(CImeDoc* pThis) ;

//	static	int		LM_bSkkComp (CImeDoc* pThis) ;
//	static	int		LM_bSkkCompDo (CImeDoc* pThis) ;
//	static	int		LM_bSkkCompPrevious (CImeDoc* pThis) ;
//	static	int		LM_bSkkCompPreviousNext (CImeDoc* pThis) ;

static	int		LM_bSkkCompDo_1 (CImeDoc* pThis) ;

static	int		LM_bSkkInputByCodeOrMenu0		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenuJump	(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenu1		(CImeDoc* pThis) ;

static	int		LM_bSkkInputByCodeOrMenu_1		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenu_2		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenu_3		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenu_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkInputByCodeOrMenu0_1		(CImeDoc* pThis) ;

static	int		LM_bSkkInputByCodeOrMenuJump_1		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenuJump_2		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenuJump_Exit	(CImeDoc* pThis) ;

static	int		LM_bSkkInputByCodeOrMenu1_1		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenu1_2		(CImeDoc* pThis) ;
static	int		LM_bSkkInputByCodeOrMenu1_Exit	(CImeDoc* pThis) ;

static	int		LM_bKillRegion				(CImeDoc* pThis) ;
static	int		LM_bKillRingSave			(CImeDoc* pThis) ;
static	int		LM_bKillRingSave_Exit		(CImeDoc* pThis) ;
static	int		LM_bYank					(CImeDoc* pThis) ;

static	int		LM_bMouseDragRegion			(CImeDoc* pThis) ;
static	int		LM_bMouseDragRegionEnd		(CImeDoc* pThis) ;
static	int		LM_bMouseDragRegionEnd_Exit	(CImeDoc* pThis) ;
static	int		LM_bMouseCopy				(CImeDoc* pThis) ;
static	int		LM_bMouseCut				(CImeDoc* pThis) ;
static	int		LM_bMousePaste				(CImeDoc* pThis) ;
static	int		LM_bMouseDelete				(CImeDoc* pThis) ;

static	int		LM_bSkkToday				(CImeDoc* pThis) ;
static	int		LM_bSkkToday_1				(CImeDoc* pThis) ;
static	int		LM_bSkkToday_2				(CImeDoc* pThis) ;

static	int		LM_bSkkKakuteiAdJisx0201_Exit	(CImeDoc* pThis) ;
static	int		LM_bSkkSetOkuriganaAdJisx0201_1	(CImeDoc* pThis) ;
static	int		LM_bSkkSetOkuriganaAdJisx0201_2	(CImeDoc* pThis) ;
static	int		LM_bSkkInsertAdJisx0201_1		(CImeDoc* pThis) ;
static	int		LM_bSkkInsertAdJisx0201_2		(CImeDoc* pThis) ;
static	int		LM_bSkkInsertAdJisx0201_3		(CImeDoc* pThis) ;

static	int		LM_bSkkToggleKatakana_1			(CImeDoc* pThis) ;
static	int		LM_bSkkToggleKatakana_2			(CImeDoc* pThis) ;
static	int		LM_bSkkJisx0201Mode_Exit		(CImeDoc* pThis) ;

