#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "dchar.h"

DCHAR	todlower (DCHAR ch)
{
	return	(GET_UNICODE_PLANE(ch) == 0)? ((DCHAR)towlower ((WCHAR)GET_UNICODE_CODE(ch))) : ch ;
}

DCHAR	todupper (DCHAR ch)
{
	return	(GET_UNICODE_PLANE(ch) == 0)? ((DCHAR)towupper ((WCHAR)GET_UNICODE_CODE(ch))) : ch ;
}

BOOL	isdspace (DCHAR ch)
{
	return	(GET_UNICODE_PLANE(ch) == 0 && iswspace ((WCHAR)GET_UNICODE_CODE(ch))) ;
}

int	dcslen (LPCDSTR p)
{
	int	n = 0 ;

	while (*p != L'\0') {
		p	++ ;
		n	++ ;
	}
	return	n ;
}

int	dcsncmp (LPCDSTR p1, LPCDSTR p2, int n)
{
	while (n > 0 && *p1 == *p2 && *p1 != '\0') {
		p1	++ ;
		p2	++ ;
		n	-- ;
	}
	if (*p1 > *p2) {
		return	(int)(*p1 - *p2) ;
	} else {
		return	-(int)(*p2 - *p1) ;
	}
}

int	dcsnicmp (LPCDSTR p1, LPCDSTR p2, int n)
{
	while (n > 0 && todlower(*p1) == todlower(*p2) && *p1 != '\0') {
		p1	++ ;
		p2	++ ;
		n	-- ;
	}
	if (*p1 > *p2) {
		return	(int)(*p1 - *p2) ;
	} else {
		return	-(int)(*p2 - *p1) ;
	}
}

int dcscpy (LPDSTR pDest, LPCDSTR pSrc) 
{
	while (*pSrc != L'\0') {
		*pDest ++	= *pSrc ++ ;
	}
	*pDest	= L'\0' ;
	return	0 ;
}

int	dcsncpy (LPDSTR pDest, LPCDSTR pSrc, int n)
{
	while (n > 0 && *pSrc != L'\0') {
		*pDest ++	= *pSrc ++ ;
		n	-- ;
	}
	if (n > 0)
		*pDest	= L'\0' ;
	return	0 ;
}

int	wcstodcs (LPDSTR pDest, int nDestSize, LPCWSTR pSrc, int nSrcLen)
{
	DCHAR*	pDestEnd ;
	LPCWSTR	ptr ;
	LPCWSTR	ptrEnd ;

	ptr			= pSrc ;
	ptrEnd		= pSrc + nSrcLen ;

	//	���܂��܎c��o�b�t�@�T�C�Y��0�Ƃ������Ƀo�b�t�@�̕K�v�T�C�Y��Ԃ����ƍ���B
	if (pDest == NULL && nDestSize == 0) {
		int		n ;
		n	= 0 ;
		while (ptr < ptrEnd) {
			if (ptr < ptrEnd && IS_SURROGATE_PAIR (*ptr, *(ptr+1))) {
//				DWORD	dw	= MAKE_DCHAR_FROM_SURROGATE_PAIR (*ptr, *(ptr+1)) ;
				n	++ ;
				ptr	+= 2 ;
			} else {
				n	++ ;
				ptr	++ ;
			}
		}
		return	n ;
	} else {
		const DCHAR*	pDestBak	= pDest ;

		pDestEnd	= pDest + nDestSize ;
		while (ptr < ptrEnd) {
			if (ptr < ptrEnd && IS_SURROGATE_PAIR (*ptr, *(ptr+1))) {
				if (pDest < pDestEnd)
					*pDest ++	= MAKE_DCHAR_FROM_SURROGATE_PAIR (*ptr, *(ptr+1)) ;
				ptr += 2 ;
			} else {
				if (pDest < pDestEnd)
					*pDest ++	= MAKE_DCHAR(0, *ptr) ;
				ptr	++ ;
			}
		}
		return	pDest - pDestBak ;
	}
}

static	HMODULE	s_hDLL		= NULL ;
static	BOOL	s_bNormaliz	= TRUE ;

int	wcstodcs_n (LPDSTR pDest, int nDestSize, LPCWSTR pSrc, int nSrcLen)
{
	LPWSTR	pBuffer	= NULL ;
	WCHAR	buf [256] ;
	int	nLength, nNeed,nRetval ;
	FARPROC	pProc ;

	//	������ Normalize ����B
	if (s_hDLL == NULL) {
		if (! s_bNormaliz)
			goto	NonNormalizeExit ;

		s_hDLL	= LoadLibrary (TEXT ("Normaliz.dll")) ;
		if (s_hDLL == NULL) {
			s_bNormaliz	= FALSE ;
			goto	NonNormalizeExit ;
		}
	}
	pProc	= GetProcAddress (s_hDLL, "NormalizeString") ;
	if (pProc == NULL)
		goto	NonNormalizeExit ;
	nNeed	= ((int (WINAPI *)(NORM_FORM,LPCWSTR,int,LPWSTR,int))pProc)(NormalizationC, pSrc, nSrcLen, NULL, 0) ;
	if (nNeed < 0) {
		DWORD	dwError	= GetLastError () ;
		goto	NonNormalizeExit ;
	}
	if (nNeed > MYARRAYSIZE (buf)) {
		pBuffer	= new WCHAR [nNeed] ;
	} else {
		pBuffer	= buf ;
	}
	nLength	= ((int (WINAPI *)(NORM_FORM,LPCWSTR,int,LPWSTR,int))pProc)(NormalizationC, pSrc, nSrcLen, pBuffer, nNeed) ;
	if (nLength < 0) {
		DWORD	dwError	= GetLastError () ;

		if (pBuffer != buf)
			delete[]	pBuffer ;
		goto	NonNormalizeExit ;
	}
	nRetval	= wcstodcs (pDest, nDestSize, pBuffer, nLength) ;
	if (pBuffer != buf)
		delete []	pBuffer ;
	return	nRetval ;

NonNormalizeExit:
	return	wcstodcs (pDest, nDestSize, pSrc, nSrcLen) ;
}

int
dcstowcs (LPWSTR pwDest, int nDestSize, LPCDSTR pdSrc, int nSrcLen)
{
	LPCDSTR	ptr ;
	LPCDSTR	ptrEnd ;
	LPCWSTR	pwDestBak ;
	LPCWSTR	pwDestEnd, pwDestEnd_1 ;

	ptr		= pdSrc ;
	ptrEnd	= pdSrc + nSrcLen ;
	if (pwDest == NULL && nDestSize == 0) {
		int	n = 0 ;

		while (ptr < ptrEnd) {
			if (GET_UNICODE_PLANE (*ptr) == 0) {
				n	++ ;
			} else {
				n	+=2 ;
			}
			ptr	++ ;
		}
		return	n ;
	}

	pwDestBak	= pwDest ;
	pwDestEnd	= pwDest + nDestSize ;
	pwDestEnd_1	= pwDest + nDestSize - 1 ;

	while (ptr < ptrEnd && pwDest < pwDestEnd) {
		int	nPlane	= GET_UNICODE_PLANE (*ptr) ;
		if (nPlane == 0) {
			*pwDest ++	= (WCHAR) GET_UNICODE_CODE (*ptr) ;
		} else {
			if (pwDest < pwDestEnd_1) {
				*pwDest ++	= GET_HIGHSURROGATE_FROM_DCHAR (*ptr) ;
				*pwDest ++	= GET_LOWSURROGATE_FROM_DCHAR (*ptr) ;
			} else {
				break ;
			}
		}
		ptr	++ ;
	}
	return	pwDest - pwDestBak ;
}

