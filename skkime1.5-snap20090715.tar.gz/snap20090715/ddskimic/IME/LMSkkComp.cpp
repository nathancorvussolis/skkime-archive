#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "ImeDoc.h"
#include "ImeBuffer.h"
#include "TMarker.h"
#include "keymap.h"
#include "TSearchSession.h"
#include "jstring.h"
#include "ImeConfig.h"

/*================================================================ skk-comp
 */
int
CImeDoc::LM_bSkkComp (
	CImeDoc*			pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pThis->bSetThisCommand (NFUNC_SKK_COMP_DO) ;
	pThis->vJump (LM_bSkkCompDo) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-comp-do
 */
static	int	LM_bSkkCompDo_1		(CImeDoc*) ;

/*	LMREGARG_0:	bFirst
 */
int
CImeDoc::LM_bSkkCompDo (
	CImeDoc*			pThis)
{
	BOOL	bFirst ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;
	if (! pThis->bGetRegBool (LMREGARG_0, &bFirst))
		bFirst	= FALSE ;
	pThis->vSetRegBool (LMREG_0, bFirst) ;
	pThis->vSetRegBool (LMREGARG_0, TRUE) ;
	if (! pThis->bCall (LM_bSkkKanaCleanup, LM_bSkkCompDo_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkCompDo_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*			pBuffer ;
	CTSearchSession*	pSession ;
	int		nStart, nEnd ;
	LPCDSTR	pCWord ;
	LPCDSTR	pSkkCompKey ;
	int		nSkkCompKey ;
	BOOL	bFirst ;


	if (! pThis->bGetRegBool (LMREG_0, &bFirst))
		bFirst	= FALSE ;
	pThis->vPopReg (LMREG_0) ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->pSkkGetSkkHenkanStartPointMarker () == NULL || pBuffer->pGetPointMarker () == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	nStart	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
	nEnd	= pBuffer->iGetPoint () ;
	if (nEnd < nStart || nEnd < 0 || nStart > pBuffer->iGetPointMax () || (nEnd > nStart && nStart == pBuffer->iGetPointMax ())) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pSession	= pBuffer->pSkkGetSkkCurrentCompletionSession () ;
	if (bFirst) {
		if (pSession != NULL) {
			pBuffer->vSkkSetSkkCurrentCompletionSession (NULL) ;
			delete	pSession ;
			pSession	= NULL ;
		}

		if (nStart == nEnd) {
			/* kakutei-history ����̌����͉ۑ�Ƃ��Ďc���Ă����B
			 */
			pSession	= new CTKakuteiHistoryCompletionSession () ;
			if (pSession == NULL) {
				pThis->vSetSignalError () ;
				return	LMR_RETURN ;
			}
		} else {
			LPCDSTR	pwBufferString	= pBuffer->pBufferRawString (NULL) ;

			pSession	= new CTCompletionSession (pwBufferString + nStart, nEnd - nStart) ;
			if (pSession == NULL) {
				pThis->vSetSignalError () ;
				return	LMR_RETURN ;
			}
		}
		pBuffer->vSkkSetSkkCurrentCompletionSession (pSession) ;
		pCWord	= pSession->pGetCandidate () ;
	} else {
		if (! pSession->bNextCandidate ()) {
			pCWord	= NULL ;
			if (CImeConfig::bSkkCompCirculatep (pThis->m_pConfig)) {
				if (pSession->bRewind ()) {
					pCWord	= pSession->pGetCandidate () ;
				}
			}
		} else {
			pCWord	=  pSession->pGetCandidate () ;
		}
	}
	if (pCWord == NULL) {
		pSkkCompKey	= pSession->pGetKeyword (&nSkkCompKey) ;
		if (CImeConfig::bSkkCompCirculatep (pThis->m_pConfig)) {
			pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iGetPoint ()) ;
			pBuffer->iInsert (pBuffer->pGetPointMarker (), pSkkCompKey, nSkkCompKey) ;
		} else {
			DCHAR	buf [MAXCOMPLEN] ;
			DCHAR*	pwDest ;
			DCHAR*	pwDestEnd ;

			pwDest		= buf ;
			pwDestEnd	= buf + ARRAYSIZE (buf) ;
			if (nSkkCompKey > 0 && pSkkCompKey != NULL) {
//				n	= wnsprintfW (buf, MYARRAYSIZE (buf), L"No %scompleitions for \"%s\"", (bFirst? L"" : L"more "), bufSkkCompKey) ;
				if (bFirst) {
					vCopyStringW (&pwDest, pwDestEnd, L"No completions for \"") ;
				} else {
					vCopyStringW (&pwDest, pwDestEnd, L"No more completions for \"") ;
				}
				vCopyStringN (&pwDest, pwDestEnd, pSkkCompKey, nSkkCompKey) ;
				vCopyStringW (&pwDest, pwDestEnd, L"\"") ;
			} else {
				vCopyStringW (&pwDest, pwDestEnd, L"No more words in history") ;
			}
			pThis->bSetMessageN (buf, pwDest - buf) ;
		}
	} else {
		pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iGetPoint ()) ;
		pBuffer->iInsert (pBuffer->pGetPointMarker (), pCWord, dcslen (pCWord)) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-comp-previous
 */
int
CImeDoc::LM_bSkkCompPrevious (
	CImeDoc*			pThis)
{
	CImeBuffer*			pBuffer ;
	CTSearchSession*	pSession ;
	int		nStart, nEnd ;
	LPCDSTR	pCWord ;
	LPCDSTR	pSkkCompKey ;
	int		nSkkCompKey ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pSession	= pBuffer->pSkkGetSkkCurrentCompletionSession () ;
	if (pSession == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->pSkkGetSkkHenkanStartPointMarker () == NULL || pBuffer->pGetPointMarker () == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	nStart	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
	nEnd	= pBuffer->iGetPoint () ;
	if (nEnd < nStart || nEnd < 0 || nStart >= pBuffer->iGetPointMax ()) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pSession->bPreviousCandidate ()) {
		if (CImeConfig::bSkkCompCirculatep (pThis->m_pConfig)) {
			while (pSession->bNextCandidate ())
				;
			pCWord	= pSession->pGetCandidate () ;
		} else {
			pCWord	= NULL ;
		}
	} else {
		pCWord	= pSession->pGetCandidate () ;
	}
	if (pCWord == NULL) {
		pSkkCompKey	= pSession->pGetKeyword (&nSkkCompKey) ;
		if (CImeConfig::bSkkCompCirculatep (pThis->m_pConfig)) {
			pBuffer->bDeleteRegion (nStart, nEnd) ;
			pBuffer->iInsertByPosition (nStart, pSkkCompKey, nSkkCompKey) ;
		} else {
			DCHAR	buf [MAXCOMPLEN] ;
			DCHAR*	pwDest ;
			DCHAR*	pwDestEnd ;

			pwDest		= buf ;
			pwDestEnd	= buf + ARRAYSIZE (buf) ;
			if (nSkkCompKey > 0 && pSkkCompKey != NULL) {
//				n	= wnsprintfW (buf, MYARRAYSIZE (buf), L"No previous compleitions for \"%s\"", bufSkkCompKey) ;
				vCopyStringW (&pwDest, pwDestEnd, L"No previous compleitions for \"") ;
				vCopyStringN (&pwDest, pwDestEnd, pSkkCompKey, nSkkCompKey) ;
				vCopyStringW (&pwDest, pwDestEnd, L"\"") ;
			} else {
				vCopyStringW (&pwDest, pwDestEnd, L"No previous words in history") ;
			}
			pThis->bSetMessageN (buf, pwDest - buf) ;
		}
	} else {
		pBuffer->bDeleteRegion (nStart, nEnd) ;
		pBuffer->iInsertByPosition (nStart, pCWord, dcslen (pCWord)) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-comp-previous-next
 */
/*
(defun skk-comp-previous/next (ch)
  (setq this-command 'skk-comp-do)
  (cond ((eq ch skk-next-completion-char)
	 (skk-comp-do nil))
	((eq ch skk-previous-completion-char)
	 (skk-previous-completion))))
*/
int
CImeDoc::LM_bSkkCompPreviousNext (
	CImeDoc*			pThis)
{
	int		nCH ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bGetRegInteger (LMREGARG_0, &nCH)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pThis->bSetThisCommand (NFUNC_SKK_COMP_DO) ;
	if (CImeConfig::bSkkNextCompletionCharp (pThis->m_pConfig, nCH)) {
		pThis->vSetRegBool (LMREGARG_0, FALSE) ;
		pThis->vJump (LM_bSkkCompDo) ;
		return	LMR_CONTINUE ;
	} else if (CImeConfig::bSkkPreviousCompletionCharp (pThis->m_pConfig, nCH)) {
		pThis->vJump (LM_bSkkCompPrevious) ;
		return	LMR_CONTINUE ;
	} else {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}
}



