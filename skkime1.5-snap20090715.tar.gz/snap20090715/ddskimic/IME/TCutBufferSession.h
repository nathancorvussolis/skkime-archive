#pragma once

#include "dchar.h"
#include "TCommuSession.h"

class CTCutBufferSession : public CTCommunicateSession {
public:
	static	BOOL	bSet (LPCDSTR pwText, int iTextLength, BOOL bAppend) ;
	static	int		iGet (LPDSTR pwBuffer, int iBufferSize) ;
} ;


