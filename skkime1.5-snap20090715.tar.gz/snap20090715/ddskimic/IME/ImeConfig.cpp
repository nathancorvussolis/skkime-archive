/*
 *	configuration �� update �������������ɂ��̒��g���Q�Ƃ���Ă����
 *	application ��������c���� rule-tree �̓r�������Ă��邱�Ƃ͂��蓾��B
 *	�����͉��Ƃ����Ȃ��Ƃ����Ȃ��Ǝv���B(�܂胁�b�Z�[�W���[�v�̂ǂ̈ʒu�ŁA��)
 */

#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "RuleTreeNode.h"
#include "keymap.h"
#include "jstring.h"
#include "ImeConfig.h"

/*========================================================================
 *	Registry-related definitions
 */
/*	generic configs */
#define	REGPATH_GENERIC						REGPATH_SKKIME L"\\Generic"
#define	REGINFO_KANAMODEWHENOPEN			L"KanaModeWhenOpen"
#define	REGINFO_ECHO						L"Echo"
#define	REGINFO_EGGLIKENEWLINE				L"EggLikeNewline"
#define	REGINFO_NEWLINEKAKUTEIALL			L"NewlineKakuteiAll"
#define	REGINFO_AUTOINSERTPAREN				L"AutoInsertParen"
#define	REGINFO_COMPOSITIONAUTOSHIFT		L"CompTextAutoShift"
#define	REGINFO_DELETEIMPLIESKAKUTEI		L"DeleteImpliesKakutei"
#define	REGINFO_DATEAD						L"DateAd"
#define	REGINFO_NUMBERSTYLE					L"NumberStyle"
#define	REGINFO_BRACKETPARENS				L"CustomBracketParens"
#define	REGINFO_KUTOUTENTYPE				L"KutoutenType"
#define	REGINFO_KUTOUTENS					L"CustomKutoutens"
#define	REGINFO_KAKUTEIEARLY				L"KakuteiEarly"
#define	REGINFO_OKURICHARALISTTYPE			L"OkuriCharAlistType"
#define	REGINFO_OKURICHARALIST				L"OkuriCharAlist"
#define	REGINFO_TICK						L"Tick"
#define	REGINFO_TSFKEYDOWNEATENDOESNOTWORK	L"TSFKeyDownEatenDoesNotWork"

/* key related */
#define	REGPATH_KEYMAP						REGPATH_SKKIME L"\\Generic"
#define	REGINFO_MAJORMODEMAP				L"MajorModeMap"
#define	REGINFO_JMODEMAP					L"JModeMap"
#define	REGINFO_LATINMODEMAP				L"LatinModeMap"
#define	REGINFO_ZENKAKUMODEMAP				L"Jisx0208LatinModeMap"
#define	REGINFO_ABBREVMODEMAP				L"AbbrevModeMap"
#define	REGINFO_MAJORMODEMAP_EX				L"MajorModeMapEx"
#define	REGINFO_JMODEMAP_EX					L"JModeMapEx"
#define	REGINFO_LATINMODEMAP_EX				L"LatinModeMapEx"
#define	REGINFO_ZENKAKUMODEMAP_EX			L"Jisx0208LatinModeMapEx"
#define	REGINFO_ABBREVMODEMAP_EX			L"AbbrevModeMapEx"
#define	REGINFO_KEYMAP_TYPE					L"KeymapType"
#define	REGINFO_STARTHENKANKEY_TYPE			L"StartHenkanKeyType"
#define	REGINFO_STARTHENKANKEY				L"StartHenkanKey"
#define	REGINFO_COMPLETIONRELATEDKEY_TYPE	L"CompletionRelatedKeyType"
#define	REGINFO_TRYCOMPLETIONKEY			L"TryCompletionKey"
#define	REGINFO_PREVIOUSCOMPLETIONKEY		L"PreviousCompletionKey"
#define	REGINFO_NEXTCOMPLETIONKEY			L"NextCompletionKey"
#define	REGINFO_SETHENKANPOINTSUBRKEY_TYPE	L"SetHenkanPointSubrKeyType"
#define	REGINFO_SETHENKANPOINTSUBRKEY		L"SetHenkanPointSubrKey"
#define	REGINFO_SPECIALMIDASHICHAR_TYPE		L"SpecialMidashiCharType"
#define	REGINFO_SPECIALMIDASHICHAR			L"SpecialMidashiChar"

#define	REGPATH_ROMAKANARULE				REGPATH_SKKIME L"\\Generic"
#define	REGINFO_ROMAKANARULE_TYPE			L"RomaKanaRuleType"
#define	REGINFO_ROMAKANARULE				L"RomaKanaRule"
#define	REGINFO_ROMAKANARULE1				L"RomaKanaRule1"
#define	REGINFO_ROMAKANARULE2				L"RomaKanaRule2"
#define	REGINFO_ROMAKANARULE3				L"RomaKanaRule3"
#define	REGINFO_JISX0201RULE				L"Jisx0201Rule"
#define	REGINFO_JISX0201RULE1				L"Jisx0201Rule1"
#define	REGINFO_JISX0201RULE2				L"Jisx0201Rule2"
#define	REGINFO_JISX0201RULE3				L"Jisx0201Rule3"
#define	REGINFO_JISX0201ROMANRULE			L"Jisx0201RomanRule"
#define	REGINFO_JISX0201ROMANRULE1			L"Jisx0201RomanRule1"
#define	REGINFO_JISX0201ROMANRULE2			L"Jisx0201RomanRule2"
#define	REGINFO_JISX0201ROMANRULE3			L"Jisx0201RomanRule3"


#define	ENABLE_OHHENKAN_DEFAULT_VALUE		TRUE

#define	REGPATH_ZENKAKUVECTOR				REGPATH_SKKIME L"\\Generic"
#define	REGINFO_ZENKAKUVECTOR_TYPE			L"ZenkakuVectorType"
#define	REGINFO_ZENKAKUVECTOR				L"ZenkakuVector"

/* conversion config */
#define	REGPATH_CONVERSION					REGPATH_SKKIME L"\\Conversion"
#define	REGINFO_CANDLISTKEYASSIGN			L"CandidateListKeyAssign"
#define	REGINFO_SHOWCANDIDATEKEYS			L"ShowCandidateKeys"
#define	REGINFO_INPUTCODEMENU1KEYS			L"InputCodeMenu1Keys"
#define	REGINFO_INPUTCODEMENU2KEYS			L"InputCodeMenu2Keys"
#define	REGINFO_SHOWCANDIDATELISTCOUNT		L"ShowCandidateListCount"
#define	REGINFO_HENKANOKURISTRICTLY			L"HenkanOkuriStrictly"
#define	REGINFO_PROCESSOKURIEARLY			L"ProcessOkuriEarly"
#define	REGINFO_HENKANSTRICTOKURIPRECEDENCE	L"HenkanStrictOkuriPrecedence"
#define	REGINFO_AUTOOKURIPROCESS			L"AutoOkuriProcess"
#define	REGINFO_AUTOSTARTHENKAN				L"AutoStartHenkan"
#define	REGINFO_AUTOSTARTHENKANKEYWORD		L"AutoStartHenkanKeyword"
#define	REGINFO_DELETEOKURIWHENQUIT			L"DeleteOkuriWhenQuit"
#define	REGINFO_SHOWANNOTATIONTYPE			L"ShowAnnotationType"
#define	REGINFO_NUMERICCONVERSION			L"NumericConversion"
#define	REGINFO_NUMERICFLOAT				L"NumericFloat"

/* colorface */
#define	REGPATH_COLORFACE					REGPATH_SKKIME L"\\ColorFace"
#define	REGSUBKEY_COLORFACE					L"style"
#define	REGSUBKEY_DEFAULTFONT				L"DefaultFont"
#define	REGSUBKEY_DEFAULTFONTSIZE			L"DefaultFontSize"

/*========================================================================
 *	definitions
 */
enum {
	KEYBINDTP_DEFAULT		= 0,
	KEYBINDTP_USERDEFINED,
} ;

enum {
	REGKEYTYPE_UNKNOWN	= -1,
	REGKEYTYPE_BOOL		= 0,
	REGKEYTYPE_INT,
} ;

enum {
	KUTOUTEN_TYPE_JP	= 0,
	KUTOUTEN_TYPE_EN,
	KUTOUTEN_TYPE_CUSTOM,
} ;

enum {
	BRACKETPARENTP_DEFAULT	= 0,
	BRACKETPARENTP_USERDEFINED,
} ;

enum {
	OKURICHARTP_DEFAULT	= 0,
	OKURICHARTP_USERDEFINED,
} ;

enum {
	CANDLIST_KEYASSIGN_DEFAULT			= 0,
	CANDLIST_KEYASSIGN_01234567890,
	CANDLIST_KEYASSIGN_USERDEFINED		= 65535,
} ;

/*========================================================================
 *	structures
 */
struct MYCOLORDEF {
	LPCDSTR		m_strText ;
	int			m_nType ;
} ;

/*========================================================================
 *	global variables (default settings)
 */
static const DCHAR	c_Zero	= 0 ;
static const DCHAR	c_Period []	= { L'.', L'\0' } ;
static const DCHAR	c_Comma []	= { L',', L'\0' } ;

LPCWSTR	CImeConfig::m_rstrDefaultJisx0208LatinVector [128]	= {
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	L"�@",	L"�I",	L"�h",	L"��",	L"��",	L"��",	L"��",	L"�f",
	L"�i",	L"�j",	L"��",	L"�{",	L"�C",	L"�|",	L"�D",	L"�^",
	L"�O",	L"�P",	L"�Q",	L"�R",	L"�S",	L"�T",	L"�U",	L"�V",
	L"�W",	L"�X",	L"�F",	L"�G",	L"��",	L"��",	L"��",	L"�H",
	L"��",	L"�`",	L"�a",	L"�b",	L"�c",	L"�d",	L"�e",	L"�f",
	L"�g",	L"�h",	L"�i",	L"�j",	L"�k",	L"�l",	L"�m",	L"�n",
	L"�o",	L"�p",	L"�q",	L"�r",	L"�s",	L"�t",	L"�u",	L"�v",
	L"�w",	L"�x",	L"�y",	L"�m",	L"�_",	L"�n",	L"�O",	L"�Q",
	L"�e",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",
	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",
	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",
	L"��",	L"��",	L"��",	L"�o",	L"�b",	L"�p",	L"�`",	NULL,
} ;

CTKanaRomaPair	CImeConfig::m_rSkkKanaRomVector [83]	= {
	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"a"),	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"i"),
	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"u"),	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"e"),
	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"o"),	CTKanaRomaPair (L'��', L"k"),	CTKanaRomaPair (L'��', L"g"),
	CTKanaRomaPair (L'��', L"k"),	CTKanaRomaPair (L'��', L"g"),	CTKanaRomaPair (L'��', L"k"),	CTKanaRomaPair (L'��', L"g"),
	CTKanaRomaPair (L'��', L"k"),	CTKanaRomaPair (L'��', L"g"),	CTKanaRomaPair (L'��', L"k"),	CTKanaRomaPair (L'��', L"g"),
	CTKanaRomaPair (L'��', L"s"),	CTKanaRomaPair (L'��', L"z"),	CTKanaRomaPair (L'��', L"s"),	CTKanaRomaPair (L'��', L"j"),
	CTKanaRomaPair (L'��', L"s"),	CTKanaRomaPair (L'��', L"z"),	CTKanaRomaPair (L'��', L"s"),	CTKanaRomaPair (L'��', L"z"),
	CTKanaRomaPair (L'��', L"s"),	CTKanaRomaPair (L'��', L"z"),	CTKanaRomaPair (L'��', L"t"),	CTKanaRomaPair (L'��', L"d"),
	CTKanaRomaPair (L'��', L"t"),	CTKanaRomaPair (L'��', L"d"),	CTKanaRomaPair (L'��', L"t"),	CTKanaRomaPair (L'��', L"t"),
	CTKanaRomaPair (L'��', L"d"),	CTKanaRomaPair (L'��', L"t"),	CTKanaRomaPair (L'��', L"d"),	CTKanaRomaPair (L'��', L"t"),
	CTKanaRomaPair (L'��', L"d"),	CTKanaRomaPair (L'��', L"n"),	CTKanaRomaPair (L'��', L"n"),	CTKanaRomaPair (L'��', L"n"),
	CTKanaRomaPair (L'��', L"n"),	CTKanaRomaPair (L'��', L"n"),	CTKanaRomaPair (L'��', L"h"),	CTKanaRomaPair (L'��', L"b"),

	CTKanaRomaPair (L'��', L"p"),	CTKanaRomaPair (L'��', L"h"),	CTKanaRomaPair (L'��', L"b"),	CTKanaRomaPair (L'��', L"p"),
	CTKanaRomaPair (L'��', L"h"),	CTKanaRomaPair (L'��', L"b"),	CTKanaRomaPair (L'��', L"p"),	CTKanaRomaPair (L'��', L"h"),
	CTKanaRomaPair (L'��', L"b"),	CTKanaRomaPair (L'��', L"p"),	CTKanaRomaPair (L'��', L"h"),	CTKanaRomaPair (L'��', L"b"),
	CTKanaRomaPair (L'��', L"p"),	CTKanaRomaPair (L'��', L"m"),	CTKanaRomaPair (L'��', L"m"),	CTKanaRomaPair (L'��', L"m"),
	CTKanaRomaPair (L'��', L"m"),	CTKanaRomaPair (L'��', L"m"),	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"y"),
	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"y"),	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"y"),
	CTKanaRomaPair (L'��', L"r"),	CTKanaRomaPair (L'��', L"r"),	CTKanaRomaPair (L'��', L"r"),	CTKanaRomaPair (L'��', L"r"),
	CTKanaRomaPair (L'��', L"r"),	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"w"),	CTKanaRomaPair (L'��', L"x"),
	CTKanaRomaPair (L'��', L"x"),	CTKanaRomaPair (L'��', L"w"),	CTKanaRomaPair (L'��', L"n"),
} ;

CImeConfig::~CImeConfig ()
{
	_vUninit () ;
	return ;
}

CImeConfig*
CImeConfig::pCreateInstance ()
{
	return	new CImeConfig () ;
}

BOOL
CImeConfig::bTSFKeyDownEatenDoesNotWorkp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bTSFKeyDownEatenDoesNotWorkp () : FALSE ;
}

BOOL
CImeConfig::bKanaModeWhenOpenp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bKanaModeWhenOpenp () : TRUE ;
}

CSkkRuleTreeNode*
CImeConfig::pGetSkkRuleTree (CImeConfig* pThis, int iRule)
{
	return	(pThis != NULL)? pThis->_pGetSkkRuleTree (iRule) : NULL ;
}

BOOL
CImeConfig::bSkkKakuteiEarlyp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkKakuteiEarlyp () : FALSE ;
}

BOOL
CImeConfig::bSkkProcessOkuriEarlyp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkProcessOkuriEarlyp () : FALSE ;
}

BOOL
CImeConfig::bSkkEchop (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkEchop () : TRUE ;
}

BOOL
CImeConfig::bSkkTryCompletionCharp (CImeConfig* pThis, int nCH) 
{
	return	pThis != NULL? pThis->_bSkkTryCompletionCharp (nCH) : (nCH == '\t') ;
}

BOOL
CImeConfig::bSkkPreviousCompletionCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkPreviousCompletionCharp (nCH) : (nCH == ',') ;
}

BOOL
CImeConfig::bSkkNextCompletionCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkNextCompletionCharp (nCH) : (nCH == '.') ;
}

BOOL
CImeConfig::bSkkAutoStartHenkanp (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkAutoStartHenkanp () : TRUE ;
}

BOOL
CImeConfig::bSkkAutoStartHenkanKeywordp (CImeConfig* pThis, LPCDSTR pwString, int iStringLength)
{
	return	pThis != NULL? pThis->_bSkkAutoStartHenkanKeywordp (pwString, iStringLength) : FALSE ;
}

BOOL
CImeConfig::bSkkSpecialMidashiCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkSpecialMidashiCharp (nCH) : FALSE ;
}

BOOL
CImeConfig::bSkkSetHenkanPointKeyp (CImeConfig* pThis, int nCH) 
{
	return	pThis != NULL? pThis->_bSkkSetHenkanPointKeyp (nCH) : FALSE ;
}

void
CImeConfig::vMaskSkkSetHenkanPointKey (CImeConfig* pThis, BOOL bMask)
{
	if (pThis != NULL) 
		pThis->_vMaskSkkSetHenkanPointKey (bMask) ;
}

BOOL
CImeConfig::bSkkSetHenkanPointKeyMaskedp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkSetHenkanPointKeyMaskedp () : FALSE ;
}

BOOL
CImeConfig::bSkkStartHenkanCharp (CImeConfig* pThis, int nCH)
{
	return	pThis != NULL? pThis->_bSkkStartHenkanCharp (nCH) : (nCH == ' ') ;
}

int
CImeConfig::iSkkARefSkkKanaRomVector (
	CImeConfig*				pThis, 
	int						nCH, 
	LPDSTR					pOkuri,
	int						nOkuri)
{
	return	pThis != NULL? pThis->_iSkkARefSkkKanaRomVector (nCH, pOkuri, nOkuri) : 0 ;
}

int
CImeConfig::iGetSkkShowAnnotationType (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_iGetSkkShowAnnotationType () : SHOW_NO_ANNOTATION ;
}

BOOL
CImeConfig::bSkkEggLikeNewline (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkEggLikeNewline () : FALSE ;
}

BOOL
CImeConfig::bSkkDeleteOkuriWhenQuit (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkDeleteOkuriWhenQuit () : FALSE ;
}

BOOL
CImeConfig::bSkkDeleteImplesKakuteip (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkDeleteImplesKakuteip () : TRUE ;
}

LPCDSTR
CImeConfig::pGetSkkHenkanShowCandidatesKeys (CImeConfig* pThis, int* pnKeys)
{
	if (pThis != NULL)
		return	pThis->_pGetSkkHenkanShowCandidatesKeys (pnKeys) ;

	if (pnKeys != NULL)
		*pnKeys	= 0 ;
	return	&c_Zero ;
}

BOOL
CImeConfig::bSkkNumericConversionp (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkNumericConversionp () : TRUE ;
}

BOOL
CImeConfig::bSkkNumConvertFloatp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkNumConvertFloatp () : FALSE ;
}

BOOL
CImeConfig::bSkkCompCirculatep (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkCompCirculatep () : FALSE ;
}
	
int
CImeConfig::iGetSkkKcodeCharset (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_iGetSkkKcodeCharset () : KCODE_CHARSET_JAPANESE_JISX0208 ;
}

LPCDSTR
CImeConfig::pGetSkkInputByCodeMenuKeys1 (CImeConfig* pThis, int* pnKeys)
{
	if (pThis != NULL)
		return	pThis->_pGetSkkInputByCodeMenuKeys1 (pnKeys) ;

	if (pnKeys != NULL)
		*pnKeys	= 0 ;
	return	&c_Zero ;
}

LPCDSTR
CImeConfig::pGetSkkInputByCodeMenuKeys2 (CImeConfig* pThis, int* pnKeys)
{
	if (pThis != NULL)
		return	pThis->_pGetSkkInputByCodeMenuKeys2 (pnKeys) ;

	if (pnKeys != NULL)
		*pnKeys	= 0 ;
	return	&c_Zero ;
}

int
CImeConfig::iGetSkkOkuriChar (
	CImeConfig*		pThis, 
	LPCDSTR			pwSrc,
	int				iSrcLength,
	LPDSTR			pwDest,
	int				iDestLength)
{
	if (pThis != NULL)
		return	pThis->_iGetSkkOkuriChar (pwSrc, iSrcLength, pwDest, iDestLength) ;
	return	0 ;
}

BOOL
CImeConfig::bSkkHenkanOkuriStrictlyp (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkHenkanOkuriStrictlyp () : FALSE ;
}

BOOL
CImeConfig::bSkkHenkanStrictOkuriPrecedencep (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkHenkanStrictOkuriPrecedencep () : FALSE ;
}

BOOL
CImeConfig::bSkkAutoOkuriProcessp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkAutoOkuriProcessp () : FALSE ;
}

int
CImeConfig::iSkkARefSkkJisx0208LatinVector (
	CImeConfig*				pThis, 
	int						nCH, 
	LPDSTR					pResult,
	int						nResultSize) 
{
	return	pThis != NULL? pThis->_iSkkARefSkkJisx0208LatinVector (nCH, pResult, nResultSize) : -1 ;
}

int
CImeConfig::iSkkRevRefSkkJisx0208LatinVector (
	CImeConfig*				pThis, 
	int						nCH, 
	LPDSTR					pResult,
	int						nResultSize)
{
	return	pThis != NULL? pThis->_iSkkRevRefSkkJisx0208LatinVector (nCH, pResult, nResultSize) : -1 ;
}

BOOL
CImeConfig::bSkkAutoInsertParen (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkAutoInsertParen () : TRUE ;
}

int
CImeConfig::iSkkAssocSkkAutoParenStringAlist (
	CImeConfig*				pThis, 
	LPCDSTR					pwString,
	int						nStringLen,
	LPDSTR					pwResult,
	int						nResultSize)
{
	return	pThis != NULL? pThis->_iSkkAssocSkkAutoParenStringAlist (pwString, nStringLen, pwResult, nResultSize) : -1 ;
}

BOOL
CImeConfig::bSkkAllowsSpacesNewlinesAndTabs (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkAllowsSpacesNewlinesAndTabs () : FALSE ;
}

LPCDSTR
CImeConfig::pGetCurrentTouten (
	CImeConfig*						pThis, 
	int								iKutoutenType,
	int*							pnLength) 
{
	if (pThis != NULL)
		return	pThis->_pGetCurrentTouten (iKutoutenType, pnLength) ;

	if (pnLength != NULL)
		*pnLength	= 1 ;
	return	c_Period ;
}

LPCDSTR
CImeConfig::pGetCurrentKuten (
	CImeConfig*						pThis, 
	int								iKutenType,
	int*							pnLength) 
{
	if (pThis != NULL)
		return	pThis->_pGetCurrentKuten (iKutenType, pnLength) ;

	if (pnLength != NULL)
		*pnLength	= 1 ;
	return	c_Comma ;
}

int
CImeConfig::iGetNumberOfKutotens (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_iGetNumberOfKutotens () : 1 ;
}

BOOL
CImeConfig::bSkkIsNewlineKakuteiAllp (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_bSkkIsNewlineKakuteiAllp () : TRUE ;
}

BOOL
CImeConfig::bSkkCompositionAutoShiftp (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_bSkkCompositionAutoShiftp () : TRUE ;
}

const struct CImeKeymap*
CImeConfig::pGetMajorModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetMajorModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkJModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkJModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkLatinModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkLatinModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkJisx0208LatinModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkJisx0208LatinModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetSkkAbbrevModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetSkkAbbrevModeMap () : NULL ;
}

const struct CImeKeymap*
CImeConfig::pGetMinibufferMinorModeMap (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_pGetMinibufferMinorModeMap () : NULL ;
}

const struct MYCOLORFACESET*
CImeConfig::pGetColorFaceSet (CImeConfig* pThis) 
{
	return	pThis != NULL? pThis->_pGetColorFaceSet () : NULL ;
}

int
CImeConfig::iGetCountHenkanShowChange (CImeConfig* pThis)
{
	return	pThis != NULL? pThis->_iGetCountHenkanShowChange () : 3 ;
}

HFONT
CImeConfig::hGetDefaultFont (CImeConfig* pThis, HDC hDC)
{
	return	pThis != NULL? pThis->_hGetDefaultFont (hDC) : NULL ;
}

/*========================================================================
 */
ULONG
CImeConfig::AddRef (void)
{
	return	++ m_cRef ;
}

ULONG
CImeConfig::Release (void)
{
	ULONG	cRef	= -- m_cRef ;

	if (m_cRef == 0) {
		delete	this ;
	}
	return	cRef ;
}

void
CImeConfig::vUpdate ()
{
	HKEY	hSubKey ;
	DWORD	cbData, dwType, dwTick ;
	BOOL	bUpdate ;
	LONG	lResult ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
		bUpdate	= ! m_bHaveSyncTick ;
		dwTick	= 0 ;
	} else {
		bUpdate	= FALSE ;
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bUpdate	= ! m_bHaveSyncTick || (m_dwSyncTick != dwTick) ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! bUpdate)
		return ;

	_vUninit () ;
	_vInit () ;
	m_bHaveSyncTick	= TRUE ;
	m_dwSyncTick	= dwTick ;
	return ;
}

/*========================================================================
 */
CImeConfig::CImeConfig ()
{
	int		i ;

	m_iRomaKanaRuleListType			= KEYBINDTP_DEFAULT ;
	m_iKeybindType					= KEYBINDTP_DEFAULT ;
	m_iStartHenkanKeyType			= KEYBINDTP_DEFAULT ;
	m_iCompletionRelatedKeyType		= KEYBINDTP_DEFAULT ;
	m_iSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
	m_iSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;

	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		m_rpSkkRuleTree	[i]					= NULL ;
		m_rpSkkJisx0201RomanRuleTree [i]	= NULL ;
		m_rpSkkJisx0201RuleTree [i]			= NULL ;
	}
	for (i = 0 ; i < MYARRAYSIZE (m_rstrJisx0208LatinVector) ; i ++) 
		m_rstrJisx0208LatinVector [i]	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (m_MajorModeMap.m_rbyBaseMap) ; i ++) {
		m_MajorModeMap.m_rbyBaseMap [i]				= NFUNC_INVALID_CHAR ;
		m_SkkJModeMap.m_rbyBaseMap [i]				= NFUNC_INVALID_CHAR ;
		m_SkkLatinModeMap.m_rbyBaseMap [i]			= NFUNC_INVALID_CHAR ;
		m_SkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
		m_SkkAbbrevModeMap.m_rbyBaseMap [i]			= NFUNC_INVALID_CHAR ;
		m_MinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	m_MajorModeMap.m_pKeyBinds		= m_SkkJModeMap.m_pKeyBinds				= NULL ;
	m_MajorModeMap.m_nKeyBinds		= m_SkkJModeMap.m_nKeyBinds				= 0 ;
	m_SkkLatinModeMap.m_pKeyBinds	= m_SkkJisx0208LatinModeMap.m_pKeyBinds	= NULL ;
	m_SkkLatinModeMap.m_nKeyBinds	= m_SkkJisx0208LatinModeMap.m_nKeyBinds	= 0 ;
	m_SkkAbbrevModeMap.m_pKeyBinds	= m_MinibufferMinorModeMap.m_pKeyBinds	= NULL ;
	m_SkkAbbrevModeMap.m_nKeyBinds	= m_MinibufferMinorModeMap.m_nKeyBinds	= 0 ;

	m_StartHenkanKeys.m_iKeys			= 0 ;
	m_TryCompletionKeys.m_iKeys			= 0 ;
	m_PreviousCompletionKeys.m_iKeys	= 0 ;
	m_NextCompletionKeys.m_iKeys		= 0 ;
	m_SetHenkanPointSubrKeys.m_iKeys	= 0 ;
	m_SpecialMidashiCharKeys.m_iKeys	= 0 ;
	m_bMaskSkkSetHenkanPointKey			= FALSE ;

	m_bEggLikeNewline				= FALSE ;
	m_bNewlineKakuteiAll			= TRUE ;
	m_bKanaModeWhenOpen				= TRUE ;
	m_bEcho							= TRUE ;
	m_bAutoInsertParen				= TRUE ;
	m_bCompositionAutoShift			= TRUE ;
	m_bDeleteImpliesKakutei			= TRUE ;
	m_bKakuteiEarly					= FALSE ;
	m_bDateAd						= FALSE ;
	m_iNumberStyle					= 0 ;

	m_iKutoutenType					= KUTOUTEN_TYPE_JP ;
	m_Kutouten.m_iCount				= 0 ;
	m_BracketParen.m_iCount			= 0 ;
	m_OkuriCharAlist.m_iCount		= 0 ;
	m_iBracketParenType				= BRACKETPARENTP_DEFAULT ;
	m_iOkuriCharAlistType			= OKURICHARTP_DEFAULT ;

	m_nCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;
	m_nNumShowCandidateKeys			= 0 ;
	m_nNumInputCodeMenu1Keys		= 0 ;
	m_nNumInputCodeMenu2Keys		= 0 ;
	m_nNumShowCandidateKeys			= 0 ;
	for (i = 0 ; i < MAX_NUMMENUKEYS ; i ++) {
		m_rwchShowCandidateKeys [i]		= 0 ;
		m_rwchInputCodeMenu1Keys [i]	= 0 ;
		m_rwchInputCodeMenu2Keys [i]	= 0 ;
	}
	m_nShowCandListCount			= SHOWCANDLIST_COUNT_ZERO + 3 ;

	m_bHenkanOkuriStrictly			= FALSE ;
	m_bProcessOkuriEarly			= FALSE ;
	m_bHenkanStrictOkuriPrecedence	= FALSE ;
	m_bAutoOkuriProcess				= FALSE ;
	m_bAutoStartHenkan				= TRUE ;
	m_bDeleteOkuriWhenQuit			= FALSE ;

	m_bNumericConversion			= TRUE ;
	m_bNumericFloat					= FALSE ;

	m_nShowAnnotationType			= SHOW_NO_ANNOTATION ;

	m_iNumAutoStartHenkanKeywords	= 0 ;
	m_pAutoStartHenkanKeywords		= NULL ;

	m_bAllowsSpacesNewlinesAndTabs	= FALSE ;
	m_iKanjiCodeCharset				= KCODE_CHARSET_JAPANESE_JISX0208 ;
	m_bCompCirculate				= FALSE ;

	memset (&m_lfDefault, 0, sizeof (LOGFONT)) ;
	m_iDefaultFontSize				= 0 ;
	m_hDefaultFont					= NULL ;

	m_bTSFKeyDownEatenDoesNotWork	= TRUE ;

	m_bHaveSyncTick					= FALSE ;
	m_dwSyncTick					= 0 ;

	/*	Reference Count
	 */
	m_cRef							= 1 ;
	return ;
}

/*
 */
BOOL
CImeConfig::_bTSFKeyDownEatenDoesNotWorkp () const
{
	return	m_bTSFKeyDownEatenDoesNotWork ;
}

BOOL
CImeConfig::_bKanaModeWhenOpenp () const
{
	return	m_bKanaModeWhenOpen ;
}

CSkkRuleTreeNode*
CImeConfig::_pGetSkkRuleTree (int iRule)
{
	if (RULETREENO_SKK_BASE <= iRule && iRule < (RULETREENO_SKK_BASE + NUM_ROMAKANARULE))
		return	m_rpSkkRuleTree [iRule - RULETREENO_SKK_BASE] ;
	if (RULETREENO_SKK_JISX0201_ROMAN <= iRule && iRule < (RULETREENO_SKK_JISX0201_ROMAN + NUM_ROMAKANARULE))
		return	m_rpSkkJisx0201RomanRuleTree [iRule - RULETREENO_SKK_JISX0201_ROMAN] ;
	if (RULETREENO_SKK_JISX0201_BASE <= iRule && iRule < (RULETREENO_SKK_JISX0201_BASE + NUM_ROMAKANARULE))
		return	m_rpSkkJisx0201RuleTree [iRule - RULETREENO_SKK_JISX0201_BASE] ;
	return	NULL ;
}

BOOL
CImeConfig::_bSkkKakuteiEarlyp () const
{
	DEBUGPRINTF ((TEXT ("CImeConfig::_bSkkKakuteiEarlyp (this:%p) return %d\n"), this, m_bKakuteiEarly)) ;
	return	m_bKakuteiEarly ;
}

BOOL
CImeConfig::_bSkkProcessOkuriEarlyp ()  const
{
	return	m_bProcessOkuriEarly ;
}

BOOL
CImeConfig::_bSkkEchop () const
{
	return	m_bEcho ;
}

BOOL
CImeConfig::_bSkkTryCompletionCharp (int nCH) const
{
	if (m_iCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'\t')? TRUE : FALSE ;
	} else {
		return	(memchr (m_TryCompletionKeys.m_rbKeys, nCH, m_TryCompletionKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
CImeConfig::_bSkkPreviousCompletionCharp (int nCH) const
{
	if (m_iCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'.')? TRUE : FALSE ;
	} else {
		return	(memchr (m_PreviousCompletionKeys.m_rbKeys, nCH, m_PreviousCompletionKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
CImeConfig::_bSkkNextCompletionCharp (int nCH) const
{
	if (m_iCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L',')? TRUE : FALSE ;
	} else {
		return	(memchr (m_NextCompletionKeys.m_rbKeys, nCH, m_NextCompletionKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
CImeConfig::_bSkkAutoStartHenkanp () const
{
	return	m_bAutoStartHenkan ;	//FALSE
}

BOOL
CImeConfig::_bSkkAutoStartHenkanKeywordp (
	LPCDSTR						pwString,
	int							nStringLength) const
{
	/*	�����ϊ��X�^�[�g�L�[���[�h�Ƃ����̂��������̂�Y��Ă����c�B����̓J�X�^�}�C�Y���ڂ��B
	static	LPCDSTR		_rstrSkkAutoStartHenkanKeywords []	= {
		L"��", L"�A", L"�B", L"�D", L"�C", L"�H", L"�v",  L"�I", L"�G", L"�F", L")", L";", L":",
		L"�j", L"�h", L"�z", L"�x", L"�t", L"�r", L"�p",  L"�n", L"�l", L"}",  L"]", L"?", L".",
		L",",  L"!",
	} ;
	 */
	LPCDSTR		pKeywords ;
	int			i ;

	if (pwString == NULL || nStringLength <= 0)
		return	FALSE ;
	if (m_pAutoStartHenkanKeywords == NULL)
		return	FALSE ;
	pKeywords	= m_pAutoStartHenkanKeywords ;
	for (i = 0 ; i < m_iNumAutoStartHenkanKeywords && *pKeywords != L'\0' ; i ++) {
		if (! dcsncmp (pKeywords, pwString, nStringLength) && pKeywords [nStringLength] == L'\0')
			return	TRUE ;
		pKeywords	+= dcslen (pKeywords) + 1 ;
	}
	return	FALSE ;
}

BOOL
CImeConfig::_bSkkSpecialMidashiCharp (int nCH) const
{
	if (m_iSpecialMidashiCharKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'?' || nCH == L'>' || nCH == L'<')? TRUE : FALSE ;
	} else {
		int		i ;
		for (i = 0 ; i < m_SpecialMidashiCharKeys.m_iKeys && i < MYARRAYSIZE (m_SpecialMidashiCharKeys.m_rbKeys) ; i ++) {
			if (m_SpecialMidashiCharKeys.m_rbKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
CImeConfig::_bSkkSetHenkanPointKeyp (int nCH)  const
{
	/*	Mask ����Ă�����A��� FALSE ��Ԃ��B
	 */
	if (m_bMaskSkkSetHenkanPointKey) {
		return	FALSE ;
	}
	if (m_iSetHenkanPointSubrKeyType == KEYBINDTP_DEFAULT) {
		/* (?A ?B ?C ?D ?E ?F ?G ?H ?I ?J ?K ?M ?N ?O ?P ?R ?S ?T ?U ?V ?W ?Y ?Z) */
		return	(L'A' <= nCH && nCH <= L'Z' && nCH != L'L' && nCH != L'Q' && nCH != L'X')? TRUE : FALSE ;
	} else {
		int	i ;
		for (i = 0 ; i < m_SetHenkanPointSubrKeys.m_iKeys && i < MYARRAYSIZE (m_SetHenkanPointSubrKeys.m_rbKeys) ; i ++) {
			if (m_SetHenkanPointSubrKeys.m_rbKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
CImeConfig::_bSkkSetHenkanPointKeyMaskedp () const
{
	return	m_bMaskSkkSetHenkanPointKey ;
}

void
CImeConfig::_vMaskSkkSetHenkanPointKey (BOOL bMask)
{
	m_bMaskSkkSetHenkanPointKey	= bMask ;
	return ;
}

BOOL
CImeConfig::_bSkkStartHenkanCharp (
	int						nCH) const
{
	/* ���[�ށA����͂ǂ�����ׂ����B��͂� j-mode-map �Ń`�F�b�N���B
	 *	... space �� skk-insert �Ȃ̂��B����� skk-insert ������ start-henkan ���ƌ������߂ɂ���̂��c
	 *	����͂܂����ȁBkeyfunc �����|���� skk-insert �����ǁc�ɂ��Ȃ��Ƃ��߂��B
	 *	����̓L�[�̒ǉ��̂Ƃ���Őݒ肳���邵���Ȃ��ȁB
	 */
	if (m_iStartHenkanKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L' ')? TRUE : FALSE ;
	} else {
		return	(memchr (m_StartHenkanKeys.m_rbKeys, nCH, m_StartHenkanKeys.m_iKeys) != NULL)? TRUE : FALSE ;
	}
}

int
CImeConfig::_iSkkARefSkkKanaRomVector (
	int						nCH, 
	LPDSTR					pOkuri,
	int						nOkuri) const
{
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (m_rSkkKanaRomVector) ; i ++) {
		if (nCH == m_rSkkKanaRomVector [i].m_nKana) {
			int		n ;

			n	= lstrlenW (m_rSkkKanaRomVector [i].m_wstrRom) ;
			if (n > 0) {
				n	= wcstodcs (pOkuri, nOkuri, m_rSkkKanaRomVector [i].m_wstrRom, n) ;
			}
			return	n ;
		}
	}
	return	0 ;
}

int
CImeConfig::_iGetSkkShowAnnotationType () const
{
	return	m_nShowAnnotationType ;
}

BOOL
CImeConfig::_bSkkEggLikeNewline ()  const
{
	return	m_bEggLikeNewline ;
}

BOOL
CImeConfig::_bSkkDeleteOkuriWhenQuit () const
{
	return	m_bDeleteOkuriWhenQuit ;
}

BOOL
CImeConfig::_bSkkDeleteImplesKakuteip ()  const
{
	return	m_bDeleteImpliesKakutei ;
}

LPCDSTR
CImeConfig::_pGetSkkHenkanShowCandidatesKeys (int* pnKeys) const
{
	if (pnKeys != NULL)
		*pnKeys	= m_nNumShowCandidateKeys ;
	return	m_rwchShowCandidateKeys ;
}

BOOL
CImeConfig::_bSkkNumericConversionp () const
{
	return	m_bNumericConversion ;
}

BOOL
CImeConfig::_bSkkNumConvertFloatp () const
{
	return	m_bNumericFloat ;
}

BOOL
CImeConfig::_bSkkCompCirculatep () const
{
	return	m_bCompCirculate ;
}

int
CImeConfig::_iGetSkkKcodeCharset () const
{
	return	m_iKanjiCodeCharset ;
}

LPCDSTR
CImeConfig::_pGetSkkInputByCodeMenuKeys1 (int* pnKeys) const
{
	if (pnKeys != NULL) {
		*pnKeys	= m_nNumInputCodeMenu1Keys ;
	}
	return	m_rwchInputCodeMenu1Keys ;
}

LPCDSTR
CImeConfig::_pGetSkkInputByCodeMenuKeys2 (int* pnKeys) const
{
	if (pnKeys != NULL) {
		*pnKeys	= m_nNumInputCodeMenu2Keys ;
	}
	return	m_rwchInputCodeMenu2Keys ;
}

int
CImeConfig::_iGetSkkOkuriChar (
	LPCDSTR					pwOkuriChar,
	int						nOkuriCharLen,
	LPDSTR					pwDest,
	int						nDestSize) const
{
	int		i, nLen ;

	if (m_iOkuriCharAlistType != OKURICHARTP_USERDEFINED)
		return	0 ;

	for (i = 0 ; i < m_OkuriCharAlist.m_iCount ; i ++) {
		if (dcsncmp (pwOkuriChar, m_OkuriCharAlist.m_rStringPair [i].m_bufLeft, nOkuriCharLen) == 0 &&
			m_OkuriCharAlist.m_rStringPair [i].m_bufLeft [nOkuriCharLen] == L'\0') {
			/*	hit */
			nLen	= MIN (nDestSize, (int) dcslen (m_OkuriCharAlist.m_rStringPair  [i].m_bufRight)) ;

			dcsncpy (pwDest, m_OkuriCharAlist.m_rStringPair [i].m_bufRight, nLen) ;
			return	nLen ;
		}
	}
	return	0 ;
}

BOOL
CImeConfig::_bSkkHenkanOkuriStrictlyp () const
{
	return	m_bHenkanOkuriStrictly ;
}

BOOL
CImeConfig::_bSkkHenkanStrictOkuriPrecedencep () const
{
	return	m_bHenkanStrictOkuriPrecedence ;
}

/*	auto-okuri-process �𗘗p����̂́Askkiserv ���ł���Ǝv���邪�A�ꉞ���̋L�q�͓���Ă����B
 */
BOOL
CImeConfig::_bSkkAutoOkuriProcessp () const
{
	return	m_bAutoOkuriProcess ;
}

int
CImeConfig::_iSkkARefSkkJisx0208LatinVector (
	int						nCH, 
	LPDSTR					pResult,
	int						nResultSize) const
{
	if (0 <= nCH && nCH < MYARRAYSIZE (m_rstrJisx0208LatinVector) &&
		m_rstrJisx0208LatinVector [nCH] != NULL) {
		int		n ;
		n	= dcslen (m_rstrJisx0208LatinVector [nCH]) ;
		n	= (n > nResultSize)? nResultSize : n ;
		if (n > 0) {
			dcsncpy (pResult, m_rstrJisx0208LatinVector [nCH], n) ;
		}
		return	n ;
	}
	return	-1 ;	/* not hit */
}

/*	�t�����B
 */
int
CImeConfig::_iSkkRevRefSkkJisx0208LatinVector (
	int						nCH, 
	LPDSTR					pResult,
	int						nResultSize) const
{
	int		i ;

	for (i = 0 ; i < sizeof (m_rstrJisx0208LatinVector) / sizeof (m_rstrJisx0208LatinVector [0]) ; i ++) {
		if (m_rstrJisx0208LatinVector [i] != NULL && 
			*(m_rstrJisx0208LatinVector [i] + 0) == nCH &&
			*(m_rstrJisx0208LatinVector [i] + 1) == L'\0') {
			if (nResultSize > 0)
				*pResult	= i ;
			return	1 ;
		}
	}
	return	-1 ;	/* not hit */
}

BOOL
CImeConfig::_bSkkAutoInsertParen () const
{
	return	m_bAutoInsertParen ;
}

int
CImeConfig::_iSkkAssocSkkAutoParenStringAlist (
	LPCDSTR					pwString,
	int						nStringLen,
	LPDSTR					pwResult,
	int						nResultSize) const
{
	int		i ;

	for (i = 0 ; i < m_BracketParen.m_iCount ; i ++) {
		if (! dcsncmp (pwString, m_BracketParen.m_rStringPair [i].m_bufLeft, nStringLen) && 
			m_BracketParen.m_rStringPair [i].m_bufLeft [nStringLen]	== L'\0') {
			int		n ;
			n	= dcslen (m_BracketParen.m_rStringPair [i].m_bufRight) ;
			n	= (n > nResultSize)? nResultSize : n ;
			if (n > 0) {
				dcsncpy (pwResult, m_BracketParen.m_rStringPair [i].m_bufRight, n) ;
			}
			return	n ;
		}
	}
	return	-1 ;	/* not hit */
}

/*	���̐ݒ�͍��̂Ƃ���J�X�^�}�C�Y�ł��Ȃ��B��� FALSE �ɂ��Ă������A����ł����̂��c�H
 */
BOOL
CImeConfig::_bSkkAllowsSpacesNewlinesAndTabs	() const
{
	return	m_bAllowsSpacesNewlinesAndTabs ;
}

LPCDSTR
CImeConfig::_pGetCurrentTouten (
	int								iKutoutenType,
	int*							pnLength) const
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % m_Kutouten.m_iCount ;
	if (pnLength != NULL)
		*pnLength	= dcslen (m_Kutouten.m_rStringPair [nIndex].m_bufLeft) ;
	return	m_Kutouten.m_rStringPair [nIndex].m_bufLeft ;
}

LPCDSTR
CImeConfig::_pGetCurrentKuten (
	int								iKutoutenType,
	int*							pnLength) const
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % m_Kutouten.m_iCount ;
	if (pnLength != NULL)
		*pnLength	= dcslen (m_Kutouten.m_rStringPair [nIndex].m_bufRight) ;
	return	m_Kutouten.m_rStringPair [nIndex].m_bufRight ;
}

int
CImeConfig::_iGetNumberOfKutotens () const
{
	return	m_Kutouten.m_iCount ;
}

/*	Newline -> Kakutei �̌�Apoint-marker �� buffer �̍Ō�ֈړ������邩�ۂ��B
 *	shift-count �̐�����A���ꂪ TRUE ���ƁuComposition �̑S�m��v�Ɍ�����B
 */
BOOL
CImeConfig::_bSkkIsNewlineKakuteiAllp () const
{
	return	m_bNewlineKakuteiAll ;
}

/*	�����I�� CompositionString ���m��ς݂Ƃ��đ����邩�ǂ��������肷��B
 *	��{�I�Ɂu�o�b�t�@�̐擪�v����upoint-marker�̈ʒu�v�u�ϊ��J�n�ʒu�v
 *	�u�����J�n�ʒu�v�̒��ōŏ��̈ʒu�܂ŃV�t�g�����B
 */
BOOL
CImeConfig::_bSkkCompositionAutoShiftp () const
{
	return	m_bCompositionAutoShift ;
}

const struct CImeKeymap*
CImeConfig::_pGetMajorModeMap ()  const
{
	return	&m_MajorModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkJModeMap () const
{
	return	&m_SkkJModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkLatinModeMap () const
{
	return	&m_SkkLatinModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkJisx0208LatinModeMap () const
{
	return	&m_SkkJisx0208LatinModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetSkkAbbrevModeMap () const
{
	return	&m_SkkAbbrevModeMap ;
}

const struct CImeKeymap*
CImeConfig::_pGetMinibufferMinorModeMap () const
{
	return	&m_MinibufferMinorModeMap ;
}

const MYCOLORFACESET*
CImeConfig::_pGetColorFaceSet () const
{
	return	m_rImeColorFaces ;
}

int
CImeConfig::_iGetCountHenkanShowChange () const
{
	return	m_nShowCandListCount ;
}

HFONT
CImeConfig::_hGetDefaultFont (HDC hdc)
{
	int	lfHeight ;

	lfHeight	= (m_iDefaultFontSize < 0)? m_iDefaultFontSize : -MulDiv (m_iDefaultFontSize, GetDeviceCaps(hdc, LOGPIXELSY), 72) ;
	if (m_hDefaultFont == NULL || m_lfDefault.lfHeight != lfHeight) {
		m_lfDefault.lfHeight	= lfHeight ;
		m_lfDefault.lfWidth		= 0 ;
		if (m_hDefaultFont != NULL) 
			DeleteObject (m_hDefaultFont) ;
		m_hDefaultFont	= CreateFontIndirect (&m_lfDefault) ;
	}
	return	(m_hDefaultFont == NULL)? (HFONT)GetStockObject (DEFAULT_GUI_FONT) : m_hDefaultFont ;
}

/*========================================================================
 *	private functions (for ZenkakuVector)
 */
void
CImeConfig::_vInit ()
{
	HKEY	hSubKey ;
	DWORD	dwTick		= 0 ;
	BOOL	bHaveTick	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData ;
		LONG	lResult ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bHaveTick	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}
	_bLoadZenkakuVector () ;
	_bLoadRomaKanaRuleList () ;
	_bLoadKeymaps () ;
	_bLoadGenericSetting () ;
	_bLoadConversionSetting () ;
	_bLoadColorfaceSetting () ;
	_vInitializeDefaultFont () ;

	m_bHaveSyncTick	= bHaveTick ;
	m_dwSyncTick	= dwTick ;
	return ;
}

void
CImeConfig::_vUninit ()
{
	_vClearZenkakuVector () ;
	_vClearRomaKanaRuleList () ;
	_vClearKeymaps () ;

	delete[]	m_pAutoStartHenkanKeywords ;
	m_pAutoStartHenkanKeywords	= NULL ;

	if (m_hDefaultFont != NULL) {
		DeleteObject (m_hDefaultFont) ;
		m_hDefaultFont	= NULL ;
	}
	memset (&m_lfDefault, 0, sizeof (LOGFONT)) ;
	m_iDefaultFontSize	= 0 ;

	m_bHaveSyncTick	= FALSE ;
	m_dwSyncTick		= 0 ;
	return ;
}

BOOL
CImeConfig::_bLoadZenkakuVector ()
{
	HKEY	hSubKey ;
	int		i ;
	BOOL	bInitialized	= FALSE ;

	_vClearZenkakuVector () ;

	/*	���W�X�g���ɃL�[�����݂��Ȃ���΁A�f�t�H���g��ݒ肷��B
	 */
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 	lResult ;
		DWORD	dwType, cbData ;
		LPWSTR	pwData ;
		LPCWSTR	pwSrc ;

		lResult	= RegQueryValueExW (hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) 
			goto	skip_error ;
		if (dwType != REG_MULTI_SZ) 
			goto	skip_error ;

		pwData	= (LPWSTR) new WCHAR [cbData] ;
		if (pwData == NULL)
			goto	skip_error ;

		(void) RegQueryValueExW (hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, (BYTE*)pwData, &cbData) ;

		pwSrc	= pwData ;
		while (*pwSrc != TEXT ('\0')) {
			LPCWSTR	pwBase ;
			int		nChara, nCH, nNeed ;

			/*	�ŏ���3�������L�����N�^�[�R�[�h���A
			 *	���������񂪂��̃R�[�h�œ��͂���镶����A
			 */
			nCH		= *pwSrc ++ ;
			if (nCH < TEXT ('0') || nCH > TEXT ('9'))
				goto	skip_error ;
			nChara	= nCH - TEXT ('0') ;

			nCH		= *pwSrc ++ ;
			if (nCH < TEXT ('0') || nCH > TEXT ('9'))
				goto	skip_error ;
			nChara	= nChara * 10 + (nCH - TEXT ('0')) ;

			nCH		= *pwSrc ++ ;
			if (nCH < TEXT ('0') || nCH > TEXT ('9'))
				goto	skip_error ;
			nChara	= nChara * 10 + (nCH - TEXT ('0')) ;
			if (nChara < 0 || nChara >= MYARRAYSIZE (m_rstrJisx0208LatinVector))
				goto	skip_error ;

			pwBase	= pwSrc ;
			while (*pwSrc != TEXT ('\0'))
				pwSrc	++ ;

			if (m_rstrJisx0208LatinVector [nChara] != NULL) {
				delete[]	m_rstrJisx0208LatinVector [nChara] ;
			}

			nNeed	= wcstodcs_n (NULL, 0, pwBase, pwSrc - pwBase) ;
			m_rstrJisx0208LatinVector [nChara]	= (LPDSTR) new DCHAR [nNeed + 1] ;
			if (m_rstrJisx0208LatinVector [nChara] == NULL)
				break ;
			(void) wcstodcs_n (m_rstrJisx0208LatinVector [nChara], nNeed, pwBase, pwSrc - pwBase) ;
			m_rstrJisx0208LatinVector [nChara][nNeed]	= L'\0' ;
			pwSrc	++ ;
		}
		bInitialized	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	if (! bInitialized) {
		for (i = 0 ; i < MYARRAYSIZE (m_rstrJisx0208LatinVector) ; i ++) {
			if (m_rstrDefaultJisx0208LatinVector [i] != NULL) {
				LPCWSTR	pwSrc	= m_rstrDefaultJisx0208LatinVector [i] ;
				LPDSTR	pwDest	= NULL ;
				int		nSrcLen	= lstrlenW (pwSrc) ;
				int		nLength ;

				nLength	= wcstodcs_n (NULL, 0, pwSrc, nSrcLen) ;
				pwDest	= (LPDSTR) new DCHAR [nLength + 1] ;
				if (pwDest != NULL) {
					(void) wcstodcs_n (pwDest, nLength, pwSrc, nSrcLen) ;
					pwDest [nLength]	= L'\0' ;
				}
				m_rstrJisx0208LatinVector [i]	= pwDest ;
			} else {
				m_rstrJisx0208LatinVector [i]	= NULL ;
			}
		}
	}
	return	TRUE ;
}

void
CImeConfig::_vClearZenkakuVector ()
{
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (m_rstrJisx0208LatinVector) ; i ++) {
		if (m_rstrJisx0208LatinVector [i] != NULL) {
			delete[]	m_rstrJisx0208LatinVector [i] ;
			m_rstrJisx0208LatinVector [i]	= NULL ;
		}
	}
	return ;
}

/*========================================================================
 *	private functions (for Keybind)
 */
BOOL
CImeConfig::_bLoadKeymaps ()
{
	HKEY	hSubKey ;
	BOOL	bRetval	= FALSE ;
	BOOL	bExistUserDefinedKeymap					= FALSE ;
	BOOL	bExistUserDefinedStartHenkanKey			= FALSE ;
	BOOL	bExistUserDefinedCompletionKey			= FALSE ;
	BOOL	bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
	BOOL	bExistUserDefinedSpecialMidashiCharKey	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData, dwValue ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_KEYMAP_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		m_iKeybindType	= (int) dwValue ;

		if (_bLoadKeymap (hSubKey, REGINFO_MAJORMODEMAP,	REGINFO_MAJORMODEMAP_EX,	&m_MajorModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_JMODEMAP,		REGINFO_JMODEMAP_EX,		&m_SkkJModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_LATINMODEMAP,	REGINFO_LATINMODEMAP_EX,	&m_SkkLatinModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_ZENKAKUMODEMAP,	REGINFO_ZENKAKUMODEMAP_EX,	&m_SkkJisx0208LatinModeMap))
			bExistUserDefinedKeymap	= TRUE ;
		if (_bLoadKeymap (hSubKey, REGINFO_ABBREVMODEMAP,	REGINFO_ABBREVMODEMAP_EX,	&m_SkkAbbrevModeMap))
			bExistUserDefinedKeymap	= TRUE ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_STARTHENKANKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		m_iStartHenkanKeyType	= (int) dwValue ;
		cbData	= sizeof (m_StartHenkanKeys.m_rbKeys) ;
		if (RegQueryValueExW (hSubKey, REGINFO_STARTHENKANKEY, NULL, &dwType, (BYTE*)m_StartHenkanKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedStartHenkanKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_StartHenkanKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedStartHenkanKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		m_iCompletionRelatedKeyType	= (int) dwValue ;
		if (RegQueryValueExW (hSubKey, REGINFO_TRYCOMPLETIONKEY, NULL, &dwType, (BYTE*)m_TryCompletionKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_TryCompletionKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, NULL, &dwType, (BYTE*)m_PreviousCompletionKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_PreviousCompletionKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueExW (hSubKey, REGINFO_NEXTCOMPLETIONKEY, NULL, &dwType, (BYTE*)m_NextCompletionKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_NextCompletionKeys.m_iKeys	= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		m_iSetHenkanPointSubrKeyType	= (int) dwValue ;
		cbData	= sizeof (m_SetHenkanPointSubrKeys.m_rbKeys) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, NULL, &dwType, (BYTE*)m_SetHenkanPointSubrKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_SetHenkanPointSubrKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		m_iSpecialMidashiCharKeyType	= (int) dwValue ;
		cbData	= sizeof (m_SpecialMidashiCharKeys.m_rbKeys) ;
		if (RegQueryValueExW (hSubKey, REGINFO_SPECIALMIDASHICHAR, NULL, &dwType, (BYTE*)m_SpecialMidashiCharKeys.m_rbKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSpecialMidashiCharKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			m_SpecialMidashiCharKeys.m_iKeys		= (int) cbData ;
			bExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_EGGLIKENEWLINE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			m_bEggLikeNewline	= (dwValue != 0) ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_NEWLINEKAKUTEIALL, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			m_bNewlineKakuteiAll	= (dwValue != 0) ;
		}
		bRetval	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}

	/* �f�[�^���ςłȂ����A�X�̗v�f���`�F�b�N����B*/
	if (bRetval) {
		_vValidateKeymap (&m_MajorModeMap) ;
		_vValidateKeymap (&m_SkkJModeMap) ;
		_vValidateKeymap (&m_SkkLatinModeMap) ;
		_vValidateKeymap (&m_SkkJisx0208LatinModeMap) ;
		_vValidateKeymap (&m_SkkAbbrevModeMap) ;
		if (m_iKeybindType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedKeymap)
			m_iKeybindType	= KEYBINDTP_DEFAULT ;
		if (m_iStartHenkanKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedStartHenkanKey)
			m_iStartHenkanKeyType	= KEYBINDTP_DEFAULT ;
		if (m_iCompletionRelatedKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedCompletionKey)
			m_iCompletionRelatedKeyType	= KEYBINDTP_DEFAULT ;
		if (m_iSetHenkanPointSubrKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSetHenkanPointSubrKey) 
			m_iSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		if (m_iSpecialMidashiCharKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSpecialMidashiCharKey) 
			m_iSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;
	} else {
		/* ���[�h�Ɏ��s�����̂ŁA�f�t�H���g�̐ݒ�ɂ���B*/
		m_iKeybindType					= KEYBINDTP_DEFAULT ;
		m_iStartHenkanKeyType			= KEYBINDTP_DEFAULT ;
		m_iCompletionRelatedKeyType		= KEYBINDTP_DEFAULT ;
		m_iSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		m_iSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;

		m_bEggLikeNewline				= FALSE ;
		m_bNewlineKakuteiAll				= TRUE ;
	}
	/*	�L�[�}�b�v�̏������B*/
	if (m_iKeybindType == KEYBINDTP_DEFAULT) {
		_vInitializeMajorModeMap () ;
		_vInitializeSkkJModeMap () ;
		_vInitializeSkkLatinModeMap () ;
		_vInitializeSkkJisx0208LatinModeMap () ;
		_vInitializeSkkAbbrevModeMap () ;	
	}
	_vInitializeMinibufferMinorModeMap () ;
	return	TRUE ;
}

BOOL
CImeConfig::_bLoadKeymap (
	HKEY				hSubKey,
	LPCWSTR				strRegistryName,
	LPCWSTR				strRegisterExtraName,
	struct CImeKeymap*	pKeymap)
{
	BOOL				bRetval	= FALSE ;
	LONG 				lResult ;
	DWORD				dwType, cbData ;
	BYTE				rbBuffer [512] ;
	BYTE*				pbBuffer	= NULL ;
	DWORD				iBufSize ;
	int					iNumKeyBinds, j ;
	const BYTE*			pbData ;
	struct CImeKeyBind*	pKeyBind ;


	lResult	= RegQueryValueExW (hSubKey, strRegistryName, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS) 
		return	TRUE ;
	if (dwType != REG_BINARY || cbData != MAX_KEYBINDS) 
		return	TRUE ;

	(void) RegQueryValueExW (hSubKey, strRegistryName, NULL, &dwType, (BYTE*)pKeymap->m_rbyBaseMap, &cbData) ;

	/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
	pKeymap->m_nKeyBinds	= 0 ;
	pKeymap->m_pKeyBinds	= NULL ;

	/*	����L�[�̓o�^�B
	 */
	pbBuffer	= rbBuffer ;
	iBufSize	= sizeof (rbBuffer) ;
	/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
	lResult	= RegQueryValueEx (hSubKey, strRegisterExtraName, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY)
		return	TRUE ;

	if (cbData > iBufSize) {
		if (pbBuffer != rbBuffer) {
			delete[]	pbBuffer ;
		}
		pbBuffer	= new BYTE [cbData] ;
		if (pbBuffer == NULL) 
			goto	exit_func ;
		iBufSize	= cbData ;
	}
	(void) RegQueryValueEx (hSubKey, strRegisterExtraName, NULL, &dwType, pbBuffer, &cbData) ;

	/*
	 */
	iNumKeyBinds	= cbData / (4 + 2 + 2) ;	/* VKEY(4), MODIFIER(2), FUNCNO(2) */
	if (iNumKeyBinds <= 0)
		goto	exit_func ;

	pKeymap->m_pKeyBinds	= new CImeKeyBind [iNumKeyBinds] ;
	if (pKeymap->m_pKeyBinds == NULL) 
		goto	exit_func ;

	pKeymap->m_nKeyBinds	= iNumKeyBinds ;
	pbData		= pbBuffer ;
	pKeyBind	= pKeymap->m_pKeyBinds ;
	for (j = 0 ; j < iNumKeyBinds ; j ++) {
		unsigned int	uVKey, uModifier ;
		int				iFuncNo ;

		uVKey		= (unsigned int) *pbData ++ ;
		uVKey		= uVKey | ((unsigned int) *pbData ++ <<  8) ;
		uVKey		= uVKey | ((unsigned int) *pbData ++ << 16) ;
		uVKey		= uVKey | ((unsigned int) *pbData ++ << 24) ;
		uModifier	= (unsigned int) *pbData ++ ;
		uModifier	= uModifier | ((unsigned int) *pbData ++ << 8) ;
		iFuncNo		= (unsigned int) *pbData ++ ;
		iFuncNo		= iFuncNo | ((unsigned int) *pbData ++) ;
		if (iFuncNo < 0 || iFuncNo >= NFUNC_INVALID_CHAR) 
			continue ;	/* skip */
		pKeyBind->m_nKeyCode		= (short) uVKey ;
		pKeyBind->m_uKeyMask		= (unsigned short) uModifier ;
		pKeyBind->m_nKeyFunction	= iFuncNo ;
		pKeyBind	++ ;
	}
	/* realloc �������Ƃ��낾���ǁc */
	pKeymap->m_nKeyBinds	= pKeyBind - pKeymap->m_pKeyBinds ;
	bRetval	= TRUE ;
exit_func:
	if (pbBuffer != rbBuffer && pbBuffer != NULL) {
		delete[]	pbBuffer ;
		pbBuffer	= NULL ;
	}
	return	TRUE ;
}

void
CImeConfig::_vValidateKeymap (
	struct CImeKeymap*		pKeymap)
{
	int		j ;

	for (j = 0 ; j < MAX_KEYBINDS ; j ++) {
		if (pKeymap->m_rbyBaseMap [j] < 0 || pKeymap->m_rbyBaseMap [j] >= NUM_SELECTABLE_FUNCTIONS) {
			pKeymap->m_rbyBaseMap [j]	= NFUNC_INVALID_CHAR ;
		}
	}
	return ;
}

void
CImeConfig::_vInitializeMajorModeMap ()
{
	static BYTE		_srbDefaultMajorModeMap []	= {
		NFUNC_SET_MARK_COMMAND,				/* C-@ */
		NFUNC_BEGINNING_OF_LINE,			/* C-a */
		NFUNC_BACKWARD_CHAR,				/* C-b */
		NFUNC_INVALID_CHAR,					//NFUNC_MODE_SPECIFIC_COMMAND_PREFIX,	/* C-c */
		NFUNC_DELETE_CHAR,					/* C-d */
		NFUNC_END_OF_LINE,					/* C-e */
		NFUNC_FORWARD_CHAR,					/* C-f */
		NFUNC_KEYBOARD_QUIT,				/* C-g */
		NFUNC_BACKWARD_DELETE_CHAR,			/* C-h */
		NFUNC_INVALID_CHAR,					//NFUNC_INDENT_FOR_TAB_COMMAND,			/* C-i */
		NFUNC_NEWLINE,						//NFUNC_NEWLINE_AND_INDENT,				/* C-j */
		NFUNC_KILL_LINE,					/* C-k */
		NFUNC_INVALID_CHAR,					//NFUNC_RECENTER,						/* C-l */
		NFUNC_NEWLINE,						/* C-m */
		NFUNC_INVALID_CHAR,					//NFUNC_NEXT_LINE,						/* C-n */
		NFUNC_INVALID_CHAR,					//NFUNC_OPEN_LINE,						/* C-o */
		NFUNC_INVALID_CHAR,					//NFUNC_PREVIOUS_LINE,					/* C-p */	
		NFUNC_INVALID_CHAR,					//NFUNC_QUATED_INSERT,					/* C-q */
		NFUNC_INVALID_CHAR,					//NFUNC_ISEARCH_BACKWARD,				/* C-r */
		NFUNC_INVALID_CHAR,					//NFUNC_ISEARCH_FORWARD,				/* C-s */
		NFUNC_TRANSPOSE_CHARS,				/* C-t */
		NFUNC_INVALID_CHAR,					//FUNC_UNIVERSAL_ARGUMENT,				/* C-u */
		NFUNC_INVALID_CHAR,					//NFUNC_SCROLL_UP,						/* C-v */
		NFUNC_KILL_REGION,					/* C-w */
		NFUNC_INVALID_CHAR,					//NFUNC_CONTROL_X_PREFIX,				/* C-x */
		NFUNC_YANK,							/* C-y */
		NFUNC_INVALID_CHAR,					//NFUNC_SCROLL_DOWN,					/* C-z */
		NFUNC_INVALID_CHAR,					//NFUNC_PREFIX_COMMAND,					/* C-[ */
		NFUNC_TOGGLE_IME,					/* C-\\ */
		NFUNC_ABORT_RECURSIVE_EDIT,			/* C-] */
		NFUNC_INVALID_CHAR,					//NFUNC_UNDO,							/* C-_ */
	} ;
	int	i ;

	for (i = 0 ; i < MYARRAYSIZE (m_MajorModeMap.m_rbyBaseMap) ; i ++) 
		m_MajorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	for (i = 0 ; i < MYARRAYSIZE (_srbDefaultMajorModeMap) ; i ++) 
		m_MajorModeMap.m_rbyBaseMap [i]	= _srbDefaultMajorModeMap [i] ;
	for (i = 32 ; i < 127 ; i ++) 
		m_MajorModeMap.m_rbyBaseMap [i]	= NFUNC_SELF_INSERT_CHARACTER ;
	m_MajorModeMap.m_pKeyBinds	= NULL ;
	m_MajorModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
CImeConfig::_vInitializeSkkJModeMap ()
{
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (m_SkkJModeMap.m_rbyBaseMap) ; i ++) {
		m_SkkJModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 32 ; i < 127 ; i ++) {
		m_SkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_INSERT ;
	}
	m_SkkJModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	m_SkkJModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_KATAKANA ;

	/*	previous-candidate-char ���ɂ���ׂ����Akeybind ���� previous-candidate-char ��
	 *	���߂�悤�ɂ���ׂ����B�ǂ��炪�������̂��B��҂��I������Ȃ��������R�́A�ǂ�
	 *	minor-mode-map �𗘗p����Ηǂ��̂�������Ȃ��������炩�H
	 */
	m_SkkJModeMap.m_rbyBaseMap ['x']	= NFUNC_SKK_PREVIOUS_CANDIDATE ;

	for (i = 0 ; i < MYARRAYSIZE (m_MajorModeMap.m_rbyBaseMap) ; i ++) {
		if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			m_SkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	/*	try-completion-char �� skk-insert �ɂ��킹��B
	 *	try-completion-char �� keybind ����ɂ��邩�c�B���[��A�ł� try-completion �̓���
	 *	�� skk-insert �Ɠ����ɂ��Ă����� (function code �͈Ⴄ���ǁA����͓�����)�A
	 *	keybind �� try-completion �Ȃ� try-completion-charp �� t ��Ԃ��Ƃ����̂́H
	 *
	 *	�����Aabbrev-map �͑f���� try-completion �Ȃ̂ɁA������� skk-insert �o�R�Ƃ����̂�
	 *	�C�ɂȂ�c�B����������闝�R���l�������� try-completion ������̂͊댯���B
	 */
	m_SkkJModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_INSERT ;
	m_SkkJModeMap.m_pKeyBinds	= NULL ;
	m_SkkJModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
CImeConfig::_vInitializeSkkLatinModeMap ()
{
	int		i ;
	for (i = 0 ; i < MYARRAYSIZE (m_SkkLatinModeMap.m_rbyBaseMap) ; i ++)
		m_SkkLatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkLatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;

	m_SkkLatinModeMap.m_pKeyBinds	= NULL ;
	m_SkkLatinModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
CImeConfig::_vInitializeSkkJisx0208LatinModeMap ()
{
	int		i ;
	for (i = 0 ; i < MYARRAYSIZE (m_SkkJisx0208LatinModeMap.m_rbyBaseMap) ; i ++)
		m_SkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	for (i = 0 ; i < 128 ; i ++) {
		/*	LatinVector �̏���������ɍs���Ă��Ȃ���΂Ȃ�Ȃ��B*/
		if (m_rstrJisx0208LatinVector [i] != NULL) 
			m_SkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_JISX0208_LATIN_INSERT ;
	}
	m_SkkJisx0208LatinModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_LATIN_HENKAN ;	/* \C-q */

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkJisx0208LatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-backward-and-set-henkan-point-char �́c 2stroke key �͎������ĂȂ�����c�B*/

	m_SkkJisx0208LatinModeMap.m_pKeyBinds	= NULL ;
	m_SkkJisx0208LatinModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
CImeConfig::_vInitializeSkkAbbrevModeMap ()
{
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (m_SkkAbbrevModeMap.m_rbyBaseMap) ; i ++)
		m_SkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	m_SkkAbbrevModeMap.m_rbyBaseMap ['.']	= NFUNC_SKK_ABBREV_PERIOD ;
	m_SkkAbbrevModeMap.m_rbyBaseMap [',']	= NFUNC_SKK_ABBREV_COMMA ;
	m_SkkAbbrevModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_CHARACTERS ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkAbbrevModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-start-henkan-char �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	m_SkkAbbrevModeMap.m_rbyBaseMap [' ']	= NFUNC_SKK_START_HENKAN ;

	for (i = 0 ; i < MYARRAYSIZE (m_MajorModeMap.m_rbyBaseMap) ; i ++) {
		if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			m_SkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	m_SkkAbbrevModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_TRY_COMPLETION ;

	m_SkkAbbrevModeMap.m_pKeyBinds	= NULL ;
	m_SkkAbbrevModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
CImeConfig::_vInitializeMinibufferMinorModeMap ()
{
	struct CImeKeyBind*	pKeyBind ;
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (m_MinibufferMinorModeMap.m_rbyBaseMap) ; i ++)
		m_MinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	m_MinibufferMinorModeMap.m_nKeyBinds	= 0 ;
	m_MinibufferMinorModeMap.m_pKeyBinds	= NULL ;

	for (i = 0 ; i < MYARRAYSIZE (m_MajorModeMap.m_rbyBaseMap) ; i ++) {
		if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_NEWLINE) {
			_bDefineKey (&m_MinibufferMinorModeMap, i, 0, FALSE, NFUNC_EXIT_RECURSIVE_EDIT) ;
		} else if (m_MajorModeMap.m_rbyBaseMap [i] == NFUNC_KEYBOARD_QUIT) {
			_bDefineKey (&m_MinibufferMinorModeMap, i, 0, FALSE, NFUNC_ABORT_RECURSIVE_EDIT) ;
		}
	}
	if (m_MajorModeMap.m_nKeyBinds > 0) {
		pKeyBind	= m_MajorModeMap.m_pKeyBinds ;
		for (i = 0 ; i < m_MajorModeMap.m_nKeyBinds ; i ++) {
			if (pKeyBind->m_nKeyFunction  == NFUNC_NEWLINE) {
				_bDefineKey (&m_MinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, TRUE, NFUNC_EXIT_RECURSIVE_EDIT) ;
			} else if (pKeyBind->m_nKeyFunction == NFUNC_KEYBOARD_QUIT) {
				_bDefineKey (&m_MinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, TRUE, NFUNC_ABORT_RECURSIVE_EDIT) ;
			}
			pKeyBind	++ ;
		}
	}
	for (i = 0 ; i < MYARRAYSIZE (m_SkkJModeMap.m_rbyBaseMap) ; i ++) {
		if (m_SkkJModeMap.m_rbyBaseMap [i] == NFUNC_SKK_KAKUTEI) 
			_bDefineKey (&m_MinibufferMinorModeMap, i, 0, FALSE, NFUNC_SKK_KAKUTEI) ;
	}
	if (m_SkkJModeMap.m_nKeyBinds > 0) {
		pKeyBind	= m_SkkJModeMap.m_pKeyBinds ;
		for (i = 0 ; i < m_SkkJModeMap.m_nKeyBinds ; i ++) {
			if (pKeyBind->m_nKeyFunction == NFUNC_SKK_KAKUTEI) 
				_bDefineKey (&m_MinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, TRUE, NFUNC_SKK_KAKUTEI) ;
			pKeyBind	++ ;
		}
	}
	return ;
}

BOOL
CImeConfig::_bDefineKey (
	struct CImeKeymap*	pKeymap,
	int					nKeyCode,
	unsigned int		uKeyMask,
	BOOL				bExtended,
	int					nKeyFunction)
{
	struct CImeKeyBind*	pKeyBind ;
	struct CImeKeyBind*	pNewKeyBind ;
	int		i ;

	if (pKeymap == NULL)
		return	FALSE ;

	if (! bExtended) {
		if (uKeyMask != 0 || nKeyCode < 0 || nKeyCode >= MAX_KEYBINDS)
			return	FALSE ;
		pKeymap->m_rbyBaseMap [nKeyCode]	= (BYTE) nKeyFunction ;
	} else {
		pKeyBind	= pKeymap->m_pKeyBinds ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
			if (pKeyBind->m_nKeyCode == nKeyCode && pKeyBind->m_uKeyMask == uKeyMask) {
				/* found */
				pKeyBind->m_nKeyFunction	= nKeyFunction ;
				return	TRUE ;
			}
			pKeyBind	++ ;
		}

		pNewKeyBind	= new CImeKeyBind [pKeymap->m_nKeyBinds + 1] ;
		if (pNewKeyBind == NULL)
			return	FALSE ;
		if (pKeymap->m_nKeyBinds > 0)
			memcpy (pNewKeyBind, pKeymap->m_pKeyBinds, sizeof (struct CImeKeyBind) * pKeymap->m_nKeyBinds) ;
		if (pKeymap->m_pKeyBinds != NULL)
			delete[]	pKeymap->m_pKeyBinds ;
		pKeymap->m_pKeyBinds	= pNewKeyBind ;
		pNewKeyBind [pKeymap->m_nKeyBinds].m_nKeyCode	= (short) nKeyCode ;
		pNewKeyBind [pKeymap->m_nKeyBinds].m_uKeyMask	= (unsigned short) uKeyMask ;
		pNewKeyBind [pKeymap->m_nKeyBinds].m_nKeyFunction	= nKeyFunction ;
		pKeymap->m_nKeyBinds	++ ;
	}
	return	TRUE ;
}

/*========================================================================
 *	private functions (for Keybind/���[�}�����ȃ��[��)
 */
BOOL
CImeConfig::_bLoadRomaKanaRuleList ()
{
	BOOL	bRetval ;
	int		i ;

	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		m_rpSkkRuleTree [i]					= NULL ;
		m_rpSkkJisx0201RomanRuleTree [i]	= NULL ;
		m_rpSkkJisx0201RuleTree [i]			= NULL ;
	}
	bRetval	= _bLoadRomaKanaRuleListFromRegistry () ;
	if (! bRetval || m_iRomaKanaRuleListType == KEYBINDTP_DEFAULT) {
		m_iRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
		_bInitializeDefaultRomaKanaRuleTree () ;
	}
	return	TRUE ;
}

void
CImeConfig::_vClearRomaKanaRuleList ()
{
	int		i ;

	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		if (m_rpSkkRuleTree [i] != NULL) {
			CSkkRuleTreeNode::vDestroyTree (m_rpSkkRuleTree [i]) ;
			m_rpSkkRuleTree [i]	= NULL ;
		}
		if (m_rpSkkJisx0201RomanRuleTree [i] != NULL) {
			CSkkRuleTreeNode::vDestroyTree (m_rpSkkJisx0201RomanRuleTree [i]) ;
			m_rpSkkJisx0201RomanRuleTree [i]	= NULL ;
		}
		if (m_rpSkkJisx0201RuleTree [i] != NULL) {
			CSkkRuleTreeNode::vDestroyTree (m_rpSkkJisx0201RuleTree [i]) ;
			m_rpSkkJisx0201RuleTree [i]	= NULL ;
		}
	}
	return ;
}

BOOL
CImeConfig::_bLoadRomaKanaRuleListFromRegistry ()
{
	HKEY	hSubKey ;
	BOOL	bExistUserDefinedRomaKanaRule	= FALSE ;
	BOOL	bRetval	= TRUE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_ROMAKANARULE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData, dwValue ;

		/* rule-list-type (default or custom) */
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, REGINFO_ROMAKANARULE_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) {
			bRetval	= FALSE ;
			goto	skip_error ;
		}
		m_iRomaKanaRuleListType	= (int) dwValue ;

		if (m_iRomaKanaRuleListType != KEYBINDTP_DEFAULT) {
			static LPCWSTR	srRomaKanaRuleTbl [NUM_ROMAKANARULE]	= {
				REGINFO_ROMAKANARULE,	REGINFO_ROMAKANARULE1,	REGINFO_ROMAKANARULE2,	REGINFO_ROMAKANARULE3,
			} ;
			static LPCWSTR	srJisx0201RomanRuleTbl [NUM_ROMAKANARULE]	= {
				REGINFO_JISX0201ROMANRULE,	REGINFO_JISX0201ROMANRULE1,	REGINFO_JISX0201ROMANRULE2,	REGINFO_JISX0201ROMANRULE3,
			} ;
			static LPCWSTR	srJisx0201RuleTbl [NUM_ROMAKANARULE]	= {
				REGINFO_JISX0201RULE,	REGINFO_JISX0201RULE1,	REGINFO_JISX0201RULE2,	REGINFO_JISX0201RULE3,
			} ;
			if (_bParseRomaKanaRules (m_rpSkkRuleTree, hSubKey, srRomaKanaRuleTbl, RULETREENO_SKK_BASE, NUM_ROMAKANARULE))
				bExistUserDefinedRomaKanaRule	= TRUE ;
			if (_bParseRomaKanaRules (m_rpSkkJisx0201RomanRuleTree, hSubKey, srJisx0201RomanRuleTbl, RULETREENO_SKK_JISX0201_ROMAN, NUM_ROMAKANARULE))
				bExistUserDefinedRomaKanaRule	= TRUE ;
			if (_bParseRomaKanaRules (m_rpSkkJisx0201RuleTree, hSubKey, srJisx0201RuleTbl, RULETREENO_SKK_JISX0201_BASE, NUM_ROMAKANARULE))
				bExistUserDefinedRomaKanaRule	= TRUE ;
		}
		if (! bExistUserDefinedRomaKanaRule) {
			m_iRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
		}
skip_error:
		RegCloseKey (hSubKey) ;
	}
	if (! bRetval)
		goto	error_exit ;
	return	TRUE ;

error_exit:
	return	FALSE ;
}

BOOL
CImeConfig::_bParseRomaKanaRules (
	CSkkRuleTreeNode**		ppTree,
	HKEY					hSubKey,
	LPCWSTR*				ppwRuleName,
	int						nRuleBase,
	int						nRule)
{
	LPWSTR				pwData	= NULL ;
	CSkkRuleTreeNode*	pRoot ;
	int					i ;
	BOOL				bRetval ;
	LONG 				lResult ;
	DWORD				dwType, cbData ;

	bRetval	= FALSE ;
	for (i = 0 ; i < nRule ; i ++) {
		/* roma-kana-rule �{�́B*/
		lResult	= RegQueryValueExW (hSubKey, ppwRuleName [i], NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) {
			ppTree [i]	= NULL ;
			continue ;
		}
		if (dwType != REG_MULTI_SZ) {
			ppTree [i]	= NULL ;
			continue ;
		}
		pwData	= (LPWSTR) new WCHAR [cbData] ;
		if (pwData == NULL)
			continue ;

		(void) RegQueryValueExW (hSubKey, ppwRuleName [i], NULL, &dwType, (BYTE*)pwData, &cbData) ;
		pRoot	= NULL ;
		if (_bParseRomaKanaRule (&pRoot, nRuleBase, i, pwData, cbData)) {
			ppTree [i]	= pRoot ;
			bRetval		= TRUE ;
		} else {
			ppTree [i]	= NULL ;
		}
		delete[]	pwData ;
		pwData	= NULL ;
	}
	return	bRetval ;
}

BOOL
CImeConfig::_bParseRomaKanaRule (
	CSkkRuleTreeNode**		ppTree,
	int						nRuleBase,
	int						nRule,
	LPCWSTR					pwData,
	int						cbData)
{
	CSkkRuleTreeNode*	pRoot	= NULL ;
	LPCWSTR		pwSrc, pwSrcEnd ;
	WCHAR		bufState [128], bufNext [128], bufNextRule [32], bufHira [128], bufKata [128] ;
	WCHAR		bufRule [32] ;
	DCHAR		bufDState [128] ;
	int			nNextRule, nStateLen ;

	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	while (*pwSrc != L'\0' && pwSrc < pwSrcEnd) {
		int							nType ;
		BOOL						bTerminated ;
		LPCWSTR						pwNext ;

		nType	= *pwSrc ++ ;
		if (! _bParseBSEncodedString (&pwSrc, bufState, MYARRAYSIZE (bufState) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! _bParseBSEncodedString (&pwSrc, bufNext,  MYARRAYSIZE (bufNext)  - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! _bParseBSEncodedString (&pwSrc, bufNextRule,  MYARRAYSIZE (bufNextRule)  - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		bufState    [MYARRAYSIZE (bufState) - 1]	= L'\0' ;
		bufRule		[MYARRAYSIZE (bufRule)  - 1]	= L'\0' ;
		bufNext     [MYARRAYSIZE (bufNext)  - 1]	= L'\0' ;
		bufNextRule [MYARRAYSIZE (bufNextRule) - 1]	= L'\0' ;
		pwNext	= (bufNext [0] != L'\0')? bufNext : NULL ;
#if defined (__STDC_WANT_SECURE_LIB__)
		if (_snwscanf_s (bufNextRule, MYARRAYSIZE (bufNextRule), L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#else
		if (swscanf (bufNextRule, L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#endif

		switch (nType) {
		case	TEXT ('1'):
			if (! _bParseBSEncodedString (&pwSrc, bufHira, MYARRAYSIZE (bufHira) - 1, &bTerminated) || bTerminated)
				goto	next_entry ;
			if (! _bParseBSEncodedString (&pwSrc, bufKata, MYARRAYSIZE (bufKata) - 1, &bTerminated) || ! bTerminated)
				goto	next_entry ;

			bufHira [MYARRAYSIZE (bufHira) - 1]		= L'\0' ;
			bufKata [MYARRAYSIZE (bufKata)  - 1]	= L'\0' ;

			nStateLen	= wcstodcs_n (bufDState, MYARRAYSIZE (bufDState), bufState, lstrlenW (bufState)) ;
			if (! CSkkRuleTreeNode::bAddRule (&pRoot, nRule + nRuleBase, bufDState, nStateLen, pwNext, lstrlenW (bufNext), nNextRule + nRuleBase, bufHira, lstrlenW (bufHira), bufKata, lstrlenW (bufKata))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('2'):
			if (! _bParseBSEncodedString (&pwSrc, bufHira, MYARRAYSIZE (bufHira) - 1, &bTerminated) || ! bTerminated)
				goto	next_entry ;
			bufHira [MYARRAYSIZE (bufHira) - 1]	= L'\0' ;

			nStateLen	= wcstodcs_n (bufDState, MYARRAYSIZE (bufDState), bufState, lstrlenW (bufState)) ;
			if (! CSkkRuleTreeNode::bAddRule (&pRoot, nRule + nRuleBase, bufDState, nStateLen, pwNext, lstrlenW (bufNext), nNextRule + nRuleBase, bufHira, lstrlenW (bufHira))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('3'):
			{
				int		nFuncNo	= 0 ;

				if (! _bParseBSEncodedString (&pwSrc, bufHira, MYARRAYSIZE (bufHira) - 1, &bTerminated) || ! bTerminated)
					goto	next_entry ;
				bufHira [MYARRAYSIZE (bufHira) - 1]	= L'\0' ;

#if defined (__STDC_WANT_SECURE_LIB__)
				if (_snwscanf_s (bufHira, MYARRAYSIZE (bufHira), L"%d", &nFuncNo) != 1)
					goto	next_entry ;
#else
				if (swscanf (bufHira, L"%d", &nFuncNo) != 1)
					goto	next_entry ;
#endif
				nStateLen	= wcstodcs_n (bufDState, MYARRAYSIZE (bufDState), bufState, lstrlenW (bufState)) ;
				if (! CSkkRuleTreeNode::bAddRule (&pRoot, nRule + nRuleBase, bufDState, nStateLen, pwNext, lstrlenW (bufNext), nNextRule + nRuleBase, nFuncNo)) {
					goto	error_exit ;
				}
			}
			break ;
		default:
			break ;
		}
next_entry:
		/* parse �Ɏ��s�����G���g���̏ꍇ nul �ɓ��B���Ă��Ȃ��̂ŁAnul �܂Ői�߂�B*/
		while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
			pwSrc ++ ;
		pwSrc	++ ;	/* nul �� skip */
	}
	if (ppTree != NULL) {
		*ppTree	= pRoot ;
	} else {
		CSkkRuleTreeNode::vDestroyTree (pRoot) ;
	}
	return	TRUE ;

error_exit:
	CSkkRuleTreeNode::vDestroyTree (pRoot) ;
	return	FALSE ;
}

void
CImeConfig::_vClearKeymaps ()
{
	_vClearKeymap (&m_MajorModeMap) ;
	_vClearKeymap (&m_SkkJModeMap) ;
	_vClearKeymap (&m_SkkLatinModeMap) ;
	_vClearKeymap (&m_SkkJisx0208LatinModeMap) ;
	_vClearKeymap (&m_SkkAbbrevModeMap) ;
	_vClearKeymap (&m_MinibufferMinorModeMap) ;
	return ;
}

void
CImeConfig::_vClearKeymap (struct CImeKeymap* pKeymap) 
{
	if (pKeymap == NULL)
		return ;
	if (pKeymap->m_nKeyBinds > 0 && pKeymap->m_pKeyBinds != NULL) 
		delete[]	pKeymap->m_pKeyBinds ;
	pKeymap->m_pKeyBinds	= NULL ;
	pKeymap->m_nKeyBinds	= 0 ;
	return ;
}

/*========================================================================
 *	private functions (for Keybind)
 */
BOOL
CImeConfig::_bLoadGenericSetting ()
{
	static const struct {
		LPCWSTR		m_strLeft ;
		LPCWSTR		m_strRight ;
	}	_srDefaultBracketParens []	= {
		{ L"�u",	L"�v" },	{ L"�w",	L"�x" },
		{ L"(",		L")"  },	{ L"�i",	L"�j" }, 
		{ L"{",		L"}"  },	{ L"�o",	L"�p" },
		{ L"�q",	L"�r" },	{ L"�s",	L"�t" },
		{ L"[",		L"]"  },	{ L"�m",	L"�n" },
		{ L"�k",	L"�l" },	{ L"�y",	L"�z" }, 
		{ L"\"",	L"\"" },	{ L"�g",	L"�h" },
		{ L"`",		L"'"  }, 
	},	_srDefaultKutoutens []	= {
		{ L"�C",	L"�D"	},	{ L"�A",	L"�B" },
	} ;
	const int	en_table []	= { 0, 1 } ;
	const int	jp_table []	= { 1, 0 } ;
	const int*	pTable	= NULL ;
	int	i ;

	if (! _bLoadGenericSettingFromRegistry ()) {
		/* default setting */
		m_bKanaModeWhenOpen		= TRUE ;
		m_bEcho					= TRUE ;
		m_bAutoInsertParen		= TRUE ;
		m_bCompositionAutoShift	= TRUE ;
		m_bDeleteImpliesKakutei	= TRUE ;
		m_bDateAd				= FALSE ;
		m_iNumberStyle			= 0 ;
		m_iKutoutenType			= KUTOUTEN_TYPE_JP ;

		for (i = 0 ; i < MYARRAYSIZE (_srDefaultBracketParens) ; i ++) {
			LPDSTR	pwDest ;
			LPCWSTR	pwSrc ;
			int		nDestSize, nSrcLen, n ;

			pwDest		= m_BracketParen.m_rStringPair [i].m_bufLeft ;
			nDestSize	= MYARRAYSIZE (m_BracketParen.m_rStringPair [i].m_bufLeft) ;
			pwSrc		= _srDefaultBracketParens [i].m_strLeft ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n		= wcstodcs_n (pwDest, nDestSize-1, pwSrc, nSrcLen) ;
			pwDest [n]	= L'\0' ;

			pwDest		= m_BracketParen.m_rStringPair [i].m_bufRight ;
			nDestSize	= MYARRAYSIZE (m_BracketParen.m_rStringPair [i].m_bufRight) ;
			pwSrc		= _srDefaultBracketParens [i].m_strRight ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n		= wcstodcs_n (pwDest, nDestSize-1, pwSrc, nSrcLen) ;
			pwDest [n]	= L'\0' ;
		}
		m_BracketParen.m_iCount		= MYARRAYSIZE (_srDefaultBracketParens) ;

		m_bTSFKeyDownEatenDoesNotWork	= TRUE ;
	}
	switch (m_iKutoutenType) {
	case	KUTOUTEN_TYPE_EN:
		pTable				= en_table ;
		m_Kutouten.m_iCount	= 2 ;
		goto	set_kutoten ;
	case	KUTOUTEN_TYPE_JP:
		pTable				= jp_table ;
		m_Kutouten.m_iCount	= 2 ;
set_kutoten:
		for (i = 0 ; i < m_Kutouten.m_iCount ; i ++) {
			LPDSTR	pwDest ;
			LPCWSTR	pwSrc ;
			int		nDestSize, nSrcLen, n ;

			pwDest		= m_Kutouten.m_rStringPair [i].m_bufLeft ;
			nDestSize	= MYARRAYSIZE (m_Kutouten.m_rStringPair [i].m_bufLeft) ;
			pwSrc		= _srDefaultKutoutens [pTable [i]].m_strLeft ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n			= wcstodcs_n (pwDest, nDestSize-1, pwSrc, nSrcLen) ;
			pwDest [n]	= L'\0' ;

			pwDest		= m_Kutouten.m_rStringPair [i].m_bufRight ;
			nDestSize	= MYARRAYSIZE (m_Kutouten.m_rStringPair [i].m_bufRight) ;
			pwSrc		= _srDefaultKutoutens [pTable [i]].m_strRight ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n			= wcstodcs_n (pwDest, nDestSize-1, pwSrc, nSrcLen) ;
			pwDest [n]	= L'\0' ;
		}
		break ;
	default:
		break; 
	}
	return	TRUE ;
}

BOOL
CImeConfig::_bLoadGenericSettingFromRegistry ()
{
	HKEY	hSubKey ;
	LONG 	lResult ;
	DWORD	dwType, cbData, dwValue ;
	LPWSTR	pwBracketParen		= NULL ;
	LPWSTR	pwKutoutens			= NULL ;
	LPWSTR	pwOkuriCharAlist	= NULL ;
	BOOL	bRetval				= FALSE ;

	DEBUGPRINTF ((TEXT ("CImeConfig::_bLoadGenericSettingFromRegistry(this:%p) - Enter\n"), this)) ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
		return	FALSE ;

	/*	���ʃy�A�ݒ�̓ǂݍ��݁B*/
	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_BRACKETPARENS, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwBracketParen	= new WCHAR [cbData] ;
		if (pwBracketParen == NULL)
			goto	skip_error ;
		(void) RegQueryValueExW (hSubKey, REGINFO_BRACKETPARENS, NULL, &dwType, (BYTE*)pwBracketParen, &cbData) ;
	} else {
		m_iBracketParenType		= BRACKETPARENTP_DEFAULT ;
	}

	/*	��Ǔ_�ݒ�̓ǂݍ��݁B*/
	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_KUTOUTENS, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwKutoutens	= new WCHAR [cbData] ;
		if (pwKutoutens == NULL)
			goto	skip_error ;
		(void) RegQueryValueExW (hSubKey, REGINFO_KUTOUTENS, NULL, &dwType, (BYTE*)pwKutoutens, &cbData) ;
	} else {
		m_iKutoutenType			= KUTOUTEN_TYPE_JP ;
	}

	/*	���艼���ǂݑւ��ݒ�̓ǂݍ��݁B*/
	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_OKURICHARALIST, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwOkuriCharAlist	= new WCHAR [cbData] ;
		if (pwOkuriCharAlist == NULL)
			goto	skip_error ;
		(void) RegQueryValueExW (hSubKey, REGINFO_OKURICHARALIST, NULL, &dwType, (BYTE*)pwOkuriCharAlist, &cbData) ;
	} else {
		m_iOkuriCharAlistType	= OKURICHARTP_DEFAULT ;
	}

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_KANAMODEWHENOPEN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_bKanaModeWhenOpen	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_ECHO, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_bEcho	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_COMPOSITIONAUTOSHIFT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_bCompositionAutoShift	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_DELETEIMPLIESKAKUTEI, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_bDeleteImpliesKakutei	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_DATEAD, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_bDateAd	= dwValue ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_NUMBERSTYLE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_iNumberStyle	= dwValue ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_KAKUTEIEARLY, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_bKakuteiEarly	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_KUTOUTENTYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_iKutoutenType	= dwValue ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_AUTOINSERTPAREN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_iBracketParenType	= dwValue ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_OKURICHARALISTTYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) 
		m_iOkuriCharAlistType	= dwValue ;

	lResult	= RegQueryValueExW (hSubKey, REGINFO_TSFKEYDOWNEATENDOESNOTWORK, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bTSFKeyDownEatenDoesNotWork	= (dwValue != 0) ;

	bRetval	= TRUE ;

skip_error:
	RegCloseKey (hSubKey) ;

	/* BracketParen �� parse */
	if (bRetval && pwBracketParen != NULL) {
		m_BracketParen.m_iCount	= _iDecodeStringPairList (pwBracketParen, m_BracketParen.m_rStringPair, MYARRAYSIZE (m_BracketParen.m_rStringPair)) ;
	}
	/* Kutouten �� parse */
	if (bRetval && pwKutoutens != NULL) {
		m_Kutouten.m_iCount	= _iDecodeStringPairList (pwKutoutens, m_Kutouten.m_rStringPair, MYARRAYSIZE (m_Kutouten.m_rStringPair)) ;
	}
	if (bRetval && pwOkuriCharAlist != NULL) {
		m_OkuriCharAlist.m_iCount	= _iDecodeStringPairList (pwKutoutens, m_OkuriCharAlist.m_rStringPair , MYARRAYSIZE (m_OkuriCharAlist.m_rStringPair )) ;
	}
	if (pwBracketParen != NULL)
		delete[]	pwBracketParen ;
	if (pwKutoutens != NULL)
		delete[]	pwKutoutens ;
	if (pwOkuriCharAlist != NULL)
		delete[]	pwOkuriCharAlist ;

	DEBUGPRINTF ((TEXT ("m_bKakuteiEarly = %d\n"), m_bKakuteiEarly)) ;
	DEBUGPRINTF ((TEXT ("CImeConfig::_bLoadGenericSettingFromRegistry - Leave(%d)\n"), bRetval)) ;
	return	bRetval ;
}

/*========================================================================
 *	private functions for conversion
 */
BOOL
CImeConfig::_bLoadConversionSetting ()
{
	static	const DCHAR	_srbDefaultCandidateKeys []	= {
		'A', 'S', 'D', 'F', 'J', 'K', 'L', 'Q', 'W', 'U', 'I', 'O', 'Z', 'C', 'V', 'B', 'M', 
	} ;
	static	const DCHAR	_srbDefaultMenu1Keys []	= {
		'A', 'S', 'D', 'F', 'G', 'H', 'Q', 'W', 'E', 'R', 'T', 'Y',
	} ;
	static	const DCHAR	_srbDefaultMenu2Keys []	= {
		'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U',
	} ;
	static	const DCHAR	_srb10Keys []	= {
		'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 
	} ;
	/* 28 keywords */
	static	const WCHAR	_srDefaultAutoStartHenkanKeywords []	= L"��\0�A\0�B\0�D\0�C\0�H\0�v\0�I\0�G\0�F\0)\0;\0:\0�j\0�h\0�z\0�x\0�t\0�r\0�p\0�n�l\0}\0]\0?\0.\0,\0!\0\0" ;

	if (! _bLoadConversionSettingFromRegistry ()) {
		m_nCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;
		m_nNumShowCandidateKeys			= 0 ;
		m_nNumInputCodeMenu1Keys		= 0 ;
		m_nNumInputCodeMenu2Keys		= 0 ;

		m_nShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;
		m_bHenkanOkuriStrictly			= FALSE ;
		m_bProcessOkuriEarly			= FALSE ;
		m_bHenkanStrictOkuriPrecedence	= FALSE ;
		m_bAutoStartHenkan				= TRUE ;
		m_bDeleteOkuriWhenQuit			= FALSE ;
		m_bAutoOkuriProcess				= FALSE ;
		m_nShowAnnotationType			= SHOW_NO_ANNOTATION ;
		delete []	m_pAutoStartHenkanKeywords ;
		m_pAutoStartHenkanKeywords		= NULL ;
		m_iNumAutoStartHenkanKeywords	= -1 ;
	}
	switch (m_nCandListKeyAssign) {
	case	CANDLIST_KEYASSIGN_DEFAULT:
		m_nNumShowCandidateKeys		= MYARRAYSIZE (_srbDefaultCandidateKeys) ;
		m_nNumInputCodeMenu1Keys	= MYARRAYSIZE (_srbDefaultMenu1Keys) ;
		m_nNumInputCodeMenu2Keys	= MYARRAYSIZE (_srbDefaultMenu2Keys) ;
		memcpy (m_rwchShowCandidateKeys,	_srbDefaultCandidateKeys,	sizeof (_srbDefaultCandidateKeys)) ;
		memcpy (m_rwchInputCodeMenu1Keys,	_srbDefaultMenu1Keys,		sizeof (_srbDefaultMenu1Keys)) ;
		memcpy (m_rwchInputCodeMenu2Keys,	_srbDefaultMenu2Keys,		sizeof (_srbDefaultMenu2Keys)) ;
		break ;
	case	CANDLIST_KEYASSIGN_01234567890:
		m_nNumShowCandidateKeys		= MYARRAYSIZE (_srb10Keys) ;
		m_nNumInputCodeMenu1Keys	= MYARRAYSIZE (_srb10Keys) ;
		m_nNumInputCodeMenu2Keys	= MYARRAYSIZE (_srb10Keys) ;
		memcpy (m_rwchShowCandidateKeys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (m_rwchInputCodeMenu1Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (m_rwchInputCodeMenu2Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		break ;
	default:
		break; 
	}
	if (m_iNumAutoStartHenkanKeywords < 0) {
		_vInitAutoStartHenkanKeywords (_srDefaultAutoStartHenkanKeywords, MYARRAYSIZE (_srDefaultAutoStartHenkanKeywords)) ;
	}
	return	TRUE ;
}

BOOL
CImeConfig::_bLoadConversionSettingFromRegistry ()
{
	HKEY	hSubKey ;
	LONG 	lResult ;
	DWORD	dwType, cbData, dwValue ;
	int		i ;
	BYTE	rbBuffer [MAX_NUMMENUKEYS] ;
	BOOL	bRetval	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_CONVERSION, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
		return	FALSE ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_CANDLISTKEYASSIGN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	m_nCandListKeyAssign	= (/*CANDLIST_KEYASSIGN_DEFAULT <= dwValue && */dwValue <= CANDLIST_KEYASSIGN_01234567890)? (int) dwValue : CANDLIST_KEYASSIGN_USERDEFINED ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_SHOWCANDIDATELISTCOUNT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	m_nShowCandListCount	= (int) dwValue ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_HENKANOKURISTRICTLY, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bHenkanOkuriStrictly	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_PROCESSOKURIEARLY, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bProcessOkuriEarly	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_HENKANSTRICTOKURIPRECEDENCE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bHenkanStrictOkuriPrecedence	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_AUTOSTARTHENKAN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bAutoStartHenkan	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_DELETEOKURIWHENQUIT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bDeleteOkuriWhenQuit	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_AUTOOKURIPROCESS, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bAutoOkuriProcess	= (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_NUMERICCONVERSION, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bNumericConversion = (dwValue != 0) ;
	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_NUMERICFLOAT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult == ERROR_SUCCESS && dwType == REG_DWORD)
		m_bNumericFloat	= (dwValue != 0) ;

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (m_nCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			m_nCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		m_nNumShowCandidateKeys	= 0 ;
	} else {
		(void) RegQueryValueExW (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++) 
			m_rwchShowCandidateKeys [i]	= (DCHAR) rbBuffer [i] ;
		m_nNumShowCandidateKeys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (m_nCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			m_nCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		m_nNumInputCodeMenu1Keys	= 0 ;
	} else {
		(void) RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++) 
			m_rwchInputCodeMenu1Keys [i]	= (DCHAR) rbBuffer [i] ;
		m_nNumInputCodeMenu1Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (m_nCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			m_nCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		m_nNumInputCodeMenu2Keys	= 0 ;
	} else {
		(void) RegQueryValueExW (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++) 
			m_rwchInputCodeMenu2Keys [i]	= (DCHAR) rbBuffer [i] ;
		m_nNumInputCodeMenu2Keys	= (int) cbData ;
	}


	delete[]	m_pAutoStartHenkanKeywords ;
	m_pAutoStartHenkanKeywords	= NULL ;

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ || cbData <= 0) {
		/* default �̐ݒ�B*/
		m_iNumAutoStartHenkanKeywords	= -1 ;
	} else {
		LPWSTR	pwBuffer ;

		pwBuffer	= new WCHAR [cbData] ;
		if (pwBuffer != NULL) {
			(void) RegQueryValueExW (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, (BYTE*) pwBuffer, &cbData) ;

			_vInitAutoStartHenkanKeywords (pwBuffer, cbData) ;
			delete[]	pwBuffer ;
		}
	}

	cbData	= 0 ;
	lResult	= RegQueryValueExW (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD) {
		m_nShowAnnotationType	= SHOW_NO_ANNOTATION ;
	} else {
		DWORD	dwValue ;
		(void) RegQueryValueExW (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;

		if (dwValue == (DWORD)DISABLE_ANNOTATION) {
			m_nShowAnnotationType	= DISABLE_ANNOTATION ;
		} else if (0 <= dwValue && dwValue <= SHOW_ANNOTATION_ALWAYS) {
			m_nShowAnnotationType	= (int) dwValue ;
		} else {
			m_nShowAnnotationType	= SHOW_NO_ANNOTATION ;
		}
	}
	bRetval	= TRUE ;

skip_error:
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

void
CImeConfig::_vInitAutoStartHenkanKeywords (LPCWSTR pwText, int nTextLen)
{
	LPCWSTR	pSrc, pSrcLast ;
	int		iNumKeywords ;
	int	nNeed, n ;

	pSrc			= pwText ;
	pSrcLast		= pwText + nTextLen ;
	nNeed			= 0 ;
	iNumKeywords	= 0 ;
	while (pSrc < pSrcLast && *pSrc != TEXT ('\0')) {
		n		= lstrlenW (pSrc) ;
		if (n > 0) {
			nNeed	+= wcstodcs_n (NULL, 0, pSrc, n) + 1 ;
			iNumKeywords	++ ;
		}
		pSrc	+= n + 1 ;
	}
	if (iNumKeywords > 0) {
		m_pAutoStartHenkanKeywords	= new DCHAR [nNeed+1] ;

		if (m_pAutoStartHenkanKeywords != NULL) {
			LPDSTR	pwDest		= m_pAutoStartHenkanKeywords ;
			LPCDSTR	pwDestEnd	= pwDest + nNeed + 1 ;

			pSrc		= pwText ;
			pSrcLast	= pwText + nTextLen ;
			while (pSrc < pSrcLast && *pSrc != TEXT ('\0')) {
				n		= lstrlenW (pSrc) ;
				if (n > 0) {
					int	nDest ;

					nDest	= wcstodcs_n (pwDest, pwDestEnd - pwDest, pSrc, n) ;
					pwDest	+= nDest ;
					if (pwDest < pwDestEnd)
						*pwDest ++	= L'\0' ;
				}
				pSrc	+= n + 1 ;
			}
			if (pwDest < pwDestEnd)
				*pwDest ++	= L'\0' ;
			m_iNumAutoStartHenkanKeywords	= iNumKeywords ;
		} else {
			m_iNumAutoStartHenkanKeywords	= 0 ;
		}
	} else {
		m_pAutoStartHenkanKeywords	= NULL ;
		m_iNumAutoStartHenkanKeywords	= 0 ;
	}
	return ;
}

/*========================================================================
 *	private functions for colorface
 */
static	BOOL	bIsValidColor		(int) ;
static	BOOL	bIsValidLineType	(int) ;

BOOL
CImeConfig::_bLoadColorfaceSetting ()
{
	static	const MYCOLORFACESET		_srDefaultColorFaces []	= {
		/*	���ϊ�������B*/
		{ MYCOLOR_TEXTAUTO,			/* ����(����) */	/* �����F�B*/
		  MYCOLOR_BACKAUTO,			/* ����(�w�i) */ 	/* �w�i�F�B*/
		  MYCOLOR_TEXTAUTO,			/* ����(����) */	/* �����F�B*/
		  MYLINE_THIN_DITHER,		/* �f�B�U(��) */	/* �����^�C�v�B*/
		},
		/*	�ϊ�������B*/
		{ MYCOLOR_HIGHLIGHTTEXT,	/* �I������(����) */	/* �����F�B*/
		  MYCOLOR_HIGHLIGHT,		/* �I������(�w�i) */	/* �w�i�F�B*/
		  MYCOLOR_TEXTAUTO,			/* ����(����) */	 	/* �����F�B*/
		  MYLINE_NO,				/* �Ȃ� */				/* �����^�C�v�B*/
		},
	} ;

	if (! _bLoadColorfaceSettingFromRegistry (_srDefaultColorFaces)) 
		memcpy (m_rImeColorFaces, _srDefaultColorFaces, sizeof (m_rImeColorFaces)) ;
	return	TRUE ; 
}

BOOL
CImeConfig::_bLoadColorfaceSettingFromRegistry (
	const MYCOLORFACESET*	pDefaultColorFaces)
{
	HKEY	hSubKey ;
	BOOL	bRetval	= FALSE ;
	BYTE	rbStyles [MYARRAYSIZE (m_rImeColorFaces) * 4] ;
	int		i ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_COLORFACE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 		lResult ;
		DWORD		dwType, cbData ;
		const BYTE*	pbData ;

		lResult	= RegQueryValueExW (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData != sizeof (rbStyles))
			goto	skip_error ;

		(void) RegQueryValueExW (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, (BYTE*)rbStyles, &cbData) ;

		pbData	= rbStyles ;
		for (i = 0 ; i < MYARRAYSIZE (m_rImeColorFaces) ; i ++) {
			int		nTextColor, nBackColor, nUnderLineColor, nUnderLineType ;

			nTextColor		= *pbData ++ ;
			nTextColor		= bIsValidColor (nTextColor)? nTextColor : pDefaultColorFaces [i].m_nTextColor ;
			m_rImeColorFaces [i].m_nTextColor		= nTextColor ;	
			nBackColor		= *pbData ++ ;
			nBackColor		= bIsValidColor (nBackColor)? nBackColor : pDefaultColorFaces [i].m_nBackColor ;
			m_rImeColorFaces [i].m_nBackColor		= nBackColor ;
			nUnderLineColor	= *pbData ++ ;
			nUnderLineColor	= bIsValidColor (nUnderLineColor)? nUnderLineColor : pDefaultColorFaces [i].m_nUnderLineColor ;
			m_rImeColorFaces [i].m_nUnderLineColor	= nUnderLineColor ;
			nUnderLineType	= *pbData ++ ;
			nUnderLineType	=  bIsValidLineType (nUnderLineType)? nUnderLineType : pDefaultColorFaces [i].m_nUnderLineType ;
			m_rImeColorFaces [i].m_nUnderLineType	= nUnderLineType ;
		}
		bRetval		= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	return	bRetval ;
}

void
CImeConfig::_vInitializeDefaultFont ()
{
	HKEY	hSubKey ;
	LOGFONT	lf ;
	NONCLIENTMETRICS	param ;

	memset (&m_lfDefault, 0, sizeof (LOGFONT)) ;

	memset (&param, 0, sizeof (param)) ;
	memset (&lf, 0, sizeof (LOGFONT)) ;
	param.cbSize	= sizeof (param) ;
	if (SystemParametersInfo (SPI_GETNONCLIENTMETRICS, param.cbSize, &param, 0)) {
		memcpy (&lf, &param.lfMessageFont, sizeof (LOGFONT)) ;
		m_iDefaultFontSize	= lf.lfHeight ;
	} else {
		if (GetObject (GetStockObject (DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf) > 0) {
			m_iDefaultFontSize	= lf.lfHeight ;
		}
	}
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_COLORFACE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 	lResult ;
		DWORD	dwType, cbData ;
		WCHAR	bufFaceName [LF_FACESIZE] ;
		DWORD	dwFontSize ;

		cbData	= 0 ;
		lResult	= RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_SZ && cbData <= sizeof (bufFaceName)) {
			cbData	= sizeof (bufFaceName) ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONT, NULL, &dwType, (BYTE*)bufFaceName, &cbData) ;

			memcpy (lf.lfFaceName, bufFaceName, LF_FACESIZE * sizeof (WCHAR)) ;
		}
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			cbData	= sizeof (DWORD) ;
			(void) RegQueryValueExW (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, (BYTE*)&dwFontSize, &cbData) ;

			m_iDefaultFontSize = (int) dwFontSize ;
		}
		RegCloseKey (hSubKey) ;
	}
	memcpy (&m_lfDefault, &lf, sizeof (LOGFONT)) ;
	return ;
}


BOOL
bIsValidColor (int nColorType)
{
	return	(nColorType < 0 || nColorType >= MAX_MYCOLOR) ? FALSE : TRUE ;
}

BOOL
bIsValidLineType (int nLineType)
{
	return	(nLineType < 0 || nLineType >= MAX_MYLINE)? FALSE : TRUE ;
}




/*
 */
BOOL
CImeConfig::_bParseBSEncodedString (
	LPCWSTR*	ppwSrc,
	LPWSTR		pwDest,
	int			nDestSize,
	BOOL*		pbTerminated)
{
	LPCWSTR	pwSrc ;
	LPWSTR	pwDestLast ;
	int		nCH ;

	pwSrc		= *ppwSrc ;
	pwDestLast	= pwDest + nDestSize ;
	while (*pwSrc != L'\0' && pwDest < pwDestLast) {
		if (*pwSrc == L'\\') {
			pwSrc	++ ;
			nCH		= *pwSrc ;
			if (nCH == L'\0') {
				break ;
			} else if (nCH == L'0') {
				/* �I�[�B*/
				pwSrc ++ ;
				break ;
			} else {
				*pwDest ++	= nCH ;
			}
		} else {
			*pwDest ++	= *pwSrc ;
		}
		pwSrc	++ ;
	}
	if (pwDest < pwDestLast)
		*pwDest	= L'\0' ;
	*pbTerminated	= (*pwSrc == L'\0') ;
	*ppwSrc			= pwSrc ;
	return	TRUE ;
}

int
CImeConfig::_iDecodeStringPairList (
	LPCWSTR					pwEncodedString,
	struct TStringPair*		pDestBuffer,
	int						iBufferSize)
{
	struct TStringPair*		pDest ;
	struct TStringPair*		pDestEnd ;
	LPCWSTR	pwSrc ;
	WCHAR	bufLeft [BUFSIZE_STRPAIR], bufRight [BUFSIZE_STRPAIR] ;
	BOOL	bTerminated ;

	pwSrc			= pwEncodedString ;
	pDest			= pDestBuffer ;
	pDestEnd		= pDestBuffer + iBufferSize ;
	while (*pwSrc != L'\0' && pDest < pDestEnd) {
		int	n ;

		if (! _bParseBSEncodedString (&pwSrc, bufLeft, MYARRAYSIZE (bufLeft) - 1, &bTerminated) || bTerminated) {
			break ;
		}
		bufLeft [MYARRAYSIZE (bufLeft) - 1]	= L'\0' ;

		if (! _bParseBSEncodedString (&pwSrc, bufRight, MYARRAYSIZE (bufRight) - 1, &bTerminated) || ! bTerminated) {
			break ;
		}
		bufRight [MYARRAYSIZE (bufRight) - 1]	= L'\0' ;

		n	= wcstodcs_n (pDest->m_bufLeft, ARRAYSIZE (pDest->m_bufLeft)-1,  bufLeft,   lstrlenW (bufLeft)) ;
		pDest->m_bufLeft [n]	= L'\0' ;
		n	= wcstodcs_n (pDest->m_bufRight, ARRAYSIZE (pDest->m_bufRight)-1, bufRight, lstrlenW (bufRight)) ;
		pDest->m_bufRight [n]	= L'\0' ;

		if (*pwSrc != L'\0')
			break ;
		pwSrc	++ ;
		pDest	++ ;
	}
	return	pDest - pDestBuffer ;
}

/*========================================================================
 *	private functions for RuleTreeNode
 */
struct TSkkBaseRuleT1 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextTree ;
	struct {
		LPCWSTR	_strKata ;
		LPCWSTR	_strHira ;
	}	_case ;
} ;

struct TSkkBaseRuleT2 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextTree ;
	LPCWSTR	_strOutput ;
} ;

struct TSkkBaseRuleT3 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextTree ;
	int		_nFunction ;
} ;

static struct TSkkBaseRuleT1	_rT1 []	= {
	{ L"a",		NULL,	0,	{ L"�A",	L"��" } },
	{ L"bb",	L"b",	0,	{ L"�b",	L"��" } },		{ L"ba",	NULL,	0,	{ L"�o",	L"��" } },
	{ L"be",	NULL,	0,	{ L"�x",	L"��" } },		{ L"bi",	NULL,	0,	{ L"�r",	L"��" } },
	{ L"bo",	NULL,	0,	{ L"�{",	L"��" } },		{ L"bu",	NULL,	0,	{ L"�u",	L"��" } },
    { L"bya",	NULL,	0,	{ L"�r��",	L"�т�" } },	{ L"bye",	NULL,	0,	{ L"�r�F",	L"�т�" } },
	{ L"byi",	NULL,	0,	{ L"�r�B",	L"�т�" } },	{ L"byo",	NULL,	0,	{ L"�r��",	L"�т�" } },
	{ L"byu",	NULL,	0,	{ L"�r��",	L"�т�" } },
    { L"cc",	L"c",	0,	{ L"�b",	L"��" } },		{ L"cha",	NULL,	0,	{ L"�`��",	L"����" } },
    { L"che",	NULL,	0,	{ L"�`�F",	L"����" } },	{ L"chi",	NULL,	0,	{ L"�`",	L"��" } },
    { L"cho",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"chu",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"cya",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"cye",	NULL,	0,	{ L"�`�F",	L"����" } },
	{ L"cyi",	NULL,	0,	{ L"�`�B",	L"����" } },	{ L"cyo",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"cyu",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"dd",	L"d",	0,	{ L"�b",	L"��" } },
	{ L"da",	NULL,	0,	{ L"�_",	L"��" } },		{ L"de",	NULL,	0,	{ L"�f",	L"��" } },
	{ L"dha",	NULL,	0,	{ L"�f��",	L"�ł�" } },	{ L"dhe",	NULL,	0,	{ L"�f�F",	L"�ł�" } },
	{ L"dhi",	NULL,	0,	{ L"�f�B",	L"�ł�" } },	{ L"dho",	NULL,	0,	{ L"�f��",	L"�ł�" } },
	{ L"dhu",	NULL,	0,	{ L"�f��",	L"�ł�" } },	{ L"di",	NULL,	0,	{ L"�a",	L"��" } },
	{ L"do",	NULL,	0,	{ L"�h",	L"��" } },		{ L"du",	NULL,	0,	{ L"�d",	L"��" } },
	{ L"dya",	NULL,	0,	{ L"�a��",	L"����" } },	{ L"dye",	NULL,	0,	{ L"�a�F",	L"����" } },
	{ L"dyi",	NULL,	0,	{ L"�a�B",	L"����" } },	{ L"dyo",	NULL,	0,	{ L"�a��",	L"����" } },
	{ L"dyu",	NULL,	0,	{ L"�a��",	L"����" } },
	{ L"e",		NULL,	0,	{ L"�G",	L"��" } },
	{ L"ff",	L"f",	0,	{ L"�b",	L"��" } },		{ L"fa",	NULL,	0,	{ L"�t�@",	L"�ӂ�" } },
	{ L"fe",	NULL,	0,	{ L"�t�F",	L"�ӂ�" } },	{ L"fi",	NULL,	0,	{ L"�t�B",	L"�ӂ�" } },
	{ L"fo",	NULL,	0,	{ L"�t�H",	L"�ӂ�" } },	{ L"fu",	NULL,	0,	{ L"�t",	L"��" } },
	{ L"fya",	NULL,	0,	{ L"�t��",	L"�ӂ�" } },	{ L"fye",	NULL,	0,	{ L"�t�F",	L"�ӂ�" } },
	{ L"fyi",	NULL,	0,	{ L"�t�B",	L"�ӂ�" } },	{ L"fyo",	NULL,	0,	{ L"�t��",	L"�ӂ�" } },
	{ L"fyu",	NULL,	0,	{ L"�t��",	L"�ӂ�" } },
	{ L"gg",	L"g",	0,	{ L"�b",	L"��" } },		{ L"ga",	NULL,	0,	{ L"�K",	L"��" } },
	{ L"ge",	NULL,	0,	{ L"�Q",	L"��" } },		{ L"gi",	NULL,	0,	{ L"�M",	L"��" } },
	{ L"go",	NULL,	0,	{ L"�S",	L"��" } },		{ L"gu",	NULL,	0,	{ L"�O",	L"��" } },
	{ L"gya",	NULL,	0,	{ L"�M��",	L"����" } },	{ L"gye",	NULL,	0,	{ L"�M�F",	L"����" } },
	{ L"gyi",	NULL,	0,	{ L"�M�B",	L"����" } },	{ L"gyo",	NULL,	0,	{ L"�M��",	L"����" } },
	{ L"gyu",	NULL,	0,	{ L"�M��",	L"����" } },
	//{ L"h", L"", { L"�I", L"��" } },
	{ L"hh",	L"h",	0,	{ L"�b",	L"��" } },
	{ L"ha",	NULL,	0,	{ L"�n",	L"��" } },		{ L"he",	NULL,	0,	{ L"�w",	L"��" } },
	{ L"hi",	NULL,	0,	{ L"�q",	L"��" } },		{ L"ho",	NULL,	0,	{ L"�z",	L"��" } },
	{ L"hu",	NULL,	0,	{ L"�t",	L"��" } },		{ L"hya",	NULL,	0,	{ L"�q��",	L"�Ђ�" } },
	{ L"hye",	NULL,	0,	{ L"�q�F",	L"�Ђ�" } },	{ L"hyi",	NULL,	0,	{ L"�q�B",	L"�Ђ�" } },
	{ L"hyo",	NULL,	0,	{ L"�q��",	L"�Ђ�" } },	{ L"hyu",	NULL,	0,	{ L"�q��",	L"�Ђ�" } },
	{ L"i",		NULL,	0,	{ L"�C",	L"��" } },		{ L"jj",	L"j",	0,	{ L"�b",	L"��" } },
	{ L"ja",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"je",	NULL,	0,	{ L"�W�F",	L"����" } },
	{ L"ji",	NULL,	0,	{ L"�W",	L"��" } },		{ L"jo",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"ju",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"jya",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"jye",	NULL,	0,	{ L"�W�F",	L"����" } },	{ L"jyi",	NULL,	0,	{ L"�W�B",	L"����" } },
	{ L"jyo",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"jyu",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"kk",	L"k",	0,	{ L"�b",	L"��" } },		{ L"ka",	NULL,	0,	{ L"�J",	L"��" } },
	{ L"ke",	NULL,	0,	{ L"�P",	L"��" } },		{ L"ki",	NULL,	0,	{ L"�L",	L"��" } },
	{ L"ko",	NULL,	0,	{ L"�R",	L"��" } },		{ L"ku",	NULL,	0,	{ L"�N",	L"��" } },
	{ L"kya",	NULL,	0,	{ L"�L��",	L"����" } },	{ L"kye",	NULL,	0,	{ L"�L�F",	L"����" } },
	{ L"kyi",	NULL,	0,	{ L"�L�B",	L"����" } },	{ L"kyo",	NULL,	0,	{ L"�L��",	L"����" } },
	{ L"kyu",	NULL,	0,	{ L"�L��",	L"����" } },
	{ L"ma",	NULL,	0,	{ L"�}",	L"��" } },		{ L"me",	NULL,	0,	{ L"��",	L"��" } },
	{ L"mi",	NULL,	0,	{ L"�~",	L"��" } },		{ L"mo",	NULL,	0,	{ L"��",	L"��" } },
	{ L"mu",	NULL,	0,	{ L"��",	L"��" } },		{ L"mya",	NULL,	0,	{ L"�~��",	L"�݂�" } },
	{ L"mye",	NULL,	0,	{ L"�~�F",	L"�݂�" } },	{ L"myi",	NULL,	0,	{ L"�~�B",	L"�݂�" } },
	{ L"myo",	NULL,	0,	{ L"�~��",	L"�݂�" } },	{ L"myu",	NULL,	0,	{ L"�~��",	L"�݂�" } },
	{ L"n",		NULL,	0,	{ L"��",	L"��" } },		{ L"n'",	NULL,	0,	{ L"��",	L"��" } },
	{ L"na",	NULL,	0,	{ L"�i",	L"��" } },		{ L"ne",	NULL,	0,	{ L"�l",	L"��" } },
	{ L"ni",	NULL,	0,	{ L"�j",	L"��" } },		{ L"nn",	NULL,	0,	{ L"��",	L"��" } },
	{ L"no",	NULL,	0,	{ L"�m",	L"��" } },		{ L"nu",	NULL,	0,	{ L"�k",	L"��" } },
	{ L"nya",	NULL,	0,	{ L"�j��",	L"�ɂ�" } },	{ L"nye",	NULL,	0,	{ L"�j�F",	L"�ɂ�" } },
	{ L"nyi",	NULL,	0,	{ L"�j�B",	L"�ɂ�" } },	{ L"nyo",	NULL,	0,	{ L"�j��",	L"�ɂ�" } },
	{ L"nyu",	NULL,	0,	{ L"�j��",	L"�ɂ�" } },	
	{ L"o",		NULL,	1,	{ L"�I",	L"��" } },
	{ L"pp",	L"p",	0,	{ L"�b",	L"��" } },		{ L"pa",	NULL,	0,	{ L"�p",	L"��" } },
	{ L"pe",	NULL,	0,	{ L"�y",	L"��" } },		{ L"pi",	NULL,	0,	{ L"�s",	L"��" } },
	{ L"po",	NULL,	0,	{ L"�|",	L"��" } },		{ L"pu",	NULL,	0,	{ L"�v",	L"��" } },
	{ L"pya",	NULL,	0,	{ L"�s��",	L"�҂�" } },	{ L"pye",	NULL,	0,	{ L"�s�F",	L"�҂�" } },
	{ L"pyi",	NULL,	0,	{ L"�s�B",	L"�҂�" } },	{ L"pyo",	NULL,	0,	{ L"�s��",	L"�҂�" } },
	{ L"pyu",	NULL,	0,	{ L"�s��",	L"�҂�" } },
	{ L"rr",	L"r",	0,	{ L"�b",	L"��" } },		{ L"ra",	NULL,	0,	{ L"��",	L"��" } },
	{ L"re",	NULL,	0,	{ L"��",	L"��" } },		{ L"ri",	NULL,	0,	{ L"��",	L"��" } },
	{ L"ro",	NULL,	0,	{ L"��",	L"��" } },		{ L"ru",	NULL,	0,	{ L"��",	L"��" } },
	{ L"rya",	NULL,	0,	{ L"����",	L"���" } },	{ L"rye",	NULL,	0,	{ L"���F",	L"�肥" } },
	{ L"ryi",	NULL,	0,	{ L"���B",	L"�股" } },	{ L"ryo",	NULL,	0,	{ L"����",	L"���" } },
	{ L"ryu",	NULL,	0,	{ L"����",	L"���" } },
	{ L"ss",	L"s",	0,	{ L"�b",	L"��" } },		{ L"sa",	NULL,	0,	{ L"�T",	L"��" } },
	{ L"se",	NULL,	0,	{ L"�Z",	L"��" } },		{ L"sha",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"she",	NULL,	0,	{ L"�V�F",	L"����" } },	{ L"shi",	NULL,	0,	{ L"�V",	L"��" } },
	{ L"sho",	NULL,	0,	{ L"�V��",	L"����" } },	{ L"shu",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"si",	NULL,	0,	{ L"�V",	L"��" } },		{ L"so",	NULL,	0,	{ L"�\",	L"��" } },
	{ L"su",	NULL,	0,	{ L"�X",	L"��" } },		{ L"sya",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"sye",	NULL,	0,	{ L"�V�F",	L"����" } },	{ L"syi",	NULL,	0,	{ L"�V�B",	L"����" } },
	{ L"syo",	NULL,	0,	{ L"�V��",	L"����" } },	{ L"syu",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"tt",	L"t",	0,	{ L"�b",	L"��" } },		{ L"ta",	NULL,	0,	{ L"�^",	L"��" } },
	{ L"te",	NULL,	0,	{ L"�e",	L"��" } },		{ L"tha",	NULL,	0,	{ L"�e�@",	L"�Ă�" } },
	{ L"the",	NULL,	0,	{ L"�e�F",	L"�Ă�" } },	{ L"thi",	NULL,	0,	{ L"�e�B",	L"�Ă�" } },
	{ L"tho",	NULL,	0,	{ L"�e��",	L"�Ă�" } },	{ L"thu",	NULL,	0,	{ L"�e��",	L"�Ă�" } },
	{ L"ti",	NULL,	0,	{ L"�`",	L"��" } },		{ L"to",	NULL,	0,	{ L"�g",	L"��" } },
	{ L"tsu",	NULL,	0,	{ L"�c",	L"��" } },		{ L"tu",	NULL,	0,	{ L"�c",	L"��" } },
	{ L"tya",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"tye",	NULL,	0,	{ L"�`�F",	L"����" } },
	{ L"tyi",	NULL,	0,	{ L"�`�B",	L"����" } },	{ L"tyo",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"tyu",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"u",		NULL,	0,	{ L"�E",	L"��" } },
	{ L"vv",	L"v",	0,	{ L"�b",	L"��" } },		{ L"va",	NULL,	0,	{ L"���@",	L"���J��" } },
	{ L"ve",	NULL,	0,	{ L"���F",	L"���J��" } },	{ L"vi",	NULL,	0,	{ L"���B",	L"���J��" } },
	{ L"vo",	NULL,	0,	{ L"���H",	L"���J��" } },	{ L"vu",	NULL,	0,	{ L"��",	L"���J" } },
	{ L"ww",	L"w",	0,	{ L"�b",	L"��" } },		{ L"wa",	NULL,	0,	{ L"��",	L"��" } },
	{ L"we",	NULL,	0,	{ L"�E�F",	L"����" } },	{ L"wi",	NULL,	0,	{ L"�E�B",	L"����" } },
	{ L"wo",	NULL,	0,	{ L"��",	L"��" } },		{ L"wu",	NULL,	0,	{ L"�E",	L"��" } },
	{ L"xx",	L"x",	0,	{ L"�b",	L"��" } },		{ L"xa",	NULL,	0,	{ L"�@",	L"��" } },
	{ L"xe",	NULL,	0,	{ L"�F",	L"��" } },		{ L"xi",	NULL,	0,	{ L"�B",	L"��" } },
	{ L"xka",	NULL,	0,	{ L"��",	L"��" } },		{ L"xke",	NULL,	0,	{ L"��",	L"��" } },
	{ L"xo",	NULL,	0,	{ L"�H",	L"��" } },		{ L"xtsu",	NULL,	0,	{ L"�b",	L"��" } },
	{ L"xtu",	NULL,	0,	{ L"�b",	L"��" } },		{ L"xu",	NULL,	0,	{ L"�D",	L"��" } },
	{ L"xwa",	NULL,	0,	{ L"��",	L"��" } },		{ L"xwe",	NULL,	0,	{ L"��",	L"��" } },
	{ L"xwi",	NULL,	0,	{ L"��",	L"��" } },		{ L"xya",	NULL,	0,	{ L"��",	L"��" } },
	{ L"xyo",	NULL,	0,	{ L"��",	L"��" } },		{ L"xyu",	NULL,	0,	{ L"��",	L"��" } },
	{ L"yy",	L"y",	0,	{ L"�b",	L"��" } },		{ L"ya",	NULL,	0,	{ L"��",	L"��" } },
	{ L"ye",	NULL,	0,	{ L"�C�F",	L"����" } },	{ L"yo",	NULL,	0,	{ L"��",	L"��" } },
	{ L"yu",	NULL,	0,	{ L"��",	L"��" } },
	{ L"zz",	L"z",	0,	{ L"�b",	L"��" } },		{ L"za",	NULL,	0,	{ L"�U",	L"��" } },
	{ L"ze",	NULL,	0,	{ L"�[",	L"��" } },		{ L"zi",	NULL,	0,	{ L"�W",	L"��" } },
	{ L"zo",	NULL,	0,	{ L"�]",	L"��" } },		{ L"zu",	NULL,	0,	{ L"�Y",	L"��" } },
	{ L"zya",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"zye",	NULL,	0,	{ L"�W�F",	L"����" } },
	{ L"zyi",	NULL,	0,	{ L"�W�B",	L"����" } },	{ L"zyo",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"zyu",	NULL,	0,	{ L"�W��",	L"����" } },
} ;

static struct TSkkBaseRuleT1	_rT1_1 []	= {
	{ L"\\?",	L"\\I",		0,	{ L"",		L"" } },
	{ L"h\\C",	L"\\I",		0,	{ L"�I",	L"��" } },
	{ L"h\\?",	L"h\\I",	0,	{ L"",		L"" } },
} ;

static struct TSkkBaseRuleT2	_rT2 []	= {
	{ L"z,",	NULL,	0,	L"�d" },	{ L"z-",	NULL,	0,	L"�`" },    { L"z.",	NULL,	0,	L"�c" },
	{ L"z/",	NULL,	0,	L"�E" },    { L"z[",	NULL,	0,	L"�w" },    { L"z]",	NULL,	0,	L"�x" },
    { L"zh",	NULL,	0,	L"��" },    { L"zj",	NULL,	0,	L"��" },    { L"zk",	NULL,	0,	L"��" },
	{ L"zl",	NULL,	0,	L"��" },    { L"-",		NULL,	0,	L"�[" },    { L":",		NULL,	0,	L"�F" },
    { L";",		NULL,	0,	L"�G" },    { L"?",		NULL,	0,	L"�H" },    { L"[",		NULL,	0,	L"�u" },
	{ L"]",		NULL,	0,	L"�v" },
//	{ L"z\\?d",	NULL,	0,	L"�b" },
} ;

static struct TSkkBaseRuleT3	_rT3 []	= {
	{ L".",		NULL,	0,	NFUNC_SKK_CURRENT_KUTEN },			{ L",",		NULL,	0,	NFUNC_SKK_CURRENT_TOUTEN },
	{ L"l",		NULL,	0,	NFUNC_SKK_LATIN_MODE },				{ L"q",		NULL,	0,	NFUNC_SKK_TOGGLE_KANA },
	{ L"L",		NULL,	0,	NFUNC_SKK_JISX0208_LATIN_MODE },	{ L"Q",		NULL,	0,	NFUNC_SKK_SET_HENKAN_POINT_SUBR },
	{ L"X",		NULL,	0,	NFUNC_SKK_PURGE_FROM_JISYO },		{ L"/",		NULL,	0,	NFUNC_SKK_ABBREV_MODE },
	{ L"$",		NULL,	0,	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT },
	{ L"@",		NULL,	0,	NFUNC_SKK_TODAY },					{ L"\\\\",	NULL,	0,	NFUNC_SKK_INPUT_BY_CODE_OR_MENU },
	{ L"\r",	NULL,	0,	NFUNC_SKK_KAKUTEI },
} ;

static struct TSkkBaseRuleT2	_rJisx0201_T2 []	= {
	{ L"a",		NULL, 0, L"�", }, 
    { L"bb",	L"b", 0, L"�", },	{ L"ba",	NULL, 0, L"��", },	{ L"be",	NULL, 0, L"��", }, 
    { L"bi",	NULL, 0, L"��", },	{ L"bo",	NULL, 0, L"��", },	{ L"bu",	NULL, 0, L"��", },	{ L"bya",	NULL, 0, L"�ެ", }, 
    { L"bye",	NULL, 0, L"�ު", },	{ L"byi",	NULL, 0, L"�ި", },	{ L"byo",	NULL, 0, L"�ޮ", },	{ L"byu",	NULL, 0, L"�ޭ", }, 
    { L"cc",	L"c", 0, L"�", },	{ L"cha",	NULL, 0, L"��", },	{ L"che",	NULL, 0, L"��", },	{ L"chi",	NULL, 0, L"�", }, 
    { L"cho",	NULL, 0, L"��", },  { L"chu",	NULL, 0, L"��", },	{ L"cya",	NULL, 0, L"��", },	{ L"cye",	NULL, 0, L"��", }, 
    { L"cyi",	NULL, 0, L"��", },  { L"cyo",	NULL, 0, L"��", },	{ L"cyu",	NULL, 0, L"��", }, 
    { L"dd",	L"d", 0, L"�", },	{ L"da",	NULL, 0, L"��", },	{ L"de",	NULL, 0, L"��", },	{ L"dha",	NULL, 0, L"�ެ", }, 
    { L"dhe",	NULL, 0, L"�ު", },	{ L"dhi",	NULL, 0, L"�ި", },	{ L"dho",	NULL, 0, L"�ޮ", },	{ L"dhu",	NULL, 0, L"�ޭ", }, 
    { L"di",	NULL, 0, L"��", },	{ L"do",	NULL, 0, L"��", },	{ L"du",	NULL, 0, L"��", },	{ L"dya",	NULL, 0, L"�ެ", }, 
    { L"dye",	NULL, 0, L"�ު", },	{ L"dyi",	NULL, 0, L"�ި", },	{ L"dyo",	NULL, 0, L"�ޮ", },	{ L"dyu",	NULL, 0, L"�ޭ", }, 
    { L"e",		NULL, 0, L"�", }, 
    { L"ff",	L"f", 0, L"�", },	{ L"fa",	NULL, 0, L"̧", },  { L"fe",	NULL, 0, L"̪", },  { L"fi",	NULL, 0, L"̨", }, 
    { L"fo",	NULL, 0, L"̫", },  { L"fu",	NULL, 0, L"�", },	{ L"fya",	NULL, 0, L"̬", },  { L"fye",	NULL, 0, L"̪", }, 
    { L"fyi",	NULL, 0, L"̨", },  { L"fyo",	NULL, 0, L"̮", },  { L"fyu",	NULL, 0, L"̭", },  { L"gg",	L"g", 0, L"�", }, 
    { L"ga",	NULL, 0, L"��", },  { L"ge",	NULL, 0, L"��", },  { L"gi",	NULL, 0, L"��", },  { L"go",	NULL, 0, L"��", }, 
    { L"gu",	NULL, 0, L"��", },  { L"gya",	NULL, 0, L"�ެ", },	{ L"gye",	NULL, 0, L"�ު", },	{ L"gyi",	NULL, 0, L"�ި", }, 
    { L"gyo",	NULL, 0, L"�ޮ", },	{ L"gyu",	NULL, 0, L"�ޭ", }, 
    { L"ha",	NULL, 0, L"�", },	{ L"he",	NULL, 0, L"�", },	{ L"hi",	NULL, 0, L"�", },	{ L"ho",	NULL, 0, L"�", }, 
    { L"hu",	NULL, 0, L"�", },	{ L"hya",	NULL, 0, L"ˬ", },  { L"hye",	NULL, 0, L"˪", },  { L"hyi",	NULL, 0, L"˨", }, 
    { L"hyo",	NULL, 0, L"ˮ", },  { L"hyu",	NULL, 0, L"˭", },  { L"i",		NULL, 0, L"�", }, 
    { L"jj",	L"j", 0, L"�", },	{ L"ja",	NULL, 0, L"�ެ", },	{ L"je",	NULL, 0, L"�ު", },	{ L"ji",	NULL, 0, L"��", }, 
    { L"jo",	NULL, 0, L"�ޮ", },	{ L"ju",	NULL, 0, L"�ޭ", },	{ L"jya",	NULL, 0, L"�ެ", },	{ L"jye",	NULL, 0, L"�ު", }, 
    { L"jyi",	NULL, 0, L"�ި", },	{ L"jyo",	NULL, 0, L"�ޮ", },	{ L"jyu",	NULL, 0, L"�ޭ", }, 
    { L"kk",	L"k", 0, L"�", },	{ L"ka",	NULL, 0, L"�", },	{ L"ke",	NULL, 0, L"�", },	{ L"ki",	NULL, 0, L"�", }, 
    { L"ko",	NULL, 0, L"�", },	{ L"ku",	NULL, 0, L"�", },	{ L"kya",	NULL, 0, L"��", },  { L"kye",	NULL, 0, L"��", }, 
    { L"kyi",	NULL, 0, L"��", },	{ L"kyo",	NULL, 0, L"��", },  { L"kyu",	NULL, 0, L"��", }, 
    { L"mm",	L"m", 0, L"�", },	{ L"ma",	NULL, 0, L"�", },	{ L"me",	NULL, 0, L"�", },	{ L"mi",	NULL, 0, L"�", }, 
    { L"mo",	NULL, 0, L"�", },	{ L"mu",	NULL, 0, L"�", },	{ L"mya",	NULL, 0, L"Ь", },  { L"mye",	NULL, 0, L"Ъ", }, 
    { L"myi",	NULL, 0, L"Ш", },	{ L"myo",	NULL, 0, L"Ю", },	{ L"myu",	NULL, 0, L"Э", }, 
    { L"n",		NULL, 0, L"�", },	{ L"n'",	NULL, 0, L"�", },	{ L"na",	NULL, 0, L"�", },	{ L"ne",	NULL, 0, L"�", }, 
    { L"ni",	NULL, 0, L"�", },	{ L"nn",	NULL, 0, L"�", },	{ L"no",	NULL, 0, L"�", },	{ L"nu",	NULL, 0, L"�", }, 
    { L"nya",	NULL, 0, L"Ƭ", },	{ L"nye",	NULL, 0, L"ƪ", },  { L"nyi",	NULL, 0, L"ƨ", },  { L"nyo",	NULL, 0, L"Ʈ", }, 
    { L"nyu",	NULL, 0, L"ƭ", }, 
    { L"o",		NULL, 1, L"�", }, 
    { L"pp",	L"p", 0, L"�", },	{ L"pa",	NULL, 0, L"��", },  { L"pe",	NULL, 0, L"��", },  { L"pi",	NULL, 0, L"��", }, 
    { L"po",	NULL, 0, L"��", },	{ L"pu",	NULL, 0, L"��", },  { L"pya",	NULL, 0, L"�߬", },	{ L"pye",	NULL, 0, L"�ߪ", }, 
    { L"pyi",	NULL, 0, L"�ߨ", },	{ L"pyo",	NULL, 0, L"�߮", },	{ L"pyu",	NULL, 0, L"�߭", }, 
    { L"rr",	L"r", 0, L"�", },	{ L"ra",	NULL, 0, L"�", },	{ L"re",	NULL, 0, L"�", },	{ L"ri",	NULL, 0, L"�", }, 
    { L"ro",	NULL, 0, L"�", },	{ L"ru",	NULL, 0, L"�", },	{ L"rya",	NULL, 0, L"ج", },  { L"rye",	NULL, 0, L"ت", }, 
    { L"ryi",	NULL, 0, L"ب", },	{ L"ryo",	NULL, 0, L"خ", },  { L"ryu",	NULL, 0, L"ح", }, 
    { L"ss",	L"s", 0, L"�", },	{ L"sa",	NULL, 0, L"�", },	{ L"se",	NULL, 0, L"�", },	{ L"sha",	NULL, 0, L"��", }, 
    { L"she",	NULL, 0, L"��", },	{ L"shi",	NULL, 0, L"�", },	{ L"sho",	NULL, 0, L"��", },  { L"shu",	NULL, 0, L"��", }, 
    { L"si",	NULL, 0, L"�", },	{ L"so",	NULL, 0, L"�", },	{ L"su",	NULL, 0, L"�", },	{ L"sya",	NULL, 0, L"��", }, 
    { L"sye",	NULL, 0, L"��", },	{ L"syi",	NULL, 0, L"��", },  { L"syo",	NULL, 0, L"��", },  { L"syu",	NULL, 0, L"��", }, 
    { L"tt",	L"t", 0, L"�", },	{ L"ta",	NULL, 0, L"�", },	{ L"te",	NULL, 0, L"�", },	{ L"tha",	NULL, 0, L"ç", }, 
    { L"the",	NULL, 0, L"ê", },  { L"thi",	NULL, 0, L"è", },  { L"tho",	NULL, 0, L"î", },  { L"thu",	NULL, 0, L"í", }, 
    { L"ti",	NULL, 0, L"�", },	{ L"to",	NULL, 0, L"�", },	{ L"tsu",	NULL, 0, L"�", },	{ L"tu",	NULL, 0, L"�", }, 
    { L"tya",	NULL, 0, L"��", },  { L"tye",	NULL, 0, L"��", },  { L"tyi",	NULL, 0, L"��", },	{ L"tyo",	NULL, 0, L"��", }, 
    { L"tyu",	NULL, 0, L"��", }, 
    { L"u",		NULL, 0, L"�", }, 
    { L"vv",	L"v", 0, L"�", },	{ L"va",	NULL, 0, L"�ާ", },	{ L"ve",	NULL, 0, L"�ު", },	{ L"vi",	NULL, 0, L"�ި", }, 
    { L"vo",	NULL, 0, L"�ޫ", },	{ L"vu",	NULL, 0, L"��", }, 
    { L"ww",	L"w", 0, L"�", },	{ L"wa",	NULL, 0, L"�", },	{ L"we",	NULL, 0, L"��", },  { L"wi",	NULL, 0, L"��", }, 
    { L"wo",	NULL, 0, L"�", },	{ L"wu",	NULL, 0, L"�", }, 
    { L"xx",	L"x", 0, L"�", },	{ L"xa",	NULL, 0, L"�", },	{ L"xe",	NULL, 0, L"�", },	{ L"xi",	NULL, 0, L"�", }, 
    { L"xka",	NULL, 0, L"�", },	{ L"xke",	NULL, 0, L"�", },	{ L"xo",	NULL, 0, L"�", },	{ L"xtsu",	NULL, 0, L"�", }, 
    { L"xtu",	NULL, 0, L"�", },	{ L"xu",	NULL, 0, L"�", },	{ L"xwa",	NULL, 0, L"�", },	{ L"xwe",	NULL, 0, L"�", }, 
    { L"xwi",	NULL, 0, L"�", },	{ L"xya",	NULL, 0, L"�", },	{ L"xyo",	NULL, 0, L"�", },	{ L"xyu",	NULL, 0, L"�", }, 
    { L"yy",	L"y", 0, L"�", },	{ L"ya",	NULL, 0, L"�", },	{ L"ye",	NULL, 0, L"��", },  { L"yo",	NULL, 0, L"�", }, 
    { L"yu",	NULL, 0, L"�", },	 
    { L"zz",	L"z", 0, L"�", },	{ L"z,",	NULL, 0, L"�d", },  { L"z-",	NULL, 0, L"�`", },  { L"z.",	NULL, 0, L"�c", }, 
    { L"z/",	NULL, 0, L"�", },	{ L"z[",	NULL, 0, L"�w", },  { L"z]",	NULL, 0, L"�x", },  { L"za",	NULL, 0, L"��", }, 
    { L"ze",	NULL, 0, L"��", },  { L"zh",	NULL, 0, L"��", },  { L"zi",	NULL, 0, L"��", },  { L"zj",	NULL, 0, L"��", }, 
    { L"zk",	NULL, 0, L"��", },	{ L"zl",	NULL, 0, L"��", },  { L"zo",	NULL, 0, L"��", },	{ L"zu",	NULL, 0, L"��", }, 
    { L"zya",	NULL, 0, L"�ެ", },	{ L"zye",	NULL, 0, L"�ު", },	{ L"zyi",	NULL, 0, L"�ި", },	{ L"zyo",	NULL, 0, L"�ޮ", }, 
    { L"zyu",	NULL, 0, L"�ޭ", }, 
	{ L",",		NULL, 0, L"�", },	{ L".",		NULL, 0, L"�", },	{ L"-",		NULL, 0, L"�", },	{ L":",		NULL, 0, L":", },
	{ L";",		NULL, 0, L";", },	{ L"?",		NULL, 0, L"?", },	{ L"[",		NULL, 0, L"�", },	{ L"]",		NULL, 0, L"�", },
	{ L"(",		NULL, 0, L"(", },	{ L"{",		NULL, 0, L"{", },
} ;

/*	oh�ϊ��̂��߂̃��[���B
 */
static struct TSkkBaseRuleT2	_rJisx0201_T2_1 []	= {
	{ L"\\?",	L"\\I",		0,	L"", },
	{ L"h\\C",	L"\\I",		0,	L"�", },
	{ L"h\\?",	L"h\\I",	0,	L"", },
} ;

static struct TSkkBaseRuleT3	_rJisx0201_T3 []	= {
	{ L"l",		NULL,	0,	NFUNC_SKK_LATIN_MODE },
    { L"q",		NULL,	0,	NFUNC_SKK_TOGGLE_KATAKANA },
    { L"L",		NULL,	0,	NFUNC_SKK_JISX0208_LATIN_MODE },	
    { L"Q",		NULL,	0,	NFUNC_SKK_SET_HENKAN_POINT_SUBR },
    { L"X",		NULL,	0,	NFUNC_SKK_PURGE_FROM_JISYO },
    { L"/",		NULL,	0,	NFUNC_SKK_ABBREV_MODE },
    { L"$",		NULL,	0,	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT },
	{ L"@",		NULL,	0,	NFUNC_SKK_TODAY },
    { L"\\\\",	NULL,	0,	NFUNC_SKK_INPUT_BY_CODE_OR_MENU },
    { L"\r",	NULL,	0,	NFUNC_SKK_KAKUTEI },
} ;

static struct TSkkBaseRuleT2	_rJisx0201Roman_T2 []	= {
	{ L"!", NULL, 0, L"!", },	{ L"\"",NULL, 0, L"\"" },  { L"#", NULL, 0, L"#", },  { L"$", NULL, 0, L"$", },  { L"%", NULL, 0, L"%", }, 
    { L"&", NULL, 0, L"&", },	{ L"'", NULL, 0, L"'", },  { L"(", NULL, 0, L"(", },  { L")", NULL, 0, L")", },  { L"*", NULL, 0, L"*", }, 
    { L"+", NULL, 0, L"+", },	{ L",", NULL, 0, L",", },  { L"-", NULL, 0, L"-", },  { L".", NULL, 0, L".", },  { L"/", NULL, 0, L"/", }, 
    { L"0", NULL, 0, L"0", },	{ L"1", NULL, 0, L"1", },  { L"2", NULL, 0, L"2", },  { L"3", NULL, 0, L"3", },  { L"4", NULL, 0, L"4", }, 
    { L"5", NULL, 0, L"5", },	{ L"6", NULL, 0, L"6", },  { L"7", NULL, 0, L"7", },  { L"8", NULL, 0, L"8", },  { L"9", NULL, 0, L"9", }, 
    { L":", NULL, 0, L":", },	{ L";", NULL, 0, L";", },  { L"<", NULL, 0, L"<", },  { L"=", NULL, 0, L"=", },  { L">", NULL, 0, L">", }, 
    { L"?", NULL, 0, L"?", },	{ L"@", NULL, 0, L"@", }, 
    { L"A", NULL, 0, L"A", },	{ L"B", NULL, 0, L"B", },  { L"C", NULL, 0, L"C", },  { L"D", NULL, 0, L"D", },  { L"E", NULL, 0, L"E", }, 
    { L"F", NULL, 0, L"F", },	{ L"G", NULL, 0, L"G", },  { L"H", NULL, 0, L"H", },  { L"I", NULL, 0, L"I", },  { L"J", NULL, 0, L"J", }, 
    { L"K", NULL, 0, L"K", },	{ L"L", NULL, 0, L"L", },  { L"M", NULL, 0, L"M", },  { L"N", NULL, 0, L"N", },  { L"O", NULL, 0, L"O", }, 
    { L"P", NULL, 0, L"P", },	{ L"Q", NULL, 0, L"Q", },  { L"R", NULL, 0, L"R", },  { L"S", NULL, 0, L"S", },  { L"T", NULL, 0, L"T", }, 
    { L"U", NULL, 0, L"U", },	{ L"V", NULL, 0, L"V", },  { L"W", NULL, 0, L"W", },  { L"X", NULL, 0, L"X", },  { L"Y", NULL, 0, L"Y", }, 
    { L"Z", NULL, 0, L"Z", }, 
    { L"[", NULL, 0, L"[", },	{ L"\\\\", NULL, 0, L"\\\\", },  { L"]", NULL, 0, L"]", },  { L"^", NULL, 0, L"^", },
	{ L"_", NULL, 0, L"_", },	{ L"`", NULL, 0, L"`", }, 
    { L"a", NULL, 0, L"a", },	{ L"b", NULL, 0, L"b", },  { L"c", NULL, 0, L"c", },  { L"d", NULL, 0, L"d", },  { L"e", NULL, 0, L"e", }, 
    { L"f", NULL, 0, L"f", },	{ L"g", NULL, 0, L"g", },  { L"h", NULL, 0, L"h", },  { L"i", NULL, 0, L"i", },  { L"j", NULL, 0, L"j", }, 
    { L"k", NULL, 0, L"k", },	{ L"l", NULL, 0, L"l", },  { L"m", NULL, 0, L"m", },  { L"n", NULL, 0, L"n", },  { L"o", NULL, 0, L"o", }, 
    { L"p", NULL, 0, L"p", },	{ L"q", NULL, 0, L"q", },  { L"r", NULL, 0, L"r", },  { L"s", NULL, 0, L"s", },  { L"t", NULL, 0, L"t", }, 
    { L"u", NULL, 0, L"u", },	{ L"v", NULL, 0, L"v", },  { L"w", NULL, 0, L"w", },  { L"x", NULL, 0, L"x", },  { L"y", NULL, 0, L"y", }, 
    { L"z", NULL, 0, L"z", }, 
    { L"{", NULL, 0, L"{", },	{ L"|", NULL, 0, L"|", },  { L"}", NULL, 0, L"}", },  { L"~", NULL, 0, L"~", }, 
} ;

BOOL
CImeConfig::_bInitializeDefaultRomaKanaRuleTree ()
{
	CSkkRuleTreeNode*	pRoot ;
	int		i, nPrefix, nNextState ;
	DCHAR	bufPrefix [32] ;
	DCHAR*	pPrefix ;

	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		m_rpSkkRuleTree [i]					= NULL ;
		m_rpSkkJisx0201RomanRuleTree [i]	= NULL ;
		m_rpSkkJisx0201RuleTree [i]			= NULL ;
	}

	/*	default �؂̏������B
	 */
	pRoot	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (_rT1) ; i ++) {
		int	nHira, nKata ;

		if (_rT1 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rT1 [i]._strState, lstrlenW (_rT1 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rT1 [i]._strNext       != NULL)? lstrlenW (_rT1 [i]._strNext)       : 0 ;
		nHira		= (_rT1 [i]._case._strHira != NULL)? lstrlenW (_rT1 [i]._case._strHira) : 0 ;
		nKata		= (_rT1 [i]._case._strKata != NULL)? lstrlenW (_rT1 [i]._case._strKata) : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, 0, pPrefix, nPrefix, _rT1 [i]._strNext, nNextState, _rT1 [i]._iNextTree, _rT1 [i]._case._strHira, nHira, _rT1 [i]._case._strKata, nKata)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	for (i = 0 ; i < MYARRAYSIZE (_rT2) ; i ++) {
		int	nOutput ;

		if (_rT2 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rT2 [i]._strState, lstrlenW (_rT2 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rT2 [i]._strNext   != NULL)? lstrlenW (_rT2 [i]._strNext)   : 0 ;
		nOutput		= (_rT2 [i]._strOutput != NULL)? lstrlenW (_rT2 [i]._strOutput) : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, 0, pPrefix, nPrefix, _rT2 [i]._strNext, nNextState, _rT2 [i]._iNextTree, _rT2 [i]._strOutput, nOutput)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	for (i = 0 ; i < MYARRAYSIZE (_rT3) ; i ++) {
		if (_rT3 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rT3 [i]._strState, lstrlenW (_rT3 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rT3 [i]._strNext   != NULL)? lstrlenW (_rT3 [i]._strNext)   : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, 0, pPrefix, nPrefix, _rT3 [i]._strNext, nNextState, _rT3 [i]._iNextTree, _rT3 [i]._nFunction)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	m_rpSkkRuleTree [0]	= pRoot ;

	/*	Rule#1 �؂̏������B
	 */
	pRoot	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (_rT1_1) ; i ++) {
		int	nHira, nKata ;

		if (_rT1_1 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rT1_1 [i]._strState, lstrlenW (_rT1_1 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rT1_1 [i]._strNext       != NULL)? lstrlenW (_rT1_1 [i]._strNext)       : 0 ;
		nHira		= (_rT1_1 [i]._case._strHira != NULL)? lstrlenW (_rT1_1 [i]._case._strHira) : 0 ;
		nKata		= (_rT1_1 [i]._case._strKata != NULL)? lstrlenW (_rT1_1 [i]._case._strKata) : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, 1, pPrefix, nPrefix, _rT1_1 [i]._strNext, nNextState, _rT1_1 [i]._iNextTree, _rT1_1 [i]._case._strHira, nHira, _rT1_1 [i]._case._strKata, nKata)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	m_rpSkkRuleTree [1]	= pRoot ;

	/*	jisx0201-base-rule-tree �̏������B
	 */
	pRoot	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (_rJisx0201_T2) ; i ++) {
		int	nOutput ;

		if (_rJisx0201_T2 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rJisx0201_T2 [i]._strState, lstrlenW (_rJisx0201_T2 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rJisx0201_T2 [i]._strNext   != NULL)? lstrlenW (_rJisx0201_T2 [i]._strNext)   : 0 ;
		nOutput		= (_rJisx0201_T2 [i]._strOutput != NULL)? lstrlenW (_rJisx0201_T2 [i]._strOutput) : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, RULETREENO_SKK_JISX0201_BASE, pPrefix, nPrefix, _rJisx0201_T2 [i]._strNext, nNextState, _rJisx0201_T2 [i]._iNextTree + RULETREENO_SKK_JISX0201_BASE, _rJisx0201_T2 [i]._strOutput, nOutput)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	for (i = 0 ; i < MYARRAYSIZE (_rJisx0201_T3) ; i ++) {
		if (_rJisx0201_T3 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rJisx0201_T3 [i]._strState, lstrlenW (_rJisx0201_T3 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rJisx0201_T3 [i]._strNext   != NULL)? lstrlenW (_rJisx0201_T3 [i]._strNext)   : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, RULETREENO_SKK_JISX0201_BASE, pPrefix, nPrefix, _rJisx0201_T3 [i]._strNext, nNextState, _rJisx0201_T3 [i]._iNextTree + RULETREENO_SKK_JISX0201_BASE, _rJisx0201_T3 [i]._nFunction)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	m_rpSkkJisx0201RuleTree [0]	= pRoot ;

	pRoot	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (_rJisx0201_T2_1) ; i ++) {
		int	nOutput ;

		if (_rJisx0201_T2_1 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rJisx0201_T2_1 [i]._strState, lstrlenW (_rJisx0201_T2_1 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rJisx0201_T2_1 [i]._strNext   != NULL)? lstrlenW (_rJisx0201_T2_1 [i]._strNext)   : 0 ;
		nOutput		= (_rJisx0201_T2_1 [i]._strOutput != NULL)? lstrlenW (_rJisx0201_T2_1 [i]._strOutput) : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, RULETREENO_SKK_JISX0201_BASE, pPrefix, nPrefix, _rJisx0201_T2_1 [i]._strNext, nNextState, _rJisx0201_T2_1 [i]._iNextTree + RULETREENO_SKK_JISX0201_BASE, _rJisx0201_T2_1 [i]._strOutput, nOutput)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	m_rpSkkJisx0201RuleTree [1]	= pRoot ;

	/*	jisx0201-roman-rule-tree �̏������B
	 */
	pRoot	= NULL ;
	for (i = 0 ; i < MYARRAYSIZE (_rJisx0201Roman_T2) ; i ++) {
		int	nOutput ;

		if (_rJisx0201Roman_T2 [i]._strState != NULL) {
			pPrefix		= bufPrefix ;
			nPrefix		= wcstodcs_n (bufPrefix, MYARRAYSIZE (bufPrefix), _rJisx0201Roman_T2 [i]._strState, lstrlenW (_rJisx0201Roman_T2 [i]._strState)) ;
		} else {
			pPrefix		= NULL ;
			nPrefix		= 0 ;
		}
		nNextState	= (_rJisx0201Roman_T2 [i]._strNext   != NULL)? lstrlenW (_rJisx0201Roman_T2 [i]._strNext)   : 0 ;
		nOutput		= (_rJisx0201Roman_T2 [i]._strOutput != NULL)? lstrlenW (_rJisx0201Roman_T2 [i]._strOutput) : 0 ;
		if (! CSkkRuleTreeNode::bAddRule (&pRoot, RULETREENO_SKK_JISX0201_ROMAN, pPrefix, nPrefix, _rJisx0201Roman_T2 [i]._strNext, nNextState, _rJisx0201Roman_T2 [i]._iNextTree + RULETREENO_SKK_JISX0201_ROMAN, _rJisx0201Roman_T2 [i]._strOutput, nOutput)) {
			CSkkRuleTreeNode::vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	m_rpSkkJisx0201RomanRuleTree [0]	= pRoot ;
	return	TRUE ;
}

