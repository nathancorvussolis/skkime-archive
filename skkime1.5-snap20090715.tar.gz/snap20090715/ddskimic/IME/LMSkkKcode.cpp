#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "ImeDoc.h"
#include "ImeBuffer.h"
#include "TSearchSession.h"
#include "keymap.h"
#include "jstring.h"
#include "TMarker.h"
#include "TMSG.h"
#include "ImeConfig.h"

/*================================================================ skk-input-by-code-or-menu
 */
int
CImeDoc::LM_bSkkInputByCodeOrMenu (
	CImeDoc*				pThis)
{
	int		iKcodeCharset ;
	WCHAR	bufText   [MAXCOMPLEN] ;
	int		nText ;
	LPDSTR	pwText ;

	iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig) ;

	/*	JIS �� EUC �Ȃ�΋�_�R�[�h�͑��݂��邾�낤���ǁAUnicode �ɂ͑����Ȃ��B���ƁAShiftJIS �œ��ꂽ���Ƃ�
	 *	���������v�]�͂Ȃ��̂��낤���H
	 *
	 *	JIS �� EUC ������������ KUTEN ��ǉ��B�����łȂ��ꍇ�ɂ͒��ڃR�[�h�݂̂Ƃ���A���ȁBskk-kcode-charset
	 *	�� Enum �^�ɂ��āA
	 *
	 *		japanese-jisx0208, katakana-jisx0201
	 *
	 *	�c�Ȃ�قǁAEUC �͂Ȃ��̂��B�������Ajisx0201 ���āA�ǂ�����ē��͂���́H ���̂�����͏C�����Ȃ��Ƒʖ�
	 *	�������B�܂�Ajapanese-jis �� unicode ���炢�Ɋɂ��ݒ�c�Ƃ���H
	 *
	 *	��_�R�[�h�Ƃ����̂́Axx-xx �Ƃ����`���炵���B
	 */
	switch (iKcodeCharset) {
	case	KCODE_CHARSET_KATAKANA_JISX0201:
		/* ��͂Ȃ��񂶂�c�B*/
		nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText) - 1, L"7/8 bits code for %s (nn or CR for Jump Menu): ", L"katakana-jisx0201") ;
		break ;
	case	KCODE_CHARSET_JAPANESE_JISX0208:
		/* ��_OK */
		nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText) - 1, L"7/8 bits or KUTEN code for %s (00nn or CR for Jump Menu): ", L"japanese-jisx0208") ;
		break ;
	case	KCODE_CHARSET_JAPANESE_JISX0212:
		/* ��_OK */
		nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText) - 1, L"7/8 bits or KUTEN code for %s (00nn or CR for Jump Menu): ", L"japanese-jisx0212") ;
		break ;
	case	KCODE_CHARSET_UNICODE:
	default:
		/* ��_�͎g���Ȃ��B*/
		nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText) - 1, L"8 bits code for %s (00nn or CR for Jump Menu): ", L"unicode") ;
		break ;
	}

	pwText		= (LPDSTR) pThis->pAlloca (nText * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwText == NULL)
		return	LMR_ERROR ;
	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;
	nText	= wcstodcs (pwText, nText, bufText, nText) ;
	pThis->vSetRegConstString	(LMREGARG_0,	pwText,		nText) ;
	pThis->vSetRegBool			(LMREGARG_1, LFALSE) ;
	if (! pThis->bCall (LM_bReadFromMinibuffer, LM_bSkkInputByCodeOrMenu_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu_Exit (
	CImeDoc*		pThis)
{
	pThis->vPopReg (LMREG_0) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR		pReadTop, pReadEnd, pRead ;
	LPCDSTR		pwResult ;
	int			nRead, nResult ;

	if (pThis->bSignalp ()) {
		pThis->vClearSignals () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL || 
		! pThis->bGetRegConstString (LMREGARG_RETVAL, &pwResult, &nResult)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}

	/* �O��̋󔒂͏������ׂ����ȁc�B*/
	pReadEnd	= pwResult + nResult - 1 ;
	pReadTop	= pwResult ;
	while (pReadEnd >= pReadTop && isdspace (*pReadEnd))
		pReadEnd	-- ;
	while (pReadTop <= pReadEnd && isdspace (*pReadTop))
		pReadTop	++ ;
	pRead		= pReadTop ;
	nRead		= (pReadTop <= pReadEnd)? ((pReadEnd - pReadTop) + 1) : 0 ;
	if (nRead > 0) {
		int		n1 = 0, n2 = 0, ch, iKcodeCharset, n ;
		BOOL	bKuten, bSingleByte ;
		DCHAR	wch ;

		iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig) ;
		switch (iKcodeCharset) {
		case	KCODE_CHARSET_KATAKANA_JISX0201:
			/* ��͂Ȃ��񂶂�c�B*/
			bKuten		= FALSE ;
			bSingleByte	= TRUE ;
			break ;
		case	KCODE_CHARSET_JAPANESE_JISX0208:
			/* ��_OK */
			bKuten		= TRUE ;
			bSingleByte	= FALSE ;
			break ;
		case	KCODE_CHARSET_JAPANESE_JISX0212:
			/* ��_OK */
			bKuten		= TRUE ;
			bSingleByte	= FALSE ;
			break ;
		case	KCODE_CHARSET_UNICODE:
		default:
			/* ��_�͎g���Ȃ��B*/
			bKuten		= FALSE ;
			bSingleByte	= FALSE ;
			break ;
		}

		/* ���̏ꍇ�ɂ́Aparse ����B*/
		{
			WCHAR	bufTemp [256] ;
			int		nTempLen ;

			nTempLen	= dcstowcs (bufTemp, ARRAYSIZE (bufTemp), pRead, nRead) ;
			n	= bKuten? _snwscanf (bufTemp, nTempLen, L"%d-%d", &n1, &n2) : 0 ;
		}
		if (n == 2) { 
			n1	+= 32 + 128 ;
			n2	+= 32 + 128 ;
		} else {
			if (bSingleByte) {
				if (! bSkkHexChar (pRead [0]) || ! bSkkHexChar (pRead [1])) {
					n1	= -1 ;
				} else {
					n1	= iSkkCharToHex (pRead [0]) * 16 + iSkkCharToHex (pRead [1]) ;
				}
				n2	= 0 ;
			} else {
				if (nRead < 4) {
					n1	= 0 ;
				} else {
					if (! bSkkHexChar (pRead [0]) || ! bSkkHexChar (pRead [1])) {
						n1	= -1 ;
					} else {
						n1	= iSkkCharToHex (pRead [0]) * 16 + iSkkCharToHex (pRead [1]) ;
					}
				}
				if (nRead < 2) {
					n2	= 0 ;
				} else {
					if (! bSkkHexChar (pRead [2]) || ! bSkkHexChar (pRead [3])) {
						n1	= -1 ;
					} else {
						n2	= iSkkCharToHex (pRead [2]) * 16 + iSkkCharToHex (pRead [3]) ;
					}
				}
			}
			if (n1 < 0 || n2 < 0 || n1 >= 256 || n2 >= 256) {
				pThis->bSetMessage (L"Invalid code") ;
				pThis->vSetSignalError () ;
				pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
				return	LMR_CONTINUE ;
			}
		}
		/* ���͉\�ȕ������낤���H */
		if (! bMakeUnicodeChar (iKcodeCharset, n1, n2, &ch)) {
			pThis->vSetRegInteger (LMREGARG_0, n1) ;
			pThis->vSetRegInteger (LMREGARG_1, n2) ;
			if (! pThis->bCall (LM_bSkkInputByCodeOrMenu0, LM_bSkkInputByCodeOrMenu_2))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
		wch	= ch ;
		if (! pBuffer->bInsertAndInherit (&wch, 1)) {
			pThis->vSetSignalError () ;
			pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
			return	LMR_CONTINUE ;
		}
		pThis->vJump (LM_bSkkInputByCodeOrMenu_3) ;
		return	LMR_CONTINUE ;
	} else {
		/* ���ڃR�[�h���͂ɂȂ�B*/
		pThis->vSetRegInteger (LMREGARG_0, 0) ;
		pThis->vSetRegInteger (LMREGARG_1, 0) ;
		if (! pThis->bCall (LM_bSkkInputByCodeOrMenu0, LM_bSkkInputByCodeOrMenu_2))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR	wch ;
	int		nCH ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_RETVAL, &nCH)) {
		pThis->bSetMessage (L"Invalid code") ;
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}
	wch	= nCH ;
	if (! pBuffer->bInsertAndInherit (&wch, 1)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}
	pThis->vJump (LM_bSkkInputByCodeOrMenu_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu_3 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
		return	LMR_CONTINUE ;
	}
	/* ... */
	pThis->vClearMessage () ;

	if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkInputByCodeOrMenu_Exit))
			return	LMR_ERROR ;
	} else {
		pThis->vJump (LM_bSkkInputByCodeOrMenu_Exit) ;
	}
	return	LMR_CONTINUE ;
}

/*================================================================ skk-input-by-code-or-menu0
 */
int
CImeDoc::LM_bSkkInputByCodeOrMenu0 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	int		n1, n2 ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &n1) || 
		! pThis->bGetRegInteger (LMREGARG_1, &n2)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSkkSetSkkInputByCodeOrMenuMode (TRUE) ;
	switch (CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig)) {
	case	KCODE_CHARSET_KATAKANA_JISX0201:
		pThis->vSetRegInteger (LMREGARG_0, n1) ;
		pThis->vSetRegInteger (LMREGARG_1, n2) ;
		pThis->vSetRegInteger (LMREGARG_2, 0xA1) ;
		pThis->vSetRegInteger (LMREGARG_3, 0xDF) ;
		pThis->vSetRegInteger (LMREGARG_4, 0x00) ;
		pThis->vSetRegInteger (LMREGARG_5, 0x00) ;
		pThis->vSetRegInteger (LMREGARG_6, 0xA1) ;
		pThis->vSetRegInteger (LMREGARG_7, 0xDF ) ;
		if (! pThis->bCall (LM_bSkkInputByCodeOrMenu1, LM_bSkkInputByCodeOrMenu0_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;

	case	KCODE_CHARSET_JAPANESE_JISX0208:
	case	KCODE_CHARSET_JAPANESE_JISX0212:
		if (n1 == 0) {
			/* 94 �����W���Ȃ̂ŁA0x21 ���� 94 �����B*/
			pThis->vSetRegInteger (LMREGARG_0, n2) ;
			pThis->vSetRegInteger (LMREGARG_1, 0x2121 | 0x8080) ;
			pThis->vSetRegInteger (LMREGARG_2, 0x7F7F | 0x8080) ;
			pThis->vSetRegInteger (LMREGARG_3, 0x80 + 0x21) ;
			pThis->vSetRegInteger (LMREGARG_4, 0x80 + 0x21 + 94 - 1) ;
			pThis->vSetRegInteger (LMREGARG_5, 0x80 + 0x21) ;
			pThis->vSetRegInteger (LMREGARG_6, 0x80 + 0x21 + 94 - 1) ;
			if (! pThis->bCall (LM_bSkkInputByCodeOrMenuJump, LM_bSkkInputByCodeOrMenu0_1))
				return	LMR_ERROR ;
		} else {
			pThis->vSetRegInteger (LMREGARG_0, n1) ;
			pThis->vSetRegInteger (LMREGARG_1, n2) ;
			pThis->vSetRegInteger (LMREGARG_2, 0x2121 | 0x8080) ;
			pThis->vSetRegInteger (LMREGARG_3, 0x7F7F | 0x8080) ;
			pThis->vSetRegInteger (LMREGARG_4, 0x80 + 0x21) ;
			pThis->vSetRegInteger (LMREGARG_5, 0x80 + 0x21 + 94 - 1) ;
			pThis->vSetRegInteger (LMREGARG_6, 0x80 + 0x21) ;
			pThis->vSetRegInteger (LMREGARG_7, 0x80 + 0x21 + 94 - 1) ;
			if (! pThis->bCall (LM_bSkkInputByCodeOrMenu1, LM_bSkkInputByCodeOrMenu0_1))
				return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;

	case	KCODE_CHARSET_UNICODE:
		/* 0x0021 - 0xFFEE */
		if (n1 == 0) {
			pThis->vSetRegInteger (LMREGARG_0, n2) ;
			pThis->vSetRegInteger (LMREGARG_1, 0x0021) ;
			pThis->vSetRegInteger (LMREGARG_2, 0xFFFD) ;
			pThis->vSetRegInteger (LMREGARG_3, 0x00) ;
			pThis->vSetRegInteger (LMREGARG_4, 0xFF) ;
			pThis->vSetRegInteger (LMREGARG_5, 0x00) ;
			pThis->vSetRegInteger (LMREGARG_6, 0xFF) ;
			if (! pThis->bCall (LM_bSkkInputByCodeOrMenuJump, LM_bSkkInputByCodeOrMenu0_1))
				return	LMR_ERROR ;
		} else {
			pThis->vSetRegInteger (LMREGARG_0, n1) ;
			pThis->vSetRegInteger (LMREGARG_1, n2) ;
			pThis->vSetRegInteger (LMREGARG_2, 0x0021) ;
			pThis->vSetRegInteger (LMREGARG_3, 0xFFFD) ;
			pThis->vSetRegInteger (LMREGARG_4, 0x00) ;
			pThis->vSetRegInteger (LMREGARG_5, 0xFF) ;
			pThis->vSetRegInteger (LMREGARG_6, 0x00) ;
			pThis->vSetRegInteger (LMREGARG_7, 0xFF) ;
			if (! pThis->bCall (LM_bSkkInputByCodeOrMenu1, LM_bSkkInputByCodeOrMenu0_1))
				return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;

	default:
		pThis->vSetRegInteger (LMREGARG_RETVAL, -1) ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu0_1) ;
		return	LMR_CONTINUE ;
	}
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu0_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		pBuffer->vSkkSetSkkInputByCodeOrMenuMode (FALSE) ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-input-by-code-or-menu-jump
 */
/*
	int			n1,
	int			nCodeMin, 
	int			nCodeMax,
	int			nSkkCodeN1Min,
	int			nSkkCodeN1Max,
	int			nSkkCodeN2Min,
	int			nSkkCodeN2Max,
*/
int
CImeDoc::LM_bSkkInputByCodeOrMenuJump (
	CImeDoc*			pThis)
{
	int			n1, nCodeMin, nCodeMax, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max ;
	int*		pnData ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bGetRegInteger (LMREGARG_0, &n1) ||
		! pThis->bGetRegInteger (LMREGARG_1, &nCodeMin) ||
		! pThis->bGetRegInteger (LMREGARG_2, &nCodeMax) ||
		! pThis->bGetRegInteger (LMREGARG_3, &nSkkCodeN1Min) ||
		! pThis->bGetRegInteger (LMREGARG_4, &nSkkCodeN1Max) ||
		! pThis->bGetRegInteger (LMREGARG_5, &nSkkCodeN2Min) ||
		! pThis->bGetRegInteger (LMREGARG_6, &nSkkCodeN2Max)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pnData	= (int*) pThis->pAlloca (sizeof (int) * 10, __alignof (int)) ;
	if (pnData == NULL)
		return	LMR_ERROR ;

#if !defined (UNITTEST)
	if (! pThis->_bCreateSkkInputByCodeOrMenuJumpList ((n1 < nSkkCodeN1Min)? nSkkCodeN1Min : n1, nSkkCodeN2Min, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max, nCodeMin, nCodeMax)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
#endif

#if !defined (UNITTEST)
	pnData [0]	= (n1 < nSkkCodeN1Min)? nSkkCodeN1Min : n1 ;
	pnData [1]	= nSkkCodeN2Min ;	/* n2 */
#else
	pnData [0]	= n1 ;
	pnData [1]	= 0 ;	/* n2 */
#endif
	pnData [2]	= n1 ;	/* n1orig */
	pnData [3]	= 0 ;	/* n2orig */
	pnData [4]	= nCodeMin ;
	pnData [5]	= nCodeMax ;
	pnData [6]	= nSkkCodeN1Min ;
	pnData [7]	= nSkkCodeN1Max ;
	pnData [8]	= nSkkCodeN2Min ;
	pnData [9]	= nSkkCodeN2Max ;
	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;
	pThis->vSetRegPointer (LMREG_0, pnData) ;
	pThis->vJump (LM_bSkkInputByCodeOrMenuJump_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenuJump_Exit (
	CImeDoc*			pThis)
{
#if !defined (UNITTEST)
	IMECANDIDATES*	pCandInfo ;

	/*	CLOSE �� CREATE �������ɗ���̂����A���v���낤���H
	 *	�ށAkeyboard quit �̖�肪����ȁB���̎��� close ����͕K�v���ȁB
	 *	�Ƃ����킯�ŁA������ Close ����B
	 */
	pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;

	pCandInfo	= pThis->pGetCandidateInfo () ;
	if (pCandInfo != NULL)
		pCandInfo->vClear () ;
#endif
	pThis->vPopReg (LMREG_0) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenuJump_1 (
	CImeDoc*			pThis)
{
#if defined (UNITTEST)
	CImeBuffer*	pBuffer ;
	int			nKeys1 ;
	int*		pnData ;
	LPCDSTR		pwKeys1 ;
	int			n1, n2, nCodeMin, nCodeMax, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max ;
	int			nSkkCodeN2Last, iKcodeCharset, nN1Org, nN2Org, i ;
	DCHAR		wbuf [512] ;
	LPDSTR		pDest, pDestEnd ;
#endif

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
		return	LMR_CONTINUE ;
	}

#if defined (UNITTEST)
	pBuffer	= pThis->pGetCurrentBuffer () ;
	pwKeys1	= CImeConfig::pGetSkkInputByCodeMenuKeys1 (pThis->m_pConfig, &nKeys1) ;
	if (pBuffer == NULL || pwKeys1 == NULL || nKeys1 <= 0) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegPointer (LMREG_0, (void**)&pnData)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
		return	LMR_CONTINUE ;
	}

	n1				= pnData [0] ;
	nCodeMin		= pnData [4] ;
	nCodeMax		= pnData [5] ;
	nSkkCodeN1Min	= pnData [6] ;
	nSkkCodeN1Max	= pnData [7] ;
	nSkkCodeN2Min	= pnData [8] ;
	nSkkCodeN2Max	= pnData [9] ;

	if (n1 < nSkkCodeN1Min) {
		n1	= nSkkCodeN1Min ;	/* skk-input-by-code-or-menu-jump-default */ ;
	}
	n2				= nSkkCodeN2Min ;
	nSkkCodeN2Last	= nSkkCodeN2Min + ((nSkkCodeN2Max - nSkkCodeN1Min) & 0xFFFFFF00U) ;
	pDestEnd		= wbuf + MYARRAYSIZE (wbuf) ;
	iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig) ;

	nN1Org			= n1 ;
	nN2Org			= n2 ;

	pDest	= wbuf ;
	for (i = 0 ; i < nKeys1 && pDest < pDestEnd ; i ++) {
		int		ch ;
#define	SAFE_COPY(ptr,chara)	{ if (ptr < pDestEnd) { *ptr ++ = (chara) ; } } 
		SAFE_COPY (pDest, towupper (pwKeys1 [i])) ;
		SAFE_COPY (pDest, L':') ;
		if (bMakeUnicodeChar (iKcodeCharset, n1, n2, &ch)) {
			SAFE_COPY (pDest, ch) ;
		} else {
			SAFE_COPY (pDest, L'?') ;
			SAFE_COPY (pDest, L'?') ;
			SAFE_COPY (pDest, L'?') ;
		}
		SAFE_COPY (pDest, L' ') ;
		SAFE_COPY (pDest, L' ') ;
#undef	SAFE_COPY

		n2	+= 16 ;
		if (n2 > nSkkCodeN2Max) {
			n1	++ ;
			if (n1 > nSkkCodeN1Max)
				n1	= nSkkCodeN1Min ;
			n2	=	nSkkCodeN2Min ;
		}
		/* unicode �̎��ɕK�v�B*/
		if (((n1 << 8) | n2) > nCodeMax) {
			n1	= (nCodeMin >> 8) & 0xFF ;
			n2	= (nCodeMin     ) & 0xFF ;
		}
	}
	pThis->bSetMessageN (wbuf, pDest - wbuf) ;
	pnData [0]	= n1 ;
	pnData [1]	= n1 ;
	pnData [2]	= nN1Org ;
	pnData [3]	= nN2Org ;
#endif
	if (! pThis->bCall (LM_bNextCommandEvent, LM_bSkkInputByCodeOrMenuJump_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenuJump_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	struct TMSG	msg ;
	int			nCH, nKeys1 ;
	int*		pnData ;
	LPCDSTR		pwKeys1 ;
	int			n1, n2, nCodeMin, nCodeMax, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max ;
#if defined (UNITTEST)
	int			nN1Org, nN2Org ;
#endif
	WCHAR		bufText [256] ;
	int			nText ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	pwKeys1	= CImeConfig::pGetSkkInputByCodeMenuKeys1 (pThis->m_pConfig, &nKeys1) ;
	if (pBuffer == NULL || pwKeys1 == NULL || nKeys1 <= 0) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegMsg (LMREGARG_RETVAL, &msg) ||
		! pThis->bGetRegPointer (LMREG_0, (void**)&pnData)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
		return	LMR_CONTINUE ;
	}

	n1				= pnData [0] ;
	n2				= pnData [1] ;
#if defined (UNITTEST)
	nN1Org			= pnData [2] ;
	nN2Org			= pnData [3] ;
#endif
	nCodeMin		= pnData [4] ;
	nCodeMax		= pnData [5] ;
	nSkkCodeN1Min	= pnData [6] ;
	nSkkCodeN1Max	= pnData [7] ;
	nSkkCodeN2Min	= pnData [8] ;
	nSkkCodeN2Max	= pnData [9] ;

	if (! pThis->bEventToCharacter (&msg, &nCH)) {
		/* "`%s' is not valid here!" */
#if !defined (UNITTEST)
		int	iFuncNo ;

		if (pThis->bLookupKeymap (&msg, &iFuncNo) && 
			(iFuncNo == NFUNC_ABORT_RECURSIVE_EDIT || iFuncNo == NFUNC_KEYBOARD_QUIT)) {
			IMECANDIDATES*	pCandInfo ;

			pThis->vSetRegNil (LMREGARG_RETVAL) ;
			pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
			pCandInfo	= pThis->pGetCandidateInfo () ;
			if (pCandInfo != NULL)
				pCandInfo->vClear () ;
			pThis->vSetSignal (LMSIGNAL_QUIT) ;
			pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
			return	LMR_CONTINUE ;
		}
#endif
		nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText)-1, L"event(%d) is not valid here!", msg.m_nMessage) ;
		bufText [nText]	= L'\0' ;
		pThis->bSetMessage (bufText) ;

#if defined (UNITTEST)
		n1	= nN1Org ;
		n2	= nN2Org ;
#endif
	} else {
		int		i, nSkkCodeN2Last ;

		nSkkCodeN2Last	= nSkkCodeN2Min + ((nSkkCodeN2Max - nSkkCodeN2Min) & 0xFFFFFFF0U) ;

		/* skk-input-by-code-menu-keys1 �ɂ��邩�ǂ����`�F�b�N����B*/
		for (i = 0 ; i < nKeys1 ; i ++) {
			if (todlower (nCH) == todlower (pwKeys1 [i]))
				break ;
		}
		if (i >= nKeys1) {
			if (pThis->bSkkPreviousCandidateCharp (nCH)) {
				/* n1, n2 �������߂��B*/
#if defined (UNITTEST)
				n1	= nN1Org ;
				n2	= nN2Org ;
#endif
				for (i = 0 ; i < nKeys1 ; i ++) {
					n2	-= 16 ;
					if (n2 < nSkkCodeN2Min) {
						n1	-- ;
						if (n1 < nSkkCodeN1Min)
							n1	= nSkkCodeN1Max ;
						n2	= nSkkCodeN2Last ;
					}
					/* unicode �̎��ɕK�v�B*/
					if (((n1 << 8) | n2) < nCodeMin) {
						n1	= (nCodeMax >> 8) & 0xFF ;
						n2	= (nCodeMax     ) & 0xFF ;
					}
				}
#if !defined (UNITTEST)
				if (! pThis->_bCreateSkkInputByCodeOrMenuJumpList (n1, n2, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max, nCodeMin, nCodeMax)) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}
				pThis->vSetUpdateFlag (IMEDOC_UPDATE_CANDIDATELIST) ;
#endif
			} else if (CImeConfig::bSkkStartHenkanCharp (pThis->m_pConfig, nCH)) {
				/* ���� n1, n2 �� ok */
#if !defined (UNITTEST)
				for (i = 0 ; i < nKeys1 ; i ++) {
					n2	+= 16 ;
					if (n2 > nSkkCodeN2Max) {
						n1	++ ;
						if (n1 > nSkkCodeN1Max)
							n1	= nSkkCodeN1Min ;
						n2	= nSkkCodeN2Min ;
					}
					/* unicode �̎��ɕK�v�B*/
					if (((n1 << 8) | n2) > nCodeMax) {
						n1	= (nCodeMin  >> 8) & 0xFF ;
						n2	= (nCodeMin      ) & 0xFF ;
					}
				}
				if (! pThis->_bCreateSkkInputByCodeOrMenuJumpList (n1, n2, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max, nCodeMin, nCodeMax)) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}
				pThis->vSetUpdateFlag (IMEDOC_UPDATE_CANDIDATELIST) ;
#endif
			} else if (nCH == L'?') {
				int		iKcodeCharset, wch ;
#if defined (UNITTEST)
				n1	= nN1Org ;
				n2	= nN2Org ;
#endif
				/* code ��\������ hit any key �ƁB*/
				iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig) ;
				if (bMakeUnicodeChar (iKcodeCharset, n1, n2, &wch)) {
					nText	= wnsprintf (bufText, MYARRAYSIZE (bufText)-1, L"`%c' EUC: %2x%2x (%3d, %3d), JIS: %2x%2x (%3d, %3d), UNICODE: %04x",
						wch, n1, n2, n1, n2, (n1 & 0x7F), (n2 & 0x7F), (n1 & 0x7F), (n2 & 0x7F), wch) ;
				} else {
					nText	= wnsprintf (bufText, MYARRAYSIZE (bufText)-1, L"`?' EUC: %2x%2x (%3d, %3d), JIS: %2x%2x (%3d, %3d)",
						n1, n2, n1, n2, (n1 & 0x7F), (n2 & 0x7F), (n1 & 0x7F), (n2 & 0x7F)) ;
				}
				bufText [nText]	= L'\0' ;
				pThis->bSetMessage (bufText) ;
			} else {
#if !defined (UNITTEST)
				int	iFuncNo ;
				if (pThis->bLookupKeymap (&msg, &iFuncNo) && 
					(iFuncNo == NFUNC_ABORT_RECURSIVE_EDIT || iFuncNo == NFUNC_KEYBOARD_QUIT)) {
					IMECANDIDATES*	pCandInfo ;

					pThis->vSetRegNil (LMREGARG_RETVAL) ;
					pThis->vJump (LM_bSkkInputByCodeOrMenuJump_Exit) ;
					pCandInfo	= pThis->pGetCandidateInfo () ;
					if (pCandInfo != NULL)
						pCandInfo->vClear () ;
					pThis->vSetSignal (LMSIGNAL_QUIT) ;
					pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
					return	LMR_CONTINUE ;
				}
#endif
				/* �����ȃL�[�B*/
#if defined (UNITTEST)
				n1	= nN1Org ;
				n2	= nN2Org ;
#endif
				if (0x21 <= nCH && nCH < 0x7F) {
					nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText)-1, L"`%c' is not valid here!", nCH) ;
				} else {
					nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText)-1, L"0x%0x is not valid here!", nCH) ;
				}
				bufText [nText]	= L'\0' ;
				pThis->bSetMessage (bufText) ;
			}
		} else {
#if !defined (UNITEST)
			IMECANDIDATES*	pCandInfo ;
#endif

#if defined (UNITTEST)
			n1	= nN1Org ;
			n2	= nN2Org ;
#endif
			while (i > 0) {
				n2	+= 16 ;
				if (n2 > nSkkCodeN2Max) {
					n1	++ ;
					if (n1 > nSkkCodeN1Max)
						n1	= nSkkCodeN1Min ;
					n2	=	nSkkCodeN2Min ;
				}
				if (((n1 << 8) | n2) > nCodeMax) {
					n1	= (nCodeMin >> 8) & 0xFF ;
					n2	= (nCodeMin     ) & 0xFF ;
				}
				i	-- ;
			}
#if ! defined (UNITTEST)
			pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;

			pCandInfo	= pThis->pGetCandidateInfo () ;
			if (pCandInfo != NULL)
				pCandInfo->vClear () ;
#endif

			// skk-input-by-code-or-menu-jump-default �� n1 �ɍX�V����B
			// ���� n1, n2 �� skk-input-by-code-or-menu-1 ���J���B
			pThis->vSetRegInteger (LMREGARG_0, n1) ;
			pThis->vSetRegInteger (LMREGARG_1, n2) ;
			pThis->vSetRegInteger (LMREGARG_2, nCodeMin) ;
			pThis->vSetRegInteger (LMREGARG_3, nCodeMax) ;
			pThis->vSetRegInteger (LMREGARG_4, nSkkCodeN1Min) ;
			pThis->vSetRegInteger (LMREGARG_5, nSkkCodeN1Max) ;
			pThis->vSetRegInteger (LMREGARG_6, nSkkCodeN2Min) ;
			pThis->vSetRegInteger (LMREGARG_7, nSkkCodeN2Max) ;
			if (! pThis->bCall (LM_bSkkInputByCodeOrMenuJump_Exit, LM_bSkkInputByCodeOrMenu1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	pnData [0]	= n1 ;
	pnData [1]	= n2 ;
	pThis->vJump (LM_bSkkInputByCodeOrMenuJump_1) ;
	return	LMR_CONTINUE ;
}

BOOL
CImeDoc::_bCreateSkkInputByCodeOrMenuJumpList (
	int				n1,
	int				n2,
	int				nSkkCodeN1Min,
	int				nSkkCodeN1Max,
	int				nSkkCodeN2Min,
	int				nSkkCodeN2Max,
	int				nCodeMin,
	int				nCodeMax)
{
	IMECANDIDATES*		pMyCand ;
	LPDSTR				pwCandStr, pwDest ;
	UINT*				piDestIndex ;
	UINT*				piPageIndex ;
	int 				i, nNumOfCand, iMaxPage, iKcodeCharset ;

	iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (m_pConfig) ;
	/*	min, max ���܂�ŁA���ꂼ��� 6 ���A�ƁB*/
	(void) CImeConfig::pGetSkkInputByCodeMenuKeys1 (m_pConfig, &nNumOfCand) ;
	if (nNumOfCand <= 0)
		return	FALSE ;
	pMyCand			= pGetCandidateInfo () ;
	if (pMyCand == NULL)
		return	FALSE ;

	iMaxPage		= 1 ;
	if (iMaxPage <= 0)
		return	FALSE ;

	pMyCand->vClear () ;
	if (! pMyCand->m_vbufCandidate.bRequire (nNumOfCand * 2) ||
		! pMyCand->m_vbufCandidateIndex.bRequire (nNumOfCand) ||
		! pMyCand->m_vbufPageIndex.bRequire (iMaxPage)) {
		pMyCand->vClear () ;
		return	FALSE ;
	}

	/* ��⃊�X�g�\���̂��m�ۂ��A����������B*/
	pMyCand->m_iCount		= nNumOfCand ;
	pMyCand->m_iStyle		= IMECANDSTYLE_CODE0 ;

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pwCandStr	= (LPDSTR) pMyCand->m_vbufCandidate.pGetBuffer () ;
	pwDest		= pwCandStr ;
	piDestIndex	= (UINT*) pMyCand->m_vbufCandidateIndex.pGetBuffer () ;

	piPageIndex	= (UINT*) pMyCand->m_vbufPageIndex.pGetBuffer () ;
	piPageIndex [0]	= 0 ;

	for (i = 0 ; i < nNumOfCand ; i ++) {
		int		ch ;

		*piDestIndex	= pwDest - pwCandStr ;
		if (bMakeUnicodeChar (iKcodeCharset, n1, n2, &ch)) {
			*pwDest ++	= ch ;
		} else {
			*pwDest ++	= L'?' ;
		}
		*pwDest ++	= L'\0' ;

		n2	+= 16 ;
		if (n2 > nSkkCodeN2Max) {
			n1	++ ;
			if (n1 > nSkkCodeN1Max)
				n1	= nSkkCodeN1Min ;
			n2	=	nSkkCodeN2Min ;
		}
		/* unicode �̎��ɕK�v�B*/
		if (((n1 << 8) | n2) > nCodeMax) {
			n1	= (nCodeMin >> 8) & 0xFF ;
			n2	= (nCodeMin     ) & 0xFF ;
		}
		piDestIndex	++ ;
	}
	pMyCand->m_iSelection	= 0 ;
	pMyCand->m_iCurrentPage	= 0 ;
	pMyCand->m_dwUpdate		= IMECANDUPDATE_COUNT | IMECANDUPDATE_STRING | IMECANDUPDATE_CURRENT_PAGE | IMECANDUPDATE_PAGE_INDEX ;
	return	TRUE ;
}

/*================================================================ skk-input-by-code-or-menu-1
 */
/*
	int			n1,
	int			n2,
	int			nCodeMin, 
	int			nCodeMax,
	int			nSkkCodeN1Min,
	int			nSkkCodeN1Max,
	int			nSkkCodeN2Min,
	int			nSkkCodeN2Max,
*/
int
CImeDoc::LM_bSkkInputByCodeOrMenu1 (
	CImeDoc*			pThis)
{
	int		n1, n2, nCodeMin, nCodeMax, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max ;
	int*	pnData ;
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pThis->bGetRegInteger (LMREGARG_0, &n1) ||
		! pThis->bGetRegInteger (LMREGARG_1, &n2) ||
		! pThis->bGetRegInteger (LMREGARG_2, &nCodeMin) ||
		! pThis->bGetRegInteger (LMREGARG_3, &nCodeMax) ||
		! pThis->bGetRegInteger (LMREGARG_4, &nSkkCodeN1Min) ||
		! pThis->bGetRegInteger (LMREGARG_5, &nSkkCodeN1Max) ||
		! pThis->bGetRegInteger (LMREGARG_6, &nSkkCodeN2Min) ||
		! pThis->bGetRegInteger (LMREGARG_7, &nSkkCodeN2Max)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pnData	= (int*) pThis->pAlloca (sizeof (int) * 10, __alignof (int)) ;
	if (pnData == NULL)
		return	LMR_ERROR ;

#if !defined (UNITTEST)
	if (! pThis->_bCreateSkkInputByCodeOrMenu1List (n1, n2, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max, nCodeMin, nCodeMax)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
#endif
	pBuffer->vSkkSetSkkInputByCodeOrMenu1Mode (TRUE) ;

	pnData [0]	= n1 ;
	pnData [1]	= n2 ;	/* n2 */
	pnData [2]	= n1 ;	/* n1orig */
	pnData [3]	= n2 ;	/* n2orig */
	pnData [4]	= nCodeMin ;
	pnData [5]	= nCodeMax ;
	pnData [6]	= nSkkCodeN1Min ;
	pnData [7]	= nSkkCodeN1Max ;
	pnData [8]	= nSkkCodeN2Min ;
	pnData [9]	= nSkkCodeN2Max ;
	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;

	pThis->vSetRegPointer (LMREG_0, pnData) ;
	pThis->vJump (LM_bSkkInputByCodeOrMenu1_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu1_Exit (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
#if !defined (UNITTEST)
	IMECANDIDATES*	pCandInfo ;
#endif

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		pBuffer->vSkkSetSkkInputByCodeOrMenu1Mode (FALSE) ;
	}
	pThis->vPopReg (LMREG_0) ;

#if !defined (UNITTEST)
	/*	CLOSE �� CREATE �������ɗ���̂����A���v���낤���H
	 *	�ށAkeyboard quit �̖�肪����ȁB���̎��� close ����͕K�v���ȁB
	 *	�Ƃ����킯�ŁA������ Close ����B
	 */
	pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;

	pCandInfo	= pThis->pGetCandidateInfo () ;
	if (pCandInfo != NULL)
		pCandInfo->vClear () ;
#endif
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu1_1 (
	CImeDoc*			pThis)
{
#if defined (UNITTEST)
	LPCDSTR			pwKeys2 ;
	int				nKeys2 ;
	int				i, nN1Org, nN2Org, iKcodeCharset ;
	DCHAR			wbuf [512] ;
	LPDSTR			pDest, pDestEnd ;
	int*			pnData ;
	int		n1, n2, nCodeMin, nCodeMax, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max ;
#endif

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
		return	LMR_CONTINUE ;
	}

#if defined (UNITTEST)
	if (! pThis->bGetRegPointer (LMREG_0, (void**)&pnData)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
		return	LMR_CONTINUE ;
	}
	pwKeys2	= CImeConfig::pGetSkkInputByCodeMenuKeys2 (pThis->m_pConfig, &nKeys2) ;
	if (pwKeys2 == NULL || nKeys2 <= 0) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
		return	LMR_CONTINUE ;
	}

	iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig) ;
	pDestEnd		= wbuf + MYARRAYSIZE (wbuf) ;
	
	n1				= pnData [0] ;
	n2				= pnData [1] ;
	nCodeMin		= pnData [4] ;
	nCodeMax		= pnData [5] ;
	nSkkCodeN1Min	= pnData [6] ;
	nSkkCodeN1Max	= pnData [7] ;
	nSkkCodeN2Min	= pnData [8] ;
	nSkkCodeN2Max	= pnData [9] ;

	nN1Org		= n1 ;
	nN2Org		= n2 ;
	pDest		= wbuf ;
	for (i = 0 ; i < nKeys2 && pDest < pDestEnd ; i ++) {
		int		ch ;
#define	SAFE_COPY(ptr,chara)	{ if (ptr < pDestEnd) { *ptr ++ = (chara) ; } } 
		SAFE_COPY (pDest, towupper (pwKeys2 [i])) ;
		SAFE_COPY (pDest, L':') ;
		if (bMakeUnicodeChar (iKcodeCharset, n1, n2, &ch)) {
			SAFE_COPY (pDest, ch) ;
		} else {
			SAFE_COPY (pDest, L'?') ;
			SAFE_COPY (pDest, L'?') ;
			SAFE_COPY (pDest, L'?') ;
		}
		SAFE_COPY (pDest, L' ') ;
		SAFE_COPY (pDest, L' ') ;
#undef	SAFE_COPY

		n2	++ ;
		if (n2 > nSkkCodeN2Max) {
			n1	++ ;
			if (n1 > nSkkCodeN1Max)
				n1	= nSkkCodeN1Min ;
			n2	=	nSkkCodeN2Min ;
		}
		if (((n1 << 8) | n2) > nCodeMax) {
			n1	= (nCodeMin >> 8) & 0xFF ;
			n2	= (nCodeMin     ) & 0xFF ;
		}
	}
	pThis->bSetMessageN (wbuf, pDest - wbuf) ;

	pnData [0]	= n1 ;
	pnData [1]	= n2 ;
	pnData [2]	= nN1Org ;
	pnData [3]	= nN2Org ;
#endif

	if (! pThis->bCall (LM_bNextCommandEvent, LM_bSkkInputByCodeOrMenu1_2))
		return	LMR_ERROR ;

	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInputByCodeOrMenu1_2 (
	CImeDoc*			pThis)
{
	struct TMSG		msg ;
	LPCDSTR			pwKeys2 ;
	int*	pnData ;
	int		n1, n2, nCodeMin, nCodeMax, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max ;
	int		nCH, nKeys2 ;
#if defined (UNITTEST)
	int		nN1Org, nN2Org ;
#endif
	WCHAR	bufText [256] ;
	int		nText ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegPointer (LMREG_0, (void**)&pnData) ||
		! pThis->bGetRegMsg (LMREGARG_RETVAL, &msg)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
		return	LMR_CONTINUE ;
	}
	pwKeys2	= CImeConfig::pGetSkkInputByCodeMenuKeys2 (pThis->m_pConfig, &nKeys2) ;
	if (pwKeys2 == NULL || nKeys2 <= 0) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
		return	LMR_CONTINUE ;
	}

	n1				= pnData [0] ;
	n2				= pnData [1] ;
#if defined (UNITTEST)
	nN1Org			= pnData [2] ;
	nN2Org			= pnData [3] ;
#endif
	nCodeMin		= pnData [4] ;
	nCodeMax		= pnData [5] ;
	nSkkCodeN1Min	= pnData [6] ;
	nSkkCodeN1Max	= pnData [7] ;
	nSkkCodeN2Min	= pnData [8] ;
	nSkkCodeN2Max	= pnData [9] ;

	if (! pThis->bEventToCharacter (&msg, &nCH)) {
#if !defined (UNITTEST)
		int	iFuncNo ;
		if (pThis->bLookupKeymap (&msg, &iFuncNo) && 
			(iFuncNo == NFUNC_ABORT_RECURSIVE_EDIT || iFuncNo == NFUNC_KEYBOARD_QUIT)) {
			IMECANDIDATES*	pCandInfo ;

			pThis->vSetRegNil (LMREGARG_RETVAL) ;
			pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
			pCandInfo	= pThis->pGetCandidateInfo () ;
			if (pCandInfo != NULL)
				pCandInfo->vClear () ;
			pThis->vSetSignal (LMSIGNAL_QUIT) ;
			pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
			return	LMR_CONTINUE ;
		}
#endif
		/* "`%s' is not valid here!" */
		nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText)-1, L"event(%d) is not valid here!", msg.m_nMessage) ;
		bufText [nText]	= L'\0' ;
		pThis->bSetMessage (bufText) ;

#if defined (UNITTEST)
		n1	= nN1Org ;
		n2	= nN2Org ;
#endif
	} else {
		int		i ;

		/* skk-input-by-code-menu-keys1 �ɂ��邩�ǂ����`�F�b�N����B*/
		for (i = 0 ; i < nKeys2 ; i ++) {
			if (towlower (nCH) == todlower (pwKeys2 [i]))
				break ;
		}
		if (i >= nKeys2) {
			if (pThis->bSkkPreviousCandidateCharp (nCH)) {
				/* n1, n2 �������߂��B*/
#if defined (UNITTEST)
				n1	= nN1Org ;
				n2	= nN2Org ;
#endif
				for (i = 0 ; i < nKeys2 ; i ++) {
					n2	-- ;
					if (n2 < nSkkCodeN2Min) {
						n1	-- ;
						if (n1 < nSkkCodeN1Min)
							n1	= nSkkCodeN1Max ;
						n2	= nSkkCodeN2Max ;
					}
					/* unicode �̎��ɕK�v�B*/
					if (((n1 << 8) | n2) < nCodeMin) {
						n1	= ((nCodeMax - 1) >> 8) & 0xFF ;
						n2	= ((nCodeMax - 1)     ) & 0xFF ;
					}
				}
#if !defined (UNITTEST)
				if (! pThis->_bCreateSkkInputByCodeOrMenu1List (n1, n2, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max, nCodeMin, nCodeMax)) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}
				pThis->vSetUpdateFlag (IMEDOC_UPDATE_CANDIDATELIST) ;
#endif
			} else if (CImeConfig::bSkkStartHenkanCharp (pThis->m_pConfig, nCH)) {
				/* ���� n1, n2 �� ok */
#if !defined (UNITTEST)
				for (i = 0 ; i < nKeys2 ; i ++) {
					n2	++ ;
					if (n2 > nSkkCodeN2Max) {
						n1	++ ;
						if (n1 > nSkkCodeN1Max)
							n1	= nSkkCodeN1Min ;
						n2	= nSkkCodeN2Min ;
					}
					/* unicode �̎��ɕK�v�B*/
					if (((n1 << 8) | n2) > nCodeMax) {
						n1	= (nCodeMin  >> 8) & 0xFF ;
						n2	= (nCodeMin      ) & 0xFF ;
					}
				}
				if (! pThis->_bCreateSkkInputByCodeOrMenu1List (n1, n2, nSkkCodeN1Min, nSkkCodeN1Max, nSkkCodeN2Min, nSkkCodeN2Max, nCodeMin, nCodeMax)) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}
				pThis->vSetUpdateFlag (IMEDOC_UPDATE_CANDIDATELIST) ;
#endif
			} else if (nCH == L'?') {
				int		iKcodeCharset, wch ;
#if defined (UNITTEST)
				n1	= nN1Org ;
				n2	= nN2Org ;
#endif
				/* code ��\������ hit any key �ƁB*/
				iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig) ;
				if (bMakeUnicodeChar (iKcodeCharset, n1, n2, &wch)) {
					nText	= wnsprintf (bufText, MYARRAYSIZE (bufText)-1, L"`%c' EUC: %2x%2x (%3d, %3d), JIS: %2x%2x (%3d, %3d), UNICODE: %04x",
						wch,
						n1, n2, n1, n2, 
						(n1 & 0x7F), (n2 & 0x7F), (n1 & 0x7F), (n2 & 0x7F),
						wch) ;
				} else {
					nText	= wnsprintf (bufText, MYARRAYSIZE (bufText)-1, L"`?' EUC: %2x%2x (%3d, %3d), JIS: %2x%2x (%3d, %3d)",
						n1, n2, n1, n2, 
						(n1 & 0x7F), (n2 & 0x7F), (n1 & 0x7F), (n2 & 0x7F)) ;
				}
				bufText [nText]	= L'\0' ;
				pThis->bSetMessage (bufText) ;
			} else {
				/* �����ȃL�[�B*/
#if !defined (UNITTEST)
				int	iFuncNo ;
				if (pThis->bLookupKeymap (&msg, &iFuncNo) && 
					(iFuncNo == NFUNC_ABORT_RECURSIVE_EDIT || iFuncNo == NFUNC_KEYBOARD_QUIT)) {
					IMECANDIDATES*	pCandInfo ;

					pThis->vSetRegNil (LMREGARG_RETVAL) ;
					pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
					pCandInfo	= pThis->pGetCandidateInfo () ;
					if (pCandInfo != NULL)
						pCandInfo->vClear () ;
					pThis->vSetSignal (LMSIGNAL_QUIT) ;
					pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
					return	LMR_CONTINUE ;
				}
#endif
				if (0x21 <= nCH && nCH < 0x7F) {
					nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText) - 1, L"`%c' is not valid here!", nCH) ;
				} else {
					nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText) - 1, L"0x%0x is not valid here!", nCH) ;
				}
				bufText [nText]	= L'\0' ;
				pThis->bSetMessage (bufText) ;

#if defined (UNITTEST)
				n1	= nN1Org ;
				n2	= nN2Org ;
#endif
			}
		} else {
			int		nRetval, iKcodeCharset ;

#if defined (UNITTEST)
			n1	= nN1Org ;
			n2	= nN2Org ;
#endif
			while (i > 0) {
				n2	++ ;
				if (n2 >= nSkkCodeN2Max) {
					n1	++ ;
					if (n1 >= nSkkCodeN1Max)
						n1	= nSkkCodeN1Min ;
					n2	=	nSkkCodeN2Min ;
				}
				if (((n1 << 8) | n2) >= nCodeMax) {
					n1	= (nCodeMin >> 8) & 0xFF ;
					n2	= (nCodeMin     ) & 0xFF ;
				}
				i	-- ;
			}
			iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (pThis->m_pConfig) ;
			/* codeset �Ƃ��đʖڂ������灬�ɂ���B*/
			if (! bMakeUnicodeChar (iKcodeCharset, n1, n2, &nRetval)) {
				pThis->vSetRegInteger (LMREGARG_RETVAL, 0) ;
			} else {
				pThis->vSetRegInteger (LMREGARG_RETVAL, nRetval) ;
			}
			pThis->vJump (LM_bSkkInputByCodeOrMenu1_Exit) ;
			return	LMR_CONTINUE ;
		}
	}
	pnData [0]	= n1 ;
	pnData [1]	= n2 ;
	pThis->vJump (LM_bSkkInputByCodeOrMenu1_1) ;
	return	LMR_CONTINUE ;
}

BOOL
CImeDoc::_bCreateSkkInputByCodeOrMenu1List (
	int				n1,
	int				n2,
	int				nSkkCodeN1Min,
	int				nSkkCodeN1Max,
	int				nSkkCodeN2Min,
	int				nSkkCodeN2Max,
	int				nCodeMin,
	int				nCodeMax)
{
	IMECANDIDATES*		pMyCand ;
	LPDSTR				pwCandStr, pwDest ;
	UINT*				piDestIndex ;
	UINT*				piPageIndex ;
	int 				i, nNumOfCand, iMaxPage, iKcodeCharset ;

	iKcodeCharset	= CImeConfig::iGetSkkKcodeCharset (m_pConfig) ;
	/*	min, max ���܂�ŁA���ꂼ��� 6 ���A�ƁB*/
	(void) CImeConfig::pGetSkkInputByCodeMenuKeys2 (m_pConfig, &nNumOfCand) ;
	if (nNumOfCand <= 0)
		return	FALSE ;
	pMyCand			= pGetCandidateInfo () ;
	if (pMyCand == NULL)
		return	FALSE ;

	iMaxPage		= 1 ;
	if (iMaxPage <= 0)
		return	FALSE ;

	pMyCand->vClear () ;
	if (! pMyCand->m_vbufCandidate.bRequire (nNumOfCand * 2) ||
		! pMyCand->m_vbufCandidateIndex.bRequire (nNumOfCand) ||
		! pMyCand->m_vbufPageIndex.bRequire (iMaxPage)) {
		pMyCand->vClear () ;
		return	FALSE ;
	}

	/* ��⃊�X�g�\���̂��m�ۂ��A����������B*/
	pMyCand->m_iCount		= nNumOfCand ;
	pMyCand->m_iStyle		= IMECANDSTYLE_CODE1 ;

	/* ��⃊�X�g��������(�ݒ�)����B*/
	pwCandStr	= (LPDSTR) pMyCand->m_vbufCandidate.pGetBuffer () ;
	pwDest		= pwCandStr ;
	piDestIndex	= (UINT*) pMyCand->m_vbufCandidateIndex.pGetBuffer () ;

	piPageIndex	= (UINT*) pMyCand->m_vbufPageIndex.pGetBuffer () ;
	piPageIndex [0]	= 0 ;

	for (i = 0 ; i < nNumOfCand ; i ++) {
		int		ch ;

		*piDestIndex	= pwDest - pwCandStr ;
		if (bMakeUnicodeChar (iKcodeCharset, n1, n2, &ch)) {
			*pwDest ++	= ch ;
		} else {
			*pwDest ++	= L'?' ;
		}
		*pwDest ++	= L'\0' ;

		n2	++ ;
		if (n2 > nSkkCodeN2Max) {
			n1	++ ;
			if (n1 > nSkkCodeN1Max)
				n1	= nSkkCodeN1Min ;
			n2	=	nSkkCodeN2Min ;
		}
		if (((n1 << 8) | n2) > nCodeMax) {
			n1	= (nCodeMin >> 8) & 0xFF ;
			n2	= (nCodeMin     ) & 0xFF ;
		}
		piDestIndex	++ ;
	}
	pMyCand->m_iSelection	= 0 ;
	pMyCand->m_iCurrentPage	= 0 ;
	pMyCand->m_dwUpdate		= IMECANDUPDATE_COUNT | IMECANDUPDATE_STRING | IMECANDUPDATE_CURRENT_PAGE | IMECANDUPDATE_PAGE_INDEX ;
	return	TRUE ;
}

#if 0//!defined (UNITTEST)
BOOL
bParseKutenCode (
	LPCDSTR		wstrKuten,
	int			nKutenLen,
	int*		pn1, 
	int*		pn2) 
{
	LPCDSTR		ptr, ptrEnd, ptrFirstEnd, ptrSecond, ptrSecondEnd ;
	int			nN1, nN2 ;

	ptr			= wstrKuten ;
	ptrEnd		= wstrKuten + nKutenLen ;
	while (ptr < ptrEnd) {
		if (! (L'0' <= *ptr && *ptr <= L'9')) 
			break ;
		ptr	++ ;
	}
	ptrFirstEnd	= ptr ;
	if (ptr == wstrKuten)
		return	FALSE ;

	if (ptr >= ptrEnd || *ptr != L'-')
		return	FALSE ;
	ptr	++ ;
	ptrSecond	= ptr ;
	while (ptr < ptrEnd) {
		if (! (L'0' <= *ptr && *ptr <= L'9')) 
			break ;
		ptr	++ ;
	}
	ptrSecondEnd	= ptr ;
	if (ptrSecondEnd == ptrSecond)
		return	FALSE ;

	ptr			= wstrKuten ;
	nN1			= 0 ;
	while (ptr < ptrFirstEnd) {
		nN1	= nN1 * 10 + (*ptr - '0') ;
		ptr	++ ;
	}
	ptr			= ptrSecond ;
	nN2			= 0 ;
	while (ptr < ptrSecondEnd) {
		nN2	= nN2 * 10 + (*ptr - '0') ;
		ptr	++ ;
	}
	if (pn1 != NULL)
		*pn1	= nN1 ;
	if (pn2 != NULL)
		*pn2	= nN2 ;
	return	TRUE ;
}

#endif


