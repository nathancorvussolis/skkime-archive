#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "ImeDoc.h"
#include "ImeBuffer.h"
#include "TMarker.h"
#include "RuleTreeNode.h"
#include "keymap.h"
#include "TMSG.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "TLispSession.h"
#include "jstring.h"
#include "ImeConfig.h"

/*=================================================================================
 *	prototypes
 */

/*================================================================ skk-pre-command
 */
int
CImeDoc::LM_bSkkPreCommand (
	CImeDoc*		pThis)
{
	static BYTE	_srSkkKanaCleanupCommandList []	= {
		NFUNC_SKK_UNDO,
		NFUNC_SKK_KAKUTEI,
		NFUNC_SKK_DELETE_BACKWARD_CHAR,
		NFUNC_SKK_INSERT,
		NFUNC_SKK_PREVIOUS_CANDIDATE,
	} ;
	int		i ;

	/*
	 *	(defun skk-pre-command ()
	 *  (when (and (memq last-command
	 *		   '(skk-insert skk-previous-candidate))
	 *	     (null (memq this-command
	 *			 skk-kana-cleanup-command-list)))
	 *    (skk-kana-cleanup t)))
	*/
	if (pThis->iGetLastCommand () != NFUNC_SKK_INSERT && 
		pThis->iGetLastCommand () != NFUNC_SKK_PREVIOUS_CANDIDATE) {
		return	LMR_RETURN ;
	}
	for (i = 0 ; i < MYARRAYSIZE (_srSkkKanaCleanupCommandList) ; i ++)
		if (_srSkkKanaCleanupCommandList [i] == pThis->iGetThisCommand ())
			return	LMR_RETURN ;
	pThis->vSetRegBool (LMREGARG_0, TRUE) ;
	pThis->vJump (LM_bSkkKanaCleanup) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-post-command
 */
int
CImeDoc::LM_bSkkPostCommand (
	CImeDoc*		pThis)
{
	CImeBuffer*				pBuffer ;
	int						nPrefix ;
	CTMarker*				pmkSkkPreviousPoint ;
	CTMarker*				pmkPoint ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;
//	const CSkkRuleTreeNode*	pSkkCurrentRuleTree ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/*
	 * (defun skk-after-point-move ()
	 *	(when (and (not (and skk-previous-point
	 *				(= skk-previous-point (point))))
	 *				(skk-get-prefix skk-current-rule-tree))
	 *		(skk-with-point-move
	 *		(skk-erase-prefix 'clean))))
	 */
	pmkSkkPreviousPoint	= pBuffer->pSkkGetSkkPreviousPointMarker () ;
	if (! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint))
		pmkPoint	= NULL ;
//	pSkkCurrentRuleTree		= pBuffer->pSkkGetSkkCurrentRuleTree () ;
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;

	if (! (pmkSkkPreviousPoint != NULL && pmkSkkPreviousPoint->iGetPosition () == pmkPoint->iGetPosition ()) &&
		(! piteSkkRuleTree->bHavePrefixp () || piteSkkRuleTree->pGetPrefix (&nPrefix) == NULL)) {
		pBuffer->bSkkErasePrefix (TRUE) ;
		pBuffer->bSkkSetSkkPreviousPoint (pmkPoint) ;
	}

	/*	completion �̉����B���̃^�C�~���O�Ŏ��s����ׂ����H
	 */
	if (pThis->iGetThisCommand () != NFUNC_SKK_COMP_DO) {
		CTSearchSession*	pSession	= pBuffer->pSkkGetSkkCurrentCompletionSession () ;
		pBuffer->vSkkSetSkkCurrentCompletionSession (NULL) ;
		if (pSession != NULL)
			delete	pSession ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-insert
 */
int
CImeDoc::LM_bSkkInsert (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR		wch ;
	int			nPrefix ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetLastCommandChar (&wch)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;

	if (pBuffer->bSkkGetSkkHenkanMode () && CImeConfig::bSkkSpecialMidashiCharp (pThis->m_pConfig, wch)) {
		if (! pThis->bCall (LM_bSkkProcessPrefixOrSuffix, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (CImeConfig::bSkkSetHenkanPointKeyp (pThis->m_pConfig, wch) &&
		(pBuffer->bSkkGetSkkOkurigana () || 
//		 pBuffer->pSkkGetSkkCurrentRuleTree () == NULL ||
		 ! piteSkkRuleTree->bHavePrefixp () ||
		/*	(null (skk-get-prefix skk-current-rule-tree)) ����������̂́Askk-rule-tree ��
		 *	root ���w���Ă����ꍇ�ł���B
		 */
		 piteSkkRuleTree->pGetPrefix (&nPrefix) == NULL ||
		 ! piteSkkRuleTree->bHaveSelectBranchp (wch))) {
//		 CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) == NULL || 
//		 CSkkRuleTreeNode::pSelectBranch (pBuffer->pSkkGetSkkCurrentRuleTree (), wch) == NULL)) {
		if (! pThis->bCall (LM_bSkkSetHenkanPoint, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->bSkkGetSkkHenkanMode () && CImeConfig::bSkkStartHenkanCharp (pThis->m_pConfig, wch)) {
		if (! pThis->bCall (LM_bSkkStartHenkan, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->bSkkGetSkkHenkanMode () != LON) {
		if (! pThis->bCall (LM_bSkkKanaInput, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->bSkkGetSkkHenkanMode () == LON && CImeConfig::bSkkTryCompletionCharp (pThis->m_pConfig, wch)) {
		/* completion �̊J�n�B*/
		pThis->vSetRegBool (LMREGARG_0, (pThis->iGetLastCommand () != NFUNC_SKK_COMP_DO)? TRUE : FALSE) ;
		if (! pThis->bCall (LM_bSkkCompDo, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->bSkkGetSkkHenkanMode () == LON && 
		(CImeConfig::bSkkNextCompletionCharp (pThis->m_pConfig, wch) || CImeConfig::bSkkPreviousCompletionCharp (pThis->m_pConfig, wch)) &&
		pThis->iGetLastCommand () == NFUNC_SKK_COMP_DO) {
		/* completion �̑����B*/
		pThis->vSetRegInteger (LMREGARG_0, wch) ;
		if (! pThis->bCall (LM_bSkkCompPreviousNext, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else {
		/* ����ȊO�B*/
		if (! pThis->bCall (LM_bSkkKanaInput, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkInsert_Exit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/* skk-point-move �̌��ʁB*/
	pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}


/*================================================================ skk-process-prefix-or-suffix
 */
int
CImeDoc::LM_bSkkProcessPrefixOrSuffix (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR	wch ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkProcessPrefixOrSuffix_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		pThis->vSetRegBool (LMREGARG_0, TRUE) ;
		if (! pThis->bCall (LM_bSkkKanaCleanup, LM_bSkkProcessPrefixOrSuffix_3))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else if (pThis->bGetLastCommandChar (&wch)) {
		LPDSTR	pwString ;

		pwString	= (LPDSTR) pThis->pAlloca (sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pwString == NULL)
			return	LMR_ERROR ;
		*pwString	= wch ;
		pThis->vSetRegConstString (LMREGARG_0, pwString, 1) ;
		pThis->vJump (LM_bSkkInsertStr) ;
		return	LMR_CONTINUE ;
	} else {
		pThis->vJump (LM_bSkkEmulateOriginalMap) ;
		return	LMR_CONTINUE ;
	}
}

int
CImeDoc::LM_bSkkProcessPrefixOrSuffix_1 (
	CImeDoc*		pThis)
{
	if (! pThis->bCall (LM_bSkkSetHenkanPointSubr, LM_bSkkProcessPrefixOrSuffix_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkProcessPrefixOrSuffix_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->bInsertAndInherit (L">", 1) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkProcessPrefixOrSuffix_3 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	int		nPoint, nHenkanStartPoint, nLength ;
	LPCDSTR		pwBufferString ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->bInsertAndInherit (L">", 1) ;
	pBuffer->bSkkSetSkkHenkanEndPointToPoint () ;
	pBuffer->vSkkSetSkkHenkanCount (0) ;
	nPoint				= pBuffer->iGetPoint () ;
	nHenkanStartPoint	= MAX (0, pBuffer->iSkkGetSkkHenkanStartPoint ()) ;
	pwBufferString		= pBuffer->pBufferRawString (&nLength) ;
	pBuffer->vSkkSetSkkHenkanKey (pwBufferString + nHenkanStartPoint, nPoint - nHenkanStartPoint) ;
	pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
	pBuffer->vSkkSetSkkAfterPrefix (LTRUE) ;
	pThis->vJump (LM_bSkkHenkan) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kana-input
 */
/*	LMREG_0				nQueueLen
 *	LMREG_1				pwQueue
 *	LMREG_2				pData
 *	LMREG_3				pNext
 */
int
CImeDoc::LM_bSkkKanaInput (
	CImeDoc*		pThis)
{
	DCHAR*		pwQueue ;
	LPDSTR		pwBuffer ;
	int			nQueue ;

	pwQueue		= (DCHAR*) pThis->pAlloca (64 * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwQueue == NULL)
		return	LMR_ERROR ;

	pwBuffer	= (LPDSTR) pThis->pAlloca (sizeof (DCHAR) * MAXCOMPLEN, __alignof (DCHAR)) ;
	if (pwBuffer == NULL)
		return	LMR_ERROR ;

	if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1) ||
		! pThis->bPushReg (LMREG_2) || ! pThis->bPushReg (LMREG_3) ||
		! pThis->bPushReg (LMREG_4) || ! pThis->bPushReg (LMREG_5))
		return	LMR_ERROR ;

	nQueue				= 0 ;
	pwQueue [nQueue ++]	= (DCHAR) pThis->iGetLastCommandChar () ;
	pThis->vSetRegInteger	(LMREG_0, nQueue) ;
	pThis->vSetRegString	(LMREG_1, pwQueue,	64) ;
	pThis->vSetRegString	(LMREG_5, pwBuffer,	MAXCOMPLEN) ;
	pThis->vJump (LM_bSkkKanaInput_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaInput_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR*		pwQueue ;
	int			nQueueLen, nQueueSize ;
	LPCDSTR		pNextState ;
	LPCDSTR		pPrefix ;
	int			nNextState, i, nPrefix ;
	DCHAR		bufNextState [64] ;
	CSkkRuleTreeIterator*			piteSkkRuleTree	= NULL ;
	const CSkkRuleTreeNodeOutput*	pData	= NULL ;

	pNextState	= NULL ;
	nNextState	= 0 ;
	nPrefix		= 0 ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegInteger (LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;
	if (! pThis->bGetRegString  (LMREG_1, &pwQueue, &nQueueSize)) {
		pwQueue		= NULL ;
		nQueueSize	= 0 ;
	}
	if (nQueueLen <= 0) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;

	if (! piteSkkRuleTree->bHavePrefixp () || piteSkkRuleTree->pGetPrefix (&nPrefix) == NULL) {
		/* ���̏ꏊ�������̊J�n�ʒu�Ƃ���B*/
		pBuffer->bSkkSetSkkKanaStartPointToPoint () ;
		/* Rule-Tree �̍��ɖ߂�B*/
		piteSkkRuleTree->vMoveToRoot (pThis->m_pConfig) ;
		pPrefix	= NULL ;
		nPrefix	= 0 ;
	} else {
		pBuffer->bSkkErasePrefix (FALSE) ;
		pPrefix	= piteSkkRuleTree->pGetPrefix (&nPrefix) ;
	}
	/* skk-prefix �� skk-get-prefix + last-command-char */
	if ((nPrefix + 1) > MAXLEN_PREFIX) {
		/* �v���t�B�N�X�o�b�t�@�[����ꂽ�ꍇ�c�B*/
		pBuffer->bSkkErasePrefix (FALSE) ;
		pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
		piteSkkRuleTree->vReset () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (nPrefix > 0) {
		pBuffer->vSkkSetSkkPrefix (pPrefix, nPrefix) ;
	}
	pBuffer->bSkkAddSkkPrefix (pThis->iGetLastCommandChar ()) ;
	/*	pBuffer->m_bufSkkPrefix [nPrefix]	= ImeDoc_iGetLastCommandChar (pBuffer->m_pDoc) ;
		pBuffer->m_nSkkPrefixLen			= nPrefix + 1 ; */

	pData	= NULL ;
	if (piteSkkRuleTree->bHaveSelectBranchp (pwQueue [0])) {
		if (piteSkkRuleTree->bNextHasBranchListp (pwQueue [0])) {
			int		nCH	= pwQueue [0] ;
			if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE &&
				CImeConfig::bSkkKakuteiEarlyp (pThis->m_pConfig) && !CImeConfig::bSkkProcessOkuriEarlyp (pThis->m_pConfig)) {
				/* !! */
				pThis->vSetRegConstString	(LMREGARG_0, NULL, 0) ;
				pThis->vSetRegInteger		(LMREG_0, nQueueLen) ;
				pThis->vSetRegConstPointer	(LMREG_2, pData) ;
//				pThis->vSetRegPointer		(LMREG_3, (void*)pNext) ;
				pThis->vSetRegInteger		(LMREG_3, pwQueue [0]) ;
				if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_1_1))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			}
			memmove (pwQueue, pwQueue + 1, sizeof (pwQueue [0]) * (nQueueLen - 1)) ;
			nQueueLen	-- ;
			piteSkkRuleTree->vWalk (nCH) ;
		} else {
			int		nNextState, i, nNextTree ;

			piteSkkRuleTree->vWalk (pwQueue [0]) ;
			pData		= piteSkkRuleTree->pGetOutput () ;
			nNextState	= piteSkkRuleTree->iGetNextState (bufNextState, MYARRAYSIZE (bufNextState), &nNextTree) ;
			piteSkkRuleTree->vMoveTree (nNextTree) ;
			if ((nNextState + nQueueLen - 1) < nQueueSize) {
				memmove (pwQueue + nNextState, pwQueue + 1, sizeof (pwQueue [0]) * (nQueueLen - 1)) ;
				for (i = 0 ; i < nNextState ; i ++)
					pwQueue [i]	= bufNextState [i] ;
				nQueueLen	= nNextState + nQueueLen - 1 ;
			} else {
				/* �L���[����ꂽ�ꍇ�c�B���̏������������̂��ǂ����͓�B*/
				piteSkkRuleTree->vReset () ;

				/* exit state �ցB*/
				pThis->vJump (LM_bSkkKanaInput_Exit) ;
				return	LMR_CONTINUE ;
			}
			piteSkkRuleTree->vReset () ;
		}
	} else {
		const CSkkRuleTreeNodeOutput*	pD ;

		pD	= piteSkkRuleTree->pGetOutput () ;
		if (pD != NULL) {
			int		nNextTree ;

			nNextState	= 0 ;
			pData		= pD ;
			if (piteSkkRuleTree->bHavePrefixp ()) {
				nNextState	= piteSkkRuleTree->iGetNextState (bufNextState, MYARRAYSIZE (bufNextState), &nNextTree) ;
			} else {
				nNextTree	= piteSkkRuleTree->iGetRuleTree () ;
			}
			piteSkkRuleTree->vMoveTree (nNextTree) ;

			if ((nNextState + nQueueLen) < nQueueSize) {
				if (nNextState > 0) {
					memmove (pwQueue + nNextState, pwQueue, sizeof (pwQueue [0]) * nQueueLen) ;
					for (i = 0 ; i < nNextState ; i ++)
						pwQueue [i]	= bufNextState [i] ;
					nQueueLen	= nNextState + nQueueLen ;
				}
			} else {
				/* �L���[����ꂽ�ꍇ�c�B���̏������������̂��ǂ����͓�B*/
				piteSkkRuleTree->vReset () ;

				/* exit state �ցB*/
				pThis->vJump (LM_bSkkKanaInput_Exit) ;
				return	LMR_CONTINUE ;
			}
			piteSkkRuleTree->vReset () ;
		} else {
			/*	oh ���Ȃ���΁ApDD == NULL �͕K�������B
			 */
			if (piteSkkRuleTree->bRootp (pThis->m_pConfig)) {
				nQueueLen						= 0 ;
				piteSkkRuleTree->vReset () ;
			} else {
				piteSkkRuleTree->vReset () ;
			}
		}
	}


	pThis->vSetRegInteger		(LMREG_0, nQueueLen) ;
	pThis->vSetRegConstPointer	(LMREG_2, pData) ;

	/* pData ���n���Ȃ��Ƃ����Ȃ��B*/
	pThis->vJump (LM_bSkkKanaInput_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaInput_1_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR*		pwQueue ;
	int			nQueueLen, nQueueSize ;
//	const CSkkRuleTreeNode*	pNext ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;
	int			wch ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegInteger (LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;
	if (! pThis->bGetRegString  (LMREG_1, &pwQueue, &nQueueSize)) {
		pwQueue		= NULL ;
		nQueueSize	= 0 ;
	}
//	if (! pThis->bGetRegPointer (LMREG_3, (void**)&pNext)) 
//		pNext	= NULL ;
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	if (pThis->bGetRegInteger (LMREG_3, &wch)) {
		piteSkkRuleTree->vWalk (wch) ;
	} else {
		piteSkkRuleTree->vReset () ;
	}

	/* !! */
	pBuffer->bSkkSetSkkKanaStartPointToPoint () ;

	memmove (pwQueue, pwQueue + 1, sizeof (pwQueue [0]) * (nQueueLen - 1)) ;
	nQueueLen	-- ;
//	pBuffer->vSkkSetSkkCurrentRuleTree (pNext) ;

	pThis->vSetRegInteger (LMREG_0, nQueueLen) ;
	pThis->vJump (LM_bSkkKanaInput_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaInput_3 (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	int						nQueueLen ;
	LPCDSTR					pPrefix ;
	int						nPrefix ;
	const CSkkRuleTreeNodeOutput*	pData	= NULL ;

	pPrefix	= NULL ;
	nPrefix	= 0 ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegInteger (LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;
	if (! pThis->bGetRegConstPointer (LMREG_2, (const void**)&pData))
		pData	= NULL ;

	if (pData == NULL) {
		pPrefix	= pBuffer->pSkkGetSkkRuleTreeIterator ()->pGetPrefix (&nPrefix) ;
//		pPrefix	= (pBuffer->pSkkGetSkkCurrentRuleTree () != NULL)? CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) : NULL ;
//		if (pPrefix != NULL) {
		if (pPrefix != NULL && nPrefix > 0) {
			pBuffer->vSkkSetSkkPrefix (pPrefix, nPrefix) ;
			pBuffer->bSkkInsertPrefix (pPrefix, nPrefix) ;	//pBuffer->_bSkkInsertPrefix (pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;
		} else {
			if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
				/* !! */
				pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
				if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_3_1))
					return	LMR_ERROR ;
				/* !! */
			} else {
				pThis->vJump (LM_bSkkKanaInput_3_1) ;
			}
			return	LMR_CONTINUE ;
		}
		//pThis->vJump (LM_bSkkKanaInput_1) ;
		//return	LMR_CONTINUE ;
	} else {
		int		nType ;

		pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
		/*
		 *	  (when (functionp data)
		 *		(setq data (funcall data (skk-make-raw-arg arg))))
		 */
		/*	�ǂ��g���������̂��Y�ނ��ǁAdata �� stringp �̂��Ƃ������̎����ł͍l���Ȃ��B
		 *	���R�́c�����炻�̃R�[�h�������ɂ́A��񂪑���Ȃ�����B�����܂����̂��A�ǂ�
		 *	�����������ǂ������̂��A�ォ��ēx���������B
		 */
		nType	= pData->iGetType () ;
		if (nType == CSkkRuleTreeNodeOutput::NTYPE_MACRO) {
			const CSkkRuleTreeNodeOutputMacro*	pDataMacro	= static_cast <const CSkkRuleTreeNodeOutputMacro*> (pData) ;
			PLMFUNC	pPC ;

			/* !! */
			pPC		= pThis->pLookupLMState (pDataMacro->iGetFunctionCode ()) ;
			if (pPC != NULL) {
				/*	argument �� clear ���Ă����K�v������Ǝv���c�����B
				 *	����Aarg �͓����I�ɂ����g��Ȃ����� call-interactive �� function
				 *	�� nil ���Ǝv������ł��邵���v���H
				 *	(Fri Jun 09 12:01:33 2006)
				 */
				if (! pThis->bCall (pPC, LM_bSkkKanaInput_3_2))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			}
			/*	�I�I ������ loop �̓��ɖ߂�̂͗ǂ��Ȃ��̂�������Ȃ����ǁc�B
			 *	���� '("" . "") �Ȍ��ʂ� macro ���Ԃ���Ƃ��ĂȂ��̂Łc
			 *	�����A�Ԃ�l��p�̃��W�X�^�Ƃ��p�ӂ��Ȃ��Ɩ{���͑ʖڂ����c�B
			 *	�ƂȂ�ƁALMR_RETURN ���鎞�� set ���Ȃ��Ƃ����Ȃ��ȁc�B
			 */
			pThis->vJump (LM_bSkkKanaInput_1) ;
			return	LMR_CONTINUE ;
		}
		if (nType == CSkkRuleTreeNodeOutput::NTYPE_STRINGPAIR || nType == CSkkRuleTreeNodeOutput::NTYPE_STRING) {
			LPCDSTR		wptr ;
			int			nwptr ;

			if (nType == CSkkRuleTreeNodeOutput::NTYPE_STRINGPAIR) {
				const CSkkRuleTreeNodeOutputStringPair*	pDataPair	= static_cast <const CSkkRuleTreeNodeOutputStringPair*> (pData) ;

				if (pBuffer->bSkkGetSkkKatakana ()) {
					wptr	= pDataPair->pGetKatakana (&nwptr) ;
				} else {
					wptr	= pDataPair->pGetHiragana (&nwptr) ;
				}
			} else {
				const CSkkRuleTreeNodeOutputString*	pDataStr	= static_cast <const CSkkRuleTreeNodeOutputString*> (pData) ;
				wptr	= pDataStr->pGetString (&nwptr) ;
			}
			/* insert-paren �� through �c�B*/
			if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE &&
				CImeConfig::bSkkKakuteiEarlyp (pThis->m_pConfig) && !CImeConfig::bSkkProcessOkuriEarlyp (pThis->m_pConfig)) {
				/* !! */
				pThis->vSetRegString (LMREGARG_0, NULL, 0) ;
				/* wptr, nwptr �� heap �̏���w���Ă���̂ŁA�����ł͉������Ȃ��ƍl���ėǂ��B*/
				pThis->vSetRegConstString (LMREG_4, wptr, nwptr) ;
				if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_4))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
				/* !! */
			}
			pThis->vSetRegConstString (LMREG_4, wptr, nwptr) ;
			pThis->vJump (LM_bSkkKanaInput_4) ;
			return	LMR_CONTINUE ;
		}
	}
	/*
	 */
	pThis->vJump (LM_bSkkKanaInput_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaInput_3_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	int				nQueueLen ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegInteger (LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;

	pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
	if (! (nQueueLen > 0 || (pThis->iGetThisCommand () != NFUNC_SKK_INSERT && pBuffer->bSkkGetSkkHenkanMode ()))) {
		/* !! */
		if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkKanaInput_1))
			return	LMR_ERROR ;
		/* !! */
		return	LMR_CONTINUE ;
	}
	/* while (nQueueLen > 0) �̃��[�v�̓��ւƖ߂�B*/
	pThis->vJump (LM_bSkkKanaInput_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaInput_3_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	LPDSTR			pwBuffer ;
	LPCDSTR			pwString = NULL, pwLeft = NULL, pwRight = NULL ;
	LPCDSTR			pwResult ;
	int				nString, nLeft, nRight, n, nResultLen, nBufferSize ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	pwResult	= NULL ;
	nResultLen	= 0 ;
	if (! pThis->bGetRegString (LMREG_5, &pwBuffer, &nBufferSize)) {
		pwBuffer	= NULL ;
		nBufferSize	= 0 ;
	}

	/*	���͂��́upwString�v�͒N���m�ۂ����̈�Ȃ̂��Ƃ������Ƃ��B���̊֐������O�ɗp�ӂ��Ă���
	 *	�Ƃ����͓̂���Bargument �ɓ����Ƃ����̂́u�C�ӂ� function ���Ă΂�邩���v�̏󋵂ł�
	 *	���������ɂȂ��Bheap �̂悤�Ȃ��̂�p�ӂ���K�v������̂��낤���c�B
	 *
	 *	return buffer �Ƃ������̂�p�ӂ��邩�BRETVAL �̊g�������BLMREGARG_RETVAL �Ɠ����x�̊��Ԓ��x
	 *	�����ێ�����Ȃ� funcall �������Ă̎󂯓n���̂��߂ɂ����g����̈�B
	 *	������Areturn ���Ė߂������͑����� my heap �� my stack �ɃR�s�[���ăf�[�^��ی삵�Ȃ��Ƃ���
	 *	�Ȃ��B
	 *	return buffer �� document class ��1���������Ă���B
	 */
	if (pThis->bGetRegConstString (LMREGARG_RETVAL, &pwString, &nString)) {
		/*	���� pwString �� m_bufRETURN ���w���Ă���̂ŁAFREE �͂��Ȃ��ŗǂ��B(�Ƃ��������ɂ���)
		 */
		if (pwString != NULL && nString > 0) {
			n			= MIN (nString, nBufferSize) ;
			dcsncpy (pwBuffer, pwString, n) ;
			pwResult	= pwBuffer ;
			nResultLen	= n ;
		}
	} else if (pThis->bGetRegConstStringPair (LMREGARG_RETVAL, &pwLeft, &nLeft, &pwRight, &nRight)) {
		/*	���� pwLeft, pwRight �� m_bufRETURN ���w���Ă���̂ŁAFREE �͂��Ȃ��ŗǂ��B(�Ƃ���������
		 *	����)
		 */
		pwString	= pBuffer->bSkkGetSkkKatakana ()? pwRight : pwLeft ;
		nString		= pBuffer->bSkkGetSkkKatakana ()? nLeft   : nRight ;
		if (pwString != NULL && nString > 0) {
			n			= MIN (nString, nBufferSize) ;
			dcsncpy (pwBuffer, pwString, n) ;
			pwResult	= pwBuffer ;
			nResultLen	= n ;
		}
	} else {
		pThis->vJump (LM_bSkkKanaInput_1) ;
		return	LMR_CONTINUE ;
	}
	/* insert-paren �� through �c�B*/
	if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE &&
		CImeConfig::bSkkKakuteiEarlyp (pThis->m_pConfig) && !CImeConfig::bSkkProcessOkuriEarlyp (pThis->m_pConfig)) {
		pThis->vSetRegString (LMREGARG_0, NULL, 0) ;
		/* wptr, nwptr �� heap �̏���w���Ă���̂ŁA�����ł͉������Ȃ��ƍl���ėǂ��B*/
		pThis->vSetRegConstString (LMREG_4, pwString, nString) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_4))
			return	LMR_ERROR ;
	} else {
		pThis->vSetRegConstString (LMREG_4, pwString, nString) ;
		pThis->vJump (LM_bSkkKanaInput_4) ;
	}
	return	LMR_CONTINUE ;
}

/*	skk-kana-input �� skk-insert-str �����̏����Bdata ���m�肵�� buffer �ɕ����񂪑}�������B
 */
int
CImeDoc::LM_bSkkKanaInput_4 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	LPCDSTR			wptr ;
	int				nwptr ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegConstString (LMREG_4, &wptr, &nwptr)) {
		wptr	= NULL ;
		nwptr	= 0 ;
	}
	pThis->vSetRegConstString (LMREGARG_0, wptr, nwptr) ;
	if (! pThis->bCall (LM_bSkkInsertStr, LM_bSkkKanaInput_4_0))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

/*	skk-kana-input �r���ł� skk-auto-insert-paren �̏����Bbuffer �ɑ}�����ꂽ����������āAparen
 *	�Ȃ� pair ��ǉ��B
 */
int
CImeDoc::LM_bSkkKanaInput_4_0 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	LPCDSTR			wptr ;
	int				nwptr ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegConstString (LMREG_4, &wptr, &nwptr)) {
		wptr	= NULL ;
		nwptr	= 0 ;
	}
	/*	skk-auto-insert-paren �̏����B
	 */
	if (nwptr > 0 && CImeConfig::bSkkAutoInsertParen (pThis->m_pConfig)) {
		DCHAR	bufPairStr [MAXCOMPLEN] ;
		int		nPairStr ;

			/*
		      (when pair
				(while (> count1 0)
				  (if (not (string= pair (char-to-string (following-char))))
				      (progn
						(setq inserted (1+ inserted))
						(skk-insert-str pair)))
				  (setq count1 (1- count1)))
				(unless (= inserted 0)
				  (backward-char inserted)))
				  */
		nPairStr	= CImeConfig::iSkkAssocSkkAutoParenStringAlist (pThis->m_pConfig, wptr, nwptr, bufPairStr, MYARRAYSIZE (bufPairStr)) ;
		if (nPairStr > 0) {
			if (! pBuffer->bFollowingStringEqualp (bufPairStr, nPairStr)) {
				LPDSTR	pwBuffer ;
				int		n, nBufferSize ;

				/*	LMREG_5 �Ɋm�ۂ���Ă����o�b�t�@�𗘗p����B
				 *	����́Aparen ����Ɏg���� result ��ێ����Ă����ꏊ�ł��邪�A
				 *	���� result �͎g��Ȃ��̂ŁB
				 */
				if (! pThis->bGetRegString (LMREG_5, &pwBuffer, &nBufferSize)) {
					pwBuffer	= NULL ;
					nBufferSize	= 0 ;
				}
				n	= MIN (nBufferSize, nPairStr) ;
				if (n > 0)
					dcsncpy (pwBuffer, bufPairStr, n) ;
				pThis->vSetRegConstString (LMREGARG_0, pwBuffer, n) ;

				/*	���݂̃J�[�\���ʒu���L������c�B�{���̓}�[�J���g�������̂����c�X�^�b�N���
				 *	�}�[�J��������Ɖ���ł��邩�ǂ����������̂ŁB(�G���[�A��O�����̓r����)
				 *
				 *	������ REG_4 �� integer �ɕς��Ă��܂��Ă���B
				 */
				pThis->vSetRegInteger (LMREG_4, pBuffer->iGetPoint ()) ;

				if (! pThis->bCall (LM_bSkkInsertStr, LM_bSkkKanaInput_4_0_1))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			}
		}
	}
	pThis->vJump (LM_bSkkKanaInput_4_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaInput_4_0_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	int	nPoint ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL && pThis->bGetRegInteger (LMREG_4, &nPoint)) {
		int		nCurPoint ;
		nCurPoint	= pBuffer->iGetPoint () ;
		pBuffer->bBackwardChar (nCurPoint - nPoint) ;
	}
	pThis->vJump (LM_bSkkKanaInput_4_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaInput_4_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	int						nQueueLen ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegInteger (LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;

	if (pBuffer->bSkkGetSkkOkurigana () && nQueueLen <= 0) {
		/* !! */
		/*	Jisx0201 �̉e���F
		/*	defadvice �� skk-set-okurigana �̌Ăяo���́A�܂� skk-set-okurigana-ad-jisx0201 �ɂ����
		 *	wrap �����B
		 *		if (! pThis->bCall (LM_bSkkSetOkurigana, LM_bSkkKanaInput_1))
		 *			return	LMR_ERROR ;
		 */
		if (! pThis->bCall (LM_bSkkSetOkuriganaAdJisx0201, LM_bSkkKanaInput_1))
			return	LMR_ERROR ;
		/* !! */
	} else {
		pThis->vJump (LM_bSkkKanaInput_1) ;
	}
	return	LMR_CONTINUE ;
}


int
CImeDoc::LM_bSkkKanaInput_Exit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
	} else {
		/* skk-point-move �̌��ʁB*/
		pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	}

	/* ������ pop ������ signal �̗L���Ɋւ�炸���s���Ȃ���΂Ȃ�Ȃ��B*/
	pThis->vPopReg (LMREG_5) ;
	pThis->vPopReg (LMREG_4) ;
	pThis->vPopReg (LMREG_3) ;
	pThis->vPopReg (LMREG_2) ;
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-start-henkan
 */
int
CImeDoc::LM_bSkkStartHenkan (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pBuffer->vSkkSetSkkHenkanCount (pBuffer->iSkkGetSkkHenkanCount () + 1) ;
		pThis->vJump (LM_bSkkHenkan) ;
	} else {
		pThis->vSetRegBool (LMREGARG_0, TRUE) ;
		if (! pThis->bCall (LM_bSkkKanaCleanup, LM_bSkkStartHenkan_1))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkStartHenkan_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	CTMarker*	pmkSkkHenkanStartPoint ;
	LPCDSTR		pwBufferString ;
	int			nPrefix, nPos, nHenkanStartPoint, nBufferStringLen ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	if (piteSkkRuleTree->bHavePrefixp () && piteSkkRuleTree->pGetPrefix (&nPrefix) != NULL) {
//	if (pBuffer->pSkkGetSkkCurrentRuleTree () != NULL && CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) != NULL) {
		/* skk-error "Have unfixed skk-prefix" */
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	nPos					= pBuffer->iGetPoint () ;
	pmkSkkHenkanStartPoint	= pBuffer->pSkkGetSkkHenkanStartPointMarker () ;
	if (pmkSkkHenkanStartPoint == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	nHenkanStartPoint	= pmkSkkHenkanStartPoint->iGetPosition () ;
	if (nPos < nHenkanStartPoint) {
		/* skk-error "Henkan end point must be after henkan start point" */
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pwBufferString	= pBuffer->pBufferRawString (&nBufferStringLen) ;
	pBuffer->vSkkSetSkkHenkanKey (pwBufferString + nHenkanStartPoint, nPos - nHenkanStartPoint) ;
	if (pBuffer->bSkkGetSkkKatakana ()) {
		DCHAR	bufTemp [MAXCOMPLEN] ;
		LPCDSTR	pwHenkanKey ;
		int		nHenkanKeyLen, nNewHenkanKeyLen ;

		pwHenkanKey			= pBuffer->pSkkGetSkkHenkanKey (&nHenkanKeyLen) ;
		nNewHenkanKeyLen	= iSkkKatakanaToHiragana (bufTemp, MYARRAYSIZE (bufTemp), pwHenkanKey, nHenkanKeyLen, FALSE) ;
		pBuffer->vSkkSetSkkHenkanKey (bufTemp, nNewHenkanKeyLen) ;
	}
	if (pBuffer->bSkkGetSkkOkurigana ()) {
		if (! pBuffer->bSkkValidSkkOkuriHenkanKeyp ()) {
			/* skk-error "No okurgana!" */
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
	}
	if (CImeConfig::bSkkAllowsSpacesNewlinesAndTabs (pThis->m_pConfig)) {
		pBuffer->bSkkNormalizeHenkanKey (TRUE) ;
	} else {
		if (! pBuffer->bSkkNormalizeHenkanKey (FALSE)) {
			/* skk-error "Henkan key may not contain a new line character" */
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
	}
	pBuffer->bSkkSetSkkHenkanEndPointToPoint () ;
	pBuffer->vSkkSetSkkHenkanCount (0) ;

	if (! pThis->bCall (LM_bSkkHenkan, LM_bSkkStartHenkan_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkStartHenkan_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->bAbbrevModep () && pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pBuffer->bSkkJModeOn (pBuffer->bSkkGetSkkKatakana ()) ;
		pBuffer->vSkkSetSkkAbbrevMode (LTRUE) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-previous-candidate
 */
int
CImeDoc::LM_bSkkPreviousCandidate (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->bSkkGetSkkHenkanMode () != LACTIVE) {
		if (pThis->iGetLastCommand () != NFUNC_SKK_KAKUTEI_HENKAN) {
			/* last-command-char �͍��̂Ƃ����� characterp ���H */
			if (! pThis->bCall (LM_bSkkKanaInput, LM_bSkkPreviousCandidate_Exit))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		} else {
			if (! pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iGetPoint ())) {
				pThis->vSetSignalError () ;
				pThis->vJump (LM_bSkkPreviousCandidate_Exit) ;
				return	LMR_CONTINUE ;
			}
			if (! pThis->bCall (LM_bSkkSetHenkanPointSubr, LM_bSkkPreviousCandidate_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	} else if (pBuffer->iSkkGetSkkHenkanKeyLength () == 0) {
			pThis->vJump (LM_bSkkPreviousCandidate_Exit) ;
			return	LMR_CONTINUE ;
	} else {
		CTMarker*	pmkMark		= NULL ;

		if (! pBuffer->bEobp ()) {
			pmkMark		= pBuffer->pMakeMarker (TRUE) ;
			if (pmkMark != NULL) {
				pmkMark->bSetPosition (pBuffer->pGetPointMarker ()) ;
				pmkMark->bForward (1) ;
			}
		}
		if (pBuffer->iSkkGetSkkHenkanCount () == 0) {
			LPCDSTR	pwSkkHenkanKey ;
			int		nSkkHenkanKeyLen ;
			int		nSkkOkuriCharLen ;
			LPCDSTR	pwPrefix ;
			int		nPrefixLen ;
			CTMarker*	pmkSkkKanaStartPoint	= NULL ;

			(void) pBuffer->pSkkGetSkkOkuriChar (&nSkkOkuriCharLen) ;
			if (nSkkOkuriCharLen > 0) {
				pwSkkHenkanKey	= pBuffer->pSkkGetSkkHenkanKey (&nSkkHenkanKeyLen) ;
				if (nSkkHenkanKeyLen > 0) 
					pBuffer->vSkkSetSkkHenkanKey (pwSkkHenkanKey, nSkkHenkanKeyLen - 1) ;
			}
			if (pBuffer->bSkkGetSkkKatakana ()) {
				DCHAR	bufTemp [MAXCOMPLEN] ;
				int		iNewHenkanKeyLen ;

				pwSkkHenkanKey		= pBuffer->pSkkGetSkkHenkanKey (&nSkkHenkanKeyLen) ;
				iNewHenkanKeyLen	= iSkkHiraganaToKatakana (bufTemp, MYARRAYSIZE (bufTemp), pwSkkHenkanKey, nSkkHenkanKeyLen, FALSE) ;
				pBuffer->vSkkSetSkkHenkanKey (bufTemp, iNewHenkanKeyLen) ;
			}
			pBuffer->vSkkSetSkkHenkanCount (-1) ;
			/* skk-henkan-in-minibuff-flag = nil */
			pBuffer->vSkkSetSkkHenkanInMinibuffFlag (LFALSE) ;
			/* skk-henkan-list = nil */
			pBuffer->vSkkClearOkurigana () ;
			pBuffer->vSkkSetSkkHenkanOkurigana (NULL, 0) ;

			pwPrefix				= pBuffer->pSkkGetSkkPrefix (&nPrefixLen) ;
			if (nPrefixLen > 0) {
				int	nKanaStartPoint	= pBuffer->iSkkGetSkkKanaStartPoint () ;

				if (nKanaStartPoint < 0 || (nKanaStartPoint + nPrefixLen) > pBuffer->iGetPointMax ()) {
					pwPrefix	= NULL ;
					nPrefixLen	= 0 ;
				} else {
					LPCDSTR		pwBufferString ;
					int			nBufferStringLength ;

					/*	�����ݕ\������Ă��� Prefix �Ǝ��ۂ� Prefix �̒��g����v���Ă��邩�ǂ���
					 *	������B
					 */
					pwBufferString	= pBuffer->pBufferRawString (&nBufferStringLength) ;
					if (memcmp (pwBufferString + nKanaStartPoint, pwPrefix, nPrefixLen * sizeof (DCHAR)) != 0) {
						pwPrefix	= NULL ;
						nPrefixLen	= 0 ;
					}
				}
			}
			pBuffer->vSkkSetSkkPrefix (pwPrefix, nPrefixLen) ;

			pmkSkkKanaStartPoint	= pBuffer->pSkkGetSkkKanaStartPointMarker () ;
			if (pmkSkkKanaStartPoint != NULL && pmkSkkKanaStartPoint->bIsValidp ())
				pmkSkkKanaStartPoint->vSetCursor (TRUE) ;
			/* (when (skk-numeric-p) ... */
			pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iSkkGetSkkHenkanEndPoint ()) ;

			pwSkkHenkanKey		= pBuffer->pSkkGetSkkHenkanKey (&nSkkHenkanKeyLen) ;
			pBuffer->iInsert (pBuffer->pSkkGetSkkHenkanEndPointMarker (), pwSkkHenkanKey, nSkkHenkanKeyLen) ;
			if (pmkSkkKanaStartPoint != NULL && pmkSkkKanaStartPoint->bIsValidp ())
				pmkSkkKanaStartPoint->vSetCursor (FALSE) ;
			pBuffer->bSkkChangeMarkerToWhite () ;
		} else {
			CTSearchSession*	pSession ;

			pBuffer->vSkkSetSkkHenkanCount (pBuffer->iSkkGetSkkHenkanCount () - 1) ;

			/*	skk-insert-new-word ... skk-get-current-candidate ... skk-henkan-list �̌`�����C�ɂȂ�ȁB
			 *	���ʂ� skk-get-current-candidate-1 �� car �� cdr ���Ƃ�Ƃǂ��Ȃ�H
			 */
			pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
			if (pSession != NULL) {
				LPCDSTR	wstrNewWord ;
				int		n ;
				
				pSession->bRewind () ;
				n	= pBuffer->iSkkGetSkkHenkanCount () ;
				while (n -- > 0) {
					if (! pSession->bNextCandidate ())
						break ;
				}
				wstrNewWord	= pSession->pGetCandidate () ;
				if (wstrNewWord != NULL) {
					if (! pBuffer->bSkkInsertNewWord (wstrNewWord, dcslen (wstrNewWord)))
						return	FALSE ;
				}
			}
		}
		if (pmkMark != NULL) {
			CTMarker*	pmkPoint	= pBuffer->pGetPointMarker () ;
			pmkPoint->bSetPosition (pmkMark) ;
			pmkPoint->bBackward (1) ;
			pBuffer->bDeleteMarker (pmkMark) ;
		} else {
			/* (point-max) �܂� cursor ���ړ��B*/
			CTMarker*	pmkPoint	= pBuffer->pGetPointMarker () ;
			pmkPoint->bForward (pBuffer->iGetPointMax () - pmkPoint->iGetPosition ()) ;
		}
		if (pBuffer->bAbbrevModep () && pBuffer->iSkkGetSkkHenkanCount () == -1) {
			/* skk-abbrev-mode-on */
			pBuffer->bSkkAbbrevModeOn () ;
		}
		pThis->vJump (LM_bSkkPreviousCandidate_Exit) ;
		return	LMR_CONTINUE ;
	}
}

int
CImeDoc::LM_bSkkPreviousCandidate_1 (
	CImeDoc*		pThis)
{
	/* skk-get-last-henkan-datum �͂Ȃ��c
	 */
	pThis->bSetThisCommand (NFUNC_SKK_UNDO_KAKUTEI_HENKAN) ;
	pThis->vJump (LM_bSkkPreviousCandidate_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkPreviousCandidate_Exit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan
 */
/*	recursive-edit �ɓ���^�C�~���O���N���e�B�J���B
 */
int
CImeDoc::LM_bSkkHenkan (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	CTMarker*		pmkMark			= NULL ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->iSkkGetSkkHenkanKeyLength () == 0) {
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		pThis->vJump (LM_bSkkKakuteiAdJisx0201) ;
		return	LMR_CONTINUE ;
	} 

	if (! pThis->bPushReg (LMREG_1))
		return	LMR_ERROR ;

	if (! pBuffer->bEobp ()) {
		pmkMark		= pBuffer->pMakeMarker (TRUE) ;
		if (pmkMark != NULL) {
			pmkMark->bSetPosition (pBuffer->pGetPointMarker ()) ;
			pmkMark->bForward (1) ;
		}
	}
	pThis->vSetRegPointer (LMREG_1, pmkMark) ;

	if (pBuffer->bSkkGetSkkHenkanMode () != LACTIVE) {
		if (! pThis->bCall (LM_bSkkChangeMarker, LM_bSkkHenkan_1))
			return	LMR_ERROR ;
	} else {
		if (! pThis->bCall (LM_bSkkHenkan1, LM_bSkkHenkan_3))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkan_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*			pBuffer ;
	int					iSearchType ;
	CTSearchSession*	pSession	= NULL ;
	LPCDSTR				pwSkkHenkanKey ;
	int					iSkkHenkanKeyLen ;
	LPCDSTR				pwOkurigana	= NULL ;
	int					nOkurigana	= 0 ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}

	/* (skk-current-search-prog-list skk-search-prog-list) */
	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (pSession != NULL) {
		pBuffer->vSkkSetSkkCurrentSearchProgSession (NULL) ;
	}
	pwSkkHenkanKey	= pBuffer->pSkkGetSkkHenkanKey (&iSkkHenkanKeyLen) ;

	/* ���艼������̏ꍇ�͒��Ӂc*/
	/*  okurigana (or skk-henkan-okurigana skk-okuri-char)) 
	 *
	 *	[2009/01/10] keyboard-quit �ő��艼���ϊ����~�߂����A�h�ϊ����艼���h��
	 *	�N���A����Ă��Ȃ����߁A�����ϊ�������Ȃ��ϊ��̎��A���艼���ϊ��ƌ����
	 *	��Ă��������Ȃ�Bprevious-candidate �ŕϊ����艼�����N���A����K�v������B
	 */
	pwOkurigana	= pBuffer->pSkkGetSkkHenkanOkurigana (&nOkurigana) ;
	if (nOkurigana <= 0) {
		pwOkurigana	= pBuffer->pSkkGetSkkOkuriChar (&nOkurigana) ;
	}
	/*	�����́A�ȉ��̃R�[�h�ő��艼��������̂��ǂ������肵�Ă����B
	 *		if (pBuffer->bSkkGetSkkOkurigana ()) {
	 *			.... ���艼�������鎞�̏���
	 *		} else {
	 *			.... ���艼�����Ȃ����̏���
	 *		}
	 *	�������Ȃ���A����ł� process-okuri-early �̎��ɐ��������삵�Ȃ��B
	 *	(skk-okurigana �� t �ɂ��Ȃ��j
	 *	�����Ŏ��ۂɑ��艼�����������݂��邩�ǂ����𔻒�����ɂ���B
	 */
	if (nOkurigana > 0) {
		/*	! ������ ImeDoc_bSkkHenkanOkuriStrictlyp �̌��ʂ��K�v���I �Ƃ����L���Ă����BWed Jul 05 22:06:11 2006
		 */
		if (CImeConfig::bSkkHenkanOkuriStrictlyp (pThis->m_pConfig)) {
			iSearchType	= SEARCH_OKURI_STRICT ;
		} else if (CImeConfig::bSkkHenkanStrictOkuriPrecedencep (pThis->m_pConfig)) {
			iSearchType	= SEARCH_OKURI_STRICT_PRECEDENCE ;
		} else {
			iSearchType	= SEARCH_OKURI_ARI ;
		}
		pSession	= new CTOkuriHenkanSession (pwSkkHenkanKey, iSkkHenkanKeyLen, pwOkurigana, nOkurigana, iSearchType, CImeConfig::bSkkNumericConversionp (pThis->m_pConfig), CImeConfig::bSkkNumConvertFloatp (pThis->m_pConfig)) ;
		if (pSession == NULL)
			return	LMR_ERROR ;
	} else {
		if (CImeConfig::bSkkAutoOkuriProcessp (pThis->m_pConfig)) {
			/* �ʏ�̌��� + ���艼�������邩������Ȃ������̑g�ݍ��킹�B*/
			iSearchType	= SEARCH_OKURI_AUTO ;
		} else {
			iSearchType	= SEARCH_OKURI_NASHI ;
		}
		pSession	= new CTHenkanSession (pwSkkHenkanKey, iSkkHenkanKeyLen, iSearchType, CImeConfig::bSkkNumericConversionp (pThis->m_pConfig), CImeConfig::bSkkNumConvertFloatp (pThis->m_pConfig)) ;
		if (pSession == NULL)
			return	LMR_ERROR ;
	}
	pBuffer->vSkkSetSkkCurrentSearchProgSession (pSession) ;

	if (! pThis->bCall (LM_bSkkHenkan1, LM_bSkkHenkan_3))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkan_3 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	int			nResultLen ;
	LPCDSTR		pwResult ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegConstString (LMREGARG_RETVAL, &pwResult, &nResultLen))
		nResultLen	= -1 ;

	if (nResultLen < 0) {
		/* signal ���󂯂��ꍇ�� < 0 ���߂�Ƃ���B*/
		pThis->vJump (LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (nResultLen > 0) {
		/*	pThis->vSetRegConstString (LMREGARG_RETVAL, pwResult, nResultLen) ;
		 *	LMREGARG_RETVAL �͂��̂܂܂� LM_bSkkHenkan_4 �ւƔ�ԁB
		 */
		pThis->vJump (LM_bSkkHenkan_4) ;
	} else {
		/* ���̏ꍇ�́Askk-henkan-in-minibuff �ɓ���B*/
		if (! pThis->bCall (LM_bSkkHenkanInMinibuff, LM_bSkkHenkan_4))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkan_4 (
	CImeDoc*		pThis)
{
	CImeBuffer*			pBuffer ;
	LPCDSTR				pNewWord ;
	int					nNewWordLen ;
	CTMarker*			pmkMark	= NULL ;
	BOOL				bKakuteiHenkan	= FALSE ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegConstString (LMREGARG_RETVAL, &pNewWord, &nNewWordLen)) {
		pNewWord	= NULL ;
		nNewWordLen	= 0 ;
	} else {
		/*	skk-henkan-in-minibuff �̕Ԃ�l�� m_bufRETURN �𗘗p���邪�ALM_bSkkHenkan_3 ����
		 *	�~��ė����ꍇ�ɂ́c
		 */
		LPDSTR		pwBuffer ;

		if (nNewWordLen > 0) {
			pwBuffer	= (LPDSTR) pThis->pAlloca (sizeof (DCHAR) * nNewWordLen, __alignof (DCHAR)) ;
			if (pwBuffer == NULL)
				return	LMR_ERROR ;
			dcsncpy (pwBuffer, pNewWord, nNewWordLen) ;
			pNewWord	= pwBuffer ;
		} else {
			pNewWord	= NULL ;
		}
		nNewWordLen	= nNewWordLen ;

		bKakuteiHenkan	= pBuffer->bSkkGetSkkKakuteiFlag () ;
	}
	if (! pThis->bGetRegPointer (LMREG_1, (void**)&pmkMark))
		pmkMark			= NULL ;

	if (nNewWordLen > 0) {
		/* skk-insert-new-word new-word */
		pBuffer->bSkkInsertNewWord (pNewWord, nNewWordLen) ;
	}
	if (pmkMark != NULL) {
		CTMarker*	pmkPoint	= pBuffer->pGetPointMarker () ;

		if (pmkPoint != NULL) {
			pmkPoint->bSetPosition (pmkMark) ;
			pmkPoint->bBackward (1) ;
		}
		pBuffer->bDeleteMarker (pmkMark) ;
	} else {
		/* (point-max) �܂� cursor ���ړ��B*/
		CTMarker*	pmkPoint	= pBuffer->pGetPointMarker () ;

		if (pmkPoint != NULL)
			pmkPoint->bForward (pBuffer->iGetPointMax () - pmkPoint->iGetPosition ()) ;
	}
	if (bKakuteiHenkan) {
		/* (skk-kakutei new-word) */
		pThis->vSetRegConstString (LMREGARG_0, pNewWord, nNewWordLen) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkHenkan_Exit))
			return	LMR_ERROR ;
	} else {
		pThis->vJump (LM_bSkkHenkan_Exit) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkan_Exit (
	CImeDoc*			pThis)
{
	pThis->vPopReg (LMREG_1) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-set-henkan-point-subr
 */
int
CImeDoc::LM_bSkkSetHenkanPointSubr (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/* cancel �͂Ȃ��B*/
	if (pBuffer->bSkkGetSkkHenkanMode ()) {
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkSetHenkanPointSubr_1))
			return	LMR_ERROR ;
	} else {
		pThis->vSetRegBool (LMREGARG_0, FALSE) ;
		if (! pThis->bCall (LM_bSkkKanaCleanup, LM_bSkkSetHenkanPointSubr_1))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkSetHenkanPointSubr_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	int		nPrefix ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	if (! piteSkkRuleTree->bHavePrefixp () || piteSkkRuleTree->pGetPrefix (&nPrefix) == NULL) {
//	if (pBuffer->pSkkGetSkkCurrentRuleTree () == NULL || CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) == NULL) {
		pBuffer->bInsertAndInherit (L"��", 1) ;
	} else {
		LPCDSTR	pwPrefix ;
		int		nPrefixLen ;

		pBuffer->bSkkErasePrefix (FALSE) ;
		pBuffer->bInsertAndInherit (L"��", 1) ;
		pBuffer->bSkkSetSkkKanaStartPointToPoint () ;
		pwPrefix	= pBuffer->pSkkGetSkkPrefix (&nPrefixLen) ;
		pBuffer->bSkkInsertPrefix (pwPrefix, nPrefixLen) ;
	}
	pBuffer->vSkkSetSkkHenkanMode (LON) ;
	pBuffer->vSkkClearSkkHenkanEndPoint () ;
	pBuffer->bSkkSetSkkHenkanStartPointToPoint () ;

	/*	���̏����̓G���[���������Ă��K�����s����Ȃ���΂Ȃ�Ȃ��I
	 */
	pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-set-henkan-point
 */
int
CImeDoc::LM_bSkkSetHenkanPoint (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	int		iLastCommandChar, iLastChar	;
	BOOL	bNormal, bSokuon, bHenkanActive ;
	LPCDSTR	pwPrefix ;
	int		nPrefixLen ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	iLastCommandChar	= pThis->iGetLastCommandChar () ;
	iLastChar			= (L'A' <= iLastCommandChar && iLastCommandChar <= L'Z')? (iLastCommandChar + (L'a' - L'A')) : iLastCommandChar ;
	bNormal				= (iLastChar != iLastCommandChar) ;

	pwPrefix			= pBuffer->pSkkGetSkkPrefix (&nPrefixLen) ;
	bSokuon				= (nPrefixLen == 1 && *pwPrefix == iLastChar && iLastChar != L'o') ;
	bHenkanActive		= (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) ;

	if (! pThis->bPushReg (LMREG_1) ||
		! pThis->bPushReg (LMREG_2) ||
		! pThis->bPushReg (LMREG_3))
		return	LMR_ERROR ;

	pThis->vSetRegInteger (LMREG_1, iLastChar) ;
	pThis->vSetRegBool    (LMREG_3, bNormal) ;

	if (pBuffer->bSkkGetSkkHenkanMode () != LON) {
		if (bNormal) {
			if (! pThis->bCall (LM_bSkkSetHenkanPointSubr, LM_bSkkSetHenkanPoint_Exit))
				return	LMR_ERROR ;
		} else {
			/* ! bNormal */
			if (pBuffer->bSkkGetSkkHenkanMode ()) {
				if (bHenkanActive) {
					if (! pThis->bCall (LM_bSkkSetHenkanPointSubr, LM_bSkkSetHenkanPoint_4))
						return	LMR_ERROR ;
				} else {
					if (! pThis->bCall (LM_bSkkSetHenkanPointSubr, LM_bSkkSetHenkanPoint_Exit))
						return	LMR_ERROR ;
				}
			} else {
				if (bHenkanActive) {
					if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkSetHenkanPoint_Exit))
						return	LMR_ERROR ;
				}
			}
		}
	} else if (! bNormal) {
		DCHAR	wch	= iLastChar ;
		int		nSkkHenkanStartPoint, nPoint ;

		pBuffer->bInsertAndInherit (&wch, 1) ;
		pBuffer->bSkkSetSkkHenkanStartPointToPoint () ;
		pBuffer->vSkkSetSkkHenkanCount (0) ;
		if (pBuffer->pSkkGetSkkHenkanStartPointMarker () == NULL) {
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
		nSkkHenkanStartPoint	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
		nPoint					= pBuffer->iGetPoint () ;
		if (nPoint >= nSkkHenkanStartPoint) {
			LPCDSTR		pwBufferString ;
			int			nBufferStringLength ;

			pwBufferString	= pBuffer->pBufferRawString (&nBufferStringLength) ;
			pBuffer->vSkkSetSkkHenkanKey (pwBufferString + nSkkHenkanStartPoint, nPoint - nSkkHenkanStartPoint) ;
		} else {
			pBuffer->vSkkSetSkkHenkanKey (NULL, 0) ;
		}
		pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
		if (! pThis->bCall (LM_bSkkHenkan, LM_bSkkSetHenkanPoint_Exit))
			return	LMR_ERROR ;
	} else {
		//BOOL	bProcess	= FALSE ;
		CSkkRuleTreeIterator*	piteSkkRuleTree ;
		int		nPrefix ;

		piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
		if (! piteSkkRuleTree->bHavePrefixp () || piteSkkRuleTree->pGetPrefix (&nPrefix) == NULL) {
//		if (pBuffer->pSkkGetSkkCurrentRuleTree () == NULL || CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) == NULL) {
			pThis->vSetRegInteger (LMREG_2, bSokuon) ;
			pThis->vJump (LM_bSkkSetHenkanPoint_1) ;
		} else if (pBuffer->pSkkGetSkkKanaStartPointMarker () != NULL && 
				   pBuffer->pSkkGetSkkHenkanStartPointMarker () != NULL &&
				   pBuffer->iSkkGetSkkKanaStartPoint () != pBuffer->iSkkGetSkkHenkanStartPoint ()) {
			pThis->vSetRegInteger (LMREG_2, bSokuon) ;
			if (! bSokuon) {
				pThis->vSetRegBool    (LMREGARG_0, FALSE) ;
				if (! pThis->bCall (LM_bSkkKanaCleanup, LM_bSkkSetHenkanPoint_1))
					return	LMR_ERROR ;
			} else {
				pThis->vJump (LM_bSkkSetHenkanPoint_1) ;
			}
		} else {
			pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
		}
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkSetHenkanPoint_Exit (
	CImeDoc*			pThis)
{
	BOOL	bNormal ;
	int		iLastChar ;

	if (! pThis->bGetRegBool (LMREG_3, &bNormal)) 
		bNormal	= FALSE ;
	if (! pThis->bGetRegInteger (LMREG_1, &iLastChar)) {
		bNormal		= FALSE ;
		iLastChar	= -1 ;
	}
	pThis->vPopReg (LMREG_3) ;
	pThis->vPopReg (LMREG_2) ;
	pThis->vPopReg (LMREG_1) ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (bNormal) {
		pThis->bSetLastCommandChar (iLastChar) ;
		pThis->vJump (LM_bSkkKanaInput) ;
		return	LMR_CONTINUE ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkSetHenkanPoint_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	BOOL	bProcess		= FALSE ;
	BOOL	bSokuon			= FALSE ;
	BOOL	bNormal			= TRUE ;
	int		iLastChar		= -1 ;

	if (! pThis->bGetRegInteger (LMREG_1, &iLastChar))
		iLastChar	= -1 ;
	if (! pThis->bGetRegInteger (LMREG_2, &bSokuon))
		bSokuon		= FALSE ;
	if (! pThis->bGetRegBool (LMREG_3, &bNormal))
		bNormal		= TRUE ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (pBuffer->bSkkGetSkkOkurigana ()) {
		pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (pBuffer->pSkkGetSkkHenkanStartPointMarker () != NULL && pBuffer->iSkkGetSkkHenkanStartPoint () == pBuffer->iGetPoint ()) {
		bProcess	= TRUE ;
	} else {
		int		iCH ;		/* char-before �͌����ɂ͓��삵�Ȃ��B*/

		iCH		= pBuffer->iGetCharAt (pBuffer->iGetPoint () - 1)  ;
		if ((L'0' <= iCH && iCH <= L'9') || iCH == L'��' || (L'�O' <= iCH && iCH <= L'�X')) {
			bProcess	= FALSE ;
		} else {
			bProcess	= TRUE ;
		}
	}
	if (bProcess) {
		if (CImeConfig::bSkkProcessOkuriEarlyp (pThis->m_pConfig)) {
			DCHAR	buf [2] ;
			DCHAR	bufOkuriChar [32] ;
			DCHAR	bufHenkanKey [MAXLEN_HENKAN_KEY] ;
			LPDSTR	pDest, pDestEnd ;
			int		n, iOkuriCharLen ;
			LPCDSTR	pwSkkOkuriChar ;
			int		nSkkOkuriCharLen ;

			pBuffer->bSkkSetSkkHenkanEndPointToPoint () ;

			/* skk-okuri-char �̐ݒ�B*/
			buf [0]				= iLastChar ;
			iOkuriCharLen		= CImeConfig::iGetSkkOkuriChar (pThis->m_pConfig, buf, 1, bufOkuriChar, MYARRAYSIZE (bufOkuriChar)) ;
			if (iOkuriCharLen <= 0) {
				bufOkuriChar [0]	= iLastChar ;
				iOkuriCharLen		= 1 ;
			}
			pBuffer->vSkkSetSkkOkuriChar (bufOkuriChar, iOkuriCharLen) ;

			pDest		= bufHenkanKey ;
			pDestEnd	= bufHenkanKey + MYARRAYSIZE (bufHenkanKey) ;
//			pDest		= pBuffer->m_bufSkkHenkanKey ;
//			pDestEnd	= pBuffer->m_bufSkkHenkanKey + MYARRAYSIZE (pBuffer->m_bufSkkHenkanKey) ;
			if (bSokuon) {
				n			= MIN (pDestEnd - pDest, pBuffer->iSkkGetSkkKanaStartPoint () - pBuffer->iSkkGetSkkHenkanStartPoint ()) ;
				if (n < 0) {
					pThis->vSetSignalError () ;
					pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
					return	LMR_CONTINUE ;
				}
				if (n > 0) {
					LPCDSTR	pwBufferString ;

					pwBufferString	= pBuffer->pBufferRawString (NULL) ;
					vCopyStringN (&pDest, pDestEnd, pwBufferString + pBuffer->iSkkGetSkkHenkanStartPoint (), n) ;
				}
				vCopyStringW (&pDest, pDestEnd, pBuffer->bSkkGetSkkKatakana ()? L"�b" : L"��") ;

				pwSkkOkuriChar	= pBuffer->pSkkGetSkkOkuriChar (&nSkkOkuriCharLen) ;
				vCopyStringN (&pDest, pDestEnd, pwSkkOkuriChar, n) ;

				pBuffer->vSkkSetSkkHenkanKey (bufHenkanKey, pDest - bufHenkanKey) ;
				pBuffer->bSkkErasePrefix (FALSE) ;
				pBuffer->bInsertAndInherit (pBuffer->bSkkGetSkkKatakana ()? L"�b" : L"��", 1) ;
				pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
				pBuffer->vSkkSetSkkHenkanCount (0) ;
				if (! pThis->bCall (LM_bSkkHenkan, LM_bSkkSetHenkanPoint_2))
					return	LMR_ERROR ;

				return	LMR_CONTINUE ;
			} else {
				n			= MIN (pDestEnd - pDest, pBuffer->iGetPoint () - pBuffer->iSkkGetSkkHenkanStartPoint ()) ;
				if (n < 0) {
					pThis->vSetSignalError () ;
					pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
					return	LMR_CONTINUE ;
				}
				if (n > 0) {
					LPCDSTR	pwBufferString ;

					pwBufferString	= pBuffer->pBufferRawString (NULL) ;
					vCopyStringN (&pDest, pDestEnd, pwBufferString + pBuffer->iSkkGetSkkHenkanStartPoint (), n) ;
				}

				pwSkkOkuriChar	= pBuffer->pSkkGetSkkOkuriChar (&nSkkOkuriCharLen) ;
				vCopyStringN (&pDest, pDestEnd, pwSkkOkuriChar, nSkkOkuriCharLen) ;

				pBuffer->vSkkSetSkkHenkanKey (bufHenkanKey, pDest - bufHenkanKey) ;
				pBuffer->bInsertAndInherit (L" ", 1) ;
				pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
				pBuffer->vSkkSetSkkHenkanCount (0) ;
				if (! pThis->bCall (LM_bSkkHenkan, LM_bSkkSetHenkanPoint_2))
					return	LMR_ERROR ;

				return	LMR_CONTINUE ;
			}
			/* ... */
		} else {
			if (pBuffer->iSkkGetSkkHenkanStartPoint () != pBuffer->iGetPoint ()) {
				CSkkRuleTreeIterator*	piteSkkRuleTree ;
				LPCDSTR	pwSkkPrefix ;
				LPCDSTR	pwBufferString ;
				int		nPrefix, nSkkPrefixLen, nBufferLen ;

				if (bSokuon) {
					pBuffer->bSkkErasePrefix (TRUE) ;
					pBuffer->bInsertAndInherit (pBuffer->bSkkGetSkkKatakana ()? L"�b" : L"��", 1) ;
				}
				/*	������ "IwakU" �Ɠ��͂��āA"IwaKu" �Ɠ����̓���������鏈��������B
				 */
				pwSkkPrefix		= pBuffer->pSkkGetSkkPrefix (&nSkkPrefixLen) ;
				piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
				pwBufferString	= pBuffer->pBufferRawString (&nBufferLen) ;
				if (! bSokuon && 
					piteSkkRuleTree->bHavePrefixp () &&
					piteSkkRuleTree->pGetPrefix (&nPrefix) != NULL &&
//					pBuffer->pSkkGetSkkCurrentRuleTree () != NULL && 
//					CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) != NULL &&
					bNormal &&
					nSkkPrefixLen > 0 &&
					pBuffer->iGetPoint () >= nSkkPrefixLen &&
					memcmp (pwBufferString + pBuffer->iGetPoint () - nSkkPrefixLen, pwSkkPrefix, sizeof (DCHAR) * nSkkPrefixLen) == 0) {

					/*	�]���̕��@���ƁAMakSu �̂悤�Ȍ���͂�����ƁA
					 *	(1) "����k|" (����: S) (| �̓J�[�\���ʒu)
					 *	(2) "����s|" 
					 *	(3) "����s|" (����: u)
					 *	(4) "��s��"
					 *	�Ƃ����ϊ������Ă��܂��̂ŁA�C���B����́Askk-kana-input �̑��ɔ��f��
					 *	�䂾�˂�ׂ��ŁA������ okurigana ���Ǝv���Ă��܂��̂͂悭�Ȃ��悤���B
					 *	���ƁAMatsU �̂悤�ȓ��͂��\�ɁBprefix-len == 1�̔���͂͂������B
					 */
					if (pBuffer->bSkkGetSkkOkurigana ()) {
						int	iOkuriganaStartPoint	= pBuffer->iSkkGetSkkOkuriganaStartPoint () ;

						if (iOkuriganaStartPoint >= 0 && iOkuriganaStartPoint < nBufferLen && pBuffer->iGetCharAt (iOkuriganaStartPoint) == L'*') {
							pBuffer->bDeleteRegion (iOkuriganaStartPoint, iOkuriganaStartPoint + 1) ;
						}
						pBuffer->vSkkSetSkkOkurigana (LFALSE) ;
					}
					if (pBuffer->iSkkGetSkkKanaStartPoint () >= 0) {
						pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkKanaStartPoint (), pBuffer->iGetPoint ()) ;
					}
					pBuffer->bSkkSetSkkOkuriganaStartPointToPoint () ;
					pBuffer->bInsertAndInherit (L"*", 1) ;
					pBuffer->bSkkSetSkkKanaStartPointToPoint () ;
					pBuffer->bSkkInsertPrefix (pwSkkPrefix, nSkkPrefixLen) ;
					pBuffer->vSkkSetSkkOkuriChar (pwSkkPrefix, nSkkPrefixLen) ;
					pBuffer->vSkkSetSkkOkurigana (LTRUE) ;
				} else {
					DCHAR	wchOkuri ;

					pBuffer->bSkkSetSkkOkuriganaStartPointToPoint () ;
					pBuffer->bInsertAndInherit (L"*", 1) ;
					pBuffer->bSkkSetSkkKanaStartPointToPoint () ;
					wchOkuri	= (DCHAR) iLastChar ;
					pBuffer->vSkkSetSkkOkuriChar (&wchOkuri, 1) ;
					pBuffer->vSkkSetSkkOkurigana (LTRUE) ;
				}
			}
		}
	}
	pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkSetHenkanPoint_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	BOOL			bSokuon ;

	if (! pThis->bGetRegInteger (LMREG_2, &bSokuon)) 
		bSokuon	= FALSE ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pBuffer->bDeleteBackwardChar (bSokuon? 2 : 1)) {
		pThis->vSetSignalError () ;
	}
	pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkSetHenkanPoint_3 (
	CImeDoc*			pThis)
{
	if (! pThis->bCall (LM_bSkkSetCharBeforeAsOkurigana, LM_bSkkSetHenkanPoint_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkSetHenkanPoint_4 (
	CImeDoc*		pThis)
{
	pThis->vJump (LM_bSkkSetHenkanPoint_Exit) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-mode
 */
int
CImeDoc::LM_bSkkMode (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pBuffer->bSkkGetSkkMode ()) {
		if (! pThis->bCall (LM_bSkkModeExit, LM_bSkkMode_1))
			return	LMR_ERROR ;
	} else {
		if (! pBuffer->bSkkGetSkkModeInvoked ())
			pBuffer->bSkkModeInvoke () ;
		pThis->vJump (LM_bSkkMode_1) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkMode_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	/* ... pre-command-hook, post-command-hook �̓x�^�Ɏ�������Ƃ��āA
	 *	run-hooks �͕s�\�B*/
	pBuffer->bSkkJModeOn (LFALSE) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-mode-exit
 */
int
CImeDoc::LM_bSkkModeExit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;

	/* 0 �� LM_bSkkKakuteiAdJisx0201 �ւ̈����B*/
	pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
	pThis->vSetRegBool   (LMREG_0, pBuffer->bSkkGetSkkMode ()) ;
	pBuffer->vSkkSetSkkMode (LTRUE) ;
	if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkModeExit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkModeExit_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	BOOL				bSkkMode ;

	if (! pThis->bGetRegBool (LMREG_0, &bSkkMode))
		bSkkMode	= FALSE ;
	pThis->vPopReg (LMREG_0) ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSkkSetSkkMode (bSkkMode) ;
	pBuffer->bSkkModeOff () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-latin-mode
 */
int
CImeDoc::LM_bSkkLatinMode (
	CImeDoc*				pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
	if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkLatinMode_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkLatinMode_1 (
	CImeDoc*				pThis)
{
	CImeBuffer*		pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pBuffer->bSkkLatinModeOn () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0208-latin-mode
 */
int
CImeDoc::LM_bSkkJisx0208LatinMode (
	CImeDoc*				pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
	if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkJisx0208LatinMode_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkJisx0208LatinMode_1 (
	CImeDoc*				pThis)
{
	CImeBuffer*		pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->bSkkJisx0208LatinModeOn () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-abbrev-mode
 */
int
CImeDoc::LM_bSkkAbbrevMode (
	CImeDoc*				pThis)
{
	CImeBuffer*		pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkAbbrevMode_1))
			return	LMR_ERROR ;
	} else if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		/* "���Ɂ����[�h�ɓ����Ă��܂�" "Already in �� mode" */
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	} else {
		pThis->vJump (LM_bSkkAbbrevMode_1) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkAbbrevMode_1 (
	CImeDoc*				pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	if (! pThis->bCall (LM_bSkkSetHenkanPointSubr, LM_bSkkAbbrevMode_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkAbbrevMode_2 (
	CImeDoc*				pThis)
{
	CImeBuffer*		pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pBuffer->bSkkAbbrevModeOn () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-set-okurigana
 */
int
CImeDoc::LM_bSkkSetOkurigana (
	CImeDoc*				pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR	wbuf [32] ;
	LPCDSTR	pwBufferString ;
	LPCDSTR	pwHenkanOkurigana ;
	int		nOkuriStartPos, nPoint, nHenkanStartPoint, nHenkanEndPoint, nOkuriganaPrefix ;
	int		nHenkanOkuriganaLen, nHenkanKeyLen, nBufferStringLen ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pBuffer->bSkkSetSkkHenkanEndPoint (pBuffer->pSkkGetSkkOkuriganaStartPointMarker ()) ;

	/* save-point �Ȃ̂� marker �� point ��ۑ�����B*/
	nOkuriStartPos	= pBuffer->iSkkGetSkkOkuriganaStartPoint () ;
	if (pBuffer->iGetCharAt (nOkuriStartPos) != L'*') {
		const DCHAR	buf [1] = { L'*' } ;
		pBuffer->iInsertByPosition (nOkuriStartPos, buf, 1) ;
	}
	nPoint			= pBuffer->iGetPoint () ;
	pwBufferString	= pBuffer->pBufferRawString (&nBufferStringLen) ;

	/* ���艼���� start point �ɂ� '*' �����݂���B*/
	nHenkanOkuriganaLen	= nPoint - nOkuriStartPos - 1 ;
	if (nHenkanOkuriganaLen > 0) {
		nHenkanOkuriganaLen	= (nHenkanOkuriganaLen > MAXLEN_HENKAN_OKURIGANA)? MAXLEN_HENKAN_OKURIGANA : nHenkanOkuriganaLen ;
		pBuffer->vSkkSetSkkHenkanOkurigana (pwBufferString + nOkuriStartPos + 1, nHenkanOkuriganaLen) ;
	} else {
		pBuffer->vSkkSetSkkHenkanOkurigana (NULL, 0) ;
	}

	nHenkanStartPoint	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
	nHenkanEndPoint		= pBuffer->iSkkGetSkkHenkanEndPoint () ;
	nHenkanKeyLen		= nHenkanEndPoint - nHenkanStartPoint ;
	pBuffer->vSkkSetSkkHenkanKey (pwBufferString + nHenkanStartPoint, nHenkanKeyLen) ;

	pwHenkanOkurigana	= pBuffer->pSkkGetSkkHenkanOkurigana (&nHenkanOkuriganaLen) ;
	nOkuriganaPrefix	= pBuffer->iSkkOkuriganaPrefix (pwHenkanOkurigana, nHenkanOkuriganaLen, wbuf, MYARRAYSIZE (wbuf)) ;
	if (nOkuriganaPrefix > 0) {
		pBuffer->bSkkAddSkkHenkanKey (wbuf, nOkuriganaPrefix) ;
	} else {
		LPCDSTR	pwOkuriChar ;
		int		nOkuriCharLen ;
		pwOkuriChar		= pBuffer->pSkkGetSkkOkuriChar (&nOkuriCharLen) ;
		pBuffer->bSkkAddSkkHenkanKey (pwOkuriChar, nOkuriCharLen) ;
	}
	pBuffer->vSkkSetSkkPrefix (NULL, 0) ;

	if (pBuffer->bSkkGetSkkKatakana ()) {
		LPCDSTR	pwHenkanKey ;
		LPCDSTR	pwHenkanOkurigana ;
		DCHAR	bufTemp [MAXCOMPLEN] ;
		int		nNewHenkanKeyLen, nNewHenkanOkuriganaLen ;

		pwHenkanKey				= pBuffer->pSkkGetSkkHenkanKey (&nHenkanKeyLen) ;
		nNewHenkanKeyLen		= iSkkKatakanaToHiragana (bufTemp, MYARRAYSIZE (bufTemp), pwHenkanKey, nHenkanKeyLen, FALSE) ;
		pBuffer->vSkkSetSkkHenkanKey (bufTemp, nNewHenkanKeyLen) ;
		pwHenkanOkurigana		= pBuffer->pSkkGetSkkHenkanOkurigana (&nHenkanOkuriganaLen) ;
		nNewHenkanOkuriganaLen	= iSkkKatakanaToHiragana (bufTemp, MYARRAYSIZE (bufTemp), pwHenkanOkurigana, nHenkanOkuriganaLen, FALSE) ;
		pBuffer->vSkkSetSkkHenkanOkurigana (bufTemp, nNewHenkanOkuriganaLen) ;
	}
	pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkOkuriganaStartPoint (), pBuffer->iSkkGetSkkOkuriganaStartPoint () + 1) ;
	pBuffer->vSkkSetSkkHenkanCount (0) ;

	if (! pThis->bCall (LM_bSkkHenkan, LM_bSkkSetOkurigana_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkSetOkurigana_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pBuffer->vSkkSetSkkOkurigana (LFALSE) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-delete-backward-char
 */
int
CImeDoc::LM_bSkkDeleteBackwardChar (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		if (! CImeConfig::bSkkDeleteImplesKakuteip (pThis->m_pConfig) && pBuffer->iSkkGetSkkHenkanEndPoint () == pBuffer->iGetPoint ()) {
			if (! pThis->bCall (LM_bSkkPreviousCandidate, LM_bSkkDeleteBackwardChar_Exit))
				return	LMR_ERROR ;
			/* overwrite-mode �͂Ȃ��B*/
			return	LMR_CONTINUE ;
		} else {
			if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkDeleteBackwardChar_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	} else if (pBuffer->bSkkGetSkkHenkanMode () && pBuffer->iSkkGetSkkHenkanStartPoint () >= pBuffer->iGetPoint ()) {
		pBuffer->vSkkSetSkkHenkanCount (0) ;
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkDeleteBackwardChar_Exit))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else {
		CSkkRuleTreeIterator*	piteSkkRuleTree ;
		int		nPrefix ;

		pBuffer->bSkkDeleteOkuriMark () ;
		piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
		if (piteSkkRuleTree->bHavePrefixp () && piteSkkRuleTree->pGetPrefix (&nPrefix) != NULL) {
//		if (pBuffer->pSkkGetSkkCurrentRuleTree () != NULL && CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) != NULL) {
			pBuffer->bSkkErasePrefix (TRUE) ;
		} else {
			pBuffer->vSkkClearSkkKanaStartPoint () ;
			if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkDeleteBackwardChar_Exit))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	pThis->vJump (LM_bSkkDeleteBackwardChar_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkDeleteBackwardChar_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	int		nCount	= 1 ;	/* num-arg = 1 �Ɖ���B*/
	LPCDSTR	pwSkkPrefix ;
	int		nSkkPrefixLen ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkDeleteBackwardChar_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkDeleteBackwardChar_Exit) ;
		return	LMR_CONTINUE ;
	}

	pwSkkPrefix	= pBuffer->pSkkGetSkkPrefix (&nSkkPrefixLen) ;
	if (nSkkPrefixLen > nCount) {
		/* �c�������R�s�[�����ʂɔ����c�B*/
		pBuffer->vSkkSetSkkPrefix (pwSkkPrefix, nSkkPrefixLen - 1) ;
	} else {
		pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
	}
	if (pBuffer->iSkkGetSkkHenkanEndPoint () >= pBuffer->iGetPoint ()) {
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkDeleteBackwardChar_Exit))
			return	LMR_ERROR ;
	} else {
		pThis->vJump (LM_bSkkDeleteBackwardChar_Exit) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkDeleteBackwardChar_Exit (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-kakutei
 */
/*	skk-update-jisyo �̒��� minibuffer-flag �� true �Ȃ� yes-or-no-p ���Ă΂�Ă��܂����߂�
 *	���� skk-kakutei �͂��̈ʒu�ɂȂ���΂Ȃ�Ȃ��B
 */
int
CImeDoc::LM_bSkkKakutei (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR		wstrWord	= NULL ;
	int			nWordLen	= 0; 

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/*	�m��word ���ς܂�Ă��邩�ǂ����`�F�b�N����B*/
	if (! pThis->bGetRegConstString (LMREGARG_0, &wstrWord, &nWordLen)) {
		wstrWord	= NULL ;
		nWordLen	= 0 ;
	}
	if (pBuffer->bSkkGetSkkHenkanMode ()) {
		LPCDSTR	pwCurKakuteiMidasi ;
		LPDSTR	pwKakuteiMidasi,   pwKakuteiWord ;
		int		nKakuteiMidasiLen, nKakuteiWordLen ;

		pwKakuteiMidasi	= (LPDSTR) pThis->pAlloca (MAXLEN_KAKUTEI_MIDASI * sizeof (DCHAR), __alignof (DCHAR)) ;
		pwKakuteiWord	= (LPDSTR) pThis->pAlloca (MAXLEN_KAKUTEI_WORD   * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pwKakuteiMidasi == NULL || pwKakuteiWord == NULL)
			return	LMR_ERROR ;

		if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
			/* �����̍X�V���ꂱ��B���͂����͎������Ȃ��B����������̂���B*/
			/* (skk-update-jisyo kakutei-word) */
			if (nWordLen <= 0) {
				CTSearchSession*	pSession ;

				pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
				if (pSession != NULL) {
					wstrWord	= pSession->pGetReferCandidate () ;
					if (wstrWord == NULL)
						wstrWord	= pSession->pGetCandidate () ;
				}
				nWordLen	= (wstrWord != NULL)? (int)dcslen (wstrWord) : 0 ;
			}
		/*
		(when (or (and (not skk-search-excluding-word-pattern-function)
				       kakutei-word)
				  (and kakutei-word
				       skk-search-excluding-word-pattern-function
				       (not (funcall
						     skk-search-excluding-word-pattern-function
						     kakutei-word))))
		  (skk-update-jisyo kakutei-word)

		  */
			/*	_bSkkUpdateJisyo �̌Ăяo���Œ��O�̊m����(���o��+�P��)���X�V����Ă��܂��̂�
			 *	�����ŕۑ����Ă����B
			 */
			pwCurKakuteiMidasi	= pBuffer->pSkkGetKakuteiMidasi (&nKakuteiMidasiLen) ;
			if (nKakuteiMidasiLen > 0) {
				LPCDSTR	pwCurKakuteiWord ;

				dcsncpy (pwKakuteiMidasi, pwCurKakuteiMidasi, nKakuteiMidasiLen) ;
				pwCurKakuteiWord	= pBuffer->pSkkGetKakuteiWord (&nKakuteiWordLen) ;
				dcsncpy (pwKakuteiWord,  pwCurKakuteiWord,    nKakuteiWordLen) ;
			} else {
				nKakuteiWordLen		= 0 ;
			}

			if (nWordLen > 0) {
				LPDSTR	pDest ;

				/*	���́A���� wstrWord, nWordLen �� LM_bSkkUpdateJisyo �ɓn����Ȃ���΂Ȃ�Ȃ����A
				 *	���̎w���Ă���̈悪�ۏ؂���Ȃ���������Ȃ��Ƃ������Ƃ��B
				 *
				 *	���z�@�B�� stack ����̈�m�ۂ��āA�����ɕۑ�����c���B���� alignment �����B
				 */
				pDest	= (LPDSTR) pThis->pAlloca (nWordLen * sizeof (DCHAR), __alignof (DCHAR)) ;
				if (pDest == NULL) {
					/* fatal error */
					return	LMR_ERROR ;
				}
				dcsncpy (pDest, wstrWord, nWordLen) ;

				if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1))
					return	LMR_ERROR ;
				pThis->vSetRegConstString (LMREGARG_0, pDest, nWordLen) ;
				pThis->vSetRegBool   (LMREGARG_1, FALSE) ;
				pThis->vSetRegString (LMREG_0, pwKakuteiWord,   nKakuteiWordLen) ;
				pThis->vSetRegString (LMREG_1, pwKakuteiMidasi, nKakuteiMidasiLen) ;
				if (! pThis->bCall (LM_bSkkUpdateJisyo, LM_bSkkKakutei_1)) 
					return	LMR_ERROR ;

				/*	���̕t�߂œǂ݉����Ƃ��� MidashiWord ��u���Ă����Ƃ�����Ƃ��K�v�ɂȂ�ɈႢ�Ȃ��c�B
				 *	���̏��� shift ����č폜���ꂽ�肵����A��������Ƃ��������ł������B
				 *
				 *	���ɑ��������ǁA�v����m�F�I
				 *
				 *	����A�ǂ݉������g����̂͊m���ł͂Ȃ��ϊ����Ȃ̂ł͂Ȃ����H�Ƃ����^�₪�B������
				 *	�^�C�~���O�ŕK�v�Ƃ����̂����؂�Ȃ��Ƃ����Ȃ��B
				 */
				if (! pThis->bRecursiveEditp ()) {
					LPCDSTR	pwHenkanKey ;
					int		nHenkanKeyLen ;

					pwHenkanKey	= pBuffer->pSkkGetSkkHenkanKey (&nHenkanKeyLen) ;
					pBuffer->bSetReadingProperty (pBuffer->pSkkGetSkkHenkanStartPointMarker (), pBuffer->pSkkGetSkkHenkanEndPointMarker (), pwHenkanKey, nHenkanKeyLen) ;
				}
				return	LMR_CONTINUE ;
			} else {
				if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1))
					return	LMR_ERROR ;
				pThis->vSetRegString (LMREG_0, pwKakuteiWord,   nKakuteiWordLen) ;
				pThis->vSetRegString (LMREG_1, pwKakuteiMidasi, nKakuteiMidasiLen) ;
				pThis->vJump (LM_bSkkKakutei_1) ;
				return	LMR_CONTINUE ;
			}
		} else {
			int		nHenkanStartPoint ;

			/* pBuffer->bSkkGetSkkHenkanMode () ==LON */
			/*
			 *		;; �����[�h�Ŋm�肵���ꍇ�B�֋X�I�Ɍ��݂̃|�C���g�܂ł����o���������
			 *		;; ���ė������X�V����B
			 *		(when (and (> skk-kakutei-history-limit 0)
			 *				   (< skk-henkan-start-point (point))
			 *				   (skk-save-point
			 *				    (goto-char skk-henkan-start-point)
			 *				    (eq (skk-what-char-type) 'hiragana)))
			 *		  (skk-update-kakutei-history
			 *		   (buffer-substring-no-properties
			 *		    skk-henkan-start-point (point))))))
			 */
			if (pBuffer->pSkkGetSkkHenkanStartPointMarker () != NULL && pBuffer->iSkkGetSkkHenkanStartPoint () < pBuffer->iGetPoint ()) {
				nHenkanStartPoint	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
				if (0 <= nHenkanStartPoint && nHenkanStartPoint < pBuffer->iGetPointMax () && L'��' <= pBuffer->iGetCharAt (nHenkanStartPoint) && pBuffer->iGetCharAt (nHenkanStartPoint) <= L'��') {
					LPCDSTR	pwBufferString ;

					pwBufferString	= pBuffer->pBufferRawString (NULL) ;
					pBuffer->bSkkUpdateKakuteiHistory (pwBufferString + nHenkanStartPoint, pBuffer->iGetPoint () - nHenkanStartPoint, NULL, 0) ;
				}
			}
		}
		pThis->vJump (LM_bSkkKakutei_4) ;
		return	LMR_CONTINUE ;
	}
	pThis->vJump (LM_bSkkKakutei_5) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKakutei_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPDSTR	pwCombWord		= NULL ;
	LPDSTR	pwSkkHenkanKey	= NULL ;
	LPDSTR	pwKakuteiMidasi,   pwKakuteiWord ;
	int		nKakuteiMidasiLen, nKakuteiWordLen ;
	int		nCombWordLen, nSkkHenkanKeyLen, nHenkanStartPoint ;
	LPCDSTR	pwCurHenkanKey ;
	LPCDSTR	pwCurKakuteiMidasi ;
	LPCDSTR	pwCurKakuteiWord ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	int		nCurHenkanKeyLen, nCurKakuteiMidasiLen, nCurKakuteiWordLen, nTempLen ;

	/*	�m�茩�o���ƃ��W�X�^�̕��A�܂ł͕K���s���B
	 */
	if (! pThis->bGetRegString (LMREG_0, &pwKakuteiWord, &nKakuteiWordLen)) {
		pwKakuteiWord	= NULL ;
		nKakuteiWordLen	= 0 ;
	}
	if (! pThis->bGetRegString (LMREG_1, &pwKakuteiMidasi, &nKakuteiMidasiLen)) {
		pwKakuteiMidasi		= NULL ;
		nKakuteiMidasiLen	= 0 ;
	}
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pwSkkHenkanKey	= (LPDSTR) pThis->pAlloca (pBuffer->iSkkGetSkkHenkanKeyLength () * sizeof (DCHAR), __alignof (DCHAR)) ;
	pwCombWord		= (LPDSTR) pThis->pAlloca (MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwSkkHenkanKey == NULL || pwCombWord == NULL)
		return	LMR_ERROR ;

	pwCurHenkanKey		= pBuffer->pSkkGetSkkHenkanKey (&nCurHenkanKeyLen) ;
	pwCurKakuteiMidasi	= pBuffer->pSkkGetKakuteiMidasi (&nCurKakuteiMidasiLen) ;
	pwCurKakuteiWord	= pBuffer->pSkkGetKakuteiWord (&nCurKakuteiWordLen) ;
	if (pBuffer->bSkkGetSkkAfterPrefix () && ! bSettoji (pwCurHenkanKey, nCurHenkanKeyLen)) {
		LPCDSTR	pwBufferString ;

		if (nKakuteiWordLen > 0 && bSettoji (pwKakuteiMidasi, nKakuteiMidasiLen)) {
			/* skk-henkan-key �̑ޔ��B*/
			if (nCurHenkanKeyLen > 0) {
				dcsncpy (pwSkkHenkanKey, pwCurHenkanKey, nCurHenkanKeyLen) ;
			}
			nSkkHenkanKeyLen	= nCurHenkanKeyLen ;

			/*	skk-henkan-start-point ����̌��ʂ��A(nth 1 list2) �ɓ������c���B
			 */
			pwCurKakuteiWord	= pBuffer->pSkkGetKakuteiWord (&nCurKakuteiWordLen) ;
			nHenkanStartPoint	= pBuffer->iSkkGetSkkHenkanStartPoint () - nCurKakuteiWordLen - 1 /* ``��''�̕��B*/ ;
			pwBufferString		= pBuffer->pBufferRawString (NULL) ;

			/*	���O�̕ϊ������� application ���ɓn����Ă���\��������B���̏ꍇ�A���̏����͓��Ă͂܂�Ȃ��c�B
			 */
			if (nHenkanStartPoint >= 0 && (nHenkanStartPoint + nKakuteiWordLen) <= pBuffer->iGetPointMax () && dcsncmp (pwBufferString + nHenkanStartPoint, pwKakuteiWord, nKakuteiWordLen) == 0) {
				nTempLen		= iConcatString (bufTemp, MYARRAYSIZE (bufTemp), pwKakuteiMidasi, nKakuteiMidasiLen - 1, pwCurKakuteiMidasi, nCurKakuteiMidasiLen, NULL) ;
				pBuffer->vSkkSetSkkHenkanKey (bufTemp, nTempLen) ;
				nCombWordLen	= iConcatString (pwCombWord, MAXCOMPLEN, pwKakuteiWord, nKakuteiWordLen, pwCurKakuteiWord, nCurKakuteiWordLen, NULL) ;

				/*	���́A���� wstrWord, nWordLen �� LM_bSkkUpdateJisyo �ɓn����Ȃ���΂Ȃ�Ȃ����A
				 *	���̎w���Ă���̈悪�ۏ؂���Ȃ���������Ȃ��Ƃ������Ƃ��B
				 *
				 *	���z�@�B�� stack ����̈�m�ۂ��āA�����ɕۑ�����c���B���� alignment �����B
				 */
				if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1))
					return	LMR_ERROR ;
				pThis->vSetRegConstString (LMREGARG_0, pwCombWord, nCombWordLen) ;
				pThis->vSetRegBool   (LMREGARG_1, FALSE) ;
				pThis->vSetRegString (LMREG_0, pwSkkHenkanKey, nSkkHenkanKeyLen) ;
				pThis->vSetRegBool   (LMREG_1, TRUE) ;
				if (! pThis->bCall (LM_bSkkUpdateJisyo, LM_bSkkKakutei_2)) {
					return	LMR_ERROR ;
				}
				return	LMR_CONTINUE ;
			}
		}
		pBuffer->vSkkSetSkkAfterPrefix (LFALSE) ;

	} else if (nCurKakuteiWordLen > 0 && bSetsubiji (pwCurKakuteiMidasi, nCurKakuteiMidasiLen)) {

		/* skk-henkan-key �̑ޔ��B*/
		if (nCurHenkanKeyLen > 0)
			dcsncpy (pwSkkHenkanKey, pwCurHenkanKey, nCurHenkanKeyLen) ;
		nSkkHenkanKeyLen	= nCurHenkanKeyLen ;

		nTempLen		= iConcatString (bufTemp, MYARRAYSIZE (bufTemp), pwKakuteiMidasi, nKakuteiMidasiLen, pwCurKakuteiMidasi + 1, nCurKakuteiMidasiLen - 1, NULL) ;
		pBuffer->vSkkSetSkkHenkanKey (bufTemp, nTempLen) ;
		nCombWordLen	= iConcatString (pwCombWord, MAXCOMPLEN, pwKakuteiWord, nKakuteiWordLen, pwCurKakuteiWord, nCurKakuteiWordLen, NULL) ;

		/*	skk-update-jisyo �̌Ăяo���B
		 */
		if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1))
			return	LMR_ERROR ;
		pThis->vSetRegConstString (LMREGARG_0, pwCombWord, nCombWordLen) ;
		pThis->vSetRegBool   (LMREGARG_1, FALSE) ;
		pThis->vSetRegString (LMREG_0, pwSkkHenkanKey, nSkkHenkanKeyLen) ;
		pThis->vSetRegBool   (LMREG_1, FALSE) ;
		if (! pThis->bCall (LM_bSkkUpdateJisyo, LM_bSkkKakutei_2)) {
			return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;
	}

	pThis->vJump (LM_bSkkKakutei_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKakutei_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPDSTR				pwSkkHenkanKey ;
	int					nSkkHenkanKeyLen ;
	int					nRetval	= LMR_RETURN ;
	BOOL				bAfterPrefix ;

	if (pThis->bSignalp ()) 
		goto	exit_func ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}
	/*	���� REG[2] �̒l���ۑ�����Ă��邩�ۂ��ɐs����B�܂�j�󂷂�ꍇ�ɂ͕ۑ����Ă����A�ƁH
	 */
	if (! pThis->bGetRegString (LMREG_0, &pwSkkHenkanKey, &nSkkHenkanKeyLen)) {
		pwSkkHenkanKey		= NULL ;
		nSkkHenkanKeyLen	= 0 ;
	}
	if (! pThis->bGetRegBool (LMREG_1, &bAfterPrefix)) {
		bAfterPrefix		= FALSE ;
	}
	if (bAfterPrefix) {
		pBuffer->vSkkSetSkkAfterPrefix (LFALSE) ;
	}

	/* skk-henkan-key �̕����B*/
	pBuffer->vSkkSetSkkHenkanKey (pwSkkHenkanKey, nSkkHenkanKeyLen) ;

	pThis->vJump (LM_bSkkKakutei_3) ;
	nRetval	= LMR_CONTINUE ;

exit_func:
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	nRetval ;
}

/*
 *	(when (skk-numeric-p)
 *		(setq converted (skk-get-current-candidate))
 *		(skk-num-update-jisyo kakutei-word converted))))
 */
int
CImeDoc::LM_bSkkKakutei_3 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bSkkNumUpdateJisyo ()) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pThis->vJump (LM_bSkkKakutei_4) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKakutei_4 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->bSkkGetSkkMode ()) {
		pBuffer->bSkkKakuteiCleanupBuffer () ;
		/* skk-kakutei-end-function �͎����\��͂Ȃ��B*/
		/* skk-kakutei-initialize? */
		pBuffer->bSkkKakuteiInitialize (NULL, 0) ;
	}
	pThis->vJump (LM_bSkkKakutei_5) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKakutei_5 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/* skk-do-auto-fill */
	if (pBuffer->bSkkGetSkkMode ()) {
		if (! (pBuffer->bJModep () || pBuffer->bJisx0201Modep ())) {
			pBuffer->bSkkJModeOn (pBuffer->bSkkGetSkkKatakana ()) ;
		} 
	} else {
		pThis->vJump (LM_bSkkModeAdJisx0201) ;	// ad-jisx0201
		return	LMR_CONTINUE ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-emulate-original-map
 */
int
CImeDoc::LM_bSkkEmulateOriginalMap (
	CImeDoc*		pThis)
{
	const struct TMSG*	pMsg ;
	int					nFuncNo, nOrigFunc ;
	PLMFUNC				pPC	= NULL ;

	/*	major-map �� lookup ���� function ��ǉ����� call ����B
	 */
	pMsg	= pThis->pGetLastCommandEvent () ;
	if (pMsg == NULL)
		return	LMR_RETURN ;

	if (! pThis->bLookupKeymap (pMsg, &nOrigFunc))
		nOrigFunc	= NFUNC_INVALID_CHAR ;
	if (! pThis->bLookupMajorKeymap (pMsg, &nFuncNo)) 
		nFuncNo	= NFUNC_INVALID_CHAR ;

	/*	emulate-original-map �̌Ăяo�����������[�v�ɂȂ�Ȃ��悤�ɁA
	 *	���Ƃ��Ƃ̌Ăяo���� original-map �̌Ăяo������v���Ă����ꍇ�ɂ́A
	 *	�������Ȃ��B
	 */
	if (nFuncNo == nOrigFunc && nFuncNo != NFUNC_INVALID_CHAR) {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}

	pPC		= pThis->pLookupLMState (nFuncNo) ;
	if (pPC == NULL) {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		return	LMR_RETURN ;	/* �������삪���蓖�Ă��ĂȂ��ꍇ�B*/
	}
	pThis->vJump (pPC) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kana-clean-up
 */
static	int		LM_bSkkHenkan1_1 (CImeDoc*) ;

/*	�������Ԃ��Bm_bufRETURN, LMREGARG_RETVAL �̃R���r�B
 */
int
CImeDoc::LM_bSkkHenkan1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR				wstrNewWord	= NULL ;
	int					nRetval		= 0 ;
	CTSearchSession*	pSession ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (pBuffer->iSkkGetSkkHenkanCount () == 0) {
		/* kakutei jisyo �� search ���Ȃ��Ƃ����̂́c��������ǂ����䂷�ׂ����H */
		if (pSession != NULL) {
			do {
				wstrNewWord		= pSession->pGetCandidate () ;
				if (wstrNewWord != NULL)
					break ;
			}	while (pSession->bNextCandidate ()) ;

			if (wstrNewWord != NULL && pBuffer->bSkkGetSkkKakuteiFlag ()) {
				pThis->bSetLastCommand (NFUNC_SKK_KAKUTEI_HENKAN) ;
			}
		}
	} else {
		if (pSession != NULL) {
			int		iCount ;

			while (pSession->bNextCandidate ()) {
				wstrNewWord		= pSession->pGetCandidate () ;
				if (wstrNewWord != NULL)
					break ;
			}
			/* ����͏����u���Ă����B*/
			iCount	= CImeConfig::iGetCountHenkanShowChange (pThis->m_pConfig) ;
			if (iCount < SHOWCANDLIST_COUNT_NOSHOW) {
				if (wstrNewWord != NULL && pBuffer->iSkkGetSkkHenkanCount () > iCount) {
					pThis->vJump (LM_bSkkHenkanShowCandidates) ;
					/* LMREGARG_RETVAL �� LM_bSkkHenkanShowCandidates �̒l�����̂܂܎g���B*/
					return	LMR_CONTINUE ;
				}
			}
		}
	}
	if (wstrNewWord != NULL) {
		LPDSTR	pwRetbuff ;
		int		nNewWordLen	= dcslen (wstrNewWord) ;
		int		nRetbuffSize ;

		pwRetbuff	= pThis->pGetReturnBuffer (&nRetbuffSize) ;
		if (pwRetbuff == NULL)
			return	LMR_ERROR ;

		nRetval	= (nNewWordLen < nRetbuffSize)? nNewWordLen : nRetbuffSize ;
		if (nRetval > 0)
			dcsncpy (pwRetbuff, wstrNewWord, nRetval) ;
		pThis->vSetRegConstString (LMREGARG_RETVAL, pwRetbuff, nRetval) ;
	} else {
		pThis->vSetRegConstString (LMREGARG_RETVAL, NULL, 0) ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan-in-minibuff
 */
/*	�����Ƃ��āALMREGARG_0 �ɓ��͌��ʂ̕�������i�[���邽�߂̗̈��^���邱�ƁB
 *	�Ԃ�l�́A���͌��ʂ̕����񒷂� LMREGARG_RETVAL �ɐ����^�œ���B
 */
int
CImeDoc::LM_bSkkHenkanInMinibuff (
	CImeDoc*		pThis)
{
	CImeBuffer*			pBuffer ;
	LPDSTR				pwText ;
	int					nText ;
	LPCDSTR				pwSkkHenkanKey ;
	int					nSkkHenkanKeyLen ;
	CTSearchSession*	pSession ;
	DCHAR				bufKeyword [MAXCOMPLEN] ;
	int					iDepth ;

	if (pThis->bSignalp ()) {
		pThis->vSetRegInteger (LMREGARG_RETVAL, -1) ;
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vSetRegInteger (LMREGARG_RETVAL, -1) ;
		return	LMR_RETURN ;
	}
	pwText	= (LPDSTR) pThis->pAlloca (MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwText == NULL)
		return	LMR_ERROR ;
	if (! pThis->bPushReg (LMREG_0) ||
		! pThis->bPushReg (LMREG_1) ||
		! pThis->bPushReg (LMREG_2))
		return	LMR_ERROR ;
	pThis->vSetRegString (LMREG_0, pwText, MAXCOMPLEN) ;

	pwSkkHenkanKey	= pBuffer->pSkkGetSkkHenkanKey (&nSkkHenkanKeyLen) ;
	pSession		= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;

	if (CImeConfig::bSkkNumericConversionp (pThis->m_pConfig) && pSession != NULL && pSession->bNumericp ()) {
		nText	= iSkkNumComputeHenkanKey (pwSkkHenkanKey, nSkkHenkanKeyLen, bufKeyword, MAXCOMPLEN, NULL, 0, CImeConfig::bSkkNumConvertFloatp (pThis->m_pConfig)) ;
	} else if (pBuffer->iSkkGetSkkOkuriCharLength () > 0) {
		LPCDSTR	pwSkkHenkanOkurigana ;
		int		nSkkHenkanOkuriganaLen ;

		pwSkkHenkanOkurigana	= pBuffer->pSkkGetSkkHenkanOkurigana (&nSkkHenkanOkuriganaLen) ;
		nText	= iSkkComputeHenkanKey2 (bufKeyword, MAXCOMPLEN, pwSkkHenkanKey, nSkkHenkanKeyLen, pwSkkHenkanOkurigana, nSkkHenkanOkuriganaLen) ;
	} else {
		nText	= (nSkkHenkanKeyLen < MAXCOMPLEN)? nSkkHenkanKeyLen : MAXCOMPLEN ;
		dcsncpy (bufKeyword, pwSkkHenkanKey, nText) ;
	}
	if (nText < MAXCOMPLEN) {
		bufKeyword [nText]	= L'\0' ;
	} else {
		bufKeyword [MAXCOMPLEN-1]	= L'\0' ;
	}

	iDepth	= pThis->iGetMinibufferDepth () ;
	if (iDepth > 8)
		iDepth	= 8 ;

	//nText	= wnsprintfW (pwText, MAXCOMPLEN, L"%s�����o�^%s %s ", L"[[[[[[[[[" + (8-iDepth), L"]]]]]]]]]" + (8-iDepth), bufKeyword) ;
	{
		DCHAR*	p		= pwText ;
		DCHAR*	pEnd	= pwText + MAXCOMPLEN ;
		int	i, n, nKeywordLen ;

		for (i = 0 ; i <= iDepth && p < pEnd ; i ++) 
			*p ++	= L'[' ;
		n	= wcstodcs (p, pEnd - p , L"�����o�^", 4) ;
		p	+= n ;
		for (i = 0 ; i <= iDepth && p < pEnd ; i ++)
			*p ++	= L']' ;
		if (p < pEnd)
			*p ++	= L' ' ;

		nKeywordLen	= dcslen (bufKeyword) ;
		n			= pEnd - p ;
		if (nKeywordLen < n)
			n	= nKeywordLen ;
		if (n > 0) {
 			dcsncpy (p, bufKeyword, n) ;
			p	+= n ;
		}
		if (p < pEnd)
			*p ++	= L' ' ;
		nText	= p - pwText ;
	}

	pThis->vSetRegConstString (LMREGARG_0, pwText, nText) ;
	pThis->vSetRegBool (LMREGARG_1, pBuffer->bJModep ()) ;
	if (! pThis->bCall (LM_bReadFromMinibuffer, LM_bSkkHenkanInMinibuff_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanInMinibuff_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	LPCDSTR			pwRead = NULL ;
	int				nRead ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (pThis->bSignalp ()) {
		if (pThis->nGetSignal () != LMSIGNAL_QUIT) {
			pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
			return	LMR_CONTINUE ;
		} else {
			/* condition-case �� signal �������Ă���̂ŁB*/
			pThis->vClearSignals () ;
			nRead	= 0 ;
		}
	} else {
		if (! pThis->bGetRegConstString (LMREGARG_RETVAL, &pwRead, &nRead))
			nRead	= -1 ;
	}
	if (nRead < 0) {
		/* buffer �쐬���s�H */
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (pThis->iGetLastCommand () == NFUNC_ABORT_RECURSIVE_EDIT) {
		/* quit */
		nRead	= 0 ;
	}
	if (nRead == 0) {
		if (pBuffer->bShowHenkanCandidatesModep ()) { /* skk-exit-show-candidates */
		} else {
			pBuffer->vSkkSetSkkHenkanCount (pBuffer->iSkkGetSkkHenkanCount () - 1) ;
		}
		if (pBuffer->iSkkGetSkkHenkanCount () == -1) {
			pBuffer->vSkkSetSkkHenkanOkurigana (NULL, 0) ;
			pBuffer->vSkkSetSkkOkurigana (LFALSE) ;
			pBuffer->vSkkSetSkkOkuriChar (NULL, 0) ;
			pBuffer->bSkkChangeMarkerToWhite () ;
		}
	} else {
		CTSearchSession*	pSession ;
		LPCDSTR	wptr ;
		int		nptr ;

		wptr	= pwRead + nRead - 1 ;
		nptr	= nRead ;
		while (nptr > 0 && (*wptr == L' ' || *wptr == L'�@')) {
			wptr	-- ;
			nptr	-- ;
		}
		nRead	= wptr - pwRead + 1 ;

		/*	������ #4 �̏��������Ȃ���΂Ȃ�Ȃ��̂Řb�͂����ȒP�ł͂Ȃ��B#4 �̏����A#4 �� replace
		 *	������ candidate �� insert �܂Ŏ��s���Ȃ���΂Ȃ�Ȃ��B
		 */
		/*	#4 ���܂܂ꂽ������ł��邩�H �������Aconcat �ň͂܂ꂽ������ #4 �͖������Ȃ��Ƃ����Ȃ��̂��H
		 *	��������͊ȒP�ł͂Ȃ��̂����c�B�Ƃ������Aconcat �̌��ʂ��X�ɐ��l�ϊ��Ƃ��� combo �͂���̂��H
		 *	���� concat (lisp �L�q)�� #4 �͑g�ݍ��킹���Ȃ��Ƃ��������u�����Ƃɂ���B
		 */
		pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
		if (nRead > 0 && pSession != NULL && pSession->bNumericp () &&  !bStringLispFormatp (pwRead, nRead)) {
			LPDSTR		pwText, pwDest, pwDestEnd ;
			LPCDSTR		pwNumeric, pwEnd ;
			/*	���ʂ� #4 �̑��݂��`�F�b�N�ł��邩���B
			 */
			/*	MAXCOMPLEN �ȏ�̕�����͓��͂ł��Ȃ��̂ŁAwpText �Ƃ��� MAXCOMPLEN �����m�ۂ���
			 *	�Ζ��Ȃ��Ǝv���B
			 */
			pwText		= (LPDSTR) pThis->pAlloca (sizeof (DCHAR) * (nRead + MAXCOMPLEN + 1), __alignof (DCHAR)) ;
			if (pwText == NULL)
				return	LMR_ERROR ;	/* critical error */

			pwNumeric	= pSession->pGetNumericList () ;
			pwDest		= pwText + nRead ;
			pwDestEnd	= pwDest + MAXCOMPLEN ;
			wptr		= pwRead ;
			pwEnd		= pwRead + nRead ;
			while (wptr < pwEnd) {
				if (*wptr == L'#') {
					LPCDSTR	wptrBase ;

					wptr	++ ;
					/*	���̏ꍇ�ɂ� #4 �ł���Ȃ��Ɋ֌W�Ȃ� numeric-list ��1�� skip ���Ȃ��Ƃ����Ȃ��B
					 */
					wptrBase	= wptr ;
					while (wptr < pwEnd && (L'0' <= *wptr && *wptr <= L'9'))
						wptr	++ ;
					if (wptr == (wptrBase + 1) && wptrBase < pwEnd && *wptrBase == L'4') {
						/*	���̍��ځB*/
						/*	�Ή����鐔�l�����݂��Ȃ���Ζ�������B*/
						if (*pwNumeric != L'\0') {
							LPDSTR	wptrDestBak	= pwDest ;
							/*	wptrNumeric �ɑ΂��ĐV�ɐ��l�o�^�����Ȃ��Ƃ����Ȃ��B*/
							vCopyString (&pwDest, pwDestEnd, pwNumeric) ;
							if (pwDest >= pwDestEnd) {
								/*	�o�b�t�@���I�[�o�[�����ꍇ�ɁA�I�[�o�[���钼�O�܂ł͔F�߂�̂��A
								 *	�S���S���j������̂��H
								 */
								pwDest	= wptrDestBak ;
								break ;
							}
							*pwDest ++	= L'\0' ;
						}
					}
					/*	wptrNumeric �����̍��ڂֈړ�������B
					 */
					if (*pwNumeric != L'\0') {
						pwNumeric	+= dcslen (pwNumeric) + 1 ;
					}
				} else {
					wptr	++ ;
				}
			}
			if (pwDest < pwDestEnd) {
				CTS4Mapping*	pNode ;

				*pwDest ++	= L'\0' ;

				/*	#4 �o�^�̏����ւƕ��򂷂�B*/
				pNode	= pBuffer->pSkkGetSkkS4NumericMappingList () ;
				if (pNode != NULL) {
					pBuffer->vSkkSetSkkS4NumericMappingList (NULL) ;
					CTS4Mapping::vClearList (pNode) ;
				}

				dcsncpy (pwText, pwRead, nRead) ;
				pThis->vSetRegConstString (LMREG_1, pwText, nRead) ;
				pThis->vSetRegConstString (LMREG_2, pwText + nRead, pwDest - (pwText + nRead)) ;
				pThis->vJump (LM_bSkkHenkanInMinibuff_S2) ;
				return	LMR_CONTINUE ;
			}
		}

		/* (setq skk-henkan-list (nconc skk-henkan-list (list new-one))) �����B*/
		if (nRead > 0 && pSession != NULL) {
			/*	�V�K�Ɍ��� insert ���鎞�� #4 expand �� control �ł��邾�낤���H �����Z���K�v���낤�B
			 */
			if (! pSession->bInsertCandidate (pwRead, nRead)) {
				pThis->vSetSignalError () ;
				pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
				return	LMR_CONTINUE ;
			}
		}
		pBuffer->vSkkSetSkkKakuteiFlag (TRUE) ;
	}
	pThis->vSetRegConstString (LMREGARG_RETVAL, pwRead, nRead) ;
	pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanInMinibuff_Exit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		CTS4Mapping*	pNode ;

		pNode	= pBuffer->pSkkGetSkkS4NumericMappingList () ;
		if (pNode != NULL) {
			pBuffer->vSkkSetSkkS4NumericMappingList (NULL) ;
			CTS4Mapping::vClearList (pNode) ;
		}
	}
	pThis->vPopReg (LMREG_2) ;
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkHenkanInMinibuff_S2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPDSTR		pwText ;
#if 0
	LPDSTR		pwDest, pwDestEnd ;
#endif
	LPCDSTR		pwNumeric ;
	int			nTextSize, nNumeric, iDepth, nText ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegString (LMREG_0, &pwText, &nTextSize)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegConstString (LMREG_2, &pwNumeric, &nNumeric)) {
		pwNumeric	= NULL ;
		nNumeric	= 0 ;
	}
	if (nNumeric <= 0 || pwNumeric == NULL || *pwNumeric == L'\0') {
		pThis->vJump (LM_bSkkHenkanInMinibuff_S4) ;
		return	LMR_CONTINUE ;
	}
	/*	"[#4�o�^] %s "
	 */
	iDepth	= pThis->iGetMinibufferDepth () ;
	if (iDepth > 8)
		iDepth	= 8 ;
//	nText	= wnsprintfW (pwText, nTextSize, L"%s�����o�^(#4)%s %s ", L"[[[[[[[[[" + (8-iDepth), L"]]]]]]]]]" + (8-iDepth), pwNumeric) ;
	{
		DCHAR*	p		= pwText ;
		DCHAR*	pEnd	= pwText + MAXCOMPLEN ;
		int	i, n ;

		for (i = 0 ; i <= iDepth && p < pEnd ; i ++) 
			*p ++	= L'[' ;
		n	= wcstodcs (p, pEnd - p , L"�����o�^(#4)", 4) ;
		p	+= n ;
		for (i = 0 ; i <= iDepth && p < pEnd ; i ++)
			*p ++	= L']' ;
		if (p < pEnd)
			*p ++	= L' ' ;

		n			= pEnd - p ;
		nNumeric	= dcslen (pwNumeric) ;
		if (nNumeric < n)
			n	= nNumeric ;
		if (n > 0) {
 			dcsncpy (p, pwNumeric, n) ;
			p	+= n ;
		}
		if (p < pEnd)
			*p ++	= L' ' ;
		nText	= p - pwText ;
	}

#if 0
	pwDest			= pwText ;
	pwDestEnd		= pwText + nTextSize ;
	vCopyString (&pwDest, pwDestEnd, 
	vCopyString (&pwDest, pwDestEnd, L"[#4�o�^] ") ;
	vCopyString (&pwDest, pwDestEnd, pwNumeric) ;
	vCopyString (&pwDest, pwDestEnd, L" ") ;
	pThis->vSetRegConstString (LMREGARG_0, pwText, pwDest - pwText) ;
#else
	pThis->vSetRegConstString (LMREGARG_0, pwText, nText) ;
#endif
	pThis->vSetRegBool (LMREGARG_1, pBuffer->bJModep ()) ;
	if (! pThis->bCall (LM_bReadFromMinibuffer, LM_bSkkHenkanInMinibuff_S3))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanInMinibuff_S3 (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	LPCDSTR			pwRead = NULL ;
	int				nRead ;
	LPCDSTR			pwNumeric ;
	int				nNumericSize, nNumericLen ;
	CTS4Mapping*	plstS4Mapping	= NULL ;
	CTS4Mapping*	pNode ;

	/*	�������� quit �̔���܂ł́A���� bSkkHenkanInMinibuff_1 �Ɠ��������ł���B
	 */
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (pThis->bSignalp ()) {
		if (pThis->nGetSignal () != LMSIGNAL_QUIT) {
			pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
			return	LMR_CONTINUE ;
		} else {
			/* condition-case �� signal �������Ă���̂ŁB*/
			pThis->vClearSignals () ;
			nRead	= 0 ;
		}
	} else {
		if (! pThis->bGetRegConstString (LMREGARG_RETVAL, &pwRead, &nRead))
			nRead	= -1 ;
	}

	if (! pThis->bGetRegConstString (LMREG_2, &pwNumeric, &nNumericSize)) {
		pwNumeric		= NULL ;
		nNumericSize	= 0 ;
	}

	if (nRead < 0 || nNumericSize <= 0) {
		/* buffer �쐬���s�H */
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (pThis->iGetLastCommand () == NFUNC_ABORT_RECURSIVE_EDIT) {
		/* quit */
		nRead	= 0 ;
	}

	/*	�������� #4 ����B
	 */
	if (nRead > 0) {
		LPCDSTR	wptr ;
		int		nptr ;

		wptr	= pwRead + nRead - 1 ;
		nptr	= nRead ;
		while (nptr > 0 && (*wptr == L' ' || *wptr == L'�@')) {
			wptr	-- ;
			nptr	-- ;
		}
		nRead	= wptr - pwRead + 1 ;
	}

	/*	#4 �� mapping ���L������B*/
	pNode	= CTS4Mapping::pCreate (pwNumeric, pwRead, nRead) ;
	if (pNode == NULL) {
		/* fatal */
		return	LMR_ERROR ;
	}
	/*	buffer-local variable �Ƃ������ƂŁApbuffer �̈ꕔ�Ƃ��ċL��������B
	 *	REG �̏ゾ�����ƁA������ꂸ�ɂЂǂ����ƂɂȂ肻���������̂ŁB
	 */
	plstS4Mapping	= pBuffer->pSkkGetSkkS4NumericMappingList () ;
	if (! CTS4Mapping::bInsertLast (&plstS4Mapping, pNode)) {
		pBuffer->vSkkSetSkkS4NumericMappingList (NULL) ;
		CTS4Mapping::vClearList (plstS4Mapping) ;
		return	LMR_ERROR ;
	}
	pBuffer->vSkkSetSkkS4NumericMappingList (plstS4Mapping) ;
	
	/*	���� numeric ���ւƈړ�������B
	 */
	nNumericLen		= dcslen (pwNumeric) ;
	pwNumeric		+= (nNumericLen + 1) ;
	nNumericSize	-= (nNumericLen + 1) ;
	if (nNumericSize <= 0) {
		pThis->vJump (LM_bSkkHenkanInMinibuff_S4) ;
	} else {
		pThis->vSetRegConstString (LMREG_2, pwNumeric, nNumericSize) ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_S2) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanInMinibuff_S4 (
	CImeDoc*		pThis)
{
	CImeBuffer*			pBuffer ;
	CTSearchSession*	pSession ;
	LPCDSTR				pwRead ;
	int					nRead ;

	if (pThis->bSignalp ()) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegConstString (LMREG_1, &pwRead, &nRead)) {
		pwRead	= NULL ;
		nRead	= 0 ;
	}

	/* (setq skk-henkan-list (nconc skk-henkan-list (list new-one))) �����B*/
	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (nRead > 0 && pSession != NULL) {
		BOOL	bFound	= FALSE ;

		/*	�V�K�Ɍ��� insert ���鎞�� #4 expand �� control �ł��邾�낤���H �����Z���K�v���낤�B
		 */
		if (! pSession->bInsertCandidateWithS4Mapping (pwRead, nRead, pBuffer->pSkkGetSkkS4NumericMappingList ())) {
			pThis->vSetSignalError () ;
			pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
			return	LMR_CONTINUE ;
		}

		/*	���l�ϊ��̖�肩�����ǂݒ����K�v������B
//		pwRead	= TSearchSession_pGetReferCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
//		if (pwRead == NULL)
		 */
		pwRead	= pSession->pGetCandidate () ;
		if (pwRead != NULL) {
			nRead	= dcslen (pwRead) ;
			if (nRead > 0) {
				LPDSTR		pwRetbuf ;
				int			nRetbufSize ;

				pwRetbuf	= pThis->pGetReturnBuffer (&nRetbufSize) ;
				if (pwRetbuf != NULL && nRetbufSize > 0) {
					nRead	= MIN (nRetbufSize, nRead) ;
					dcsncpy (pwRetbuf, pwRead, nRead) ;
					pwRead	= pwRetbuf ;
					bFound	= TRUE ;
				}
			}
		}
		if (! bFound) {
			pwRead	= NULL ;
			nRead	= 0 ;
		}
	} else {
		pwRead	= NULL ;
		nRead	= 0 ;
	}
	pThis->vSetRegConstString (LMREGARG_RETVAL, pwRead, nRead) ;
	pThis->vJump (LM_bSkkHenkanInMinibuff_Exit) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kana-clean-up
 */
int
CImeDoc::LM_bSkkTryCompletion (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		pThis->vSetRegBool (LMREGARG_0, (pThis->iGetLastCommand () != NFUNC_SKK_COMP_DO)? TRUE : FALSE) ;
		if (! pThis->bCall (LM_bSkkCompDo, LM_bSkkTryCompletion_1))
			return	LMR_ERROR ;
	} else {
		if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkTryCompletion_Exit)) 
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkTryCompletion_1 (
	CImeDoc*		pThis)
{
	if (! pThis->bSignalp ()) {
		pThis->bSetThisCommand (NFUNC_SKK_COMP_DO) ;
	}
	pThis->vJump (LM_bSkkTryCompletion_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkTryCompletion_Exit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-abbrev-comma
 */
int
CImeDoc::LM_bSkkAbbrevComma (
	CImeDoc*		pThis)
{
	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	if (pThis->iGetLastCommand () == NFUNC_SKK_COMP_DO) {
		if (! pThis->bCall (LM_bSkkCompPrevious, LM_bSkkTryCompletion_1))
			return	LMR_ERROR ;
	} else {
		if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkTryCompletion_Exit)) 
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

/*================================================================ skk-abbrev-period
 */
int
CImeDoc::LM_bSkkAbbrevPeriod (
	CImeDoc*		pThis)
{
	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	if (pThis->iGetLastCommand () == NFUNC_SKK_COMP_DO) {
		pThis->vSetRegBool (LMREGARG_0, FALSE) ;
		if (! pThis->bCall (LM_bSkkCompDo, LM_bSkkTryCompletion_1))
			return	LMR_ERROR ;
	} else {
		if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkTryCompletion_Exit)) 
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

/*================================================================ skk-set-char-before-as-okurigana
 */
int
CImeDoc::LM_bSkkSetCharBeforeAsOkurigana (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	BOOL				bNoSokuon	= FALSE ;
	int					iPt1, iOkuri = -1, iSokuon = -1 ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	iPt1	= pBuffer->iGetPoint () ;
	if (iPt1 > 0) {
		iOkuri	= pBuffer->iGetCharAt (iPt1 - 1) ;
	} else {
		iOkuri	= -1 ;
	}
	if (iOkuri >= 0) {
		LPCDSTR		pwBufferString ;
		int			iOkuriganaStartPoint, iBufferEnd ;
		CTMarker*	pmkOkuriganaStartPoint	= NULL ;
		CTMarker*	pmkBufferEnd			= NULL ;
		DCHAR		bufOkuriChar [64] ;
		int			nOkuriCharLen ;

		if (! bNoSokuon) {
			iSokuon	= (iPt1 > 1)? pBuffer->iGetCharAt (iPt1 - 2) : -1 ;
			if (iSokuon != L'��' && iSokuon != L'�b')
				iSokuon	= -1 ;
		}
		if (! pBuffer->bSkkSetSkkOkuriganaStartPointToPoint () || pBuffer->pSkkGetSkkOkuriganaStartPointMarker () == NULL) {
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
		pmkOkuriganaStartPoint	= pBuffer->pSkkGetSkkOkuriganaStartPointMarker () ;
		(void) pmkOkuriganaStartPoint->bBackward (iSokuon >= 0? 2 : 1) ;

		iOkuriganaStartPoint	= pmkOkuriganaStartPoint->iGetPosition () ;
		if (! pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkBufferEnd) || pmkBufferEnd == NULL) {
			iBufferEnd	= pBuffer->iGetPointMax () ;
		} else {
			iBufferEnd	= pmkBufferEnd->iGetPosition () ;
		}
		pwBufferString	= pBuffer->pBufferRawString (NULL) ;
		nOkuriCharLen	= pBuffer->iSkkOkuriganaPrefix (pwBufferString + iOkuriganaStartPoint, iBufferEnd - iOkuriganaStartPoint, bufOkuriChar, MYARRAYSIZE (bufOkuriChar)) ;
		pBuffer->vSkkSetSkkOkuriChar (bufOkuriChar, nOkuriCharLen) ;

		/*	original �ɂ́A������ skk-okurigana �� t �ɂ���R�[�h�͂Ȃ����A�����ǉ�����B
		 *	skk-henkan �ɑΉ�����code�� skk-okurigana �����Ă���̂ŁAnil �̂܂܂��Ƒ���ϊ��ɂȂ�Ȃ��B
		 */
		pBuffer->vSkkSetSkkOkurigana (LTRUE) ;

		/*	���̏����͕K�v���낤���H
		if (pBuffer->m_pSkkCurrentSearchProgSession == NULL) {
		}
		*/
		/*	defadvice �� skk-set-okurigana �̌Ăяo���́A�܂� skk-set-okurigana-ad-jisx0201 �ɂ����
		 *	wrap �����B
		 *		pThis->vJump (LM_bSkkSetOkurigana) ;
		 */
		pThis->vJump (LM_bSkkSetOkuriganaAdJisx0201) ;
		return	LMR_CONTINUE ;
	}
	return	LMR_RETURN ;
}


/*================================================================ skk-toggle-kutouten
 */
int
CImeDoc::LM_bSkkToggleKutouten (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	int			iCurrentKutotenType, iNumKutouten ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	/*	��Ǔ_�^�C�v�𑝂₵�����Ƃ����l�͂���̂��낤���H 
	 *	�W���ł� 'en, 'jp �����Ȃ����Aalist �Ƃ������Ƃ͒ǉ����ł���Ƃ������ƂŁc
	 *	�����A���̏ꍇ�ɂ� toggle-kutoten ���ꎩ�̂��Ē�`���Ȃ��Ƃ����Ȃ����ǁB
	 */
	iCurrentKutotenType	= pBuffer->iSkkGetSkkCurrentKutotenType () ;
	iNumKutouten		= CImeConfig::iGetNumberOfKutotens (pThis->m_pConfig) ;
	if (iNumKutouten > 0) {
		iCurrentKutotenType	= (iCurrentKutotenType + 1) % iNumKutouten ;
	} else {
		iCurrentKutotenType	= 0 ;
	}
	pBuffer->vSkkSetSkkCurrentKutotenType (iCurrentKutotenType) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-current-kuten
 */
/*	interactive-function �ł͂Ȃ��̂����c�B
 */
int
CImeDoc::LM_bSkkCurrentKuten (
	CImeDoc*		pThis)
{
	LPCDSTR		pwKuten ;
	int			nKutenLen ;
//	LPDSTR		pwResult ;
//	int			nResultSize ;

	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
#if 0
	pwResult	= pThis->pGetReturnBuffer (&nResultSize) ;
	pwKuten		= pThis->pGetCurrentKuten (pBuffer->iSkkGetSkkCurrentKutotenType (), &nKutenLen) ;
	if (pwKuten != NULL && pwResult != NULL) {
		int		n	= MIN (nResultSize, nKutenLen) ;
		dcsncpy (pwResult, pwKuten, nKutenLen) ;
		pThis->vSetRegConstString (LMREGARG_RETVAL, pwResult, nKutenLen) ;
	} else {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
	}
#else
	pwKuten		= CImeConfig::pGetCurrentKuten (pThis->m_pConfig, pBuffer->iSkkGetSkkCurrentKutotenType (), &nKutenLen) ;
	if (pwKuten != NULL) {
		pThis->vSetRegConstString (LMREGARG_RETVAL, pwKuten, nKutenLen) ;
	} else {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
	}
#endif
	return	LMR_RETURN ;
}

/*================================================================ skk-current-touten
 */
/*	interactive-function �ł͂Ȃ��̂����c�ǂ����邩�B
 */
int
CImeDoc::LM_bSkkCurrentTouten (
	CImeDoc*		pThis)
{
	LPCDSTR		pwTouten ;
	int			nToutenLen ;
//	LPDSTR		pwResult ;
//	int			nResultSize ;

	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
#if 0
	pwResult	= pThis->pGetReturnBuffer (&nResultSize) ;
	pwTouten	= pThis->pGetCurrentTouten (pBuffer->iSkkGetSkkCurrentKutotenType (), &nToutenLen) ;
	if (pwTouten != NULL && pwResult != NULL) {
		int		n	= MIN (nResultSize, nToutenLen) ;
		dcsncpy (pwResult, pwTouten, nToutenLen) ;
		pThis->vSetRegConstString (LMREGARG_RETVAL, pwResult, nToutenLen) ;
	} else {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
	}
#else
	/*	�q�[�v��� pwTouten ���m�ۂ���Ă���̂ŁAReturn Buffer �ɃR�s�[����K�v�͂Ȃ��B
	 */
	pwTouten	= CImeConfig::pGetCurrentTouten (pThis->m_pConfig, pBuffer->iSkkGetSkkCurrentKutotenType (), &nToutenLen) ;
	if (pwTouten != NULL) {
		pThis->vSetRegConstString (LMREGARG_RETVAL, pwTouten, nToutenLen) ;
	} else {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
	}
#endif
	return	LMR_RETURN ;
}

/*================================================================ skk-toggle-characters
 */
int
CImeDoc::LM_bSkkToggleCharacters (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;

	if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		CTMarker*		pmkHenkanStartPoint ;
		CTMarker*		pmkPoint ;
		int				nEndPos, nPosition, nCH ;
		int				(*pFunc)(CImeDoc*) ;
		BOOL			bVContract	= FALSE ;

		if (! pBuffer->bGetMarker (CImeBuffer::MARKER_SKK_HENKAN_START_POINT, &pmkHenkanStartPoint) || pmkHenkanStartPoint == NULL ||
			! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
			pThis->vSetSignalError () ;
			return	LMR_RETURN ;
		}
		nEndPos		= pmkPoint->iGetPosition () ;
		nPosition	= pmkHenkanStartPoint->iGetPosition () ;
		pFunc		= NULL ;
		while (nPosition < nEndPos && nPosition < pBuffer->iGetPointMax ()) {
			nCH	= pBuffer->iGetCharAt (nPosition) ;
			if (bHiraganaCharp (nCH)) {
				pFunc	= &LM_bSkkKatakanaRegion ;
				bVContract	= TRUE ;
				break ;
			} else if (bKatakanaCharp (nCH)) {
				pFunc	= &LM_bSkkHiraganaRegion ;
				break ;
			} else if (bJisx0208LatinCharp (nCH)) {
				pFunc	= &LM_bSkkLatinRegion ;
				break ;
			} else if (bSkkAsciiCharp (nCH)) {
				pFunc	= &LM_bSkkJisx0208LatinRegion ;
				break ;
			}
			nPosition	++ ;
		}
		pThis->vSetRegPointer (LMREGARG_0, pFunc) ;
		pThis->vSetRegBool (LMREGARG_1, bVContract) ;
		if (! pThis->bCall (LM_bSkkHenkanSkkRegionByFunc, LM_bSkkToggleCharacters_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else if (pThis->bRecursiveEditp () && ! pBuffer->bJModep ()) {
		pBuffer->bSkkJModeOn (FALSE) ;
	} else {
		pBuffer->vSkkSetSkkKatakana (! pBuffer->bSkkGetSkkKatakana ()) ;
	}
	pThis->vJump (LM_bSkkToggleCharacters_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkToggleCharacters_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) 
		pThis->vSetRegBool   (LMREG_0, pBuffer->bSkkGetSkkKatakana ()) ;
	pThis->vSetRegString (LMREGARG_0, NULL, 0) ;
	if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkToggleCharacters_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkToggleCharacters_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	BOOL					bSkkKatakana ;

	if (! pThis->bGetRegBool (LMREG_0, &bSkkKatakana))
		bSkkKatakana	= FALSE ;
	pThis->vPopReg (LMREG_0) ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (pBuffer->bJModep ()) {
		pBuffer->bSkkJModeOn (bSkkKatakana) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan-skk-region-by-func
 */
int
CImeDoc::LM_bSkkHenkanSkkRegionByFunc (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pThis->vSetRegNil (LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	} else if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		int		(*pFunc)(CImeDoc*) ;
		int		nHenkanStartPoint, nPoint ;
		BOOL	bVContract ;

		pBuffer->bSkkSetSkkHenkanEndPointToPoint () ;
		nHenkanStartPoint	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
		nPoint				= pBuffer->iGetPoint () ;
		if (nHenkanStartPoint < nPoint && 0 <= nHenkanStartPoint && nHenkanStartPoint < pBuffer->iGetPointMax () &&
			bHiraganaCharp (pBuffer->iGetCharAt (nHenkanStartPoint))) {
			LPCDSTR	pwBufferString	= pBuffer->pBufferRawString (NULL) ;
			pBuffer->bSkkUpdateKakuteiHistory (pwBufferString + nHenkanStartPoint, nPoint - nHenkanStartPoint, NULL, 0) ;
		}
		if (pBuffer->pSkkGetSkkRuleTreeIterator ()->bHavePrefixp ()) {
			/* ���͓r���̉����v���t�B�N�X������܂��B*/
			pThis->bSetMessage (L"���͓r���̉����v���t�B�N�X������܂�") ;
			pThis->vSetSignalError () ;
			pThis->vJump (LM_bSkkHenkanSkkRegionByFunc_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (nPoint < nHenkanStartPoint) {
			pThis->bSetMessage (L"�J�[�\�����ϊ��J�n�n�_���O�ɂ���܂�") ;
			pThis->vSetSignalError () ;
			pThis->vJump (LM_bSkkHenkanSkkRegionByFunc_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (! CImeConfig::bSkkAllowsSpacesNewlinesAndTabs (pThis->m_pConfig)) {
			LPCDSTR	pwBufferString ;
			int		nPos, nBufferLength ;

			pwBufferString	= pBuffer->pBufferRawString (&nBufferLength) ;
			for (nPos = nHenkanStartPoint ; nPos < nPoint && nPos < nBufferLength ; nPos ++) {
				int		nCH	= pwBufferString [nPos] ;
				if (nCH == L' ' || nCH == L'\t' || nCH == L'\n' || nCH == L'\r') {
					pThis->bSetMessage (L"�ϊ��L�[�ɉ��s���܂܂�Ă��܂�") ;
					pThis->vSetSignalError () ;
					pThis->vJump (LM_bSkkHenkanSkkRegionByFunc_Exit) ;
					return	LMR_CONTINUE ;
				}
			}
		}
		if (! pThis->bGetRegPointer (LMREGARG_0, (void**)&pFunc)) {
			pThis->vSetSignalError () ;
			pThis->vJump (LM_bSkkHenkanSkkRegionByFunc_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (! pThis->bGetRegBool (LMREGARG_1, &bVContract))
			bVContract	= FALSE ;
		if (pFunc != NULL) {
			pThis->vSetRegInteger (LMREGARG_0, nHenkanStartPoint) ;
			pThis->vSetRegInteger (LMREGARG_1, nPoint) ;
			pThis->vSetRegBool (LMREGARG_2, bVContract) ;
			if (! pThis->bCall (pFunc, LM_bSkkHenkanSkkRegionByFunc_1))
				return	LMR_ERROR ;
		} else {
			pThis->vJump (LM_bSkkHenkanSkkRegionByFunc_1) ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkHenkanSkkRegionByFunc_Exit))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
}

int
CImeDoc::LM_bSkkHenkanSkkRegionByFunc_1 (
	CImeDoc*			pThis)
{
	if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkHenkanSkkRegionByFunc_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanSkkRegionByFunc_Exit (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/* skk-point-move �̌��ʁB*/
	pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-katakana-region
 */
int
CImeDoc::LM_bSkkKatakanaRegion (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pwBufferString ;
	int		nStartPos, nEndPos, nLength, nReplaceText ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	BOOL	bVContract ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &nStartPos) || ! pThis->bGetRegInteger (LMREGARG_1, &nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bValidRegionp (nStartPos, nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegBool (LMREGARG_2, &bVContract))
		bVContract	= FALSE ;

	pwBufferString	= pBuffer->pBufferRawString (NULL) ;
	nLength			= iSkkHiraganaToKatakana (bufTemp, MYARRAYSIZE (bufTemp), pwBufferString + nStartPos, nEndPos - nStartPos, bVContract) ;

	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
		pBuffer->bDeleteRegion (nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nReplaceText) ;
		pBuffer->iInsertByPosition (nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-hiragana-region
 */
int
CImeDoc::LM_bSkkHiraganaRegion (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pwBufferString ;
	int		nStartPos, nEndPos, nLength, nReplaceText ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	BOOL	bVExtract ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &nStartPos) || ! pThis->bGetRegInteger (LMREGARG_1, &nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bValidRegionp (nStartPos, nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegBool (LMREGARG_2, &bVExtract))
		bVExtract	= FALSE ;

	pwBufferString	= pBuffer->pBufferRawString (NULL) ;
	nLength	= iSkkKatakanaToHiragana (bufTemp, MYARRAYSIZE (bufTemp), pwBufferString + nStartPos, nEndPos - nStartPos, bVExtract) ;

	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
		pBuffer->bDeleteRegion (nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nReplaceText) ;
		pBuffer->iInsertByPosition (nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0208-latin-region
 */
int
CImeDoc::LM_bSkkJisx0208LatinRegion (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pwBufferString ;
	int		nStartPos, nEndPos ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pSrc, pSrcEnd ;
	int		nLength, nReplaceText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &nStartPos) || ! pThis->bGetRegInteger (LMREGARG_1, &nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bValidRegionp (nStartPos, nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pwBufferString	= pBuffer->pBufferRawString (NULL) ;
	pDest		= bufTemp ;
	pDestEnd	= bufTemp + MYARRAYSIZE (bufTemp) ;
	pSrc		= pwBufferString + nStartPos ;
	pSrcEnd		= pwBufferString + nEndPos ; 
	while (pSrc < pSrcEnd && pDest < pDestEnd) {
		if (L' ' <= *pSrc && *pSrc <= L'~') {
			DCHAR	bufCH [MAXCOMPLEN] ;
			int		nLen	= CImeConfig::iSkkARefSkkJisx0208LatinVector (pThis->m_pConfig, *pSrc, bufCH, MYARRAYSIZE (bufCH)) ;

			if (nLen >= 0) {
				LPCDSTR	ptr ;

				ptr		= bufCH ;
				while (pDest < pDestEnd && nLen > 0) {
					*pDest ++	= *ptr ++ ;
				}
			} else {
				*pDest ++	= *pSrc ++ ;
			}
		} else {
			*pDest ++	= *pSrc ++ ;
		}
	}
	nLength			= pDest - bufTemp ;
	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
		pBuffer->bDeleteRegion (nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nReplaceText) ;
		pBuffer->iInsertByPosition (nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-latin-region
 */
int
CImeDoc::LM_bSkkLatinRegion (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pwBufferString ;
	int		nStartPos, nEndPos ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pSrc,  pSrcEnd ;
	int		nLength, nReplaceText ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_0, &nStartPos) || ! pThis->bGetRegInteger (LMREGARG_1, &nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bValidRegionp (nStartPos, nEndPos)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pwBufferString	= pBuffer->pBufferRawString (NULL) ;
	pDest		= bufTemp ;
	pDestEnd	= bufTemp + MYARRAYSIZE (bufTemp) ;
	pSrc		= pwBufferString + nStartPos ;
	pSrcEnd		= pwBufferString + nEndPos ; 
	while (pSrc < pSrcEnd && pDest < pDestEnd) {
		if (L'�@' <= *pSrc && *pSrc <= L'�`') {
			DCHAR	bufCH [16] ;
			int		nLen ;

			/*	skk-jisx0208-latin-vector ���t�Ɉ����B*/
			nLen	= CImeConfig::iSkkRevRefSkkJisx0208LatinVector (pThis->m_pConfig, *pSrc, bufCH, MYARRAYSIZE (bufCH)) ;
			if (nLen >= 0) {
				LPCDSTR	ptr ;

				ptr		= bufCH ;
				while (pDest < pDestEnd && nLen > 0) {
					*pDest ++	= *ptr ++ ;
				}
			} else {
				*pDest ++	= *pSrc ++ ;
			}
		} else {
			*pDest ++	= *pSrc ++ ;
		}
	}

	nLength			= pDest - bufTemp ;
	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
		pBuffer->bDeleteRegion (nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nReplaceText) ;
		pBuffer->iInsertByPosition (nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		pBuffer->iOverwriteByPosition (nStartPos, bufTemp, nLength) ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0208-latin-insert
 */
int
CImeDoc::LM_bSkkJisx0208LatinInsert (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	DCHAR				bufResult [MAXCOMPLEN] ;
	LPDSTR				pwResult ;
	int					iCH ;
	int					nResult ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	iCH		= pThis->iGetLastCommandChar () ;
	nResult	= CImeConfig::iSkkARefSkkJisx0208LatinVector (pThis->m_pConfig, iCH, bufResult, MYARRAYSIZE (bufResult)) ;
	if (nResult < 0) {
		if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkJisx0208LatinInsert_Exit))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	pwResult	= (LPDSTR) pThis->pAlloca (nResult * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwResult == NULL)
		return	LMR_ERROR ;
	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;

	dcsncpy (pwResult, bufResult, nResult) ;
	pThis->vSetRegConstString (LMREGARG_0, pwResult, nResult) ;
	pThis->vSetRegConstString (LMREG_0,    pwResult, nResult) ;
	if (! pThis->bCall (LM_bSkkInsertStr, LM_bSkkJisx0208LatinInsert_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkJisx0208LatinInsert_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR		pwResult ;
	int			nResult ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkJisx0208LatinInsert_Exit) ;
		return	LMR_CONTINUE ;
	}

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkJisx0208LatinInsert_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegConstString (LMREG_0, &pwResult, &nResult)) {
		pwResult	= NULL ;
		nResult		= 0 ;
	}

	/*	�y�A���́c�B���܂�L���ł͂Ȃ��̂�����ǂ������͂��Ă����B
	 */
	if (nResult > 0 && CImeConfig::bSkkAutoInsertParen (pThis->m_pConfig)) {
		DCHAR	bufPairStr [MAXCOMPLEN] ;
		int		nPairStr ;

		nPairStr	= CImeConfig::iSkkAssocSkkAutoParenStringAlist (pThis->m_pConfig, pwResult, nResult, bufPairStr, MYARRAYSIZE (bufPairStr)) ;
		if (nPairStr > 0) {
			LPDSTR		pwPairStr ;
			CTMarker*	pmkPoint ;
			CTMarker*	pmkMark ;

			pwPairStr	= (LPDSTR) pThis->pAlloca (nPairStr * sizeof (DCHAR), __alignof (DCHAR)) ;
			if (pwPairStr == NULL)
				return	LMR_ERROR ;

			pmkMark		= pBuffer->pMakeMarker (FALSE) ;
			if (pmkMark == NULL || ! pBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
				pThis->vSetSignalError () ;
				pThis->vJump (LM_bSkkJisx0208LatinInsert_Exit) ;
				return	LMR_CONTINUE ;
			}
			pmkMark->bSetPosition (pmkPoint) ;

			dcsncpy (pwPairStr, bufPairStr, nPairStr) ;
			pThis->vSetRegConstString (LMREGARG_0, pwPairStr, nPairStr) ;
			pThis->vSetRegPointer (LMREG_0, pmkMark) ;

			/*	���̃R�[�h�� insert �񐔂𐔂��āA�J�[�\���� backward ���Ă��邪�c�B�������� insert
			 *	�񐔂́A���ۂ� insert ���ꂽ�ʂƈقȂ�\���������Č������B
			 *	marker ���g���� cursor �ʒu���L������̂��ǂ����B
			 */
			if (! pThis->bCall (LM_bSkkInsertStr, LM_bSkkJisx0208LatinInsert_2))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	pThis->vJump (LM_bSkkJisx0208LatinInsert_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkJisx0208LatinInsert_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	CTMarker*	pmkMark ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		/* �������� buffer �s�݂ł̓}�[�J�̔j�����ł��Ȃ��B*/
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkJisx0208LatinInsert_Exit) ;
		return	LMR_CONTINUE ;
	}
	/*	signal ��Ԃł��낤�ƂȂ��낤�ƁAmarker ��j�����Ȃ��Ƃ܂����B
	 */
	if (! pThis->bGetRegPointer (LMREG_0, (void**)&pmkMark)) {
		pmkMark	= NULL ;
	}
	if (pmkMark != NULL) {
		CTMarker*	pmkPoint	= pBuffer->pGetPointMarker () ;
		if (pmkPoint != NULL)
			pmkPoint->bSetPosition (pmkMark) ;
		pBuffer->bDeleteMarker (pmkMark) ;
	}
	pThis->vJump (LM_bSkkJisx0208LatinInsert_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkJisx0208LatinInsert_Exit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	}
	pThis->vPopReg (LMREG_0) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-kana-clean-up
 */
int
CImeDoc::LM_bSkkKanaCleanup (
	CImeDoc*		pThis)
{
	CSkkRuleTreeIterator*			piteSkkRuleTree ;
	const CSkkRuleTreeNodeOutput*	pData	= NULL ;
	CImeBuffer*	pBuffer ;
	LPCDSTR				wstrKana ;
	int					nKanaLen ;
	BOOL				bForce ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	/*	Register �o�R�ň�����n���̂��c�H
	 */
	if (! pThis->bGetRegBool (LMREGARG_0, &bForce)) {
		bForce	= FALSE ;
	}

	/* 	������ BOOL bForce ���ǂ�����Ď󂯎��̂��c�B*/
	piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
	if (piteSkkRuleTree->bHavePrefixp () && ! piteSkkRuleTree->bHaveNextState ()) {
//	if (pBuffer->pSkkGetSkkCurrentRuleTree () != NULL && pBuffer->pSkkGetSkkCurrentRuleTree ()->pGetNextState (&nNextState) == NULL) {
		pData	= piteSkkRuleTree->pGetOutput () ;
//		pData	= pBuffer->pSkkGetSkkCurrentRuleTree ()->pGetOutput () ;
	} else {
		pData	= NULL ;
	}
	if (bForce || pData != NULL) {
		pBuffer->bSkkErasePrefix (TRUE) ;

		wstrKana	= NULL ;
		nKanaLen	= 0 ;
		if (pData != NULL) {
			int		nType	= pData->iGetType () ;
			if (nType == CSkkRuleTreeNodeOutput::NTYPE_MACRO) {
				const CSkkRuleTreeNodeOutputMacro*	pDataMacro	= static_cast <const CSkkRuleTreeNodeOutputMacro*> (pData) ;
				PLMFUNC	pPC	= NULL ;

				/*	�ށAskk-kana-cleanup ���܂����̂��B������ execute ���Ȃ��Ƃ����Ȃ��̂ŁA��x�����Ԃ��Ȃ���΁c�B
				 */
				pPC	= pThis->pLookupLMState (pDataMacro->iGetFunctionCode ()) ;
				if (pPC == NULL) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}
				if (! pThis->bCall (pPC, LM_bSkkKanaCleanup_1))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			} else {
				if (nType == CSkkRuleTreeNodeOutput::NTYPE_STRINGPAIR) {
					const CSkkRuleTreeNodeOutputStringPair*	pDataPair	= static_cast <const CSkkRuleTreeNodeOutputStringPair*> (pData) ;

					if (pBuffer->bSkkGetSkkKatakana ()) {
						wstrKana	= pDataPair->pGetKatakana (&nKanaLen) ;
					} else {
						wstrKana	= pDataPair->pGetHiragana (&nKanaLen) ;
					}
				} else if (nType == CSkkRuleTreeNodeOutput::NTYPE_STRING) {
					const CSkkRuleTreeNodeOutputString*	pDataStr	= static_cast <const CSkkRuleTreeNodeOutputString*> (pData) ;
					wstrKana	= pDataStr->pGetString (&nKanaLen) ;
				}
			}
		}
		if (wstrKana != NULL && nKanaLen > 0) {
			LPDSTR	pwString ;

			pwString	= (LPDSTR) pThis->pAlloca (nKanaLen * sizeof (DCHAR), __alignof (DCHAR)) ;
			if (pwString == NULL) 
				return	LMR_ERROR ;

			dcsncpy (pwString, wstrKana, nKanaLen) ;
			pThis->vSetRegConstString (LMREGARG_0, pwString, nKanaLen) ;
			if (! pThis->bCall (LM_bSkkInsertStr, LM_bSkkKanaCleanup_2))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
		pBuffer->vSkkClearSkkKanaStartPoint () ;
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkKanaCleanup_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR		pwString, pwLeft, pwRight ;
	int			nStringLen, nLeft, nRight, nResultLen ;
	LPDSTR		pwResult ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/*	Macro �����s������̏����B�{���͂��̌��ʂ� string �Ł`�Ƃ����\���B
	 */
	if (pThis->bGetRegConstString (LMREGARG_RETVAL, &pwString, &nStringLen)) {
		/* ... */
	} else if (pThis->bGetRegConstStringPair (LMREGARG_RETVAL, &pwLeft, &nLeft, &pwRight, &nRight)) {
		if (pBuffer->bSkkGetSkkKatakana ()) {
			pwString	= pwRight ;
			nStringLen	= nRight ;
		} else {
			pwString	= pwLeft ;
			nStringLen	= nLeft ;
		}
	} else {
		pwString	= NULL ;
		nStringLen	= 0 ;
	}
	if (pwString != NULL && nStringLen > 0) {
		pwResult	= (LPDSTR) pThis->pAlloca (nStringLen * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pwResult == NULL)
			return	LMR_ERROR ;
		dcsncpy (pwResult, pwString, nStringLen) ;
		nResultLen	= nStringLen ;
	} else {
		pwResult	= NULL ;
		nResultLen	= 0 ;
	}
	pThis->vSetRegConstString (LMREGARG_0, pwResult, nResultLen) ;
	if (! pThis->bCall (LM_bSkkInsertStr, LM_bSkkKanaCleanup_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKanaCleanup_2 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pBuffer->vSkkClearSkkKanaStartPoint () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-insert-str
 */
/*
(defun skk-insert-str (str)
  "STR ��}������B�K�v�ł���� `self-insert-after-hook' ���R�[������B
`overwrite-mode' �ł���΁A�K�؂ɏ㏑�����s���B"
  (insert-and-inherit str)
  (if (eq skk-henkan-mode 'on)
      ;;
      (when (and skk-auto-start-henkan
				 (not skk-okurigana))
		(skk-auto-start-henkan str))
    ;;
    (when (and (boundp 'self-insert-after-hook)
		       self-insert-after-hook)
      (funcall self-insert-after-hook
		       (- (point) (length str))
		       (point)))
    (when overwrite-mode
      (skk-del-char-with-pad (skk-ovwrt-len (string-width str)))))
  ;; SKK 9.6 �ł͂��̃^�C�~���O�� fill ���s���Ă������ASKK 10 �ł͍s���Ă�
  ;; �Ȃ������B
  (when (and skk-j-mode
		     (not skk-henkan-mode))
    (skk-do-auto-fill)))
		*/
int
CImeDoc::LM_bSkkInsertStr (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR				pwString ;
	int					nStringLen ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegConstString (LMREGARG_0, &pwString, &nStringLen)) {
		pwString	= NULL ;
		nStringLen	= 0 ;
	}
	pBuffer->bInsertAndInherit (pwString, nStringLen) ;
	if (pBuffer->bSkkGetSkkHenkanMode () == LON) {
		if (CImeConfig::bSkkAutoStartHenkanp (pThis->m_pConfig) && ! pBuffer->bSkkGetSkkOkurigana ()) {
			pThis->vJump (LM_bSkkAutoStartHenkan) ;
			return	LMR_CONTINUE ;
		}
	} else {
		/* self-insert-after-hook �̎����͂Ȃ��B*/
		/* overwrite-mode �̎������Ȃ��B*/
	}
	/* skk-do-auto-fill �� editor ���̋@�\�ł���Ǝv���̂Ŏ����͂Ȃ��B*/
	return	LMR_RETURN ;
}

/*================================================================ skk-auto-start-henkan
 */
int
CImeDoc::LM_bSkkAutoStartHenkan (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR				pwString ;
	int					nStringLen ;
	CTMarker*		pmkMark ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1))
		return	LMR_ERROR ;

	/*	skk-save-point ���������Ă���̂�Y��Ă���I
	 */
	pmkMark	= pBuffer->pMakeMarker (TRUE) ;
	if (pmkMark == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pmkMark->bSetPosition (pBuffer->pGetPointMarker ()) ;
	pThis->vSetRegPointer (LMREG_0, pmkMark) ;

	if (! pThis->bGetRegConstString (LMREGARG_0, &pwString, &nStringLen)) {
		pwString	= NULL ;
		nStringLen	= 0 ;
	}
	if (CImeConfig::bSkkAutoStartHenkanKeywordp (pThis->m_pConfig, pwString, nStringLen)) {
		if (! pBuffer->bBackwardChar (1)) {
			pThis->vSetSignalError () ;
			pThis->vJump (LM_bSkkAutoStartHenkan_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (pBuffer->iSkkGetSkkHenkanStartPoint () >= 0 &&
			pBuffer->iGetPoint () > pBuffer->iSkkGetSkkHenkanStartPoint ()) {
			LPCDSTR		pwCurPrefix ;
			LPDSTR		pwSkkPrefix ;
			int			nCurPrefixLen ;

			/* let skk-prefix "" �� emulation�Bskk-prefix ���ꎞ�I�ɑޔ�����B*/
			pwCurPrefix	= pBuffer->pSkkGetSkkPrefix (&nCurPrefixLen) ;
			if (nCurPrefixLen > 0) {
				pwSkkPrefix	= (LPDSTR) pThis->pAlloca (nCurPrefixLen * sizeof (DCHAR), __alignof (DCHAR)) ;
				if (pwSkkPrefix == NULL)
					return	LMR_ERROR ;
				dcsncpy (pwSkkPrefix, pwCurPrefix, nCurPrefixLen) ;
			} else {
				pwSkkPrefix	= NULL ;
			}
			if (! pThis->bPushReg (LMREG_1))
				return	LMR_ERROR ;
			pThis->vSetRegConstString (LMREG_1, pwSkkPrefix, nCurPrefixLen) ;

			pBuffer->vSkkSetSkkPrefix (NULL, 0) ;
			pThis->vSetRegNil (LMREGARG_0) ;
			if (! pThis->bCall (LM_bSkkStartHenkan, LM_bSkkAutoStartHenkan_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	pThis->vJump (LM_bSkkAutoStartHenkan_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkAutoStartHenkan_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR		pwSkkPrefix ;
	int			nSkkPrefix ;

	if (pThis->bSignalp ()) 
		goto	exit_func ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}
	/* skk-prefix �̕��A�B*/
	if (! pThis->bGetRegConstString (LMREG_1, &pwSkkPrefix, &nSkkPrefix)) {
		pwSkkPrefix	= NULL ;
		nSkkPrefix	= 0 ;
	}
	pBuffer->vSkkSetSkkPrefix (pwSkkPrefix, nSkkPrefix) ;

exit_func:
	pThis->vJump (LM_bSkkAutoStartHenkan_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkAutoStartHenkan_Exit (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;

	/*	�J�[�\���}�[�J�̈ʒu�����B
	 */
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		CTMarker*	pmkMark ;

		/*	�ۑ����Ă������}�[�J�Ƀ|�C���g�����킹��B
		 */
		if (pThis->bGetRegPointer (LMREG_0, (void**)&pmkMark) && pmkMark != NULL && pmkMark->bIsValidp ()) {
			CTMarker*	pmkPoint	= pBuffer->pGetPointMarker () ;
			if (pmkPoint != NULL)
				pmkPoint->bSetPosition (pmkMark) ;
			pBuffer->bDeleteMarker (pmkMark) ;
		}
	}
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-change-marker
 */
int
CImeDoc::LM_bSkkChangeMarker (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	CTMarker*	pmkHenkanStartPoint ;
	CTMarker*	pmkPoint ;
	int			nPosition ;

	if (pThis->bSignalp ()) {
		return	LMR_RETURN ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pmkHenkanStartPoint	= pBuffer->pSkkGetSkkHenkanStartPointMarker () ;
	if (pmkHenkanStartPoint == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	nPosition	= pmkHenkanStartPoint->iGetPosition () - 1 ;
	if (nPosition < 0) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pBuffer->iGetCharAt (nPosition) != L'��') {
		pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkChangeMarker_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	pmkPoint	= pBuffer->pGetPointMarker () ;
	if (pmkPoint == NULL) 
		return	LMR_ERROR ;
	pmkPoint->bSetPosition (pmkHenkanStartPoint) ;
	pmkPoint->bBackward (1) ;
	pBuffer->bInsertAndInherit (L"��", 1) ;
	pBuffer->bDeleteRegion (pmkPoint->iGetPosition (), pmkPoint->iGetPosition () + 1) ;
	pBuffer->vSkkSetSkkHenkanMode (LACTIVE) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkChangeMarker_1 (
	CImeDoc*		pThis)
{
	/* (skk-error "It seems that you have delete ��") */
	pThis->vSetSignalError () ;
	return	LMR_RETURN ;
}

/*================================================================ skk-purge-from-jisyo
 */
/*
;;; jisyo related functions
(defun skk-purge-from-jisyo (&optional arg)
  "�����[�h�Ō��݂̌��������o�b�t�@�����������B"
  (interactive "*P")
  (skk-with-point-move
   (cond
    ((not (eq skk-henkan-mode 'active))
     (skk-emulate-original-map arg))
    ((and (eq skk-henkan-mode 'active)
		  (not (string= skk-henkan-key ""))
		  (yes-or-no-p
		   (format
		    (if skk-japanese-message-and-error
				"%s /%s/%s����������폜���܂��B�ǂ��ł����H"
		      "Really purge \"%s /%s/%s\"?")
		    skk-henkan-key
		    (skk-get-current-candidate)
		    (cond
		     ((not (and skk-henkan-okurigana
						(or skk-henkan-okuri-strictly
						    skk-henkan-strict-okuri-precedence)))
		      " ")
		     (skk-japanese-message-and-error
		      (format " (���艼��: %s) " skk-henkan-okurigana))
		     (t
		      (format " (okurigana: %s) " skk-henkan-okurigana))))))
     ;; skk-henkan-start-point ���� point �܂ō폜���Ă��܂��Ă��A�ϊ�����
     ;; �� (�J�[�\���𓮂������ƂȂ�) skk-purge-from-jisyo ���ĂׂΖ��Ȃ�
     ;; ���A�J�[�\�����Ⴄ�ꏊ�ֈړ����Ă����ꍇ�́A�폜���ׂ��łȂ����̂�
     ;; �ō폜���Ă��܂��\��������B�����ŁA���艼��������΂��̒�������
     ;; �߂� end �����߁A����̕ϊ��Ɋ֘A�����������𐳊m�ɐ؂���悤��
     ;; ����B
     (let ((end (if skk-henkan-okurigana
				    (+ (length skk-henkan-okurigana)
				       skk-henkan-end-point)
				  skk-henkan-end-point))
		   (word (skk-get-current-candidate)))
       (skk-update-jisyo word 'purge)
       ;; Emacs 19.28 ���� Overlay �������Ă����Ȃ��ƁA���� insert �����
       ;; skk-henkan-key �ɉ��̂� Overlay ���������Ă��܂��B
       (when skk-use-face
		 (skk-henkan-face-off))
       (delete-region skk-henkan-start-point end)
       (skk-change-marker-to-white)
       (skk-kakutei)))))
  nil) */

int
CImeDoc::LM_bSkkPurgeFromJisyo (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pThis->bPushReg (LMREG_0) ||
		! pThis->bPushReg (LMREG_1) ||
		! pThis->bPushReg (LMREG_2) ||
		! pThis->bPushReg (LMREG_3))
		return	LMR_ERROR ;

	if (pBuffer->bSkkGetSkkHenkanMode () != LACTIVE) {
		if (! pThis->bCall (LM_bSkkEmulateOriginalMap, LM_bSkkPurgeFromJisyo_Exit))
			return	LMR_ERROR ;
	} else {
		CTSearchSession*	pSession ;

		pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
		if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE && pBuffer->iSkkGetSkkHenkanKeyLength () > 0) {
			LPDSTR	pwText ;
			DCHAR	bufOkurigana [128] ;
			LPCDSTR	pwCandidate ;
			LPCDSTR	pwHenkanKey ;
			int		n, iHenkanKeyLen ;

			pwCandidate	= (pSession != NULL)? pSession->pGetCandidate () : NULL ;
			if (pwCandidate == NULL) {
				pThis->vSetSignalError () ;
				return	LMR_RETURN ;
			}

#define	TEMP_TEXTBUFSIZE	384
			pwText	= (LPDSTR) pThis->pAlloca (sizeof (DCHAR) * TEMP_TEXTBUFSIZE, __alignof (DCHAR)) ;
			if (pwText == NULL)
				return	LMR_ERROR ;
			pThis->vSetRegString (LMREG_0, pwText, TEMP_TEXTBUFSIZE) ;

			if (! (pBuffer->bSkkGetSkkOkurigana () && (CImeConfig::bSkkHenkanOkuriStrictlyp (pThis->m_pConfig) || CImeConfig::bSkkHenkanStrictOkuriPrecedencep (pThis->m_pConfig)))) {
				bufOkurigana [0]	= L' ' ;
				bufOkurigana [1]	= L'\0' ;
			} else {
				LPDSTR	pwDest, pwDestEnd ;
				LPCDSTR	pwHenkanOkurigana ;
				int		iHenkanOkuriganaLen ;

				pwDest		= bufOkurigana ;
				pwDestEnd	= bufOkurigana + MYARRAYSIZE (bufOkurigana) - 1 ;
				vCopyStringW (&pwDest, pwDestEnd, L" (���艼��: ") ;
				pwHenkanOkurigana	= pBuffer->pSkkGetSkkHenkanOkurigana (&iHenkanOkuriganaLen) ;
				vCopyStringN (&pwDest, pwDestEnd, pwHenkanOkurigana, iHenkanOkuriganaLen) ;
				vCopyStringW (&pwDest, pwDestEnd, L") ") ;
				*pwDest		= L'\0' ;
			}

			pwHenkanKey	= pBuffer->pSkkGetSkkHenkanKey (&iHenkanKeyLen) ;
			n	= MIN (TEMP_TEXTBUFSIZE - 1, iHenkanKeyLen) ;
			dcsncpy (pwText, pwHenkanKey, n) ;

//			wnsprintfW (pwText + n, TEMP_TEXTBUFSIZE - n - 1, L" /%s/%s����������폜���܂��B��낵���ł����H", pwCandidate, bufOkurigana) ;
//			pwText [TEMP_TEXTBUFSIZE - 1]	= L'\0' ;
			{
				DCHAR*	pwDest ;
				DCHAR*	pwDestEnd ;
				pwDest		= pwText + n ;
				pwDestEnd	= pwText + TEMP_TEXTBUFSIZE - 1 ;
				vCopyStringW (&pwDest, pwDestEnd, L"/") ;
				vCopyString  (&pwDest, pwDestEnd, pwCandidate) ;
				vCopyStringW (&pwDest, pwDestEnd, L"/") ;
				vCopyString  (&pwDest, pwDestEnd, bufOkurigana) ;
				vCopyStringW (&pwDest, pwDestEnd, L"����������폜���܂��B��낵���ł����H") ;
				*pwDest		= L'\0' ;
			}
#undef	TEMP_TEXTBUFSIZE

			pThis->vSetRegConstString (LMREGARG_0, pwText, dcslen (pwText)) ;
			/*	yes-or-no ���Ăяo���B
			 */
			if (! pThis->bCall (LM_bYesOrNop, LM_bSkkPurgeFromJisyo_1))
				return	LMR_ERROR ;
		} else {
			pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		}
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkPurgeFromJisyo_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	BOOL		bRetval ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegBool (LMREGARG_RETVAL, &bRetval)) {
		bRetval	= FALSE ;
	}
	if (bRetval) {
		CTSearchSession*	pSession ;
		LPCDSTR				pwWord ;
		int					nWordLen ;

		/*	skk-henkan-okurigana �̏��� skk-update-jisyo �̌���c���Ă�����̂Ɖ��肵��
		 *	�����ł͐����Ȃ��B
		 */
		pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
		if (pSession == NULL) {
			pThis->vSetSignalError () ;
			pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
			return	LMR_CONTINUE ;
		}
		pwWord		= pSession->pGetCandidate () ;
		nWordLen	= (pwWord != NULL)? dcslen (pwWord) : 0 ;

		pThis->vSetRegConstString (LMREGARG_0, pwWord, nWordLen) ;
		pThis->vSetRegBool        (LMREGARG_1, TRUE) ;
		if (! pThis->bCall (LM_bSkkUpdateJisyo, LM_bSkkPurgeFromJisyo_2))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else {
		pThis->vJump (LM_bSkkPurgeFromJisyo_2) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkPurgeFromJisyo_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*			pBuffer ;
	CTSearchSession*	pSession ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (pSession == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pSession->bNumericp () || pSession->pGetReferCandidate () == NULL) {
		pThis->vJump (LM_bSkkPurgeFromJisyo_5) ;
		return	LMR_CONTINUE ;
	}
	/*	������ #4 �ϊ��������ꍇ�ɂ� #4 �Ή��̍폜���q�˂�K�v�����邪�c
	 */
	pThis->vSetRegInteger (LMREG_1, 0) ;
	pThis->vJump (LM_bSkkPurgeFromJisyo_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkPurgeFromJisyo_3 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	CTSearchSession*	pSession ;
	CTS4Candidate*	pS4Node ;
	int				nTextSize, num, i ;
	LPDSTR			pwText, pwDest, pwDestEnd ;
	LPCDSTR			pwNumKeyword, pwNumResult ;
	int				nNumKeywordLen, nNumResultLen ;

	pwNumKeyword	= NULL ;
	nNumKeywordLen	= 0 ;
	pwNumResult		= NULL ;
	nNumResultLen	= 0 ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! pThis->bGetRegString (LMREG_0, &pwText, &nTextSize) || 
		! pThis->bGetRegInteger (LMREG_1, &num)) {
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (pSession == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	/* #4 �̃`�F�b�N���s���B*/
	pS4Node	= pSession->pGetNumericLink () ;
	for (i = 0 ; i < num && pS4Node != NULL ; i ++) {
		pS4Node	= pSession->pGetNextNumericLink (pS4Node) ;
	}
	while (pS4Node != NULL) {
		/*	"[#4�폜] %s /%s/ ����������폜���܂����H"
		 *	�����c�d�����������ꍇ�ɂ͂����Ƃ����������B
		 */
		pwNumKeyword	= pSession->pGetNumericKeyword (pS4Node, &nNumKeywordLen) ;
		pwNumResult		= pSession->pGetNumericResult  (pS4Node, &nNumResultLen) ;
		if (pwNumKeyword != NULL && nNumKeywordLen > 0 && pwNumResult != NULL && nNumResultLen > 0)
			break ;
		pS4Node	= pSession->pGetNextNumericLink (pS4Node) ;
		num	++ ;
	}
	if (pS4Node == NULL) {
		/* �I���B*/
		pThis->vJump (LM_bSkkPurgeFromJisyo_5) ;
		return	LMR_CONTINUE ;
	}

	pThis->vSetRegInteger     (LMREG_1, num) ;
	pThis->vSetRegConstString (LMREG_2, pwNumKeyword, nNumKeywordLen) ;
	pThis->vSetRegConstString (LMREG_3, pwNumResult,  nNumResultLen) ;

	pwDest			= pwText ;
	pwDestEnd		= pwText + nTextSize ;
	vCopyStringW (&pwDest, pwDestEnd, L"[#4�폜] ") ;
	vCopyStringN (&pwDest, pwDestEnd, pwNumKeyword, nNumKeywordLen) ;
	vCopyStringW (&pwDest, pwDestEnd, L" /") ;
	vCopyStringN (&pwDest, pwDestEnd, pwNumResult, nNumResultLen) ;
	vCopyStringW (&pwDest, pwDestEnd, L"/ ����������폜���܂��B��낵���ł����H") ;
	pThis->vSetRegConstString (LMREGARG_0, pwText, pwDest - pwText) ;
	if (! pThis->bCall (LM_bYesOrNop, LM_bSkkPurgeFromJisyo_4))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkPurgeFromJisyo_4 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	LPDSTR			pwText ;
	LPCDSTR			pwNumKeyword, pwNumResult ;
	int				nNumKeywordLen, nNumResultLen, num, nTextSize ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	/*	�ϊ��L�[���ꎞ�I�ɕۑ�����B*/
	if (! pThis->bGetRegString (LMREG_0, &pwText, &nTextSize) || 
		! pThis->bGetRegInteger (LMREG_1, &num) ||
		! pThis->bGetRegConstString (LMREG_2, &pwNumKeyword, &nNumKeywordLen) ||
		! pThis->bGetRegConstString (LMREG_3, &pwNumResult,  &nNumResultLen)) {
		/* error */
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	/*  skk-update-jisyo ���Ăяo���B
	 *	�͕s�\�B
	 *	���R�́cHenkanKey �� numeric-convertion ����Ă��܂��� # �ɗ��Ƃ���Ă��܂�����B
	 */
	CTPurgeSession::bUpdate (pwNumKeyword, nNumKeywordLen, pwNumResult, nNumResultLen, NULL, 0, FALSE) ;

	/*  ���� S4Node ���w���B*/
	num	++ ;
	pThis->vSetRegInteger (LMREG_1, num) ;

	pThis->vJump (LM_bSkkPurgeFromJisyo_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkPurgeFromJisyo_5 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	int					nStart, nEnd ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	nStart	= pBuffer->iSkkGetSkkHenkanStartPoint () ;
	nEnd	= pBuffer->iSkkGetSkkHenkanEndPoint () ;
	if (pBuffer->iSkkGetSkkHenkanOkuriganaLength () > 0) {
		nEnd	+= pBuffer->iSkkGetSkkHenkanOkuriganaLength () ;
	}
	pBuffer->bDeleteRegion (nStart, nEnd) ;
	pBuffer->bSkkChangeMarkerToWhite () ;

	pThis->vSetRegNil (LMREGARG_0) ;
	if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkPurgeFromJisyo_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkPurgeFromJisyo_Exit (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;

	pThis->vPopReg (LMREG_3) ;
	pThis->vPopReg (LMREG_2) ;
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/* skk-point-move �̌��ʁB*/
	pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-update-jisyo
 */
/*	LMARG_0:		pWord, nWordLen (STRING)
 *	LMARG_1:		bPurge (BOOL)
 */
int
CImeDoc::LM_bSkkUpdateJisyo (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pMidashi ;
	int		nMidashiLen ;
	LPCDSTR	pWord ;
	int		nWordLen ;
	BOOL	bPurge ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	if (! pThis->bGetRegConstString (LMREGARG_0, &pWord, &nWordLen)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	/* bPurge ���͏ȗ��\�B*/
	if (! pThis->bGetRegBool (LMREGARG_1, &bPurge)) {
		bPurge	= FALSE ;
	}

	if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1))
		return	LMR_ERROR ;

	/*	���ꂾ�Ɩ{���ɐ��l�ϊ������s���Ă��邩���炩����Ȃ��悤�Ɏv����ȁc�B�I���W�i���͓o�^���悤�Ƃ��Ă���
	 */
	if (CImeConfig::bSkkNumericConversionp (pThis->m_pConfig) && (bStringLispFormatp (pWord, nWordLen) || bStringNumericWordp (pWord, nWordLen))) {
		LPCDSTR		pwSkkHenkanKey ;
		int			iSkkHenkanKeyLen ;
		LPDSTR		pwString ;

		pwString	= (LPDSTR) pThis->pAlloca (MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pwString == NULL) 
			return	LMR_ERROR ;
		pwSkkHenkanKey	= pBuffer->pSkkGetSkkHenkanKey (&iSkkHenkanKeyLen) ;
		nMidashiLen	= iSkkNumComputeHenkanKey (pwSkkHenkanKey, iSkkHenkanKeyLen, pwString, MAXCOMPLEN, NULL, 0, CImeConfig::bSkkNumConvertFloatp (pThis->m_pConfig)) ;
		pMidashi	= pwString ;
	} else {
		pMidashi	= pBuffer->pSkkGetSkkHenkanKey (&nMidashiLen) ;
	}
	if (pBuffer->iSkkGetSkkOkuriIndexMin () > -1) {
		LPDSTR	pNewWord ;
		pNewWord	= (LPDSTR) pThis->pAlloca (MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pNewWord == NULL)
			LMR_ERROR ;
		pThis->vSetRegString (LMREG_0, pNewWord, MAXCOMPLEN) ;
		pThis->vSetRegBool   (LMREG_1, bPurge) ;

		pThis->vSetRegConstString (LMREGARG_0, pWord, nWordLen) ;
		pThis->vSetRegString (LMREGARG_1, pNewWord, MAXCOMPLEN) ;
		if (! pThis->bCall (LM_bSkkRemoveCommon, LM_bSkkUpdateJisyo_1))
			return	LMR_ERROR ;
	} else {
		pThis->vSetRegConstString (LMREGARG_0, pWord,    nWordLen) ;
		pThis->vSetRegBool        (LMREGARG_1, bPurge) ;
		pThis->vSetRegConstString (LMREGARG_2, pMidashi, nMidashiLen) ;
		pThis->vJump (LM_bSkkUpdateJisyo_2) ;
	}
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkUpdateJisyo_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	LPDSTR		pWord ;
	int			nMaxWordSize, nWordLen ;
	LPCDSTR		pMidashi ;
	int			nMidashiLen ;
	BOOL		bPurge ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegInteger (LMREGARG_RETVAL, &nWordLen)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegString (LMREG_0, &pWord, &nMaxWordSize)) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegBool (LMREG_1, &bPurge))
		bPurge	= FALSE ;

	pMidashi	= pBuffer->pSkkGetSkkHenkanKey (&nMidashiLen) ;
	pThis->vSetRegConstString (LMREGARG_0, pWord, nWordLen) ;
	pThis->vSetRegBool        (LMREGARG_1, bPurge) ;
	pThis->vSetRegConstString (LMREGARG_2, pMidashi, nMidashiLen) ;
	pThis->vJump (LM_bSkkUpdateJisyo_2) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkUpdateJisyo_2 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	LPCDSTR	pWord ;
	LPCDSTR	pMidashi, pOkurigana ;
	int		nWordLen, nMidashiLen, nOkuriganaLen ;
	BOOL	bPurge, bOkuri, bRetval ;

	if (pThis->bSignalp ())
		goto	exit_func ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}
	if (! pThis->bGetRegConstString (LMREGARG_0, &pWord, &nWordLen)) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}
	if (! pThis->bGetRegBool (LMREGARG_1, &bPurge)) 
		bPurge	= FALSE ;
	if (! pThis->bGetRegConstString (LMREGARG_2, &pMidashi, &nMidashiLen)) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}
	if (pBuffer->iSkkGetSkkHenkanOkuriganaLength () > 0) {
		pOkurigana		= pBuffer->pSkkGetSkkHenkanOkurigana (&nOkuriganaLen) ;
	} else if (pBuffer->iSkkGetSkkOkuriCharLength () > 0) {
		pOkurigana		= pBuffer->pSkkGetSkkOkuriChar (&nOkuriganaLen) ;
	} else {
		pOkurigana		= NULL ;
		nOkuriganaLen	= 0 ;
	}
	/* okurigana, midashi, word, purge/record �̃y�A�œo�^����B*/
	bOkuri	= FALSE ;
	if (nOkuriganaLen > 0) {
		/*	skk-process-okuri-early �������ꍇ�ɁA���ۂ̑��艼���͕�����Ȃ��B
		 *	������A���蕶���͖����ɂ���B
		 */
		if (CImeConfig::bSkkProcessOkuriEarlyp (pThis->m_pConfig)) {
			const DCHAR	bufTemp []	= { 0 } ;
			pOkurigana		= bufTemp ;
			nOkuriganaLen	= 0 ;
		}
		bOkuri	= TRUE ;
	} else {
		LPCDSTR	pwSkkHenkanKey ;
		int		iSkkHenkanKeyLen ;
		/*	skk-process-okuri-earlyp �̎��̑���ϊ����������ǂ����̔���͂���ő��v���낤���H
		 *	�������B
		 */
		pwSkkHenkanKey	= pBuffer->pSkkGetSkkHenkanKey (&iSkkHenkanKeyLen) ;
		if (CImeConfig::bSkkProcessOkuriEarlyp (pThis->m_pConfig) && 
			pBuffer->bJModep () && 
			iSkkHenkanKeyLen > 1 && 
			(CImeConfig::bSkkSetHenkanPointKeyp (pThis->m_pConfig, todupper (pwSkkHenkanKey [iSkkHenkanKeyLen - 1])) ||
			CImeConfig::bSkkSetHenkanPointKeyp (pThis->m_pConfig, todlower (pwSkkHenkanKey [iSkkHenkanKeyLen - 1])))) {
			pOkurigana		= NULL ;
			nOkuriganaLen	= 0 ;
			bOkuri			= TRUE ;
		}
	}
	if (! bPurge) {
		bRetval	= CTRecordSession::bUpdate (pMidashi, nMidashiLen, pWord, nWordLen, pOkurigana, nOkuriganaLen, bOkuri) ;
	} else {
		bRetval	= CTPurgeSession::bUpdate (pMidashi, nMidashiLen, pWord, nWordLen, pOkurigana, nOkuriganaLen, bOkuri) ;
	}
	if (bRetval) {
		/* ���̌��o���� Word �Œ��O�� kakutei-history �Ƃ��ċL������B*/
		if (! bOkuri) 
			pBuffer->bSkkUpdateKakuteiHistory (pMidashi, nMidashiLen, pWord, nWordLen) ;
	}
exit_func:
	pThis->vJump (LM_bSkkUpdateJisyo_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkUpdateJisyo_Exit (
	CImeDoc*		pThis)
{
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-remove-common
 */

/*	�Ԃ�l: LMREGARG_RETVAL �� WordResult �� length
 */
int
CImeDoc::LM_bSkkRemoveCommon (
	CImeDoc*		pThis)
{
	CImeBuffer*		pBuffer ;
	LPCDSTR		pWord ;
	int			nWordLen ;
	LPDSTR		pwWordResult ;
	int			nWordResultSize ;
	LPCDSTR		pMidashi ;
	int			nMidashiLen, nNewWordLen ;

	nNewWordLen	= 0 ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pThis->bGetRegConstString (LMREGARG_0, &pWord, &nWordLen) ||
		! pThis->bGetRegString      (LMREGARG_1, &pwWordResult, &nWordResultSize)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if ((pBuffer->pSkkGetSkkCurrentSearchProgSession () != NULL && pBuffer->pSkkGetSkkCurrentSearchProgSession ()->bNumericp ()) ||
		pBuffer->bAbbrevModep () ||
		! (pBuffer->iSkkGetSkkHenkanInMinibuffFlag () ||
		   (pBuffer->iSkkGetSkkOkuriIndexMin ()  <= pBuffer->iSkkGetSkkHenkanCount () && 
		    pBuffer->iSkkGetSkkHenkanCount ()    <= pBuffer->iSkkGetSkkOkuriIndexMax ()))) {
		pThis->vSetRegInteger (LMREGARG_RETVAL, 0) ;
		return	LMR_RETURN ;
	}

	pMidashi	= pBuffer->pSkkGetSkkHenkanKey (&nMidashiLen) ;
	if (nMidashiLen >= 2 && nWordLen >= 2) {
		int		nMidashiTail, nWordTail ;

		if (bSkkAsciiCharp (pMidashi [nMidashiLen - 1]) && pMidashi [nMidashiLen - 1] == pWord [nWordLen - 1]) {
			nMidashiLen	-- ;
			nWordLen	-- ;
		}
		nMidashiTail	= pMidashi [nMidashiLen - 1] ;
		nWordTail		= pWord [nWordLen - 1] ;
		if (nMidashiTail == nWordTail && ((L'��' <= nMidashiTail && nMidashiTail <= L'��') || nMidashiTail == L'�A' || nMidashiTail == L'�B' || nMidashiTail == L'�C' || nMidashiTail == L'�D')) {
			int		nPos, nPos2, nChar ;

			nPos	= nWordLen - 1 ;
			while (nPos > 0) {
				nChar	= pWord [nPos - 1] ;
				if (bCJKKanjip (nChar)) { /* unicode �Ŋ������ǂ���������āc�ǂ����邩�B*/
					break ;
				}
				nPos	-- ;
			}
			nPos2	= nMidashiLen - (nWordLen - nPos) ;

			if (nMidashiLen == nWordLen && memcmp (pMidashi + nPos2, pWord + nPos, sizeof (DCHAR) * nMidashiLen) == 0) {
				DCHAR	bufHenkanOkurigana	[2] ;
				DCHAR	bufNewSkkHenkanKey	[MAXCOMPLEN] ;
				DCHAR	bufNewWord			[MAXCOMPLEN] ;
				DCHAR	bufNewSkkOkuriChar	[MAXCOMPLEN] ;
				int		nOkuriFirst, nHenkanOkuriganaLen, nNewSkkOkuriCharLen, nNewSkkHenkanKeyLen ;

				nOkuriFirst				= pWord [nPos] ;
				bufHenkanOkurigana [0]	= nOkuriFirst ;
				nHenkanOkuriganaLen		= 1 ;
				if (nOkuriFirst == L'��' && (nPos + 2) <= nWordLen) {
					bufHenkanOkurigana [1]	= pWord [nPos + 1] ;
					nHenkanOkuriganaLen	++ ;
				}

				nNewWordLen	= nPos ;
				if (nNewWordLen >= MYARRAYSIZE (bufNewWord)) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}
				dcsncpy (bufNewWord, pWord, nNewWordLen) ;
				bufNewWord [nNewWordLen]	= L'\0' ;
				nNewSkkOkuriCharLen	= pBuffer->iSkkOkuriganaPrefix (bufHenkanOkurigana, nHenkanOkuriganaLen, bufNewSkkOkuriChar, MYARRAYSIZE (bufNewSkkOkuriChar)) ;

				nNewSkkHenkanKeyLen	= nPos2 + nNewSkkOkuriCharLen ;
				if ((nPos2 + nNewSkkOkuriCharLen) >= MYARRAYSIZE (bufNewSkkHenkanKey)) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}
				dcsncpy (bufNewSkkHenkanKey,         pMidashi + 0,       nPos2) ;
				dcsncpy (bufNewSkkHenkanKey + nPos2, bufNewSkkOkuriChar, nNewSkkOkuriCharLen) ;
				bufNewSkkHenkanKey [nNewSkkHenkanKeyLen]	= L'\0' ;

				if (nNewWordLen > nWordResultSize) {
					pThis->vSetSignalError () ;
					return	LMR_RETURN ;
				}

				if (! pBuffer->iSkkGetSkkHenkanInMinibuffFlag ()) {
					pBuffer->vSkkSetSkkHenkanKey (bufNewSkkHenkanKey, nNewSkkHenkanKeyLen) ;
					pBuffer->vSkkSetSkkOkuriChar (bufNewSkkOkuriChar, nNewSkkOkuriCharLen) ;

					dcsncpy (pwWordResult, bufNewWord, nNewWordLen) ;
				} else {
					DCHAR	bufText [256] ;
					int		nText ;
					LPDSTR	pwText, pwNewWord, pwNewSkkHenkanKey, pwNewSkkOkuriChar ;

					/* Shall I register this as okuri-ari word: %s /%s/ ? */
//					nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText), L"Shall I register this as okuri-ari word: %s /%s/ ? ", bufNewSkkHenkanKey, bufNewWord) ;
					{
						DCHAR*	pwDest		= bufText ;
						DCHAR*	pwDestEnd	= bufText + ARRAYSIZE (bufText) ;

						vCopyStringW (&pwDest, pwDestEnd, L"Shall I register this as okuri-ari word: ") ;
						vCopyString  (&pwDest, pwDestEnd, bufNewSkkHenkanKey) ;
						vCopyStringW (&pwDest, pwDestEnd, L" /") ;
						vCopyString  (&pwDest, pwDestEnd, bufNewWord) ;
						vCopyStringW (&pwDest, pwDestEnd, L"/ ? ") ;
						nText	= pwDest - bufText ;
					}
					if (! pThis->bPushReg (LMREG_0) || ! pThis->bPushReg (LMREG_1) ||
						! pThis->bPushReg (LMREG_2) || ! pThis->bPushReg (LMREG_3))
						return	LMR_ERROR ;

#define	SAFE_ALLOCA_STRING(pDest,pSrc,nSize,nAlign)	\
	if ((nSize) > 0) { \
		(pDest) = (LPDSTR)pThis->pAlloca ((nSize), (nAlign)) ; \
		if ((pDest) == NULL) \
			return LMR_ERROR ; \
		memcpy ((pDest), (pSrc), (nSize)) ; \
	} else { \
		(pDest) = NULL ; \
	}
					SAFE_ALLOCA_STRING (pwNewWord,			bufNewWord,			nNewWordLen				* sizeof (DCHAR), __alignof (DCHAR)) ;
					SAFE_ALLOCA_STRING (pwNewSkkHenkanKey,	bufNewSkkHenkanKey,	nNewSkkHenkanKeyLen		* sizeof (DCHAR), __alignof (DCHAR)) ;
					SAFE_ALLOCA_STRING (pwNewSkkOkuriChar,	bufNewSkkOkuriChar,	nNewSkkOkuriCharLen		* sizeof (DCHAR), __alignof (DCHAR)) ;
					SAFE_ALLOCA_STRING (pwText,				bufText,			nText					* sizeof (DCHAR), __alignof (DCHAR)) ;
#undef	SAFE_ALLOCA_STRING
					pThis->vSetRegConstString (LMREG_0, pwNewWord,			nNewWordLen) ;
					pThis->vSetRegConstString (LMREG_1, pwNewSkkHenkanKey,	nNewSkkHenkanKeyLen) ;
					pThis->vSetRegConstString (LMREG_2, pwNewSkkOkuriChar,	nNewSkkOkuriCharLen) ;
					pThis->vSetRegString      (LMREG_3, pwWordResult,			nWordResultSize) ;
					pThis->vSetRegString (LMREGARG_0, pwText, nText) ;
					if (! pThis->bCall (LM_bYesOrNop, LM_bSkkRemoveCommon_1))
						return	LMR_ERROR ;
					return	LMR_CONTINUE ;
				}
			}
		}
	}
	pThis->vSetRegInteger (LMREGARG_RETVAL, nNewWordLen) ;
	return	LMR_RETURN ;
}

/*
					// yes-or-no-p �Ŏ��s������ skk-henkan-okurigana �� nil �� skk-okuri-char �� nil ���B
					if (! ImeDoc_bYesOrNop (pBuffer->m_pDoc, bufText, nText, &bRetval)) {
						return	FALSE ;
					}
					if (bRetval) {
						memcpy (pBuffer->m_bufSkkHenkanKey, bufNewSkkHenkanKey, sizeof (DCHAR) * nNewSkkHenkanKeyLen) ;
						pBuffer->m_nSkkHenkanKeyLen	= nNewSkkHenkanKeyLen ;
						memcpy (pBuffer->m_bufSkkOkuriChar, bufNewSkkOkuriChar, sizeof (DCHAR) * nNewSkkOkuriCharLen) ;
						pBuffer->m_nSkkOkuriCharLen	= nNewSkkOkuriCharLen ;

						memcpy (pwWordResult, bufNewWord, sizeof (DCHAR) * nNewWordLen) ;
					} else {
						pBuffer->m_nSkkHenkanOkuriganaLen	= 0 ;
						pBuffer->m_nSkkOkuriCharLen			= 0 ;
					}
					ImeDoc_vClearMessage (pBuffer->m_pDoc) ;
 */
int
CImeDoc::LM_bSkkRemoveCommon_1 (
	CImeDoc*		pThis)
{
	CImeBuffer*	pBuffer ;
	LPCDSTR	pNewSkkHenkanKey, pNewSkkOkuriChar, pNewWord ;
	int		nNewSkkHenkanKeyLen, nNewSkkOkuriCharLen, nNewWordLen ;
	LPDSTR	pwWordResult ;
	int		nWordResultSize ;
	BOOL	bYesOrNo ;

	if (pThis->bSignalp ())
		goto	exit_func ;
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}
	if (! pThis->bGetRegBool (LMREGARG_RETVAL, &bYesOrNo)) 
		goto	exit_func ;
	if (! pThis->bGetRegConstString (LMREG_0, &pNewWord, &nNewWordLen)) {
		pNewWord			= NULL ;
		nNewWordLen			= 0 ;
	}
	if (! pThis->bGetRegConstString (LMREG_1, &pNewSkkHenkanKey, &nNewSkkHenkanKeyLen)) {
		pNewSkkHenkanKey	= NULL ;
		nNewSkkHenkanKeyLen	= 0 ;
	}
	if (! pThis->bGetRegConstString (LMREG_2, &pNewSkkOkuriChar, &nNewSkkOkuriCharLen)) {
		pNewSkkOkuriChar	= NULL ;
		nNewSkkOkuriCharLen	= 0 ;
	}
	if (! pThis->bGetRegString (LMREG_3, &pwWordResult, &nWordResultSize)) {
		pwWordResult	= NULL ;
		nWordResultSize	= 0 ;
	}
	if (bYesOrNo) {
		pBuffer->vSkkSetSkkHenkanKey (pNewSkkHenkanKey, nNewSkkHenkanKeyLen) ;
		pBuffer->vSkkSetSkkOkuriChar (pNewSkkOkuriChar, nNewSkkOkuriCharLen) ;

		if (nNewWordLen > 0) {
			nNewWordLen	= MIN (nNewWordLen, nWordResultSize) ;
			if (nNewWordLen > 0 && pwWordResult != NULL)
				dcsncpy (pwWordResult, pNewWord, nNewWordLen) ;
		}
	} else {
		pBuffer->vSkkSetSkkHenkanOkurigana (NULL, 0) ;
		pBuffer->vSkkSetSkkOkuriChar (NULL, 0) ;
		nNewWordLen							= 0 ;
	}
	pThis->vClearMessage () ;
	pThis->vSetRegInteger (LMREGARG_RETVAL, nNewWordLen) ;

exit_func:
	pThis->vPopReg (LMREG_3) ;
	pThis->vPopReg (LMREG_2) ;
	pThis->vPopReg (LMREG_1) ;
	pThis->vPopReg (LMREG_0) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan-show-candidates
 */
/*	�����̓���͗ǂ��Ȃ��B���̂Ȃ���ꗗ��\������@�\�� Windows ���� interface �����邩��B
 *	�܂��A���͌�ł��킹��Ƃ������ƂŃX���[����B
 */

/*	�Ԃ�l: LMREGARG_RETVAL �ɑI���������̕�����
 *			LMREGARG_0	�ɗ^����ꂽ�o�b�t�@�ɑI���������(�̕�����)���R�s�[
 */
int
CImeDoc::LM_bSkkHenkanShowCandidates (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	int			nCandidateKey ;

	if (pThis->bSignalp ()) 
		return	LMR_RETURN ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iSkkGetSkkHenkanEndPoint ())) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (CImeConfig::pGetSkkHenkanShowCandidatesKeys (pThis->m_pConfig, &nCandidateKey) == NULL || nCandidateKey <= 0) {
		pThis->bSetMessage (L"Invalid skk-henkan-show-candiates-keys!") ;
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}

	pBuffer->vSkkSetSkkHenkanShowCandidatesMode (TRUE) ;

	if (! pThis->bPushReg (LMREG_1) || ! pThis->bPushReg (LMREG_2) ||
		! pThis->bPushReg (LMREG_3) || ! pThis->bPushReg (LMREG_4) ||
		! pThis->bPushReg (LMREG_5))
		return	LMR_ERROR ;

	pThis->vSetRegInteger	(LMREG_1, 0) ;			/* nLoop */
	pThis->vSetRegBool		(LMREG_2, FALSE) ;		/* bUpdateShow */
	pThis->vSetRegInteger	(LMREG_4, 0) ;			/* nShow */
	pThis->vSetRegInteger	(LMREG_5, nCandidateKey) ;
	pThis->vJump (LM_bSkkHenkanShowCandidates_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanShowCandidates_Exit (
	CImeDoc*			pThis)
{
	pThis->vPopReg (LMREG_5) ;
	pThis->vPopReg (LMREG_4) ;
	pThis->vPopReg (LMREG_3) ;
	pThis->vPopReg (LMREG_2) ;
	pThis->vPopReg (LMREG_1) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkHenkanShowCandidates_1 (
	CImeDoc*			pThis)
{
	CImeBuffer*			pBuffer ;
	CTSearchSession*	pSession ;
	int		nCandidateKey, nPrevCandidateKey, nLoop, nMaxShow ;
	DCHAR	buffer [512] ;
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pCandidateKey ;
#if defined (UNITTEST)
	BOOL	bSearchContinue ;
#endif
	int		nShow, nHenkanCount, iAnnotationType ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	if (! pThis->bGetRegInteger (LMREG_1, &nLoop))
		nLoop		= 0 ;
	if (! pThis->bGetRegInteger (LMREG_5, &nPrevCandidateKey)) 
		nPrevCandidateKey	= IMEDOC_NUMHENKANSHOWCANDIDATES ;

	pCandidateKey	= CImeConfig::pGetSkkHenkanShowCandidatesKeys (pThis->m_pConfig, &nCandidateKey) ;
	if (pCandidateKey == NULL || nCandidateKey <= 0 || nPrevCandidateKey != nCandidateKey) {
		pThis->bSetMessage (L"Invalid skk-henkan-show-candiates-keys!") ;
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	/*	nMaxShow �����W�X�g���̐ݒ�Ɉˑ�����Ƃ������Ƃ́A�\�����Ă���Œ��ɒ��g������������
	 *	�ςȏ�Ԃɗ��Ƃ����ނ��Ƃ��\��������Ȃ��B
	 *	������i���u����K�v�����邩���B
	 */
	nMaxShow		= (nCandidateKey < IMEDOC_MAXCANDPAGESIZE)? nCandidateKey : IMEDOC_MAXCANDPAGESIZE ;

	/* �P���7���\������Ηǂ������̂悤���B���G�ɏ������Ƃ͂Ȃ��B*/
	nHenkanCount	= pBuffer->iSkkGetSkkHenkanCount () + nLoop * nMaxShow ;
	pDest			= buffer ;
	pDestEnd		= buffer + MYARRAYSIZE (buffer) ;
	nShow			= 0 ;
	iAnnotationType	= CImeConfig::iGetSkkShowAnnotationType (pThis->m_pConfig) ;

	buffer [0]	= L'\0' ;
	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (pSession != NULL) {
#if defined (UNITTEST)
		LPCDSTR		pSrc ;
		int			nLeft ;
		DCHAR		buf [64], bufTemp [MAXCOMPLEN] ;
		struct IMETEXTATTRIBUTE		rMsgTextAttributes [IMEDOC_NUMHENKANSHOWCANDIDATES] ;
		struct IMETEXTATTRIBUTE*	pTextAttributes ;

		if (pSession->bNumericp ()) {
			CTLispSession::bSetNumberList (pSession->pGetNumericList ()) ;
		} else {
			CTLispSession::bSetNumberList (NULL) ;
		}
		pTextAttributes	= rMsgTextAttributes ;
		while (nShow < nMaxShow) {
			LPCDSTR		wstrNewWord ;
			int			nStartPos, nEndPos ;

			if (pDest < pDestEnd) 
				*pDest ++	= *pCandidateKey ++ ;
			if (pDest < pDestEnd)
				*pDest ++	= L':' ;

			/*	�����Ŏ��o���� Candidate �� List �ɂ� annotation ���t���Ă��邵�A
			 *	Lisp Function �̂܂܂������肷��B
			 */
			wstrNewWord		= pSession->pGetCandidate () ;
			if (wstrNewWord != NULL) {
				LPCDSTR		wstrNote ;
				int			nNewWordLen, nNoteLen ;

				nNewWordLen	= lstrlenW (wstrNewWord) ;
				wstrNote	= NULL ;
				nNoteLen	= 0 ;
				if (iAnnotationType != DISABLE_ANNOTATION) { 
					pSrc		= wstrNewWord + nNewWordLen - 1 ;
					while (pSrc >= wstrNewWord && *pSrc != L';')
						pSrc	-- ;
					if (pSrc >= wstrNewWord) {
						/*	Annotation �͖{���͋L�����Ă����āA���o����悤�ɂ��Ă����Ȃ���
						 *	�����Ȃ����c�B������ Buffer Property �̂悤�Ȍ`���ŕێ�����΂���
						 *	�̂��H buffer �͎g���Ă��Ȃ����B
						 */
						wstrNote		= pSrc + 1 ;
						nNoteLen		= nNewWordLen - (wstrNote - pSrc) ;
						nNewWordLen		= pSrc - wstrNewWord ;
					}
				}
				if (nNewWordLen > 1 && wstrNewWord [0] == L'(' && wstrNewWord [nNewWordLen - 1] == L')') {
					if (CTLispSession::bEval (wstrNewWord, nNewWordLen, bufTemp, MYARRAYSIZE (bufTemp) - 1)) {
						bufTemp [MYARRAYSIZE (bufTemp) - 1]	= L'0' ;
						wstrNewWord	= bufTemp ;
						nNewWordLen	= lstrlenW (bufTemp) ;
					}
				}
				pSrc		= wstrNewWord ;
				nStartPos	= pDest - buffer ;
				while (pDest < pDestEnd && *pSrc != L'\0') {
					*pDest ++	= *pSrc ++ ;
				}
				nEndPos		= pDest - buffer ;

				/* Annotation �̏����B*/
				if (iAnnotationType != SHOW_NO_ANNOTATION && wstrNote != NULL && nNoteLen > 0 && nStartPos < nEndPos) {
					if (nNoteLen > 1 && wstrNote [0] == L'(' && wstrNote [nNoteLen - 1] == L')') {
						if (CTLispSession::bEval (wstrNote, nNoteLen, bufTemp, MYARRAYSIZE (bufTemp) - 1)) {
							bufTemp [MYARRAYSIZE (bufTemp) - 1]	= L'0' ;
							wstrNote	= bufTemp ;
							nNoteLen	= lstrlenW (bufTemp) ;
						}
					}
					if (nNoteLen > 0 && wstrNote != NULL) {
						int		n	= (nNoteLen < MAX_LENGTH_ONE_ANNOTATION)? nNoteLen : MAX_LENGTH_ONE_ANNOTATION ;
						pTextAttributes->m_nStartPos	= nStartPos ;
						pTextAttributes->m_nEndPos		= nEndPos ;
						dcsncpy (pTextAttributes->m_wszWord, wstrNote, n) ;
						pTextAttributes->m_nWordLen		= n ;
						pTextAttributes	++ ;
					}
				}
			} else {
				/* ���̏ꍇ�͖�������ׂ����B*/
			}
			if (pDest < pDestEnd)
				*pDest ++	= L' ' ;
			nShow	++ ;
			if (! pSession->bNextCandidate ())
				break ;
		}
		nLeft	= pSession->iGetNumberOfCandidate (&bSearchContinue) - nHenkanCount - nShow ;
		wnsprintfW (buf, MYARRAYSIZE (buf) - 1, L"[�c�� %d%s]", nLeft, (bSearchContinue? L"+" : L"")) ;
		buf [MYARRAYSIZE (buf) - 1]	= L'\0' ;
		pSrc	= buf ;
		while (pDest < pDestEnd && *pSrc != L'\0') {
			*pDest ++	= *pSrc ++ ;
		}
		pThis->bSetMessageN (buffer, pDest - buffer) ;
		pThis->bSetMessageAttributes (rMsgTextAttributes, pTextAttributes - rMsgTextAttributes) ;
#else
		if (pSession->bNumericp ()) {
			CTLispSession::bSetNumberList (pSession->pGetNumericList ()) ;
		} else {
			CTLispSession::bSetNumberList (NULL) ;
		}
		if (! pBuffer->bInitializeHenkanCandidateList (nHenkanCount)) {
			/* fatal error */
			return	LMR_ERROR ;
		}
		/*
		 *	ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_UPDATE_CANDIDATES or IMEDOC_UPDATE_CANDIDATES) ;
		 *	���͍쐬�ƍX�V�������Ȃ̂ŁB
		 */
		pThis->vSetUpdateFlag (IMEDOC_UPDATE_CANDIDATELIST) ;
#endif
	} else {
		pThis->vClearMessage () ;	/* ����̓G���[�ł́H */
		pThis->vSetRegInteger (LMREGARG_RETVAL, -1) ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pThis->vSetRegInteger (LMREG_4, nShow) ;
	pThis->vJump (LM_bSkkHenkanShowCandidates_2) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanShowCandidates_2 (
	CImeDoc*			pThis)
{
	pThis->vSetRegBool (LMREG_2, FALSE) ;
	pThis->vJump (LM_bSkkHenkanShowCandidates_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanShowCandidates_3 (
	CImeDoc*			pThis)
{
	int			nLoop ;
	BOOL		bUpdateShow ;

	if (! pThis->bGetRegInteger (LMREG_1, &nLoop))
		nLoop	= 0 ;
	if (! pThis->bGetRegBool    (LMREG_2, &bUpdateShow))
		bUpdateShow	= FALSE ;
#if !defined (UNITTEST)
#else
	if (bUpdateShow) {
		pThis->vJump (LM_bSkkHenkanShowCandidates_1) ;
		return	LMR_CONTINUE ;
	}
#endif
	if (! pThis->bCall (LM_bNextCommandEvent, LM_bSkkHenkanShowCandidates_4))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanShowCandidates_4 (
	CImeDoc*			pThis)
{
	CImeBuffer*			pBuffer ;
	CTSearchSession*	pSession ;
	struct TMSG		ev ;
	int				n, nCH, nShow, nCandidateKey, nPrevCandidateKey, nLoop, nMaxShow ;
	LPCDSTR			pCandidateKey ;
	BOOL			bKeyChar, bUpdateShow ;

	if (! pThis->bGetRegMsg (LMREGARG_RETVAL, &ev)) {
		/* FALSE exit */
		pThis->vSetRegInteger (LMREGARG_RETVAL, -1) ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (pSession == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}

	/* �C�x���g���L�����N�^�[�ɕϊ�����B*/
	bKeyChar	= pThis->bEventToCharacter (&ev, &nCH) ;
	if (! bKeyChar) {
		/* original map �̎��s�́H */
//		pThis->vJump (LM_bSkkHenkanShowCandidates_3) ;
//		return	LMR_CONTINUE ;
		nCH	= -1 ;
	}

	if (! pThis->bGetRegInteger (LMREG_4, &nShow))
		nShow	= 0 ;
	if (! pThis->bGetRegInteger (LMREG_5, &nPrevCandidateKey)) 
		nPrevCandidateKey	= IMEDOC_NUMHENKANSHOWCANDIDATES ;

	/* ������ skk-key-num-alist �ƌ���ׂāA��₪�I�΂ꂽ�����`�F�b�N����B*/
	pCandidateKey	= CImeConfig::pGetSkkHenkanShowCandidatesKeys (pThis->m_pConfig, &nCandidateKey) ;
	if (pCandidateKey == NULL || nCandidateKey <= 0 || nCandidateKey != nPrevCandidateKey) {
		pThis->bSetMessage (L"Invalid skk-henkan-show-candiates-keys!") ;
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	nMaxShow		= (nCandidateKey < IMEDOC_MAXCANDPAGESIZE)? nCandidateKey : IMEDOC_MAXCANDPAGESIZE ;
	n				= 0 ;
	bUpdateShow		= FALSE ;

#if !defined (UNITTEST)
	/*	nShow �͍Čv�Z����Ȃ��̂ŁAMaxShow �ɌŒ肵�Ă��܂��B(!UNITETEST ���_)
	 */
	nShow			= nMaxShow ;
#endif

	while (n < nShow && n < nCandidateKey) {
		if (todlower (pCandidateKey [n]) == todlower (nCH)) {
			/* found */
			break ;
		}
		n	++ ;
	}
	if (! pThis->bGetRegInteger (LMREG_1, &nLoop))
		nLoop	= 0 ;
	if (n < nShow && n < nCandidateKey) {
		LPCDSTR	wstrNewWord ;

		/* ����I������B*/
#if !defined (UNITTEST)
		IMECANDIDATES*	pCandInfo	= NULL ;
		UINT*			puPageIndex ;
		UINT			uCandIndex, uCandStrIndex ;

		pCandInfo		= pThis->pGetCandidateInfo () ;
		if (pCandInfo == NULL)
			return	LMR_ERROR ;	/* error */
		if (pCandInfo->m_iCurrentPage < 0 || pCandInfo->m_iCurrentPage >= pCandInfo->m_vbufPageIndex.iGetUsage ())
			goto	exit_func ;
		puPageIndex		= pCandInfo->m_vbufPageIndex.pGetBuffer () + pCandInfo->m_iCurrentPage ;
		uCandIndex		= *puPageIndex + n ;
		if (uCandIndex >= pCandInfo->m_vbufCandidateIndex.iGetUsage()) {
			goto	exit_func ;
		}
		uCandStrIndex	= *(pCandInfo->m_vbufCandidateIndex.pGetBuffer () + uCandIndex) ;
		if (uCandStrIndex >= pCandInfo->m_vbufCandidate.iGetUsage ())
			return	LMR_ERROR ;

		wstrNewWord		= pCandInfo->m_vbufCandidate.pGetBuffer () + uCandStrIndex ;
		if (wstrNewWord != NULL) {
			LPDSTR		pwRetbuff ;
			int			n, nNewWordLen, nRetbuffSize ;

			pwRetbuff	= pThis->pGetReturnBuffer (&nRetbuffSize) ;
			if (pwRetbuff == NULL)
				return	LMR_ERROR ;

			nNewWordLen	= dcslen (wstrNewWord) ;
			n			= MIN (nNewWordLen, nRetbuffSize) ;
			if (n > 0)
				dcsncpy (pwRetbuff, wstrNewWord, n) ;
			pThis->vSetRegConstString (LMREGARG_RETVAL, pwRetbuff, n) ;
			pBuffer->vSkkSetSkkKakuteiFlag (TRUE) ;
		} else {
			pThis->vSetRegNil (LMREGARG_RETVAL) ;
		}
		/* _Exit_ �őS�ċz�����ׂ����H */
		pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
		pThis->vClearCandidateInfo () ;
#else
		int		nBack ;

		nBack	= nShow - n - 1 ;
		while (nBack > 0 && pSession->bPreviousCandidate ())
			nBack	-- ;

		wstrNewWord	= pSession->pGetCandidate () ;
		if (wstrNewWord != NULL) {
			LPDSTR		pwRetbuff ;
			int			n, nNewWordLen, nRetbuffSize ;

			pwRetbuff	= pThis->pGetReturnBuffer (&nRetbuffSize) ;
			if (pwRetbuff == NULL)
				return	LMR_ERROR ;

			nNewWordLen	= lstrlenW (wstrNewWord) ;
			n			= MIN (nNewWordLen, nRetbuffSize) ;
			if (n > 0)
				dcsncpy (pwRetbuff, wstrNewWord, n) ;
			pThis->vSetRegConstString (LMREGARG_RETVAL, pwRetbuff, n) ;
		} else {
			pThis->vSetRegNil (LMREGARG_RETVAL) ;
		}
#endif
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	} else {
		int		iFuncNo ;

		if (! pThis->bLookupKeymap (&ev, &iFuncNo)) 
			iFuncNo	= NFUNC_NOFUNCTION ;

		/* ����ȊO�̃L�[�̏ꍇ�B�K�� SPC �͌���B*/
		if (nCH == L' ' || iFuncNo == NFUNC_SKK_START_HENKAN) {
#if !defined (UNITTEST)
			/*	NextCandidate ���̐��������s���̔���� minibuffer-mode �Ɉڍs���ׂ����ǂ�����
			 *	�`�F�b�N�ł��Ȃ��BnMaxShow �����񂵂Ă݂�K�v������B
			 */
			IMECANDIDATES*	pCandInfo	= NULL ;


			pCandInfo	= pThis->pGetCandidateInfo () ;
			DEBUGPRINTF ((TEXT ("Count(%d), CurPage(%d), Selection(%d), MaxPage(%d)\n"),
				pCandInfo->m_iCount, pCandInfo->m_iCurrentPage, pCandInfo->m_iSelection, 
				pCandInfo->m_vbufPageIndex.iGetUsage ())) ;
			if ((pCandInfo->m_iCurrentPage + 1) < pCandInfo->m_vbufPageIndex.iGetUsage ()) {
				nLoop	++ ;
				pCandInfo->m_iCurrentPage	++ ;
				pCandInfo->m_iSelection		+= nMaxShow ;
				pCandInfo->m_dwUpdate		|= IMECANDUPDATE_SELECTION | IMECANDUPDATE_CURRENT_PAGE ;
				pThis->vSetUpdateFlag (IMEDOC_UPDATE_CANDIDATELIST) ;
				DEBUGPRINTF ((TEXT ("-> CurPage(%d), Selection(%d), MaxPage(%d)\n"),
					pCandInfo->m_iCurrentPage, pCandInfo->m_iSelection, 
					pCandInfo->m_vbufPageIndex.iGetUsage ())) ;
			} else {
				DEBUGPRINTF ((TEXT ("-> henkan-in-minibuff\n"))) ;
				/*	�ʖځB�ċA�o�^���[�h�Ɉڍs���邱�ƁB
				/*	�ċA���[�h�ł́ACandidate-List �͕���B�������A�߂��ė������̏󋵎���ł�
				 *	�ēx��邱�ƂɂȂ邪�c�B
				 */
				pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
				pThis->vClearCandidateInfo () ;
				pThis->vSetRegInteger (LMREG_3, n) ;
				if (! pThis->bCall (LM_bSkkHenkanInMinibuff, LM_bSkkHenkanShowCandidates_5))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			}
#else
			if (! pSession->bNextCandidate ()) {
				pThis->vSetRegInteger (LMREG_3, nShow) ;
				/*	�ċA�o�^���[�h�Ɉړ�����B*/
				/*	�ċA�o�^���[�h����߂��ė������ɂ܂� skk-henkan-show-candidates-mode �ł���
				 *	�ꍇ�ɂ́ACANDIDATELIST ���č\�z���Ȃ��Ƃ����Ȃ� > Windows IME
				 *	���̂܂܏������p�������肵�Ȃ����ƁB
				 */
				if (! pThis->bCall (LM_bSkkHenkanInMinibuff, LM_bSkkHenkanShowCandidates_5))
					return	LMR_ERROR ;

				/*	�I���W�i���̓���́A
				 *	1. skk-exit-show-candidates �� skk-henkan-count ��ݒ肵�A
				 *	   skk-henkan1 �֓��͂� nil �ł������Ƃ��Ė߂�B
				 *	2. skk-henkan1 �͕Ԃ�l nil �� skk-henkan �ւƖ߂��Askk-henkan �͕Ԃ�l�� nil ������
				 *	   �ꍇ�ɂ́Askk-henkan-in-minibuff ���Ăяo���B
				 *	3. skk-henkan-in-minibuff �� cancel ������ (keyboard-quit �Ȃ�����return)�A
				 *	   skk-exit-show-candidates ���Q�Ƃ��āA�ݒ肳��Ă���΂��̒l�������l�Ƃ���
				 *	   skk-henkan-show-candidates ���Ăяo���B
				 *
				 *	���� skk-henkan ���o�R���� skk-henkan-in-minibuff ���� skk-henkan-show-candidates ��
				 *	�ēx�Ăяo�����\�����ǂ��Ȃ̂��͕�����Ȃ����Astack ���]�v�ɕK�v�ɂȂ肻����������
				 *	�ŁA�������� skk-henkan-in-minibuff ���Ăяo���Ă���B
				 */
				return	LMR_CONTINUE ;
			} else {
				nLoop	++ ;
				(void)pSession->bPreviousCandidate () ;
				/* ���̌��̕\���ցc�B*/
			}
#endif
			bUpdateShow	= TRUE ;
		} else if (nCH == L'.') {
			/* �����o�^�Ɉړ�����L�[�̏ꍇ�Bdefault �� '.' */
#if !defined (UNITTEST)
			pThis->vSetRegInteger (LMREG_3, 0) ;	/* �ړ������ĂȂ�����A0�ŗǂ����H */
#else
			pThis->vSetRegInteger (LMREG_3, nShow) ;
#endif

			/*	�ċA�o�^���[�h�Ɉړ�����B*/
			/*	�ċA�o�^���[�h����߂��ė������ɂ܂� skk-henkan-show-candidates-mode �ł���
			 *	�ꍇ�ɂ́ACANDIDATELIST ���č\�z���Ȃ��Ƃ����Ȃ� > Windows IME
			 *	���̂܂܏������p�������肵�Ȃ����ƁB
			 */
			if (! pThis->bCall (LM_bSkkHenkanInMinibuff, LM_bSkkHenkanShowCandidates_5))
				return	LMR_ERROR ;

#if !defined (UNITTEST)
			pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
			pThis->vClearCandidateInfo () ;
#endif
			return	LMR_CONTINUE ;
		} else if (nCH == L'x' || iFuncNo == NFUNC_SKK_PREVIOUS_CANDIDATE) {
			/* 1�O�ɖ߂�L�[�̏ꍇ�B(skk-previous-candidate-char) default �� 'x' */
			if (nLoop <= 0) {
				struct TMSG	msg ;

				pBuffer->vSkkSetSkkHenkanCount (CImeConfig::iGetCountHenkanShowChange (pThis->m_pConfig) + 1) ;
				/* skk-previous-candidate �� bind ���ꂽ������ unread-event �ɐݒ肵�Ă���悤�����c�B*/
#if 1
				msg.m_nMessage	= WM_LM_COMMAND ;
				msg.m_nTime		= GetTickCount () ;
				msg.m_wParam	= NFUNC_SKK_PREVIOUS_CANDIDATE ;
				msg.m_lParam	= 0 ;
				msg.m_rParam	= 0 ;
				msg.m_pt.x		= msg.m_pt.y	= 0 ;
				pThis->bSetUnreadCommandEvent (&msg) ;
#else
				pThis->bSetUnreadCommandChar (L'x') ;
#endif
				pThis->vSetRegNil (LMREGARG_RETVAL) ;
				pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0);
#if !defined (UNITTEST)
				pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
				pThis->vClearCandidateInfo () ;
#endif
				return	LMR_CONTINUE ;
			} else {
#if !defined (UNITTEST)
				IMECANDIDATES*	pCandInfo	= NULL ;

				pCandInfo	= pThis->pGetCandidateInfo () ;
				if (pCandInfo != NULL) {
					/*	�����A�{���͂����Ɛ^�ʖڂɒ��ׂȂ��Ƃ����Ȃ��B
					 *	�y�[�W�T�C�Y�Ƃ�������ƌ��āB
					 */
					pCandInfo->m_iCurrentPage	= (pCandInfo->m_iCurrentPage > 0)? (pCandInfo->m_iCurrentPage - 1) : 0 ;
					pCandInfo->m_iSelection		= (pCandInfo->m_iSelection > nMaxShow)? (pCandInfo->m_iSelection - nMaxShow) : 0 ;
					pCandInfo->m_dwUpdate		|= IMECANDUPDATE_SELECTION | IMECANDUPDATE_CURRENT_PAGE ;
				}
				pThis->vSetUpdateFlag (IMEDOC_UPDATE_CANDIDATELIST) ;
#else
				int		nBack ;

				nBack	= nMaxShow + nShow ;
				while (nBack > 0 && pSession->bPreviousCandidate ()) 
					nBack	-- ;
#endif
				nLoop	-- ;
				bUpdateShow	= TRUE ;
			}
		} else if (nCH == 0x07 || (iFuncNo == NFUNC_KEYBOARD_QUIT || iFuncNo == NFUNC_ABORT_RECURSIVE_EDIT)) {
			struct TMSG	msg ;

			/* quit �� bind ����Ă���ꍇ�B*/
			/* signal ���g���� keyboard-quit ���Ăяo���Ă���悤�����c�B*/
#if 1
			msg.m_nMessage	= WM_LM_COMMAND ;
			msg.m_wParam	= NFUNC_KEYBOARD_QUIT ;
			msg.m_lParam	= 0 ;
			msg.m_pt.x		= msg.m_pt.y	= 0 ;
			msg.m_nTime		= GetTickCount () ;
			pThis->bSetUnreadCommandEvent (&msg) ;
#else
			pThis->bSetUnreadCommandChar (0x07) ;
#endif
			pThis->vSetRegNil (LMREGARG_RETVAL) ;
			pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0);
#if !defined (UNITTEST)
			pThis->vSetUpdateFlag (IMEDOC_CLOSE_CANDIDATELIST) ;
			pThis->vClearCandidateInfo () ;
#endif
			pBuffer->vSkkSetSkkKakuteiFlag (FALSE) ;
			return	LMR_CONTINUE ;
		} else {
			/*	����ȊO�͖����ȃL�[�ł��ƕ\������̂����Asit-for �����݂ł��Ȃ�(application�ɐ��䂪�߂�)�̂�
			 *	�\�����邱�Ƃ̓��[�U�[�ɂƂ��Ďז��ł����Ȃ����B
			 */
			WCHAR	bufText [256] ;
			int		nText ;
			if (0x21 <= nCH && nCH < 0x7E) {
				nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText)-1, L"`%c' is not valid here!", nCH) ;
			} else {
				nText	= wnsprintfW (bufText, MYARRAYSIZE (bufText)-1, L"0x%0x is not valid here!", nCH) ;
			}
			bufText [nText]	= L'\0' ;
			pThis->bSetMessage (bufText) ;
		}
	}
exit_func:
	pThis->vSetRegInteger (LMREG_1, nLoop) ;
	pThis->vSetRegBool    (LMREG_2, bUpdateShow) ;
	pThis->vJump (LM_bSkkHenkanShowCandidates_3) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanShowCandidates_5 (
	CImeDoc*			pThis)
{
	CImeBuffer*			pBuffer ;
	CTSearchSession*	pSession ;
	LPCDSTR		pwResult ;
	int			nResultLen ;

	if (pThis->bSignalp ()) {
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pSession	= pBuffer->pSkkGetSkkCurrentSearchProgSession () ;
	if (pSession == NULL) {
		pThis->vSetSignalError () ;
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	if (pThis->bGetRegConstString (LMREGARG_RETVAL, &pwResult, &nResultLen) && nResultLen > 0) {
		/* return n */
		/* pThis->vSetRegInteger (LMREGARG_RETVAL, n) ; */
		pThis->vJump (LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
#if defined (UNITTEST)
	{
		int	nShow ;
		if (pThis->bGetRegInteger (LMREG_4, &nShow)) {
			while (nShow > 1 && pSession->bPreviousCandidate ()) 
				nShow	-- ;
		}
	}
#endif
	pThis->vSetRegBool (LMREG_2, TRUE) ;
	pThis->vJump (LM_bSkkHenkanShowCandidates_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkHenkanShowCandidates_Exit_0 (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		pBuffer->vSkkSetSkkHenkanShowCandidatesMode (FALSE) ;
		/* skk-point-move �̌��ʁB*/
		pBuffer->bSkkSetSkkPreviousPointToPoint () ;
	}
	pThis->vClearMessage () ;
	pThis->vJump (LM_bSkkHenkanShowCandidates_Exit) ;
	return	LMR_CONTINUE ;
}

/*================================================================ ad-keyboard-quit (around)
 */
/*	around (���Ƃ̊֐��̎��s���܂�)�� emulation�Bad-do-it �͂��Ƃ̊֐��̎��s�������ɓ��邱�Ƃ�
 *	�����B
 *	�Ԃ�l: LMREGARG_RETVAL: ad-do-it ���ǂ����B�{���� ad-do-it ���ĂԈʒu�͔C�ӂȂ̂ŕԂ�l��
 *			�����͓̂K�؂ł͂Ȃ��c�B
 */
int
CImeDoc::LM_bSkkAdKeyboardQuit (
	CImeDoc*			pThis)
{
	CImeBuffer*				pBuffer ;
	CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bSkkGetSkkMode ()) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bSkkGetSkkHenkanMode ()) {
		int		nPrefix ;

		piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
		if (piteSkkRuleTree->bHavePrefixp () && piteSkkRuleTree->pGetPrefix (&nPrefix) != NULL) {
//		if (pBuffer->pSkkGetSkkCurrentRuleTree () != NULL && CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) != NULL) {
			pBuffer->bSkkErasePrefix (TRUE) ;
		} else {
			pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
			return	LMR_RETURN ;
		}
	} else if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pBuffer->vSkkSetSkkHenkanCount (0) ;
		if (CImeConfig::bSkkDeleteOkuriWhenQuit (pThis->m_pConfig)) {
			int		nSkkHenkanOkuriganaLen ;

			if (! pThis->bPushReg (LMREG_0))
				return	LMR_ERROR ;
			(void) pBuffer->pSkkGetSkkHenkanOkurigana (&nSkkHenkanOkuriganaLen) ;
			pThis->vSetRegInteger (LMREG_0, nSkkHenkanOkuriganaLen) ;
			if (! pThis->bCall (LM_bSkkPreviousCandidate, LM_bSkkKeyboardQuit_PostProcessPreviousCandidateForDeleteOkuriWhenQuit))
				return	LMR_ERROR ;
		} else {
			if (! pThis->bCall (LM_bSkkPreviousCandidate, LM_bSkkKeyboardQuit_1))
				return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (pThis->iGetLastCommand () == NFUNC_SKK_COMP_DO) {
			CTSearchSession*	pSession ;

			if (pBuffer->pSkkGetSkkHenkanStartPointMarker () != NULL)
				pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iGetPoint ()) ;

			/* skk-comp-key */
			pSession	= pBuffer->pSkkGetSkkCurrentCompletionSession () ;
			if (pSession != NULL) {
				LPCDSTR	pSkkCompKey ;
				int		nSkkCompKey ;

				pSkkCompKey	= pSession->pGetKeyword (&nSkkCompKey) ;
				pBuffer->iInsert (pBuffer->pGetPointMarker (), pSkkCompKey, nSkkCompKey) ;

				pBuffer->vSkkSetSkkCurrentCompletionSession (NULL) ;
				delete	pSession ;
			}
		} else {
			pBuffer->bSkkErasePrefix (TRUE) ;
			if (pBuffer->pSkkGetSkkHenkanStartPointMarker ()!= NULL && pBuffer->iGetPoint () > pBuffer->iSkkGetSkkHenkanStartPoint ()) {
				pBuffer->bDeleteRegion (pBuffer->iGetPoint (), pBuffer->iSkkGetSkkHenkanStartPoint ()) ;
			}
			pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
			if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkKeyboardQuit_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	pThis->vSetRegBool (LMREGARG_RETVAL, TRUE) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkKeyboardQuit_PostProcessPreviousCandidateForDeleteOkuriWhenQuit (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	int		nCount ;

	if (! pThis->bSignalp ()) {
		pBuffer	= pThis->pGetCurrentBuffer () ;
		if (pBuffer == NULL) {
			pThis->vSetSignalError () ;
		} else {
			/*	���艼���̕����������� backward-delete-char �����s����B
			 */
			if (! pThis->bGetRegInteger (LMREG_0, &nCount))
				nCount	= 0 ;
			if (! pBuffer->bDeleteBackwardChar (nCount)) {
				pThis->vSetSignalError () ;
			}
		}
	}
	pThis->vPopReg (LMREG_0) ;
	pThis->vJump (LM_bSkkKeyboardQuit_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkKeyboardQuit_1 (
	CImeDoc*			pThis)
{
	/* ... */
	pThis->vSetRegBool (LMREGARG_RETVAL, TRUE) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-abort-recursive-edit (around)
 */
/*	around (���Ƃ̊֐��̎��s���܂�)�� emulation
 */
int
CImeDoc::LM_bSkkAdAbortRecursiveEdit (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	/*	�ȉ��� hook ����菜�����삪�K�v���H�F
	 *  (skk-remove-minibuffer-setup-hook
	 *   'skk-j-mode-on 'skk-setup-minibuffer
	 *   #'(lambda () (add-hook 'pre-command-hook 'skk-pre-command nil 'local)))
	 */
	if (! pBuffer->bSkkGetSkkMode ()) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->bSkkGetSkkHenkanMode ()) {
		CSkkRuleTreeIterator*	piteSkkRuleTree ;
		int		nPrefix ;

		piteSkkRuleTree	= pBuffer->pSkkGetSkkRuleTreeIterator () ;
		if (piteSkkRuleTree->bHavePrefixp () && piteSkkRuleTree->pGetPrefix (&nPrefix) != NULL) {
//		if (pBuffer->pSkkGetSkkCurrentRuleTree () != NULL && CSkkRuleTreeNode::pGetPrefix (pBuffer->pSkkGetSkkCurrentRuleTree (), &nPrefix) != NULL) {
			pBuffer->bSkkErasePrefix (TRUE) ;
		} else {
			pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
			return	LMR_RETURN ;
		}
	} else if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
		pBuffer->vSkkSetSkkHenkanCount (0) ;
		if (CImeConfig::bSkkDeleteOkuriWhenQuit (pThis->m_pConfig)) {
			int		nSkkHenkanOkuriganaLen ;

			if (! pThis->bPushReg (LMREG_0))
				return	LMR_ERROR ;
			(void) pBuffer->pSkkGetSkkHenkanOkurigana (&nSkkHenkanOkuriganaLen) ;
			pThis->vSetRegInteger (LMREG_0, nSkkHenkanOkuriganaLen) ;
			if (! pThis->bCall (LM_bSkkPreviousCandidate, LM_bSkkAbortRecursiveEdit_PostProcessPreviousCandidateForDeleteOkuriWhenQuit))
				return	LMR_ERROR ;
		} else {
			if (! pThis->bCall (LM_bSkkPreviousCandidate, LM_bSkkAbortRecursiveEdit_1))
				return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (pThis->iGetLastCommand () == NFUNC_SKK_COMP_DO) {
			CTSearchSession*	pSession ;

			if (pBuffer->pSkkGetSkkHenkanStartPointMarker () != NULL)
				pBuffer->bDeleteRegion (pBuffer->iSkkGetSkkHenkanStartPoint (), pBuffer->iGetPoint ()) ;

			/* skk-comp-key */
			pSession	= pBuffer->pSkkGetSkkCurrentCompletionSession () ;
			if (pSession != NULL) {
				LPCDSTR	pSkkCompKey ;
				int		nSkkCompKey ;

				pSkkCompKey	= pSession->pGetKeyword (&nSkkCompKey) ;
				pBuffer->iInsert (pBuffer->pGetPointMarker (), pSkkCompKey, nSkkCompKey) ;

				pBuffer->vSkkSetSkkCurrentCompletionSession (NULL) ;
				delete	pSession ;
			}
		} else {
			pBuffer->bSkkErasePrefix (TRUE) ;
			if (pBuffer->pSkkGetSkkHenkanStartPointMarker () != NULL && pBuffer->iGetPoint () > pBuffer->iSkkGetSkkHenkanStartPoint ()) {
				pBuffer->bDeleteRegion (pBuffer->iGetPoint (), pBuffer->iSkkGetSkkHenkanStartPoint ()) ;
			}
			pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
			if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkAbortRecursiveEdit_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	pThis->vSetRegBool (LMREGARG_RETVAL, TRUE) ;
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkAbortRecursiveEdit_PostProcessPreviousCandidateForDeleteOkuriWhenQuit (
	CImeDoc*			pThis)
{
	CImeBuffer*	pBuffer ;
	int		nCount ;

	if (! pThis->bSignalp ()) {
		pBuffer	= pThis->pGetCurrentBuffer () ;
		if (pBuffer == NULL) {
			pThis->vSetSignalError () ;
		} else {
			/*	���艼���̕����������� backward-delete-char �����s����B
			 */
			if (! pThis->bGetRegInteger (LMREG_0, &nCount))
				nCount	= 0 ;
			if (! pBuffer->bDeleteBackwardChar (nCount)) {
				pThis->vSetSignalError () ;
			}
		}
	}
	pThis->vPopReg (LMREG_0) ;
	pThis->vJump (LM_bSkkKeyboardQuit_1) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkAbortRecursiveEdit_1 (
	CImeDoc*			pThis)
{
	/* ... */
	pThis->vSetRegBool (LMREGARG_RETVAL, TRUE) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-exit-minibuffer (around)
 */
/*	around (���Ƃ̊֐��̎��s���܂�)�� emulation
 */
int
CImeDoc::LM_bSkkAdExitMinibuffer (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	/*  (skk-remove-minibuffer-setup-hook
	 *   'skk-j-mode-on 'skk-setup-minibuffer
	 *   #'(lambda ()
	 *       (add-hook 'pre-command-hook 'skk-pre-command nil 'local)))
	 *
	 *	���̈������ǂ�����ׂ����c�B
	 */
	if (! (pBuffer->bJModep () || pBuffer->bJisx0201Modep () || pBuffer->bAbbrevModep ())) {
		/* through */
	} else {
		BOOL	bNoNewline ;

		bNoNewline	= (CImeConfig::bSkkEggLikeNewline (pThis->m_pConfig) && pBuffer->bSkkGetSkkHenkanMode ()) ;
		if (! pThis->bPushReg (LMREG_0))
			return	LMR_ERROR ;

		pThis->vSetRegBool (LMREG_0, bNoNewline) ;
		if (pBuffer->bSkkGetSkkMode ()) {
			pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
			if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkExitMinibuffer_1))
				return	LMR_ERROR ;
		} else {
			pThis->vJump (LM_bSkkExitMinibuffer_1) ;
		}
		return	LMR_CONTINUE ;
	}
	pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;	/* ad-do-it */
	return	LMR_RETURN ;
}

int
CImeDoc::LM_bSkkExitMinibuffer_1 (
	CImeDoc*			pThis)
{
	BOOL					bNoNewline ;

	if (! pThis->bGetRegBool (LMREG_0, &bNoNewline))
		bNoNewline	= TRUE ;
	pThis->vSetRegBool (LMREGARG_RETVAL, bNoNewline) ;
	pThis->vPopReg (LMREG_0) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-next-line (before)
 */
/*
 *	(defadvice next-line (before skk-ad activate)
 *	  (when (eq skk-henkan-mode 'active)
 *	    (skk-kakutei)))
 */
int
CImeDoc::LM_bSkkAdNextLine (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	/*	before advice �Ȃ̂� ad-do-it �̎w��͂Ȃ��B�Ƃ������A�K���{�͎̂��s�����B
	 */
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
			pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
			pThis->vJump (LM_bSkkKakuteiAdJisx0201) ;
			return	LMR_CONTINUE ;
		}
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-previous-line (before)
 */
/*
 *	(defadvice previous-line (before skk-ad activate)
 *	  (when (eq skk-henkan-mode 'active)
 *	    (skk-kakutei)))
 */
int
CImeDoc::LM_bSkkAdPreviousLine (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;

	/*	before advice �Ȃ̂� ad-do-it �̎w��͂Ȃ��B�Ƃ������A�K���{�͎̂��s�����B
	 */
	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer != NULL) {
		if (pBuffer->bSkkGetSkkHenkanMode () == LACTIVE) {
			pThis->vSetRegConstString (LMREGARG_0, NULL, 0) ;
			pThis->vJump (LM_bSkkKakuteiAdJisx0201) ;
			return	LMR_CONTINUE ;
		}
	}
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-newline (around)
 */
	/*
(skk-defadvice newline (around skk-ad activate)
  "`skk-egg-like-newline' ��������A�ϊ����͊m��̂ݍs���A���s���Ȃ��B"
  (interactive "*P")
  (if (not (or skk-j-mode
	       skk-jisx0201-mode
	       skk-abbrev-mode))
      ad-do-it
    (let (;;(arg (ad-get-arg 0))
	  ;; `skk-kakutei' �����s����� `skk-henkan-mode' �̒l��
	  ;; �������� nil �ɂȂ�̂ŁA�ۑ����Ă����K�v������B
	  (no-newline (and skk-egg-like-newline
			   skk-henkan-mode))
	  (auto-fill-function (if (interactive-p)
				  auto-fill-function
				nil)))
      ;; fill ����Ă� nil ���A���Ă��� :-<
      ;;(if (skk-kakutei)
      ;;    (setq arg (1- arg)))
      ;;(if skk-mode
      ;;    (let ((opos (point)))
      ;;      ;; skk-kakutei (skk-do-auto-fill) �ɂ���čs���܂�Ԃ��ꂽ��
      ;;      ;; arg �� 1 ���炷�B
      ;;      (skk-kakutei)
      ;;      (if (and (not (= opos (point))) (integerp arg))
      ;;          (ad-set-arg 0 (1- arg)))))
      (when skk-mode
	(skk-kakutei))
      (undo-boundary)
      (unless no-newline
	ad-do-it))))*/
int
CImeDoc::LM_bSkkAdNewline (
	CImeDoc*			pThis)
{
	CImeBuffer*		pBuffer ;
	BOOL		bNoNewline ;

	pBuffer	= pThis->pGetCurrentBuffer () ;
	if (pBuffer == NULL) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		pThis->vSetUpdateFlag (IMEDOC_NEWLINE) ;
		return	LMR_RETURN ;
	}
	if (! (pBuffer->bJModep () || pBuffer->bJisx0201Modep () || pBuffer->bAbbrevModep ())) {
		pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
		pThis->vSetUpdateFlag (IMEDOC_NEWLINE) ;
		return	LMR_RETURN ;
	}
	if (! pThis->bPushReg (LMREG_0))
		return	LMR_ERROR ;

	/*	newline �őS�m��@�\������̂Ȃ���l���Ȃ���΁B
	 */
	bNoNewline	= (CImeConfig::bSkkEggLikeNewline (pThis->m_pConfig) && pBuffer->bSkkGetSkkHenkanMode ())? TRUE : FALSE ;
	pThis->vSetRegBool (LMREG_0, bNoNewline) ;

	if (pBuffer->bSkkGetSkkMode ()) {
		pThis->vSetRegNil (LMREGARG_0) ;
		if (! pThis->bCall (LM_bSkkKakuteiAdJisx0201, LM_bSkkAdNewline_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	pThis->vSetRegBool (LMREGARG_RETVAL, FALSE) ;
	pThis->vJump (LM_bSkkAdNewline_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkAdNewline_1 (
	CImeDoc*			pThis)
{
	BOOL	bNoNewline ;

	if (! pThis->bGetRegBool (LMREG_0, &bNoNewline))
		bNoNewline	= TRUE ;

	/*	newline �őS�m��ɂ���ꍇ�ɂ� QueryShiftCount �̐����� skk-kakutei �̒���ł���
	 *	���Ƃ���ӂ݂āApoint-marker ���ŏI�ʒu�ֈړ�������Ηǂ��B
	 */
	if (CImeConfig::bSkkIsNewlineKakuteiAllp (pThis->m_pConfig) && ! pThis->bIsStatusActivep ()) {
		CImeBuffer*	pBuffer ;

		pBuffer	= pThis->pGetCurrentBuffer () ;
		if (pBuffer != NULL && pBuffer->pGetPointMarker ()->bIsValidp ()) {
			CTMarker*	pmkBufferEnd	= NULL ;

			/*	point marker ���s���ւƈړ�������B*/
			if (pBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkBufferEnd) && pmkBufferEnd != NULL) {
				pBuffer->pGetPointMarker ()->bSetPosition (pmkBufferEnd) ;
			} else {
				int		nPoint	= pBuffer->iGetPoint () ;
				if (0 <= nPoint && nPoint < pBuffer->iGetPointMax ()) {
					pBuffer->pGetPointMarker ()->bForward (pBuffer->iGetPointMax () - nPoint) ;
				}
			}
		}
	}
	pThis->vSetRegBool (LMREGARG_RETVAL, bNoNewline) ;
	pThis->vJump (LM_bSkkAdNewline_Exit) ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bSkkAdNewline_Exit (
	CImeDoc*			pThis)
{
	pThis->vPopReg (LMREG_0) ;
	pThis->vSetUpdateFlag (IMEDOC_NEWLINE) ;
	return	LMR_RETURN ;
}




