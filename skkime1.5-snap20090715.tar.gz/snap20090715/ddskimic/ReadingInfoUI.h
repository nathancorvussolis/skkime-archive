#pragma once

class	CSkkImeTextService ;

class	CSkkImeReadingInfoUIElement : 
#if defined (__ITfReadingInformationUIElement_INTERFACE_DEFINED__)
	public ITfReadingInformationUIElement 
#else
	public IUnknown
#endif
{
private:
	enum {
		MAXLEN_READINGSTRING	= 256,
	} ;
public:
    /* IUnknown Interface */
    STDMETHODIMP			QueryInterface (REFIID riid, void **ppvObj) ;
    STDMETHODIMP_(ULONG)	AddRef () ;
    STDMETHODIMP_(ULONG)	Release () ;

	/* ITfUIElement Interface */
	STDMETHODIMP		GetDescription (BSTR* pbstrDescription) ;
	STDMETHODIMP		GetGUID (GUID* pguid) ;
	STDMETHODIMP		Show (BOOL bShow) ;
	STDMETHODIMP		IsShown (BOOL* pbShow) ;

	/* ITfReadingInformationUIElement Interface */
	STDMETHODIMP		GetUpdatedFlags (DWORD* pdwFlags) ;
	STDMETHODIMP		GetContext (ITfContext** ppic) ;
	STDMETHODIMP		GetString (BSTR* pstr) ;
	STDMETHODIMP		GetMaxReadingStringLength (UINT* pcchMax) ;
	STDMETHODIMP		GetErrorIndex (UINT* pErrorIndex) ;
	STDMETHODIMP		IsVerticalOrderPreferred (BOOL* pfVertical) ;


public:
	CSkkImeReadingInfoUIElement (CSkkImeTextService* pTSF) ;
	virtual				~CSkkImeReadingInfoUIElement () ;

	BOOL				_Init (BOOL bConsole) ;
	void				_Uninit () ;

	BOOL				_SetReadingString (LPCWSTR wstrText, UINT cchText) ;

private:
	CSkkImeTextService*	m_pTSF ;
	WCHAR				m_wszText [MAXLEN_READINGSTRING] ;
	UINT				m_cchText ;
	BOOL				m_bShown ;
	DWORD				m_dwElementId ;
	BOOL				m_bOpen ;
	HWND				m_hWnd ;
	POINT				m_ptWnd ;
	BOOL				m_bConsole ;
	POINT				m_ptLastCursor ;

    LONG				m_cRef ;
	static	const GUID	m_guidSkkImeReadinfInfoUIElement ;
	static	LPCWSTR		m_wstrDescription ;
	static	TCHAR		m_szClassName [] ;
} ;

