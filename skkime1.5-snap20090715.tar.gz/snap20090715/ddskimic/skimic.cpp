#include "globals.h"
#include "skimic.h"
#include "IME/ImeConfig.h"

HRESULT
CSkkImeTextService::CreateInstance (
	IUnknown*		pUnkOuter,
	REFIID			riid,
	void**			ppvObj)
{
	CSkkImeTextService*	pTSF ;
	HRESULT				hr ;

	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
	if (pUnkOuter != NULL)
		return	CLASS_E_NOAGGREGATION ;

	pTSF	= new CSkkImeTextService ;
	if (pTSF == NULL)
		return	E_OUTOFMEMORY ;
	hr		= pTSF->QueryInterface (riid, ppvObj) ;
	pTSF->Release () ;
	return	hr ;
}

CSkkImeTextService::CSkkImeTextService ()
{
	DllAddRef () ;
	m_pThreadMgr						= NULL ;
	m_tfClientId						= TF_CLIENTID_NULL ;
	m_pCModeLangBarItem					= NULL ;
	m_dwThreadMgrEventSinkCookie		= TF_INVALID_COOKIE ;
	m_dwThreadFocusSinkCookie			= TF_INVALID_COOKIE ;
	m_dwTextEditSinkCookie				= TF_INVALID_COOKIE ;
	m_dwCompKeyboardOpenCloseCookie		= TF_INVALID_COOKIE ;
	m_dwCompKeyboardDisabledCookie		= TF_INVALID_COOKIE ;
	m_dwCompEmptyContextCookie			= TF_INVALID_COOKIE ;
	m_pTextEditSinkContext				= NULL ;
	m_pComposition						= NULL ;
	m_pSkkIme							= NULL ;
    m_pIMELangBarItem					= NULL ;
    m_pCModeLangBarItem					= NULL ;
	m_pRCandidateList					= NULL ;
	m_fCleaningUp						= FALSE ;
	m_gaDisplayAttributeInput			= TF_INVALID_GUIDATOM ;
	m_gaDisplayAttributeConverted		= TF_INVALID_GUIDATOM ;
	m_cRef								= 1 ;
	m_pCandidateListUIElement			= NULL ;
	m_pToolTipUIElement					= NULL ;
#if defined (not_work)
	m_pReadingInformationUIElement		= NULL ;
#endif
	m_dwActivateFlag					= 0 ;
	m_pConfig							= NULL ;
	return ;
}

CSkkImeTextService::~CSkkImeTextService ()
{
	if (m_pConfig != NULL) {
		m_pConfig->Release () ;
		m_pConfig	= NULL ;
	}
	DllRelease () ;
	return ;
}

STDAPI
CSkkImeTextService::QueryInterface (
	REFIID			riid,
	void**			ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::QueryInterface ()\n"))) ;

	*ppvObj	= NULL ;
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfTextInputProcessorEx)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfTextInputProcessorEx\n"))) ;
		*ppvObj	= (ITfTextInputProcessorEx *)this ;
	} else if (IsEqualIID (riid, IID_ITfTextInputProcessor)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfTextInputProcessor\n"))) ;
		*ppvObj	= (ITfTextInputProcessor*)this ;
#else
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfTextInputProcessor)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfTextInputProcessor\n"))) ;
		*ppvObj	= (ITfTextInputProcessor*)this ;
#endif
	} else if (IsEqualIID (riid, IID_ITfThreadMgrEventSink)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfThreadMgrEventSink\n"))) ;
		*ppvObj	= (ITfThreadMgrEventSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfThreadFocusSink)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfThreadFocusSink\n"))) ;
		*ppvObj	= (ITfThreadFocusSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfTextEditSink)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfTextEditSink\n"))) ;
		*ppvObj	= (ITfTextEditSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfKeyEventSink)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfKeyEventSink\n"))) ;
		*ppvObj	= (ITfKeyEventSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfFunctionProvider)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfFunctionProvider\n"))) ;
		*ppvObj	= (ITfFunctionProvider *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnConfigure)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfFnConfigure\n"))) ;
		*ppvObj	= (ITfFnConfigure *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnConfigureRegisterWord)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfFnConfigureRegisterWord\n"))) ;
		*ppvObj	= (ITfFnConfigureRegisterWord *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnReconversion)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfFnReconversion\n"))) ;
		*ppvObj	= (ITfFnReconversion *) this ;
#if defined (not_work)
	} else if (IsEqualIID (riid, IID_ITfFnPropertyUIStatus)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfFnPropertyUIStatus\n"))) ;
		*ppvObj	= (ITfFnPropertyUIStatus *) this ;
#endif
	} else if (IsEqualIID (riid, IID_ITfDisplayAttributeProvider)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfDisplayAttributeProvider\n"))) ;
		*ppvObj	= (ITfDisplayAttributeProvider *)this ;
	} else if (IsEqualIID (riid, IID_ITfCleanupContextDurationSink)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfCleanupContextDurationSink\n"))) ;
		*ppvObj	= (ITfCleanupContextDurationSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfCleanupContextSink)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfCleanupContextSink\n"))) ;
		*ppvObj	= (ITfCleanupContextSink *)this ;
	} else if (IsEqualIID (riid, IID_ITfCompartmentEventSink)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfCompartmentEventSink\n"))) ;
		*ppvObj	= (ITfCompartmentEventSink *) this ;
#if defined (__ITfToolTipUIElement_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfToolTipUIElement)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfToolTipUIElement\n"))) ;
		*ppvObj	= (ITfToolTipUIElement *)m_pToolTipUIElement ;
#endif
#if defined (__ITfCandidateListUIElement_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfCandidateListUIElement)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfCandidateListUIElement\n"))) ;
		*ppvObj	= (ITfCandidateListUIElement *)m_pCandidateListUIElement ;
#endif
#if defined (__ITfCandidateListUIElementBehavior_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfCandidateListUIElementBehavior)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfCandidateListUIElementBehavior\n"))) ;
		*ppvObj	= (ITfCandidateListUIElementBehavior *)m_pCandidateListUIElement ;
#endif
#if defined (not_work)
#if defined (__ITfReadingInformationUIElement_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfReadingInformationUIElement)) {
		DEBUGPRINTF ((TEXT ("QueryInterface() = IID_ITfReadingInformationUIElement\n"))) ;
		*ppvObj	= (ITfReadingInformationUIElement *)m_pReadingInformationUIElement ;
#endif
#endif
	} else {
#if 0
		static	const IID	guidUnknown	= {
			0x3977526d, 0x1a0a, 0x435a, { 0x8d, 0x06, 0xec, 0xc9, 0x51, 0x6b, 0x48, 0x4f }
		} ;
		if (IsEqualIID (riid, guidUnknown)) {
			/*	��̓I�ɂǂ̂悤�� Interface �ɂȂ�̂��͕�����Ȃ������p����Ă���悤�Ɏv����B
			 */
		}
#endif
		DEBUGPRINTF ((TEXT ("QueryInterface() = %08x-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x\n"),
			riid.Data1, riid.Data2, riid.Data3, 
			riid.Data4 [0], riid.Data4 [1], riid.Data4 [2], riid.Data4 [3], 
			riid.Data4 [4], riid.Data4 [5], riid.Data4 [6], riid.Data4 [7])) ;
	}

	if (*ppvObj) {
		AddRef () ;
		return	S_OK ;
	}
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::QueryInterface () return E_NOINTERFACE\n"))) ;
	return	E_NOINTERFACE ;
}

STDAPI_(ULONG)	CSkkImeTextService::AddRef ()
{
	return	++ m_cRef ;
}

STDAPI_(ULONG)	CSkkImeTextService::Release ()
{
	LONG	cr	= -- m_cRef ;

	assert (m_cRef >= 0) ;

	if (m_cRef == 0) 
		delete	this ;

	return	cr ;
}

STDAPI
CSkkImeTextService::Activate (
	ITfThreadMgr*		pThreadMgr,
	TfClientId			tfClientId)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::Activate (0x%x) -> ActiavteEx\n"), tfClientId)) ;
	return	ActivateEx (pThreadMgr, tfClientId, 0) ;
}

STDAPI
CSkkImeTextService::ActivateEx (
	ITfThreadMgr*		pThreadMgr,
	TfClientId			tfClientId,
	DWORD				dwFlags)
{
#if defined (TSFcase)
	ITfDocumentMgr*		pFocusDoc ;
#endif
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::ActivateEx (ClientId:0x%x, flags:0x%0x)\n"), tfClientId, dwFlags)) ;

	if (pThreadMgr == NULL)
		return	E_INVALIDARG ;

	m_pThreadMgr		= pThreadMgr ;
	m_pThreadMgr->AddRef () ;

	m_tfClientId		= tfClientId ;

	if (! _InitThreadMgrSink ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitThreadMgrSink () failed.\n"))) ;
		goto	exit_error ;
	}

	if (! _InitKeystrokeSink ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitKeystrokeSink () failed.\n"))) ;
		goto	exit_error ;
	}

    if (!_InitPreservedKey ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitPreservedKey () failed.\n"))) ;
        goto	exit_error ;
	}

	if (!_InitSkkImeMgr ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitSkkImeMgr () failed.\n"))) ;
		goto	exit_error ;
	}

	if (!_InitGlobalCompartment ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitGlobalCompartment (0x%x) failed\n"), tfClientId)) ;
		goto	exit_error ;
	}

	if (!_InitFunctionProvider ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitFunctionProvider (0x%x) failed\n"), tfClientId)) ;
		goto	exit_error ;
	}

	if (!_InitReconversion ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitReconversion (0x%x) failed\n"), tfClientId)) ;
		goto	exit_error ;
	}

	if (! _InitDisplayAttributeGuidAtom ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitDisplayAttributeGuidAtom (0x%x) failed\n"), tfClientId)) ;
		goto	exit_error ;
	}

	if (! _InitLangBarItem ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitLangBarItem () failed.\n"))) ;
		goto	exit_error ;
	}

	if (! _InitUIElements (dwFlags)) {
		/* ����͎�������ĂȂ��\�������邩��G���[�͖�������B*/
	}
#if defined (TSFcase)
	if (m_pThreadMgr->GetFocus (&pFocusDoc) == S_OK) {
		// The system will call OnSetFocus only for focus events after Activate
		// is called.
		OnSetFocus (pFocusDoc, NULL) ;
		pFocusDoc->Release () ;
	}
#endif
	m_dwActivateFlag	= dwFlags ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::Activate (0x%x) succeeded\n"), tfClientId)) ;
	return	S_OK ;

 exit_error:
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::Activate (0x%x) failed -> deactivate\n"), tfClientId)) ;
	Deactivate () ;
	return	E_FAIL ;
}

STDAPI
CSkkImeTextService::Deactivate ()
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::Deactivate (0x%x)\n"), m_tfClientId)) ;
	_UninitThreadMgrSink () ;
	_UninitLangBarItem () ;
    _UninitKeystrokeSink();
    _UninitPreservedKey () ;
    _InitTextEditSink (NULL) ;
	_UninitSkkImeMgr () ;
	_UninitGlobalCompartment () ;
	_UninitFunctionProvider () ;
	_UninitReconversion () ;
	_UninitUIElements () ;

	SafeReleaseClear (m_pThreadMgr) ;
	m_tfClientId	= TF_CLIENTID_NULL ;
	return	S_OK ;
}

BOOL
CSkkImeTextService::_GetFocusWnd (
	HWND*			phWnd)
{
    ITfDocumentMgr *pFocusDoc;
	ITfContext*		pContext ;
	ITfContextView*	pContextView ;
	BOOL			fRetval	= FALSE ;

	if (m_pThreadMgr == NULL)
		return	FALSE ;
	if (m_pThreadMgr->GetFocus (&pFocusDoc) != S_OK)
		return	FALSE ;
	if (pFocusDoc->GetTop (&pContext) == S_OK) {
		if (pContext->GetActiveView (&pContextView) == S_OK) {
			pContextView->GetWnd (phWnd) ;
			fRetval	= TRUE ;
			pContextView->Release () ;
		}
		pContext->Release () ;
	}
	pFocusDoc->Release () ;
	return	fRetval ;
}

TfClientId
CSkkImeTextService::_GetClientId ()
{
	return	m_tfClientId ;
}

ITfThreadMgr*
CSkkImeTextService::_GetThreadMgr ()
{
	return	m_pThreadMgr ;
}

HRESULT
CSkkImeTextService::_GetFocusContext (
	ITfContext**	ppContext)
{
	HRESULT         hr ;
	ITfDocumentMgr*	pFocusDoc ;
	ITfContext*		pContext ;

	if (ppContext == NULL || m_pThreadMgr == NULL)
		return	E_INVALIDARG ;

	hr	= m_pThreadMgr->GetFocus (&pFocusDoc) ;
	if (FAILED (hr))
		return	hr ;

	hr	= pFocusDoc->GetTop (&pContext) ;
	if (FAILED (hr))
		goto	exit_func ;
	*ppContext	= pContext ;	/* [must] Caller must release pContext. */
exit_func:
	if (pFocusDoc != NULL)
		pFocusDoc->Release () ;
	return	hr ;
}


