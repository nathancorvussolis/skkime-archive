#pragma once

#include	"Char.h"
#include	"varbuffer.h"

struct tagSkkJisyo ;

enum {
	SEARCH_OKURI_NASHI	= 0,
	SEARCH_OKURI_ARI,
	SEARCH_OKURI_STRICT,
	SEARCH_OKURI_STRICT_PRECEDENCE,
	SEARCH_OKURI_AUTO,
} ;

/*	�����̈�ʂ̑���ꗗ�F
 *		����, �R���v���[�V����, �o�^, �폜, �Z�[�u, �j��
 *
 *	�쐬�͌X�̎����̒��ɂ͂Ȃ��B����͏�� or �N���X�̊֐��ɂȂ�B
 */
typedef struct tagSkkJisyoFunc {
	BOOL	(*m_pSearch)		(struct tagSkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
	BOOL	(*m_pCompletion)	(struct tagSkkJisyo*, const Char*, int, TVarbuffer*) ;
	BOOL	(*m_pRecord)		(struct tagSkkJisyo*, const Char*, int, const Char*, int, const Char*, int, BOOL) ;
	BOOL	(*m_pPurge)			(struct tagSkkJisyo*, const Char*, int, const Char*, int, const Char*, int, BOOL) ;
	BOOL	(*m_pSave)			(struct tagSkkJisyo*) ;
	BOOL	(*m_pDestroy)		(struct tagSkkJisyo*) ;
	LPCTSTR	(*m_pGetPath)		(struct tagSkkJisyo*) ;
}	SkkJisyoFunc ;

struct tagSkkJisyo {
	SkkJisyoFunc*		m_pVtbl ;
} ;

typedef struct tagSkkJisyo	SkkJisyo ;

/*	�v���g�^�C�v�錾�B
 */
BOOL	SkkJisyo_Search			(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
BOOL	SkkJisyo_TryCompletion	(SkkJisyo*, const Char*, int, TVarbuffer*) ;
BOOL	SkkJisyo_Record			(SkkJisyo*, const Char*, int, const Char*, int, const Char*, int, BOOL) ;
BOOL	SkkJisyo_Purge			(SkkJisyo*, const Char*, int, const Char*, int, const Char*, int, BOOL) ;
BOOL	SkkJisyo_Save			(SkkJisyo*) ;
BOOL	SkkJisyo_Destroy		(SkkJisyo*) ;
LPCTSTR	SkkJisyo_GetPath		(SkkJisyo*) ;

