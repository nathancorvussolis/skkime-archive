#include "local.h"
#include "jisyo.h"
#include "sortedjisyo.h"
#include "cstring.h"
#include "kstring.h"

#define	BUFSIZE				(512)
#define	KEOF				((Char)-1)

/* '��' ���� '��' �܂ŁB*/
#define	MYCHAR_KANA_START	(Char_Make (KCHARSET_JISX0208_1983, 0x2421))
#define	MYCHAR_KANA_END		(Char_Make (KCHARSET_JISX0208_1983, 0x2473))
#define AFTER_KANA			(MYCHAR_KANA_END - MYCHAR_KANA_START + 1)
#define EOL					(0x0a)

#define	MYSTR1				";; okuri-ari entries."
#define	MYSTR2				" okuri-nasi entries."

struct KanjiReader {
	KANJISTATEMACHINE	m_KSM ;
	Char				m_buf [8] ;
	int					m_iUsage ;
} ;

/*
 *	Prototypes
 */
static	SkkJisyo*	skkSortedJisyo_create	(LPCTSTR, int) ;
static	BOOL		skkSortedJisyo_search 	(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
static	BOOL		skkSortedJisyo_destroy	(SkkJisyo*) ;
static	LPCTSTR		skkSortedJisyo_getPath	(SkkJisyo*) ;

static	BOOL	skkSortedJisyo_makeTab		(SkkSortedJisyo*) ;
static	BOOL	skkSortedJisyo_makeNewTab	(SkkSortedJisyo*, int) ;
static	BOOL	skkSortedJisyo_searchRange	(SkkSortedJisyo*, const Char*, int, int, long, long, TVarbuffer*) ;
static	BOOL	skkSortedJisyo_find			(struct KanjiReader*, const unsigned char*, const unsigned char*, TVarbuffer*) ;
static	int		skkSortedJisyo_compare		(Char, Char, int) ;

/*
 *	Global Variables
 */
static SkkJisyoFunc		sSortedJisyoProcTbl	= {
	skkSortedJisyo_search,
	NULL,
	NULL,
	NULL,
	NULL,
	skkSortedJisyo_destroy,
	skkSortedJisyo_getPath,
} ;


SkkJisyo*
SkkSortedJisyo_Create (
	register const Char*	pFileName,
	register int			nFileName,
	register int			nCodingSystem)
{
	TCHAR				strPath [PATH_MAX + 1] ;
	register SkkJisyo*	pJisyo ;

	if (nFileName > PATH_MAX)
		return	NULL ;

#if defined (UNICODE)
	internal2wstr (strPath, ARRAYSIZE (strPath) - 1, pFileName, nFileName) ;
#else
	cstrtostr (strPath, pFileName, nFileName) ;
#endif
	strPath [nFileName]	= TEXT('\0') ;

	/* �����t�@�C�����Ǘ����邽�߂̃f�[�^�̈���m�ۂ���B*/
	pJisyo	= skkSortedJisyo_create (strPath, nCodingSystem) ;
	return	pJisyo ;
}

SkkJisyo*
SkkSortedJisyo_CreateT (
	register LPCTSTR		pFileName,
	register int			nCodingSystem)
{
	register int		nFileName ;

	if (pFileName == NULL)
		return	NULL ;

	nFileName	= lstrlen (pFileName) ;
	if (nFileName >= PATH_MAX)
		return	NULL ;

	/* �����t�@�C�����Ǘ����邽�߂̃f�[�^�̈���m�ۂ���B*/
	return	skkSortedJisyo_create (pFileName, nCodingSystem) ;
}

/*
 *	Private Functions
 */
SkkJisyo*
skkSortedJisyo_create (
	register LPCTSTR	strPath,
	register int		nCodingSystem)
{
	register SkkJisyo*			pSkkJisyo ;
	register SkkSortedJisyo*	pJisyo ;
	register HANDLE				hFile, hJisyoMapping ;
	register void*				pJisyoMapping ;
	register DWORD				dwFileSize ;
	register LPCTSTR			pSrc ;
	register LPTSTR				pDest ;
	register int				nCheckBytes, cc, nDest ;
#if defined (DEBUG)
	register DWORD				dwFrom, dwTo, dwDiff ;
#endif

	DEBUGPRINTF ((TEXT ("SkkSortedJisyo_Create (jisyo => \"%s\")\n"), strPath)) ;

	pSkkJisyo	= MALLOC (sizeof (SkkJisyo) + sizeof (SkkSortedJisyo)) ;
	if (pSkkJisyo == NULL)
		return	NULL ;
	memset (pSkkJisyo, 0, (sizeof (SkkJisyo) + sizeof (SkkSortedJisyo))) ;

	pSkkJisyo->m_pVtbl	= &sSortedJisyoProcTbl ;
	pJisyo				= (SkkSortedJisyo *)(pSkkJisyo + 1) ;

	pSrc	= strPath ;
	pDest	= pJisyo->m_tszPath ;
	nDest	= MAX_PATH ;
	while (cc = *pSrc ++, cc != TEXT ('\0') && nDest -- > 0) 
		*pDest ++	= (TCHAR)((cc == TEXT ('/'))? TEXT ('\\') : (TCHAR) cc) ;
	*pDest	= TEXT ('\0') ;

	hFile	= CreateFile (pJisyo->m_tszPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE) {
		DEBUGPRINTF ((TEXT ("CreateFile failed (%d)\n"), (int)GetLastError ())) ;
		goto	exit_func_4 ;
	}
	dwFileSize	= GetFileSize (hFile, NULL) ;
	if (dwFileSize == INVALID_FILE_SIZE) {
		DEBUGPRINTF ((TEXT ("GetFileSize failed (%d)\n"), (int)GetLastError ())) ;
		goto	exit_func_4 ;
	}

	hJisyoMapping	= CreateFileMapping (hFile, NULL, PAGE_READONLY, 0, 0, NULL) ;
	if (hJisyoMapping == NULL) {
		DEBUGPRINTF ((TEXT ("CreateFileMapping failed (%d)\n"), (int)GetLastError ())) ;
		goto	exit_func_3 ;
	}
	pJisyoMapping	= MapViewOfFile (hJisyoMapping, FILE_MAP_READ, 0, 0, 0) ;
	if (pJisyoMapping == NULL) {
		DEBUGPRINTF ((TEXT ("MapViewOfFile failed (%d)\n"), (int)GetLastError ())) ;
		goto	exit_func_2 ;
	}

	pJisyo->m_hFile			= hFile ;
	pJisyo->m_hMapping		= hJisyoMapping ;
	pJisyo->m_pBuffer		= pJisyoMapping ;
	pJisyo->m_nBufferSize	= dwFileSize ;

	/* �����̕�����������@�����o����B*/
	nCheckBytes				= (dwFileSize < 4096)? dwFileSize : 4096 ;
	pJisyo->m_nCodingSystem	= DetectKanjiCodingSystem (pJisyo->m_pBuffer, nCheckBytes, NULL) ;
	pJisyo->m_lFormat		= 0 ;
	
	/* �����^�O���쐬����B*/
#if defined (DEBUG)
	dwFrom	= GetTickCount () ;
#endif
	if (TFAILED (skkSortedJisyo_makeTab (pJisyo))) {
		DEBUGPRINTF ((TEXT ("MakeTab failed\n"))) ;
		goto	exit_func_1 ;
	}
#if defined (DEBUG)
	dwTo	= GetTickCount () ;
	dwDiff	= (dwTo < dwFrom)? (dwTo + ((DWORD)-1 - dwFrom) + 1) : (dwTo - dwFrom) ;
	DEBUGPRINTF ((TEXT ("cost = %ld\n"), dwDiff)) ;
#endif
	return	pSkkJisyo ;

  exit_func_1:
	UnmapViewOfFile (pJisyoMapping) ;
  exit_func_2:
	CloseHandle (hJisyoMapping) ;
  exit_func_3:
	CloseHandle (hFile) ;
  exit_func_4:
	FREE (pSkkJisyo) ;
	return	NULL ;
	UNREFERENCED_PARAMETER (nCodingSystem) ;
}

BOOL
skkSortedJisyo_search (
	SkkJisyo*		pSkkJisyo,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	TVarbuffer*		pvbuf)
{
	SkkSortedJisyo*	pJisyo	= (SkkSortedJisyo *)(pSkkJisyo + 1) ;
	Char		cc ;
	long		lStartPosition ;
	long		lEndPosition ;
	int			iSearchStyle ;

	if (pKey == NULL || nKey <= 0 || Char_IsNul (*pKey))
		return	TRUE ;

	if (pJisyo->m_lFormat == 0){
		iSearchStyle	= 0 ;
	} else {
		iSearchStyle	= (nOkuriType != SEARCH_OKURI_NASHI)? 1 : 2 ;
	}
	cc	= *pKey ;
	if ((iSearchStyle == 0) || (iSearchStyle == 2)) {
		if (cc < MYCHAR_KANA_START){
			if (iSearchStyle == 0){
				lStartPosition	= 0 ;
			} else { 
				lStartPosition	= pJisyo->m_lFormat ;
			}
			lEndPosition	= pJisyo->m_jtab2 [0] ;
		} else if (cc > MYCHAR_KANA_END){
			lStartPosition	= pJisyo->m_jtab2 [AFTER_KANA] ;
			lEndPosition	= pJisyo->m_jtab2 [AFTER_KANA + 1] ;
		} else {
			lStartPosition	= pJisyo->m_jtab2 [cc - MYCHAR_KANA_START] ;
			lEndPosition	= pJisyo->m_jtab2 [cc - MYCHAR_KANA_START + 1] ;
		} 
	} else {
		if (cc < MYCHAR_KANA_START) {
			lStartPosition	= pJisyo->m_jtab1 [AFTER_KANA] ;
			lEndPosition	= pJisyo->m_jtab1 [AFTER_KANA + 1] ;
		} else if (cc > MYCHAR_KANA_END){
			lStartPosition	= 0 ;
			lEndPosition	= pJisyo->m_jtab1 [0] ;
		} else {
			lStartPosition	= pJisyo->m_jtab1[MYCHAR_KANA_END - cc] ;
			lEndPosition	= pJisyo->m_jtab1[MYCHAR_KANA_END - cc + 1] ;
		}
	}
	return	skkSortedJisyo_searchRange (pJisyo, pKey, nKey, iSearchStyle, lStartPosition, lEndPosition, pvbuf) ;
	UNREFERENCED_PARAMETER (pOkurigana) ;
	UNREFERENCED_PARAMETER (nOkurigana) ;
}

BOOL
skkSortedJisyo_destroy (
	register SkkJisyo*	pSkkJisyo)
{
	register SkkSortedJisyo*	pJisyo ;

	if (pSkkJisyo == NULL) 
		return	TRUE ;

	pJisyo	= (SkkSortedJisyo*)(pSkkJisyo + 1) ;
	if (pJisyo->m_pBuffer != NULL) {
		UnmapViewOfFile (pJisyo->m_pBuffer) ;
		pJisyo->m_pBuffer		= NULL ;
		pJisyo->m_nBufferSize	= 0 ; 
	}
	if (pJisyo->m_hMapping != NULL) {
		CloseHandle (pJisyo->m_hMapping) ;
		pJisyo->m_hMapping		= NULL ;
	}
	if (pJisyo->m_hFile != INVALID_HANDLE_VALUE) {
		CloseHandle (pJisyo->m_hFile) ;
		pJisyo->m_hFile			= INVALID_HANDLE_VALUE ;
	}
	FREE (pSkkJisyo) ;
	return	TRUE ;
}

LPCTSTR
skkSortedJisyo_getPath	(
	register SkkJisyo*		pSkkJisyo)
{
	register SkkSortedJisyo*	pJisyo	= (SkkSortedJisyo *)(pSkkJisyo + 1) ;

	return	pJisyo->m_tszPath ;
}

/*========================================================================
 *	private functions
 */

static	Char	kanjiReader_getChar (struct KanjiReader* pReader, const unsigned char** pSrc, const unsigned char* pSrcEnd) ;

static	BOOL	kanjiReader_initialize (
	struct KanjiReader*		pReader,
	int						iCodingSystem)
{
	InitializeKanjiFiniteStateMachine (&pReader->m_KSM, iCodingSystem) ;
	pReader->m_iUsage	= 0 ;
	return	TRUE ;
}

static	void	kanjiReader_reset (
	struct KanjiReader*		pReader)
{
	RestartKanjiFiniteStateMachine (&pReader->m_KSM) ;
	pReader->m_iUsage	= 0 ;
	return ;
}

static	Char	kanjiReader_getChar (
	struct KanjiReader*		pReader,
	const unsigned char**	ppSrc,
	const unsigned char*	pSrcEnd)
{
	Char		wch		= KEOF ;
	int			n		= 0 ;
	const unsigned char*	pSrc ;

	if (pReader->m_iUsage > 0) {
		wch	= pReader->m_buf [0] ;
		pReader->m_iUsage	-- ;
		if (pReader->m_iUsage > 0) 
			memmove (pReader->m_buf, pReader->m_buf + 1, pReader->m_iUsage * sizeof (Char)) ;
		return	wch ;
	}
	pSrc	= *ppSrc ;
	while (pSrc < pSrcEnd) {
		n	= TransferKanjiFiniteStateMachine (&pReader->m_KSM, (unsigned char)*pSrc ++, pReader->m_buf) ;
		if (n > 0) {
			break ;
		}
	}
	if (n <= 0) {
		n	= TransferKanjiFiniteStateMachine (&pReader->m_KSM, -1, pReader->m_buf) ;
		if (n <= 0) {
			*ppSrc	= pSrc ;
			return	KEOF ;
		}
	}
	wch	= pReader->m_buf [0] ;
	n	-- ;
	pReader->m_iUsage	= n ;
	if (n > 0) 
		memmove (pReader->m_buf, pReader->m_buf + 1, n * sizeof (Char)) ;
	*ppSrc	= pSrc ;
	return	wch ;
}

BOOL
skkSortedJisyo_makeTab (
	SkkSortedJisyo*		pJisyo)
{
	const unsigned char*	pBuffer ;
	const unsigned char*	pBufferEnd ;
	int						nBuffer ;
	const char*				pMYSTR1	= MYSTR1 ;
	const char*				ptr ;
	Char				cc ;
	struct KanjiReader	kr ;

	pBuffer		= (const unsigned char*)pJisyo->m_pBuffer ;
	nBuffer		= pJisyo->m_nBufferSize ;
	pBufferEnd	= pBuffer + nBuffer ;

	kanjiReader_initialize (&kr, pJisyo->m_nCodingSystem) ;
  again:
	ptr			= pMYSTR1 ;
	cc			= KEOF ;
	while (*ptr != '\0') {
		cc	= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
		if (cc == KEOF || cc == EOL || Char_DifferenceAscii (cc, *ptr)) 
			break ;
		ptr	++ ;
	}
	if (cc == KEOF) {
		DEBUGPRINTF ((TEXT ("makeTab: MYSTR1 not found\n"))) ;
		return	FALSE ;
	}
	if (*ptr == '\0') {
		do {
			cc	= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
		}	while (cc != KEOF && cc != EOL) ;

		if (cc != EOL) 
			return	FALSE ;
		skkSortedJisyo_makeNewTab (pJisyo, pBuffer - (const unsigned char*)pJisyo->m_pBuffer) ;
	} else if ((ptr - pMYSTR1) >= 2) {
		/*	�R�����g�����͈�v�����B
		 */
		if (cc != EOL) {
			while (cc = kanjiReader_getChar (&kr, &pBuffer, pBufferEnd), cc != KEOF) {
				if (cc == EOL)
					break ;
			}
		}
		kanjiReader_reset (&kr) ;
		goto	again ;
	} else {
		/*	����ȊO�B
		 *		- �� + �R�����g(';'�ł͂��܂�ȉ��s���܂�)
		 *	�͋����B
		 */
		if ((ptr - pMYSTR1) == 1 || cc == '\t' || cc == ' ') {
			/* �󔒂����̍s�Ȃ�󔒂̊Ԃ͓ǂݔ�΂��B*/
			if (cc == '\t' || cc == ' ') {
				while (cc = kanjiReader_getChar (&kr, &pBuffer, pBufferEnd), cc != KEOF) {
					if (cc == EOL || (cc != '\t' && cc != ' ') || cc == ';')
						break ;
				}
			}
			/* �s���܂œǂݔ�΂��B*/
			if ((ptr - pMYSTR1) == 1 || cc == ';') {
				while (cc = kanjiReader_getChar (&kr, &pBuffer, pBufferEnd), cc != KEOF) {
					if (cc == EOL)
						break ;
				}
			}
		}
		if (cc != EOL) {
			DEBUGPRINTF ((TEXT ("makeTab: old jisyo tab?\n"))) ;
			return	FALSE ;
		}
		kanjiReader_reset (&kr) ;
		goto	again ;
		/*
		DEBUGPRINTF ((TEXT ("*ptr=%d, (ptr - MYSTR1)=%d\n"), (int)*ptr, (int)(ptr - pMYSTR1))) ;
#if 0
		skkSortedJisyo_makeOldTab (pJisyo) ;
#endif
		DEBUGPRINTF ((TEXT ("makeTab: old jisyo tab?\n"))) ;
		return	FALSE ;
		*/
	}
	return	TRUE ;
}

#if 0
BOOL	j_make_old_jisyo_tab (
	register SkkSortedJisyo*	pJisyo,
	register unsigned char*		pString)
{
	long*	pjtab ;
	int		c ;					/* one character */
	int		code ;				/* compared code */
	int		target ;			/* target code (2 bytes) */
	long	lFilePos ;

	pjtab		= lpJisyo->m_jtab2 ;
	code		= KANA_START ;
	target		= (*pString & 0xff) << 8 ;
	target		|= *++pString & 0xff ;

	while (target >= code && code <= KANA_END){
		*pjtab	++	= 0 ;
		code	++ ;
	}
    
	while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
		target		= ((c & 0xff) << 8) | (winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile)) & 0xff) ;
		lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
		while (target >= code && code <= KANA_END) {
			*pjtab	++	= lFilePos - 2 ;
			code	++ ;
		}
		while ((c = winfgetc ((LPWINFILE)&(lpJisyo->m_JisyoFile))) != EOF){
			if (c == EOL)
				break ;
			if (code > KANA_END) {
				lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
				*pjtab	++	= lFilePos ;
				code	++ ;
				break;
			}
		}
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	while (code <= KANA_END + 1) {
		*pjtab	++ = lFilePos ;
		code	++ ;
	}
	lFilePos	= winftell ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	*pjtab		= lFilePos ;		/* size of jisyo */
	winrewind ((LPWINFILE)&(lpJisyo->m_JisyoFile)) ;
	return	TRUE ;
}
#endif

BOOL
skkSortedJisyo_makeNewTab (
	SkkSortedJisyo*		pJisyo,
	int					iStartPosition)
{
	const char*	ptr ;
	const unsigned char*	pBufferTop ;
	const unsigned char*	pBuffer ;
	const unsigned char*	pBufferEnd ;
	Char			cc ;
	Char			code ;			/* compared code */
	Char			target ;		/* target code (2 bytes) */
	long*			pjtab ;
	long			lPosition ;
	struct KanjiReader		kr ;

	pjtab		= pJisyo->m_jtab1 ;
	code		= MYCHAR_KANA_END ;

	pBufferTop	= (const unsigned char*)pJisyo->m_pBuffer ;
	pBuffer		= pBufferTop + iStartPosition ;
	pBufferEnd	= pBufferTop + pJisyo->m_nBufferSize ;

	lPosition	= 0 ;
	kanjiReader_initialize (&kr, pJisyo->m_nCodingSystem) ;

	while (TRUE) {
		lPosition	= pBuffer - pBufferTop ;
		/*	�s���̂P�����𔲂��o���B*/
		cc			= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
		if (cc == KEOF)
			break;

		/*	�s�����R�����g�̊J�n���Ӗ�����Z�~�R�������H */
		if (!Char_DifferenceAscii (cc, ';')){
			/*	�����P�������X�ɃZ�~�R�������ǂ����`�F�b�N����B*/
			cc		= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
			if (cc == ';'){
				/*	���̏ꍇ�ɂ͑��艼���������̊J�n�ʒu���ǂ�����
				 *	�`�F�b�N����B*/
				ptr	= MYSTR2 ;
				while (*ptr != '\0') {
					cc		= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
					if (cc == KEOF || cc == EOL || Char_DifferenceAscii (cc, *ptr))
						break ;
					ptr	++ ;
				}
				if (*ptr == '\0') {
					do {
						cc	= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
					}	while (cc != KEOF && cc != EOL) ;
					break ;
				}

				/*	���艼���������̊J�n�ʒu�ł͖��������̂ŁA
				 *	���̍s�͖�������B*/
				while (pBuffer < pBufferEnd && *pBuffer != EOL)
					pBuffer	++ ;
				while (pBuffer < pBufferEnd && *pBuffer == EOL)
					pBuffer	++ ;
				kanjiReader_reset (&kr) ;
				continue ;
			}
		}
		/*	���̉������� �` code �܂ł̃^�O�����݂̍s���ɐݒ肷��B*/
		target	= cc ;
#if defined (DEBUG)
		if (target <= code && MYCHAR_KANA_START <= code) {
			DEBUGPRINTF ((TEXT ("target(%lx), code(%lx) <= position(%ld)\n"), 
						 target, code, lPosition)) ;
		}
#endif
		if (target < MYCHAR_KANA_START) {
			while ((MYCHAR_KANA_START - 1) <= code) {
				*pjtab	++	= lPosition ;
				code	-- ;
			}
		} else {
			while (target <= code && MYCHAR_KANA_START <= code){ 
				*pjtab	++	= lPosition ;
				code	-- ;
			}
		}
		/*	�s���܂ŃX�L�b�v����B*/
		while (pBuffer < pBufferEnd && *pBuffer != EOL)
			pBuffer	++ ;
		while (pBuffer < pBufferEnd && *pBuffer == EOL)
			pBuffer	++ ;
		kanjiReader_reset (&kr) ;
	}
#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("0x%0x <= code <= 0x%lx <= position(%ld)\n"), MYCHAR_KANA_START-1, code, lPosition)) ;
#endif
	lPosition	= pBuffer - pBufferTop ;
	while (code >= MYCHAR_KANA_START - 1) {
		*pjtab	++	= lPosition ;
		code	-- ;
	}
	*pjtab				= lPosition ;
	pJisyo->m_lFormat	= lPosition ;

	pjtab	= pJisyo->m_jtab2 ;
	code	= MYCHAR_KANA_START ;
	kanjiReader_reset (&kr) ;

	for ( ; ; ){
		lPosition	= pBuffer - pBufferTop ;

		/*	�s���̂P�����𔲂��o���B*/
		cc	= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
		if (cc == KEOF)
			break ;

		target	= cc ;
		while (code <= target && code <= MYCHAR_KANA_END) { 
			*pjtab	++	= lPosition ;
			code	++ ;
		}

		/*	�s���܂ŃX�L�b�v����B*/
		while (pBuffer < pBufferEnd && *pBuffer != EOL)
			pBuffer	++ ;
		while (pBuffer < pBufferEnd && *pBuffer == EOL)
			pBuffer	++ ;
		kanjiReader_reset (&kr) ;

		if (code > MYCHAR_KANA_END){
			lPosition	= pBuffer - pBufferTop ;
			*pjtab	++	= lPosition ;
			code	++ ;
			break ;
		}
	}
	lPosition	= pBuffer - pBufferTop ;
	while (code <= MYCHAR_KANA_END + 1) {
		*pjtab	++	= lPosition ;
		code	++ ;
	}
	*pjtab		= pBuffer - pBufferTop ;
	return	TRUE ;
}

BOOL
skkSortedJisyo_searchRange (
	register SkkSortedJisyo*	pJisyo,
	register const Char*		pKey,
	register int				nKey,
	register int				iSearchStyle,
	register long				lStartPosition,
	register long				lEndPosition,
	register TVarbuffer*		pvbuf)
{
	struct KanjiReader		kr ;
	const Char*				ptr ;
	int						nptr ;
	Char					cc ;
	const unsigned char*	pBuffer ;
	const unsigned char*	pBufferEnd ;

	if (lStartPosition >= lEndPosition || lStartPosition >= pJisyo->m_nBufferSize)
		return	TRUE ;

	cc			= '\0' ;
	pBuffer		= (const unsigned char*)pJisyo->m_pBuffer + lStartPosition ;
	pBufferEnd	= (const unsigned char*)pJisyo->m_pBuffer + lEndPosition ;

	kanjiReader_initialize (&kr, pJisyo->m_nCodingSystem) ;
	while (pBuffer < pBufferEnd) {
		ptr		= pKey ;
		nptr	= nKey ;
		while (nptr > 0) {
			cc	= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
			if (cc == KEOF || *ptr != cc || cc == ' ' || cc == EOL)
				break ;
			ptr	 ++ ;
			nptr -- ;
		}
		if (cc == KEOF)
			break ;

		if (nptr == 0) {
			cc	= kanjiReader_getChar (&kr, &pBuffer, pBufferEnd) ;
			if (cc == ' ') 
				return	skkSortedJisyo_find (&kr, pBuffer, pBufferEnd, pvbuf) ;
		}
		if (skkSortedJisyo_compare (*ptr, cc, iSearchStyle))
			break ; 

		while (pBuffer < pBufferEnd && *pBuffer != EOL)
			pBuffer	++ ;
		while (pBuffer < pBufferEnd && *pBuffer == EOL)
			pBuffer ++ ;
		kanjiReader_reset (&kr) ;
	}
	return	TRUE ;
}

int
skkSortedJisyo_compare (
	register Char	c1,
	register Char	c2,
	register int	f)
{
	if (c1 == ' ' || c1 == '\n')
		c1	= 0 ;
	if (c2 == ' ')
		c2	= 0 ;
	if (f != 1) {
		return	(c1 < c2) ;
	} else {
		return	(c1 > c2) ;
	}
}

BOOL
skkSortedJisyo_find (
	struct KanjiReader*		pKR,
	const unsigned char*	pJisyoBuffer,
	const unsigned char*	pJisyoBufferEnd,
	TVarbuffer*				pvbuf)
{
	Char			szBuffer [BUFSIZE] ;
	Char*			pDest ;
	const Char*		pDestEnd ;
	Char			cc, chPrev ;
	BOOL			bDuringAnnotation ;

	pDest				= szBuffer ;
	pDestEnd			= szBuffer + ARRAYSIZE (szBuffer) ;
	chPrev				= '\0' ;
	bDuringAnnotation	= FALSE ;

	while (TRUE) {
		cc	= kanjiReader_getChar (pKR, &pJisyoBuffer, pJisyoBufferEnd) ;

		/*	����ϊ������Ȃ��̂ŁA'[' �ȍ~�͖������Ȃ���΂Ȃ�Ȃ��B���Aannotated �Ȏ����̏ꍇ
		 *	���߂� '[' �����p����邱�Ƃ����肦��B[�L�F����17�N2��14��(��)]
		 */
		switch (cc) {
			case	EOL:
			case	KEOF:
				goto	exit_loop ;
			case	'[':
				if (chPrev == '/' && ! bDuringAnnotation)
					goto	exit_loop ;
				break ;
			case	'/':
				bDuringAnnotation	= FALSE ;
				break ;
			case	';':
				if (! bDuringAnnotation)
					bDuringAnnotation	= TRUE ;
				break ;
			default:
				break ;
		}
		if (pDest >= pDestEnd) {
			if (TFAILED (TVarbuffer_Add (pvbuf, szBuffer, BUFSIZE)))
				return	FALSE ;
			pDest	= szBuffer ;
		}
		*pDest ++	= cc ;
		chPrev		= cc ;
	}
exit_loop:
	if (pDest > szBuffer) 
		if (TFAILED (TVarbuffer_Add (pvbuf, szBuffer, pDest - szBuffer)))
			return	FALSE ;
	return	TRUE ;
}

