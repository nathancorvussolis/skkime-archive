#if !defined (sortedjisyo_h)
#define	sortedjisyo_h

#include "varbuffer.h"
#include "Char.h"
#include "kfile.h"

#define KANAMOJI		(100)

typedef struct tagSkkSortedJisyo {
	TCHAR						m_tszPath [PATH_MAX + 1] ;
	int							m_nCodingSystem ;
	HANDLE						m_hFile ;
	HANDLE						m_hMapping ;
	void*						m_pBuffer ;
	size_t						m_nBufferSize ;
	long						m_lFormat ;
	long						m_jtab1 [KANAMOJI] ;
	long						m_jtab2 [KANAMOJI] ;
	struct tagSkkSortedJisyo*	m_pNext ;
}	SkkSortedJisyo ;

/*	prototypes */
SkkJisyo*	SkkSortedJisyo_Create	(const Char*, int, int) ;
SkkJisyo*	SkkSortedJisyo_CreateT	(LPCTSTR, int) ;

#endif

