#pragma once

#include <tchar.h>
#include "Char.h"

#if !defined (DEBUG_LV)
#define	DEBUG_LV	(103)
#endif

#if defined (__cplusplus)
extern "C" {
#endif
void	DebugPrintf			(LPCTSTR, ...) ;
void	DebugPrintfToFile	(LPCTSTR, ...) ;
int		ConvertCStrToTStr	(const Char*, int, LPTSTR, int) ;
#if defined (__cplusplus)
}
#endif

#if defined (DEBUG)
#define	ASSERT(expression)			assert(expression)
#define	DEBUGPRINTF(arg)			DebugPrintfToFile##arg
#define	DEBUGPRINTFEX(level,arg)	DebugPrintfToFile##arg
//if((level) >= DEBUG_LV) DebugPrintfToFile##arg
#else
#define	ASSERT(expression)			/* expression */
#define	DEBUGPRINTF(arg)			/* arg */
#define	DEBUGPRINTFEX(level,arg)	/* level arg */
#endif


