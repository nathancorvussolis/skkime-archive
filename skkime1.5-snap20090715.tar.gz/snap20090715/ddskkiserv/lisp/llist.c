/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lispmgrp.h"

#define	lispEntity_GetConsPtr(ptr)	((TLispConscell *)((TLispEntity *)(ptr) + 1))

BOOL
lispMgr_CreateConscell (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntCar,
	register TLispEntity*			pEntCdr,
	register TLispEntity** const	ppEntReturn)
{
	TLispEntity*			pEntity ;
	register TLispConscell*	pConscell ;

	assert (pLispMgr    != NULL) ;
	assert (pEntCar     != NULL) ;
	assert (pEntCdr     != NULL) ;
	assert (ppEntReturn != NULL) ;

#if defined (DEBUG_LV99)
	fprintf (stderr, "Garbage collecting ...") ;
	fflush (stderr) ;
	lispMgr_CollectGarbage (pLispMgr) ;
	fprintf (stderr, "done.\n") ;
#endif	
	if (TFAILED (lispMgr_AllocateEntity (pLispMgr, sizeof (TLispConscell), &pEntity)))
		return	FALSE ;
		
	pEntity->m_iType		= LISPENTITY_CONSCELL ;
	pEntity->m_lReferCount	= 0 ;	/* �쐬����͎Q�ƃJ�E���^�� 0�B*/
	pConscell				= lispEntity_GetConsPtr (pEntity) ;
	pConscell->m_pCar		= pEntCar ;
	pConscell->m_pCdr		= pEntCdr ;
	lispMgr_RegisterMisc (pLispMgr, pEntity) ;

	*ppEntReturn	= pEntity ;
	return	TRUE ;
}

BOOL
lispMgr_CreateList (
	register TLispManager*			pLispMgr,
	register TLispEntity** 			ppEntities,
	register int					nEntities,
	register TLispEntity** const	ppEntReturn)
{
	TLispEntity*			pNil ;
	TLispEntity*			pListTop ;
	register TLispEntity*	pListLast ;
	TLispEntity*			pNode ;

	assert (pLispMgr != NULL) ;
	assert ((nEntities >  0 && ppEntities != NULL) ||
			(nEntities == 0 && ppEntities == NULL)) ;
	assert (ppEntReturn != NULL) ;

	(void) lispMgr_CreateNil (pLispMgr, &pNil) ;
	if (nEntities > 0) {
		if (TFAILED (lispMgr_CreateConscell (pLispMgr, *ppEntities ++, pNil, &pListTop)))
			return	FALSE ;
		nEntities	-- ;

		lispEntity_AddRef (pLispMgr, pListTop) ;
		pListLast	= pListTop ;
		while (nEntities > 0) {
			if (TFAILED (lispMgr_CreateConscell (pLispMgr, *ppEntities, pNil, &pNode))) {
				lispEntity_Release (pLispMgr, pListTop) ;
				return	FALSE ;
			}
			lispEntity_SetCdr (pLispMgr, pListLast, pNode) ;
			pListLast	= pNode ;
			ppEntities	++ ;
			nEntities	-- ;
		}
		*ppEntReturn	= pListTop ;
		lispEntity_Release (pLispMgr, pListTop) ;
	} else {
		*ppEntReturn	= pNil ;
	}
	return	TRUE ;
}

BOOL
lispEntity_PlistGet (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntPlist,
	register TLispEntity*			pEntProperty,
	register TLispEntity** const	ppEntRetval)
{
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntCdr ;
	TLispEntity*	pEntRetval ;

	if (TFAILED (lispEntity_Consp (pLispMgr, pEntPlist))) 
		return	FALSE ;

	lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntPlist))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntPlist, &pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntPlist, &pEntCdr)) ||
			TFAILED (lispEntity_Consp  (pLispMgr, pEntCdr)))
			return	FALSE ;
		if (TSUCCEEDED (lispEntity_Eq (pLispMgr, pEntCar, pEntProperty))) {
			lispEntity_GetCar (pLispMgr, pEntCdr, &pEntRetval) ;
			break ;
		}
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntCdr, &pEntCdr)))
			return	FALSE ;
		pEntPlist	= pEntCdr ;
	}
	*ppEntRetval	= pEntRetval ;
	return	TRUE ;
}

BOOL
lispEntity_PlistPut (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntPlist,
	register TLispEntity*			pEntProperty,
	register TLispEntity*			pEntValue,
	register TLispEntity** const	ppEntRetval)
{
	TLispEntity*	pEntNewPlist ;
	TLispEntity*	apEntities [2] ;

	if (TSUCCEEDED (lispEntity_Consp (pLispMgr, pEntPlist))) {
		register TLispEntity*	pEntNode ;
		TLispEntity*	pEntNewTail ;
		TLispEntity*	pEntCar ;
		TLispEntity*	pEntCdr ;

		pEntNode	= pEntPlist ;
		while (TFAILED (lispEntity_Nullp (pLispMgr, pEntNode))) {
			if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntNode, &pEntCar)) ||
				TFAILED (lispEntity_GetCdr  (pLispMgr, pEntNode, &pEntCdr)) ||
				TFAILED (lispEntity_Consp   (pLispMgr, pEntCdr)))
				return	FALSE ;
			if (TSUCCEEDED (lispEntity_Eq (pLispMgr, pEntCar, pEntProperty))) {
				lispEntity_SetCar (pLispMgr, pEntCdr, pEntValue) ;
				*ppEntRetval	= pEntPlist ;
				return	TRUE ;
			}
			if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntCdr, &pEntCdr)))
				return	FALSE ;
			pEntNode	= pEntCdr ;
		}
		apEntities [0]	= pEntProperty ;
		apEntities [1]	= pEntValue ;
		if (TFAILED (lispMgr_CreateList (pLispMgr, apEntities, 2, &pEntNewTail)))
			return	FALSE ;

		/*	list �̍Ō�ɉ�����B*/
		pEntNode	= pEntPlist ;
		while (TSUCCEEDED (lispEntity_GetCdr (pLispMgr, pEntNode, &pEntCdr)) &&
			   TFAILED (lispEntity_Nullp  (pLispMgr, pEntCdr)))
			pEntNode	= pEntCdr ;
		if (TFAILED (lispEntity_SetCdr (pLispMgr, pEntNode, pEntNewTail)))
			return	FALSE ;
		*ppEntRetval	= pEntPlist ;
		return	TRUE ;
	} else {
		apEntities [0]	= pEntProperty ;
		apEntities [1]	= pEntValue ;
		if (TFAILED (lispMgr_CreateList (pLispMgr, apEntities, 2, &pEntNewPlist)))
			return	FALSE ;
		*ppEntRetval	= pEntNewPlist ;
		return	TRUE ;
	}
}

BOOL
lispEntity_CopyList (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntList,
	register TLispEntity** const	ppEntRetval)
{
	register TLispEntity*	pEntHead ;
	register TLispEntity*	pEntTail ;
	TLispEntity*			pEntNewTail ;
	TLispEntity*			pEntNil ;
	TLispEntity*			pEntCar ;
	TLispEntity*			pEntCdr ;

	pEntHead	= NULL ;
	pEntTail	= NULL ;
	lispMgr_CreateNil (pLispMgr, &pEntNil) ;

	if (TFAILED (lispEntity_GetCar (pLispMgr, pEntList, &pEntCar)) ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntCdr))) 
		return	FALSE ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntCar, pEntNil, &pEntNewTail)))
		return	FALSE ;
	pEntHead	= pEntNewTail ;
	pEntTail	= pEntNewTail ;
	lispEntity_AddRef (pLispMgr, pEntHead) ;
	pEntList	= pEntCdr ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntList, &pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntCdr))) 
			goto	error ;
		lispEntity_SetCdr (pLispMgr, pEntTail, pEntNewTail) ;
		pEntTail	= pEntNewTail ;
		pEntList	= pEntCdr ;
	}
	*ppEntRetval	= pEntHead ;
	lispEntity_Release (pLispMgr, pEntHead) ;
	return	TRUE ;

  error:
	lispEntity_Release (pLispMgr, pEntHead) ;
	return	FALSE ;
}

BOOL
lispEntity_GetCar (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntity, 
	register TLispEntity** const	ppRetvalue)
{
	TLispConscell*	pConscell ;

	assert (pLispMgr   != NULL) ;
	assert (pEntity    != NULL) ;
	assert (ppRetvalue != NULL) ;

	if (lispEntity_Nullp (pLispMgr, pEntity)) 
		return	lispMgr_CreateNil (pLispMgr, ppRetvalue) ;

	if (pEntity->m_iType != LISPENTITY_CONSCELL)
		return	FALSE ;

	pConscell	= lispEntity_GetConsPtr (pEntity) ;
	*ppRetvalue	= pConscell->m_pCar ;
	return	TRUE ;
}

BOOL
lispEntity_GetCdr (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntity,
	register TLispEntity** const	ppRetvalue)
{
	register TLispConscell*	pConscell ;

	assert (pLispMgr   != NULL) ;
	assert (pEntity    != NULL) ;
	assert (ppRetvalue != NULL) ;

	if (lispEntity_Nullp (pLispMgr, pEntity)) 
		return	lispMgr_CreateNil (pLispMgr, ppRetvalue) ;

	if (pEntity->m_iType != LISPENTITY_CONSCELL)
		return	FALSE ;

	pConscell	= lispEntity_GetConsPtr (pEntity) ;
	*ppRetvalue	= pConscell->m_pCdr ;
	return	TRUE ;
}

BOOL
lispEntity_GetCadr (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntity,
	register TLispEntity** const	ppRetvalue)
{
	TLispEntity*	pCDR ;
	TLispEntity*	pCADR ;
	
	if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pCDR)) ||
		TFAILED (lispEntity_GetCar (pLispMgr, pCDR,    &pCADR)))
		return	FALSE ;
	*ppRetvalue	= pCADR ;
	return	TRUE ;
}

BOOL
lispEntity_GetCaar (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntity,
	register TLispEntity** const	ppRetvalue)
{
	TLispEntity*	pCAR ;
	TLispEntity*	pCAAR ;
	
	if (TFAILED (lispEntity_GetCar (pLispMgr, pEntity, &pCAR)) ||
		TFAILED (lispEntity_GetCar (pLispMgr, pCAR,    &pCAAR)))
		return	FALSE ;
	*ppRetvalue	= pCAAR ;
	return	TRUE ;
}

BOOL
lispEntity_GetCaddr (
	register TLispManager*			pLispMgr,
	register TLispEntity*			pEntity,
	register TLispEntity** const	ppRetvalue)
{
	TLispEntity*	pCDR ;
	TLispEntity*	pCDDR ;
	TLispEntity*	pCADDR ;
	
	if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pCDR))  ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pCDR,    &pCDDR)) ||
		TFAILED (lispEntity_GetCar (pLispMgr, pCDDR,   &pCADDR)))
		return	FALSE ;
	*ppRetvalue	= pCADDR ;
	return	TRUE ;
}

BOOL
lispEntity_GetCddr (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispEntity** const ppRetvalue)
{
	TLispEntity*	pCDR ;
	TLispEntity*	pCDDR ;
	
	if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pCDR)) ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pCDR,    &pCDDR)))
		return	FALSE ;
	*ppRetvalue	= pCDDR ;
	return	TRUE ;
}

BOOL
lispEntity_SetCar (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispEntity*	pCar)
{
	register TLispConscell*	pConscell ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pCar     != NULL) ;

	if (pEntity->m_iType != LISPENTITY_CONSCELL)
		return	FALSE ;

	pConscell			= lispEntity_GetConsPtr (pEntity) ;
	pConscell->m_pCar	= pCar ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispEntity_SetCdr (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispEntity*	pCdr)
{
	register TLispConscell*	pConscell ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pCdr     != NULL) ;

	if (pEntity->m_iType != LISPENTITY_CONSCELL)
		return	FALSE ;

	pConscell			= lispEntity_GetConsPtr (pEntity) ;
	pConscell->m_pCdr	= pCdr ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispEntity_CountArgument (
	register TLispManager*	pLispMgr,
	TLispEntity*			pEntity,
	int*					pnCount)
{
	register int		nArgument ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ; 
	assert (pnCount  != NULL) ;

	nArgument	= 0 ;
	while (!lispEntity_Nullp (pLispMgr, pEntity)) {
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pEntity)) ||
			pEntity == NULL)
			return	FALSE ;
		nArgument	++ ;
	}
	*pnCount	= nArgument ;
	return	TRUE ;
}

BOOL
lispEntity_Push2List (
	register TLispManager*	pLispMgr,
	register TLispConscell*	pList,
	register TLispEntity*	pEntElement)
{
	register TLispEntity*	pEntNil ;
	TLispEntity*			pEntNode ;

	pEntNil	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_NIL) ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntElement, pEntNil, &pEntNode)))
		return	FALSE ;
	if (pList->m_pCar == NULL) {
		pList->m_pCar	= pEntNode ;
		pList->m_pCdr	= pEntNode ;
		lispEntity_AddRef (pLispMgr, pEntNode) ;
	} else {
		lispEntity_SetCdr (pLispMgr, pList->m_pCdr, pEntNode) ;
		pList->m_pCdr	= pEntNode ;
	}
	return	TRUE ;
}

