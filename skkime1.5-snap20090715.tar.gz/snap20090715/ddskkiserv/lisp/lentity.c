/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include <stdarg.h>
#include "lispmgrp.h"
#include "cstring.h"
#include "kanji.h"

#define	TEMPBUFSIZE	(1024)

static	BOOL	lispEntity_princStr			(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrInteger	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrFloat	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrSymbol	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrString	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrConscell	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrVector	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrMarker	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrBuffer	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrSubr		(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_princStrRest		(TLispManager*, LPCTSTR, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_print		(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printInteger	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printFloat	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printSymbol	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printString	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printConscell(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printVector	(TLispManager*r, TLispEntity*) ;
static	BOOL	lispEntity_printMarker	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printBuffer	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printWindow	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printFrame	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printSubr	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printIMClient(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printMutex   (TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printXEvent  (TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printEmpty	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_printVoid	(TLispManager*, TLispEntity*) ;
static	BOOL	lispEntity_formatString	(TLispManager*, TLispEntity*, int, TVarbuffer*) ;
static	BOOL	lispEntity_formatChar	(TLispManager*, TLispEntity*, TVarbuffer*) ;
static	BOOL	lispEntity_formatNumber	(TLispManager*, TLispEntity*, const Char*, int, const BOOL, TVarbuffer*) ;
static	BOOL	lispEntity_formatNumberA	(TLispManager*, TLispEntity*, LPCTSTR, int, const BOOL, TVarbuffer*) ;
static	BOOL	lispEntity_formatNumberCommon	(TLispManager*, TLispEntity*, LPCTSTR, const BOOL, TVarbuffer*) ;
static	BOOL	lispEntity_copyConscell	(TLispManager*, TLispEntity*, TLispEntity**) ;
static	BOOL	lispEntity_copyVector	(TLispManager*, TLispEntity*, TLispEntity**) ;

/*=======
 */
BOOL
lispEntity_GetType (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register int*			piType)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (piType   != NULL) ;

	*piType	= pEntity->m_iType ; 
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispEntity_AddRef (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (0 <= pEntity->m_iType && pEntity->m_iType < MAX_LISPENTITY_TYPE) ;
	assert (pEntity->m_lReferCount >= 0) ;

	pEntity->m_lReferCount	++ ;
	assert (pEntity->m_lReferCount >= 0) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispEntity_Release (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (0 <= pEntity->m_iType && pEntity->m_iType < MAX_LISPENTITY_TYPE) ;
	assert (pEntity->m_lReferCount > 0) ;

	pEntity->m_lReferCount	-- ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

	TLispEntity*
lispMgr_GetReservedEntity (
	register TLispManager*			pLispMgr,
	register int					nIndex)
{
	assert (pLispMgr != NULL) ;
	assert (0 <= nIndex && nIndex < LISPMGR_SIZE_RESERVED) ;
	assert (pLispMgr->m_apEntReserved [nIndex] != NULL) ;
	return	pLispMgr->m_apEntReserved [nIndex] ;
}

BOOL
lispMgr_CreateNil (
	register TLispManager*			pLispMgr,
	register TLispEntity** const	ppEntReturn)
{
	assert (pLispMgr != NULL) ;
	assert (ppEntReturn != NULL) ;
	*ppEntReturn	= pLispMgr->m_apEntReserved [LISPMGR_INDEX_NIL] ;
	return	TRUE ;
}

BOOL
lispMgr_CreateT (
	register TLispManager*			pLispMgr,
	register TLispEntity** const	ppEntReturn)
{
	assert (pLispMgr != NULL) ;
	assert (ppEntReturn != NULL) ;
	*ppEntReturn	= pLispMgr->m_apEntReserved [LISPMGR_INDEX_T] ;
	return	TRUE ;
}

BOOL
lispMgr_CreateVoid (
	register TLispManager*			pLispMgr,
	register TLispEntity** const	ppEntReturn)
{
	assert (pLispMgr != NULL) ;
	assert (pLispMgr->m_pEntVoid != NULL) ;
	assert (ppEntReturn != NULL) ;
	
	*ppEntReturn	= pLispMgr->m_pEntVoid ;
	return	TRUE ;
}

BOOL
lispMgr_CreateEmpty (
	register TLispManager*			pLispMgr,
	register TLispEntity** const	ppEntReturn)
{
	assert (pLispMgr != NULL) ;
	assert (pLispMgr->m_pEntEmpty != NULL) ;
	assert (ppEntReturn != NULL) ;
	
	*ppEntReturn	= pLispMgr->m_pEntEmpty ;
	return	TRUE ;
}

BOOL
lispEntity_Nullp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	TLispEntity*	pNil ;

	(void) lispMgr_CreateNil (pLispMgr, &pNil) ;
	return	(pNil == pEntity)? TRUE : FALSE ;
}

BOOL
lispEntity_Symbolp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	int		iType ;
#if defined (DEBUG)
	BOOL	fResult ;
#endif
#if defined (DEBUG)
	fResult	= lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	assert (fResult == TRUE) ;
#else
	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
#endif
	return	(iType == LISPENTITY_SYMBOL)? TRUE : FALSE ;
}

BOOL
lispEntity_Integerp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	return	(pEntity->m_iType == LISPENTITY_INTEGER) ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispEntity_Floatp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	int		iType ;
#if defined (DEBUG)
	BOOL	fResult ;
#endif
#if defined (DEBUG)
	fResult	= lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	assert (fResult == TRUE) ;
#else
	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
#endif
	return	(iType == LISPENTITY_FLOAT)? TRUE : FALSE ;
}

BOOL
lispEntity_Markerp (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntity)
{
	int		iType ;
#if defined (DEBUG)
	BOOL	fResult ;
#endif
#if defined (DEBUG)
	fResult	= lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	assert (fResult == TRUE) ;
#else
	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
#endif
	return	(iType == LISPENTITY_MARKER)? TRUE : FALSE ;
}

BOOL
lispEntity_Numberp (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntity)
{
	return	(lispEntity_Floatp   (pLispMgr, pEntity) ||
			 lispEntity_Integerp (pLispMgr, pEntity)) ;
}

BOOL
lispEntity_IntegerOrMarkerp (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntity)
{
	return	(lispEntity_Integerp (pLispMgr, pEntity) ||
			 lispEntity_Markerp  (pLispMgr, pEntity)) ;
}

BOOL
lispEntity_Consp (
	register TLispManager*		pLispMgr,
	register TLispEntity*		pEntity)
{
	int		iType ;
#if defined (DEBUG)
	BOOL	fResult ;
#endif
#if defined (DEBUG)
	fResult	= lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	assert (fResult == TRUE) ;
#else
	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
#endif
	return	(iType == LISPENTITY_CONSCELL)? TRUE : FALSE ;
}

BOOL
lispEntity_Listp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	int	iType ;

	if (lispEntity_Nullp (pLispMgr, pEntity))
		return	TRUE ;

	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	return	(iType == LISPENTITY_CONSCELL)? TRUE : FALSE ;
}

BOOL
lispEntity_Stringp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	int		iType ;
#if defined (DEBUG)
	BOOL	fResult ;
#endif
#if defined (DEBUG)
	fResult	= lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	assert (fResult == TRUE) ;
#else
	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
#endif
	return	(iType == LISPENTITY_STRING)? TRUE : FALSE ;
}

BOOL
lispEntity_Vectorp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	int		iType ;
#if defined (DEBUG)
	BOOL	fResult ;
#endif
#if defined (DEBUG)
	fResult	= lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	assert (fResult == TRUE) ;
#else
	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
#endif
	return	(iType == LISPENTITY_VECTOR)? TRUE : FALSE ;
}

BOOL
lispEntity_Arrayp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	
	return	(lispEntity_Vectorp (pLispMgr, pEntity) ||
			 lispEntity_Stringp (pLispMgr, pEntity)) ;
}

/*
 *	Entity �� buffer �ł��邩�ǂ����𔻒肷��B
 */
BOOL
lispEntity_Bufferp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	int		iType ;
#if defined (DEBUG)
	BOOL	fResult ;
#endif
#if defined (DEBUG)
	fResult	= lispEntity_GetType (pLispMgr, pEntity, &iType) ;
	assert (fResult == TRUE) ;
#else
	(void) lispEntity_GetType (pLispMgr, pEntity, &iType) ;
#endif
	return	(iType == LISPENTITY_BUFFER)? TRUE : FALSE ;
}

BOOL
lispEntity_Sequencep (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	
	return	(lispEntity_Listp  (pLispMgr, pEntity) ||
			 lispEntity_Arrayp (pLispMgr, pEntity)) ;
}

BOOL
lispEntity_Eq (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pLeftEntity,
	register TLispEntity*	pRightEntity)
{
	assert (pLispMgr     != NULL) ;
	assert (pLeftEntity  != NULL) ;
	assert (pRightEntity != NULL) ;
	return	(pLeftEntity == pRightEntity)? TRUE : FALSE ;

	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispEntity_Tp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	TLispEntity*	pT ;

	lispMgr_CreateT (pLispMgr, &pT) ;
	return	(pT == pEntity)? TRUE : FALSE ;
}

BOOL
lispEntity_Voidp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pLispMgr->m_pEntVoid != NULL) ;
	return	(pEntity == pLispMgr->m_pEntVoid) ;
}

BOOL
lispEntity_Emptyp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;
	assert (pLispMgr->m_pEntEmpty != NULL) ;
	return	(pEntity == pLispMgr->m_pEntEmpty) ;
}

BOOL
lispEntity_GetLastElement (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntList,
	register TLispEntity**	ppEntRetval)
{
	TLispEntity*	pEntNextList ;

	assert (pLispMgr != NULL) ;
	assert (pEntList != NULL) ;
	assert (ppEntRetval != NULL) ;

	while (TSUCCEEDED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntNextList)) &&
		   TFAILED    (lispEntity_Nullp  (pLispMgr, pEntNextList)))
		pEntList	= pEntNextList ;
	*ppEntRetval	= pEntList ;
	return	TRUE ;
}

BOOL
lispEntity_Lambdap (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	return	lispEntity_Eq (pLispMgr, pEntity, lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_LAMBDA)) ;
}

BOOL
lispEntity_Macrop (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	return	lispEntity_Eq (pLispMgr, pEntity, lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_MACRO)) ;
}

BOOL
lispEntity_Optionalp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	return	lispEntity_Eq (pLispMgr, pEntity, lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_OPTIONAL)) ;
}

BOOL
lispEntity_Restp (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	return	lispEntity_Eq (pLispMgr, pEntity, lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_REST)) ;
}

/*
 *	LIST pEntList �� CAR �� pEntElt �� eq �ł���΁A���� CDR ��
 *	�Ԃ��B
 */
BOOL
lispEntity_Memq (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntElt,
	register TLispEntity*	pEntList,
	register TLispEntity**	ppEntRetval)
{
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntNextList ;

	assert (pLispMgr    != NULL) ;
	assert (pEntElt     != NULL) ;
	assert (pEntList    != NULL) ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntList, &pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntNextList)))
			return	FALSE ;
		if (TSUCCEEDED (lispEntity_Eq (pLispMgr, pEntElt, pEntCar))) 
			break ;
		pEntList	= pEntNextList ;
	}
	if (ppEntRetval != NULL)
		*ppEntRetval	= pEntList ;
	return	TRUE ;
}

BOOL
lispEntity_Member (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntElt,
	register TLispEntity*	pEntList,
	register TLispEntity**	ppEntRetval)
{
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntNextList ;

	assert (pLispMgr    != NULL) ;
	assert (pEntElt     != NULL) ;
	assert (pEntList    != NULL) ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntList, &pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntNextList)))
			return	FALSE ;
		if (TSUCCEEDED (lispEntity_Equal (pLispMgr, pEntElt, pEntCar))) 
			break ;
		pEntList	= pEntNextList ;
	}
	if (ppEntRetval != NULL)
		*ppEntRetval	= pEntList ;
	return	TRUE ;
}

BOOL
lispEntity_Rassoc (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntKey,
	register TLispEntity*	pEntList,
	register TLispEntity**	ppEntRetval)
{
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntCadr ;
	TLispEntity*	pEntNextList ;
	TLispEntity*	pEntRetval ;

	assert (pLispMgr    != NULL) ;
	assert (pEntKey     != NULL) ;
	assert (pEntList    != NULL) ;

	lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntList, &pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntNextList)))
			return	FALSE ;
		if (TSUCCEEDED (lispEntity_GetCdr (pLispMgr, pEntCar, &pEntCadr)) &&
			TSUCCEEDED (lispEntity_Equal  (pLispMgr, pEntKey, pEntCadr))) {
			pEntRetval	= pEntCar ;
			break ;
		}
		pEntList	= pEntNextList ;
	}
	if (ppEntRetval != NULL)
		*ppEntRetval	= pEntRetval ;
	return	TRUE ;
}

BOOL
lispEntity_Nconc (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntList,
	register TLispEntity**	ppEntRetval)
{
	TLispEntity*	pEntRetval ;
	TLispEntity*	pEntTail	= NULL ;
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntCdr ;

	assert (pLispMgr    != NULL) ;
	assert (pEntList    != NULL) ;
	assert (ppEntRetval != NULL) ;

	lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntList, &pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntCdr)))
			return	FALSE ;
		pEntList	= pEntCdr ;
		if (TFAILED (lispEntity_Nullp  (pLispMgr, pEntCar))) {
			pEntRetval	= pEntCar ;
			lispEntity_GetLastElement (pLispMgr,  pEntCar, &pEntTail) ;
			break ;
		}
	}
	if (pEntTail == NULL)
		return	FALSE ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntList))) {
		if (TFAILED (lispEntity_GetCar (pLispMgr, pEntList, &pEntCar)) ||
			TFAILED (lispEntity_Listp  (pLispMgr, pEntCar)) ||
			TFAILED (lispEntity_GetCdr (pLispMgr, pEntList, &pEntCdr)))
			return	FALSE ;
		if (TFAILED (lispEntity_Nullp  (pLispMgr, pEntCar))) {
			lispEntity_SetCdr (pLispMgr, pEntTail, pEntCar) ;
			lispEntity_GetLastElement (pLispMgr, pEntCar, &pEntTail) ;
			break ;
		}
		pEntList	= pEntCdr ;
	}
	*ppEntRetval	= pEntRetval ;
	return	TRUE ;
}

BOOL
lispEntity_Equal (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntLeft,
	register TLispEntity*	pEntRight)
{
	int			iLeftType,   iRightType ;

	assert (pLispMgr     != NULL) ;
	assert (pEntLeft  != NULL) ;
	assert (pEntRight != NULL) ;

	/*	`eq' �Ȃ瓖�R `equal' �͐�������B*/
	if (TSUCCEEDED (lispEntity_Eq (pLispMgr, pEntLeft, pEntRight)))
		return	TRUE ;
	
	if (TFAILED (lispEntity_GetType (pLispMgr, pEntLeft,  &iLeftType))  ||
		TFAILED (lispEntity_GetType (pLispMgr, pEntRight, &iRightType)) ||
		iLeftType != iRightType) 
		return	FALSE ;
	
	switch (iLeftType /* == iRightType */) {
	case	LISPENTITY_FLOAT:
	{
		float	fLeftValue, fRightValue ;

		lispEntity_GetFloatValue (pLispMgr, pEntLeft,  &fLeftValue) ;
		lispEntity_GetFloatValue (pLispMgr, pEntRight, &fRightValue) ;
		return	(fLeftValue == fRightValue)? TRUE : FALSE ;
	}

	case	LISPENTITY_CONSCELL:
	{
		TLispEntity*	pLeftCar ;
		TLispEntity*	pLeftCdr ;
		TLispEntity*	pRightCar ;
		TLispEntity*	pRightCdr ;

		lispEntity_GetCar (pLispMgr, pEntLeft,  &pLeftCar) ;
		lispEntity_GetCar (pLispMgr, pEntRight, &pRightCar) ;
		if (TFAILED (lispEntity_Equal (pLispMgr, pLeftCar, pRightCar)))
			return	FALSE ;
		lispEntity_GetCdr (pLispMgr, pEntLeft,  &pLeftCdr) ;
		lispEntity_GetCdr (pLispMgr, pEntRight, &pRightCdr) ;
		if (TFAILED (lispEntity_Equal (pLispMgr, pLeftCdr, pRightCdr)))
			return	FALSE ;
		return	TRUE ;
	}
			
	case	LISPENTITY_STRING:
	{
		const Char*	pLeftString ;
		int			nLeftLength ;
		const Char*	pRightString ;
		int			nRightLength ;

		lispEntity_GetStringValue (pLispMgr, pEntLeft,  &pLeftString,  &nLeftLength) ;
		lispEntity_GetStringValue (pLispMgr, pEntRight, &pRightString, &nRightLength) ;
		if (nLeftLength != nRightLength ||
			Cstrncmp (pLeftString, pRightString, nLeftLength))
			return	FALSE ;
		return	TRUE ;
	}
		
	case	LISPENTITY_VECTOR:
	{
		TLispEntity**	ppLeftElement ;
		int				nLeftElement ;
		TLispEntity**	ppRightElement ;
		int				nRightElement ;

		lispEntity_GetVectorValue (pLispMgr, pEntLeft,  &ppLeftElement,  &nLeftElement) ;
		lispEntity_GetVectorValue (pLispMgr, pEntRight, &ppRightElement, &nRightElement) ;
		if (nLeftElement != nRightElement)
			return	FALSE ;

		while (nLeftElement > 0) {
			if (TFAILED (lispEntity_Equal (pLispMgr, *ppLeftElement, *ppRightElement)))
				return	FALSE ;
			ppLeftElement	++ ;
			ppRightElement	++ ;
			nLeftElement	-- ;
		}
		return	TRUE ;
	}
		
	case	LISPENTITY_SYMBOL:
	case	LISPENTITY_INTEGER:
	default:
		return	FALSE ;
	}
}

BOOL
lispEntity_GetNumberValueOrMarkerPosition (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispNumber*	pReturn)
{
	long			lValue ;
	float			fValue ;
	TLispEntity*	pEntBuffer ;
	int				iPos ;

	assert (pLispMgr != NULL) ;

	switch (pEntity->m_iType) {
	case	LISPENTITY_INTEGER:
		if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntity, &lValue)))
			return	FALSE ;
		pReturn->m_fFloatp			= FALSE ;
		pReturn->m_Value.m_lLong	= lValue ;
		break ;
	case	LISPENTITY_MARKER:
		if (TFAILED (lispMarker_GetBufferPosition (pLispMgr, pEntity, &pEntBuffer, &iPos)) ||
			pEntBuffer == NULL)
			return	FALSE ;
		pReturn->m_fFloatp			= FALSE ;
		pReturn->m_Value.m_lLong	= (long) iPos ;
		break ;
	case	LISPENTITY_FLOAT:
		(void) lispEntity_GetFloatValue (pLispMgr, pEntity, &fValue) ;
		pReturn->m_fFloatp			= TRUE ;
		pReturn->m_Value.m_fFloat	= fValue ;
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

BOOL
lispEntity_GetLength (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register int*			pnLength)
{
	int			nLength ; 
	
	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pnLength != NULL) ;

	if (TFAILED (lispEntity_Sequencep (pLispMgr, pEntity)))
		return	FALSE ;

	switch (pEntity->m_iType) {
	case	LISPENTITY_STRING:
	{
		const Char*	pString ;
		
		(void) lispEntity_GetStringValue (pLispMgr, pEntity, &pString, &nLength) ;
		break ;
	}
		
	case	LISPENTITY_VECTOR:
	{
		TLispEntity**	ppElement ;

		(void) lispEntity_GetVectorValue (pLispMgr, pEntity, &ppElement, &nLength) ;
		break ;
	}
	
	default:
	{
		TLispEntity*	pNextEntity ;
		
		nLength	= 0 ;
		while (TFAILED (lispEntity_Nullp (pLispMgr, pEntity))) {
			if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pNextEntity))) {
#if defined (DEBUG)
				DEBUGPRINTF ((TEXT ("Wrong type argument: listp, "))) ;
				lispEntity_Print (pLispMgr, pEntity) ;
				DEBUGPRINTF ((TEXT ("\n"))) ;
#endif
				return	FALSE ;
			}
			nLength		++ ;
			pEntity	= pNextEntity ;
		}
	}
	}
	*pnLength	= nLength ;
	return	TRUE ;
}

BOOL
lispEntity_GetInteractive (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TLispEntity**	ppReturn)
{
	TLispEntity*	pInteractive ;
	TLispEntity*	pNextEntity ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (ppReturn != NULL) ;

	pInteractive	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_INTERACTIVE) ;
	while (TFAILED (lispEntity_Nullp (pLispMgr, pEntity))) {
		TLispEntity*	pCar ;
		TLispEntity*	pCaar ;
		if (TSUCCEEDED (lispEntity_GetCar (pLispMgr, pEntity, &pCar))  &&
			TSUCCEEDED (lispEntity_GetCar (pLispMgr, pCar,    &pCaar)) &&
			pCaar == pInteractive) {
			lispEntity_GetCadr (pLispMgr, pCar, ppReturn) ;
			return	TRUE ;
		}
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pNextEntity)))
			return	FALSE ;
		pEntity	= pNextEntity ;
	}
	*ppReturn	= NULL ;
	return	TRUE ;
}

/*
 *	(format STRING &rest OBJECTS) �̎��̂ƂȂ�֐��B
 *
 *	(pFormat, nFormat) �ŗ^����ꂽ�����ɏ]���� pEntData �ɂ����
 *	�^����ꂽ entity �� list ��\������B
 *	�����ɑΉ����� entity ���Ԉ���Ă���/�Ȃ��ꍇ�ɂ̓G���[��Ԃ��B
 */
BOOL
lispEntity_Format (
	register TLispManager*	pLispMgr,
	register const Char*	pFormat,
	register int			nFormat,
	register TLispEntity*	pEntData,
	register TLispEntity**	ppEntRetval)
{
	TVarbuffer			vbuf ;
	TLispEntity*		pEntArg ;
	TLispEntity*		pEntNextData ;
	register int			nUpper ;
	register const Char*	pSubFormat ;
	register int			nSubFormat ;

	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (Char))))
		return	FALSE ;

	while (nFormat > 0) {
		if (*pFormat != '%') {
			if (TFAILED (TVarbuffer_Add (&vbuf, pFormat, 1)))
				goto	error ;
			goto	skip ;
		}
		pSubFormat	= pFormat ;
		pFormat	++ ;
		nFormat	-- ;
		if (nFormat <= 0) {
			goto	error ;
		}
		nUpper	= 0 ;
		while (nFormat > 0 && '0' <= *pFormat && *pFormat <= '9') {
			nUpper	= nUpper * 10 + (nUpper - '0') ;
			pFormat	++ ;
			nFormat -- ;
		}
		if (nFormat > 0 && *pFormat == '.') {
			pFormat	++ ;
			nFormat -- ;
			while (nFormat > 0 && '0' <= *pFormat && *pFormat <= '9') {
				pFormat	++ ;
				nFormat -- ;
			}
		}
		if (nFormat <= 0) {
			goto	error ;
		}
		nSubFormat	= pFormat - pSubFormat + 1 ;
		switch (*pFormat) {
		case	's':
		case	'S':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatString (pLispMgr, pEntArg, nUpper, &vbuf))) {
				goto	error ;
			}
			break ;

		case	'c':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatChar (pLispMgr, pEntArg, &vbuf))) {
				goto	error ;
			}
			break ;

		case	'd':
		case	'o':
		case	'x':
		case	'X':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatNumber (pLispMgr, pEntArg, pSubFormat, nSubFormat, FALSE, &vbuf))) {
				goto	error ;
			}
			break ;

		case	'e':
		case	'f':
		case	'g':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatNumber (pLispMgr, pEntArg, pSubFormat, nSubFormat, TRUE, &vbuf))) {
				goto	error ;
			}
			break ;

		case	'%':
			if (TFAILED (TVarbuffer_Add (&vbuf, pFormat, 1)))
				goto	error ;
			goto	skip ;

		default:
			goto	error ;
		}
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntData, &pEntNextData)))
			goto	error ;
		pEntData	= pEntNextData ;
	  skip:
		pFormat	++ ;
		nFormat	-- ;
	}

	if (TFAILED (lispMgr_CreateString (pLispMgr, TVarbuffer_GetBuffer (&vbuf), TVarbuffer_GetUsage (&vbuf), ppEntRetval)))
		goto	error ;
	return	TRUE ;

 error:
	TVarbuffer_Uninitialize (&vbuf) ;
	return	FALSE ;
}

/*
 *	(format STRING &rest OBJECTS) �̎��̂ƂȂ�֐��B
 *
 *	(pFormat, nFormat) �ŗ^����ꂽ�����ɏ]���� pEntData �ɂ����
 *	�^����ꂽ entity �� list ��\������B
 *	�����ɑΉ����� entity ���Ԉ���Ă���/�Ȃ��ꍇ�ɂ̓G���[��Ԃ��B
 */
BOOL
lispEntity_FormatA (
	register TLispManager*	pLispMgr,
	register LPCTSTR		pFormat,
	register int			nFormat,
	register TLispEntity*	pEntData,
	register TLispEntity**	ppEntRetval)
{
	TVarbuffer			vbuf ;
	TLispEntity*		pEntArg ;
	TLispEntity*		pEntNextData ;
	Char				cc ;
	register int		nUpper ;
	register LPCTSTR	pSubFormat ;
	register int		nSubFormat ;
	register BOOL		fRetval	= FALSE ;

	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (Char))))
		return	FALSE ;

	while (nFormat > 0) {
		if (*pFormat != '%') {
			cc	= Char_MakeAscii (*pFormat) ;
			if (TFAILED (TVarbuffer_Add (&vbuf, &cc, 1)))
				goto	error ;
			goto	skip ;
		}
		pSubFormat	= pFormat ;
		pFormat	++ ;
		nFormat	-- ;
		if (nFormat <= 0)
			goto	error ;
		nUpper	= 0 ;
		while (nFormat > 0 && '0' <= *pFormat && *pFormat <= '9') {
			nUpper	= nUpper * 10 + (nUpper - '0') ;
			pFormat	++ ;
			nFormat -- ;
		}
		if (nFormat > 0 && *pFormat == '.') {
			pFormat	++ ;
			nFormat -- ;
			while (nFormat > 0 && '0' <= *pFormat && *pFormat <= '9') {
				pFormat	++ ;
				nFormat -- ;
			}
		}
		if (nFormat <= 0)
			goto	error ;

		nSubFormat	= pFormat - pSubFormat + 1 ;
		switch (*pFormat) {
		case	's':
		case	'S':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatString (pLispMgr, pEntArg, nUpper, &vbuf)))
				goto	error ;
			break ;

		case	'c':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatChar (pLispMgr, pEntArg, &vbuf)))
				goto	error ;
			break ;

		case	'd':
		case	'o':
		case	'x':
		case	'X':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatNumberA (pLispMgr, pEntArg, pSubFormat, nSubFormat, FALSE, &vbuf)))
				goto	error ;
			break ;

		case	'e':
		case	'f':
		case	'g':
			if (TFAILED (lispEntity_GetCar (pLispMgr, pEntData, &pEntArg)) ||
				TFAILED (lispEntity_formatNumberA (pLispMgr, pEntArg, pSubFormat, nSubFormat, TRUE, &vbuf))) 
				goto	error ;
			break ;

		case	'%':
			cc	= Char_MakeAscii (*pFormat) ;
			if (TFAILED (TVarbuffer_Add (&vbuf, &cc, 1)))
				goto	error ;
			goto	skip ;

		default:
			goto	error ;
		}
		if (TFAILED (lispEntity_GetCdr (pLispMgr, pEntData, &pEntNextData)))
			goto	error ;
		pEntData	= pEntNextData ;
	  skip:
		pFormat	++ ;
		nFormat	-- ;
	}

	if (TFAILED (lispMgr_CreateString (pLispMgr, TVarbuffer_GetBuffer (&vbuf), TVarbuffer_GetUsage (&vbuf), ppEntRetval)))
		goto	error ;
	fRetval	= TRUE ;

 error:
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fRetval ;
}

BOOL
lispEntity_PrincStr (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	static const Char	chL	= '(' ;
	static const Char	chR	= ')' ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pvbuf    != NULL) ;

	if (TSUCCEEDED (lispEntity_Consp (pLispMgr, pEntity))) {
		if (TFAILED (TVarbuffer_Add (pvbuf, &chL, 1)) ||
			TFAILED (lispEntity_princStr (pLispMgr, pEntity, pvbuf)) ||
			TFAILED (TVarbuffer_Add (pvbuf, &chR, 1)))
			return	FALSE ;
		return	TRUE ;
	} else {
		return	lispEntity_princStr (pLispMgr, pEntity, pvbuf) ;
	}
}

BOOL
lispEntity_princStr (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	static	BOOL	(*arPrincStrFuncTbl[])(TLispManager*, TLispEntity*, TVarbuffer*) = {
		lispEntity_princStrInteger,		lispEntity_princStrFloat,
		lispEntity_princStrConscell,	lispEntity_princStrVector,
		lispEntity_princStrString,		lispEntity_princStrSymbol,
		lispEntity_princStrMarker,		lispEntity_princStrBuffer,
		lispEntity_princStrSubr,		NULL,	/* empty */
		NULL,	/* void */				NULL,	/* bool-vector */
		NULL,	/* char-table */
	} ;
	int		nType ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pvbuf    != NULL) ;

	lispEntity_GetType (pLispMgr, pEntity, &nType) ;
	if (nType < 0 || nType >= MAX_LISPENTITY_TYPE)
		return	FALSE ;
	if (arPrincStrFuncTbl [nType] != NULL) {
		return	(arPrincStrFuncTbl [nType])(pLispMgr, pEntity, pvbuf) ;
	} else {
		static const Char	sstrUnknown[]	= { '(','u','n','k','n','o','w','n',')' } ;
		return	TVarbuffer_Add (pvbuf, sstrUnknown, ARRAYSIZE (sstrUnknown)) ;
	}
}

/*
 *	��̊֐��Ǝ��Ă��邪�A������̓f�o�b�O�p�ł���B
 */
BOOL
lispEntity_Print (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	assert (pLispMgr != NULL) ;

	if (pEntity == NULL) {
		DEBUGPRINTF ((TEXT ("NULL"))) ;
		return	TRUE ;
	}
	if (TSUCCEEDED (lispEntity_Consp (pLispMgr, pEntity))) {
		DEBUGPRINTF ((TEXT ("("))) ;
		lispEntity_print (pLispMgr, pEntity) ;
		DEBUGPRINTF ((TEXT (")"))) ;
		return	TRUE ;
	} else {
		return	lispEntity_print (pLispMgr, pEntity) ;
	}
}

BOOL
lispEntity_print (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	static	BOOL	(*arPrintFuncTbl[])(TLispManager*, TLispEntity*) = {
		lispEntity_printInteger,	lispEntity_printFloat,
		lispEntity_printConscell,	lispEntity_printVector,
		lispEntity_printString,		lispEntity_printSymbol,
		lispEntity_printMarker,		lispEntity_printBuffer,
		lispEntity_printSubr,		lispEntity_printEmpty,
		lispEntity_printVoid,
		NULL, /* bool-vector */
		NULL, /* char-table */
	} ;
	int		nType ;

	assert (pLispMgr != NULL) ;

	if (pEntity == NULL) {
		DEBUGPRINTF ((TEXT ("NULL"))) ;
		return	TRUE ;
	}
	lispEntity_GetType (pLispMgr, pEntity, &nType) ;
	if (nType < 0 || nType >= MAX_LISPENTITY_TYPE)
		return	FALSE ;
	if (arPrintFuncTbl [nType] != NULL) {
		return	(arPrintFuncTbl [nType])(pLispMgr, pEntity) ;
	} else {
		DEBUGPRINTF ((TEXT ("'unknown"))) ;
		return	TRUE ;
	}
}

/*	private functions */
BOOL
lispEntity_princStrInteger (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	TCHAR			szBuf [64] ;
	long			lValue ;
	register int	nLength ;
	register Char*	pDest ;
	register int	nUsage ;
	
	if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntity, &lValue)))
		return	FALSE ;
#if __STDC_WANT_SECURE_LIB__
	_sntprintf_s (szBuf, ARRAYSIZE (szBuf) - 1, _TRUNCATE, TEXT ("%ld"), lValue) ;
#else
	_sntprintf (szBuf, ARRAYSIZE (szBuf) - 1, TEXT ("%ld"), lValue) ;
#endif
	szBuf [ARRAYSIZE (szBuf) - 1]	= TEXT ('\0') ;
	nLength	= lstrlen (szBuf) ;
	nUsage	= TVarbuffer_GetUsage (pvbuf) ;
	if (TFAILED (TVarbuffer_Require (pvbuf, nLength)))
		return	FALSE ;
	pDest	= (Char *)TVarbuffer_GetBuffer (pvbuf) + nUsage ;
	strtocstr (pDest, szBuf, nLength) ;
	return	TRUE ;
}
	
BOOL
lispEntity_princStrFloat (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	TCHAR			szBuf [64] ;
	float			fValue ;
	register int	nLength ;
	register Char*	pDest ;
	register int	nUsage ;

	if (TFAILED (lispEntity_GetFloatValue (pLispMgr, pEntity, &fValue)))
		return	FALSE ;
#if __STDC_WANT_SECURE_LIB__
	_sntprintf_s (szBuf, ARRAYSIZE (szBuf) - 1, _TRUNCATE, TEXT ("%f"), fValue) ;
#else
	_sntprintf (szBuf, ARRAYSIZE (szBuf) - 1, TEXT ("%f"), fValue) ;
#endif
	szBuf [ARRAYSIZE (szBuf) - 1]	= TEXT ('\0') ;
	nLength	= lstrlen (szBuf) ;
	nUsage	= TVarbuffer_GetUsage (pvbuf) ;
	if (TFAILED (TVarbuffer_Require (pvbuf, nLength)))
		return	FALSE ;
	pDest	= (Char *)TVarbuffer_GetBuffer (pvbuf) + nUsage ;
	strtocstr (pDest, szBuf, nLength) ;
	return	TRUE ;
}
	
BOOL
lispEntity_princStrSymbol (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	const Char*	pName ;
	int			nName ;

	if (TFAILED (lispEntity_GetSymbolName (pLispMgr, pEntity, &pName, &nName)) |\
		TFAILED (TVarbuffer_Add (pvbuf, pName, nName)))
		return	FALSE ;
	return	TRUE ;
}

BOOL
lispEntity_princStrString (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	static const Char	chDoubleQuote	= '\"' ;
	const Char*	pString ;
	int			nLength ;
	
	(void) lispEntity_GetStringValue (pLispMgr, pEntity, &pString, &nLength) ;
	if (TFAILED (TVarbuffer_Add (pvbuf, &chDoubleQuote, 1)) ||
		TFAILED (TVarbuffer_Add (pvbuf, pString, nLength)) ||
		TFAILED (TVarbuffer_Add (pvbuf, &chDoubleQuote, 1)))
		return	FALSE ;
	return	TRUE ;
}

BOOL
lispEntity_princStrConscell (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	static const Char	chParenthesisL	= '(' ;
	static const Char	chParenthesisR	= ')' ;
	static const Char	chSpace			= ' ' ;
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntCdr ;

	if (TFAILED (lispEntity_GetCar (pLispMgr, pEntity, &pEntCar)) ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pEntity, &pEntCdr)))
		return	FALSE ;
	if (TSUCCEEDED (lispEntity_Consp (pLispMgr, pEntCar))) {
		if (TFAILED (TVarbuffer_Add (pvbuf, &chParenthesisL, 1)) ||
			TFAILED (lispEntity_princStr (pLispMgr, pEntCar, pvbuf)) ||
			TFAILED (TVarbuffer_Add (pvbuf, &chParenthesisR, 1)))
			return	FALSE ;
	} else {
		if (TFAILED (lispEntity_princStr (pLispMgr, pEntCar, pvbuf)))
			return	FALSE ;
	}
	if (TFAILED (lispEntity_Listp (pLispMgr, pEntCdr))) {
		static const Char	rchSDS []	= { ' ', '.', ' ', } ;
		if (TFAILED (TVarbuffer_Add (pvbuf, rchSDS, ARRAYSIZE (rchSDS))) ||
			TFAILED (lispEntity_princStr (pLispMgr, pEntCdr, pvbuf)))
			return	FALSE ;
	} else {
		if (TFAILED (lispEntity_Nullp (pLispMgr, pEntCdr)) &&
			(TFAILED (TVarbuffer_Add (pvbuf, &chSpace, 1)) ||
			 TFAILED (lispEntity_princStr (pLispMgr, pEntCdr, pvbuf))))
			return	FALSE ;
	}
	return	TRUE ;
}

BOOL
lispEntity_princStrVector (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	static const Char	chBracketL	= '[' ;
	static const Char	chSpace		= ' ' ;
	static const Char	chBracketR	= ']' ;
	TLispEntity**	ppElement ;
	int				nElement ;

	lispEntity_GetVectorValue (pLispMgr, pEntity, &ppElement, &nElement) ;
	if (TFAILED (TVarbuffer_Add (pvbuf, &chBracketL, 1)))
		return	FALSE ;
	if (nElement > 0) {
		do {
			if (TFAILED (lispEntity_PrincStr (pLispMgr, *ppElement ++, pvbuf)) ||
				(nElement > 1 && TFAILED (TVarbuffer_Add (pvbuf, &chSpace, 1))))
				return	FALSE ;
			nElement	-- ;
		} while (nElement > 0) ;
	}
	return	TVarbuffer_Add (pvbuf, &chBracketR, 1) ;
}

BOOL
lispEntity_princStrMarker (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	TLispEntity*	pEntBuffer ;
	int				nPos ;
	TCHAR			szBuf [64] ;
	register int	nLength ;
	register Char*	pDest ;

	lispMarker_GetBufferPosition (pLispMgr, pEntity, &pEntBuffer, &nPos) ;
	if (pEntBuffer != NULL) {
#if __STDC_WANT_SECURE_LIB__
		_sntprintf_s (szBuf, ARRAYSIZE (szBuf) - 1, _TRUNCATE, TEXT ("#<marker at %d in %p>"), nPos, pEntBuffer) ;
#else
		_sntprintf (szBuf, ARRAYSIZE (szBuf) - 1, TEXT ("#<marker at %d in %p>"), nPos, pEntBuffer) ;
#endif
	} else {
#if __STDC_WANT_SECURE_LIB__
		_sntprintf_s (szBuf, ARRAYSIZE (szBuf) - 1, _TRUNCATE, TEXT ("#<marker in no buffer>")) ;
#else
		_sntprintf (szBuf, ARRAYSIZE (szBuf) - 1, TEXT ("#<marker in no buffer>")) ;
#endif
	}
	szBuf [ARRAYSIZE (szBuf) - 1]	= TEXT ('\0') ;
	nLength	= lstrlen (szBuf) ;
	if (TFAILED (TVarbuffer_Require (pvbuf, nLength)))
		return	FALSE ;
	pDest	= (Char *)TVarbuffer_GetBuffer (pvbuf) + TVarbuffer_GetUsage (pvbuf) ;
	strtocstr (pDest, szBuf, nLength) ;
	return	TRUE ;
}

BOOL
lispEntity_princStrBuffer (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity, 
	register TVarbuffer*	pvbuf)
{
	return	lispEntity_princStrRest (pLispMgr, TEXT ("#<buffer %p>"), pEntity, pvbuf) ;
}

BOOL
lispEntity_princStrSubr (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	static const Char	rchSTR1 []	= { '#','<','s','u','b','r',' ', } ;
	static const Char	rchSTR2 []	= { '>', } ;
	const Char*	strSubrName ;

	if (TFAILED (lispSubr_GetName (pLispMgr, pEntity, &strSubrName)))
		return	FALSE ;
	if (TFAILED (TVarbuffer_Add (pvbuf, rchSTR1, ARRAYSIZE (rchSTR1))) ||
		TFAILED (TVarbuffer_Add (pvbuf, strSubrName, Cstrlen (strSubrName))) ||
		TFAILED (TVarbuffer_Add (pvbuf, rchSTR2, ARRAYSIZE (rchSTR2))))
		return	FALSE ;
	return	TRUE ;
}

BOOL
lispEntity_princStrRest (
	register TLispManager*	pLispMgr,
	register LPCTSTR		pFormat,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	TCHAR			szBuf [64] ;
	int				nLength ;
	Char*			pDest ;
#if __STDC_WANT_SECURE_LIB__
	_sntprintf_s (szBuf, ARRAYSIZE (szBuf) - 1, _TRUNCATE, pFormat, pEntity) ;
#else
	_sntprintf (szBuf, ARRAYSIZE (szBuf) - 1, pFormat, pEntity) ;
#endif
	szBuf [ARRAYSIZE (szBuf) - 1]	= TEXT ('\0') ;
	nLength	= lstrlen (szBuf) ;
	if (TFAILED (TVarbuffer_Require (pvbuf, nLength)))
		return	FALSE ;
	pDest	= (Char *)TVarbuffer_GetBuffer (pvbuf) + TVarbuffer_GetUsage (pvbuf) ;
	strtocstr (pDest, szBuf, nLength) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
}

BOOL
lispEntity_printInteger (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	long	lValue ;
	(void) lispEntity_GetIntegerValue (pLispMgr, pEntity, &lValue) ;
	DEBUGPRINTF ((TEXT ("%ld"), lValue)) ;
	return	TRUE ;
}

BOOL
lispEntity_printFloat (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	float	fValue ;
	(void) lispEntity_GetFloatValue (pLispMgr, pEntity, &fValue) ;
	DEBUGPRINTF ((TEXT ("%f"), fValue)) ;
	return	TRUE ;
}

BOOL
lispEntity_printSymbol (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	const Char*	pName ;
	int			nName ;
	int			nLength ;
	TCHAR		achBuf [TEMPBUFSIZE] ;
	
	(void) lispEntity_GetSymbolName (pLispMgr, pEntity, &pName, &nName) ;
	nLength	= ARRAYSIZE (achBuf) - 1 ;
	if (nName < nLength)
		nLength	= nName ;
	
	cstrtostr (achBuf, pName, nLength) ;
	achBuf [nLength]	= '\0' ;
	DEBUGPRINTF ((TEXT ("%s"), achBuf)) ;
	return	TRUE ;
}

BOOL
lispEntity_printString (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	const Char*	pString ;
	int			nLength ;
	char		achBuf [TEMPBUFSIZE] ;
	
	(void) lispEntity_GetStringValue (pLispMgr, pEntity, &pString, &nLength) ;
	if (nLength <= 0) {
		DEBUGPRINTF ((TEXT ("\"\""))) ;
		return	TRUE ;
	}
	if (nLength  > (sizeof (achBuf) - 1))
		nLength	= sizeof (achBuf) - 1 ;
#if 1
	{
		KANJISTATEMACHINE	ksm ;
		int					n ;
		InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_SHIFTJIS) ;
		DEBUGPRINTF ((TEXT ("\""))) ;
		while (nLength > 0) {

			n	= RtransferKanjiFiniteStateMachine (&ksm, *pString ++, achBuf) ;
			achBuf [n]	= '\0' ;
#if defined (UNICODE) || defined (_UNICODE)
			{
				TCHAR	wbuf [16] ;
				n	= MultiByteToWideChar (932, 0, achBuf, n, wbuf, ARRAYSIZE (wbuf)) ; 
				wbuf [n]	= TEXT ('\0') ;
				DEBUGPRINTF ((TEXT ("%s"), wbuf)) ;
			}
#else
			DEBUGPRINTF ((TEXT ("%s"), achBuf)) ;
#endif
			nLength	-- ;
		}
		n	= RtransferKanjiFiniteStateMachine (&ksm, '\"', achBuf) ;
		achBuf [n]	= '\0' ;
#if defined (UNICODE) || defined (_UNICODE)
		{
			TCHAR	wbuf [16] ;
			n	= MultiByteToWideChar (932, 0, achBuf, n, wbuf, ARRAYSIZE (wbuf)) ; 
			wbuf [n]	= TEXT ('\0') ;
			DEBUGPRINTF ((TEXT ("%s"), wbuf)) ;
		}
#else
		DEBUGPRINTF ((TEXT ("%s"), achBuf)) ;
#endif
	}
#else
	cstrtostr (achBuf, pString, nLength) ;
	achBuf [nLength]	= '\0' ;
	DEBUGPRINTF ((TEXT ("\"%s\""), achBuf)) ;
#endif
	return	TRUE ;
}

BOOL
lispEntity_printConscell (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	TLispEntity*	pEntCar ;
	TLispEntity*	pEntCdr ;
	
	lispEntity_GetCar (pLispMgr, pEntity, &pEntCar) ;
	lispEntity_GetCdr (pLispMgr, pEntity, &pEntCdr) ;

	if (TSUCCEEDED (lispEntity_Consp (pLispMgr, pEntCar))) {
		DEBUGPRINTF ((TEXT ("("))) ;
		lispEntity_print (pLispMgr, pEntCar) ;
		DEBUGPRINTF ((TEXT (")"))) ;
	} else {
		lispEntity_print (pLispMgr, pEntCar) ;
	}
	if (TFAILED (lispEntity_Listp (pLispMgr, pEntCdr))) {
		DEBUGPRINTF ((TEXT (" . "))) ;
		lispEntity_print (pLispMgr, pEntCdr) ;
	} else {
		if (TFAILED (lispEntity_Nullp (pLispMgr, pEntCdr))) {
			DEBUGPRINTF ((TEXT (" "))) ;
			lispEntity_print (pLispMgr, pEntCdr) ;
		}
	}
	return	TRUE ;
}

BOOL
lispEntity_printVector (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	TLispEntity**	ppElement ;
	int				nElement ;

	lispEntity_GetVectorValue (pLispMgr, pEntity, &ppElement, &nElement) ;
	DEBUGPRINTF ((TEXT ("["))) ;
	if (nElement > 0) {
		do {
			lispEntity_Print (pLispMgr, *ppElement ++) ;
			if (nElement > 1)
				DEBUGPRINTF ((TEXT (" "))) ;
			nElement	-- ;
		} while (nElement > 0) ;
	}
	DEBUGPRINTF ((TEXT ("]"))) ;
	return	TRUE ;
}

BOOL
lispEntity_printMarker (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	TLispEntity*	pEntBuffer ;
	int				nPos ;
	lispMarker_GetBufferPosition (pLispMgr, pEntity, &pEntBuffer, &nPos) ;
	if (pEntBuffer != NULL) {
		DEBUGPRINTF ((TEXT ("#<marker at %d in %p>"), nPos, pEntBuffer)) ;
	} else {
		DEBUGPRINTF ((TEXT ("#<marker in no buffer>"))) ;
	}
	return	TRUE ;
}

BOOL
lispEntity_printBuffer (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	DEBUGPRINTF ((TEXT ("#<buffer %p>"), pEntity)) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
	UNREFERENCED_PARAMETER (pEntity) ;
}

BOOL
lispEntity_printSubr (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	const Char*	pName ;
	int			nName ;
	TCHAR		achBuf [TEMPBUFSIZE] ;

	DEBUGPRINTF ((TEXT ("#<subr "))) ;
	lispSubr_GetName (pLispMgr, pEntity, &pName) ;
	nName	= Cstrlen (pName) ;
	if (nName >= ARRAYSIZE (achBuf))
		nName	= ARRAYSIZE (achBuf) - 1 ;
	cstrtostr (achBuf, pName, nName) ;
	achBuf [nName]	= '\0' ;
	DEBUGPRINTF ((TEXT ("%s>"), achBuf)) ;
	return	TRUE ;
}

BOOL
lispEntity_printEmpty (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	DEBUGPRINTF ((TEXT ("#<empty>"))) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
	UNREFERENCED_PARAMETER (pEntity) ;
}

BOOL
lispEntity_printVoid (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity)
{
	DEBUGPRINTF ((TEXT ("#<void>"))) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (pLispMgr) ;
	UNREFERENCED_PARAMETER (pEntity) ;
}

BOOL
lispEntity_formatString (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register int			nCount,
	register TVarbuffer*	pvbuf)
{
	TVarbuffer				vbuf ;
	register BOOL			fRetval	= FALSE ;
	register const Char*	pString ;
	register int			nUsage ;
	int						nType ;

	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (Char))))
		return	FALSE ;
	if (TFAILED (lispEntity_PrincStr (pLispMgr, pEntity, &vbuf))) 
		goto	error ;
	lispEntity_GetType (pLispMgr, pEntity, &nType) ;
	if (nType == LISPENTITY_STRING) {
		nUsage	= TVarbuffer_GetUsage (&vbuf) - 2 ;
		if (nUsage < 0)
			return	FALSE ;
		pString	= (const Char *)TVarbuffer_GetBuffer (&vbuf) + 1 ;
	} else {
		nUsage	= TVarbuffer_GetUsage (&vbuf) ;
		pString	= (const Char *)TVarbuffer_GetBuffer (&vbuf) ;
	}
	if (0 < nCount && nUsage < nCount) {
		register int		nSpace	= nUsage - nCount ;
		static const Char	cc		= ' ' ;
		while (nSpace > 0) {
			if (TFAILED (TVarbuffer_Add (pvbuf, &cc, 1)))
				goto	error ;
			nSpace	-- ;
		}
	}
	if (nUsage > 0)
		fRetval	= TVarbuffer_Add (pvbuf, pString, nUsage) ;
  error:
	TVarbuffer_Uninitialize (&vbuf) ;
	return	fRetval ;


}

BOOL
lispEntity_formatChar (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register TVarbuffer*	pvbuf)
{
	Char	cc ;

	if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntity, (long*)&cc)))
		return	FALSE ;
	return	TVarbuffer_Add (pvbuf, &cc, 1) ;
}

BOOL
lispEntity_formatNumber (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register const Char*	pFormat,
	register int			nFormat,
	register const BOOL	fFloat,
	register TVarbuffer*	pvbuf)
{
	TCHAR				achFormat [64] ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pvbuf    != NULL) ;

	if (nFormat	>= sizeof (achFormat))
		return	FALSE ;
	cstrtostr (achFormat, pFormat, nFormat) ;
	achFormat [nFormat]	= TEXT ('\0') ;
	return	lispEntity_formatNumberCommon (pLispMgr, pEntity, achFormat, fFloat, pvbuf) ;
}

BOOL
lispEntity_formatNumberA (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register LPCTSTR		pFormat,
	register int			nFormat,
	register const BOOL		fFloat,
	register TVarbuffer*	pvbuf)
{
	TCHAR				achFormat [64] ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pvbuf    != NULL) ;

	if (nFormat	>= sizeof (achFormat))
		return	FALSE ;
	memcpy (achFormat, pFormat, nFormat * sizeof (TCHAR)) ;
	achFormat [nFormat]	= TEXT ('\0') ;
	return	lispEntity_formatNumberCommon (pLispMgr, pEntity, achFormat, fFloat, pvbuf) ;
}

BOOL
lispEntity_formatNumberCommon (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntity,
	register LPCTSTR		pFormat,
	register const BOOL		fFloat,
	register TVarbuffer*	pvbuf)
{
	TCHAR				achBuffer [64] ;
	Char				aChBuffer [64] ;
	register LPTSTR		ptr ;
	register Char*		pPtr ;
	TLispNumber			num ;

	assert (pLispMgr != NULL) ;
	assert (pEntity  != NULL) ;
	assert (pFormat  != NULL) ;
	assert (pvbuf    != NULL) ;

	if (TFAILED (lispEntity_GetNumberValue (pLispMgr, pEntity, &num)))
		return	FALSE ;

	if (fFloat) {
		register double	dValue ;
		if (TSUCCEEDED (num.m_fFloatp)) {
			dValue	= num.m_Value.m_fFloat ;
		} else {
			dValue	= (float)num.m_Value.m_lLong ;
		}
#if __STDC_WANT_SECURE_LIB__
		_sntprintf_s (achBuffer, ARRAYSIZE (achBuffer) - 1, _TRUNCATE, pFormat, dValue) ;
#else
		_sntprintf (achBuffer, ARRAYSIZE (achBuffer) - 1, pFormat, dValue) ;
#endif
	} else {
		register long	lValue ;
		if (TSUCCEEDED (num.m_fFloatp)) {
			lValue	= (long)num.m_Value.m_fFloat ;
		} else {
			lValue	= num.m_Value.m_lLong ;
		}
#if __STDC_WANT_SECURE_LIB__
		_sntprintf_s (achBuffer, ARRAYSIZE (achBuffer) - 1, _TRUNCATE, pFormat, lValue) ;
#else
		_sntprintf (achBuffer, ARRAYSIZE (achBuffer) - 1, pFormat, lValue) ;
#endif
	}
	achBuffer [ARRAYSIZE (achBuffer) - 1]	= '\0' ;
	ptr		= achBuffer ;
	pPtr	= aChBuffer ;
	while (*ptr != '\0') 
		*pPtr ++	= Char_MakeAscii (*ptr ++) ;
	return	TVarbuffer_Add (pvbuf, aChBuffer, pPtr - aChBuffer) ;
}

BOOL
lispEntity_Copy (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntSrc,
	register TLispEntity**	ppEntDest)
{
	int		nType ;

	lispEntity_GetType (pLispMgr, pEntSrc, &nType) ;
	if (nType == LISPENTITY_CONSCELL) {
		return	lispEntity_copyConscell (pLispMgr, pEntSrc, ppEntDest) ;
	} else if (nType == LISPENTITY_VECTOR) {
		return	lispEntity_copyVector (pLispMgr, pEntSrc, ppEntDest) ;
	} else {
		*ppEntDest	= pEntSrc ;
		return	TRUE ;
	}
}

BOOL
lispEntity_copyConscell (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntSrc,
	register TLispEntity**	ppEntDest)
{
	TLispEntity*	pEntSrcCar ;
	TLispEntity*	pEntSrcCdr ;
	TLispEntity*	pEntDestCar ;
	TLispEntity*	pEntDestCdr ;

	if (TFAILED (lispEntity_GetCar (pLispMgr, pEntSrc, &pEntSrcCar)) ||
		TFAILED (lispEntity_GetCdr (pLispMgr, pEntSrc, &pEntSrcCdr)))
		return	FALSE ;
	if (TFAILED (lispEntity_Copy (pLispMgr, pEntSrcCar, &pEntDestCar)))
		return	FALSE ;
	lispEntity_AddRef (pLispMgr, pEntDestCar) ;
	if (TFAILED (lispEntity_Copy (pLispMgr, pEntSrcCdr, &pEntDestCdr))) {
		lispEntity_Release (pLispMgr, pEntDestCar) ;
		return	FALSE; 
	}
	lispEntity_AddRef (pLispMgr, pEntDestCdr) ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pEntDestCar, pEntDestCdr, ppEntDest))) {
		lispEntity_Release (pLispMgr, pEntDestCar) ;
		lispEntity_Release (pLispMgr, pEntDestCdr) ;
		return	FALSE ;
	}
	lispEntity_Release (pLispMgr, pEntDestCar) ;
	lispEntity_Release (pLispMgr, pEntDestCdr) ;
	return	TRUE ;
}

BOOL
lispEntity_copyVector (
	register TLispManager*	pLispMgr,
	register TLispEntity*	pEntSrc,
	register TLispEntity**	ppEntDest)
{
	TVarbuffer				vbufEntDest ;
	TLispEntity**			ppEntSrcElm ;
	TLispEntity*			pEntDestElm ;
	int						nEntSrcElm ;
	register TLispEntity**	ppEntDests ;
	register int			nEntDests ;
	register int			i ;
	register BOOL		fRetval	= FALSE ;

	if (TFAILED (TVarbuffer_Initialize (&vbufEntDest, sizeof (TLispEntity*))))
		return	FALSE ;

	lispEntity_GetVectorValue (pLispMgr, pEntSrc, &ppEntSrcElm, &nEntSrcElm) ;
	for (i = 0 ; i < nEntSrcElm ; i ++) {
		if (TFAILED (lispEntity_Copy (pLispMgr, *ppEntSrcElm ++, &pEntDestElm))) 
			break ;
		if (TFAILED (TVarbuffer_Add (&vbufEntDest, &pEntDestElm, 1)))
			return	FALSE ;
		lispEntity_AddRef (pLispMgr, pEntDestElm) ;
	}
	
	ppEntDests	= TVarbuffer_GetBuffer (&vbufEntDest) ;
	nEntDests	= TVarbuffer_GetUsage  (&vbufEntDest) ;
	if (i == nEntSrcElm) 
		fRetval	= lispMgr_CreateVector (pLispMgr, ppEntDests, nEntDests, ppEntDest) ;
	for (i = 0 ; i < nEntDests ; i ++) {
		lispEntity_Release (pLispMgr, *ppEntDests) ;
		ppEntDests	++ ;
	}
	TVarbuffer_Uninitialize (&vbufEntDest) ;
	return	fRetval ;
}


