/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"

/*
 *[�@�\]
 *	Lisp Machine �� local �ȃV���{��(�ϐ�)���쐬����B�V���{���̖��O��
 *	Lisp �� Entity �ŗ^����B
 */
BOOL
lispMachine_MakeSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pSymbol,
	register TLispBind**	ppBindReturn)
{
	assert (pLM      != NULL) ;
	assert (pSymbol  != NULL) ;

	return	lispBindTable_MakeEntry (pLM->m_pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pSymbol, ppBindReturn) ;
}

/*
 *[�@�\]
 *	Lisp Machine �� Local �ȃV���{��(�ϐ�)���쐬����B�V���{���̖��O��
 *	Char ������ŗ^����B
 */
BOOL
lispMachine_MakeSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register int			nName,
	register TLispBind**	ppBindReturn)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntSymbol ;
	assert (pLM      != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;
	return	lispBindTable_MakeEntry (pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pEntSymbol, ppBindReturn) ;
}

/*
 *[�@�\]
 *	Local �Ȃ��̂��珇�ԂɃV���{��(�ϐ�)�����݂��邩�m�F���āA���t������
 *	�V���{���ɑ΂��Ēl���Z�b�g����B
 *	Global �ȃV���{���܂őS�đ��݂��Ȃ������ꍇ�ɂ́AGlobal �V���{������
 *	�����Ēl���Z�b�g����B
 */
BOOL
lispMachine_SetCurrentSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	assert (pLM        != NULL) ;
	assert (pEntSymbol != NULL) ;
	assert (pEntValue  != NULL) ;

	return	(lispMachine_SetCurrentBufferLocalSymbolValue (pLM, pEntSymbol, pEntValue) ||
			 lispMachine_SetGlobalSymbolValue      (pLM, pEntSymbol, pEntValue)) ;
}

/*
 *[�@�\]
 *	buffer-local-variable �ɒl��ݒ肷��B
 *[���l]
 *	Lisp �̖��߂� buffer-local-variable �������w���āA�l���Z�b�g����
 *	���̂����邩�ǂ����͕�����Ȃ��B�����s����������Ȃ����B
 */
BOOL
lispMachine_SetCurrentBufferLocalSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr ;
	register TLispEntity*	pEntBuffer ;

	assert (pLM        != NULL) ;
	assert (pEntSymbol != NULL) ;
	assert (pEntValue  != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr   != NULL) ;
	pEntBuffer	= pLM->m_pCurBuffer ;

	/*	���̍s�͈ꎞ�I�Ȃ��̂��낤���B*/
	if (pEntBuffer == NULL)
		return	FALSE ;

	return	lispBuffer_SetSymbolValue (pLispMgr, pEntBuffer, pEntSymbol, pEntValue) ;
}

/*
 *[�@�\]
 *	Lisp Machine �� Local �ȃV���{���ɒl���Z�b�g����B
 */
BOOL
lispMachine_SetGlobalSymbolValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntSymbol,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispBind*	pBind ;

	assert (pLM             != NULL) ;
	assert (pLM->m_pLispMgr != NULL) ;
	assert (pEntSymbol      != NULL) ;

	if (TFAILED (lispBindTable_SearchEntry (pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pEntSymbol, &pBind)) ||
		pBind == NULL) {
		if (TFAILED (lispBindTable_MakeEntry (pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pEntSymbol, &pBind)))
			return	FALSE ;
	}
	lispBind_SetValue (pLispMgr, pBind, pEntValue) ;
	return	TRUE ;
}

/*
 *[�@�\]
 *	buffer-local-variable �ɒl���Z�b�g����B�V���{���� Char ������ŗ^����B
 */
BOOL
lispMachine_SetCurrentBufferLocalSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register int			nName,
	register TLispEntity*	pEntValue)
{
	assert (pLM       != NULL) ;
	assert (pName     != NULL && nName > 0) ;
	assert (pEntValue != NULL) ;

	/*	���̍s�͈ꎞ�I�Ȃ��̂��낤���B*/
	if (pLM->m_pCurBuffer == NULL)
		return	FALSE ;

	return	lispBuffer_SetSymbolValueWithName (pLM->m_pLispMgr, pLM->m_pCurBuffer, pName, nName, pEntValue) ;
}

/*
 *[�@�\]
 *	Lisp Machine �� local �ȃV���{���ɒl���Z�b�g����B�V���{���� Char ������
 *	�Ŏw�肷��B
 */
BOOL
lispMachine_SetGlobalSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register int			nName,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;
	TLispBind*		pBind ;

	assert (pLM             != NULL) ;
	assert (pLM->m_pLispMgr != NULL) ;
	assert (pName           != NULL && nName > 0) ;
	assert (pEntValue       != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;

	if (TFAILED (lispBindTable_SearchEntry (pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pEntSymbol, &pBind)) ||
		pBind == NULL) {
		if (TFAILED (lispBindTable_MakeEntry (pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pEntSymbol, &pBind)))
			return	FALSE ;
	}
	lispBind_SetValue (pLispMgr, pBind, pEntValue) ;
	return	TRUE ;
}

/*
 *[�@�\]
 *	Symbol ���ł����āASymbol �ɒl�����蓖�Ă�BLocal �Ȃ��̂��� Global ��
 *	���̂ւƏ��Ԃ� Symbol �ɒl�����蓖�Ă��Ă��邩���Ă����B
 *	�ŏI�I�ɒN������ Symbol �ɒl�����蓖�ĂĂ��Ȃ���΁AGlobal �� Symbol 
 *	Value �Ƃ��Ēl�����蓖�Ă��邱�ƂɂȂ�B
 *	Buffer Local �� Machine Local �� Symbol �̒l�����蓖�Ă����ꍇ�ɂ́A��
 *	�O�ɗp�ӂ��Ă����K�v������B
 */
BOOL
lispMachine_SetCurrentSymbolValueWithName (
	register TLispMachine*	pLM,
	register const Char*	pName,
	register int			nName,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM       != NULL) ;
	assert (pName     != NULL && nName > 0) ;
	assert (pEntValue != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;

	return	(lispMachine_SetCurrentBufferLocalSymbolValue (pLM, pEntSymbol, pEntValue) ||
			 lispMachine_SetGlobalSymbolValue      (pLM, pEntSymbol, pEntValue)) ;
}

BOOL
lispMachine_SetCurrentSymbolValueWithNameA (
	register TLispMachine*	pLM,
	register LPCTSTR		pName,
	register int			nName,
	register TLispEntity*	pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM       != NULL) ;
	assert (pName     != NULL && nName > 0) ;
	assert (pEntValue != NULL) ;

	if (TFAILED (lispMgr_InternSymbolA (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;

	return	(lispMachine_SetCurrentBufferLocalSymbolValue (pLM, pEntSymbol, pEntValue) ||
			 lispMachine_SetGlobalSymbolValue      (pLM, pEntSymbol, pEntValue)) ;
}

/*
 *[�@�\]
 *	�V���{���Ɋ��蓖�Ă��Ă���l�𓾂�Blocal �Ȃ��̂��珇�ԂɌ�������
 *	���t�������Ƃ���ŁA���̃V���{���̒l�𓾂�B�V���{���� entity �Ŏw��
 *	����B
 *[���l]
 *	���R�Aentity �̃^�C�v���V���{���łȂ���΃G���[�ɂȂ�B
 */
BOOL
lispMachine_GetCurrentSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	assert (pLM         != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (ppEntReturn != NULL) ;

	return	(lispMachine_GetCurrentBufferLocalSymbolValue (pLM, pEntTarget, ppEntReturn) ||
			 lispMachine_GetGlobalSymbolValue (pLM, pEntTarget, ppEntReturn)) ;
}

BOOL
lispMachine_GetCurrentBufferLocalSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	return	lispMachine_GetBufferLocalSymbolValue (pLM, pLM->m_pCurBuffer, pEntTarget, ppEntReturn) ;
}

BOOL
lispMachine_GetGlobalSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;

	assert (pLM             != NULL) ;
	assert (pLispMgr        != NULL) ;
	assert (pEntSymbol      != NULL) ;
	assert (ppEntReturn     != NULL) ;

	while (pLM != NULL) {
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pEntSymbol, ppEntReturn)))
			return	TRUE ;
		pLM	= pLM->m_pMacParent ;
	}
	return	FALSE ;
}

BOOL
lispMachine_GetSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntBuffer,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	return	(lispMachine_GetBufferLocalSymbolValue (pLM, pEntBuffer, pEntTarget, ppEntReturn) ||
			 lispMachine_GetGlobalSymbolValue (pLM, pEntTarget, ppEntReturn)) ;
}

BOOL
lispMachine_GetBufferLocalSymbolValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntBuffer,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register BOOL			fRetval ;
	TLispEntity*	pEntRetval ;

	assert (pLM         != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (pEntBuffer  != NULL) ;
	assert (ppEntReturn != NULL) ;

	fRetval	= lispBuffer_GetSymbolValue (pLispMgr, pEntBuffer, pEntTarget, &pEntRetval) ;
	if (TFAILED (fRetval) ||
		pEntRetval == NULL ||
		TSUCCEEDED (lispEntity_Emptyp (pLispMgr, pEntRetval)))
		return	FALSE ;
	*ppEntReturn	= pEntRetval ;
	return	TRUE ;
}

BOOL
lispMachine_GetCurrentSymbolValueWithName (
	register TLispMachine*			pLM,
	register const Char*			pName,
	register int					nName,
	register TLispEntity** const	ppReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM      != NULL) ;
	assert (ppReturn != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;

	return	(lispMachine_GetCurrentBufferLocalSymbolValue (pLM, pEntSymbol, ppReturn) ||
			 lispMachine_GetGlobalSymbolValue (pLM, pEntSymbol, ppReturn)) ;
}

BOOL
lispMachine_GetCurrentBufferLocalSymbolValueWithName (
	register TLispMachine*			pLM,
	register const Char*			pName,
	register int					nName,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntBuffer	= pLM->m_pCurBuffer ;
	register BOOL			fRetval ;
	TLispEntity*	pEntRetval ;

	assert (pLM      != NULL) ;
	assert (pName    != NULL && nName > 0) ;
	assert (ppEntReturn != NULL) ;

	/*	���̍s�͈ꎞ�I�Ȃ��̂��낤���B*/
	if (pLM->m_pCurBuffer == NULL)
		return	FALSE ;

	fRetval	= lispBuffer_GetSymbolValueWithName (pLispMgr, pEntBuffer, pName, nName, &pEntRetval) ;
	if (TFAILED (fRetval) ||
		pEntRetval == NULL ||
		TSUCCEEDED (lispEntity_Emptyp (pLispMgr, pEntRetval)))
		return	FALSE ;
	*ppEntReturn	= pEntRetval ;
	return	TRUE ;

}

BOOL
lispMachine_GetGlobalSymbolValueWithName (
	register TLispMachine*			pLM,
	register const Char*			pName,
	register int					nName,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntSymbol ;

	assert (pLM             != NULL) ;
	assert (pLM->m_pLispMgr != NULL) ;

	if (TFAILED (lispMgr_InternSymbol (pLispMgr, pName, nName, &pEntSymbol)))
		return	FALSE ;

	while (pLM != NULL) {
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apVariableTable, ARRAYSIZE (pLM->m_apVariableTable), pEntSymbol, ppEntReturn)))
			return	TRUE ;
		pLM	= pLM->m_pMacParent ;
	}
	return	FALSE ;
}

BOOL
lispMachine_SetSymbolFunctionValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity*			pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispBind*	pBind ;

	assert (pLM         != NULL) ;
	assert (pEntSymbol  != NULL) ;
	assert (pEntValue   != NULL) ;

	if (TFAILED (lispBindTable_SearchEntry (pLispMgr, pLM->m_apFunctionTable, ARRAYSIZE (pLM->m_apFunctionTable), pEntSymbol, &pBind)) ||
		pBind == NULL) {
		if (TFAILED (lispBindTable_MakeEntry (pLispMgr, pLM->m_apFunctionTable, ARRAYSIZE (pLM->m_apFunctionTable), pEntSymbol, &pBind)))
			return	FALSE ;
	}
	lispBind_SetValue (pLispMgr, pBind, pEntValue) ;
	return	TRUE ;
}

BOOL
lispMachine_GetSymbolFunctionValue (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntTarget,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	const LMCMDINFO*	pProcInfo ;

	assert (pLM         != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (ppEntReturn != NULL) ;

	while (pLM != NULL) {
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apFunctionTable, ARRAYSIZE (pLM->m_apFunctionTable), pEntTarget, ppEntReturn)))
			return	TRUE ;
		pLM	= pLM->m_pMacParent ;
	}
	/*	builtin function �ɂȂ������ׂ�B*/
	if (TFAILED (lispMachine_SearchBuiltinFunction (pLispMgr, pEntTarget, &pProcInfo)) ||
		pProcInfo == NULL) 
		return	FALSE ;

	return	lispMgr_CreateSubr (pLispMgr, pProcInfo, ppEntReturn) ;
}

BOOL
lispMachine_GetFinalSymbolFunctionValue (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntTarget,
	register TLispEntity**	ppEntReturn)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntValue	= NULL ;
	register int	nCount		= MAX_NEST_COUNT ;

	assert (pLM != NULL) ;
	assert (pEntTarget  != NULL) ;
	assert (ppEntReturn != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	while (TSUCCEEDED (lispEntity_Symbolp (pLispMgr, pEntTarget)) &&
		   nCount -- > 0) {
		if (TFAILED (lispMachine_GetSymbolFunctionValue (pLM, pEntTarget, &pEntValue))) {
#if defined (DEBUG)
			DEBUGPRINTF ((TEXT ("void function: "))) ;
			lispEntity_Print (pLispMgr, pEntTarget) ;
#endif
		}
		pEntTarget	= pEntValue ;
	}
	if (nCount == 0)
		return	FALSE ;
	*ppEntReturn	= pEntValue ;
	return	TRUE ;
}

BOOL
lispMachine_SetSymbolProperty (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity* 			pEntValue)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispBind*	pBind ;

	assert (pLM         != NULL) ;
	assert (pEntSymbol  != NULL) ;
	assert (pEntValue   != NULL) ;

	if (TFAILED (lispBindTable_SearchEntry (pLispMgr, pLM->m_apPropertyTable, ARRAYSIZE (pLM->m_apPropertyTable), pEntSymbol, &pBind)) ||
		pBind == NULL) {
		if (TFAILED (lispBindTable_MakeEntry (pLispMgr, pLM->m_apPropertyTable, ARRAYSIZE (pLM->m_apPropertyTable), pEntSymbol, &pBind)))
			return	FALSE ;
	}
	lispBind_SetValue (pLispMgr, pBind, pEntValue) ;
	return	TRUE ;
}

BOOL
lispMachine_GetSymbolProperty (
	register TLispMachine*			pLM,
	register TLispEntity*			pEntSymbol,
	register TLispEntity** const	ppEntReturn)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;

	assert (pLM         != NULL) ;
	assert (pEntSymbol  != NULL) ;
	assert (ppEntReturn != NULL) ;

	while (pLM != NULL) {
		if (TSUCCEEDED (lispBindTable_GetEntryValue (pLispMgr, pLM->m_apPropertyTable, ARRAYSIZE (pLM->m_apPropertyTable), pEntSymbol, ppEntReturn)))
			return	TRUE ;
		pLM	= pLM->m_pMacParent ;
	}
	return	FALSE ;
}

