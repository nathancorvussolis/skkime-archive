/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#pragma once

#if defined (__cplusplus)
extern "C" {
#endif
BOOL		lispMachineCode_PushVReg	(TLispMachine*, int) ;
BOOL		lispMachineCode_PopVReg		(TLispMachine*, int) ;
BOOL		lispMachineCode_SetVRegI	(TLispMachine*, int, long) ;
BOOL		lispMachineCode_SetVRegP	(TLispMachine*, int, void*) ;
BOOL		lispMachineCode_SetVRegFP	(TLispMachine*, int, BOOL (*pFunc)(TLispMachine*, TLispEntity*, TLispEntity*)) ;
BOOL		lispMachineCode_GetVRegI	(TLispMachine*, int, long*) ;
BOOL		lispMachineCode_GetVRegP	(TLispMachine*, int, void**) ;
BOOL		lispMachineCode_GetVRegFP	(TLispMachine*, int, BOOL (**ppFunc)(TLispMachine*, TLispEntity*, TLispEntity*)) ;
BOOL		lispMachineCode_MoveVReg	(TLispMachine*, int, int) ;
BOOL		lispMachineCode_Evaln		(TLispMachine*, TLispEntity*, TLMRESULT (*)(TLispMachine*)) ;
BOOL		lispMachineCode_Car			(TLispMachine*, int, int) ;
BOOL		lispMachineCode_SetCurrentFrame	(TLispMachine*, TLispEntity*) ;
BOOL		lispMachineCode_GetCurrentFrame	(TLispMachine*, TLispEntity**) ;
BOOL		lispMachineCode_SetCurrentWindow(TLispMachine*, TLispEntity*) ;
BOOL		lispMachineCode_GetCurrentWindow(TLispMachine*, TLispEntity**) ;
BOOL		lispMachineCode_SetCurrentBuffer(TLispMachine*, TLispEntity*) ;
BOOL		lispMachineCode_GetCurrentBuffer(TLispMachine*, TLispEntity**) ;
BOOL		lispMachineCode_SetException	(TLispMachine*, TLispEntity*, TLispEntity*) ;
BOOL		lispMachineCode_GetException	(TLispMachine*, TLispEntity**, TLispEntity**) ;
BOOL		lispMachineCode_ResetException	(TLispMachine*) ;
BOOL		lispMachineCode_SetSignal		(TLispMachine*, TLispEntity*, TLispEntity*) ;
BOOL		lispMachineCode_GetSignal		(TLispMachine*, TLispEntity**, TLispEntity**) ;
BOOL		lispMachineCode_ResetSignal		(TLispMachine*) ;
BOOL		lispMachineCode_SetError		(TLispMachine*) ;
BOOL		lispMachineCode_SetErrorEx		(TLispMachine*, TLispEntity*) ;
BOOL		lispMachineCode_SetMessage		(TLispMachine*, TLispEntity*) ;
BOOL		lispMachineCode_CurrentMinorModeMaps (TLispMachine*, TLispEntity**) ;

BOOL		lispMachineCode_SetRegmatchTarget (TLispMachine*, TLispEntity*) ;
BOOL		lispMachineCode_StringMatch		(TLispMachine*, const Char*, int, const Char*, int, int) ;
BOOL		lispMachineCode_SearchForward	(TLispMachine*, TLispEntity*, const Char*, int, int, int) ;
BOOL		lispMachineCode_SearchBackward	(TLispMachine*, TLispEntity*, const Char*, int, int, int) ;
BOOL		lispMachineCode_ReSearchForward	(TLispMachine*, TLispEntity*, const Char*, int, int, int) ;
BOOL		lispMachineCode_ReSearchBackward(TLispMachine*, TLispEntity*, const Char*, int, int, int) ;
BOOL		lispMachineCode_MatchBeginning	(TLispMachine*, int, int*) ;
BOOL		lispMachineCode_MatchEnd		(TLispMachine*, int, int*) ;
BOOL		lispMachineCode_MatchData		(TLispMachine*, TLispEntity**) ;

BOOL		lispMachineCode_CreateMarker	(TLispMachine*, TLispEntity*, int, TLispEntity**) ;
BOOL		lispMachineCode_Featurep		(TLispMachine*, TLispEntity*) ;
BOOL		lispMachineCode_Provide			(TLispMachine*, TLispEntity*) ;

BOOL		lispMachineCode_PushState	(TLispMachine*, TLMRESULT (*)(TLispMachine*)) ;
BOOL		lispMachineCode_PopState	(TLispMachine*) ;
BOOL		lispMachineCode_PushLReg	(TLispMachine*, int) ;
BOOL		lispMachineCode_PopLReg		(TLispMachine*, int) ;
BOOL		lispMachineCode_SetLReg		(TLispMachine*, int, TLispEntity*) ;
BOOL		lispMachineCode_GetLReg		(TLispMachine*, int, TLispEntity**) ;
BOOL		lispMachineCode_MoveLReg	(TLispMachine*, int, int) ;
BOOL		lispMachineCode_Cdr			(TLispMachine*, int, int) ;
BOOL		lispMachineCode_SetInteractive	(TLispMachine*, BOOL) ;
BOOL		lispMachineCode_GetInteractive	(TLispMachine*, BOOL*) ;
BOOL		lispMachineCode_UnsetInteractive(TLispMachine*, BOOL) ;
BOOL		lispMachineCode_SetTail		(TLispMachine*, int, int, TLispEntity*) ;
BOOL		lispMachineCode_SetState	(TLispMachine*, TLMRESULT (*)(TLispMachine*)) ;
void		lispMachineCode_ClearQuitFlag	(TLispMachine*) ;
#if defined (__cplusplus)
}
#endif


