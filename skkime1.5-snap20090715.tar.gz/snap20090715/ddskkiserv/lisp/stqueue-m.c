/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"

TLMRESULT
lispMachineState_QueueCreate (register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pQueue ;
	TLispEntity*	pNil ;
	TLispEntity*	pSymbol ;
	TLispEntity*	pTail ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	
	lispMgr_CreateNil (pLispMgr, &pNil) ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pNil, pNil, &pQueue)))
		return	LMR_ERROR ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pQueue) ;
	if (TFAILED (lispMgr_InternSymbolA (pLispMgr, TEXT ("QUEUE"), 5, &pSymbol)))
		return	LMR_ERROR ;
	lispEntity_SetCar (pLispMgr, pQueue, pSymbol) ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pNil, pNil, &pTail)))
		return	LMR_ERROR ;
	lispEntity_SetCdr (pLispMgr, pQueue, pTail) ;
	return	LMR_RETURN ;
}

TLMRESULT
lispMachineState_QueueAll (register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pArglist ;
	TLispEntity*	pQueue ;
	TLispEntity*	pRetval ;

	assert (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	assert (pLispMgr != NULL) ;
	
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;
	assert (pArglist != NULL) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pArglist, &pQueue)) ||
		TFAILED (lispEntity_GetCadr (pLispMgr, pQueue, &pRetval))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pRetval) ;
	return	LMR_RETURN ;
}

TLMRESULT
lispMachineState_QueueEnqueue (register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pArglist ;
	TLispEntity*	pQueue ;
	TLispEntity*	pQueueCdr ;
	TLispEntity*	pQueueCadr ;
	TLispEntity*	pQueueCddr ;
	TLispEntity*	pNil ;
	TLispEntity*	pElt ;
	TLispEntity*	pElementcell ;

	pLispMgr	= pLM->m_pLispMgr ;
	
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;
	assert (pArglist != NULL) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pArglist, &pQueue)) ||
		TFAILED (lispEntity_Listp   (pLispMgr, pQueue)) ||
		TFAILED (lispEntity_GetCadr (pLispMgr, pArglist, &pElt))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (TFAILED (lispEntity_GetCdr (pLispMgr, pQueue, &pQueueCdr)) ||
		TFAILED (lispEntity_GetCadr (pLispMgr, pQueue, &pQueueCadr))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMgr_CreateNil (pLispMgr, &pNil) ;
	if (TFAILED (lispMgr_CreateConscell (pLispMgr, pElt, pNil, &pElementcell)))
		return	LMR_ERROR ;
	if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pQueueCadr))) {
		lispEntity_SetCdr (pLispMgr, pQueueCdr, pElementcell) ;
		lispEntity_SetCar (pLispMgr, pQueueCdr, pElementcell) ;
	} else {
		if (TFAILED (lispEntity_GetCddr (pLispMgr, pQueue, &pQueueCddr))) {
			lispMachineCode_SetError (pLM) ;
			return	LMR_RETURN ;
		}
		lispEntity_SetCdr (pLispMgr, pQueueCddr, pElementcell) ;
		lispEntity_SetCdr (pLispMgr, pQueueCdr,  pElementcell) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pElementcell) ;
	return	LMR_RETURN ;
}

