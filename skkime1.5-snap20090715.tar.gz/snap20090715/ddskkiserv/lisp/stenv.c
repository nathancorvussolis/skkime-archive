/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include <assert.h>
#include "lmachinep.h"
#include "cstring.h"

TLMRESULT
lispMachineState_Getenv (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntVAR ;
	TVarbuffer		vbuf ;
#if defined (_MSC_VER) && ( _MSC_VER >= 1400 )
	TVarbuffer		vbufResult ;
	size_t			nReturnSize ;
#endif
	TVarbuffer		vbufChar ;
	LPTSTR			pDest ;
	TLispEntity*	pEntRetval ;
	LPCTSTR			pResult ;
	const Char*		pString ;
	int				nString ;
	int				nRetval	= LMR_ERROR ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntVAR) ;
	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntVAR, &pString, &nString))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	/*	�����R�[�h�ׂ͒��B*/
	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (TCHAR))) ||
#if defined (_MSC_VER) && ( _MSC_VER >= 1400 )
		TFAILED (TVarbuffer_Initialize (&vbufResult, sizeof (TCHAR))) ||
#endif
		TFAILED (TVarbuffer_Initialize (&vbufChar, sizeof (Char))))
		return	LMR_ERROR ;
	if (TFAILED (TVarbuffer_Require (&vbuf, nString + 1)))
		goto	exit_func ;

	pDest	= (LPTSTR) TVarbuffer_GetBuffer (&vbuf) ;
	cstrtostr (pDest, pString, nString) ;
	*(pDest + nString)	= TEXT ('\0') ;

#if defined (_tgetenv_s)
	if (_tgetenv_s (&nReturnSize, NULL, 0, pDest) == 0) {
		Char*		pChResult ;
		int			nResultLength ;

		/*	nReturnSize �� nul character ���܂�ł���B*/
		if (TFAILED (TVarbuffer_Require (&vbufResult, nReturnSize))) 
			goto	exit_func ;
		(void) _tgetenv_s (0, (TCHAR*) TVarbuffer_GetBuffer (&vbufResult), nReturnSize, pDest) ;

		pResult	= (LPCTSTR) TVarbuffer_GetBuffer (&vbufResult) ;
		if (nReturnSize > 0 && *(pResult + nReturnSize - 1) == TEXT ('\0')) {
			nResultLength	= nReturnSize - 1 ;
		} else {
			nResultLength	= nReturnSize ;
		}
		if (TFAILED (TVarbuffer_Require (&vbufChar, nResultLength))) 
			goto	exit_func ;
		pChResult	= (Char*) TVarbuffer_GetBuffer (&vbufChar) ;
		strtocstr (pChResult, pResult, nResultLength) ;
		if (TFAILED (lispMgr_CreateString (pLispMgr, pChResult, nResultLength, &pEntRetval))) {
			goto	exit_func ;
		}
	} else {
		lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
#else
	pResult	= _tgetenv (pDest) ;
	if (pResult != NULL) {
		Char*		pChResult ;
		int			nResult ;

		nResult		= lstrlen (pResult) ;
		if (TFAILED (TVarbuffer_Require (&vbufChar, nResult))) 
			goto	exit_func ;
		pChResult	= TVarbuffer_GetBuffer (&vbufChar) ;
		strtocstr (pChResult, pResult, nResult) ;
		if (TFAILED (lispMgr_CreateString (pLispMgr, pChResult, nResult, &pEntRetval))) {
			goto	exit_func ;
		}
	} else {
		lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
#endif
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	nRetval	= LMR_RETURN ;
exit_func:
	TVarbuffer_Uninitialize (&vbuf) ;
#if defined (_MSC_VER) && ( _MSC_VER >= 1400 )
	TVarbuffer_Uninitialize (&vbufResult) ;
#endif
	TVarbuffer_Uninitialize (&vbufChar) ;
	return	nRetval ;
}


