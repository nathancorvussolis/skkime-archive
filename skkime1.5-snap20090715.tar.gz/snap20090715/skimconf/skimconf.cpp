// skimconf.cpp : �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//
#include "stdafx.h"
#include "skimconf.h"
#include "resource.h"
#include "keymap.h"
#include "TCommuSession.h"
#include "version.h"

#if !defined (ICC_STANDARD_CLASSES)
#define	ICC_STANDARD_CLASSES	0x4000
#endif

#define	MAX_PAGES		16

static	int		CALLBACK	propSheetProc		(HWND, UINT, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgGenericProc		(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgKeybindProc		(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgConversionProc	(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgDictioanryProc	(HWND, UINT, WPARAM, LPARAM) ;
extern	INT_PTR	CALLBACK	DlgColorProc		(HWND, UINT, WPARAM, LPARAM) ;
extern	BOOL				dlgDictionary_bSyncSkkiserv (void) ;


static	struct TPropPageSheetConfig			_srPageSheetTbl []	= {
#if defined (UNICODE) || defined (_UNICODE)
	{ L"�S��",							DlgGenericProc,			IDD_PROPPAGE_GENERIC, },
	{ L"�L�[�ݒ�",						DlgKeybindProc,			IDD_PROPPAGE_KEYBIND, },
	{ L"�ϊ��ݒ�",						DlgConversionProc,		IDD_PROPPAGE_CONVERSION, },
	{ L"�����ݒ�",						DlgDictioanryProc,		IDD_PROPPAGE_DICTIONARY, },
	{ L"�O��",							DlgColorProc,			IDD_PROPPAGE_COLOR, },
#else
	{ "�S��",							DlgGenericProc,			IDD_PROPPAGE_GENERIC, },
	{ "�L�[�ݒ�",						DlgKeybindProc,			IDD_PROPPAGE_KEYBIND, },
	{ "�ϊ��ݒ�",						DlgConversionProc,		IDD_PROPPAGE_CONVERSION, },
	{ "�����ݒ�",						DlgDictioanryProc,		IDD_PROPPAGE_DICTIONARY, },
	{ "�O��",							DlgColorProc,			IDD_PROPPAGE_COLOR, },
#endif
} ;

static	DWORD	_dwTick	= 0 ;

/*
 */
int	APIENTRY
_tWinMain (
	HINSTANCE	hInstance,
	HINSTANCE	hPrevInstance,
	LPTSTR		lpCmdLine,
	int			nCmdShow)
{
	UNREFERENCED_PARAMETER (hPrevInstance) ;
	UNREFERENCED_PARAMETER (lpCmdLine) ;
	UNREFERENCED_PARAMETER (nCmdShow) ;

	// TODO: �����ɃR�[�h��}�����Ă��������B
	INITCOMMONCONTROLSEX	initCtrls ;
	HPROPSHEETPAGE	rPages [MAX_PAGES] ;
	PROPSHEETHEADER	psh ;
	int		i ;
	HKEY	hSubKey ;
	DWORD	dwTick ;
	HWND	hWnd ;

	/*	�Q�d�N���̃`�F�b�N�B
	 */
	hWnd	= 	FindWindow (TEXT ("#32770"), SKKIME_VERSION TEXT("�̃v���p�e�B")) ;
	if (hWnd != NULL) {
		SetForegroundWindow (hWnd) ;
		return	0 ;
	}

	memset (&initCtrls, 0, sizeof (initCtrls)) ;
	initCtrls.dwSize	= sizeof (initCtrls) ;
	initCtrls.dwICC		= ICC_LISTVIEW_CLASSES | ICC_STANDARD_CLASSES ;
	InitCommonControlsEx (&initCtrls) ;

	psh.dwSize		= sizeof (psh) ;
	psh.dwFlags		= PSH_PROPTITLE | PSH_USECALLBACK ;
	psh.hwndParent	= NULL ;

	psh.hInstance	= hInstance ;
	psh.pszIcon		= NULL ;
	psh.pszCaption	= SKKIME_VERSION ;
	psh.nPages		= 0 ;
	psh.nStartPage	= 0 ;
	psh.phpage		= rPages ;
	psh.pfnCallback	= propSheetProc ;

	for (i = 0 ; i < ARRAYSIZE (_srPageSheetTbl) ; i ++) {
		if (! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [i], NULL))
			return	FALSE ;
	}

	dwTick	= 0 ;
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData ;
		LONG	lResult ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		RegCloseKey (hSubKey) ;
	}
	_dwTick	= dwTick ;

	(void) TCommunicateSession_bClassInit () ;
	if (psh.nPages > 0) {
		/* Tick �� update ����B*/
		int	n = PropertySheet (&psh) ;

		if (n > 0) {
			vUpdateTick () ;
			dlgDictionary_bSyncSkkiserv () ;
		}
	}
	return	0 ;
}

BOOL
bNewPageSheet (
	LPPROPSHEETHEADER				ppsh,
	HINSTANCE						hInstance,
	struct TPropPageSheetConfig*	pConfig,
	void*							pvParam)
{
	PROPSHEETPAGE		psp ;

	/* �����̃`�F�b�N�B*/
	if (ppsh == NULL || pConfig == NULL)
		return	FALSE ;
	if (ppsh->nPages >= MAX_PAGES)
		return	FALSE ;

	/* �v���p�e�B�V�[�g�Ƀy�[�W��ǉ�����B*/
	psp.dwSize		= sizeof (psp) ;
	psp.dwFlags		= PSP_DEFAULT | PSP_USETITLE ;
	psp.hInstance	= hInstance ;
	psp.pszTemplate	= MAKEINTRESOURCE(pConfig->m_nResId) ;
	psp.pszIcon		= 0 ;
	psp.pfnDlgProc	= pConfig->m_pDialogProc ;
	psp.pfnCallback	= 0 ;
	psp.pszTitle	= pConfig->m_ptszTitle ;
	psp.lParam		= (LPARAM) pvParam ;
	ppsh->phpage [ppsh->nPages]	= CreatePropertySheetPage (&psp) ;
	if (ppsh->phpage [ppsh->nPages]){
		ppsh->nPages	++ ;
	}
	return	TRUE ;
}

int CALLBACK 
propSheetProc (
	HWND				hwnd,
	UINT				uMsg,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	PSCB_INITIALIZED:
		break ;
	default:
		break ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (hwnd) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

/*========================================================================
 *	public functions
 */
static LPCTSTR		_srpFunctionNameTable [NUM_SELECTABLE_FUNCTIONS]	= {
	TEXT ("self-insert-character"),
	TEXT ("set-mark-command"),
	TEXT ("beginning-of-line"),
	TEXT ("backward-char"),
	NULL,	//	TEXT ("mode-specific-command-prefix"),		/* �@�\�����B*/
	TEXT ("delete-char"),
	TEXT ("end-of-line"),
	TEXT ("foward-char"),
	TEXT ("keyboard-quit"),
	TEXT ("backward-delete-char"),
	NULL,	//	TEXT ("indent-for-tab-command"),			/* �@�\�����B*/
	NULL,	//	TEXT ("newline-and-indent"),				/* �@�\�����B*/
	TEXT ("kill-line"),
	NULL,	//	TEXT ("recenter"),							/* �@�\�����B*/
	TEXT ("newline"),
	NULL,	//	TEXT ("next-line"),							/* �@�\�����B*/
	NULL,	//	TEXT ("open-line"),							/* �@�\�����B*/
	NULL,	//	TEXT ("previous-line"),						/* �@�\�����B*/
	NULL,	//	TEXT ("quated-insert"),						/* �@�\�����B*/
	NULL,	//	TEXT ("isearch-backward"),					/* �@�\�����B*/
	NULL,	//	TEXT ("isearch-forward"),					/* �@�\�����B*/
	TEXT ("transpose-chars"),
	NULL,	//	TEXT ("universal-argument"),				/* �@�\�����B*/
	NULL,	//	TEXT ("scroll-up"),							/* �@�\�����B*/
	TEXT ("kill-region"),
	TEXT ("kill-ring-save"),
	NULL,	//	TEXT ("control-x-prefix"),					/* �@�\�����B*/
	TEXT ("yank"),
	NULL,	//	TEXT ("scroll-down"),
	NULL,	//	TEXT ("prefix-command"),					/* �@�\�����B*/
	TEXT ("exit-recursive-edit"),
	TEXT ("abort-recursive-edit"),
	NULL,	//	TEXT ("undo"),								/* �@�\�����B*/
	TEXT ("toggle-ime"),	// 33
	TEXT ("backward-word"),
	TEXT ("forward-word"),

	NULL,	NULL,	NULL,	NULL,									// 33-39
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 40-47
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 48-55
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 56-63

	/* skk ���� command */
	TEXT ("skk-insert"),
	TEXT ("skk-kakutei"),
	TEXT ("skk-start-henkan"),
	TEXT ("skk-try-completion"),
	TEXT ("skk-delete-backward-char"),
	TEXT ("skk-previous-candidate"),
	TEXT ("skk-toggle-characters"),
	TEXT ("skk-mode"),
	TEXT ("skk-latin-mode"),
	TEXT ("skk-jisx0208-latin-mode"),
	TEXT ("skk-set-henkan-point-subr"),
	TEXT ("skk-purge-from-jisyo"),
	TEXT ("skk-abbrev-mode"),
	TEXT ("skk-display-code-for-char-at-point"),
	TEXT ("skk-today"),
	TEXT ("skk-input-by-code-or-menu"),
	NULL,	//	TEXT ("skk-undo"),							/* �@�\�����B*/
	TEXT ("skk-comp-do"),
	TEXT ("skk-kakutei-henkan"),				/* �H */
	NULL,	//	TEXT ("skk-undo-kakutei-henkan"),			/* �@�\�����B*/
	TEXT ("skk-jisx0208-latin-insert"),
	TEXT ("skk-latin-henkan"),
	TEXT ("skk-abbrev-comma"),
	TEXT ("skk-abbrev-period"),
	TEXT ("skk-toggle-kutouten"),							// 88
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,			// 89-95
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 96-103
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 104-111
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 112-119
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 120-127

	/* non-interactive functions */
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 128
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 136
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 144
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 152

	/* non-interactive functions */
	TEXT ("skk-current-kuten"),										// 160
	TEXT ("skk-current-touten"),
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 168
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	// 176
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,			// 184-190

	/* invalid-char */
	TEXT ("-"),	// 191
} ;

static	LPCTSTR		_rVirtualKeyCodeNames [0x100]	= {
	NULL,	/* 0 */			TEXT ("LButton"),		TEXT ("RButton"),		TEXT ("Cancel"),
	TEXT ("MButton"),		TEXT ("XButton1"),		TEXT ("XButton2"),		NULL,/* undefined */
	TEXT ("Backspace"),		TEXT ("Tab"),			NULL,/* reserved */		NULL,
	TEXT ("Clear"),			TEXT ("Return"),		NULL,/* undefined 0E */	NULL,/* undefined 0F */
	TEXT ("Shift"),			TEXT ("Control"),		TEXT ("Menu"),			TEXT ("Pause"),
	TEXT ("Caps Lock"),		TEXT ("Kana/Hunguel"),	NULL,/* undefined 16 */	TEXT ("Junja"),
	TEXT ("Final"),			TEXT ("Kanji/Hanja"),	NULL,/* undefined */	TEXT ("Escape"),
	TEXT ("Convert"),		TEXT ("Non-Convert"),	TEXT ("Accept"),		TEXT ("Mode-Change"),
	TEXT ("Space"),			TEXT ("Page Up"),		TEXT ("Page Down"),		TEXT ("End"),
	TEXT ("Home"),			TEXT ("Left"),			TEXT ("Up"),			TEXT ("Right"),
	TEXT ("Down"),			TEXT ("Select"),		TEXT ("Print"),			TEXT ("Execute"),
	TEXT ("Print Screen"),	TEXT ("Insert"),		TEXT ("Delete"),		TEXT ("Help"),			
	TEXT ("0"),				TEXT ("1"),				TEXT ("2"),				TEXT ("3"),	
	TEXT ("4"),				TEXT ("5"),				TEXT ("6"),				TEXT ("7"),	
	TEXT ("8"),				TEXT ("9"),				NULL,					NULL,
	NULL,					NULL,					NULL,					NULL,					
	NULL,					TEXT ("A"),				TEXT ("B"),				TEXT ("C"),
	TEXT ("D"),				TEXT ("E"),				TEXT ("F"),				TEXT ("G"),
	TEXT ("H"),				TEXT ("I"),				TEXT ("J"),				TEXT ("K"),
	TEXT ("L"),				TEXT ("M"),				TEXT ("N"),				TEXT ("O"),
	TEXT ("P"),				TEXT ("Q"),				TEXT ("R"),				TEXT ("S"),
	TEXT ("T"),				TEXT ("U"),				TEXT ("V"),				TEXT ("W"),
	TEXT ("X"),				TEXT ("Y"),				TEXT ("Z"),				TEXT ("Left Windows"),
	TEXT ("Right Windows"),	TEXT ("Applications"),	NULL,/* Reserved */		TEXT ("Sleep"),	
	TEXT ("Numpad 0"),		TEXT ("Numpad 1"),		TEXT ("Numpad 2"),		TEXT ("Numpad 3"),
	TEXT ("Numpad 4"),		TEXT ("Numpad 5"),		TEXT ("Numpad 6"),		TEXT ("Numpad 7"),
	TEXT ("Numpad 8"),		TEXT ("Numpad 9"),		TEXT ("Multiply"),		TEXT ("Add"),
	TEXT ("Separator"),		TEXT ("Minus"),			TEXT ("Decimal"),		TEXT ("Divide"),
	TEXT ("F1"),			TEXT ("F2"),			TEXT ("F3"),			TEXT ("F4"),
	TEXT ("F5"),			TEXT ("F6"),			TEXT ("F7"),			TEXT ("F8"),
	TEXT ("F9"),			TEXT ("F10"),			TEXT ("F11"),			TEXT ("F12"),
	TEXT ("F13"),			TEXT ("F14"),			TEXT ("F15"),			TEXT ("F16"),
	TEXT ("F17"),			TEXT ("F18"),			TEXT ("F19"),			TEXT ("F20"),
	TEXT ("F21"),			TEXT ("F22"),			TEXT ("F23"),			TEXT ("F24"),
	NULL,/* unassigned */	NULL,/* unassigned */	NULL,/* unassigned */	NULL,/* unassigned */
	NULL,/* unassigned */	NULL,/* unassigned */	NULL,/* unassigned */	NULL,/* unassigned */
	TEXT ("Num Lock"),		TEXT ("Scroll Lock"),	NULL,/* OEM specific */	NULL,/* OEM specific */
	NULL,/* OEM specific */	NULL,/* OEM specific */	NULL,/* OEM specific */	NULL,/* Unassigned */
	NULL,/* Unassigned */	NULL,/* Unassigned */	NULL,/* Unassigned */	NULL,/* Unassigned */
	NULL,/* Unassigned */	NULL,/* Unassigned */	NULL,/* Unassigned */	NULL,/* Unassigned */
	TEXT ("Left SHIFT"),	TEXT ("Right SHIFT"),	TEXT ("Left CONTROL"),	TEXT ("Right CONTROL"),
	TEXT ("Left MENU"),		TEXT ("Right MENU"),	TEXT ("Browser Back"),	TEXT ("Browser Forward"),
	TEXT ("Browser Refresh"),TEXT ("Browser Stop"),	TEXT ("Browser Search"),TEXT ("Browser Favorites"),
	TEXT ("Browser Home"),	TEXT ("Volume Mute"),	TEXT ("Volume Down"),	TEXT ("Volume Up"),
	TEXT ("Next Track"),	TEXT ("Previous Track"),TEXT ("Stop Media"),	TEXT ("Play/Pause Media"),
	TEXT ("Start Mail"),	TEXT ("Select Media"),	TEXT ("Start Application 1"),TEXT ("Start Application 2"),
	NULL,/* Reserved B8 */	NULL,/* Reserved B9 */	TEXT ("OEM_1 (`;:')"),	TEXT ("OEM_PLUS (`+')"),
	TEXT ("OEM_COMMA (`,')"),TEXT ("OEM_MINUS (`-')"),TEXT ("OEM_PERIOD (`.')"),TEXT ("OEM_2 (`/?')"),
	TEXT ("OEM_3 (``~')"),	NULL,/* Reserved C1 */	NULL,/* Reserved C2 */	NULL,/* Reserved C3 */
	NULL,/* Reserved C4 */	NULL,/* Reserved C5 */	NULL,/* Reserved C6 */	NULL,/* Reserved C7 */
	NULL,/* Reserved C8 */	NULL,/* Reserved C9 */	NULL,/* Reserved CA */	NULL,/* Reserved CB */
	NULL,/* Reserved CC */	NULL,/* Reserved CD */	NULL,/* Reserved CE */	NULL,/* Reserved CF */
	NULL,/* Reserved D0 */	NULL,/* Reserved D1 */	NULL,/* Reserved D2 */	NULL,/* Reserved D3 */
	NULL,/* Reserved D4 */	NULL,/* Reserved D5 */	NULL,/* Reserved D6 */	NULL,/* Reserved D7 */
	NULL,/* Unassigned D8*/	NULL,/* Unassigned D9*/	NULL,/* Unassigned DA*/	TEXT ("OEM_4 (`[{')"),
	TEXT ("OEM_5 (`\\|')"),	TEXT ("OEM_6 (`]}')"),	TEXT ("OEM_7 (single-quote/double-quote)"),	TEXT ("OEM_8"),
	NULL,/* reserved E0 */	TEXT ("OEM_AX"),		TEXT ("OEM_102"),		TEXT ("ICO HELP"),
	TEXT ("ICO 00"),		TEXT ("Process"),		TEXT ("ICO Clear"),		TEXT ("Packet"),
	NULL,/* Unassigned*/	TEXT ("OEM Reset"),		TEXT ("OEM Jump"),		TEXT ("OEM PA1"),
	TEXT ("OEM PA2"),		TEXT ("OEM PA3"),		TEXT ("OEM WSCTRL"),	TEXT ("OEM CUSEL"),
	TEXT ("OEM ATTN"),		TEXT ("OEM FINISH"),	TEXT ("OEM COPY"),		TEXT ("OEM AUTO"),
	TEXT ("OEM ENLW"),		TEXT ("OEM BACKTAB"),	TEXT ("Attn"),			TEXT ("CrSel"),
	TEXT ("ExSel"),			TEXT ("Erase EOF"),		TEXT ("Play"),			TEXT ("Zoom"),
	NULL,/* Reserved FC */	TEXT ("PA1"),			TEXT ("OEM Clear"),		NULL,	/* FF */
} ;

int
iShortStringCopy (
	LPWSTR		pszBuffer,
	int			nBufferSize,
	LPCWSTR		pwString,
	int			nStringLen)
{
	LPWSTR	pwDest, pwDestEnd ;
	LPCWSTR	pwSrc,	pwSrcEnd ;

	pwDest		= pszBuffer ;
	pwSrc		= pwString ;
	pwSrcEnd	= pwString + nStringLen ;
	if (nBufferSize < nStringLen) {
		pwDestEnd	= pszBuffer + nBufferSize - 3 ;
		while (pwDest < pwDestEnd && pwSrc < pwSrcEnd)
			*pwDest ++	= *pwSrc ++ ;
		pwDestEnd	= pszBuffer + nBufferSize ;
		pwSrc		= L"..." ;
		while (pwDest < pwDestEnd && *pwSrc != L'\0')
			*pwDest ++	= *pwSrc ++ ;
	} else {
		pwDestEnd	= pszBuffer + nBufferSize ;
		while (pwDest < pwDestEnd && pwSrc < pwSrcEnd)
			*pwDest ++	= *pwSrc ++ ;
	}
	return	pwDest - pszBuffer ;
}

int
iString2PrintableString (
	LPTSTR		pszBuffer,
	int			nBufferSize,
	LPCWSTR		pwString,
	int			nStringLen)
{
	LPCWSTR	pwSrc,  pwSrcEnd ;
	LPTSTR	pwDest, pwDestEnd ;

	pwDest		= pszBuffer ;
	pwDestEnd	= pszBuffer + nBufferSize ;
	pwSrc		= pwString ;
	pwSrcEnd	= pwString + nStringLen ;
#define	SAFE_COPY(dest,destend,chara)	if ((dest)<(destend)) { *(dest) = (chara) ; (dest) ++ ; }
	while (pwDest < pwDestEnd && pwSrc < pwSrcEnd) {
		if (*pwSrc <= 0x20 || *pwSrc == 0x7F) {
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('\\')) ;
			if (*pwSrc >= 64)
				SAFE_COPY (pwDest, pwDestEnd, TEXT ('0') + (*pwSrc / 64)) ;
			if (*pwSrc >= 8)
				SAFE_COPY (pwDest, pwDestEnd, TEXT ('0') + (0x07 & (*pwSrc / 8))) ;
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('0') + (0x07 & *pwSrc)) ;
		} else if (*pwSrc == TEXT ('\\')) {
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('\\')) ;
			SAFE_COPY (pwDest, pwDestEnd, TEXT ('\\')) ;
		} else {
			SAFE_COPY (pwDest, pwDestEnd, *pwSrc) ;
		}
		pwSrc	++ ;
	}
#undef	SAFE_COPY
	if (pwDest < pwDestEnd)
		*pwDest	= TEXT ('\0') ;
	return	pwDest - pszBuffer ;
}


int
TestConfig_iKeyList2String (
	LPTSTR		pstrBuffer,
	int			nBufferSize,
	LPCWSTR		pwKey)
{
	TCHAR	szBuffer [64] ;
	LPTSTR	pDest ;
	LPCTSTR	pDestEnd ;
	LPTSTR	pSrc ;

	if (pwKey == NULL || pstrBuffer == NULL || nBufferSize <= 0)
		return	0 ;

	pDest		= pstrBuffer ;
	pDestEnd	= pstrBuffer + nBufferSize ;
	while (pDest < pDestEnd && *pwKey != TEXT ('\0')) {
		vKey2String (szBuffer, ARRAYSIZE (szBuffer), *pwKey) ;
		szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;

		pSrc	= szBuffer ;
		while (pSrc != TEXT ('\0') && pDest < pDestEnd) {
			*pDest ++	= *pSrc ++ ;
		}
		pwKey	++ ;
	}
	if (pDest < pDestEnd)
		*pDest	= TEXT ('\0') ;
	return	pDest - pstrBuffer ;
}

void
vKey2String (
	LPTSTR		pstrBuffer,
	int			nBufferSize,
	UINT		uKey)
{
	static LPCTSTR	rpFormat []	= {
		TEXT ("[%s]"), TEXT ("[C-%s]"), TEXT ("[S-%s]"),
	} ;

	if (/*0 <= uKey &&*/ uKey < 0x20) {
		wnsprintf (pstrBuffer, nBufferSize, TEXT ("\\C-%c"), TEXT ("@abcdefghijklmnopqrstuvwxyz[\\]^_") [uKey]) ;
		return ;
	}
	if (uKey == 0x20) {
		lstrcpyn (pstrBuffer, TEXT ("\\40"), nBufferSize) ;
		return ;
	}
	if (0x20 < uKey && uKey < 0x7F) {
		wnsprintf (pstrBuffer, nBufferSize, TEXT ("%c"), uKey) ;
		return ;
	}
	if (uKey == 0x7F) {
		lstrcpyn (pstrBuffer, TEXT ("\\177"), nBufferSize) ;
		return ;
	}
	/*
	if (0x80 <= uKey && uKey < SIZE_MYKEYMAP) {
		register int	nMajor, nMinor ;
		nMajor	= (uKey - 0x80) / NUM_BIND_PER_MYSPECIAL_KEY ;
		nMinor	= (uKey - 0x80) % NUM_BIND_PER_MYSPECIAL_KEY ;
		wsprintf (pstrBuffer, nBufferSize, rpFormat [nMinor], srVkKeyBinds [nMajor].m_pszText) ;
		return ;
	}
	*/
	lstrcpyn (pstrBuffer, TEXT ("undefined"), nBufferSize) ;
	return ;
}

void
vKey2StringEx (
	LPTSTR		pstrBuffer,
	int			nBufferSize,
	UINT		uKeyCode,
	UINT		uKeyMask)
{
	static LPCTSTR	rpFormat []	= {
		TEXT ("[%s]"), TEXT ("[C-%s]"), TEXT ("[S-%s]"),
	} ;
	TCHAR	buf [256] ;
	TCHAR*	pbuf ;
	UINT	uMask ;

	pbuf	= buf ;
	if (uKeyMask & KEYMASK_CONTROL) {
		uMask	= uKeyMask & KEYMASK_CONTROL ;
		if (uMask == KEYMASK_CONTROL) {
			lstrcpy (pbuf, TEXT ("Control-")) ;
		} else if (uMask == KEYMASK_LCONTROL) {
			lstrcpy (pbuf, TEXT ("Left Control-")) ;
		} else {
			lstrcpy (pbuf, TEXT ("Right Control-")) ;
		}
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & KEYMASK_SHIFT) {
		uMask	= uKeyMask & KEYMASK_SHIFT ;
		if (uMask == KEYMASK_SHIFT) {
			lstrcpy (pbuf, TEXT ("Shift-")) ;
		} else if (uMask == KEYMASK_LSHIFT) {
			lstrcpy (pbuf, TEXT ("Left Shift-")) ;
		} else {
			lstrcpy (pbuf, TEXT ("Right Shift-")) ;
		}
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & (KEYMASK_LMENU | KEYMASK_RMENU)) {
		uMask	= uKeyMask & (KEYMASK_LMENU | KEYMASK_RMENU) ;
		if (uMask == (KEYMASK_LMENU | KEYMASK_RMENU)) {
			lstrcpy (pbuf, TEXT ("Alt-")) ;
		} else if (uMask == KEYMASK_LMENU) {
			lstrcpy (pbuf, TEXT ("Left Alt-")) ;
		} else {
			lstrcpy (pbuf, TEXT ("Right Alt-")) ;
		}
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & KEYMASK_NUMLOCK) {
		lstrcpy (pbuf, TEXT ("NumLock-")) ;
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyMask & KEYMASK_SCROLL) {
		lstrcpy (pbuf, TEXT ("ScrollLock-")) ;
		pbuf	+= lstrlen (pbuf) ;
	}
	if (uKeyCode >= ARRAYSIZE (_rVirtualKeyCodeNames) || _rVirtualKeyCodeNames [uKeyCode] == NULL) {
		TCHAR	buf2 [32] ;
		int		n ;
		n	= wnsprintf (buf2, ARRAYSIZE (buf2) - 1, TEXT ("\\x%0x"), uKeyCode) ;
		buf2 [n]	= TEXT ('\0') ;
		lstrcpy (pbuf, buf2) ;
	} else {
		lstrcpy (pbuf, _rVirtualKeyCodeNames [uKeyCode]) ;
	}
	lstrcpyn (pstrBuffer, buf, nBufferSize) ;
	return ;
}

BOOL
bGetKeyFuncName (
	LPTSTR		pBuffer,
	int			nBufferSize,
	int			nFuncNo)
{
	if (pBuffer == NULL || nBufferSize <= 0)
		return	FALSE ;

	if (0 <= nFuncNo && nFuncNo < ARRAYSIZE (_srpFunctionNameTable)) {
		int		n ;

		if (_srpFunctionNameTable [nFuncNo] == NULL)
			return	FALSE ;

		n	= lstrlen (_srpFunctionNameTable [nFuncNo]) ;
		if (n >= nBufferSize) {
			LPTSTR	pDest, pDestEnd ;
			LPCTSTR	pSrc ;

			pDest		= pBuffer ;
			pDestEnd	= pBuffer + nBufferSize - 4 ;
			pSrc		= _srpFunctionNameTable [nFuncNo] ;
			while (pDest < pDestEnd && *pSrc != TEXT ('\0'))
				*pDest ++	= *pSrc ++ ;

			pSrc		= TEXT ("...") ;
			pDestEnd	= pBuffer + nBufferSize ;
			while (pDest < pDestEnd && *pSrc != TEXT ('\0'))
				*pDest ++	= *pSrc ++ ;
			if (pDest < pDestEnd)
				*pDest = TEXT ('\0') ;
		} else {
			lstrcpyn (pBuffer, _srpFunctionNameTable [nFuncNo], nBufferSize) ;
		}
	}  else {
		if (nFuncNo != NFUNC_INVALID_CHAR) {
			pBuffer [0]	= TEXT ('\0') ;
		} else {
			lstrcpyn (pBuffer, TEXT ("-"), nBufferSize) ;
		}
	}
	return	TRUE ;
}

BOOL
EnableDlgItem (
	HWND		hDlg,
	int			nResId,
	BOOL		fEnable)
{
	HWND	hwndCtl ;

	hwndCtl	= GetDlgItem (hDlg, nResId) ;
	if (hwndCtl == NULL)
		return	FALSE ;
	EnableWindow (hwndCtl, fEnable) ;
	return	TRUE ;
}

BOOL
SetDropDownListCurrentSelectionByData (
	HWND		hDlg,
	int			nResId,
	int			nData)
{
	HWND	hwndControl ;
	int		nItemCount, i, nValue ;

	hwndControl	= GetDlgItem (hDlg, nResId) ;
	if (hwndControl == NULL)
		return	FALSE ;
	nItemCount	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
	if (nItemCount == CB_ERR)
		return	FALSE ;
	for (i = 0 ; i < nItemCount ; i ++) {
		nValue	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
		if (nValue != CB_ERR && nValue == nData) {
			return	(SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) != CB_ERR) ;
		}
	}
	SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
	return	FALSE ;
}

BOOL
IsRadioButtonChecked (
	HWND		hDlg,
	int			nRadioIdStart,
	int			nRadioIdEnd,
	int			nRadioId)
{
	int		nIDButton ;

	for (nIDButton = nRadioIdStart ; nIDButton <= nRadioIdEnd ; nIDButton ++) {
		if (nIDButton == nRadioId)
			continue ;
		if (IsDlgButtonChecked (hDlg, nIDButton) != BST_UNCHECKED)
			return	FALSE ;
	}
	return	TRUE ;
}

BOOL
bCreateRegistryKey (
	LPCTSTR		pstrSubKey,
	BOOL		fClean,
	HKEY*		phKey)
{
	HKEY	hSubKey ;
	DWORD	dwDispose ;
	LONG	lResult ;

	if (pstrSubKey == NULL || phKey == NULL)
		return	FALSE ;

	if (fClean) {
		lResult	= RegDeleteKey (HKEY_CURRENT_USER, pstrSubKey) ;
	}
	if (RegCreateKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, NULL, &hSubKey, &dwDispose) != ERROR_SUCCESS) {
		return	FALSE ;
	}
	*phKey	= hSubKey ;
	return	TRUE ;
}

int
iPopupMenu (
	HWND					hwndOwner,
	const struct TMENUITEM*	pMenuItem,
	int						nMenuItem)
{
	HMENU				hMenu	= CreatePopupMenu () ;
	static MENUITEMINFO	mmi ;
	POINT				pt ;
	int					i, n ;

	memset (&mmi, 0, sizeof (mmi)) ;
	mmi.cbSize	= sizeof (mmi) ;
	for (i = 0 ; i < nMenuItem ; i ++) {
#if(WINVER >= 0x0500)
		mmi.fMask		= pMenuItem->m_fMask ;
#else
		mmi.fMask		= pMenuItem->m_fMask | 0x00000140 ;
#endif
		mmi.fType		= pMenuItem->m_fType ;
		mmi.dwTypeData	= (LPTSTR) pMenuItem->m_strText ;
		mmi.wID			= pMenuItem->m_wID ;
		mmi.fState		= pMenuItem->m_fState ;
		mmi.cch			= lstrlen (pMenuItem->m_strText) ;
		InsertMenuItem (hMenu, i, TRUE, &mmi) ;
		pMenuItem	++ ;
	}
	if (! GetCursorPos (&pt)) 
		pt.x	= pt.y	= 0 ;
	n	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwndOwner, NULL) ;
	DestroyMenu (hMenu) ;
	return	n ;
}

BOOL
bParseBSEncodedString (
	LPCTSTR*	ppwSrc,
	LPTSTR		pwDest,
	int			nDestSize,
	BOOL*		pbTerminated)
{
	LPCTSTR	pwSrc ;
	LPTSTR	pwDestLast ;
	int		nCH ;

	pwSrc		= *ppwSrc ;
	pwDestLast	= pwDest + nDestSize ;
	while (*pwSrc != TEXT ('\0') && pwDest < pwDestLast) {
		if (*pwSrc == TEXT ('\\')) {
			pwSrc	++ ;
			nCH		= *pwSrc ;
			if (nCH == TEXT ('\0')) {
				break ;
			} else if (nCH == TEXT ('0')) {
				/* �I�[�B*/
				pwSrc ++ ;
				break ;
			} else {
				*pwDest ++	= nCH ;
			}
		} else {
			*pwDest ++	= *pwSrc ;
		}
		pwSrc	++ ;
	}
	if (pwDest < pwDestLast)
		*pwDest	= TEXT ('\0') ;
	*pbTerminated	= (*pwSrc == TEXT ('\0')) ;
	*ppwSrc			= pwSrc ;
	return	TRUE ;
}

int
iCountBSEncodedString (
	LPCTSTR		strString)
{
	LPCTSTR		pwSrc ;
	int			nCount ;

	nCount	= 0 ;
	if (strString != NULL) {
		pwSrc	= strString ;
		while (*pwSrc != TEXT ('\0')) {
			nCount	+= (*pwSrc == TEXT ('\\'))? 2 : 1 ;
			pwSrc	++ ;
		}
	}
	return	nCount ;
}

int
iBSEncodeString (
	LPTSTR		pwDest,
	LPCTSTR		pwSrc)
{
	LPTSTR	pwDestBak ;

	if (pwSrc == NULL)
		return	0 ;

	pwDestBak	= pwDest ;
	while (*pwSrc != TEXT ('\0')) {
		if (*pwSrc == TEXT ('\\')) {
			*pwDest ++	= TEXT ('\\') ;
			*pwDest ++	= TEXT ('\\') ;
		} else {
			*pwDest ++	= *pwSrc ;
		}
		pwSrc	++ ;
	}
	return	(pwDest - pwDestBak) ;
}

int
iCountBSEncodedInteger (
	int			iValue)
{
	TCHAR	bufText [64] ;
	int		nText ;

	nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d"), iValue) ;
	bufText [nText]	= TEXT ('\0') ;
	return	iCountBSEncodedString (bufText) ;
}
int
iBSEncodeInteger (
	LPTSTR		pwDest,
	int			iValue)
{
	TCHAR	bufText [64] ;
	int		nText ;

	nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d"), iValue) ;
	bufText [nText]	= TEXT ('\0') ;
	return	iBSEncodeString (pwDest, bufText) ;
}


void
vUpdateTick (void)
{
	HKEY	hKey ;

	_dwTick	++ ;
	if (bCreateRegistryKey (REGPATH_GENERIC, FALSE, &hKey)) {
		(void) RegSetValueEx (hKey, REGINFO_TICK, 0, REG_DWORD, (BYTE*) &_dwTick, sizeof (DWORD)) ;
		RegCloseKey (hKey) ;
	}
	return ;
}

#if 0



#include "stdafx.h"
#include "skimconf.h"

#define MAX_LOADSTRING 100

// �O���[�o���ϐ�:
static	HINSTANCE	hInst ;									// ���݂̃C���^�[�t�F�C�X
static	TCHAR		szTitle			[MAX_LOADSTRING] ;		// �^�C�g�� �o�[�̃e�L�X�g
static	TCHAR		szWindowClass	[MAX_LOADSTRING] ;		// ���C�� �E�B���h�E �N���X��





// ���̃R�[�h ���W���[���Ɋ܂܂��֐��̐錾��]�����܂�:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);




int APIENTRY
_tWinMain (
	HINSTANCE	hInstance,
	HINSTANCE	hPrevInstance,
	LPTSTR		lpCmdLine,
	int			nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: �����ɃR�[�h��}�����Ă��������B



	MSG		msg ;
	HACCEL	hAccelTable ;

	// �O���[�o������������������Ă��܂��B
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_SKIMCONF, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance) ;

	// �A�v���P�[�V�����̏����������s���܂�:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_SKIMCONF));

	// ���C�� ���b�Z�[�W ���[�v:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  �֐�: MyRegisterClass()
//
//  �ړI: �E�B���h�E �N���X��o�^���܂��B
//
//  �R�����g:
//
//    ���̊֐�����юg�����́A'RegisterClassEx' �֐����ǉ����ꂽ
//    Windows 95 ���O�� Win32 �V�X�e���ƌ݊�������ꍇ�ɂ̂ݕK�v�ł��B
//    �A�v���P�[�V�������A�֘A�t����ꂽ
//    �������`���̏������A�C�R�����擾�ł���悤�ɂ���ɂ́A
//    ���̊֐����Ăяo���Ă��������B
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SKIMCONF));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_SKIMCONF);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   �֐�: InitInstance(HINSTANCE, int)
//
//   �ړI: �C���X�^���X �n���h����ۑ����āA���C�� �E�B���h�E���쐬���܂��B
//
//   �R�����g:
//
//        ���̊֐��ŁA�O���[�o���ϐ��ŃC���X�^���X �n���h����ۑ����A
//        ���C�� �v���O���� �E�B���h�E���쐬����ѕ\�����܂��B
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // �O���[�o���ϐ��ɃC���X�^���X�������i�[���܂��B

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  �֐�: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  �ړI:  ���C�� �E�B���h�E�̃��b�Z�[�W���������܂��B
//
//  WM_COMMAND	- �A�v���P�[�V���� ���j���[�̏���
//  WM_PAINT	- ���C�� �E�B���h�E�̕`��
//  WM_DESTROY	- ���~���b�Z�[�W��\�����Ė߂�
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message)
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// �I�����ꂽ���j���[�̉��:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: �`��R�[�h�������ɒǉ����Ă�������...
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// �o�[�W�������{�b�N�X�̃��b�Z�[�W �n���h���ł��B
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
#endif

