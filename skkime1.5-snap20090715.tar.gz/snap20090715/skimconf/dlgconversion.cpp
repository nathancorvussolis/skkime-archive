#include "stdafx.h"
#include "skimconf.h"
#include "keymap.h"

/*========================================================================
 *	registry-related definitions
 */
#define	REGPATH_CONVERSION					TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\Conversion")
#define	REGINFO_CANDLISTKEYASSIGN			TEXT("CandidateListKeyAssign")
#define	REGINFO_SHOWCANDIDATEKEYS			TEXT("ShowCandidateKeys")
#define	REGINFO_INPUTCODEMENU1KEYS			TEXT("InputCodeMenu1Keys")
#define	REGINFO_INPUTCODEMENU2KEYS			TEXT("InputCodeMenu2Keys")
#define	REGINFO_SHOWCANDIDATELISTCOUNT		TEXT("ShowCandidateListCount")
#define	REGINFO_HENKANOKURISTRICTLY			TEXT("HenkanOkuriStrictly")
#define	REGINFO_PROCESSOKURIEARLY			TEXT("ProcessOkuriEarly")
#define	REGINFO_HENKANSTRICTOKURIPRECEDENCE	TEXT("HenkanStrictOkuriPrecedence")
#define	REGINFO_AUTOOKURIPROCESS			TEXT("AutoOkuriProcess")
#define	REGINFO_AUTOSTARTHENKAN				TEXT("AutoStartHenkan")
#define	REGINFO_AUTOSTARTHENKANKEYWORD		TEXT("AutoStartHenkanKeyword")
#define	REGINFO_DELETEOKURIWHENQUIT			TEXT("DeleteOkuriWhenQuit")
#define	REGINFO_SHOWANNOTATIONTYPE			TEXT("ShowAnnotationType")
#define	REGINFO_NUMERICCONVERSION			TEXT("NumericConversion")
#define	REGINFO_NUMERICFLOAT				TEXT("NumericFloat")

/*========================================================================
 *	definitions
 */
#define	MAX_NUMMENUKEYS	256

enum {
	CANDLIST_KEYASSIGN_DEFAULT		= 0,
	CANDLIST_KEYASSIGN_01234567890,
	CANDLIST_KEYASSIGN_USERDEFINED	= 65535,
} ;

enum {
	SHOWCANDLIST_COUNT_ZERO			= 0,

	SHOWCANDLIST_COUNT_NOSHOW		= 65534,
	SHOWCANDLIST_COUNT_USERDEFINED	= 65535,
} ;

enum {
	DISABLE_ANNOTATION				= -1,
	SHOW_NO_ANNOTATION				= 0,
	SHOW_ANNOTATION_IN_CANDLIST,
	SHOW_ANNOTATION_ALWAYS,
} ;

#define	MAXLEN_AUTOSTARTHENKAN_KEYWORD	32

enum {
	DEFAULT_HENKAN_OKURI_STRICTLY			= FALSE,
	DEFAULT_PROCESS_OKURI_EARLY				= FALSE,
	DEFAULT_HENKAN_STRICT_OKURI_PRECEDENCE	= FALSE,
	DEFAULT_AUTO_OKURI_PROCESS				= FALSE,
} ;

/*========================================================================
 *	structures
 */
struct TEditMenuKeysArg {
	int		m_nNumCandKeys ;
	BYTE	m_rbCandKeys  [MAX_NUMMENUKEYS] ;
	int		m_nNumMenu1Keys ;
	BYTE	m_rbMenu1Keys [MAX_NUMMENUKEYS] ;
	int		m_nNumMenu2Keys ;
	BYTE	m_rbMenu2Keys [MAX_NUMMENUKEYS] ;
	int		m_iFocus ;
} ;

struct TKeySelectArg {
	int				m_nNumUsedKeys ;
	BYTE*			m_pbUsedKeys ;
	int				m_nCurSel ;
} ;

struct TEditAutoStartHenkanArg {
	int				m_nKeywords ;
	TCHAR			m_bufKeywords [1024] ;
} ;

/*========================================================================
 *	prototypes
 */
static	int		dlgConversion_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	int		dlgConversion_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgConversion_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void	dlgConversion_vSyncControls	(HWND) ;
static	BOOL	dlgConversion_bEditMenuKeys	(HWND) ;
static	BOOL	dlgConversion_bEditAutoStartHenkanKeyword	(HWND) ;

static	BOOL	dlgConversion_bLoadRegistrySetting		(void) ;
static	BOOL	dlgConversion_bSaveSettingToRegistry	(void) ;
static	void	dlgConversion_vLoadDefaultSetting		(void) ;

static	INT_PTR	CALLBACK	dlgEditMenuKeysProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditAutoStartHenkanProc	(HWND, UINT, WPARAM, LPARAM) ;

/*========================================================================
 *	constant global variables
 */
static	const BYTE	_srbDefaultCandidateKeys []	= {
	'A', 'S', 'D', 'F', 'J', 'K', 'L', 'Q', 'W', 'U', 'I', 'O', 'Z', 'C', 'V', 'B', 'M',
} ;

static	const BYTE	_srbDefaultMenu1Keys []	= {
	'A', 'S', 'D', 'F', 'G', 'H', 'Q', 'W', 'E', 'R', 'T', 'Y',
} ;

static	const BYTE	_srbDefaultMenu2Keys []	= {
	'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U',
} ;

static	const BYTE	_srb10Keys []	= {
	'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 
} ;

/* 28 keywords */
static	const TCHAR	_srDefaultAutoStartHenkanKeywords []	= TEXT ("��\0�A\0�B\0�D\0�C\0�H\0�v\0�I\0�G\0�F\0)\0;\0:\0�j\0�h\0�z\0�x\0�t\0�r\0�p\0�n�l\0}\0]\0?\0.\0,\0!\0\0") ;

/*========================================================================
 *	global variables
 */
static	int		_snCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;

static	int		_snNumShowCandidateKeys ;
static	int		_snNumInputCodeMenu1Keys ;
static	int		_snNumInputCodeMenu2Keys ;
static	BYTE	_srbyShowCandidateKeys  [MAX_NUMMENUKEYS]	= { 0 } ;
static	BYTE	_srbyInputCodeMenu1Keys [MAX_NUMMENUKEYS]	= { 0 } ;
static	BYTE	_srbyInputCodeMenu2Keys [MAX_NUMMENUKEYS]	= { 0 } ;
static	int		_snShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;

static	BOOL	_sbHenkanOkuriStrictly			= FALSE ;
static	BOOL	_sbProcessOkuriEarly			= FALSE ;
static	BOOL	_sbHenkanStrictOkuriPrecedence	= FALSE ;
static	BOOL	_sbAutoStartHenkan				= TRUE ;
static	BOOL	_sbDeleteOkuriWhenQuit			= FALSE ;
static	BOOL	_sbAutoOkuriProcess				= FALSE ;

static	BOOL	_sbNumericConversion			= TRUE ;
static	BOOL	_sbNumericFloat					= FALSE ;

static	int		_siNumAutoStartHenkanKeywords		= 0 ;
static	TCHAR	_srAutoStartHenkanKeywords [1024]	= { TEXT ('\0') } ;

static	int		_snShowAnnotationType			= SHOW_NO_ANNOTATION ;
static	HICON	_hiconArrowDown					= NULL ;
static	HICON	_hiconArrowUp					= NULL ;

/*========================================================================
 *	public	functions
 */
INT_PTR	CALLBACK
DlgConversionProc (
	HWND			hDlg,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgConversion_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgConversion_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgConversion_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	private	functions (dialog message handler)
 */
int
dlgConversion_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	/*	"ASDFJKLQWRUIOZCVBM,"(7n),
	 *	"ASDFGHQWERTY"(12)
	 *	"ASDFGHJKLQWERTYU"(16)
	 */
	static	struct {
		LPCTSTR	m_strTitle ;
		int		m_nValue ;
	}	_srCandListKeyAssign []	= {
		{	TEXT ("default"),		CANDLIST_KEYASSIGN_DEFAULT	},		/*  7-12-16 */
		{	TEXT ("1234567890"),	CANDLIST_KEYASSIGN_01234567890	},	/* 10-10-10 */
		/* {	TEXT ("���[�U��`"),	CANDLIST_KEYASSIGN_USERDEFINED	},	/* ����͎��ۂɃ��[�U��`������ĂȂ��ƕ\�����Ȃ��B*/
	},	_srShowCandListCount []	= {
		{	TEXT ("���ꗗ�Ȃ�"),	SHOWCANDLIST_COUNT_NOSHOW	},
		{	TEXT ("0"),				SHOWCANDLIST_COUNT_ZERO	},
		{	TEXT ("1"),				SHOWCANDLIST_COUNT_ZERO+1	},
		{	TEXT ("2"),				SHOWCANDLIST_COUNT_ZERO+2	},
		{	TEXT ("3 (default)"),	SHOWCANDLIST_COUNT_ZERO+3	},
		{	TEXT ("4"),				SHOWCANDLIST_COUNT_ZERO+4	},
		{	TEXT ("5"),				SHOWCANDLIST_COUNT_ZERO+5	},
		/* {	TEXT ("���[�U��`"),	SHOWCANDLIST_COUNT_USERDEFINED	},	/* ����͎��ۂɃ��[�U��`������ĂȂ��ƕ\�����Ȃ��B*/
	} ;
	PROPSHEETPAGE*	pPropPage	= (PROPSHEETPAGE*) lParam ;
	int		i, nItem ;
	HWND	hwndControl ;

	if (pPropPage != NULL) {
		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pPropPage->lParam) ;
	} else {
		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) 0) ;
	}

	/*
	IDC_COMBO_SHOWCANDLIST_COUNT
	IDC_COMBO_CANDLIST_KEYASSIGN
	 */
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SHOWCANDLIST_COUNT) ;
	if (hwndControl != NULL) {
		for (i = 0 ; i < ARRAYSIZE (_srShowCandListCount) ; i ++) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) _srShowCandListCount [i].m_strTitle) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) _srShowCandListCount [i].m_nValue) ;
			}
		}
	}
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_CANDLIST_KEYASSIGN) ;
	if (hwndControl != NULL) {
		for (i = 0 ; i < ARRAYSIZE (_srCandListKeyAssign) ; i ++) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) _srCandListKeyAssign [i].m_strTitle) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) _srCandListKeyAssign [i].m_nValue) ;
			}
		}
	}
	if (! dlgConversion_bLoadRegistrySetting ())
		dlgConversion_vLoadDefaultSetting () ;
	dlgConversion_vSyncControls (hDlg) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}


int
dlgConversion_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;
	BOOL	bUpdate			= FALSE ;

	switch (woControl) {
	case	IDC_CHECK_AUTO_START_HENKAN:
		_sbAutoStartHenkan	= IsDlgButtonChecked (hDlg, IDC_CHECK_AUTO_START_HENKAN) == BST_CHECKED ;
		bUpdate				= TRUE ;
		break ;
	case	IDC_CHECK_HENKAN_OKURI_STRICTLY:
		_sbHenkanOkuriStrictly	= IsDlgButtonChecked (hDlg, IDC_CHECK_HENKAN_OKURI_STRICTLY) == BST_CHECKED ;
		bUpdate				= TRUE ;
		break ;
	case	IDC_CHECK_PROCESS_OKURI_EARLY:
		_sbProcessOkuriEarly	= IsDlgButtonChecked (hDlg, IDC_CHECK_PROCESS_OKURI_EARLY) == BST_CHECKED ;
		bUpdate				= TRUE ;
		break ;
	case	IDC_CHECK_HENKAN_STRICT_OKURI_PRECEDENCE:
		_sbHenkanStrictOkuriPrecedence	= IsDlgButtonChecked (hDlg, IDC_CHECK_HENKAN_STRICT_OKURI_PRECEDENCE) == BST_CHECKED ;
		bUpdate				= TRUE ;
		break ;
	case	IDC_CHECK_DELETE_OKURI_WHEN_QUIT:
		_sbDeleteOkuriWhenQuit	= IsDlgButtonChecked (hDlg, IDC_CHECK_DELETE_OKURI_WHEN_QUIT) == BST_CHECKED ;
		bUpdate				= TRUE ;
		break ;
	case	IDC_CHECK_NUMERICFLOAT:
		_sbNumericFloat		= IsDlgButtonChecked (hDlg, IDC_CHECK_NUMERICFLOAT) == BST_CHECKED ;
		bUpdate				= TRUE ;
		break ;
	case	IDC_CHECK_AUTO_OKURI_PROCESS:
		_sbAutoOkuriProcess	= IsDlgButtonChecked (hDlg, IDC_CHECK_AUTO_OKURI_PROCESS) == BST_CHECKED ;
		bUpdate				= TRUE ;
		break ;
	case	IDC_RADIO_DISABLE_ANNOTATION:
	case	IDC_RADIO_SHOW_NO_ANNOTATION:
	case	IDC_RADIO_SHOW_ANNOTATION_IN_CANDLIST:
	case	IDC_RADIO_SHOW_ANNOTATION_ALWAYS:
		if (woNotification == BN_CLICKED) {
			BOOL	bChanged ;

			bChanged	= ! IsRadioButtonChecked (hDlg, IDC_RADIO_DISABLE_ANNOTATION, IDC_RADIO_SHOW_ANNOTATION_ALWAYS, woControl) ;
			if (bChanged) {
				CheckRadioButton (hDlg, IDC_RADIO_DISABLE_ANNOTATION, IDC_RADIO_SHOW_ANNOTATION_ALWAYS, woControl) ;
				_snShowAnnotationType	= (woControl != IDC_RADIO_DISABLE_ANNOTATION)? (woControl - IDC_RADIO_SHOW_NO_ANNOTATION + SHOW_NO_ANNOTATION) : DISABLE_ANNOTATION ; 
				bUpdate	= TRUE ;
			}
		}
		break ;
	case	IDC_COMBO_CANDLIST_KEYASSIGN:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl ;
			int		nItem ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_CANDLIST_KEYASSIGN) ;
			if (hwndControl != NULL && IsWindow (hwndControl)) {
				nItem		= SendMessage (hwndControl, CB_GETCURSEL, 0, 0) ;
				if (nItem != CB_ERR) {
					LRESULT	lData ;

					lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nItem, (LPARAM) 0) ;
					if (lData != CB_ERR && _snCandListKeyAssign != (int) lData) {
						_snCandListKeyAssign	= (int) lData ;
						bUpdate	= TRUE ;
					}
				}
			}
		}
		break;
	case	IDC_COMBO_SHOWCANDLIST_COUNT:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl ;
			int		nItem ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SHOWCANDLIST_COUNT) ;
			if (hwndControl != NULL && IsWindow (hwndControl)) {
				nItem		= SendMessage (hwndControl, CB_GETCURSEL, 0, 0) ;
				if (nItem != CB_ERR) {
					LRESULT	lData ;

					lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nItem, (LPARAM) 0) ;
					if (lData != CB_ERR && _snShowCandListCount != (int) lData) {
						_snShowCandListCount	= (int) lData ;
						bUpdate	= TRUE ;
					}
				}
			}
		}
		break;
	case	IDC_BUTTON_CONFIGCANDKEY:
		if (dlgConversion_bEditMenuKeys (hDlg)) 
			bUpdate	= TRUE ;
		break ;
	case	IDC_BUTTON_EDIT_AUTOSTARTHENKAN_KEYWORD:
		if (dlgConversion_bEditAutoStartHenkanKeyword (hDlg)) 
			bUpdate	= TRUE ;
		break ;
	case	IDC_CHECK_NUMERICCONVERSION:
		if (woNotification == BN_CLICKED) {
			_sbNumericConversion	= IsDlgButtonChecked (hDlg, IDC_CHECK_NUMERICCONVERSION) == BST_CHECKED ;
			EnableDlgItem (hDlg, IDC_CHECK_NUMERICFLOAT, _sbNumericConversion) ;
			bUpdate	= TRUE ;
		}
		break ;
	default:
		break ;
	}
	if (bUpdate) {
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	0 ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgConversion_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->code) {
	case	PSN_APPLY:
		if (dlgConversion_bSaveSettingToRegistry ())
			vUpdateTick () ;
		break ;
	case	PSN_RESET:
		if (! dlgConversion_bLoadRegistrySetting ())
			dlgConversion_vLoadDefaultSetting () ;
		dlgConversion_vSyncControls (hDlg) ;
		break ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgConversion_vSyncControls (
	HWND			hDlg)
{
	WORD	woControl ;
	static LPCTSTR	wpUserDefined	= TEXT ("���[�U��`") ;

	CheckDlgButton (hDlg, IDC_CHECK_HENKAN_OKURI_STRICTLY,			_sbHenkanOkuriStrictly?			BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_PROCESS_OKURI_EARLY,			_sbProcessOkuriEarly?			BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_HENKAN_STRICT_OKURI_PRECEDENCE,	_sbHenkanStrictOkuriPrecedence?	BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_AUTO_START_HENKAN,				_sbAutoStartHenkan?				BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_DELETE_OKURI_WHEN_QUIT,			_sbDeleteOkuriWhenQuit?			BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_AUTO_OKURI_PROCESS,				_sbAutoOkuriProcess?			BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_NUMERICCONVERSION,				_sbNumericConversion?			BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_NUMERICFLOAT,					_sbNumericFloat?				BST_CHECKED : BST_UNCHECKED) ;
	EnableDlgItem (hDlg, IDC_CHECK_NUMERICFLOAT, _sbNumericConversion) ;

	/*	��芸���� default �ɐݒ肷��B
	 */
	if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED) {
		HWND	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_CANDLIST_KEYASSIGN) ;

		if (hwndControl != NULL && IsWindow (hwndControl) && SendMessage (hwndControl, CB_FINDSTRING, (WPARAM) 0, (LPARAM) wpUserDefined) == CB_ERR) {
			int	iIndex ;
			iIndex	= SendMessage (hwndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) wpUserDefined) ;
			if (iIndex >= 0) 
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) iIndex, (LPARAM) CANDLIST_KEYASSIGN_USERDEFINED) ;
		}
	}
	if (_snShowCandListCount == SHOWCANDLIST_COUNT_USERDEFINED) {
		HWND	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SHOWCANDLIST_COUNT) ;

		if (hwndControl != NULL && IsWindow (hwndControl) && SendMessage (hwndControl, CB_FINDSTRING, (WPARAM) 0, (LPARAM) wpUserDefined) == CB_ERR) {
			int	iIndex ;
			iIndex	= SendMessage (hwndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) wpUserDefined) ;
			if (iIndex >= 0) 
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) iIndex, (LPARAM) SHOWCANDLIST_COUNT_USERDEFINED) ;
		}
	}
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_CANDLIST_KEYASSIGN, _snCandListKeyAssign) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_SHOWCANDLIST_COUNT, _snShowCandListCount) ;

	switch (_snShowAnnotationType) {
	case	SHOW_ANNOTATION_IN_CANDLIST:
		woControl	= IDC_RADIO_SHOW_ANNOTATION_IN_CANDLIST ;
		break ;
	case	SHOW_ANNOTATION_ALWAYS:
		woControl	= IDC_RADIO_SHOW_ANNOTATION_ALWAYS ;
		break ;
	case	DISABLE_ANNOTATION:
		woControl	= IDC_RADIO_DISABLE_ANNOTATION ;
		break ;
	case	SHOW_NO_ANNOTATION:
	default:
		woControl	= IDC_RADIO_SHOW_NO_ANNOTATION ;
		_snShowAnnotationType	= SHOW_NO_ANNOTATION ;
		break ;
	}
	CheckRadioButton (hDlg, IDC_RADIO_DISABLE_ANNOTATION, IDC_RADIO_SHOW_ANNOTATION_ALWAYS, woControl) ;
	return ;
}

BOOL
dlgConversion_bEditMenuKeys (
	HWND			hDlg)
{
	struct TEditMenuKeysArg	arg ;
	int			nRetval ;
	HINSTANCE	hInst ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;

	memset (&arg, 0, sizeof (arg)) ;
	switch (_snCandListKeyAssign) {
	case	CANDLIST_KEYASSIGN_01234567890:
		arg.m_nNumCandKeys	= ARRAYSIZE (_srb10Keys) ;
		arg.m_nNumMenu1Keys	= ARRAYSIZE (_srb10Keys) ;
		arg.m_nNumMenu2Keys	= ARRAYSIZE (_srb10Keys) ;
		memcpy (arg.m_rbCandKeys,	_srb10Keys,		ARRAYSIZE (_srb10Keys)) ; 
		memcpy (arg.m_rbMenu1Keys,	_srb10Keys,		ARRAYSIZE (_srb10Keys)) ; 
		memcpy (arg.m_rbMenu2Keys,	_srb10Keys,		ARRAYSIZE (_srb10Keys)) ; 
		break ;
	case	CANDLIST_KEYASSIGN_USERDEFINED:
		arg.m_nNumCandKeys	= _snNumShowCandidateKeys ;
		arg.m_nNumMenu1Keys	= _snNumInputCodeMenu1Keys ;
		arg.m_nNumMenu2Keys	= _snNumInputCodeMenu2Keys ;
		memcpy (arg.m_rbCandKeys,	_srbyShowCandidateKeys,		_snNumShowCandidateKeys) ; 
		memcpy (arg.m_rbMenu1Keys,	_srbyInputCodeMenu1Keys,	_snNumInputCodeMenu1Keys) ; 
		memcpy (arg.m_rbMenu2Keys,	_srbyInputCodeMenu2Keys,	_snNumInputCodeMenu2Keys) ; 
		break; 
	case	CANDLIST_KEYASSIGN_DEFAULT:
	default:
		arg.m_nNumCandKeys	= ARRAYSIZE (_srbDefaultCandidateKeys) ;
		arg.m_nNumMenu1Keys	= ARRAYSIZE (_srbDefaultMenu1Keys) ;
		arg.m_nNumMenu2Keys	= ARRAYSIZE (_srbDefaultMenu2Keys) ;
		memcpy (arg.m_rbCandKeys,	_srbDefaultCandidateKeys,	ARRAYSIZE (_srbDefaultCandidateKeys)) ; 
		memcpy (arg.m_rbMenu1Keys,	_srbDefaultMenu1Keys,		ARRAYSIZE (_srbDefaultMenu1Keys)) ; 
		memcpy (arg.m_rbMenu2Keys,	_srbDefaultMenu2Keys,		ARRAYSIZE (_srbDefaultMenu2Keys)) ; 
		break ;
	}
	nRetval	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_MENUKEYS), hDlg, dlgEditMenuKeysProc, (LPARAM) &arg) ;
	if (nRetval != IDOK)
		return	TRUE ;

	_snCandListKeyAssign		= CANDLIST_KEYASSIGN_USERDEFINED ;
	_snNumShowCandidateKeys		= arg.m_nNumCandKeys ;
	_snNumInputCodeMenu1Keys	= arg.m_nNumMenu1Keys ;
	_snNumInputCodeMenu2Keys	= arg.m_nNumMenu2Keys ;
	memcpy (_srbyShowCandidateKeys,		arg.m_rbCandKeys,	_snNumShowCandidateKeys) ; 
	memcpy (_srbyInputCodeMenu1Keys,	arg.m_rbMenu1Keys,	_snNumInputCodeMenu1Keys) ; 
	memcpy (_srbyInputCodeMenu2Keys,	arg.m_rbMenu2Keys,	_snNumInputCodeMenu2Keys) ; 

	dlgConversion_vSyncControls (hDlg) ;
	return	TRUE ;
}

BOOL
dlgConversion_bEditAutoStartHenkanKeyword (
	HWND		hDlg)
{
	struct TEditAutoStartHenkanArg	arg ;
	int			nRetval ;
	HINSTANCE	hInst ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	arg.m_nKeywords	= _siNumAutoStartHenkanKeywords ;
	memcpy (arg.m_bufKeywords, _srAutoStartHenkanKeywords, sizeof (_srAutoStartHenkanKeywords)) ;
	nRetval	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_AUTOSTARTHENKAN), hDlg, dlgEditAutoStartHenkanProc, (LPARAM) &arg) ;
	if (nRetval != IDOK)
		return	FALSE ;
	_siNumAutoStartHenkanKeywords	= arg.m_nKeywords ;
	memcpy (_srAutoStartHenkanKeywords, arg.m_bufKeywords, sizeof (_srAutoStartHenkanKeywords)) ;
	return	TRUE ;
}

static struct {
	LPCTSTR		m_strInfoKey ;
	BOOL*		m_pbData ;
}	_srRegBoolValues []	= {
	{	REGINFO_HENKANOKURISTRICTLY,			&_sbHenkanOkuriStrictly,			},
	{	REGINFO_PROCESSOKURIEARLY,				&_sbProcessOkuriEarly,				},
	{	REGINFO_HENKANSTRICTOKURIPRECEDENCE,	&_sbHenkanStrictOkuriPrecedence,	},
	{	REGINFO_AUTOSTARTHENKAN,				&_sbAutoStartHenkan,				},
	{	REGINFO_DELETEOKURIWHENQUIT,			&_sbDeleteOkuriWhenQuit,			},
	{	REGINFO_AUTOOKURIPROCESS,				&_sbAutoOkuriProcess,				},
	{	REGINFO_NUMERICCONVERSION,				&_sbNumericConversion,				},
	{	REGINFO_NUMERICFLOAT,					&_sbNumericFloat,					},
} ;

BOOL
dlgConversion_bLoadRegistrySetting (void)
{
	HKEY	hSubKey ;
	LONG 	lResult ;
	DWORD	dwType, cbData, dwValue ;
	int		i ;
	BOOL	bRetval	= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_CONVERSION, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
		return	FALSE ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_CANDLISTKEYASSIGN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	_snCandListKeyAssign	= (CANDLIST_KEYASSIGN_DEFAULT <= dwValue && dwValue <= CANDLIST_KEYASSIGN_01234567890)? (int) dwValue : CANDLIST_KEYASSIGN_USERDEFINED ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATELISTCOUNT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	_snShowCandListCount	= (int) dwValue ;


	for (i = 0 ; i < ARRAYSIZE (_srRegBoolValues) ; i ++) {
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueEx (hSubKey, _srRegBoolValues [i].m_strInfoKey, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		*(BOOL*)(_srRegBoolValues [i].m_pbData)	= (dwValue != 0) ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumShowCandidateKeys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, (BYTE*)_srbyShowCandidateKeys, &cbData) ;
		_snNumShowCandidateKeys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumInputCodeMenu1Keys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, (BYTE*)_srbyInputCodeMenu1Keys, &cbData) ;
		_snNumInputCodeMenu1Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumInputCodeMenu2Keys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, (BYTE*)_srbyInputCodeMenu2Keys, &cbData) ;
		_snNumInputCodeMenu2Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ || cbData <= 0 || cbData >= sizeof (_srAutoStartHenkanKeywords)) {
		/* default �̐ݒ�B*/
		_siNumAutoStartHenkanKeywords	= 28 ;
		memcpy (_srAutoStartHenkanKeywords, _srDefaultAutoStartHenkanKeywords, sizeof (_srDefaultAutoStartHenkanKeywords)) ;
	} else {
		LPCTSTR	pSrc, pSrcLast ;
		int		iNumKeywords ;

		(void) RegQueryValueEx (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, (BYTE*) _srAutoStartHenkanKeywords, &cbData) ;
		/* ���𐔂���B*/
		iNumKeywords	= 0 ;
		pSrc			= _srAutoStartHenkanKeywords ;
		pSrcLast		= _srAutoStartHenkanKeywords + ARRAYSIZE (_srAutoStartHenkanKeywords) ;
		while (pSrc < pSrcLast && *pSrc != TEXT ('\0')) {
			int	nKeywordLen	= lstrlen (pSrc) ;
			if (nKeywordLen > 0)
				iNumKeywords ++ ;
			pSrc	+= nKeywordLen + 1 ;
		}
		_siNumAutoStartHenkanKeywords	= iNumKeywords ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD) {
		_snShowAnnotationType	= SHOW_NO_ANNOTATION ;
	} else {
		DWORD	dwValue ;
		(void) RegQueryValueEx (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;

		if (dwValue == (DWORD)DISABLE_ANNOTATION) {
			_snShowAnnotationType	= DISABLE_ANNOTATION ;
		} else if (0 <= dwValue && dwValue <= SHOW_ANNOTATION_ALWAYS) {
			_snShowAnnotationType	= (int) dwValue ;
		} else {
			_snShowAnnotationType	= SHOW_NO_ANNOTATION ;
		}
	}
	bRetval	= TRUE ;

skip_error:
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

BOOL
dlgConversion_bSaveSettingToRegistry (void)
{
	HKEY	hSubKey ;
	DWORD	dwValue ;
	int		i ;
	BOOL	bRetval	= FALSE ;

	if (! bCreateRegistryKey (REGPATH_CONVERSION, FALSE, &hSubKey)) 
		return	FALSE ;

	dwValue	= (DWORD) _snCandListKeyAssign ;
	if (RegSetValueEx (hSubKey, REGINFO_CANDLISTKEYASSIGN, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	error_exit ;

	dwValue	= (DWORD) _snShowCandListCount ;
	if (RegSetValueEx (hSubKey, REGINFO_SHOWCANDIDATELISTCOUNT, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	error_exit ;

	for (i = 0 ; i < ARRAYSIZE (_srRegBoolValues) ; i ++) {
		dwValue	= (DWORD) *(BOOL*)(_srRegBoolValues [i].m_pbData) ;
		if (RegSetValueEx (hSubKey, _srRegBoolValues [i].m_strInfoKey, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
			goto	error_exit ;
	}
	if (_snNumShowCandidateKeys > 0) {
		if (RegSetValueEx (hSubKey, REGINFO_SHOWCANDIDATEKEYS,  0, REG_BINARY, (BYTE*) _srbyShowCandidateKeys,  _snNumShowCandidateKeys) != ERROR_SUCCESS)
			goto	error_exit ;
	}
	if (_snNumInputCodeMenu1Keys > 0) {
		if (RegSetValueEx (hSubKey, REGINFO_INPUTCODEMENU1KEYS, 0, REG_BINARY, (BYTE*) _srbyInputCodeMenu1Keys, _snNumInputCodeMenu1Keys) != ERROR_SUCCESS)
			goto	error_exit ;
	}
	if (_snNumInputCodeMenu2Keys > 0) {
		if (RegSetValueEx (hSubKey, REGINFO_INPUTCODEMENU2KEYS, 0, REG_BINARY, (BYTE*) _srbyInputCodeMenu2Keys, _snNumInputCodeMenu2Keys) != ERROR_SUCCESS)
			goto	error_exit ;
	}
	if (_siNumAutoStartHenkanKeywords > 0) {
		LPCTSTR	pSrc, pSrcLast ;
		pSrc		= _srAutoStartHenkanKeywords ;
		pSrcLast	= _srAutoStartHenkanKeywords + ARRAYSIZE (_srAutoStartHenkanKeywords) ;
		while (pSrc < pSrcLast && *pSrc != TEXT ('\0')) {
			pSrc	+= lstrlen (pSrc) + 1 ;
		}
		if (pSrc < pSrcLast && *pSrc == TEXT ('\0')) {
			int		nDataSize	= (pSrc + 1 - _srAutoStartHenkanKeywords) * sizeof (TCHAR) ;
			if (RegSetValueEx (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, 0, REG_MULTI_SZ, (BYTE*) _srAutoStartHenkanKeywords, nDataSize) != ERROR_SUCCESS)
				goto	error_exit ;
		}
	} else {
		/*	default ���g���Ă��܂�Ȃ��悤�ɋ��ݒ�c�����Aauto-start-henkan �� enable �� keyword �������
		 *	����Ȃ񂾂낤���H
		 */
		TCHAR	bufNulMultiSz []	= { TEXT ('\0'), TEXT ('\0') } ;
		(void) RegSetValueEx (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, 0, REG_MULTI_SZ, (BYTE*) bufNulMultiSz, sizeof (bufNulMultiSz)) ;
	}

	dwValue	= (DWORD) _snShowAnnotationType ;
	if (RegSetValueEx (hSubKey, REGINFO_SHOWANNOTATIONTYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	error_exit ;

	bRetval	= TRUE ;
error_exit:
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

void
dlgConversion_vLoadDefaultSetting (void)
{
	_snCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;
	_snNumShowCandidateKeys			= 0 ;
	_snNumInputCodeMenu1Keys		= 0 ;
	_snNumInputCodeMenu2Keys		= 0 ;

	_snShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;
	_sbHenkanOkuriStrictly			= FALSE ;
	_sbProcessOkuriEarly			= FALSE ;
	_sbHenkanStrictOkuriPrecedence	= FALSE ;
	_sbAutoStartHenkan				= TRUE ;
	_sbDeleteOkuriWhenQuit			= FALSE ;
	_sbAutoOkuriProcess				= FALSE ;
	_sbNumericConversion			= TRUE ;
	_sbNumericFloat					= FALSE ;
	_snShowAnnotationType			= SHOW_NO_ANNOTATION ;

	/* auto-start-henkan-keyword �̏������B*/
	_siNumAutoStartHenkanKeywords	= 28 ;
	memcpy (_srAutoStartHenkanKeywords, _srDefaultAutoStartHenkanKeywords, sizeof (_srDefaultAutoStartHenkanKeywords)) ;
	return ;
}

/*================================================================
 *	private functions for IDD_MENUKEYS
 */
static	INT_PTR	dlgEditMenuKeys_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditMenuKeys_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditMenuKeys_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	BOOL	dlgEditMenuKeys_bInitializeListItem	(HWND, int, const BYTE*) ;
static	BOOL	dlgEditMenuKeys_bFullUpdateMenuKeys	(HWND, int, const BYTE*) ;
static	BOOL	dlgEditMenuKeys_bUpdateMenuKeys		(HWND, int, const BYTE*) ;
static	BOOL	dlgEditMenuKeys_bEditMenuKey	(HWND, int, int) ;
static	int		dlgEditMenuKeys_iGetFocusedControl	(HWND) ;
static	void	dlgEditMenuKeys_vKillFocus		(HWND, int) ;
static	void	dlgEditMenuKeys_vUpdateButtons	(HWND, int) ;
static	int		dlgEditMenuKeys_iPopupMenu		(HWND, int) ;

static	INT_PTR	CALLBACK	dlgKeyboardProc		(HWND, UINT, WPARAM, LPARAM) ;
static	int					dlgKeyboard_iCommandToChar	(int) ;

static	int		_srMenuListFocuedItem	[3]	= { 0 } ;

INT_PTR	CALLBACK
dlgEditMenuKeysProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgEditMenuKeys_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditMenuKeys_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditMenuKeys_iOnNotify (hDlg, wParam, lParam) ;
	case	WM_DESTROY:
		{
			if (_hiconArrowDown != NULL) {
				DestroyIcon (_hiconArrowDown) ;
				_hiconArrowDown	= NULL ;
			}
			if (_hiconArrowUp != NULL) {
				DestroyIcon (_hiconArrowUp) ;
				_hiconArrowUp	= NULL ;
			}
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditMenuKeys_iOnInitDialog (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	struct TEditMenuKeysArg*	pArg ;
	HINSTANCE	hInst ;
	HWND		hwndControl, hwndButton ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pArg	= (struct TEditMenuKeysArg*) lParam ;
	if (pArg == NULL)
		return	(INT_PTR) FALSE ;
	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_CANDIDATE_KEYS) ;
	if (hwndControl != NULL) {
		dlgEditMenuKeys_bInitializeListItem (hwndControl, pArg->m_nNumCandKeys, pArg->m_rbCandKeys) ;
		ListView_SetSelectionMark (hwndControl, 0) ;
		ListView_SetItemState (hwndControl, 0, LVIS_FOCUSED | LVIS_SELECTED, LVIS_FOCUSED | LVIS_SELECTED) ;
	}
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_MENU1_KEYS) ;
	if (hwndControl != NULL) {
		dlgEditMenuKeys_bInitializeListItem (hwndControl, pArg->m_nNumMenu1Keys, pArg->m_rbMenu1Keys) ;
		ListView_SetSelectionMark (hwndControl, 0) ;
		ListView_SetItemState (hwndControl, 0, LVIS_FOCUSED, LVIS_FOCUSED) ;
	}
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_MENU2_KEYS) ;
	if (hwndControl != NULL) {
		dlgEditMenuKeys_bInitializeListItem (hwndControl, pArg->m_nNumMenu2Keys, pArg->m_rbMenu2Keys) ;
		ListView_SetSelectionMark (hwndControl, 0) ;
		ListView_SetItemState (hwndControl, 0, LVIS_FOCUSED, LVIS_FOCUSED) ;
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWUP) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWUP2), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowUp		= hIcon ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWDOWN) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWDOWN2), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowDown	= hIcon ;
		}
	}
	dlgEditMenuKeys_vUpdateButtons (hDlg, IDC_LIST_CANDIDATE_KEYS) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditMenuKeys_iOnCommand (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	struct TEditMenuKeysArg*	pArg ;
	WORD		woControlId		= LOWORD (wParam) ;
	/*WORD		woNotification	= HIWORD (wParam) ;*/

	pArg	= (struct TEditMenuKeysArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;

	switch (woControlId) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_MODIFY:
	case	IDC_BUTTON_REMOVE:
	case	IDC_BUTTON_ARROWUP:
	case	IDC_BUTTON_ARROWDOWN:
		{
			int	nTarget	= dlgEditMenuKeys_iGetFocusedControl (hDlg);

			if (nTarget != -1) 
				dlgEditMenuKeys_bEditMenuKey (hDlg, nTarget, woControlId) ;
		}
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, woControlId) ;
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditMenuKeys_iOnNotify (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;
	struct TEditMenuKeysArg*	pArg ;

	pArg	= (struct TEditMenuKeysArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	(INT_PTR) 1 ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_CANDIDATE_KEYS:
	case	IDC_LIST_MENU1_KEYS:
	case	IDC_LIST_MENU2_KEYS:
		{
			switch (pNMHDR->code) {
			case	NM_SETFOCUS:
				{
					int		nItem ;

					if (pNMHDR->idFrom != IDC_LIST_CANDIDATE_KEYS)
						dlgEditMenuKeys_vKillFocus (hDlg, IDC_LIST_CANDIDATE_KEYS) ;
					if (pNMHDR->idFrom != IDC_LIST_MENU1_KEYS)
						dlgEditMenuKeys_vKillFocus (hDlg, IDC_LIST_MENU1_KEYS) ;
					if (pNMHDR->idFrom != IDC_LIST_MENU2_KEYS)
						dlgEditMenuKeys_vKillFocus (hDlg, IDC_LIST_MENU2_KEYS) ;

					nItem	= ListView_GetSelectionMark (pNMHDR->hwndFrom) ;
					if (nItem != -1) {
						TCHAR buf [256] ;
						int		n ;
						n	= wnsprintf (buf, ARRAYSIZE (buf) - 1, TEXT ("idFrom(%d), selected(%d)\n"), pNMHDR->idFrom, nItem) ;
						buf [n]	= TEXT ('\0') ;
						OutputDebugString (buf) ;
	
						ListView_SetItemState (pNMHDR->hwndFrom, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
						ListView_SetSelectionMark (pNMHDR->hwndFrom, nItem) ;
					}
					pArg->m_iFocus	= pNMHDR->idFrom ;
				}
				break ;

			case	NM_CLICK:
			case	NM_RCLICK:
			case	LVN_ITEMCHANGED:
				dlgEditMenuKeys_vUpdateButtons (hDlg, pNMHDR->idFrom) ;

				if (pNMHDR->code == NM_RCLICK) {
					/* �ǉ��A�ύX�A�폜�� Context ���j���[�̕\���B*/
					/*NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;*/
					int	n ;

					n	= dlgEditMenuKeys_iPopupMenu (hDlg, pNMHDR->idFrom) ;
					if (n > 0) {
						if (dlgEditMenuKeys_bEditMenuKey (hDlg, pNMHDR->idFrom, n))
							dlgEditMenuKeys_vUpdateButtons (hDlg, pNMHDR->idFrom) ;
					}
				}
				break ;
			case	NM_KILLFOCUS:
				break ;
			case	NM_DBLCLK:
				/* �ύX�Ƃ��Ă����Ȃ� Keyboard Dialog ���J���B*/
				dlgEditMenuKeys_bEditMenuKey (hDlg, pNMHDR->idFrom, IDC_BUTTON_MODIFY) ;
				break ;
			default:
				break ;
			}
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 0 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

int
dlgEditMenuKeys_iPopupMenu (
	HWND		hDlg,
	int			nItem)
{
	struct TMENUITEM 	rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ǉ�"), IDC_BUTTON_ADD, },
		{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ύX"), IDC_BUTTON_MODIFY, },
		{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�폜"), IDC_BUTTON_REMOVE, },
	} ;
	struct TEditMenuKeysArg*	pArg ;
	int		nNumUsedKeys ;

	pArg	= (struct TEditMenuKeysArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	-1 ;

	switch (nItem) {
	case	IDC_LIST_CANDIDATE_KEYS:
		nNumUsedKeys	= pArg->m_nNumCandKeys ;
		break ;
	case	IDC_LIST_MENU1_KEYS:
		nNumUsedKeys	= pArg->m_nNumMenu1Keys ;
		break ;
	case	IDC_LIST_MENU2_KEYS:
		nNumUsedKeys	= pArg->m_nNumMenu2Keys ;
		break ;
	default:
		return	-1 ;
	}
	if (nNumUsedKeys <= 1) {
		rmi [2].m_fMask		|= MIIM_STATE ;
		rmi [2].m_fState	|= MF_GRAYED ;
	}
	if (nNumUsedKeys >= MAX_NUMMENUKEYS) {
		rmi [0].m_fMask		|= MIIM_STATE ;
		rmi [0].m_fState	|= MF_GRAYED ;
	}
	return	iPopupMenu (hDlg, rmi, ARRAYSIZE (rmi)) ;
}

BOOL
dlgEditMenuKeys_bInitializeListItem (
	HWND		hwndControl,
	int			nNumMenuKeys,
	const BYTE*	pbMenuKeys)
{
	LVCOLUMN	lvColumn ;

	if (hwndControl == NULL)
		return	FALSE ;

	ListView_DeleteAllItems (hwndControl) ;
	ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;
		
	lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_SUBITEM ;
	lvColumn.fmt		= LVCFMT_LEFT ;
	lvColumn.cx			= 32 ;
	ListView_InsertColumn (hwndControl, 0, &lvColumn) ;
	lvColumn.cx			= 32 ;
	ListView_InsertColumn (hwndControl, 1, &lvColumn) ;
	dlgEditMenuKeys_bFullUpdateMenuKeys (hwndControl, nNumMenuKeys, pbMenuKeys) ;

	/*	�u�ǉ��v�̗v�f�BListView �̈�ԉ��� ``...'' ��p�ӂ��āA������ dblclk ��
	 *	�v�f�ǉ����l�����̂����ǁA������h�����ȁH ���ʂɁu�ǉ��v�̃{�^����p�ӂ��������������B
	n	= wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%3d:"), i) ;
	szBuffer [n]	= TEXT ('\0') ;
	lvi.iItem		= i ;
	lvi.lParam		= (LPARAM) -1 ;
	lvi.pszText		= szBuffer ;
	nItem			= ListView_InsertItem (hwndControl, &lvi) ;
	if (nItem != -1) {
		ListView_SetItemText (hwndControl, nItem, 1, TEXT ("...")) ;
	}
	 */
	return	TRUE ;
}

int
dlgEditMenuKeys_iGetFocusedControl (
	HWND			hDlg)
{
	static	int	srnControls []	= {
		IDC_LIST_CANDIDATE_KEYS,	IDC_LIST_MENU1_KEYS,		IDC_LIST_MENU2_KEYS,
	} ;
	int		i ;
	struct TEditMenuKeysArg*	pArg ;

	pArg	= (struct TEditMenuKeysArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	for (i = 0 ; i < ARRAYSIZE (srnControls) ; i ++) {
		if (pArg->m_iFocus == srnControls [i])
			return	pArg->m_iFocus ;
	}
	return	-1 ;
}

void
dlgEditMenuKeys_vKillFocus (
	HWND			hDlg,
	int				nItem)
{
	HWND	hwndControl ;
	int		nIndex ;

	hwndControl	= GetDlgItem (hDlg, nItem) ;
	nIndex		= ListView_GetSelectionMark (hwndControl) ;
	if (nIndex != -1) {

		TCHAR buf [256] ;
		int		n ;
		n	= wnsprintf (buf, ARRAYSIZE (buf) - 1, TEXT ("kill: idFrom(%d), selected(%d)\n"), nItem, nIndex) ;
		buf [n]	= TEXT ('\0') ;
		OutputDebugString (buf) ;

		ListView_SetItemState (hwndControl, nIndex, 0, LVIS_SELECTED) ;
//		ListView_SetSelectionMark (hwndControl, -1) ;
	}
	return ;
}

void
dlgEditMenuKeys_vUpdateButtons (
	HWND			hDlg,
	int				nItem)
{
	struct TEditMenuKeysArg*	pArg ;
	HWND	hwndControl ;
	int		nNumUsedKeys, nCurSel ;

	pArg	= (struct TEditMenuKeysArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return ;

	hwndControl	= GetDlgItem (hDlg, nItem) ;
	if (hwndControl == NULL) 
		return ;

	nCurSel	= ListView_GetSelectionMark (hwndControl) ;
	EnableDlgItem (hDlg, IDC_BUTTON_MODIFY, (nCurSel != -1)? TRUE : FALSE) ;

	switch (nItem) {
	case	IDC_LIST_CANDIDATE_KEYS:
		nNumUsedKeys	= pArg->m_nNumCandKeys ;
		break ;
	case	IDC_LIST_MENU1_KEYS:
		nNumUsedKeys	= pArg->m_nNumMenu1Keys ;
		break ;
	case	IDC_LIST_MENU2_KEYS:
		nNumUsedKeys	= pArg->m_nNumMenu2Keys ;
		break ;
	default:
		return ;
	}
	EnableDlgItem (hDlg, IDC_BUTTON_REMOVE,	(nNumUsedKeys <= 1 || nCurSel == -1)? FALSE : TRUE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ADD,	(nNumUsedKeys >= MAX_NUMMENUKEYS)? FALSE : TRUE) ;

	EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,	(nCurSel <= 0)? FALSE : TRUE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,	(nCurSel == -1 || nCurSel >= (nNumUsedKeys - 1))? FALSE : TRUE) ;
	return ;
}

BOOL
dlgEditMenuKeys_bEditMenuKey (
	HWND			hDlg,
	int				nItem,
	int				nCommand)
{
	struct TEditMenuKeysArg*	pArg ;
	struct TKeySelectArg		arg ;
	HWND			hwndControl ;
	int				nCurSel ;
	int*			pnNumKeys ;

	pArg	= (struct TEditMenuKeysArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;
	hwndControl	= GetDlgItem (hDlg, nItem) ;
	if (hwndControl == NULL)
		return	FALSE ;

	/*	�ǉ��A�폜�̏ꍇ�ɂ́A�ݒ肪�K�v�B
	 */
	nCurSel		= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1 && nCommand != IDC_BUTTON_ADD)
		return	FALSE ;

	memset (&arg, 0, sizeof (arg)) ;
	switch (nItem) {
	case	IDC_LIST_CANDIDATE_KEYS:
		pnNumKeys			= &pArg->m_nNumCandKeys ;
		arg.m_nNumUsedKeys	= pArg->m_nNumCandKeys ;
		arg.m_pbUsedKeys	= pArg->m_rbCandKeys ;
		break ;
	case	IDC_LIST_MENU1_KEYS:
		pnNumKeys			= &pArg->m_nNumMenu1Keys ;
		arg.m_nNumUsedKeys	= pArg->m_nNumMenu1Keys ;
		arg.m_pbUsedKeys	= pArg->m_rbMenu1Keys ;
		break ;
	case	IDC_LIST_MENU2_KEYS:
		pnNumKeys			= &pArg->m_nNumMenu2Keys ;
		arg.m_nNumUsedKeys	= pArg->m_nNumMenu2Keys ;
		arg.m_pbUsedKeys	= pArg->m_rbMenu2Keys ; ;
		break ;
	default:
		return	FALSE ;
	}
	arg.m_nCurSel	= (0 <= nCurSel && nCurSel < arg.m_nNumUsedKeys)? arg.m_pbUsedKeys [nCurSel] : -1 ;

	switch (nCommand) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_MODIFY:
		{
			HINSTANCE		hInst ;
			int				nResult, nCH ;

			hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
			nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_KEYBOARD), hDlg, dlgKeyboardProc, (LPARAM) &arg) ;
			if (nResult == IDCANCEL || nResult == IDC_BUTTON_ESC)
				return	TRUE ;	/* cancel */

			nCH		= dlgKeyboard_iCommandToChar (nResult) ;
			if (nCommand == IDC_BUTTON_ADD) {
				/* current selection �̎��ɒǉ��������B*/
				if (arg.m_nNumUsedKeys >= MAX_NUMMENUKEYS)
					return	FALSE ;
				if (nCurSel < (arg.m_nNumUsedKeys - 1))
					memmove (arg.m_pbUsedKeys + nCurSel + 2, arg.m_pbUsedKeys + nCurSel + 1, (arg.m_nNumUsedKeys - nCurSel - 1)) ;
				arg.m_nNumUsedKeys ++ ;
				arg.m_pbUsedKeys [nCurSel + 1]	= nCH ;
			} else {
				/* current selection �̒��g��ύX�B*/
				arg.m_pbUsedKeys [nCurSel]	= nCH ;
			}
		}
		break ;
	case	IDC_BUTTON_ARROWUP:
		{
			int	nTemp ;

			if (nCurSel >= 1) {
				nTemp							= arg.m_pbUsedKeys [nCurSel] ;
				arg.m_pbUsedKeys [nCurSel]		= arg.m_pbUsedKeys [nCurSel - 1] ;
				arg.m_pbUsedKeys [nCurSel - 1]	= nTemp ;
				/*	Focus �����炷�B*/
				ListView_SetItemState (hwndControl, nCurSel, 0, LVIS_SELECTED | LVIS_FOCUSED) ;
				nCurSel	-- ;
				ListView_SetItemState (hwndControl, nCurSel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED) ;
				ListView_SetSelectionMark (hwndControl, nCurSel) ;
			} else {
				return	FALSE ;
			}
		}
		break ;
	case	IDC_BUTTON_ARROWDOWN:
		{
			int		nTemp ;
			if ((nCurSel + 1) < arg.m_nNumUsedKeys) {
				nTemp							= arg.m_pbUsedKeys [nCurSel] ;
				arg.m_pbUsedKeys [nCurSel]		= arg.m_pbUsedKeys [nCurSel + 1] ;
				arg.m_pbUsedKeys [nCurSel + 1]	= nTemp ;
				/*	Focus �����炷�B*/
				ListView_SetItemState (hwndControl, nCurSel, 0, LVIS_SELECTED | LVIS_FOCUSED) ;
				nCurSel	++ ;
				ListView_SetItemState (hwndControl, nCurSel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED) ;
				ListView_SetSelectionMark (hwndControl, nCurSel) ;
			} else {
				return	FALSE ;
			}
		}
		break ;
	case	IDC_BUTTON_REMOVE:
	default:
		if (arg.m_nNumUsedKeys > 1 && nCurSel != -1) {
			if ((nCurSel + 1) < arg.m_nNumUsedKeys)
				memmove (arg.m_pbUsedKeys + nCurSel, arg.m_pbUsedKeys + nCurSel + 1, (arg.m_nNumUsedKeys - nCurSel - 1)) ;
			arg.m_nNumUsedKeys -- ;
		} else {
			return	FALSE ;
		}
		break ;
	}
	*pnNumKeys	= arg.m_nNumUsedKeys ;
	if (arg.m_nNumUsedKeys <= 1)
		EnableDlgItem (hDlg, IDC_BUTTON_REMOVE, FALSE) ;
	if (arg.m_nNumUsedKeys >= MAX_NUMMENUKEYS)
		EnableDlgItem (hDlg, IDC_BUTTON_ADD, FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,   (nCurSel >= 1)? TRUE : FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN, ((nCurSel + 1) < arg.m_nNumUsedKeys)? TRUE : FALSE) ;

	dlgEditMenuKeys_bUpdateMenuKeys (hwndControl, arg.m_nNumUsedKeys, arg.m_pbUsedKeys) ;
	return	TRUE ;
}

BOOL
dlgEditMenuKeys_bFullUpdateMenuKeys (
	HWND		hwndControl,
	int			nNumMenuKeys,
	const BYTE*	pbMenuKeys)
{
	TCHAR	szBuffer [32] ;
	LVITEM	lvi ;
	int		i, n, nItem ;

	ListView_DeleteAllItems (hwndControl) ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
	for (i = 0 ; i < nNumMenuKeys ; i ++) {
		n	= wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%3d:"), i) ;
		szBuffer [n]	= TEXT ('\0') ;
		lvi.iItem		= i ;
		lvi.lParam		= (LPARAM) pbMenuKeys [i] ;
		lvi.pszText		= szBuffer ;
		nItem			= ListView_InsertItem (hwndControl, &lvi) ;
		if (nItem != -1) {
			n	= wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%c"), pbMenuKeys [i]) ;
			szBuffer [n]	= TEXT ('\0') ;
			ListView_SetItemText (hwndControl, nItem, 1, szBuffer) ;
		}
	}
	return	TRUE ;
}

BOOL
dlgEditMenuKeys_bUpdateMenuKeys (
	HWND		hwndControl,
	int			nNumMenuKeys,
	const BYTE*	pbMenuKeys)
{
	TCHAR	szBuffer [32] ;
	LVITEM	lvi ;
	int		i, n, nItem, nItems, nCount ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask	= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;

	nItems	= ListView_GetItemCount (hwndControl) ;

	nCount	= (nNumMenuKeys < nItems)? nNumMenuKeys : nItems ;
	for (i = 0 ; i < nCount ; i ++) {
		n	= wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%c"), pbMenuKeys [i]) ;
		szBuffer [n]	= TEXT ('\0') ;
		ListView_SetItemText (hwndControl, i, 1, szBuffer) ;
	}
	if (nNumMenuKeys >= nItems) {
		for ( ; i < nNumMenuKeys ; i ++) {
			n	= wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%3d:"), i) ;
			szBuffer [n]	= TEXT ('\0') ;
			lvi.iItem		= i ;
			lvi.lParam		= (LPARAM) pbMenuKeys [i] ;
			lvi.pszText		= szBuffer ;
			nItem			= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				n	= wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%c"), pbMenuKeys [i]) ;
				szBuffer [n]	= TEXT ('\0') ;
				ListView_SetItemText (hwndControl, nItem, 1, szBuffer) ;
			}
		}
	} else {
		/* ���� delete item �� index ���ϓ�����񂶂�Ȃ����Ƃ������Ƃ����ǁc�B*/
		for ( ; i < nItems ; i ++) {
			ListView_DeleteItem (hwndControl, i) ;
		}
	}
	return	TRUE ;
}

/*================================================================
 *	private functions for IDD_KEYBOARD
 */
INT_PTR	CALLBACK
dlgKeyboardProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		{
			/*	...���Ƃ��Ɛݒ肵�Ă������L�[�Ƀt�H�[�J�X�����킹��ׂ����H
			 *	
			 */
			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
		}
		return	(INT_PTR) FALSE ;
	case	WM_COMMAND:
		{
			struct TKeySelectArg*	pArg ;
			WORD	woControlId	= LOWORD (wParam) ;

			pArg	= (struct TKeySelectArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;

			/*	...
			 *	�L�[���d�����Ă�����G���[���o���ׂ����B
			 */
			if (woControlId != IDCANCEL			&& 
				woControlId != IDC_BUTTON_ESC) {
				TCHAR	buf [256] ;
				int		nCH, n ;

				nCH	= dlgKeyboard_iCommandToChar (woControlId) ;
				if (nCH == -1)
					break ;
				if (pArg != NULL && memchr (pArg->m_pbUsedKeys, nCH, pArg->m_nNumUsedKeys) != NULL && pArg->m_nCurSel != nCH) {
					n	= wnsprintf (buf, ARRAYSIZE (buf) - 1, TEXT ("�L�[``%c'' �͊��Ɏg���Ă��܂��B"), nCH) ;
					buf [n]	= TEXT ('\0') ;
					MessageBox (hDlg, buf, TEXT ("�G���["), MB_OK) ;
					break ;
				}
			}
			EndDialog (hDlg, woControlId) ;
		}
		return	(INT_PTR) 1 ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*	���߂Ȋ֐��B
 */
int
dlgKeyboard_iCommandToChar (
	int				nCommand)
{
	switch (nCommand) {
	case	IDC_BUTTON_0:			return	'0' ;
	case	IDC_BUTTON_1:			return	'1' ;
	case	IDC_BUTTON_2:			return	'2' ;
	case	IDC_BUTTON_3:			return	'3' ;
	case	IDC_BUTTON_4:			return	'4' ;
	case	IDC_BUTTON_5:			return	'5' ;
	case	IDC_BUTTON_6:			return	'6' ;
	case	IDC_BUTTON_7:			return	'7' ;
	case	IDC_BUTTON_8:			return	'8' ;
	case	IDC_BUTTON_9:			return	'9' ;
	case	IDC_BUTTON_A:			return	'A' ;
	case	IDC_BUTTON_B:			return	'B' ;
	case	IDC_BUTTON_C:			return	'C' ;
	case	IDC_BUTTON_D:			return	'D' ;
	case	IDC_BUTTON_E:			return	'E' ;
	case	IDC_BUTTON_F:			return	'F' ;
	case	IDC_BUTTON_G:			return	'G' ;
	case	IDC_BUTTON_H:			return	'H' ;
	case	IDC_BUTTON_I:			return	'I' ;
	case	IDC_BUTTON_J:			return	'J' ;
	case	IDC_BUTTON_K:			return	'K' ;
	case	IDC_BUTTON_L:			return	'L' ;
	case	IDC_BUTTON_M:			return	'M' ;
	case	IDC_BUTTON_N:			return	'N' ;
	case	IDC_BUTTON_O:			return	'O' ;
	case	IDC_BUTTON_P:			return	'P' ;
	case	IDC_BUTTON_Q:			return	'Q' ;
	case	IDC_BUTTON_R:			return	'R' ;
	case	IDC_BUTTON_S:			return	'S' ;
	case	IDC_BUTTON_T:			return	'T' ;
	case	IDC_BUTTON_U:			return	'U' ;
	case	IDC_BUTTON_V:			return	'V' ;
	case	IDC_BUTTON_W:			return	'W' ;
	case	IDC_BUTTON_X:			return	'X' ;
	case	IDC_BUTTON_Y:			return	'Y' ;
	case	IDC_BUTTON_Z:			return	'Z' ;
	case	IDC_BUTTON_COMMA:		return	',' ;
	case	IDC_BUTTON_PERIOD:		return	'.' ;
	case	IDC_BUTTON_SLASH:		return	'/' ;
	case	IDC_BUTTON_SEMICOLON:	return	';' ;
	case	IDC_BUTTON_LBRACKET:	return	'[' ;
	case	IDC_BUTTON_RBRACKET:	return	']' ;
	case	IDC_BUTTON_QUOTE:		return	'\'' ;
	case	IDC_BUTTON_BACKSLASH:	return	'\\' ;
	case	IDC_BUTTON_BACKQUOTE:	return	'`' ;
	case	IDC_BUTTON_MINUS:		return	'-' ;
	case	IDC_BUTTON_EQUAL:		return	'=' ;
	default:						return	-1 ;
	}
}

/*================================================================
 *	private functions for IDD_EDIT_AUTOSTARTHENKAN
 */
static	INT_PTR		dlgEditAutoStartHenkan_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgEditAutoStartHenkan_iOnCommand		(HWND, WPARAM, LPARAM) ;

static	INT_PTR	CALLBACK	dlgEditAutoStartHenkanKeywordProc	(HWND, UINT, WPARAM, LPARAM) ;


INT_PTR	CALLBACK
dlgEditAutoStartHenkanProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		return	dlgEditAutoStartHenkan_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditAutoStartHenkan_iOnCommand (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditAutoStartHenkan_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditAutoStartHenkanArg*	pArg	= (struct TEditAutoStartHenkanArg*) lParam ;
	HWND	hwndControl ;

	/*	AutoStartHenkan �̃L�[���[�h����ׂ�B*/
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_AUTOSTARTHENKAN_KEYWORD) ;
	if (hwndControl != NULL && pArg != NULL) {
		LVITEM	lvi ;
		LPTSTR	pSrc ;
		int		i ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_TEXT ;
		pSrc		= pArg->m_bufKeywords ;
		for (i = 0 ; i < pArg->m_nKeywords && *pSrc != TEXT ('\0') ; i ++) {
			lvi.iItem	= i ;
			lvi.pszText	= pSrc ;
			ListView_InsertItem (hwndControl, &lvi) ;
			pSrc		+= lstrlen (pSrc) + 1 ;
		}
	}
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditAutoStartHenkan_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	/*WORD	woNotification	= HIWORD (wParam) ;*/
	TCHAR	bufText [MAXLEN_AUTOSTARTHENKAN_KEYWORD] ;

	switch (woControl) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		{
			int			nResult, nCurSel, nIndex ;
			HWND		hwndControl ;
			HINSTANCE	hInst ;
			LVFINDINFO	lvfi ;

			hwndControl	= GetDlgItem (hDlg, IDC_LIST_AUTOSTARTHENKAN_KEYWORD) ;
			if (hwndControl == NULL)
				break ;
			nCurSel	= -1 ;
			if (woControl == IDC_BUTTON_ADD) {
				bufText [0]	= TEXT ('\0') ;
			} else {
				nCurSel	= ListView_GetSelectionMark (hwndControl) ;
				if (nCurSel == -1)
					break ;
				ListView_GetItemText (hwndControl, nCurSel, 0, bufText, ARRAYSIZE (bufText) - 1) ;
				bufText [ARRAYSIZE (bufText) - 1]	= TEXT ('\0') ;
			}
			hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
			nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_AUTOSTARTHENKAN_KEYWORD), hDlg, dlgEditAutoStartHenkanKeywordProc, (LPARAM) bufText) ;
			if (nResult != IDOK)
				break ;
			if (bufText [0] == TEXT ('\0')) {
				(void) MessageBox (hDlg, TEXT ("�L�[���[�h�ɋ󕶎����ݒ肷�邱�Ƃ͂ł��܂���B"), TEXT ("�G���["), MB_OK) ;
				break ;
			}
			/* �ǉ� or �ҏW�B*/
			memset (&lvfi, 0, sizeof (lvfi)) ;
			lvfi.flags	= LVFI_STRING ;
			lvfi.psz	= bufText ;
			nIndex		= ListView_FindItem (hwndControl, -1, &lvfi) ;
			if (nIndex != -1) {
				TCHAR	bufMessage [256] ;
				int		nText ;
				nText	= wnsprintf (bufMessage, ARRAYSIZE (bufMessage) - 1, TEXT ("�L�[���[�h ``%s'' �͊��ɑ��݂��Ă��܂��B"), bufText) ;
				bufMessage [nText]	= TEXT ('\0') ;
				(void) MessageBox (hDlg, bufMessage, TEXT ("�G���["), MB_OK) ;
				break ;
			} else {
				if (woControl == IDC_BUTTON_ADD) {
					LVITEM	lvi ;
					memset (&lvi, 0, sizeof (lvi)) ;
					lvi.iItem		= ListView_GetItemCount (hwndControl) ;
					lvi.iSubItem	= 0 ;
					lvi.pszText		= bufText ;
					ListView_InsertItem (hwndControl, &lvi) ;
				} else {
					ListView_SetItemText (hwndControl, nCurSel, 0, bufText) ;
				}
			}
		}
		break ;
	case	IDC_BUTTON_DELETE:
		{
			HWND	hwndControl ;
			int		nCurSel ;

			hwndControl	= GetDlgItem (hDlg, IDC_LIST_AUTOSTARTHENKAN_KEYWORD) ;
			if (hwndControl == NULL)
				break ;
			nCurSel	= ListView_GetSelectionMark (hwndControl) ;
			if (nCurSel == -1)
				break ;
			ListView_DeleteItem (hwndControl, nCurSel) ;
		}
		break ;
	case	IDOK:
		{
			struct TEditAutoStartHenkanArg*	pArg ;
			HWND	hwndControl ;

			hwndControl	= GetDlgItem (hDlg, IDC_LIST_AUTOSTARTHENKAN_KEYWORD) ;
			pArg		= (struct TEditAutoStartHenkanArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (hwndControl != NULL && pArg != NULL) {
				LPTSTR	pDest, pDestLast ;
				int		i, nTextLen ;

				pDest		= pArg->m_bufKeywords ; 
				pDestLast	= pArg->m_bufKeywords + ARRAYSIZE (pArg->m_bufKeywords) - 1 ;
				/* ListView_GetItemText �� Label ��S�ďE���W�߂�B*/
				for (i = 0 ; i < ListView_GetItemCount (hwndControl) ; i ++) {
					ListView_GetItemText (hwndControl, i, 0, bufText, ARRAYSIZE (bufText) - 1) ;
					bufText [ARRAYSIZE (bufText) - 1]	= TEXT ('\0') ;
					
					nTextLen	= lstrlen (bufText) ;
					if (nTextLen > 0) {
						if ((pDest + nTextLen + 1/*nul*/) < pDestLast) {
							lstrcpy (pDest, bufText) ;
							pDest	+= nTextLen + 1 ;
						} else {
							break ;
						}
					}
				}
				*pDest	= TEXT ('\0') ;	/* nul */
				pArg->m_nKeywords	= i ;
			}
		}
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	(INT_PTR) TRUE ;
	default:
		break ;
	}
	
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR	CALLBACK
dlgEditAutoStartHenkanKeywordProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		{
			LPTSTR	pString	= (LPTSTR) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
			if (pString != NULL)
				SetDlgItemText (hDlg, IDC_EDIT_KEYWORD, pString) ;

			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_KEYWORD) ;
			if (hwndControl != NULL) {
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) MAXLEN_AUTOSTARTHENKAN_KEYWORD, (LPARAM) 0) ;
			}
			return	(INT_PTR) TRUE ;
		}
	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			/*WORD	woNotification	= HIWORD (wParam) ;*/
			switch (woControl) {
			case	IDOK:
				{
					LPTSTR	pString	= (LPTSTR) GetWindowLongPtr (hDlg, DWLP_USER) ;

					if (pString != NULL) {
						int		nText ;

						nText	= GetDlgItemText (hDlg, IDC_EDIT_KEYWORD, pString, MAXLEN_AUTOSTARTHENKAN_KEYWORD-1) ;
						*(pString + nText)	= TEXT ('\0') ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
			default:
				break ;
			}
			return	(INT_PTR) TRUE ;
		}
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

