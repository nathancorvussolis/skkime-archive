#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDoc.h"
#include "ImeBufferP.h"
#include "TMarker.h"
#include "RuleTreeNode.h"
#include "keymap.h"
#include "TMSG.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "lmstate.h"
#include "jstring.h"
#include "ImeConfig.h"

/*=================================================================================
 *	prototypes
 */

/*================================================================ skk-mode-jisx0201
 */
int
LM_bSkkJisx0201ModeOn ( 
	struct CImeDoc*		pThis)
{
	/*
		(defsubst skk-jisx0201-mode-on (&optional arg)
		  "SKK JIS X 0201 (�J�i) ���[�h���N������B"
		  (make-local-variable 'skk-rule-tree)
		  (setq skk-mode t
				skk-jisx0201-mode t
				skk-jisx0201-roman arg
				skk-rule-tree (if arg
								  skk-jisx0201-roman-rule-tree
								skk-jisx0201-base-rule-tree)
				skk-abbrev-mode nil
				skk-latin-mode nil
				skk-j-mode nil
				skk-jisx0208-latin-mode nil
				skk-katakana nil)
		  (skk-update-modeline 'jisx0201)
		  (skk-cursor-set))
	 */
	struct CImeBuffer*	pBuffer ;
	int					bRoman ;

	if (ImeDoc_bSignalp (pThis)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegInteger (pThis, LMREGARG_0, &bRoman))
		bRoman	= FALSE ;

	imeBuffer_bSkkJisx0201ModeOn (pBuffer, bRoman) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-mode-jisx0201
 */
int
LM_bSkkModeAdJisx0201 ( 
	struct CImeDoc*		pThis)
{
	/*
		(defadvice skk-mode (before skk-jisx0201-ad activate)
		  (setq skk-jisx0201-mode nil)
		  (kill-local-variable 'skk-rule-tree))
	 */
	struct CImeBuffer*				pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	if (ImeDoc_bSignalp (pThis)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkJisx0201Mode	= LFALSE ;

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
	SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, RULETREENO_SKK_BASE) ;
	ImeDoc_vJump (pThis, LM_bSkkMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kakutei-jisx0201
 */
static	int	LM_bSkkKakuteiAdJisx0201_Exit (struct CImeDoc*) ;

int
LM_bSkkKakuteiAdJisx0201 ( 
	struct CImeDoc*		pThis)
{
	/*
	(defadvice skk-kakutei (around skk-jisx0201-ad activate)
	  (let ((jisx0201 skk-jisx0201-mode))
		ad-do-it
		(when jisx0201
		  (skk-jisx0201-mode-on skk-jisx0201-roman))))
	*/
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pThis)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bPushReg (pThis, LMREG_1))
		return	LMR_ERROR ;
	ImeDoc_vSetRegInteger (pThis, LMREG_1, pBuffer->m_bSkkJisx0201Mode) ;
	if (! ImeDoc_bCall (pThis,  LM_bSkkKakutei, LM_bSkkKakuteiAdJisx0201_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKakuteiAdJisx0201_Exit (
	struct CImeDoc*		pThis)
{
	/*
	(defadvice skk-kakutei (around skk-jisx0201-ad activate)
	  (let ((jisx0201 skk-jisx0201-mode))
		ad-do-it
		(when jisx0201
		  (skk-jisx0201-mode-on skk-jisx0201-roman))))
	*/
	struct CImeBuffer*	pBuffer ;
	int			bJisx0201 ;

	if (! ImeDoc_bGetRegInteger (pThis, LMREG_1, &bJisx0201))
		bJisx0201	= LFALSE ;
	ImeDoc_vPopReg (pThis, LMREG_1) ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (bJisx0201) {
		ImeDoc_vSetRegInteger (pThis, LMREGARG_0, pBuffer->m_bSkkJisx0201Roman) ;
		ImeDoc_vJump (pThis, LM_bSkkJisx0201ModeOn) ;
		return	LMR_CONTINUE ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-latin-mode-jisx0201
 */
int
LM_bSkkLatinModeAdJisx0201 (
	struct CImeDoc*		pThis)
{
	/*
	(defadvice skk-latin-mode (before skk-jisx0201-ad activate)
	  (setq skk-jisx0201-mode nil)
	  (kill-local-variable 'skk-rule-tree))
	*/
	struct CImeBuffer*				pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkJisx0201Mode	= LFALSE ;

	/*	(kill-local-variable 'skk-rule-tree) �����Brule-tree �� jisx0201-roman �� jisx0201-base
	 *	��ݒ肷�鑀��� Tree Rule �̐؂�ւ��Ŏ�������B
	 */
	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
	SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, RULETREENO_SKK_BASE) ;
	ImeDoc_vJump (pThis, LM_bSkkLatinMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-jisx0208-latin-mode-jisx0201
 */
int
LM_bSkkJisx0208LatinModeAdJisx0201 (
	struct CImeDoc*		pThis)
{
	/*
	(defadvice skk-latin-mode (before skk-jisx0201-ad activate)
	  (setq skk-jisx0201-mode nil)
	  (kill-local-variable 'skk-rule-tree))
	*/
	struct CImeBuffer*				pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkJisx0201Mode	= LFALSE ;

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
	SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, RULETREENO_SKK_BASE) ;
	ImeDoc_vJump (pThis, LM_bSkkJisx0208LatinMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-abbrev-mode-jisx0201
 */
int
LM_bSkkAbbrevModeAdJisx0201 (
	struct CImeDoc*		pThis)
{
	/*
		(defadvice skk-abbrev-mode (before skk-jisx0201-ad activate)
		  (setq skk-jisx0201-mode nil)
		  (kill-local-variable 'skk-rule-tree))
	*/
	struct CImeBuffer*				pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkJisx0201Mode	= LFALSE ;

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
	SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, RULETREENO_SKK_BASE) ;
	ImeDoc_vJump (pThis, LM_bSkkAbbrevMode) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-set-okurigana-jisx0201
 */
static	int	LM_bSkkSetOkuriganaAdJisx0201_1 (struct CImeDoc* pThis) ;
static	int	LM_bSkkSetOkuriganaAdJisx0201_2 (struct CImeDoc* pThis) ;

int
LM_bSkkSetOkuriganaAdJisx0201 (
	struct CImeDoc*		pThis)
{
	struct CImeBuffer*				pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_bSkkJisx0201Mode) {
		int			iOkuriganaStartPoint ;

		if (pBuffer->m_pmkSkkOkuriganaStartPoint == NULL || ! TMarker_bIsValidp (pBuffer->m_pmkSkkOkuriganaStartPoint)) {
			ImeDoc_vSetSignalError (pThis) ;
			return	LMR_RETURN ;
		}

		iOkuriganaStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint) ;
		if (iOkuriganaStartPoint < 0 || iOkuriganaStartPoint >= (pBuffer->m_nbufComp - 1)) {
			ImeDoc_vSetSignalError (pThis) ;
			return	LMR_RETURN ;
		}
		if (pBuffer->m_bufComp [iOkuriganaStartPoint + 1] == L'*') {
			ImeBuffer_bDeleteRegion (pBuffer, iOkuriganaStartPoint, iOkuriganaStartPoint + 1) ;
		}
		if (pBuffer->m_pmkSkkHenkanStartPoint == NULL || ! TMarker_bIsValidp (pBuffer->m_pmkSkkHenkanStartPoint)) {
			ImeDoc_vSetSignalError (pThis) ;
			return	LMR_RETURN ;
		}
		ImeDoc_vSetRegInteger (pThis, LMREGARG_0, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) ;
		ImeDoc_vSetRegInteger (pThis, LMREGARG_1, TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint)) ;
		if (! ImeDoc_bCall (pThis,  LM_bSkkJisx0201ZenkakuRegion, LM_bSkkSetOkuriganaAdJisx0201_1))
			return	LMR_ERROR ;
	} else {
		/* ad-do-it */
		ImeDoc_vJump (pThis, LM_bSkkSetOkurigana) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkSetOkuriganaAdJisx0201_1 (
	struct CImeDoc*			pThis)
{
	struct CImeBuffer*		pBuffer ;
	LPCDSTR			pwBufferString ;
	int				iPoint, iBufferTop, iBufferEnd, nBufferLength ;
	DCHAR			rszOkuri [32] ;
	int				nOkuriLen ;
	BOOL			bSokuon ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	iPoint	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;

	{
		struct TMarker*	pmkBufferTop	= NULL ;
		struct TMarker*	pmkBufferEnd	= NULL ;

		if (! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkBufferEnd) || pmkBufferEnd == NULL) {
			iBufferEnd	= pBuffer->m_nbufComp ;
		} else {
			iBufferEnd	= TMarker_iGetPosition (pmkBufferEnd) ;
		}
		if (! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkBufferTop) || pmkBufferTop == NULL) {
			iBufferTop	= 0 ;
		} else {
			iBufferTop	= TMarker_iGetPosition (pmkBufferTop) ;
		}
	}

	/*	buffer-top, buffer-end �Ƃ̔�r���K�v�ł���悤�Ɏv����B
	 */
	if (iPoint <= iBufferTop || iPoint >= iBufferEnd) {
		nOkuriLen	= 0 ;
	} else {
		rszOkuri [0]	= pBuffer->m_bufComp [iPoint - 1] ;
		nOkuriLen	= 1 ;
	}
	if (nOkuriLen > 0) {
		if (rszOkuri [0] == L'�' || rszOkuri [0] == L'�') {
			rszOkuri [1]	= rszOkuri [0] ;
			rszOkuri [0]	= pBuffer->m_bufComp [iPoint - 2] ;
			nOkuriLen		= 2 ;
			bSokuon			= TRUE ;
		} else {
			if (! (iPoint >= (iBufferTop + 2) && pBuffer->m_bufComp [iPoint - 2] == L'�')) {
				bSokuon		= FALSE ;
			}
		}
	}
	if (nOkuriLen > 0) {
		DCHAR		bufTemp [32], bufTemp2 [32], bufSkkOkuriChar [32] ;
		int			nZenkakuOkuriLen, nHiraganaOkuriLen, nSkkOkuriCharLen ;

		if (! ImeBuffer_bSetMarker (pBuffer, &pBuffer->m_pmkSkkOkuriganaStartPoint, MARKER_SKK_OKURIGANA_START_POINT, pBuffer->m_pmkPoint) ||
			pBuffer->m_pmkSkkOkuriganaStartPoint == NULL) {
			ImeDoc_vSetSignalError (pThis) ;
			return	LMR_RETURN ;
		}
		(void) TMarker_bBackward (pBuffer->m_pmkSkkOkuriganaStartPoint, bSokuon? 2 : 1) ;

		nZenkakuOkuriLen	= iSkkJisx0201Zenkaku (bufTemp, ARRAYSIZE (bufTemp), rszOkuri, nOkuriLen) ;
		nHiraganaOkuriLen	= iSkkKatakanaToHiragana (bufTemp2, ARRAYSIZE (bufTemp2), bufTemp, nZenkakuOkuriLen, FALSE) ;

		pBuffer->m_nSkkOkuriCharLen	= imeBuffer_iSkkOkuriganaPrefix (pBuffer, bufTemp2, nHiraganaOkuriLen, pBuffer->m_bufSkkOkuriChar, ARRAYSIZE (pBuffer->m_bufSkkOkuriChar)) ;

		/*	���Ƃ��Ƃ� skk-katakana �̒l���o���āASetOkurigana ���Ăяo���B
		 */
		if (! ImeDoc_bPushReg (pThis, LMREG_1))
			return	LMR_ERROR ;
		ImeDoc_vSetRegInteger (pThis, LMREG_1, pBuffer->m_bSkkKatakana) ;
		pBuffer->m_bSkkKatakana	= LTRUE ;
		if (! ImeDoc_bCall (pThis,  LM_bSkkSetOkurigana, LM_bSkkSetOkuriganaAdJisx0201_2))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	return	LMR_RETURN ;
}

int
LM_bSkkSetOkuriganaAdJisx0201_2 (
	struct CImeDoc*			pThis)
{
	struct CImeBuffer*		pBuffer ;
	int				iSkkKatakana ;

	/*	(let (skk-katakana) ...) �� skk-katakana �� local-scope �ł��邱�Ƃ�
	 *	�Ή�����㏈���B
	 */
	if (! ImeDoc_bGetRegInteger (pThis, LMREG_1, &iSkkKatakana))
		iSkkKatakana	= LFALSE ;
	ImeDoc_vPopReg (pThis, LMREG_1) ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkKatakana	= iSkkKatakana ;
	ImeDoc_vSetRegNil (pThis, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-insert-jisx0201
 */
static	int	LM_bSkkInsertAdJisx0201_1 (struct CImeDoc* pThis) ;
static	int	LM_bSkkInsertAdJisx0201_2 (struct CImeDoc* pThis) ;
static	int	LM_bSkkInsertAdJisx0201_3 (struct CImeDoc* pThis) ;

int
LM_bSkkInsertAdJisx0201 (
	struct CImeDoc*		pThis)
{
	struct CImeBuffer*				pBuffer ;
	DCHAR							wch ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;
	int								nPrefix ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}

	if (! pBuffer->m_bSkkJisx0201Mode) {
		ImeDoc_vJump (pThis, LM_bSkkInsert) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetLastCommandChar (pThis, &wch)) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;

	/*
       ((or (and (not skk-jisx0201-roman)
                 (memq ch skk-set-henkan-point-key)
                 (or skk-okurigana
                     (not (skk-get-prefix skk-current-rule-tree))
                     (not (skk-select-branch
                           skk-current-rule-tree ch))))
            (and skk-henkan-mode
                 (memq ch skk-special-midashi-char-list)))
        ad-do-it)
		*/
	if ((! pBuffer->m_bSkkJisx0201Roman && 
			ImeConfig_bSkkSetHenkanPointKeyp (wch) &&
			(pBuffer->m_bSkkOkurigana ||
			 SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) == NULL ||
			 ! SkkRuleTreeIterator_bHaveSelectBranchp (piteSkkRuleTree, wch))) ||
		(pBuffer->m_bSkkHenkanMode && 
		ImeConfig_bSkkSpecialMidashiCharp (wch))) {
		ImeDoc_vJump (pThis, LM_bSkkInsert) ;
		return	LMR_CONTINUE ;
	}
	/*
       ((and skk-henkan-mode
             (eq ch skk-start-henkan-char))
        (skk-kana-cleanup 'force)
        (unless (or skk-okurigana
                    skk-okuri-char)
          (let ((jisx0201 (buffer-substring-no-properties
                           skk-henkan-start-point
                           (point)))
                jisx0208)
            (when (and jisx0201
                       (setq jisx0208
                             (skk-jisx0201-zenkaku jisx0201)))
              (insert-before-markers jisx0208)
              (delete-region skk-henkan-start-point
                             (- (point) (length jisx0208))))))
        (let ((skk-katakana t))
          (skk-start-henkan arg))
        (skk-cursor-set))
		*/
	if (pBuffer->m_bSkkHenkanMode && ImeConfig_bSkkStartHenkanCharp (wch)) {
		ImeDoc_vSetRegBool (pThis, LMREGARG_0, TRUE) ;
		if (! ImeDoc_bCall (pThis, LM_bSkkKanaCleanup, LM_bSkkInsertAdJisx0201_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	/*
      (skk-jisx0201-roman
        (let (skk-set-henkan-point-key)
          ad-do-it))
		  */
	if (pBuffer->m_bSkkJisx0201Roman) {
		/*	(let (skk-set-henkan-point-key) �ɑ����B
		 */
		BOOL	bMask	= ImeConfig_bSkkSetHenkanPointKeyMaskedp () ;
		if (! ImeDoc_bPushReg (pThis, LMREG_0))
			return	LMR_ERROR ;
		ImeConfig_vMaskSkkSetHenkanPointKey (FALSE) ;
		ImeDoc_vSetRegInteger (pThis, LMREG_0, bMask) ;

		/*	ad-do-it
		 */
		if (! ImeDoc_bCall (pThis, LM_bSkkInsert, LM_bSkkInsertAdJisx0201_3))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	ImeDoc_vJump (pThis, LM_bSkkInsert) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkInsertAdJisx0201_1 (
	struct CImeDoc*		pThis)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR		pwJisx0201 ;
	DCHAR		bufJisx0208 [MAXCOMPLEN] ;
	int			iJisx0201Len, iJisx0208Len ;
	int			iSkkKatakana ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}

	/*
	    (unless (or skk-okurigana
                    skk-okuri-char)
          (let ((jisx0201 (buffer-substring-no-properties
                           skk-henkan-start-point
                           (point)))
                jisx0208)
            (when (and jisx0201
                       (setq jisx0208
                             (skk-jisx0201-zenkaku jisx0201)))
              (insert-before-markers jisx0208)
              (delete-region skk-henkan-start-point
                             (- (point) (length jisx0208))))))
 		*/
	if (! (pBuffer->m_bSkkOkurigana || pBuffer->m_nSkkOkuriCharLen > 0)) {
		int		iSkkHenkanStartPoint ;
		int		iPoint ;

		iSkkHenkanStartPoint	= (pBuffer->m_pmkSkkHenkanStartPoint != NULL)?	TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)	: 0 ;
		iPoint					= (pBuffer->m_pmkPoint != NULL)?				TMarker_iGetPosition (pBuffer->m_pmkPoint)					: 0 ;
		if (iSkkHenkanStartPoint >= 0 && iPoint >= 0 && iPoint >= iSkkHenkanStartPoint) {
			iJisx0201Len	= iPoint - iSkkHenkanStartPoint ;
			pwJisx0201		= pBuffer->m_bufComp + iSkkHenkanStartPoint ;
		} else {
			iJisx0201Len	= 0 ;
			pwJisx0201		= NULL ;
		}
		if (iJisx0201Len > 0) {
			iJisx0208Len	= iSkkJisx0201Zenkaku (bufJisx0208, ARRAYSIZE (bufJisx0208), pwJisx0201, iJisx0201Len) ;
			if (iJisx0208Len > 0) {
				/*	insert-before-markers �łȂ���΁Ahenkan-end-point �� henkan-start-point �Ɉ�v���Ă��܂��B
				 *	�ꎞ�I�� marker ��S�� cursor marker �������Ă� insert ���K�v�B
				 */
				ImeBuffer_bInsertBeforeMarkers (pBuffer, bufJisx0208, iJisx0208Len) ;

				iSkkHenkanStartPoint	= (pBuffer->m_pmkSkkHenkanStartPoint != NULL)?	TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)	: 0 ;
				iPoint					= (pBuffer->m_pmkPoint != NULL)?				TMarker_iGetPosition (pBuffer->m_pmkPoint)					: 0 ;
				ImeBuffer_bDeleteRegion (pBuffer, iSkkHenkanStartPoint, iPoint - iJisx0208Len) ;
			}
		}
	}

	/*
       (let ((skk-katakana t))
          (skk-start-henkan arg))
        (skk-cursor-set))
		*/
	if (! ImeDoc_bPushReg (pThis, LMREG_1))
		return	LMR_ERROR ;

	ImeDoc_vSetRegInteger (pThis, LMREG_1, pBuffer->m_bSkkKatakana) ;
	pBuffer->m_bSkkKatakana	= LTRUE ;
	if (! ImeDoc_bCall (pThis,  LM_bSkkStartHenkan, LM_bSkkInsertAdJisx0201_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkInsertAdJisx0201_2 (
	struct CImeDoc*		pThis)
{
	struct CImeBuffer*	pBuffer ;
	int			iSkkKatakana ;

	if (ImeDoc_bGetRegInteger (pThis, LMREG_1, &iSkkKatakana))
		iSkkKatakana	= LFALSE ;
	ImeDoc_vPopReg (pThis, LMREG_1) ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkKatakana	= iSkkKatakana ;
	ImeDoc_vSetRegNil (pThis, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
LM_bSkkInsertAdJisx0201_3 (
	struct CImeDoc*		pThis)
{
	int			iMask ;

	/*	skk-set-henkan-point-key �� mask �����ɖ߂��B
	 */
	if (ImeDoc_bGetRegInteger (pThis, LMREG_1, &iMask))
		iMask	= FALSE ;
	ImeDoc_vPopReg (pThis, LMREG_1) ;
	ImeConfig_vMaskSkkSetHenkanPointKey ((BOOL) iMask) ;
	ImeDoc_vSetRegNil (pThis, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-zenkaku-region
 */
int
LM_bSkkJisx0201ZenkakuRegion (
	struct CImeDoc*			pThis)
{
	struct CImeBuffer*	pBuffer ;
	int		nStartPos, nEndPos ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	int		nLength, nReplaceText ;

	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegInteger (pThis, LMREGARG_0, &nStartPos) || ! ImeDoc_bGetRegInteger (pThis, LMREGARG_1, &nEndPos)) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (! imeBuffer_bValidRegionp (pBuffer, nStartPos, nEndPos)) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}

	nReplaceText	= nEndPos - nStartPos ;
	nLength			= iSkkJisx0201Zenkaku (bufTemp, ARRAYSIZE (bufTemp), pBuffer->m_bufComp + nStartPos, nReplaceText) ;
	if (nLength < nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
		ImeBuffer_bDeleteRegion (pBuffer, nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nReplaceText) ;
		ImeBuffer_iInsertByPosition (pBuffer, nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
	}
	ImeDoc_vSetRegNil (pThis, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-region
 */
int
LM_bSkkJisx0201Region (
	struct CImeDoc*			pThis)
{
	struct CImeBuffer*	pBuffer ;
	int		nStartPos, nEndPos ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	int		nLength, nReplaceText ;

	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegInteger (pThis, LMREGARG_0, &nStartPos) || ! ImeDoc_bGetRegInteger (pThis, LMREGARG_1, &nEndPos)) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (! imeBuffer_bValidRegionp (pBuffer, nStartPos, nEndPos)) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}

	nReplaceText	= nEndPos - nStartPos ;
	nLength			= iSkkJisx0201Hankaku (bufTemp, ARRAYSIZE (bufTemp), pBuffer->m_bufComp + nStartPos, nReplaceText) ;
	if (nLength < nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
		ImeBuffer_bDeleteRegion (pBuffer, nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nReplaceText) ;
		ImeBuffer_iInsertByPosition (pBuffer, nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
	}
	ImeDoc_vSetRegNil (pThis, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-henkan
 */
int
LM_bSkkJisx0201Henkan (
	struct CImeDoc*			pThis)
{
	/*
		  "�����[�h�ł���΁A�̈�̂Ђ炪��/�J�^�J�i�� �ݶ����� �ɕϊ�����B
		�����[�h�ł͉������Ȃ��B
		���̑��̃��[�h�ł́A�I���W�i���̃L�[����t���Ńo�C���h����Ă���R�}���h�����s
		����B"
		  (interactive "*P")
		  (skk-henkan-skk-region-by-func #'skk-jisx0201-region arg))
	 */
	ImeDoc_vSetRegPointer (pThis, LMREGARG_0, &LM_bSkkJisx0201Region) ;
	ImeDoc_vSetRegBool (pThis, LMREGARG_1, LFALSE) ;
	ImeDoc_vJump (pThis, &LM_bSkkHenkanSkkRegionByFunc) ;
	return	LMR_CONTINUE ;
}


/*================================================================ skk-toggle-katakana
 */
static	int	LM_bSkkToggleKatakana_1 (struct CImeDoc* pThis) ;
static	int	LM_bSkkToggleKatakana_2 (struct CImeDoc* pThis) ;

int
LM_bSkkToggleKatakana (
	struct CImeDoc*			pThis)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_bSkkHenkanMode == LON) {
		ImeDoc_vJump (pThis, LM_bSkkJisx0201Henkan) ;
		return	LMR_CONTINUE ;
	} else if (pBuffer->m_bSkkJisx0201Mode) {
		if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
			if (! ImeDoc_bCall (pThis, LM_bSkkKakuteiAdJisx0201, LM_bSkkToggleKatakana_1))
				return	LMR_ERROR ;
		} else {
			ImeDoc_vJump (pThis, LM_bSkkToggleKatakana_1) ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
			if (! ImeDoc_bCall (pThis, LM_bSkkKakuteiAdJisx0201, LM_bSkkToggleKatakana_2))
				return	LMR_ERROR ;
		} else {
			ImeDoc_vJump (pThis, LM_bSkkToggleKatakana_2) ;
		}
		return	LMR_CONTINUE ;
	}
}

int
LM_bSkkToggleKatakana_1 (
	struct CImeDoc*			pThis)
{
	struct CImeBuffer*				pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;

	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkJisx0201Mode	= LFALSE ;
	imeBuffer_bSkkJModeOn (pBuffer, pBuffer->m_bSkkKatakana) ;

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
	SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, RULETREENO_SKK_BASE) ;
	return	LMR_RETURN ;
}

int
LM_bSkkToggleKatakana_2 (
	struct CImeDoc*			pThis)
{
	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;

	ImeDoc_vSetRegNil (pThis, LMREGARG_0) ;
	ImeDoc_vJump (pThis, LM_bSkkJisx0201ModeOn) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-toggle-jisx0201
 */
int
LM_bSkkToggleJisx0201 (
	struct CImeDoc*			pThis)
{
	struct CImeBuffer*				pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;

	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pThis)  ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pThis) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_bSkkHenkanMode == LON) {
		ImeDoc_vJump (pThis, LM_bSkkJisx0201Henkan) ;
		return	LMR_CONTINUE ;
	} else if (pBuffer->m_bSkkJisx0201Roman) {
		piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
		SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
		SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, RULETREENO_SKK_JISX0201_BASE) ;
		pBuffer->m_bSkkJisx0201Roman	= LFALSE ;
	} else {
		piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
		SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
		SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, RULETREENO_SKK_JISX0201_ROMAN) ;
		pBuffer->m_bSkkJisx0201Roman	= LTRUE ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0201-mode
 */
static	int	LM_bSkkJisx0201Mode_Exit (struct CImeDoc* pThis) ;

int
LM_bSkkJisx0201Mode (
	struct CImeDoc*			pThis)
{
	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;
	if (! ImeDoc_bCall (pThis,  LM_bSkkKakuteiAdJisx0201, LM_bSkkJisx0201Mode_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkJisx0201Mode_Exit (
	struct CImeDoc*			pThis)
{
	if (ImeDoc_bSignalp (pThis))
		return	LMR_RETURN ;
	ImeDoc_vSetRegNil (pThis, LMREGARG_0) ;
	ImeDoc_vJump (pThis, LM_bSkkJisx0201ModeOn) ;
	return	LMR_CONTINUE ;
}





