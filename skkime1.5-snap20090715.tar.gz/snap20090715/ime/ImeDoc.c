#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDocP.h"
#include "ImeBuffer.h"
#include "TMarker.h"
#include "lmstate.h"
#include "jstring.h"
#include "RuleTreeNode.h"
#include "ImeConfig.h"

#define	NLOOP_IMEDOC	256

/*========================================================================
 *	prototypes
 */
static	BOOL	imeDoc_bDefineMajorModeMap				(struct CImeDoc*) ;
static	BOOL	imeDoc_bDefineSkkJModeMap				(struct CImeDoc*) ;
static	BOOL	imeDoc_bDefineSkkLatinModeMap			(struct CImeDoc*) ;
static	BOOL	imeDoc_bDefineSkkJisx0208LatinModeMap	(struct CImeDoc*) ;
static	BOOL	imeDoc_bDefineSkkAbbrevModeMap			(struct CImeDoc*) ;

static	struct CImeBuffer*	imeDoc_pCreateBuffer		(struct CImeDoc*, LPCDSTR, int) ;
static	void	imeDoc_vDeleteUnusedBuffer				(struct CImeDoc*) ;
static	BOOL	imeDoc_bDeleteBuffer					(struct CImeDoc*, struct CImeBuffer*) ;

static	BOOL	imeDoc_bTick							(struct CImeDoc*) ;
static	BOOL	imeDoc_bInitConfig						(struct CImeDoc*) ;
static	void	imeDoc_vUninitConfig					(struct CImeDoc*) ;

static	BOOL	imeDoc_bWhereIsInternal					(const struct CImeKeymap*, int, struct TMSG*) ;
static	BOOL	imeDoc_bProcessFunctionp				(struct CImeDoc*, int) ;
static	BOOL	imeDoc_bLookupKeymap					(const struct CImeKeymap*, const struct TMSG*, int*) ;
static	int		imeDoc_iGetKeyMatchScore				(unsigned int, unsigned int, unsigned int) ;

static	BOOL	imeDoc_bUpdateCandidateInfoForStatusText	(struct CImeDoc*) ;

static	BOOL	imeDoc_bInitContextBuffer				(struct CImeDoc*) ;
static	void	imeDoc_vUninitContextBuffer				(struct CImeDoc*) ;
static	BOOL	imeDoc_bEmulateFilterEvent				(struct CImeDoc*, const struct TMSG*, BOOL*) ;

/*========================================================================
 *	static global variable
 */
static	struct CImeDocContext	s_DocContext ;

/*========================================================================
 *	public functions (ImeUI inferface)
 */
BOOL
ImeDoc_bInit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int						i ;

	pDoc->m_pPC					= LM_iMessageLoop ;
	pDoc->m_nRetPC				= 0 ;

	pDoc->m_nUnreadMessages		= 0 ;
	pDoc->m_nBuffer				= 0 ;
	pDoc->m_nUnusedBuffer		= 0 ;
	pDoc->m_pCurBuffer			= NULL ;
	pDoc->m_pbStackArea			= 0 ;
	pDoc->m_nStackHead			= 0 ;
	pDoc->m_nStackAreaSize		= 0 ;
	pDoc->m_nRegStackHead		= 0 ;
	pDoc->m_pRegStack			= NULL ;

	pDoc->m_nSignal				= LMSIGNAL_NONE ;
	pDoc->m_iThisCommand		= NFUNC_INVALID_CHAR ;
	pDoc->m_iLastCommand		= NFUNC_INVALID_CHAR ;
	memset (&pDoc->m_LastEvent, 0, sizeof (pDoc->m_LastEvent)) ;
	pDoc->m_nbufMessage			= 0 ;
	pDoc->m_pPreCommandHook		= NULL ;
	pDoc->m_pPostCommandHook	= NULL ;
	pDoc->m_dwUpdateFlag		= 0 ;

	memset (pDoc->m_rpBuffer,		0, sizeof (pDoc->m_rpBuffer)) ;
	memset (pDoc->m_rpUnusedBuffer, 0, sizeof (pDoc->m_rpUnusedBuffer)) ;

	TVarbuffer_Init (&pDoc->m_vbufCandInfo, 1) ;
	TVarbuffer_Init (&pDoc->m_vbufMessage,  1) ;

	if (! imeDoc_bInitConfig (pDoc))
		return	FALSE ;

	pBuffer	= ImeDoc_pCreateBuffer (pDoc, NULL, 0, TRUE) ;
	if (pBuffer == NULL)
		return	FALSE ;

	pDoc->m_pbStackArea			= (LPBYTE) MALLOC (NSIZE_IMEDOC_STACK) ;
	if (pDoc->m_pbStackArea == NULL) 
		return	FALSE ;
	pDoc->m_nStackAreaSize		= NSIZE_IMEDOC_STACK ;

	pDoc->m_pRegStack			= (struct LMREG*) MALLOC (sizeof (struct LMREG) * NSIZE_REGSTACK) ;
	if (pDoc->m_pRegStack == NULL)
		return	FALSE ;

	for (i = 0 ; i < ARRAYSIZE (pDoc->m_rREGS) ; i ++)
		pDoc->m_rREGS [i].m_nType	= LMREGTYPE_NIL ;

	if (! imeDoc_bInitContextBuffer (pDoc))
		return	FALSE ;

	pDoc->m_pCurBuffer			= pBuffer ;

	/*	skk-mode-invoke
	 */
	pDoc->m_pPreCommandHook		= LM_bSkkPreCommand ;
	pDoc->m_pPostCommandHook	= LM_bSkkPostCommand ;
	return	TRUE ;
}

void
ImeDoc_vUninit (
	struct CImeDoc*			pDoc)
{
	int		i ;

	if (pDoc == NULL)
		return ;

	for (i = 0 ; i < pDoc->m_nBuffer ; i ++) {
		ImeBuffer_vDestroy (pDoc->m_rpBuffer [i]) ;
		pDoc->m_rpBuffer [i]	= NULL ;
	}
	for (i = 0 ; i < pDoc->m_nUnusedBuffer ; i ++) {
		ImeBuffer_vDestroy (pDoc->m_rpUnusedBuffer [i]) ;
		pDoc->m_rpUnusedBuffer [i]	= NULL ;
	}
	pDoc->m_nBuffer = pDoc->m_nUnusedBuffer = 0 ;

	imeDoc_vUninitContextBuffer (pDoc) ;
	imeDoc_vUninitConfig (pDoc) ;

	TVarbuffer_Uninit (&pDoc->m_vbufCandInfo) ;
	TVarbuffer_Uninit (&pDoc->m_vbufMessage) ;
	return ;
}

void
ImeDoc_vClear (
	struct CImeDoc*			pDoc)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (pDoc->m_rREGS) ; i ++)
		pDoc->m_rREGS [i].m_nType	= LMREGTYPE_NIL ;

	/*	stack �ʒu��擪�ɖ߂��B
	 */
	pDoc->m_nRegStackHead		= 0 ;
	pDoc->m_nStackHead			= 0 ;
	pDoc->m_pPC					= LM_iMessageLoop ;
	pDoc->m_nRetPC				= 0 ;
	pDoc->m_nUnreadMessages		= 0 ;
	pDoc->m_nSignal				= LMSIGNAL_NONE ;

	for (i = 1 ; i < pDoc->m_nBuffer ; i ++) {
		if (ImeDoc_bDeleteBuffer (pDoc, pDoc->m_rpBuffer [i]))
			pDoc->m_rpBuffer [i]	= NULL ;
	}
	if (pDoc->m_rpBuffer [0] != NULL) {
		ImeBuffer_bClear (pDoc->m_rpBuffer [0]) ;
		pDoc->m_pCurBuffer	= pDoc->m_rpBuffer [0] ;
		ImeBuffer_bSetConversionMode (pDoc->m_pCurBuffer, IMECMODE_HIRAGANA) ;
	} else {
		pDoc->m_pCurBuffer	= NULL ;
	}
	pDoc->m_iThisCommand		= NFUNC_INVALID_CHAR ;
	pDoc->m_iLastCommand		= NFUNC_INVALID_CHAR ;
	memset (&pDoc->m_LastEvent, 0, sizeof (pDoc->m_LastEvent)) ;
	pDoc->m_nbufMessage			= 0 ;

	TVarbuffer_Clear (&pDoc->m_vbufCandInfo) ;
	TVarbuffer_Clear (&pDoc->m_vbufMessage) ;
	return ;
}

LPCDSTR
ImeDoc_pGetPreeditText (struct CImeDoc* pDoc, int* pnLength)
{
	ASSERT (pDoc->m_nBuffer > 0 && pDoc->m_rpBuffer [0] != NULL) ;

	return	ImeBuffer_pBufferRawString (pDoc->m_rpBuffer [0], pnLength) ;
}

BOOL
ImeDoc_bGetPreeditCursor (const struct CImeDoc* pDoc, int* pnCursor)
{
	struct TMarker*	pmkPoint ;

	ASSERT (pDoc->m_nBuffer > 0 && pDoc->m_rpBuffer [0] != NULL) ;
	ASSERT (pnCursor != NULL) ;

	if (! ImeBuffer_bGetMarker (pDoc->m_rpBuffer [0], MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
		return	FALSE ;
	*pnCursor	= TMarker_iGetPosition (pmkPoint) ;
	return	TRUE ;
}

/*	��⃊�X�g��\�����Ȃ���΂Ȃ�Ȃ���Ԃ��ǂ����𔻒肷��B
 */
BOOL
ImeDoc_bShowCandidatesListp (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	FALSE ;
	if (ImeBuffer_bShowHenkanCandidatesModep (pCurBuffer) || ImeBuffer_bInputByCodeOrMenuModep (pCurBuffer))
		return	TRUE ;
	return	FALSE ;
}

#if 0
LPMYCAND
ImeDoc_pGetCandidatesList (
	struct CImeDoc*		pDoc,
	DWORD*				pdwSize)
{
	TVarbuffer*	pvbuf ;
	DWORD		dwSize ;

	if (pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer || pDoc->m_nbufMessage > 0) {
		if (ImeBuffer_bShowHenkanCandidatesModep (pDoc->m_pCurBuffer) || 
			ImeBuffer_bInputByCodeOrMenuModep	(pDoc->m_pCurBuffer)) {
			pvbuf	= &pDoc->m_vbufCandInfo ;
		} else {
			pvbuf	= &pDoc->m_vbufMessage ;
		}
	} else {
		if (ImeBuffer_bShowHenkanCandidatesModep (pDoc->m_pCurBuffer) || 
			ImeBuffer_bInputByCodeOrMenuModep	(pDoc->m_pCurBuffer)) {
			pvbuf	= &pDoc->m_vbufCandInfo ;
		} else {
			return	NULL ;
		}
	}
	dwSize		= TVarbuffer_GetUsage (pvbuf) ;
	if (dwSize <= sizeof (MYCAND))
		return	NULL ;
	*pdwSize	= dwSize ;
	return	(LPMYCAND) TVarbuffer_GetBuffer (pvbuf) ;
}
#endif

#if !defined (UNITTEST)
LPMYCAND
ImeDoc_pGetStatusText (
	struct CImeDoc*		pDoc,
	DWORD*				pdwSize)
{
	TVarbuffer*	pvbuf ;
	DWORD		dwSize ;

	if (pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer || pDoc->m_nbufMessage > 0) {
		if (ImeBuffer_bShowHenkanCandidatesModep (pDoc->m_pCurBuffer) || 
			ImeBuffer_bInputByCodeOrMenuModep	(pDoc->m_pCurBuffer)) {
			pvbuf	= &pDoc->m_vbufCandInfo ;
		} else {
			pvbuf	= &pDoc->m_vbufMessage ;
		}
	} else {
		if (ImeBuffer_bShowHenkanCandidatesModep (pDoc->m_pCurBuffer) || 
			ImeBuffer_bInputByCodeOrMenuModep	(pDoc->m_pCurBuffer)) {
			pvbuf	= &pDoc->m_vbufCandInfo ;
		} else {
			return	NULL ;
		}
	}
	dwSize		= TVarbuffer_GetUsage (pvbuf) ;
	if (dwSize <= sizeof (MYCAND))
		return	NULL ;
	*pdwSize	= dwSize ;
	return	(LPMYCAND) TVarbuffer_GetBuffer (pvbuf) ;
}
#else
LPCDSTR
ImeDoc_pGetStatusText (struct CImeDoc* pDoc, int* pnLength)
{
	ASSERT (pDoc->m_nBuffer > 0 && pDoc->m_rpBuffer [0] != NULL) ;
	ASSERT (pnLength != NULL) ;

	if (pDoc->m_nbufMessage > 0) {
		*pnLength	= pDoc->m_nbufMessage ;
		return	pDoc->m_bufMessage ;
	} else {
		if (pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer)
			return	ImeBuffer_pBufferRawString (pDoc->m_pCurBuffer, pnLength) ;
	}
	*pnLength	= 0 ;
	return	NULL ;
}
#endif

BOOL
ImeDoc_bGetStatusCursor (const struct CImeDoc* pDoc, int* pnCursor)
{
	struct TMarker*	pmkPoint ;

	ASSERT (pnCursor != NULL) ;

#if 0
	if (pDoc->m_nbufMessage > 0)
		return	FALSE ;
	if (pDoc->m_rpBuffer [0] == pDoc->m_pCurBuffer)
		return	FALSE ;

	if (! ImeBuffer_bGetMarker (pDoc->m_pCurBuffer, MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
		return	FALSE ;
	*pnCursor	= TMarker_iGetPosition (pmkPoint) ;
	return	TRUE ;
#else
	/*	�D�揇�ʂ̕ύX�ɔ����AMinibuffer �� Cursor ����̗D�揇�ʂ��ύX����B
	 *	�܂��ċA�ҏW����Ă��邩�ǂ����A����Ă��Ȃ���΁A�Ƃ���B
	 */
	if (pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer && ! ImeDoc_bShowHenkanCandidatesModep (pDoc) && ! ImeDoc_bInputByCodeOrMenuModep (pDoc, NULL)) {
		int		iCursor ;

		if (! ImeBuffer_bGetMarker (pDoc->m_pCurBuffer, MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
			return	FALSE ;
		iCursor	= TMarker_iGetPosition (pmkPoint) ;
		if (pDoc->m_nbufMessage > 0) {
			/*	�擪�́u�I�v�̒ǉ��̂��߂� minibuffer text �� region �I��������Ă�
			 *	�܂��B����āAiCursor + 1 ���Ȃ��Ƃ����Ȃ����O�ɏo���Ă��܂��킯�ɂ�
			 *	�����Ȃ��B
			 */
			iCursor	++ ;
		}
		*pnCursor	= iCursor ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
#endif
}

BOOL
ImeDoc_bIsStatusActivep (const struct CImeDoc* pDoc)
{
	return	(pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer) ;
}

BOOL
ImeDoc_bRecursiveEditp (
	const struct CImeDoc*		pDoc)
{
	return	(pDoc->m_nBuffer > 1 && pDoc->m_pCurBuffer != pDoc->m_rpBuffer [0])? TRUE : FALSE ;
}

BOOL
ImeDoc_bQueryFilterEvent	(
	struct CImeDoc*			pDoc,
	const struct TMSG*		pMsg,
	BOOL*					pfEaten)
{
	BOOL	bEaten ;

	if (pDoc == NULL || pMsg == NULL)
		return	FALSE ;

	/*	����͑S�� process ����Ƃ��Ă����B��ɏC���B
	 */
	bEaten	= FALSE ;
	if (ImeDoc_bRecursiveEditp (pDoc)) {
		bEaten	= TRUE ;
	} else {
		if (ImeBuffer_bShowHenkanCandidatesModep (pDoc->m_pCurBuffer) ||
			ImeBuffer_bInputByCodeOrMenuModep (pDoc->m_pCurBuffer)) {
			bEaten	= TRUE ;
		} else if (ImeBuffer_bHavePrefixp (pDoc->m_pCurBuffer)) {
			/*	prefix �����݂���΁Askk-pre-command �����s����Ȃ���΂Ȃ�Ȃ��̂ŁA
			 *	eaten
			 */
			bEaten	= TRUE ;
		} else {
			int		nText, nFuncNo ;

			/* �����Ŏ��ۂɐH�ׂ�L�[�����ǂ��������`�F�b�N����B*/
			(void) ImeBuffer_pBufferString (pDoc->m_pCurBuffer, &nText) ;
			if (nText > 0) {
				/* ���炩�̃e�L�X�g�����͂���Ă���΁A�L�[���ꉞ�H�ׂ�B*/
				bEaten	= TRUE ;
			} else {
				if (ImeDoc_bLookupKeymap (pDoc, pMsg, &nFuncNo) && imeDoc_bProcessFunctionp (pDoc, nFuncNo)) {
					/*	�����Ŏ��ۂɂ� original-keymap ���Ă΂�� unprocess-keyevent ��
					 *	�Ă΂��\��������B�P���� Eaten ���ƌ��ߕt���邱�Ƃ͂ł��Ȃ��B
					 *	���ۂ� Tick ���Ăяo���Ă݂āA���̌��� Unprocess Message ������
					 *	���邩�ǂ���������K�v������B�������A���̂��߂ɂ͂ǂꂾ����
					 *	�X�e�[�g��ێ����Ȃ���΂Ȃ�Ȃ��̂��낤���H
					 */
					if (! imeDoc_bEmulateFilterEvent (pDoc, pMsg, &bEaten)) {
						bEaten	= TRUE ;	/* �G���[�͐H�ׂ邩�H */
					}
				}
			}
		}
	}
	if (pfEaten != NULL)
		*pfEaten	= bEaten ;
	return	TRUE ;
}

BOOL
ImeDoc_bFilterEvent	(
	struct CImeDoc*			pDoc,
	const struct TMSG*		pMsg)
{
	BOOL	bRetval ;
	int		iConversionMode ;

	if (! ImeDoc_bPushEvent (pDoc, pMsg))
		return	FALSE ;

	/* �������C�x���g�́u��v�ɐݒ肳���B*/
	pDoc->m_UnprocessEvent.m_nMessage	= WM_NULL ;

	/* update flag �͏����������B*/
	ImeDoc_vClearUpdateFlag (pDoc) ;
	ImeDoc_vClearMessage (pDoc) ;
	iConversionMode	= ImeDoc_iGetConversionMode (pDoc) ;
	bRetval			= imeDoc_bTick (pDoc) ;

	if (bRetval && iConversionMode != ImeDoc_iGetConversionMode (pDoc)) {
		ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_UPDATE_CONVERSIONMODE) ;
	}
	/* status candidate �� update */
	imeDoc_bUpdateCandidateInfoForStatusText (pDoc) ;
	ImeDoc_vDeleteUnusedBuffer (pDoc) ;
	return	bRetval ;
}

BOOL
ImeDoc_bQueryToggleIMEEvent	(
	struct CImeDoc*			pDoc,
	const struct TMSG*		pMsg,
	BOOL*					pfEaten)
{
	BOOL	bEaten ;
	int		nFuncNo ;

	if (pDoc == NULL || pMsg == NULL)
		return	FALSE ;

	if (ImeDoc_bLookupKeymap (pDoc, pMsg, &nFuncNo) && nFuncNo == NFUNC_TOGGLE_IME) {
		bEaten	= TRUE ;
	} else {
		bEaten	= FALSE ;
	}
	if (pfEaten != NULL)
		*pfEaten	= bEaten ;
	return	TRUE ;
}

const struct TMSG*
ImeDoc_pGetUnprocessEvent (
	struct CImeDoc*			pDoc)
{
	if (pDoc == NULL || pDoc->m_UnprocessEvent.m_nMessage == WM_NULL)
		return	NULL ;

	return	&pDoc->m_UnprocessEvent ;
}

int
ImeDoc_iGetReadingText (
	struct CImeDoc*			pDoc,
	LPDSTR					pwReading,
	int						nReadingSize,
	int						nCompPosition,
	int*					pnReadingPosition)
{
	/*	buffer class �� (henkan-start-point, henkan-end-point, henkan-key) �̃y�A��
	 *	�L�^������B�����āAbuffer-string ����鎞�� (henkan-start-point, henkan-end-point) ��
	 *	������� henkan-key �ɒu��������B
	 *	����ő��� reading-text �͂���Ȃ�Ɏ擾�ł��锤�B(top-buffer �ł̂ݎ�������΂�����
	 *	�v��)
	 */
	if (pDoc == NULL || pwReading == NULL)
		return	0 ;

	return	ImeBuffer_iGetReadingText (pDoc->m_rpBuffer [0], pwReading, nReadingSize, nCompPosition, pnReadingPosition) ;
}

/*	�ϊ����[�h��؂�ւ���Btopbuffer ��؂�ւ���̂͗ǂ��̂����Arecursive-edit-mode
 *	�������ꍇ�ɂ͗ǂ��̂��낤���H ���̂�����͎d�l�̍ă`�F�b�N���K�v���낤�B
 */
BOOL
ImeDoc_bSetConversionMode (
	struct CImeDoc*			pDoc,
	int						nConversionMode)
{
	struct CImeBuffer*	pBuffer ;
	struct TMSG	msg ;
	int			nCurMode ;

	if (pDoc->m_pCurBuffer == NULL)
		return	FALSE ;
	pBuffer	= pDoc->m_pCurBuffer ;

	/*	�ǂ̂悤�ɂ��� conversion-mode ��ύX������Ηǂ��̂��낤���H
	 *	�܂�A�����[�h��������A�����[�h��������Askk-show-henkan-candidates-mode ��������
	 *	skk-input-by-code-or-menu-mode �������肵������ conversion-mode ��ύX������Ƃ�������
	 *	�͉����w���ׂ��Ȃ̂��낤���H
	 */
	nCurMode		= ImeDoc_iGetConversionMode (pDoc) ;
	if (nCurMode == nConversionMode)
		return	TRUE ;

	/* �������C�x���g�́u��v�ɐݒ肳���B*/
	pDoc->m_UnprocessEvent.m_nMessage	= WM_NULL ;
	/* update flag �͏����������B*/
	ImeDoc_vClearUpdateFlag (pDoc) ;			

	msg.m_nMessage	= WM_LM_COMMAND ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= msg.m_pt.y	= 0 ;

	switch (nConversionMode) {
	case	IMECMODE_HIRAGANA:
	case	IMECMODE_KATAKANA:
		/* conversion-mode -> hiragana �ւ� route */
		if (! ImeBuffer_bJModep (pBuffer)) {
			/* skk-mode-on ���Ăяo���B*/
			msg.m_wParam	= NFUNC_SKK_MODE ;
			if (! ImeDoc_bPushEvent (pDoc, &msg))
				return	FALSE ;
			/* katakana-mode �� FALSE �ɂȂ�B����Ŋ����B*/
			if (nConversionMode == IMECMODE_KATAKANA) {
				if (! imeDoc_bTick (pDoc)) {
					ImeDoc_vClear (pDoc) ;
					return	FALSE ;
				}
				msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
				if (! ImeDoc_bPushEvent (pDoc, &msg))
					return	FALSE ;
			}
		} else {
			if (ImeBuffer_bLatinModep (pBuffer) || ImeBuffer_bJisx0208LatinModep (pBuffer)) {
				/* skk-kakutei �ł܂� j-mode �ɂ���B*/
				msg.m_wParam	= NFUNC_SKK_MODE ;
				if (! ImeDoc_bPushEvent (pDoc, &msg))
					return	FALSE ;
				if ((  ImeBuffer_bKatakanaModep (pBuffer) && nConversionMode == IMECMODE_HIRAGANA) ||
					(! ImeBuffer_bKatakanaModep (pBuffer) && nConversionMode == IMECMODE_KATAKANA)) {
					if (! imeDoc_bTick (pDoc)) {
						ImeDoc_vClear (pDoc) ;
						return	FALSE ;
					}
					msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
					if (! ImeDoc_bPushEvent (pDoc, &msg))
						return	FALSE ;
				}
			} else if (ImeBuffer_bJisx0201Modep (pBuffer)) {
				/* �܂���������ĂȂ��B*/
				/* toggle-jisx0201 ���Ăяo���B*/
				/* ���̌�Akatakana-mode ���ǂ�������肾���c�B*/
				/* ���̌�Atoggle-characters */
			} else if (ImeBuffer_bKatakanaModep (pBuffer)) {
				if (nConversionMode == IMECMODE_HIRAGANA) {
					msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
					if (! ImeDoc_bPushEvent (pDoc, &msg))
						return	FALSE ;
				}
			} else {
				if (nConversionMode == IMECMODE_KATAKANA) {
					msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
					if (! ImeDoc_bPushEvent (pDoc, &msg))
						return	FALSE ;
				}
			}
		}
		break ;
	case	IMECMODE_ZENKAKU:
	case	IMECMODE_ASCII:
		if (! ImeBuffer_bJModep (pBuffer)) {
			/* skk-mode-on ���Ăяo���B*/
			msg.m_wParam	= NFUNC_SKK_MODE ;
			if (! ImeDoc_bPushEvent (pDoc, &msg))
				return	FALSE ;
			if (! imeDoc_bTick (pDoc)) {
				ImeDoc_vClear (pDoc) ;
				return	FALSE ;
			}
		}
		msg.m_wParam	= (nConversionMode == IMECMODE_ZENKAKU)?  NFUNC_SKK_JISX0208_LATIN_MODE : NFUNC_SKK_LATIN_MODE ;
		if (! ImeDoc_bPushEvent (pDoc, &msg))
			return	FALSE ;
		break ;

	case	IMECMODE_HANKANA:
		if (! ImeBuffer_bJisx0201Modep (pBuffer)) {
			if (! ImeBuffer_bJModep (pBuffer)) {
				/* skk-mode-on ���Ăяo���B*/
				msg.m_wParam	= NFUNC_SKK_MODE ;
				if (! ImeDoc_bPushEvent (pDoc, &msg))
					return	FALSE ;
				if (! imeDoc_bTick (pDoc)) {
					ImeDoc_vClear (pDoc) ;
					return	FALSE ;
				}
			}
			msg.m_wParam	= NFUNC_SKK_TOGGLE_KATAKANA ;
			if (! ImeDoc_bPushEvent (pDoc, &msg))
				return	FALSE ;
		} else {
			if (ImeBuffer_bJisx0201Romanp (pBuffer)) {
				msg.m_wParam	= NFUNC_SKK_TOGGLE_JISX0201 ;
				if (! ImeDoc_bPushEvent (pDoc, &msg))
					return	FALSE ;
			} else {
				return	TRUE ;
			}
		}
		break ;

	case	IMECMODE_HANKANA_ROMAN:
		if (! ImeBuffer_bJisx0201Modep (pBuffer)) {
			if (! ImeBuffer_bJModep (pBuffer)) {
				/* skk-mode-on ���Ăяo���B*/
				msg.m_wParam	= NFUNC_SKK_MODE ;
				if (! ImeDoc_bPushEvent (pDoc, &msg))
					return	FALSE ;
				if (! imeDoc_bTick (pDoc)) {
					ImeDoc_vClear (pDoc) ;
					return	FALSE ;
				}
			}
			msg.m_wParam	= NFUNC_SKK_TOGGLE_KATAKANA ;
			if (! ImeDoc_bPushEvent (pDoc, &msg))
				return	FALSE ;
			if (! imeDoc_bTick (pDoc)) {
				ImeDoc_vClear (pDoc) ;
				return	FALSE ;
			}
			msg.m_wParam	= NFUNC_SKK_TOGGLE_JISX0201 ;
			if (! ImeDoc_bPushEvent (pDoc, &msg))
				return	FALSE ;
		} else {
			if (ImeBuffer_bJisx0201Romanp (pBuffer)) {
				return	TRUE ;
			} else {
				msg.m_wParam	= NFUNC_SKK_TOGGLE_JISX0201 ;
				if (! ImeDoc_bPushEvent (pDoc, &msg))
					return	FALSE ;
			}
		}
		break ;

	case	IMECMODE_OFF:
		/*	����� IME �����Ƃ������Ƃ��Ǝv�����ǁc�����ɗ��邱�Ƃ͂Ȃ��Ǝv���B */
		return	FALSE ;
	}
	if (! imeDoc_bTick (pDoc)) {
		ImeDoc_vClear (pDoc) ;
	}
	return	FALSE ;
}

int
ImeDoc_iGetConversionMode (
	struct CImeDoc*			pDoc)
{
	ASSERT (pDoc != NULL && pDoc->m_nBuffer > 0 && pDoc->m_rpBuffer [0] != NULL) ;
	return	ImeBuffer_iGetConversionMode (pDoc->m_rpBuffer [0]) ;
}

BOOL
ImeDoc_bSetConversionString (
	struct CImeDoc*		pDoc,
	LPCDSTR				wstrText,
	int					nText)
{
	/*	����̓��[�h�ɂ���ē��삪�قȂ�B
	 */
	ImeDoc_vClear (pDoc) ;
	return	ImeBuffer_bSetConversionString (pDoc->m_pCurBuffer, wstrText, nText, ImeConfig_bSkkCompositionAutoShiftp ()) ;
}

BOOL
ImeDoc_bGetSelectedRegion (
	struct CImeDoc*		pDoc,
	int*				pnStartPos,
	int*				pnEndPos)
{
	ASSERT (pDoc != NULL) ;
	
	return	ImeBuffer_bGetSelectedRegion (pDoc->m_pCurBuffer, pnStartPos, pnEndPos) ;
}

BOOL
ImeDoc_bGetConvertedRegion	(
	struct CImeDoc*		pDoc,
	int*				pnStartPos,
	int*				pnEndPos)
{
	ASSERT (pDoc != NULL) ;

	return	ImeBuffer_bGetConvertedRegion (pDoc->m_pCurBuffer, pnStartPos, pnEndPos) ;
}

BOOL
ImeDoc_bQueryUpdateContext (
	struct CImeDoc*		pDoc,
	int*				pnShift,
	int*				pnCursor,
	BOOL*				pfContinue)
{
	ASSERT (pDoc != NULL && pDoc->m_nBuffer > 0 && pDoc->m_rpBuffer [0] != NULL) ;
	ASSERT (pnShift    != NULL) ;
	ASSERT (pnCursor   != NULL) ;
	ASSERT (pfContinue != NULL) ;

	if (pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer) {
		struct TMarker*	pmkPoint ;

		if (! ImeBuffer_bGetMarker (pDoc->m_rpBuffer [0], MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
			return	FALSE ;

		*pnShift	= 0 ;
		*pnCursor	= TMarker_iGetPosition (pmkPoint) ;
		*pfContinue	= TRUE ;
		return	TRUE ;
	}

	/*	�����V�t�g�ł͂Ȃ��A���� newline �ɂ�鋭�� update �������Ă��Ȃ��ꍇ�ɂ�
	 *	�������Ȃ��Bcontinue ���ǂ����͏󋵂ɂ��B
	 */
	if (! ImeConfig_bSkkCompositionAutoShiftp () && (pDoc->m_dwUpdateFlag & IMEDOC_NEWLINE) == 0) {
		struct TMarker*	pmkPoint ;

		if (! ImeBuffer_bGetMarker (pDoc->m_rpBuffer [0], MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
			return	FALSE ;

		*pnShift	= 0 ;
		if (ImeDoc_bProcessEventp (pDoc)) {
			*pnCursor	= TMarker_iGetPosition (pmkPoint) ;
			*pfContinue	= TRUE ;
		} else {
			*pnCursor	= 0 ;
			*pfContinue	= FALSE ;
		}
		return	TRUE ;
	}
	if (ImeConfig_bSkkIsNewlineKakuteiAllp () && (pDoc->m_dwUpdateFlag & IMEDOC_NEWLINE) != 0) {
		if (! ImeBuffer_bSkkHenkanActivep (pDoc->m_rpBuffer [0]) && ! ImeBuffer_bHavePrefixp (pDoc->m_rpBuffer [0])) {
//		if (! ImeBuffer_bSkkHenkanActivep (pDoc->m_rpBuffer [0]) && ImeBuffer_pSkkGetSkkCurrentRuleTree (pDoc->m_rpBuffer [0]) == NULL) {
			struct TMarker*	pmkPoint ;
			struct TMarker*	pmkBufferEnd ;
			int				iMove ;

			if (! ImeBuffer_bGetMarker (pDoc->m_rpBuffer [0], MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
				return	FALSE ;
			if (! ImeBuffer_bGetMarker (pDoc->m_rpBuffer [0], MARKER_BUFFEREND, &pmkBufferEnd) || pmkBufferEnd == NULL)
				return	FALSE ;
			iMove	= TMarker_iGetPosition (pmkBufferEnd) - TMarker_iGetPosition (pmkPoint) ;
			if (! TMarker_bForward (pmkPoint, iMove))
				return	FALSE ;
		}
	}
	return	ImeBuffer_bQueryUpdateContext (pDoc->m_rpBuffer [0], pnShift, pnCursor, pfContinue) ;
}

BOOL
ImeDoc_bUpdateContext (
	struct CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL && pDoc->m_nBuffer > 0 && pDoc->m_rpBuffer [0] != NULL) ;

	if (pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer) 
		return	TRUE ;

	/*	�����V�t�g�ł͂Ȃ��A���� newline �ɂ�鋭�� update �������Ă��Ȃ��ꍇ�ɂ�
	 *	�������Ȃ��Bcontinue ���ǂ����͏󋵂ɂ��B
	 */
	if (! ImeConfig_bSkkCompositionAutoShiftp () && (pDoc->m_dwUpdateFlag & IMEDOC_NEWLINE) == 0) 
		return	TRUE ;
	return	ImeBuffer_bUpdateContext (pDoc->m_rpBuffer [0]) ;
}

void
ImeDoc_vUpdateConfig (
	struct CImeDoc*		pDoc)
{
	/*	Configuration �� Update �������̂ŁA������Ԃɖ߂��BRuleTree �����ǂ��Ă���r���� 
	 *	RuleTree ���X�V���ꂽ�肷��Ɨ����邵���Ȃ����B
	 */
//	imeDoc_vUninitConfig (pDoc) ;
	ImeDoc_vClear (pDoc) ;
	return ;
}

BOOL
ImeDoc_bRevertText (
	struct CImeDoc*		pDoc) 
{
	int		nConversionMode ;

	/*	�e�L�X�g��S�L�����Z���B���̏ꍇ�͑S buffer �� clear ����
	 *	stack �����������āAmessage-loop �� pointer ��߂��΂����̂��B
	 */
	nConversionMode	= ImeBuffer_iGetConversionMode (pDoc->m_rpBuffer [0]) ;
	ImeDoc_vClear (pDoc) ;
	/*	Clear ��Ԃ���� SetConversionMode �͗e�ՁB
	 */
	ImeBuffer_bSetConversionMode (pDoc->m_rpBuffer [0], nConversionMode) ;
	return	TRUE ;
}

BOOL
ImeDoc_bCompleteText (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMSG			msg ;
	int					nLoop, nConversionMode ;

	/*	�e�L�X�g��S�m��B(������ top �ȊO�� cancel ��)
	 *	safety �̂��߂ɍő僋�[�v�񐔂�ݒ肵�Ă����B
	 */
	for (nLoop = NLOOP_IMEDOC ; nLoop > 0 ; nLoop --) {
		pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
		if (ImeBuffer_bInputByCodeOrMenuModep (pBuffer) ||
			ImeBuffer_bShowHenkanCandidatesModep (pBuffer)) {
			/*	�L�����Z���̃L�[��p�ӁB
			 *	�{���� keyboard-quit �� abort-recursive-edit �����蓖�Ă��Ă���
			 *	key �Ȃ�� cancel �Ƃ��ē��삷��Ƃ����R�[�h�ɂ��Ȃ���΂Ȃ�Ȃ�
			 *	 > input-by-code-or-menu �� henkan-show-candidates
			 */
			msg.m_nMessage	= WM_CHAR ;
			msg.m_wParam	= 0x07 ;			/*,.. */
			msg.m_lParam	= 0 ;
			msg.m_rParam	= 0 ;
			msg.m_nTime		= GetTickCount () ;
			msg.m_pt.x		= msg.m_pt.y	= 0 ;
		} else {
			if (! ImeDoc_bRecursiveEditp (pDoc))
				break ;

			if (! ImeDoc_bWhereIsInternal (pDoc, NFUNC_ABORT_RECURSIVE_EDIT, &msg)) {
				/* �d���Ȃ��̂ŁA�����O���R�}���h�𔭍s����B*/
				msg.m_nMessage	= WM_LM_COMMAND ;
				msg.m_nTime		= GetTickCount () ;
				msg.m_wParam	= NFUNC_ABORT_RECURSIVE_EDIT ;
				msg.m_lParam	= 0 ;
				msg.m_rParam	= 0 ;
				msg.m_pt.x		= msg.m_pt.y	= 0 ;
			}
		} 
		if (! ImeDoc_bPushEvent (pDoc, &msg) || 
			! imeDoc_bTick (pDoc)) {
			/*	����̓N���e�B�J���ȁc�󋵂Ȃ̂ŁA�������������B
			 */
			ImeDoc_vClear (pDoc) ;
			goto	exit_func ;
		}
	}
	if (ImeBuffer_bInputByCodeOrMenuModep (pBuffer) ||
		ImeBuffer_bShowHenkanCandidatesModep (pBuffer) ||
		ImeDoc_bRecursiveEditp (pDoc) ||
		pDoc->m_pPC != LM_iMessageLoop) {
		ImeDoc_vClear (pDoc) ;
		goto	exit_func ;
	}
	/*	���̒i�K�� topbuffer �ɓ��B���Ă��锤�B
	 *	�m�肵�Ă���A���̓��[�h�̒�������킹��B
	 */
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	nConversionMode		= ImeBuffer_iGetConversionMode (pBuffer) ;
	if (! ImeDoc_bWhereIsInternal (pDoc, NFUNC_SKK_KAKUTEI, &msg)) {
		msg.m_nMessage	= WM_LM_COMMAND ;
		msg.m_nTime		= GetTickCount () ;
		msg.m_wParam	= NFUNC_SKK_KAKUTEI ;
		msg.m_lParam	= 0 ;
		msg.m_rParam	= 0 ;
		msg.m_pt.x		= msg.m_pt.y	= 0 ;
	}
	if (! ImeDoc_bPushEvent (pDoc, &msg) || 
		! imeDoc_bTick (pDoc)) {
		ImeDoc_vClear (pDoc) ;
		goto	exit_func ;
	}
	ImeBuffer_bSetConversionMode (pBuffer, nConversionMode) ;

	/*	���̏�Ԃ� buffer-string �𓾂āA���ꂩ�� clear ����Ηǂ��B
	 */
exit_func:
	return	TRUE ;
}

void
ImeDoc_vSetUpdateFlag (
	struct CImeDoc*		pDoc,
	unsigned int		uFlag)
{
	if ((uFlag & IMEDOC_CLOSE_CANDIDATELIST) != 0 && (uFlag & IMEDOC_CREATE_CANDIDATELIST) != 0) {
		/* �쐬�Ɣj���͓����ɂ͂ł��Ȃ��B*/
		uFlag	&= ~IMEDOC_CREATE_CANDIDATELIST ;
	}
	if ((uFlag & IMEDOC_CLOSE_CANDIDATELIST) != 0) {
		/*	�ŏI�I�� CANDIDATELIST ���j�������̂Ȃ�A�r���� CREATE �͈Ӗ����Ȃ��Ȃ��B
		 */
		pDoc->m_dwUpdateFlag	&= ~(IMEDOC_CREATE_CANDIDATELIST | IMEDOC_UPDATE_CANDIDATELIST) ;
	}

	/*	����ɂ�� CREATE_CANDIDATELIST �� CLOSE_CANDIDATELIST �������ɑ��݂���̂�
	 *	CLOSE -> CREATE �̏��ԂŎ��s���ꂽ�������ł���B
	 */
	pDoc->m_dwUpdateFlag	|= uFlag ;
	return ;
}

void
ImeDoc_vClearUpdateFlag (
	struct CImeDoc*		pDoc)
{
	pDoc->m_dwUpdateFlag	= 0 ;
	return ;
}

unsigned int
ImeDoc_uGetUpdateFlag (
	struct CImeDoc*		pDoc)
{
	return	pDoc->m_dwUpdateFlag ;
}

BOOL
ImeDoc_bShowHenkanCandidatesModep (
	const struct CImeDoc*		pDoc)
{
	if (pDoc == NULL || pDoc->m_pCurBuffer == NULL)
		return	FALSE ;
	return	ImeBuffer_bShowHenkanCandidatesModep (pDoc->m_pCurBuffer) ;
}

BOOL
ImeDoc_bInputByCodeOrMenuModep (
	const struct CImeDoc*		pDoc,
	BOOL*						pbMenu1p)
{
	if (pDoc == NULL || pDoc->m_pCurBuffer == NULL)
		return	FALSE ;
	if (! ImeBuffer_bInputByCodeOrMenuModep (pDoc->m_pCurBuffer))
		return	FALSE ;
	if (pbMenu1p != NULL) {
		/* MenuJump or Menu1Jump */
		*pbMenu1p	= ImeBuffer_bInputByCodeOrMenu1Modep (pDoc->m_pCurBuffer) ;
	}
	return	TRUE ;
}

BOOL
ImeDoc_bHaveMessagep (
	const struct CImeDoc*	pDoc)
{
	return	pDoc->m_nbufMessage > 0 ;
}

LPCDSTR
ImeDoc_pGetMessage (
	const struct CImeDoc*	pDoc,
	int*					piLength)
{
	if (piLength != NULL)
		*piLength	= pDoc->m_nbufMessage ;
	return	pDoc->m_bufMessage ;
}

/*========================================================================
 *	public functions (ImeDoc internal)
 */
BOOL
ImeDoc_bSkkPreviousCandidateCharp	(
	struct CImeDoc*			pDoc,
	int						nCH)
{
	struct TMSG		msg ;
	int				nFunc ;

	msg.m_nMessage	= WM_CHAR ;
	msg.m_wParam	= nCH ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= 0 ;
	msg.m_pt.y		= 0 ;

	if (ImeDoc_bLookupKeymap (pDoc, &msg, &nFunc))
		return	(nFunc == NFUNC_SKK_PREVIOUS_CANDIDATE) ;

	return	FALSE ;
}

/*========================================================================
 *	public functions (ImeDoc internal)
 */
void
ImeDoc_vSetCurrentBuffer (
	struct CImeDoc*			pDoc,
	struct CImeBuffer*		pBuffer)
{
	pDoc->m_pCurBuffer	= pBuffer ;
	return ;
}

struct CImeBuffer*
ImeDoc_pGetCurrentBuffer (
	struct CImeDoc*			pDoc)
{
	return	pDoc->m_pCurBuffer ;
}

BOOL
ImeDoc_bSetMessage (
	struct CImeDoc*			pDoc, 
	LPCDSTR					wstrMessage)
{
	if (wstrMessage == NULL)
		return	FALSE ;
	return	ImeDoc_bSetMessageN (pDoc, wstrMessage, dcslen (wstrMessage)) ;
}

BOOL
ImeDoc_bSetMessageW (
	struct CImeDoc*			pDoc, 
	LPCWSTR					wstrMessage)
{
	if (wstrMessage == NULL)
		return	FALSE ;
	return	ImeDoc_bSetMessageNW (pDoc, wstrMessage, lstrlenW (wstrMessage)) ;
}

BOOL
ImeDoc_bSetMessageN (
	struct CImeDoc*			pDoc, 
	LPCDSTR					wstrMessage,
	int						nstrMessage)
{
	ASSERT (wstrMessage != NULL || nstrMessage == 0) ;

	pDoc->m_nbufMessage	= (nstrMessage > MSGBUFSIZE)? MSGBUFSIZE : nstrMessage ;
	if (wstrMessage != NULL) {
		dcsncpy (pDoc->m_bufMessage, wstrMessage, pDoc->m_nbufMessage) ;
	}
	return	TRUE ;
}

BOOL
ImeDoc_bSetMessageNW (
	struct CImeDoc*			pDoc, 
	LPCWSTR					wstrMessage,
	int						nstrMessage)
{
	if (wstrMessage != NULL) {
		pDoc->m_nbufMessage = wcstodcs (pDoc->m_bufMessage, MSGBUFSIZE, wstrMessage, nstrMessage) ;
	} else {
		pDoc->m_nbufMessage	= 0 ;
	}
	return	TRUE ;
}

void
ImeDoc_vClearMessage (struct CImeDoc* pDoc)
{
	pDoc->m_nbufMessage		= 0 ;
	return ;
}

BOOL
ImeDoc_bGetLastCommandChar (
	struct CImeDoc*				pDoc,
	DCHAR*						pwCH)
{
	int		iCH ;

	/* printable �łȂ��ꍇ�ɂ� false ��Ԃ��B*/
	iCH	= ImeDoc_iGetCharFromEvent (&pDoc->m_LastEvent) ;
	if (! (0x20 <= iCH && iCH < 0x7F)) {
		if (! ImeConfig_bSkkSpecialMidashiCharp		(iCH) && 
			! ImeConfig_bSkkSetHenkanPointKeyp		(iCH) &&
			! ImeConfig_bSkkStartHenkanCharp		(iCH) &&
			! ImeConfig_bSkkTryCompletionCharp		(iCH) &&
			! ImeConfig_bSkkNextCompletionCharp		(iCH) &&
			! ImeConfig_bSkkPreviousCompletionCharp	(iCH)) {
			return	FALSE ;
		}
	}
	if (pwCH != NULL)
		*pwCH	= iCH ;
	return	TRUE ;
}

BOOL
ImeDoc_bUnprocessEvent (
	struct CImeDoc*				pDoc,
	const struct TMSG*			pMsg)
{
	if (pDoc == NULL)
		return	FALSE ;
	if (pMsg != NULL) {
		pDoc->m_UnprocessEvent	= *pMsg ;
	} else {
		pDoc->m_UnprocessEvent.m_nMessage	= WM_NULL ;
	}
	return	TRUE ;
}

BOOL
ImeDoc_bPushEvent (
	struct CImeDoc*			pDoc,
	const struct TMSG*		pMSG)
{
	if (pDoc == NULL || pMSG == NULL)
		return	FALSE ;
	if (pDoc->m_nUnreadMessages >= ARRAYSIZE (pDoc->m_rMessages)) {
		return	FALSE ;
	}
	pDoc->m_rMessages [pDoc->m_nUnreadMessages ++]	= *pMSG ;
	return	TRUE ;
}

int
ImeDoc_nGetSignal (
	const struct CImeDoc*		pDoc)
{
	return	pDoc->m_nSignal ;
}

void
ImeDoc_vSetSignal (
	struct CImeDoc*				pDoc,
	int							nSignal)
{
	pDoc->m_nSignal	= nSignal ;
	return ;
}

BOOL
ImeDoc_bSignalp (
	const struct CImeDoc*		pDoc)
{
	return	(pDoc->m_nSignal != LMSIGNAL_NONE) ;
}

void
ImeDoc_vSetSignalError (
	struct CImeDoc*			pDoc)
{
	pDoc->m_nSignal	= LMSIGNAL_ERROR ;
	return ;
}

BOOL
ImeDoc_bSignalMinibuffp (
	const struct CImeDoc*	pDoc)
{
	/* minibuffer �𔲂��� signal �������Ă���Ύ�芸���� TRUE ��Ԃ��B*/
	return	(pDoc->m_nSignal == LMSIGNAL_EXIT_MINIBUFFER || pDoc->m_nSignal == LMSIGNAL_ABORT_RECURSIVE_EDIT) ;
}

BOOL
ImeDoc_bSignalAbortMinibuffp (
	const struct CImeDoc*	pDoc)
{
	return	(pDoc->m_nSignal == LMSIGNAL_ABORT_RECURSIVE_EDIT) ;
}

void
ImeDoc_vClearSignals (
	struct CImeDoc*			pDoc)
{
	pDoc->m_nSignal			= LMSIGNAL_NONE ;
	return ;
}

void
ImeDoc_vJump (
	struct CImeDoc*			pDoc,
	PLMFUNC					pNextState)
{
	pDoc->m_pPC					= pNextState ;
	return ;
}

BOOL
ImeDoc_bCall (
	struct CImeDoc*			pDoc,
	PLMFUNC					pNextState,
	PLMFUNC					pReturnState)
{
	int		nPos ;

	if (pDoc->m_nRetPC >= ARRAYSIZE (pDoc->m_rpRetPC))
		return	FALSE ;
	nPos						= pDoc->m_nRetPC ++ ;
	pDoc->m_rpRetPC    [nPos]	= pReturnState ;
	pDoc->m_rnStackPos [nPos]	= pDoc->m_nStackHead ;
	pDoc->m_pPC					= pNextState ;
	return	TRUE ;
}

void*
ImeDoc_pAlloca (
	struct CImeDoc*			pDoc,
	int						nSize,
	int						nAlign) 
{
	LPBYTE		pbAddress ;
	LPBYTE		pbNextAddress ;
	void*		pvRetval ;
	int			nSkip ;

	if (pDoc == NULL || nSize <= 0 || nAlign <= 0)
		return	NULL ;

	pbAddress			= pDoc->m_pbStackArea + pDoc->m_nStackHead ;
#pragma warning (push)
#pragma warning (disable : 4311)
	/*	BYTE* ���� DWORD �ɐ؂�l�߂Ă���̂́A������������Ɏv�����Ȃ��̂Łc�B
	 */
	nSkip				= nAlign - ((DWORD) pbAddress & (nAlign - 1)) ;
#pragma warning (pop)
	pvRetval			= pbAddress + nSkip ;
	pbNextAddress		= pbAddress + nSkip + nSize ;
	if (pbNextAddress > (pDoc->m_pbStackArea + pDoc->m_nStackAreaSize)) 
		return	NULL ;
	pDoc->m_nStackHead	+= nSkip + nSize ;
	return	pvRetval ;
}

void
ImeDoc_vSetRegBool (
	struct CImeDoc*			pDoc,
	int						nReg,
	BOOL					bValue)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	pDoc->m_rREGS [nReg].m_nType		= LMREGTYPE_BOOL ;
	pDoc->m_rREGS [nReg].m_value.m_bool	= bValue ;
	return ;
}

void
ImeDoc_vSetRegString (
	struct CImeDoc*			pDoc,
	int						nReg,
	LPDSTR					pwString,
	int						nStringLen)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	pDoc->m_rREGS [nReg].m_nType	= LMREGTYPE_STRING ;
	pDoc->m_rREGS [nReg].m_value.m_string.m_pointer	= pwString ;
	pDoc->m_rREGS [nReg].m_value.m_string.m_length	= nStringLen ;
	return ;
}


void
ImeDoc_vSetRegConstString (
	struct CImeDoc*			pDoc,
	int						nReg,
	LPCDSTR					pwString,
	int						nStringLen)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	pDoc->m_rREGS [nReg].m_nType	= LMREGTYPE_CONST_STRING ;
	pDoc->m_rREGS [nReg].m_value.m_cstring.m_pointer	= pwString ;
	pDoc->m_rREGS [nReg].m_value.m_cstring.m_length		= nStringLen ;
	return ;
}

void
ImeDoc_vSetRegInteger (
	struct CImeDoc*			pDoc,
	int						nReg,
	int						nValue)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	pDoc->m_rREGS [nReg].m_nType	= LMREGTYPE_INTEGER ;
	pDoc->m_rREGS [nReg].m_value.m_integer	= nValue ;
	return ;
}

void
ImeDoc_vSetRegPointer (
	struct CImeDoc*			pDoc,
	int						nReg,
	void*					pvValue)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	pDoc->m_rREGS [nReg].m_nType	= LMREGTYPE_POINTER ;
	pDoc->m_rREGS [nReg].m_value.m_pointer	= pvValue ;
	return ;
}

void
ImeDoc_vSetRegConstPointer (
	struct CImeDoc*			pDoc,
	int						nReg,
	const void*				pvValue)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	pDoc->m_rREGS [nReg].m_nType	= LMREGTYPE_CONST_POINTER ;
	pDoc->m_rREGS [nReg].m_value.m_const_pointer	= pvValue ;
	return ;
}

void
ImeDoc_vSetRegMsg (
	struct CImeDoc*			pDoc,
	int						nReg,
	const struct TMSG*		pMsg)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (pMsg == NULL)
		return ;
	pDoc->m_rREGS [nReg].m_nType		= LMREGTYPE_MESSAGE ;
	pDoc->m_rREGS [nReg].m_value.m_msg	= *pMsg ;
	return ;
}

void
ImeDoc_vSetRegNil (
	struct CImeDoc*			pDoc,
	int						nReg)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	pDoc->m_rREGS [nReg].m_nType		= LMREGTYPE_NIL ;
	return ;
}

struct LMREG*
ImeDoc_pGetRegValue (
	struct CImeDoc*			pDoc,
	int						nReg)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	return	pDoc->m_rREGS + nReg ;
}

BOOL
ImeDoc_bGetRegBool (
	struct CImeDoc*			pDoc,
	int						nReg,
	BOOL*					pfRetval)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_BOOL) {
		if (pfRetval != NULL)
			*pfRetval	= pDoc->m_rREGS [nReg].m_value.m_bool ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
ImeDoc_bGetRegInteger (
	struct CImeDoc*			pDoc,
	int						nReg,
	int*					piRetval)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_INTEGER) {
		if (piRetval != NULL)
			*piRetval	= pDoc->m_rREGS [nReg].m_value.m_integer ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
ImeDoc_bGetRegString (
	struct CImeDoc*			pDoc,
	int						nReg,
	LPDSTR*					ppwString,
	int*					pnStringLen)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_STRING) {
		if (ppwString != NULL)
			*ppwString	= pDoc->m_rREGS [nReg].m_value.m_string.m_pointer ;
		if (pnStringLen != NULL)
			*pnStringLen	= pDoc->m_rREGS [nReg].m_value.m_string.m_length ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
ImeDoc_bGetRegConstString (
	struct CImeDoc*			pDoc,
	int						nReg,
	LPCDSTR*				ppwString,
	int*					pnStringLen)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_CONST_STRING) {
		if (ppwString != NULL)
			*ppwString	= pDoc->m_rREGS [nReg].m_value.m_cstring.m_pointer ;
		if (pnStringLen != NULL)
			*pnStringLen	= pDoc->m_rREGS [nReg].m_value.m_cstring.m_length ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
ImeDoc_bGetRegConstStringPair (
	struct CImeDoc*			pDoc,
	int						nReg,
	LPCDSTR*				ppwLeft,
	int*					pnLeftLen,
	LPCDSTR*				ppwRight,
	int*					pnRightLen)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (pDoc->m_rREGS [nReg].m_nType != LMREGTYPE_CONST_STRINGPAIR) 
		return	FALSE ;
	if (ppwLeft != NULL)
		*ppwLeft	= pDoc->m_rREGS [nReg].m_value.m_cstringpair.m_left ;
	if (pnLeftLen != NULL)
		*pnLeftLen	= pDoc->m_rREGS [nReg].m_value.m_cstringpair.m_nleft ;
	if (ppwRight != NULL)
		*ppwRight	= pDoc->m_rREGS [nReg].m_value.m_cstringpair.m_right ;
	if (pnRightLen != NULL)
		*pnRightLen	= pDoc->m_rREGS [nReg].m_value.m_cstringpair.m_nright ;
	return	TRUE ;
}

BOOL
ImeDoc_bGetRegPointer (
	struct CImeDoc*			pDoc,
	int						nReg,
	void**					ppvRetval)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_POINTER) {
		if (ppvRetval != NULL)
			*ppvRetval	= pDoc->m_rREGS [nReg].m_value.m_pointer ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
ImeDoc_bGetRegConstPointer (
	struct CImeDoc*			pDoc,
	int						nReg,
	const void**			ppvRetval)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_CONST_POINTER) {
		if (ppvRetval != NULL)
			*ppvRetval	= pDoc->m_rREGS [nReg].m_value.m_const_pointer ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
ImeDoc_bGetRegMsg (
	struct CImeDoc*			pDoc,
	int						nReg,
	struct TMSG*			pMsg)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_MESSAGE) {
		if (pMsg != NULL)
			*pMsg	= pDoc->m_rREGS [nReg].m_value.m_msg ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
ImeDoc_bIsRegNilp (
	const struct CImeDoc*	pDoc,
	int						nReg)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	return	(pDoc->m_rREGS [nReg].m_nType == LMREGTYPE_NIL) ;
}

BOOL
ImeDoc_bPushReg (
	struct CImeDoc*			pDoc,
	int						nReg)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (pDoc->m_nRegStackHead >= NSIZE_REGSTACK)
		return	FALSE ;
	pDoc->m_pRegStack [pDoc->m_nRegStackHead ++]	= pDoc->m_rREGS [nReg] ;
	return	TRUE ;
}

void
ImeDoc_vPopReg (
	struct CImeDoc*			pDoc,
	int						nReg)
{
	ASSERT (pDoc != NULL) ;
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	ASSERT (pDoc->m_nRegStackHead > 0) ;

	pDoc->m_rREGS [nReg]	= pDoc->m_pRegStack [-- pDoc->m_nRegStackHead] ;
	return ;
}

LPDSTR
ImeDoc_pGetReturnBuffer (
	struct CImeDoc*			pDoc,
	int*					pnRetbufSize)
{
	if (pDoc == NULL)
		return	NULL ;
	if (pnRetbufSize != NULL)
		*pnRetbufSize	= ARRAYSIZE (pDoc->m_bufRETURN) ;
	return	pDoc->m_bufRETURN ;
}

int
ImeDoc_iGetMinibufferDepth	(
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct CImeBuffer*	pParent ;
	int		iDepth ;

	if (pDoc == NULL)
		return	0 ;
	pBuffer	= pDoc->m_pCurBuffer ;
	if (pBuffer == NULL)
		return	0 ;
	iDepth	= 0 ;
	while (pParent = ImeBuffer_pGetParent (pBuffer), pParent != NULL) {
		pBuffer	= pParent ;
		iDepth	++ ;
	}
	return	iDepth ;
}


/*========================================================================
 *	Internal public functions (cont.)
 *
 *	InputContext interface �͔p�~�B
 */
TVarbuffer*
ImeDoc_pGetCandidateInfoBuffer (
	struct CImeDoc*			pDoc)
{
	return	&pDoc->m_vbufCandInfo ;
}

TVarbuffer*
ImeDoc_pGetMessageInfoBuffer (
	struct CImeDoc*			pDoc)
{
	return	&pDoc->m_vbufMessage ;
}

/*========================================================================
 *		state machine mainloop
 */
/*
 */
BOOL
imeDoc_bTick (
	struct CImeDoc*			pDoc)
{
	int		nRetval ;

	while (pDoc->m_pPC != NULL) {
		nRetval		= (pDoc->m_pPC)(pDoc) ;
		switch (nRetval) {
		case	LMR_STOP:
			goto	exit_loop ;
		case	LMR_RETURN:
			if (pDoc->m_nRetPC <= 0) {
				/* fatal error */
				return	FALSE ;
			}
			-- pDoc->m_nRetPC ;
			pDoc->m_nStackHead	= pDoc->m_rnStackPos	[pDoc->m_nRetPC] ;
			pDoc->m_pPC			= pDoc->m_rpRetPC		[pDoc->m_nRetPC] ;
			break ;
		case	LMR_ERROR:
			/* fatal error */
			return	FALSE ;
		case	LMR_CONTINUE:
		default:
			break ;
		}
	}
exit_loop:
	return	TRUE ;
}

/*========================================================================
 *	
 */
int
ImeDoc_iGetLastCommand (
	const struct CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	return	pDoc->m_iLastCommand ; 
}

int
ImeDoc_iGetThisCommand (
	const struct CImeDoc*		pDoc)
{
	ASSERT (pDoc != NULL) ;
	return	pDoc->m_iThisCommand ;
}

BOOL
ImeDoc_bSetThisCommand (
	struct CImeDoc*				pDoc, 
	int							nFuncNo)
{
	ASSERT (pDoc != NULL) ;
	pDoc->m_iThisCommand	= nFuncNo ;
	return	TRUE ;
}

BOOL
ImeDoc_bSetLastCommand (
	struct CImeDoc*				pDoc, 
	int							nFuncNo)
{
	ASSERT (pDoc != NULL) ;
	pDoc->m_iLastCommand	= nFuncNo ;
	return	TRUE ;
}

int
ImeDoc_iGetLastCommandChar (
	struct CImeDoc*				pDoc)
{
	return	pDoc->m_iLastCommandChar ;
}

BOOL
ImeDoc_bSetLastCommandChar (
	struct CImeDoc*				pDoc,
	int							nCH)
{
	pDoc->m_iLastCommandChar		= nCH ;

	/* last-command-event �𓯊�������c����ŗǂ��̂��H */
	pDoc->m_LastEvent.m_nMessage	= WM_CHAR ;
	pDoc->m_LastEvent.m_wParam		= nCH ;
	pDoc->m_LastEvent.m_lParam		= 0 ;
	pDoc->m_LastEvent.m_rParam		= 0 ;
	pDoc->m_LastEvent.m_nTime		= GetTickCount () ;
	pDoc->m_LastEvent.m_pt.x		= 0 ;
	pDoc->m_LastEvent.m_pt.y		= 0 ;
	return	TRUE ;
}

const struct TMSG*
ImeDoc_pGetLastCommandEvent (
	const struct CImeDoc*		pDoc)
{
	return	&pDoc->m_LastEvent ;
}

BOOL
ImeDoc_bSetUnreadCommandEvent (
	struct CImeDoc*				pDoc, 
	const struct TMSG*			pMsg)
{
	if (pMsg == NULL || pDoc == NULL)
		return	FALSE ;
	return	ImeDoc_bPushEvent (pDoc, pMsg) ;
}

BOOL
ImeDoc_bSetUnreadCommandChar (
	struct CImeDoc*				pDoc, 
	int							ch)
{
	struct TMSG		msg ;

	msg.m_nMessage	= WM_CHAR ;
	msg.m_wParam	= ch ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= 0 ;
	msg.m_pt.y		= 0 ;
	return	ImeDoc_bPushEvent (pDoc, &msg) ;
}

BOOL
ImeDoc_bLookupKeymap (
	struct CImeDoc*				pDoc, 
	const struct TMSG*			pEvent,
	int*						pnFuncNo)
{
	struct CImeBuffer*	pCurBuffer ;
	int		nFuncNo ;

	ASSERT (pDoc != NULL) ;
	ASSERT (pEvent != NULL) ;

	/*	�@�\�𒼐ڎw�肳��Ă��܂����ꍇ�ɂ́c
	 */
	if (pEvent->m_nMessage == WM_LM_COMMAND) {
		*pnFuncNo	= (int) pEvent->m_wParam ;
		return	TRUE ;
	}

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL || pnFuncNo == NULL)
		return	FALSE ;

	nFuncNo		= NFUNC_INVALID_CHAR ;
	/* minor-mode �� keymap �� check */
	if (nFuncNo == NFUNC_INVALID_CHAR && (ImeBuffer_bJModep (pCurBuffer) || ImeBuffer_bJisx0201Modep (pCurBuffer))) 
		imeDoc_bLookupKeymap (ImeConfig_pGetSkkJModeMap (), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && ImeBuffer_bLatinModep (pCurBuffer)) 
		imeDoc_bLookupKeymap (ImeConfig_pGetSkkLatinModeMap (), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && ImeBuffer_bJisx0208LatinModep (pCurBuffer)) 
		imeDoc_bLookupKeymap (ImeConfig_pGetSkkJisx0208LatinModeMap (), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && ImeBuffer_bAbbrevModep (pCurBuffer)) 
		imeDoc_bLookupKeymap (ImeConfig_pGetSkkAbbrevModeMap (), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && ImeDoc_bRecursiveEditp (pDoc)) 
		imeDoc_bLookupKeymap (ImeConfig_pGetMinibufferMinorModeMap (), pEvent, &nFuncNo) ;
	/* major-mode �� keymap �� check */
	if (nFuncNo == NFUNC_INVALID_CHAR) 
		imeDoc_bLookupKeymap (ImeConfig_pGetMajorModeMap (), pEvent, &nFuncNo) ;
	*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

BOOL
ImeDoc_bWhereIsInternal (
	struct CImeDoc*				pDoc, 
	int							nFuncNo,
	struct TMSG*				pEvent)
{
	struct CImeBuffer*	pCurBuffer ;

	if (pDoc == NULL || pDoc->m_pCurBuffer == NULL)
		return	FALSE ;
	pCurBuffer	= pDoc->m_pCurBuffer ;
	if ((ImeBuffer_bJModep (pCurBuffer) || ImeBuffer_bJisx0201Modep (pCurBuffer)) &&
		imeDoc_bWhereIsInternal (ImeConfig_pGetSkkJModeMap (), nFuncNo, pEvent))
		return	TRUE ;
	if (ImeBuffer_bLatinModep (pCurBuffer) &&
		imeDoc_bWhereIsInternal (ImeConfig_pGetSkkLatinModeMap (), nFuncNo, pEvent))
		return	TRUE ;
	if (ImeBuffer_bJisx0208LatinModep (pCurBuffer) &&
		imeDoc_bWhereIsInternal (ImeConfig_pGetSkkJisx0208LatinModeMap (), nFuncNo, pEvent))
		return	TRUE ;
	if (ImeBuffer_bAbbrevModep (pCurBuffer) &&
		imeDoc_bWhereIsInternal (ImeConfig_pGetSkkAbbrevModeMap (), nFuncNo, pEvent))
		return	TRUE ;
	if (ImeDoc_bRecursiveEditp (pDoc) &&
		imeDoc_bWhereIsInternal (ImeConfig_pGetMinibufferMinorModeMap (), nFuncNo, pEvent))
		return	TRUE ;
	if (imeDoc_bWhereIsInternal (ImeConfig_pGetMajorModeMap (), nFuncNo, pEvent))
		return	TRUE ;
	return	FALSE ;
}

BOOL
ImeDoc_bLookupMajorKeymap (
	struct CImeDoc*				pDoc, 
	const struct TMSG*			pEvent,
	int*						pnFuncNo)
{
	struct CImeBuffer*	pCurBuffer ;
	int	nFuncNo ;

	/*	�@�\�𒼐ڎw�肳��Ă��܂����ꍇ�ɂ́c
	 */
	if (pEvent->m_nMessage == WM_LM_COMMAND) {
		*pnFuncNo	= (int) pEvent->m_wParam ;
		return	TRUE ;
	}

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL || pnFuncNo == NULL)
		return	FALSE ;

	if (! imeDoc_bLookupKeymap (ImeConfig_pGetMajorModeMap (), pEvent, &nFuncNo)) {
		*pnFuncNo	= NFUNC_INVALID_CHAR ;
		return	TRUE ;
	}
	*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

PLMFUNC
ImeDoc_pLookupLMState (
	struct CImeDoc*			pDoc,
	int						nFuncNo)
{
	PLMFUNC	pPC	= NULL ;

	switch (nFuncNo) {
	case	NFUNC_SELF_INSERT_CHARACTER:
		pPC	= &LM_bSelfInsertCharacter ;
		break ;
	case	NFUNC_BACKWARD_CHAR:
		pPC	= &LM_bBackwardChar ;
		break ;
	case	NFUNC_FORWARD_CHAR:
		pPC	= &LM_bForwardChar ;
		break ;
	case	NFUNC_DELETE_CHAR:
		pPC	= &LM_bDeleteChar ;
		break ;
	case	NFUNC_BACKWARD_DELETE_CHAR:
		pPC	= &LM_bBackwardDeleteChar ;
		break ;
	case	NFUNC_TRANSPOSE_CHARS:
		pPC	= &LM_bTransposeChars ;
		break ;
	case	NFUNC_END_OF_LINE:
		pPC	= &LM_bEndOfLine ;
		break ;
	case	NFUNC_BEGINNING_OF_LINE:
		pPC	= &LM_bBeginningOfLine ;
		break ;
	case	NFUNC_SET_MARK_COMMAND:
		pPC	= &LM_bSetMarkCommand ;
		break ;
	case	NFUNC_KEYBOARD_QUIT:
		pPC	= &LM_bKeyboardQuit ;
		break ;
	case	NFUNC_SKK_INSERT:
//		pPC	= &LM_bSkkInsert ;
		pPC	= &LM_bSkkInsertAdJisx0201 ;
		break ;
	case	NFUNC_SKK_PREVIOUS_CANDIDATE:
		pPC	= &LM_bSkkPreviousCandidate ;
		break ;
	case	NFUNC_EXIT_RECURSIVE_EDIT:
		pPC	= &LM_bExitRecursiveEdit ;
		break ;
	case	NFUNC_ABORT_RECURSIVE_EDIT:
		pPC	= &LM_bAbortRecursiveEdit ;
		break ;
	case	NFUNC_SKK_MODE:
//		pPC	= &LM_bSkkMode ;
		pPC	= &LM_bSkkModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_KAKUTEI:
//		pPC	= &LM_bSkkKakutei ;
		pPC	= &LM_bSkkKakuteiAdJisx0201 ;
		break ;
	case	NFUNC_SKK_START_HENKAN:
		pPC	= &LM_bSkkStartHenkan ;
		break ;
	case	NFUNC_SKK_SET_HENKAN_POINT_SUBR:
		pPC	= &LM_bSkkSetHenkanPointSubr ;
		break ;
	case	NFUNC_SKK_LATIN_MODE:
//		pPC	= &LM_bSkkLatinMode ;
		pPC	= &LM_bSkkLatinModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_JISX0208_LATIN_MODE:
//		pPC	= &LM_bSkkJisx0208LatinMode ;
		pPC	= &LM_bSkkJisx0208LatinModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_ABBREV_MODE:
//		pPC	= &LM_bSkkAbbrevMode ;
		pPC	= &LM_bSkkAbbrevModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_DELETE_BACKWARD_CHAR:
		pPC	= &LM_bSkkDeleteBackwardChar ;
		break ;
	case	NFUNC_NEWLINE:
		pPC	= &LM_bNewline ;
		break ;
	case	NFUNC_SKK_INPUT_BY_CODE_OR_MENU:
		pPC	= &LM_bSkkInputByCodeOrMenu ;
		break ;
	case	NFUNC_SKK_TRY_COMPLETION:
		pPC	= &LM_bSkkTryCompletion ;
		break ;
	case	NFUNC_SKK_ABBREV_COMMA:
		pPC	= &LM_bSkkAbbrevComma ;
		break ;
	case	NFUNC_SKK_ABBREV_PERIOD:
		pPC	= &LM_bSkkAbbrevPeriod ;
		break ;
	case	NFUNC_SKK_JISX0208_LATIN_INSERT:
		pPC	= &LM_bSkkJisx0208LatinInsert ;
		break ;
	case	NFUNC_SKK_TOGGLE_CHARACTERS:
		pPC	= &LM_bSkkToggleCharacters ;
		break ;
	case	NFUNC_SKK_TOGGLE_KUTOUTEN:
		pPC	= &LM_bSkkToggleKutouten ;
		break ;
	case	NFUNC_SKK_PURGE_FROM_JISYO:
		pPC	= &LM_bSkkPurgeFromJisyo ;
		break ;
	case	NFUNC_SKK_TODAY:
		pPC	= &LM_bSkkToday ;
		break ;
	case	NFUNC_SKK_TOGGLE_KATAKANA:
		pPC	= &LM_bSkkToggleKatakana ;
		break ;
	case	NFUNC_SKK_JISX0201_HENKAN:
		pPC	= &LM_bSkkJisx0201Henkan ;
		break ;
	case	NFUNC_SKK_JISX0201_MODE:
		pPC	= &LM_bSkkJisx0201Mode ;
		break ;
	case	NFUNC_SKK_TOGGLE_JISX0201:
		pPC	= &LM_bSkkToggleJisx0201 ;
		break ;

		/*----------------------------------------------------------------
		 *	������ interactive function �ł͂Ȃ��̂ŁA�Ăяo�����̈ʒu (message-loop���H)
		 *	�ɒ��ӂ��邱�ƁB
		 */
	case	NFUNC_SKK_CURRENT_KUTEN:
		pPC	= &LM_bSkkCurrentKuten ;
		break ;
	case	NFUNC_SKK_CURRENT_TOUTEN:
		pPC	= &LM_bSkkCurrentTouten ;
		break ;

		/*
		 *	�����܂�
		 *----------------------------------------------------------------
		 */
	case	NFUNC_KILL_REGION:
		pPC	= &LM_bKillRegion ;
		break ;
	case	NFUNC_KILL_RING_SAVE:
		pPC	= &LM_bKillRingSave ;
		break ;
	case	NFUNC_YANK:
		pPC	= &LM_bYank ;
		break ;
	case	NFUNC_BACKWARD_WORD:
		pPC	= &LM_bBackwardWord ;
		break ;
	case	NFUNC_FORWARD_WORD:
		pPC	= &LM_bForwardWord ;
		break ;

	case	NFUNC_MOUSE_DRAG_REGION:
		pPC	= &LM_bMouseDragRegion ;
		break ;
	case	NFUNC_MOUSE_DRAG_REGION_END:
		pPC	= &LM_bMouseDragRegionEnd ;
		break ;
	case	NFUNC_MOUSE_PASTE:
		pPC	= &LM_bMousePaste ;
		break ;
	case	NFUNC_MOUSE_CUT:
		pPC	= &LM_bMouseCut ;
		break ;
	case	NFUNC_MOUSE_COPY:
		pPC	= &LM_bMouseCopy ;
		break ;
	case	NFUNC_MOUSE_DELETE:
		pPC	= &LM_bMouseDelete ;
		break ;

	default:
		/* default �̓���B*/
		pPC	= &LM_bUnprecessEvent ;
		break ;
	}
	return	pPC ;
}

BOOL
ImeDoc_bIgnoreMessagep (
	const struct TMSG*				pEvent)
{
	if (pEvent == NULL)
		return	TRUE ;

	switch (pEvent->m_nMessage) {
	case	WM_KEYDOWN:
		{
			int		nVkCode			= (int) pEvent->m_wParam ;

			if (nVkCode == VK_SHIFT || nVkCode == VK_CONTROL || nVkCode == VK_RSHIFT || nVkCode == VK_RCONTROL)
				return	TRUE ;
		}
		break ;
	case	WM_IME_KEYDOWN:
		{
			/*
			 *		wParam
			 *			��� 16 �r�b�g�ɉ����ꂽ�����̕����R�[�h���A
			 *			���� 16 �r�b�g�ɉ����ꂽ�L�[�̉��z�L�[�R�[�h�������Ă��܂��B
			 *		lParam
			 *			WM_KEYDOWN �ɗ^������ lParam �Ɠ����ł��B
			 *		lpbKeyState
			 *			���݂̃L�[�{�[�h�̏�Ԃ��܂�256�o�C�g�̔z��ւ̃|�C���^�ł��B
			 *			IME �͂��̓��e��ύX���Ă͂����܂���B
			 */
			int		nKeyCode		= HIWORD (pEvent->m_wParam) ;
			int		nVkCode			= LOWORD (pEvent->m_wParam) ;


			if (nVkCode == VK_SHIFT || nVkCode == VK_CONTROL || nVkCode == VK_RSHIFT || nVkCode == VK_RCONTROL)
				return	TRUE ;
		}
		break ;
	default:
		break ;
	}
	return	FALSE ;
}

/*	WPARAM ���� DCHAR ���쐬����BDCHAR �ɕϊ����邽�߂� WIN32API ��
 *	ToAscii �𗘗p���Ă���B
 *	ToAscii �ŕϊ��ł��Ȃ������ɑ΂��ẮA�ꕔ�� VK_XXX �������E����
 *	128 �ȏ�̃R�[�h�����蓖�Ă邱�ƂƂ��Ă���B
 */
int
ImeDoc_iGetCharFromEvent (
	const struct TMSG*				pEvent)
{
	static BYTE	byKeyState [256] = { 0 } ;
	int		iCH ;

	if (pEvent == NULL)
		return	-1 ;

	switch (pEvent->m_nMessage) {
	case	WM_KEYDOWN:
		if (pEvent->m_wParam < 0x100) {
			WORD					rwCH [2] ;

			byKeyState [VK_LCONTROL]	= (pEvent->m_rParam & KEYMASK_LCONTROL)?	0x80 : 0 ;
			byKeyState [VK_RCONTROL]	= (pEvent->m_rParam & KEYMASK_RCONTROL)?	0x80 : 0 ;
			byKeyState [VK_LSHIFT]		= (pEvent->m_rParam & KEYMASK_LSHIFT)?		0x80 : 0 ;
			byKeyState [VK_RSHIFT]		= (pEvent->m_rParam & KEYMASK_RSHIFT)?		0x80 : 0 ;
			byKeyState [VK_LMENU]		= (pEvent->m_rParam & KEYMASK_LMENU)?		0x80 : 0 ;
			byKeyState [VK_RMENU]		= (pEvent->m_rParam & KEYMASK_RMENU)?		0x80 : 0 ;
			byKeyState [VK_NUMLOCK]		= (pEvent->m_rParam & KEYMASK_NUMLOCK)?		0x80 : 0 ;
			byKeyState [VK_SCROLL]		= (pEvent->m_rParam & KEYMASK_SCROLL)?		0x80 : 0 ;
			byKeyState [VK_CONTROL]		= (pEvent->m_rParam & (KEYMASK_LCONTROL | KEYMASK_RCONTROL))?	0x80 : 0 ;
			byKeyState [VK_SHIFT]		= (pEvent->m_rParam & (KEYMASK_LSHIFT   | KEYMASK_RSHIFT))?		0x80 : 0 ;
			rwCH [0]	= 0 ;
		
			/*	�܂��͌��݂� keyboard �����āA�ϊ��ł��Ȃ������ǂ������`�F�b�N
			 *	����B
			 */
			if (ToAscii ((UINT)pEvent->m_wParam, 0x80000000, byKeyState, rwCH, 0) == 0) {
				rwCH [0]	= (DCHAR) -1 ;
			} else {
				/*	keyboard �����ĕϊ��ł����ꍇ�̏����B
				 */
				if (rwCH [0] == TEXT(' ') && (byKeyState [VK_CONTROL] & 0x80))
					rwCH [0]	= 0 ;
			}
			return	rwCH [0] ;
		} else {
			return	-1 ;
		}
		break ;
	case	WM_IME_KEYDOWN:
		{
			/*
			 *		wParam
			 *			��� 16 �r�b�g�ɉ����ꂽ�����̕����R�[�h���A
			 *			���� 16 �r�b�g�ɉ����ꂽ�L�[�̉��z�L�[�R�[�h�������Ă��܂��B
			 *		lParam
			 *			WM_KEYDOWN �ɗ^������ lParam �Ɠ����ł��B
			 *		lpbKeyState
			 *			���݂̃L�[�{�[�h�̏�Ԃ��܂�256�o�C�g�̔z��ւ̃|�C���^�ł��B
			 *			IME �͂��̓��e��ύX���Ă͂����܂���B
			 */
			int		nKeyCode		= HIWORD (pEvent->m_wParam) ;
			int		nVkCode			= LOWORD (pEvent->m_wParam) ;
			WORD		rwCH [2] ;

			byKeyState [VK_LCONTROL]	= (pEvent->m_rParam & KEYMASK_LCONTROL)?	0x80 : 0 ;
			byKeyState [VK_RCONTROL]	= (pEvent->m_rParam & KEYMASK_RCONTROL)?	0x80 : 0 ;
			byKeyState [VK_LSHIFT]		= (pEvent->m_rParam & KEYMASK_LSHIFT)?		0x80 : 0 ;
			byKeyState [VK_RSHIFT]		= (pEvent->m_rParam & KEYMASK_RSHIFT)?		0x80 : 0 ;
			byKeyState [VK_LMENU]		= (pEvent->m_rParam & KEYMASK_LMENU)?		0x80 : 0 ;
			byKeyState [VK_RMENU]		= (pEvent->m_rParam & KEYMASK_RMENU)?		0x80 : 0 ;
			byKeyState [VK_NUMLOCK]		= (pEvent->m_rParam & KEYMASK_NUMLOCK)?		0x80 : 0 ;
			byKeyState [VK_SCROLL]		= (pEvent->m_rParam & KEYMASK_SCROLL)?		0x80 : 0 ;
			byKeyState [VK_CONTROL]		= (pEvent->m_rParam & (KEYMASK_LCONTROL | KEYMASK_RCONTROL))?	0x80 : 0 ;
			byKeyState [VK_SHIFT]		= (pEvent->m_rParam & (KEYMASK_LSHIFT   | KEYMASK_RSHIFT))?		0x80 : 0 ;
			rwCH [0]	= 0 ;

			/*	where-is-internal �p�ɁA���� pbKeyState �̎w�����e���R�s�[����
			 *	�����ׂ��Ȃ̂��낤���H
			 */
			if (ToAscii (nVkCode, 0x80000000, byKeyState, rwCH, 0) == 0) {
				rwCH [0]	= (DCHAR) -1 ;
			} else {
				/*	keyboard �����ĕϊ��ł����ꍇ�̏����B
				 */
				/*	Control-Space �� Code 0 �Ƃ��Ĉ����B
				 */
				if (rwCH [0] == TEXT(' ') && (byKeyState [VK_CONTROL] & 0x80) != 0)
					rwCH [0]	= 0 ;
			}
			return	rwCH [0] ;
		}
		break ;
	case	WM_CHAR:
		return	(UINT)pEvent->m_wParam ;
	default:
		iCH	= -1 ;
		break ;
	}
	return	iCH ;
}

BOOL
ImeDoc_bEventToCharacter (
	const struct TMSG*		pEvent,
	int*					pCH)
{
	int		nCH ;

	if (pEvent == NULL)
		return	FALSE ;

	nCH	= ImeDoc_iGetCharFromEvent (pEvent) ;
	if (nCH < 0)
		return	FALSE ;
	if (pCH != NULL)
		*pCH	= nCH ;
	return	TRUE ;
}

BOOL
ImeDoc_bProcessEventp (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	int		nText ;

	/*	�Ăяo�����̃A�v���P�[�V�����ɃC�x���g�𓊂��Ԃ��ׂ����ǂ������f����B
	 *	�����Ԃ��ׂ��ł͂Ȃ��Ɣ��f�����ꍇ�ɂ́A�C�x���g�͐H�ׂ��Ă��܂��B
	 *
	 *	�����Ԃ��ׂ����ۂ��̔��f�́A
	 *	- minibuffer �� recursive-edit �����Ă��� => no
	 *	- ���ڃR�[�h���̓��[�h�Ȃ����ϊ����I�����[�h => no
	 *	- ����prefix�����݂��� (ImeBuffer_bHavePrefixp �� TRUE ��Ԃ�) => no
	 *	- composition string �����݂��� (�������Anext-line �̂悤�ɁA�m�肵�Ă��� event 
	 *	  ��e�ɕԂ��悤�Ȃ��̂����݂���B��O�ɒ��ӂ��邱��) => no
	 *	- 
	 */
	if (ImeDoc_bRecursiveEditp (pDoc))
		return	TRUE ;

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	FALSE ;
	if (ImeBuffer_bShowHenkanCandidatesModep (pCurBuffer) || ImeBuffer_bInputByCodeOrMenuModep (pCurBuffer))
		return	TRUE ;
	if (ImeBuffer_bHavePrefixp (pCurBuffer))
		return	TRUE ;
	(void) ImeBuffer_pBufferString (pCurBuffer, &nText) ;
	if (nText > 0)
		return	TRUE ;
	return	FALSE ;
}

/*========================================================================
 *	buffer interfaces
 */
struct CImeBuffer*
ImeDoc_pCreateBuffer (
	struct CImeDoc*			pDoc,
	LPCDSTR					wstrMessage,
	int						nstrMessage,
	BOOL					bSkkModeOn)
{
	struct CImeBuffer*	pBuffer ;
	int					nIndex ;
	BOOL				fInc ;

	/*	����ȏ�ċA�ł��Ȃ����H */
	if (pDoc->m_nBuffer >= MAXIMEBUFFER) {
		for (nIndex = 0 ; nIndex < MAXIMEBUFFER ; nIndex ++)
			if (pDoc->m_rpBuffer [nIndex] == NULL)
				break ;
		if (nIndex >= MAXIMEBUFFER)
			return	NULL ;
		fInc	= FALSE ;
	} else {
		nIndex	= pDoc->m_nBuffer ;
		fInc	= TRUE ;
	}
	pBuffer	= ImeBuffer_pCreate (pDoc) ;
	if (pBuffer == NULL) 
		return	NULL ;
	if (! ImeBuffer_bInit (pBuffer, wstrMessage, nstrMessage, bSkkModeOn)) {
		ImeBuffer_vDestroy (pBuffer) ;
		return	NULL ;
	}
	pDoc->m_rpBuffer [nIndex]	= pBuffer ;
	if (fInc)
		pDoc->m_nBuffer	++ ;
	return	pBuffer ;
}

void
ImeDoc_vDeleteUnusedBuffer (
	struct CImeDoc*				pDoc)
{
	int	i ;

	for (i = 0 ; i < pDoc->m_nUnusedBuffer ; i ++) {
		ImeBuffer_vDestroy (pDoc->m_rpUnusedBuffer [i]) ;
		pDoc->m_rpUnusedBuffer [i]	= NULL ;
	}
	pDoc->m_nUnusedBuffer	= 0 ;
	for (i = pDoc->m_nBuffer - 1 ; i >= 0 && pDoc->m_rpBuffer [i] == NULL ; i --) 
		;
	pDoc->m_nBuffer	= i + 1 ;
	return ;
}

BOOL
ImeDoc_bDeleteBuffer (
	struct CImeDoc*			pDoc, 
	struct CImeBuffer*		pUnusedBuffer)
{
	int			i, nIndex ;

	nIndex = -1 ;
	for (i = 0 ; i < pDoc->m_nBuffer ; i ++) {
		if (pDoc->m_rpBuffer [i] == pUnusedBuffer) {
			nIndex	= i ;
			continue ;
		}
	}
	if (nIndex < 0)
		return	FALSE ;
	/* ... */
	if (pDoc->m_nUnusedBuffer >= ARRAYSIZE (pDoc->m_rpUnusedBuffer)) {
		ImeDoc_vDeleteUnusedBuffer (pDoc) ;
		pDoc->m_nUnusedBuffer	= 0 ;
	}
	pDoc->m_rpUnusedBuffer [pDoc->m_nUnusedBuffer ++]	= pUnusedBuffer ;
	pDoc->m_rpBuffer [nIndex]	= NULL ;
	if (nIndex == (pDoc->m_nBuffer - 1))
		pDoc->m_nBuffer	-- ;
	return	TRUE ;
}

/*========================================================================
 *	private methods
 */
BOOL
imeDoc_bInitConfig (struct CImeDoc* pDoc)
{
	return	TRUE ;
}

void
imeDoc_vUninitConfig (struct CImeDoc* pDoc)
{
	return ;
}

BOOL
imeDoc_bWhereIsInternal (
	const struct CImeKeymap*	pKeymap,
	int							nFuncNo,
	struct TMSG*				pEvent)
{
	const struct CImeKeyBind*	pBind ;
	const struct CImeKeyBind*	pCurBind ;
	int		i, nBind, nCurScore ;
	unsigned int	uKeyMask, uKeyMaskW ;

	for (i = 0 ; i < SIZE_IMEDOC_KEYMAP ; i ++) {
		if (nFuncNo == pKeymap->m_rbyBaseMap [i]) {
			if (pEvent != NULL) {
				pEvent->m_nMessage	= WM_CHAR ;
				pEvent->m_wParam	= (WPARAM) i ;
				pEvent->m_lParam	= 0 ;
				pEvent->m_rParam	= 0 ;
				pEvent->m_nTime		= GetTickCount () ;
				pEvent->m_pt.x		= 0 ;
				pEvent->m_pt.y		= 0 ;
			}
			return	TRUE ;
		}
	}
	pBind		= pKeymap->m_pKeyBinds ;
	nBind		= pKeymap->m_nKeyBinds ;
	pCurBind	= NULL ;
	nCurScore	= -1 ;
	while (nBind > 0) {
		if (pBind->m_nKeyFunction == nFuncNo) {
			if (pEvent != NULL) {
				/*	�L�[�}�X�N�Ɉˑ����Ă��܂��̂ŁA���Ƃ������Ȃ����c */
				pEvent->m_nMessage	= WM_KEYDOWN ;
				pEvent->m_wParam	= (WPARAM) pCurBind->m_nKeyCode ;
				pEvent->m_lParam	= 0 ;
				pEvent->m_rParam	= pCurBind->m_uKeyMask ;
				pEvent->m_nTime		= GetTickCount () ;
				pEvent->m_pt.x		= 0 ;
				pEvent->m_pt.y		= 0 ;
			}
			return	TRUE ;
		}
		pBind	++ ;
		nBind	-- ;
	}
	return	FALSE ;
}

BOOL
imeDoc_bProcessFunctionp (
	struct CImeDoc*				pDoc,
	int							nFuncNo)
{
	/*	topbuffer �ŉ������������͂���Ă��Ȃ����� filter ���邩�ۂ��̃e�[�u���B
	 *	�V�`���G�[�V�����Ƃ��āu���蓾�Ȃ��v�́u�ǂ��瑤�ɓ|���v�̂��ǂ����c�������B
	 */
	switch (nFuncNo) {
	case	NFUNC_SKK_MODE:
	case	NFUNC_SKK_LATIN_MODE:
	case	NFUNC_SKK_JISX0208_LATIN_MODE:
	case	NFUNC_SKK_SET_HENKAN_POINT_SUBR:
	case	NFUNC_SKK_INPUT_BY_CODE_OR_MENU:
	case	NFUNC_SKK_ABBREV_COMMA:
	case	NFUNC_SKK_ABBREV_PERIOD:
	case	NFUNC_SKK_INSERT:
	case	NFUNC_SKK_KAKUTEI:
	case	NFUNC_SKK_JISX0208_LATIN_INSERT:
	case	NFUNC_SKK_TODAY:
	case	NFUNC_TOGGLE_IME:
	case	NFUNC_SKK_TOGGLE_CHARACTERS:
	case	NFUNC_SKK_TOGGLE_KUTOUTEN:
	case	NFUNC_SKK_PREVIOUS_CANDIDATE:
	case	NFUNC_SKK_TOGGLE_KATAKANA:
	case	NFUNC_SKK_TOGGLE_JISX0201:
	case	NFUNC_SKK_JISX0201_MODE:
		return	TRUE ;
	case	NFUNC_INVALID_CHAR:
	default:
		return	FALSE ;
	}

/*	�ۗ��F
	NFUNC_SELF_INSERT_CHARACTER,
	NFUNC_SET_MARK_COMMAND,
	NFUNC_BEGINNING_OF_LINE,
	NFUNC_BACKWARD_CHAR,
	NFUNC_MODE_SPECIFIC_COMMAND_PREFIX,
	NFUNC_DELETE_CHAR,
	NFUNC_END_OF_LINE,
	NFUNC_FORWARD_CHAR,
	NFUNC_KEYBOARD_QUIT,
	NFUNC_BACKWARD_DELETE_CHAR,
	NFUNC_INDENT_FOR_TAB_COMMAND,
	NFUNC_NEWLINE_AND_INDENT,
	NFUNC_KILL_LINE,
	NFUNC_RECENTER,
	NFUNC_NEWLINE,
	NFUNC_NEXT_LINE,
	NFUNC_OPEN_LINE,
	NFUNC_PREVIOUS_LINE,
	NFUNC_QUATED_INSERT,
	NFUNC_ISEARCH_BACKWARD,
	NFUNC_ISEARCH_FORWARD,
	NFUNC_TRANSPOSE_CHARS,
	NFUNC_UNIVERSAL_ARGUMENT,
	NFUNC_SCROLL_UP,
	NFUNC_KILL_REGION,
	NFUNC_CONTROL_X_PREFIX,
	NFUNC_YANK,
	NFUNC_SCROLL_DOWN,
	NFUNC_PREFIX_COMMAND,
	NFUNC_EXIT_RECURSIVE_EDIT,
	NFUNC_ABORT_RECURSIVE_EDIT,
	NFUNC_UNDO,
	NFUNC_SKK_START_HENKAN,
	NFUNC_SKK_TRY_COMPLETION,
	NFUNC_SKK_DELETE_BACKWARD_CHAR,
	NFUNC_SKK_PREVIOUS_CANDIDATE,
	NFUNC_SKK_TOGGLE_CHARACTERS,
	NFUNC_SKK_PURGE_FROM_JISYO,
	NFUNC_SKK_ABBREV_MODE,
	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT,
	NFUNC_SKK_CURRENT_KUTEN,
	NFUNC_SKK_UNDO,
	NFUNC_SKK_COMP_DO,
	NFUNC_SKK_KAKUTEI_HENKAN,
	NFUNC_SKK_UNDO_KAKUTEI_HENKAN,
	NFUNC_SKK_LATIN_HENKAN,
	*/
}

BOOL
imeDoc_bLookupKeymap (
	const struct CImeKeymap*	pKeymap,
	const struct TMSG*			pEvent,
	int*						pnFuncNo)
{
	const struct CImeKeyBind*	pBind ;
	int		nFuncNo, iCH, nBind, nKeyCode, nCurScore ;
	unsigned int	uKeyMask, uKeyMaskW ;

	if (pKeymap == NULL || pEvent == NULL)
		return	FALSE ;

	switch (pEvent->m_nMessage) {
	case	WM_KEYDOWN:
	case	WM_IME_KEYDOWN:
		nKeyCode	= (short) pEvent->m_wParam ;
		break ;
	case	WM_CHAR:
	case	WM_IME_CHAR:
		nKeyCode	= VkKeyScan (pEvent->m_wParam) ;
		uKeyMask	= 0 ;
		if (nKeyCode & 0x100)
			uKeyMask	|= (KEYMASK_LCONTROL | KEYMASK_RCONTROL) ;
		if (nKeyCode & 0x200)
			uKeyMask	|= (KEYMASK_LSHIFT | KEYMASK_RSHIFT) ;
		nKeyCode	= nKeyCode & 0xFF ;
		break ;
	case	WM_LBUTTONDOWN:
	case	WM_LBUTTONUP:
		nKeyCode	= VK_LBUTTON ;
		break ;
	case	WM_RBUTTONDOWN:
	case	WM_RBUTTONUP:
		nKeyCode	= VK_RBUTTON ;
		break ;
	default:
		return	FALSE ;
	}

	uKeyMask	= pEvent->m_rParam ;
	uKeyMaskW	= uKeyMask ;
	uKeyMaskW	|= (uKeyMask & (KEYMASK_LCONTROL | KEYMASK_RCONTROL))? (KEYMASK_LCONTROL | KEYMASK_RCONTROL) : 0 ;
	uKeyMaskW	|= (uKeyMask & (KEYMASK_LMENU    | KEYMASK_RMENU))?    (KEYMASK_LMENU    | KEYMASK_RMENU)    : 0 ;
	uKeyMaskW	|= (uKeyMask & (KEYMASK_RSHIFT   | KEYMASK_LSHIFT))?   (KEYMASK_RSHIFT   | KEYMASK_LSHIFT)   : 0 ;

	/*	�e�X�g�̏��Ԃ͎��̒ʂ�F
	 *	1. keymask �̊��S��v�A
	 *	2. keymask �� L �� R �𖳎�������r�ł̈�v�A
	 *	3. keymask �̕�����v�A
	 *	1->2->3 �̏����Ńe�X�g���āA���t����ΏI���B
	 *	���t����Ȃ���΁A�����ŃA�E�g�B
	 *
	 *	���� L �� R �𖳎�������r�����ACONTROL, MENU, SHIFT �ȂǕ�����������
	 *	������Ă����ꍇ�ɂ́A
	 */
	pBind	= pKeymap->m_pKeyBinds ;
	nBind	= pKeymap->m_nKeyBinds ;
	nFuncNo	= NFUNC_INVALID_CHAR ;
	nCurScore	= -1 ;
	while (nBind > 0) {
		if (pBind->m_nKeyCode == nKeyCode) {
			if ((pBind->m_uKeyMask & uKeyMaskW) == pBind->m_uKeyMask) {
				int		nScore ;

				/* match �x�����ɑ΂��� score �����肷��B*/
				nScore	= imeDoc_iGetKeyMatchScore (pBind->m_uKeyMask, uKeyMask, uKeyMaskW) ;
				if (nScore > nCurScore) {
					nFuncNo		= pBind->m_nKeyFunction ;
					nCurScore	= nScore ;

					if (nCurScore == 100)
						break ;
				}
			}
		}
		pBind	++ ;
		nBind	-- ;
	}

	iCH	= ImeDoc_iGetCharFromEvent (pEvent) ;
	if (0 <= iCH && iCH < SIZE_IMEDOC_KEYMAP) {
		if (nCurScore <= 0) {
			if (pnFuncNo != NULL)
				*pnFuncNo	= pKeymap->m_rbyBaseMap [iCH] ;
			return	TRUE ;
		}
	}

	if (nCurScore < 0)
		return	FALSE ;
	if (pnFuncNo != NULL)
		*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

int
imeDoc_iGetKeyMatchScore (
	unsigned int				uMask,
	unsigned int				uExactMask,
	unsigned int				uRoughMask)
{
	unsigned int	uValue ;
	int				nScore, i ;

	if (uMask == uRoughMask)
		return	100 ;	/* 100% */

	/*	���ۂɉ����ꂽ�L�[���牟����ĂȂ��ƍ�邱�Ƃ͂����Ă����̋t�͂Ȃ��B
	 *	(����ɉ��������Ƃɂ�����͂��Ȃ�)
	 *	�܂�A�������L�[�̉��߂��A
	 *		SHIFT + F.1 => F.1 
	 *	�̕����͂����Ă�
	 *		F.1 => SHIFT + F.1
	 *	�ɂ͊g�債�Ȃ��B
	 */
	if ((uRoughMask & uMask) != uMask)
		return	0 ;

	/*	��v���Ă��鐔�����X�R�A�������Ȃ�B�������ALR �̈Ⴂ�ň�v����ꍇ��
	 *	���S��v�����X�R�A���Ⴂ�B
	 */
	uValue	= uExactMask & uMask ;
	nScore	= 0 ;
	for (i = 0 ; i < NBITS_KEYMASK ; i ++)
		if (uValue & (1 << i))
			nScore	++ ;
	uValue	= uRoughMask & uMask ;
	for (i = 0 ; i < NBITS_KEYMASK ; i ++)
		if (uValue & (1 << i))
			nScore	++ ;
	return	nScore ;
}


/*========================================================================
 */
BOOL
imeDoc_bUpdateCandidateInfoForStatusText (
	struct CImeDoc*		pDoc)
{
	TVarbuffer*		pvbufMessageInfo ;
	LPMYCAND		pMyCand ;
	LPCANDIDATEINFO	pCandInfo ;
	LPCANDIDATELIST	pCandList ;
	LPMYSTR			pCandidateStr ;
	DWORD*			pCandidateOffset ;
	DWORD			dwSize ;
	LPWSTR			pwDest ;

	ASSERT (pDoc != NULL && pDoc->m_nBuffer > 0 && pDoc->m_rpBuffer [0] != NULL) ;
	ASSERT (pnLength != NULL) ;
	ASSERT (pnCursor != NULL) ;

	pvbufMessageInfo	= ImeDoc_pGetMessageInfoBuffer (pDoc) ;
	if (pvbufMessageInfo == NULL)
		return	FALSE ;

	dwSize	= sizeof (MYCAND) + sizeof (DWORD) * 1 ;
	if (pDoc->m_rpBuffer [0] != pDoc->m_pCurBuffer) {
		LPCDSTR			pdText ;
		LPWSTR			pwDestEnd ;
		int				iDLength, iCursorDPos, iCursorWPos = -1, nWLength ;
		struct TMarker*	pmkPoint ;

		/*	Message ���������ꍇ�ɂ͐擪�Ɂu�I�v��ǉ����������c�B
		 *	���ƁA���O�� StatusLine ���`��ł��Ȃ��ꍇ�ɁA�J�[�\�����Ӗ�����
		 *	���������Ă��������B``|'' �ŗǂ����B
		 */
		pdText	= ImeBuffer_pBufferRawString (pDoc->m_pCurBuffer, &iDLength) ;
		if (ImeBuffer_bGetMarker (pDoc->m_pCurBuffer, MARKER_POINT, &pmkPoint) && pmkPoint != NULL) {
			iCursorDPos	= TMarker_iGetPosition (pmkPoint) ;
		} else {
			iCursorDPos	= -1 ;
		}
		/*	"|" �̃T�C�Y�� SURROGATE_PAIR �̉e���͎󂯂Ȃ��B�Ȃ̂�+1�ŁB�����͍l���Ȃ��B
		 */
		nWLength	= dcstowcs (NULL, 0, pdText, iDLength) + 1/*``|''�̕�*/ + 1/*nul�̕�*/ ; 

		if (pDoc->m_nbufMessage > 0) {
			/*	���́u�I�v�̒ǉ��̂��߂� minibuffer text �� region �I��������Ă�
			 *	�܂��B
			 */
			nWLength	++ ;	/*``�I''�̕�*/ 
		}

		dwSize	+= sizeof (MYCHAR) * nWLength ;
		TVarbuffer_Clear (pvbufMessageInfo) ;
		if (! TVarbuffer_Require (pvbufMessageInfo, dwSize))
			return	FALSE ;

		pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufMessageInfo) ;
		pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
		pCandInfo->dwSize		= dwSize ;
		pCandInfo->dwCount		= 1 ;
		pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
		pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
		pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * 1 + sizeof (MYCHAR) * nWLength ;
		pCandList->dwStyle		= IME_CAND_UNKNOWN ;
		pCandList->dwCount		= 1 ;
		pCandList->dwPageSize	= 1 ;
		pCandList->dwSelection	= 0 ;
		pCandList->dwPageStart	= 0 ;
		pCandidateStr			= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * 1) ;
		pCandidateOffset		= pCandList->dwOffset ;
		pCandidateOffset [0]	= (DWORD)((LPSTR)pCandidateStr - (LPSTR)pCandList) ;

		pwDest		= pCandidateStr ;
		pwDestEnd	= pwDest + nWLength ;
		if (pDoc->m_nbufMessage > 0) {
			*pwDest ++	= L'�I' ;
		}
		if (0 < iCursorDPos) {
			iCursorWPos	= dcstowcs (pwDest, pwDestEnd - pwDest, pdText, iCursorDPos) ;
			pwDest	+= iCursorWPos ;
		}
		*pwDest ++	= L'|' ;
		if (iCursorDPos < iDLength) {
			int	n = dcstowcs (pwDest, pwDestEnd - pwDest, pdText + iCursorDPos, iDLength - iCursorDPos) ;
			pwDest	+= n ;
		}
		*pwDest = L'\0' ;
	} else {
		int	nWLength, n ;

		nWLength	= dcstowcs (NULL, 0, pDoc->m_bufMessage, pDoc->m_nbufMessage) + 1 ;

		dwSize		+= sizeof (MYCHAR) * nWLength ;
		TVarbuffer_Clear (pvbufMessageInfo) ;
		if (! TVarbuffer_Require (pvbufMessageInfo, dwSize))
			return	FALSE ;

		pMyCand					= (LPMYCAND) TVarbuffer_GetBuffer (pvbufMessageInfo) ;
		pCandInfo				= (LPCANDIDATEINFO)&(pMyCand->ci) ;
		pCandInfo->dwSize		= dwSize ;
		pCandInfo->dwCount		= 1 ;
		pCandInfo->dwOffset [0]	= (DWORD)((LPSTR)&(pMyCand->cl) - (LPSTR)pCandInfo) ;
		pCandList				= (LPCANDIDATELIST)&(pMyCand->cl) ;
		pCandList->dwSize		= sizeof (CANDIDATELIST) + sizeof (DWORD) * 1 + sizeof (MYCHAR) * nWLength ;
		pCandList->dwStyle		= IME_CAND_UNKNOWN ;
		pCandList->dwCount		= 1 ;
		pCandList->dwPageSize	= 1 ;
		pCandList->dwSelection	= 0 ;
		pCandList->dwPageStart	= 0 ;
		pCandidateStr			= (LPMYSTR)((LPSTR)pCandList + sizeof (CANDIDATELIST) + sizeof (DWORD) * 1) ;
		pCandidateOffset		= pCandList->dwOffset ;
		pCandidateOffset [0]	= (DWORD)((LPSTR)pCandidateStr - (LPSTR)pCandList) ;

		n	= dcstowcs (pCandidateStr, nWLength-1, pDoc->m_bufMessage, pDoc->m_nbufMessage) ;
		pCandidateStr [n]	= L'\0' ;
	}
	return	TRUE ;
}

/*===============================================================
 *	Context-Related private functions
 */
BOOL
imeDoc_bInitContextBuffer (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		i ;

	memset (&s_DocContext, 0, sizeof (s_DocContext)) ;

	s_DocContext.m_pRegStack	= (struct LMREG*) MALLOC (sizeof (struct LMREG) * NSIZE_REGSTACK) ;
	if (s_DocContext.m_pRegStack == NULL)
		return	FALSE ;
	s_DocContext.m_pbStackArea	= (BYTE*) MALLOC (pDoc->m_nStackAreaSize) ;
	if (s_DocContext.m_pbStackArea == NULL) {
		FREE (s_DocContext.m_pRegStack) ;
		s_DocContext.m_pRegStack	= NULL ;
		return	FALSE ;
	}
	s_DocContext.m_nStackAreaSize	= pDoc->m_nStackAreaSize ;
	for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
		pBuffer	= ImeBuffer_pCreate (pDoc) ;
		if (pBuffer == NULL) 
			goto	error_exit ;
		if (! ImeBuffer_bInit (pBuffer, NULL, 0, FALSE)) {
			ImeBuffer_vDestroy (pBuffer) ;
			goto	error_exit ;
		}
		s_DocContext.m_rpBufferState [i]	= pBuffer ;
	}
	return	TRUE ;

error_exit:
	imeDoc_vUninitContextBuffer (pDoc) ;
	return	FALSE ;
}

void
imeDoc_vUninitContextBuffer (
	struct CImeDoc*			pDoc)
{
	int	i ;

	if (s_DocContext.m_pRegStack != NULL) {
		FREE (s_DocContext.m_pRegStack) ;
		s_DocContext.m_pRegStack	= NULL ;
	}
	if (s_DocContext.m_pbStackArea != NULL) {
		FREE (s_DocContext.m_pbStackArea) ;
		s_DocContext.m_pbStackArea	= NULL ;
	}
	for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
		if (s_DocContext.m_rpBufferState [i] != NULL) {
			ImeBuffer_vDestroy (s_DocContext.m_rpBufferState [i]) ;
			s_DocContext.m_rpBufferState [i]	= NULL ;
		}
	}
	return ;
}

BOOL
imeDoc_bSaveContext (
	struct CImeDoc*			pDoc)
{
	struct CImeDocContext*	pContext	= NULL ;
	int						i ;

	pContext						= &s_DocContext ;
	if (pContext->m_nStackAreaSize != pDoc->m_nStackAreaSize)
		return	FALSE ;
	if (pContext->m_pRegStack == NULL || pContext->m_pbStackArea == NULL)
		return	FALSE ;

	pContext->m_pPC					= pDoc->m_pPC ;
	memcpy (pContext->m_rpRetPC, pDoc->m_rpRetPC, sizeof (pDoc->m_rpRetPC)) ;
	pContext->m_nRetPC				= pDoc->m_nRetPC ;
	pContext->m_nStackAreaSize		= pDoc->m_nStackAreaSize ;
	pContext->m_nStackHead			= pDoc->m_nStackHead ;
	memcpy (pContext->m_pbStackArea,	pDoc->m_pbStackArea,	pDoc->m_nStackAreaSize) ;
	memcpy (pContext->m_rnStackPos,		pDoc->m_rnStackPos,		sizeof (pDoc->m_rnStackPos)) ;
	memcpy (pContext->m_pRegStack,		pDoc->m_pRegStack,		sizeof (struct LMREG) * NSIZE_REGSTACK) ;
	pContext->m_nRegStackHead		= pDoc->m_nRegStackHead ;
	memcpy (pContext->m_rREGS, pDoc->m_rREGS, sizeof (pDoc->m_rREGS)) ;
	pContext->m_iThisCommand		= pDoc->m_iThisCommand ;
	pContext->m_iLastCommand		= pDoc->m_iLastCommand ;
	pContext->m_LastEvent			= pDoc->m_LastEvent ;
	pContext->m_iLastCommandChar	= pDoc->m_iLastCommandChar ;

	pContext->m_nBuffer				= pDoc->m_nBuffer ;
	/*	�o�b�t�@���̏�Ԃ��ω�����\��������̂ŁA�L�����Ă����K�v������c�B*/
	for (i = 0 ; i < pDoc->m_nBuffer ; i ++) {
		if (pDoc->m_rpBuffer [i] != NULL) {
			ImeBuffer_vCopyState (pContext->m_rpBufferState [i], pDoc->m_rpBuffer [i]) ;
		}
	}
	/*	Restore �̎��ɑ������o�b�t�@�͔j������B*/
	memset (pContext->m_rpBuffer, 0, sizeof (pContext->m_rpBuffer)) ;
	for (i = 0 ; i < pDoc->m_nBuffer ; i ++)
		pContext->m_rpBuffer [i]	= pDoc->m_rpBuffer [i] ;
	pContext->m_pCurBuffer			= pDoc->m_pCurBuffer ;
	pContext->m_pPreCommandHook		= pDoc->m_pPreCommandHook ;
	pContext->m_pPostCommandHook	= pDoc->m_pPostCommandHook ;
	return	TRUE ;
}

void
imeDoc_vRestoreContext (
	struct CImeDoc*			pDoc)
{
	struct CImeDocContext*	pContext	= &s_DocContext ;
	int		iCurBuffer, i ;

	pDoc->m_pPC					= pContext->m_pPC ;
	memcpy (pDoc->m_rpRetPC, pContext->m_rpRetPC, sizeof (pDoc->m_rpRetPC)) ;
	pDoc->m_nRetPC				= pContext->m_nRetPC ;
	memcpy (pDoc->m_rnStackPos, pContext->m_rnStackPos, sizeof (pDoc->m_rnStackPos)) ;
	memcpy (pDoc->m_pRegStack,  pContext->m_pRegStack,  sizeof (struct LMREG) * NSIZE_REGSTACK) ;
	pDoc->m_nStackHead			= pContext->m_nStackHead ;
	pDoc->m_nRegStackHead		= pContext->m_nRegStackHead ;
	memcpy (pDoc->m_rREGS, pContext->m_rREGS, sizeof (pDoc->m_rREGS)) ;
	pDoc->m_iThisCommand		= pContext->m_iThisCommand ;
	pDoc->m_iLastCommand		= pContext->m_iLastCommand ;
	pDoc->m_LastEvent			= pContext->m_LastEvent ;
	pDoc->m_iLastCommandChar	= pContext->m_iLastCommandChar ;

	for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
		if (pContext->m_pCurBuffer == pContext->m_rpBuffer [i])
			iCurBuffer	= i ;
	}
	if (pDoc->m_nBuffer != pContext->m_nBuffer) {
		for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
			if (pContext->m_rpBuffer [i] != pDoc->m_rpBuffer [i]) {
				DEBUGPRINTFEX (99, (TEXT ("[%d] Compare Buffers (before: %p, after:%p)\n"), i, pContext->m_rpBuffer [i], pDoc->m_rpBuffer [i])) ;
				if (pDoc->m_rpBuffer [i] == NULL) {
					/* ���̏ꍇ�ɂ� buffer �������Ă��܂����̂ŁA���ɖ߂����߂� buffer ���U�B*/
					if (pDoc->m_nUnusedBuffer > 0) {
						pDoc->m_rpBuffer [i]	= pDoc->m_rpUnusedBuffer [-- pDoc->m_nUnusedBuffer] ;
						pDoc->m_rpUnusedBuffer [pDoc->m_nUnusedBuffer]	= NULL ;
					} else {
						struct CImeBuffer*	pBuffer	= NULL ;

						pBuffer	= ImeBuffer_pCreate (pDoc) ;
						if (pBuffer != NULL) {
							if (ImeBuffer_bInit (pBuffer, NULL, 0, FALSE)) {
								pDoc->m_rpBuffer [i]	= pBuffer ;
							} else {
								ImeBuffer_vDestroy (pBuffer) ;
								pBuffer	= NULL ;
							}
						}
					}
				} else if (pContext->m_rpBuffer [i] == NULL) {
					/* ���̏ꍇ�ɂ� buffer ���������̂ŁA���ɖ߂����߂ɑ����� buffer ��j���B*/
					if (! ImeDoc_bDeleteBuffer (pDoc, pDoc->m_rpBuffer [i])) {
						ImeBuffer_vDestroy (pDoc->m_rpBuffer [i]) ;
						pDoc->m_rpBuffer [i]	= NULL ;
					}
				} else {
					/* ���̏ꍇ�ɂ� CopyState �ŉ����ł���B*/
				}
			}
		}
	} else {
		/*	CopyState �ŉ����ł��邾�낤�B*/
		pDoc->m_nBuffer		= pContext->m_nBuffer ;
	}
	for (i = 0 ; i < pDoc->m_nBuffer ; i ++) {
		if (pContext->m_rpBufferState [i] != NULL) {
			ImeBuffer_vCopyState (pDoc->m_rpBuffer [i], pContext->m_rpBufferState [i]) ;
		}
	}
	pDoc->m_pCurBuffer			= pDoc->m_rpBuffer [iCurBuffer] ;
	pDoc->m_pPreCommandHook		= pContext->m_pPreCommandHook ;
	pDoc->m_pPostCommandHook	= pContext->m_pPostCommandHook ;
	return ;
}

BOOL
imeDoc_bEmulateFilterEvent (
	struct CImeDoc*			pDoc,
	const struct TMSG*		pMsg,
	BOOL*					pbEaten)
{
	BOOL	bRetval ;
	int		nUnreadMessages	;

	/*	test
	 */
	DEBUGPRINTFEX (99, (TEXT ("[enter] imeDoc_bEmulateFilterEvent (msgnum:%d)\n"), pDoc->m_nUnreadMessages)) ;
	if (pDoc->m_nBuffer != 1)
		return	FALSE ;

	if (! imeDoc_bSaveContext (pDoc))
		return	FALSE ;

	nUnreadMessages	= pDoc->m_nUnreadMessages ;
	if (! ImeDoc_bPushEvent (pDoc, pMsg))
		return	FALSE ;

	pDoc->m_UnprocessEvent.m_nMessage	= WM_NULL ;
	bRetval	= imeDoc_bTick (pDoc) ;
	if (pDoc->m_UnprocessEvent.m_nMessage	!= WM_NULL			&&
		pDoc->m_UnprocessEvent.m_nMessage	== pMsg->m_nMessage &&
		pDoc->m_UnprocessEvent.m_wParam		== pMsg->m_wParam	&&
		pDoc->m_UnprocessEvent.m_lParam		== pMsg->m_lParam) {
		*pbEaten	= FALSE ;
	} else {
		*pbEaten	= TRUE ;
	}
	imeDoc_vRestoreContext (pDoc) ;
	ImeDoc_vDeleteUnusedBuffer (pDoc) ;
	pDoc->m_nUnreadMessages	= nUnreadMessages ;
	DEBUGPRINTFEX (99, (TEXT ("[leave] imeDoc_bEmulateFilterEvent (msgnum:%d)\n"), pDoc->m_nUnreadMessages)) ;
	return	bRetval ;
}


