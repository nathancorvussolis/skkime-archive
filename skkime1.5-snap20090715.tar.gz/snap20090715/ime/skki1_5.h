/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * skki1_0.h
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#pragma once
#pragma warning (disable : 4242 4244)

#include <indicml.h>

/*========================================================================
 *	Constants
 */
#define	SKKISERVER_PIPE_BASENAME	L"\\\\.\\pipe\\skkiserv010500_pipe_%s"
#define	PROGRAMF_DIR				L"IME"
#define	SKKIMEProg_S_DIR			L"SKKIM15"
#define	SKKIMEServerFile			L"skkiserv.exe"
#define	SKKIMEConfigProg			L"skimconf.exe"

#define	SKKIME_MUTEX_NAME			TEXT ("skkime1_5_mutex")

#include "mylocale.h"

/* for limit of SKKIME */
#define MAXCOMPWND					(10)
#define MAXCOMPSIZE					(256)
#define MAXCLAUSESIZE				(16)
#define MAXCANDPAGESIZE				(9)
#define MAXCANDSTRSIZE				(16)
#define MAXGLCHAR					(256)
#define MAXCANDSTRNUM				(32)

/* special messages */
#define WM_UI_UPDATE				(WM_USER+500)
#define WM_UI_HIDE					(WM_USER+501)

#define WM_UI_STATEMOVE				(WM_USER+601)
#define WM_UI_DEFCOMPMOVE			(WM_USER+602)
#define WM_UI_CANDMOVE				(WM_USER+603)
#define WM_UI_GUIDEMOVE				(WM_USER+604)
#define	WM_UI_STATEHIDE				(WM_USER+605)

#define	IMN_PRIVATE_INDICICON				(1)
#define	IMN_PRIVATE_SHOWSTATUSWINDOW		(3)
#define	IMN_PRIVATE_ACTIVATECONTEXT			(4)
#define	IMN_PRIVATE_DEACTIVATECONTEXT		(5)

/* Escape Functions */
#define IME_ESC_PRI_GETDWORDTEST (IME_ESC_PRIVATE_FIRST + 0)

/* special style */
#define WS_COMPDEFAULT		(WS_DISABLED | WS_POPUP)
#define WS_COMPNODEFAULT	(WS_DISABLED | WS_POPUP)

#define	UI_CURSORWIDTH			(2)

/* Change Mode index */
#define TO_CMODE_ALPHANUMERIC	(0x0001)
#define TO_CMODE_KATAKANA		(0x0002)
#define TO_CMODE_HIRAGANA		(0x0003)
#define TO_CMODE_FULLSHAPE		(0x0008)
#define TO_CMODE_ROMAN			(0x0010)
#define TO_CMODE_CHARCODE		(0x0020)
#define TO_CMODE_TOOLBAR		(0x0100)

/* WndExtra of child UI windows */
#define	FIGWL_MOUSE					(0)

#define	FIGWL_UICAND_MOUSE			(FIGWL_MOUSE)
#define	FIGWLP_UICAND_SVRWND		(FIGWL_UICAND_MOUSE			+ sizeof (LONG))
#define	FIGWLP_UICAND_TOOLTIP		(FIGWLP_UICAND_SVRWND		+ sizeof (LONG_PTR))
#define	FIGWLP_UICAND_TOOLTIPINFO	(FIGWLP_UICAND_TOOLTIP		+ sizeof (LONG_PTR))
#define	UICAND_EXTRASIZE			(FIGWLP_UICAND_TOOLTIPINFO	+ sizeof (LONG_PTR))

#define	FIGWLP_UIANNOT_SVRWND		(FIGWL_MOUSE				+ sizeof (LONG))
#define	FIGWLP_UIANNOT_TEXT			(FIGWLP_UIANNOT_SVRWND		+ sizeof (LONG_PTR))
#define	UIANNOT_EXTRASIZE			(FIGWLP_UIANNOT_TEXT		+ sizeof (LONG_PTR))

#define	FIGWL_UICOMP_MOUSE			(FIGWL_MOUSE)
#define	FIGWL_UICOMP_SVRWND			(FIGWL_UICOMP_MOUSE			+ sizeof (LONG))
#define	FIGWL_UICOMP_FONT			(FIGWL_UICOMP_SVRWND		+ sizeof (LONG_PTR))
#define	FIGWL_UICOMP_COMPSTARTSTR	(FIGWL_UICOMP_FONT   		+ sizeof (LONG_PTR))
#define	FIGWL_UICOMP_COMPSTARTNUM	(FIGWL_UICOMP_COMPSTARTSTR	+ sizeof (LONG))
#define	FIGWL_UICOMP_PREVCURSOR		(FIGWL_UICOMP_COMPSTARTNUM	+ sizeof (LONG))
#define	UICOMP_EXTRASIZE			(FIGWL_UICOMP_PREVCURSOR	+ sizeof (LONG))

#define	FIGWL_UISTATE_MOUSE			(FIGWL_MOUSE)
#define	FIGWL_UISTATE_SVRWND		(FIGWL_UISTATE_MOUSE		+ sizeof (LONG))
#define	FIGWL_UISTATE_STATUSORGBMP	(FIGWL_UISTATE_SVRWND		+ sizeof (LONG_PTR))
#define	FIGWL_UISTATE_CLOSEORGBMP	(FIGWL_UISTATE_STATUSORGBMP	+ sizeof (LONG_PTR))
#define	FIGWL_UISTATE_STATUSBMP		(FIGWL_UISTATE_CLOSEORGBMP	+ sizeof (LONG_PTR))
#define	FIGWL_UISTATE_CLOSEBMP		(FIGWL_UISTATE_STATUSBMP	+ sizeof (LONG_PTR))
#define	FIGWL_UISTATE_PUSHSTATUS	(FIGWL_UISTATE_CLOSEBMP		+ sizeof (LONG_PTR))
#define	FIGWL_UISTATE_CURSOR		(FIGWL_UISTATE_PUSHSTATUS	+ sizeof (LONG))
#define	FIGWL_UISTATE_PREVCMODE		(FIGWL_UISTATE_CURSOR		+ sizeof (LONG_PTR))
#define	UISTATE_EXTRASIZE			(FIGWL_UISTATE_PREVCMODE	+ sizeof (LONG))

#define	FIGWL_UIMINIBUF_MOUSE		(FIGWL_MOUSE)
#define	FIGWL_UIMINIBUF_SVRWND		(FIGWL_UIMINIBUF_MOUSE		+ sizeof (LONG))
#define	FIGWL_UIMINIBUF_PREVCURSOR	(FIGWL_UIMINIBUF_SVRWND		+ sizeof (LONG_PTR))
#define	UIMINIBUF_EXTRASIZE			(FIGWL_UIMINIBUF_PREVCURSOR	+ sizeof (LONG))

/* The flags of FIGWL_MOUSE */
#define FIM_FOCUS				(0x01)	/* �}�E�X�͂��̃E�B���h�E���ɑ��݂���B*/
#define FIM_CAPUTURED			(0x02)	/* �}�E�X�̓��͂�D��������K�v������B*/
#define FIM_MOVED				(0x04)

/* The flags of the button of Status Window */
#define PUSHED_STATUS_ONOFF		(0x01)
#define PUSHED_STATUS_MODE		(0x02)
#define PUSHED_STATUS_MOVE		(0x04)

/* Status Button Pos */
#ifdef STATUSWINDOW_LARGE
#define	STATUSONOFF_BTNX		(12)
#define	STATUSONOFF_BTNY		(20)
#define	STATUSONOFF_X			(0)
#define	STATUSONOFF_Y			(0)
#define	STATUSCMODE_BTNX		(48)
#define	STATUSCMODE_BTNY		(20)
#define	STATUSCMODE_X			(STATUSONOFF_X+STATUSONOFF_BTNX)
#define	STATUSCMODE_Y			(STATUSONOFF_Y)
#define	STATUS_BTNX				(STATUSONOFF_BTNX+STATUSCMODE_BTNX)
#define	STATUS_BTNY				(STATUSCMODE_BTNY)
#else
#define	STATUSONOFF_BTNX		(11)
#define	STATUSONOFF_BTNY		(15)
#define	STATUSONOFF_X			(0)
#define	STATUSONOFF_Y			(0)
#define	STATUSCMODE_BTNX		(32)
#define	STATUSCMODE_BTNY		(15)
#define	STATUSCMODE_X			(STATUSONOFF_X+STATUSONOFF_BTNX)
#define	STATUSCMODE_Y			(STATUSONOFF_Y)
#define	STATUS_BTNX				(STATUSONOFF_BTNX+STATUSCMODE_BTNX)
#define	STATUS_BTNY				(STATUSCMODE_BTNY)
#endif

enum {
	BTY_DIRECTINPUT				= STATUS_BTNY * 0,
	BTY_KANA					= STATUS_BTNY * 1,
	BTY_KATAKANA				= STATUS_BTNY * 2,
	BTY_ZENEI					= STATUS_BTNY * 3,
	BTY_ASCII					= STATUS_BTNY * 4,
	BTY_JISX0201KANA			= STATUS_BTNY * 5,
	BTY_JISX0201ROMAN			= STATUS_BTNY * 6,
} ;

/* Init or Clear Structure Flag */
#define	CLR_RESULT				(1)
#define	CLR_UNDET				(2)
#define	CLR_RESULT_AND_UNDET	(3)


/* define GET LP for COMPOSITIONSTRING members. */
#define GETLPCOMPREADATTR(lpcs)		(LPBYTE) ((LPBYTE)(lpcs) + (lpcs)->dwCompReadAttrOffset)
#define GETLPCOMPREADCLAUSE(lpcs)	(LPDWORD)((LPBYTE)(lpcs) + (lpcs)->dwCompReadClauseOffset)
#define GETLPCOMPREADSTR(lpcs)		(LPMYSTR)((LPBYTE)(lpcs) + (lpcs)->dwCompReadStrOffset)
#define GETLPCOMPATTR(lpcs)			(LPBYTE) ((LPBYTE)(lpcs) + (lpcs)->dwCompAttrOffset)
#define GETLPCOMPCLAUSE(lpcs)		(LPDWORD)((LPBYTE)(lpcs) + (lpcs)->dwCompClauseOffset)
#define GETLPCOMPSTR(lpcs)			(LPMYSTR)((LPBYTE)(lpcs) + (lpcs)->dwCompStrOffset)
#define GETLPRESULTREADCLAUSE(lpcs)	(LPDWORD)((LPBYTE)(lpcs) + (lpcs)->dwResultReadClauseOffset)
#define GETLPRESULTREADSTR(lpcs)	(LPMYSTR)((LPBYTE)(lpcs) + (lpcs)->dwResultReadStrOffset)
#define GETLPRESULTCLAUSE(lpcs)		(LPDWORD)((LPBYTE)(lpcs) + (lpcs)->dwResultClauseOffset)
#define GETLPRESULTSTR(lpcs)		(LPMYSTR)((LPBYTE)(lpcs) + (lpcs)->dwResultStrOffset)


#define SetClause(lpdw,num)			{*((LPDWORD)(lpdw)) = 0;*((LPDWORD)(lpdw)+1) = num;}

#define GCS_COMPALL					(GCS_COMPSTR | GCS_COMPATTR | GCS_COMPREADSTR | GCS_COMPREADATTR | GCS_COMPCLAUSE | GCS_COMPREADCLAUSE)
#define GCS_RESULTALL				(GCS_RESULTSTR | GCS_RESULTREADSTR | GCS_RESULTCLAUSE | GCS_RESULTREADCLAUSE)

/* ImeMenu Define */
#define	NUM_INPUTMODE_MENU			(7)
#define NUM_ROOT_MENU_L				(NUM_INPUTMODE_MENU+6)
#define NUM_ROOT_MENU_R				(8)

#define	IDIM_SHOW_TOOLBAR			(0x10)
#define	IDIM_PROPERTY				(0x11)
#define	IDIM_INPUTMODE				(0x12)
#define	IDIM_CANCEL					(0x13)

/*	IDIM_CMODE_TO_ASCII ���� IDIM_CMODE_TO_DIRECTINPUT ��
 *	�u���̕��тŘA�����Ă���v���Ƃ����肵�Ă���R�[�h
 *	�ɂȂ��Ă���B
#define	IDIM_CMODE_TO_ASCII			(0x20)
#define	IDIM_CMODE_TO_ROMANHIRA		(0x21)
#define	IDIM_CMODE_TO_ROMANKATA		(0x22)
#define	IDIM_CMODE_TO_JISX0201KANA	(0x23)
#define	IDIM_CMODE_TO_JISX0201ROMAN	(0x24)
#define	IDIM_CMODE_TO_ZENEI			(0x25)
#define	IDIM_CMODE_TO_DIRECTINPUT	(0x26)
 */

#define	MYVARTYPE_BOOL				(0)
#define	MYVARTYPE_INT				(1)
#define	MYVARTYPE_LONG				(2)
#define	MYVARTYPE_COLORFACE			(3)

/* ���W�X�g���L�[�B*/
#define	REGPATH_SKKIME_BASE			"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5"
#define	REGPATH_SKKIME_BASE_W		L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5"
#define	REGKEY_HIDETOOLBAR			"HideToolbar"
#define	REGKEY_SHOWKEYBRDICON		"ShowKeyboardIcon"
#define	REGKEY_SHOWIMEICON			"ShowInputMethodIcon"
#define	REGKEY_SHOWINPUTMODEICON	"ShowInputModeIcon"

#define	DEFAULT_MINIBUF_CHARWIDTH	(80)

#define NATIVE_CHARSET				(SHIFTJIS_CHARSET)
#define	SKKIME_LANGID				(0xE0110411)

enum {
	MYCOLOR_TEXTAUTO	= 0,	MYCOLOR_BACKAUTO,
	MYCOLOR_BLACK,				MYCOLOR_DARKRED,
	MYCOLOR_DARKGREEN,			MYCOLOR_DARKYELLOW,
	MYCOLOR_DARKBLUE,			MYCOLOR_DARKPURPLE,
	MYCOLOR_DARKLIGHTBLUE,		MYCOLOR_DARKGRAY,
	MYCOLOR_LIGHTGRAY,			MYCOLOR_RED,
	MYCOLOR_GREEN,				MYCOLOR_YELLOW,
	MYCOLOR_BLUE,				MYCOLOR_PURPLE,
	MYCOLOR_LIGHTBLUE,			MYCOLOR_WHITE,
	MYCOLOR_SYSTEM,
	MYCOLOR_BTNFACE		= MYCOLOR_SYSTEM,
	MYCOLOR_BTNTEXT,			MYCOLOR_ACTIVEBORDER,
	MYCOLOR_ACTIVECAPTION,		MYCOLOR_CAPTIONTEXT,
	MYCOLOR_APPWORKSPACE,		MYCOLOR_WINDOW,
	MYCOLOR_WINDOWTEXT,			MYCOLOR_DESKTOP,
	MYCOLOR_INFOBK,				MYCOLOR_INFOTEXT,
	MYCOLOR_MSGBOXTEXT,			MYCOLOR_MENU,
	MYCOLOR_MENUTEXT,			MYCOLOR_HIGHLIGHTTEXT,
	MYCOLOR_HIGHLIGHT,			MYCOLOR_INACTIVEBORDER,
	MYCOLOR_INACTIVECAPTION,	MYCOLOR_INACTIVECAPTIONTEXT,
	MAX_MYCOLOR,
} ;

enum {
	MYLINE_NO	= 0,	MYLINE_SOLID,		MYLINE_DOTTED,
	MYLINE_THICK_SOLID,	MYLINE_THIN_DITHER,	MYLINE_THICK_DITHER,
	MAX_MYLINE,
} ;

enum {
	MYCOLORFACE_INDEX_MIHENKANMOJIRETSU	= 0,
	MYCOLORFACE_INDEX_HENKANMOJIRETSU	= 1,
} ;

enum {
	RECURSIVE_EDIT_ALWAYS				= 0,
	RECURSIVE_EDIT_UICAND_IS_ENABLE,
	RECURSIVE_EDIT_UICOMP_IS_ENABLE,
	RECURSIVE_EDIT_BOTH_ENABLE,
	RECURSIVE_EDIT_NEVER,
	NUM_RECURSIVE_EDIT,
} ;

/*========================================================================
 *	Macros
 */
#if !defined (ARRAYSIZE)
#define	ARRAYSIZE(myarray)	(sizeof myarray / sizeof myarray[0])
#endif
#if !defined (MIN)
#define	MIN(left,right)		(((left) < (right))? (left) : (right))
#endif
#if !defined (MAX)
#define	MAX(left,right)		(((left) > (right))? (left) : (right))
#endif
#define	ASSERT(x)

#include "ImeDocP.h"

/*========================================================================
 *	  Structures
 */
typedef struct tagKEYEVENT {
	WPARAM		_wParam ;
	LPARAM		_lParam ;
}	KEYEVENT ;

typedef struct _tagCANDFORM {
	HWND				hWnd ;
	DWORD				dwIndex ;
	DWORD				dwStyle ;
}	MYCANDFORM, NEAR* PMYCANDFORM, FAR* LPMYCANDFORM ;

typedef struct _tagMYCOMPSTR {
	/*	Windows �Ƃ̂����ŕK�v�ȍ\���� COMPOSITIONSTRING */
	COMPOSITIONSTRING	cs ;
	/*	COMPOSITIONSTRING �̒�����Q�Ƃ����f�[�^�̎��́B*/
	MYCHAR				szCompReadStr		[MAXCOMPSIZE] ;
	BYTE				bCompReadAttr		[MAXCOMPSIZE] ;
	DWORD				dwCompReadClause	[MAXCLAUSESIZE] ;
	MYCHAR				szCompStr			[MAXCOMPSIZE] ;
	BYTE				bCompAttr			[MAXCOMPSIZE] ;
	DWORD				dwCompClause		[MAXCLAUSESIZE] ;
	char				szTypeInfo			[MAXCOMPSIZE] ;
	MYCHAR				szResultReadStr		[MAXCOMPSIZE] ;
	DWORD				dwResultReadClause	[MAXCOMPSIZE] ;
	MYCHAR				szResultStr			[MAXCOMPSIZE] ;
	DWORD				dwResultClause		[MAXCOMPSIZE] ;
	/*	SKKUI ��񋟂��邽�߂ɕK�v�ȃf�[�^(���?)�B*/
	struct CImeDoc		_Doc ;
	KEYEVENT			_KeyEvent ;
	BOOL				_fComposing ;
	BOOL				_bCandMode ;
	DWORD				dwUpdateFlag ;
	DWORD				dwShowStyle ;
	MYCANDFORM			cfCandBase ;		/* default candform[0] */
}	MYCOMPSTR, NEAR *PMYCOMPSTR, FAR *LPMYCOMPSTR ;

typedef struct _tagMYCAND{
	CANDIDATEINFO		ci ;
	CANDIDATELIST		cl ;
	DWORD				offset [MAXCANDSTRNUM] ;
	TCHAR				szCand [MAXCANDSTRNUM][MAXCANDSTRSIZE] ;
}	MYCAND, NEAR *PMYCAND, FAR *LPMYCAND ;

typedef struct _tagMYPRIVATE {
	DWORD				m_dwSize ;
}	MYPRIVATE, NEAR *PMYPRIVATE, FAR *LPMYPRIVATE ;

typedef struct _tagUICHILD{
	HWND				hWnd ;
	BOOL				bShow ;
	POINT				pt ;
}	UICHILD, NEAR *PUICHILD, FAR *LPUICHILD ;

typedef struct _tagUICHILD2{
	HWND				hWnd ;
	BOOL				bShow ;
	RECT				rc ;
}	UICHILD2, NEAR *PUICHILD2, FAR *LPUICHILD2 ;

typedef struct _tagUIEXTRA{
	HIMC				hIMC ;
	UICHILD				uiStatus ;
	UICHILD				uiCand ;
	DWORD				dwCompStyle ;
	DWORD				dwShowStyle ;
	HFONT				hFont ;
	BOOL				bVertical ;
	UICHILD				uiDefComp ;
	UICHILD2			uiComp [MAXCOMPWND] ;
	UICHILD2			uiGuide ;
}	UIEXTRA, NEAR *PUIEXTRA, FAR *LPUIEXTRA ;

typedef struct _tagMYGUIDELINE{
	DWORD				dwLevel ;
	DWORD				dwIndex ;
	DWORD				dwStrID ;
	DWORD				dwPrivateID ;
}	MYGUIDELINE, NEAR *PMYGUIDELINE, FAR *LPMYGUIDELINE ;

typedef struct _tagMYVARTYPEPAIR {
	LPVOID				m_lpVariable ;
	int					m_iType ;
}	MYVARTYPEPAIR, NEAR *pMYVARTYPEPAIR, FAR *LPMYVARTYPEPAIR ;

typedef struct _tagMYMSGFUNCPAIR {
	UINT				m_uMsg ;
	LRESULT				(*m_pFunction)(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) ;
}	MYMSGFUNCPAIR, NEAR *PMYMSGFUNCPAIR, FAR *LPMYMSGFUNCPAIR ;

typedef struct _tagMYMENUTITEMINFO {
	UINT				m_fMask ;
	UINT				m_fType ;
	DWORD				m_wID ;
	LPTSTR				m_dwTypeData ;
}	MYMENUITEMINFO, NEAR *PMYMENUITEMINFO, FAR *LPMYMENUITEMINFO ;

typedef struct _tagMYMENUTITEMINFOEX {
	UINT				m_fMask ;
	UINT				m_fType ;
	DWORD				m_wID ;
	LPTSTR				m_dwTypeData ;
	DWORD				(*m_pGetStateProc)(void) ;
}	MYMENUITEMINFOEX, NEAR *PMYMENUITEMINFOEX, FAR *LPMYMENUITEMINFOEX ;

typedef struct _tagMYSTRTYPEPAIR {
	DWORD				m_wID ;
	LPCMYSTR			m_lpString ;
}	MYSTRTYPEPAIR, NEAR *PMYSTRTYPEPAIR, FAR *LPMYSTRTYPEPAIR ;

typedef struct _tagMYSTRTYPEPAIREX {
	DWORD				m_wID ;
	DWORD				m_dwType ;
	LPCMYSTR			m_lpString ;
}	MYSTRTYPEPAIREX, NEAR *PMYSTRTYPEPAIREX, FAR *LPMYSTRTYPEPAIREX ;

typedef struct _tagMYKANAPAIR {
	LPCMYSTR			m_pKatakana ;
	LPCMYSTR			m_pHiragana ;
	LPCMYSTR			m_pJisx0201 ;
}	MYKANAPAIR, NEAR *PMYKANAPAIR, FAR *LPMYKANAPAIR ;

typedef struct tagMYCOLORFACESET {
	int				m_nTextColor ;
	int				m_nBackColor ;
	int				m_nUnderLineColor ;
	int				m_nUnderLineType ;
}	MYCOLORFACESET ;

/*========================================================================
 *	Global Variables
 */
#ifndef _NO_EXTERN_
extern	HINSTANCE			g_hInst ;
extern	HKL					g_hMyKL ;
extern	LPTRANSMSGLIST		g_lpCurTransKey ;
extern	UINT				g_uNumTransKey ;
extern	BOOL				g_bOverTransKey ;
#if defined(MIXED_UNICODE_ANSI)
extern	WCHAR				g_wszUIClassName		[] ;
#endif
extern	TCHAR				g_szUIClassName			[] ;
extern	TCHAR				g_szCompStrClassName	[] ;
extern	TCHAR				g_szMinibufClassName	[] ;
extern	TCHAR				g_szCandClassName		[] ;
extern	TCHAR				g_szCandAnnotClassName	[] ;
extern	TCHAR				g_szStatusClassName		[] ;
extern	TCHAR				g_szGuideClassName		[] ;
extern	MYGUIDELINE			g_glTable				[] ;

extern	BOOL				g_bSkkImeSecure ;
extern	POINT				g_ptUIStatus ;
#endif //_NO_EXTERN_

/*========================================================================
 *	Function Prototypes
 */
/*   subs.c	 */
void		PASCAL	TSkkIme_vInitCompStr			(LPCOMPOSITIONSTRING, DWORD) ;
void		PASCAL	TSkkIme_vClearCompStr			(LPCOMPOSITIONSTRING, DWORD) ;
void		PASCAL	TSkkIme_vClearCandidate			(LPCANDIDATEINFO) ;
BOOL		PASCAL	TSkkIme_bHasCompStrp			(HIMC) ;
BOOL		PASCAL	TSkkIme_bHasConvertedCompStrp	(HIMC) ;
BOOL		PASCAL	TSkkIme_bHasCandidateListp		(LPINPUTCONTEXT) ;
HKL 		PASCAL	TSkkIme_hGetHKL					(void) ;
void		PASCAL	TSkkIme_vUpdateIndicIcon		(HIMC) ;
HMENU		PASCAL	TSkkIme_hCreateClipboardMenu	(LPMYCOMPSTR) ;
HFONT				TSkkIme_hCheckNativeCharset		(HDC, BOOL*) ;
COLORREF			TSkkIme_crGetImeColor			(HWND, int) ;
HBRUSH				TSkkIme_hbrGetImeLineBrush		(HWND, int, int, COLORREF*, HBITMAP*, int*) ;
BOOL		PASCAL	IsCrossRectangle				(LPPOINT, LPSIZE, LPRECT) ;
int			PASCAL	iGetConversionModeFromHIMC		(HIMC) ;
int			PASCAL	iGetConversionModeFromLPIMC		(LPINPUTCONTEXT) ;
BOOL		PASCAL	ChangeConversionMode			(HIMC, int) ;
BOOL		PASCAL	ChangeConversionModeWithIDM		(HIMC, int) ;

/*	tstring.c */
void	PASCAL		lmemset			(LPBYTE, BYTE, UINT) ;
void	PASCAL		Myltoa			(LPMYSTR, long) ;
long	PASCAL		Myatol			(LPMYSTR) ;
LPMYSTR	PASCAL		Myctime			(LPSYSTEMTIME) ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
int		PASCAL		MylstrcmpW		(LPCWSTR, LPCWSTR) ;
int		PASCAL		MylstrcpyW		(LPWSTR, LPCWSTR) ;
int		PASCAL		MylstrcatW		(LPWSTR, LPCWSTR) ;
int		PASCAL		MylstrncmpW		(LPCWSTR, LPCWSTR, int) ;
int		PASCAL		MylstrncpyW		(LPWSTR, LPCWSTR, int) ;
int		PASCAL		MylstrncatW		(LPWSTR, LPCWSTR, int) ;
LPWSTR	PASCAL		MyCharPrevW		(LPWSTR, LPWSTR) ;
LPWSTR	PASCAL		MyCharNextW		(LPWSTR) ;
LPWSTR	PASCAL		MylstrcpynW		(LPWSTR, LPWSTR, int) ;
#if defined (MIXED_UNICODE_ANSI)
int		PASCAL		MystrToShiftJis	(LPTSTR, int, LPCMYSTR, int) ;
int		PASCAL		shiftJisToMystr	(LPMYSTR, int, LPCSTR, int) ;
#endif
#else
int		PASCAL		MylstrncmpA		(LPMYSTR, LPMYSTR, int) ;
int		PASCAL		MylstrncpyA		(LPMYSTR, LPMYSTR, int) ;
int		PASCAL		MylstrncatA		(LPMYSTR, LPMYSTR, int) ;
#endif
void	PASCAL		Mysnprintf		(LPTSTR, int, LPCTSTR,...) ;

/*   toascii.c   */
BOOL	PASCAL		GenerateMessageToTransKey	(LPTRANSMSGLIST, LPTRANSMSG) ;
BOOL	PASCAL		GenerateOverFlowMessage		(LPTRANSMSGLIST) ;

/*   input.c	 */
BOOL	PASCAL		IMEKeydownHandler			(HIMC, WPARAM, LPARAM, LPBYTE, BOOL) ;
BOOL	PASCAL		IMEKeyupHandler				(HIMC, WPARAM, LPARAM, LPBYTE, BOOL) ;

/*   ui.c		*/
BOOL	PASCAL		IMERegisterClass			(HANDLE) ;
LRESULT	CALLBACK	SKKIMEWndProc				(HWND, UINT, WPARAM, LPARAM) ;
void	PASCAL		DrawUIBorder				(LPRECT) ;
void	PASCAL		DragUI						(HWND, UINT, WPARAM, LPARAM) ;
BOOL	PASCAL		GetCompFontMetrics			(LPUIEXTRA, LPTEXTMETRIC) ;

/*	uinotiy.c */
LRESULT	PASCAL 		TSkkImeWnd_lOnImeNotify		(HIMC, HWND, UINT, WPARAM, LPARAM) ;

/*	uictrl.c */
LONG	PASCAL		TSkkImeWnd_lOnImeControl	(HIMC, HWND, UINT, WPARAM, LPARAM) ;

/*   uistate.c   */
LRESULT	CALLBACK	UIStatus_WndProc			(HWND, UINT, WPARAM, LPARAM) ;
BOOL	PASCAL		MyIsIMEMessage				(UINT) ;
void	PASCAL		UIStatus_Update				(LPUIEXTRA) ;
void	PASCAL		UIStatus_Move				(LPUIEXTRA, const POINTS*) ;
void	PASCAL		UIStatus_AdjustPosition		(LPUIEXTRA) ;
void	PASCAL		UIStatus_Show				(LPUIEXTRA) ;

/* uicand.c	  */
LRESULT	CALLBACK	UICand_WndProc				(HWND, UINT, WPARAM, LPARAM) ;
void	PASCAL		UICand_Paint				(HWND hCandWnd) ;
void	PASCAL		UICand_Create				(HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
BOOL	PASCAL		UICand_GetPosFromCompWnd	(LPUIEXTRA, LPPOINT) ;
BOOL	PASCAL		UICand_GetPosFromCompForm	(LPINPUTCONTEXT, LPUIEXTRA, LPPOINT) ;
void	PASCAL		UICand_Hide					(LPUIEXTRA) ;
void	PASCAL		UICand_Move					(HWND, LPINPUTCONTEXT, LPUIEXTRA, BOOL) ;
LRESULT	CALLBACK	UIAnnot_WndProc				(HWND, UINT, WPARAM, LPARAM) ;

/* uicomp.c	  */
LRESULT	CALLBACK	UIComp_WndProc				(HWND, UINT, WPARAM, LPARAM) ;
void	PASCAL		UIComp_Paint				(HWND) ;
void	PASCAL		UIComp_Create				(HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
void	PASCAL		UIComp_Move					(HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
void	PASCAL		UIComp_Hide					(LPUIEXTRA) ;
void	PASCAL		UIComp_SetFont				(LPUIEXTRA lpUIExtra) ;

/* uiminibuf.c */
LRESULT	CALLBACK	UIMinibuf_WndProc			(HWND, UINT, WPARAM, LPARAM) ;
void	PASCAL		UIMinibuf_Create			(HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
void	PASCAL		UIMinibuf_Move				(HWND, LPUIEXTRA, LPINPUTCONTEXT) ;
void	PASCAL		UIMinibuf_Hide				(LPUIEXTRA) ;
void	PASCAL		UIMinibuf_NotifyComposition	(HWND, LPUIEXTRA, LPINPUTCONTEXT) ;

/*	config.c	*/
BOOL					TSkkIme_bIsHideToolbarp		(void) ;
void					TSkkIme_vUpdateConfig		(HIMC) ;

/* DIC.C		 */ 
BOOL	PASCAL			MakeGuideLine				(HIMC, DWORD) ;
BOOL	PASCAL			MakeInfoGuideLine			(HIMC, LPCMYSTR, int, int) ;
BOOL	PASCAL			GenerateMessage				(HIMC, LPINPUTCONTEXT, LPTRANSMSGLIST, LPTRANSMSG) ;

/* skkui.c */
BOOL	PASCAL			TSkkIme_bHandleKeyDown		(HIMC, WPARAM, LPARAM, LPBYTE, BOOL) ;
BOOL	PASCAL			TSkkIme_bHandleKeyUp		(HIMC, WPARAM, LPARAM, LPBYTE, BOOL) ;
BOOL	PASCAL			TSkkIme_bStartConversion	(HIMC, LPINPUTCONTEXT) ;
BOOL					TSkkIme_bUpdateComposition	(HIMC, LPINPUTCONTEXT, LPCOMPOSITIONSTRING) ;

/* skksubs.c */
BOOL	PASCAL		TSkkIme_bSetConversionMode		(HIMC, DWORD) ;
DWORD	PASCAL		TSkkIme_dwGetConversionMode		(HIMC) ;
BOOL	PASCAL		TSkkIme_bUpdateConversionMode	(HIMC) ;
BOOL	PASCAL		TSkkIme_bNotifyChangeConversionMode	(HIMC) ;
BOOL				TSkkIme_bCompleteString			(HIMC, LPINPUTCONTEXT) ;
BOOL				TSkkIme_bConvertString			(HIMC, LPINPUTCONTEXT) ;
BOOL				TSkkIme_bRevertString			(HIMC, LPINPUTCONTEXT) ;
BOOL				TSkkIme_bOpenCandidate			(HIMC, LPINPUTCONTEXT) ;
BOOL				TSkkIme_bSelectCandidateStr		(HIMC, LPINPUTCONTEXT, int) ;
BOOL				TSkkIme_bSetCandidatePageStart	(HIMC, LPINPUTCONTEXT, int) ;
int					TSkkIme_bHasWordAnnotationp		(LPCMYSTR, int) ;
BOOL				TSkkIme_bSetReconvertStr		(HIMC, LPINPUTCONTEXT, LPCOMPOSITIONSTRING, LPRECONVERTSTRING, BOOL) ;
void	PASCAL		TSkkIme_vFlushText				(HIMC hIMC) ;
void	PASCAL		TSkkIme_vCloseText				(HIMC hIMC) ;

/* Mutex.c */
HANDLE	PASCAL			TSkkIme_hCreateMutex		(LPCTSTR pMutexName) ;

/* registry.c */
BOOL	PASCAL		GetRegDwordValue	(LPCTSTR, LPCTSTR, LPDWORD) ;
long	PASCAL		GetRegStringValue	(LPCTSTR, LPCTSTR, LPTSTR) ;
BOOL	PASCAL		SetRegDwordValue	(LPCTSTR, LPCTSTR, DWORD) ;
BOOL	PASCAL		SetRegStringValue	(LPCTSTR, LPCTSTR, LPTSTR) ;

/* FDEBUG.C	  */
void	PASCAL		DebugPrintf (LPCTSTR, ...) ;
void	PASCAL		DebugPrintfToFile (LPCTSTR, ...) ;
void				DebugDump	(LPCTSTR, LPCTSTR, int) ;
void				DebugDumpRS	(LPRECONVERTSTRING) ;

/* tsf.cpp */
#if !defined (NO_TSF)
BOOL	PASCAL		bTSF_InitLanguageBar	(void) ;
BOOL	PASCAL		bTSF_IsTSFEnabled		(void) ;
BOOL	PASCAL		bTSF_DoesThreadMgrExistp(void) ;
BOOL	PASCAL		bTSF_UpdateLanguageBar	(HIMC) ;
void	PASCAL		vTSF_ActivateLanguageBar(HIMC, BOOL) ;
BOOL	PASCAL		bTSF_ShowKeyboardIcon	(BOOL) ;
void	PASCAL		vTSF_UninitLanguageBar	(void) ;
#endif

#undef DEBUG_LV
#if !defined (DEBUG_LV)
#define	DEBUG_LV	1
#endif
#if defined (DEBUG) || defined (DBG)
#define	DEBUGPRINTF(arg)			DebugPrintf##arg
#define	DEBUGPRINTFEX(level,arg)	if((level) >= DEBUG_LV) DebugPrintf##arg
#else
#define	DEBUGPRINTF(arg)			/* arg */
#define	DEBUGPRINTFEX(level,arg)	/*if((level) >= DEBUG_LV) DebugPrintfToFile##arg*/
#endif

__inline	struct CImeDoc*
GetDocumentFromCompStr (
	LPCOMPOSITIONSTRING		lpCompStr)
{
	return	&((LPMYCOMPSTR)lpCompStr)->_Doc ;
}

