#pragma once

#include "dchar.h"
#include "ImeBuffer.h"

struct CSkkRuleTreeNode ;

struct CSkkRuleTreeIterator {
	struct CSkkRuleTreeNode*	m_pSkkRuleTree ;
	int							m_iTree ;
	DCHAR						m_bufPrefix [MAXCOMPLEN] ;
	int							m_nPrefixLength ;
	int							m_iPreviousSelectBranchChar ;
} ;

/*	prototypes
 */
void	SkkRuleTreeIterator_vInit (struct CSkkRuleTreeIterator* piteRuleTree) ;
void	SkkRuleTreeIterator_vReset (struct CSkkRuleTreeIterator* piteRuleTree) ;
const DCHAR*	SkkRuleTreeIterator_pGetPrefix (struct CSkkRuleTreeIterator* piteRuleTree, int* pnLength)  ;
BOOL	SkkRuleTreeIterator_bHavePrefixp (const struct CSkkRuleTreeIterator* piteRuleTree) ;
int		SkkRuleTreeIterator_iGetRuleTree (struct CSkkRuleTreeIterator* piteRuleTree) ;
BOOL	SkkRuleTreeIterator_bRootp (struct CSkkRuleTreeIterator* piteRuleTree) ;
void	SkkRuleTreeIterator_vMoveToRoot (struct CSkkRuleTreeIterator* piteRuleTree) ;
void	SkkRuleTreeIterator_vMoveTree (struct CSkkRuleTreeIterator* piteRuleTree, int iTree) ;
BOOL	SkkRuleTreeIterator_bHaveSelectBranchp (struct CSkkRuleTreeIterator* piteRuleTree, int wch) ;
BOOL	SkkRuleTreeIterator_bNextHasBranchListp (struct CSkkRuleTreeIterator* piteRuleTree, int wch) ;
const struct CSkkRuleTreeNodeOutput*	SkkRuleTreeIterator_pGetOutput (struct CSkkRuleTreeIterator* piteRuleTree) ;
BOOL	SkkRuleTreeIterator_bHaveNextState (struct CSkkRuleTreeIterator* piteRuleTree) ;
int		SkkRuleTreeIterator_iGetNextState (struct CSkkRuleTreeIterator* piteRuleTree, LPDSTR pwBuffer, int nBufferSize, int* pnNextTree) ;
void	SkkRuleTreeIterator_vWalk (struct CSkkRuleTreeIterator* piteRuleTree, int wch) ;

