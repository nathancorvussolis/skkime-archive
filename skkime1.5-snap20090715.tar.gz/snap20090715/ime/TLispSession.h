#pragma once

#include "dchar.h"
#include "TCommuSession.h"

BOOL	TLispSession_bSetNumberList (LPCDSTR wstrNumberList) ;
BOOL	TLispSession_bEval (LPCDSTR wstrHenkanKey, int nstrHenkanKey, LPDSTR wstrDest, int nstrDest) ;

