#pragma once

#include "dchar.h"

struct tagTVarbuffer ;
struct _tagMYCAND ;

/*=================================================================================
 *	definitions or typedefs for external usage
 */
enum {
	GC_EGG_LIKE_NEWLINE	= 0,
	GC_DELETE_IMPLIES_KAKUTEI,
	GC_USE_NUMERIC_CONVERSION,
	GC_DABBREV_LIKE_COMPLETION,
	GC_KATAKANA_HIRAGANA_HENKAN,
	GC_STYLE,
	GC_DATE_AD,
	GC_SHOW_ANNOTATION,
	GC_KAKUTEI_EARLY,
	GC_PROCESS_OKURI_EARLY,
	GC_DELETE_OKURI_WHEN_QUIT,
	NUMGENERICCONFIG
} ;

enum {
	IMECMODE_HIRAGANA	= 0,
	IMECMODE_KATAKANA,
	IMECMODE_ZENKAKU,
	IMECMODE_HANKANA,
	IMECMODE_HANKANA_ROMAN,
	IMECMODE_ASCII,
	IMECMODE_OFF,
	NUM_IMECMODE,
} ;

/*	document ���̍X�V���B
 */
enum {
	IMEDOC_UPDATE_CURSOR			= 1 << 0,
	IMEDOC_UPDATE_COMPOSITIONSTRING	= 1 << 1,
	IMEDOC_UPDATE_RESULT			= 1 << 2,
	IMEDOC_UPDATE_UNPROCESSKEY		= 1 << 3,
	IMEDOC_CREATE_CANDIDATELIST		= 1 << 4,
	IMEDOC_UPDATE_CANDIDATELIST		= 1 << 5,
	IMEDOC_CLOSE_CANDIDATELIST		= 1 << 6,
	IMEDOC_UPDATE_CONVERSIONMODE	= 1 << 7,
	IMEDOC_CHECK_NEWLINE			= 1 << 8,
	IMEDOC_NEWLINE					= 1 << 9,
} ;

#define	IMEDOC_NUMHENKANSHOWCANDIDATES		256
#define	IMEDOC_MAXCANDPAGESIZE				IMEDOC_NUMHENKANSHOWCANDIDATES

/*=================================================================================
 *	definitions or typedefs for internal usage
 */
struct CImeBuffer ;
struct CImeDoc ;
struct LMREG ;
struct TMSG ;

typedef int		(*PLMFUNC)(struct CImeDoc*) ;

enum {
	LMSIGNAL_NONE	= 0,
	LMSIGNAL_QUIT,
	LMSIGNAL_ERROR,
	LMSIGNAL_ABORT,
	LMSIGNAL_EXIT_MINIBUFFER,
	LMSIGNAL_ABORT_RECURSIVE_EDIT,
} ;

enum {
	LMR_STOP,
	LMR_CONTINUE,
	LMR_RETURN,
	LMR_ERROR,
} ;

enum {
	LMREG_0	= 0,	LMREG_1,	LMREG_2,	LMREG_3,	LMREG_4,	LMREG_5,	LMREG_6,	LMREG_7,
	LMREGARG_0,		LMREGARG_1,	LMREGARG_2,	LMREGARG_3,	LMREGARG_4,	LMREGARG_5,	LMREGARG_6,	LMREGARG_7,
	LMREGARG_RETVAL,
	MAX_REGS,
} ;

#define	WM_LM_COMMAND	(WM_USER+113)

/*=================================================================================
 *	prototypes
 */
#if defined (__cplusplus)
extern "C" {
#endif

/*=================================================================================
 *	ImeDoc �̊O�� interface 
 */
BOOL				ImeDoc_bInit				(struct CImeDoc*) ;
void				ImeDoc_vUninit				(struct CImeDoc*) ;
void				ImeDoc_vClear				(struct CImeDoc*) ;
LPCDSTR				ImeDoc_pGetPreeditText		(struct CImeDoc*, int*) ;
BOOL				ImeDoc_bGetPreeditCursor	(const struct CImeDoc*, int*) ;
#if defined (UNITTEST)
LPCDSTR				ImeDoc_pGetStatusText		(struct CImeDoc*, int*) ;
#else
struct _tagMYCAND*	ImeDoc_pGetStatusText		(struct CImeDoc*, DWORD*) ;
#endif
BOOL				ImeDoc_bGetStatusCursor		(const struct CImeDoc*, int*) ;
BOOL				ImeDoc_bIsStatusActivep		(const struct CImeDoc*) ;
BOOL				ImeDoc_bQueryFilterEvent	(struct CImeDoc*, const struct TMSG*, BOOL*) ;
BOOL				ImeDoc_bFilterEvent			(struct CImeDoc*, const struct TMSG*) ;

BOOL				ImeDoc_bQueryToggleIMEEvent	(struct CImeDoc*, const struct TMSG*, BOOL*) ;
int					ImeDoc_iGetReadingText		(struct CImeDoc*, LPDSTR, int, int, int*) ;
BOOL				ImeDoc_bSetConversionMode	(struct CImeDoc*, int) ;
int					ImeDoc_iGetConversionMode	(struct CImeDoc*) ;
BOOL				ImeDoc_bSetConversionString	(struct CImeDoc*, LPCDSTR, int) ;
BOOL				ImeDoc_bGetSelectedRegion	(struct CImeDoc*, int*, int*) ;
BOOL				ImeDoc_bGetSelectedRegion	(struct CImeDoc*, int*, int*) ;
BOOL				ImeDoc_bGetConvertedRegion	(struct CImeDoc*, int*, int*) ;
BOOL				ImeDoc_bQueryUpdateContext	(struct CImeDoc*, int*, int*, BOOL*) ;
BOOL				ImeDoc_bUpdateContext		(struct CImeDoc*) ;
void				ImeDoc_vUpdateConfig		(struct CImeDoc*) ;
BOOL				ImeDoc_bRevertText			(struct CImeDoc*) ;
BOOL				ImeDoc_bCompleteText		(struct CImeDoc*) ;
void				ImeDoc_vSetUpdateFlag		(struct CImeDoc*, unsigned int) ;
void				ImeDoc_vClearUpdateFlag		(struct CImeDoc*) ;
unsigned int		ImeDoc_uGetUpdateFlag		(struct CImeDoc*) ;

BOOL				ImeDoc_bShowHenkanCandidatesModep	(const struct CImeDoc*) ;
BOOL				ImeDoc_bInputByCodeOrMenuModep		(const struct CImeDoc*, BOOL*) ;
BOOL				ImeDoc_bHaveMessagep		(const struct CImeDoc*) ;
LPCDSTR				ImeDoc_pGetMessage			(const struct CImeDoc*, int*) ;

/*	������ -> �p�ӂ��ׂ��O�� interface
 */
const struct TMSG*	ImeDoc_pGetUnprocessEvent	(struct CImeDoc*) ;


/*=================================================================================
 *	ImeDoc �̓��� interface  
 */
#if !defined (UNITTEST)
struct tagTVarbuffer*	ImeDoc_pGetCandidateInfoBuffer	(struct CImeDoc*) ;
#endif

void				ImeDoc_vSetCurrentBuffer	(struct CImeDoc*, struct CImeBuffer*) ;
struct CImeBuffer*	ImeDoc_pGetCurrentBuffer	(struct CImeDoc*) ;
BOOL				ImeDoc_bGetLastCommandChar	(struct CImeDoc*, DCHAR*) ;
BOOL				ImeDoc_bSetMessage			(struct CImeDoc*, LPCDSTR) ;
BOOL				ImeDoc_bSetMessageW			(struct CImeDoc*, LPCWSTR) ;
BOOL				ImeDoc_bSetMessageN			(struct CImeDoc*, LPCDSTR, int) ;
BOOL				ImeDoc_bSetMessageNW		(struct CImeDoc*, LPCWSTR, int) ;
void				ImeDoc_vClearMessage		(struct CImeDoc*) ;
BOOL				ImeDoc_bRecursiveEditp		(const struct CImeDoc*) ;

BOOL				ImeDoc_bIgnoreMessagep		(const struct TMSG*) ;
BOOL				ImeDoc_bLookupKeymap		(struct CImeDoc*, const struct TMSG*, int*) ;
BOOL				ImeDoc_bWhereIsInternal		(struct CImeDoc*, int nFuncNo, struct TMSG*) ; 
BOOL				ImeDoc_bLookupMajorKeymap	(struct CImeDoc*, const struct TMSG*, int*) ;
PLMFUNC				ImeDoc_pLookupLMState		(struct CImeDoc*, int) ;
int					ImeDoc_iGetCharFromEvent	(const struct TMSG*) ;
int					ImeDoc_iGetLastCommand		(const struct CImeDoc*) ;
BOOL				ImeDoc_bSetLastCommand		(struct CImeDoc*, int nCmd) ;
int					ImeDoc_iGetThisCommand		(const struct CImeDoc*) ;
BOOL				ImeDoc_bSetThisCommand		(struct CImeDoc*, int nCmd) ;
int					ImeDoc_iGetLastCommandChar	(struct CImeDoc*) ;
BOOL				ImeDoc_bSetLastCommandChar	(struct CImeDoc*, int) ;
const struct TMSG*	ImeDoc_pGetLastCommandEvent	(const struct CImeDoc*) ;
BOOL				ImeDoc_bSetUnreadCommandEvent(struct CImeDoc*, const struct TMSG*) ;
BOOL				ImeDoc_bSetUnreadCommandChar(struct CImeDoc*, int) ; 
BOOL				ImeDoc_bEventToCharacter	(const struct TMSG*, int*) ; 
BOOL				ImeDoc_bPushEvent			(struct CImeDoc*, const struct TMSG*) ;
BOOL				ImeDoc_bProcessEventp		(struct CImeDoc*) ;
BOOL				ImeDoc_bUnprocessEvent		(struct CImeDoc*, const struct TMSG*) ;

struct CImeBuffer*	ImeDoc_pCreateBuffer		(struct CImeDoc*, LPCDSTR, int, BOOL) ;
void				ImeDoc_vDeleteUnusedBuffer	(struct CImeDoc*) ;
BOOL				ImeDoc_bDeleteBuffer		(struct CImeDoc*, struct CImeBuffer*) ;

/*	state machine interfaces:
 */
BOOL				ImeDoc_bSignalp				(const struct CImeDoc*) ;
void				ImeDoc_vSetSignalError		(struct CImeDoc*) ;
BOOL				ImeDoc_bSignalMinibuffp		(const struct CImeDoc*) ;
BOOL				ImeDoc_bSignalAbortMinibuffp(const struct CImeDoc*) ;
void				ImeDoc_vClearSignals		(struct CImeDoc*) ;
int					ImeDoc_nGetSignal			(const struct CImeDoc*) ;
void				ImeDoc_vSetSignal			(struct CImeDoc*, int) ;
BOOL				ImeDoc_bCall				(struct CImeDoc*, PLMFUNC, PLMFUNC) ;
void				ImeDoc_vJump				(struct CImeDoc*, PLMFUNC) ;
void*				ImeDoc_pAlloca				(struct CImeDoc*, int, int) ;
void				ImeDoc_vSetRegString		(struct CImeDoc*, int, LPDSTR, int) ;
void				ImeDoc_vSetRegConstString	(struct CImeDoc*, int, LPCDSTR, int) ;
void				ImeDoc_vSetRegBool			(struct CImeDoc*, int, BOOL) ;
void				ImeDoc_vSetRegInteger		(struct CImeDoc*, int, int) ;
void				ImeDoc_vSetRegPointer		(struct CImeDoc*, int, void*) ;
void				ImeDoc_vSetRegConstPointer	(struct CImeDoc*, int, const void*) ;
void				ImeDoc_vSetRegMsg			(struct CImeDoc*, int, const struct TMSG*) ;
void				ImeDoc_vSetRegNil			(struct CImeDoc*, int) ;
BOOL				ImeDoc_bGetRegBool			(struct CImeDoc*, int, BOOL*) ;
BOOL				ImeDoc_bGetRegInteger		(struct CImeDoc*, int, int*) ;
BOOL				ImeDoc_bGetRegString		(struct CImeDoc*, int, LPDSTR*, int*) ;
BOOL				ImeDoc_bGetRegConstString	(struct CImeDoc*, int, LPCDSTR*, int*) ;
BOOL				ImeDoc_bGetRegConstStringPair	(struct CImeDoc*, int, LPCDSTR*, int*, LPCDSTR*, int*) ;
BOOL				ImeDoc_bGetRegPointer		(struct CImeDoc*, int, void**) ;
BOOL				ImeDoc_bGetRegConstPointer	(struct CImeDoc*, int, const void**) ;
BOOL				ImeDoc_bGetRegMsg			(struct CImeDoc*, int, struct TMSG*) ;
BOOL				ImeDoc_bIsRegNilp			(const struct CImeDoc*, int) ;
struct LMREG*		ImeDoc_pGetRegValue			(struct CImeDoc*, int) ;
BOOL				ImeDoc_bPushReg				(struct CImeDoc*, int) ;
void				ImeDoc_vPopReg				(struct CImeDoc*, int) ;
LPDSTR				ImeDoc_pGetReturnBuffer		(struct CImeDoc*, int*) ;
int					ImeDoc_iGetMinibufferDepth	(struct CImeDoc*) ;

/*	configuration:
 */
BOOL				ImeDoc_bShowHenkanCandidatesModep	(const struct CImeDoc*) ;
BOOL				ImeDoc_bInputByCodeOrMenuModep		(const struct CImeDoc*, BOOL*) ;
BOOL				ImeDoc_bSkkPreviousCandidateCharp	(struct CImeDoc*, int) ;

#if defined (__cplusplus)
}
#endif



