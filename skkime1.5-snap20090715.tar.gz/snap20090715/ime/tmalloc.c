#include <windows.h>
#include <assert.h>
#include <tchar.h>
#if defined (DEBUG_TINYMALLOC)
#include <stdio.h>
#endif
#include "tmalloc.h"

#define	TINYMEMBLOCK_UNIT_BIT		(4)
#define	TINYMEMBLOCK_UNIT_SIZE		(1 << TINYMEMBLOCK_UNIT_BIT)
#define	TINYMEMBLOCK_UNIT_MASK		(TINYMEMBLOCK_UNIT_SIZE - 1)

#define	TINYMEMBLOCK_NEXT(pBlock)	((BYTE*)(pBlock) + (((pBlock)->m_nBlock + 1) << TINYMEMBLOCK_UNIT_BIT))
#define	TINYMEMBLOCK_PTR(pBlock)	((BYTE*)(pBlock) + TINYMEMBLOCK_UNIT_SIZE)

typedef struct tagTINYMEMBLOCK {	/* 16byte */
	struct tagTINYMEMBLOCK*	m_pPrev ;		/* �O�̃u���b�N�B*/
	struct tagTINYMEMBLOCK*	m_pNext ;		/* ���̃u���b�N�B*/
	int						m_nBlock ;		/* ���p����Ă���u���b�N���B*/
}	TINYMEMBLOCK ;

#if defined (DEBUG_TINYMALLOC)
static	BOOL	tinyMalloc_checkPointer(TINYMEMMGR*, TINYMEMBLOCK*) ;
#endif
static	void*	tinyMalloc_findBlock	(TINYMEMMGR*, TINYMEMBLOCK*, int) ;
static	void	tinyMalloc_mergeBlock	(TINYMEMBLOCK*, TINYMEMBLOCK*) ;
#if defined (DEBUG_TINYMALLOC)
static	BOOL	tinyMalloc_leakcheck	(TINYMEMMGR*, int) ;
#endif
#if defined (DEBUG_TINYMALLOC)
static	void	tinyMalloc_showBlock	(TINYMEMBLOCK*) ;
#endif

BOOL
TinyMalloc_Initialize (
	register TINYMEMMGR*	pMemMgr,
	register void*			pMemoryArea,
	register size_t			nMemoryArea)
{
	register TINYMEMBLOCK*	pBlock ;
	register int			nBlock ;

	nBlock	= (nMemoryArea >> TINYMEMBLOCK_UNIT_BIT) ;
	if (nBlock <= 0)
		return	FALSE ;

	pBlock	= (TINYMEMBLOCK *)pMemoryArea ;
	pBlock->m_nBlock			= nBlock - 1 ;
	pBlock->m_pPrev				= NULL ;
	pBlock->m_pNext				= NULL ;
	pMemMgr->m_lstAllocBlock	= NULL ;
	pMemMgr->m_lstFreeBlock		= pBlock ;
#if defined (DEBUG_TINYMALLOC)
	pMemMgr->m_pvMemoryArea		= pMemoryArea ;
	pMemMgr->m_nMemoryArea		= nMemoryArea ;
#endif
	return	TRUE ;
}

void
TinyMalloc_Uninitialize (
	register TINYMEMMGR*	pMemMgr)
{
	return ;
	UNREFERENCED_PARAMETER (pMemMgr) ;
}

void*
TinyMalloc_Malloc (
	register TINYMEMMGR*	pMemMgr,
	register size_t			nRequest)
{
	register TINYMEMBLOCK*	pBlock ;
	register int			nRequestBlock ;

	if (nRequest <= 0)
		return	NULL ;

	nRequestBlock	= (nRequest + TINYMEMBLOCK_UNIT_SIZE - 1) >> TINYMEMBLOCK_UNIT_BIT ;
	pBlock			= pMemMgr->m_lstFreeBlock ;
	/*	�߂������Ƃɐ擪�����v������̂�T���Ƃ�����肾�B�ܘ_�A���t������
	 *	���_�Ō����͏I������̂ŁA�������u���b�N�����t����R�X�g�� O(n) ����
	 *	����Ȃ�ɂ͏������Ǝv���B���ǁA�������̗��p�����͍ň��c�B*/
	while (pBlock != NULL) {
		if (pBlock->m_nBlock >= nRequestBlock) 
			return	tinyMalloc_findBlock (pMemMgr, pBlock, nRequestBlock) ;
		pBlock	= pBlock->m_pNext ;
	}
	/*	out of memory */
	return	NULL ;
}

/*	�m�ۂ���Ă��郁�����̈���������B
 */
BOOL
TinyMalloc_Free (
	register TINYMEMMGR*	pMemMgr,
	register void*			pvMemory)
{
	register TINYMEMBLOCK*	pBlock ;
	register TINYMEMBLOCK*	pNode ;
	register TINYMEMBLOCK*	pPrevNode ;
	
	assert (pMemMgr != NULL) ;

	if (pvMemory == NULL)
		return	TRUE ;

	pBlock	= (TINYMEMBLOCK *)((BYTE *)pvMemory - TINYMEMBLOCK_UNIT_SIZE) ;
	/*	�������|�C���^���ǂ������`�F�b�N����B*/
#if defined (DEBUG_TINYMALLOC)
	if (! tinyMalloc_checkPointer (pMemMgr, pBlock)) {
		_tprintf (TEXT ("error: invalid block\n")) ;
		return	FALSE ;
	}
#endif
	if (pBlock->m_pPrev != NULL) {
		pBlock->m_pPrev->m_pNext	= pBlock->m_pNext ;
	} else {
		assert (pMemMgr->m_lstAllocBlock == pBlock) ;
		pMemMgr->m_lstAllocBlock	= pBlock->m_pNext ;
	}
	if (pBlock->m_pNext != NULL) 
		pBlock->m_pNext->m_pPrev	= pBlock->m_pPrev ;
	pBlock->m_pPrev	= NULL ;
	pBlock->m_pNext	= NULL ;

	pNode		= pMemMgr->m_lstFreeBlock ;
	pPrevNode	= NULL ;
	while (pNode != NULL && pNode < pBlock) {
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
	}
	if (pPrevNode == NULL) {
		pMemMgr->m_lstFreeBlock	= pBlock ;
	} else {
		pPrevNode->m_pNext		= pBlock ;
	}
	pBlock->m_pPrev	= pPrevNode ;
	if (pNode != NULL) 
		pNode->m_pPrev	= pBlock ;
	pBlock->m_pNext	= pNode ;

	/*	�������d�v�BmergeBlock ��2�Ԗڂ̈����̃u���b�N����������
	 *	�\��������̂ŁApBlock �͍ŏ���1�����ɁA���ɑ�2������
	 *	����Ȃ��Ƃ����Ȃ��B
	 */
	if (pNode != NULL)
		tinyMalloc_mergeBlock (pBlock,    pNode) ;
	if (pPrevNode != NULL)
		tinyMalloc_mergeBlock (pPrevNode, pBlock) ;
#if defined (DEBUG_TINYMALLOC)
	tinyMalloc_leakcheck (pMemMgr, __LINE__) ;
#endif
	return	TRUE ;
}

#if defined (DEBUG_TINYMALLOC)
BOOL
tinyMalloc_checkPointer (
	register TINYMEMMGR*	pMemMgr,
	register TINYMEMBLOCK*	pBlock)
{
	register TINYMEMBLOCK*	pNode ;

	pNode	= pMemMgr->m_lstAllocBlock ;
	while (pNode != NULL && pNode != pBlock) 
		pNode	= pNode->m_pNext ;
	return	(pNode == pBlock) ;
}
#endif

/*	�m�ۂ��郁�����u���b�N�����t���������̏����B
 */
void*
tinyMalloc_findBlock (
	register TINYMEMMGR*	pMemMgr,
	register TINYMEMBLOCK*	pBlock,
	register int			nRequestBlock)
{
#if defined (DEBUG_TINYMALLOC)
	register BOOL	fDivide	= FALSE ;
#endif
	assert (pBlock->m_nBlock >= nRequestBlock) ;

#if defined (DEBUG_TINYMALLOC)
	tinyMalloc_leakcheck (pMemMgr, __LINE__) ;

	if (pBlock->m_pPrev)
		tinyMalloc_showBlock (pBlock->m_pPrev) ;
	tinyMalloc_showBlock (pBlock) ;
	if (pBlock->m_pNext)
		tinyMalloc_showBlock (pBlock->m_pNext) ;
#endif

	if (pBlock->m_nBlock > (nRequestBlock + 1)) {
		register TINYMEMBLOCK*	pNewBlock ;
		register int			nNewBlockSize ;
		register int			nRealSize ;

		/*	�u���b�N�����������ƁA�Ǘ��p��1�P�ʃ�������]����
		 *	����邱�ƂɂȂ�B����āA�v�����ꂽ�P�� + 1 ����
		 *	�����Ă��Ȃ��Ƃ����Ȃ��B
		 */
		nRealSize		= TINYMEMBLOCK_UNIT_SIZE * (1 + nRequestBlock) ;
		pNewBlock		= (TINYMEMBLOCK *)((BYTE *)pBlock + nRealSize) ;
		nNewBlockSize	= pBlock->m_nBlock - (nRequestBlock + 1) ;
		
		pNewBlock->m_nBlock	= nNewBlockSize ;
		pBlock->m_nBlock	= nRequestBlock ;

		pNewBlock->m_pNext	= pBlock->m_pNext ;
		if (pBlock->m_pNext != NULL)
			pBlock->m_pNext->m_pPrev	= pNewBlock ;
		pBlock->m_pNext		= pNewBlock ;
		pNewBlock->m_pPrev	= pBlock ;
#if defined (DEBUG_TINYMALLOC)
		tinyMalloc_leakcheck (pMemMgr, __LINE__) ;
		fDivide	= TRUE ;
#endif
	}
	/*	���̃u���b�N�����̂܂܎g����B*/
	if (pBlock->m_pPrev != NULL) {
		pBlock->m_pPrev->m_pNext	= pBlock->m_pNext ;
	} else {
		assert (pMemMgr->m_lstFreeBlock == pBlock) ;
		pMemMgr->m_lstFreeBlock		= pBlock->m_pNext ;
	}
	if (pBlock->m_pNext != NULL)
		pBlock->m_pNext->m_pPrev	= pBlock->m_pPrev ;

	pBlock->m_pPrev = NULL ;
	pBlock->m_pNext	= pMemMgr->m_lstAllocBlock ;
	if (pMemMgr->m_lstAllocBlock != NULL)
		pMemMgr->m_lstAllocBlock->m_pPrev	= pBlock ;
	pMemMgr->m_lstAllocBlock	= pBlock ;
#if defined (DEBUG_TINYMALLOC)
	if (! tinyMalloc_leakcheck (pMemMgr, __LINE__)) {
		tinyMalloc_showBlock (pBlock) ;
		_tprintf (TEXT ("divide = %d\n"), fDivide) ;
		exit (1) ;
	}
#endif
	return	TINYMEMBLOCK_PTR (pBlock) ;
}

void
tinyMalloc_mergeBlock (
	register TINYMEMBLOCK*	pBlock,
	register TINYMEMBLOCK*	pNextBlock)
{
	register void*	pvNextArea ;

	assert (pBlock     != NULL) ;
	assert (pNextBlock != NULL) ;
	assert (pBlock->m_pNext == pNextBlock) ;
	assert (pBlock == pNextBlock->m_pPrev) ;

	pvNextArea		= TINYMEMBLOCK_NEXT (pBlock) ;
	if (pNextBlock != pvNextArea) 
		return ;

	pBlock->m_nBlock	+= (pNextBlock->m_nBlock + 1) ;
	pBlock->m_pNext		= pNextBlock->m_pNext ;
	if (pNextBlock->m_pNext != NULL)
		pNextBlock->m_pNext->m_pPrev	= pBlock ;
	return ;
}

#if defined (DEBUG_TINYMALLOC)
BOOL
tinyMalloc_leakcheck (
	register TINYMEMMGR*	pMemMgr,
	register int			nLine)
{
	register TINYMEMBLOCK*	pBlock ;
	register int			nTotalAlloc, nTotalFree, nRegisteredBlock ;

	nTotalAlloc	= 0 ;
	pBlock		= pMemMgr->m_lstAllocBlock ;
	while (pBlock != NULL) {
		nTotalAlloc	+= (pBlock->m_nBlock + 1) ;
		pBlock		= pBlock->m_pNext ;
	}
	nTotalFree	= 0 ;
	pBlock		= pMemMgr->m_lstFreeBlock ;
	while (pBlock != NULL) {
		nTotalFree	+= (pBlock->m_nBlock + 1) ;
		pBlock	= pBlock->m_pNext ;
	}
	nRegisteredBlock	= pMemMgr->m_nMemoryArea >> TINYMEMBLOCK_UNIT_BIT ;
	if ((nTotalAlloc + nTotalFree) != nRegisteredBlock) {
		register TINYMEMBLOCK*	pAlloc ;
		register TINYMEMBLOCK*	pPrevAlloc ;
		register TINYMEMBLOCK*	pFree ;
		register TINYMEMBLOCK*	pPrevFree ;

		_tprintf (TEXT ("[%d]TotalAlloc(%d) + nTotalFree(%d), %d != Registered(%d)\n"), nLine, nTotalAlloc, nTotalFree, nTotalAlloc + nTotalFree, nRegisteredBlock) ;
		pPrevAlloc	= NULL ;
		pAlloc		= pMemMgr->m_lstAllocBlock ;
		while (pAlloc != NULL) {
			pPrevFree	= NULL ;
			pFree		= pMemMgr->m_lstFreeBlock ;
			while (pFree != NULL && pAlloc != pFree) {
				pPrevFree	= pFree ;
				pFree		= pFree->m_pNext ;
			}
			if (pAlloc == pFree) {
				_tprintf (TEXT ("Overlap detect (%p, A-Prev:%p, F-Prev:%p)\n"), pAlloc, pPrevAlloc, pPrevFree) ;
				tinyMalloc_showBlock (pAlloc) ;
				if (pPrevAlloc != NULL)
					tinyMalloc_showBlock (pPrevAlloc) ;
				if (pPrevFree  != NULL)
					tinyMalloc_showBlock (pPrevFree) ;
				break ;
			}
			pPrevAlloc	= pAlloc ;
			pAlloc		= pAlloc->m_pNext ;
		}
		return	FALSE ;
	}
	return	TRUE ;
}
#endif

#if defined (DEBUG_TINYMALLOC)
void
tinyMalloc_showBlock (
	register TINYMEMBLOCK*	pBlock)
{
	_tprintf (TEXT ("Block(%p): Prev(%p), Next(%p), Block(%d)\n"),
			  pBlock, pBlock->m_pPrev, pBlock->m_pNext, pBlock->m_nBlock) ;
	return ;
}
#endif

#if defined (DEBUG_TINYMALLOC) && defined (TEST_TINYMALLOC)
static	void*	spvBlock [1024] ;

int
_tmain (
	register int		nArgc,
	register TCHAR**	ppArgv)
{
	TINYMEMMGR		memmgr ;
	register void*	pvMemory ;
	register int	n, i, request ;

	pvMemory	= HeapAlloc (GetProcessHeap (), 0, 1024 * 1024) ;
	if (! TinyMalloc_Initialize (&memmgr, pvMemory, 1024 * 1024)) {
		_tprintf (TEXT ("fatal: tinymalloc initialize error.\n")) ;
		return	1 ;
	}
	for (i = 0 ; i < sizeof (spvBlock) / sizeof (spvBlock [0]) ; i ++) 
		spvBlock [i]	= NULL ;
	for (i = 0 ; i < 65536 ; i ++) {
		n	= (int)(((float)rand () / (float)RAND_MAX) * (sizeof (spvBlock) / sizeof (spvBlock [0]) - 1)) ;
		if (spvBlock [n] != NULL) {
			_tprintf (TEXT ("[%d] free (%p)\n"), i, spvBlock [n]) ;
			/* bug �� merge �ɂ���B*/
			if (! TinyMalloc_Free (&memmgr, spvBlock [n])) {
				_tprintf (TEXT ("free(%p/%d) failed.\n"), spvBlock [n], n) ;
			}
			spvBlock [n]	= NULL ;
		} else {
			request	= (int)(((float)rand () / (float)RAND_MAX) * 4096.0f) ;
			_tprintf (TEXT ("[%d] n(%d) = malloc (%d)\n"), i, n, request) ;
			spvBlock [n]	= TinyMalloc_Malloc (&memmgr, request) ;
			if (spvBlock [n] != NULL) 
				memset (spvBlock [n], i, request) ;
		}
	}
	HeapFree (GetProcessHeap (), 0, pvMemory) ;
	return	0 ;
}
#endif

