#pragma once

struct TMarker {
	int			m_iPosition ;
	BOOL		m_bCursor ;
	BOOL		m_bValid ;
} ;

BOOL	TMarker_bInit	 		(struct TMarker*, BOOL) ;
int		TMarker_iGetPosition	(const struct TMarker*) ;
BOOL	TMarker_bForward		(struct TMarker*, int) ;
BOOL	TMarker_bBackward		(struct TMarker*, int) ;
BOOL	TMarker_bIsCursor		(const struct TMarker*) ;
BOOL	TMarker_bSetCursor		(struct TMarker*, BOOL) ;
BOOL	TMarker_bIsValidp		(const struct TMarker*) ;
BOOL	TMarker_bSetPosition	(struct TMarker*, const struct TMarker*) ;
void	TMarker_vInvalidate		(struct TMarker*) ;

