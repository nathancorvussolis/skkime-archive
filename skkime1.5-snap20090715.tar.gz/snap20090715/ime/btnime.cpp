#if !defined (NO_TSF)
/*	LanguageBar �́u���͕����H�v�{�^�����i��B
 */
#include "windows.h"
#include "tchar.h"
#include "immdev.h"
extern "C" {
#include "skki1_5.h"
#include "resource.h"
}
#include "msctf_.h"
#include "tsf.h"

#define LANGBAR_ITEM_DESC	L"���͕���" // max 32 chars! �ށA�ő�32�����������B
#define	SKKIME_LANGBARITEMSINK_COOKIE	0x0fab0fac

class	CLangBarItemImeButton ;

typedef struct {
	const WCHAR*	pchDesc ;
	DWORD			(*pfnGetFlag)(CLangBarItemImeButton*) ;
	void			(*pfnHandler)(CLangBarItemImeButton*) ;
}	TSFLBMENUINFOEX ;

enum {
	MENU_ITEM_INDEX_CANCEL		= -1,
	MENU_ITEM_INDEX_HELP,
	MENU_ITEM_INDEX_PROPERTY,
	MENU_ITEM_INDEX_RECONVRESION,
} ;

/*	�c�{�^���̐����� class ���K�v���ƍl����̂��ǂ��������B
 *	�ォ��ǉ����Ȃ��Ƃ����Ȃ����ȁB
 */
class	CLangBarItemImeButton : public ITfLangBarItemButton,
							 public ITfSource
{
public:
	CLangBarItemImeButton () ;
	CLangBarItemImeButton (HIMC hIMC) ;
	~CLangBarItemImeButton () ;

	// IUnknown
	STDMETHODIMP	QueryInterface (REFIID riid, void **ppvObj) ;
	STDMETHODIMP_(ULONG)	AddRef (void) ;
	STDMETHODIMP_(ULONG)	Release (void) ;
	
	// ITfLangBarItem
	STDMETHODIMP	GetInfo (TF_LANGBARITEMINFO *pInfo) ;
	STDMETHODIMP	GetStatus (DWORD *pdwStatus) ;
	STDMETHODIMP	Show (BOOL fShow) ;
	STDMETHODIMP	GetTooltipString (BSTR *pbstrToolTip) ;
	
	// ITfLangBarItemButton
	STDMETHODIMP	OnClick (TfLBIClick click, POINT pt, const RECT *prcArea) ;
	STDMETHODIMP	InitMenu (ITfMenu *pMenu) ;
	STDMETHODIMP	OnMenuSelect (UINT wID) ;
	STDMETHODIMP	GetIcon (HICON *phIcon) ;
	STDMETHODIMP	GetText (BSTR *pbstrText) ;
	
	// ITfSource
	STDMETHODIMP	AdviseSink(REFIID riid, IUnknown *punk, DWORD *pdwCookie);
	STDMETHODIMP	UnadviseSink(DWORD dwCookie);

	STDMETHODIMP	Update () ;
	STDMETHODIMP	SetActiveContext (HIMC hIMC) ;

private:
	static	void	_Menu_Help (CLangBarItemImeButton* pThis) ;
	static	void	_Menu_Property (CLangBarItemImeButton* pThis) ;
	static	void	_Menu_Reconversion (CLangBarItemImeButton* pThis) ;
	static	void	_Menu_ToggleShowKeyboard (CLangBarItemImeButton* pThis) ;
	static	DWORD	_MenuItem_GetNormalFlag (CLangBarItemImeButton* pThis) ;
	static	DWORD	_MenuItem_GetToggleKeyboardFlag (CLangBarItemImeButton* pThis) ;

private:
	ITfLangBarItemSink*		_pLangBarItemSink ;
	TF_LANGBARITEMINFO		_tfLangBarItemInfo ;
	LONG					_cRef ;

	HIMC					_hIMC ;
	BOOL					_bShow ;

private:
	static const TSFLBMENUINFOEX	c_rgMenuItems [] ;
} ;

const TSFLBMENUINFOEX	CLangBarItemImeButton::c_rgMenuItems []	= {
	{	L"�w���v(&H)",				
		CLangBarItemImeButton::_MenuItem_GetNormalFlag,
		CLangBarItemImeButton::_Menu_Help },
	{	L"�v���p�e�B(&R)",
		CLangBarItemImeButton::_MenuItem_GetNormalFlag,
		CLangBarItemImeButton::_Menu_Property },
	{	L"�ĕϊ�(&C)",
		CLangBarItemImeButton::_MenuItem_GetNormalFlag,
		CLangBarItemImeButton::_Menu_Reconversion },
	{	NULL,
		NULL,
		NULL },
	{	L"�L�[�{�[�h�̕\��/��\��",
		CLangBarItemImeButton::_MenuItem_GetToggleKeyboardFlag,
		CLangBarItemImeButton::_Menu_ToggleShowKeyboard },
	{	NULL,
		NULL,
		NULL },
	{	L"�L�����Z��",
		NULL,
		NULL }
} ;

CLangBarItemImeButton::CLangBarItemImeButton ()
{
	//DllAddRef () ;
	_tfLangBarItemInfo.clsidService	= c_clsidSkkImeTextService ;
	_tfLangBarItemInfo.guidItem		= c_guidItemButtonIME ;
	_tfLangBarItemInfo.dwStyle		= TF_LBI_STYLE_BTN_MENU | TF_LBI_STYLE_SHOWNINTRAY ;
	_tfLangBarItemInfo.ulSort		= 1 ;
	SafeStringCopy (_tfLangBarItemInfo.szDescription, NELEMENTS (_tfLangBarItemInfo.szDescription), LANGBAR_ITEM_DESC) ;
	_pLangBarItemSink	= NULL ;
	_cRef				= 1 ;
	_hIMC				= NULL ;
	_bShow				= TRUE ;
	return ;
}

CLangBarItemImeButton::CLangBarItemImeButton (HIMC hIMC)
{
	//DllAddRef () ;
	_tfLangBarItemInfo.clsidService	= c_clsidSkkImeTextService ;
//	_tfLangBarItemInfo.clsidService	= CLSID_NULL ;
	_tfLangBarItemInfo.guidItem		= c_guidItemButtonIME ;
	_tfLangBarItemInfo.dwStyle		= TF_LBI_STYLE_BTN_MENU | TF_LBI_STYLE_SHOWNINTRAY ;
	_tfLangBarItemInfo.ulSort		= 1 ;
	SafeStringCopy (_tfLangBarItemInfo.szDescription, NELEMENTS (_tfLangBarItemInfo.szDescription), LANGBAR_ITEM_DESC) ;
	_pLangBarItemSink	= NULL ;
	_cRef				= 1 ;
	_hIMC				= hIMC ;
	_bShow				= TRUE ;
	return ;
}

CLangBarItemImeButton::~CLangBarItemImeButton ()
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::~CLangBarItemImeButton (this:%p)\n"), this)) ;
	//DllRelease () ;
	return ;
}

STDAPI
CLangBarItemImeButton::QueryInterface (
	REFIID			riid,
	void**			ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfLangBarItem) ||
		IsEqualIID (riid, IID_ITfLangBarItemButton)) {
		*ppvObj	= (ITfLangBarItemButton *)this ;
	} else if (IsEqualIID (riid, IID_ITfSource)) {
		*ppvObj	= (ITfSource *)this ;
	}
	if (*ppvObj != NULL) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CLangBarItemImeButton::AddRef ()
{
	return	++ _cRef ;
}

STDAPI_(ULONG)
CLangBarItemImeButton::Release ()
{
	LONG	cr	= -- _cRef ;

	if (_cRef == 0) {
		delete	this ;
	}
	return	cr ;
}

STDAPI
CLangBarItemImeButton::GetInfo (
	TF_LANGBARITEMINFO*		pInfo)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::GetInfo (this:%p)\n"), this)) ;
	
	if (pInfo == NULL)
		return	E_INVALIDARG ;

	*pInfo	= _tfLangBarItemInfo ;
	return	S_OK ;
}

STDAPI
CLangBarItemImeButton::Show (
	BOOL					bShow)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::Show (BOOL:%d)\n"), bShow)) ;
	if (_bShow != bShow) {
		if (_pLangBarItemSink == NULL)
			return	CONNECT_E_NOCONNECTION ;

		_bShow	= bShow ;
		_pLangBarItemSink->OnUpdate (TF_LBI_STATUS) ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemImeButton::GetStatus (
	DWORD*					pdwStatus)
{
	if (pdwStatus == NULL)
		return	E_INVALIDARG ;

	*pdwStatus	= ((_hIMC != NULL)? 0 : TF_LBI_STATUS_DISABLED) | (_bShow? 0 : TF_LBI_STATUS_HIDDEN) ;
	return	S_OK ;
}

/*	Button �� tooltip ��Ԃ��B�Ԃ��l�� SysAllocString �ɂ����
 *	�m�ۂ����̈�ɏ������K�v������B����� SysFreeString ��
 *	��̂́A�Ăяo�������̐ӔC�ł���B
 */
STDAPI
CLangBarItemImeButton::GetTooltipString (
	BSTR*					pbstrToolTip)
{
	if (pbstrToolTip == NULL)
		return	E_INVALIDARG ;

	*pbstrToolTip	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrToolTip == NULL)? E_OUTOFMEMORY : S_OK ;
}

/*	ITfLangBarItemButton::OnClick
 *
 *	���� method �̓��[�U������o�[�� TF_LBI_STYLE_BTN_BUTTON �܂�
 *	�� TF_LBI_STYLE_BTN_TOGGLE �X�^�C���������Ă���{�^���̏�Ń}
 *	�E�X���N���b�N�������ɌĂяo�����B
 *	�����{�^�� item �� TF_LBI_STYLE_BTN_BUTTON �X�^�C���������Ȃ�
 *	�̂Ȃ�A���� method �g���Ȃ��B
 *(*)
 *	���̏󋵂ł͓��ɉ�������K�v�͂Ȃ��̂ŁAS_OK �𑦕Ԃ��B
 */
STDAPI
CLangBarItemImeButton::OnClick (
	TfLBIClick				click,
	POINT					pt,
	const RECT*				prcArea)
{
	return	S_OK ;
}

/*	ITfLangBarItemButton::InitMenu
 *
 *	���� method �� TF_LBI_STYLE_BTN_MENU �X�^�C��������������o�[�̃{�^��
 *	������o�[���{�^���ɑ΂��ĕ\������ menu item ��ǉ����ėL���ɂ��邽��
 *	�ɌĂяo�����B
 */
STDAPI
CLangBarItemImeButton::InitMenu (
	ITfMenu*				pMenu)
{
	register int		i ;
	register DWORD		dwFlag ;
	register LPCWSTR	wstrDesc ;
	register ULONG		nstrDesc ;

	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::InitMenu (ITfMenu:%p)\n"), pMenu)) ;

	if (pMenu == NULL)
		return	E_INVALIDARG ;

	for (i = 0 ; i < NELEMENTS (c_rgMenuItems) ; i ++) {
		wstrDesc		= c_rgMenuItems [i].pchDesc ;
		if (wstrDesc != NULL) {
			nstrDesc	= wcslen (wstrDesc) ;
			dwFlag		= (c_rgMenuItems [i].pfnGetFlag != NULL)? (c_rgMenuItems [i].pfnGetFlag)(this) : 0 ;
		} else {
			nstrDesc	= 0 ;
			dwFlag		= TF_LBMENUF_SEPARATOR ;
		}
		pMenu->AddMenuItem (i, dwFlag, NULL, NULL, wstrDesc, nstrDesc, NULL) ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemImeButton::OnMenuSelect (
	UINT					wID)
{
	if (wID >= NELEMENTS (c_rgMenuItems))
		return	E_FAIL ;

	/*	NULL �̏ꍇ�� Cancel ���Ǝv�����Ƃɂ���B*/
	if (c_rgMenuItems [wID].pfnHandler != NULL) {
		c_rgMenuItems [wID].pfnHandler (this) ;
//		Update () ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemImeButton::GetIcon (
	HICON*					phIcon)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::GetIcon(%p)\n"), phIcon)) ;

	if (phIcon == NULL)
		return	E_INVALIDARG ;

    *phIcon	= (HICON)LoadImage (g_hInst, TEXT ("IMEICON"), IMAGE_ICON, 16, 16, LR_SHARED);
    return (*phIcon != NULL) ? S_OK : E_FAIL ;
}

STDAPI
CLangBarItemImeButton::GetText (
	BSTR*			pbstrText)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::GetText ()\n"))) ;

	if (pbstrText == NULL)
		return	E_INVALIDARG ;

	*pbstrText	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrText == NULL)? E_OUTOFMEMORY : S_OK ;
}

STDAPI
CLangBarItemImeButton::AdviseSink (
	REFIID			riid,
	IUnknown*		punk,
	DWORD*			pdwCookie)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::AdviseSink (this:%p)\n"), this)) ;

    if (!IsEqualIID (IID_ITfLangBarItemSink, riid)) {
		DEBUGPRINTFEX (100, (TEXT ("CONNECT_E_CANNOTCONNECT\n"))) ;
        return	CONNECT_E_CANNOTCONNECT ;
	}

    if (_pLangBarItemSink != NULL) {
		DEBUGPRINTFEX (100, (TEXT ("CONNECT_E_ADVISELIMIT\n"))) ;
        return	CONNECT_E_ADVISELIMIT ;
	}

    if (punk->QueryInterface (IID_ITfLangBarItemSink, (void **)&_pLangBarItemSink) != S_OK) {
		DEBUGPRINTFEX (100, (TEXT ("E_NOINTERFACE\n"))) ;
        _pLangBarItemSink	= NULL ;
        return	E_NOINTERFACE ;
    }

    *pdwCookie	= SKKIME_LANGBARITEMSINK_COOKIE ;
    return	S_OK ;
}

STDAPI
CLangBarItemImeButton::UnadviseSink (
	DWORD			dwCookie)
{
	DEBUGPRINTFEX (100, (TEXT ("CLangBarItemImeButton::UnadviseSink ()\n"))) ;

    if (dwCookie != SKKIME_LANGBARITEMSINK_COOKIE)
        return	CONNECT_E_NOCONNECTION ;

    if (_pLangBarItemSink == NULL)
        return	CONNECT_E_NOCONNECTION ;

    _pLangBarItemSink->Release () ;
    _pLangBarItemSink	= NULL ;

    return	S_OK ;
}

STDAPI
CLangBarItemImeButton::Update ()
{
	DWORD	dwStatus ;

	if (_pLangBarItemSink == NULL)
		return	CONNECT_E_NOCONNECTION ;

	_pLangBarItemSink->OnUpdate (TF_LBI_STATUS) ;
	return	S_OK ;
}

STDAPI
CLangBarItemImeButton::SetActiveContext (HIMC hIMC)
{
	_hIMC	= hIMC ;
	return	Update () ;
}

/*========================================================================*
 *	public function interface
 */
BOOL
bButtonIME_Create (
	HIMC				hIMC,
	ITfLangBarItem**	ppLangBarItem)
{
	if (ppLangBarItem == NULL)
		return	FALSE ;
	*ppLangBarItem		= new CLangBarItemImeButton (hIMC) ;
	return	(*ppLangBarItem != NULL) ;
}

HRESULT
hrButtonIME_Update (
	ITfLangBarItem*		pItem)
{
	CLangBarItemImeButton*	pButtonIME ;

	if (pItem == NULL)
		return	E_INVALIDARG ;

	pButtonIME	= (CLangBarItemImeButton*) pItem ;
	return	pButtonIME->Update () ;
}

HRESULT
hrButtonIME_SetActiveContext (
	ITfLangBarItem*		pItem,
	HIMC				hIMC)
{
	CLangBarItemImeButton*	pButtonIME ;

	if (pItem == NULL)
		return	E_INVALIDARG ;

	pButtonIME	= (CLangBarItemImeButton*) pItem ;
	pButtonIME->SetActiveContext (hIMC) ;
	return	S_OK ;
}

/*========================================================================*
 *	private functions
 */
void
CLangBarItemImeButton::_Menu_Help (
	CLangBarItemImeButton*		pThis)
{
	/*	���[��AHELP �͍���ĂȂ��c�B*/
	return ;
}

void
CLangBarItemImeButton::_Menu_Property (
	CLangBarItemImeButton*		pThis)
{
	register HKL	hKL		= TSkkIme_hGetHKL () ;
	register HWND	hWnd	= GetFocus () ;

	if (hKL == NULL)
		return ;
	(void) ImeConfigure (hKL, hWnd, IME_CONFIG_GENERAL, NULL) ;
	return ;
}

void
CLangBarItemImeButton::_Menu_Reconversion (
	CLangBarItemImeButton*		pThis)
{
	register DWORD				dwSize ;
	register LPRECONVERTSTRING	lpRS ;

	if (pThis->_hIMC == NULL)
		return ;

	dwSize	= (DWORD) MyImmRequestMessage (pThis->_hIMC, IMR_RECONVERTSTRING, 0) ;
	if (! dwSize) 
		return ;

	lpRS			= (LPRECONVERTSTRING) GlobalAlloc (GPTR, dwSize) ;
	lpRS->dwSize	= dwSize ;
	if (dwSize = (DWORD) MyImmRequestMessage (pThis->_hIMC, IMR_RECONVERTSTRING, (LPARAM) lpRS)) {
		register LPINPUTCONTEXT			lpIMC ;
			
		lpIMC	= ImmLockIMC (pThis->_hIMC) ;
		if (lpIMC != NULL) {
			register LPCOMPOSITIONSTRING	lpCompStr ;

			if (ImmGetIMCCSize (lpIMC->hCompStr) < sizeof (MYCOMPSTR))
				goto	pass_1 ;

			/*	�ϊ����[�h�������I�ɉ������̓��[�h�ɐݒ肷��B*/
			lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
			if (lpCompStr != NULL) {
				TSkkIme_bSetReconvertStr (pThis->_hIMC, lpIMC, lpCompStr, lpRS, TRUE) ; // ?
				ImmUnlockIMCC (lpIMC->hCompStr) ;
			}
		pass_1:
			ImmUnlockIMC (pThis->_hIMC) ;
		}
		MyImmRequestMessage(pThis->_hIMC, IMR_CONFIRMRECONVERTSTRING, (LPARAM)lpRS) ;
	} else {
		GlobalFree((HANDLE)lpRS) ;
	}
	return ;
}

void
CLangBarItemImeButton::_Menu_ToggleShowKeyboard (
	CLangBarItemImeButton*		pThis)
{
	register BOOL	fShowKeyboardIcon	= TRUE ;
	DWORD			dwValue ;

	if (GetRegDwordValue (TEXT ("\\CICERO"), TEXT(REGKEY_SHOWKEYBRDICON), &dwValue)) 
		fShowKeyboardIcon	= (BOOL) dwValue ;
	SetRegDwordValue (TEXT ("\\CICERO"), TEXT(REGKEY_SHOWKEYBRDICON), !fShowKeyboardIcon) ;
	bTSF_ShowKeyboardIcon (!fShowKeyboardIcon) ;
	return ;
}

DWORD
CLangBarItemImeButton::_MenuItem_GetNormalFlag (
	CLangBarItemImeButton*		pThis)
{
	return	0 ;
}

DWORD
CLangBarItemImeButton::_MenuItem_GetToggleKeyboardFlag (
	CLangBarItemImeButton*		pThis)
{
	register BOOL	fShowKeyboardIcon	= TRUE ;
	DWORD			dwValue ;
	
	if (GetRegDwordValue (TEXT ("\\CICERO"), TEXT(REGKEY_SHOWKEYBRDICON), &dwValue)) 
		fShowKeyboardIcon	= (BOOL) dwValue ;
	return	(fShowKeyboardIcon)? TF_LBMENUF_CHECKED : 0 ;
}

#endif
