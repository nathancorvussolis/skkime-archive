#include <windows.h>
#include <tchar.h>
#include "immdev.h"
#include "skki1_5.h"
#include "immsec.h"

HANDLE	PASCAL
TSkkIme_hCreateMutex (
	LPCTSTR					pMutexName)
{
	PSECURITY_ATTRIBUTES	psa ;
	HANDLE					hMutex ;

	DEBUGPRINTFEX (99, (MYTEXT ("TSkkIme_hCreateMutex ()\n"))) ;

	//psa		= CreateSecurityAttributes () ;
	psa		= NULL ;
	hMutex	= CreateMutex (psa, FALSE, pMutexName) ;
	if (psa != NULL)
		FreeSecurityAttributes (psa) ;
	return	hMutex ;
}

