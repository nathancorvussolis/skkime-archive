#if !defined (mylocale_h)
#define	mylocale_h

/* UNICODE or ANSI $B@lMQ(B */
typedef LPTSTR						LPMYSTR ;
typedef LPCTSTR						LPCMYSTR ;
typedef TCHAR						MYCHAR ;
typedef LOGFONT						MYLOGFONT ;
typedef PLOGFONT					PMYLOGFONT ;
typedef LPLOGFONT					LPMYLOGFONT ;
#define MYTEXT(x)					TEXT(x)
#define Mylstrlen(x)				lstrlen((x))
#define Mylstrcpy(x, y)				lstrcpy((x), (y))
#define Mylstrcmp(x, y)				lstrcmp((x), (y))
#define	Mylstrcat(x, y)				lstrcat((x), (y))
#define	Mylstrncpy(x, y, z)			MylstrncpyA((x), (y), (z))
#define	Mylstrncmp(x, y, z)			MylstrncmpA((x), (y), (z))
#define	Mylstrncat(x, y, z)			MylstrncatA((x), (y), (z))
#define MyCharPrev(x, y)			AnsiPrev((x), (y))
#define MyCharNext(x)				AnsiNext((x))
#define	MystrToEuc(x, y, z)			MystrToEucA((x), (y), (z))
#define	Mylstrncpyex(v, w, x, y, z)	MylstrncpyexA ((v), (w), (x), (y), (z))
#include <mbstring.h>
#define Mystrtok					_mbstrtok
#define Mystrchr					_mbschr

#define Mylstrcpyn					lstrcpyn
#define MyTextOut					TextOut
#define MyGetTextExtentPoint 		GetTextExtentPoint32
#define LPMYIMEMENUITEMINFO			LPIMEMENUITEMINFO
#define MyImmRequestMessage			ImmRequestMessage
#define MyOutputDebugString			OutputDebugString
#define MyFileName					TEXT ("skki1_5.ime")
#define	MyGlobalAddAtom				GlobalAddAtom
#define	MyGlobalDeleteAtom			GlobalDeleteAtom
#define	MyGlobalGetAtomName			GlobalGetAtomName
#define	MyCreateFontIndirect(x)		CreateFontIndirect((x))
#define	MyGetUserName(x, y)			GetUserName((x), (y))

#define	MyRegCreateKeyEx(a,b,c,d,e,f,g,h,i)	RegCreateKeyEx((a),(b),(c),(d),(e),(f),(g),(h),(i))
#define	MyRegOpenKeyEx(a,b,c,d,e)			RegOpenKeyEx((a),(b),(c),(d),(e))
#define	MyRegEnumValue(a,b,c,d,e,f,g,h)		RegEnumValue((a),(b),(c),(d),(e),(f),(g),(h))
#define	MyRegQueryValueEx(a,b,c,d,e,f)		RegQueryValueEx((a),(b),(c),(d),(e),(f))
#define	MyRegSetValueEx(a,b,c,d,e,f)		RegSetValueEx((a),(b),(c),(d),(e),(f))
#define	MyRegDeleteValue(a,b)				RegDeleteValue((a),(b))
#define	MyRegCloseKey(a)					RegCloseKey((a))

#define	Mywsprintf							wsprintf
#define	Mywvsprintf(a,b,c)					wvsprintf((a),(b),(c))
#define	Mylstrlen(a)						lstrlen((a))
#define	Mylstrcpy(a,b)						lstrcpy((a),(b))
#define	Mylstrcpyn(a,b,c)					lstrcpyn((a),(b),(c))
#define	Mylstrcmp(a,b)						lstrcmp((a),(b))
#if defined (UNICODE) || defined (_UNICODE)
#define	Mylstrcmpn(a,b,c)					lstrcmpnW((a),(b),(c))
#else
#define	Mylstrcmpn(a,b,c)					lstrcmpnA((a),(b),(c))
#endif
#define	MyExpandEnvironmentStrings(a,b,c)	ExpandEnvironmentStrings((a),(b),(c))

#define	MySendMessage(a,b,c,d)				SendMessage((a),(b),(c),(d))
#define	MyOutputDebugString(a)				OutputDebugString((a))
#define	MyDialogBoxParam(a,b,c,d,e)			DialogBoxParam((a),(b),(c),(d),(e))
#define	MySetWindowText(a,b)				SetWindowText((a),(b))
#define	MyGetWindowText(a,b,c)				GetWindowText((a),(b),(c))
#define	MyGetDlgItemText(a,b,c,d)			GetDlgItemText((a),(b),(c),(d))

#define	MYLV_COLUMN							LV_COLUMN
#define	MYLVITEM							LVITEM
#define	MYLVFINDINFO						LVFINDINFO

#define	MyListView_GetItem(hwnd,pitem)		\
	ListView_GetItem((hwnd),(pitem))
#define	MyListView_SetItem(hwnd,pitem)		\
	ListView_SetItem((hwnd),(pitem))
#define	MyListView_InsertItem(hwnd,pitem)	\
	ListView_InsertItem((hwnd),(pitem))
#define	MyListView_DeleteItem(hwnd,pitem)	\
	ListView_DeleteItem((hwnd),(pitem))
#define	MyListView_DeleteAllItems(hwnd)		\
	ListView_DeleteAllItems((hwnd))
#define	MyListView_FindItem(hwnd,iStart,plvfi)	\
	ListView_FindItem((hwnd),(iStart),(plvfi))
#define	MyListView_SetItemPosition(hwndLV,i,x,y)	\
	ListView_SetItemPosition((hwndLV),(i),(x),(y))
#define	MyListView_GetItemPosition(hwndLV,i,ppt)	\
	ListView_GetItemPosition((hwndLV),(i),(ppt))
#define	MyListView_GetStringWidth(hwnd,psz)	\
	ListView_GetStringWidth((hwnd),(psz))
#define	MyListView_HitTest(hwndLV,pinfo)	\
	ListView_HitText((hwndLV),(pinfo))
#define	MyListView_GetColumn(hwnd,iCol,pcol)	\
	ListView_GetColumn((hwnd),(iCol),(pcol))
#define	MyListView_SetColumn(hwnd,iCol,pcol)	\
	ListView_SetColumn((hwnd),(iCol),(pcol))
#define	MyListView_InsertColumn(hwnd,iCol,pcol)	\
	ListView_InsertColumn((hwnd),(iCol),(pcol))
#define	MyListView_GetColumnWidth(hwnd,iCol)	\
	ListView_GetColumnWidth((hwnd),(iCol))
#define	MyListView_SetColumnWidth(hwnd,iCol,cx)	\
	ListView_SetColumnWidth((hwnd),(iCol),(cx))
#define	MyListView_CreateDragImage(hwnd,i,lpptUpLeft)	\
	ListView_CreateDragImage((hwnd),(i),(lpptUpLeft))
#define	MyListView_Update(hwndLV,i)	\
	ListView_Update((hwndLV),(i))
#define	MyListView_SetItemState(hwndLV,i,data,mask)	\
	ListView_SetItemState((hwndLV),(i),(data),(mask))
#define	MyListView_GetItemText(hwndLV,i,iSubItem_,pszText_,cchTextMax_)	\
	ListView_GetItemText((hwndLV),(i),(iSubItem_),(pszText_),(cchTextMax_))
#define	MyListView_SetItemText(hwndLV,i,iSubItem_,pszText_)	\
	ListView_SetItemText((hwndLV),(i),(iSubItem_),(pszText_))
#define	MyListView_SetItemCount(hwndLV,cItems)	\
	ListView_SetItemCount((hwndLV),(citems))
#define	MyListView_SortItems(hwndLV,_pfnCompare,_lPrm)	\
	ListView_SortItems((hwndLV),(_pfnCompare),(_lPrm))
#define	MyListView_GetItemCount(hwnd) \
	ListView_GetItemCount((hwnd))

#endif

