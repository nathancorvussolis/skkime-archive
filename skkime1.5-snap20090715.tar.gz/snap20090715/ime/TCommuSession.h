#pragma once

struct	CTPacket ;

BOOL	TCommunicateSession_bClassInit	(void) ;
HANDLE	TCommunicateSession_hOpenServer	(void) ;
BOOL	TCommunicateSession_bSend		(HANDLE, struct CTPacket*) ;
BOOL	TCommunicateSession_bRecv		(HANDLE, struct CTPacket*) ;
BOOL	TCommunicateSession_bStartServer(void) ;

