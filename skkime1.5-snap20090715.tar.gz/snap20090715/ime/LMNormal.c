#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDocP.h"
#include "ImeBuffer.h"
#include "TMarker.h"
#include "lmstate.h"

#define	IS_BLANKCHAR(ch)	((ch) == L' ' || (ch) == L'\t' || (ch) == '\n' || (ch) == '\r')
#define	IS_ASCIICHAR(ch)	(32 <= (ch) && (ch) < 128)

/*======================================================================== message-loop
 */
static	int		LM_iMessageLoop_1		(struct CImeDoc*) ;
static	int		LM_iPostMessageLoop		(struct CImeDoc*) ;
static	int		LM_iPostMessageLoop_1	(struct CImeDoc*) ;
static	int		LM_iPostMessageLoop_2	(struct CImeDoc*) ;

int
LM_iMessageLoop (
	struct CImeDoc*			pDoc)
{
	struct TMSG*	pMSG ;
	int				nFuncNo ;
	PLMFUNC			pPC	= NULL ;

	/*	MessageLoop �ɖ߂��Ă������� Recursive Edit �𔲂��鏈�������Ă����ꍇ�ɂ́A
	 *	�c
	 *	����A�����ŏ�������K�v������̂��l���Ȃ���΁B
	if (pDoc->m_bExitReEdit) {
	}
	 */

	if (pDoc->m_nUnreadMessages <= 0) {
		return	LMR_STOP ;
	}
	pDoc->m_nUnreadMessages -- ;
	pMSG	= pDoc->m_rMessages + pDoc->m_nUnreadMessages ;
	if (ImeDoc_bIgnoreMessagep (pMSG))
		return	LMR_CONTINUE ;

	pDoc->m_iLastCommandChar	= ImeDoc_iGetCharFromEvent (pMSG) ;
	if (! ImeDoc_bLookupKeymap (pDoc, pMSG, &nFuncNo)) 
		nFuncNo	= NFUNC_INVALID_CHAR ;

	pPC		= ImeDoc_pLookupLMState (pDoc, nFuncNo) ;
	if (pPC == NULL)
		return	LMR_CONTINUE ;	/* �������삪���蓖�Ă��ĂȂ��ꍇ�B*/

	/*	MessageLoop �� error �� quit �� signal �������B*/
	ImeDoc_vClearSignals (pDoc) ;
	pDoc->m_iThisCommand	= nFuncNo ;
	pDoc->m_LastEvent		= *pMSG ;

	if (pDoc->m_pPreCommandHook != NULL) {
		if (! ImeDoc_bPushReg (pDoc, LMREG_0))
			return	LMR_ERROR ;
		ImeDoc_vSetRegInteger (pDoc, LMREG_0, nFuncNo) ;
		if (! ImeDoc_bCall (pDoc, pDoc->m_pPreCommandHook, LM_iMessageLoop_1))
			return	LMR_ERROR ;
	} else {
		/* call-interactively �̐^�����B*/
		ImeDoc_vSetRegNil (pDoc, LMREGARG_0) ;
		if (! ImeDoc_bCall (pDoc, pPC, LM_iPostMessageLoop))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
LM_iMessageLoop_1 (
	struct CImeDoc*			pDoc)
{
	PLMFUNC	pPC ;
	int		nFuncNo ;

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nFuncNo)) 
		nFuncNo	= NFUNC_INVALID_CHAR ;

	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	pPC		= ImeDoc_pLookupLMState (pDoc, nFuncNo) ;
	if (pPC == NULL) {
		/* �����ɗ��邱�Ƃ͖{�����肦�Ȃ��Ǝv���̂ł͂��邪�B*/
		ImeDoc_vJump (pDoc, LM_iPostMessageLoop) ;
		return	LMR_CONTINUE ;
	}
	/* call-interactively �̐^�����B*/
	ImeDoc_vSetRegNil (pDoc, LMREGARG_0) ;
	if (! ImeDoc_bCall (pDoc, pPC, LM_iPostMessageLoop))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_iPostMessageLoop (
	struct CImeDoc*			pDoc)
{
	/* last-command �̍X�V�B*/
	pDoc->m_iLastCommand	= pDoc->m_iThisCommand ;

	/*	post-command-hook �̃^�C�~���O�͂������낤���H */
	if (pDoc->m_pPostCommandHook != NULL) {
		if (! ImeDoc_bPushReg (pDoc, LMREG_0))
			return	LMR_ERROR ;

		ImeDoc_vSetRegInteger (pDoc, LMREG_0, ImeDoc_nGetSignal (pDoc)) ;
		ImeDoc_vClearSignals  (pDoc) ;
		if (! ImeDoc_bCall (pDoc, pDoc->m_pPostCommandHook, LM_iPostMessageLoop_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else {
		ImeDoc_vJump (pDoc, LM_iPostMessageLoop_2) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_iPostMessageLoop_1 (
	struct CImeDoc*			pDoc)
{
	int		nSignal ;

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nSignal))
		nSignal	= LMSIGNAL_NONE ;
	ImeDoc_vSetSignal (pDoc, nSignal) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	ImeDoc_vJump (pDoc, LM_iPostMessageLoop_2) ;
	return	LMR_CONTINUE ;
}

int
LM_iPostMessageLoop_2 (
	struct CImeDoc*			pDoc)
{
	/*	������ minibuffer �𔲂��鏈��������B*/
	if (ImeDoc_bSignalMinibuffp (pDoc)) {
		struct CImeBuffer*	pBuffer ;

		if (ImeDoc_nGetSignal (pDoc) == LMSIGNAL_EXIT_MINIBUFFER) {
			ImeDoc_vClearSignals (pDoc) ;
		} else {
			ImeDoc_vSetSignal (pDoc, LMSIGNAL_QUIT) ;
		}
		pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
		if (pBuffer != NULL && ImeBuffer_pGetParent (pBuffer) != NULL)
			return	LMR_RETURN ;
	}
	ImeDoc_vJump (pDoc, LM_iMessageLoop) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== next-command-event
 */
int
LM_bNextCommandEvent (
	struct CImeDoc*			pDoc)
{
	struct TMSG*	pMSG ;

	if (pDoc->m_nUnreadMessages <= 0) {
		return	LMR_STOP ;
	}
	pDoc->m_nUnreadMessages -- ;
	pMSG	= pDoc->m_rMessages + pDoc->m_nUnreadMessages ;

	ImeDoc_vSetRegMsg (pDoc, LMREGARG_RETVAL, pMSG) ;
	return	LMR_RETURN ;
}

/*======================================================================== read-from-minibuffer
 */
static	int		LM_bReadFromMinibuffer_Exit		(struct CImeDoc*) ;

int
LM_bReadFromMinibuffer (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pNewBuffer ;
	struct CImeBuffer*	pCurBuffer ;
	LPCDSTR		pwText ;
	int			nText ;
	BOOL		bSkkModeOn ;

	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &pwText,   &nText)) {
		pwText		= NULL ;
		nText		= 0 ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_1, &bSkkModeOn)) {
		bSkkModeOn	= FALSE ;
	}
	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}

	pNewBuffer	= ImeDoc_pCreateBuffer (pDoc, pwText, nText, bSkkModeOn) ;
	if (pNewBuffer == NULL) {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}
	ImeBuffer_vSetParent (pNewBuffer, pCurBuffer) ;

	ImeDoc_vSetCurrentBuffer (pDoc, pNewBuffer) ;
	ImeDoc_vClearMessage (pDoc) ;

	if (! ImeDoc_bCall (pDoc, LM_iMessageLoop, LM_bReadFromMinibuffer_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bReadFromMinibuffer_Exit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct CImeBuffer*	pPrevBuffer ;
	LPDSTR				pwResult	= NULL ;
	int					nText ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}

	/*	current-buffer �����ɖ߂��B
	 */
	pPrevBuffer	= ImeBuffer_pGetParent (pBuffer) ;
	if (pPrevBuffer != NULL) {
		ImeDoc_vSetCurrentBuffer (pDoc, pPrevBuffer) ;
		/*	�s�v�ɂȂ��� buffer ���폜����B*/
		ImeDoc_bDeleteBuffer (pDoc, pBuffer) ;
	} else {
		/* ... fatal */
	}

	if (ImeDoc_nGetSignal (pDoc) == LMSIGNAL_QUIT) {
		/* abort �����̂Ȃ�A���͂����e�L�X�g�͂Ȃ��B���[��Asignal �͎c���ׂ��Ȃ̂��H */
		nText	= 0 ;
		ImeDoc_vSetSignal (pDoc, LMSIGNAL_QUIT) ;
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	} else {
		LPCDSTR	pwText ;
		int		nResultSize ;

		pwResult	= ImeDoc_pGetReturnBuffer (pDoc, &nResultSize) ;
		if (pwResult != NULL) {
			pwText		= ImeBuffer_pBufferString (pBuffer, &nText) ;
			if (nText > 0) {
				nText	= MIN (nResultSize, nText) ;
				if (nText > 0) {
					memcpy (pwResult, pwText, nText * sizeof (DCHAR)) ;
				}
			} 
		} else {
			nText	= 0 ;
		}
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwResult, nText) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== yes-or-no-p
 */
static	int		LM_bYesOrNop_1		(struct CImeDoc*) ;
static	int		LM_bYesOrNop_2		(struct CImeDoc*) ;
static	int		LM_bYesOrNop_Exit	(struct CImeDoc*) ;

int
LM_bYesOrNop (
	struct CImeDoc*		pDoc)
{
	LPCDSTR		pwText ;
	int			nText ;

	if (! ImeDoc_bPushReg (pDoc, LMREG_0))
		return	LMR_ERROR ;

	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &pwText, &nText)) {
		pwText	= NULL ;
		nText	= 0 ;
	}
	ImeDoc_vSetRegConstString (pDoc, LMREG_0, pwText, nText) ;
	ImeDoc_vJump (pDoc, LM_bYesOrNop_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bYesOrNop_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pNewBuffer ;
	struct CImeBuffer*	pCurBuffer ;
	LPCDSTR		pwText ;
	int			nText ;

	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_0, &pwText, &nText)) {
		pwText		= NULL ;
		nText		= 0 ;
	}
	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		ImeDoc_vJump (pDoc, LM_bYesOrNop_Exit) ;
		return	LMR_CONTINUE ;
	}

	pNewBuffer	= ImeDoc_pCreateBuffer (pDoc, pwText, nText, FALSE) ;
	if (pNewBuffer == NULL) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		ImeDoc_vJump (pDoc, LM_bYesOrNop_Exit) ;
		return	LMR_CONTINUE ;
	}
	ImeBuffer_vSetParent (pNewBuffer, pCurBuffer) ;

	if (! ImeDoc_bPushReg (pDoc, LMREG_0)) {
		ImeDoc_bDeleteBuffer (pDoc, pNewBuffer) ;
		return	LMR_ERROR ;
	}
	ImeDoc_vSetCurrentBuffer (pDoc, pNewBuffer) ;
	ImeDoc_vClearMessage (pDoc) ;

	if (! ImeDoc_bCall (pDoc, LM_iMessageLoop, LM_bYesOrNop_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bYesOrNop_2 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct CImeBuffer*	pPrevBuffer ;
	BOOL				bRetval	= FALSE ;
	BOOL				bRetry	= FALSE ;
	const DWORD	c_dstrYes []	= { L'y', L'e', L's', L'\0' } ;
	const DWORD	c_dstrNo  []	= { L'n', L'o', L'\0' } ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}

	if (ImeDoc_nGetSignal (pDoc) == LMSIGNAL_QUIT) {
		/* abort �����̂Ȃ�A���͂����e�L�X�g�͂Ȃ��B���[��Asignal �͎c���ׂ��Ȃ̂��H */
		ImeDoc_vSetSignal (pDoc, LMSIGNAL_QUIT) ;
		bRetry	= FALSE ;
	} else {
		LPCDSTR	pwText ;
		int		nText ;

		pwText	= ImeBuffer_pBufferString (pBuffer, &nText) ;
		if (nText > 0) {
			LPCDSTR	ptrLast, ptrTop ;

			ptrLast	= pwText + nText - 1 ;
			while (ptrLast >= pwText && iswspace (*ptrLast))
				ptrLast	-- ;
			ptrTop	= pwText ;
			while (ptrTop <= ptrLast && iswspace (*ptrTop))
				ptrTop	++ ;
			nText	= ptrLast - ptrTop + 1 ;
			pwText	= ptrTop ;
			if (! dcsnicmp (pwText, c_dstrYes, nText)) {
				bRetval	= TRUE ;
			} else if (! dcsnicmp (pwText, c_dstrNo, nText)) {
				bRetval	= FALSE ;
			} else {
				/* retry */
				bRetry	= TRUE ;
			}
		} else {
			bRetry	= TRUE ;
		}
	}
	/*	current-buffer �����ɖ߂��B
	 */
	pPrevBuffer	= ImeBuffer_pGetParent (pBuffer) ;
	if (pPrevBuffer != NULL) {
		ImeDoc_vSetCurrentBuffer (pDoc, pPrevBuffer) ;
		/*	�s�v�ɂȂ��� buffer ���폜����B*/
		ImeDoc_bDeleteBuffer (pDoc, pBuffer) ;
	} else {
		/* ... fatal */
	}
	if (bRetry) {
		ImeDoc_vJump (pDoc, LM_bYesOrNop_1) ;
		return	LMR_CONTINUE ;
	} 
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, bRetval) ;
exit_func:
	ImeDoc_vJump (pDoc, LM_bYesOrNop_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bYesOrNop_Exit (
	struct CImeDoc*			pDoc)
{
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	return	LMR_RETURN ;
}

/*======================================================================== self-insert-character
 */
int
LM_bSelfInsertCharacter (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	DCHAR				wCH ;
	struct TMarker*		pmkPoint ;

	/*	signal ���ݒ肳��Ă���Γ��삵�Ȃ��B
	 *	�Ƃ������A���̔���𖈉�Ă΂ꂽ���ɏ����̂͂Ȃ��c�B
	 */
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	/*	printable �ȃC�x���g���ǂ����`�F�b�N����B
	 */
	if (! ImeDoc_bGetLastCommandChar (pDoc, &wCH)) {
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (ImeBuffer_iInsert (pBuffer, pmkPoint, &wCH, 1) <= 0) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== backward-char
 */
int
LM_bBackwardChar (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkTop ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (TMarker_iGetPosition (pmkTop) < TMarker_iGetPosition (pmkPoint)) {
		if (! TMarker_bBackward (pmkPoint, 1)) {
			ImeDoc_vSetSignalError (pDoc) ;
		}
	} else {
		/*	�����ŃG���[�t���b�O�𗧂Ă邩�ǂ����́A�󋵎��悾���c�B
		 */
		ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== forward-char
 */
int
LM_bForwardChar (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (TMarker_iGetPosition (pmkPoint) < TMarker_iGetPosition (pmkEnd)) {
		if (! TMarker_bForward (pmkPoint, 1)) {
			ImeDoc_vSetSignalError (pDoc) ;
		}
	} else {
		/*	�����ŃG���[�t���b�O�𗧂Ă邩�ǂ����́A�󋵎��悾���c�B
		 */
		ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== delete-char
 */
int
LM_bDeleteChar (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	int					nPoint ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	nPoint	= TMarker_iGetPosition (pmkPoint) ;
	if (nPoint < TMarker_iGetPosition (pmkEnd)) {
		if (! ImeBuffer_bDeleteRegion (pBuffer, nPoint, nPoint + 1)) {
			ImeDoc_vSetSignalError (pDoc) ;
		}
	} else {
		ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
} 

/*======================================================================== backward-delete-char
 */
int
LM_bBackwardDeleteChar (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkTop ;
	int					nPoint ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	nPoint	= TMarker_iGetPosition (pmkPoint) ;
	if (nPoint > 0 && nPoint > TMarker_iGetPosition (pmkTop)) {
		if (! ImeBuffer_bDeleteRegion (pBuffer, nPoint - 1, nPoint)) {
			ImeDoc_vSetSignalError (pDoc) ;
		}
	} else {
		ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== transpose-chars
 */
int
LM_bTransposeChars (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkTop ;
	struct TMarker*		pmkEnd ;
	int					nPoint, nBufferTop, nBufferEnd, nLength ;
	DCHAR				wch ;
	LPCDSTR				wstrText ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL || 
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	nPoint		= TMarker_iGetPosition (pmkPoint) ;
	nBufferEnd	= TMarker_iGetPosition (pmkEnd) ;
	nBufferTop	= TMarker_iGetPosition (pmkTop) ;
	if (nPoint >= nBufferEnd || nPoint < (nBufferTop + 1)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	wstrText	= ImeBuffer_pBufferString (pBuffer, &nLength) ;
	wch			= wstrText [nPoint - 1] ;
	if (! ImeBuffer_bDeleteRegion (pBuffer, nPoint - 1, nPoint) || 
		! TMarker_bForward (pmkPoint, 1) ||
		ImeBuffer_iInsert (pBuffer, pmkPoint, &wch, 1) <= 0) {
		ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== end-of-line
 */
BOOL
LM_bEndOfLine (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	int					nPoint, nBufferEnd, nPointBak, nLength ;
	LPCDSTR				wstrText ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	nPoint		= TMarker_iGetPosition (pmkPoint) ;
	nBufferEnd	= TMarker_iGetPosition (pmkEnd) ;
	wstrText	= ImeBuffer_pBufferRawString (pBuffer, &nLength) ;
	nPointBak	= nPoint ;
	while (nPoint < nBufferEnd && nPoint < nLength) {
		if (wstrText [nPoint] == L'\n') 
			break ;
		nPoint	++ ;
	}
	if (! TMarker_bForward (pmkPoint, nPoint - nPointBak)) {
		ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== beginning-of-line
 */
BOOL
LM_bBeginningOfLine (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	struct TMarker*	pmkPoint ;
	struct TMarker*	pmkTop ;
	struct TMarker*	pmkEnd ;
	int			nPoint, nTop, nBufferEnd ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	nBufferEnd		= TMarker_iGetPosition (pmkEnd) ;
	if (ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nTop	= TMarker_iGetPosition (pmkTop) ;
	} else {
		nTop	= 0 ;
	}
	nPoint	= TMarker_iGetPosition (pmkPoint) ;
	if (nPoint > nTop) {
		LPCDSTR	wstrText	= ImeBuffer_pBufferRawString (pCurBuffer, NULL) ;
		nPoint	-- ;
		while (nPoint > nTop) {
			if (wstrText [nPoint] == L'\n') {
				nPoint	++ ;
				break ;
			}
			nPoint	-- ;
		}
		TMarker_bBackward (pmkPoint, TMarker_iGetPosition (pmkPoint) - nPoint) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== set-mark-command
 */
BOOL
LM_bSetMarkCommand (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	struct TMarker*	pmkPoint ;
	struct TMarker*	pmkMark ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_MARK, &pmkMark)) {
		pmkMark	= NULL ;
	}
	if (! ImeDoc_bSetMessageW (pDoc, L"Mark Set") || 
		! ImeBuffer_bSetMarker (pCurBuffer, &pmkMark, MARKER_MARK, pmkPoint)) {
		ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== keyboard-quit
 */
static	int	LM_bKeyboardQuit_1	(struct CImeDoc*) ;

int
LM_bKeyboardQuit (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL) {
		ImeDoc_vSetSignal (pDoc, LMSIGNAL_QUIT) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bCall (pDoc, LM_bSkkAdKeyboardQuit, LM_bKeyboardQuit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bKeyboardQuit_1 (
	struct CImeDoc*				pDoc)
{
	BOOL	bDone ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_RETVAL, &bDone))
		bDone	= FALSE ;
	if (! bDone) {
		/*	inhibit-quit ���Ȃ��Ƃ܂��������c�B
		 */
		/*	keyboard-quit ���N�ɂ��������ꂸ�ɗ���ė����ꍇ�A�Ăяo�����ɕԂ�
		 *	�K�v�����邩������Ȃ��B
		 */
		if (! ImeDoc_bProcessEventp (pDoc)) {
			(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
			return	LMR_RETURN ;
		}
		ImeDoc_vSetSignal (pDoc, LMSIGNAL_QUIT) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== exit-recursive-edit
 */
static	int		LM_bExitRecursiveEdit_1 (struct CImeDoc*) ;

int
LM_bExitRecursiveEdit (
	struct CImeDoc*				pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bCall (pDoc, LM_bSkkAdExitMinibuffer, LM_bExitRecursiveEdit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bExitRecursiveEdit_1 (
	struct CImeDoc*				pDoc)
{
	BOOL	bDone ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_RETVAL, &bDone))
		bDone	= FALSE ;
	if (! bDone) {
		if (ImeDoc_bRecursiveEditp (pDoc)) {
			ImeDoc_vSetSignal (pDoc, LMSIGNAL_EXIT_MINIBUFFER) ;
		}
	}
	return	LMR_RETURN ;
}

/*======================================================================== abort-recursive-edit
 */
static	int		LM_bAbortRecursiveEdit_1 (struct CImeDoc*) ;

int
LM_bAbortRecursiveEdit (
	struct CImeDoc*				pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bCall (pDoc, LM_bSkkAdAbortRecursiveEdit, LM_bAbortRecursiveEdit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bAbortRecursiveEdit_1 (
	struct CImeDoc*				pDoc)
{
	BOOL	bDone ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_RETVAL, &bDone))
		bDone	= FALSE ;
	if (! bDone) {
		if (ImeDoc_bRecursiveEditp (pDoc)) {
			ImeDoc_vSetSignal (pDoc, LMSIGNAL_ABORT_RECURSIVE_EDIT) ;
		}
	}
	return	LMR_RETURN ;
}

/*======================================================================== new-line
 */
static	int		LM_bNewline_1	(struct CImeDoc*) ;

int
LM_bNewline (
	struct CImeDoc*				pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bCall (pDoc, LM_bSkkAdNewline, LM_bNewline_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bNewline_1 (
	struct CImeDoc*				pDoc)
{
	BOOL	bProcess ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_RETVAL, &bProcess))
		bProcess	= FALSE ;
	if (! bProcess) 
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
	return	LMR_RETURN ;
}

/*======================================================================== next-line
 */
int
LM_bNextLine (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	struct TMarker*		pmkTop ;
	int					nPosition, nBufferEnd, nBufferTop, nPoint, nOffset, nText ;
	LPCDSTR				pwText, pwPos ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}
	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL) {
		ImeDoc_vSetSignal (pDoc, LMSIGNAL_QUIT) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= TMarker_iGetPosition (pmkTop) ;
	} else {
		nBufferTop	= 0 ;
	}
	nBufferEnd		= TMarker_iGetPosition (pmkEnd) ;
	nPoint			= TMarker_iGetPosition (pmkPoint) ;
	pwText			= ImeBuffer_pBufferRawString (pCurBuffer, &nText) ;

	if (ImeDoc_iGetLastCommand (pDoc) != NFUNC_NEXT_LINE && ImeDoc_iGetLastCommand (pDoc) != NFUNC_PREVIOUS_LINE) {
		/*	�I�t�Z�b�g�̌v�Z�������B
		 */
		nPosition	= nPoint ;
		pwPos		= pwText + TMarker_iGetPosition (pmkPoint) ;
		while (nPosition >= nBufferTop && *pwPos != L'\n') {
			pwPos		-- ;
			nPosition	-- ;
		}
		nOffset		= nPoint - nPosition ;
	} else {
		/*	�O��̃I�t�Z�b�g�̍ė��p�B
		 */
		nOffset		= ImeBuffer_iGetLineOffset (pCurBuffer) ;
	}

	/*	�ŏ��̈ʒu�ɖ߂��B
	 */
	nPosition	= nPoint ;
	while (nPosition < nBufferEnd) {
		if (*pwPos == L'\n') 
			break ;
		pwPos		++ ;
		nPosition	++ ;
	}
	if (nPosition < nBufferEnd && *pwPos == L'\n') {
		int			n	= nOffset ;
		nPosition	++ ;
		pwPos		++ ;
		while (nPosition < nBufferEnd && *pwPos != L'\n' && n > 0) {
			pwPos		++ ;
			nPosition	++ ;
			nOffset		-- ;
		}
	} else {
		nPosition	= nBufferEnd ;
	}

	/*	���ă}�[�J���ړ������悤�B
	 */
	if (nPosition > nPoint) {
		/* �o�b�t�@�̍Ō�܂ŗ��Ă�����A���s������Ƃ������V������̂����B*/
		TMarker_bForward (pmkPoint, nPosition - nPoint) ;
	}

	/*	����̃I�t�Z�b�g���L�����Ă������B
	 */
	ImeBuffer_vSetLineOffset (pCurBuffer, nOffset) ;
	return	LMR_RETURN ;
}

/*======================================================================== new-line
 */
int
LM_bPreviousLine (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	struct TMarker*		pmkTop ;
	int					nPosition, nBufferEnd, nBufferTop, nPoint, nOffset, nText ;
	LPCDSTR				pwText, pwPos ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}
	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL) {
		ImeDoc_vSetSignal (pDoc, LMSIGNAL_QUIT) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= TMarker_iGetPosition (pmkTop) ;
	} else {
		nBufferTop	= 0 ;
	}
	nBufferEnd		= TMarker_iGetPosition (pmkEnd) ;
	nPoint			= TMarker_iGetPosition (pmkPoint) ;
	pwText			= ImeBuffer_pBufferRawString (pCurBuffer, &nText) ;

	if (ImeDoc_iGetLastCommand (pDoc) != NFUNC_NEXT_LINE && ImeDoc_iGetLastCommand (pDoc) != NFUNC_PREVIOUS_LINE) {
		/*	�I�t�Z�b�g�̌v�Z�������B
		 */
		nPosition	= nPoint ;
		pwPos		= pwText + TMarker_iGetPosition (pmkPoint) ;
		while (nPosition >= nBufferTop && *pwPos != L'\n') {
			pwPos		-- ;
			nPosition	-- ;
		}
		nOffset		= nPoint - nPosition ;
	} else {
		/*	�O��̃I�t�Z�b�g�̍ė��p�B
		 */
		nOffset		= ImeBuffer_iGetLineOffset (pCurBuffer) ;
	}

	/*	�ŏ��̈ʒu�ɖ߂��B
	 */
	nPosition	= nPoint ;
	while (nBufferTop <= nPosition && *pwPos != L'\n') {
		pwPos		-- ;
		nPosition	-- ;
	}
	if (nBufferTop < nPosition && *pwPos == L'\n') {
		int		n ;

		pwPos		-- ;
		nPosition	-- ;
		while (nBufferTop <= nPosition && *pwPos != L'\n') {
			pwPos		-- ;
			nPosition	-- ;
		}
		if (nBufferTop <= nPosition && *pwPos == L'\n') {
			/* 1�߂��Ă���v�Z�B*/
			pwPos		++ ;
			nPosition	++ ;
		} else {
			/* buffer-top ����v�Z�B*/
			pwPos		= pwText + nBufferTop ;
			nPosition	= nBufferTop ;
		}

		/*	offset �ʒu�ɂ��킹��B
		 */
		n	= nOffset ;
		while (nPosition < nPoint && n > 0 && *pwPos != L'\n') {
			pwPos		++ ;
			nPosition	++ ;
			n			-- ;
		}
	} else {
		nPosition	= nBufferTop ;
	}

	/*	���ă}�[�J���ړ������悤�B
	 */
	if (nPosition < nPoint) {
		/* �o�b�t�@�̍Ō�܂ŗ��Ă�����A���s������Ƃ������V������̂����B*/
		TMarker_bBackward (pmkPoint, nPoint - nPosition) ;
	}

	/*	����̃I�t�Z�b�g���L�����Ă������B
	 */
	ImeBuffer_vSetLineOffset (pCurBuffer, nOffset) ;
	return	LMR_RETURN ;
}

/*======================================================================== backward-word
 */
int
LM_bBackwardWord (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkTop ;
	int		nPoint, nBufferTop, nPointBak, nText ;
	LPCDSTR	pwText ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	nBufferTop		= TMarker_iGetPosition (pmkTop) ;
	nPoint			= TMarker_iGetPosition (pmkPoint) ;
	nPointBak		= nPoint ;
	pwText			= ImeBuffer_pBufferRawString (pBuffer, &nText) ;
	if (nBufferTop < nPoint) {
		nPoint	-- ;
		while (nBufferTop < nPoint && IS_BLANKCHAR (pwText [nPoint]))
			nPoint	-- ;
		if (nBufferTop < nPoint) {
			if (IS_ASCIICHAR (pwText [nPoint])) {
				while (nBufferTop <= nPoint) {
					if (IS_BLANKCHAR (pwText [nPoint]) || ! IS_ASCIICHAR (pwText [nPoint])) 
						break ;
					nPoint -- ;
				}
			} else {
				while (nBufferTop <= nPoint) {
					if (IS_BLANKCHAR (pwText [nPoint]) || IS_ASCIICHAR (pwText [nPoint])) 
						break ;
					nPoint -- ;
				}
			}
			nPoint	++ ;
		}
	}
	if (nPoint < nPointBak) {
		if (! TMarker_bBackward (pmkPoint, nPointBak - nPoint)) 
			ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== forward-word
 */
int
LM_bForwardWord (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	struct TMarker*		pmkTop ;
	int	nBufferTop, nBufferEnd, nPoint, nPointBak, nText ;
	LPCDSTR	pwText ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bProcessEventp (pDoc)) {
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL ||
		! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFERTOP, &pmkTop)   || pmkTop   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	nBufferTop		= TMarker_iGetPosition (pmkTop) ;
	nBufferEnd		= TMarker_iGetPosition (pmkEnd) ;
	nPoint			= TMarker_iGetPosition (pmkPoint) ;
	nPointBak		= nPoint ;
	pwText			= ImeBuffer_pBufferRawString (pBuffer, &nText) ;
	if (nPoint < nBufferEnd) {
		if (IS_ASCIICHAR (pwText [nPoint])) {
			while (nPoint < nBufferEnd && ! IS_BLANKCHAR (pwText [nPoint]) && IS_ASCIICHAR (pwText [nPoint]))
				nPoint	++ ;
		} else {
			while (nPoint < nBufferEnd && ! IS_BLANKCHAR (pwText [nPoint]) && ! IS_ASCIICHAR (pwText [nPoint]))
				nPoint	++ ;
		}
		while (nPoint < nBufferEnd && IS_BLANKCHAR (pwText [nPoint]))
			nPoint	++ ;
	}
	if (nPoint > nPointBak) {
		if (! TMarker_bForward (pmkPoint, nPoint - nPointBak)) 
			ImeDoc_vSetSignalError (pDoc) ;
	}
	return	LMR_RETURN ;
}

/*======================================================================== ...
 */
int
LM_bUnprecessEvent (
	struct CImeDoc*				pDoc)
{
	if (! ImeDoc_bProcessEventp (pDoc)) {
		/*	��芸�����C�x���g�𑗂�Ԃ����Ƃɂ���B
		 */
		(void) ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
	}
	return	LMR_RETURN ;
}


