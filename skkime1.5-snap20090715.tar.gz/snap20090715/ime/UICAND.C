/* # SKKIME1.0 (Simple Kana-Kanji Input Method Editor for Windows2000)
 * UICAND.C
 * This file is part of skkime1.0.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "commctrl.h"
#include "immdev.h"
#include "skki1_5.h"
#include "ImeConfig.h"
#include "resource.h"

#define	MAX_ANNOTATIONS				32
#define	NBUFFER_ANNOTATION_TEXT		1024
#define	SKKIME_DEFAULT_HOVERTIME	(400)
#define	TIMEEV_SHOWANNOTATION		(0)

enum {
	UICAND_INVALIDMODE				= -1,
	UICAND_SHOWHANKANCANDIDATESMODE	= 0,
	UICAND_INPUTBYCODEORMENUMODE,
} ;

typedef struct tagTEXTREGION {
	DWORD		m_nCandidate ;
	int			m_nOffset ;
	int			m_nLength ;
}	TEXTREGION, *PTEXTREGION ;

typedef struct tagMYTOOLTIPINFO {
	int			_nCount ;
	POINT		_ptLastPos ;
	RECT		_rrcHitArea [MAX_ANNOTATIONS] ;
	int			_rnOffsets [MAX_ANNOTATIONS] ;
	int			_rnLengths [MAX_ANNOTATIONS] ;
	MYCHAR		_bufText [NBUFFER_ANNOTATION_TEXT] ;
}	MYTOOLTIPINFO, *PTOOLTIPINFO ;

/*
 *	�v���g�^�C�v�錾�B
 */
static	void	uiCand_vOnPaint			(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnSetCursor		(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnMove			(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnTimer			(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnDestroy		(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnPaint			(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnMouseMove		(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnNcMouseMove	(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnButtonDown	(HWND, UINT, WPARAM, LPARAM) ;
static	void	uiCand_vOnButtonUp		(HWND, UINT, WPARAM, LPARAM) ;
static	BOOL	uiCand_bMinibuffered	(LPINPUTCONTEXT) ;
static	int		uiCand_iGetMinibufferCursorPos		(HWND, HIMC, POINT*) ;
static	BOOL	uiCand_bHandleMinibufContextMenu	(HWND, HIMC) ;
static	int		uiCand_iPopupMinibufContextMenu		(HWND, HIMC) ;


static	BOOL	PASCAL	uiCand_bMoveDefault (HWND, LPINPUTCONTEXT, LPUIEXTRA) ;
static	BOOL	PASCAL	uiCand_bMoveExclude (HWND, LPINPUTCONTEXT, LPUIEXTRA) ;
static	BOOL	PASCAL	uiCand_bMovePosition (HWND, LPINPUTCONTEXT, LPUIEXTRA) ;
static	BOOL	PASCAL	uiCand_bPaint (HWND, HDC, HIMC, LPRECT) ;
static	BOOL	PASCAL	uiCand_bPaintMinibufferText (HWND, HDC, LPINPUTCONTEXT, LPCANDIDATELIST, LPRECT) ;
static	BOOL			uiCand_bGetMinibufferTextSize (HWND, HDC, LPINPUTCONTEXT, LPCANDIDATELIST, int, SIZE*) ;

static	HWND	PASCAL	uiCand_hCreateToolTip (HWND) ;
static	BOOL	PASCAL	uiCand_bAdjustSize (HWND, LPINPUTCONTEXT, LPSIZE) ;
static	BOOL	PASCAL	uiCand_bConfigureAnnotation (HWND, LPINPUTCONTEXT) ;
static	void	PASCAL	uiCand_vHitTestAnnotation (HWND, const POINT*) ;
static	BOOL	PASCAL	uiCand_bHideToolTipp (HWND) ;

static	int		uiCand_iGetHenkanShowCandidatesText (LPWSTR, int, PTEXTREGION, LPCANDIDATELIST, LPCWSTR, int) ;
static	int		uiCand_iGetInputByCodeOrMenuText	(LPWSTR, int, PTEXTREGION, LPCANDIDATELIST, LPCWSTR, int) ;
static	BOOL	uiCand_bPaint						(HWND, HDC, HIMC, LPRECT) ;
static	BOOL	uiCand_bPaintHenkanCandidatesList	(HWND, HDC, LPCANDIDATELIST, LPRECT, LPCWSTR, int) ;
static	BOOL	uiCand_bPaintCodeList				(HWND, HDC, LPCANDIDATELIST, LPRECT, LPCWSTR, int) ;
static	int		uiCand_iGetCandidateMenuKeys		(LPINPUTCONTEXT, LPWSTR, int, int*) ;

static	BOOL	uiCand_bShowBalloonTip			(HWND, LPINPUTCONTEXT) ;
static	BOOL	uiCand_bNeedCandidateWindowp	(LPINPUTCONTEXT) ;
static	void	uiCand_vAdjustPosition			(const RECT*, const SIZE*, POINT*) ;


/*
 *	---- �֐��̒�` ---- ��������---- �֐��̒�` ---- ��������----
 */

/*
 *	Candidate Window �� WINDOWPROC�B
 *(�R�����g)
 *	Candidate Window ����Window Message�͂��̊֐��ɑ����ė��܂��̂ŁA
 *	Window Message �ɑΉ������������s���܂��B���̊֐����̂� Window
 *	Message �̐U�蕪�������ł����ǁB
 *(����)
 *	hWnd	Window Message ���󂯎���� Composition Window �� Handle
 *	message	Window Message
 *	wParam	Window Message �̈�������1
 *	lParam	Window Message �̈�������2
 *(����)
 *	Candidate Window �͕ϊ���⃊�X�g��\������̂Ɏg�� Window �ł��B
 */
LRESULT	CALLBACK
UICand_WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND		hUIWnd ;
	HGLOBAL	hUICandInfo ;

	DEBUGPRINTF ((TEXT ("Message:%d, WPARAM: 0x%lx, LPARAM: 0x%0lx\n"), message, wParam, lParam)) ;

	switch (message){
	case WM_PAINT:
		uiCand_vOnPaint (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_SETCURSOR:
		uiCand_vOnSetCursor (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_MOUSEMOVE:
		uiCand_vOnMouseMove (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_NCMOUSEMOVE:
		uiCand_vOnNcMouseMove (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_LBUTTONDOWN:
	case	WM_RBUTTONDOWN:
		uiCand_vOnButtonDown (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_LBUTTONUP:
	case	WM_RBUTTONUP:
		uiCand_vOnButtonUp (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_MOVE:
		uiCand_vOnMove (hWnd, message, wParam, lParam) ;
		break;

	case	WM_TIMER:
		uiCand_vOnTimer (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_DESTROY:
		uiCand_vOnDestroy (hWnd, message, wParam, lParam) ;
		break ;

	default:
		if (!MyIsIMEMessage (message))
			return DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	0L ;
}

/*************************************************************************
 *	CreateCandWindow
 *		���\���ɗp���� Window ���쐬����֐��B
 *************************************************************************/
void	PASCAL
UICand_Create (
	HWND				hUIWnd,
	LPUIEXTRA			lpUIExtra,
	LPINPUTCONTEXT		lpIMC)
{
	HINSTANCE			hInstance ;
	POINT				pt ;
	HGLOBAL	hUICandInfo ;

	DEBUGPRINTFEX (106, (TEXT ("UICand_Create (index:%d, style:%d, lpIMC->hWnd:0x%x, hUIWnd:0x%x)\n)\n"), 
		(int)lpIMC->cfCandForm [0].dwIndex, (int) lpIMC->cfCandForm [0].dwStyle,
		(DWORD) lpIMC->hWnd, (DWORD) hUIWnd)) ;

	if (UICand_GetPosFromCompWnd (lpUIExtra, &pt)){
		lpUIExtra->uiCand.pt.x	= pt.x ;
		lpUIExtra->uiCand.pt.y	= pt.y ;
	}

	hInstance	= (HINSTANCE)GetWindowLongPtr (hUIWnd, GWLP_HINSTANCE) ;

	if (!IsWindow (lpUIExtra->uiCand.hWnd)){
		HWND	hwndUICand, hwndTT ;

		hwndUICand	= CreateWindowEx (WS_EX_WINDOWEDGE,
								(LPTSTR)g_szCandClassName, NULL,
								WS_COMPDEFAULT | WS_DLGFRAME,
								lpUIExtra->uiCand.pt.x,
								lpUIExtra->uiCand.pt.y,
								1, 1,
								hUIWnd, NULL, hInstance, NULL) ;
		lpUIExtra->uiCand.hWnd	= hwndUICand ;

		hwndTT		= CreateWindowEx (WS_EX_TOPMOST, (LPTSTR)g_szCandAnnotClassName, NULL, 
			WS_COMPDEFAULT | WS_BORDER, 0, 0, 1, 1, hwndUICand, NULL, hInstance, NULL) ;
		if (hwndTT != NULL && IsWindow (hwndTT)) {
			SetWindowLongPtr (hwndTT, FIGWLP_UIANNOT_SVRWND,  (LONG_PTR) hUIWnd) ;
			SetWindowLongPtr (hwndTT, FIGWLP_UIANNOT_TEXT,    (LONG_PTR) 0) ;
			ShowWindow (hwndTT, SW_HIDE) ;
		}
		SetWindowLongPtr (hwndUICand, FIGWLP_UICAND_TOOLTIP,		(LONG_PTR) hwndTT) ;
		SetWindowLongPtr (hwndUICand, FIGWLP_UICAND_TOOLTIPINFO,	(LONG_PTR) GlobalAlloc (GHND, sizeof (MYTOOLTIPINFO))) ;
	}
	SetWindowLongPtr (lpUIExtra->uiCand.hWnd, FIGWLP_UICAND_SVRWND,  (LONG_PTR) hUIWnd) ;
	ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
	lpUIExtra->uiCand.bShow	= FALSE ;

	SetWindowLong    (lpUIExtra->uiCand.hWnd, FIGWL_UICAND_MOUSE,   0L) ;
	return ;
}

/*************************************************************************
 *	UICand_Hide
 *		���\�������\����Ԃɂ���B
 *************************************************************************/
void	PASCAL
UICand_Hide (
	LPUIEXTRA		lpUIExtra)
{
	HWND	hwndTT ;
	RECT	rc ;

	DEBUGPRINTFEX (99, (TEXT ("UICand_Hide ()\n"))) ;

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, (LPRECT)&rc);
		lpUIExtra->uiCand.pt.x	= rc.left ;
		lpUIExtra->uiCand.pt.y	= rc.top ;
		MoveWindow (lpUIExtra->uiCand.hWnd, -1 , -1 , 0 , 0, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		lpUIExtra->uiCand.bShow	= FALSE ;

		hwndTT	= (HWND) GetWindowLongPtr (lpUIExtra->uiCand.hWnd, FIGWLP_UICAND_TOOLTIP) ;
		if (hwndTT != NULL && IsWindow (hwndTT)) 
			ShowWindow (hwndTT, SW_HIDE) ;
	}
	return ;
}

/*
 */
static	BOOL	PASCAL
uiCand_bIsDefaultStylep (
	LPINPUTCONTEXT	lpIMC)
{
	return	(lpIMC->cfCandForm [0].dwIndex == -1)? TRUE : FALSE ;
}

/*************************************************************************
 *	UICand_Move
 *		���\����������̈ʒu�Ɉړ�������B�ǂ̈ʒu���͕ϊ��N���C�A���g��
 *		�w������B
 *************************************************************************/
void	PASCAL
UICand_Move (
	HWND			hUIWnd,
	LPINPUTCONTEXT	lpIMC,
	LPUIEXTRA		lpUIExtra,
	BOOL			fForceComp)
{
	POINT			pt ;
	CANDIDATEFORM	caf ;

	if (! (lpUIExtra->dwShowStyle & ISC_SHOWUIALLCANDIDATEWINDOW))
		return ;

	DEBUGPRINTFEX (106, (TEXT ("UICand_Move (index:%d, style:%d)\n"), 
		(int)lpIMC->cfCandForm [0].dwIndex, (int) lpIMC->cfCandForm [0].dwStyle)) ;

	/*	CompositionWindow �̈ʒu���ύX���ꂽ�ꍇ�ACandidateWindow �̈ʒu��
	 *	Default �ł��������̂݉e������邱�Ƃɂ���B
	 */
	if (fForceComp) {
		if (uiCand_bIsDefaultStylep (lpIMC)) {
			uiCand_bMoveDefault (hUIWnd, lpIMC, lpUIExtra) ;

			if (TSkkIme_bHasCandidateListp (lpIMC) && IsWindow (lpUIExtra->uiCand.hWnd)) 
				uiCand_bShowBalloonTip (lpUIExtra->uiCand.hWnd, lpIMC) ;
		}
		return ;
	}

	/*	Tooltip ���S��CandidateWindow�����Ȃ̂ŁA�܂�����ł͂����đ��v�B
	 */
	if (! TSkkIme_bHasCandidateListp (lpIMC))
		return ;


	if (ImmGetIMCCSize (lpIMC->hCandInfo) < sizeof (CANDIDATEINFO)) {
		return ;
	} else {
		LPCANDIDATEINFO	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
		int	iCount ;
		if (lpCandInfo == NULL)
			return ;
		iCount	= lpCandInfo->dwCount ;
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
		if (iCount <= 0)
			return ;
	}
	if (uiCand_bIsDefaultStylep (lpIMC)) {
		uiCand_bMoveDefault (hUIWnd, lpIMC, lpUIExtra) ;
	} else if (lpIMC->cfCandForm [0].dwStyle == CFS_EXCLUDE){
		uiCand_bMoveExclude (hUIWnd, lpIMC, lpUIExtra) ;
	} else if (lpIMC->cfCandForm[0].dwStyle == CFS_CANDIDATEPOS){
		uiCand_bMovePosition (hUIWnd, lpIMC, lpUIExtra) ;
	}
	if (IsWindow (lpUIExtra->uiCand.hWnd)) {
		if (ImeConfig_iGetSkkShowAnnotationType () != SHOW_NO_ANNOTATION) 
			uiCand_bConfigureAnnotation (lpUIExtra->uiCand.hWnd, lpIMC) ;
		uiCand_bShowBalloonTip (lpUIExtra->uiCand.hWnd, lpIMC) ;
	}
	return ;
}

/*************************************************************************
 *	GetCansPosFromCompWnd ()
 *		���\������ Composition Window �ɂ�����Ȃ��悤�Ȉʒu�𓾂�B
 *		���\���������R�Ȉʒu�ɔz�u�ł���Ηǂ��̂����A����c����������
 *		���ȍ��ɂ͂Ȃ��Ă��Ȃ��B�Œ�ʒu�B
 *		������AComposition Window ���B���Ă��܂��ƂƂĂ����f�B
 *************************************************************************/
BOOL	PASCAL
UICand_GetPosFromCompWnd (
	LPUIEXTRA		lpUIExtra,
	LPPOINT			lppt)
{
	RECT rc ;

	if (lpUIExtra->dwCompStyle){
		if (IsWindow (lpUIExtra->uiComp [0].hWnd) && lpUIExtra->uiComp [0].bShow) {
			RECT	rcWnd ;
			int		i ;

			GetWindowRect (lpUIExtra->uiComp [0].hWnd, &rc) ;
			for (i = 1 ; i < MAXCOMPWND ; i ++) {
				if (! IsWindow (lpUIExtra->uiComp [i].hWnd) || ! lpUIExtra->uiComp [i].bShow)
					break ;
				GetWindowRect (lpUIExtra->uiComp [i].hWnd, &rcWnd) ;
				rc.left		= (rc.left   < rcWnd.left)?   rc.left   : rcWnd.left ;
				rc.top		= (rc.top    < rcWnd.top)?    rc.top    : rcWnd.top ;
				rc.right	= (rc.right  > rcWnd.right)?  rc.right  : rcWnd.right ;
				rc.bottom	= (rc.bottom > rcWnd.bottom)? rc.bottom : rcWnd.bottom ;
			}
			lppt->x	= rc.left ;
			lppt->y	= rc.bottom + 1 ;
			return	TRUE ;
		}
	} else {
		if (lpUIExtra->uiDefComp.bShow){
			GetWindowRect (lpUIExtra->uiDefComp.hWnd, &rc) ;
			lppt->x	= rc.left ;
			lppt->y	= rc.bottom + 1 ;
			return	TRUE ;
		}
	}
	return	FALSE ;
}

BOOL	PASCAL
UICand_GetPosFromCompForm (
	LPINPUTCONTEXT	lpIMC,
	LPUIEXTRA		lpUIExtra,
	LPPOINT			lppt)
{
	TEXTMETRIC	tm ;

	if (lpUIExtra->dwCompStyle){
		if (lpIMC && lpIMC->fdwInit & INIT_COMPFORM){
			GetCompFontMetrics (lpUIExtra, &tm) ;
			if (!lpUIExtra->bVertical){
				lppt->x	= lpIMC->cfCompForm.ptCurrentPos.x ;
				lppt->y	= lpIMC->cfCompForm.ptCurrentPos.y + tm.tmHeight ;
			} else {
				lppt->x	= lpIMC->cfCompForm.ptCurrentPos.x ;
				lppt->y	= lpIMC->cfCompForm.ptCurrentPos.y + tm.tmMaxCharWidth ;
			}
			ClientToScreen (lpIMC->hWnd, lppt) ;
			return	TRUE ;
		}
	}
	return	FALSE ;
}

/*========================================================================
 *	Window Message Handlers
 */
void
uiCand_vOnPaint (
	HWND		hCandWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	PAINTSTRUCT		ps ;
	HIMC			hIMC ;
	HBRUSH			hbr ;
	HDC				hDC ;
	RECT			rc ;
	HWND	hSvrWnd ;
	HBRUSH 			hBrushParent ;
	HDC				hPDC ;

	GetClientRect (hCandWnd, &rc) ;
	hDC				= BeginPaint (hCandWnd, &ps) ;

	/* ���\��������U�e Window �̔w�i�F�œh��Ԃ��B*/
	hPDC			= GetDC (GetParent (hCandWnd)) ;
	hBrushParent	= CreateSolidBrush (GetBkColor (hPDC)) ;
	hbr				= SelectObject (hDC, hBrushParent) ;
	PatBlt (hDC, 0, 0, rc.right - rc.left, rc.bottom - rc.top, PATCOPY) ;
	SelectObject (hDC, hbr) ;
	DeleteObject (hBrushParent) ;
	ReleaseDC (GetParent (hCandWnd), hPDC) ;
	SetTextColor (hDC, RGB (0, 0, 0)) ;
	SetBkMode (hDC, TRANSPARENT) ;

	/* ���ꗗ��\������B*/
	hSvrWnd			= (HWND)GetWindowLongPtr (hCandWnd, FIGWLP_UICAND_SVRWND) ;
	hIMC			= (HIMC)GetWindowLongPtr (hSvrWnd, IMMGWLP_IMC) ;
	uiCand_bPaint (hCandWnd, hDC, hIMC, &rc) ;
	EndPaint (hCandWnd, &ps) ;
	return ;
}

void
uiCand_vOnSetCursor (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HIMC			hIMC ;
	HWND			hwndTT ;
	HWND			hSvrWnd ;
	LPINPUTCONTEXT	lpIMC ;
	BOOL			bMinibuffered ;

	hwndTT	= (HWND) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIP) ;
	if (IsWindow (hwndTT) && uiCand_bHideToolTipp (hWnd))
		ShowWindow (hwndTT, SW_HIDE) ;

	hSvrWnd	= (HWND)GetWindowLongPtr (hWnd,		FIGWLP_UICAND_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,	IMMGWLP_IMC) ;
	if (! hIMC)
		return ;

	lpIMC		= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL) 
		return ;
	bMinibuffered	= uiCand_bMinibuffered (lpIMC) ;
	ImmUnlockIMC (hIMC) ;

	if (bMinibuffered) {
		switch (HIWORD (lParam)) {
		case	WM_LBUTTONDOWN:
		case	WM_RBUTTONDOWN:
			uiCand_vOnButtonDown (hWnd, HIWORD(lParam), 0, 0) ;
			break ;
		case	WM_LBUTTONUP:
		case	WM_RBUTTONUP:
			uiCand_vOnButtonUp (hWnd, HIWORD(lParam), 0, 0) ;
			break ;
		default:
			uiCand_vOnMouseMove (hWnd, WM_MOUSEMOVE, 0, 0) ;
			break ;
		}
	} else {
		/* tooltip �̏����B*/
		if (HIWORD(lParam) != WM_LBUTTONDOWN && HIWORD(lParam) != WM_RBUTTONDOWN) {
			UINT	uHoverTime ;
			if (ImeConfig_iGetSkkShowAnnotationType () != SHOW_NO_ANNOTATION) {
				if (! SystemParametersInfo (SPI_GETMOUSEHOVERTIME, 0, &uHoverTime, 0))
					uHoverTime	= SKKIME_DEFAULT_HOVERTIME ;
				SetTimer (hWnd, TIMEEV_SHOWANNOTATION, uHoverTime, NULL) ;
			}
		}
	}
	return ;
}

void
uiCand_vOnMove (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND	hUIWnd ;

	hUIWnd	= (HWND)GetWindowLongPtr (hWnd, FIGWLP_UICAND_SVRWND) ;
	if (IsWindow (hUIWnd))
		SendMessage (hUIWnd, WM_UI_CANDMOVE, wParam, lParam) ;
	return ;
}

void
uiCand_vOnTimer (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	KillTimer (hWnd, wParam) ;

	if (ImeConfig_iGetSkkShowAnnotationType () != SHOW_NO_ANNOTATION) {
		POINT		pt ;

		GetCursorPos (&pt) ;
		ScreenToClient (hWnd, &pt) ;
		uiCand_vHitTestAnnotation (hWnd, &pt) ;
	}
	return ;
}

void
uiCand_vOnDestroy (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HGLOBAL	hToolTipInfo ;
	HWND	hwndTT ;

	hToolTipInfo	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIPINFO) ;
	if (hToolTipInfo != 0) 
		GlobalFree (hToolTipInfo) ;

	hwndTT	= (HWND) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIP) ;
	if (hwndTT != NULL && IsWindow (hwndTT))
		DestroyWindow (hwndTT) ;
	return ;
}

void
uiCand_vOnMouseMove (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND			hSvrWnd ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	POINT			pos ;
	DWORD			dwButtonPressed ;
	SIZE			sz ;

	dwButtonPressed	= (DWORD)GetWindowLong (hWnd, FIGWL_UICAND_MOUSE) ;
	if (! dwButtonPressed)
		return ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (hWnd, &pos))
		return ;

	hSvrWnd	= (HWND)GetWindowLongPtr (hWnd,		FIGWLP_UICAND_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,	IMMGWLP_IMC) ;
	if (! hIMC)
		return ;

	lpIMC		= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL) 
		return ;

	if (uiCand_bMinibuffered (lpIMC)) {
		LPMYCOMPSTR		lpMyCompStr ;
		int				nPrevPos ;

		/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr != NULL) {
			if (ImeDoc_bGetStatusCursor (&lpMyCompStr->_Doc, &nPrevPos)){
				struct TMSG		msg ;
				int		iCursorPos ;
				BOOL	fEaten ;

				iCursorPos	= uiCand_iGetMinibufferCursorPos (hWnd, hIMC, &pos) ;

				msg.m_nMessage	= WM_LM_COMMAND ;
				msg.m_pt.x		= pos.x ;
				msg.m_pt.y		= pos.y ;
				msg.m_nTime		= GetTickCount () ;
				msg.m_wParam	= NFUNC_MOUSE_DRAG_REGION ;
				msg.m_lParam	= iCursorPos ;
				msg.m_rParam	= 0 ;
				if (ImeDoc_bFilterEvent (&lpMyCompStr->_Doc, &msg)) 
					TSkkIme_bUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr) ;

				if (! ImeDoc_bGetStatusCursor (&lpMyCompStr->_Doc, &iCursorPos) || nPrevPos != iCursorPos)
					InvalidateRect (hWnd, NULL, FALSE) ;
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
	}
	ImmUnlockIMC (hIMC) ;
	/*DragUI (hWnd, message, wParam, lParam) ;*/
	return ;
}

void
uiCand_vOnNcMouseMove (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	uiCand_vOnMouseMove (hWnd, WM_MOUSEMOVE, wParam, lParam) ;
	return ;
}

void
uiCand_vOnButtonDown (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND			hSvrWnd ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPMYCOMPSTR		lpMyCompStr ;
	LPCANDIDATEINFO	lpCandInfo ;
	POINT			pos ;
	DWORD			dwButtonPressed ;

	hSvrWnd	= (HWND)GetWindowLongPtr (hWnd,		FIGWLP_UICAND_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,	IMMGWLP_IMC) ;
	if (! hIMC)
		return ;

	dwButtonPressed	= (DWORD)GetWindowLong (hWnd, FIGWL_UICAND_MOUSE) ;
	GetCursorPos (&pos) ;
	if (!ScreenToClient (hWnd, &pos))
		return ;

	lpIMC		= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL)
		return ;
	if (! uiCand_bMinibuffered (lpIMC))
		goto	exit_func_1 ;

	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr != NULL) {
		int		nPrevPos ;

		if (ImeDoc_bGetStatusCursor (&lpMyCompStr->_Doc, &nPrevPos)) {
			struct TMSG	msg ;
			BOOL		fRedraw, fEaten ;
			int			iCursorPos ;

			if (message == WM_LBUTTONDOWN) {
				iCursorPos	= uiCand_iGetMinibufferCursorPos (hWnd, hIMC, &pos) ;

				/*	WM_LBUTTONDOWN �Ƃ��Đ������p�����[�^���낤���H > wParam, lParam
				 */
				msg.m_nMessage	= WM_LM_COMMAND ;
				msg.m_pt.x		= pos.x ;
				msg.m_pt.y		= pos.y ;
				msg.m_nTime		= GetTickCount () ;
				msg.m_wParam	= NFUNC_MOUSE_DRAG_REGION ;
				msg.m_lParam	= iCursorPos ;
				msg.m_rParam	= 0 ;
				if (ImeDoc_bFilterEvent (&lpMyCompStr->_Doc, &msg))
					TSkkIme_bUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr) ;
				if (! ImeDoc_bGetStatusCursor (&lpMyCompStr->_Doc, &iCursorPos) || nPrevPos != iCursorPos)
					InvalidateRect (hWnd, NULL, FALSE) ;
			}
			SetWindowLong (hWnd, FIGWL_UICAND_MOUSE, (LONG)1L) ;
			SetCapture (hWnd) ;
		}
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
exit_func_1:
	ImmUnlockIMC (hIMC) ;
	return ;
}

void
uiCand_vOnButtonUp (
	HWND		hWnd,
	UINT		message,
	WPARAM		wParam,
	LPARAM		lParam)
{
	HWND			hSvrWnd ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	POINT			pos ;
	DWORD			dwButtonPressed ;

	dwButtonPressed	= (DWORD)GetWindowLong (hWnd, FIGWL_UICAND_MOUSE) ;
	/*
	 * �}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 * �ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (! dwButtonPressed) 
		goto	exit_func ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (hWnd, &pos))
		goto	exit_func ;

	hSvrWnd	= (HWND)GetWindowLongPtr (hWnd,		FIGWLP_UICAND_SVRWND) ;
	hIMC	= (HIMC)GetWindowLongPtr (hSvrWnd,	IMMGWLP_IMC) ;
	if (hIMC == NULL)
		goto	exit_func ;

	lpIMC		= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL)
		goto	exit_func ;

	if (uiCand_bMinibuffered (lpIMC)) {
		LPMYCOMPSTR		lpMyCompStr ;
		int				nPrevPos ;

		/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr != NULL) {
			if (ImeDoc_bGetStatusCursor (&lpMyCompStr->_Doc, &nPrevPos)){
				struct TMSG	msg ;
				BOOL		fRedraw, fEaten ;
				int			iCursorPos ;

				iCursorPos	= uiCand_iGetMinibufferCursorPos (hWnd, hIMC, &pos) ;
				if (dwButtonPressed && message == WM_LBUTTONUP){
					msg.m_nMessage	= WM_LM_COMMAND ;
					msg.m_pt.x		= pos.x ;
					msg.m_pt.y		= pos.y ;
					msg.m_nTime		= GetTickCount () ;
					msg.m_wParam	= NFUNC_MOUSE_DRAG_REGION_END ;
					msg.m_lParam	= iCursorPos ;
					msg.m_rParam	= 0 ;
					if (ImeDoc_bFilterEvent (&lpMyCompStr->_Doc, &msg)) 
						TSkkIme_bUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr) ;
					if (! ImeDoc_bGetStatusCursor (&lpMyCompStr->_Doc, &iCursorPos) || nPrevPos != iCursorPos)
						InvalidateRect (hWnd, NULL, FALSE) ;
				}
			}
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
	}
	ImmUnlockIMC (hIMC) ;
exit_func:
	SetWindowLong (hWnd, FIGWL_UICAND_MOUSE, (LONG)0L) ;
	ReleaseCapture () ;
	if (dwButtonPressed && message == WM_RBUTTONUP){
		uiCand_bHandleMinibufContextMenu (hWnd, hIMC) ;
	}
	/*DragUI (hWnd, message, wParam, lParam) ;
	SetWindowLong (hWnd, FIGWL_UICAND_MOUSE, 0L) ;*/
	return ;
}

/*========================================================================
 *	private functions
 */
BOOL	PASCAL
uiCand_bMoveDefault (
	HWND				hUIWnd,
	LPINPUTCONTEXT		lpIMC,
	LPUIEXTRA			lpUIExtra)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	RECT	rcWork ;
	POINT	pt, ptOffset, ptBase ;
	SIZE	sizeCandWnd ;

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, (LPRECT)&rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom = 0 ;
	}
	if (! UICand_GetPosFromCompWnd (lpUIExtra, &pt)){
		if (! UICand_GetPosFromCompForm (lpIMC, lpUIExtra, &pt))
			pt.x = pt.y = 0 ;
	}
	/* ��⑋�̑傫�����v�Z����B*/
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;
	sizeCandWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom     - rc.top       + 2 * GetSystemMetrics (SM_CYEDGE) ;
	uiCand_bAdjustSize (hUIWnd, lpIMC, &sizeCandWnd) ;

	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
	uiCand_vAdjustPosition (&rcWork, &sizeCandWnd, &pt) ;

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		if (uiCand_bNeedCandidateWindowp (lpIMC)) {
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_SHOWNOACTIVATE) ;
		} else {
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		}
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	}
	lpUIExtra->uiCand.bShow	= TRUE ;
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x,(WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL
uiCand_bMoveExclude (
	HWND			hUIWnd,
	LPINPUTCONTEXT	lpIMC,
	LPUIEXTRA		lpUIExtra)
{
	RECT	rc ;
	RECT	rcWork ;
	RECT	rcExclude ;
	RECT	rcUIWnd ;
	POINT	pt, ptOffset, ptBase ;
	SIZE	sizeCandWnd ;

	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetClientRect (lpUIExtra->uiCand.hWnd, &rc) ;
	} else {
		rc.left	= rc.top	= rc.bottom	= rc.right	= 0 ;
	}
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;

	/* ��⑋��\�����Ă͂����Ȃ��̈�𓾂�B*/
	pt.x	= lpIMC->cfCandForm [0].rcArea.left ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.top ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.left		= pt.x ;
	rcExclude.top		= pt.y ;
	pt.x	= lpIMC->cfCandForm [0].rcArea.right ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.bottom ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.right		= pt.x ;
	rcExclude.bottom	= pt.y ;

	/* ��⑋�̈ʒu�Ƒ傫�������肷��B*/
	sizeCandWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom - rc.top + 2 * GetSystemMetrics (SM_CYEDGE) ;
	uiCand_bAdjustSize (hUIWnd, lpIMC, &sizeCandWnd) ;

	pt.x	= lpIMC->cfCandForm [0].ptCurrentPos.x ;
	pt.y	= lpIMC->cfCandForm [0].ptCurrentPos.y ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	uiCand_vAdjustPosition (&rcWork, &sizeCandWnd, &pt) ;
	if (! IsCrossRectangle (&pt, &sizeCandWnd, &rcExclude))
		goto	_ok ;

	pt.x	= rcExclude.left ;
	pt.y	= rcExclude.bottom ;
	uiCand_vAdjustPosition (&rcWork, &sizeCandWnd, &pt) ;
	if (! IsCrossRectangle (&pt, &sizeCandWnd, &rcExclude))
		goto	_ok ;
	pt.x	= rcExclude.left ;
	pt.y	= rcExclude.top - sizeCandWnd.cy ;
	uiCand_vAdjustPosition (&rcWork, &sizeCandWnd, &pt) ;
	if (! IsCrossRectangle (&pt, &sizeCandWnd, &rcExclude))
		goto	_ok ;
	pt.x	= 0 ;
	pt.y	= rcUIWnd.bottom - rcUIWnd.top ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	uiCand_vAdjustPosition (&rcWork, &sizeCandWnd, &pt) ;
	if (! IsCrossRectangle (&pt, &sizeCandWnd, &rcExclude))
		goto	_ok ;

	pt.x	= rcExclude.left ;
	pt.y	= rcExclude.bottom ;	/* adjust �͂�����߂�B*/
_ok:
	/* �ǂ��ړ������悤�Ƃ����̂���\������B*/
	DEBUGPRINTF ((TEXT ("uiCand_bMoveExclude (%d, %d)/(%d, %d)-(%d,%d)\n"),
				  (int)pt.x, (int)pt.y,
				  rcExclude.left,
				  rcExclude.top,
				  rcExclude.right,
				  rcExclude.bottom)) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, &rc) ;
		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		if (uiCand_bNeedCandidateWindowp (lpIMC)) {
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_SHOWNOACTIVATE) ;
		} else {
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		}
		lpUIExtra->uiCand.bShow	= TRUE ;
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL
uiCand_bMovePosition (
	HWND			hUIWnd,
	LPINPUTCONTEXT	lpIMC, 
	LPUIEXTRA		lpUIExtra)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	RECT	rcWork ;
	SIZE	sizeCandWnd ;
	POINT	pt, ptOffset, ptBase ;
	WINDOWINFO	wi ;

	pt.x	= lpIMC->cfCandForm[0].ptCurrentPos.x ;
	pt.y	= lpIMC->cfCandForm[0].ptCurrentPos.y ;
	wi.cbSize	= sizeof (WINDOWINFO) ;
	if (GetWindowInfo (lpIMC->hWnd, &wi)) {
		pt.x	+= wi.rcWindow.left ;
		pt.y	+= wi.rcWindow.top  + GetSystemMetrics (SM_CYEDGE) ;
	} else {
		ClientToScreen (lpIMC->hWnd, &pt) ;
	}

	/*	Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) 
	 *	2nd, 3rd �̈ʒu�̖�肪����c�B
	 */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, &rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom	= 0 ;
	}

	/*	Window ����ʊO�ɏo�����Ƃ��Ӑ}���Ă��邩�H 
	 *
	 *	�ǂ�����ʊO���w�肷�邱�ƂŁA��\�����Ӑ}���Ă���
	 *	�A�v���P�[�V���������݂���悤���B
	 * (��)
	 *	PSO
	 *
	 *	IME_CONTROL �� Window �̕\����\��������ł���̂�
	 *	���̎�̗��Z�Ή��͂��Ȃ����ƂɘH���ύX�ł��B
#if 0
	if (((pt.x + 1) >= rcWork.right && (pt.y + 1) >= rcWork.bottom) || (pt.x == -1 && pt.y == -1)) {
		if (IsWindow (lpUIExtra->uiCand.hWnd))
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		lpUIExtra->uiCand.bShow	= FALSE ;
		return	TRUE ;
	}
#endif
	 */

	/* ��⑋�̑傫�����v�Z����B*/
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;
	sizeCandWnd.cx	= rcUIWnd.right - rcUIWnd.left + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom     - rc.top       + 1 * GetSystemMetrics (SM_CYEDGE) ;
	uiCand_bAdjustSize (hUIWnd, lpIMC, &sizeCandWnd) ;

	/*	Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B
	 */
	uiCand_vAdjustPosition (&rcWork, &sizeCandWnd, &pt) ;

	/* �ǂ��ړ������悤�Ƃ����̂���\������B*/
	DEBUGPRINTF ((TEXT ("uiCand_bMovePosition (%d, %d)/(%d, %d)/(%dx%d)\n"),
				  (int)pt.x, (int)pt.y,
				  (int)lpIMC->cfCandForm [0].ptCurrentPos.x,
				  (int)lpIMC->cfCandForm [0].ptCurrentPos.y,
				  rcWork.right, rcWork.bottom)) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		if (uiCand_bNeedCandidateWindowp (lpIMC)) {
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_SHOWNOACTIVATE) ;
		} else {
			ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		}
		lpUIExtra->uiCand.bShow	= TRUE ;
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL
uiCand_bPaint (
	HWND		hWnd,
	HDC		hDC,
	HIMC		hIMC,
	LPRECT		prcDraw)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCANDIDATEINFO		lpCandInfo ;
	LPCANDIDATELIST		lpCandList ;
	HFONT				hOldFont ;
	WCHAR				bufKeys [64] ;
	int					nKeys, nMode ;
	BOOL				bFontCreated	= FALSE ;

	if (hIMC == NULL)
		return	FALSE ;

	lpIMC		= ImmLockIMC (hIMC) ;
	nKeys		= uiCand_iGetCandidateMenuKeys (lpIMC, bufKeys, ARRAYSIZE (bufKeys), &nMode) ;
	if (ImmGetIMCCSize (lpIMC->hCandInfo) < sizeof (CANDIDATEINFO)) 
		goto	exit_func_1 ;
	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (lpCandInfo == NULL)
		goto	exit_func_1 ;
	if (lpCandInfo->dwCount <= 0)
		goto	exit_func_2 ;

	hOldFont	= TSkkIme_hCheckNativeCharset (hDC, &bFontCreated) ;
	lpCandList	= (LPCANDIDATELIST)((LPSTR)lpCandInfo  + lpCandInfo->dwOffset[0]) ;
	switch (nMode) {
	case	UICAND_SHOWHANKANCANDIDATESMODE:
		uiCand_bPaintHenkanCandidatesList (hWnd, hDC, lpCandList, prcDraw, bufKeys, nKeys) ;
		break ;
	case	UICAND_INPUTBYCODEORMENUMODE:
		uiCand_bPaintCodeList (hWnd, hDC, lpCandList, prcDraw, bufKeys, nKeys) ;
		break ;
	default:
		uiCand_bPaintMinibufferText (hWnd, hDC, lpIMC, lpCandList, prcDraw) ;
		break ;
	}

	/*	�m�ۂ��Ă��� GDI ���\�[�X�̉���B
	 */
	if (bFontCreated) {
		DeleteObject (SelectObject(hDC, hOldFont)) ;
	} else {
		(void) SelectObject(hDC, hOldFont);
	}

exit_func_2:
	ImmUnlockIMCC (lpIMC->hCandInfo) ;

 exit_func_1:
	ImmUnlockIMC (hIMC) ;
	return	TRUE ;
}

BOOL
uiCand_bPaintHenkanCandidatesList (
	HWND				hWnd,
	HDC					hDC,
	LPCANDIDATELIST		pCandList,
	LPRECT				prcDraw,
	LPCWSTR				pwKeys,
	int					nKeys)
{
	HBRUSH				hULBrush = NULL, hOldBrush = NULL ;
	HBITMAP				hbmUL = NULL ;
	int					nULHeight, nPageSize, nText ;
	COLORREF			colUL ;
	SIZE				sz ;
	TCHAR				bufText [1024] ;
	TEXTREGION			bufAnnot [32] ;
	PTEXTREGION			pbufAnnot ;

	hULBrush	= TSkkIme_hbrGetImeLineBrush (hWnd, MYCOLOR_TEXTAUTO, MYLINE_THIN_DITHER, &colUL, &hbmUL, &nULHeight) ;
	if (hULBrush)
		hOldBrush	= SelectObject (hDC, hULBrush) ;

	pbufAnnot	= (pCandList->dwPageSize >= ARRAYSIZE (bufAnnot))? NULL : bufAnnot ;
	nPageSize	= (pbufAnnot == NULL)? 0 : pCandList->dwPageSize ;
	memset (bufAnnot, 0, sizeof (bufAnnot)) ;
	nText		= uiCand_iGetHenkanShowCandidatesText (bufText, ARRAYSIZE (bufText), pbufAnnot, pCandList, pwKeys, nKeys) ;
	if (nText > 0) {
		int		nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPTSTR		pText ;
		PTEXTREGION	pAnnot ;
		TEXTMETRIC	tm ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= prcDraw->top ;
		pText		= bufText ;
		nTextPos	= 0 ;

		while (y < prcDraw->bottom && 0 < nText) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= prcDraw->left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32 (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) > prcDraw->right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			/* ���̍s�ɂ� nChar �����\������B*/
			MyTextOut (hDC, x, y, pText, nChar) ;
			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
			x	+= sz.cx ;

			/* �܂�Ԃ�������\������B*/
			if (nChar < nText) {
				SIZE	szBackslash ;
				MyTextOut (hDC, x, y, MYTEXT ("\\"), 1) ;
				MyGetTextExtentPoint (hDC, MYTEXT ("\\"), 1, &szBackslash) ;
				x	+= szBackslash.cx ;
			}

#define	IsTextRegionCrossp(text1,ntext1,text2,ntext2)	(!((((text1)+(ntext1))<=(text2)||(text1)>=((text2)+(ntext2)))))
			for (nAnnot = 0 ; nAnnot < nPageSize ; nAnnot ++) {
				int	nOffset, nLength ;

				pAnnot	= &bufAnnot [nAnnot] ;
				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32 (hDC, pText, nOffset, &sz) ;
					nAnnotX	= prcDraw->left + sz.cx ;
				} else {
					nAnnotX	= prcDraw->left ;
				}
				GetTextExtentPoint32 (hDC, pText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				if (hULBrush) 
					PatBlt (hDC, nAnnotX, y + nDY - nULHeight, nAnnotWidth, nULHeight, PATCOPY) ;
			}
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
	}

	if (hULBrush) {
		(void) SelectObject (hDC, hOldBrush) ;
		DeleteObject (hULBrush) ;
	}
	if (hbmUL)
		DeleteObject (hbmUL) ;
	return	TRUE ;
}

BOOL
uiCand_bPaintCodeList (
	HWND			hWnd,
	HDC				hDC,
	LPCANDIDATELIST	pCandList,
	LPRECT			prcDraw,
	LPCWSTR			pwKeys,
	int				nKeys)
{
	TCHAR				bufText [1024] ;
	SIZE				sz ;
	int					nText ;

	nText		= uiCand_iGetInputByCodeOrMenuText (bufText, ARRAYSIZE (bufText), NULL, pCandList, pwKeys, nKeys) ;
	if (nText > 0) {
		int		nTextPos, nDY, nDefaultDY, x, y, nChar ;
		LPTSTR		pText ;
		TEXTMETRIC	tm ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= prcDraw->top ;
		pText		= bufText ;
		nTextPos	= 0 ;

		while (y < prcDraw->bottom && 0 < nText) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= prcDraw->left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32 (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) > prcDraw->right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			/* ���̍s�ɂ� nChar �����\������B*/
			MyTextOut (hDC, x, y, pText, nChar) ;
			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;
			x	+= sz.cx ;

			/* �܂�Ԃ�������\������B*/
			if (nChar < nText) {
				SIZE	szBackslash ;
				MyTextOut (hDC, x, y, MYTEXT ("\\"), 1) ;
				MyGetTextExtentPoint (hDC, MYTEXT ("\\"), 1, &szBackslash) ;
				x	+= szBackslash.cx ;
			}
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
	}
	return	TRUE ;
}

BOOL
uiCand_bPaintMinibufferText (
	HWND				hWnd,
	HDC					hDC,
	LPINPUTCONTEXT		lpIMC,
	LPCANDIDATELIST		pCandList,
	LPRECT				prcDraw)
{
	/*	Key 1 �ɕt�� ``X:'' ��2�����ASeparator �̋󔒂� 1 �����A
	 *	���̕\���� 1 �` 2 �����A
	 *	����āAARRAYSIZE (pCandidateKey) * (2 + 1 + 1) �܂��� (2 + 1 + 2)
	 *	���������B
	 */
	LPMYCOMPSTR		lpMyCompStr ;
	HBRUSH			hbr, hBrushParent ;
	HDC				hPDC ;
	HFONT			hOldFont ;
	RECT			rc ;
	int				nRegionStart, nRegionEnd ;
	int				x, y, nDY, nText, nTextPos ;
	LPMYSTR			pwSText, pText ;
	int				lLength, iCursorPos, lPrevCursorPos ;
	BOOL			fRegionSelected, bAnnotated ;
	DWORD			dwLevel, dwSize ;
	TEXTMETRIC		tm ;
	BOOL			bCursorPos ;

	pwSText	= (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset [0]) ;

	/*	Minibuffer �̃J�[�\���̈ʒu�𓾂�B*/
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr){
		struct CImeDoc*	pDoc	= &lpMyCompStr->_Doc ;
		if (! ImeDoc_bGetStatusCursor (pDoc, &iCursorPos))
			iCursorPos	= -1 ;
		if (iCursorPos >= 0) {
			fRegionSelected	= ImeDoc_bGetSelectedRegion (pDoc, &nRegionStart, &nRegionEnd) ;
			if (fRegionSelected) {
				if (nRegionStart > iCursorPos)
					nRegionStart	++ ;
				if (nRegionEnd > iCursorPos)
					nRegionEnd		++ ;
			}
		} else {
			fRegionSelected	= FALSE ;
		}
		bAnnotated	= ImeDoc_bRecursiveEditp (pDoc) && ImeDoc_bHaveMessagep (pDoc) ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	} else {
		iCursorPos		= -1 ;
		fRegionSelected	= FALSE ;
		bAnnotated		= FALSE ;
	}

	/* Minibuffer Window �̑傫���𓾂�B*/
	GetClientRect (hWnd, &rc) ;
		
	/* �eWindow �̔w�i�F�𓾂�B*/
	hPDC 			= GetDC (GetParent (hWnd)) ;
	hBrushParent	= CreateSolidBrush (GetBkColor (hPDC)) ;
	/*lPrevCursorPos	= GetWindowLong (hMinibufWnd, FIGWL_UIMINIBUF_PREVCURSOR) ;*/

	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	SetBkMode (hDC, OPAQUE) ;
	SetBkColor (hDC, GetBkColor (hPDC)) ;
	SetTextColor (hDC, RGB (0, 0, 0)) ;

	if (bAnnotated) {
		pwSText			++ ;
		iCursorPos		-- ;
		nRegionStart	-- ;
		nRegionEnd		-- ;
	}

	pText		= pwSText ;
	nText		= Mylstrlen (pwSText) ;
	nTextPos	= 0 ;
	y			= rc.top ;
	x			= rc.left ;
	bCursorPos	= FALSE ;
	while (y < rc.bottom && 0 < nText) {
		int		nChar, iSX ;
		BOOL	bCRLF ;
		SIZE	sz ;

		bCRLF	= FALSE ;
		iSX		= x ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			if ((nTextPos + nChar - 1) == iCursorPos && *(pText + nChar - 1) == L'|') {
				break ;	/* cursor */
			}
			MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
			if ((x + sz.cx) >= rc.right) {
				bCRLF	= TRUE ;
				break ;
			}
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;
#if 0
		if (nTextPos <= lPrevCursorPos && lPrevCursorPos <= (nTextPos + nChar)){
			MyGetTextExtentPoint (hDC, pText, lPrevCursorPos - nTextPos, &sz) ;
			hbr		= SelectObject (hDC, hBrushParent) ;
			PatBlt (hDC, iSX + sz.cx, y, UI_CURSORWIDTH, y + nDY, PATCOPY) ;
			(void) SelectObject (hDC, hbr) ;
		}
#endif
		if (fRegionSelected && !(nRegionEnd <= nTextPos || (nTextPos + nChar) <= nRegionStart)) {
			int	nStart, nEnd ;

			if (nTextPos < nRegionStart) {
				MyTextOut (hDC, x, y, pText, nRegionStart - nTextPos) ;
				MyGetTextExtentPoint (hDC, pText, nRegionStart - nTextPos, &sz) ;
				x	+= sz.cx ;
			}
			nStart	= (nRegionStart < nTextPos)? nTextPos : nRegionStart ;
			nEnd	= (nRegionEnd   >= (nTextPos + nChar))? (nTextPos + nChar) : nRegionEnd ;
			if (nStart < nEnd) {
				SetBkColor (hDC, RGB (192, 192, 224)) ;
				MyTextOut (hDC, x, rc.top, pwSText + nStart, nEnd - nStart) ;
				MyGetTextExtentPoint (hDC, pwSText + nStart, nEnd - nStart, &sz) ;
				SetBkColor (hDC, GetBkColor (hPDC)) ;
				x	+= sz.cx ;
			}
			if (nEnd < (nTextPos + nChar)) {
				MyTextOut (hDC, x, rc.top, pwSText + nEnd, nTextPos + nChar - nEnd) ;
				MyGetTextExtentPoint (hDC, pwSText + nEnd, nTextPos + nChar - nEnd, &sz) ;
				x	+= sz.cx ;
			}
		} else {
			/* �e�L�X�g��\������B*/
			MyTextOut (hDC, x, y, pText, nChar) ;
			MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
		}
#if 0
		/* �e�L�X�g��\������B*/
		MyTextOut (hDC, x, y, pText, nChar) ;
		MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
		x	+= sz.cx ;
#endif
		if (bCRLF) {
			/*	�܂�Ԃ��L����\������B*/
			MyTextOut (hDC, x, y, MYTEXT ("\\"), 1) ;
			MyGetTextExtentPoint (hDC, MYTEXT ("\\"), 1, &sz) ;
			x	+= sz.cx ;
		}
		if (bCRLF || nChar == nText)
			PatBlt (hDC, x, y, rc.right - x, nDY, PATCOPY) ;

		/* �K�v�Ȃ�J�[�\����\������B*/
		/*if (nTextPos <= iCursorPos && iCursorPos <= (nTextPos + nChar)){*/
		if ((nTextPos + nChar) == iCursorPos) {
			/* �J�[�\���̒��O�܂ŕ`�悳��Ă����ԁB*/
			if ((nChar + 1) >= nText) {
				RECT			invRect ;
				MyGetTextExtentPoint (hDC, pText, iCursorPos - nTextPos, &sz) ;
				invRect.left	= iSX + sz.cx ;
				invRect.right	= iSX + sz.cx + UI_CURSORWIDTH ;
				invRect.top		= y ;
				invRect.bottom	= y + nDY ;
				PatBlt (hDC, x, y, rc.right - x, nDY, PATCOPY) ;
				InvertRect (hDC, &invRect) ;
			} else {
				bCursorPos		= TRUE ;
			}
			nChar	++ ;	/* skip: �J�[�\���ʒu�ɑ}������Ă���``|'' */
		} else {
			if (bCursorPos) {
				RECT			invRect ;
				invRect.left	= iSX ;
				invRect.right	= iSX + UI_CURSORWIDTH ;
				invRect.top		= y ;
				invRect.bottom	= y + nDY ;
				InvertRect (hDC, &invRect) ;
				bCursorPos	= FALSE ;
			}
		}
		pText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		if (bCRLF) {
			y		+= nDY ;
			x		= rc.left ;
		}
	}

	DeleteObject (hBrushParent) ;
	/*SetWindowLong (hMinibufWnd, FIGWL_UIMINIBUF_PREVCURSOR, iCursorPos) ;*/
	ReleaseDC (GetParent (hWnd), hPDC) ;
	return	TRUE ;
}

/*	uiCand_bAdjustSize
 *		���\�����̓K�؂ȑ傫���𓾂�B
 */
BOOL	PASCAL
uiCand_bAdjustSize (
	HWND			hwnd,
	LPINPUTCONTEXT	lpIMC,
	LPSIZE			lpSize)
{
	HWND				hSvrWnd ;
	HDC					hDC			= NULL ;
	HFONT				hOldFont ;
	LPCOMPOSITIONSTRING	lpCompStr	= NULL ;
	LPCANDIDATEINFO		lpCandInfo	= NULL ;
	LPCANDIDATELIST		lpCandList	= NULL ;
	TEXTMETRIC			tm ;
	int					nDefaultWidth, nDefaultHeight, nFrameWidth, nFrameHeight ;
	WCHAR				bufKeys [64] ;
	int					nKeys, nMode ;
	BOOL				bFontCreated	= FALSE ;

	if (lpIMC == NULL)
		return	FALSE ;
	if (ImmGetIMCCSize(lpIMC->hCandInfo) < sizeof (CANDIDATEINFO))
		return	FALSE ;

	hDC			= GetDC (hwnd) ;
	if (!hDC)
		return	FALSE ;

	/*	Document ���猻�݂� state �����Ȃ��ƁA���̗��R�Ō�⃊�X�g��
	 *	�쐬�����̂�������Ȃ��B
	 *		- �ϊ��̉ߒ��A
	 *		- ���l���͂̉ߒ� (menu1 or menu2?)
	 *	�܂��ϊ��L�[�̃��X�g���~�����B
	 */
	nKeys		= uiCand_iGetCandidateMenuKeys (lpIMC, bufKeys, ARRAYSIZE (bufKeys), &nMode) ;

	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (lpCandInfo == NULL)
		goto	exit_func_1 ;

	hOldFont	= TSkkIme_hCheckNativeCharset (hDC, &bFontCreated) ;
	GetTextMetrics (hDC, &tm) ;

	nFrameWidth		= GetSystemMetrics (SM_CXDLGFRAME) * 2 ;
	nFrameHeight	= GetSystemMetrics (SM_CYDLGFRAME) * 2 ;
	nDefaultWidth	= tm.tmAveCharWidth * DEFAULT_MINIBUF_CHARWIDTH + nFrameWidth ;
	nDefaultHeight	= tm.tmHeight + nFrameHeight ;

	if (lpCandInfo->dwCount <= 0) {
		if (lpSize){
			if (lpSize->cx < nDefaultWidth)
				lpSize->cx	= nDefaultWidth ;
			lpSize->cy	= nDefaultHeight ;
		}
		goto	exit_func_2 ;
	}

	/*	�\���̈�̌v�Z�B
	 */
	lpCandList	= (LPCANDIDATELIST)((LPSTR)lpCandInfo  + lpCandInfo->dwOffset[0]) ;
	if (nMode == UICAND_SHOWHANKANCANDIDATESMODE || nMode == UICAND_INPUTBYCODEORMENUMODE) {
		TCHAR	bufText [1024] ;
		int		nText, nWidth, nHeight ;
		SIZE	sz ;

		if (nMode == UICAND_SHOWHANKANCANDIDATESMODE) {
			nText	= uiCand_iGetHenkanShowCandidatesText (bufText, ARRAYSIZE (bufText), NULL, lpCandList, bufKeys, nKeys) ;
		} else {
			nText	= uiCand_iGetInputByCodeOrMenuText (bufText, ARRAYSIZE (bufText), NULL, lpCandList, bufKeys, nKeys) ;
		}
		if (nText > 0) {
			GetTextExtentPoint32 (hDC, bufText, nText, &sz) ;
			nWidth	= (lpSize != NULL && nDefaultWidth < lpSize->cx)? lpSize->cx : nDefaultWidth ;
			if ((sz.cx + nFrameWidth) > nWidth) {
				int	n	= nWidth - nFrameWidth ;
				nHeight	= (sz.cx + n - 1) / n * sz.cy + nFrameHeight ;
			} else {
				nHeight	= sz.cy + nFrameHeight ;
			}
			nHeight	= (nHeight < nDefaultHeight)? nDefaultHeight : nHeight ;
		} else {
			nWidth	= nDefaultWidth ;
			nHeight	= nDefaultHeight ;
		}
		if (lpSize) {
			if (lpSize->cx < nWidth)
				lpSize->cx	= nWidth ;
			lpSize->cy	= nHeight ;
		}
	} else {
		SIZE	sz ;
		int		nWidth ;

		/* Minibuffer Text �̏ꍇ�B*/
		nWidth	= (lpSize != NULL && nDefaultWidth < lpSize->cx)? lpSize->cx : nDefaultWidth ;
		if (! uiCand_bGetMinibufferTextSize (hwnd, hDC, lpIMC, lpCandList, nWidth - nFrameWidth, &sz)) {
			if (lpSize != NULL) {
				lpSize->cx	= nDefaultWidth ;
				lpSize->cy	= nDefaultHeight ;
			}
		} else {
			lpSize->cx	= (! uiCand_bNeedCandidateWindowp (lpIMC))? (sz.cx + nFrameWidth) : nWidth ;
			lpSize->cy	= sz.cy + nFrameHeight ;
		}
	}
exit_func_2:
	if (bFontCreated) {
		DeleteObject (SelectObject(hDC, hOldFont)) ;
	} else {
		(void) SelectObject(hDC, hOldFont);
	}
exit_func_1:
	if (lpCandInfo != NULL)
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
	if (hDC != NULL)
		ReleaseDC (hwnd, hDC) ;
	return	TRUE ;
}

BOOL
uiCand_bGetMinibufferTextSize (
	HWND				hWnd,
	HDC					hDC,
	LPINPUTCONTEXT		lpIMC,
	LPCANDIDATELIST		pCandList,
	int					nDefaultWidth,
	SIZE*				pSZ)
{
	/*	Key 1 �ɕt�� ``X:'' ��2�����ASeparator �̋󔒂� 1 �����A
	 *	���̕\���� 1 �` 2 �����A
	 *	����āAARRAYSIZE (pCandidateKey) * (2 + 1 + 1) �܂��� (2 + 1 + 2)
	 *	���������B
	 */
	LPMYCOMPSTR		lpMyCompStr ;
	RECT			rc ;
	int				x, y, nDY ;
	LPMYSTR			pwSText ;
	int				lLength, iCursorPos, lPrevCursorPos, nSTextLen ;
	TEXTMETRIC		tm ;
	BOOL			bCalculate, bAnnotated ;
	int				iCalculateCount ;

	if (pCandList->dwCount < 1)
		return	FALSE ;

	pwSText	= (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset [0]) ;

	/*	Minibuffer �̃J�[�\���̈ʒu�𓾂�B*/
	iCursorPos	= -1 ;
	bAnnotated	= FALSE ;
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr){
		struct CImeDoc*	pDoc	= &lpMyCompStr->_Doc ;
		if (! ImeDoc_bGetStatusCursor (pDoc, &iCursorPos))
			iCursorPos	= -1 ;
		bAnnotated	= ImeDoc_bRecursiveEditp (pDoc) && ImeDoc_bHaveMessagep (pDoc) ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
	rc.left			= 0 ;
	rc.top			= 0 ;
	rc.right		= nDefaultWidth ;
	iCalculateCount	= 3 ;

	/* Minibuffer Window �̑傫���𓾂�B*/
	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;
	if (bAnnotated) {
		pwSText		++ ;
		iCursorPos	-- ;
	} 
	nSTextLen	= Mylstrlen (pwSText) ;

	do {
		LPMYSTR		pText ;
		int			nText, nTextPos ;
		BOOL		bCursorPos ;

		pText		= pwSText ;
		nText		= nSTextLen ;
		nTextPos	= 0 ;
		y			= rc.top ;
		x			= rc.left ;
		bCursorPos	= FALSE ;
		bCalculate	= FALSE ;
		while (0 < nText) {
			int		nChar, iSX ;
			BOOL	bCRLF ;
			SIZE	sz ;

			bCRLF	= FALSE ;
			iSX		= x ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				if ((nTextPos + nChar - 1) == iCursorPos && *(pText + nChar - 1) == L'|') {
					break ;	/* cursor */
				}
				MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) >= rc.right) {
					if (nChar == 1 && x == rc.left) {
						/*	width ��ύX���čŏ�����B
						 *	�������A�������[�v�ɓ���Ȃ��悤�ɍő�v�Z�񐔂�
						 *	�ݒ肵�Ă����B
						 */
						rc.right	= rc.left + sz.cx + 1 ;
						if (iCalculateCount <= 0)
							return	FALSE ;
						bCalculate	= TRUE ;
						iCalculateCount	-- ;
					}
					bCRLF	= TRUE ;
					break ;
				}
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;
			/* �e�L�X�g��\������B*/
			MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
			x	+= sz.cx ;
			if (bCRLF) {
				/*	�܂�Ԃ��L����\������B*/
				MyGetTextExtentPoint (hDC, MYTEXT ("\\"), 1, &sz) ;
				x	+= sz.cx ;
			}

			/* �K�v�Ȃ�J�[�\����\������B*/
			/*if (nTextPos <= iCursorPos && iCursorPos <= (nTextPos + nChar)){*/
			if ((nTextPos + nChar) == iCursorPos) {
				/* �J�[�\���̒��O�܂ŕ`�悳��Ă����ԁB*/
				if ((nChar + 1) >= nText) {
				} else {
					bCursorPos		= TRUE ;
				}
				nChar	++ ;	/* skip: �J�[�\���ʒu�ɑ}������Ă���``|'' */
			} else {
				if (bCursorPos) {
					bCursorPos	= FALSE ;
				}
			}
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			if (bCRLF) {
				y		+= nDY ;
				x		= rc.left ;
			}
		}
	}	while (bCalculate) ;

	if (pSZ != NULL) {
		pSZ->cx	= (y != rc.top)? rc.right : x ;
		pSZ->cy	= y + nDY ;
	}
	return	TRUE ;
}

/*========================================================================
 */
int
uiCand_iGetHenkanShowCandidatesText (
	LPTSTR				strDest,
	int					nDest,
	PTEXTREGION			pText,
	LPCANDIDATELIST		pCandList,
	LPCWSTR				pwKeys,
	int					nKeys)
{
	LPTSTR			pDest		= strDest ;
	DWORD			i, iCount, nCandidate ;
	TCHAR			ch ;
	const DWORD*	pdwAnnotationIndex ;
	int				iShowAnnotation ;

	iCount		= 0 ;
	i			= pCandList->dwPageStart ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPMYSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		Mylstrncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/*	Annotation �� Offset ���ݒ肳��Ă��邩�`�F�b�N����B
	 */
	nCandidate			= pCandList->dwCount ;
	iShowAnnotation		= ImeConfig_iGetSkkShowAnnotationType () ;
	pdwAnnotationIndex	= NULL ;
	if (iShowAnnotation == SHOW_ANNOTATION_ALWAYS || iShowAnnotation == SHOW_ANNOTATION_IN_CANDLIST) {
		pdwAnnotationIndex	= pCandList->dwOffset + nCandidate ;
		/*	���� offset �͏���ɍ���� offset �Ȃ̂ŁA���������݂��邩�ǂ����`�F�b�N����B
		 */
		if (((LPSTR)pCandList + pCandList->dwOffset[0]) >= ((LPSTR)(pdwAnnotationIndex + nCandidate))) {
			pdwAnnotationIndex	= pCandList->dwOffset + nCandidate ;
		}
	}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < (pCandList->dwPageStart + pCandList->dwPageSize) && i < pCandList->dwCount && iCount < (DWORD)nKeys && nDest > 0) {
		LPMYSTR		lpstr ;
		int			nIndex, nCandLen ;

		ch			= pwKeys [iCount] ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, TEXT (":"), 1) ;

		lpstr		=  (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset[i]) ;
		nCandLen	= Mylstrlen (lpstr) ;

		/*	���� annotation �����݂���ꍇ�B*/
		if (pText != NULL) {
			if (nDest > 0 && pdwAnnotationIndex != NULL && pdwAnnotationIndex [i] > 0) {
				pText->m_nCandidate	= i ;
				pText->m_nOffset	= pDest - strDest ;
				pText->m_nLength	= (nDest < nCandLen)? nDest : nCandLen ;
			} else {
				pText->m_nCandidate	= 0 ;
				pText->m_nOffset	= 0 ;
				pText->m_nLength	= 0 ;
			}
			pText	++ ;
		}
		SAFE_COPY (pDest, nDest, lpstr, nCandLen) ;
		SAFE_COPY (pDest, nDest, TEXT (" "), 1) ;
		iCount	++ ;
		i		++ ;
	}
	if (nDest > 0) {
		MYCHAR	buffer [32] ;
		Mylstrcpy (buffer, MYTEXT (" [�c�� ")) ;
		Myltoa    (buffer + Mylstrlen (buffer), pCandList->dwCount - i) ;
		Mylstrcat (buffer, MYTEXT ("]")) ;
		SAFE_COPY (pDest, nDest, buffer, Mylstrlen (buffer)) ;
	}
#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

int
uiCand_iGetInputByCodeOrMenuText (
	LPTSTR				strDest,
	int					nDest,
	PTEXTREGION			pText,
	LPCANDIDATELIST		pCandList,
	LPCWSTR				pwKeys,
	int					nKeys)
{
	LPTSTR		pDest		= strDest ;
	DWORD		i, iCount ;
	TCHAR		ch ;

	iCount		= 0 ;
	i			= pCandList->dwPageStart ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPMYSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		Mylstrncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < (pCandList->dwPageStart + pCandList->dwPageSize) && i < pCandList->dwCount && iCount < (DWORD)nKeys && nDest > 0) {
		LPMYSTR		lpstr ;
		int			nCandLen ;

		ch			= pwKeys [iCount] ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY (pDest, nDest, TEXT (":"), 1) ;

		lpstr		=  (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset[i]) ;
		nCandLen	= Mylstrlen (lpstr) ;

		/*	���� annotation �����݂���ꍇ�B*/
		if (pText != NULL) {
			pText->m_nCandidate	= 0 ;
			pText->m_nOffset	= 0 ;
			pText->m_nLength	= 0 ;
			pText	++ ;
		}
		SAFE_COPY (pDest, nDest, lpstr, nCandLen) ;
		SAFE_COPY (pDest, nDest, TEXT (" "), 1) ;
		iCount	++ ;
		i		++ ;
	}
#undef	SAFE_COPY
	return	(pDest - strDest) ;
}

void	PASCAL
uiCand_vHitTestAnnotation (
	HWND			hWnd,
	const POINT*	pPT)
{
	HWND			hwndTT ;
	HGLOBAL			hToolTipInfo ;
	PTOOLTIPINFO	pToolTipInfo ;

	hwndTT			= (HWND) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIP) ;
	hToolTipInfo	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIPINFO) ;
	if (hToolTipInfo == NULL)
		return ;

	pToolTipInfo	= (PTOOLTIPINFO) GlobalLock (hToolTipInfo) ;
	if (pToolTipInfo != NULL) {
		int		nTool ;

		for (nTool = 0 ; nTool < pToolTipInfo->_nCount ; nTool ++) {
			if (pToolTipInfo->_rrcHitArea [nTool].left <= pPT->x && pPT->x < pToolTipInfo->_rrcHitArea [nTool].right &&
				pToolTipInfo->_rrcHitArea [nTool].top  <= pPT->y && pPT->y < pToolTipInfo->_rrcHitArea [nTool].bottom) {
				POINT	pt ;
				RECT	rc ;
				/* hit */
				pt.x	= pPT->x ;
				pt.y	= pPT->y ;
				ClientToScreen (hWnd, &pt) ;
				pToolTipInfo->_ptLastPos.x	= pt.x ;
				pToolTipInfo->_ptLastPos.y	= pt.y ;
				if (! GetWindowRect (hWnd, &rc))
					rc.bottom	= pt.y + GetSystemMetrics (SM_CYCURSOR) / 2 ;
				MoveWindow (hwndTT, pt.x, rc.bottom, 1, 1, TRUE) ;
				SetWindowText (hwndTT, pToolTipInfo->_bufText + pToolTipInfo->_rnOffsets [nTool]) ;
				ShowWindow (hwndTT, SW_SHOWNOACTIVATE) ;
				break ;
			}
		}
		GlobalUnlock (hToolTipInfo) ;
	}
	return ;
}

BOOL	PASCAL
uiCand_bHideToolTipp (
	HWND			hWnd)
{
	HGLOBAL			hToolTipInfo ;
	PTOOLTIPINFO	pToolTipInfo ;
	BOOL	bRetval	= TRUE ;

	hToolTipInfo	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIPINFO) ;
	if (hToolTipInfo == NULL)
		return	TRUE ;

	pToolTipInfo	= (PTOOLTIPINFO) GlobalLock (hToolTipInfo) ;
	if (pToolTipInfo != NULL) {
		POINT		pt ;
		GetCursorPos (&pt) ;
		if (pt.x == pToolTipInfo->_ptLastPos.x && pt.y == pToolTipInfo->_ptLastPos.y)
			bRetval	= FALSE ;
		GlobalUnlock (hToolTipInfo) ;
	}
	return	bRetval ;
}

BOOL	PASCAL
uiCand_bConfigureAnnotation (
	HWND			hWnd,
	LPINPUTCONTEXT	lpIMC)
{
	HWND			hSvrWnd, hwndTT ;
	LPCANDIDATEINFO			pCandInfo	= NULL ;
	LPCANDIDATELIST			pCandList	= NULL ;
	HFONT					hOldFont	= NULL ;
	HDC						hDC			= NULL ;
	RECT					rcDraw ;
	int						nPageSize, nText, nTools ;
	SIZE					sz ;
	TCHAR					bufText [1024] ;
	TEXTREGION				bufAnnot [32] ;
	PTEXTREGION				pbufAnnot ;
	HGLOBAL					hToolTipInfo ;
	PTOOLTIPINFO			pToolTipInfo ;
	BOOL					bRetval		= FALSE ;
	WCHAR					bufKeys [64] ;
	int						nKeys, nMenuMode ;
	const DWORD*			pdwAnnotationOffset ;
	BOOL					bFontCreated	= FALSE ;

	if (lpIMC == NULL || ! IsWindow (hWnd))
		return	FALSE ;

	hwndTT			= (HWND) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIP) ;
	if (hwndTT == NULL || ! IsWindow (hwndTT))
		return	FALSE ;
	ShowWindow (hwndTT, SW_HIDE) ;

	hToolTipInfo	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIPINFO) ;
	if (hToolTipInfo == NULL)
		return	FALSE ;

	hSvrWnd		= (HWND)GetWindowLongPtr (hWnd, FIGWLP_UICAND_SVRWND) ;
	hDC			= GetDC (hWnd) ;
	if (!hDC)
		return	FALSE ;

	nKeys		= uiCand_iGetCandidateMenuKeys (lpIMC, bufKeys, ARRAYSIZE (bufKeys), &nMenuMode) ;
	if (nKeys <= 0 || nMenuMode != UICAND_SHOWHANKANCANDIDATESMODE)
		goto	exit_func_1 ;

	if (ImmGetIMCCSize(lpIMC->hCandInfo) < sizeof (CANDIDATEINFO))
		goto	exit_func_1 ;
	pCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (pCandInfo == NULL)
		goto	exit_func_1 ;
	if (pCandInfo->dwCount <= 0)
		goto	exit_func_1 ;

	hOldFont	= TSkkIme_hCheckNativeCharset (hDC, &bFontCreated) ;
	GetClientRect (hWnd, &rcDraw) ;
	pCandList	= (LPCANDIDATELIST)((LPSTR)pCandInfo  + pCandInfo->dwOffset[0]) ;

	pdwAnnotationOffset	= pCandList->dwOffset + pCandList->dwCount ;
	/*	���� offset �͏���ɍ���� offset �Ȃ̂ŁA���������݂��邩�ǂ����`�F�b�N����B*/
	if ((BYTE*)(pdwAnnotationOffset + pCandList->dwCount) > (BYTE*)((LPSTR)pCandList + pCandList->dwOffset [0]))
		goto	exit_func_1 ;

	/*	TOOL ��ǉ�����B*/
	pbufAnnot	= (pCandList->dwPageSize >= ARRAYSIZE (bufAnnot))? NULL : bufAnnot ;
	nPageSize	= (pbufAnnot == NULL)? 0 : pCandList->dwPageSize ;

	memset (bufAnnot, 0, sizeof (bufAnnot)) ;
	nText		= uiCand_iGetHenkanShowCandidatesText (bufText, ARRAYSIZE (bufText), pbufAnnot, pCandList, bufKeys, nKeys) ;

	pToolTipInfo	= (PTOOLTIPINFO) GlobalLock (hToolTipInfo) ;
	if (pToolTipInfo == NULL)
		goto	exit_func_1 ;

	if (nText > 0) {
		int			nTextPos, nDY, nDefaultDY, x, y, nAnnotX, nAnnotWidth, nAnnot, nChar ;
		LPTSTR		pText ;
		PTEXTREGION	pAnnot ;
		TEXTMETRIC	tm ;
		int			nTool, nLeft ;
		MYCHAR*		pDest ;

		GetTextMetrics (hDC, &tm) ;
		nDefaultDY	= tm.tmHeight ;

		y			= rcDraw.top ;
		pText		= bufText ;
		nTextPos	= 0 ;
		nTool		= 0 ;
		pDest		= pToolTipInfo->_bufText ;
		nLeft		= NBUFFER_ANNOTATION_TEXT ;

		while (y < rcDraw.bottom && 0 < nText && nLeft > 0 && nTool < MAX_ANNOTATIONS) {
			/*	��s�ɕ\�����镶������ guess ����B���͉����l���Ȃ��c�x���A���S���Y���ōs���B*/
			x	= rcDraw.left ;
			for (nChar = 1 ; nChar <= nText ; nChar ++) {
				GetTextExtentPoint32 (hDC, pText, nChar, &sz) ;
				if ((x + sz.cx) > rcDraw.right) 
					break ;
			}
			nChar	-- ;
			if (nChar <= 0)
				break ;

			nDY	= (sz.cy < nDefaultDY)? nDefaultDY : sz.cy ;

			/* ���̍s�� hit ����BTEXTREGION �𗘗p����B*/
			for (nAnnot = 0 ; nAnnot < nPageSize && nLeft > 0 && nTool < MAX_ANNOTATIONS ; nAnnot ++) {
				LPMYSTR		lpstr ;
				int			nOffset, nLength, nCandLen ;

				pAnnot	= &bufAnnot [nAnnot] ;
				if (! IsTextRegionCrossp (nTextPos, nChar, pAnnot->m_nOffset, pAnnot->m_nLength))
					continue ;
				nOffset	= (pAnnot->m_nOffset < nTextPos)? 0 : (pAnnot->m_nOffset - nTextPos) ;
				nLength	= (pAnnot->m_nOffset < nTextPos)? (pAnnot->m_nLength + pAnnot->m_nOffset - nTextPos) : pAnnot->m_nLength ;
				if (nLength > nChar)
					nLength	= nChar ;

				if (nOffset > 0) {
					GetTextExtentPoint32 (hDC, pText, nOffset, &sz) ;
					nAnnotX	= rcDraw.left + sz.cx ;
				} else {
					nAnnotX	= rcDraw.left ;
				}
				GetTextExtentPoint32 (hDC, pText + nOffset, nLength, &sz) ;
				nAnnotWidth	= sz.cx ;

				/* �O�̂��߂Ɍ�₪���݂��邩�`�F�b�N����B*/
				if (pAnnot->m_nCandidate >= pCandList->dwCount)
					continue ;

				if (pdwAnnotationOffset == NULL || pdwAnnotationOffset [pAnnot->m_nCandidate] <= 0)
					continue ;

				lpstr		=  (LPMYSTR)((LPSTR)pCandList + pdwAnnotationOffset [pAnnot->m_nCandidate]) ;
				nCandLen	= Mylstrlen (lpstr) ;

				/*	(nAnnotX, y) - (nAnnotX + nAnnotWidth, y + nDY)
				 */
				pToolTipInfo->_rrcHitArea [nTool].left		= nAnnotX ;
				pToolTipInfo->_rrcHitArea [nTool].right		= nAnnotX + nAnnotWidth ;
				pToolTipInfo->_rrcHitArea [nTool].top		= y ;
				pToolTipInfo->_rrcHitArea [nTool].bottom	= y + nDY ;
				pToolTipInfo->_rnOffsets [nTool]			= pDest - pToolTipInfo->_bufText ;

				nLength		= (nCandLen > nLeft)? (nLeft - 1) : nCandLen ;
				if (nLength > 0) {
					Mylstrncpy (pDest, lpstr, nLength) ;
					pDest [nLength]	= MYTEXT ('\0') ;
					pDest	+= nLength + 1 ;
					nLeft	-= nLength + 1 ;
				}
				pToolTipInfo->_rnLengths [nTool]			= nLength ;
				nTool			++ ;
			}
			x			+= sz.cx ;
			pText		+= nChar ;
			nTextPos	+= nChar ;
			nText		-= nChar ;
			y			+= nDY ;
		}
		pToolTipInfo->_nCount	= nTool ;
	} else {
		pToolTipInfo->_nCount	= 0 ;
	}
	GlobalUnlock (hToolTipInfo) ;
	bRetval	= TRUE ;

exit_func_1:

	if (pCandInfo != NULL)
		ImmUnlockIMCC (lpIMC->hCandInfo) ;
	if (hDC != NULL) {
		if (bFontCreated) {
			DeleteObject (SelectObject(hDC, hOldFont)) ;
		} else {
			(void) SelectObject(hDC, hOldFont);
		}
		ReleaseDC (hWnd, hDC) ;
	}
	return	bRetval ;
}

int
uiCand_iGetCandidateMenuKeys (
	LPINPUTCONTEXT		lpIMC,
	LPWSTR				pwDest,
	int					nDestSize,
	int*				pnMenuMode)
{
	LPCOMPOSITIONSTRING	lpCompStr	= NULL ;
	LPCDSTR		pdKeys	= NULL ;
	int			nKeys	= 0 ;
	int			nMode	= -1 ;

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpCompStr) {
		LPMYCOMPSTR	pMyCompStr	= (LPMYCOMPSTR) lpCompStr ;
		BOOL		bMenu1p ;

		if (lpCompStr->dwSize > sizeof (COMPOSITIONSTRING)){
			int			ndKeys	= 0 ;

			if (ImeDoc_bShowHenkanCandidatesModep (&pMyCompStr->_Doc)) {
				nMode	= UICAND_SHOWHANKANCANDIDATESMODE ;
				pdKeys	= ImeConfig_pGetSkkHenkanShowCandidatesKeys (&ndKeys) ;
			} else if (ImeDoc_bInputByCodeOrMenuModep (&pMyCompStr->_Doc, &bMenu1p)) {
				nMode	= UICAND_INPUTBYCODEORMENUMODE ;
				if (! bMenu1p) {
					pdKeys	= ImeConfig_pGetSkkInputByCodeMenuKeys1 (&ndKeys) ;
				} else {
					pdKeys	= ImeConfig_pGetSkkInputByCodeMenuKeys2 (&ndKeys) ;
				}
			} else {
				/* error */
				nMode	= UICAND_INVALIDMODE ;
				pdKeys	= NULL ;
			}
			if (pdKeys != NULL && ndKeys > 0) {
				nKeys	= dcstowcs (pwDest, nDestSize, pdKeys, ndKeys) ;
			} else {
				nKeys	= 0 ;
			}
		}
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
	if (pnMenuMode != NULL)
		*pnMenuMode	= nMode ;
	return	nKeys ;
}

/*========================================================================
 *	For UI Annotation Window
 */
void	PASCAL
uiAnnot_vPaint (
	HWND		hWnd)
{
	HDC			hDC ;
	HGLOBAL		hText ;
	PAINTSTRUCT	ps ;

	hDC		= BeginPaint (hWnd, &ps) ;
	hText	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UIANNOT_TEXT) ;
	if (hText != NULL) {
		LPCTSTR	strText ;

		strText	= (LPCTSTR) GlobalLock (hText) ;
		if (strText != NULL)
			MyTextOut (hDC, 0, 0, strText, lstrlen (strText)) ;
		GlobalUnlock (hText) ;
	}
	EndPaint (hWnd, &ps) ;
	return ;
}

LRESULT	CALLBACK
UIAnnot_WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message){
	case	WM_CREATE:
		{
			SetWindowLongPtr (hWnd, FIGWLP_UIANNOT_TEXT,    (LONG_PTR) 0) ;
			SetWindowLong    (hWnd, FIGWL_MOUSE,			(LONG) 0) ;
			return	0 ;
		}

	case	WM_SETCURSOR:
		{
			DWORD	dwMouse	= (DWORD) GetWindowLong (hWnd, FIGWL_MOUSE) ;
			POINT	ptCursor ;

			GetCursorPos (&ptCursor) ;
			if (LOWORD (dwMouse)  != ptCursor.x || HIWORD (dwMouse) != ptCursor.y)
				ShowWindow (hWnd, SW_HIDE) ;
			SetWindowLong (hWnd, FIGWL_MOUSE, ((DWORD)ptCursor.y << 16) | (WORD)ptCursor.x) ;
			return	0 ;
		}

	case	WM_SETTEXT:
		{
			const MYCHAR*	strText	= (const MYCHAR*) lParam ;
			HGLOBAL	hText	= 0 ;
			int		nText	= 0 ;

			hText	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UIANNOT_TEXT) ;
			if (hText != 0) 
				GlobalFree (hText) ;

			if (strText != 0 && *strText != MYTEXT ('\0')) {
				nText	= Mylstrlen (strText) ;
				hText	= GlobalAlloc (GHND, sizeof (TCHAR) * (nText + 1)) ;
				if (hText != NULL) {
					MYCHAR*	pText ;
					pText	= (MYCHAR*) GlobalLock (hText) ;
					if (pText != NULL) {
						Mylstrcpy (pText, strText) ;
						GlobalUnlock (hText) ;
					}
				}
			} else {
				hText	= 0 ;
			}
			SetWindowLongPtr (hWnd, FIGWLP_UIANNOT_TEXT, (LONG_PTR) hText) ;

			/*	Resize Window */
			if (nText > 0) {
				HDC		hDC ;
				SIZE	sz ;
				RECT	rc ;
				POINT	ptCursor ;

				hDC		= GetDC (hWnd) ;
				sz.cx = sz.cy	= 0 ;
				if (hDC != NULL) {
					if (GetTextExtentPoint32 (hDC, strText, nText, &sz)) {
						sz.cx	+= GetSystemMetrics (SM_CXBORDER) * 2 ;
						sz.cy	+= GetSystemMetrics (SM_CYBORDER) * 2 ;
					}
					ReleaseDC (hWnd, hDC) ;
				}
				if (! GetWindowRect (hWnd, &rc))
					rc.left = rc.top = 0 ;

				GetCursorPos (&ptCursor) ;
				SetWindowLong (hWnd, FIGWL_MOUSE, ((DWORD)ptCursor.y << 16) | (WORD)ptCursor.x) ;
				MoveWindow (hWnd, rc.left, rc.top, sz.cx, sz.cy, TRUE) ;
			} else {
				ShowWindow (hWnd, SW_HIDE) ;
			}
			break ;
		}

	case	WM_DESTROY:
		{
			HGLOBAL	hText	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UIANNOT_TEXT) ;
			if (hText != 0) 
				GlobalFree (hText) ;
			return	0 ;
		}

	case WM_PAINT:
		uiAnnot_vPaint (hWnd) ;
		break ;

	case WM_MOVE:
		break ;

	default:
		if (!MyIsIMEMessage (message))
			return DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	0L ;
}

/*========================================================================
 */
/*
 *	�~�j�o�b�t�@���ŉE�N���b�N���ꂽ���� Context Menu �̏������s���֐��B
 */
BOOL	
uiCand_bHandleMinibufContextMenu (
	HWND		hwnd,
	HIMC		hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	int				nCmd ;
	unsigned int		uVK ;

	nCmd	= uiCand_iPopupMinibufContextMenu (hwnd, hIMC) ;
	lpIMC	= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	switch (nCmd){
	case	IDM_CUT:
		uVK	= NFUNC_MOUSE_CUT ;
		break ;
	case	IDM_PASTE:
		uVK	= NFUNC_MOUSE_PASTE ;
		break ;
	case	IDM_COPY:
		uVK	= NFUNC_MOUSE_COPY ;
		break ;
	case	IDM_DELETE:
		uVK	= NFUNC_MOUSE_DELETE ;
		break ;
	default:
		uVK	= 0 ;
		break ;
	}
	if (uVK != 0) {
		LPMYCOMPSTR		lpMyCompStr ;

		lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
		if (lpMyCompStr != NULL){
			struct TMSG	msg ;
			BOOL		fEaten ;

			msg.m_nMessage	= WM_LM_COMMAND ;
			msg.m_wParam	= uVK ;
			msg.m_lParam	= 0 ;
			msg.m_pt.x		= msg.m_pt.y	= 0 ;
			msg.m_nTime		= GetTickCount () ;
			msg.m_rParam	= 0 ;
			if (ImeDoc_bFilterEvent (&lpMyCompStr->_Doc, &msg))
				TSkkIme_bUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr) ;
			ImmUnlockIMCC (lpIMC->hCompStr) ;
		}
	}
	ImmUnlockIMC (hIMC) ;
	return	TRUE ;
}

int	
uiCand_iPopupMinibufContextMenu (
	HWND	hwnd,
	HIMC	hIMC)
{
	HMENU			hMenu		= NULL ;
	LPINPUTCONTEXT	lpIMC		= NULL ;
	LPMYCOMPSTR		lpMyCompStr	= NULL ;
	int				nCmd ;
	HCURSOR			hCursor ;
	POINT			ptCursor ;

	hMenu		= 0 ;
	nCmd		= -1 ;
	GetCursorPos (&ptCursor) ;
	lpIMC		= ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	-1 ;
	/* Minibuffer �ɕ\�����ׂ�������𓾂�B*/
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr){
		hMenu	= TSkkIme_hCreateClipboardMenu (lpMyCompStr) ;
		ImmUnlockIMCC (lpIMC->hCompStr) ;
	}
	ImmUnlockIMC (hIMC) ;
	if (hMenu){
		/* ���j���[��\�����āA�I��������B*/
		hCursor	= SetCursor (LoadCursor (NULL, IDC_ARROW)) ;
		nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN, ptCursor.x, ptCursor.y, 0, hwnd, NULL) ;
		DestroyMenu (hMenu) ;
		(void)SetCursor (hCursor) ;
	}
	return	nCmd ;
}

int
uiCand_iGetMinibufferCursorPos (
	HWND				hWnd,
	HIMC				hIMC,
	LPPOINT				lppoint)
{
	LPINPUTCONTEXT	lpIMC		= NULL ;
	LPMYCOMPSTR		lpMyCompStr	= NULL ;
	LPCANDIDATEINFO	lpCandInfo	= NULL ;
	LPCANDIDATELIST	pCandList	= NULL ;
	TEXTMETRIC		tm ;
	int				iCursorPos		= -1 ;
	int				iNewCursorPos	= -1 ;
	LPMYSTR			pwSText, pText ;
	HDC				hDC ;
	int				nText, nDY, x, y, nTextPos ;
	RECT			rc ;
	BOOL			bCursorPos ;

	lpIMC			= ImmLockIMC (hIMC) ;
	if (lpIMC == NULL) 
		goto	exit_func ;

	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		goto	exit_func ;
	if (! ImeDoc_bGetStatusCursor (&lpMyCompStr->_Doc, &iCursorPos)) {
		iCursorPos	= -1 ;
	}
	ImmUnlockIMCC (lpIMC->hCompStr) ;

	if (ImmGetIMCCSize (lpIMC->hCandInfo) < sizeof (CANDIDATEINFO)) 
		goto	exit_func ;
	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (lpCandInfo == NULL)
		goto	exit_func ;
	if (lpCandInfo->dwCount <= 0)
		goto	exit_func_1 ;

	GetClientRect (hWnd, &rc) ;
	hDC			= GetDC (hWnd) ;
	if (hDC == NULL)
		goto	exit_func_1 ;
	GetTextMetrics (hDC, &tm) ;
	nDY			= tm.tmHeight ;

	pCandList	= (LPCANDIDATELIST)((LPSTR)lpCandInfo  + lpCandInfo->dwOffset[0]) ;
	pwSText		= (LPMYSTR)((LPSTR)pCandList + pCandList->dwOffset [0]) ;
	pText		= pwSText ;
	nText		= Mylstrlen (pwSText) ;
	nTextPos	= 0 ;
	x			= rc.left ;
	y			= rc.top ;
	bCursorPos	= FALSE ;
	while (y < rc.bottom && 0 < nText) {
		int		nChar, iSX ;
		BOOL	bCRLF ;
		SIZE	sz ;

		bCRLF	= FALSE ;
		iSX		= x ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			if ((nTextPos + nChar - 1) == iCursorPos && *(pText + nChar - 1) == L'|') {
				break ;	/* cursor */
			}
			MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
			if ((x + sz.cx) >= rc.right) {
				bCRLF	= TRUE ;
				break ;
			}
			if ((x + sz.cx) >= lppoint->x && y <= lppoint->y && lppoint->y < (y + nDY)) {
				/* found */
				iNewCursorPos	= nTextPos + nChar - 1 ;
				goto	exit_loop ;
			}
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;

		MyGetTextExtentPoint (hDC, pText, nChar, &sz) ;
		x	+= sz.cx ;
		if (bCRLF) {
			MyGetTextExtentPoint (hDC, MYTEXT ("\\"), 1, &sz) ;
			x	+= sz.cx ;
		}
		if ((nTextPos + nChar) == iCursorPos) {
			/* �J�[�\���̒��O�܂ŕ`�悳��Ă����ԁB*/
			if ((nChar + 1) >= nText) {
			} else {
				bCursorPos		= TRUE ;
			}
			nChar	++ ;	/* skip: �J�[�\���ʒu�ɑ}������Ă���``|'' */
		} else {
			if (bCursorPos) {
				bCursorPos	= FALSE ;
			}
		}
		if (bCRLF) {
			y		+= nDY ;
			x		= rc.left ;
		}
		if (y > lppoint->y) {
			/* found */
			iNewCursorPos	= nTextPos + nChar - 1 ;
			goto	exit_loop ;
		}
		pText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
	}
	iNewCursorPos	= nTextPos ;
exit_loop:
	ReleaseDC (hWnd, hDC) ;

	if (iNewCursorPos > 0 && iNewCursorPos > iCursorPos)
		iNewCursorPos	-- ;
exit_func_1:
	ImmUnlockIMCC (lpIMC->hCandInfo) ;
exit_func:
	ImmUnlockIMC (hIMC) ;
	return	iNewCursorPos ;
}

BOOL
uiCand_bMinibuffered (
	LPINPUTCONTEXT	lpIMC)
{
	LPCANDIDATEINFO	lpCandInfo ;
	LPCANDIDATELIST	lpCandList ;
	BOOL			bMinibuffered	= FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCandInfo) < sizeof (CANDIDATEINFO)) 
		return	FALSE ;
	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	if (lpCandInfo == NULL)
		return	FALSE ;
	if (lpCandInfo->dwCount <= 0)
		goto	exit_func_1 ;

	lpCandList		= (LPCANDIDATELIST)((LPSTR)lpCandInfo  + lpCandInfo->dwOffset[0]) ;
	bMinibuffered	= (lpCandList->dwPageSize == 1) ;
exit_func_1:
	ImmUnlockIMCC (lpIMC->hCandInfo) ;
	return	bMinibuffered ;
}

/*========================================================================
 *	For UI Message Window
 */
BOOL
uiCand_bShowBalloonTip (
	HWND			hWnd,
	LPINPUTCONTEXT	lpIMC)
{
	HWND		hwndToolTips ;
	HGLOBAL		hToolTipInfo ;
	LPMYCOMPSTR	lpMyCompStr ;
	struct CImeDoc*	pDoc ;
	BOOL		bNeedShow, bNeedCandWnd ;
	LPCDSTR		pdText ;
	int			iTextDLen, iTextLen ;
	WCHAR		bufText [256] ;
    TOOLINFO	ti ;
	RECT		rc ;

	hwndToolTips	= (HWND) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIP) ;
	if (hwndToolTips == NULL || ! IsWindow (hwndToolTips))
		return	FALSE ;

	/*	minibuffer mode �� message �����݂���Aor
	 *	���ꗗ�\�� mode �� message �����݂���ꍇ�̏����B
	 */
	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		return	FALSE ;

	pDoc			= &lpMyCompStr->_Doc ;
	bNeedCandWnd	= ImeDoc_bRecursiveEditp (pDoc) || ImeDoc_bShowHenkanCandidatesModep (pDoc) || ImeDoc_bInputByCodeOrMenuModep (pDoc, NULL) ;
	bNeedShow		= /*bNeedCandWnd &&*/ ImeDoc_bHaveMessagep (pDoc) ;
	if (! bNeedShow) {
		ShowWindow (hwndToolTips, SW_HIDE) ;
		goto	exit_func ;
	}

	pdText		= ImeDoc_pGetMessage (pDoc, &iTextDLen) ;
	if (iTextDLen <= 0) {
		ShowWindow (hwndToolTips, SW_HIDE) ;
		goto	exit_func ;
	}
	iTextLen	= dcstowcs (bufText, ARRAYSIZE (bufText), pdText, iTextDLen) ; 
	if (iTextLen >= ARRAYSIZE (bufText)) {
		bufText [ARRAYSIZE (bufText) - 4]	= L'.' ;
		bufText [ARRAYSIZE (bufText) - 3]	= L'.' ;
		bufText [ARRAYSIZE (bufText) - 2]	= L'.' ;
		bufText [ARRAYSIZE (bufText) - 1]	= L'\0' ;
	} else {
		bufText [iTextLen]	= L'\0' ;
	}

	hToolTipInfo	= (HGLOBAL) GetWindowLongPtr (hWnd, FIGWLP_UICAND_TOOLTIPINFO) ;
	if (hToolTipInfo != NULL) {
		PTOOLTIPINFO	pToolTipInfo ;

		pToolTipInfo	= (PTOOLTIPINFO) GlobalLock (hToolTipInfo) ;
		if (pToolTipInfo != NULL) {
			POINT		pt ;
			GetCursorPos (&pt) ;
			pToolTipInfo->_ptLastPos.x	= pt.x ;
			pToolTipInfo->_ptLastPos.y	= pt.y ;
			GlobalUnlock (hToolTipInfo) ;
		}
	}

	GetWindowRect (hWnd, &rc) ;
	if (bNeedCandWnd) {
		/* Window �̏ꏊ�́E�E�E */
		MoveWindow (hwndToolTips, rc.left, rc.bottom, 1, 1, TRUE) ;
	} else {
		MoveWindow (hwndToolTips, rc.left, rc.top, 1, 1, TRUE) ;
	}
	/* SetWindowText �ŃT�C�Y�̒����������B*/
	SetWindowText (hwndToolTips, bufText) ;
	ShowWindow (hwndToolTips, SW_SHOWNOACTIVATE) ;
exit_func:
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	TRUE ;
}

BOOL
uiCand_bNeedCandidateWindowp (
	LPINPUTCONTEXT		lpIMC)
{
	LPMYCOMPSTR	lpMyCompStr ;
	struct CImeDoc*	pDoc ;
	BOOL		bNeedShow, bNeedCandWnd ;

	lpMyCompStr	= (LPMYCOMPSTR)ImmLockIMCC (lpIMC->hCompStr) ;
	if (lpMyCompStr == NULL) 
		return	FALSE ;

	pDoc			= &lpMyCompStr->_Doc ;
	bNeedCandWnd	= ImeDoc_bRecursiveEditp (pDoc) || ImeDoc_bShowHenkanCandidatesModep (pDoc) || ImeDoc_bInputByCodeOrMenuModep (pDoc, NULL) ;
	ImmUnlockIMCC (lpIMC->hCompStr) ;
	return	bNeedCandWnd ;
}

void
uiCand_vAdjustPosition (
	const RECT*				pRect,
	const SIZE*				pszWnd,
	POINT*					pPT)
{
	POINT	ptOffset, ptBase ;

	/* Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B*/
	if (pPT->x < 0)
		pPT->x	= 0 ;
	if (pPT->y < 0)
		pPT->y	= 0 ;

	if (pRect->right > 0) {
		ptOffset.x	= pPT->x % pRect->right ;
		if (ptOffset.x < 0)
			ptOffset.x	= pRect->right + ptOffset.x ;
		ptBase.x	= pPT->x - ptOffset.x ;
		if ((ptOffset.x + pszWnd->cx) > pRect->right){
			ptOffset.x	= pRect->right - pszWnd->cx ;
		}
		if (ptOffset.x < 0)
			ptOffset.x	= 0 ;
		pPT->x		= ptBase.x + ptOffset.x ;
	}
	if (pRect->bottom > 0) {
		ptOffset.y	= pPT->y % pRect->bottom ;
		if (ptOffset.y < 0)
			ptOffset.y	= pRect->bottom + ptOffset.y ;
		ptBase.y	= pPT->y - ptOffset.y ;
		if ((ptOffset.y + pszWnd->cy) > pRect->bottom){
			ptOffset.y = pRect->bottom - pszWnd->cy ;
		}
		if (ptOffset.y < 0)
			ptOffset.y	= 0 ;
		pPT->y		= ptBase.y + ptOffset.y ;
	}
	/*	���̑���̌�A���O����̈�Əd�Ȃ��Ă���\����
	 *	����̂ł͂Ȃ��낤���H
	 */
	return ;
}

