#if !defined (mylmcons_h)
#define	mylmcons_h

/*	WindowsXP DDK 
 */
#if defined (_WIN32_WINNT) && (_WIN32_WINNT >= 0x0500)
#define	UNLEN	(256)
#else
#if defined (WINVER) && (WINVER >= 0x0500)
#define	UNLEN	(256)
#else
#include "lmcons.h"
#endif
#endif

#endif

