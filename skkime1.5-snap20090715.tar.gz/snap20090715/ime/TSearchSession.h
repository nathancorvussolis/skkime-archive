#pragma once

struct CTSearchSession ;
struct CTS4Candidate ;
struct CTS4Mapping ;

enum {
	SEARCH_OKURI_NASHI	= 0,
	SEARCH_OKURI_ARI,
	SEARCH_OKURI_STRICT,
	SEARCH_OKURI_STRICT_PRECEDENCE,
	SEARCH_OKURI_AUTO,
} ;

/*========================================================================
 *	prototypes
 */
LPCDSTR		TSearchSession_pGetReferCandidate		(struct CTSearchSession*) ;
LPCDSTR		TSearchSession_pGetCandidate			(struct CTSearchSession*) ;
LPCDSTR		TSearchSession_pGetKeyword				(struct CTSearchSession*, int*) ;
BOOL		TSearchSession_bNextCandidate			(struct CTSearchSession*) ;
BOOL		TSearchSession_bPreviousCandidate		(struct CTSearchSession*) ;
BOOL		TSearchSession_bInsertCandidate			(struct CTSearchSession*, LPCDSTR, int) ;
BOOL		TSearchSession_bInsertCandidateWithS4Mapping	(struct CTSearchSession*, LPCDSTR, int, const struct CTS4Mapping*) ;
BOOL		TSearchSession_bRewind					(struct CTSearchSession*) ;
void		TSearchSession_vDestroy					(struct CTSearchSession*) ;
int			TSearchSession_iGetNumberOfCandidate	(struct CTSearchSession*, BOOL*) ;
BOOL		TSearchSession_bNumericp				(const struct CTSearchSession*) ;
LPCDSTR		TSearchSession_pGetNumericList			(const struct CTSearchSession*) ;

struct CTS4Candidate*	TSearchSession_pGetNumericLink	(struct CTSearchSession*) ;
LPCDSTR		TSearchSession_pGetNumericKeyword	(struct CTSearchSession*, struct CTS4Candidate*, int*) ;
LPCDSTR		TSearchSession_pGetNumericResult	(struct CTSearchSession*, struct CTS4Candidate*, int*) ;
struct CTS4Candidate*	TSearchSession_pGetNextNumericLink	(struct CTSearchSession*, struct CTS4Candidate*) ;

struct CTSearchSession*	TCompletionSession_pCreate	(LPCDSTR, int) ;
struct CTSearchSession*	TOkuriHenkanSession_pCreate	(LPCDSTR, int, LPCDSTR, int, int, BOOL, BOOL) ;
struct CTSearchSession*	THenkanSession_pCreate		(LPCDSTR, int, int, BOOL, BOOL) ;
struct CTSearchSession*	TKakuteiHistoryCompletionSession_pCreate (void) ;

struct CTS4Mapping*		TS4Mapping_pCreate			(LPCDSTR, LPCDSTR, int) ;
BOOL		TS4Mapping_bInsertLast					(struct CTS4Mapping**, struct CTS4Mapping*) ;
void		TS4Mapping_vClearList					(struct CTS4Mapping*) ;


