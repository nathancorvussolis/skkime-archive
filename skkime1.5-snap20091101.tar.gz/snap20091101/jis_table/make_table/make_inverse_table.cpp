/*	JISX0213-2004-std.txt parser
 */
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>

#define	BUFFER_UNITSIZE	(4096)
#define	NODE_UNICODELEN	(8)

struct MyNode {
	DWORD	m_rdwUnicode [NODE_UNICODELEN] ;
	DWORD	m_dwCode ;
	struct MyNode*	m_pNext ; 
} ;

struct MyLabelNode {
	TCHAR	m_bufLabel [256] ;
	int		m_iNumber ;
	struct MyLabelNode*	m_pNext ;
} ;

static	BOOL	bReadTable (FILE* fp, LPCTSTR) ;
static	BOOL	bMakeCode (DWORD*, const BYTE*, int) ;
static	BOOL	bRegisterCode (LPCTSTR, const BYTE* pbMB, int nMBLen, const DWORD* pbUnicode, int nUnicodeLen) ;
static	BOOL	bParseNumber (LPCTSTR* ppString, BYTE* pResult, int* pnResultLen) ;
static	BOOL	bParseUnicode (LPCTSTR* ppString, DWORD* pdwUnicode, int nBufferSize, int* pnUsage) ;
static	BOOL	bParseWindowOrFullwidthCode (LPCTSTR* ppString, DWORD* pdwUnicode, int nBufferSize, int* pnUsage) ;
static	void	vDumpTable (void) ;

static	DWORD	s_rdwUnicodeTable [65536] = { 0 } ;

static	DWORD*	s_rpUnicodeTables [16]	= {
	s_rdwUnicodeTable,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
} ;

static	struct MyNode*		s_plst			= NULL ;
static	struct MyLabelNode*	s_plstLabel		= NULL ;
static	int					s_iLabelCount	= 1 ;
static	BOOL				s_bWindows		= TRUE ;
static	BOOL				s_bFullwidth	= TRUE ;

int _tmain (int argc, TCHAR* rpArgv [])
{
	int	i ;

	memset (s_rdwUnicodeTable, 0, sizeof (s_rdwUnicodeTable)) ;
	for (i = 1 ; i < argc ; i ++) {
		FILE*	fp ;
		BOOL	bRetval ;
		TCHAR	bufLabel [256] ;

		fp	= _tfopen (rpArgv [i], TEXT ("r")) ;
		if (fp == NULL) {
			_ftprintf (stderr, TEXT ("\"%s\" not found.\n"), rpArgv [i]) ;
			continue ;
		}

		{
			int		nLen ;
			LPCTSTR	ptr ;
			nLen	= lstrlen (rpArgv [i]) ;
			ptr	= rpArgv [i] + nLen - 1 ;
			while (ptr >= rpArgv [i]) {
				if (*ptr == TEXT ('.')) {
					int	n = ptr - rpArgv [i] ;
					_tcsncpy (bufLabel, rpArgv [i], n) ;
					bufLabel [n]	= TEXT ('\0') ;
					break ;
				}
				ptr	-- ;
			}
			if (ptr < rpArgv [i]) {
				int	n = (nLen < ARRAYSIZE(bufLabel)-1)? nLen : ARRAYSIZE(bufLabel)-1 ;
				_tcsncpy (bufLabel, rpArgv [i], n) ;
				bufLabel [n]	= TEXT ('\0') ;
			}
		}
		_ftprintf (stderr, TEXT ("Parsing \"%s\" (label: \"%s\")..."), rpArgv [i], bufLabel) ;
		bRetval	= bReadTable (fp, bufLabel) ;
		fclose (fp) ;
		_ftprintf (stderr, TEXT ("%s\n"), (bRetval? TEXT("ok") : TEXT("ng"))) ;
	}
	vDumpTable () ;
	return	EXIT_SUCCESS ;
}

static	BOOL
bReadTable (FILE* fp, LPCTSTR strLabel)
{
	TCHAR	buf [2048] ;
	TCHAR	bufLabel [256] ;
	BOOL	bRetval	= TRUE ;

	while (! feof (fp)) {
		BYTE	bufMB [32] ;
		DWORD	rdwCodes [32] ;
		int		nCodeLen ;
		int		nMBLen ; 
		int		nLength ;
		LPCTSTR	ptr ;
		LPCTSTR	strCurLabel ;
		BOOL	bOverwrite ;

		buf [ARRAYSIZE(buf)-1]	= TEXT ('\0') ;
		if (_fgetts (buf, ARRAYSIZE (buf)-1, fp) == NULL)
			break ;
		nLength	= lstrlen (buf) ;
		if (! ((nLength > 0 && buf [nLength-1] == 0x0A) || (nLength > 1 && buf [nLength-2] == 0x0D && buf [nLength-1] == 0x0A))) {
			/* too long line */
			while (! feof (fp)) {
				int	ch	= _fgettc (fp) ;
				if (ch == TEXT ('\n'))
					break ;
			}
			continue ;
		}
		if (nLength <= 0)
			continue ;
		if (buf [0] == 0x0A || (nLength > 1 && buf [0] == 0x0D && buf [1] == 0x0A))
			continue ;
		if (buf [0] == TEXT ('#'))
			continue ;	/* comment line */

		/* token ���ɐ؂�o���B*/
		ptr			= buf ;
		strCurLabel	= NULL ;
		nMBLen		= 0 ;
		while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0')) {
			if ((*ptr == TEXT ('3') || *ptr == TEXT ('4')) && *(ptr+1) == TEXT ('-')) {
				int	n;
				/* found 
				bufMB [0]	= (*ptr - TEXT ('3')) + 3 ;
				*/
				n				= _sntprintf (bufLabel, ARRAYSIZE (bufLabel)-1, TEXT ("%s_%d"), strLabel, (*ptr - TEXT ('0'))) ;
				bufLabel [n]	= TEXT ('\0') ;
				strCurLabel		= bufLabel ;

				ptr			+= 2 ;
				nMBLen		= ARRAYSIZE (bufMB) ;
				if (! bParseNumber (&ptr, bufMB, &nMBLen)) {
					_ftprintf (stderr, TEXT ("Parse number error\n")) ;
					goto	skip_loop ;
				}
//				_ftprintf (stderr, TEXT ("%d (%x, %x, %x)\n"), nMBLen, bufMB [0], bufMB [1], bufMB [2]) ;
				break ;
			} else if (*ptr == TEXT ('0') && *(ptr+1) == TEXT ('x')) {
				strCurLabel	= strLabel ;

				ptr			+= 2 ;
				nMBLen		= ARRAYSIZE (bufMB) ;
				if (! bParseNumber (&ptr, bufMB, &nMBLen)) 
					goto	skip_loop ;
				break ;
			}
			if (*ptr != TEXT (' ') && *ptr != TEXT ('\t'))
				goto	skip_loop ;
			ptr	++ ;
		}
		if (strCurLabel == NULL) {
//			_ftprintf (stderr, TEXT ("Parse number error\n")) ;
			goto	skip_loop ;
#if 0
		} else {
			_ftprintf (stderr, TEXT ("\"%s\"\n"), ptr) ;
#endif
		}
		nCodeLen	= 0 ;
		bOverwrite	= FALSE ;
		while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0')) {
			if ((*ptr == TEXT ('U') && *(ptr+1) == TEXT ('+')) ||
				(*ptr == TEXT ('0') && *(ptr+1) == TEXT ('x'))) {
				/* found */
				if (! bParseUnicode (&ptr, rdwCodes, ARRAYSIZE(rdwCodes), &nCodeLen))
					goto	skip_loop ;
				while (*ptr == TEXT (' ') || *ptr == TEXT ('\t'))
					ptr	++ ;
				if (*ptr == TEXT ('#')) {
					DWORD	rdwCodes2 [32] ;
					int		nCodeLen2 ;

					ptr	++ ;
					if (bParseWindowOrFullwidthCode (&ptr, rdwCodes2, ARRAYSIZE(rdwCodes2), &nCodeLen2)) {
						if (rdwCodes [0] <= 0x7F && nCodeLen == 1) {
							bOverwrite	= TRUE ;
						}
						memcpy (rdwCodes, rdwCodes2, nCodeLen2 * sizeof (DWORD)) ;
						nCodeLen	= nCodeLen2 ;
					} else {
						bOverwrite	= TRUE ;
					}
				}
#if 0
				if (rdwCodes [0] == 0xFF0D) {
					int	i ;
					for (i = 0 ; i < nMBLen ; i ++) {
						_ftprintf (stderr, TEXT("%02X"), bufMB [i]) ;
					}
					_ftprintf (stderr, TEXT (" ")) ;
					_ftprintf (stderr, TEXT ("U")) ;
					for (i = 0 ; i < nCodeLen ; i ++) {
						_ftprintf (stderr, TEXT ("+%08X"), rdwCodes [i]) ;
					}
					_ftprintf (stderr, TEXT ("\n")) ;
				}
#endif
				break ;
			} else if (*ptr == TEXT ('#') && (s_bFullwidth || s_bWindows)) {
				ptr	++ ;
				if (! bParseWindowOrFullwidthCode (&ptr, rdwCodes, ARRAYSIZE(rdwCodes), &nCodeLen)) {
					goto	skip_loop ;
				}
			} else if (*ptr != TEXT (' ') && *ptr != TEXT ('\t')) {
				goto	skip_loop ;
			}
			ptr	++ ;
		}
		if (! bRegisterCode (strCurLabel, bufMB, nMBLen, rdwCodes, nCodeLen)) {
			// error
			bRetval	= FALSE ;
			break ;
		}
skip_loop:
		;
	}
	return	bRetval ;
}

static	int
iGetLabelNumber (LPCTSTR strLabel)
{
	struct MyLabelNode*	pNode ;
	int		nLen, n ;

	pNode	= s_plstLabel ;
	while (pNode != NULL) {
		if (! lstrcmp (pNode->m_bufLabel, strLabel)) {
			return	pNode->m_iNumber ;
		}
		pNode	= pNode->m_pNext ;
	}
	nLen			= lstrlen (strLabel) ;
	pNode	= (struct MyLabelNode*) malloc (sizeof (struct MyLabelNode)) ;
	pNode->m_pNext	= s_plstLabel ;
	s_plstLabel		= pNode ;
	n				= (nLen < ARRAYSIZE (pNode->m_bufLabel)-1)? nLen : ARRAYSIZE(pNode->m_bufLabel)-1 ;
	_tcsncpy (pNode->m_bufLabel, strLabel, n) ;
	pNode->m_bufLabel [n]	= TEXT ('\0') ;
	pNode->m_iNumber		= s_iLabelCount ++ ;
	return	pNode->m_iNumber ;
}

static	BOOL
bRegisterCode (
	LPCTSTR			strCurLabel,
	const BYTE*		pbMB,
	int				nMBLen,
	const DWORD*	pdwUnicode,
	int				nUnicodeLen)
{
	DWORD	dwLeading, dwCode, dwUnicode ;
	int		nLabel ;

	if (nMBLen > 2 || nMBLen <= 0 || nUnicodeLen <= 0) {
		int	i ;
		for (i = 0 ; i < nMBLen ; i ++) {
			_ftprintf (stderr, TEXT("%02X "), pbMB [i]) ;
		}
		_ftprintf (stderr, TEXT ("(%d), nUnicodeLen = %d\n"), nMBLen, nUnicodeLen) ;
		return	FALSE ;
	}

	nLabel		= iGetLabelNumber (strCurLabel) ;
	if (nLabel < 0) {
		_ftprintf (stderr, TEXT ("Label = %d\n"), nLabel) ;
		return	FALSE ;
	}

	if (nMBLen == 2) {
		dwCode	= ((DWORD)*pbMB << 8) | ((DWORD)*(pbMB + 1)) ;
	} else {
		dwCode	= (DWORD) *pbMB ;
	}

	if (nUnicodeLen == 1) {
		DWORD	dwPlane ;
		DWORD*	pdwUnicodeTable ;

		dwUnicode		= *pdwUnicode ;
		dwPlane			= dwUnicode >> 16;
		if (dwPlane >= 16)
			return	FALSE ;
		pdwUnicodeTable	= s_rpUnicodeTables [dwPlane] ;
		if (pdwUnicodeTable == NULL) {
			s_rpUnicodeTables [dwPlane]	= (DWORD*) malloc (sizeof (DWORD) * 0x10000) ;
			if (s_rpUnicodeTables [dwPlane] == NULL) {
				_ftprintf (stderr, TEXT ("Out of memory.\n")) ;
				exit (1) ;
			}
			pdwUnicodeTable	= s_rpUnicodeTables [dwPlane] ;
			memset (pdwUnicodeTable, 0, sizeof (DWORD) * 0x10000) ;
		}
		if (pdwUnicodeTable [dwUnicode & 0xFFFF] == 0)
			pdwUnicodeTable [dwUnicode & 0xFFFF]	= (nLabel << 24) | dwCode ;
	} else if (nUnicodeLen < NODE_UNICODELEN) {
		struct MyNode*	pNode	= NULL ;
		int	i ;


		pNode	= (struct MyNode*) malloc (sizeof (struct MyNode)) ;
		if (pNode == NULL) {
			_ftprintf (stderr, TEXT ("Out of memory.\n")) ;
			exit (1) ;
		}
		memset (pNode, 0, sizeof (struct MyNode)) ;
		pNode->m_pNext	= s_plst ;
		s_plst			= pNode ;
		pNode->m_dwCode	= (nLabel << 24) | dwCode ;
		memcpy (pNode->m_rdwUnicode, pdwUnicode, sizeof (DWORD) * nUnicodeLen) ;
		pNode->m_rdwUnicode [nUnicodeLen]	= 0 ;
	} else {
		return	FALSE ;
	}
	return	TRUE ;
}

static	BOOL
bMakeCode (
	DWORD*		pdwDest,
	const BYTE*	pbUnicode,
	int			nUnicodeLen)
{
	DWORD	dw ;

	if (nUnicodeLen <= 0 || nUnicodeLen > 4)
		return	FALSE ;
	dw	= 0 ;
	while (nUnicodeLen > 0) {
		dw	= (dw << 8) | ((DWORD) *pbUnicode ++) ;
		nUnicodeLen	-- ;
	}
	*pdwDest	= dw ;
	return	TRUE ;
}

static	BOOL
bParseNumber (
	LPCTSTR*	ppString,
	BYTE*		pResult,
	int*		pnResultLen)
{
	BYTE	buf [256] ;
	LPCTSTR	ptr ;
	BYTE*	pDest ;
	const BYTE*	pDestEnd ;
	const BYTE*	pSrc ;
	const BYTE*	pSrcEnd ;
	int		nResultLen ;

	if (ppString == NULL || pnResultLen == NULL)
		return	FALSE ;

	ptr			= *ppString ;
#if 0
	if (*ptr != TEXT ('0'))
		return	FALSE ;
	ptr	++ ;
	if (*ptr != TEXT ('x'))
		return	FALSE ;
	ptr	++ ;
#endif
	pDest		= buf ;
	pDestEnd	= buf + ARRAYSIZE (buf) ;
	while (*ptr != TEXT ('\0')) {
		if (TEXT ('0') <= *ptr && *ptr <= TEXT ('9')) {
			if (pDest >= pDestEnd)
				return	FALSE ;
			*pDest ++	= *ptr - TEXT ('0') ;
		} else if (TEXT ('A') <= *ptr && *ptr <= TEXT ('F')) {
			if (pDest >= pDestEnd)
				return	FALSE ;
			*pDest ++	= (*ptr - TEXT ('A')) + 10 ;
		} else if (TEXT ('a') <= *ptr && *ptr <= TEXT ('f')) {
			if (pDest >= pDestEnd)
				return	FALSE ;
			*pDest ++	= (*ptr - TEXT ('a')) + 10 ;
		} else {
			break ;
		}
		ptr	++ ;
	}
	if (pDest <= buf)
		return	FALSE ;

	pSrc		= buf ;
	pSrcEnd		= pDest ;

	if (pResult != NULL) {
		int	nLength		= pDest - buf ;
		DWORD	dwValue ;
	
		nResultLen	= *pnResultLen ;
		pDest		= pResult ;
		pDestEnd	= pResult + nResultLen ;

		if ((nLength & 1) && pDest < pDestEnd) {
			*pDest ++	= *pSrc ++ ;
		}
		while (pSrc < pSrcEnd-1 && pDest < pDestEnd) {
			dwValue		=  (*pSrc ++) << 4 ;
			dwValue		|= *pSrc ++ ;
			*pDest ++	=  dwValue ;
		}
		nResultLen	= pDest - pResult ;
	} else {
		int	nLength		= pDest - buf ;

		nResultLen	= (nLength + 1) / 2 ;
	}
	*pnResultLen	= nResultLen ;
	*ppString		= ptr ;
	return	TRUE ;
}

BOOL
bParseUnicode (LPCTSTR* ppString, DWORD* pdwUnicode, int nBufferSize, int* pnUsage)
{
	LPCTSTR	ptr			= *ppString ;
	DWORD*	pdwCode		= pdwUnicode ;
	DWORD*	pdwCodeEnd	= pdwUnicode + nBufferSize ;
	BOOL	bRetval		= TRUE ;
	BYTE	bufUnicode [32] ;
	int		nUnicodeLen ;

	ptr	++ ;
	do {
		ptr	++ ;	// skip '+'
		if (pdwCode >= pdwCodeEnd) {
			bRetval	= FALSE ;
			break ;
		}
		nUnicodeLen	= ARRAYSIZE (bufUnicode) ;
		if (! bParseNumber (&ptr, bufUnicode, &nUnicodeLen)) {
			bRetval	= FALSE ;
			break ;
		}
		if (! bMakeCode (pdwCode, bufUnicode, nUnicodeLen)) {
			bRetval	= FALSE ;
			break ;
		}
		pdwCode	++ ;
	}	while (*ptr == TEXT ('+')) ;

	*ppString	= ptr ;
	*pnUsage	= pdwCode - pdwUnicode ;
	return	bRetval ;
}

BOOL
bParseWindowOrFullwidthCode (LPCTSTR* ppString, DWORD* pdwUnicode, int nBufferSize, int* pnUsage)
{
	LPCTSTR	ptr		= *ppString ;
	BOOL	bRetval	= FALSE ;

	while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0')) {
		if (s_bWindows && ! _tcsncmp (ptr, TEXT ("Windows: U+"), 11)) {
			ptr	+= 9 ;
			if (bParseUnicode (&ptr, pdwUnicode, nBufferSize, pnUsage)) {
				bRetval	= TRUE ;
				break ;
			}
		}
		if (s_bFullwidth && ! _tcsncmp (ptr, TEXT ("Fullwidth: U+"), 13)) {
			ptr	+= 11 ;
			if (bParseUnicode (&ptr, pdwUnicode, nBufferSize, pnUsage)) {
				bRetval	= TRUE ;
				break ;
			}
		}
		ptr	++ ;
	}
	*ppString	= ptr ;
	return	bRetval ;
}

#define	BLOCKSIZE	512

static	void
vConvertLabel (
	TCHAR*		pDest,
	int			nDestSize,
	LPCTSTR		pSrc)
{
	LPCTSTR	pDestEnd	= pDest + nDestSize ;

	while (pDest < pDestEnd && *pSrc != TEXT ('\0')) {
		int	ch	= *pSrc ++ ;
		if ((TEXT('0') <= ch && ch <= TEXT('9')) ||
			(TEXT('a') <= ch && ch <= TEXT('z')) ||
			(TEXT('A') <= ch && ch <= TEXT('Z')) ||
			ch == TEXT('_')) {
		} else {
			ch	= TEXT ('_') ;
		}
		*pDest ++	= ch ;
	}
	if (pDest < pDestEnd)
		*pDest	= TEXT('\0') ;
}

static	int	iCountBit (unsigned int n)
{
	int	bits	= 0 ;
	while (n > 1) {
		n	= n >> 1 ;
		bits	++ ;
	}
	return	bits ;
}

/*	�t�ϊ��e�[�u�����o�͂���B
 */
static	void
vDumpTable (void)
{
	int	i ;
	BYTE	bEmpty [BLOCKSIZE] = { 0 } ;

	_tprintf (TEXT ("#define ______________ 0\n")) ;
	_tprintf (TEXT ("#define INVERSE_TABLE_SIZE_NBIT\t%d\n"), iCountBit (BLOCKSIZE)) ;
	_tprintf (TEXT ("#define	INVERSE_TABLE_SIZE		(1 << INVERSE_TABLE_SIZE_NBIT)\n")) ;
	_tprintf (TEXT ("#define	INVERSE_TABLE_SIZE_MASK	(INVERSE_TABLE_SIZE - 1)\n")) ;

/*
#define	INVERSE_TABLE_SIZE_NBIT	(9)
#define	INVERSE_TABLE_SIZE		(1 << INVERSE_TABLE_SIZE_NBIT)
#define	INVERSE_TABLE_SIZE_MASK	(INVERSE_TABLE_SIZE - 1) */
	{
		struct MyLabelNode*	pNode ;

		pNode	= s_plstLabel ;
		while (pNode != NULL) {
			TCHAR	buf [512] ;
			vConvertLabel (buf, ARRAYSIZE(buf)-1, pNode->m_bufLabel) ;
			buf [ARRAYSIZE(buf)-1]	= TEXT ('\0') ;
			_tprintf (TEXT ("#define C%02d %s\n"), pNode->m_iNumber, buf) ;
			pNode	= pNode->m_pNext ;
		}
	}
	_tprintf (TEXT ("\n")) ;

	for(i = 0 ; i < 16 ; i ++) {
		int	count, j, k ;
		if (s_rpUnicodeTables [i] == NULL)
			continue ;

		count	= 0 ;
		for (j = 0 ; j < 0x10000 / BLOCKSIZE; j ++) {
			for (k = 0 ; k < BLOCKSIZE ; k ++) {
				if (s_rpUnicodeTables [i][j * BLOCKSIZE + k] != 0)
					break ;
			}
			if (k >= BLOCKSIZE) {
				bEmpty [j]	= TRUE ;
			} else {
				bEmpty [j]	= FALSE ;
			}
		}
		for (j = 0 ; j < 0x10000 / BLOCKSIZE ; j ++) {
			if (bEmpty [j])
				continue ;
			_tprintf (TEXT ("static const DWORD table%02d_%04X [INVERSE_TABLE_SIZE] = {\n"), i, j) ;
			count	= j * BLOCKSIZE ;
			for (k = 0 ; k < BLOCKSIZE/8 ; k ++) {
				int	l ;
				_tprintf (TEXT ("\t")) ;
				for (l = 0 ; l < 8 ; l ++) {
					DWORD	dw	= s_rpUnicodeTables [i][count ++] ;
					if (dw != 0) {
						_tprintf (TEXT ("C%02d | 0x%06X, "), (dw >> 24), dw & 0x00FFFFFFUL) ;
					} else {
//						_tprintf (TEXT ("0x%08X,     "), 0) ;
						_tprintf (TEXT ("______________, "), 0) ;
					}
				}
				if ((k & 15) == 0)
					_tprintf (TEXT ("\t// 0x%04X"), j * 8) ;
				_tprintf (TEXT ("\n")) ;
			}
			_tprintf (TEXT ("};\n\n")) ;
		}
		_tprintf (TEXT ("static const DWORD* table_table%02d [] = {\n"), i) ;
		for (j = 0 ; j < 0x10000 / BLOCKSIZE; j ++) {
			for (k = 0 ; k < BLOCKSIZE ; k ++) {
				if (s_rpUnicodeTables [i][j * BLOCKSIZE + k] != 0)
					break ;
			}
			if (k >= BLOCKSIZE) {
				_tprintf (TEXT ("\tNULL, \n")) ;
			} else {
				_tprintf (TEXT ("\ttable%02d_%04X, \n"), i, j) ;
			}
		}
		_tprintf (TEXT ("} ;\n\n")) ;

	}

	{
		struct MyNode*	pNode ;

		_tprintf (TEXT ("static const DWORD multi_table [][9] = {\n"), i) ;
		pNode	= s_plst ;
		while (pNode != NULL) {
			DWORD	dw ;
			int		j ;

			_tprintf (TEXT ("\t{ ")) ;
			for (j = 0 ; j < 8 ; j ++) {
				_tprintf (TEXT ("0x%08X, "), pNode->m_rdwUnicode [j]) ;
			}
			dw	= pNode->m_dwCode ;
			_tprintf (TEXT ("C%02d | 0x%06X, "), (dw >> 24), dw & 0x00FFFFFFUL) ;
	//		_tprintf (TEXT ("0x%08X, "), pNode->m_dwCode) ;
			_tprintf (TEXT ("},\n")) ;
			pNode	= pNode->m_pNext ;
		}
		_tprintf (TEXT ("} ;\n")) ;
	}
	return ;
}

#if 0
static	void
vDumpTable (void)
{
	struct MyNode*	pNode ;

	pNode	= s_plst ;
	while (pNode != NULL) {
		int	count	= 0 ;
		int	i, j ;

		_tprintf (TEXT ("// 0x%02X\n"), pNode->m_dwLeading) ;
		_tprintf (TEXT ("DWORD\ttable%02X [] = {\n"), pNode->m_dwLeading) ;
		for (i = 0 ; i < 0x10000/8 ; i ++) {
			_tprintf (TEXT ("\t")) ;
			for (j = 0 ; j < 8 ; j ++) {
				_tprintf (TEXT ("0x%08X, "), pNode->m_pdwTable [count ++]) ;
			}
			if ((i & 15) == 0) {
				_tprintf (TEXT ("\t// 0x%0X"), i * 8) ;
			}
			_tprintf (TEXT ("\n")) ;
		}
		_tprintf (TEXT ("};\n\n")) ;
		pNode	= pNode->m_pNext ;
	}

	if (s_pdwBuffer != NULL && s_dwBufferUsage > 0) {
		DWORD	dw= 0 ;

		_tprintf (TEXT ("// Special Table\n")) ;
		_tprintf (TEXT ("DWORD\tspecial_table [] = {\n")) ;
		for (dw = 0 ; dw < s_dwBufferUsage ; dw ++) {
			if ((dw & 7) == 0)
				_tprintf (TEXT ("\t")) ;
			_tprintf (TEXT ("0x%08X, "), s_pdwBuffer [dw]) ;
			if ((dw & 7) == 7 && dw != 0) {
				_tprintf (TEXT ("\n")) ;
			}
		}
		if ((dw & 7) != 0)
			_tprintf (TEXT ("\n")) ;
		_tprintf (TEXT ("} ;\n")) ;
	}
	return ;
}
#endif





