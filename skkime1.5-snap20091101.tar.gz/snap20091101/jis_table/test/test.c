#include "local.h"
#include <assert.h>
#include "kstring.h"
#include "Char.h"

int
_tmain (void)
{
	Char	buf [32] ;
	DWORD	dwUpper, dwLower ;
	WCHAR	wbuf [32] ;

	for (dwUpper = 0x21 ; dwUpper <= 0x7E ; dwUpper ++) {
		for (dwLower = 0x21 ; dwLower <= 0x7E ; dwLower ++) {
			DWORD	dwCode ;
			int		nWLen, n ;

			dwCode	= (dwUpper << 8) | dwLower ;
			buf [0]	= Char_Make (KCHARSET_JISX0213_2004_PLANE1, dwCode) ;
			buf [1]	= 0 ;

			nWLen		= internal2wstr (wbuf, ARRAYSIZE(wbuf), buf, 1) ;
			if (nWLen <= 0) {
				_ftprintf (stderr, TEXT ("Error: cannot convert jisx0213-2004-plane1: %0X\n"), dwCode) ;
			} else {
				Char	buf2 [32] ;

				n	= wstr2internal (buf2, ARRAYSIZE(buf2), wbuf, nWLen) ;
				if (n <= 0) {
					_ftprintf (stderr, TEXT ("Error: \n")) ;
				} else {
					int	i ;

					if (n != 1 || buf [0] != buf2 [0]) {
						_ftprintf (stderr, TEXT ("Error: 0x%0X -> "), buf [0] & 0xFFFF) ;
						for (i = 0 ; i < nWLen ; i ++) {
							_ftprintf (stderr, TEXT("%04X "), wbuf [i]) ;
						}
						_ftprintf (stderr, TEXT ("-> 0x%0X\n"), buf2 [0] & 0xFFFF) ;
					}
				}
			}
		}
	}
	return	0 ;
}

