#pragma once

#include "Char.h"

#define	SURROGATE_PAIR_TO_U32(dwHigh,dwLow)	(((((DWORD)(dwHigh) - 0xD800UL) << 10) | ((DWORD)(dwLow) - 0xDC00UL)) + 0x10000UL)
#define	GET_HIGHSURROGATE_FROM_U32(dwD)		((WCHAR)(0xD800 + ((((dwD) - 0x10000UL) >> 10) & 0x3FF)))
#define	GET_LOWSURROGATE_FROM_U32(dwD)		((WCHAR)(0xDC00 + (((dwD) - 0x10000UL) & 0x3FF)))

#ifndef IS_HIGH_SURROGATE
#define	IS_HIGH_SURROGATE(n1)		(0xD800 <= (n1) && (n1) < 0xDC00)
#endif
#ifndef IS_LOW_SURROGATE
#define	IS_LOW_SURROGATE(n2)		(0xDC00 <= (n2) && (n2) < 0xE000)
#endif
#ifndef IS_SURROGATE_PAIR
#define	IS_SURROGATE_PAIR(n1,n2)	(IS_HIGH_SURROGATE((n1)) && IS_LOW_SURROGATE((n2)))
#endif
#if !defined (WINVER) || WINVER < 0x0600
typedef enum _NORM_FORM {
    NormalizationOther  = 0,
    NormalizationC      = 0x1,
    NormalizationD      = 0x2,
    NormalizationKC     = 0x5,
	NormalizationKD     = 0x6,
} NORM_FORM;
#endif

#if defined (__cplusplus)
extern "C" {
#endif
int		wstr2internal	(Char*, int, LPCWSTR, int) ;
int		internal2wstr	(LPWSTR, int, const Char*, int) ;
BOOL	internalStringContainsUnicodeCharp (const Char*, int) ;
int		iLookupUnicodeInverseMap(DWORD*, int, Char**, const Char*, BOOL) ;
#if defined (__cplusplus)
}
#endif

