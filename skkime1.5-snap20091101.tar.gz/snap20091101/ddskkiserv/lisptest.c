#include "local.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <shlwapi.h>
#include <shlobj.h>
#include "kstring.h"
#include "lisp\lispmgr.h"
#include "lisp\lmachine.h"
#undef	DEBUGPRINTF
#define	DEBUGPRINTF(x)	_tprintf##x

#define	DEBUGFILENAME	TEXT("lisptest.log")


static	BOOL	lisp_eval	(LPCWSTR) ;
static	BOOL	lisp_loadinifile (TLispMachine*, TLispManager*) ;

static	TLispManager*		spSkkiservLispMgr		= NULL ;
static	TLispMachine*		spSkkiservLispMachine	= NULL ;

int
_tmain (int nArgc, TCHAR* rpArgv [])
{
	TCHAR				szBuffer [256] ;
	register int		nwKey ;

	_tsetlocale (LC_ALL, TEXT ("")) ;

	if (TFAILED (TLispMgr_Create (&spSkkiservLispMgr)) ||
		TFAILED (TLispMachine_Create (spSkkiservLispMgr, NULL, &spSkkiservLispMachine))) {
		DEBUGPRINTF ((TEXT ("lisp initialize failed\n"))) ;
		return	EXIT_FAILURE ;
	}
	lisp_loadinifile (spSkkiservLispMachine, spSkkiservLispMgr) ;

	while (! feof (stdin)) {
		_tprintf (TEXT ("> ")) ;
		fflush (stdout) ;
		if (_fgetts (szBuffer, ARRAYSIZE (szBuffer), stdin) == NULL)
			break ;
		nwKey	= lstrlen (szBuffer) ;
		while (nwKey > 0 &&
			   (szBuffer [nwKey - 1] == TEXT ('\n') ||
				szBuffer [nwKey - 1] == TEXT ('\r')))
			nwKey	-- ;
		if (nwKey <= 0)
			continue ;
		lisp_eval (szBuffer) ;
	}
	return	EXIT_SUCCESS ;
}

BOOL
lisp_eval (
	LPCWSTR		pwWord)
{
	Char			rCWord [512] ;
	TVarbuffer		vbuf ;
	TCHAR			szBuffer [256] ;
	int				nChar, nwWord, nCWord, n ;
	const Char*		pChar ;
	TLispEntity*	pEntTarget ;
	TLispEntity*	pEntResult	= NULL ;

	/*	�����̌����B*/
	nwWord	= lstrlen (pwWord) ;
	nCWord	= wstr2internal (rCWord, ARRAYSIZE (rCWord), pwWord, nwWord) ;
	if (nCWord >= ARRAYSIZE (rCWord)) {
		DEBUGPRINTF ((TEXT ("Too long input word: \"%s\"\n"), pwWord)) ;
		return	FALSE ;
	}
	if (nCWord < 0) {
		DEBUGPRINTF ((TEXT ("Convert failed.\n"), pwWord)) ;
		return	FALSE ;
	}

	if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (Char)))) 
		return	FALSE ;

	pEntTarget	= lispMgr_ParseString (spSkkiservLispMgr, rCWord, nCWord, NULL) ;
	if (TFAILED (TLispMachine_TestEx (spSkkiservLispMachine, pEntTarget, &pEntResult))) {
		DEBUGPRINTF ((TEXT ("lisp_test failed\n"))) ;
		goto	exit_func ;
	}
	if (! lispEntity_PrincStr (spSkkiservLispMgr, pEntResult, &vbuf))
		goto	exit_func ;

	/*	�ŏ��Ƀ��v���C�̃g�[�^���T�C�Y�����߂Ȃ���΁BUNICODE
	 *	���Ƌ��߂�̂͊y�B�P�ʂ̓o�C�g�ŁB
	 */
	pChar	= TVarbuffer_GetBuffer (&vbuf) ;
	nChar	= TVarbuffer_GetUsage  (&vbuf) ;
	n			= internal2wstr (szBuffer, ARRAYSIZE (szBuffer), pChar, nChar) ;
	if (n >= ARRAYSIZE (szBuffer)) {
		_tprintf (TEXT ("Result is long(%d/%d) ... \n"), n, nChar) ;
		szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
	} else {
		szBuffer [n]	= TEXT ('\0') ;
	}
	_tprintf (TEXT ("200 OK \"%s\"\n"), szBuffer) ;
 exit_func:
	TVarbuffer_Uninitialize (&vbuf) ;
	return	TRUE ;
}

#define	REGPATH_SKKIME			L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5"
#define	REGPATH_GENERIC			REGPATH_SKKIME L"\\Generic"
#define	REGINFO_INIFILE			L"SkkiservIniFile"

BOOL
lisp_loadinifile (
	TLispMachine*		pLispMachine,
	TLispManager*		pLispMgr)
{
	WCHAR			bufIniPath [MAX_PATH+1] ;
	HKEY			hSubKey ;
	int				nLength ;
	BOOL			bRetval		= FALSE ;

	bufIniPath [0]	= L'\0' ;
	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	cbData, dwType ;
		LONG	lResult ;

		cbData	= sizeof (bufIniPath) - sizeof (WCHAR) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_INIFILE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_SZ) {
			(void) RegQueryValueExW (hSubKey, REGINFO_INIFILE, NULL, &dwType, (LPBYTE)bufIniPath, &cbData) ;
			bufIniPath [MAX_PATH]	= L'\0' ;
		}
		RegCloseKey (hSubKey) ;
	}
	/*	Default �� Application Data �̉��� init.el ��u���A�Ƃ������Ƃɂ���B
	 */
	if (bufIniPath [0] == L'\0') {
		WCHAR	bufPath [MAX_PATH + 1] ;

		if (FAILED (SHGetFolderPathW (NULL, CSIDL_APPDATA, NULL, SHGFP_TYPE_CURRENT, bufPath)))
			return	FALSE ;
		bufPath [MAX_PATH]	= TEXT ('\0') ;
		nLength	= wnsprintfW (bufIniPath, ARRAYSIZE (bufIniPath) - 1, TEXT ("%s\\skk\\skki1_5\\init.el"), bufPath) ;
		bufIniPath [nLength]	= L'\0' ;
	}
	/*	(load-file "init.el") �� LispMachine �Ɏ��s������B
	 *	���̂��߂ɁAstring ������R�[�h�ɕϊ�������Alist �ɕϊ�����B
	 */
	{
		TLispEntity*	pEntRetval	= NULL ;
		Char	rCWord [512] ;
		int		nCWord ;

		nCWord	= wstr2internal (rCWord, ARRAYSIZE (rCWord), bufIniPath, nLength) ;
		if (nCWord <= 0)
			return	FALSE ;
		/*	LispMachine �Ɏ��s������B
		 */
		bRetval	= TLispMachine_LoadFile (pLispMachine, rCWord, nCWord) ;
	}
	return	bRetval ;
}

void
DebugPrintf (
	LPCTSTR	ptszFormat,
	...)
{
	TCHAR	szBuffer [2048] ;
	va_list	vl ;
	
	va_start (vl, ptszFormat) ;
#if defined (_MSC_VER) && (_MSC_VER >= 1400) && !defined (WIN64)
	_vsntprintf_s (szBuffer, ARRAYSIZE (szBuffer) - 1, _TRUNCATE, ptszFormat, vl) ;
#else
	_vsntprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, ptszFormat, vl) ;
#endif
	va_end (vl) ;
	szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
	_tprintf (TEXT ("%s"), szBuffer) ;
	return ;
}

void	PASCAL
DebugPrintfToFile (
	LPCTSTR	ptszFormat,
	...)
{
	TCHAR	szBuffer [2048] ;
	va_list	vl ;
	HANDLE	hFile		= INVALID_HANDLE_VALUE ;
	DWORD	dwWritten	= 0, dwFileName = 0 ;
	TCHAR	szPath [MAX_PATH + 1] ;
	int		n ;
	
	/*	�f�o�b�O���O�̏o�̓p�X��ݒ肷��B*/
	dwFileName	= GetTempPath (MAX_PATH, szBuffer) ;
	if (dwFileName <= 0 || dwFileName >= MAX_PATH)
		return ;
	szBuffer [dwFileName]	= TEXT ('\0') ;
	n	= wnsprintf (szPath, MAX_PATH, TEXT ("%s%s"), szBuffer, DEBUGFILENAME) ;
	if (n < 0 || n >= MAX_PATH)
		return ;
	szPath [n]	= TEXT ('\0') ;

	/*	�o�͂��钆�g��ݒ肷��B*/
	va_start (vl, ptszFormat) ;
	n	= wvnsprintf (szBuffer, ARRAYSIZE (szBuffer), ptszFormat, vl) ;
	va_end (vl) ;
	if (n < 0)
		return ;

	/*	�t�@�C�����쐬����B*/
	hFile	= CreateFile (szPath, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL) ;
	if (hFile == INVALID_HANDLE_VALUE)
		return ;
	/*	�t�@�C���Ƀf�[�^��ǉ�����B*/
	/*	�G���[���������Ă����ɉ����ł��Ȃ��̂ŁA���̂܂ܗ����B*/
	SetFilePointer (hFile, 0, NULL, FILE_END) ;
	WriteFile (hFile, szBuffer, n * sizeof (TCHAR), &dwWritten, NULL) ;
	CloseHandle (hFile) ;
	return ;
}

int
ConvertCStrToTStr (
	register const Char*	pCstr,
	register int			nCstr,
	register LPTSTR			wpDest,
	register int			nwDest)
{
	char				buf [32] ;
	KANJISTATEMACHINE	ksm ;
	register int		nbuf, nconv, nUsage ;

	InitializeKanjiFiniteStateMachine (&ksm, KCODING_SYSTEM_SHIFTJIS) ;
	nUsage	= 0 ;
	while (nwDest > 0 && nCstr > 0) {
		nbuf	= RtransferKanjiFiniteStateMachine (&ksm, *pCstr, buf) ;
		if (nbuf > 0) {
#if defined (UNICODE) || defined (_UNICODE)
			nconv	= MultiByteToWideChar (932, MB_ERR_INVALID_CHARS | MB_PRECOMPOSED, buf, nbuf, wpDest, nwDest) ;
			if (nconv <= 0)
				return	-1 ;
#else
			/*	���ꂾ�� ShiftJis �̓r���ŏI���\��������
			 *	�̂����B*/
			nconv	= (nbuf > nwDest)? nwDest : nbuf ;
			memcpy (wpDest, buf, sizeof (TCHAR) * nconv) ;
#endif
			wpDest	+= nconv ;
			nwDest	-= nconv ;
			nUsage	+= nconv ;
		}
		pCstr	++ ;
		nCstr	-- ;
	}
	return	nUsage ;
}



