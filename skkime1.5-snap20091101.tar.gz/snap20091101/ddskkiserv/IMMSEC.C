#include "stdafx.h"
#include "ddskkiserv.h"
#include <sddl.h>
#include "immsec.h"

#define MEMALLOC(x)      LocalAlloc(LMEM_FIXED, x)
#define MEMFREE(x)       LocalFree(x)

static	POSVERSIONINFO GetVersionInfo(void) ;

/*	WindowsVista �ł� LowSecurityMode �� CreatePipe ����K�v������B
 *	�������Ȃ���΁AProtect Mode �œ��삵�Ă��� IE ���� Pipe �ɐڑ��ł��Ȃ��B
 *	(LowIntegrityMode �̃`�F�b�N�� Access ���̃`�F�b�N����ɍs���āA������
 *	���s����� E_ACCESSDENIED �ɂȂ��Ă��܂��B���Ƃ��������t�^����Ă����Ƃ��Ă�)
 */
PSECURITY_ATTRIBUTES CreateSecurityAttributes(void)
{
#if WINVER >= 0x0600
	/*	���̏����� Vista �ł̂ݗL���B
	 */
#define LOW_INTEGRITY_SDDL_SACL_W L"S:(ML;;NW;;;LW)"
	// The LABEL_SECURITY_INFORMATION SDDL SACL to be set for low integrity 
	PSECURITY_DESCRIPTOR	pSD		= NULL ;
	PSECURITY_ATTRIBUTES	psa		= NULL ;

	if (ConvertStringSecurityDescriptorToSecurityDescriptorW (LOW_INTEGRITY_SDDL_SACL_W, SDDL_REVISION_1, &pSD, NULL)) {
		psa = (PSECURITY_ATTRIBUTES)MEMALLOC (sizeof (SECURITY_ATTRIBUTES)) ;
		if  (psa == NULL)  
			return NULL ;

		psa->nLength				= sizeof (SECURITY_ATTRIBUTES) ;
		psa->lpSecurityDescriptor	= (PVOID)pSD ;
		psa->bInheritHandle			= TRUE ;
	} else {
		psa	= NULL ;
	}
    return	psa ;
#else
	return	NULL ;
#endif
}

VOID FreeSecurityAttributes (PSECURITY_ATTRIBUTES psa) 
{
    BOOL fResult;
    BOOL fDaclPresent;
    BOOL fDaclDefaulted;
    PACL pacl;

    if (psa == NULL)
        return;

    fResult = GetSecurityDescriptorDacl (psa->lpSecurityDescriptor, &fDaclPresent, &pacl, &fDaclDefaulted) ;
    if  (fResult)  {
        if  (pacl != NULL) 
            MEMFREE (pacl) ;
    }
    MEMFREE (psa->lpSecurityDescriptor) ;
    MEMFREE (psa) ;
	return ;
}

//
// IsNT()
//
// Return value:
//
//      TRUE if the current system is Windows NT
//
// Remarks:
//
//      The implementation of this function is not multi-thread safe.
//      You need to modify the function if you call the function in 
//      multi-thread environment.
//
BOOL IsNT(void)
{
    return GetVersionInfo()->dwPlatformId == VER_PLATFORM_WIN32_NT;
}

POSVERSIONINFO GetVersionInfo(void)
{
    static BOOL fFirstCall = TRUE;
    static OSVERSIONINFO os;

    if  (fFirstCall)  {
        os.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
        if  (GetVersionEx (&os) ) {
            fFirstCall = FALSE;
        }
    }
    return &os;
}

