#pragma once

#if !defined (windows_h)
#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <tchar.h>
#include <limits.h>
#include <locale.h>
#include <lmcons.h>
#define	windows_h
#endif
#include "debug.h"

#if !defined (MALLOC)
#define	MALLOC(x)			malloc((x))
#endif
#if !defined (FREE)
#define	FREE(x)				free((x))
#endif
#if !defined (TFAILED)
#define	TFAILED(x)			(!(x))
#endif
#if !defined (TSUCCEEDED)
#define	TSUCCEEDED(x)		((x))
#endif
#if !defined (ARRAYSIZE)
#define	ARRAYSIZE(array)	(sizeof array / sizeof array[0])
#endif

#if !defined (PATH_MAX)
#define	PATH_MAX			MAX_PATH
#endif

