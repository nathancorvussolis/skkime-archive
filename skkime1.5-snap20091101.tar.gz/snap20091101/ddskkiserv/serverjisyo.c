#include "local.h"
#include <stdio.h>
#include <sys/types.h>
#include "jisyo.h"
#include "serverjisyo.h"
#include "genericjisyo.h"
#include "sortedjisyo.h"
#include "cstring.h"
#include "kanji.h"

#pragma warning( disable : 4244 4310 )
/*
 *	Definitions
 */
#define	SKKSERV_BYE			(0)
#define	SKKSERV_SEARCH		(1)
#define	SKKSERV_VERSION		(2)
#define	SKKSERV_HOSTNAME	(3)

#define	SKKSERV_BUFSIZE		(512)
#define	MAX_SKKSERVERS		(4)

#define	EOL					(0x0A)

#define	SKKSERV_TIMEOUT			(5000)	/* 1�b�܂Ŏ����� connect ��҂B*/
#define	MAX_SOCKS				(5)		/* 5�܂œ����T���B*/
#define	SKKSERV_DEFAULT_PORTNUM	(1178)

#if !defined (SD_BOTH)
#define SD_RECEIVE      0x00
#define SD_SEND         0x01
#define SD_BOTH         0x02
#endif

struct tagSkkServerHost {
	SOCKET						m_hSocket ;
	char						m_szHost [MAX_HOSTNAME] ;
	int							m_nPort ;
	struct sockaddr_in			m_Address ;
	struct tagSkkServerHost*	m_pPrev ;
	struct tagSkkServerHost*	m_pNext ;
} ;

/*	prototypes */
static	BOOL			skkServerJisyo_search				(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
static	BOOL			skkServerJisyo_searchWithoutConnection(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
static	BOOL			skkServerJisyo_destroy				(SkkJisyo*) ;

static	SkkServerHost*	skkServerJisyo_parsePortAndHost		(LPCTSTR, int) ;
static	SkkServerHost*	skkServerJisyo_newPortAndHostNode	(LPCTSTR, int, int) ;
static	void			skkServerJisyo_destroyHostList		(SkkServerHost*, SkkServerHost*) ;
static	void			skkServerJisyo_destroyHost			(SkkServerHost*) ;
static	BOOL			skkServerJisyo_connectionEstablishedp(SkkServerHost*) ;
static	BOOL			skkServerJisyo_searchAux			(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
static	BOOL			skkServerJisyo_sendmsg				(SOCKET, const Char*, int, BOOL, TVarbuffer*) ;
static	BOOL			skkServerJisyo_sendCommand			(SOCKET, int, const Char*, int) ;
static	int				skkServerJisyo_extractResult		(const char*, int, TVarbuffer*) ;
static	BOOL			skkServerJisyo_getResult			(SOCKET, TVarbuffer*) ;
static	void			skkServerJisyo_clearResult			(SOCKET) ;

/*	global variables */
/*	VTBL */
static SkkJisyoFunc		sServerJisyoProcTbl	= {
	skkServerJisyo_search,
	NULL,
	NULL,
	NULL,
	NULL,
	skkServerJisyo_destroy,
	NULL,
} ;

/*========================================================================
 *	public functions
 */
SkkJisyo*
SkkServerJisyo_Create (
	register LPCTSTR		strHostPort)
{
	register SkkJisyo*			pSkkJisyo ;
	register SkkServerJisyo*	pJisyo ;
	register SkkServerHost*		plstHost ;
	register SkkServerHost*		pNode ;
	register LPCTSTR	pAuxPath		= NULL ;
	register LPCTSTR	pStart ;
	register LPCTSTR	ptr ;
	register BOOL		fEnableAuxJisyo	= FALSE ;
	register BOOL		fSortedAuxJisyo	= FALSE ;

	plstHost	= NULL ;
	pStart		= strHostPort ;
	while (*pStart != TEXT ('\0')) {
		ptr		= pStart ;
		while (*ptr != TEXT ('\0') && *ptr != TEXT (',')) 
			ptr	++ ;

		/*	�⏕�����̐ݒ肪���t�������ꍇ�A����ɑ����T�[�o��
		 *	�ݒ�͑��݂��Ȃ��B*/
		if (! _tcsncmp (pStart, TEXT ("aux:"), 4)) {
			pStart		+= 4 ;
			if (*pStart == TEXT('s') || *pStart == TEXT('f')) {
				fSortedAuxJisyo	= (*pStart == TEXT('s'))? TRUE : FALSE ;
				pStart	++ ;
			}
			if (*pStart == TEXT('e') || *pStart == TEXT('d')) {
				fEnableAuxJisyo	= (*pStart == TEXT ('e'))? TRUE : FALSE ;
				pStart	++ ;
			}
			/*	���̏ꍇ�ɂ̓G���[�B����̓V�r�A�B*/
			if (*pStart == TEXT('=')) {
				pAuxPath	= pStart + 1 ;
			} else {
				pAuxPath	= NULL ;
			}
			break ;
		}
		/*	port/host �̃T�[�o�̐ݒ�𔲂��o���B*/
		pNode	= skkServerJisyo_parsePortAndHost (pStart, ptr - pStart) ;
		if (pNode != NULL) {
			pNode->m_pNext	= plstHost ;
			if (plstHost != NULL)
				plstHost->m_pPrev	= pNode ;
			plstHost	= pNode ;
		}
		if (*ptr == TEXT ('\0'))
			break ;
		pStart	= ptr + 1 ;
	}
	/*	�����Ƃ��ċ@�\���Ȃ��Ȃ�Anode �͍��Ȃ��B*/
	if (plstHost == NULL && (pAuxPath == NULL || ! fEnableAuxJisyo)) {
#if defined (DEBUG)
		DEBUGPRINTF ((TEXT ("No jisyo setting\n"))) ;
#endif
		return	NULL ;
	}

	pSkkJisyo	= MALLOC (sizeof (SkkJisyo) + sizeof (SkkServerJisyo)) ;
	if (pSkkJisyo == NULL) {
		skkServerJisyo_destroyHostList (plstHost, NULL) ;
		return	NULL ;
	}
	pSkkJisyo->m_pVtbl	= &sServerJisyoProcTbl ;
	pJisyo				= (SkkServerJisyo *)(pSkkJisyo + 1) ;
	pJisyo->m_lstHost	= plstHost ;
	if (fEnableAuxJisyo && pAuxPath != NULL) {
		lstrcpy (pJisyo->m_szAuxJisyo, pAuxPath) ;
	} else {
		pJisyo->m_szAuxJisyo [0]	= TEXT ('\0') ;
	}
	pJisyo->m_pAuxJisyo			= NULL ;
	pJisyo->m_fAuxJisyoSorted	= fSortedAuxJisyo ;
	return	pSkkJisyo ;
}

/*========================================================================
 *	private functions (VTBL)
 */
BOOL
skkServerJisyo_search	(
	SkkJisyo*		pSkkJisyo,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	TVarbuffer*		pvbuf)
{
	SkkServerJisyo*	pJisyo	= (SkkServerJisyo *)(pSkkJisyo + 1) ;

	DEBUGPRINTF ((TEXT ("skkServerJisyo_search (%p,%d)\n"), pSkkJisyo, nKey)) ;

	/*	���ɃT�[�o�����Ƃ��Ă̋@�\���ʂ����Ȃ��H */
	if (pJisyo->m_lstHost == NULL)
		return	skkServerJisyo_searchAux (pSkkJisyo, pKey, nKey, pOkurigana, nOkurigana, nOkuriType, pvbuf) ;

	if (skkServerJisyo_connectionEstablishedp (pJisyo->m_lstHost)) {
		register SOCKET	hSocket ;
		register BOOL	fRetval ;

		DEBUGPRINTF ((TEXT ("search -- using established connection)\n"))) ;
		hSocket	= pJisyo->m_lstHost->m_hSocket ;
		fRetval	= skkServerJisyo_sendmsg (hSocket, pKey, nKey, nOkuriType != SEARCH_OKURI_NASHI, pvbuf) ;
		if (fRetval)
			return	TRUE ;
		DEBUGPRINTF ((TEXT ("search -- established connection is broken)\n"))) ;
		shutdown (hSocket, SD_BOTH) ;
		closesocket (hSocket) ;
		pJisyo->m_lstHost->m_hSocket	= INVALID_SOCKET ;
	}
	return	skkServerJisyo_searchWithoutConnection (pSkkJisyo, pKey, nKey, pOkurigana, nOkurigana, nOkuriType, pvbuf) ;
}

BOOL
skkServerJisyo_searchWithoutConnection (
	SkkJisyo*		pSkkJisyo,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	TVarbuffer*		pvbuf)
{
	register SkkServerJisyo*	pJisyo	= (SkkServerJisyo *)(pSkkJisyo + 1) ;
	register SkkServerHost*		pHost ;
	register SkkServerHost*		pTop ;
	register SOCKET				hSocket ;
	register WSAEVENT			hEvent ;
	SOCKET						rhSocket [MAX_SOCKS] ;
	WSAEVENT					rhEvent  [MAX_SOCKS] ;
	register struct protoent*	pProto ;
	register BOOL				fRetval ;
	register BOOL				fError ;
	register int				i, n, nRetval ;
	register DWORD				dwRetval ;
	static struct linger		lingval	= { 0, 0, } ;

	DEBUGPRINTF ((TEXT ("skkServerJisyo_searchWithoutConn (%p,%d)\n"), pSkkJisyo, nKey)) ;

	/* Protocol �̐ݒ�B*/
	pProto		= getprotobyname ("tcp") ;
	if (pProto == NULL)
		return	FALSE ;

	for (i = 0 ; i < MAX_SOCKS ; i ++) {
		hEvent	= WSACreateEvent () ;
		if (hEvent == WSA_INVALID_EVENT) 
			return	FALSE ;
		rhEvent  [i]	= hEvent ;
		rhSocket [i]	= INVALID_SOCKET ;
	}

	pHost	= pJisyo->m_lstHost ;
	fRetval	= FALSE ;
	fError	= FALSE ;
	while (pHost != NULL) {
		pTop	= pHost ;
		n		= 0 ;
		while (n < MAX_SOCKS && pHost != NULL) {
			hEvent	= rhEvent  [n] ;
			hSocket	= socket (AF_INET, SOCK_STREAM, pProto->p_proto) ;
			if (hSocket == INVALID_SOCKET) {
				/*	socket �̍쐬�Ɏ��s�����Bfunction �𔲂���B*/
				fError	= TRUE ;
				goto	error_exit ;
			}
			nRetval	= WSAEventSelect (hSocket, hEvent, FD_CONNECT | FD_READ | FD_WRITE) ;
			if (nRetval == SOCKET_ERROR) {
				/*	event-select �Ɏ��s�Bfunction �𔲂���B*/
				fError	= TRUE ;
				goto	error_exit ;
			}
			/*	closesocket ���u���ɏI���悤�ɂ���B*/
			setsockopt (hSocket, SOL_SOCKET, SO_LINGER, (const char*)&lingval, sizeof (lingval)) ;

			rhSocket [n]	= hSocket ;

			nRetval	= connect (hSocket, (struct sockaddr*)&pHost->m_Address, sizeof (pHost->m_Address)) ;
			if (nRetval != 0 && WSAGetLastError () != WSAEWOULDBLOCK) {
				/*	connect �Ɏ��s������Asocket ���̂Ă�B*/
				WSAEventSelect (hSocket, hEvent, 0) ;
#if defined (DEBUG)
				if (closesocket (hSocket) == SOCKET_ERROR) 
					DEBUGPRINTF ((TEXT ("closesocket: failed(%d)\n"), WSAGetLastError ())) ;
#else
				closesocket (hSocket) ;
#endif
			} else {
				n	++ ;
			}
			pHost	= pHost->m_pNext ;
		}
		if (n > 0) {
			dwRetval = WSAWaitForMultipleEvents (n, rhEvent, FALSE, SKKSERV_TIMEOUT, FALSE) ;
#if defined (DEBUG)
			DEBUGPRINTF ((TEXT ("select(%lx), %d\n"), dwRetval, WSAGetLastError ())) ;
#endif
			if (WSA_WAIT_EVENT_0 <= dwRetval && dwRetval <= (WSA_WAIT_EVENT_0 + n)) {
				register SkkServerHost*		pNode ;
				register SkkServerHost*		pNextNode ;
				register int				nTarget ;

				nTarget	= dwRetval - WSA_WAIT_EVENT_0 ;
				DEBUGPRINTF ((TEXT ("found (%d)\n"), nTarget)) ;

				/*	���� socket �ɐڑ����ł����B*/
				hSocket	= rhSocket [nTarget] ;
				WSAEventSelect (hSocket, 0, 0) ;

				/*	������ fRetval �� FALSE �ł��������R�𒲂ׂāA�����ăT�[�o��
				 *	��������ׂ������`�F�b�N���Ȃ��Ƃ����Ȃ��̂����B
				 *	���� fRetval �� FALSE �ł��������R�������ɁA�����͐���������
				 *	�̂Ƃ��Ĉ����Ă���B
				 */
				fRetval	= skkServerJisyo_sendmsg (hSocket, pKey, nKey, nOkuriType != SEARCH_OKURI_NASHI, pvbuf) ;

				if (fRetval) {
					register int	i ;
					pNode		= pTop ;
					for (i = 0 ; i < nTarget && pNode != NULL ; i ++, pNode = pNode->m_pNext)
						;
					if (pNode != NULL) {
						/*	���t�������z�X�g�������̐擪�ւƈړ�������B*/
						if (pNode->m_pPrev != NULL) {
							register SkkServerHost*		pPrevNode	= pNode->m_pPrev ;

							pNextNode			= pNode->m_pNext ;
							pPrevNode->m_pNext	= pNextNode ;
							if (pNextNode != NULL)
								pNextNode->m_pPrev	= pPrevNode ;
							pNode->m_pPrev	= NULL ;
							pNode->m_pNext	= pJisyo->m_lstHost ;
							if (pJisyo->m_lstHost != NULL) 
								pJisyo->m_lstHost->m_pPrev	= pNode ;
							pJisyo->m_lstHost	= pNode ;
						}
						/*	connection ���L��������B*/
						DEBUGPRINTF ((TEXT ("register conn (%d)\n"), nTarget)) ;
						pNode->m_hSocket	= hSocket ;
						rhSocket [nTarget]	= INVALID_SOCKET ;
					}
					break ;
				}

				/*	���s�����G���g�����폜����B*/
				pNode		= pTop ;
				while (nTarget -- > 0 && pNode != NULL) 
					pNode		= pNode->m_pNext ;
				if (pNode != NULL) {
					pNextNode	= pNode->m_pNext ;
					if (pNode == pJisyo->m_lstHost)
						pJisyo->m_lstHost	= pNextNode ;
					if (pNode == pTop)
						pTop	= pNextNode ;
					skkServerJisyo_destroyHostList (pNode, pNextNode) ;
				}
			} else if (dwRetval == WSA_WAIT_TIMEOUT) {
				/*	pTop ���� pHost �܂ł��������B�ڑ��̌����݂Ȃ��B*/
#if defined (DEBUG)
				DEBUGPRINTF ((TEXT ("WSA_WAIT_TIMEOUT (%p, %p)\n"), pTop, pHost)) ;
#endif
				skkServerJisyo_destroyHostList (pTop, pHost) ;
				pJisyo->m_lstHost	= pHost ;
			} else {
#if defined (DEBUG)
				DEBUGPRINTF ((TEXT ("WSA_FAIL?\n"))) ;
#endif
				/*	�ǂ�������Ȃ����ǁA���s�����݂�����... */
				fError	= TRUE ;
				goto	error_exit ;
			}
		}

		/*	��n���̏����B*/
		for (i = 0 ; i < n ; i ++) {
			WSAEventSelect (rhSocket [i], rhEvent [i], 0) ;
			shutdown (rhSocket [i], SD_BOTH) ;
#if defined (DEBUG)
			if (closesocket (rhSocket [i]) == SOCKET_ERROR) 
				DEBUGPRINTF ((TEXT ("closesocket: failed(%d)\n"), WSAGetLastError ())) ;
#else
			closesocket (rhSocket [i]) ;
#endif
			rhSocket [i]	= INVALID_SOCKET ;
		}
		pTop	= pHost ;
	}

 error_exit:
	for (i = 0 ; i < MAX_SOCKS ; i ++) {
		if (rhSocket [i] != INVALID_SOCKET) {
			WSAEventSelect (rhSocket [i], 0, 0) ;
			shutdown (rhSocket [i], SD_BOTH) ;	
#if defined (DEBUG)
			if (closesocket (rhSocket [i]) == SOCKET_ERROR) 
				DEBUGPRINTF ((TEXT ("closesocket: failed(%d)\n"), WSAGetLastError ())) ;
#else
			closesocket (rhSocket [i]) ;
#endif
		}
		if (rhEvent [i] != WSA_INVALID_EVENT) {
			WSACloseEvent (rhEvent [i]) ;
		}
	}

	/*	�S�Ẵz�X�g�������ł������ꍇ�ɂ́A
	 *	�⏕�������猟�����邱�ƂɂȂ�B
	 */
	if (!fError && !fRetval && pJisyo->m_lstHost == NULL)
		return	skkServerJisyo_searchAux (pSkkJisyo, pKey, nKey, pOkurigana, nOkurigana, nOkuriType, pvbuf) ;

	return	fRetval ;
}

BOOL
skkServerJisyo_destroy (
	register SkkJisyo*		pSkkJisyo)
{
	register SkkServerJisyo*	pJisyo ;

	if (pSkkJisyo == NULL)
		return	TRUE ;

	pJisyo	= (SkkServerJisyo *)(pSkkJisyo + 1) ;
	if (pJisyo->m_pAuxJisyo != NULL) {
		SkkJisyo_Destroy (pJisyo->m_pAuxJisyo) ;
		pJisyo->m_pAuxJisyo	= NULL ;
	}
	if (pJisyo->m_lstHost != NULL) {
		skkServerJisyo_destroyHostList (pJisyo->m_lstHost, NULL) ;
		pJisyo->m_lstHost	= NULL ;
	}
	FREE (pSkkJisyo) ;
	return	TRUE ;
}

/*========================================================================
 *	private functions
 */
SkkServerHost*
skkServerJisyo_parsePortAndHost (
	register LPCTSTR		pstrPortAndHost,
	register int			nPortAndHost)
{
	register LPCTSTR	ptr		= pstrPortAndHost ;
	register int		nPort	= 0 ;
	register LPCTSTR	pHostname ;
	register int		nHostnameLen ;

	if (*ptr != TEXT ('/')) {
		while (nPortAndHost > 0 && *ptr != TEXT ('/')) {
			if (! (TEXT ('0') <= *ptr && *ptr <= TEXT ('9')))
				return	NULL ;
			nPort	= nPort * 10 + (*ptr - TEXT ('0')) ;
			ptr				++ ;
			nPortAndHost	-- ;
		}
		if (nPort < 0 || nPort >= 65536)
			return	NULL ;
	} else {
		nPort	= SKKSERV_DEFAULT_PORTNUM ;
	}
	if (nPortAndHost <= 0 || *ptr != TEXT ('/'))
		return	NULL ;

	/*	"/" ��ǂݔ�΂��B*/
	nPortAndHost	-- ;
	ptr				++ ;

	nHostnameLen	= nPortAndHost ;
	pHostname		= ptr ;
	if (nHostnameLen <= 0)
		return	NULL ;

	/*	�ȉ��A�S�āA�ƌ��������Ƃ��낾���Ahostname �Ƃ��ĕs�K�؂ȕ���
	 *	������Ύ̂Ă����Ă��炤�B�^�ʖڂȃp�[�Y�͂��Ȃ��B*/
	while (nPortAndHost > 0 &&
		   ((TEXT ('0') <= *ptr && *ptr <= TEXT ('9')) ||
			(TEXT ('a') <= *ptr && *ptr <= TEXT ('z')) ||
			(TEXT ('A') <= *ptr && *ptr <= TEXT ('Z')) ||
			*ptr == TEXT ('-') ||
			*ptr == TEXT ('.'))) {
		ptr				++ ;
		nPortAndHost	-- ;
	}
	if (nPortAndHost != 0)
		return	NULL ;
	
	return	skkServerJisyo_newPortAndHostNode (pHostname, nHostnameLen, nPort) ;
}

SkkServerHost*
skkServerJisyo_newPortAndHostNode (
	register LPCTSTR		strHost,
	register int			nHostLen,
	register int			nPort)
{
	register SkkServerHost*		pNode ;
	register struct hostent*	pHostent ;
	char						szHost [MAX_HOSTNAME] ;
#if defined (UNICODE)
	register int				n ;
#endif

#if defined (UNICODE)
#if defined (DEBUG)
	{
		TCHAR	szBuffer [256] ;
		memcpy (szBuffer, strHost, sizeof (TCHAR) * nHostLen) ;
		szBuffer [nHostLen]	= TEXT ('\0') ;
		DEBUGPRINTF ((TEXT ("Host: \"%s\"\n"), szBuffer)) ;
	}
#endif
	n	= WideCharToMultiByte (932, 0, strHost, nHostLen, NULL, 0, NULL, NULL) ;
	if (n >= MAX_HOSTNAME)
		return	NULL ;
	n	= WideCharToMultiByte (932, 0, strHost, nHostLen, szHost, MAX_HOSTNAME, NULL, NULL) ;
	szHost [n]	= '\0' ;
#else
	if (nHostLen >= MAX_HOSTNAME) {	/* �z�X�g�������߂���B*/
#if defined (DEBUG)
		DEBUGPRINTF ((TEXT ("fatal: too long host length(%d)\n"), nHostLen)) ;
#endif
		return	NULL ;
	}
	memcpy (szHost, strHost, nHostLen) ;
	szHost [nHostLen]	= '\0' ;
#endif
	pHostent	= gethostbyname (szHost) ;
	if (pHostent == NULL) {
#if defined (DEBUG)
		DEBUGPRINTF ((TEXT ("gethostbyname() failed (%d)\n"), WSAGetLastError ())) ;
#endif
		return	NULL ;
	}

	pNode	= MALLOC (sizeof (SkkServerHost)) ;
	if (pNode == NULL) {
#if defined (DEBUG)
		DEBUGPRINTF ((TEXT ("fatal: malloc failed\n"))) ;
#endif
		return	NULL ;
	}

	pNode->m_hSocket			= INVALID_SOCKET ;
	memset (&pNode->m_Address, 0, sizeof (struct sockaddr_in)) ;
	pNode->m_Address.sin_family	= AF_INET ;
	pNode->m_Address.sin_port	= htons ((u_short)nPort) ;
	memcpy (&(pNode->m_Address.sin_addr), pHostent->h_addr, pHostent->h_length) ;
	pNode->m_nPort				= nPort ;
	pNode->m_pPrev				= NULL ;
	pNode->m_pNext				= NULL ;
	return	pNode ;
}

void
skkServerJisyo_destroyHostList (
	register SkkServerHost*		plstHost,
	register SkkServerHost*		pLastNode)
{
	register SkkServerHost*		pNode ;
	register SkkServerHost*		pNextNode ;

#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("skkServerJisyo_destroyHostList -- enter(%p, %p)\n"), plstHost, pLastNode)) ;
#endif
	pNode	= plstHost ;
	while (pNode != NULL && pNode != pLastNode) {
		pNextNode	= pNode->m_pNext ;
		skkServerJisyo_destroyHost (pNode) ;
		pNode		= pNextNode ;
	}
#if defined (DEBUG)
	DEBUGPRINTF ((TEXT ("skkServerJisyo_destroyHostList -- leave\n"))) ;
#endif
	return ;
}

void
skkServerJisyo_destroyHost (
	register SkkServerHost*		pNode)
{
	if (pNode == NULL)
		return ;
	if (pNode->m_hSocket != INVALID_SOCKET) {
		shutdown (pNode->m_hSocket, SD_BOTH) ;
#if defined (DEBUG)
		if (closesocket (pNode->m_hSocket) == SOCKET_ERROR) 
			DEBUGPRINTF ((TEXT ("closesocket: failed(%d)\n"), WSAGetLastError ())) ;
#else
		closesocket (pNode->m_hSocket) ;
#endif
		pNode->m_hSocket	= INVALID_SOCKET ;
	}
	FREE (pNode) ;
	return ;
}

BOOL
skkServerJisyo_connectionEstablishedp (
	register SkkServerHost*		pNode)
{
	return	(pNode != NULL && pNode->m_hSocket != INVALID_SOCKET) ;
}

BOOL
skkServerJisyo_searchAux (
	SkkJisyo*		pSkkJisyo,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	TVarbuffer*		pvbuf)
{
	register SkkServerJisyo*	pJisyo	= (SkkServerJisyo *)(pSkkJisyo + 1) ;

	if (pJisyo->m_pAuxJisyo == NULL) {
		register LPCTSTR	pFilename ;
		register int		nFilename ;
		register SkkJisyo*	pAuxJisyo ;

		if (pJisyo->m_szAuxJisyo [0] == TEXT ('\0'))
			return	TRUE ;
		pFilename	= pJisyo->m_szAuxJisyo ;
		nFilename	= lstrlen (pJisyo->m_szAuxJisyo) ;
		if (pJisyo->m_fAuxJisyoSorted) {
			pAuxJisyo	= SkkSortedJisyo_CreateT (pFilename, KCODING_SYSTEM_UNKNOWN) ;
		} else {
			pAuxJisyo	= SkkGenericJisyo_CreateT (pFilename) ;
		}
		pJisyo->m_pAuxJisyo	= pAuxJisyo ;
		if (pAuxJisyo == NULL) {
			pJisyo->m_szAuxJisyo [0]	= TEXT ('\0') ;
			return	TRUE ;
		}
	}
	return	SkkJisyo_Search (pJisyo->m_pAuxJisyo, pKey, nKey, pOkurigana, nOkurigana, nOkuriType, pvbuf) ;
}

BOOL
skkServerJisyo_sendmsg (
	register SOCKET				hSocket,
	register const Char*		pKey,
	register int				nKey,
	register BOOL				fOkuri,
	register TVarbuffer*		pvbuf)
{
	char					szBuffer [SKKSERV_BUFSIZE] ;
	register int			nRecv ;
	register BOOL			fRetval	= FALSE ;
	unsigned long			ulZERO	= 0L ;
	register int			nfd ;
	fd_set					rfds ;
	static struct timeval	timeout	= { 0, 0, } ;

	/*	�O��� recv �ɂӂ�܂킳��邱�Ƃ�����H �m���ɑO��� recv
	 *	�ƌ��ʂ��邽�߂� select ��������B���ۂ� recv �܂ōs���K�v
	 *	�͂Ȃ��悤�����c�Bselect ���Ȃ��ƁA�ςɂȂ�B
	 *	(*)
	 *	���� select ���ʂ̏ꏊ�ɂ���o�O���B�����Ă��邾���A���|��
	 *	��̑㕨���c�Ƃ����\���͂���B�{���I�ɉ����������̂���
	 *	�����̕K�v�����邪�c��������|��ɂ���΂����̂��c�B
	 *
	 *	���Ȃ݂ɕs��̗�́A
	 *		���ق�Ă�(�ϊ�)->���ق�Ă�(�ϊ�)->���ق�ւ�(�ϊ�)
	 *	�Ƃ���ƁA�Ō�̕ϊ����Ɂu��{�_�v�� result �ɂȂ邱�ƁB
	 *	�Č��͂��������e�Ղł���B
	 */
	FD_ZERO (&rfds) ;
	FD_SET (hSocket, &rfds) ;
	nfd	= select (1, &rfds, NULL, NULL, &timeout) ;
	if (nfd > 0) {
		nRecv	= recv (hSocket, szBuffer, sizeof (szBuffer), 0) ;
		DEBUGPRINTF ((TEXT ("mu! recv? %d\n"), nRecv)) ;
	}

	/*	blocking socket �ɂ���B*/
#if defined (DEBUG)
	if (ioctlsocket (hSocket, FIONBIO, &ulZERO) != 0) {
		DEBUGPRINTF ((TEXT ("ioctlsocket: failed(%d)\n"), WSAGetLastError ())) ;
	} else {
		DEBUGPRINTF ((TEXT ("ioctlsocket: succeeded?\n"))) ;
	}
#else
	ioctlsocket (hSocket, FIONBIO, &ulZERO) ;
#endif

	/* �T�[�o�[�Ɍ������s���悤�w������B*/
	if (TFAILED (skkServerJisyo_sendCommand (hSocket, SKKSERV_SEARCH, pKey, nKey))) 
		return	FALSE ;

	nRecv		= recv (hSocket, szBuffer, sizeof (szBuffer), 0) ;
	DEBUGPRINTF ((TEXT ("sendmsg received (%d)\n"), nRecv)) ;
	if ((nRecv == SOCKET_ERROR && WSAGetLastError () != WSAEWOULDBLOCK) ||
		nRecv <= 0) {
		DEBUGPRINTF ((TEXT ("recv error? %d\n"), WSAGetLastError ())) ;
		return	FALSE ;
	}
	DEBUGPRINTF ((TEXT ("sendmsg received first char=%d\n"), szBuffer [0])) ;
	if (szBuffer [0] == '1') {
 		for ( ; ; ) {
 			register const char*	pResult ;
 			register int			nResult ;
 			if (nRecv == 1) {
 				nResult	= recv (hSocket, szBuffer, sizeof (szBuffer), 0) ;
 				DEBUGPRINTF ((TEXT ("[2] sendmsg received (%d)\n"), nRecv)) ;
 				pResult	= szBuffer ;
 				if (nResult == SOCKET_ERROR || nResult <= 0) {
 					DEBUGPRINTF ((TEXT ("[2] recv error? %d\n"), WSAGetLastError ())) ;
 					return	FALSE ;
 				}
 			} else {
 				pResult	= &szBuffer [1] ;
 				nResult	= nRecv - 1 ;
  			}
 			fRetval	= skkServerJisyo_extractResult (pResult, nResult, pvbuf) ;
 			if (fRetval != TRUE) {
 				if (fRetval == EOL)
 					fRetval	= TRUE ;
 				break;
 			}
 			nRecv = 1;
  		}
	} else {
		fRetval	= TRUE ;
	}
	return	fRetval ;

	UNREFERENCED_PARAMETER (fOkuri) ;
}

BOOL
skkServerJisyo_sendCommand (
	register SOCKET				hSocket,
	register int				nCmd,
	register const Char*		pString,
	register int				nString)
{
	char				szBuffer [3] ;
	register char*		pBuffer ;
	register int		nUsage, nBuffer, nSend ;
	TVarbuffer			vbuf ;

	switch (nCmd) {
	case	SKKSERV_BYE :
	case	SKKSERV_VERSION :
	case	SKKSERV_HOSTNAME :
		szBuffer [0]	= (char)('0' + nCmd) ;
		do {
			nSend	= send (hSocket, szBuffer, 1, 0) ;
		}	while (nSend == SOCKET_ERROR && WSAGetLastError () == WSAEWOULDBLOCK) ;
		break ;

	case SKKSERV_SEARCH :
		if (TFAILED (TVarbuffer_Initialize (&vbuf, sizeof (char))))
			return	FALSE ;
		TVarbuffer_Add (&vbuf, "1", 1) ;
		nUsage	= 0 ;
		while (nString > 0) {
			switch (Char_Charset (*pString)) {
			case	KCHARSET_JISX0201_1976:
				if (Char_IsAscii (*pString)) 
					goto	ascii_char ;
				szBuffer [0]	= (char) 0x8E ;
				szBuffer [1]	= (char) *pString ;
				nUsage			= 2 ;
				break ;
#if KCHARSET_JISX0208_1978 != KCHARSET_JISX0208_1983
			case	KCHARSET_JISX0208_1978:
#endif
			case	KCHARSET_JISX0208_1983:
				szBuffer [0]	= (char)(Char_Code (*pString) >> 8) | 0x80 ;
				szBuffer [1]	= (char)(Char_Code (*pString)     ) | 0x80 ;
				nUsage			= 2 ;
				break ;
			case	KCHARSET_JISX0212_1990:
				szBuffer [0]	= (char)0x8F ;
				szBuffer [1]	= (char)(Char_Code (*pString) >> 8) | 0x80 ;
				szBuffer [2]	= (char)(Char_Code (*pString)     ) | 0x80 ;
				nUsage			= 3 ;
				break ;
			case	KCHARSET_ASCII:
				goto	ascii_char ;
			default:
				if (!Char_IsAscii (*pString)) 
					goto	skip ;
			  ascii_char:
				szBuffer [0]	= (char) *pString ;
				nUsage			= 1 ;
				break ;
			}
			if (TFAILED (TVarbuffer_Add (&vbuf, szBuffer, nUsage)))
				return	FALSE ;
		  skip:
			pString	++ ;
			nString	-- ;
		}
		if (TFAILED (TVarbuffer_Add (&vbuf, " \n", 2)))
			return	FALSE ;

		pBuffer	= TVarbuffer_GetBuffer (&vbuf) ;
		nBuffer	= TVarbuffer_GetUsage (&vbuf) ;
		while (nBuffer > 0) {
			nSend	= send (hSocket, pBuffer, nBuffer, 0) ;
			if (nSend == SOCKET_ERROR) {
				if (WSAGetLastError () == WSAEWOULDBLOCK)
					continue ;
				return	FALSE ;
			}
			pBuffer	+= nSend ;
			nBuffer	-= nSend ;
		}
		TVarbuffer_Uninitialize (&vbuf) ;
		break ;

	default :
		return	FALSE ;
	}
	return	TRUE ;
}

/*
 *	skkserv ���當�������M����֐��B
 *-----
 *	�ǂ̈ʂ̒����̕����񂪋A���ė���̂����������Ȃ��̂ŁA�ϒ�
 *	�o�b�t�@�Ŏ󂯎���Ă���B
 */
int
skkServerJisyo_extractResult (
	register const char*		pResult,
	register int				nResult,
	register TVarbuffer*		pvbuf)
{
	Char					schDest  [SKKSERV_BUFSIZE] ;
	register Char			cc ;
	register Char*			pDest ;
	register const unsigned char*	ptr ;
	register int			nptr ;
	register int			nDest ;
	register int			nState ;
	register unsigned short	wc ;
	register int			nRetval	= TRUE ;

	pDest	= schDest ;
	nDest	= ARRAYSIZE (schDest) ;
	nState	= 0 ;
	wc		= 0 ;
	ptr		= (const unsigned char*) pResult ;
	nptr	= nResult ;
	while (nptr > 0) {
		switch (nState) {
			/*	Fumihiko MACHIDA [machida@users.sourceforge.jp] ����� patch
			 *	�u�����T�[�o����̔��p������ reply ��������v
			 *	�𓖂Ă܂����B(Sat Nov 22 12:56:14 2003)
			 */
		case	0:
 			if (*ptr == (unsigned char)0x8E) {
  				nState	= 2 ;
  				break ;
 			} else if (*ptr == (unsigned char)0x8F) {
 				nState	= 3 ;
 				break ;
			} else if ((*ptr & 0x80) != 0) {
				wc		= (unsigned short)(*ptr & 0x7F) ;
				nState	= 1 ;
				break ;
			}
 			if (*ptr == EOL) {
				nRetval	= EOL ;
				goto	exit_loop ;
 			}
			cc	= Char_MakeAscii (*ptr) ;
			goto	push_state ;
		case	1:
			wc	= (unsigned short)((wc << 8) | ((*ptr) & 0x7F)) ;
			cc	= Char_Make (KCHARSET_JISX0208_1983, wc) ;
			goto	push_state ;
		case	2:
			cc	= Char_Make (KCHARSET_JISX0201_1976, (unsigned char)(*ptr)) ;
			goto	push_state ;
		case	3:
			wc	= (unsigned short)((unsigned char)(*ptr) & 0x7F) ;
			nState	= 4 ;
			break ;
		case	4:
			wc	= (unsigned short)((wc << 8) | ((*ptr) & 0x7F)) ;
			cc	= Char_Make (KCHARSET_JISX0212_1990, wc) ;
			/*goto	push_state ;*/
		push_state:
			if (nDest == 0) {
				if (TFAILED (TVarbuffer_Add (pvbuf, schDest, ARRAYSIZE (schDest))))
					return	FALSE ;
				pDest		= schDest ;
				nDest		= ARRAYSIZE (schDest) ;
			}
			*pDest ++	= cc ;
			nDest  -- ;
			nState	= 0 ;
			wc		= 0 ;
			break ;
		default:
			return	FALSE ;
		}
		ptr  ++ ;
		nptr -- ;
	}
 exit_loop:
	if (nDest < ARRAYSIZE (schDest)) {
		if (TFAILED (TVarbuffer_Add (pvbuf, schDest, ARRAYSIZE (schDest) - nDest)))
			return	FALSE ;
	}
	return	nRetval ;
}

