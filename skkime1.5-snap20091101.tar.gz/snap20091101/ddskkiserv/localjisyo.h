#pragma once

#include "Char.h"
#include "bufstring.h"
#include "varbuffer.h"

typedef struct tagSkkLocalJisyo {
	int							m_nOkuriAriPos ;
	int							m_nOkuriNasiPos ;
	BOOL						m_fModified ;
	BOOL						m_fUnicode ;		/* Unicode �����ł��邩�ۂ��B*/
	TBufString					m_bufJisyo ;
	struct tagSkkLocalJisyo*	m_pNext ;
	TCHAR						m_tszPath [PATH_MAX + 1] ;
}	SkkLocalJisyo ;

/*	prototypes */
SkkJisyo*	SkkLocalJisyo_Create		(const Char*, int) ;
SkkJisyo*	SkkLocalJisyo_CreateT		(LPCTSTR) ;
BOOL		SkkLocalJisyo_bOkuriSearch	(SkkJisyo*, const Char*, int, const Char*, int, int, TVarbuffer*) ;

