#pragma once

#include "dchar.h"
#include "keymap.h"

class	CSkkRuleTreeNodeOutput {
public:
	enum {
		NTYPE_INVALIDVALUE	= -1,
		NTYPE_MACRO,
		NTYPE_STRING,
		NTYPE_STRINGPAIR,
	} ;
public:
	CSkkRuleTreeNodeOutput () {
		return ;
	}
	virtual	~CSkkRuleTreeNodeOutput () {
		return ;
	}
	virtual int		iGetType () const {
		return	NTYPE_INVALIDVALUE ;
	}
} ;

class	CSkkRuleTreeNodeOutputStringPair : public CSkkRuleTreeNodeOutput {
private:
	LPDSTR		m_strHira ;
	int			m_nHira ;
	LPDSTR		m_strKata ;
	int			m_nKata ;
public:
	CSkkRuleTreeNodeOutputStringPair () : CSkkRuleTreeNodeOutput (), m_strHira (NULL), m_nHira (0), m_strKata (NULL), m_nKata (0) {
		return ;
	}
	virtual	~CSkkRuleTreeNodeOutputStringPair () {
		if (m_strHira != NULL) {
			delete[]	m_strHira ;
			m_strHira	= NULL ;
		}
		if (m_strKata != NULL) {
			delete[]	m_strKata ;
			m_strKata	= NULL ;
		}
		return ;
	}
	virtual int		iGetType () const {
		return	NTYPE_STRINGPAIR ;
	}
	virtual LPCDSTR		pGetHiragana (int* pnLength) const {
		if (pnLength != NULL)
			*pnLength	= m_nHira ;
		return	m_strHira ;
	}
	virtual LPCDSTR		pGetKatakana (int* pnLength) const {
		if (pnLength != NULL)
			*pnLength	= m_nKata ;
		return	m_strKata ;
	}
	static CSkkRuleTreeNodeOutput*	pCreateInstance (LPCDSTR wstrHira, int nHira, LPCDSTR wstrKata, int nKata) ;
} ;

class	CSkkRuleTreeNodeOutputString : public CSkkRuleTreeNodeOutput {
private:
	LPDSTR		m_strValue ;
	int			m_nValue ;
public:
	CSkkRuleTreeNodeOutputString () : CSkkRuleTreeNodeOutput (), m_strValue (NULL), m_nValue (0) {
		return ;
	}
	virtual	~CSkkRuleTreeNodeOutputString () {
		if (m_strValue != NULL) {
			delete[]	m_strValue ;
			m_strValue	= NULL ;
		}
		return ;
	}
	virtual int		iGetType () const {
		return	NTYPE_STRING ;
	}
	virtual	LPCDSTR		pGetString (int* pnLength) const {
		if (pnLength != NULL)
			*pnLength	= m_nValue ;
		return	m_strValue ;
	}
	static CSkkRuleTreeNodeOutput*	pCreateInstance (LPCDSTR pwString, int nLength) ;
} ;

class	CSkkRuleTreeNodeOutputMacro : public CSkkRuleTreeNodeOutput {
private:
	int			m_nMacro ;
public:
	CSkkRuleTreeNodeOutputMacro () : CSkkRuleTreeNodeOutput (), m_nMacro (NFUNC_NOFUNCTION) {
		return ;
	}
	virtual	~CSkkRuleTreeNodeOutputMacro () {
		return ;
	}
	virtual int		iGetType () const {
		return	NTYPE_MACRO ;
	}
	virtual	int			iGetFunctionCode () const {
		return	m_nMacro ;
	}
	static CSkkRuleTreeNodeOutput*	pCreateInstance (int nFuncNo) ;
} ;

/*	Rule ��1�{�̖؂���Ȃ��āA�����̖؁c�тɂ�������ǂ��̂ł͂Ȃ����H
 *	oh �̖��� o ����������Ԃ�1�{�̖؂����ł͕\���ł��Ȃ���������ŁA
 *	�����ʂ̖؂ɉ����t����΁Achar-previous �����Ȃ��Ă�(����A��������
 *	�u���v�����邩�ǂ���������������̂����ǁA�G�f�B�^����Ȃ�������͂�
 *	�I������ꏊ�Ɂu���v�����邩�ǂ����͕�����Ȃ���)�ǂ��Ȃ�̂ł͂Ȃ����H
 *
 *	�؂𕪊������ traverse ����Ƃ���ł͂܂�B(�؂����ǂ蒼����Ƃ͑��)
 */
class	CSkkRuleTreeNode {
private:
	enum {
		SYSCHAR_INVALID		= -1,
		SYSCHAR_DEFAULT		= 65536,
		SYSCHAR_VOWEL,
		SYSCHAR_CONSONANT,
	} ;
private:
	int						m_nCH ;
	int						m_iRule ;
	LPDSTR					m_pPrefix ;			/* ����ԁB*/
	int						m_nPrefix ;
	LPDSTR					m_pNextState ;		/* ����ԁB*/
	int						m_nNextState ;
	int						m_nNextRule ;		/* ���̖؁B*/

	CSkkRuleTreeNodeOutput*	m_pOutput ;

	CSkkRuleTreeNode*		m_pChild ;			/* �q���B*/
	CSkkRuleTreeNode*		m_pBrother ;		/* �Z��B*/

public:
	CSkkRuleTreeNode () : m_nCH (0), m_pPrefix (NULL), m_nPrefix (0), m_pNextState (NULL), m_nNextState (0), m_pOutput (NULL), m_pChild (NULL), m_pBrother (NULL) {
		return ;
	}
	virtual	~CSkkRuleTreeNode () {
		if (m_pPrefix != NULL) {
			delete[]	m_pPrefix ;
			m_pPrefix	= NULL ;
		}
		if (m_pNextState != NULL) {
			delete[]	m_pNextState ;
			m_pNextState	= NULL ;
		}
		if (m_pOutput != NULL) {
			delete	m_pOutput ;
			m_pOutput	= NULL ;
		}
		return ;
	} 

	virtual	int							iGetChar () const {
		return	m_nCH ;
	}

	virtual	LPCDSTR						pGetNextState (int* pnLength, int* pnNextRule) const {
		if (pnLength != NULL)
			*pnLength	= m_nNextState ;
		if (pnNextRule != NULL)
			*pnNextRule	= m_nNextRule ;
		return	m_pNextState ;
	}

	virtual	const CSkkRuleTreeNode*		pGetChild () const {
		return	m_pChild ;
	}

	virtual	CSkkRuleTreeNode*			pGetChild () {
		return	m_pChild ;
	}

	virtual	void	vSetChild (CSkkRuleTreeNode* pChild) {
		m_pChild	= pChild ;
		return ;
	}

	virtual	const CSkkRuleTreeNode*		pGetBrother () const {
		return	m_pBrother ;
	}

	virtual	CSkkRuleTreeNode*			pGetBrother () {
		return	m_pBrother ;
	}

	virtual	void	vSetBrother (CSkkRuleTreeNode* pBrother) {
		m_pBrother	= pBrother ;
		return ;
	}

	virtual	CSkkRuleTreeNodeOutput*		pGetOutput () {
		return	m_pOutput ;
	}

	virtual	const CSkkRuleTreeNodeOutput*		pGetOutput () const {
		return	m_pOutput ;
	}

	virtual	void	vSetOutput (CSkkRuleTreeNodeOutput* pOutput) {
		if (m_pOutput == pOutput)
			return ;
		if (m_pOutput != NULL) 
			delete	m_pOutput ;
		m_pOutput	= pOutput ;
		return ;
	}
#if 0
	virtual	void	vDebugOut () const ;
#endif
	static	CSkkRuleTreeNode*		pCreateInstance (int iRule, int nChar, LPCDSTR pwPrefix, int nPrefixLen, LPCDSTR pwNext, int nNextLen, int iNextRule, CSkkRuleTreeNodeOutput* pOutput) ;

	static	LPCDSTR					pGetPrefix (CSkkRuleTreeNode* pNode, int* pnPrefix) ;
	static	LPCDSTR					pGetPrefix (const CSkkRuleTreeNode* pNode, int* pnPrefix) ;
	static	CSkkRuleTreeNode*		pSelectBranch (CSkkRuleTreeNode* pNode, int iCH) ;
	static	const CSkkRuleTreeNode*	pSelectBranch (const CSkkRuleTreeNode* pNode, int iCH) ;
	static	CSkkRuleTreeNode*		pGetBranchList (CSkkRuleTreeNode* pNode) ;
	static	const CSkkRuleTreeNode*	pGetBranchList (const CSkkRuleTreeNode* pNode) ;

	static	int						iSearchTree (CSkkRuleTreeNode* pTree, LPCDSTR pwString, int nString, CSkkRuleTreeNode** ppResult) ;
	static	BOOL					bAddRule (CSkkRuleTreeNode** ppTree, int iTree, LPCDSTR wstrPrefix, int nPrefixLen, LPCWSTR wstrNext, int nNextLen, int nNextTree, LPCWSTR wstrHira, int nHiraLen, LPCWSTR wstrKata, int nKataLen) ;
	static	BOOL					bAddRule (CSkkRuleTreeNode** ppTree, int iTree, LPCDSTR wstrPrefix, int nPrefixLen, LPCWSTR wstrNext, int nNextLen, int nNextTree, LPCWSTR wstrString, int nString) ;
	static	BOOL					bAddRule (CSkkRuleTreeNode** ppTree, int iTree, LPCDSTR wstrPrefix, int nPrefixLen, LPCWSTR wstrNext, int nNextLen, int nNextTree, int nMacro) ;
	static	BOOL					bDeleteRule (CSkkRuleTreeNode**	ppTree, LPCDSTR pString, int nString) ;
	static	void					vDestroyTree (CSkkRuleTreeNode* pNode) ;

private:
//	static	int						iSearchTre (CSkkRuleTreeNode* pTree, LPCDSTR pString, int nString, CSkkRuleTreeNode** ppResult) ;

	static	BOOL					bMatchChar (int nSystemChar, int nInputChar, int* pnScore) ;
	static	int						iGetRuleCharacter (LPCDSTR* ppwPtr, LPCDSTR pwPtrEnd) ;
} ;

/*


BOOL	TSkkRuleTree_bInitializeDefault (struct CSkkRuleTreeNode**) ;
BOOL	TSkkRuleTreeNode_bAddRuleSP		(struct CSkkRuleTreeNode**, LPCDSTR, int, LPCDSTR, int, LPCDSTR, int, LPCDSTR, int) ;
BOOL	TSkkRuleTreeNode_bAddRuleS		(struct CSkkRuleTreeNode**, LPCDSTR, int, LPCDSTR, int, LPCDSTR, int) ;
BOOL	TSkkRuleTreeNode_bAddRuleM		(struct CSkkRuleTreeNode**, LPCDSTR, int, LPCDSTR, int, int) ;

void	TSkkRuleTreeNode_vDestroyTree	(struct CSkkRuleTreeNode*) ;
LPCDSTR	TSkkRuleTreeNode_pGetPrefix		(const struct CSkkRuleTreeNode*, int*) ;
struct CSkkRuleTreeNode*				TSkkRuleTreeNode_pSelectBranch	(struct CSkkRuleTreeNode*, int) ;
LPCDSTR	TSkkRuleTreeNode_pGetNextState	(const struct CSkkRuleTreeNode*, int*) ;
struct CSkkRuleTreeNode*				TSkkRuleTreeNode_pGetBranchList (struct CSkkRuleTreeNode*) ;

const struct CSkkRuleTreeNodeOutput*	TSkkRuleTreeNode_pGetOutput		(const struct CSkkRuleTreeNode*) ;

struct CSkkRuleTreeNodeOutput*			TSkkRuleTreeNodeOutput_pCreateStringPairInstance	(LPCDSTR, int, LPCDSTR, int) ;
struct CSkkRuleTreeNodeOutput*			TSkkRuleTreeNodeOutput_pCreateMacroInstance			(int) ;
struct CSkkRuleTreeNodeOutput*			TSkkRuleTreeNodeOutput_pCreateStringInstance		(LPCDSTR, int) ;
void	TSkkRuleTreeNodeOutput_vDestroy		(struct CSkkRuleTreeNodeOutput*) ;

int		TSkkRuleTreeNodeOutput_iGetType		(const struct CSkkRuleTreeNodeOutput*) ;
BOOL	TSkkRuleTreeNodeOutput_bGetMacro	(const struct CSkkRuleTreeNodeOutput*, int* pnFuncNo) ;
BOOL	TSkkRuleTreeNodeOutput_bGetString	(const struct CSkkRuleTreeNodeOutput*, LPCDSTR*, int*) ;
BOOL	TSkkRuleTreeNodeOutput_bGetLString	(const struct CSkkRuleTreeNodeOutput*, LPCDSTR*, int*) ;
BOOL	TSkkRuleTreeNodeOutput_bGetRString	(const struct CSkkRuleTreeNodeOutput*, LPCDSTR*, int*) ;



*/