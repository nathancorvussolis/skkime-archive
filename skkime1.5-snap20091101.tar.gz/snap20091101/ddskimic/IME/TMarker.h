#pragma once

class CTMarker {
private:
	int			m_iPosition ;
	BOOL		m_bCursor ;
	BOOL		m_bValid ;

public:
	CTMarker () : m_iPosition (0), m_bCursor (FALSE), m_bValid (FALSE) {
		return; 
	}

	virtual	~CTMarker () {
		return ;
	}

	virtual	BOOL	bInit (BOOL bCursor) {
		m_iPosition		= 0 ;
		m_bCursor		= bCursor ;
		m_bValid		= TRUE ;
		return	TRUE ;
	}

	virtual	int		iGetPosition () const {
		return	(m_bValid)? m_iPosition : -1 ;
	}

	virtual	BOOL	bForward (int n) {
		register int	nPos ;

		if (! m_bValid)
			return	FALSE ;
		nPos		= m_iPosition + n ;
		m_iPosition	= (nPos > 0)? nPos : 0 ;
		return	TRUE ;
	}

	virtual	BOOL	bBackward (int n) {
		register int	nPos ;

		if (! m_bValid)
			return	FALSE ;
		nPos		= m_iPosition - n ;
		m_iPosition	= (nPos > 0)? nPos : 0 ;
		return	TRUE ;
	}

	virtual	BOOL	bIsCursor () const {
		return	m_bCursor ;
	}

	virtual void	vSetCursor (BOOL bCursor) {
		if (! m_bValid)
			return ;
		m_bCursor	= bCursor ;
		return ;
	}

	virtual BOOL	bIsValidp () const {
		return	m_bValid ;
	}

	virtual	BOOL	bSetPosition (const CTMarker* pMarker) {
		if (pMarker == NULL || ! pMarker->m_bValid || ! m_bValid)
			return	FALSE ;
		m_iPosition	= pMarker->m_iPosition ;
		return	TRUE ;
	}

	virtual	void	vInvalidate () {
		m_bValid	= FALSE ;
		return ;
	}
} ;



