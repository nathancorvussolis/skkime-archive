#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "TLispSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
CTLispSession::bEval (
	LPCDSTR		wstrHenkanKey,
	int			nstrHenkanKey,
	LPDSTR		wstrDest,
	int			nstrDest)
{
	CTPacket	packet ;
	HANDLE		hPipe ;
	int			nMajor = -1, nMinor, nSize ;
	WORD		wTotalResult ;
	LPCWSTR		wstrResult ;
	int			nResult, nRecv ;
	BOOL		fRetval	= FALSE ;
	
	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.bSetHeader  (SKKISERV_PROTO_EVAL, 0) ||
		! packet.bAddDString (wstrHenkanKey, nstrHenkanKey) ||
		! packet.bSetLength () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! _bRecv (hPipe, &packet) ||
		! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.iGetDataSize () ;
	if (nMajor != SKKISERV_PROTO_EVAL_REPLY)
		goto	exit_func ;
	if (! packet.bGetCard16 (SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;
	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	wstrResult	= (LPCWSTR)(packet.pGetData () + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;

	if (wTotalResult > 0) {
		int		nTotalResult	= wTotalResult ;
		DCHAR*	ptr				= wstrDest ;
		DCHAR*	ptrEnd			= wstrDest + nstrDest ;
		int		n ;

		if (nResult > nTotalResult)
			nResult		= nTotalResult ;

		if (ptr < ptrEnd) {
			n	= wcstodcs (ptr, ptrEnd - ptr, wstrResult, nResult) ;
			ptr	+= n ;
		}
		wTotalResult	-= nResult ;

		while (nTotalResult > 0 && ptr < ptrEnd) {
			if (! _bRecv (hPipe, &packet))
				break ;
			nRecv	= packet.iGetDataSize () ;
			if (nRecv < 0)
				break ;
			wstrResult	= (LPCWSTR) packet.pGetData () ;
			nResult		= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;

			n	= wcstodcs (ptr, ptrEnd - ptr, wstrResult, nResult) ;
			ptr				+= n ;
			nTotalResult	-= nResult ;
		}
		if (ptr < ptrEnd) 
			*ptr	= L'\0' ;
		fRetval	= TRUE ;
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

BOOL
CTLispSession::bSetNumberList (
	LPCDSTR	wstrNumberList)
{
	CTPacket	packet ;
	HANDLE		hPipe ;
	int			nMajor = -1, nMinor, nSize ;
	int			nRecv ;
	BOOL		fRetval	= FALSE ;
	
	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;

	if (! packet.bSetHeader (SKKISERV_PROTO_SETJNUMLIST, 0))
		goto	exit_func ;
	if (wstrNumberList != NULL && *wstrNumberList != L'\0') {
		LPCDSTR		wptr ;
		int			nwptr ;

		if (! packet.bAddString (L"/", 1))
			goto	exit_func ;

		wptr	= wstrNumberList ;
		if (wptr != NULL) {
			while (wptr != L'\0') {
				nwptr	= dcslen (wptr) ;
				if (! packet.bAddDString (wptr, nwptr) ||
					! packet.bAddString (L"/", 1))
					goto	exit_func ;
				wptr	+= nwptr + 1 ;
			}
		}
	}
	if (! packet.bSetLength () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;
	if (! _bRecv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= packet.iGetDataSize () ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	fRetval	= (nMajor == SKKISERV_PROTO_SETJNUMLIST_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}


