#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "ImeDoc.h"
#include "ImeBuffer.h"
#include "TMarker.h"
#include "jstring.h"
#include "ImeConfig.h"
#include "TCommuSession.h"

#define	NLOOP_IMEDOC	256

/*========================================================================
 *	public functions (ImeUI inferface)
 */
CImeDoc::CImeDoc () :
	m_pPC				(NULL),
	m_nRetPC			(0),
	m_nUnreadMessages	(0),
	m_nBuffer			(0),
	m_nUnusedBuffer		(0),
	m_pCurBuffer		(NULL),
	m_pbStackArea		(0),
	m_nStackHead		(0),
	m_nStackAreaSize	(0),
	m_nRegStackHead		(0),
	m_pRegStack			(NULL),
	m_nSignal			(LMSIGNAL_NONE),
	m_iThisCommand		(NFUNC_INVALID_CHAR),
	m_iLastCommand		(NFUNC_INVALID_CHAR),
	m_nbufMessage		(0),
	m_pPreCommandHook	(NULL),
	m_pPostCommandHook	(NULL),
	m_dwUpdateFlag		(0)
{
	return ;
}

CImeDoc::~CImeDoc ()
{
	if (m_pbStackArea != NULL) {
		delete[]	m_pbStackArea ;
		m_pbStackArea	= NULL ;
	}
	if (m_pRegStack != NULL) {
		delete[]	m_pRegStack ;
		m_pRegStack	= NULL ;
	}
	return ;
}

BOOL
CImeDoc::bInit (CImeConfig* pConfig)
{
	CImeBuffer*		pBuffer ;
	int				i ;

	m_pPC				= CImeDoc::LM_iMessageLoop ;
	m_nRetPC			= 0 ;

	m_nUnreadMessages	= 0 ;
	m_nBuffer			= 0 ;
	m_nUnusedBuffer		= 0 ;
	m_pCurBuffer		= NULL ;
	m_pbStackArea		= 0 ;
	m_nStackHead		= 0 ;
	m_nStackAreaSize	= 0 ;
	m_nRegStackHead		= 0 ;
	m_pRegStack			= NULL ;
	m_pConfig			= pConfig ;

	m_nSignal			= LMSIGNAL_NONE ;
	m_iThisCommand		= NFUNC_INVALID_CHAR ;
	m_iLastCommand		= NFUNC_INVALID_CHAR ;
	memset (&m_LastEvent, 0, sizeof (m_LastEvent)) ;
	m_nbufMessage		= 0 ;
	m_pPreCommandHook	= NULL ;
	m_pPostCommandHook	= NULL ;
	m_dwUpdateFlag		= 0 ;
	memset (m_rpBuffer, 0, sizeof (m_rpBuffer)) ;
	memset (m_rpUnusedBuffer, 0, sizeof (m_rpUnusedBuffer)) ;

	if (! _bInitConfig ())
		return	FALSE ;

	pBuffer	= pCreateBuffer (NULL, 0, TRUE) ;
	if (pBuffer == NULL)
		return	FALSE ;

	m_pbStackArea			= new BYTE [NSIZE_IMEDOC_STACK] ;
	if (m_pbStackArea == NULL) 
		return	FALSE ;
	m_nStackAreaSize		= NSIZE_IMEDOC_STACK ;

	m_pRegStack				= new struct LMREG [NSIZE_REGSTACK] ;	//(struct LMREG*) MALLOC (sizeof (struct LMREG) * NSIZE_REGSTACK) ;
	if (m_pRegStack == NULL)
		return	FALSE ;

	if (! _bInitContextBuffer ())
		return	FALSE ;

	for (i = 0 ; i < MYARRAYSIZE (m_rREGS) ; i ++)
		m_rREGS [i].m_nType	= LMREGTYPE_NIL ;

	m_pCurBuffer		= pBuffer ;

	/*	skk-mode-invoke
	 */
	m_pPreCommandHook	= CImeDoc::LM_bSkkPreCommand ;
	m_pPostCommandHook	= CImeDoc::LM_bSkkPostCommand ;

	(void) CTCommunicateSession::bInitPipeName () ;

	m_CandInfo.vClear () ;
	m_MessageInfo.vClear () ;
	return	TRUE ;
}

void
CImeDoc::vUninit ()
{
	int		i ;

	for (i = 0 ; i < m_nBuffer ; i ++) {
		if (m_rpBuffer [i] != NULL) 
			delete	m_rpBuffer [i] ;
		m_rpBuffer [i]	= NULL ;
	}
	for (i = 0 ; i < m_nUnusedBuffer ; i ++) {
		if (m_rpUnusedBuffer [i] != NULL) 
			delete	m_rpUnusedBuffer [i] ;
		m_rpUnusedBuffer [i]	= NULL ;
	}
	m_nBuffer = m_nUnusedBuffer = 0 ;

	_vUninitConfig () ;
	m_CandInfo.vClear () ;
	m_MessageInfo.vClear () ;
	_vUninitContextBuffer () ;
	return ;
}

void
CImeDoc::vClear (BOOL bFullClear)
{
	int		i ;

	for (i = 0 ; i < MYARRAYSIZE (m_rREGS) ; i ++)
		m_rREGS [i].m_nType	= LMREGTYPE_NIL ;

	/*	stack �ʒu��擪�ɖ߂��B
	 */
	m_nRegStackHead		= 0 ;
	m_nStackHead		= 0 ;
	m_pPC				= CImeDoc::LM_iMessageLoop ;
	m_nRetPC			= 0 ;
	m_nUnreadMessages	= 0 ;
	m_nSignal			= LMSIGNAL_NONE ;

	for (i = 1 ; i < m_nBuffer ; i ++) {
		if (bDeleteBuffer (m_rpBuffer [i]))
			m_rpBuffer [i]	= NULL ;
	}
	if (m_rpBuffer [0] != NULL) {
		m_rpBuffer [0]->bClear (bFullClear) ;
		m_pCurBuffer	= m_rpBuffer [0] ;
		(void) m_pCurBuffer->bSetConversionMode (IMECMODE_HIRAGANA) ;
	} else {
		m_pCurBuffer	= NULL ;
	}
	m_iThisCommand		= NFUNC_INVALID_CHAR ;
	m_iLastCommand		= NFUNC_INVALID_CHAR ;
	memset (&m_LastEvent, 0, sizeof (m_LastEvent)) ;
	m_nbufMessage			= 0 ;
	m_CandInfo.vClear () ;
	m_MessageInfo.vClear () ;
	return ;
}

LPCDSTR
CImeDoc::pGetPreeditText (int* pnLength)
{
	LPCDSTR	strPreeditText ;
	int		nLength ;

	ASSERT (m_nBuffer > 0 && m_rpBuffer [0] != NULL) ;

	strPreeditText	= m_rpBuffer [0]->pBufferRawString (&nLength) ;

	if ((bRecursiveEditp () || m_rpBuffer [0]->bInputByCodeOrMenuModep () || m_rpBuffer [0]->bShowHenkanCandidatesModep ()) && nLength == 0) {
		static const DCHAR	s_bufDummy []	= { 0 } ;
		/*	TF_SELECTION.RANGE �� Empty ���� ITfContextView->GetTextExt �̕Ԃ� RECT ��
		 *	�R�����A�v���P�[�V���������݂��邽�߁A�ҏW���̃e�L�X�g��s������B
		 *	(Empty �ɂ͂Ȃ�Ȃ��悤��)
		 *	����ɂ�� Message Window (Status Window) ���ҏW���̃e�L�X�g�ɏd�Ȃ��肪
		 *	�ɘa����锤�B���܂�i�D�悭�Ȃ��������@�ł��邪�c�B
			strPreeditText	= L" " ;
			nLength			= 1 ;
		 *
		 *	�ƁA�ӂƎv�����̂����ǁAStatus Window ��\��������󔒂ɖ߂��Ƃǂ��Ȃ�̂�
		 *	�낤���H
		 *	���̎��݂����s�����Ȃ�A��� L" " �𗘗p���邵���Ȃ����낤���ǁc�B
		 */
		strPreeditText	= s_bufDummy ;
		nLength			= 0 ;
	}
	if (pnLength != NULL)
		*pnLength	= nLength ;
	return	strPreeditText ;
}

BOOL
CImeDoc::bGetPreeditCursor (int* pnCursor) const
{
	CTMarker*	pmkPoint ;

	ASSERT (m_nBuffer > 0 && m_rpBuffer [0] != NULL) ;
	ASSERT (pnCursor != NULL) ;

	if (! m_rpBuffer [0]->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
		return	FALSE ;
	*pnCursor	= pmkPoint->iGetPosition () ;
	return	TRUE ;
}

#if !defined (UNITTEST)
const IMECANDIDATES*
CImeDoc::pGetStatusText () const
{
	if (m_pCurBuffer->bShowHenkanCandidatesModep () ||
		m_pCurBuffer->bInputByCodeOrMenuModep () ||
		m_pCurBuffer->bInputByCodeOrMenu1Modep ()) {
		return	m_CandInfo.bIsEnabledp ()? &m_CandInfo : NULL ;
	} else {
		if (m_rpBuffer [0] != m_pCurBuffer) 
			return	m_MessageInfo.bIsEnabledp ()? &m_MessageInfo : NULL ;
	}
	return	NULL ;
}
#else
LPCDSTR
CImeDoc::pGetStatusText (int* pnLength)
{
	ASSERT (m_nBuffer > 0 && m_rpBuffer [0] != NULL) ;
	ASSERT (pnLength != NULL) ;

	if (m_nbufMessage > 0) {
		*pnLength	= m_nbufMessage ;
		return	m_bufMessage ;
	} else {
		if (m_rpBuffer [0] != m_pCurBuffer)
			return	m_pCurBuffer->pBufferRawString (pnLength) ;
	}
	*pnLength	= 0 ;
	return	NULL ;
}
#endif

BOOL
CImeDoc::bGetStatusCursor (int* pnCursor) const
{
	CTMarker*	pmkPoint ;

	ASSERT (pnCursor != NULL) ;

#if 0
	if (m_nbufMessage > 0)
		return	FALSE ;
	if (m_rpBuffer [0] == m_pCurBuffer)
		return	FALSE ;

	if (! m_pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
		return	FALSE ;
	*pnCursor	= pmkPoint->iGetPosition () ;
#else
	if (m_rpBuffer [0] != m_pCurBuffer && ! bShowHenkanCandidatesModep () && ! bInputByCodeOrMenuModep (NULL)) {
		if (! m_pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
			return	FALSE ;
		*pnCursor	= pmkPoint->iGetPosition () ;
	} else {
		return	FALSE ;
	}
#endif
	return	TRUE ;
}

BOOL
CImeDoc::bIsStatusActivep () const
{
	return	(m_rpBuffer [0] != m_pCurBuffer) ;
}

BOOL
CImeDoc::bRecursiveEditp () const
{
	return	(m_nBuffer > 1 && m_pCurBuffer != m_rpBuffer [0])? TRUE : FALSE ;
}

BOOL
CImeDoc::bQueryFilterEvent	(
	const struct TMSG*		pMsg,
	BOOL*					pfEaten)
{
	BOOL	bEaten ;

	if (pMsg == NULL)
		return	FALSE ;

	/*	����͑S�� process ����Ƃ��Ă����B��ɏC���B
	 */
	bEaten	= FALSE ;
	if (bRecursiveEditp ()) {
		bEaten	= TRUE ;
	} else {
		if (m_pCurBuffer->bShowHenkanCandidatesModep () ||
			m_pCurBuffer->bInputByCodeOrMenuModep ()) {
			bEaten	= TRUE ;
		} else if (m_pCurBuffer->bHavePrefixp ()) {
			/*	prefix �����݂���΁Askk-pre-command �����s����Ȃ���΂Ȃ�Ȃ��̂ŁA
			 *	eaten
			 */
			bEaten	= TRUE ;
		} else {
			int		nText, nFuncNo ;

			/* �����Ŏ��ۂɐH�ׂ�L�[�����ǂ��������`�F�b�N����B*/
			(void) m_pCurBuffer->pBufferString (&nText) ;
			if (nText > 0) {
				/* ���炩�̃e�L�X�g�����͂���Ă���΁A�L�[���ꉞ�H�ׂ�B*/
				bEaten	= TRUE ;
			} else {
				if (bLookupKeymap (pMsg, &nFuncNo) && _bProcessFunctionp (nFuncNo)) {
					/*	�����Ŏ��ۂɂ� original-keymap ���Ă΂�� unprocess-keyevent ��
					 *	�Ă΂��\��������B�P���� Eaten ���ƌ��ߕt���邱�Ƃ͂ł��Ȃ��B
					 *	���ۂ� Tick ���Ăяo���Ă݂āA���̌��� Unprocess Message ������
					 *	���邩�ǂ���������K�v������B�������A���̂��߂ɂ͂ǂꂾ����
					 *	�X�e�[�g��ێ����Ȃ���΂Ȃ�Ȃ��̂��낤���H
					 */
					if (! _bEmulateFilterEvent (pMsg, &bEaten)) {
						bEaten	= TRUE ;	/* �G���[�͐H�ׂ邩�H */
					}
				}
			}
		}
	}
	if (pfEaten != NULL)
		*pfEaten	= bEaten ;
	return	TRUE ;
}

BOOL
CImeDoc::bFilterEvent	(
	const struct TMSG*		pMsg)
{
	BOOL	bRetval ;
	int		iConversionMode ;

	if (! bPushEvent (pMsg))
		return	FALSE ;

	/* �������C�x���g�́u��v�ɐݒ肳���B*/
	m_UnprocessEvent.m_nMessage	= WM_NULL ;
	/* update flag �͏����������B*/
	vClearUpdateFlag () ;
	vClearMessage () ;
	iConversionMode	= iGetConversionMode () ;
	bRetval	= _bTick () ;
	if (bRetval && iConversionMode != iGetConversionMode ()) {
		vSetUpdateFlag (IMEDOC_UPDATE_CONVERSIONMODE) ;
	}
	/* status candidate �� update */
	_bUpdateCandidateInfoForStatusText () ;
	vDeleteUnusedBuffer () ;
	return	bRetval ;
}

BOOL
CImeDoc::bQueryToggleIMEEvent	(
	const struct TMSG*		pMsg,
	BOOL*					pfEaten)
{
	BOOL	bEaten ;
	int		nFuncNo ;

	if (pMsg == NULL)
		return	FALSE ;

	if (bLookupKeymap (pMsg, &nFuncNo) && nFuncNo == NFUNC_TOGGLE_IME) {
		bEaten	= TRUE ;
	} else {
		bEaten	= FALSE ;
	}
	if (pfEaten != NULL)
		*pfEaten	= bEaten ;
	return	TRUE ;
}

const struct TMSG*
CImeDoc::pGetUnprocessEvent ()
{
	if (m_UnprocessEvent.m_nMessage == WM_NULL)
		return	NULL ;

	return	&m_UnprocessEvent ;
}

int
CImeDoc::iGetReadingText (
	LPDSTR					pwReading,
	int						nReadingSize,
	int						nCompPosition,
	int*					pnReadingPosition)
{
	/*	buffer class �� (henkan-start-point, henkan-end-point, henkan-key) �̃y�A��
	 *	�L�^������B�����āAbuffer-string ����鎞�� (henkan-start-point, henkan-end-point) ��
	 *	������� henkan-key �ɒu��������B
	 *	����ő��� reading-text �͂���Ȃ�Ɏ擾�ł��锤�B(top-buffer �ł̂ݎ�������΂�����
	 *	�v��)
	 */
	if (pwReading == NULL || m_rpBuffer [0] == NULL)
		return	0 ;

	return	m_rpBuffer [0]->iGetReadingText (pwReading, nReadingSize, nCompPosition, pnReadingPosition) ;
}

/*	�ϊ����[�h��؂�ւ���Btopbuffer ��؂�ւ���̂͗ǂ��̂����Arecursive-edit-mode
 *	�������ꍇ�ɂ͗ǂ��̂��낤���H ���̂�����͎d�l�̍ă`�F�b�N���K�v���낤�B
 */
BOOL
CImeDoc::bSetConversionMode (
	int						nConversionMode)
{
	CImeBuffer*	pBuffer ;
	struct TMSG	msg ;
	int			nCurMode ;

	if (m_pCurBuffer == NULL)
		return	FALSE ;

	pBuffer	= m_pCurBuffer ;

	/*	�ǂ̂悤�ɂ��� conversion-mode ��ύX������Ηǂ��̂��낤���H
	 *	�܂�A�����[�h��������A�����[�h��������Askk-show-henkan-candidates-mode ��������
	 *	skk-input-by-code-or-menu-mode �������肵������ conversion-mode ��ύX������Ƃ�������
	 *	�͉����w���ׂ��Ȃ̂��낤���H
	 */
	nCurMode		= iGetConversionMode () ;
	if (nCurMode == nConversionMode)
		return	TRUE ;

	/* �������C�x���g�́u��v�ɐݒ肳���B*/
	m_UnprocessEvent.m_nMessage	= WM_NULL ;
	/* update flag �͏����������B*/
	vClearUpdateFlag () ;			

	msg.m_nMessage	= WM_LM_COMMAND ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= msg.m_pt.y	= 0 ;

	switch (nConversionMode) {
	case	IMECMODE_HIRAGANA:
	case	IMECMODE_KATAKANA:
		/* conversion-mode -> hiragana �ւ� route */
		if (! pBuffer->bJModep ()) {
			/* skk-mode-on ���Ăяo���B*/
			msg.m_wParam	= NFUNC_SKK_MODE ;
			if (! bPushEvent (&msg))
				return	FALSE ;
			/* katakana-mode �� FALSE �ɂȂ�B����Ŋ����B*/
			if (nConversionMode == IMECMODE_KATAKANA) {
				if (! _bTick ()) {
					vClear () ;
					return	FALSE ;
				}
				msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
				if (! bPushEvent (&msg))
					return	FALSE ;
			}
		} else {
			if (pBuffer->bLatinModep () || pBuffer->bJisx0208LatinModep ()) {
				/* skk-kakutei �ł܂� j-mode �ɂ���B*/
				msg.m_wParam	= NFUNC_SKK_MODE ;
				if (! bPushEvent (&msg))
					return	FALSE ;
				if ((  pBuffer->bKatakanaModep () && nConversionMode == IMECMODE_HIRAGANA) ||
					(! pBuffer->bKatakanaModep () && nConversionMode == IMECMODE_KATAKANA)) {
					if (! _bTick ()) {
						vClear () ;
						return	FALSE ;
					}
					msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
					if (! bPushEvent (&msg))
						return	FALSE ;
				}
			} else if (pBuffer->bJisx0201Modep ()) {
				/* �܂���������ĂȂ��B*/
				/* toggle-jisx0201 ���Ăяo���B*/
				/* ���̌�Akatakana-mode ���ǂ�������肾���c�B*/
				/* ���̌�Atoggle-characters */
			} else if (pBuffer->bKatakanaModep ()) {
				if (nConversionMode == IMECMODE_HIRAGANA) {
					msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
					if (! bPushEvent (&msg))
						return	FALSE ;
				}
			} else {
				if (nConversionMode == IMECMODE_KATAKANA) {
					msg.m_wParam	= NFUNC_SKK_TOGGLE_CHARACTERS ;
					if (! bPushEvent (&msg))
						return	FALSE ;
				}
			}
		}
		break ;

	case	IMECMODE_ZENKAKU:
	case	IMECMODE_ASCII:
		if (! pBuffer->bJModep  ()) {
			/* skk-mode-on ���Ăяo���B*/
			msg.m_wParam	= NFUNC_SKK_MODE ;
			if (! bPushEvent (&msg))
				return	FALSE ;
			if (! _bTick ()) {
				vClear () ;
				return	FALSE ;
			}
		}
		msg.m_wParam	= (nConversionMode == IMECMODE_ZENKAKU)? NFUNC_SKK_JISX0208_LATIN_MODE : NFUNC_SKK_LATIN_MODE ;
		if (! bPushEvent (&msg))
			return	FALSE ;
		break ;

	case	IMECMODE_HANKANA:
		if (! pBuffer->bJisx0201Modep ()) {
			if (! pBuffer->bJModep  ()) {
				/* skk-mode-on ���Ăяo���B*/
				msg.m_wParam	= NFUNC_SKK_MODE ;
				if (! bPushEvent (&msg))
					return	FALSE ;
				if (! _bTick ()) {
					vClear () ;
					return	FALSE ;
				}
			}
			msg.m_wParam	= NFUNC_SKK_TOGGLE_KATAKANA ;
			if (! bPushEvent (&msg))
				return	FALSE ;
		} else {
			if (pBuffer->bJisx0201Romanp ()) {
				msg.m_wParam	= NFUNC_SKK_TOGGLE_JISX0201 ;
				if (! bPushEvent (&msg))
					return	FALSE ;
			} else {
				return	TRUE ;
			}
		}
		break ;

	case	IMECMODE_HANKANA_ROMAN:
		if (! pBuffer->bJisx0201Modep ()) {
			if (! pBuffer->bJModep  ()) {
				/* skk-mode-on ���Ăяo���B*/
				msg.m_wParam	= NFUNC_SKK_MODE ;
				if (! bPushEvent (&msg))
					return	FALSE ;
				if (! _bTick ()) {
					vClear () ;
					return	FALSE ;
				}
			}
			msg.m_wParam	= NFUNC_SKK_TOGGLE_KATAKANA ;
			if (! bPushEvent (&msg))
				return	FALSE ;
			if (! _bTick ()) {
				vClear () ;
				return	FALSE ;
			}
			msg.m_wParam	= NFUNC_SKK_TOGGLE_JISX0201 ;
			if (! bPushEvent (&msg))
				return	FALSE ;
		} else {
			if (pBuffer->bJisx0201Romanp ()) {
				return	TRUE ;
			} else {
				msg.m_wParam	= NFUNC_SKK_TOGGLE_JISX0201 ;
				if (! bPushEvent (&msg))
					return	FALSE ;
			}
		}
		break ;

	case	IMECMODE_OFF:
		/*	����� IME �����Ƃ������Ƃ��Ǝv�����ǁc�����ɗ��邱�Ƃ͂Ȃ��Ǝv���B */
		return	FALSE ;
	}
	if (! _bTick ()) {
		vClear () ;
	}
	return	TRUE ;
}

int
CImeDoc::iGetConversionMode ()
{
	ASSERT (m_nBuffer > 0 && m_rpBuffer [0] != NULL) ;
	return	m_rpBuffer [0]->iGetConversionMode () ;
}

BOOL
CImeDoc::bSetConversionString (
	LPCDSTR				wstrText,
	int					nText)
{
	/*	����̓��[�h�ɂ���ē��삪�قȂ�B
	 */
	vClear () ;
	return	m_pCurBuffer->bSetConversionString (wstrText, nText, CImeConfig::bSkkCompositionAutoShiftp (m_pConfig)) ;
}

BOOL
CImeDoc::bGetSelectedRegion (
	int*				pnStartPos,
	int*				pnEndPos)
{
	return	m_pCurBuffer->bGetSelectedRegion (pnStartPos, pnEndPos) ;
}

BOOL
CImeDoc::bGetConvertedRegion (
	int*				pnStartPos,
	int*				pnEndPos)
{
	return	m_pCurBuffer->bGetConvertedRegion (pnStartPos, pnEndPos) ;
}

BOOL
CImeDoc::bQueryUpdateContext (
	int*				pnShift,
	int*				pnCursor,
	BOOL*				pfContinue)
{
	ASSERT (m_nBuffer > 0 && m_rpBuffer [0] != NULL) ;
	ASSERT (pnShift    != NULL) ;
	ASSERT (pnCursor   != NULL) ;
	ASSERT (pfContinue != NULL) ;

	if (m_rpBuffer [0] != m_pCurBuffer) {
		CTMarker*	pmkPoint ;

		if (! m_rpBuffer [0]->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
			return	FALSE ;

		*pnShift	= 0 ;
		*pnCursor	= pmkPoint->iGetPosition () ;
		*pfContinue	= TRUE ;
		return	TRUE ;
	}

	/*	�����V�t�g�ł͂Ȃ��A���� newline �ɂ�鋭�� update �������Ă��Ȃ��ꍇ�ɂ�
	 *	�������Ȃ��Bcontinue ���ǂ����͏󋵂ɂ��B
	 */
	if (! CImeConfig::bSkkCompositionAutoShiftp (m_pConfig) && (m_dwUpdateFlag & IMEDOC_NEWLINE) == 0) {
		CTMarker*	pmkPoint ;

		if (! m_rpBuffer [0]->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
			return	FALSE ;

		*pnShift	= 0 ;
		if (bProcessEventp ()) {
			*pnCursor	= pmkPoint->iGetPosition () ;
			*pfContinue	= TRUE ;
		} else {
			*pnCursor	= 0 ;
			*pfContinue	= FALSE ;
		}
		return	TRUE ;
	}
	if (CImeConfig::bSkkIsNewlineKakuteiAllp (m_pConfig) && (m_dwUpdateFlag & IMEDOC_NEWLINE) != 0) {

		if (! m_rpBuffer [0]->bSkkHenkanActivep () && ! m_rpBuffer [0]->pSkkGetSkkRuleTreeIterator ()->bHavePrefixp ()) {
//		if (! m_rpBuffer [0]->bSkkHenkanActivep () && m_rpBuffer [0]->pSkkGetSkkCurrentRuleTree () == NULL) {
			CTMarker*	pmkPoint ;
			CTMarker*	pmkBufferEnd ;
			int			iMove ;

			if (! m_rpBuffer [0]->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) || pmkPoint == NULL)
				return	FALSE ;
			if (! m_rpBuffer [0]->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkBufferEnd) || pmkBufferEnd == NULL)
				return	FALSE ;
			iMove	= pmkBufferEnd->iGetPosition () - pmkPoint->iGetPosition () ;
			if (! pmkPoint->bForward (iMove))
				return	FALSE ;
		}
	}
	return	m_rpBuffer [0]->bQueryUpdateContext (pnShift, pnCursor, pfContinue) ;
}

BOOL
CImeDoc::bUpdateContext ()
{
	ASSERT (m_nBuffer > 0 && m_rpBuffer [0] != NULL) ;

	if (m_rpBuffer [0] != m_pCurBuffer) 
		return	TRUE ;

	/*	�����V�t�g�ł͂Ȃ��A���� newline �ɂ�鋭�� update �������Ă��Ȃ��ꍇ�ɂ�
	 *	�������Ȃ��Bcontinue ���ǂ����͏󋵂ɂ��B
	 */
	if (! CImeConfig::bSkkCompositionAutoShiftp (m_pConfig) && (m_dwUpdateFlag & IMEDOC_NEWLINE) == 0) 
		return	TRUE ;
	return	m_rpBuffer [0]->bUpdateContext () ;
}

void
CImeDoc::vUpdateConfig ()
{
	/*	Configuration �� Update �������̂ŁA������Ԃɖ߂��BRuleTree �����ǂ��Ă���r���� 
	 *	RuleTree ���X�V���ꂽ�肷��Ɨ����邵���Ȃ����B
	 */
//	_vUninitConfig () ;
	vClear () ;
	return ;
}

BOOL
CImeDoc::bRevertText ()
{
	int		nConversionMode ;

	/*	�e�L�X�g��S�L�����Z���B���̏ꍇ�͑S buffer �� clear ����
	 *	stack �����������āAmessage-loop �� pointer ��߂��΂����̂��B
	 */
	nConversionMode	= m_rpBuffer [0]->iGetConversionMode () ;
	vClear () ;
	/*	Clear ��Ԃ���� SetConversionMode �͗e�ՁB
	 */
	m_rpBuffer [0]->bSetConversionMode (nConversionMode) ;
	return	TRUE ;
}

BOOL
CImeDoc::bCompleteText ()
{
	CImeBuffer*		pBuffer ;
	struct TMSG		msg ;
	int				nLoop, nConversionMode ;

	/*	�e�L�X�g��S�m��B(������ top �ȊO�� cancel ��)
	 *	safety �̂��߂ɍő僋�[�v�񐔂�ݒ肵�Ă����B
	 */
	for (nLoop = NLOOP_IMEDOC ; nLoop > 0 ; nLoop --) {
		pBuffer	= pGetCurrentBuffer () ;
		if (pBuffer->bInputByCodeOrMenuModep () ||
			pBuffer->bShowHenkanCandidatesModep ()) {
			/*	�L�����Z���̃L�[��p�ӁB
			 *	�{���� keyboard-quit �� abort-recursive-edit �����蓖�Ă��Ă���
			 *	key �Ȃ�� cancel �Ƃ��ē��삷��Ƃ����R�[�h�ɂ��Ȃ���΂Ȃ�Ȃ�
			 *	 > input-by-code-or-menu �� henkan-show-candidates
			 */
			msg.m_nMessage	= WM_CHAR ;
			msg.m_wParam	= 0x07 ;			/*,.. */
			msg.m_lParam	= 0 ;
			msg.m_rParam	= 0 ;
			msg.m_nTime		= GetTickCount () ;
			msg.m_pt.x		= msg.m_pt.y	= 0 ;
		} else {
			if (! bRecursiveEditp ())
				break ;

			if (! bWhereIsInternal (NFUNC_ABORT_RECURSIVE_EDIT, &msg)) {
				/* �d���Ȃ��̂ŁA�����O���R�}���h�𔭍s����B*/
				msg.m_nMessage	= WM_LM_COMMAND ;
				msg.m_nTime		= GetTickCount () ;
				msg.m_wParam	= NFUNC_ABORT_RECURSIVE_EDIT ;
				msg.m_lParam	= 0 ;
				msg.m_rParam	= 0 ;
				msg.m_pt.x		= msg.m_pt.y	= 0 ;
			}
		} 
		if (! bPushEvent (&msg) || 
			! _bTick ()) {
			/*	����̓N���e�B�J���ȁc�󋵂Ȃ̂ŁA�������������B
			 */
			vClear () ;
			goto	exit_func ;
		}
	}

	pBuffer	= pGetCurrentBuffer () ;
	if (pBuffer->bInputByCodeOrMenuModep () ||
		pBuffer->bShowHenkanCandidatesModep () ||
		bRecursiveEditp () ||
		m_pPC != CImeDoc::LM_iMessageLoop) {
		vClear () ;
		goto	exit_func ;
	}
	/*	���̒i�K�� topbuffer �ɓ��B���Ă��锤�B
	 *	�m�肵�Ă���A���̓��[�h�̒�������킹��B
	 */
	pBuffer	= pGetCurrentBuffer () ;
	nConversionMode		= pBuffer->iGetConversionMode  () ;
	if (! bWhereIsInternal (NFUNC_SKK_KAKUTEI, &msg)) {
		msg.m_nMessage	= WM_LM_COMMAND ;
		msg.m_nTime		= GetTickCount () ;
		msg.m_wParam	= NFUNC_SKK_KAKUTEI ;
		msg.m_lParam	= 0 ;
		msg.m_pt.x		= msg.m_pt.y	= 0 ;
	}
	if (! bPushEvent (&msg) || 
		! _bTick ()) {
		vClear () ;
		goto	exit_func ;
	}
	pBuffer->bSetConversionMode (nConversionMode) ;

	/*	���̏�Ԃ� buffer-string �𓾂āA���ꂩ�� clear ����Ηǂ��B
	 */
exit_func:
	return	TRUE ;
}

void
CImeDoc::vSetUpdateFlag (
	unsigned int		uFlag)
{
	if ((uFlag & IMEDOC_CLOSE_CANDIDATELIST) != 0 && (uFlag & IMEDOC_CREATE_CANDIDATELIST) != 0) {
		/* �쐬�Ɣj���͓����ɂ͂ł��Ȃ��B*/
		uFlag	&= ~IMEDOC_CREATE_CANDIDATELIST ;
	}
	if ((uFlag & IMEDOC_CLOSE_CANDIDATELIST) != 0) {
		/*	�ŏI�I�� CANDIDATELIST ���j�������̂Ȃ�A�r���� CREATE �͈Ӗ����Ȃ��Ȃ��B
		 */
		m_dwUpdateFlag	&= ~(IMEDOC_CREATE_CANDIDATELIST | IMEDOC_UPDATE_CANDIDATELIST) ;
	}

	/*	����ɂ�� CREATE_CANDIDATELIST �� CLOSE_CANDIDATELIST �������ɑ��݂���̂�
	 *	CLOSE -> CREATE �̏��ԂŎ��s���ꂽ�������ł���B
	 */
	m_dwUpdateFlag	|= uFlag ;
	return ;
}

void
CImeDoc::vClearUpdateFlag ()
{
	m_dwUpdateFlag	= 0 ;
	return ;
}

unsigned int
CImeDoc::uGetUpdateFlag ()
{
	return	m_dwUpdateFlag ;
}

BOOL
CImeDoc::bShowHenkanCandidatesModep () const
{
	if (m_pCurBuffer == NULL)
		return	FALSE ;
	return	m_pCurBuffer->bShowHenkanCandidatesModep  () ;
}

BOOL
CImeDoc::bInputByCodeOrMenuModep (
	BOOL*				pbMenu1p) const
{
	if (m_pCurBuffer == NULL)
		return	FALSE ;
	if (! m_pCurBuffer->bInputByCodeOrMenuModep  ())
		return	FALSE ;
	if (pbMenu1p != NULL) {
		/* MenuJump or Menu1Jump */
		*pbMenu1p	= m_pCurBuffer->bInputByCodeOrMenu1Modep  () ;
	}
	return	TRUE ;
}

/*	�܂����g�͂Ȃ��B��B
 *	����̓���́A��������o���ݒ�ɂ���ĕω�����B��������o�����ƁA���}�[�N�Ȃ��ɂ͓����Ȃ���
 *	�Ȃ��Ȃ�ʂɂ����B
 */
BOOL
CImeDoc::bSetReconvertText (
	LPCDSTR				wstrText,
	int					nTextLen)
{
	vClear () ;
	return	m_rpBuffer [0]->bSetReconvertText (wstrText, nTextLen) ;
}

IMECANDIDATES*
CImeDoc::pGetCandidateInfo ()
{
	return	&m_CandInfo ;
}

void
CImeDoc::vClearCandidateInfo ()
{
	m_CandInfo.vClear () ;
	return ;
}

int
CImeDoc::iGetCandidateText (
	LPDSTR					strDest,
	int						nDest,
	TEXTREGION*				pTextHead,
	int*					piNumText,
	const IMECANDIDATES*	pMyCand)
{
	LPDSTR		pDest ;
	int			iCount, nKeys, iNumText, nTotalCandLen ;
	UINT		iPageStart, iNextPage, iMaxPage, i ;
	TEXTREGION*	pText ;
	TEXTREGION*	pTextLast ;
	const UINT*	piPageIndex ;
	DCHAR		ch ;
	LPCDSTR		pCandKeyTbl ;
	LPCDSTR		pwCandBase ;
	const UINT*	puCandIndexBase ;
	const UINT*	puAnnoIndexBase ;

	pDest		= strDest ;
	iCount		= 0 ;
	piPageIndex	= pMyCand->m_vbufPageIndex.pGetBuffer () ;
	iMaxPage	= pMyCand->m_vbufPageIndex.iGetUsage () ;
	iPageStart	= piPageIndex [pMyCand->m_iCurrentPage] ;
	iNextPage	= ((pMyCand->m_iCurrentPage + 1) < iMaxPage)? (piPageIndex [pMyCand->m_iCurrentPage + 1]) : pMyCand->m_iCount ;
	i			= iPageStart ;
	pCandKeyTbl	= CImeConfig::pGetSkkHenkanShowCandidatesKeys (m_pConfig, &nKeys) ;

	iNumText	= (piNumText != NULL)? *piNumText : 0 ;
	pText		= pTextHead ;
	if (piNumText != NULL && pText != NULL) {
		pTextLast	= pText + iNumText ;
	} else {
		pTextLast	= NULL ;
	}
	

#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPDSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		dcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}
#define	SAFE_COPY2(dest,ndest,src,nsrc) { \
	LPDSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int     _n      = 0 ; \
	if (_nSrc > 0) { \
		_n = wcstodcs (_pDest, _nDest, (src), _nSrc) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	pwCandBase		= pMyCand->m_vbufCandidate.pGetBuffer () ;
	nTotalCandLen	= pMyCand->m_vbufCandidate.iGetUsage () ;
	puCandIndexBase	= pMyCand->m_vbufCandidateIndex.pGetBuffer () ;
	puAnnoIndexBase	= pMyCand->m_vbufAnnotationIndex.pGetBuffer () ;
	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < iNextPage && i < pMyCand->m_iCount && iCount < nKeys && nDest > 0) {
		LPCDSTR		pwCandidate ;
		int			nAnnotationIndex, nCandLen ;

		ch			= *(pCandKeyTbl + iCount) ;
		SAFE_COPY  (pDest, nDest, &ch, 1) ;
		SAFE_COPY2 (pDest, nDest, L":", 1) ;

		pwCandidate	= pwCandBase + *(puCandIndexBase + i) ;
		nCandLen	= dcslen (pwCandidate) ;
		nAnnotationIndex	= (i < (UINT)pMyCand->m_vbufAnnotationIndex.iGetUsage ())? *(puAnnoIndexBase + i) : 0 ;

		/*	���� annotation �����݂���ꍇ�B*/
		if (pText != NULL && pText < pTextLast) {
			if (nDest > 0 && nAnnotationIndex > 0 && nAnnotationIndex < nTotalCandLen && dcslen (pwCandBase + nAnnotationIndex) > 0) {
				pText->m_nCandidate	= i ;
				pText->m_nOffset	= pDest - strDest ;
				pText->m_nLength	= (nDest < nCandLen)? nDest : nCandLen ;
			} else {
				pText->m_nCandidate	= 0 ;
				pText->m_nOffset	= 0 ;
				pText->m_nLength	= 0 ;
			}
			pText	++ ;
		}
		SAFE_COPY  (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY2 (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
	if (nDest > 0) {
		WCHAR	buffer [32] ;
		int		n ;

		/*	+ �\�����t���悤�ɂȂ�̂��ǂ����͖���B
		 */
		n	= wnsprintfW (buffer, MYARRAYSIZE (buffer), L" [�c�� %d]", pMyCand->m_iCount - i) ;
		SAFE_COPY2 (pDest, nDest, buffer, n) ;
	}
	if (pText != NULL && piNumText != NULL)
		*piNumText	= pText - pTextHead ;

#undef	SAFE_COPY
#undef	SAFE_COPY2
	return	(pDest - strDest) ;
}

int
CImeDoc::iGetCodeMenuJumpText (
	LPDSTR					strDest,
	int						nDest,
	const IMECANDIDATES*	pMyCand)
{
	LPDSTR		pDest ;
	int			iCount, nKeys ;
	UINT		iPageStart, iNextPage, iMaxPage, i ;
	const UINT*	piPageIndex ;
	DCHAR		ch ;
	LPCDSTR		pCandKeyTbl ;

	pDest		= strDest ;
	iCount		= 0 ;
	piPageIndex	= pMyCand->m_vbufPageIndex.pGetBuffer () ;
	iMaxPage	= pMyCand->m_vbufPageIndex.iGetUsage () ;
	iPageStart	= piPageIndex [pMyCand->m_iCurrentPage] ;
	iNextPage	= ((pMyCand->m_iCurrentPage + 1) < iMaxPage)? (piPageIndex [pMyCand->m_iCurrentPage + 1]) : pMyCand->m_iCount ;
	i			= iPageStart ;
	pCandKeyTbl	= CImeConfig::pGetSkkInputByCodeMenuKeys1 (m_pConfig, &nKeys) ;
	

#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPDSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		dcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}
#define	SAFE_COPY2(dest,ndest,src,nsrc) { \
	LPDSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int     _n      = 0 ; \
	if (_nSrc > 0) { \
		_n = wcstodcs (_pDest, _nDest, (src), _nSrc) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < iNextPage && i < pMyCand->m_iCount && iCount < nKeys && nDest > 0) {
		LPCDSTR		pwCandidate ;
		int			nCandLen ;

		ch			= *(pCandKeyTbl + iCount) ;
		SAFE_COPY  (pDest, nDest, &ch, 1) ;
		SAFE_COPY2 (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCDSTR)pMyCand->m_vbufCandidate.pGetBuffer () + *(pMyCand->m_vbufCandidateIndex.pGetBuffer () + i) ;
		nCandLen	= dcslen (pwCandidate) ;

		SAFE_COPY  (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY2 (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
#undef	SAFE_COPY
#undef	SAFE_COPY2
	return	(pDest - strDest) ;
}

int
CImeDoc::iGetCodeMenu1Text (
	LPDSTR					strDest,
	int						nDest,
	const IMECANDIDATES*	pMyCand)
{
	LPDSTR		pDest ;
	int			iCount, nKeys ;
	UINT		iPageStart, iNextPage, iMaxPage, i ;
	const UINT*	piPageIndex ;
	DCHAR		ch ;
	LPCDSTR		pCandKeyTbl ;

	pDest		= strDest ;
	iCount		= 0 ;
	piPageIndex	= pMyCand->m_vbufPageIndex.pGetBuffer () ;
	iMaxPage	= pMyCand->m_vbufPageIndex.iGetUsage () ;
	iPageStart	= piPageIndex [pMyCand->m_iCurrentPage] ;
	iNextPage	= ((pMyCand->m_iCurrentPage + 1) < iMaxPage)? (piPageIndex [pMyCand->m_iCurrentPage + 1]) : pMyCand->m_iCount ;
	i			= iPageStart ;
	pCandKeyTbl	= CImeConfig::pGetSkkInputByCodeMenuKeys2 (m_pConfig, &nKeys) ;
	
#define	SAFE_COPY(dest,ndest,src,nsrc)	{ \
	LPDSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int		_n		= (_nDest < _nSrc)? _nDest : _nSrc ; \
	if (_n > 0) { \
		dcsncpy (_pDest, (src), _n) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}
#define	SAFE_COPY2(dest,ndest,src,nsrc) { \
	LPDSTR	_pDest	= (dest) ;	\
	int		_nDest	= (ndest) ; \
	int		_nSrc	= (nsrc) ; \
	int     _n      = 0 ; \
	if (_nSrc > 0) { \
		_n = wcstodcs (_pDest, _nDest, (src), _nSrc) ;	\
		_pDest	+= _n ;	\
		_nDest	-= _n ;	\
		(dest)	= _pDest ;	\
		(ndest)	= _nDest ;	\
	}	\
}

	/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
	while (i < iNextPage && i < pMyCand->m_iCount && iCount < nKeys && nDest > 0) {
		LPCDSTR		pwCandidate ;
		int			nCandLen ;

		ch			= *(pCandKeyTbl + iCount) ;
		SAFE_COPY (pDest, nDest, &ch, 1) ;
		SAFE_COPY2 (pDest, nDest, L":", 1) ;

		pwCandidate	= (LPCDSTR)pMyCand->m_vbufCandidate.pGetBuffer () + *((const int*)pMyCand->m_vbufCandidateIndex.pGetBuffer () + i) ;
		nCandLen	= dcslen (pwCandidate) ;

		SAFE_COPY  (pDest, nDest, pwCandidate, nCandLen) ;
		SAFE_COPY2 (pDest, nDest, L" ", 1) ;
		iCount	++ ;
		i		++ ;
	}
#undef	SAFE_COPY
#undef	SAFE_COPY2
	return	(pDest - strDest) ;
}

BOOL
CImeDoc::bHaveMessagep () const
{
	return	m_nbufMessage > 0 ;
}

LPCDSTR
CImeDoc::pGetMessage (int* piLength) const 
{
	if (piLength != NULL)
		*piLength	= m_nbufMessage ;
	return	m_bufMessage ;
}

/*========================================================================
 *	public functions (ImeDoc internal)
 */
BOOL
CImeDoc::bSkkPreviousCandidateCharp	(
	int						nCH)
{
	struct TMSG		msg ;
	int				nFunc ;

	msg.m_nMessage	= WM_CHAR ;
	msg.m_wParam	= nCH ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= 0 ;
	msg.m_pt.y		= 0 ;

	if (bLookupKeymap (&msg, &nFunc))
		return	(nFunc == NFUNC_SKK_PREVIOUS_CANDIDATE) ;

	return	FALSE ;
}

/*========================================================================
 *	public functions (ImeDoc internal)
 */
void
CImeDoc::vSetCurrentBuffer (
	CImeBuffer*		pBuffer)
{
	m_pCurBuffer	= pBuffer ;
	return ;
}

CImeBuffer*
CImeDoc::pGetCurrentBuffer ()
{
	return	m_pCurBuffer ;
}

BOOL
CImeDoc::bSetMessage (
	LPCDSTR					wstrMessage)
{
	if (wstrMessage == NULL)
		return	FALSE ;
	return	bSetMessageN (wstrMessage, dcslen (wstrMessage)) ;
}

BOOL
CImeDoc::bSetMessageN (
	LPCDSTR					wstrMessage,
	int						nstrMessage)
{
	ASSERT (wstrMessage != NULL || nstrMessage == 0) ;

	m_nbufMessage	= (nstrMessage > MSGBUFSIZE)? MSGBUFSIZE : nstrMessage ;
	if (wstrMessage != NULL)
		memcpy (m_bufMessage, wstrMessage, m_nbufMessage * sizeof (DCHAR)) ;

	return	TRUE ;
}

BOOL
CImeDoc::bSetMessage (
	LPCWSTR					wstrMessage)
{
	if (wstrMessage == NULL)
		return	FALSE ;
	wcstodcs (m_bufMessage, MYARRAYSIZE (m_bufMessage), wstrMessage, lstrlenW (wstrMessage)) ;
	return	TRUE ;
}

void
CImeDoc::vClearMessage ()
{
	m_nbufMessage		= 0 ;
	return ;
}

BOOL
CImeDoc::bGetLastCommandChar (
	DCHAR*						pwCH)
{
	int		iCH ;

	/* printable �łȂ��ꍇ�ɂ� false ��Ԃ��B*/
	iCH	= iGetCharFromEvent (&m_LastEvent) ;
	if (! (0x20 <= iCH && iCH < 0x7F)) {
		if (! CImeConfig::bSkkSpecialMidashiCharp		(m_pConfig, iCH) && 
			! CImeConfig::bSkkSetHenkanPointKeyp		(m_pConfig, iCH) &&
			! CImeConfig::bSkkStartHenkanCharp			(m_pConfig, iCH) &&
			! CImeConfig::bSkkTryCompletionCharp		(m_pConfig, iCH) &&
			! CImeConfig::bSkkNextCompletionCharp		(m_pConfig, iCH) &&
			! CImeConfig::bSkkPreviousCompletionCharp	(m_pConfig, iCH)) {
			return	FALSE ;
		}
	}
	if (pwCH != NULL)
		*pwCH	= (DCHAR) iCH ;
	return	TRUE ;
}

BOOL
CImeDoc::bUnprocessEvent (
	const struct TMSG*			pMsg)
{
	if (pMsg != NULL) {
		m_UnprocessEvent	= *pMsg ;
	} else {
		m_UnprocessEvent.m_nMessage	= WM_NULL ;
	}
	return	TRUE ;
}

BOOL
CImeDoc::bPushEvent (
	const struct TMSG*		pMSG)
{
	if (pMSG == NULL)
		return	FALSE ;
	if (m_nUnreadMessages >= MYARRAYSIZE (m_rMessages)) {
		return	FALSE ;
	}
	m_rMessages [m_nUnreadMessages ++]	= *pMSG ;
	return	TRUE ;
}

int
CImeDoc::nGetSignal () const
{
	return	m_nSignal ;
}

void
CImeDoc::vSetSignal (
	int							nSignal)
{
	m_nSignal	= nSignal ;
	return ;
}

BOOL
CImeDoc::bSignalp () const
{
	return	(m_nSignal != LMSIGNAL_NONE) ;
}

void
CImeDoc::vSetSignalError ()
{
	m_nSignal	= LMSIGNAL_ERROR ;
	return ;
}

BOOL
CImeDoc::bSignalMinibuffp () const
{
	/* minibuffer �𔲂��� signal �������Ă���Ύ�芸���� TRUE ��Ԃ��B*/
	return	(m_nSignal == LMSIGNAL_EXIT_MINIBUFFER || m_nSignal == LMSIGNAL_ABORT_RECURSIVE_EDIT) ;
}

BOOL
CImeDoc::bSignalAbortMinibuffp () const
{
	return	(m_nSignal == LMSIGNAL_ABORT_RECURSIVE_EDIT) ;
}

void
CImeDoc::vClearSignals ()
{
	m_nSignal			= LMSIGNAL_NONE ;
	return ;
}

void
CImeDoc::vJump (
	PLMFUNC					pNextState)
{
	m_pPC					= pNextState ;
	return ;
}

BOOL
CImeDoc::bCall (
	PLMFUNC					pNextState,
	PLMFUNC					pReturnState)
{
	int		nPos ;

	if (m_nRetPC >= MYARRAYSIZE (m_rpRetPC))
		return	FALSE ;
	nPos				= m_nRetPC ++ ;
	m_rpRetPC    [nPos]	= pReturnState ;
	m_rnStackPos [nPos]	= m_nStackHead ;
	m_pPC				= pNextState ;
	return	TRUE ;
}

BOOL
CImeDoc::bInteractivep () const
{
	if (m_nRetPC > 0 && m_rpRetPC [m_nRetPC-1] == CImeDoc::LM_iPostMessageLoop)
		return	TRUE ;
	return	FALSE ;
}

void*
CImeDoc::pAlloca (
	int						nSize,
	int						nAlign) 
{
	LPBYTE		pbAddress ;
	LPBYTE		pbNextAddress ;
	void*		pvRetval ;
	int			nSkip ;

	if (nSize <= 0 || nAlign <= 0)
		return	NULL ;

	pbAddress			= m_pbStackArea + m_nStackHead ;
#pragma warning (push)
#pragma warning (disable : 4311)
	/*	BYTE* ���� DWORD �ɐ؂�l�߂Ă���̂́A������������Ɏv�����Ȃ��̂Łc�B
	 */
	nSkip				= nAlign - ((DWORD) pbAddress & (nAlign - 1)) ;
#pragma warning (pop)
	pvRetval			= pbAddress + nSkip ;
	pbNextAddress		= pbAddress + nSkip + nSize ;
	if (pbNextAddress > (m_pbStackArea + m_nStackAreaSize)) 
		return	NULL ;
	m_nStackHead	+= nSkip + nSize ;
	return	pvRetval ;
}

void
CImeDoc::vSetRegBool (
	int						nReg,
	BOOL					bValue)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	m_rREGS [nReg].m_nType		= LMREGTYPE_BOOL ;
	m_rREGS [nReg].m_value.m_bool	= bValue ;
	return ;
}

void
CImeDoc::vSetRegString (
	int						nReg,
	LPDSTR					pwString,
	int						nStringLen)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	m_rREGS [nReg].m_nType	= LMREGTYPE_STRING ;
	m_rREGS [nReg].m_value.m_string.m_pointer	= pwString ;
	m_rREGS [nReg].m_value.m_string.m_length	= nStringLen ;
	return ;
}


void
CImeDoc::vSetRegConstString (
	int						nReg,
	LPCDSTR					pwString,
	int						nStringLen)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	m_rREGS [nReg].m_nType	= LMREGTYPE_CONST_STRING ;
	m_rREGS [nReg].m_value.m_cstring.m_pointer	= pwString ;
	m_rREGS [nReg].m_value.m_cstring.m_length	= nStringLen ;
	return ;
}

void
CImeDoc::vSetRegInteger (
	int						nReg,
	int						nValue)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	m_rREGS [nReg].m_nType	= LMREGTYPE_INTEGER ;
	m_rREGS [nReg].m_value.m_integer	= nValue ;
	return ;
}

void
CImeDoc::vSetRegPointer (
	int						nReg,
	void*					pvValue)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	m_rREGS [nReg].m_nType	= LMREGTYPE_POINTER ;
	m_rREGS [nReg].m_value.m_pointer	= pvValue ;
	return ;
}

void
CImeDoc::vSetRegConstPointer (
	int						nReg,
	const void*				pvValue)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	m_rREGS [nReg].m_nType	= LMREGTYPE_CONST_POINTER ;
	m_rREGS [nReg].m_value.m_const_pointer	= pvValue ;
	return ;
}

void
CImeDoc::vSetRegMsg (
	int						nReg,
	const struct TMSG*		pMsg)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (pMsg == NULL)
		return ;
	m_rREGS [nReg].m_nType			= LMREGTYPE_MESSAGE ;
	m_rREGS [nReg].m_value.m_msg	= *pMsg ;
	return ;
}

void
CImeDoc::vSetRegNil (
	int						nReg)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	m_rREGS [nReg].m_nType		= LMREGTYPE_NIL ;
	return ;
}

struct CImeDoc::LMREG*
CImeDoc::pGetRegValue (
	int						nReg)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	return	m_rREGS + nReg ;
}

BOOL
CImeDoc::bGetRegBool (
	int						nReg,
	BOOL*					pfRetval)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (m_rREGS [nReg].m_nType == LMREGTYPE_BOOL) {
		if (pfRetval != NULL)
			*pfRetval	= m_rREGS [nReg].m_value.m_bool ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeDoc::bGetRegInteger (
	int						nReg,
	int*					piRetval)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (m_rREGS [nReg].m_nType == LMREGTYPE_INTEGER) {
		if (piRetval != NULL)
			*piRetval	= m_rREGS [nReg].m_value.m_integer ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeDoc::bGetRegString (
	int						nReg,
	LPDSTR*					ppwString,
	int*					pnStringLen)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (m_rREGS [nReg].m_nType == LMREGTYPE_STRING) {
		if (ppwString != NULL)
			*ppwString	= m_rREGS [nReg].m_value.m_string.m_pointer ;
		if (pnStringLen != NULL)
			*pnStringLen	= m_rREGS [nReg].m_value.m_string.m_length ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeDoc::bGetRegConstString (
	int						nReg,
	LPCDSTR*				ppwString,
	int*					pnStringLen)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	if (m_rREGS [nReg].m_nType == LMREGTYPE_CONST_STRING) {
		if (ppwString != NULL)
			*ppwString	= m_rREGS [nReg].m_value.m_cstring.m_pointer ;
		if (pnStringLen != NULL)
			*pnStringLen	= m_rREGS [nReg].m_value.m_cstring.m_length ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeDoc::bGetRegConstStringPair (
	int						nReg,
	LPCDSTR*				ppwLeft,
	int*					pnLeftLen,
	LPCDSTR*				ppwRight,
	int*					pnRightLen)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (m_rREGS [nReg].m_nType != LMREGTYPE_CONST_STRINGPAIR) 
		return	FALSE ;
	if (ppwLeft != NULL)
		*ppwLeft	= m_rREGS [nReg].m_value.m_cstringpair.m_left ;
	if (pnLeftLen != NULL)
		*pnLeftLen	= m_rREGS [nReg].m_value.m_cstringpair.m_nleft ;
	if (ppwRight != NULL)
		*ppwRight	= m_rREGS [nReg].m_value.m_cstringpair.m_right ;
	if (pnRightLen != NULL)
		*pnRightLen	= m_rREGS [nReg].m_value.m_cstringpair.m_nright ;
	return	TRUE ;
}

BOOL
CImeDoc::bGetRegPointer (
	int						nReg,
	void**					ppvRetval)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (m_rREGS [nReg].m_nType == LMREGTYPE_POINTER) {
		if (ppvRetval != NULL)
			*ppvRetval	= m_rREGS [nReg].m_value.m_pointer ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeDoc::bGetRegConstPointer (
	int						nReg,
	const void**			ppvRetval)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (m_rREGS [nReg].m_nType == LMREGTYPE_CONST_POINTER) {
		if (ppvRetval != NULL)
			*ppvRetval	= m_rREGS [nReg].m_value.m_const_pointer ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeDoc::bGetRegMsg (
	int						nReg,
	struct TMSG*			pMsg)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (m_rREGS [nReg].m_nType == LMREGTYPE_MESSAGE) {
		if (pMsg != NULL)
			*pMsg	= m_rREGS [nReg].m_value.m_msg ;
		return	TRUE ;
	} else {
		return	FALSE ;
	}
}

BOOL
CImeDoc::bIsRegNilp (
	int						nReg) const
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	return	(m_rREGS [nReg].m_nType == LMREGTYPE_NIL) ;
}

BOOL
CImeDoc::bPushReg (
	int						nReg)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;

	if (m_nRegStackHead >= NSIZE_REGSTACK)
		return	FALSE ;
	m_pRegStack [m_nRegStackHead ++]	= m_rREGS [nReg] ;
	return	TRUE ;
}

void
CImeDoc::vPopReg (
	int						nReg)
{
	ASSERT (0 <= nReg && nReg < MAX_REGS) ;
	ASSERT (m_nRegStackHead > 0) ;

	m_rREGS [nReg]	= m_pRegStack [-- m_nRegStackHead] ;
	return ;
}

LPDSTR
CImeDoc::pGetReturnBuffer (
	int*					pnRetbufSize)
{
	if (pnRetbufSize != NULL)
		*pnRetbufSize	= MYARRAYSIZE (m_bufRETURN) ;
	return	m_bufRETURN ;
}

int
CImeDoc::iGetMinibufferDepth () const
{
	CImeBuffer*	pBuffer	= m_pCurBuffer ;
	CImeBuffer*	pParent ;
	int			iDepth	= 0 ;

	if (pBuffer == NULL)
		return	0 ;

	while (pParent = pBuffer->pGetParent (), pParent != NULL) {
		pBuffer	= pParent ;
		iDepth	++ ;
	}
	return	iDepth ;
}

/*========================================================================
 *		state machine mainloop
 */
/*
 */
BOOL
CImeDoc::_bTick ()
{
	int		nRetval ;

	while (m_pPC != NULL) {
		nRetval		= (*m_pPC)(this) ;
		switch (nRetval) {
		case	LMR_STOP:
			goto	exit_loop ;
		case	LMR_RETURN:
			if (m_nRetPC <= 0) {
				/* fatal error */
				return	FALSE ;
			}
			-- m_nRetPC ;
			m_nStackHead	= m_rnStackPos	[m_nRetPC] ;
			m_pPC			= m_rpRetPC		[m_nRetPC] ;
			break ;
		case	LMR_ERROR:
			/* fatal error */
			return	FALSE ;
		case	LMR_CONTINUE:
		default:
			break ;
		}
	}
exit_loop:
	return	TRUE ;
}

/*========================================================================
 *	
 */
int
CImeDoc::iGetLastCommand () const
{
	return	m_iLastCommand ; 
}

int
CImeDoc::iGetThisCommand () const
{
	return	m_iThisCommand ;
}

BOOL
CImeDoc::bSetThisCommand (
	int							nFuncNo)
{
	m_iThisCommand	= nFuncNo ;
	return	TRUE ;
}

BOOL
CImeDoc::bSetLastCommand (
	int							nFuncNo)
{
	m_iLastCommand	= nFuncNo ;
	return	TRUE ;
}

int
CImeDoc::iGetLastCommandChar ()
{
	return	m_iLastCommandChar ;
}

BOOL
CImeDoc::bSetLastCommandChar (
	int							nCH)
{
	m_iLastCommandChar		= nCH ;

	/* last-command-event �𓯊�������c����ŗǂ��̂��H */
	m_LastEvent.m_nMessage	= WM_CHAR ;
	m_LastEvent.m_wParam	= nCH ;
	m_LastEvent.m_lParam	= 0 ;
	m_LastEvent.m_rParam	= 0 ;
	m_LastEvent.m_nTime		= GetTickCount () ;
	m_LastEvent.m_pt.x		= 0 ;
	m_LastEvent.m_pt.y		= 0 ;
	return	TRUE ;
}

const struct TMSG*
CImeDoc::pGetLastCommandEvent () const
{
	return	&m_LastEvent ;
}

BOOL
CImeDoc::bSetUnreadCommandChar (
	int							ch)
{
	struct TMSG		msg ;

	msg.m_nMessage	= WM_CHAR ;
	msg.m_wParam	= ch ;
	msg.m_lParam	= 0 ;
	msg.m_rParam	= 0 ;
	msg.m_nTime		= GetTickCount () ;
	msg.m_pt.x		= 0 ;
	msg.m_pt.y		= 0 ;
	return	bPushEvent (&msg) ;
}

BOOL
CImeDoc::bSetUnreadCommandEvent (
	const struct TMSG*			pMsg)
{
	if (pMsg == NULL)
		return	FALSE ;

	return	bPushEvent (pMsg) ;
}

BOOL
CImeDoc::bLookupKeymap (
	const struct TMSG*			pEvent,
	int*						pnFuncNo)
{
	CImeBuffer*	pCurBuffer ;
	int		nFuncNo ;

	ASSERT (pEvent != NULL) ;

	/*	�@�\�𒼐ڎw�肳��Ă��܂����ꍇ�ɂ́c
	 */
	if (pEvent->m_nMessage == WM_LM_COMMAND) {
		*pnFuncNo	= (int) pEvent->m_wParam ;
		return	TRUE ;
	}

	pCurBuffer	= pGetCurrentBuffer () ;
	if (pCurBuffer == NULL || pnFuncNo == NULL)
		return	FALSE ;

	nFuncNo		= NFUNC_INVALID_CHAR ;
	/* minor-mode �� keymap �� check */
	if (nFuncNo == NFUNC_INVALID_CHAR && (pCurBuffer->bJModep  () || pCurBuffer->bJisx0201Modep ())) 
		_bLookupKeymap (CImeConfig::pGetSkkJModeMap (m_pConfig), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && pCurBuffer->bLatinModep  ()) 
		_bLookupKeymap (CImeConfig::pGetSkkLatinModeMap (m_pConfig), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && pCurBuffer->bJisx0208LatinModep  ()) 
		_bLookupKeymap (CImeConfig::pGetSkkJisx0208LatinModeMap (m_pConfig), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && pCurBuffer->bAbbrevModep  ()) 
		_bLookupKeymap (CImeConfig::pGetSkkAbbrevModeMap (m_pConfig), pEvent, &nFuncNo) ;
	if (nFuncNo == NFUNC_INVALID_CHAR && bRecursiveEditp ()) 
		_bLookupKeymap (CImeConfig::pGetMinibufferMinorModeMap (m_pConfig), pEvent, &nFuncNo) ;
	/* major-mode �� keymap �� check */
	if (nFuncNo == NFUNC_INVALID_CHAR) 
		_bLookupKeymap (CImeConfig::pGetMajorModeMap (m_pConfig), pEvent, &nFuncNo) ;
	*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

BOOL
CImeDoc::bWhereIsInternal (
	int							nFuncNo,
	struct TMSG*				pEvent)
{
	CImeBuffer*	pCurBuffer ;

	if (m_pCurBuffer == NULL)
		return	FALSE ;
	pCurBuffer	= m_pCurBuffer ;
	if ((pCurBuffer->bJModep () || pCurBuffer->bJisx0201Modep ()) &&
		_bWhereIsInternal (CImeConfig::pGetSkkJModeMap (m_pConfig), nFuncNo, pEvent))
		return	TRUE ;
	if (pCurBuffer->bLatinModep  () &&
		_bWhereIsInternal (CImeConfig::pGetSkkLatinModeMap (m_pConfig), nFuncNo, pEvent))
		return	TRUE ;
	if (pCurBuffer->bJisx0208LatinModep  () &&
		_bWhereIsInternal (CImeConfig::pGetSkkJisx0208LatinModeMap (m_pConfig), nFuncNo, pEvent))
		return	TRUE ;
	if (pCurBuffer->bAbbrevModep  () &&
		_bWhereIsInternal (CImeConfig::pGetSkkAbbrevModeMap (m_pConfig), nFuncNo, pEvent))
		return	TRUE ;
	if (bRecursiveEditp () &&
		_bWhereIsInternal (CImeConfig::pGetMinibufferMinorModeMap (m_pConfig), nFuncNo, pEvent))
		return	TRUE ;
	if (_bWhereIsInternal (CImeConfig::pGetMajorModeMap (m_pConfig), nFuncNo, pEvent))
		return	TRUE ;
	return	FALSE ;
}

BOOL
CImeDoc::bLookupMajorKeymap (
	const struct TMSG*			pEvent,
	int*						pnFuncNo)
{
	CImeBuffer*	pCurBuffer ;
	int			nFuncNo ;

	/*	�@�\�𒼐ڎw�肳��Ă��܂����ꍇ�ɂ́c
	 */
	if (pEvent->m_nMessage == WM_LM_COMMAND) {
		*pnFuncNo	= (int) pEvent->m_wParam ;
		return	TRUE ;
	}

	pCurBuffer	= pGetCurrentBuffer () ;
	if (pCurBuffer == NULL || pnFuncNo == NULL)
		return	FALSE ;

	if (! _bLookupKeymap (CImeConfig::pGetMajorModeMap (m_pConfig), pEvent, &nFuncNo)) {
		*pnFuncNo	= NFUNC_INVALID_CHAR ;
		return	TRUE ;
	}
	*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

PLMFUNC
CImeDoc::pLookupLMState (
	int						nFuncNo)
{
	PLMFUNC	pPC	= NULL ;

	switch (nFuncNo) {
	case	NFUNC_SELF_INSERT_CHARACTER:
		pPC	= CImeDoc::LM_bSelfInsertCharacter ;
		break ;
	case	NFUNC_BACKWARD_CHAR:
		pPC	= CImeDoc::LM_bBackwardChar ;
		break ;
	case	NFUNC_FORWARD_CHAR:
		pPC	= CImeDoc::LM_bForwardChar ;
		break ;
	case	NFUNC_DELETE_CHAR:
		pPC	= CImeDoc::LM_bDeleteChar ;
		break ;
	case	NFUNC_BACKWARD_DELETE_CHAR:
		pPC	= CImeDoc::LM_bBackwardDeleteChar ;
		break ;
	case	NFUNC_TRANSPOSE_CHARS:
		pPC	= CImeDoc::LM_bTransposeChars ;
		break ;
	case	NFUNC_END_OF_LINE:
		pPC	= CImeDoc::LM_bEndOfLine ;
		break ;
	case	NFUNC_BEGINNING_OF_LINE:
		pPC	= CImeDoc::LM_bBeginningOfLine ;
		break ;
	case	NFUNC_SET_MARK_COMMAND:
		pPC	= CImeDoc::LM_bSetMarkCommand ;
		break ;
	case	NFUNC_KEYBOARD_QUIT:
		pPC	= CImeDoc::LM_bKeyboardQuit ;
		break ;
	case	NFUNC_SKK_INSERT:
//		pPC	= CImeDoc::LM_bSkkInsert ;
		pPC	= CImeDoc::LM_bSkkInsertAdJisx0201 ;
		break ;
	case	NFUNC_SKK_PREVIOUS_CANDIDATE:
		pPC	= CImeDoc::LM_bSkkPreviousCandidate ;
		break ;
	case	NFUNC_EXIT_RECURSIVE_EDIT:
		pPC	= CImeDoc::LM_bExitRecursiveEdit ;
		break ;
	case	NFUNC_ABORT_RECURSIVE_EDIT:
		pPC	= CImeDoc::LM_bAbortRecursiveEdit ;
		break ;
	case	NFUNC_SKK_MODE:
//		pPC	= CImeDoc::LM_bSkkMode ;
		pPC	= CImeDoc::LM_bSkkModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_KAKUTEI:
//		pPC	= CImeDoc::LM_bSkkKakutei ;
		pPC	= CImeDoc::LM_bSkkKakuteiAdJisx0201 ;
		break ;
	case	NFUNC_SKK_START_HENKAN:
		pPC	= CImeDoc::LM_bSkkStartHenkan ;
		break ;
	case	NFUNC_SKK_SET_HENKAN_POINT_SUBR:
		pPC	= CImeDoc::LM_bSkkSetHenkanPointSubr ;
		break ;
	case	NFUNC_SKK_LATIN_MODE:
//		pPC	= CImeDoc::LM_bSkkLatinMode ;
		pPC	= CImeDoc::LM_bSkkLatinModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_JISX0208_LATIN_MODE:
//		pPC	= CImeDoc::LM_bSkkJisx0208LatinMode ;
		pPC	= CImeDoc::LM_bSkkJisx0208LatinModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_ABBREV_MODE:
//		pPC	= CImeDoc::LM_bSkkAbbrevMode ;
		pPC	= CImeDoc::LM_bSkkAbbrevModeAdJisx0201 ;
		break ;
	case	NFUNC_SKK_DELETE_BACKWARD_CHAR:
		pPC	= CImeDoc::LM_bSkkDeleteBackwardChar ;
		break ;
	case	NFUNC_NEWLINE:
		pPC	= CImeDoc::LM_bNewline ;
		break ;
	case	NFUNC_SKK_INPUT_BY_CODE_OR_MENU:
		pPC	= CImeDoc::LM_bSkkInputByCodeOrMenu ;
		break ;
	case	NFUNC_SKK_TRY_COMPLETION:
		pPC	= CImeDoc::LM_bSkkTryCompletion ;
		break ;
	case	NFUNC_SKK_ABBREV_COMMA:
		pPC	= CImeDoc::LM_bSkkAbbrevComma ;
		break ;
	case	NFUNC_SKK_ABBREV_PERIOD:
		pPC	= CImeDoc::LM_bSkkAbbrevPeriod ;
		break ;
	case	NFUNC_SKK_JISX0208_LATIN_INSERT:
		pPC	= CImeDoc::LM_bSkkJisx0208LatinInsert ;
		break ;
	case	NFUNC_SKK_TOGGLE_CHARACTERS:
		pPC	= CImeDoc::LM_bSkkToggleCharacters ;
		break ;
	case	NFUNC_SKK_TOGGLE_KUTOUTEN:
		pPC	= CImeDoc::LM_bSkkToggleKutouten ;
		break ;
	case	NFUNC_SKK_PURGE_FROM_JISYO:
		pPC	= CImeDoc::LM_bSkkPurgeFromJisyo ;
		break ;
	case	NFUNC_SKK_TODAY:
		pPC	= CImeDoc::LM_bSkkToday ;
		break ;
	case	NFUNC_SKK_TOGGLE_KATAKANA:
		pPC	= CImeDoc::LM_bSkkToggleKatakana ;
		break ;
	case	NFUNC_SKK_JISX0201_HENKAN:
		pPC	= CImeDoc::LM_bSkkJisx0201Henkan ;
		break ;
	case	NFUNC_SKK_JISX0201_MODE:
		pPC	= CImeDoc::LM_bSkkJisx0201Mode ;
		break ;
	case	NFUNC_SKK_TOGGLE_JISX0201:
		pPC	= CImeDoc::LM_bSkkToggleJisx0201 ;
		break ;

		/*----------------------------------------------------------------
		 *	������ interactive function �ł͂Ȃ��̂ŁA�Ăяo�����̈ʒu (message-loop���H)
		 *	�ɒ��ӂ��邱�ƁB
		 */
	case	NFUNC_SKK_CURRENT_KUTEN:
		pPC	= CImeDoc::LM_bSkkCurrentKuten ;
		break ;
	case	NFUNC_SKK_CURRENT_TOUTEN:
		pPC	= CImeDoc::LM_bSkkCurrentTouten ;
		break ;
		/*
		 *	�����܂�
		 *----------------------------------------------------------------
		 */
	case	NFUNC_KILL_REGION:
		pPC	= CImeDoc::LM_bKillRegion ;
		break ;
	case	NFUNC_KILL_RING_SAVE:
		pPC	= CImeDoc::LM_bKillRingSave ;
		break ;
	case	NFUNC_YANK:
		pPC	= CImeDoc::LM_bYank ;
		break ;
	case	NFUNC_BACKWARD_WORD:
		pPC	= CImeDoc::LM_bBackwardWord ;
		break ;
	case	NFUNC_FORWARD_WORD:
		pPC	= CImeDoc::LM_bForwardWord ;
		break ;

	case	NFUNC_MOUSE_DRAG_REGION:
		pPC	= CImeDoc::LM_bMouseDragRegion ;
		break ;
	case	NFUNC_MOUSE_DRAG_REGION_END:
		pPC	= CImeDoc::LM_bMouseDragRegionEnd ;
		break ;
	case	NFUNC_MOUSE_PASTE:
		pPC	= CImeDoc::LM_bMousePaste ;
		break ;
	case	NFUNC_MOUSE_CUT:
		pPC	= CImeDoc::LM_bMouseCut ;
		break ;
	case	NFUNC_MOUSE_COPY:
		pPC	= CImeDoc::LM_bMouseCopy ;
		break ;
	case	NFUNC_MOUSE_DELETE:
		pPC	= CImeDoc::LM_bMouseDelete ;
		break ;

	default:
		/* default �̓���B*/
		pPC	= CImeDoc::LM_bUnprecessEvent ;
		break ;
	}
	return	pPC ;
}

BOOL
CImeDoc::bIgnoreMessagep (
	const struct TMSG*				pEvent)
{
	if (pEvent == NULL)
		return	TRUE ;

	switch (pEvent->m_nMessage) {
	case	WM_KEYDOWN:
		{
			int		nVkCode			= (int) pEvent->m_wParam ;

			if (nVkCode == VK_SHIFT || nVkCode == VK_CONTROL || nVkCode == VK_RSHIFT || nVkCode == VK_RCONTROL)
				return	TRUE ;
		}
		break ;
	case	WM_IME_KEYDOWN:
		{
			/*
			 *		wParam
			 *			��� 16 �r�b�g�ɉ����ꂽ�����̕����R�[�h���A
			 *			���� 16 �r�b�g�ɉ����ꂽ�L�[�̉��z�L�[�R�[�h�������Ă��܂��B
			 *		lParam
			 *			WM_KEYDOWN �ɗ^������ lParam �Ɠ����ł��B
			 *		lpbKeyState
			 *			���݂̃L�[�{�[�h�̏�Ԃ��܂�256�o�C�g�̔z��ւ̃|�C���^�ł��B
			 *			IME �͂��̓��e��ύX���Ă͂����܂���B
			 */
			//int		nKeyCode		= HIWORD (pEvent->m_wParam) ;
			int		nVkCode			= LOWORD (pEvent->m_wParam) ;


			if (nVkCode == VK_SHIFT || nVkCode == VK_CONTROL || nVkCode == VK_RSHIFT || nVkCode == VK_RCONTROL)
				return	TRUE ;
		}
		break ;
	default:
		break ;
	}
	return	FALSE ;
}

/*	WPARAM ���� WCHAR ���쐬����BWCHAR �ɕϊ����邽�߂� WIN32API ��
 *	ToAscii �𗘗p���Ă���B
 *	ToAscii �ŕϊ��ł��Ȃ������ɑ΂��ẮA�ꕔ�� VK_XXX �������E����
 *	128 �ȏ�̃R�[�h�����蓖�Ă邱�ƂƂ��Ă���B
 */
int
CImeDoc::iGetCharFromEvent (
	const struct TMSG*				pEvent)
{
	static BYTE	byKeyState [256] = { 0 } ;
	int		iCH ;

	if (pEvent == NULL)
		return	-1 ;

	switch (pEvent->m_nMessage) {
	case	WM_KEYDOWN:
		if (pEvent->m_wParam < 0x100) {
			WORD					rwCH [2] ;

			byKeyState [VK_LCONTROL]	= (pEvent->m_rParam & KEYMASK_LCONTROL)?	0x80 : 0 ;
			byKeyState [VK_RCONTROL]	= (pEvent->m_rParam & KEYMASK_RCONTROL)?	0x80 : 0 ;
			byKeyState [VK_LSHIFT]		= (pEvent->m_rParam & KEYMASK_LSHIFT)?		0x80 : 0 ;
			byKeyState [VK_RSHIFT]		= (pEvent->m_rParam & KEYMASK_RSHIFT)?		0x80 : 0 ;
			byKeyState [VK_LMENU]		= (pEvent->m_rParam & KEYMASK_LMENU)?		0x80 : 0 ;
			byKeyState [VK_RMENU]		= (pEvent->m_rParam & KEYMASK_RMENU)?		0x80 : 0 ;
			byKeyState [VK_NUMLOCK]		= (pEvent->m_rParam & KEYMASK_NUMLOCK)?		0x80 : 0 ;
			byKeyState [VK_SCROLL]		= (pEvent->m_rParam & KEYMASK_SCROLL)?		0x80 : 0 ;
			byKeyState [VK_CONTROL]		= byKeyState [VK_LCONTROL] | byKeyState [VK_RCONTROL] ;
			byKeyState [VK_SHIFT]		= byKeyState [VK_LSHIFT]   | byKeyState [VK_RSHIFT] ;
			rwCH [0]	= 0 ;
		
			/*	�܂��͌��݂� keyboard �����āA�ϊ��ł��Ȃ������ǂ������`�F�b�N
			 *	����B
			 */
			if (ToAscii ((UINT)pEvent->m_wParam, 0x80000000, byKeyState, rwCH, 0) == 0) {
				rwCH [0]	= (WCHAR) -1 ;
			} else {
				/*	keyboard �����ĕϊ��ł����ꍇ�̏����B
				 */
				if (rwCH [0] == TEXT(' ') && (byKeyState [VK_CONTROL] & 0x80))
					rwCH [0]	= 0 ;
			}
			return	rwCH [0] ;
		} else {
			return	-1 ;
		}
		break ;
	case	WM_IME_KEYDOWN:
		{
			/*
			 *		wParam
			 *			��� 16 �r�b�g�ɉ����ꂽ�����̕����R�[�h���A
			 *			���� 16 �r�b�g�ɉ����ꂽ�L�[�̉��z�L�[�R�[�h�������Ă��܂��B
			 *		lParam
			 *			WM_KEYDOWN �ɗ^������ lParam �Ɠ����ł��B
			 *		lpbKeyState
			 *			���݂̃L�[�{�[�h�̏�Ԃ��܂�256�o�C�g�̔z��ւ̃|�C���^�ł��B
			 *			IME �͂��̓��e��ύX���Ă͂����܂���B
			 */
			//int		nKeyCode		= HIWORD (pEvent->m_wParam) ;
			int		nVkCode			= LOWORD (pEvent->m_wParam) ;
			WORD	rwCH [2] ;

			rwCH [0]	= 0 ;
			byKeyState [VK_LCONTROL]	= (pEvent->m_rParam & KEYMASK_LCONTROL)?	0x80 : 0 ;
			byKeyState [VK_RCONTROL]	= (pEvent->m_rParam & KEYMASK_RCONTROL)?	0x80 : 0 ;
			byKeyState [VK_LSHIFT]		= (pEvent->m_rParam & KEYMASK_LSHIFT)?		0x80 : 0 ;
			byKeyState [VK_RSHIFT]		= (pEvent->m_rParam & KEYMASK_RSHIFT)?		0x80 : 0 ;
			byKeyState [VK_LMENU]		= (pEvent->m_rParam & KEYMASK_LMENU)?		0x80 : 0 ;
			byKeyState [VK_RMENU]		= (pEvent->m_rParam & KEYMASK_RMENU)?		0x80 : 0 ;
			byKeyState [VK_NUMLOCK]		= (pEvent->m_rParam & KEYMASK_NUMLOCK)?		0x80 : 0 ;
			byKeyState [VK_SCROLL]		= (pEvent->m_rParam & KEYMASK_SCROLL)?		0x80 : 0 ;
			byKeyState [VK_CONTROL]		= byKeyState [VK_LCONTROL] | byKeyState [VK_RCONTROL] ;
			byKeyState [VK_SHIFT]		= byKeyState [VK_LSHIFT]   | byKeyState [VK_RSHIFT] ;

			/*	where-is-internal �p�ɁA���� pbKeyState �̎w�����e���R�s�[����
			 *	�����ׂ��Ȃ̂��낤���H
			 */
			if (ToAscii (nVkCode, 0x80000000, byKeyState, rwCH, 0) == 0) {
				rwCH [0]	= (WCHAR) -1 ;
			} else {
				/*	keyboard �����ĕϊ��ł����ꍇ�̏����B
				 */
				/*	Control-Space �� Code 0 �Ƃ��Ĉ����B
				 */
				if (rwCH [0] == TEXT(' ') && (byKeyState [VK_CONTROL] & 0x80) != 0)
					rwCH [0]	= 0 ;
			}
			return	rwCH [0] ;
		}
		break ;
	case	WM_CHAR:
		return	(UINT)pEvent->m_wParam ;
	default:
		iCH	= -1 ;
		break ;
	}
	return	iCH ;
}

BOOL
CImeDoc::bEventToCharacter (
	const struct TMSG*		pEvent,
	int*					pCH)
{
	int		nCH ;

	if (pEvent == NULL)
		return	FALSE ;

	nCH	= iGetCharFromEvent (pEvent) ;
	if (nCH < 0)
		return	FALSE ;
	if (pCH != NULL)
		*pCH	= nCH ;
	return	TRUE ;
}

BOOL
CImeDoc::bProcessEventp ()
{
	CImeBuffer*	pCurBuffer ;
	int		nText ;

	/*	�Ăяo�����̃A�v���P�[�V�����ɃC�x���g�𓊂��Ԃ��ׂ����ǂ������f����B
	 *	�����Ԃ��ׂ��ł͂Ȃ��Ɣ��f�����ꍇ�ɂ́A�C�x���g�͐H�ׂ��Ă��܂��B
	 *
	 *	�����Ԃ��ׂ����ۂ��̔��f�́A
	 *	- minibuffer �� recursive-edit �����Ă��� => no
	 *	- ���ڃR�[�h���̓��[�h�Ȃ����ϊ����I�����[�h => no
	 *	- ����prefix�����݂��� (ImeBuffer_bHavePrefixp �� TRUE ��Ԃ�) => no
	 *	- composition string �����݂��� (�������Anext-line �̂悤�ɁA�m�肵�Ă��� event 
	 *	  ��e�ɕԂ��悤�Ȃ��̂����݂���B��O�ɒ��ӂ��邱��) => no
	 *	- 
	 */
	if (bRecursiveEditp ())
		return	TRUE ;

	pCurBuffer	= pGetCurrentBuffer () ;
	if (pCurBuffer == NULL)
		return	FALSE ;
	if (pCurBuffer->bShowHenkanCandidatesModep  () || pCurBuffer->bInputByCodeOrMenuModep  ())
		return	TRUE ;
	if (pCurBuffer->bHavePrefixp  ())
		return	TRUE ;
	(void) pCurBuffer->pBufferString (&nText) ;
	if (nText > 0)
		return	TRUE ;
	return	FALSE ;
}

/*========================================================================
 *	buffer interfaces
 */
CImeBuffer*
CImeDoc::pCreateBuffer (
	LPCDSTR					wstrMessage,
	int						nstrMessage,
	BOOL					bSkkModeOn)
{
	CImeBuffer*	pBuffer ;
	int			nIndex ;
	BOOL		fInc ;

	/*	����ȏ�ċA�ł��Ȃ����H */
	if (m_nBuffer >= MAXIMEBUFFER) {
		for (nIndex = 0 ; nIndex < MAXIMEBUFFER ; nIndex ++)
			if (m_rpBuffer [nIndex] == NULL)
				break ;
		if (nIndex >= MAXIMEBUFFER)
			return	NULL ;
		fInc	= FALSE ;
	} else {
		nIndex	= m_nBuffer ;
		fInc	= TRUE ;
	}
	pBuffer	= new CImeBuffer (this) ;
	if (pBuffer == NULL) 
		return	NULL ;
	if (! pBuffer->bInit (wstrMessage, nstrMessage, bSkkModeOn)) {
		delete	pBuffer ;
		return	NULL ;
	}
	m_rpBuffer [nIndex]	= pBuffer ;
	if (fInc)
		m_nBuffer	++ ;
	return	pBuffer ;
}

void
CImeDoc::vDeleteUnusedBuffer ()
{
	int	i ;

	for (i = 0 ; i < m_nUnusedBuffer ; i ++) {
		if (m_rpUnusedBuffer [i] != NULL)
			delete	m_rpUnusedBuffer [i] ;
		m_rpUnusedBuffer [i]	= NULL ;
	}
	m_nUnusedBuffer	= 0 ;
	for (i = m_nBuffer - 1 ; i >= 0 && m_rpBuffer [i] == NULL ; i --) 
		;
	m_nBuffer	= i + 1 ;
	return ;
}

BOOL
CImeDoc::bDeleteBuffer (
	CImeBuffer*		pUnusedBuffer)
{
	int			i, nIndex ;

	nIndex = -1 ;
	for (i = 0 ; i < m_nBuffer ; i ++) {
		if (m_rpBuffer [i] == pUnusedBuffer) {
			nIndex	= i ;
			continue ;
		}
	}
	if (nIndex < 0)
		return	FALSE ;
	if (m_nUnusedBuffer >= MYARRAYSIZE (m_rpUnusedBuffer)) {
		vDeleteUnusedBuffer () ;
		m_nUnusedBuffer	= 0 ;
	}
	m_rpUnusedBuffer [m_nUnusedBuffer ++]	= pUnusedBuffer ;
	m_rpBuffer [nIndex]	= NULL ;
	if (nIndex == (m_nBuffer - 1))
		m_nBuffer	-- ;
	return	TRUE ;
}

/*========================================================================
 *	private methods
 */
BOOL
CImeDoc::_bInitConfig ()
{
	return	TRUE ;
}

void
CImeDoc::_vUninitConfig ()
{
	return ;
}

BOOL
CImeDoc::_bWhereIsInternal (
	const struct CImeKeymap*	pKeymap,
	int							nFuncNo,
	struct TMSG*				pEvent)
{
	const struct CImeKeyBind*	pBind ;
	const struct CImeKeyBind*	pCurBind ;
	int		i, nBind, nCurScore ;

	for (i = 0 ; i < SIZE_IMEDOC_KEYMAP ; i ++) {
		if (nFuncNo == pKeymap->m_rbyBaseMap [i]) {
			if (pEvent != NULL) {
				pEvent->m_nMessage	= WM_CHAR ;
				pEvent->m_wParam	= (WPARAM) i ;
				pEvent->m_lParam	= 0 ;
				pEvent->m_rParam	= 0 ;
				pEvent->m_nTime		= GetTickCount () ;
				pEvent->m_pt.x		= 0 ;
				pEvent->m_pt.y		= 0 ;
			}
			return	TRUE ;
		}
	}

	pBind		= pKeymap->m_pKeyBinds ;
	nBind		= pKeymap->m_nKeyBinds ;
	pCurBind	= NULL ;
	nCurScore	= -1 ;
	while (nBind > 0) {
		if (pBind->m_nKeyFunction == nFuncNo) {
			if (pEvent != NULL) {
				/*	�L�[�}�X�N�Ɉˑ����Ă��܂��̂ŁA���Ƃ������Ȃ����c */
				pEvent->m_nMessage	= WM_KEYDOWN ;
				pEvent->m_wParam	= (WPARAM) pCurBind->m_nKeyCode ;
				pEvent->m_rParam	= pCurBind->m_uKeyMask ;
				pEvent->m_lParam	= 0 ;
				pEvent->m_nTime		= GetTickCount () ;
				pEvent->m_pt.x		= 0 ;
				pEvent->m_pt.y		= 0 ;
			}
			return	TRUE ;
		}
		pBind	++ ;
		nBind	-- ;
	}
	return	FALSE ;
}

BOOL
CImeDoc::_bProcessFunctionp (
	int							nFuncNo)
{
	/*	topbuffer �ŉ������������͂���Ă��Ȃ����� filter ���邩�ۂ��̃e�[�u���B
	 *	�V�`���G�[�V�����Ƃ��āu���蓾�Ȃ��v�́u�ǂ��瑤�ɓ|���v�̂��ǂ����c�������B
	 */
	switch (nFuncNo) {
	case	NFUNC_SKK_MODE:
	case	NFUNC_SKK_LATIN_MODE:
	case	NFUNC_SKK_JISX0208_LATIN_MODE:
	case	NFUNC_SKK_SET_HENKAN_POINT_SUBR:
	case	NFUNC_SKK_INPUT_BY_CODE_OR_MENU:
	case	NFUNC_SKK_ABBREV_COMMA:
	case	NFUNC_SKK_ABBREV_PERIOD:
	case	NFUNC_SKK_INSERT:
	case	NFUNC_SKK_KAKUTEI:
	case	NFUNC_SKK_JISX0208_LATIN_INSERT:
	case	NFUNC_SKK_TODAY:
	case	NFUNC_TOGGLE_IME:
	case	NFUNC_SKK_TOGGLE_CHARACTERS:
	case	NFUNC_SKK_TOGGLE_KUTOUTEN:
	case	NFUNC_SKK_PREVIOUS_CANDIDATE:
	case	NFUNC_SKK_TOGGLE_KATAKANA:
	case	NFUNC_SKK_TOGGLE_JISX0201:
	case	NFUNC_SKK_JISX0201_MODE:
		return	TRUE ;
	case	NFUNC_INVALID_CHAR:
	default:
		return	FALSE ;
	}

/*	�ۗ��F
	NFUNC_SELF_INSERT_CHARACTER,
	NFUNC_SET_MARK_COMMAND,
	NFUNC_BEGINNING_OF_LINE,
	NFUNC_BACKWARD_CHAR,
	NFUNC_MODE_SPECIFIC_COMMAND_PREFIX,
	NFUNC_DELETE_CHAR,
	NFUNC_END_OF_LINE,
	NFUNC_FORWARD_CHAR,
	NFUNC_KEYBOARD_QUIT,
	NFUNC_BACKWARD_DELETE_CHAR,
	NFUNC_INDENT_FOR_TAB_COMMAND,
	NFUNC_NEWLINE_AND_INDENT,
	NFUNC_KILL_LINE,
	NFUNC_RECENTER,
	NFUNC_NEWLINE,
	NFUNC_NEXT_LINE,
	NFUNC_OPEN_LINE,
	NFUNC_PREVIOUS_LINE,
	NFUNC_QUATED_INSERT,
	NFUNC_ISEARCH_BACKWARD,
	NFUNC_ISEARCH_FORWARD,
	NFUNC_TRANSPOSE_CHARS,
	NFUNC_UNIVERSAL_ARGUMENT,
	NFUNC_SCROLL_UP,
	NFUNC_KILL_REGION,
	NFUNC_CONTROL_X_PREFIX,
	NFUNC_YANK,
	NFUNC_SCROLL_DOWN,
	NFUNC_PREFIX_COMMAND,
	NFUNC_EXIT_RECURSIVE_EDIT,
	NFUNC_ABORT_RECURSIVE_EDIT,
	NFUNC_UNDO,
	NFUNC_SKK_START_HENKAN,
	NFUNC_SKK_TRY_COMPLETION,
	NFUNC_SKK_DELETE_BACKWARD_CHAR,
	NFUNC_SKK_PREVIOUS_CANDIDATE,
	NFUNC_SKK_TOGGLE_CHARACTERS,
	NFUNC_SKK_PURGE_FROM_JISYO,
	NFUNC_SKK_ABBREV_MODE,
	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT,
	NFUNC_SKK_CURRENT_KUTEN,
	NFUNC_SKK_UNDO,
	NFUNC_SKK_COMP_DO,
	NFUNC_SKK_KAKUTEI_HENKAN,
	NFUNC_SKK_UNDO_KAKUTEI_HENKAN,
	NFUNC_SKK_LATIN_HENKAN,
	*/
}

BOOL
CImeDoc::_bLookupKeymap (
	const struct CImeKeymap*	pKeymap,
	const struct TMSG*			pEvent,
	int*						pnFuncNo)
{
	const struct CImeKeyBind*	pBind ;
	int		nFuncNo, nBind, nKeyCode, nCurScore ;
	unsigned int	uKeyMask, uKeyMaskW ;

	if (pKeymap == NULL || pEvent == NULL)
		return	FALSE ;

	switch (pEvent->m_nMessage) {
	case	WM_KEYDOWN:
		nKeyCode	= (short) pEvent->m_wParam ;
		uKeyMask	= pEvent->m_rParam ;
		break ;
	case	WM_LBUTTONDOWN:
		nKeyCode	= VK_LBUTTON ;
		uKeyMask	= 0 ;
		break ;
	case	WM_RBUTTONDOWN:
		nKeyCode	= VK_RBUTTON ;
		uKeyMask	= 0 ;
		break ;
	case	WM_CHAR:
	case	WM_IME_CHAR:
		nKeyCode	= VkKeyScan (pEvent->m_wParam) ;
		uKeyMask	= 0 ;
		if (nKeyCode & 0x100)
			uKeyMask	|= (KEYMASK_LCONTROL | KEYMASK_RCONTROL) ;
		if (nKeyCode & 0x200)
			uKeyMask	|= (KEYMASK_LSHIFT | KEYMASK_RSHIFT) ;
		nKeyCode	= nKeyCode & 0xFF ;
		break ;
	default:
		return	FALSE ;
	}

	uKeyMaskW	= uKeyMask ;
	uKeyMaskW	|= (uKeyMask & (KEYMASK_LCONTROL | KEYMASK_RCONTROL))? (KEYMASK_LCONTROL | KEYMASK_RCONTROL) : 0 ;
	uKeyMaskW	|= (uKeyMask & (KEYMASK_LMENU    | KEYMASK_RMENU))?    (KEYMASK_LMENU    | KEYMASK_RMENU)    : 0 ;
	uKeyMaskW	|= (uKeyMask & (KEYMASK_RSHIFT   | KEYMASK_LSHIFT))?   (KEYMASK_RSHIFT   | KEYMASK_LSHIFT)   : 0 ;

	/*	�e�X�g�̏��Ԃ͎��̒ʂ�F
	 *	1. keymask �̊��S��v�A
	 *	2. keymask �� L �� R �𖳎�������r�ł̈�v�A
	 *	3. keymask �̕�����v�A
	 *	1->2->3 �̏����Ńe�X�g���āA���t����ΏI���B
	 *	���t����Ȃ���΁A�����ŃA�E�g�B
	 *
	 *	���� L �� R �𖳎�������r�����ACONTROL, MENU, SHIFT �ȂǕ�����������
	 *	������Ă����ꍇ�ɂ́A
	 */
	pBind	= pKeymap->m_pKeyBinds ;
	nBind	= pKeymap->m_nKeyBinds ;
	nFuncNo	= NFUNC_INVALID_CHAR ;
	nCurScore	= -1 ;
	while (nBind > 0) {
		if (pBind->m_nKeyCode == nKeyCode) {
			if ((pBind->m_uKeyMask & uKeyMaskW) == pBind->m_uKeyMask) {
				int		nScore ;

				/* match �x�����ɑ΂��� score �����肷��B*/
				nScore	= _iGetKeyMatchScore (pBind->m_uKeyMask, uKeyMask, uKeyMaskW) ;
				if (nScore > nCurScore) {
					nFuncNo		= pBind->m_nKeyFunction ;
					nCurScore	= nScore ;

					if (nCurScore == 100)
						break ;
				}
			}
		}
		pBind	++ ;
		nBind	-- ;
	}
	/*	����L�[�̃o�C���h���ɂ���B
	 */
	if (nCurScore <= 0) {
		int		iCH ;

		iCH	= iGetCharFromEvent (pEvent) ; 
		if (0 <= iCH && iCH < SIZE_IMEDOC_KEYMAP) {
			if (pnFuncNo != NULL)
				*pnFuncNo	= pKeymap->m_rbyBaseMap [iCH] ;
			return	TRUE ;
		}
	}
	if (nCurScore < 0)
		return	FALSE ;
	if (pnFuncNo != NULL)
		*pnFuncNo	= nFuncNo ;
	return	TRUE ;
}

int
CImeDoc::_iGetKeyMatchScore (
	unsigned int				uMask,
	unsigned int				uExactMask,
	unsigned int				uRoughMask)
{
	unsigned int	uValue ;
	int				nScore, i ;

	if (uMask == uRoughMask)
		return	100 ;	/* 100% */

	/*	���ۂɉ����ꂽ�L�[���牟����ĂȂ��ƍ�邱�Ƃ͂����Ă����̋t�͂Ȃ��B
	 *	(����ɉ��������Ƃɂ�����͂��Ȃ�)
	 *	�܂�A�������L�[�̉��߂��A
	 *		SHIFT + F.1 => F.1 
	 *	�̕����͂����Ă�
	 *		F.1 => SHIFT + F.1
	 *	�ɂ͊g�債�Ȃ��B
	 */
	if ((uRoughMask & uMask) != uMask)
		return	0 ;

	/*	��v���Ă��鐔�����X�R�A�������Ȃ�B�������ALR �̈Ⴂ�ň�v����ꍇ��
	 *	���S��v�����X�R�A���Ⴂ�B
	 */
	uValue	= uExactMask & uMask ;
	nScore	= 0 ;
	for (i = 0 ; i < NBITS_KEYMASK ; i ++)
		if (uValue & (1 << i))
			nScore	++ ;
	uValue	= uRoughMask & uMask ;
	for (i = 0 ; i < NBITS_KEYMASK ; i ++)
		if (uValue & (1 << i))
			nScore	++ ;
	return	nScore ;
}

BOOL
CImeDoc::_bUpdateCandidateInfoForStatusText ()
{
	IMECANDIDATES*	pMyCand ;

	pMyCand				= &m_MessageInfo ;
	if (m_rpBuffer [0] != m_pCurBuffer) {
		LPDSTR			pwDest ;
		LPDSTR			pCandidateStr ;
		int				nText ;
		LPCDSTR			pwText ;
		int				iLength, iCursor ;
		CTMarker*		pmkPoint	= NULL ;
		UINT*			pPageIndex ;
		UINT*			pCandidateOffset ;

		/*	Message ���������ꍇ�ɂ͐擪�Ɂu�I�v��ǉ����������c�B
		 *	���ƁA���O�� StatusLine ���`��ł��Ȃ��ꍇ�ɁA�J�[�\�����Ӗ�����
		 *	���������Ă��������B``|'' �ŗǂ����B
		 */
		pwText	= m_pCurBuffer->pBufferRawString (&iLength) ;
		if (m_pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT, &pmkPoint) && pmkPoint != NULL) {
			iCursor	= pmkPoint->iGetPosition () ;
		} else {
			iCursor	= -1 ;
		}
		nText	= iLength + 1/*``|''�̕�*/ + 1/*nul�̕�*/ ;  

		pMyCand->m_vbufCandidate.vClear () ;
		pMyCand->m_vbufCandidateIndex.vClear () ;
		pMyCand->m_vbufPageIndex.vClear () ;
		pMyCand->m_vbufAnnotationIndex.vClear () ;
		if (! pMyCand->m_vbufCandidate.bRequire (nText) ||
			! pMyCand->m_vbufCandidateIndex.bRequire (1) ||
			! pMyCand->m_vbufPageIndex.bRequire (1))
			return	FALSE ;

		pMyCand->m_iStyle		= IMECANDSTYLE_MINIBUFFERTEXT ;
		pMyCand->m_iCount		= 1 ;
		pMyCand->m_iSelection	= 0 ;
		pMyCand->m_iCurrentPage	= 0 ;
		pCandidateOffset		= pMyCand->m_vbufCandidateIndex.pGetBuffer () ;
		pCandidateOffset [0]	= 0 ;
		pPageIndex				= pMyCand->m_vbufPageIndex.pGetBuffer () ;
		pPageIndex [0]			= 0 ;
		pCandidateStr			= pMyCand->m_vbufCandidate.pGetBuffer () ;

		pwDest		= pCandidateStr ;
		if (0 < iCursor) {
			memcpy (pwDest, pwText, iCursor * sizeof (DCHAR)) ;
			pwDest	+= iCursor ;
		}
		*pwDest ++	= L'|' ;
		if (iCursor < iLength) {
			memcpy (pwDest, pwText + iCursor, (iLength - iCursor) * sizeof (DCHAR)) ;
			pwDest	+= (iLength - iCursor) ;
		}
		*pwDest = L'\0' ;
	} else {
		pMyCand->vClear () ;
	}
	return	TRUE ;
}

struct CImeDoc::CImeDocContext	CImeDoc::m_ContextBackup ;

BOOL
CImeDoc::_bInitContextBuffer ()
{
	int		i ;

	memset (&m_ContextBackup, 0, sizeof (m_ContextBackup)) ;

	m_ContextBackup.m_pRegStack	= new struct LMREG [NSIZE_REGSTACK] ;
	if (m_ContextBackup.m_pRegStack == NULL)
		return	FALSE ;
	m_ContextBackup.m_pbStackArea	= new BYTE [m_nStackAreaSize] ;
	if (m_ContextBackup.m_pbStackArea == NULL) {
		delete[]	m_ContextBackup.m_pRegStack ;
		m_ContextBackup.m_pRegStack	= NULL ;
		return	FALSE ;
	}
	for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
		m_ContextBackup.m_rpBufferState [i]	= new CImeBuffer (this) ;
		if (m_ContextBackup.m_rpBufferState [i] == NULL)
			goto	error_exit ;
		if (! m_ContextBackup.m_rpBufferState [i]->bInit (NULL, 0, FALSE)) 
			goto	error_exit ;
	}
	return	TRUE ;

error_exit:
	_vUninitContextBuffer () ;
	return	FALSE ;
}

void
CImeDoc::_vUninitContextBuffer ()
{
	int	i ;

	if (m_ContextBackup.m_pRegStack != NULL) {
		delete[]	m_ContextBackup.m_pRegStack ;
		m_ContextBackup.m_pRegStack	= NULL ;
	}
	if (m_ContextBackup.m_pbStackArea != NULL) {
		delete[]	m_ContextBackup.m_pbStackArea ;
		m_ContextBackup.m_pbStackArea	= NULL ;
	}
	for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
		if (m_ContextBackup.m_rpBufferState [i] != NULL) {
			m_ContextBackup.m_rpBufferState [i]->vUninit () ;
			delete	m_ContextBackup.m_rpBufferState [i] ;
			m_ContextBackup.m_rpBufferState [i]	= NULL ;
		}
	}
	return ;
}

BOOL
CImeDoc::_bSaveContext ()
{
	struct CImeDocContext*	pContext	= NULL ;
	int						i ;

	pContext						= &m_ContextBackup ;
	pContext->m_pPC					= m_pPC ;
	memcpy (pContext->m_rpRetPC, m_rpRetPC, sizeof (m_rpRetPC)) ;
	pContext->m_nRetPC				= m_nRetPC ;
	pContext->m_nStackAreaSize		= m_nStackAreaSize ;
	pContext->m_nStackHead			= m_nStackHead ;
	memcpy (pContext->m_pbStackArea, m_pbStackArea, m_nStackAreaSize) ;
	memcpy (pContext->m_rnStackPos, m_rnStackPos, sizeof (m_rnStackPos)) ;
	memcpy (pContext->m_pRegStack,  m_pRegStack,  sizeof (struct LMREG) * NSIZE_REGSTACK) ;
	pContext->m_nRegStackHead		= m_nRegStackHead ;
	memcpy (pContext->m_rREGS, m_rREGS, sizeof (m_rREGS)) ;
	pContext->m_iThisCommand		= m_iThisCommand ;
	pContext->m_iLastCommand		= m_iLastCommand ;
	pContext->m_LastEvent			= m_LastEvent ;
	pContext->m_iLastCommandChar	= m_iLastCommandChar ;

	pContext->m_nBuffer				= m_nBuffer ;
	/*	�o�b�t�@���̏�Ԃ��ω�����\��������̂ŁA�L�����Ă����K�v������c�B*/
	for (i = 0 ; i < m_nBuffer ; i ++) {
		if (m_rpBuffer [i] != NULL) {
			pContext->m_rpBufferState [i]->vCopyState (m_rpBuffer [i]) ;
		}
	}
	/*	Restore �̎��ɑ������o�b�t�@�͔j������B*/
	memset (pContext->m_rpBuffer, 0, sizeof (pContext->m_rpBuffer)) ;
	for (i = 0 ; i < m_nBuffer ; i ++)
		pContext->m_rpBuffer [i]	= m_rpBuffer [i] ;
	pContext->m_pCurBuffer			= m_pCurBuffer ;
	pContext->m_pPreCommandHook		= m_pPreCommandHook ;
	pContext->m_pPostCommandHook	= m_pPostCommandHook ;
	return	TRUE ;
}

void
CImeDoc::_vRestoreContext ()
{
	struct CImeDocContext*	pContext	= &m_ContextBackup ;
	int		iCurBuffer = 0, i ;

	m_pPC				= pContext->m_pPC ;
	memcpy (m_rpRetPC, pContext->m_rpRetPC, sizeof (m_rpRetPC)) ;
	m_nRetPC			= pContext->m_nRetPC ;
	memcpy (m_rnStackPos, pContext->m_rnStackPos, sizeof (m_rnStackPos)) ;
	memcpy (m_pRegStack,  pContext->m_pRegStack,  sizeof (struct LMREG) * NSIZE_REGSTACK) ;
	m_nRegStackHead		= pContext->m_nRegStackHead ;
	m_nStackHead		= pContext->m_nStackHead ;
	memcpy (m_rREGS, pContext->m_rREGS, sizeof (m_rREGS)) ;
	m_iThisCommand		= pContext->m_iThisCommand ;
	m_iLastCommand		= pContext->m_iLastCommand ;
	m_LastEvent			= pContext->m_LastEvent ;
	m_iLastCommandChar	= pContext->m_iLastCommandChar ;

	for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
		if (pContext->m_pCurBuffer == pContext->m_rpBuffer [i])
			iCurBuffer	= i ;
	}
	if (m_nBuffer != pContext->m_nBuffer) {
		for (i = 0 ; i < MAXIMEBUFFER ; i ++) {
			if (pContext->m_rpBuffer [i] != m_rpBuffer [i]) {
				if (m_rpBuffer [i] == NULL) {
					/* ���̏ꍇ�ɂ� buffer �������Ă��܂����̂ŁA���ɖ߂����߂� buffer ���U�B*/
					if (m_nUnusedBuffer > 0) {
						m_rpBuffer [i]	= m_rpUnusedBuffer [-- m_nUnusedBuffer] ;
						m_rpUnusedBuffer [m_nUnusedBuffer]	= NULL ;
					} else {
						m_rpBuffer [i]	= new CImeBuffer (this) ;
						if (m_rpBuffer [i] != NULL) {
							if (! m_rpBuffer [i]->bInit (NULL, 0, FALSE)) {
								delete	m_rpBuffer [i] ;
								m_rpBuffer [i]	= NULL ;
							}
						}
					}
				} else if (pContext->m_rpBuffer [i] == NULL) {
					/* ���̏ꍇ�ɂ� buffer ���������̂ŁA���ɖ߂����߂ɑ����� buffer ��j���B*/
					if (! bDeleteBuffer (m_rpBuffer [i])) {
						m_rpBuffer [i]->vUninit () ;
						delete	m_rpBuffer [i] ;
						m_rpBuffer [i]	= NULL ;
					}
				} else {
					/* ���̏ꍇ�ɂ� CopyState �ŉ����ł���B*/
				}
			}
		}
	} else {
		/*	CopyState �ŉ����ł��邾�낤�B*/
		m_nBuffer		= pContext->m_nBuffer ;
	}
	for (i = 0 ; i < m_nBuffer ; i ++) {
		if (pContext->m_rpBufferState [i] != NULL) {
			m_rpBuffer [i]->vCopyState (pContext->m_rpBufferState [i]) ;
		}
	}
	m_pCurBuffer		= m_rpBuffer [iCurBuffer] ;
	m_pPreCommandHook	= pContext->m_pPreCommandHook ;
	m_pPostCommandHook	= pContext->m_pPostCommandHook ;
	return ;
}

BOOL
CImeDoc::_bEmulateFilterEvent (
	const struct TMSG*		pMsg,
	BOOL*					pbEaten)
{
	BOOL	bRetval ;
	int		nUnreadMessages ;

	if (m_nBuffer != 1)
		return	FALSE ;

	if (! _bSaveContext ())
		return	FALSE ;

	nUnreadMessages	= m_nUnreadMessages ;
	if (! bPushEvent (pMsg))
		return	FALSE ;

	m_UnprocessEvent.m_nMessage	= WM_NULL ;
	bRetval	= _bTick () ;
	if (m_UnprocessEvent.m_nMessage != WM_NULL			&&
		m_UnprocessEvent.m_nMessage	== pMsg->m_nMessage &&
		m_UnprocessEvent.m_wParam	== pMsg->m_wParam	&&
		m_UnprocessEvent.m_lParam	== pMsg->m_lParam) {
		*pbEaten	= FALSE ;
	} else {
		*pbEaten	= TRUE ;
	}
	_vRestoreContext () ;
	m_nUnreadMessages	= nUnreadMessages ;
	vDeleteUnusedBuffer () ;
	return	bRetval ;
}


