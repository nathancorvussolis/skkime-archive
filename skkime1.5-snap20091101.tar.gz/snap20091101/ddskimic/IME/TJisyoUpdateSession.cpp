#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "TJisyoUpdateSession.h"
#include "TCommuSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
CTRecordSession::bUpdate (
	LPCDSTR		wstrHenkanKey,
	int			nstrHenkanKey,
	LPCDSTR		wstrResult,
	int			nstrResult,
	LPCDSTR		wstrOkurigana,
	int			nOkuriganaLen,
	BOOL		bOkurigana)
{
	CTPacket	packet ;
	HANDLE		hPipe ;
	int			nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.bSetHeader  (SKKISERV_PROTO_RECORD, bOkurigana) ||
		! packet.bAddDString (wstrHenkanKey, nstrHenkanKey)       ||
		! packet.bAddDString (wstrResult,    nstrResult)          ||
		! packet.bAddDString (wstrOkurigana, nOkuriganaLen)       ||
		! packet.bSetLength  () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! _bRecv (hPipe, &packet) ||
		! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.iGetDataSize () ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_RECORD_REPLY) ;
}

BOOL
CTPurgeSession::bUpdate (
	LPCDSTR		wstrHenkanKey,
	int			nstrHenkanKey,
	LPCDSTR		wstrResult,
	int			nstrResult,
	LPCDSTR		wstrOkurigana,
	int			nOkuriganaLen,
	BOOL		bOkurigana)
{
	CTPacket	packet ;
	HANDLE		hPipe ;
	int			nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.bSetHeader  (SKKISERV_PROTO_PURGE, bOkurigana)	||
		! packet.bAddDString (wstrHenkanKey, nstrHenkanKey)		||
		! packet.bAddDString (wstrResult,    nstrResult)		||
		! packet.bAddDString (wstrOkurigana, nOkuriganaLen)		||
		! packet.bSetLength  () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! _bRecv (hPipe, &packet) ||
		! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.iGetDataSize () ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_PURGE_REPLY) ;
} 

BOOL
CTJisyoSaveSession::bSynchronize (void) 
{
	CTPacket		packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.bSetHeader (SKKISERV_PROTO_SAVELOCALJISYO, 0) ||
		! packet.bSetLength () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! _bRecv (hPipe, &packet) ||
		! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.iGetDataSize () ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_SAVELOCALJISYO_REPLY) ;
}

BOOL
CTRecordKakuteiHistorySession::bUpdate (
	LPCDSTR		wstrMidasi,
	int			nMidasiLen,
	LPCDSTR		wstrWord,
	int			nWordLen)
{
	CTPacket	packet ;
	HANDLE		hPipe ;
	int			nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.bSetHeader  (SKKISERV_PROTO_RECORDKAKUTEIHISTORY, 0)	||
		! packet.bAddDString (wstrMidasi,	nMidasiLen)				||
		! packet.bAddDString (wstrWord,		nWordLen)				||
		! packet.bSetLength () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! _bRecv (hPipe, &packet) ||
		! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= packet.iGetDataSize () ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_RECORDKAKUTEIHISTORY_REPLY) ;
}

