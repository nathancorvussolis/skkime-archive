#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"

#define	SKKIME_FUNCTION_DESC	L"SKKIME1.5 FunctionProvider"

// {3BC3E3C9-5375-4f8e-B9D7-C1D7AAFE3991}
static const GUID	_Guid_ITfFunctionProvider = {
	0x3bc3e3c9, 0x5375, 0x4f8e, { 0xb9, 0xd7, 0xc1, 0xd7, 0xaa, 0xfe, 0x39, 0x91 }
} ;


HRESULT
CSkkImeTextService::GetType (
	GUID*		pguid)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetType ()\n"))) ;

	if (pguid == NULL)
		return	E_INVALIDARG ;
	*pguid	= _Guid_ITfFunctionProvider ;
	return	S_OK ;
}

HRESULT
CSkkImeTextService::GetDescription (
	BSTR*		pbstrDesc)
{
	BSTR	bstrDesc ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetDescription ()\n"))) ;

	if (pbstrDesc == NULL)
		return	E_INVALIDARG ;

	bstrDesc	= SysAllocString (SKKIME_FUNCTION_DESC) ;
	if (bstrDesc == NULL)
		return	E_OUTOFMEMORY ;
	*pbstrDesc	= bstrDesc ;
	return	S_OK ;
}

HRESULT
CSkkImeTextService::GetFunction (
	REFGUID		rguid,
	REFIID		riid,
	IUnknown**	ppunk)
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction ()\n"))) ;

	if (ppunk == NULL)
		return	E_INVALIDARG ;

	/*	
	 */
	*ppunk	= NULL ;
	if (IsEqualIID (riid, IID_ITfFnConfigure)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnConfigure)\n"))) ;
		*ppunk	= (ITfFnConfigure *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnConfigureRegisterWord)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnConfigureRegisterWord)\n"))) ;
		*ppunk	= (ITfFnConfigureRegisterWord *)this ;
	} else if (IsEqualIID (riid, IID_ITfFnReconversion)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnReconversion)\n"))) ;
		*ppunk	= (ITfFnReconversion *)this ;
#if defined (not_work)
		/*	ITfFnPropertyUIStatus �͉��������Ηǂ��̂��낤�B�܂���񂪂Ȃ��B
		 */
	} else if (IsEqualIID (riid, IID_ITfFnPropertyUIStatus)) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetFunction (IID_ITfFnPropertyUIStatus)\n"))) ;
		*ppunk	= (ITfFnPropertyUIStatus *)this ;
#endif
	}
	if (*ppunk != NULL) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

BOOL
CSkkImeTextService::_InitFunctionProvider ()
{
	HRESULT				hr ;
	ITfSourceSingle*	pSourceSingle ;

	if (m_pThreadMgr == NULL)
		return	FALSE ;
	hr = m_pThreadMgr->QueryInterface(IID_ITfSourceSingle, (LPVOID*)&pSourceSingle) ;
	if (FAILED (hr)) {
		DEBUGPRINTF ((TEXT ("m_pThreadMgr->QueryInterface failed (0x%lx)\n"), (DWORD)hr)) ;
		return	FALSE ;
	}
	
	hr	= pSourceSingle->AdviseSingleSink (m_tfClientId, IID_ITfFunctionProvider, (ITfFnConfigure *)this) ;
#if defined (DEBUG) || defined (DBG)
	if (FAILED (hr)) {
		DEBUGPRINTF ((TEXT ("pSourceSingle->AdviseSingleSink failed (0x%lx)\n"), (DWORD)hr)) ;
	}
#endif
	pSourceSingle->Release () ;
	return	SUCCEEDED (hr) ;
}

void
CSkkImeTextService::_UninitFunctionProvider ()
{
	HRESULT				hr ;
	ITfSourceSingle*	pSourceSingle ;

	if (m_pThreadMgr == NULL)
		return ;
	hr = m_pThreadMgr->QueryInterface(IID_ITfSourceSingle, (LPVOID*)&pSourceSingle) ;
	if (FAILED (hr)) 
		return ;
	
	pSourceSingle->UnadviseSingleSink (m_tfClientId, IID_ITfFunctionProvider) ;
	pSourceSingle->Release () ;
	return ;
}

