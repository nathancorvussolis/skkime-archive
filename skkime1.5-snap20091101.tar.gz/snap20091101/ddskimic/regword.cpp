/*	config.cpp
 *
 *	ITfFnConfigure implementation
 */
#include "globals.h"
#include <shlwapi.h>
#include "skimic.h"
#include "skkimmgr.h"
#include "resource.h"
#include "IME\TJisyoUpdateSession.h"
#include "IME\jstring.h"

#define	SKKWORD_OKURIARI	(IME_REGWORD_STYLE_USER_FIRST+0)
#define SKKWORD_OKURINASI	(IME_REGWORD_STYLE_USER_FIRST+1)
#define	MAX_KEYWORD			(256)

class	CRegisterWordContainer {
private:
	WCHAR		_wszKey  [MAX_KEYWORD] ;
	WCHAR		_wszWord [MAX_KEYWORD] ;
	BOOL		_fOkuri ;

public:
	CRegisterWordContainer () {
		_wszKey [0]		= L'\0' ;
		_wszWord [0]	= L'\0' ;
		_fOkuri			= FALSE ;
	}

	CRegisterWordContainer (LPCWSTR wstrKey) {
		if (wstrKey != NULL) {
			lstrcpynW (_wszKey, wstrKey, MAX_KEYWORD) ;
		} else {
			_wszKey [0]	= L'\0' ;
		}
		_wszWord [0]	= L'\0' ;
		_fOkuri			= FALSE ;
		return ;
	}

	LPCWSTR		GetKeyword () const {
		return	_wszKey ;
	}
	LPCWSTR		GetWord () const {
		return	_wszWord ;
	}
	BOOL		GetOkuri () const {
		return	_fOkuri ;
	}
	BOOL		SetKeyword (LPCWSTR wstrKey) {
		lstrcpynW (_wszKey, wstrKey, MAX_KEYWORD) ;
		return	TRUE ;
	}
	BOOL		SetWord (LPCWSTR wstrWord) {
		lstrcpynW (_wszWord, wstrWord, MAX_KEYWORD) ;
		return	TRUE ;
	}
	BOOL		SetOkuri (BOOL fOkuri) {
		_fOkuri	= fOkuri ;
		return	TRUE ;
	}
} ;

HRESULT
CSkkImeTextService::Show (
	HWND		hwndParent,
	LANGID		langid,
	REFGUID		rguidProfile,
	BSTR		bstrRegistered)
{
	CRegisterWordContainer	container (bstrRegistered) ;
	int		nRetval ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::Show ()/ITFnConfigureRegisterWord\n"))) ;

	if (langid != SKKIME_LANGID)
		return	E_FAIL ;

	nRetval		= DialogBoxParam (
		g_hInst,
		MAKEINTRESOURCE (IDD_DIALOG_REGISTER_WORD),
		hwndParent,
		&_DialogProc_RegisterWord,
		(LPARAM) &container) ;
	if (nRetval == IDOK) {
		CTRecordSession*	pSession		= new CTRecordSession ;
		LPCWSTR				wstrHenkanKey	= container.GetKeyword () ;
		LPCWSTR				wstrResult		= container.GetWord () ;
		BOOL				bOkurigana		= container.GetOkuri ()? TRUE : FALSE ;

		if (pSession != NULL) {
			DCHAR	bufResult [64] ;
			DCHAR	bufHenkanKey [64] ;
			DCHAR*	pdResult	= NULL ;
			DCHAR*	pdHenkanKey	= NULL ;
			int		nHenkanKeyDLen, nResultDLen ;

			/*	���艼���̐ݒ肪���͓K���Ȃ̂ŃR���p�C�����ʂ�悤�ɂȂ����猩��������(Sat Mar 31 20:40:53 2007)
			 *--
			 *	���̑��艼���ɂ́AL""�ƂȂ��Ă���Ƃ��낾���A����(��r)�ƕϊ������ꍇ�ɁA�u��v��D��Ƃ����Ӗ���
			 *	�ǉ�����Ă��邪�A�P���ɓo�^���������Ɂu��v�܂Őݒ肷��͎̂�Ԃ��낤�c����A���̂܂܂ōs���B
			 *	((current-time-string)
			 */
			pdHenkanKey	= pGetDString (bufHenkanKey, MYARRAYSIZE(bufHenkanKey), wstrHenkanKey, lstrlenW (wstrHenkanKey), &nHenkanKeyDLen) ;
			pdResult	= pGetDString (bufResult,    MYARRAYSIZE(bufResult),    wstrResult,    lstrlenW (wstrResult),    &nResultDLen) ;
			if (nHenkanKeyDLen > 0 && nResultDLen > 0) {
				pSession->bUpdate (pdHenkanKey, nHenkanKeyDLen, pdResult, nResultDLen, NULL, 0, bOkurigana) ;
			}
			if (pdHenkanKey != bufHenkanKey)
				delete[]	pdHenkanKey ;
			if (pdResult != bufResult)
				delete[]	pdResult ;
			delete	pSession ;
		}
	} else if (nRetval == -1) {
		DWORD	dwError	= GetLastError () ;
		DEBUGPRINTF ((TEXT ("DialogBoxParam () failed (0x%lx)\n"), dwError)) ;
	}
	return	S_OK ;
	UNREFERENCED_PARAMETER (rguidProfile) ;
}

INT_PTR	CALLBACK
CSkkImeTextService::_DialogProc_RegisterWord (
	HWND		hwndDlg,
    UINT		uMsg,
    WPARAM		wParam,
    LPARAM		lParam)
{
	CRegisterWordContainer*	pContainer	= NULL ;
	HWND					hwndItem ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		pContainer	= (CRegisterWordContainer*) lParam ;

		SetWindowLongPtr (hwndDlg, DWLP_USER, (LONG_PTR) pContainer) ;
		if (pContainer != NULL) {
			SetDlgItemTextW (hwndDlg, IDC_EDIT_REGISTER_KEY, pContainer->GetKeyword ()) ;
			SetDlgItemTextW (hwndDlg, IDC_EDIT_REGISTER_WORD, pContainer->GetWord ()) ;
			CheckRadioButton (hwndDlg, IDC_RADIO_OKURI_ARI, IDC_RADIO_OKURI_NASHI, IDC_RADIO_OKURI_NASHI) ;
		}
		hwndItem	= GetDlgItem (hwndDlg, IDC_COMBO_OKURI_MOJI) ;
		if (hwndItem != NULL) {
			TCHAR	tszBuffer [2] ;
			int		ch, nPos ;

			tszBuffer [1]	= TEXT ('\0') ;
			for (ch = TEXT ('a') ; ch <= TEXT ('z') ; ch ++) {
				tszBuffer [0]	= ch ;
				nPos	= SendMessage (hwndItem, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) tszBuffer) ;
				if (nPos != CB_ERR) 
					SendMessage (hwndItem, CB_SETITEMDATA, (WPARAM) nPos, (LPARAM) ch) ;
			}
			EnableWindow (hwndItem, FALSE) ;
		}
		return	TRUE ;
	}
	case WM_COMMAND: 
	{
		WCHAR					wszBuffer [MAX_KEYWORD] ;

		pContainer	= (CRegisterWordContainer *)GetWindowLongPtr (hwndDlg, DWLP_USER) ;
		switch (LOWORD (wParam)) { 
		case	IDC_RADIO_OKURI_ARI:
		case	IDC_RADIO_OKURI_NASHI:
			if (HIWORD (wParam) == BN_CLICKED) {
				CheckRadioButton (hwndDlg, IDC_RADIO_OKURI_ARI, IDC_RADIO_OKURI_NASHI, LOWORD (wParam)) ;
				hwndItem	= GetDlgItem (hwndDlg, IDC_COMBO_OKURI_MOJI) ;
				if (hwndItem != NULL) 
					EnableWindow (hwndItem, (LOWORD (wParam) == IDC_RADIO_OKURI_ARI)) ;
				return	TRUE ; 
			}
			break ;
			
		case	IDOK: 
		{
			BOOL	fOkuri	= FALSE ;
			int		n, ch = 0;

			/*	����ϊ��̓o�^���ǂ������`�F�b�N����B
			 */
			if (IsDlgButtonChecked (hwndDlg, IDC_RADIO_OKURI_ARI)) {
				int		nIndex ;

				hwndItem	= GetDlgItem (hwndDlg, IDC_COMBO_OKURI_MOJI) ;
				if (hwndItem == NULL)
					break ;

				nIndex	= SendMessage (hwndItem, CB_GETCURSEL, 0, 0) ;
				if (nIndex == CB_ERR) {
					MessageBox (hwndDlg, TEXT ("���蕶�����w�肵�ĉ�����"), TEXT ("�x��"), MB_OK) ;
					break ;
				}
				ch	= SendMessage (hwndItem, CB_GETITEMDATA, (WPARAM) nIndex, 0) ;
				if (ch < L'a' || ch > L'z') {
					MessageBox (hwndDlg, TEXT ("���蕶�����K�؂ł͂���܂���"), TEXT ("�x��"), MB_OK) ;
					break ;
				}
				fOkuri	= TRUE ;
			}
			/*	�o�^���镶����𓾂�B
			 */
			n	= GetDlgItemTextW (hwndDlg, IDC_EDIT_REGISTER_KEY, wszBuffer, MAX_KEYWORD - 2) ;
			if (n <= 0) {
				MessageBox (hwndDlg, TEXT ("�o�^����P��(�ϊ��O)����ł�"), TEXT ("�x��"), MB_OK) ;
				break ;
			}
			/*	����ϊ��̓o�^�Ȃ瑗�蕶����ǉ�����B
			 */
			if (fOkuri) 
				wszBuffer [n ++]	= (WCHAR)ch ;
			wszBuffer [n]	= L'\0' ;
			if (wcspbrk (wszBuffer, L" \t\n\r") != NULL) {
				MessageBox (hwndDlg, TEXT ("�o�^����P��(�ϊ��O)�Ɏg�p�ł��Ȃ�����(�󔒁A�^�u)���܂܂�Ă��܂�"), TEXT ("�x��"), MB_OK) ;
				break ;
			}
			pContainer->SetOkuri (fOkuri) ;

			/*	�ϊ����ʂ�ǉ�����B
			 */
			if (pContainer != NULL)
				pContainer->SetKeyword (wszBuffer) ;
			n	= GetDlgItemTextW (hwndDlg, IDC_EDIT_REGISTER_WORD, wszBuffer, MAX_KEYWORD - 1) ;
			if (n <= 0) {
				MessageBox (hwndDlg, TEXT ("�ϊ����ʂ���ł�"), TEXT ("�x��"), MB_OK) ;
				break ;
			}
			wszBuffer [n]	= L'\0' ;
			if (pContainer != NULL)
				pContainer->SetWord (wszBuffer) ;

			// Fall through. 
		}
		case	IDCANCEL: 
			EndDialog (hwndDlg, wParam) ; 
			return	TRUE ; 
		} 
    } 
	default:
		break ;
	}
	return	FALSE ;
}



