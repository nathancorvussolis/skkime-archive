//
// precomp.cpp
//
// Stub for vc precompiled header.
//

#include "globals.h"

