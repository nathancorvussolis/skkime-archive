/*	dap.cpp
 *
 *	ITfDisplayAttributeProvider implementation
 *
 *	���[�ށA��񂵂ɂ��Ă݂邩�B
 */

#include "globals.h"
#include "skimic.h"
#include "edai.h"
#include "dai.h"

STDAPI
CSkkImeTextService::EnumDisplayAttributeInfo (
	IEnumTfDisplayAttributeInfo**	ppEnum)
{
    CEnumDisplayAttributeInfo*	pAttributeEnum ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::EnumDisplayAttributeInfo\n"))) ;

    if (ppEnum == NULL)
        return	E_INVALIDARG ;

    *ppEnum	= NULL;
    if ((pAttributeEnum = new CEnumDisplayAttributeInfo) == NULL)
        return	E_OUTOFMEMORY ;

    *ppEnum	= pAttributeEnum ;
    return	S_OK ;
}

STDAPI
CSkkImeTextService::GetDisplayAttributeInfo (
	REFGUID						guidInfo,
	ITfDisplayAttributeInfo**	ppInfo)
{
	ITfDisplayAttributeInfo*	pDAI	= NULL ;

    if (ppInfo == NULL)
        return	E_INVALIDARG ;

	DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetDisplayAttributeInfo\n"))) ;
    *ppInfo	= NULL ;
    if (IsEqualGUID (guidInfo, c_guidSkkImeDisplayAttributeInput)) {
		pDAI	= new CDisplayAttributeInfoInput () ;
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetDisplayAttributeInfo (input)\n"))) ;
	} else if (IsEqualGUID (guidInfo, c_guidSkkImeDisplayAttributeTargetConverted)) {
		pDAI	= new CDisplayAttributeInfoConverted () ;
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::GetDisplayAttributeInfo (converted)\n"))) ;
	} else {
        return	E_INVALIDARG ;
	}
	if (pDAI == NULL)
		return	E_OUTOFMEMORY ;
	*ppInfo	= pDAI ;
    return	S_OK ;
}

/*========================================================================*
 */

BOOL
CSkkImeTextService::_InitDisplayAttributeGuidAtom ()
{
	ITfCategoryMgr*	pCategoryMgr ;
	HRESULT			hr ;
	BOOL			fRetval	= TRUE ;

    hr	= CoCreateInstance (CLSID_TF_CategoryMgr,
							NULL, 
                            CLSCTX_INPROC_SERVER, 
                            IID_ITfCategoryMgr, 
                            (LPVOID*)&pCategoryMgr) ;
    if (FAILED (hr)) 
		return	FALSE ;

	if (FAILED (pCategoryMgr->RegisterGUID (c_guidSkkImeDisplayAttributeInput, &m_gaDisplayAttributeInput)) ||
		FAILED (pCategoryMgr->RegisterGUID (c_guidSkkImeDisplayAttributeTargetConverted, &m_gaDisplayAttributeConverted))) {
		fRetval	= FALSE ;
	}
	pCategoryMgr->Release () ;
	return	fRetval ;
}



