//
// editsess.h
//
// CEditSessionBase declaration.
//

#ifndef EDITSESS_H
#define EDITSESS_H

class CEditSessionBase : public ITfEditSession
{
public:
    CEditSessionBase(ITfContext *pContext)
    {
        m_cRef = 1;
        m_pContext = pContext;
        m_pContext->AddRef();
    }
    virtual ~CEditSessionBase()
    {
        m_pContext->Release();
    }

    // IUnknown
    STDMETHODIMP QueryInterface(REFIID riid, void **ppvObj)
    {
        if (ppvObj == NULL)
            return E_INVALIDARG;

        *ppvObj = NULL;

        if (IsEqualIID(riid, IID_IUnknown) ||
            IsEqualIID(riid, IID_ITfEditSession))
        {
            *ppvObj = (ITfLangBarItemButton *)this;
        }

        if (*ppvObj)
        {
            AddRef();
            return S_OK;
        }

        return E_NOINTERFACE;
    }
    STDMETHODIMP_(ULONG) AddRef(void)
    {
        return ++m_cRef;
    }
    STDMETHODIMP_(ULONG) Release(void)
    {
        LONG cr = --m_cRef;

        assert(m_cRef >= 0);

        if (m_cRef == 0)
        {
            delete this;
        }

        return cr;
    }

    // ITfEditSession
    virtual STDMETHODIMP DoEditSession(TfEditCookie ec) = 0;

protected:
    ITfContext *m_pContext;

private:
    LONG m_cRef;     // COM ref count
};

#endif // EDITSESS_H
