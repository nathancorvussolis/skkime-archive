#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "uistatus.h"
#include "commctrl.h"
#include "IME\ImeDoc.h"
#include "editsess.h"

static	HFONT	_CheckNativeCharset (HDC hDC) ;
static	void	_AdjustRect (RECT* prcDest, LPCWSTR pwstr, int nstr, const RECT* prcSrc) ;
static	BOOL	_ConfigureToolTip (HWND hwnd, HWND hwndTT, LPCWSTR strMessage, int nstrMessage, const IMETEXTATTRIBUTE* pTextAttrs, int nTextAttrs) ;

class CGetTextExtentEditSession : public CEditSessionBase
{
public:
    CGetTextExtentEditSession (CSkkImeTextService* pTSF, ITfContext* pContext, ITfContextView* pContextView, ITfRange* pRange, CUIStatus* pUIStatus) : CEditSessionBase (pContext)
    {
		_pTSF				= pTSF ;
        _pContextView		= pContextView ;
		m_pContext			= pContext ;
        _pRange				= pRange ;
		_pUIStatus			= pUIStatus ;
    }

    // ITfEditSession
    STDMETHODIMP	DoEditSession (TfEditCookie ec) ;

private:
	CSkkImeTextService*	_pTSF ;
    ITfContextView*		_pContextView ;
	ITfContext*			m_pContext ;
    ITfRange*			_pRange ;
	CUIStatus*			_pUIStatus ;
} ;

STDAPI
CGetTextExtentEditSession::DoEditSession (TfEditCookie ec)
{
	RECT					rc, rcTemp ;
    BOOL					fClipped ;
	HRESULT					hr ;
	BOOL					bEmpty ;
	BOOL					bOk	= FALSE ;

	if (FAILED (_pContextView->GetScreenExt (&rcTemp)))
		return	S_FALSE ;

	if (FAILED (_pRange->IsEmpty (ec, &bEmpty)) || bEmpty) {
		DEBUGPRINTF ((TEXT ("CGetTextExtentEditSession: _pRange is empty.\n"))) ;
		ITfContext*				pContext			= NULL ;
		ITfInsertAtSelection*	pInsertAtSelection	= NULL ;
		ITfRange*				pRange				= NULL ;

		if (SUCCEEDED (_pRange->GetContext (&pContext)) && pContext != NULL) {
			if (SUCCEEDED (pContext->QueryInterface (IID_ITfInsertAtSelection, (void**)&pInsertAtSelection)) && 
				pInsertAtSelection != NULL) {
				hr	= pInsertAtSelection->InsertTextAtSelection (ec, TF_IAS_QUERYONLY, L"��", 1, &pRange) ;
				if (hr == S_OK && pRange != NULL) {
					if (FAILED (pRange->IsEmpty (ec, &bEmpty)) || bEmpty) {
						DEBUGPRINTF ((TEXT ("CGetTextExtentEditSession: pRange is empty, too.\n"))) ;
					}
					hr	= _pContextView->GetTextExt (ec, pRange, &rc, &fClipped) ;
					if (hr == S_OK && rc.top < rc.bottom) {
						DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d)\n"), rc.left, rc.right, rc.top, rc.bottom)) ;
						rc.left		= rcTemp.left ;
						rc.right	= rcTemp.right ;
						_pUIStatus->_SetTargetRect (&rc) ;
						bOk			= TRUE ;
					}
					pRange->Release () ;
				}
				pInsertAtSelection->Release () ;
			}
			pContext->Release () ;
		}
	}
	if (! bOk) {
		hr	= _pContextView->GetTextExt (ec, _pRange, &rc, &fClipped) ;
		if (hr == S_OK && rc.top < rc.bottom) {
			DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d)\n"), rc.left, rc.right, rc.top, rc.bottom)) ;
			rc.left		= rcTemp.left ;
			rc.right	= rcTemp.right ;
			_pUIStatus->_SetTargetRect (&rc) ;
		} else {
			DEBUGPRINTF ((TEXT ("_pContextView->GetTextExt(l:%d,r:%d,t:%d,b:%d) failed(0x%x),(range:%p)\n"),
				rc.left, rc.right, rc.top, rc.bottom,
				hr, _pRange)) ;
			_pUIStatus->_SetTargetRect (&rcTemp) ;
		}
	}
    return	S_OK ;
}

const TCHAR		CUIStatus::_szUIStatusWndClass []	= TEXT ("SkkImeTextService001500 UIStatus Wnd Class") ;

CUIStatus::CUIStatus (
	CSkkImeTextService*		pTSF,
	CSkkImeMgr*				pIME)
{
	_pTSF					= pTSF ;
	_pIME					= pIME ;
	m_pContext				= NULL ;
	_pRange					= NULL ;
	_dwCookieTextLayoutSink	= TF_INVALID_COOKIE ;
	_hwnd					= NULL ;
	_cRef					= 1 ;
	_bButtonPressed			= FALSE ;
	_rcTarget.left	= _rcTarget.top		= 0 ;
	_rcTarget.right	= _rcTarget.bottom	= 1 ;
	DllAddRef () ;
	return ;
}

CUIStatus::~CUIStatus ()
{
	_Close () ;
	DllRelease () ;
	return ;
}

STDAPI
CUIStatus::QueryInterface (REFIID riid, void** ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
    if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfTextLayoutSink)) {
        *ppvObj = (ITfTextLayoutSink *)this ;
    }

    if (*ppvObj) {
        AddRef () ;
        return	S_OK ;
    }
    return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CUIStatus::AddRef ()
{
    return	++_cRef ;
}

STDAPI_(ULONG)
CUIStatus::Release ()
{
    LONG	cr = --_cRef ;

    assert (_cRef >= 0) ;

    if (_cRef == 0) {
        delete	this ;
    }
    return	cr ;
}

STDAPI
CUIStatus::OnLayoutChange (
	ITfContext*			pContext,
	TfLayoutCode		lcode,
	ITfContextView*		pContextView)
{
	DEBUGPRINTF ((TEXT ("CUIStatus::OnLayoutChange ()\n"))) ;

    if (pContext != m_pContext)
        return	S_OK ;

    switch (lcode) {
	case	TF_LC_CREATE:
	case	TF_LC_CHANGE:
		DEBUGPRINTF ((TEXT ("CUIStatus::OnLayoutChange (TF_LC_CHANGE)\n"))) ;
		if (_hwnd != NULL) 
			_AdjustWindow (pContextView) ;
		break ;

	case TF_LC_DESTROY:
		DEBUGPRINTF ((TEXT ("CUIStatus::OnLayoutChange (TF_LC_DESTROY)\n"))) ;
		_Close () ;
		break ;
	default:
		break ;
    }
    return	S_OK ;
}

/*========================================================================*
 */
HRESULT
CUIStatus::_Open (
	ITfContext*			pContextDocument,
	ITfRange*			pRange)
{
	ITfContextView*	pContextView	= NULL ;
    HRESULT			hr				= E_FAIL ;

	DEBUGPRINTF ((TEXT ("CUIStatus::_ShowWindow (Context:%p)\n"), pContextDocument)) ;

	_Close () ;
	_pRange		= pRange ;
	if (_pRange != NULL)
		_pRange->AddRef () ;
    m_pContext	= pContextDocument ;
    m_pContext->AddRef () ;
    if (FAILED (_AdviseTextLayoutSink ()))
        goto	Exit ;

	if (_CreateWindow ()) {
		RECT					rcUI ;
		CImeDoc*				pDoc	= NULL ;
		LPCWSTR					wstrTop ;
		int						nwstr ;
		const IMETEXTATTRIBUTE*	pTextAttrs ;
		int						nTextAttrs ;

		if (FAILED (m_pContext->GetActiveView (&pContextView))) 
			goto	Skip ;
		_AdjustWindow (pContextView) ;
Skip:
		pDoc	= (_pIME != NULL)? _pIME->GetDocument () : NULL ;
		if (pDoc != NULL) {
			wstrTop		= pDoc->pGetStatusText (&nwstr) ;
			pTextAttrs	= pDoc->pGetStatusTextAttributes (&nTextAttrs) ;
		} else {
			wstrTop		= NULL ;
			nwstr		= 0 ;
			pTextAttrs	= NULL ;
			nTextAttrs	= 0 ;
		}
		_AdjustRect (&rcUI, wstrTop, nwstr, &_rcTarget) ;
		MoveWindow (_hwnd, rcUI.left, rcUI.top, rcUI.right, rcUI.bottom, TRUE) ;
		DEBUGPRINTF ((TEXT ("CUIStatus::_Open -> MoveWindow (%d, %d, %d, %d)\n"),
			rcUI.left, rcUI.top, rcUI.right, rcUI.bottom)) ;

		_ConfigureToolTip (_hwnd, _hwndTT, wstrTop, nwstr, pTextAttrs, nTextAttrs) ;
		ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
		hr	= S_OK ;
    }
Exit:
	_bButtonPressed	= FALSE ;
	if (pContextView != NULL)
		pContextView->Release () ;
    if (FAILED (hr)) 
		_Close () ;
    return	hr ;
}

void
CUIStatus::_Update ()
{
	CImeDoc*				pDoc	= NULL ;
	RECT					rcWnd, rcUI, rc ;
	LPCWSTR					wstrTop ;
	int						nwstr ;
	const IMETEXTATTRIBUTE*	pTextAttrs ;
	int						nTextAttrs ;

	if (_hwnd == NULL || m_pContext == NULL)
		return ;
#if 0 //defined (DEBUG) || defined (_DEBUG)
	{
		ITfContextView*	pContextView	= NULL ;
		if (SUCCEEDED (m_pContext->GetActiveView (&pContextView)) && pContextView != NULL) {
			_QueryWindowPos (pContextView) ;
			pContextView->Release () ;
		}
	}
#endif
	GetWindowRect (_hwnd, &rcWnd) ;
	GetClientRect (_hwnd, &rc) ;
	rc.left	= rcWnd.left ;
	rc.top	= rcWnd.top ;
	pDoc	= (_pIME != NULL)? _pIME->GetDocument () : NULL ;
	if (pDoc != NULL) {
		wstrTop		= pDoc->pGetStatusText (&nwstr) ;
		pTextAttrs	= pDoc->pGetStatusTextAttributes (&nTextAttrs) ;
	} else {
		wstrTop		= NULL ;
		nwstr		= 0 ;
		pTextAttrs	= NULL ;
		nTextAttrs	= 0 ;
	}
	_AdjustRect (&rcUI, wstrTop, nwstr, &_rcTarget) ;
	if (rcUI.left  != rcWnd.left || rcUI.top != rcWnd.top ||
		rcUI.right != (rcWnd.right - rcWnd.left) || rcUI.bottom != (rcWnd.bottom - rcWnd.top)) {
		DEBUGPRINTF ((TEXT ("CUIStatus::_Update (position(%d,%d,w:%d,h:%d)->(%d,%d,w:%d,h:%d),%d,%d\n"),
			rcWnd.left, rcWnd.top, rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top,
			rcUI.left, rcUI.top, rcUI.right, rcUI.bottom)) ;
		MoveWindow (_hwnd, rcUI.left, rcUI.top, rcUI.right, rcUI.bottom, TRUE) ;
		ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
	}
	_ConfigureToolTip (_hwnd, _hwndTT, wstrTop, nwstr, pTextAttrs, nTextAttrs) ;
	ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
	InvalidateRect (_hwnd, NULL, FALSE) ;
	return ;
}

void
CUIStatus::_Close ()
{
	DEBUGPRINTF ((TEXT ("CUIStatus::_Close ()\n"))) ;

    if (_hwnd) {
		DEBUGPRINTF ((TEXT ("CUIStatus::_Close () -> DestroyWindow\n"))) ;
		ShowWindow (_hwnd, SW_HIDE) ;
		DestroyWindow (_hwnd) ;
		_hwnd	= NULL ;
    }
    if (m_pContext) {
		_UnadviseTextLayoutSink () ;
		m_pContext->Release () ;
		m_pContext	= NULL ;
    }
	if (_pRange) {
		_pRange->Release () ;
		_pRange		= NULL ;
	}
	_dwCookieTextLayoutSink	= TF_INVALID_COOKIE ;
	return ;
}

void
CUIStatus::_Popup (BOOL fShow)
{
	if (_hwnd == NULL || m_pContext == NULL)
		return ;
	ShowWindow (_hwnd, fShow? SW_SHOWNOACTIVATE : SW_HIDE) ;
	return ;
}

BOOL
CUIStatus::_IsContextStatusWindow (ITfContext* pContext) const
{
	return	(pContext == m_pContext) ;
}

BOOL
CUIStatus::_IsActivep (ITfContext* pContext) const
{
	return	_hwnd != NULL && _IsContextStatusWindow (pContext) ;
}

HRESULT
CUIStatus::_AdviseTextLayoutSink()
{
    HRESULT		hr ;
    ITfSource*	pSource	= NULL ;

    hr	= E_FAIL ;
    if (FAILED (m_pContext->QueryInterface (IID_ITfSource, (void **)&pSource)))
        goto	Exit ;

    if (FAILED (pSource->AdviseSink (IID_ITfTextLayoutSink, (ITfTextLayoutSink *)this, &_dwCookieTextLayoutSink)))
        goto	Exit ;

    hr	= S_OK ;
Exit:
    if (pSource != NULL)
        pSource->Release () ;
    return	hr ;
}

HRESULT
CUIStatus::_UnadviseTextLayoutSink()
{
    HRESULT		hr ;
    ITfSource*	pSource	= NULL ;

    hr	= E_FAIL ;
    if (m_pContext == NULL)
        goto	Exit ;

    if (FAILED (m_pContext->QueryInterface (IID_ITfSource, (void **)&pSource)))
        goto	Exit ;

    if (FAILED (pSource->UnadviseSink (_dwCookieTextLayoutSink)))
        goto	Exit;

    hr	= S_OK ;
Exit:
    if (pSource != NULL)
        pSource->Release () ;
    return	hr ;
}

/*========================================================================*
 */
BOOL
CUIStatus::_CreateWindow ()
{
	WNDCLASS	wc ;

	if (_hwnd != NULL)
		return	TRUE ;

	memset (&wc, 0, sizeof (wc)) ;
	wc.lpfnWndProc		= _UIStatusWndProc ;
	wc.hInstance		= g_hInst ;
	wc.lpszClassName	= _szUIStatusWndClass ;

	if (RegisterClass (&wc) == 0) {
		DWORD	dwError	= GetLastError () ;
		if (dwError != ERROR_CLASS_ALREADY_EXISTS) {
			DEBUGPRINTF ((TEXT ("CUIStatus::_RegisterClass (0x%lx) failed.\n"), dwError)) ;
			return	FALSE ;
		}
	}
	_hwnd	= CreateWindowEx (WS_EX_DLGMODALFRAME | WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
							  _szUIStatusWndClass,
							  TEXT ("SkkImeTextService UIStatus Wnd"),
							  WS_DISABLED | WS_POPUP,
							  0, 0, 100, 32, NULL, NULL, g_hInst, this) ;
	if (_hwnd == NULL) {
		DEBUGPRINTF ((TEXT ("CUIStatus::_CreateWindowEx () failed.\n"))) ;
		return	FALSE ;
	}
	ShowWindow (_hwnd, SW_HIDE) ;

	/*	tooltip Window ���쐬����B*/
	_hwndTT	= CreateWindowEx (WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL, WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP | WS_DISABLED,		
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, _hwnd, NULL, g_hInst, NULL) ;
	if (_hwndTT == NULL) {
		DEBUGPRINTF ((TEXT ("CUIStatus::_CreateWindowEx () failed (tooltip).\n"))) ;
		return	FALSE ;
	}
	ShowWindow (_hwndTT, SW_SHOWNOACTIVATE) ;
	return	TRUE ;
}

void
CUIStatus::_SetTargetRect (
	const RECT*		pRect)
{
	if (pRect != NULL) {
		_rcTarget	= *pRect ;
	} else {
		_rcTarget.left  = _rcTarget.top    = 0 ;
		_rcTarget.right = _rcTarget.bottom = 1 ;
	}
	return ;
}

void
CUIStatus::_AdjustWindow (
	ITfContextView*		pContextView)
{
	CGetTextExtentEditSession*	pEditSession ;
	HRESULT						hr ;
	
	if (m_pContext == NULL || _hwnd == NULL || pContextView == NULL)
		return ;

	pEditSession	= new CGetTextExtentEditSession (_pTSF, m_pContext, pContextView, _pRange, this) ;
	if (pEditSession != NULL) {
		m_pContext->RequestEditSession (_pTSF->_GetClientId (), pEditSession, TF_ES_SYNC | TF_ES_READ, &hr) ;
		if (hr == S_OK) {
			LPCWSTR						wstrTop ;
			int							nwstr ;
			CSkkImeMgr*					pIME	= NULL ;
			CImeDoc*					pDoc	= NULL ;
			const IMETEXTATTRIBUTE*		pTextAttrs ;
			int							nTextAttrs ;
			RECT						rcUI ;

			pIME	= (_pTSF != NULL)? _pTSF->_GetCurrentIME () : NULL ;
			pDoc	= (pIME  != NULL)? pIME->GetDocument () : NULL ;
			if (pDoc != NULL) {
				wstrTop		= pDoc->pGetStatusText (&nwstr) ;
				pTextAttrs	= pDoc->pGetStatusTextAttributes (&nTextAttrs) ;
			} else {
				wstrTop		= NULL ;
				nwstr		= 0 ;
				pTextAttrs	= NULL ;
				nTextAttrs	= 0 ;
			}
			_AdjustRect (&rcUI, wstrTop, nwstr, &_rcTarget) ;
			MoveWindow (_hwnd, rcUI.left, rcUI.top, rcUI.right, rcUI.bottom, TRUE) ;
			_ConfigureToolTip (_hwnd, _hwndTT, wstrTop, nwstr, pTextAttrs, nTextAttrs) ;
			ShowWindow (_hwnd, SW_SHOWNOACTIVATE) ;
		}
		pEditSession->Release () ;
	}
	return ;
}

#if defined (DEBUG) || defined (_DEBUG)
void
CUIStatus::_QueryWindowPos (
	ITfContextView*		pContextView)
{
	CGetTextExtentEditSession*	pEditSession ;
	HRESULT						hr ;
	RECT						rc ;
	
	if (m_pContext == NULL || _hwnd == NULL || pContextView == NULL)
		return ;

	rc				= _rcTarget ;
	pEditSession	= new CGetTextExtentEditSession (_pTSF, m_pContext, pContextView, _pRange, this) ;
	if (pEditSession != NULL) {
		m_pContext->RequestEditSession (_pTSF->_GetClientId (), pEditSession, TF_ES_SYNC | TF_ES_READ, &hr) ;
		if (hr == S_OK) {
			DEBUGPRINTF ((TEXT ("Query result(l:%d, r:%d, t:%d, b:%d)\n"),
				_rcTarget.left, _rcTarget.right, _rcTarget.top, _rcTarget.bottom)) ;
		}
		pEditSession->Release () ;
	}
	_rcTarget		= rc ;
	return ;
}
#endif

void
CUIStatus::_PaintUIStatusWnd (
	HWND	hwnd,
	HDC		hdc)
{
	HFONT		hOldFont ;

	hOldFont	= _CheckNativeCharset (hdc) ;
	_Paint (hdc) ;
//	DeleteObject (SelectObject (hdc, hOldFont)) ;
	SelectObject (hdc, hOldFont) ;
	return ;
}

BOOL
CUIStatus::_Paint (
	HDC			hdc)
{
	CImeDoc*	pDoc	= NULL ;
	register LPCWSTR	wstrTop ;
	register LPCWSTR	pText ;
	int			nwstr, nCursor, nText, nTextPos, x, y, nDY ;
	TEXTMETRIC	tm ;
	HBRUSH		hbrush ;
	BOOL		fCursor ;
	RECT		rc ;
	const IMETEXTATTRIBUTE*	pTextAttrs = NULL ;
	int						nTextAttrs = 0 ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return	FALSE ;

	wstrTop	= pDoc->pGetStatusText (&nwstr) ;
	if (nwstr <= 0 || wstrTop == NULL) {
		ShowWindow (_hwnd, SW_HIDE) ;
		return	FALSE ;
	}

	fCursor		= pDoc->bGetStatusCursor (&nCursor) ;
	pTextAttrs	= pDoc->pGetStatusTextAttributes (&nTextAttrs) ;

	GetClientRect (_hwnd, &rc) ;
	if (GetTextMetrics (hdc, &tm)) {
		nDY	= tm.tmHeight ;
	} else {
		nDY	= 1 ;
	}
	hbrush		=  (HBRUSH) GetClassLongPtr (_hwnd, GCLP_HBRBACKGROUND) ;
	pText		= wstrTop ;
	nText		= nwstr ;
	nTextPos	= 0 ;
	y			= 0 ;
	while (y < rc.bottom && 0 < nText) {
		int		nChar ;
		SIZE	sz ;
		RECT	rcErase ;

		x	= 0 ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			GetTextExtentPoint32W (hdc, pText, nChar, &sz) ;
			if ((x + sz.cx) >= rc.right) 
				break ;
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;

		_TextOut (hdc, x, y, pText, nChar, (fCursor && 0 <= nCursor && nCursor <= nChar)? &nCursor : NULL, &sz) ;
		if (sz.cy < nDY) {
			rcErase.left		= x ;
			rcErase.right	= x + sz.cx ;
			rcErase.top		= y + sz.cy ;
			rcErase.bottom	= y + nDY ;
			FillRect (hdc, &rcErase, hbrush) ;
		}

		if (nTextAttrs > 0) {
			int	nOffset	= pText - wstrTop ;

			while (nTextAttrs > 0) {
				SIZE	szL, szR ;
				int		n ;

				if (pTextAttrs->m_nStartPos < nOffset) {
					szL.cx	= szL.cy	= 0 ;
				} else {
					n	= pTextAttrs->m_nStartPos - nOffset ;
					if (n >= nChar)
						break ;
					GetTextExtentPoint32W (hdc, pText, n, &szL) ;
				}
				if (szL.cx >= rc.right)
					break ;

				if (pTextAttrs->m_nEndPos < nOffset) {
					//	����͕\���̂��悤���Ȃ��̂� skip
				} else {
					n	= pTextAttrs->m_nEndPos - nOffset ;
					if (n >= nChar) {
						GetTextExtentPoint32W (hdc, pText, nChar, &szR) ;
						MoveToEx (hdc, x + szL.cx, y + nDY - 1, NULL) ;
						LineTo (hdc, x + szR.cx, y + nDY - 1) ;
						break ;
					} else {
						GetTextExtentPoint32W (hdc, pText, n, &szR) ;
						MoveToEx (hdc, x + szL.cx, y + nDY - 1, NULL) ;
						LineTo (hdc, x + szR.cx, y + nDY - 1) ;
					}
				}
				pTextAttrs	++ ;
				nTextAttrs	-- ;
			}
		}

		x	+= sz.cx ;
		if (nChar < nText) {
			/*	�܂�Ԃ��L����\������B*/
			_TextOut (hdc, x, y, L"\\", 1, NULL, &sz) ;
			x	+= sz.cx ;
		}
		if (x < rc.right) {
			rcErase.left	= x ;
			rcErase.right	= rc.right ; 
			rcErase.top		= y ;
			rcErase.bottom	= y + nDY ;
			FillRect (hdc, &rcErase, hbrush) ;
		}
		pText		+= nChar ;
		nTextPos	+= nChar ;
		nText		-= nChar ;
		nCursor		-= nChar ;
		y			+= nDY ;
	}
	return	TRUE ;
}

BOOL
CUIStatus::_TextOut (
	HDC			hdc,
	int			nX,
	int			nY,
	LPCWSTR		wstr, 
	int			nwstr,
	int*		pCursor,
	SIZE*		pSZ)
{
	SIZE	sz ;

	if (nwstr > 0) {
		TextOutW (hdc, nX, nY, wstr, nwstr) ;
		if (pCursor != NULL) {
			GetTextExtentPoint32W (hdc, wstr, *pCursor, &sz) ;
			Rectangle (hdc, nX + sz.cx, nY, nX + sz.cx + 1, nY + sz.cy) ;
		}
	} else {
		if (pCursor != NULL) {
			GetTextExtentPoint32W (hdc, L"|", 1, &sz) ;
			Rectangle (hdc, nX + sz.cx, nY, nX + sz.cx + 1, nY + sz.cy) ;
		}
	}
	if (pSZ != NULL) {
		if (nwstr > 0) {
			GetTextExtentPoint32W (hdc, wstr, nwstr, &sz) ;
			if (pCursor != NULL && *pCursor == nwstr)
				sz.cx	+= 1 ;
			*pSZ	= sz ;
		} else {
			GetTextExtentPoint32W (hdc, L"|", 1, pSZ) ;
			pSZ->cx	= 1 ;
		}
	}
	return	TRUE ;
}

void
CUIStatus::_RelayEventToTooltip (
	HWND		hWnd,
	UINT		uMessage)
{
	MSG				msg ;
	POINT			pt ;

	if (! IsWindow (_hwndTT) || ! GetCursorPos (&pt))
		return ;

	switch (uMessage) {
		case	WM_SETCURSOR:
			{
				msg.hwnd	= hWnd ;
				msg.message	= WM_MOUSEMOVE ;
				msg.pt.x	= pt.x ;
				msg.pt.y	= pt.y ;
				ScreenToClient (hWnd, &pt) ;
				msg.lParam	= pt.y << 16 | pt.x ;
				msg.wParam	= 0 ;
				msg.time	= GetTickCount () ;
				(void) SendMessage (_hwndTT, (UINT) TTM_RELAYEVENT, (WPARAM) 0, (LPARAM) &msg) ;
				break ;
			}
		default:
			break ;
	}
	return ;
}

void
CUIStatus::_Drag (
	UINT		uMessage)
{
	CImeDoc*				pDoc	= NULL ;
	HDC						hDC ;
	int						nNewCursor ;
	POINT					pos ;
	LPCWSTR					wstrTop ;
	int						nwstr, nCursor ;
	BOOL					bCursor ;
	const IMETEXTATTRIBUTE*	pTextAttrs = NULL ;
	int						nTextAttrs = 0 ;

	/*	�}�E�X��������Ă��Ȃ���΁A�}�E�X�̃L�[�𗣂����ƃ}�E�X���ړ������邱��
	 *	�ɂ��J�[�\���̈ړ��͂Ȃ��B
	 */
	if (uMessage != WM_RBUTTONDOWN && uMessage != WM_RBUTTONUP &&
		uMessage != WM_LBUTTONDOWN && !_bButtonPressed)
		return ;

	GetCursorPos (&pos) ;
	if (!ScreenToClient (_hwnd, &pos))
		return ;

	pDoc	= _pIME->GetDocument () ;
	if (pDoc == NULL)
		return ;

	wstrTop	= pDoc->pGetStatusText (&nwstr) ;
	if (nwstr <= 0 || wstrTop == NULL) 
		return ;

	/*	Status Window �� Cursor ���ړ����Ă��Ȃ���Ζ�������B
	 */
	bCursor		= pDoc->bGetStatusCursor (&nCursor) ;
	if (! bCursor)
		return ;

	hDC		= GetDC (_hwnd) ;
	if (! hDC)
		return ;

	DEBUGPRINTF ((TEXT ("CUIStatus::_Drag (%d)\n"), uMessage)) ;
	if (uMessage != WM_RBUTTONUP && uMessage != WM_RBUTTONDOWN){
		struct TMSG		msg ;
		BOOL	bRedraw, bEaten ;

		memset (&msg, 0, sizeof (msg)) ;
		msg.m_nMessage	= uMessage ;
		msg.m_wParam	= 0 ;
		msg.m_lParam	= 0 ;
		msg.m_rParam	= 0 ;
		msg.m_nTime		= GetTickCount () ;

		nNewCursor	= _GetCursorPos (hDC, wstrTop, nwstr, &pos) ;
		/* �̈�I���J�n�ʒu���L������B*/
		switch (uMessage){
		case	WM_LBUTTONDOWN:
			{
				bRedraw	= (nNewCursor != nCursor) ;
				msg.m_wParam	= nNewCursor ;
				(void) pDoc->bFilterEvent (&msg) ;
#if 0
				ImeDoc_FilterKeyEvent (&lpMyCompStr->_Doc, MYVK_LBUTTON, dwCursor, NULL, &fEaten) ;
				SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
#endif
				if (bRedraw)
					InvalidateRect (_hwnd, NULL, FALSE) ;
			}
			break ;

		case	WM_LBUTTONUP:
			msg.m_lParam	|= 0x80000000L ;
			/*	fall-through */
		case	WM_MOUSEMOVE:
		case	WM_NCMOUSEMOVE:
			{
				if (_bButtonPressed) {
					bRedraw	= (nNewCursor != nCursor) ;
					msg.m_wParam	= nNewCursor ;
					(void) pDoc->bFilterEvent (&msg) ;
#if 0
					ImeDoc_FilterKeyEvent (&lpMyCompStr->_Doc, MYVK_LBUTTON, (LPARAM)nNewCursor, NULL, &fEaten) ;
					SKKUpdateComposition (hIMC, lpIMC, (LPCOMPOSITIONSTRING)lpMyCompStr, TRUE) ;
#endif
					if (bRedraw)
						InvalidateRect (_hwnd, NULL, FALSE) ;
				}
			}
			break ;
		default:
			break ;
		}
	}
	ReleaseDC (_hwnd, hDC) ;

	if (uMessage == WM_LBUTTONDOWN){
		_bButtonPressed	= TRUE ;
		SetCapture (_hwnd) ;
	}
	if (uMessage == WM_LBUTTONUP || uMessage == WM_RBUTTONUP){
		ReleaseCapture () ;
		_bButtonPressed	= FALSE ;
		if (uMessage == WM_RBUTTONUP){
		}
	}
	return ;
}

int
CUIStatus::_GetCursorPos (
	HDC								hDC,
	LPCWSTR							wstring,
	int								nwstring,
	const POINT*					lppoint)
{
	int				nCursor	= -1 ;
	SIZE			sz ;

	if (nwstring <= 0 || wstring == NULL || lppoint == NULL)
		return	0 ;

	nCursor	= 0 ;
	while (nCursor < nwstring) {
		if (! GetTextExtentPoint32W (hDC, wstring, nCursor + 1, &sz))
			break ;
		if (lppoint->x < sz.cx)
			break ;
		nCursor	++ ;
	}
	return	nCursor ;
}

LRESULT	CALLBACK
CUIStatus::_UIStatusWndProc (
	HWND			hwnd,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	CUIStatus*		pThis ;

	switch (uMsg) {
	case	WM_CREATE:
		SetWindowLongPtr (hwnd, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCT *)lParam)->lpCreateParams) ;
		return	0L ;

	case	WM_SETCURSOR:
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL) {
			if (IsWindow (pThis->_hwndTT))
				pThis->_RelayEventToTooltip (hwnd, WM_SETCURSOR) ;
			pThis->_Drag (HIWORD (lParam)) ;
		}
		return	0L ;

	case	WM_PAINT:
	{
		PAINTSTRUCT	ps ;
		HDC			hdc ;

		hdc		= BeginPaint (hwnd, &ps) ;
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL)
			pThis->_PaintUIStatusWnd (hwnd, hdc) ;
		EndPaint (hwnd, &ps) ;
		return	0L ;
	}

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MOUSEMOVE:
	case WM_NCMOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		pThis	= (CUIStatus*)GetWindowLongPtr (hwnd, GWLP_USERDATA) ;
		if (pThis != NULL)
			pThis->_Drag (uMsg) ;
		return	0L ;

	default:
		return	DefWindowProc (hwnd, uMsg, wParam, lParam) ;
	}
}

////////////////////////////////////////////////////////////////////////
//	private functions


////////////////////////////////////////////////////////////////////////
//	private functions

BOOL
_ConfigureToolTip (
	HWND					hwnd,
	HWND					hwndTT,
	LPCWSTR					strMessage,
	int						nstrMessage,
	const IMETEXTATTRIBUTE*	pTextAttrs,
	int						nTextAttrs)
{
	HFONT					hOldFont	= NULL ;
	HDC						hDC			= NULL ;
	int						nTools, nDY, y ;
	SIZE					szL, szR, sz ;
	UINT_PTR				uid ;
#if !defined (UNICODE) && !defined (_UNICODE)
	TCHAR					buf [256] ;
	int						n ;
#endif
	TOOLINFO				ti ;
	TEXTMETRIC				tm ;
	RECT					rc ;
	LPCWSTR					pText ;
	int						nTextOffset, nText ;

	if (! IsWindow (hwnd) || ! IsWindow (hwndTT))
		return	FALSE ;

	/*	�܂��S�Ă� TOOL ���폜����B*/
	ti.cbSize		= sizeof (ti) ;
	ti.uFlags		= 0 ;
	ti.hwnd			= hwnd ;
	ti.hinst		= g_hInst ;
	nTools			= SendMessage (hwndTT, TTM_GETTOOLCOUNT, (WPARAM)0, (LPARAM)0) ;	
	for (uid = 0 ; uid < (UINT) nTools ; uid ++) {
		ti.uId			= uid ;
		SendMessageW (hwndTT, TTM_DELTOOLW, 0, (LPARAM) (LPTOOLINFOW) &ti) ;	
	}
	if (strMessage == NULL || nstrMessage <= 0 || pTextAttrs == NULL || nTextAttrs <= 0)
		return	TRUE ;
	
	hDC			= GetDC (hwnd) ;
	if (!hDC)
		return	FALSE ;

	hOldFont	= _CheckNativeCharset (hDC) ;

	GetClientRect (hwnd, &rc) ;
	if (GetTextMetrics (hDC, &tm)) {
		nDY	= tm.tmHeight ;
	} else {
		nDY	= 1 ;
	}

	/*	TOOL ��ǉ�����B*/
	pText		= strMessage ;
	nTextOffset	= 0 ;
	y			= 0 ;
	sz.cx = sz.cy = 0 ;
	while (nTextAttrs > 0 && nTextOffset < nstrMessage) {
		/*	���o���B
		 *	(1) �s�� > TextAttribute �̊J�n�ʒu�A
		 *	(2) TextAttribute �̊J�n�ʒu <= �s���A
		 *	��2�̏ꍇ�����݂���B
		 *	��� (2) �̏ꍇ�ɂ́A�\���ʒu�͍��[����ɂȂ�B
		 */
		szL.cx	= szL.cy	= 0 ;
		while (pTextAttrs->m_nStartPos >= nTextOffset) {
			GetTextExtentPoint32W (hDC, pText, pTextAttrs->m_nStartPos - nTextOffset, &szL) ;
			if (szL.cx >= rc.right) {
				for (nText = pTextAttrs->m_nStartPos ; nText > 0 ; nText --) {
					GetTextExtentPoint32W (hDC, pText, nText, &sz) ;
					if (sz.cx < rc.right)
						break ;
				}
				pText		+= nText ;
				nTextOffset	+= nText ;
				y			+= nDY ;
			} else {
				break ;
			}
		}
		ti.cbSize		= sizeof (ti) ;
		ti.uFlags		= 0 ;
		ti.hwnd			= hwnd ;
		ti.hinst		= g_hInst ;
		ti.uId			= uid ;
		ti.rect.left	= szL.cx ;
		ti.rect.top		= y ;
#if defined (UNICODE) || defined (_UNICODE)
		ti.lpszText		= (WCHAR*) pTextAttrs->m_wszWord ;
#else
		n	= WideCharToMultiByte (932, 0, pTextAttrs->m_wszWord, pTextAttrs->m_nWordLen, buf, sizeof (buf) / sizeof (buf [0]) - 1, NULL, NULL) ;
		buf [n]			= TEXT ('\0') ;
		ti.lpszText		= buf ;
#endif

		GetTextExtentPoint32W (hDC, pText, pTextAttrs->m_nEndPos - nTextOffset,   &szR) ;
		if (szR.cx >= rc.right) {
			for (nText = pTextAttrs->m_nEndPos ; nText > 0 ; nText --) {
				GetTextExtentPoint32W (hDC, pText, nText, &sz) ;
				if (sz.cx < rc.right)
					break ;
			}
			ti.rect.right	= sz.cx ;
			pText		+= nText ;
			nTextOffset	+= nText ;
			y			+= nDY ;
		} else {
			ti.rect.right	= szR.cx ;
			pTextAttrs	++ ;
			nTextAttrs	-- ;
		}
		ti.rect.bottom	= ti.rect.top + szR.cy ;
		SendMessage (hwndTT, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti) ;
		uid			++ ;
	}
	if (hDC != NULL) {
//		if (hOldFont) 
//			DeleteObject (SelectObject (hDC, hOldFont)) ;
		SelectObject (hDC, hOldFont) ;
		ReleaseDC (hwnd, hDC) ;
	}
	return	TRUE ;
}

#if 0
HFONT
_CheckNativeCharset (
	HDC	hDC) 
{
#if 0
	BOOL		bDiffCharSet	= FALSE ;
	HFONT		hOldFont ;
	LOGFONT		lfFont ;

	hOldFont	= (HFONT) GetCurrentObject (hDC, OBJ_FONT) ;
	GetObject (hOldFont, sizeof(LOGFONT), &lfFont) ;

	if (lfFont.lfCharSet != SHIFTJIS_CHARSET/*NATIVE_CHARSET*/) {
		bDiffCharSet			= TRUE ;
		lfFont.lfWeight			= FW_NORMAL ;
		lfFont.lfCharSet		= SHIFTJIS_CHARSET ; //NATIVE_CHARSET
		lfFont.lfFaceName[0]	= TEXT ('\0') ;
		SelectObject (hDC, CreateFontIndirect (&lfFont)) ;
	} else {
		hOldFont				= NULL ;
	}
#else
	hOldFont	= (HFONT) SelectObject (hDC, (HFONT) GetStockObject (DEFAULT_GUI_FONT)) ;
#endif
	return	hOldFont ;
}
#endif

void
_AdjustRect (
	RECT*				prcDest,
	LPCWSTR				pText,
	int					nText,
	const RECT*			prcSrc)
{
	HDC					hdc ;
	HFONT				holdfont ;
	RECT				rcUI, rcWork ;
	int					nWidth, nHeight, nFontHeight, nFontWidth ;
	int					nFrameWidth, nFrameHeight, nDefaultWidth, nDefaultHeight ;
	TEXTMETRIC			tm ;
	SIZE				sz ;


	memset (&rcUI, 0, sizeof (rcUI)) ;

	/*	��ʑS�̂̃T�C�Y�𓾂�B*/
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, 0) ;

	hdc		= CreateDC (TEXT ("DISPLAY"), NULL, NULL, NULL) ;
	if (hdc == NULL) {
		if (prcDest != NULL) {
			prcDest->left	= 0 ;
			prcDest->top	= 0 ;
			prcDest->right	= rcWork.right ;
			prcDest->bottom	= 18 ;
		}
		return ;	// ���̏ꍇ�͌v�Z�s�\�B
	}

	holdfont	= (HFONT) _CheckNativeCharset (hdc) ;
	if (GetTextMetrics (hdc, &tm)) {
		nFontWidth	= tm.tmAveCharWidth ;
		nFontHeight	= tm.tmHeight ;
	} else {
		GetTextExtentPoint32W (hdc, L"��", 1, &sz) ;
		nFontWidth	= (sz.cx + 1) / 2 ;
		nFontHeight	= sz.cy ;
	}
	nFrameWidth		= GetSystemMetrics (SM_CXDLGFRAME) * 2 ;
	nFrameHeight	= GetSystemMetrics (SM_CYDLGFRAME) * 2 ;
	nDefaultWidth	= nFontWidth * 80 ;
	nDefaultHeight	= nFontHeight ;

	nWidth	= (prcSrc != NULL && nDefaultWidth < (prcSrc->right - prcSrc->left))? (prcSrc->right - prcSrc->left) : nDefaultWidth ;
	nHeight	= 0 ;

	if ((nWidth + nFrameWidth) > (rcWork.right - rcWork.left)) 
		nWidth	= rcWork.right - rcWork.left - nFrameWidth ;
	if (nWidth <= 0) {
		rcUI	= *prcSrc ;
		goto	exit_func ;
	}

	while (nText > 0) {
		int			nChar ;
		for (nChar = 1 ; nChar <= nText ; nChar ++) {
			GetTextExtentPoint32W (hdc, pText, nChar, &sz) ;
			if (sz.cx >= nWidth) 
				break ;
		}
		nChar	-- ;
		if (nChar <= 0)
			break ;
		nHeight	+= nFontHeight ;
		pText	+= nChar ;
		nText	-= nChar ;
	}
	if (nHeight <= 0)
		nHeight	= nFontHeight ;

	nWidth	+= nFrameWidth ;
	nHeight	+= nFrameHeight ;

	if ((prcSrc->left + nWidth) > (rcWork.right - rcWork.left)) {
		rcUI.left	= rcWork.right - nWidth ;
	} else {
		rcUI.left	= prcSrc->left ;
	}
	rcUI.right	= nWidth ;

	if ((prcSrc->bottom + nHeight) >= rcWork.bottom) {
		if ((prcSrc->top - nHeight) <= rcWork.top) {
			rcUI.top	= rcWork.bottom - nHeight ;
		} else {
			rcUI.top	= prcSrc->bottom + 1 ;
		}
	} else {
		rcUI.top	= prcSrc->bottom + 1 ;
	}
	rcUI.bottom	= nHeight ;

	DEBUGPRINTF ((TEXT ("View(l:%d, t:%d, r:%d, b:%d), WorkArea(l:%d, t:%d, r:%d, b:%d), w:%d, h:%d\n"),
				  prcSrc->left, prcSrc->top, prcSrc->right, prcSrc->bottom,
				  rcWork.left, rcWork.top, rcWork.right, rcWork.bottom,
				  nFontWidth, nFontHeight)) ;
exit_func:
	if (prcDest != NULL)
		*prcDest	= rcUI ;
//	DeleteObject (SelectObject (hdc, holdfont)) ;
	SelectObject (hdc, holdfont) ;
	DeleteDC (hdc) ;
	return ;
}

