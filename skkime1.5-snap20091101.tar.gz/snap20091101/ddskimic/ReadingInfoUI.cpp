#include "globals.h"
#include "skimic.h"
#include "ReadingInfoUI.h"

const GUID	CSkkImeReadingInfoUIElement::m_guidSkkImeReadingInfoUIElement =  {
	0xaa445ac4, 0xcaca, 0x4646, { 0xac, 0xcc, 0x39, 0x3e, 0xc7, 0x9f, 0x22, 0x76 }
} ;

LPCWSTR		CSkkImeReadingInfoUIElement::m_wstrDescription	= L"SKKIME ReadingInfo UIElement" ;
TCHAR		CSkkImeReadingInfoUIElement::m_szClassName []	= TEXT ("SkkImeTextService ReadingInfo Wnd Class") ;

CSkkImeReadingInfoUIElement::CSkkImeReadingInfoUIElement (
	CSkkImeTextService*		pTSF)
{
	m_pTSF			= pTSF ;
	m_cRef			= 1 ;
	m_wszText [0]	= L'\0' ;
	m_bShown		= FALSE ;
	m_bOpen			= FALSE ;
	m_hWnd			= NULL ;
	m_dwElementId	= (DWORD) -1 ;
	m_ptWnd.x		= 0 ;
	m_ptWnd.y		= 0 ;
	m_bConsole		= FALSE ;
	DllAddRef () ;
	return ;
}

CSkkImeReadingInfoUIElement::~CSkkImeReadingInfoUIElement ()
{
	DllRelease () ;
	return ;
}

STDAPI
CSkkImeReadingInfoUIElement::QueryInterface (REFIID riid, void **ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
#if defined (__ITfToolTipUIElement_INTERFACE_DEFINED__)
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfReadingInformationUIElement)) {
		*ppvObj	= (ITfReadingInformationUIElement *)this ;
#else
	if (IsEqualIID (riid, IID_IUnknown)) {
		*ppvObj	= (IUnknown *)this ;
#endif
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfUIElement)) {
		*ppvObj	= (ITfUIElement *)this ;
#endif
	} 
	if (*ppvObj) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

ULONG
CSkkImeReadingInfoUIElement::AddRef () 
{
	m_cRef	++ ;
	return	m_cRef ;
}

ULONG
CSkkImeReadingInfoUIElement::Release ()
{
	ULONG	cRef	= -- m_cRef ;

	if (cRef == 0)
		delete	this ;

	return	cRef ;
}

STDAPI
CSkkImeReadingInfoUIElement::GetDescription (BSTR* pbstrDescription) 
{
    BSTR	bstrDesc ;

    if (pbstrDescription == NULL)
        return	E_INVALIDARG ;
	if (m_wstrDescription == NULL)
		return	E_FAIL ;

    *pbstrDescription	= NULL ;
    if ((bstrDesc = SysAllocString(m_wstrDescription)) == NULL)
        return	E_OUTOFMEMORY ;

    *pbstrDescription	= bstrDesc ;
    return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::GetGUID (GUID* pguid) 
{
	if (pguid == NULL)
		return	E_INVALIDARG ;

	memcpy (pguid, &m_guidSkkImeReadingInfoUIElement, sizeof (m_guidSkkImeReadingInfoUIElement)) ;
	return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::Show (BOOL bShow) 
{
	/*
	 *	���� Show �́A
	 *		- BeginUIElement �Ŗ��񂱂������\���������� kick ����� application ���������Ă�
	 *		  �����̂Ȃ̂��A
	 *		- application ���ŏ��Ɏ��O�ŕ\�����邩�ǂ��������肵�āAtrue �� false �𓊂�����
	 *		  ���Ƃ͂��̂܂܂ɂȂ���̂Ȃ̂��A
	 *	�ǂ������^�C�~���O�ŌĂ΂��̂��낤�H
	 */
	m_bShown	= bShow ;
	return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::IsShown (BOOL* pbShow) 
{
	if (pbShow == NULL)
		return	E_INVALIDARG ;

	*pbShow	= m_bShown ;
	return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::GetUpdatedFlags (DWORD* pdwFlags)
{
	if (pdwFlags == NULL)
		return	E_INVALIDARG ;
	*pdwFlasg	= m_dwUpdateFlag ;
	m_dwUpdateFlag	= 0 ;
	return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::GetContext (ITfContext** ppic)
{
	if (ppic == NULL)
		return	E_INVALIDARG ;
	*ppic	= m_pContext ;
	return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::GetString (BSTR* pbstr) 
{
    BSTR	bstrText ;

    if (pbstr == NULL)
        return	E_INVALIDARG ;

    *pbstr	= NULL ;
    if ((bstrText = SysAllocString (m_wszText)) == NULL)
        return	E_OUTOFMEMORY ;

    *pbstr	= bstrText ;
    return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::GetMaxReadingStringLength (UINT* pcchMax)
{
	if (pcchMax == NULL)
		return	E_INVALIDARG ;
	*pcchMax	= MAXLEN_READINGSTRING ;
	return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::GetErrorIndex (UINT* pErrorIndex)
{
	if (pErrorIndex == NULL)
		return	E_INVALIDARG ;
	*pErrorIndex	= m_cchText ;	/* Error �𖳂��ƕ\������̂́C����ŗǂ��̂��H*/
	return	S_OK ;
}

STDAPI
CSkkImeReadingInfoUIElement::IsVerticalOrderPreferred (BOOL* pfVertical)
{
	if (pfVertical == NULL)
		return	E_INVALIDARG ;

	*pfVertical	= FALSE ;
	return	S_OK ;
}

/*========================================================================
 *	�����C���^�[�t�F�[�X�B
 */
BOOL
CSkkImeReadingInfoUIElement::_Init (BOOL bConsole)
{
	WNDCLASS	wc ;

	if (! bConsole) {
		memset (&wc, 0, sizeof (wc)) ;
		wc.lpfnWndProc		= CSkkImeReadingInfoUIElement::_WndProc ;
		wc.hInstance		= g_hInst ;
		wc.lpszClassName	= CSkkImeReadingInfoUIElement::m_szClassName ;
		if (RegisterClass (&wc) == 0) {
			DWORD	dwError	= GetLastError () ;
			if (dwError != ERROR_CLASS_ALREADY_EXISTS) {
				DEBUGPRINTF ((TEXT ("CUIStatus::_RegisterClass (0x%lx) failed.\n"), dwError)) ;
				return	FALSE ;
			}
		}
		/*	tooltip Window ���쐬����B*/
		m_hWnd		= CreateWindowEx (WS_EX_TOOLWINDOW | WS_EX_TOPMOST, (LPTSTR) m_szClassName, NULL, 
				WS_DISABLED | WS_POPUP | WS_BORDER, 0, 0, 1, 1, NULL, NULL, g_hInst, this) ;
		if (m_hWnd == NULL || ! IsWindow (m_hWnd)) {
			return	FALSE ;
		}
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShown	= FALSE ;
	} else {
		/* console mode �ł� Window �����Ȃ��B*/
		m_hWnd		= NULL ;
		m_bShown	= FALSE ;
	}
	m_bConsole	= bConsole ;
	return	TRUE ;
}

void
CSkkImeReadingInfoUIElement::_Uninit ()
{
	if (m_hWnd != NULL) {
		if (IsWindow (m_hWnd))
			DestroyWindow (m_hWnd) ;
		m_hWnd	= NULL ;
	}
	m_bShown	= FALSE ;
	m_bOpen		= FALSE ;
	m_bConsole	= FALSE ;
	return ;
}

void
CSkkImeReadingInfoUIElement::_SetText (
	LPCWSTR			wstrText)
{
	if (wstrText == NULL || *wstrText == L'\0') {
		_Clear () ;
	} else {
		_SetText (wstrText, lstrlenW (wstrText)) ;
	}
	return ;
}

void
CSkkImeReadingInfoUIElement::_SetText (
	LPCWSTR			wstrText,
	UINT			nTextLen)
{
	if (nTextLen <= 0 || wstrText == NULL) {
		_Clear () ;
		return ;
	}
	if (nTextLen >= MYARRAYSIZE (m_wszText)) {
#if __STDC_WANT_SECURE_LIB__
		wcsncpy_s (m_wszText, MYARRAYSIZE (m_wszText), wstrText, nTextLen) ;
#else
		wcsncpy (m_wszText, wstrText, MYARRAYSIZE (m_wszText) - 1 - 3) ;
#endif
		m_wszText [MYARRAYSIZE (m_wszText) - 1]	= L'\0' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 2]	= L'.' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 3]	= L'.' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 4]	= L'.' ;
	} else {
#if __STDC_WANT_SECURE_LIB__
		wcsncpy_s (m_wszText, MYARRAYSIZE (m_wszText), wstrText, nTextLen) ;
#else
		wcsncpy (m_wszText, wstrText, nTextLen) ;
#endif
		m_wszText [nTextLen]	= L'\0' ;
	}

	/* Point ���ێ������܂܃T�C�Y��ύX����B*/
	if (m_bShown && m_hWnd != NULL && IsWindow (m_hWnd)) {
		RECT	rc ;
		if (! _AdjustWindowRect (&rc)) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShown	= FALSE ;
		} else {
			MoveWindow (m_hWnd, rc.left, rc.top, rc.right, rc.bottom, TRUE) ;
		}
	}
	m_dwUpdateFlag	|= TF_RIUIE_STRING ;
	return ;
}

void
CSkkImeReadingInfoUIElement::_Clear () 
{
	m_wszText [0]	= L'\0' ;
	if (m_bShown) {
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShown	= FALSE ;
	}
	m_dwUpdateFlag	|= TF_RIUIE_STRING ;
	return ;
}

void
CSkkImeReadingInfoUIElement::_SetContext (
	ITfContext*			pContext)
{
	/*	AddRef/Release ����ׂ����H
	 */
	m_pContext		= pContext ;
	m_dwUpdateFlag	|= TF_RIUIE_CONTEXT ;
	return ;
}


