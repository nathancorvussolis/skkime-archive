#pragma once

#if !defined (DEBUGPRINTF)
#if defined (DEBUG) || defined (_DEBUG)
#define	DEBUGPRINTF(myformat)	DebugPrintf##myformat
#else
#define	DEBUGPRINTF(myformat)	/*myformat*/
#endif
#endif

#if defined (__cplusplus)
extern "C" {
#endif
void	DebugPrintf (LPCTSTR,...) ;
#if defined (__cplusplus)
}
#endif

