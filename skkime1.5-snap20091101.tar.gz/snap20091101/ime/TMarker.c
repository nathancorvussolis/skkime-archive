#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "TMarker.h"

BOOL
TMarker_bInit (
	struct TMarker*		pMarker,
	BOOL				fCursor)
{
	ASSERT (pMarker != NULL) ;
	pMarker->m_iPosition	= 0 ;
	pMarker->m_bCursor		= fCursor ;
	pMarker->m_bValid		= TRUE ;
	return	TRUE ;
}

int
TMarker_iGetPosition (
	const struct TMarker*	pMarker)
{
	ASSERT (pMarker != NULL) ;
	if (! pMarker->m_bValid)	/* ������ marker ����ʒu�͂Ƃ�Ȃ��B*/
		return	-1 ;
	return	pMarker->m_iPosition ;
}

BOOL
TMarker_bForward (
	struct TMarker*		pMarker,
	int					n)
{
	register int	nPos ;

	ASSERT (pMarker != NULL) ;
	if (! pMarker->m_bValid)
		return	FALSE ;
	nPos					= pMarker->m_iPosition + n ;
	pMarker->m_iPosition	= (nPos > 0)? nPos : 0 ;
	return	TRUE ;
}

BOOL
TMarker_bBackward (
	struct TMarker*		pMarker,
	int					n)
{
	register int	nPos ;

	ASSERT (pMarker != NULL) ;
	if (! pMarker->m_bValid)
		return	FALSE ;
	nPos					= pMarker->m_iPosition - n ;
	pMarker->m_iPosition	= (nPos > 0)? nPos : 0 ;
	return	TRUE ;
}

BOOL
TMarker_bIsCursor (
	const struct TMarker*		pMarker)
{
	ASSERT (pMarker != NULL) ;
	return	pMarker->m_bCursor ;
}

BOOL
TMarker_bSetCursor (
	struct TMarker*				pMarker,
	BOOL						bCursor)
{
	if (pMarker == NULL || ! TMarker_bIsValidp (pMarker))
		return	FALSE ;
	pMarker->m_bCursor	= bCursor ;
	return	TRUE ;
}

BOOL
TMarker_bIsValidp (
	const struct TMarker*		pMarker)
{
	ASSERT (pMarker != NULL) ;
	return	pMarker->m_bValid ;
}

BOOL
TMarker_bSetPosition (
	struct TMarker*			pMarker,
	const struct TMarker*	pMarkerSrc)
{
	ASSERT (pMarker    != NULL) ;
	ASSERT (pMarkerSrc != NULL) ;

	if (! pMarker->m_bValid || ! pMarkerSrc->m_bValid)
		return	FALSE ;
	pMarker->m_iPosition	= pMarkerSrc->m_iPosition ;
	return	TRUE ;
}

void
TMarker_vInvalidate (
	struct TMarker*		pMarker)
{
	ASSERT (pMarker != NULL) ;
	pMarker->m_bValid	= FALSE ;
	return ;
}

