#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif

#include "jstring.h"
#include "jisx0212.h"
#include "debug.h"

BOOL
bSkkHexChar (
	int			nCH)
{
	return	((L'0' <= nCH && nCH <= L'9') || (L'a' <= nCH && nCH <= L'f') || (L'A' <= nCH && nCH <= L'F'))? TRUE : FALSE ;
}

int
iSkkCharToHex (
	int			nCH)
{
	return	(L'0' <= nCH && nCH <= L'9')? (nCH - L'0') : ((L'a' <= nCH && nCH <= L'f')? (nCH - L'a' + 10) : ((L'A' <= nCH && nCH <= L'F')? (nCH - L'A' + 10) : 0)) ;
}

BOOL
bJisx0208LatinCharp (
	int			nCH)
{
	if (L'�I' <= nCH && nCH <= L'�`')
		return	TRUE ;
	return	FALSE ;
}

BOOL
bHiraganaCharp (
	int			nCH)
{
	if ((L'��' <= nCH && nCH <= L'��') || nCH == 0x3094 /* ``���J'' */)
		return	TRUE ;
	return	FALSE ;
}

BOOL
bKatakanaCharp (
	int			nCH)
{
	if (L'�@' <= nCH && nCH <= 0x30F4)
		return	TRUE ;
	return	FALSE ;
}

BOOL
bCJKKanjip (
	int			nCH)
{
	return	((0x4E00 <= nCH && nCH <= 0x9FA5) || (0xF929 <= nCH && nCH <= 0xFA2D))? TRUE : FALSE ;
}

BOOL
bSkkAsciiCharp (
	int			nCH)
{
	return	iswascii (nCH) ;
}

WORD
JisCharToSjisChar (
	register WORD	woChara)
{
	register WORD	n1, n2 ;

	n1		= (((woChara >> 8) + 1) >> 1) + 0x70 ;
	n1		= ((n1 >= 0xA0)? n1 + 0x40 : n1) ;
	n2		= (woChara & 0x00FF) + ((woChara & 0x0100)? 0x1F : 0x7D) ;
	n2		= ((n2 >= 0x7F)? n2 + 1 : n2) ;
	return	((n1 & 0x00FF) << 8) | (n2 & 0x00FF) ;
}

BOOL
bMakeUnicodeChar (
	int			iCharset,
	int			n1,
	int			n2,
	int*		pnRetval)
{
	/*	JIS0212 �� TABLE �� Windows �ł͂ǂ������̂��낤�H
	 */
	switch (iCharset) {
	case	KCODE_CHARSET_KATAKANA_JISX0201:
		{
			char	buf  [4] ;
			WCHAR	wbuf [4] ;
			int		n ;

			/* ���p�J�^�J�i		0x21�`0x5F (7�r�b�g) / 0xA1�`0xDF (8�r�b�g) */
			/* ���p�J�^�J�i	0xA1�`0xDF */
			n2	= n2 & 0x7F ;
			if (n2 < 0x21 || n2 > 0x5F || n1 != 0)
				return	FALSE ;
			buf [0]	= n2 | 0x80 ;
			/* CP_932 = SHIFT_JIS */
			n		= MultiByteToWideChar (932, 0, buf, 1, wbuf, ARRAYSIZE (wbuf)) ;
			if (n != 1)
				return	FALSE ;
			if (pnRetval != NULL)
				*pnRetval	= wbuf [0] ;
		}
		break ;
	case	KCODE_CHARSET_JAPANESE_JISX0208:
		{
			char	buf  [4] ;
			WCHAR	wbuf [4] ;
			int		nCode1, nCode2, n ;

			n1		= n1 & 0x7F ;
			n2		= n2 & 0x7F ;
			if (n1 < 0x21 || n2 < 0x21 || n1 >= (94 + 0x21) || n2 >= (94 + 0x21))
				return	FALSE ;
			nCode1	= ((n1 - 0x21) >> 1) + 0x81 ;
			nCode1	= (nCode1 >= 0xA0)? (nCode1 + 0x40) : nCode1 ;
			nCode2	= n2 + ((n1 & 1)? 0x1F : 0x7D) ;
			nCode2	= (nCode2 >= 0x7F)? (nCode2 + 1) : nCode2 ;
			buf [0]	= nCode1 ;
			buf [1]	= nCode2 ;
			/* CP_932 = SHIFT_JIS */
			n		= MultiByteToWideChar (932, 0, buf, 2, wbuf, ARRAYSIZE (wbuf)) ;
			if (n != 1)
				return	FALSE ;
			if (pnRetval != NULL)
				*pnRetval	= wbuf [0] ;
		}
		break ;
	case	KCODE_CHARSET_JAPANESE_JISX0212:
		{
			int		n ;

			n1	= (n1 & 0x7F) - 0x21 ;
			n2	= (n2 & 0x7F) - 0x21 ;
			if (n1 < 0 || n2 < 0 || n1 >= 94 || n2 >= 94)
				return	FALSE ;
			n	= n1 * 94 + n2 ;
			if (n >= ARRAYSIZE (_wUnicodeTblJISX0212))
				return	FALSE ;
			if (pnRetval != NULL)
				*pnRetval	= _wUnicodeTblJISX0212 [n] ;
		}
		break ;
	case	KCODE_CHARSET_UNICODE:
	default:
		{
			if (n1 < 0 || n2 < 0 || n1 > 0xFF || n2 > 0xFF)
				return	FALSE ;
			if (pnRetval != NULL)
				*pnRetval	= (n1 << 8) | n2 ;
		}
		break ;
	}
	return	TRUE ;
}

int
iSkkKatakanaToHiragana (
	LPDSTR		pDest,
	int			nDest,
	LPCDSTR		pSrc,
	int			nSrc,
	BOOL		bVExpand)
{
	LPCDSTR	pSrcEnd		= pSrc  + nSrc ;
	LPDSTR	pDestEnd	= pDest + nDest ;
	LPDSTR	pDestBak	= pDest ;
	int		nCH ;

	while (pDest < pDestEnd && pSrc < pSrcEnd) {
		nCH			= *pSrc ++ ;
		if (bVExpand && nCH == L'��') {
			*pDest ++	= L'��' ;
			if (pDest < pDestEnd)
				*pDest ++	= L'�J' ;
		} else {
			*pDest ++	= (L'�@' <= nCH && nCH <= (L'��' + 1))? (nCH + (L'��' - L'�@')) : nCH ;
		}
	}
	return	pDest - pDestBak ;
}

int
iSkkHiraganaToKatakana (
	LPDSTR		pDest,
	int			nDest,
	LPCDSTR		pSrc,
	int			nSrc,
	BOOL		bVContract)
{
	LPCDSTR	pSrcEnd		= pSrc  + nSrc ;
	LPDSTR	pDestEnd	= pDest + nDest ;
	LPDSTR	pDestBak	= pDest ;
	int		nCH ;

	while (pDest < pDestEnd && pSrc < pSrcEnd) {
		nCH			= *pSrc ++ ;
		if (bVContract && nCH == L'��' && (pSrc < pSrcEnd && *pSrc == L'�J')) {
			*pDest	++	= L'��' ;
			pSrc	++ ;
		} else {
			*pDest ++	= (L'��' <= nCH && nCH <= (L'��' + 1))? (nCH + (L'�@' - L'��')) : nCH ;
		}
	}
	return	pDest - pDestBak ;
}

int
iSkkJisx0208LatinToLatin (
	LPDSTR		pDest,
	int			nDest,
	LPCDSTR		pSrc,
	int			nSrc)
{
	int		nDestBak	= nDest ;
	int		nCH ;

	while (nDest > 0 && nSrc > 0) {
		nCH			= *pSrc ++ ;
		*pDest ++	= (L'�I' <= nCH && nCH <= L'�`')? (L'!' + (nCH - L'�I')) : nCH ;
		nSrc	-- ;
		nDest	-- ;
	}
	return	nDestBak - nDest ;
}

int
iSkkLatinToJisx0208Latin (
	LPDSTR		pDest,
	int			nDest,
	LPCDSTR		pSrc,
	int			nSrc)
{
	int		nDestBak	= nDest ;
	int		nCH ;

	while (nDest > 0 && nSrc > 0) {
		nCH			= *pSrc ++ ;
		*pDest ++	= (L'!' <= nCH && nCH <= L'~')? (L'�I' + (nCH - L'!')) : nCH ;
		nSrc	-- ;
		nDest	-- ;
	}
	return	nDestBak - nDest ;
}

int
iSkkComputeHenkanKey2 (
	LPDSTR		pDest,
	int			nDest,
	LPCDSTR		pSkkHenkanKey,
	int			nSkkHenkanKeyLen,
	LPCDSTR		pSkkHenkanOkurigana,
	int			nSkkHenkanOkurigana)
{
	LPCDSTR		wptr ;
	LPCDSTR		wptrLast ;

	if (nSkkHenkanOkurigana <= 0)
		return	0 ;

	wptrLast	= pSkkHenkanKey + nSkkHenkanKeyLen - 1 ;
	wptr		= wptrLast ;
	while (wptr >= pSkkHenkanKey && (L'a' <= *wptr && *wptr <= L'z'))
		wptr	-- ;
	if (wptr < wptrLast) {
		LPCDSTR	wptrOkuri ;
		int		nDestBak	= nDest ;

		wptrOkuri	= wptr + 1 ;
		wptr		= pSkkHenkanKey ;
		while (nDest > 0 && wptr < wptrOkuri) {
			*pDest ++	= *wptr ++ ;
			nDest -- ;
		}
		if (nDest > 0) {
			*pDest ++	= L'*' ;
			nDest -- ;
		}
		while (nDest > 0 && nSkkHenkanOkurigana > 0) {
			*pDest ++	= *pSkkHenkanOkurigana ++ ;
			nDest	-- ;
			nSkkHenkanOkurigana	-- ;
		}
		return	nDestBak - nDest ;
	} else {
		return	0 ;
	}
}

int
iSkkNumComputeHenkanKey (
	LPCDSTR			strHenkanKey,
	int				nHenkanKeyLen,
	LPDSTR			pResult,
	int				nResultSize,
	LPDSTR			pNumList,
	int				nNumListSize,
	BOOL			bFloat)			/* float value ���l�����邩�ۂ��B�A�� [0-9]*(\.?[0-9]+)? �̌`�̂݁B*/
{
	LPCDSTR		pSrc,  pSrcEnd ;
	LPDSTR		pDest, pDestEnd ;
	LPDSTR		pDestNum, pDestNumEnd ;

	pSrc		= strHenkanKey ;
	pSrcEnd		= pSrc + nHenkanKeyLen ;
	pDest		= pResult ;
	pDestEnd	= pResult + nResultSize ;
	pDestNum	= (pNumList != NULL)? pNumList : NULL ;
	pDestNumEnd	= (pNumList != NULL)? (pNumList + nNumListSize) : NULL ;
	while (pSrc < pSrcEnd && pDest < pDestEnd) {
		/* ���l�̊J�n�ʒu�̌����B*/
		int		nCH	= *pSrc ;
		if ((L'0' <= nCH && nCH <= L'9') || (L'�O' <= nCH && nCH <= L'�X') || 
			/* ``.'' �ŊJ�n����ꍇ�ɂ́A���������������łȂ���΂Ȃ�Ȃ��B���̌`�������F�߂ĂȂ��B*/
			(bFloat && nCH == L'.' && (pSrc + 1) < pSrcEnd && 
			((L'0' <= *(pSrc + 1) && *(pSrc + 1) <= L'9') || (L'�O' <= *(pSrc + 1) && *(pSrc + 1) <= L'�X')))) {
			LPCDSTR	pNumBegin, pSrcNum ;

			pNumBegin	= pSrc ;
			/* float �̏���������ׂ����ۂ��B*/
			if (bFloat) {
				while (pSrc < pSrcEnd && ((L'0' <= *pSrc && *pSrc <= L'9') || (L'�O' <= *pSrc && *pSrc <= L'�X') || *pSrc == L','))
					pSrc	++ ;
				if (pSrc < pSrcEnd && *pSrc == L'.')
					pSrc	++ ;
				/* continue */
			}
			while (pSrc < pSrcEnd && ((L'0' <= *pSrc && *pSrc <= L'9') || (L'�O' <= *pSrc && *pSrc <= L'�X') || *pSrc == L',')) {
#if 0//defined(DEBUG)
				wprintf (L"%c", *pSrc) ;
#endif
				pSrc	++ ;
			}

			/* pNumBegin ���� pSrc �܂ł� num-list �ɕۑ�����B*/
			if (pDestNum != NULL) {
				pSrcNum	= pNumBegin ;
				while (pDestNum < pDestNumEnd && pSrcNum < pSrc) {
					if (L'0' <= *pSrcNum && *pSrcNum <= L'9') {
						*pDestNum	++ = *pSrcNum ;
					} else if (L'�O' <= *pSrcNum && *pSrcNum <= L'�X') {
						*pDestNum	++ = (*pSrcNum - L'�O' + L'0') ;
					} else if (*pSrcNum == L'.') {
						*pDestNum	++ = L'.' ;
					} else {
						/* ``,'' �͖�������B*/
					}
					pSrcNum	++ ;
				}
				if (pDestNum < pDestNumEnd) 
					*pDestNum ++	= L'\0' ;	/* separator */
			}
			*pDest	++	= L'#' ;
		} else {
			*pDest	++	= nCH ;
			pSrc	++ ;
		}
	}
	if (pDestNum != NULL && pDestNum < pDestNumEnd) 
		*pDestNum	= L'\0' ;	/* terminator */
	return	(pDest - pResult) ;
}

int
iConcatString (
	LPDSTR		pDest,
	int			nDestSize,
	...)
{
   va_list	argptr ;
   LPCDSTR	pSrc ;
   int		nSrcLen, nDest, n ;

   va_start (argptr, nDestSize) ;

   nDest	= nDestSize ;
   while (nDest > 0) {
	   pSrc		= va_arg (argptr, LPCDSTR) ;
	   if (pSrc == NULL)
		   break ;
	   nSrcLen	= va_arg (argptr, int) ;

	   n		= MIN (nDest, nSrcLen) ;
	   memcpy (pDest, pSrc, n * sizeof (DCHAR)) ;
	   pDest	+= n ;
	   nDest	-= n ;
   }
   va_end (argptr) ;

   return	(nDestSize - nDest) ;
}

BOOL
bSettoji (
	LPCDSTR		pWord,
	int			nWordLen)
{
	LPCDSTR	ptr, ptrEnd ;

	if (nWordLen < 2 || pWord [nWordLen - 1] != L'>')
		return	FALSE ;
	ptr		= pWord ;
	ptrEnd	= pWord + nWordLen - 1 ;
	while (ptr < ptrEnd && !(/*0x00 <= *ptr &&*/ *ptr <= 0x7F))
		ptr	++ ;

	return	(ptr == ptrEnd) ;
}

BOOL
bSetsubiji (
	LPCDSTR		pWord,
	int			nWordLen)
{
	LPCDSTR	ptr, ptrEnd ;

	if (nWordLen < 2 || pWord [0] != L'>')
		return	FALSE ;
	ptr		= pWord + 1 ;
	ptrEnd	= pWord + nWordLen ;
	while (ptr < ptrEnd && !(/*0x00 <= *ptr &&*/ *ptr <= 0x7F))
		ptr	++ ;

	return	(ptr == ptrEnd) ;
}

int
lstrncpyW (
	register LPWSTR		pDest,
	register LPCWSTR	pSrc,
	register int		n)
{
	register int	ch	= -1 ;

	while (n -- > 0 && ch != L'\0') 
		ch = *pSrc, *pDest ++ = *pSrc ++ ;
	return	n ;
}

int
lstrncmpW (
	register LPCWSTR	pLeft,
	register LPCWSTR	pRight,
	register int		n)
{
	register int	nDiff	= 0 ;

	while (n > 0) {
		nDiff	= *pLeft - *pRight ;
		if (nDiff != 0)
			return	nDiff ;
		if (*pLeft == L'\0')
			break ;
		pLeft	++ ;
		pRight	++ ;
		n		-- ;
	}
	return	nDiff ;
}

int
wmemindex (
	register LPCWSTR	pLeft,
	register LPCWSTR	pRight,
	register int		n)
{
	int	n_back	= n ;

	while (n > 0 && *pLeft == *pRight) {
		n		-- ;
		pLeft	++ ;
		pRight	++ ;
	}
	return	n_back - n ;
}

void
vCopyString (
	LPDSTR*		ppwDest,
	LPCDSTR		pwDestEnd,
	LPCDSTR		pwSrc)
{
	LPDSTR		pwDest ;

	if (ppwDest == NULL || pwDestEnd == NULL || pwSrc == NULL)
		return ;
	pwDest	= *ppwDest ;
	if (pwDest == NULL)
		return ;
	while (pwDest < pwDestEnd && *pwSrc != L'\0') 
		*pwDest ++	= *pwSrc ++ ;
	*ppwDest	= pwDest ;
	return ;
}

void	vCopyStringN (
	LPDSTR*		ppwDest,
	LPCDSTR		pwDestEnd,
	LPCDSTR		pwSrc,
	int			nSrcLen)
{
	LPDSTR		pwDest ;

	if (ppwDest == NULL || pwDestEnd == NULL || pwSrc == NULL || nSrcLen <= 0)
		return ;
	pwDest	= *ppwDest ;
	if (pwDest == NULL)
		return ;
	while (pwDest < pwDestEnd && nSrcLen > 0) {
		*pwDest ++	= *pwSrc ++ ;
		nSrcLen	-- ;
	}
	*ppwDest	= pwDest ;
	return ;
}

BOOL
bStringLispFormatp (
	LPCDSTR			pwString,
	int				nStringLength)
{
	if (pwString == NULL || nStringLength <= 1)
		return	FALSE ;
	return	(*pwString == L'(' && *(pwString + nStringLength - 1) == L')')? TRUE : FALSE ;
}

BOOL
bStringNumericWordp (
	LPCDSTR			pwString,
	int				nStringLength)
{
	LPCDSTR	pwSrc, pwSrcEnd ;

	if (pwString == NULL || nStringLength <= 1)
		return	FALSE ;

	pwSrc		= pwString ;
	pwSrcEnd	= pwSrc + nStringLength - 1 ;

	/*	annotation �ȍ~�� # �̓`�F�b�N���Ȃ��Ƃ���B���ꂪ���������삩�ǂ����͕�����Ȃ����B
	 */
	while (pwSrc < pwSrcEnd && *pwSrc != L';') {
		if (*pwSrc == L'#' && (L'0' <= *(pwSrc + 1) && *(pwSrc + 1) <= L'9'))
			return	TRUE ;
		pwSrc	++ ;
	}
	return	FALSE ;
}


int
iSkkJisx0201Hankaku (
	LPDSTR		pwDest,
	int			nDest,
	LPCDSTR		pwSrc,
	int			nSrc)
{
	static	DCHAR	rchHankakuTbl []	= {
		L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', 
		L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', 
		L'�', L'\0', L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'\0',
		L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'\0', L'�', L'�',  
		L'�', L'\0', L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'\0', 
		L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'\0', L'�', L'�',
		L'�', L'\0', L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'\0', 
		L'�', L'\0', L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'\0', 
		L'�', L'�', 
		L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', 
		L'�', L'\0', L'�', L'�',  L'�', L'�',  L'�', L'\0', L'�', L'�', 
		L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'�',  L'�', L'\0', 
		L'�', L'�',  L'�', L'�',  L'�', L'\0', L'�', L'�',  L'�', L'�', 
		L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', 
		L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0',
		L'�', L'\0', 
		L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', L'�', L'\0', 
	} ;
	LPDSTR	pwDestEnd	= pwDest + nDest ;
	LPCDSTR	pwSrcEnd	= pwSrc  + nSrc ;
	LPDSTR	pwDestBack	= pwDest ;
	int		nCH ;

	while (pwSrc < pwSrcEnd && pwDest < pwDestEnd) {
		int		nIndex ;
		nCH		= *pwSrc ++ ;
		if (L'��' <= nCH && nCH <= L'��') {
			nIndex	= (nCH - L'��') * 2 ;
			*pwDest ++	= rchHankakuTbl [nIndex] ;	nIndex ++ ;
			if (rchHankakuTbl [nIndex] != L'\0' && pwDest < pwDestEnd)
				*pwDest ++	= rchHankakuTbl [nIndex] ;
		} else if (L'�@' <= nCH && nCH <= L'��') {
			nIndex	= (nCH - L'�@') * 2 ;
			*pwDest ++	= rchHankakuTbl [nIndex] ;	nIndex ++ ;
			if (rchHankakuTbl [nIndex] != L'\0' && pwDest < pwDestEnd)
				*pwDest ++	= rchHankakuTbl [nIndex] ;
		} else {
			switch (nCH) {
			case	L'��':
			case	L'��':
				*pwDest ++	= L'�' ;
				break ;
			case	L'��':
			case	L'��':
				*pwDest ++	= L'�' ;
				break ;
			case	L'��':
			case	L'��':
				*pwDest ++	= L'�' ;
				break ;
			case	L'��':
				*pwDest ++	= L'�' ;
				if (pwDest < pwDestEnd)
					*pwDest ++	= L'�' ;
				break ;
			case	L'�J':
				*pwDest ++	= L'�' ;
				break ;
			case	L'�K':
				*pwDest ++	= L'�' ;
				break ;
			case	L'�E':
				*pwDest ++	= L'�' ;
				break ;
			case	L'�[':
				*pwDest ++	= L'�' ;
				break ;
			case	L'�u':
				*pwDest ++	= L'�' ;
				break ;
			case	L'�v':
				*pwDest ++	= L'�' ;
				break ;
			case	L'�A':
				*pwDest ++	= L'�' ;
				break ;
			case	L'�B':
				*pwDest ++	= L'�' ;
				break ;
			default:
				*pwDest ++	= nCH ;
				break ;
			}
		}
	}
	return	pwDest - pwDestBack ;
}

int
iSkkJisx0201Zenkaku (
	LPDSTR		pwDest,
	int			nDest,
	LPCDSTR		pwSrc,
	int			nSrc)
{
	static	WCHAR	rwTbl []	= L"�B�u�v�A�E���@�B�D�F�H�������b�[�A�C�E�G�I�J�L�N�P�R�T�V�X�Z�\�^�`�c�e�g�i�j�k�l�m�n�q�t�w�z�}�~��������������������������" ;
	LPDSTR	pwDestEnd	= pwDest + nDest ;
	LPCDSTR	pwSrcEnd	= pwSrc  + nSrc ;
	LPDSTR	pwDestBak	= pwDest ;
	int	nCH, nPrevCH ;

	nPrevCH	= 0 ;
	while (pwSrc < pwSrcEnd && pwDest < pwDestEnd) {
		nCH	= *pwSrc ++ ;
		if (L'�' <= nCH && nCH <= L'�') {
			*pwDest ++	= rwTbl [nCH - L'�'] ;
		} else if (nCH == L'�') {
			if (L'�' <= nPrevCH && nPrevCH <= L'�' && pwDest > pwDestBak) {
				*(pwDest - 1)	= L"�p�s�v�y�|" [nPrevCH - L'�'] ;
			} else {
				*pwDest ++	= L'�K' ;
			}
		} else if (nCH == L'�') {
			if (pwDest > pwDestBak) {
				if (L'�' <= nPrevCH && nPrevCH <= L'�') {
					*(pwDest - 1)	= L"�K�M�O�Q�S�U�W�Y�[�]�_�a�d�f�h" [nPrevCH - L'�'] ;
				} else if (L'�' <= nPrevCH && nPrevCH <= L'�') {
					*(pwDest - 1)	= L"�o�r�u�x�{" [nPrevCH - L'�'] ;
				} else if (nPrevCH == L'�') {
					*(pwDest - 1)	= L'��' ;
				} else {
					*pwDest ++	= L'�J' ;
				}
			} else {
				*pwDest ++	= L'�J' ;
			}
		} else {
			*pwDest ++	= nCH ;
		}
		nPrevCH	= nCH ;
	}
	return	pwDest - pwDestBak ;
}

void
vCopyStringW (
	LPDSTR*		ppwDest,
	LPCDSTR		pwDestEnd,
	LPCWSTR		pwSrc)
{
	LPDSTR		pwDest ;

	if (ppwDest == NULL || pwDestEnd == NULL || pwSrc == NULL)
		return ;
	pwDest	= *ppwDest ;
	if (pwDest == NULL)
		return ;
	if (pwDest < pwDestEnd) {
		int	nSrcLen	= wcslen (pwSrc) ;
		int	n		= wcstodcs (pwDest, pwDestEnd - pwDest, pwSrc, nSrcLen) ;
		*ppwDest	= pwDest + n ;
	}
	return ;
}

void	vCopyStringNW (
	LPDSTR*		ppwDest,
	LPCDSTR		pwDestEnd,
	LPCWSTR		pwSrc,
	int			nSrcLen)
{
	LPDSTR		pwDest ;

	if (ppwDest == NULL || pwDestEnd == NULL || pwSrc == NULL || nSrcLen <= 0)
		return ;
	pwDest	= *ppwDest ;
	if (pwDest == NULL)
		return ;
	if (pwDest < pwDestEnd) {
		int	n		= wcstodcs (pwDest, pwDestEnd - pwDest, pwSrc, nSrcLen) ;
		*ppwDest	= pwDest + n ;
	}
	return ;
}

LPDSTR
pGetDString (
	LPDSTR		pBuffer,
	int			nBufferSize,
	LPCWSTR		pSrc,
	int			nSrcLen,
	int*		pnLength)
{
	int	n, nLength ;

	if (nSrcLen > 0) {
		n	= wcstodcs_n (NULL, 0, pSrc, nSrcLen) ;

		if (n < nBufferSize) {
			nLength		= wcstodcs_n (pBuffer, nBufferSize, pSrc, nSrcLen) ;
		} else {
			pBuffer		= (LPDSTR) MALLOC (sizeof (DCHAR) * n) ;
			if (pBuffer == NULL) {
				*pnLength	= 0 ;
				return	NULL ;
			}
			nLength		= wcstodcs_n (pBuffer, n, pSrc, nSrcLen) ;
		}
		*pnLength	= nLength ;
		return	pBuffer ;
	} else {
		*pnLength	= 0 ;
		return	NULL ;
	}
}

