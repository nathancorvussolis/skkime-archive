#pragma once

#include "dchar.h"
#include "TCommuSession.h"

/*	cutbuffer �֘A�B*/
BOOL	TCutBufferSession_bSet (LPCDSTR, int, BOOL) ;
int		TCutBufferSession_iGet (LPDSTR, int) ;

