#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "RuleTreeNodeP.h"
#include "keymap.h"
#include "ImeConfig.h"
#include "jstring.h"

enum {
	SYSCHAR_INVALID		= -1,
	SYSCHAR_DEFAULT		= 65536,
	SYSCHAR_VOWEL,
	SYSCHAR_CONSONANT,
} ;

static	int	TSkkRuleTreeNode_iGetRuleCharacter (LPCDSTR*, LPCDSTR) ;
static	int	TSkkRuleTreeNode_iGetRule			(const struct CSkkRuleTreeNode*) ;

struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNodeOutput_pCreateStringPairInstance (
	LPCDSTR							dstrLeft,
	int								nLeftLen,
	LPCDSTR							dstrRight,
	int								nRightLen)
{
	struct CSkkRuleTreeNodeOutput*	pNode ;
	DCHAR*	pwDest ;
	int		nSize ;

	nSize	= sizeof (struct CSkkRuleTreeNodeOutput) + nLeftLen * sizeof (DCHAR) + nRightLen * sizeof (DCHAR) ;
	if (nSize < sizeof (struct CSkkRuleTreeNodeOutput))
		return	NULL ;
	pNode	= (struct CSkkRuleTreeNodeOutput*) MALLOC (nSize) ;
	if (pNode == NULL)
		return	NULL ;
	pwDest			= (DCHAR*) (pNode + 1) ;
	pNode->m_nType	= NTYPE_STRINGPAIR ;
	if (dstrLeft != NULL) {
		pNode->m_uValue.m_stringpair.m_strHira	= pwDest ;
		dcsncpy (pwDest, dstrLeft, nLeftLen) ;
		pNode->m_uValue.m_stringpair.m_nHira	= nLeftLen ;
		pwDest	+= nLeftLen ;
	} else {
		pNode->m_uValue.m_stringpair.m_strHira	= NULL ;
		pNode->m_uValue.m_stringpair.m_nHira	= 0 ;
	}
	if (dstrRight != NULL) {
		pNode->m_uValue.m_stringpair.m_strKata	= pwDest ;
		dcsncpy (pwDest, dstrRight, nRightLen) ;
		pNode->m_uValue.m_stringpair.m_nKata	= nRightLen ;
		pwDest	+= nRightLen ;
	} else {
		pNode->m_uValue.m_stringpair.m_strKata	= NULL ;
		pNode->m_uValue.m_stringpair.m_nKata	= 0 ;
	}
	return	pNode ;
}

struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNodeOutput_pCreateStringInstance (
	LPCDSTR							wstrString,
	int								nStringLen)
{
	struct CSkkRuleTreeNodeOutput*	pNode ;
	DCHAR*	pwDest ;
	int		nSize ;

	nSize	= sizeof (struct CSkkRuleTreeNodeOutput) + nStringLen * sizeof (DCHAR) ;
	if (nSize < sizeof (struct CSkkRuleTreeNodeOutput))
		return	NULL ;
	pNode	= (struct CSkkRuleTreeNodeOutput*) MALLOC (nSize) ;
	if (pNode == NULL)
		return	NULL ;
	pwDest			= (DCHAR*) (pNode + 1) ;
	pNode->m_nType	= NTYPE_STRING ;
	if (wstrString != NULL) {
		pNode->m_uValue.m_string.m_strValue	= pwDest ;
		memcpy (pwDest, wstrString, nStringLen * sizeof (DCHAR)) ;
		pNode->m_uValue.m_string.m_nValue	= nStringLen ;
	} else {
		pNode->m_uValue.m_string.m_strValue	= NULL ;
		pNode->m_uValue.m_string.m_nValue	= 0 ;
	}
	return	pNode ;
}

struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNodeOutput_pCreateMacroInstance (
	int								nMacro)
{
	struct CSkkRuleTreeNodeOutput*	pNode ;

	pNode	= (struct CSkkRuleTreeNodeOutput*) MALLOC (sizeof (struct CSkkRuleTreeNodeOutput)) ;
	if (pNode == NULL)
		return	NULL ;
	pNode->m_nType				= NTYPE_MACRO ;
	pNode->m_uValue.m_nMacro	= nMacro ;
	return	pNode ;
}

void
TSkkRuleTreeNodeOutput_vDestroy (
	struct CSkkRuleTreeNodeOutput*	pNode)
{
	if (pNode == NULL)
		return ;
	FREE (pNode) ;
	return ;
}

int
TSkkRuleTreeNodeOutput_iGetType		(
	const struct CSkkRuleTreeNodeOutput*	pNode)
{
	return	(pNode != NULL)? pNode->m_nType : -1 ;
}

BOOL
TSkkRuleTreeNodeOutput_bGetMacro	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	int*									pnFuncNo)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_MACRO)
		return	FALSE ;
	if (pnFuncNo != NULL)
		*pnFuncNo	= pNode->m_uValue.m_nMacro ;
	return	TRUE ;
}

BOOL
TSkkRuleTreeNodeOutput_bGetString	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	LPCDSTR*								ppwString,
	int*									pnStringLen)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_STRING)
		return	FALSE ;
	if (ppwString != NULL)
		*ppwString	= pNode->m_uValue.m_string.m_strValue ;
	if (pnStringLen != NULL)
		*pnStringLen	= pNode->m_uValue.m_string.m_nValue ;
	return	TRUE ;
}


BOOL
TSkkRuleTreeNodeOutput_bGetLString	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	LPCDSTR*								ppwString,
	int*									pnStringLen)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_STRINGPAIR)
		return	FALSE ;
	if (ppwString != NULL)
		*ppwString	= pNode->m_uValue.m_stringpair.m_strHira ;
	if (pnStringLen != NULL)
		*pnStringLen	= pNode->m_uValue.m_stringpair.m_nHira ;
	return	TRUE ;
}


BOOL
TSkkRuleTreeNodeOutput_bGetRString	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	LPCDSTR*								ppwString,
	int*									pnStringLen)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_STRINGPAIR)
		return	FALSE ;
	if (ppwString != NULL)
		*ppwString	= pNode->m_uValue.m_stringpair.m_strKata ;
	if (pnStringLen != NULL)
		*pnStringLen	= pNode->m_uValue.m_stringpair.m_nKata ;
	return	TRUE ;
}

/*===============================================================
 *	struct CSkkRuleTreeNode public functions
 */
LPCDSTR
TSkkRuleTreeNode_pGetPrefix (
	const struct CSkkRuleTreeNode*			pNode,
	int*									pnLength)
{
	if (pNode == NULL)
		return	NULL ;
	if (pnLength != NULL)
		*pnLength	= pNode->_nPrefix ;
	return	pNode->_pPrefix ;
}

LPCDSTR
TSkkRuleTreeNode_pGetNextState	(
	const struct CSkkRuleTreeNode*			pNode,
	int*									pnLength,
	int*									pnNextRule)
{
	if (pNode == NULL) {
		if (pnNextRule != NULL)
			*pnNextRule	= 0 ;
		return	NULL ;
	}
	if (pnLength != NULL)
		*pnLength	= pNode->_nNextState ;
	if (pnNextRule != NULL)
		*pnNextRule	= pNode->_nNextRule ;
	return	pNode->_pNextState ;
}

const struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNode_pGetOutput		(
	const struct CSkkRuleTreeNode*			pNode)
{
	return	(pNode != NULL)? pNode->_pOutput : NULL ;
}

/*===============================================================
 *	static public methods
 */
struct CSkkRuleTreeNode*
TSkkRuleTreeNode_pCreateInstance (
	int								nChar, 
	LPCDSTR							wstrPrefix,
	int								nPrefixLen,
	LPCDSTR							wstrNext,
	int								nNextLen,
	int								iNextRule,
	struct CSkkRuleTreeNodeOutput*	pOutput)
{
	struct CSkkRuleTreeNode*	pNode ;
	int					nSize ;
	DCHAR*				pwDest ;

	nSize	= sizeof (struct CSkkRuleTreeNode) + sizeof (DCHAR) * nPrefixLen + sizeof (DCHAR) * nNextLen ;
	pNode	= (struct CSkkRuleTreeNode*) MALLOC (nSize) ;
	if (pNode == NULL)
		return	NULL ;

	pNode->_nCH	= nChar ;
	pwDest		= (DCHAR*) (pNode + 1) ;
	if (nPrefixLen > 0) {
		pNode->_pPrefix	= pwDest ;
		memcpy (pNode->_pPrefix, wstrPrefix, sizeof (DCHAR) * nPrefixLen) ;
		pwDest			+= nPrefixLen ;
	} else {
		pNode->_pPrefix	= NULL ;
		nPrefixLen		= 0 ;
	}
	pNode->_nPrefix	= nPrefixLen ;

	if (nNextLen > 0) {
		pNode->_pNextState	= pwDest ;
		memcpy (pNode->_pNextState, wstrNext, sizeof (DCHAR) * nNextLen) ;
		pwDest		+= nNextLen ;
	} else {
		pNode->_pNextState	= NULL ;
		nNextLen	= 0 ;
	}
	pNode->_nNextState	= nNextLen ;
	pNode->_nNextRule	= iNextRule ;
	pNode->_pOutput		= pOutput ;
	pNode->_pChild		= NULL ;
	pNode->_pBrother	= NULL ;
	return	pNode ;
}

void
TSkkRuleTreeNode_vDestroy (
	struct CSkkRuleTreeNode*	pNode)
{
	if (pNode == NULL)
		return ;

	TSkkRuleTreeNodeOutput_vDestroy (pNode->_pOutput) ;
	pNode->_pOutput	= NULL ;
	FREE (pNode) ;
	return ;
}

void
TSkkRuleTreeNode_vSetBrother (
	struct CSkkRuleTreeNode*		pRoot,
	struct CSkkRuleTreeNode*		pBrother)
{
	pRoot->_pBrother	= pBrother ;
	return ;
}

void
TSkkRuleTreeNode_vSetChild (
	struct CSkkRuleTreeNode*		pRoot,
	struct CSkkRuleTreeNode*		pChild)
{
	pRoot->_pChild	= pChild ;
	return ;
}

void
TSkkRuleTreeNode_vSetOutput (
	struct CSkkRuleTreeNode*		pNode,
	struct CSkkRuleTreeNodeOutput*	pOutput)
{
	if (pNode == NULL)
		return ;
	if (pNode->_pOutput != NULL) {
		TSkkRuleTreeNodeOutput_vDestroy (pNode->_pOutput) ;
	}
	pNode->_pOutput	= pOutput ;
	return ;
}

struct CSkkRuleTreeNode*
TSkkRuleTreeNode_pGetBranchList (
	struct CSkkRuleTreeNode*		pRoot)
{
	return	pRoot != NULL? TSkkRuleTreeNode_pGetChild (pRoot) : NULL ;
}

BOOL
TSkkRuleTreeNode_bMatchChar (int nSystemChar, int nInputChar, int* pnScore)
{
	switch (nSystemChar) {
	case	SYSCHAR_DEFAULT:
		if (pnScore != NULL)
			*pnScore	= 0 ;	/* �Œ�_���B*/
		return	TRUE ;
	case	SYSCHAR_VOWEL:
		if	(nInputChar == 'a' || nInputChar == 'i' || nInputChar == 'u' || nInputChar == 'e' || nInputChar == 'o') {
			if (pnScore != NULL)
				*pnScore	= 50 ;
			return	TRUE ;
		}
		break ;
	case	SYSCHAR_CONSONANT:
		if	(('a' <= nInputChar && nInputChar <= 'z') && ! (nInputChar == 'a' || nInputChar == 'i' || nInputChar == 'u' || nInputChar == 'e' || nInputChar == 'o')) {
			if (pnScore != NULL)
				*pnScore	= 50 ;
			return	TRUE ;
		}
		break ;
	default:
		if (nSystemChar == nInputChar) {
			if (pnScore != NULL)
				*pnScore	= 100 ;
			return	TRUE ;
		}
		break ;
	}
	return	FALSE ;
}

struct CSkkRuleTreeNode*
TSkkRuleTreeNode_pSelectBranch (
	struct CSkkRuleTreeNode*	pRoot,
	int							nChar)
{
	struct CSkkRuleTreeNode*	pNode ;
	struct CSkkRuleTreeNode*	pHitNode ;
	int	nCurScore ;

	if (pRoot == NULL)
		return	NULL ;

	pNode		= TSkkRuleTreeNode_pGetChild (pRoot) ;
	pHitNode	= NULL ;
	nCurScore	= -1 ;
	while (pNode != NULL) {
		int	nScore ;
		if (TSkkRuleTreeNode_bMatchChar (TSkkRuleTreeNode_iGetChar (pNode), nChar, &nScore)) {
			if (nCurScore < nScore) {
				pHitNode	= pNode ;
				nCurScore	= nScore ;
			}
			if (nScore == 100)
				break ;
		}
		pNode	= TSkkRuleTreeNode_pGetBrother (pNode) ;
	}
	return	pHitNode ;
}

/*	�Ԃ�l�́A�T���ɐ�������������(���ǂ�Ȃ��Ȃ����炻���܂�)
 *	���̎��_�ł̃m�[�h�� ppResult �ɓ������B
 */
int
TSkkRuleTreeNode_iSearchTree (
	struct CSkkRuleTreeNode*	pTree,
	LPCDSTR						pString,
	int							nString,
	struct CSkkRuleTreeNode**	ppResult)
{
	struct CSkkRuleTreeNode*	pParent ;
	struct CSkkRuleTreeNode*	pNode ;
	LPCDSTR		wptr, wptrEnd ;
	int			nCH ;

	pNode		= pTree != NULL? TSkkRuleTreeNode_pGetChild (pTree) : NULL ;
	pParent		= pTree ;
	wptr		= pString ;
	wptrEnd		= pString + nString ;
	while (wptr < wptrEnd) {
		LPCDSTR	wptrBack	= wptr ;
		nCH		= TSkkRuleTreeNode_iGetRuleCharacter (&wptr, wptrEnd) ;

		/* �Z�푤�̒T���B*/
		while (pNode != NULL) {
			if (TSkkRuleTreeNode_iGetChar (pNode) == nCH)
				break ;
			pNode	= TSkkRuleTreeNode_pGetBrother (pNode) ;
		}
		if (pNode == NULL) {
			/* �����ł����B��v���Ă����Ƃ���܂ŕԂ��B*/
			if (ppResult != NULL)
				*ppResult	= pParent ;
#if defined (DEBUG)
			_tprintf (TEXT ("iSeachTree: not found\n")) ;
#endif
			return	wptrBack - pString ;
		}
		if (wptr >= wptrEnd) {
			/* ���������B*/
			if (ppResult != NULL)
				*ppResult	= pNode ;
#if defined (DEBUG)
			_tprintf (TEXT ("iSeachTree: found\n")) ;
			TSkkRuleTreeNode_vDebugOut (pNode) ;
			TSkkRuleTreeNode_vDebugOut (pParent) ;
#endif
			return	wptr - pString ;
		}
#if defined (DEBUG)
		_tprintf (TEXT ("iSearchTree: -> goto child\n")) ;
		TSkkRuleTreeNode_vDebugOut (pNode) ;
#endif
		pParent	= pNode ;
		pNode	= TSkkRuleTreeNode_pGetChild (pNode) ;
	}
	if (ppResult != NULL)
		*ppResult	= pTree ;
	return	0 ;
}

BOOL
TSkkRuleTreeNode_bAddRuleSP (
	struct CSkkRuleTreeNode**	ppTree,
	int							iTree,
	LPCDSTR						dstrPrefix,
	int							nPrefixLen,
	LPCWSTR						wstrNext,
	int							nNextLen,
	int							iNextRule,
	LPCWSTR						wstrHira,
	int							nHiraLen,
	LPCWSTR						wstrKata,
	int							nKataLen)
{
	struct CSkkRuleTreeNode*	pRoot ;
	struct CSkkRuleTreeNode*	pAddPoint ;
	struct CSkkRuleTreeNode*	pAddTree ;
	struct CSkkRuleTreeNode*	pAddTreeRoot	= NULL ;
	struct CSkkRuleTreeNodeOutput*	pOutput	= NULL ;
	LPCDSTR						pwPtr ;
	LPCDSTR						pwPtrEnd ;
	int							nCH, nOffset = 0 ;
	DCHAR	dbufHira [32], dbufKata [32], dbufNext [32] ;
	LPDSTR						dstrHira	= NULL ;
	LPDSTR						dstrKata	= NULL ;
	LPDSTR						dstrNext	= NULL ;
	BOOL						bRetval		= TRUE ;

	/* prefix �����݂��Ȃ��̂͋�����Ȃ��Bprefix �Ȃ��͔ԕ��݂̂ł���B*/
	if (ppTree == NULL || dstrPrefix == NULL || nPrefixLen <= 0)
		return	FALSE ;

	pRoot		= *ppTree ;
	/* �ԕ���p�ӂ���B����� original �̍\���ɂ��킹�Ă���B*/
	if (pRoot == NULL) {
		pRoot	= TSkkRuleTreeNode_pCreateInstance (0, NULL, 0, NULL, 0, iTree, NULL) ;
		if (pRoot == NULL)
			return	FALSE ;
		*ppTree	= pRoot ;
	}
	nOffset		= TSkkRuleTreeNode_iSearchTree (pRoot, dstrPrefix, nPrefixLen, &pAddPoint) ;

	pwPtr		= dstrPrefix + nOffset ;
	pwPtrEnd	= dstrPrefix + nPrefixLen ;
	if (pwPtr < pwPtrEnd) {
		struct CSkkRuleTreeNode*		pCurAddPoint		= NULL ;
		int	nKataDLen, nHiraDLen, nNextDLen ;

		/*	�S���̐V�K�o�^�ł���ꍇ�B*/
		/*
		 *	shu �Ƃ��āAs �����݂���ꍇ�ɂ� nOffset = 1�B
		 *
		 *	���[�g -> ``s'' -> ...
		 *
		 *	���� ``s'' �� pAddPoint �Ƃ��Č��t�����Ă���B��������A
		 *
		 *	(1) ``h'' -> ``u'' �̃����N���쐬����B
		 *	(2) ``s'' �̎q���Ƃ��Ēǉ�����B
		 *		����ɂ�� ``s'' -> ``h'' -> ``u'' �� rule-tree ���쐬�����B
		 *
		 *	���� ``s'' �̎q�������݂����ꍇ�ɂ́A
		 *
		 *	(2)' ``h''->``u'' �� ``h'' �̌Z��ɂ��Ƃ��Ƃ� ``s'' �̎q����ǉ�����B
		 *	(3)  ``s'' �̎q���Ƃ��� ``h'' ���Ȃ��B
		 *
		 *	���̃��[���Ɉᔽ���Ȃ��悤�Ƀ��[���؂̍\�����g�����Ȃ���΂Ȃ�Ȃ��B
		 *	nCH �� INT �Ȃ̂ŁA�����̕������ԈႦ�Ȃ���Ίg���Ɏ��s���邱�Ƃ͂Ȃ�
		 *	�̂�������Ȃ��B
		 *	nCH �ɓ��ꕶ������ꂽ�ꍇ�́u���ݏ�Ԃ̊Ǘ��v�����B�����͂ǂ��ɂ���
		 *	�Ȃ���΂Ȃ�Ȃ��B����̓��[���؂̒��ɓ����̂͂܂�����������Ȃ��B
		 *	nCH �̓��ꕶ���g������
		 *		SelectBranch
		 *	�͕ω�����B
		 *	����Ԃ� m_pPrefix, m_nPrefix ������A����̎��ۂ�ۑ�����ꏊ���K�v�B
		 *	���ۂ̏�Ԃ́AiCH, m_pPrefix, m_nPrefix ����쐬����锤�B
		 */
		pAddTreeRoot	= NULL ;
		while (pwPtr < pwPtrEnd) {
			LPCDSTR	pwPtrBack	= pwPtr ;

			nCH			= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
			if (nCH == SYSCHAR_INVALID) {
				return	FALSE ;
			}
			if (pwPtr >= pwPtrEnd) {
				pwPtr	= pwPtrBack ;
				break ;
			}
			pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, pwPtr - dstrPrefix, NULL, 0, iTree, NULL) ;
			if (pAddTree == NULL) {
				TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
				return	FALSE ;
			}

			ASSERT (pAddPoint != NULL && pRoot != NULL) ;
			/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
			if (pAddTreeRoot == NULL) {
				pAddTreeRoot	= pAddTree ;
				pCurAddPoint	= pAddTree ;
			} else {
				TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
				TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
				pCurAddPoint	= pAddTree ;
			}
		}

		/*	Output ���쐬����B
		 */
		dstrHira	= pGetDString (dbufHira, ARRAYSIZE (dbufHira), wstrHira, nHiraLen, &nHiraDLen) ;
		dstrKata	= pGetDString (dbufKata, ARRAYSIZE (dbufKata), wstrKata, nKataLen, &nKataDLen) ;

		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringPairInstance (dstrHira, nHiraDLen, dstrKata, nKataDLen) ;
		if (pOutput == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}

		/*	Output �̂Ȃ��� RuleTree �̃m�[�h���쐬����B
		 */
		nCH	= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
		if (nCH == SYSCHAR_INVALID) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		dstrNext	= pGetDString (dbufNext, ARRAYSIZE (dbufNext), wstrNext, nNextLen, &nNextDLen) ;

		pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, nPrefixLen, dstrNext, nNextDLen, iNextRule, pOutput) ;
		if (pAddTree == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
		ASSERT (pAddPoint != NULL && pRoot != NULL) ;
		if (pAddTreeRoot != NULL) {
			ASSERT (pCurAddPoint != NULL && pCurAddPoint != pAddPoint) ;
			TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
			TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
		} else {
			pAddTreeRoot	= pAddTree ;
		}

		/*	���̒i�K�ł��Ƃ̖؂Ƀ}�[�W����B
		 */
		TSkkRuleTreeNode_vSetBrother (pAddTreeRoot, TSkkRuleTreeNode_pGetChild (pAddPoint)) ;
		TSkkRuleTreeNode_vSetChild (pAddPoint, pAddTreeRoot) ;
	} else {
		/*	NextState �̍X�V���Ȃ��Ƃ����Ȃ��̂ł́B
		 */
		int	nHiraDLen, nKataDLen ;

		dstrHira	= pGetDString (dbufHira, ARRAYSIZE (dbufHira), wstrHira, nHiraLen, &nHiraDLen) ;
		dstrKata	= pGetDString (dbufKata, ARRAYSIZE (dbufKata), wstrKata, nKataLen, &nKataDLen) ;

		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringPairInstance (dstrHira, nHiraDLen, dstrKata, nKataDLen) ;
		if (pOutput == NULL) {
			bRetval	= FALSE ;
			goto	Exit ;
		}
		TSkkRuleTreeNode_vSetOutput (pAddPoint, pOutput) ;
	}
Exit:
	if (dstrHira != dbufHira && dstrHira != NULL)
		FREE (dstrHira) ;
	if (dstrKata != dbufKata && dstrKata != NULL)
		FREE (dstrKata) ;
	if (dstrNext != dbufNext && dstrNext != NULL)
		FREE (dstrKata) ;
	return	bRetval ; ;
}

BOOL
TSkkRuleTreeNode_bAddRuleS (
	struct CSkkRuleTreeNode**	ppTree,
	int							iTree,
	LPCDSTR						dstrPrefix,
	int							nPrefixLen,
	LPCWSTR						wstrNext,
	int							nNextLen,
	int							iNextRule,
	LPCWSTR						wstrString,
	int							nString)
{
	struct CSkkRuleTreeNode*	pRoot ;
	struct CSkkRuleTreeNode*	pAddPoint ;
	struct CSkkRuleTreeNode*	pAddTree ;
	struct CSkkRuleTreeNode*	pAddTreeRoot	= NULL ;
	struct CSkkRuleTreeNodeOutput*	pOutput	= NULL ;
	LPCDSTR						pwPtr ;
	LPCDSTR						pwPtrEnd ;
	int							nCH, nOffset = 0 ;
	DCHAR	dbufString [32], dbufNext [32] ;
	LPDSTR						dstrString	= NULL ;
	LPDSTR						dstrNext	= NULL ;
	BOOL						bRetval		= TRUE ;

	/* prefix �����݂��Ȃ��̂͋�����Ȃ��Bprefix �Ȃ��͔ԕ��݂̂ł���B*/
	if (ppTree == NULL || dstrPrefix == NULL || nPrefixLen <= 0)
		return	FALSE ;

	pRoot		= *ppTree ;
	/* �ԕ���p�ӂ���B����� original �̍\���ɂ��킹�Ă���B*/
	if (pRoot == NULL) {
		pRoot	= TSkkRuleTreeNode_pCreateInstance (0, NULL, 0, NULL, 0, iTree, NULL) ;
		if (pRoot == NULL)
			return	FALSE ;
		*ppTree	= pRoot ;
	}
	nOffset		= TSkkRuleTreeNode_iSearchTree (pRoot, dstrPrefix, nPrefixLen, &pAddPoint) ;

	pwPtr		= dstrPrefix + nOffset ;
	pwPtrEnd	= dstrPrefix + nPrefixLen ;
	if (pwPtr < pwPtrEnd) {
		struct CSkkRuleTreeNode*		pCurAddPoint		= NULL ;
		int	nNextDLen, nStrDLen ;

		/*	�S���̐V�K�o�^�ł���ꍇ�B*/
		/*
		 *	shu �Ƃ��āAs �����݂���ꍇ�ɂ� nOffset = 1�B
		 *
		 *	���[�g -> ``s'' -> ...
		 *
		 *	���� ``s'' �� pAddPoint �Ƃ��Č��t�����Ă���B��������A
		 *
		 *	(1) ``h'' -> ``u'' �̃����N���쐬����B
		 *	(2) ``s'' �̎q���Ƃ��Ēǉ�����B
		 *		����ɂ�� ``s'' -> ``h'' -> ``u'' �� rule-tree ���쐬�����B
		 *
		 *	���� ``s'' �̎q�������݂����ꍇ�ɂ́A
		 *
		 *	(2)' ``h''->``u'' �� ``h'' �̌Z��ɂ��Ƃ��Ƃ� ``s'' �̎q����ǉ�����B
		 *	(3)  ``s'' �̎q���Ƃ��� ``h'' ���Ȃ��B
		 *
		 *	���̃��[���Ɉᔽ���Ȃ��悤�Ƀ��[���؂̍\�����g�����Ȃ���΂Ȃ�Ȃ��B
		 *	nCH �� INT �Ȃ̂ŁA�����̕������ԈႦ�Ȃ���Ίg���Ɏ��s���邱�Ƃ͂Ȃ�
		 *	�̂�������Ȃ��B
		 *	nCH �ɓ��ꕶ������ꂽ�ꍇ�́u���ݏ�Ԃ̊Ǘ��v�����B�����͂ǂ��ɂ���
		 *	�Ȃ���΂Ȃ�Ȃ��B����̓��[���؂̒��ɓ����̂͂܂�����������Ȃ��B
		 *	nCH �̓��ꕶ���g������
		 *		SelectBranch
		 *	�͕ω�����B
		 *	����Ԃ� m_pPrefix, m_nPrefix ������A����̎��ۂ�ۑ�����ꏊ���K�v�B
		 *	���ۂ̏�Ԃ́AiCH, m_pPrefix, m_nPrefix ����쐬����锤�B
		 */
		pAddTreeRoot	= NULL ;
		while (pwPtr < pwPtrEnd) {
			LPCDSTR	pwPtrBack	= pwPtr ;

			nCH			= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
			if (nCH == SYSCHAR_INVALID) {
				return	FALSE ;
			}
			if (pwPtr >= pwPtrEnd) {
				pwPtr	= pwPtrBack ;
				break ;
			}
			pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, pwPtr - dstrPrefix, NULL, 0, iTree, NULL) ;
			if (pAddTree == NULL) {
				TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
				return	FALSE ;
			}

			ASSERT (pAddPoint != NULL && pRoot != NULL) ;
			/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
			if (pAddTreeRoot == NULL) {
				pAddTreeRoot	= pAddTree ;
				pCurAddPoint	= pAddTree ;
			} else {
				TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
				TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
				pCurAddPoint	= pAddTree ;
			}
		}

		/*	Output ���쐬����B
		 */
		dstrString	= pGetDString (dbufString, ARRAYSIZE (dbufString), wstrString, nString, &nStrDLen) ;
		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringInstance (dstrString, nStrDLen) ;
		if (pOutput == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}

		/*	Output �̂Ȃ��� RuleTree �̃m�[�h���쐬����B
		 */
		nCH	= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
		if (nCH == SYSCHAR_INVALID) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		dstrNext	= pGetDString (dbufNext, ARRAYSIZE (dbufNext), wstrNext, nNextLen, &nNextDLen) ;

		pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, nPrefixLen, dstrNext, nNextDLen, iNextRule, pOutput) ;
		if (pAddTree == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
		ASSERT (pAddPoint != NULL && pRoot != NULL) ;
		if (pAddTreeRoot != NULL) {
			ASSERT (pCurAddPoint != NULL && pCurAddPoint != pAddPoint) ;
			TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
			TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
		} else {
			pAddTreeRoot	= pAddTree ;
		}

		/*	���̒i�K�ł��Ƃ̖؂Ƀ}�[�W����B
		 */
		TSkkRuleTreeNode_vSetBrother (pAddTreeRoot, TSkkRuleTreeNode_pGetChild (pAddPoint)) ;
		TSkkRuleTreeNode_vSetChild (pAddPoint, pAddTreeRoot) ;
	} else {
		int	nStrDLen ;
		/*	NextState �̍X�V���Ȃ��Ƃ����Ȃ��̂ł́B
		 */
		dstrString	= pGetDString (dbufString, ARRAYSIZE (dbufString), wstrString, nString, &nStrDLen) ;
		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringInstance (dstrString, nStrDLen) ;
		if (pOutput == NULL) {
			bRetval	= FALSE ;
			goto	Exit ;
		}
		TSkkRuleTreeNode_vSetOutput (pAddPoint, pOutput) ;
	}
Exit:
	if (dstrString != dbufString && dstrString != NULL)
		FREE (dstrString) ;
	if (dstrNext != dbufNext && dstrNext != NULL)
		FREE (dstrNext) ;
	return	bRetval ; ;
}

BOOL
TSkkRuleTreeNode_bAddRuleM (
	struct CSkkRuleTreeNode**	ppTree,
	int							iTree,
	LPCDSTR						dstrPrefix,
	int							nPrefixLen,
	LPCWSTR						wstrNext,
	int							nNextLen,
	int							iNextRule,
	int							nMacro) 
{
	struct CSkkRuleTreeNode*	pRoot ;
	struct CSkkRuleTreeNode*	pAddPoint ;
	struct CSkkRuleTreeNode*	pAddTree ;
	struct CSkkRuleTreeNode*	pAddTreeRoot	= NULL ;
	struct CSkkRuleTreeNodeOutput*	pOutput	= NULL ;
	LPCDSTR						pwPtr ;
	LPCDSTR						pwPtrEnd ;
	int							nCH, nOffset = 0 ;
	DCHAR						dbufNext [32] ;
	LPDSTR						dstrNext	= NULL ;
	BOOL						bRetval		= TRUE ;
	/* prefix �����݂��Ȃ��̂͋�����Ȃ��Bprefix �Ȃ��͔ԕ��݂̂ł���B*/
	if (ppTree == NULL || dstrPrefix == NULL || nPrefixLen <= 0)
		return	FALSE ;

	pRoot		= *ppTree ;
	/* �ԕ���p�ӂ���B����� original �̍\���ɂ��킹�Ă���B*/
	if (pRoot == NULL) {
		pRoot	= TSkkRuleTreeNode_pCreateInstance (0, NULL, 0, NULL, 0, iTree, NULL) ;
		if (pRoot == NULL)
			return	FALSE ;
		*ppTree	= pRoot ;
	}
	nOffset		= TSkkRuleTreeNode_iSearchTree (pRoot, dstrPrefix, nPrefixLen, &pAddPoint) ;

	pwPtr		= dstrPrefix + nOffset ;
	pwPtrEnd	= dstrPrefix + nPrefixLen ;
	if (pwPtr < pwPtrEnd) {
		struct CSkkRuleTreeNode*		pCurAddPoint		= NULL ;
		int	nNextDLen ;

		/*	�S���̐V�K�o�^�ł���ꍇ�B*/
		/*
		 *	shu �Ƃ��āAs �����݂���ꍇ�ɂ� nOffset = 1�B
		 *
		 *	���[�g -> ``s'' -> ...
		 *
		 *	���� ``s'' �� pAddPoint �Ƃ��Č��t�����Ă���B��������A
		 *
		 *	(1) ``h'' -> ``u'' �̃����N���쐬����B
		 *	(2) ``s'' �̎q���Ƃ��Ēǉ�����B
		 *		����ɂ�� ``s'' -> ``h'' -> ``u'' �� rule-tree ���쐬�����B
		 *
		 *	���� ``s'' �̎q�������݂����ꍇ�ɂ́A
		 *
		 *	(2)' ``h''->``u'' �� ``h'' �̌Z��ɂ��Ƃ��Ƃ� ``s'' �̎q����ǉ�����B
		 *	(3)  ``s'' �̎q���Ƃ��� ``h'' ���Ȃ��B
		 *
		 *	���̃��[���Ɉᔽ���Ȃ��悤�Ƀ��[���؂̍\�����g�����Ȃ���΂Ȃ�Ȃ��B
		 *	nCH �� INT �Ȃ̂ŁA�����̕������ԈႦ�Ȃ���Ίg���Ɏ��s���邱�Ƃ͂Ȃ�
		 *	�̂�������Ȃ��B
		 *	nCH �ɓ��ꕶ������ꂽ�ꍇ�́u���ݏ�Ԃ̊Ǘ��v�����B�����͂ǂ��ɂ���
		 *	�Ȃ���΂Ȃ�Ȃ��B����̓��[���؂̒��ɓ����̂͂܂�����������Ȃ��B
		 *	nCH �̓��ꕶ���g������
		 *		SelectBranch
		 *	�͕ω�����B
		 *	����Ԃ� m_pPrefix, m_nPrefix ������A����̎��ۂ�ۑ�����ꏊ���K�v�B
		 *	���ۂ̏�Ԃ́AiCH, m_pPrefix, m_nPrefix ����쐬����锤�B
		 */
		pAddTreeRoot	= NULL ;
		while (pwPtr < pwPtrEnd) {
			LPCDSTR	pwPtrBack	= pwPtr ;

			nCH			= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
			if (nCH == SYSCHAR_INVALID) {
				return	FALSE ;
			}
			if (pwPtr >= pwPtrEnd) {
				pwPtr	= pwPtrBack ;
				break ;
			}
			pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, pwPtr - dstrPrefix, NULL, 0, iTree, NULL) ;
			if (pAddTree == NULL) {
				TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
				return	FALSE ;
			}

			ASSERT (pAddPoint != NULL && pRoot != NULL) ;
			/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
			if (pAddTreeRoot == NULL) {
				pAddTreeRoot	= pAddTree ;
				pCurAddPoint	= pAddTree ;
			} else {
				TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
				TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
				pCurAddPoint	= pAddTree ;
			}
		}

		/*	Output ���쐬����B
		 */
		pOutput		= TSkkRuleTreeNodeOutput_pCreateMacroInstance (nMacro) ;
		if (pOutput == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			return	FALSE ;
		}

		/*	Output �̂Ȃ��� RuleTree �̃m�[�h���쐬����B
		 */
		nCH	= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
		if (nCH == SYSCHAR_INVALID) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			return	FALSE ;
		}
		dstrNext	= pGetDString (dbufNext, ARRAYSIZE (dbufNext), wstrNext, nNextLen, &nNextDLen) ;
		pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, nPrefixLen, dstrNext, nNextDLen, iNextRule, pOutput) ;
		if (pAddTree == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
		ASSERT (pAddPoint != NULL && pRoot != NULL) ;
		if (pAddTreeRoot != NULL) {
			ASSERT (pCurAddPoint != NULL && pCurAddPoint != pAddPoint) ;
			TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
			TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
		} else {
			pAddTreeRoot	= pAddTree ;
		}

		/*	���̒i�K�ł��Ƃ̖؂Ƀ}�[�W����B
		 */
		TSkkRuleTreeNode_vSetBrother (pAddTreeRoot, TSkkRuleTreeNode_pGetChild (pAddPoint)) ;
		TSkkRuleTreeNode_vSetChild (pAddPoint, pAddTreeRoot) ;
	} else {
		/*	NextState �̍X�V���Ȃ��Ƃ����Ȃ��̂ł́B
		 */
		pOutput		= TSkkRuleTreeNodeOutput_pCreateMacroInstance (nMacro) ;
		if (pOutput == NULL)
			return	FALSE ;
		TSkkRuleTreeNode_vSetOutput (pAddPoint, pOutput) ;
	}
Exit:
	if (dstrNext != dbufNext && dstrNext != NULL)
		FREE (dstrNext) ;
	return	bRetval ; ;
}

BOOL
TSkkRuleTreeNode_bDeleteRule (
	struct CSkkRuleTreeNode**	ppTree,
	LPCDSTR						pString,
	int							nString)
{
	struct CSkkRuleTreeNode*	pTree ;
	struct CSkkRuleTreeNode*	pParent ;
	struct CSkkRuleTreeNode*	pNode ;
	struct CSkkRuleTreeNode*	pPrev ;
	LPCDSTR		wptr ;
	int			nptr, nCH ;

	pTree	= *ppTree ;
	pNode	= pTree != NULL? TSkkRuleTreeNode_pGetChild (pTree) : NULL ;
	pParent	= pTree ;
	wptr	= pString ;
	nptr	= nString ;

	/*	�܂� brother �����ւ̒T�������s����B*/
	while (pNode != NULL && nptr > 0) {
		nCH		= *wptr ;
		pPrev	= NULL ;
		while (pNode != NULL) {
			if (TSkkRuleTreeNode_iGetChar (pNode) == nCH) 
				break ;
			pPrev	= pNode ;
			pNode	= TSkkRuleTreeNode_pGetBrother (pNode) ;
		}
		/* �Y���Ȃ��B*/
		if (pNode == NULL)
			return	FALSE ;

		wptr	++ ;
		nptr	-- ;
		if (nptr <= 0) {
			/* ���̈ʒu�ō폜�B*/
			if (pPrev == NULL) {
				/* �e����̃����N��\��ւ���B*/
				if (pParent != NULL) {
					TSkkRuleTreeNode_vSetChild (pParent, TSkkRuleTreeNode_pGetBrother (pNode)) ;
				} else {
					*ppTree				= TSkkRuleTreeNode_pGetBrother (pNode) ;
				}
				TSkkRuleTreeNode_vSetBrother (pNode, NULL) ;
			} else {
				/*	�Z��̃����N��\��ւ���B
				 *	�c�q����������q���͑S�ł���B
				 */
				TSkkRuleTreeNode_vSetBrother (pPrev, TSkkRuleTreeNode_pGetBrother (pNode)) ;
				TSkkRuleTreeNode_vSetBrother (pNode, NULL) ;
			}
			TSkkRuleTreeNode_vDestroyTree (pNode) ;
			break ;
		}
		pParent	= pNode ;
		pNode	= TSkkRuleTreeNode_pGetChild (pNode) ;
	}
	return	TRUE ;
}

void
TSkkRuleTreeNode_vDestroyTree (
	struct CSkkRuleTreeNode*	pRoot)
{
	struct CSkkRuleTreeNode*	pBrother ;
	struct CSkkRuleTreeNode*	pChild ;

	if (pRoot == NULL)
		return ;

	pBrother	= TSkkRuleTreeNode_pGetBrother (pRoot) ;
	pChild		= TSkkRuleTreeNode_pGetChild (pRoot) ;
	TSkkRuleTreeNode_vSetBrother (pRoot, NULL) ;
	TSkkRuleTreeNode_vSetChild (pRoot, NULL) ;
	TSkkRuleTreeNode_vDestroy (pRoot) ;

	if (pBrother != NULL)
		TSkkRuleTreeNode_vDestroyTree (pBrother) ;
	if (pChild != NULL)
		TSkkRuleTreeNode_vDestroyTree (pChild) ;
	return ;
}

int
TSkkRuleTreeNode_iGetRuleCharacter (
	LPCDSTR*	ppwPtr,
	LPCDSTR		pwPtrEnd)
{
	LPCDSTR	pwPtr ;
	int		nCH ;

	if (ppwPtr == NULL || pwPtrEnd == NULL)
		return	SYSCHAR_INVALID ;

	pwPtr	= *ppwPtr ;
	if (pwPtr == NULL)
		return	SYSCHAR_INVALID ;

	if (*pwPtr == L'\\') {
		pwPtr	++ ;
		if (pwPtr >= pwPtrEnd) {
			nCH	= SYSCHAR_INVALID ;
		} else {
			switch (*pwPtr) {
			case '\\':
				nCH	= '\\' ;
				break ;
			case	'V':	/* Vowel */
				nCH	= SYSCHAR_VOWEL ;
				break ;
			case	'C':
				nCH	= SYSCHAR_CONSONANT ;
				break ;
			case	'?':
				nCH	= SYSCHAR_DEFAULT ;
				break ;
			default:
				nCH	= SYSCHAR_INVALID ; 
				break ;
			}
		}
	} else {
		nCH	= *pwPtr ;
	}
	pwPtr	++ ;
	*ppwPtr	= pwPtr ;
	return	nCH ;
}

/*===============================================================
 *	public methods
 */

#if 0
void
TSkkRuleTreeNode_vDebugOut (const struct CSkkRuleTreeNode* pNode)
{
	DCHAR	buf [256] ;
	DCHAR	bufPrefix [128], bufNextState [128] ;
	int		n ;

	if (pNode->_pPrefix != NULL && pNode->_nPrefix > 0) {
		n	= (pNode->_nPrefix < (ARRAYSIZE (bufPrefix) - 1))? pNode->_nPrefix : (ARRAYSIZE (bufPrefix) - 1) ;
		memcpy (bufPrefix, pNode->_pPrefix, n * sizeof (DCHAR)) ;
		bufPrefix [n]	= L'\0' ;
	} else {
		bufPrefix [0]	= L'\0' ;
	}
	if (pNode->_pNextState != NULL && pNode->_nNextState > 0) {
		n	= (pNode->_nNextState < (ARRAYSIZE (bufNextState) - 1))? pNode->_nNextState : (ARRAYSIZE (bufNextState) - 1) ;
		memcpy (bufNextState, pNode->_pNextState, n * sizeof (DCHAR)) ;
		bufNextState [n]	= L'\0' ;
	} else {
		bufNextState [0]	= L'\0' ;
	}
	if (pNode->_pOutput != NULL) {
		switch (TSkkRuleTreeNodeOutput_iGetType (pNode->_pOutput)) {
		case	NTYPE_STRINGPAIR:
			{
				LPCDSTR	pHira, pKata ;
				int		nHira, nKata ;
				DCHAR	bufHira [128], bufKata [128] ;

				if (! TSkkRuleTreeNodeOutput_bGetLString (pNode->_pOutput, &pHira, &nHira) ||
					! TSkkRuleTreeNodeOutput_bGetRString (pNode->_pOutput, &pKata, &nKata)) {
					break ;
				}
				if (pHira != NULL && nHira > 0) {
					n	= (nHira < (ARRAYSIZE (bufHira) - 1))? nHira : (ARRAYSIZE (bufHira) - 1) ;
					memcpy (bufHira, pHira, nHira * sizeof (DCHAR)) ;
					bufHira [n]	= L'\0' ;
				} else {
					bufHira [0]	= L'\0' ;
				}
				if (pKata != NULL && nKata > 0) {
					n	= (nKata < (ARRAYSIZE (bufKata) - 1))? nKata : (ARRAYSIZE (bufKata) - 1) ;
					memcpy (bufKata, pKata, nKata * sizeof (DCHAR)) ;
					bufKata [n]	= L'\0' ;
				} else {
					bufKata [0]	= L'\0' ;
				}
				wnsprintfW (buf, ARRAYSIZE (buf) - 1, L"Prefix(\"%s\"), Next(\"%s\"), Hira(\"%s\"), Kata(\"%s\")\n", bufPrefix, bufNextState, bufHira, bufKata) ;
				buf [ARRAYSIZE (buf) - 1]	= L'\0' ;
			}
			break ;

		case	NTYPE_STRING:
			{
				DCHAR	bufString [128] ;
				LPCDSTR	pString ;
				int		nString ;
				if (! TSkkRuleTreeNodeOutput_bGetString (pNode->_pOutput, &pString, &nString)) {
					break ;
				}
				if (pString != NULL && nString > 0) {
					n	= (nString < (ARRAYSIZE (bufString) - 1))? nString : (ARRAYSIZE (bufString) - 1) ;
					memcpy (bufString, pString, nString * sizeof (DCHAR)) ;
				} else {
					bufString [0]	= L'\0' ;
				}
				wnsprintfW (buf, ARRAYSIZE (buf) - 1, L"Prefix(\"%s\"), Next(\"%s\"), String(\"%s\")\n", bufPrefix, bufNextState, bufString) ;
				buf [ARRAYSIZE (buf) - 1]	= L'\0' ;
			}
			break ;

		case	NTYPE_MACRO:
			{
				int		nMacro ;
				if (! TSkkRuleTreeNodeOutput_bGetMacro (pNode->_pOutput, &nMacro)) {
					break ;
				}
				wnsprintfW (buf, ARRAYSIZE (buf) - 1, L"Prefix(\"%s\"), Next(\"%s\"), Macro(%d)\n", bufPrefix, bufNextState, nMacro) ;
				buf [ARRAYSIZE (buf) - 1]	= L'\0' ;
			}
			break ;
		default:
			break ;
		}
		wprintf (L"%s\n", buf) ;
	} else {
		wprintf (L"nil\n", buf) ;
	}
	return ;
}
#endif

struct TSkkBaseRuleT1 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextRule ;
	struct {
		LPCWSTR	_strKata ;
		LPCWSTR	_strHira ;
	}	_case ;
} ;

struct TSkkBaseRuleT2 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextRule ;
	LPCWSTR	_strOutput ;
} ;

struct TSkkBaseRuleT3 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextRule ;
	int		_nFunction ;
} ;

static struct TSkkBaseRuleT1	_rT1 []	= {
	{ L"a",		NULL,	0,	{ L"�A",	L"��" } },
	{ L"bb",	L"b",	0,	{ L"�b",	L"��" } },		{ L"ba",	NULL,	0,	{ L"�o",	L"��" } },
	{ L"be",	NULL,	0,	{ L"�x",	L"��" } },		{ L"bi",	NULL,	0,	{ L"�r",	L"��" } },
	{ L"bo",	NULL,	0,	{ L"�{",	L"��" } },		{ L"bu",	NULL,	0,	{ L"�u",	L"��" } },
    { L"bya",	NULL,	0,	{ L"�r��",	L"�т�" } },	{ L"bye",	NULL,	0,	{ L"�r�F",	L"�т�" } },
	{ L"byi",	NULL,	0,	{ L"�r�B",	L"�т�" } },	{ L"byo",	NULL,	0,	{ L"�r��",	L"�т�" } },
	{ L"byu",	NULL,	0,	{ L"�r��",	L"�т�" } },
    { L"cc",	L"c",	0,	{ L"�b",	L"��" } },		{ L"cha",	NULL,	0,	{ L"�`��",	L"����" } },
    { L"che",	NULL,	0,	{ L"�`�F",	L"����" } },	{ L"chi",	NULL,	0,	{ L"�`",	L"��" } },
    { L"cho",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"chu",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"cya",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"cye",	NULL,	0,	{ L"�`�F",	L"����" } },
	{ L"cyi",	NULL,	0,	{ L"�`�B",	L"����" } },	{ L"cyo",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"cyu",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"dd",	L"d",	0,	{ L"�b",	L"��" } },
	{ L"da",	NULL,	0,	{ L"�_",	L"��" } },		{ L"de",	NULL,	0,	{ L"�f",	L"��" } },
	{ L"dha",	NULL,	0,	{ L"�f��",	L"�ł�" } },	{ L"dhe",	NULL,	0,	{ L"�f�F",	L"�ł�" } },
	{ L"dhi",	NULL,	0,	{ L"�f�B",	L"�ł�" } },	{ L"dho",	NULL,	0,	{ L"�f��",	L"�ł�" } },
	{ L"dhu",	NULL,	0,	{ L"�f��",	L"�ł�" } },	{ L"di",	NULL,	0,	{ L"�a",	L"��" } },
	{ L"do",	NULL,	0,	{ L"�h",	L"��" } },		{ L"du",	NULL,	0,	{ L"�d",	L"��" } },
	{ L"dya",	NULL,	0,	{ L"�a��",	L"����" } },	{ L"dye",	NULL,	0,	{ L"�a�F",	L"����" } },
	{ L"dyi",	NULL,	0,	{ L"�a�B",	L"����" } },	{ L"dyo",	NULL,	0,	{ L"�a��",	L"����" } },
	{ L"dyu",	NULL,	0,	{ L"�a��",	L"����" } },
	{ L"e",		NULL,	0,	{ L"�G",	L"��" } },
	{ L"ff",	L"f",	0,	{ L"�b",	L"��" } },		{ L"fa",	NULL,	0,	{ L"�t�@",	L"�ӂ�" } },
	{ L"fe",	NULL,	0,	{ L"�t�F",	L"�ӂ�" } },	{ L"fi",	NULL,	0,	{ L"�t�B",	L"�ӂ�" } },
	{ L"fo",	NULL,	0,	{ L"�t�H",	L"�ӂ�" } },	{ L"fu",	NULL,	0,	{ L"�t",	L"��" } },
	{ L"fya",	NULL,	0,	{ L"�t��",	L"�ӂ�" } },	{ L"fye",	NULL,	0,	{ L"�t�F",	L"�ӂ�" } },
	{ L"fyi",	NULL,	0,	{ L"�t�B",	L"�ӂ�" } },	{ L"fyo",	NULL,	0,	{ L"�t��",	L"�ӂ�" } },
	{ L"fyu",	NULL,	0,	{ L"�t��",	L"�ӂ�" } },
	{ L"gg",	L"g",	0,	{ L"�b",	L"��" } },		{ L"ga",	NULL,	0,	{ L"�K",	L"��" } },
	{ L"ge",	NULL,	0,	{ L"�Q",	L"��" } },		{ L"gi",	NULL,	0,	{ L"�M",	L"��" } },
	{ L"go",	NULL,	0,	{ L"�S",	L"��" } },		{ L"gu",	NULL,	0,	{ L"�O",	L"��" } },
	{ L"gya",	NULL,	0,	{ L"�M��",	L"����" } },	{ L"gye",	NULL,	0,	{ L"�M�F",	L"����" } },
	{ L"gyi",	NULL,	0,	{ L"�M�B",	L"����" } },	{ L"gyo",	NULL,	0,	{ L"�M��",	L"����" } },
	{ L"gyu",	NULL,	0,	{ L"�M��",	L"����" } },
	{ L"ha",	NULL,	0,	{ L"�n",	L"��" } },		{ L"he",	NULL,	0,	{ L"�w",	L"��" } },
	{ L"hi",	NULL,	0,	{ L"�q",	L"��" } },		{ L"ho",	NULL,	0,	{ L"�z",	L"��" } },
	{ L"hu",	NULL,	0,	{ L"�t",	L"��" } },		{ L"hya",	NULL,	0,	{ L"�q��",	L"�Ђ�" } },
	{ L"hye",	NULL,	0,	{ L"�q�F",	L"�Ђ�" } },	{ L"hyi",	NULL,	0,	{ L"�q�B",	L"�Ђ�" } },
	{ L"hyo",	NULL,	0,	{ L"�q��",	L"�Ђ�" } },	{ L"hyu",	NULL,	0,	{ L"�q��",	L"�Ђ�" } },
	{ L"i",		NULL,	0,	{ L"�C",	L"��" } },		{ L"jj",	L"j",	0,	{ L"�b",	L"��" } },
	{ L"ja",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"je",	NULL,	0,	{ L"�W�F",	L"����" } },
	{ L"ji",	NULL,	0,	{ L"�W",	L"��" } },		{ L"jo",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"ju",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"jya",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"jye",	NULL,	0,	{ L"�W�F",	L"����" } },	{ L"jyi",	NULL,	0,	{ L"�W�B",	L"����" } },
	{ L"jyo",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"jyu",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"kk",	L"k",	0,	{ L"�b",	L"��" } },		{ L"ka",	NULL,	0,	{ L"�J",	L"��" } },
	{ L"ke",	NULL,	0,	{ L"�P",	L"��" } },		{ L"ki",	NULL,	0,	{ L"�L",	L"��" } },
	{ L"ko",	NULL,	0,	{ L"�R",	L"��" } },		{ L"ku",	NULL,	0,	{ L"�N",	L"��" } },
	{ L"kya",	NULL,	0,	{ L"�L��",	L"����" } },	{ L"kye",	NULL,	0,	{ L"�L�F",	L"����" } },
	{ L"kyi",	NULL,	0,	{ L"�L�B",	L"����" } },	{ L"kyo",	NULL,	0,	{ L"�L��",	L"����" } },
	{ L"kyu",	NULL,	0,	{ L"�L��",	L"����" } },
	{ L"ma",	NULL,	0,	{ L"�}",	L"��" } },		{ L"me",	NULL,	0,	{ L"��",	L"��" } },
	{ L"mi",	NULL,	0,	{ L"�~",	L"��" } },		{ L"mo",	NULL,	0,	{ L"��",	L"��" } },
	{ L"mu",	NULL,	0,	{ L"��",	L"��" } },		{ L"mya",	NULL,	0,	{ L"�~��",	L"�݂�" } },
	{ L"mye",	NULL,	0,	{ L"�~�F",	L"�݂�" } },	{ L"myi",	NULL,	0,	{ L"�~�B",	L"�݂�" } },
	{ L"myo",	NULL,	0,	{ L"�~��",	L"�݂�" } },	{ L"myu",	NULL,	0,	{ L"�~��",	L"�݂�" } },
	{ L"n",		NULL,	0,	{ L"��",	L"��" } },		{ L"n'",	NULL,	0,	{ L"��",	L"��" } },
	{ L"na",	NULL,	0,	{ L"�i",	L"��" } },		{ L"ne",	NULL,	0,	{ L"�l",	L"��" } },
	{ L"ni",	NULL,	0,	{ L"�j",	L"��" } },		{ L"nn",	NULL,	0,	{ L"��",	L"��" } },
	{ L"no",	NULL,	0,	{ L"�m",	L"��" } },		{ L"nu",	NULL,	0,	{ L"�k",	L"��" } },
	{ L"nya",	NULL,	0,	{ L"�j��",	L"�ɂ�" } },	{ L"nye",	NULL,	0,	{ L"�j�F",	L"�ɂ�" } },
	{ L"nyi",	NULL,	0,	{ L"�j�B",	L"�ɂ�" } },	{ L"nyo",	NULL,	0,	{ L"�j��",	L"�ɂ�" } },
	{ L"nyu",	NULL,	0,	{ L"�j��",	L"�ɂ�" } },
	{ L"o",		NULL,	1,	{ L"�I",	L"��" } },
	{ L"pp",	L"p",	0,	{ L"�b",	L"��" } },		{ L"pa",	NULL,	0,	{ L"�p",	L"��" } },
	{ L"pe",	NULL,	0,	{ L"�y",	L"��" } },		{ L"pi",	NULL,	0,	{ L"�s",	L"��" } },
	{ L"po",	NULL,	0,	{ L"�|",	L"��" } },		{ L"pu",	NULL,	0,	{ L"�v",	L"��" } },
	{ L"pya",	NULL,	0,	{ L"�s��",	L"�҂�" } },	{ L"pye",	NULL,	0,	{ L"�s�F",	L"�҂�" } },
	{ L"pyi",	NULL,	0,	{ L"�s�B",	L"�҂�" } },	{ L"pyo",	NULL,	0,	{ L"�s��",	L"�҂�" } },
	{ L"pyu",	NULL,	0,	{ L"�s��",	L"�҂�" } },
	{ L"rr",	L"r",	0,	{ L"�b",	L"��" } },		{ L"ra",	NULL,	0,	{ L"��",	L"��" } },
	{ L"re",	NULL,	0,	{ L"��",	L"��" } },		{ L"ri",	NULL,	0,	{ L"��",	L"��" } },
	{ L"ro",	NULL,	0,	{ L"��",	L"��" } },		{ L"ru",	NULL,	0,	{ L"��",	L"��" } },
	{ L"rya",	NULL,	0,	{ L"����",	L"���" } },	{ L"rye",	NULL,	0,	{ L"���F",	L"�肥" } },
	{ L"ryi",	NULL,	0,	{ L"���B",	L"�股" } },	{ L"ryo",	NULL,	0,	{ L"����",	L"���" } },
	{ L"ryu",	NULL,	0,	{ L"����",	L"���" } },
	{ L"ss",	L"s",	0,	{ L"�b",	L"��" } },		{ L"sa",	NULL,	0,	{ L"�T",	L"��" } },
	{ L"se",	NULL,	0,	{ L"�Z",	L"��" } },		{ L"sha",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"she",	NULL,	0,	{ L"�V�F",	L"����" } },	{ L"shi",	NULL,	0,	{ L"�V",	L"��" } },
	{ L"sho",	NULL,	0,	{ L"�V��",	L"����" } },	{ L"shu",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"si",	NULL,	0,	{ L"�V",	L"��" } },		{ L"so",	NULL,	0,	{ L"�\",	L"��" } },
	{ L"su",	NULL,	0,	{ L"�X",	L"��" } },		{ L"sya",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"sye",	NULL,	0,	{ L"�V�F",	L"����" } },	{ L"syi",	NULL,	0,	{ L"�V�B",	L"����" } },
	{ L"syo",	NULL,	0,	{ L"�V��",	L"����" } },	{ L"syu",	NULL,	0,	{ L"�V��",	L"����" } },
	{ L"tt",	L"t",	0,	{ L"�b",	L"��" } },		{ L"ta",	NULL,	0,	{ L"�^",	L"��" } },
	{ L"te",	NULL,	0,	{ L"�e",	L"��" } },		{ L"tha",	NULL,	0,	{ L"�e�@",	L"�Ă�" } },
	{ L"the",	NULL,	0,	{ L"�e�F",	L"�Ă�" } },	{ L"thi",	NULL,	0,	{ L"�e�B",	L"�Ă�" } },
	{ L"tho",	NULL,	0,	{ L"�e��",	L"�Ă�" } },	{ L"thu",	NULL,	0,	{ L"�e��",	L"�Ă�" } },
	{ L"ti",	NULL,	0,	{ L"�`",	L"��" } },		{ L"to",	NULL,	0,	{ L"�g",	L"��" } },
	{ L"tsu",	NULL,	0,	{ L"�c",	L"��" } },		{ L"tu",	NULL,	0,	{ L"�c",	L"��" } },
	{ L"tya",	NULL,	0,	{ L"�`��",	L"����" } },	{ L"tye",	NULL,	0,	{ L"�`�F",	L"����" } },
	{ L"tyi",	NULL,	0,	{ L"�`�B",	L"����" } },	{ L"tyo",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"tyu",	NULL,	0,	{ L"�`��",	L"����" } },
	{ L"u",		NULL,	0,	{ L"�E",	L"��" } },
	{ L"vv",	L"v",	0,	{ L"�b",	L"��" } },		{ L"va",	NULL,	0,	{ L"���@",	L"���J��" } },
	{ L"ve",	NULL,	0,	{ L"���F",	L"���J��" } },	{ L"vi",	NULL,	0,	{ L"���B",	L"���J��" } },
	{ L"vo",	NULL,	0,	{ L"���H",	L"���J��" } },	{ L"vu",	NULL,	0,	{ L"��",	L"���J" } },
	{ L"ww",	L"w",	0,	{ L"�b",	L"��" } },		{ L"wa",	NULL,	0,	{ L"��",	L"��" } },
	{ L"we",	NULL,	0,	{ L"�E�F",	L"����" } },	{ L"wi",	NULL,	0,	{ L"�E�B",	L"����" } },
	{ L"wo",	NULL,	0,	{ L"��",	L"��" } },		{ L"wu",	NULL,	0,	{ L"�E",	L"��" } },
	{ L"xx",	L"x",	0,	{ L"�b",	L"��" } },		{ L"xa",	NULL,	0,	{ L"�@",	L"��" } },
	{ L"xe",	NULL,	0,	{ L"�F",	L"��" } },		{ L"xi",	NULL,	0,	{ L"�B",	L"��" } },
	{ L"xka",	NULL,	0,	{ L"��",	L"��" } },		{ L"xke",	NULL,	0,	{ L"��",	L"��" } },
	{ L"xo",	NULL,	0,	{ L"�H",	L"��" } },		{ L"xtsu",	NULL,	0,	{ L"�b",	L"��" } },
	{ L"xtu",	NULL,	0,	{ L"�b",	L"��" } },		{ L"xu",	NULL,	0,	{ L"�D",	L"��" } },
	{ L"xwa",	NULL,	0,	{ L"��",	L"��" } },		{ L"xwe",	NULL,	0,	{ L"��",	L"��" } },
	{ L"xwi",	NULL,	0,	{ L"��",	L"��" } },		{ L"xya",	NULL,	0,	{ L"��",	L"��" } },
	{ L"xyo",	NULL,	0,	{ L"��",	L"��" } },		{ L"xyu",	NULL,	0,	{ L"��",	L"��" } },
	{ L"yy",	L"y",	0,	{ L"�b",	L"��" } },		{ L"ya",	NULL,	0,	{ L"��",	L"��" } },
	{ L"ye",	NULL,	0,	{ L"�C�F",	L"����" } },	{ L"yo",	NULL,	0,	{ L"��",	L"��" } },
	{ L"yu",	NULL,	0,	{ L"��",	L"��" } },
	{ L"zz",	L"z",	0,	{ L"�b",	L"��" } },		{ L"za",	NULL,	0,	{ L"�U",	L"��" } },
	{ L"ze",	NULL,	0,	{ L"�[",	L"��" } },		{ L"zi",	NULL,	0,	{ L"�W",	L"��" } },
	{ L"zo",	NULL,	0,	{ L"�]",	L"��" } },		{ L"zu",	NULL,	0,	{ L"�Y",	L"��" } },
	{ L"zya",	NULL,	0,	{ L"�W��",	L"����" } },	{ L"zye",	NULL,	0,	{ L"�W�F",	L"����" } },
	{ L"zyi",	NULL,	0,	{ L"�W�B",	L"����" } },	{ L"zyo",	NULL,	0,	{ L"�W��",	L"����" } },
	{ L"zyu",	NULL,	0,	{ L"�W��",	L"����" } },
} ;

static struct TSkkBaseRuleT1	_rT1_1 []	= {
	{ L"\\?",	L"\\I",		0,	{ L"",		L"" } },
	{ L"h\\C",	L"\\I",		0,	{ L"�I",	L"��" } },
	{ L"h\\?",	L"h\\I",	0,	{ L"",		L"" } },
} ;

static struct TSkkBaseRuleT2	_rT2 []	= {
	{ L"z,",	NULL,	0,	L"�d" },	{ L"z-",	NULL,	0,	L"�`" },    { L"z.",	NULL,	0,	L"�c" },
	{ L"z/",	NULL,	0,	L"�E" },    { L"z[",	NULL,	0,	L"�w" },    { L"z]",	NULL,	0,	L"�x" },
    { L"zh",	NULL,	0,	L"��" },    { L"zj",	NULL,	0,	L"��" },    { L"zk",	NULL,	0,	L"��" },
	{ L"zl",	NULL,	0,	L"��" },    { L"-",		NULL,	0,	L"�[" },    { L":",		NULL,	0,	L"�F" },
    { L";",		NULL,	0,	L"�G" },    { L"?",		NULL,	0,	L"�H" },    { L"[",		NULL,	0,	L"�u" },
	{ L"]",		NULL,	0,	L"�v" },
} ;

static struct TSkkBaseRuleT3	_rT3 []	= {
	{ L".",		NULL,	0,	NFUNC_SKK_CURRENT_KUTEN },	
	{ L",",		NULL,	0,	NFUNC_SKK_CURRENT_TOUTEN },
	{ L"l",		NULL,	0,	NFUNC_SKK_LATIN_MODE },	
	{ L"q",		NULL,	0,	NFUNC_SKK_TOGGLE_KANA },
	{ L"L",		NULL,	0,	NFUNC_SKK_JISX0208_LATIN_MODE },
	{ L"Q",		NULL,	0,	NFUNC_SKK_SET_HENKAN_POINT_SUBR },
	{ L"X",		NULL,	0,	NFUNC_SKK_PURGE_FROM_JISYO },
	{ L"/",		NULL,	0,	NFUNC_SKK_ABBREV_MODE },
	{ L"$",		NULL,	0,	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT },
	{ L"@",		NULL,	0,	NFUNC_SKK_TODAY },
	{ L"\\\\",	NULL,	0,	NFUNC_SKK_INPUT_BY_CODE_OR_MENU },
	{ L"\r",	NULL,	0,	NFUNC_SKK_KAKUTEI },
} ;

static struct TSkkBaseRuleT2	_rJisx0201_T2 []	= {
	{ L"a",		NULL, 0, L"�", }, 
    { L"bb",	L"b", 0, L"�", },	{ L"ba",	NULL, 0, L"��", },	{ L"be",	NULL, 0, L"��", }, 
    { L"bi",	NULL, 0, L"��", },	{ L"bo",	NULL, 0, L"��", },	{ L"bu",	NULL, 0, L"��", },	{ L"bya",	NULL, 0, L"�ެ", }, 
    { L"bye",	NULL, 0, L"�ު", },	{ L"byi",	NULL, 0, L"�ި", },	{ L"byo",	NULL, 0, L"�ޮ", },	{ L"byu",	NULL, 0, L"�ޭ", }, 
    { L"cc",	L"c", 0, L"�", },	{ L"cha",	NULL, 0, L"��", },	{ L"che",	NULL, 0, L"��", },	{ L"chi",	NULL, 0, L"�", }, 
    { L"cho",	NULL, 0, L"��", },  { L"chu",	NULL, 0, L"��", },	{ L"cya",	NULL, 0, L"��", },	{ L"cye",	NULL, 0, L"��", }, 
    { L"cyi",	NULL, 0, L"��", },  { L"cyo",	NULL, 0, L"��", },	{ L"cyu",	NULL, 0, L"��", }, 
    { L"dd",	L"d", 0, L"�", },	{ L"da",	NULL, 0, L"��", },	{ L"de",	NULL, 0, L"��", },	{ L"dha",	NULL, 0, L"�ެ", }, 
    { L"dhe",	NULL, 0, L"�ު", },	{ L"dhi",	NULL, 0, L"�ި", },	{ L"dho",	NULL, 0, L"�ޮ", },	{ L"dhu",	NULL, 0, L"�ޭ", }, 
    { L"di",	NULL, 0, L"��", },	{ L"do",	NULL, 0, L"��", },	{ L"du",	NULL, 0, L"��", },	{ L"dya",	NULL, 0, L"�ެ", }, 
    { L"dye",	NULL, 0, L"�ު", },	{ L"dyi",	NULL, 0, L"�ި", },	{ L"dyo",	NULL, 0, L"�ޮ", },	{ L"dyu",	NULL, 0, L"�ޭ", }, 
    { L"e",		NULL, 0, L"�", }, 
    { L"ff",	L"f", 0, L"�", },	{ L"fa",	NULL, 0, L"̧", },  { L"fe",	NULL, 0, L"̪", },  { L"fi",	NULL, 0, L"̨", }, 
    { L"fo",	NULL, 0, L"̫", },  { L"fu",	NULL, 0, L"�", },	{ L"fya",	NULL, 0, L"̬", },  { L"fye",	NULL, 0, L"̪", }, 
    { L"fyi",	NULL, 0, L"̨", },  { L"fyo",	NULL, 0, L"̮", },  { L"fyu",	NULL, 0, L"̭", },  { L"gg",	L"g", 0, L"�", }, 
    { L"ga",	NULL, 0, L"��", },  { L"ge",	NULL, 0, L"��", },  { L"gi",	NULL, 0, L"��", },  { L"go",	NULL, 0, L"��", }, 
    { L"gu",	NULL, 0, L"��", },  { L"gya",	NULL, 0, L"�ެ", },	{ L"gye",	NULL, 0, L"�ު", },	{ L"gyi",	NULL, 0, L"�ި", }, 
    { L"gyo",	NULL, 0, L"�ޮ", },	{ L"gyu",	NULL, 0, L"�ޭ", }, 
    { L"ha",	NULL, 0, L"�", },	{ L"he",	NULL, 0, L"�", },	{ L"hi",	NULL, 0, L"�", },	{ L"ho",	NULL, 0, L"�", }, 
    { L"hu",	NULL, 0, L"�", },	{ L"hya",	NULL, 0, L"ˬ", },  { L"hye",	NULL, 0, L"˪", },  { L"hyi",	NULL, 0, L"˨", }, 
    { L"hyo",	NULL, 0, L"ˮ", },  { L"hyu",	NULL, 0, L"˭", },  { L"i",		NULL, 0, L"�", }, 
    { L"jj",	L"j", 0, L"�", },	{ L"ja",	NULL, 0, L"�ެ", },	{ L"je",	NULL, 0, L"�ު", },	{ L"ji",	NULL, 0, L"��", }, 
    { L"jo",	NULL, 0, L"�ޮ", },	{ L"ju",	NULL, 0, L"�ޭ", },	{ L"jya",	NULL, 0, L"�ެ", },	{ L"jye",	NULL, 0, L"�ު", }, 
    { L"jyi",	NULL, 0, L"�ި", },	{ L"jyo",	NULL, 0, L"�ޮ", },	{ L"jyu",	NULL, 0, L"�ޭ", }, 
    { L"kk",	L"k", 0, L"�", },	{ L"ka",	NULL, 0, L"�", },	{ L"ke",	NULL, 0, L"�", },	{ L"ki",	NULL, 0, L"�", }, 
    { L"ko",	NULL, 0, L"�", },	{ L"ku",	NULL, 0, L"�", },	{ L"kya",	NULL, 0, L"��", },  { L"kye",	NULL, 0, L"��", }, 
    { L"kyi",	NULL, 0, L"��", },	{ L"kyo",	NULL, 0, L"��", },  { L"kyu",	NULL, 0, L"��", }, 
    { L"mm",	L"m", 0, L"�", },	{ L"ma",	NULL, 0, L"�", },	{ L"me",	NULL, 0, L"�", },	{ L"mi",	NULL, 0, L"�", }, 
    { L"mo",	NULL, 0, L"�", },	{ L"mu",	NULL, 0, L"�", },	{ L"mya",	NULL, 0, L"Ь", },  { L"mye",	NULL, 0, L"Ъ", }, 
    { L"myi",	NULL, 0, L"Ш", },	{ L"myo",	NULL, 0, L"Ю", },	{ L"myu",	NULL, 0, L"Э", }, 
    { L"n",		NULL, 0, L"�", },	{ L"n'",	NULL, 0, L"�", },	{ L"na",	NULL, 0, L"�", },	{ L"ne",	NULL, 0, L"�", }, 
    { L"ni",	NULL, 0, L"�", },	{ L"nn",	NULL, 0, L"�", },	{ L"no",	NULL, 0, L"�", },	{ L"nu",	NULL, 0, L"�", }, 
    { L"nya",	NULL, 0, L"Ƭ", },	{ L"nye",	NULL, 0, L"ƪ", },  { L"nyi",	NULL, 0, L"ƨ", },  { L"nyo",	NULL, 0, L"Ʈ", }, 
    { L"nyu",	NULL, 0, L"ƭ", }, 
    { L"o",		NULL, 1, L"�", }, 
    { L"pp",	L"p", 0, L"�", },	{ L"pa",	NULL, 0, L"��", },  { L"pe",	NULL, 0, L"��", },  { L"pi",	NULL, 0, L"��", }, 
    { L"po",	NULL, 0, L"��", },	{ L"pu",	NULL, 0, L"��", },  { L"pya",	NULL, 0, L"�߬", },	{ L"pye",	NULL, 0, L"�ߪ", }, 
    { L"pyi",	NULL, 0, L"�ߨ", },	{ L"pyo",	NULL, 0, L"�߮", },	{ L"pyu",	NULL, 0, L"�߭", }, 
    { L"rr",	L"r", 0, L"�", },	{ L"ra",	NULL, 0, L"�", },	{ L"re",	NULL, 0, L"�", },	{ L"ri",	NULL, 0, L"�", }, 
    { L"ro",	NULL, 0, L"�", },	{ L"ru",	NULL, 0, L"�", },	{ L"rya",	NULL, 0, L"ج", },  { L"rye",	NULL, 0, L"ت", }, 
    { L"ryi",	NULL, 0, L"ب", },	{ L"ryo",	NULL, 0, L"خ", },  { L"ryu",	NULL, 0, L"ح", }, 
    { L"ss",	L"s", 0, L"�", },	{ L"sa",	NULL, 0, L"�", },	{ L"se",	NULL, 0, L"�", },	{ L"sha",	NULL, 0, L"��", }, 
    { L"she",	NULL, 0, L"��", },	{ L"shi",	NULL, 0, L"�", },	{ L"sho",	NULL, 0, L"��", },  { L"shu",	NULL, 0, L"��", }, 
    { L"si",	NULL, 0, L"�", },	{ L"so",	NULL, 0, L"�", },	{ L"su",	NULL, 0, L"�", },	{ L"sya",	NULL, 0, L"��", }, 
    { L"sye",	NULL, 0, L"��", },	{ L"syi",	NULL, 0, L"��", },  { L"syo",	NULL, 0, L"��", },  { L"syu",	NULL, 0, L"��", }, 
    { L"tt",	L"t", 0, L"�", },	{ L"ta",	NULL, 0, L"�", },	{ L"te",	NULL, 0, L"�", },	{ L"tha",	NULL, 0, L"ç", }, 
    { L"the",	NULL, 0, L"ê", },  { L"thi",	NULL, 0, L"è", },  { L"tho",	NULL, 0, L"î", },  { L"thu",	NULL, 0, L"í", }, 
    { L"ti",	NULL, 0, L"�", },	{ L"to",	NULL, 0, L"�", },	{ L"tsu",	NULL, 0, L"�", },	{ L"tu",	NULL, 0, L"�", }, 
    { L"tya",	NULL, 0, L"��", },  { L"tye",	NULL, 0, L"��", },  { L"tyi",	NULL, 0, L"��", },	{ L"tyo",	NULL, 0, L"��", }, 
    { L"tyu",	NULL, 0, L"��", }, 
    { L"u",		NULL, 0, L"�", }, 
    { L"vv",	L"v", 0, L"�", },	{ L"va",	NULL, 0, L"�ާ", },	{ L"ve",	NULL, 0, L"�ު", },	{ L"vi",	NULL, 0, L"�ި", }, 
    { L"vo",	NULL, 0, L"�ޫ", },	{ L"vu",	NULL, 0, L"��", }, 
    { L"ww",	L"w", 0, L"�", },	{ L"wa",	NULL, 0, L"�", },	{ L"we",	NULL, 0, L"��", },  { L"wi",	NULL, 0, L"��", }, 
    { L"wo",	NULL, 0, L"�", },	{ L"wu",	NULL, 0, L"�", }, 
    { L"xx",	L"x", 0, L"�", },	{ L"xa",	NULL, 0, L"�", },	{ L"xe",	NULL, 0, L"�", },	{ L"xi",	NULL, 0, L"�", }, 
    { L"xka",	NULL, 0, L"�", },	{ L"xke",	NULL, 0, L"�", },	{ L"xo",	NULL, 0, L"�", },	{ L"xtsu",	NULL, 0, L"�", }, 
    { L"xtu",	NULL, 0, L"�", },	{ L"xu",	NULL, 0, L"�", },	{ L"xwa",	NULL, 0, L"�", },	{ L"xwe",	NULL, 0, L"�", }, 
    { L"xwi",	NULL, 0, L"�", },	{ L"xya",	NULL, 0, L"�", },	{ L"xyo",	NULL, 0, L"�", },	{ L"xyu",	NULL, 0, L"�", }, 
    { L"yy",	L"y", 0, L"�", },	{ L"ya",	NULL, 0, L"�", },	{ L"ye",	NULL, 0, L"��", },  { L"yo",	NULL, 0, L"�", }, 
    { L"yu",	NULL, 0, L"�", },	 
    { L"zz",	L"z", 0, L"�", },	{ L"z,",	NULL, 0, L"�d", },  { L"z-",	NULL, 0, L"�`", },  { L"z.",	NULL, 0, L"�c", }, 
    { L"z/",	NULL, 0, L"�", },	{ L"z[",	NULL, 0, L"�w", },  { L"z]",	NULL, 0, L"�x", },  { L"za",	NULL, 0, L"��", }, 
    { L"ze",	NULL, 0, L"��", },  { L"zh",	NULL, 0, L"��", },  { L"zi",	NULL, 0, L"��", },  { L"zj",	NULL, 0, L"��", }, 
    { L"zk",	NULL, 0, L"��", },	{ L"zl",	NULL, 0, L"��", },  { L"zo",	NULL, 0, L"��", },	{ L"zu",	NULL, 0, L"��", }, 
    { L"zya",	NULL, 0, L"�ެ", },	{ L"zye",	NULL, 0, L"�ު", },	{ L"zyi",	NULL, 0, L"�ި", },	{ L"zyo",	NULL, 0, L"�ޮ", }, 
    { L"zyu",	NULL, 0, L"�ޭ", }, 
	{ L",",		NULL, 0, L"�", },	{ L".",		NULL, 0, L"�", },	{ L"-",		NULL, 0, L"�", },	{ L":",		NULL, 0, L":", },
	{ L";",		NULL, 0, L";", },	{ L"?",		NULL, 0, L"?", },	{ L"[",		NULL, 0, L"�", },	{ L"]",		NULL, 0, L"�", },
	{ L"(",		NULL, 0, L"(", },	{ L"{",		NULL, 0, L"{", },
} ;

/*	oh�ϊ��̂��߂̃��[���B
 */
static struct TSkkBaseRuleT2	_rJisx0201_T2_1 []	= {
	{ L"\\?",	L"\\I",		0,	L"", },
	{ L"h\\C",	L"\\I",		0,	L"�", },
	{ L"h\\?",	L"h\\I",	0,	L"", },
} ;

static struct TSkkBaseRuleT3	_rJisx0201_T3 []	= {
	{ L"l",		NULL,	0,	NFUNC_SKK_LATIN_MODE },
    { L"q",		NULL,	0,	NFUNC_SKK_TOGGLE_KATAKANA },
    { L"L",		NULL,	0,	NFUNC_SKK_JISX0208_LATIN_MODE },	
    { L"Q",		NULL,	0,	NFUNC_SKK_SET_HENKAN_POINT_SUBR },
    { L"X",		NULL,	0,	NFUNC_SKK_PURGE_FROM_JISYO },
    { L"/",		NULL,	0,	NFUNC_SKK_ABBREV_MODE },
    { L"$",		NULL,	0,	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT },
	{ L"@",		NULL,	0,	NFUNC_SKK_TODAY },
    { L"\\\\",	NULL,	0,	NFUNC_SKK_INPUT_BY_CODE_OR_MENU },
    { L"\r",	NULL,	0,	NFUNC_SKK_KAKUTEI },
} ;

static struct TSkkBaseRuleT2	_rJisx0201Roman_T2 []	= {
	{ L"!", NULL, 0, L"!", },	{ L"\"",NULL, 0, L"\"" },  { L"#", NULL, 0, L"#", },  { L"$", NULL, 0, L"$", },  { L"%", NULL, 0, L"%", }, 
    { L"&", NULL, 0, L"&", },	{ L"'", NULL, 0, L"'", },  { L"(", NULL, 0, L"(", },  { L")", NULL, 0, L")", },  { L"*", NULL, 0, L"*", }, 
    { L"+", NULL, 0, L"+", },	{ L",", NULL, 0, L",", },  { L"-", NULL, 0, L"-", },  { L".", NULL, 0, L".", },  { L"/", NULL, 0, L"/", }, 
    { L"0", NULL, 0, L"0", },	{ L"1", NULL, 0, L"1", },  { L"2", NULL, 0, L"2", },  { L"3", NULL, 0, L"3", },  { L"4", NULL, 0, L"4", }, 
    { L"5", NULL, 0, L"5", },	{ L"6", NULL, 0, L"6", },  { L"7", NULL, 0, L"7", },  { L"8", NULL, 0, L"8", },  { L"9", NULL, 0, L"9", }, 
    { L":", NULL, 0, L":", },	{ L";", NULL, 0, L";", },  { L"<", NULL, 0, L"<", },  { L"=", NULL, 0, L"=", },  { L">", NULL, 0, L">", }, 
    { L"?", NULL, 0, L"?", },	{ L"@", NULL, 0, L"@", }, 
    { L"A", NULL, 0, L"A", },	{ L"B", NULL, 0, L"B", },  { L"C", NULL, 0, L"C", },  { L"D", NULL, 0, L"D", },  { L"E", NULL, 0, L"E", }, 
    { L"F", NULL, 0, L"F", },	{ L"G", NULL, 0, L"G", },  { L"H", NULL, 0, L"H", },  { L"I", NULL, 0, L"I", },  { L"J", NULL, 0, L"J", }, 
    { L"K", NULL, 0, L"K", },	{ L"L", NULL, 0, L"L", },  { L"M", NULL, 0, L"M", },  { L"N", NULL, 0, L"N", },  { L"O", NULL, 0, L"O", }, 
    { L"P", NULL, 0, L"P", },	{ L"Q", NULL, 0, L"Q", },  { L"R", NULL, 0, L"R", },  { L"S", NULL, 0, L"S", },  { L"T", NULL, 0, L"T", }, 
    { L"U", NULL, 0, L"U", },	{ L"V", NULL, 0, L"V", },  { L"W", NULL, 0, L"W", },  { L"X", NULL, 0, L"X", },  { L"Y", NULL, 0, L"Y", }, 
    { L"Z", NULL, 0, L"Z", }, 
    { L"[", NULL, 0, L"[", },	{ L"\\\\", NULL, 0, L"\\\\", },  { L"]", NULL, 0, L"]", },  { L"^", NULL, 0, L"^", },
	{ L"_", NULL, 0, L"_", },	{ L"`", NULL, 0, L"`", }, 
    { L"a", NULL, 0, L"a", },	{ L"b", NULL, 0, L"b", },  { L"c", NULL, 0, L"c", },  { L"d", NULL, 0, L"d", },  { L"e", NULL, 0, L"e", }, 
    { L"f", NULL, 0, L"f", },	{ L"g", NULL, 0, L"g", },  { L"h", NULL, 0, L"h", },  { L"i", NULL, 0, L"i", },  { L"j", NULL, 0, L"j", }, 
    { L"k", NULL, 0, L"k", },	{ L"l", NULL, 0, L"l", },  { L"m", NULL, 0, L"m", },  { L"n", NULL, 0, L"n", },  { L"o", NULL, 0, L"o", }, 
    { L"p", NULL, 0, L"p", },	{ L"q", NULL, 0, L"q", },  { L"r", NULL, 0, L"r", },  { L"s", NULL, 0, L"s", },  { L"t", NULL, 0, L"t", }, 
    { L"u", NULL, 0, L"u", },	{ L"v", NULL, 0, L"v", },  { L"w", NULL, 0, L"w", },  { L"x", NULL, 0, L"x", },  { L"y", NULL, 0, L"y", }, 
    { L"z", NULL, 0, L"z", }, 
    { L"{", NULL, 0, L"{", },	{ L"|", NULL, 0, L"|", },  { L"}", NULL, 0, L"}", },  { L"~", NULL, 0, L"~", }, 
} ;

BOOL
TSkkRuleTree_bInitializeDefault (
	struct CSkkRuleTreeNode**			ppTree,
	int									cbTree)
{
	struct CSkkRuleTreeNode*	pRoot ;
	DCHAR	dbufPrefix [64] ;
	LPCDSTR	pPrefix ;
	int		i, nPrefix, nNextState ;

	if (ppTree == NULL || cbTree < 2)
		return	FALSE ;

	pRoot	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (_rT1) ; i ++) {
		int	nHira, nKata ;

		if (_rT1 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rT1 [i]._strState, lstrlenW (_rT1 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rT1 [i]._strNext       != NULL)? lstrlenW (_rT1 [i]._strNext)       : 0 ;
		nHira		= (_rT1 [i]._case._strHira != NULL)? lstrlenW (_rT1 [i]._case._strHira) : 0 ;
		nKata		= (_rT1 [i]._case._strKata != NULL)? lstrlenW (_rT1 [i]._case._strKata) : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleSP (&pRoot, 0, pPrefix, nPrefix, _rT1 [i]._strNext, nNextState, _rT1 [i]._iNextRule, _rT1 [i]._case._strHira, nHira, _rT1 [i]._case._strKata, nKata)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	for (i = 0 ; i < ARRAYSIZE (_rT2) ; i ++) {
		int	nOutput ;

		if (_rT2 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rT2 [i]._strState, lstrlenW (_rT2 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rT2 [i]._strNext   != NULL)? lstrlenW (_rT2 [i]._strNext)   : 0 ;
		nOutput		= (_rT2 [i]._strOutput != NULL)? lstrlenW (_rT2 [i]._strOutput) : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleS (&pRoot, 0, pPrefix, nPrefix, _rT2 [i]._strNext, nNextState, _rT2 [i]._iNextRule, _rT2 [i]._strOutput, nOutput)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	for (i = 0 ; i < ARRAYSIZE (_rT3) ; i ++) {
		if (_rT3 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rT3 [i]._strState, lstrlenW (_rT3 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rT3 [i]._strNext   != NULL)? lstrlenW (_rT3 [i]._strNext)   : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleM (&pRoot, 0, pPrefix, nPrefix, _rT3 [i]._strNext, nNextState, _rT3 [i]._iNextRule, _rT3 [i]._nFunction)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	ppTree [0]	= pRoot ;

	pRoot	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (_rT1_1) ; i ++) {
		int	nHira, nKata ;

		if (_rT1_1 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rT1_1 [i]._strState, lstrlenW (_rT1_1 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rT1_1 [i]._strNext       != NULL)? lstrlenW (_rT1_1 [i]._strNext)       : 0 ;
		nHira		= (_rT1_1 [i]._case._strHira != NULL)? lstrlenW (_rT1_1 [i]._case._strHira) : 0 ;
		nKata		= (_rT1_1 [i]._case._strKata != NULL)? lstrlenW (_rT1_1 [i]._case._strKata) : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleSP (&pRoot, 1, pPrefix, nPrefix, _rT1_1 [i]._strNext, nNextState, _rT1_1 [i]._iNextRule, _rT1_1 [i]._case._strHira, nHira, _rT1_1 [i]._case._strKata, nKata)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	ppTree [1]	= pRoot ;
	return	TRUE ;
}

BOOL
TSkkRuleTree_bInitializeJisx0201Default (
	struct CSkkRuleTreeNode**			ppTree,
	int									cbTree)
{
	struct CSkkRuleTreeNode*	pRoot ;
	int		i, nPrefix, nNextState ;
	DCHAR	dbufPrefix [64] ;
	LPCDSTR	pPrefix ;

	if (ppTree == NULL || cbTree < 2)
		return	FALSE ;

	/*	jisx0201-base-rule-tree �̏������B
	 */
	pRoot	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (_rJisx0201_T2) ; i ++) {
		int	nOutput ;

		if (_rJisx0201_T2 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rJisx0201_T2 [i]._strState, lstrlenW (_rJisx0201_T2 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rJisx0201_T2 [i]._strNext   != NULL)? lstrlenW (_rJisx0201_T2 [i]._strNext)   : 0 ;
		nOutput		= (_rJisx0201_T2 [i]._strOutput != NULL)? lstrlenW (_rJisx0201_T2 [i]._strOutput) : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleS (&pRoot, RULETREENO_SKK_JISX0201_BASE, pPrefix, nPrefix, _rJisx0201_T2 [i]._strNext, nNextState, _rJisx0201_T2 [i]._iNextRule + RULETREENO_SKK_JISX0201_BASE, _rJisx0201_T2 [i]._strOutput, nOutput)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	for (i = 0 ; i < ARRAYSIZE (_rJisx0201_T3) ; i ++) {
		if (_rJisx0201_T3 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rJisx0201_T3 [i]._strState, lstrlenW (_rJisx0201_T3 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rJisx0201_T3 [i]._strNext   != NULL)? lstrlenW (_rJisx0201_T3 [i]._strNext)   : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleM (&pRoot, RULETREENO_SKK_JISX0201_BASE, pPrefix, nPrefix, _rJisx0201_T3 [i]._strNext, nNextState, _rJisx0201_T3 [i]._iNextRule + RULETREENO_SKK_JISX0201_BASE, _rJisx0201_T3 [i]._nFunction)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	ppTree [0]	= pRoot ;

	pRoot	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (_rJisx0201_T2_1) ; i ++) {
		int	nOutput ;

		if (_rJisx0201_T2_1 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rJisx0201_T2_1 [i]._strState, lstrlenW (_rJisx0201_T2_1 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rJisx0201_T2_1 [i]._strNext   != NULL)? lstrlenW (_rJisx0201_T2_1 [i]._strNext)   : 0 ;
		nOutput		= (_rJisx0201_T2_1 [i]._strOutput != NULL)? lstrlenW (_rJisx0201_T2_1 [i]._strOutput) : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleS (&pRoot, RULETREENO_SKK_JISX0201_BASE, pPrefix, nPrefix, _rJisx0201_T2_1 [i]._strNext, nNextState, _rJisx0201_T2_1 [i]._iNextRule + RULETREENO_SKK_JISX0201_BASE, _rJisx0201_T2_1 [i]._strOutput, nOutput)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	ppTree [1]	= pRoot ;
	return	TRUE ;
}

BOOL
TSkkRuleTree_bInitializeJisx0201RomanDefault (
	struct CSkkRuleTreeNode**			ppTree,
	int									cbTree)
{
	struct CSkkRuleTreeNode*	pRoot ;
	int		i, nPrefix, nNextState ;
	DCHAR	dbufPrefix [64] ;
	LPCDSTR	pPrefix ;

	if (ppTree == NULL || cbTree < 1)
		return	FALSE ;

	/*	jisx0201-roman-rule-tree �̏������B
	 */
	pRoot	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (_rJisx0201Roman_T2) ; i ++) {
		int	nOutput ;

		if (_rJisx0201Roman_T2 [i]._strState != NULL) {
			nPrefix	= wcstodcs (dbufPrefix, ARRAYSIZE (dbufPrefix), _rJisx0201Roman_T2 [i]._strState, lstrlenW (_rJisx0201Roman_T2 [i]._strState)) ;
			pPrefix	= dbufPrefix ;
		} else {
			pPrefix	= NULL ;
			nPrefix	= 0 ;
		}
		nNextState	= (_rJisx0201Roman_T2 [i]._strNext   != NULL)? lstrlenW (_rJisx0201Roman_T2 [i]._strNext)   : 0 ;
		nOutput		= (_rJisx0201Roman_T2 [i]._strOutput != NULL)? lstrlenW (_rJisx0201Roman_T2 [i]._strOutput) : 0 ;
		if (! TSkkRuleTreeNode_bAddRuleS (&pRoot, RULETREENO_SKK_JISX0201_ROMAN, pPrefix, nPrefix, _rJisx0201Roman_T2 [i]._strNext, nNextState, _rJisx0201Roman_T2 [i]._iNextRule + RULETREENO_SKK_JISX0201_ROMAN, _rJisx0201Roman_T2 [i]._strOutput, nOutput)) {
			TSkkRuleTreeNode_vDestroyTree (pRoot) ;
			return	FALSE ;
		}
	}
	ppTree [0]	= pRoot ;
	return	TRUE ;
}

#if defined (UNIT_TEST)
/*	�P�̃e�X�g�̂��߂̃R�[�h�B
 */
int
_tmain (void)
{
	struct CSkkRuleTreeNode*	pRoot	= NULL ;
	struct CSkkRuleTreeNode*	pNode	= NULL ;
	int		i, n ;
	char	buf [12] ;

	/*
struct TSkkBaseRuleT1 {
	LPCTSTR	_strState ;
	LPCTSTR	_strNext ;
	struct {
		LPCTSTR	_strHira ;
		LPCTSTR	_strKata ;
	}	_case ;
} ;*/
	_tsetlocale (LC_CTYPE, TEXT ("")) ;

	/* debugger �� process �� attach ���邽�߂̗]�T�����B*/
	_tprintf (TEXT ("> ")) ;
	fflush (stdout) ;
	fgets (buf, 10, stdin) ;

	for (i = 0 ; i < ARRAYSIZE (_rT1) ; i ++) {
		int	nPrefix, nNextState, nHira, nKata ;

		nPrefix		= (_rT1 [i]._strState      != NULL)? lstrlenW (_rT1 [i]._strState)      : 0 ;
		nNextState	= (_rT1 [i]._strNext       != NULL)? lstrlenW (_rT1 [i]._strNext)       : 0 ;
		nHira		= (_rT1 [i]._case._strHira != NULL)? lstrlenW (_rT1 [i]._case._strHira) : 0 ;
		nKata		= (_rT1 [i]._case._strKata != NULL)? lstrlenW (_rT1 [i]._case._strKata) : 0 ;
		if (! TSkkRuleTreeNode_bAddRule (&pRoot, _rT1 [i]._strState, nPrefix, _rT1 [i]._strNext, nNextState, _rT1 [i]._case._strHira, nHira, _rT1 [i]._case._strKata, nKata)) {
			_tprintf (TEXT ("TSkkRuleTreeNode_bAddRule: failed. (%d)\n"), i) ;
			break ;
		}
	}
	if (pRoot != NULL) {
		_tprintf (TEXT ("Root ...\n")) ;
		TSkkRuleTreeNode_vDebugOut (pRoot) ;
	}
	n	= TSkkRuleTreeNode_iSearchTree (pRoot, L"b", 1, &pNode) ;
	_tprintf (TEXT ("Search ... \"b\" ... hit(%d)\n"), n) ;
	if (pNode != NULL) {
		TSkkRuleTreeNode_vDebugOut (pNode) ;
	}
	n	= TSkkRuleTreeNode_iSearchTree (pRoot, L"fya", 3, &pNode) ;
	_tprintf (TEXT ("Search ... \"fya\" ... hit(%d)\n"), n) ;
	if (pNode != NULL) {
		TSkkRuleTreeNode_vDebugOut (pNode) ;
	}
	return	0 ;
}
#endif



