#pragma once

typedef DWORD DCHAR ;

typedef DCHAR*			LPDSTR ;
typedef const DCHAR*	LPCDSTR ;

#define	GET_UNICODE_PLANE(ch)	((ch) >> 16)
#define	GET_UNICODE_CODE(ch)	((ch) & 0xFFFF)
#define	MAKE_DCHAR(plane,code)	(((DWORD)(plane) << 16) | (DWORD)(code))
#define	isdalnum(ch)			(GET_UNICODE_PLANE((ch)) == 0 && iswalnum((WCHAR)(ch)))

#ifndef IS_HIGH_SURROGATE
#define	IS_HIGH_SURROGATE(n1)		(0xD800 <= (n1) && (n1) < 0xDC00)
#endif
#ifndef IS_LOW_SURROGATE
#define	IS_LOW_SURROGATE(n2)		(0xDC00 <= (n2) && (n2) < 0xE000)
#endif
#ifndef IS_SURROGATE_PAIR
#define	IS_SURROGATE_PAIR(n1,n2)	(IS_HIGH_SURROGATE((n1)) && IS_LOW_SURROGATE((n2)))
#endif
#if !defined (WINVER) || WINVER < 0x0600
typedef enum _NORM_FORM {
    NormalizationOther  = 0,
    NormalizationC      = 0x1,
    NormalizationD      = 0x2,
    NormalizationKC     = 0x5,
	NormalizationKD     = 0x6,
} NORM_FORM;
#endif

#define	MAKE_DCHAR_FROM_SURROGATE_PAIR(dwHigh,dwLow)	(((((DWORD)(dwHigh) - 0xD800UL) << 10) | ((DWORD)(dwLow) - 0xDC00UL)) + 0x10000UL)
#define	GET_HIGHSURROGATE_FROM_DCHAR(dwD)	((WCHAR)(0xD800 + ((((dwD) - 0x10000UL) >> 10) & 0x3FF)))
#define	GET_LOWSURROGATE_FROM_DCHAR(dwD)	((WCHAR)(0xDC00 + (((dwD) - 0x10000UL) & 0x3FF)))


DWORD	todupper (DCHAR ch) ;
DWORD	todlower (DCHAR ch) ;
BOOL	isdspace (DCHAR ch) ;
int	dcsncmp (LPCDSTR, LPCDSTR, int) ;
int dcsnicmp (LPCDSTR, LPCDSTR, int) ;
int	dcslen (LPCDSTR) ;
int	dcscpy (LPDSTR, LPCDSTR) ;
int	dcsncpy (LPDSTR, LPCDSTR, int) ;
int	wcstodcs (LPDSTR pDest, int nDestSize, LPCWSTR pSrc, int nSrcLen) ;
int	dcstowcs (LPWSTR pDest, int nDestSize, LPCDSTR pSrc, int nSrcLen) ;
int	wcstodcs_n (LPDSTR pDest, int nDestSize, LPCWSTR pSrc, int nSrcLen) ;	// with normalize_C




