#if !defined (tsf_h)
#define	tsf_h

#if !defined (NELEMENTS)
#define	NELEMENTS(array)	(sizeof (array) / sizeof (array[0]))
#endif

inline void SafeStringCopy (WCHAR *pchDst, ULONG cchMax, const WCHAR *pchSrc)
{
    if (cchMax > 0)
    {
        wcsncpy(pchDst, pchSrc, cchMax);
        pchDst[cchMax-1] = '\0';
    }
}

typedef HRESULT (WINAPI *PTF_CREATETHREADMGR)(ITfThreadMgr**) ;
typedef HRESULT (WINAPI *PTF_CREATELANGBARITEMMGR)(ITfLangBarItemMgr**);

extern const CLSID	c_clsidSkkImeTextService ;
extern const GUID	c_guidSkkImeProfile ;
extern const GUID	c_guidItemButtonCMode ;
extern const GUID	c_guidItemButtonIME	;
extern const GUID	c_guidKeyboardItemButton ;

/*	prototypes */
BOOL	bButtonCMode_Create				(HIMC hIMC, ITfLangBarItem** ppLangBarItem) ;
HRESULT	hrButtonCMode_Update			(ITfLangBarItem* pItem) ;
HRESULT	hrButtonCMode_SetActiveContext	(ITfLangBarItem* pItem, HIMC hIMC) ;

BOOL	bButtonIME_Create				(HIMC hIMC, ITfLangBarItem** ppLangBarItem) ;
HRESULT	hrButtonIME_Update				(ITfLangBarItem* pItem) ;
HRESULT	hrButtonIME_SetActiveContext	(ITfLangBarItem* pItem, HIMC hIMC) ;

BOOL	bTSF_ShowKeyboardIcon		(BOOL fShow) ;

#endif

