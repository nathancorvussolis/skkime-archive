#include "StdAfx.h"
#include "TPacket.h"

#define	PACKET_ALIGN		(4)
#define	PADNUM(x)			((PACKET_ALIGN - ((x) & (PACKET_ALIGN - 1))) & (PACKET_ALIGN - 1))

BOOL
TPacket_bInitialize	(
	struct CTPacket*		pPacket)
{
	pPacket->m_nUsage	= 0 ;
	return	TRUE ;
}

BOOL
TPacket_bSetHeader	(
	struct CTPacket*		pPacket,
	int						nMajor,
	int						nMinor)
{
	pPacket->m_rbyBuffer [0]	= (BYTE) nMajor ;
	pPacket->m_rbyBuffer [1]	= (BYTE) nMinor ;
	pPacket->m_rbyBuffer [2]	= 0 ;
	pPacket->m_rbyBuffer [3]	= 0 ;
	pPacket->m_nUsage			= 4 ;
	return	TRUE ;
}

BOOL
TPacket_bAddPad		(
	struct CTPacket*		pPacket)
{
	register int	nPad	= PADNUM (pPacket->m_nUsage) ;

	if ((pPacket->m_nUsage + nPad) > TPACKET_MSGBUFSIZE)
		return	FALSE ;
	pPacket->m_nUsage	+= nPad ;
	return	TRUE ;

}

BOOL
TPacket_bAddCard32 (
	struct CTPacket*		pPacket,
	DWORD					dwData)
{
	register LPBYTE	pDest ;

	if ((pPacket->m_nUsage + 4) > TPACKET_MSGBUFSIZE)
		return	FALSE ;

	pDest		= pPacket->m_rbyBuffer + pPacket->m_nUsage ;
	*pDest ++	= (BYTE)(dwData >>  0) ;
	*pDest ++	= (BYTE)(dwData >>  8) ;
	*pDest ++	= (BYTE)(dwData >> 16) ;
	*pDest ++	= (BYTE)(dwData >> 24) ;
	pPacket->m_nUsage += 4 ;
	return	TRUE ;
}

BOOL
TPacket_bAddCard16 (
	struct CTPacket*		pPacket,
	unsigned int			woData)
{
	register LPBYTE	pDest ;

	if ((pPacket->m_nUsage + 2) > TPACKET_MSGBUFSIZE)
		return	FALSE ;

	pDest		= pPacket->m_rbyBuffer + pPacket->m_nUsage ;
	*pDest ++	= (BYTE)(woData >>  0) ;
	*pDest ++	= (BYTE)(woData >>  8) ;
	pPacket->m_nUsage	+= 2 ;
	return	TRUE ;
}

BOOL
TPacket_bAddCard8 (
	struct CTPacket*		pPacket,
	unsigned int			byData)
{
	if ((pPacket->m_nUsage + 1) > TPACKET_MSGBUFSIZE)
		return	FALSE ;

	pPacket->m_rbyBuffer [pPacket->m_nUsage ++]	= (BYTE) byData ;
	return	TRUE ;
}

BOOL
TPacket_bSetLength (
	struct CTPacket*		pPacket)
{
	register LPBYTE	pDest ;

	if (pPacket->m_nUsage < SKKISERV_PROTO_HEADER_SIZE || pPacket->m_nUsage > TPACKET_MSGBUFSIZE)
		return	FALSE ;

	pDest		= pPacket->m_rbyBuffer + 2 ;
	*pDest ++	= (BYTE) (pPacket->m_nUsage >> 0) ;
	*pDest ++	= (BYTE) (pPacket->m_nUsage >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_bSetCard16 (
	struct CTPacket*		pPacket,
	int						nPosition,
	unsigned int			woValue)
{
	register LPBYTE	pDest ;

	if (nPosition < 0 || (nPosition + 2) > pPacket->m_nUsage)
		return	FALSE ;

	pDest		= pPacket->m_rbyBuffer + nPosition ;
	*pDest ++	= (BYTE) (woValue >> 0) ;
	*pDest ++	= (BYTE) (woValue >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_bGetCard16 (
	struct CTPacket*		pPacket,
	int						nPosition,
	WORD*					pwResult)
{
	register WORD		woValue ;
	register const BYTE*	pSrc ;

	if (nPosition < 0 || (nPosition + 2) > pPacket->m_nUsage)
		return	FALSE ;

	pSrc		= pPacket->m_rbyBuffer + nPosition ;
	woValue		= (WORD) *pSrc ++ ;
	woValue		= woValue | ((WORD)*pSrc << 8) ;
	*pwResult	= woValue ;
	return	TRUE ;
}

BOOL
TPacket_bAddString (
	struct CTPacket*		pPacket,
	LPCWSTR					wstring,
	int						nstring)
{
	register int	nPos, nPad, nStringByteLen, nResultLength ;

	nPos			= pPacket->m_nUsage ;
	nStringByteLen	= nstring * sizeof (WCHAR) ;
	nPad			= PADNUM(nPos + 2 + nStringByteLen) ;
	nResultLength	= nPos + 2 + nStringByteLen + nPad ;
	if (nResultLength > TPACKET_MSGBUFSIZE)
		return	FALSE ;
		
	if (nstring > 0)
		memcpy (pPacket->m_rbyBuffer + nPos + 2, wstring, nStringByteLen) ;
		
	pPacket->m_nUsage			= nResultLength ;
	return	TPacket_bSetCard16 (pPacket, nPos, (WORD)nstring) ;
}

BOOL
TPacket_bAddByte (
	struct CTPacket*		pPacket,
	const BYTE*				pByte,
	int						nByte)
{
	if ((pPacket->m_nUsage + nByte) > TPACKET_MSGBUFSIZE)
		return	FALSE ;
	memcpy (pPacket->m_rbyBuffer + pPacket->m_nUsage, pByte, nByte) ;
	pPacket->m_nUsage	+= nByte ;
	return	TRUE ;
}

BOOL
TPacket_bGetHeader (
	struct CTPacket*		pPacket,
	int*					pnMajor,
	int*					pnMinor,
	int*					pnSize)
{
	if (pPacket->m_nUsage < SKKISERV_PROTO_HEADER_SIZE)
		return	FALSE ;
	if (pnMajor != NULL)
		*pnMajor	= pPacket->m_rbyBuffer [0] ;
	if (pnMinor != NULL)
		*pnMinor	= pPacket->m_rbyBuffer [1] ;
	if (pnSize != NULL) {
		register WORD		woSIZE ;
		woSIZE		= pPacket->m_rbyBuffer [3] ;
		woSIZE		= (woSIZE << 8) | (WORD)pPacket->m_rbyBuffer [2] ;
		*pnSize		= (int) woSIZE ;
	}
	return	TRUE ;
}

LPBYTE
TPacket_pGetData (
	struct CTPacket*		pPacket)
{
	return	pPacket->m_rbyBuffer ;
}

int
TPacket_iGetDataSize (
	struct CTPacket*		pPacket)
{
	return	pPacket->m_nUsage ;
}

void
TPacket_vSetDataSize (
	struct CTPacket*		pPacket,
	int						nSize)
{
	pPacket->m_nUsage	= nSize ;
	return ;
}

void
TPacket_vClear (
	struct CTPacket*		pPacket)
{
	pPacket->m_nUsage		= 0 ;
	return ;
}


