#pragma once

#include "TProtocol.h"

/*
 */
#define	TPACKET_MSGBUFSIZE	(2048)

/*
 */
struct CTPacket {
	BYTE	m_rbyBuffer [TPACKET_MSGBUFSIZE] ;
	int		m_nUsage ;
} ;

/*
 */
BOOL		TPacket_bInitialize	(struct CTPacket*) ;
BOOL		TPacket_bSetHeader	(struct CTPacket*, int, int) ;
BOOL		TPacket_bAddPad		(struct CTPacket*) ;
BOOL		TPacket_bAddCard32	(struct CTPacket*, DWORD) ;
BOOL		TPacket_bAddCard16	(struct CTPacket*, unsigned int) ;
BOOL		TPacket_bAddCard8	(struct CTPacket*, unsigned int) ;
BOOL		TPacket_bSetLength	(struct CTPacket*) ;
BOOL		TPacket_bSetCard16	(struct CTPacket*, int, unsigned int) ;
BOOL		TPacket_bGetCard16	(struct CTPacket*, int, WORD*) ;
BOOL		TPacket_bAddString	(struct CTPacket*, LPCWSTR, int) ;
BOOL		TPacket_bAddDString	(struct CTPacket*, LPCDSTR, int) ;
BOOL		TPacket_bAddByte	(struct CTPacket*, const BYTE*, int) ;
BOOL		TPacket_bGetHeader	(struct CTPacket*, int*, int*, int*) ;
LPBYTE		TPacket_pGetData	(struct CTPacket*) ;
int			TPacket_iGetDataSize(struct CTPacket*) ;
void		TPacket_vSetDataSize(struct CTPacket*, int) ;
void		TPacket_vClear		(struct CTPacket*) ;

