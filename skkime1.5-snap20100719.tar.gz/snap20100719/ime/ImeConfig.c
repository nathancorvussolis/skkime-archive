/*
 *	configuration �� update �������������ɂ��̒��g���Q�Ƃ���Ă����
 *	application ��������c���� rule-tree �̓r�������Ă��邱�Ƃ͂��蓾��B
 *	�����͉��Ƃ����Ȃ��Ƃ����Ȃ��Ǝv���B(�܂胁�b�Z�[�W���[�v�̂ǂ̈ʒu�ŁA��)
 */

#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "RuleTreeNode.h"
#include "keymap.h"
#include "jstring.h"
#include "ImeConfig.h"

/*========================================================================
 *	Registry-related definitions
 */
/*	generic configs */
#define	REGPATH_GENERIC						TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\Generic")
#define	REGINFO_KANAMODEWHENOPEN			TEXT("KanaModeWhenOpen")
#define	REGINFO_ECHO						TEXT("Echo")
#define	REGINFO_EGGLIKENEWLINE				TEXT("EggLikeNewline")
#define	REGINFO_NEWLINEKAKUTEIALL			TEXT("NewlineKakuteiAll")
#define	REGINFO_AUTOINSERTPAREN				TEXT("AutoInsertParen")
#define	REGINFO_COMPOSITIONAUTOSHIFT		TEXT("CompTextAutoShift")
#define	REGINFO_DELETEIMPLIESKAKUTEI		TEXT("DeleteImpliesKakutei")
#define	REGINFO_DATEAD						TEXT("DateAd")
#define	REGINFO_NUMBERSTYLE					TEXT("NumberStyle")
#define	REGINFO_BRACKETPARENS				TEXT("CustomBracketParens")
#define	REGINFO_KUTOUTENTYPE				TEXT("KutoutenType")
#define	REGINFO_KUTOUTENS					TEXT("CustomKutoutens")
#define	REGINFO_KAKUTEIEARLY				TEXT("KakuteiEarly")
#define	REGINFO_OKURICHARALISTTYPE			TEXT("OkuriCharAlistType")
#define	REGINFO_OKURICHARALIST				TEXT("OkuriCharAlist")
#define	REGINFO_TICK						TEXT("Tick")

/* key related */
#define	REGPATH_KEYMAP						TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\Generic")
#define	REGINFO_MAJORMODEMAP				TEXT("MajorModeMap")
#define	REGINFO_JMODEMAP					TEXT("JModeMap")
#define	REGINFO_LATINMODEMAP				TEXT("LatinModeMap")
#define	REGINFO_ZENKAKUMODEMAP				TEXT("Jisx0208LatinModeMap")
#define	REGINFO_ABBREVMODEMAP				TEXT("AbbrevModeMap")

#define	REGINFO_MAJORMODEMAP_EX				TEXT("MajorModeMapEx")
#define	REGINFO_JMODEMAP_EX					TEXT("JModeMapEx")
#define	REGINFO_LATINMODEMAP_EX				TEXT("LatinModeMapEx")
#define	REGINFO_ZENKAKUMODEMAP_EX			TEXT("Jisx0208LatinModeMapEx")
#define	REGINFO_ABBREVMODEMAP_EX			TEXT("AbbrevModeMapEx")

#define	REGINFO_KEYMAP_TYPE					TEXT("KeymapType")
#define	REGINFO_STARTHENKANKEY_TYPE			TEXT("StartHenkanKeyType")
#define	REGINFO_STARTHENKANKEY				TEXT("StartHenkanKey")
#define	REGINFO_COMPLETIONRELATEDKEY_TYPE	TEXT("CompletionRelatedKeyType")
#define	REGINFO_TRYCOMPLETIONKEY			TEXT("TryCompletionKey")
#define	REGINFO_PREVIOUSCOMPLETIONKEY		TEXT("PreviousCompletionKey")
#define	REGINFO_NEXTCOMPLETIONKEY			TEXT("NextCompletionKey")
#define	REGINFO_SETHENKANPOINTSUBRKEY_TYPE	TEXT("SetHenkanPointSubrKeyType")
#define	REGINFO_SETHENKANPOINTSUBRKEY		TEXT("SetHenkanPointSubrKey")
#define	REGINFO_SPECIALMIDASHICHAR_TYPE		TEXT("SpecialMidashiCharType")
#define	REGINFO_SPECIALMIDASHICHAR			TEXT("SpecialMidashiChar")

#define	REGPATH_ROMAKANARULE				TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\Generic")
#define	REGINFO_ROMAKANARULE_TYPE			TEXT("RomaKanaRuleType")
#define	REGINFO_ROMAKANARULE				TEXT("RomaKanaRule")
#define	REGINFO_ROMAKANARULE1				TEXT("RomaKanaRule1")
#define	REGINFO_ROMAKANARULE2				TEXT("RomaKanaRule2")
#define	REGINFO_ROMAKANARULE3				TEXT("RomaKanaRule3")
#define	REGINFO_JISX0201RULE				TEXT("Jisx0201Rule")
#define	REGINFO_JISX0201RULE1				TEXT("Jisx0201Rule1")
#define	REGINFO_JISX0201RULE2				TEXT("Jisx0201Rule2")
#define	REGINFO_JISX0201RULE3				TEXT("Jisx0201Rule3")
#define	REGINFO_JISX0201ROMANRULE			TEXT("Jisx0201RomanRule")
#define	REGINFO_JISX0201ROMANRULE1			TEXT("Jisx0201RomanRule1")
#define	REGINFO_JISX0201ROMANRULE2			TEXT("Jisx0201RomanRule2")
#define	REGINFO_JISX0201ROMANRULE3			TEXT("Jisx0201RomanRule3")

#define	ENABLE_OHHENKAN_DEFAULT_VALUE		TRUE

#define	REGPATH_ZENKAKUVECTOR				TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\Generic")
#define	REGINFO_ZENKAKUVECTOR_TYPE			TEXT("ZenkakuVectorType")
#define	REGINFO_ZENKAKUVECTOR				TEXT("ZenkakuVector")

/* conversion config */
#define	REGPATH_CONVERSION					TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\Conversion")
#define	REGINFO_CANDLISTKEYASSIGN			TEXT("CandidateListKeyAssign")
#define	REGINFO_SHOWCANDIDATEKEYS			TEXT("ShowCandidateKeys")
#define	REGINFO_INPUTCODEMENU1KEYS			TEXT("InputCodeMenu1Keys")
#define	REGINFO_INPUTCODEMENU2KEYS			TEXT("InputCodeMenu2Keys")
#define	REGINFO_SHOWCANDIDATELISTCOUNT		TEXT("ShowCandidateListCount")
#define	REGINFO_HENKANOKURISTRICTLY			TEXT("HenkanOkuriStrictly")
#define	REGINFO_PROCESSOKURIEARLY			TEXT("ProcessOkuriEarly")
#define	REGINFO_HENKANSTRICTOKURIPRECEDENCE	TEXT("HenkanStrictOkuriPrecedence")
#define	REGINFO_AUTOOKURIPROCESS			TEXT("AutoOkuriProcess")
#define	REGINFO_AUTOSTARTHENKAN				TEXT("AutoStartHenkan")
#define	REGINFO_AUTOSTARTHENKANKEYWORD		TEXT("AutoStartHenkanKeyword")
#define	REGINFO_DELETEOKURIWHENQUIT			TEXT("DeleteOkuriWhenQuit")
#define	REGINFO_SHOWANNOTATIONTYPE			TEXT("ShowAnnotationType")
#define	REGINFO_NUMERICCONVERSION			TEXT("NumericConversion")
#define	REGINFO_NUMERICFLOAT				TEXT("NumericFloat")
#define	REGINFO_AUTOSTARTHENKANKEYWORD_W	L"AutoStartHenkanKeyword"

/* colorface */
#define	REGPATH_COLORFACE					TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\ColorFace")
#define	REGSUBKEY_COLORFACE					TEXT("style")

#define	REGSUBKEY_DEFAULTFONTFACE			TEXT("DefaultFont")
#define	REGSUBKEY_DEFAULTFONTSIZE			TEXT("DefaultFontSize")


/*========================================================================
 *	definitions
 */
#define	MAX_KEYBINDS					SIZE_IMEDOC_KEYMAP
#define	MAX_LENGTH_INPUTVECTOR			128
#define	MAX_SPECIALKEYS					64

enum {
	KEYBINDTP_DEFAULT		= 0,
	KEYBINDTP_USERDEFINED,
} ;

enum {
	REGKEYTYPE_UNKNOWN	= -1,
	REGKEYTYPE_BOOL		= 0,
	REGKEYTYPE_INT,
} ;

enum {
	KUTOUTEN_TYPE_JP	= 0,
	KUTOUTEN_TYPE_EN,
	KUTOUTEN_TYPE_CUSTOM,
} ;

enum {
	BRACKETPARENTP_DEFAULT	= 0,
	BRACKETPARENTP_USERDEFINED,
} ;

enum {
	OKURICHARTP_DEFAULT	= 0,
	OKURICHARTP_USERDEFINED,
} ;

#define	BUFSIZE_STRPAIR					32

#define	MAX_NUMKUTOUTENS				32
#define	MAX_NUMBRACKETPARENS			32
#define	MAX_NUMOKURICHARPAIR			32

/* for menu-keys (show-candidates-list-keys, input-by-code-or-menu1/2-keys */
#define	MAX_NUMMENUKEYS					256

enum {
	CANDLIST_KEYASSIGN_DEFAULT			= 0,
	CANDLIST_KEYASSIGN_01234567890,
	CANDLIST_KEYASSIGN_USERDEFINED		= 65535,
} ;


/* for colorface */
#define	MAX_NUMCOLORFACES	2

#if defined (UNITTEST)
enum {
	MYCOLOR_TEXTAUTO	= 0,	MYCOLOR_BACKAUTO,			MYCOLOR_BLACK,
	MYCOLOR_DARKRED,			MYCOLOR_DARKGREEN,			MYCOLOR_DARKYELLOW,
	MYCOLOR_DARKBLUE,			MYCOLOR_DARKPURPLE,			MYCOLOR_DARKLIGHTBLUE,
	MYCOLOR_DARKGRAY,			MYCOLOR_LIGHTGRAY,			MYCOLOR_RED,
	MYCOLOR_GREEN,				MYCOLOR_YELLOW,				MYCOLOR_BLUE,
	MYCOLOR_PURPLE,				MYCOLOR_LIGHTBLUE,			MYCOLOR_WHITE,
	MYCOLOR_SYSTEM,	
	MYCOLOR_BTNFACE		= MYCOLOR_SYSTEM,
	MYCOLOR_BTNTEXT,			MYCOLOR_ACTIVEBORDER,		MYCOLOR_ACTIVECAPTION,
	MYCOLOR_CAPTIONTEXT,		MYCOLOR_APPWORKSPACE,		MYCOLOR_WINDOW,
	MYCOLOR_WINDOWTEXT,			MYCOLOR_DESKTOP,			MYCOLOR_INFOBK,	
	MYCOLOR_INFOTEXT,			MYCOLOR_MSGBOXTEXT,			MYCOLOR_MENU,
	MYCOLOR_MENUTEXT,			MYCOLOR_HIGHLIGHTTEXT,		MYCOLOR_HIGHLIGHT,	
	MYCOLOR_INACTIVEBORDER,		MYCOLOR_INACTIVECAPTION,	MYCOLOR_INACTIVECAPTIONTEXT,
	MAX_MYCOLOR,
} ;

enum {
	MYLINE_NO	= 0,	MYLINE_SOLID,		MYLINE_DOTTED,
	MYLINE_THICK_SOLID,	MYLINE_THIN_DITHER,	MYLINE_THICK_DITHER,
	MAX_MYLINE,
} ;

enum {
	MYCOLORFACE_INDEX_MIHENKANMOJIRETSU	= 0,
	MYCOLORFACE_INDEX_HENKANMOJIRETSU	= 1,
} ;
#endif

/*========================================================================
 *	structures
 */
struct TStringPair {
	DCHAR	m_bufLeft  [BUFSIZE_STRPAIR] ;
	DCHAR	m_bufRight [BUFSIZE_STRPAIR] ;
} ;

struct MYCOLORDEF {
	LPCTSTR		m_strText ;
	int			m_nType ;
} ;

/*========================================================================
 *	prototypes
 */
static	BOOL	imeConfig_bLoadZenkakuVector		(void) ;
static	void	imeConfig_vClearZenkakuVector		(void) ;
static	BOOL	imeConfig_bLoadRomaKanaRuleList		(void) ;
static	void	imeConfig_vClearRomaKanaRuleList	(void) ;
static	BOOL	imeConfig_bLoadKeymap				(void) ;
static	BOOL	imeConfig_bLoadGenericSetting		(void) ;
static	BOOL	imeConfig_bLoadConversionSetting	(void) ;
static	BOOL	imeConfig_bLoadColorfaceSetting		(void) ;
static	void	imeConfig_vInitializeDefaultFontSetting	(void) ;
static	BOOL	imeConfig_bParseBSEncodedString		(LPCTSTR*, LPTSTR, int, BOOL*) ;
static	int		imeConfig_iDecodeStringPairList		(LPCTSTR, struct TStringPair*, int) ;
static	BOOL	imeConfig_bDefineKey				(struct CImeKeymap*, int, unsigned int, int) ;

static	void	imeConfig_vInitAutoStartHenkanKeys	(LPCWSTR pwKeys, int nKeyLen) ;

/*========================================================================
 *	global variables (default settings)
 */
static	LPCWSTR	_rstrDefaultJisx0208LatinVector [128]	= {
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,
	L"�@",	L"�I",	L"�h",	L"��",	L"��",	L"��",	L"��",	L"�f",
	L"�i",	L"�j",	L"��",	L"�{",	L"�C",	L"�|",	L"�D",	L"�^",
	L"�O",	L"�P",	L"�Q",	L"�R",	L"�S",	L"�T",	L"�U",	L"�V",
	L"�W",	L"�X",	L"�F",	L"�G",	L"��",	L"��",	L"��",	L"�H",
	L"��",	L"�`",	L"�a",	L"�b",	L"�c",	L"�d",	L"�e",	L"�f",
	L"�g",	L"�h",	L"�i",	L"�j",	L"�k",	L"�l",	L"�m",	L"�n",
	L"�o",	L"�p",	L"�q",	L"�r",	L"�s",	L"�t",	L"�u",	L"�v",
	L"�w",	L"�x",	L"�y",	L"�m",	L"�_",	L"�n",	L"�O",	L"�Q",
	L"�e",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",
	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",
	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",	L"��",
	L"��",	L"��",	L"��",	L"�o",	L"�b",	L"�p",	L"�`",	NULL,
} ;

/*========================================================================
 *	global variables (current settings)
 */
/* key related config */
static	int			_siRomaKanaRuleListType ;
static	int			_siKeybindType ;
static	int			_siStartHenkanKeyType ;
static	int			_siCompletionRelatedKeyType ;
static	int			_siSetHenkanPointSubrKeyType ;
static	int			_siSpecialMidashiCharKeyType ;

static	struct CSkkRuleTreeNode*	_rpSkkRuleTree [NUM_ROMAKANARULE]				= { NULL } ;
static	struct CSkkRuleTreeNode*	_rpSkkJisx0201RomanRuleTree [NUM_ROMAKANARULE]	= { NULL } ;
static	struct CSkkRuleTreeNode*	_rpSkkJisx0201RuleTree [NUM_ROMAKANARULE]		= { NULL } ;
static	LPDSTR						_rstrJisx0208LatinVector	[128]	= { NULL } ;
static	struct CImeKeymap			_sMajorModeMap ;
static	struct CImeKeymap			_sSkkJModeMap ;
static	struct CImeKeymap			_sSkkLatinModeMap ;
static	struct CImeKeymap			_sSkkJisx0208LatinModeMap ;
static	struct CImeKeymap			_sSkkAbbrevModeMap ;
static	struct CImeKeymap			_sMinibufferMinorModeMap ;
static	BOOL						_bOHHenkan ;
static	struct CSkkRuleTreeNodeOutput*	_pOhOutput						= NULL ;


/* skk-insert ���œ���ȓ��������L�[�̐ݒ�B(�ǂ����� rule �ɏ����Ȃ��񂾂낤�H) */
static	int			_siNumStartHenkanKeys ;
static	BYTE		_srbyStartHenkanKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumTryCompletionKeys ;
static	BYTE		_srbyTryCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumPreviousCompletionKeys ;
static	BYTE		_srbyPreviousCompletionKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumNextCompletionKeys ;
static	BYTE		_srbyNextCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumSetHenkanPointSubrKeys ;
static	BYTE		_srbySetHenkanPointSubrKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumSpecialMidashiCharKeys ;
static	BYTE		_srbySpecialMidashiCharKeys		[MAX_SPECIALKEYS] ;

static	BOOL		_bMaskSkkSetHenkanPointKey	= FALSE ;
static	BOOL		_bEggLikeNewline		= FALSE ;
static	BOOL		_bNewlineKakuteiAll		= TRUE ;

/* generic config */
static	BOOL		_bKanaModeWhenOpen		= TRUE ;
static	BOOL		_bEcho					= TRUE ;
static	BOOL		_bAutoInsertParen		= TRUE ;
static	BOOL		_bCompositionAutoShift	= TRUE ;
static	BOOL		_bDeleteImpliesKakutei	= TRUE ;
static	BOOL		_bKakuteiEarly			= FALSE ;

/* date & number style */
static	int			_bDateAd				= FALSE ;
static	int			_iNumberStyle			= 0 ;

/* kutouten & bracket settins */
static	int						_iKutoutenType			= KUTOUTEN_TYPE_JP ;
static	int						_iNumKutouten			= 0 ;
static	int						_iNumBracketParen		= 0 ;
static	int						_iNumOkuriCharAlist		= 0 ;
static	struct TStringPair		_srKutouten			[MAX_NUMKUTOUTENS] ;
static	int						_iBracketParenType		= BRACKETPARENTP_DEFAULT ;
static	struct TStringPair		_srBracketParen		[MAX_NUMBRACKETPARENS] ;
static	int						_iOkuriCharAlistType	= OKURICHARTP_DEFAULT ;
static	struct TStringPair		_srOkuriCharAlist	[MAX_NUMOKURICHARPAIR] ;

/* conversion settings */
static	int			_snCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;

static	int			_snNumShowCandidateKeys ;
static	int			_snNumInputCodeMenu1Keys ;
static	int			_snNumInputCodeMenu2Keys ;
static	DCHAR		_srdchShowCandidateKeys  [MAX_NUMMENUKEYS]	= { 0 } ;
static	DCHAR		_srdchInputCodeMenu1Keys [MAX_NUMMENUKEYS]	= { 0 } ;
static	DCHAR		_srdchInputCodeMenu2Keys [MAX_NUMMENUKEYS]	= { 0 } ;
static	int			_snShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;

static	BOOL		_sbHenkanOkuriStrictly			= FALSE ;
static	BOOL		_sbProcessOkuriEarly			= FALSE ;
static	BOOL		_sbHenkanStrictOkuriPrecedence	= FALSE ;
static	BOOL		_sbAutoOkuriProcess				= FALSE ;
static	BOOL		_sbAutoStartHenkan				= TRUE ;
static	BOOL		_sbDeleteOkuriWhenQuit			= FALSE ;

static	BOOL		_sbNumericConversion			= TRUE ;
static	BOOL		_sbNumericFloat					= FALSE ;

static	int			_snShowAnnotationType			= SHOW_NO_ANNOTATION ;

static	int			_siNumAutoStartHenkanKeywords		= 0 ;
static	DCHAR		_srAutoStartHenkanKeywords [512]	= { TEXT ('\0') } ;

/* colorface settings */
static	 MYCOLORFACESET	_srImeColorFaces [MAX_NUMCOLORFACES] ;

/*	Dialog �ɂȂ�(�ݒ荀�ڂ����Y��Ă����㕨)
 *	completion �� 1property sheet page ����Ă��ǂ��Ǝv���B
 */
static	BOOL		_bAllowsSpacesNewlinesAndTabs	= FALSE ;
/* ���ڃR�[�h���͂� default kanji-code charset */
static	int			_iKanjiCodeCharset				= KCODE_CHARSET_JAPANESE_JISX0208 ;
static	BOOL		_bCompCirculate					= FALSE ;

/* minibuffer �̕\���ɗp����f�t�H���g�̃t�H���g�̐ݒ�B*/
static	LOGFONT		_slfDefaultFont ;
static	int			_siDefaultFontSize				= -1 ;

/*	�����ɖ�����������́B
 *	ImeDoc_bSkkTryCompletionCharp (const struct CImeDoc* pDoc, int nCH)
 *	BOOL	ImeConfig_bSkkStartHenkanCharp (int						nCH)
 *	���̂�����B
 */
/*	�ݒ�� sync �Ɏg���B
 */
static	BOOL	_bHaveSyncTick	= FALSE ;
static	DWORD	_dwSyncTick		= 0 ;

/*========================================================================
 *	public functions
 */
void
ImeConfig_vLoad (void)
{
	HKEY	hSubKey ;
	DWORD	dwTick		= 0 ;
	BOOL	bHaveTick	= FALSE ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData ;
		LONG	lResult ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bHaveTick	= TRUE ;
		}
		RegCloseKey (hSubKey) ;
	}

	imeConfig_bLoadZenkakuVector () ;
	imeConfig_bLoadRomaKanaRuleList () ;
	imeConfig_bLoadKeymap () ;
	_bMaskSkkSetHenkanPointKey	= FALSE ;
	imeConfig_bLoadGenericSetting () ;
	imeConfig_bLoadConversionSetting () ;
	imeConfig_bLoadColorfaceSetting () ;
	imeConfig_vInitializeDefaultFontSetting () ;

	_bHaveSyncTick	= bHaveTick ;
	_dwSyncTick		= dwTick ;
	return ;
}

void
ImeConfig_vUnload (void)
{
	imeConfig_vClearZenkakuVector () ;
	imeConfig_vClearRomaKanaRuleList () ;

	_bHaveSyncTick	= FALSE ;
	_dwSyncTick		= 0 ;
	return ;
}

void
ImeConfig_vUpdate (void)
{
	HKEY	hSubKey ;
	DWORD	cbData, dwType, dwTick ;
	BOOL	bUpdate ;
	LONG	lResult ;

	if (RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
		bUpdate	= ! _bHaveSyncTick ;
		dwTick	= 0 ;
	} else {
		bUpdate	= FALSE ;
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueExW (hSubKey, REGINFO_TICK, NULL, &dwType, (BYTE*)&dwTick, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			bUpdate	= ! _bHaveSyncTick || (_dwSyncTick != dwTick) ;
		}
		RegCloseKey (hSubKey) ;
	}
	if (! bUpdate)
		return ;

	ImeConfig_vUnload () ;
	ImeConfig_vLoad () ;
	_bHaveSyncTick	= TRUE ;
	_dwSyncTick		= dwTick ;
	return ;
}

/*
 */
BOOL
ImeConfig_bKanaModeWhenOpenp (void)
{
	return	_bKanaModeWhenOpen ;
}

struct CSkkRuleTreeNode*
ImeConfig_pGetSkkRuleTree (int iRule)
{
	if (RULETREENO_SKK_BASE <= iRule && iRule < (RULETREENO_SKK_BASE + NUM_ROMAKANARULE))
		return	_rpSkkRuleTree [iRule - RULETREENO_SKK_BASE] ;
	if (RULETREENO_SKK_JISX0201_ROMAN <= iRule && iRule < (RULETREENO_SKK_JISX0201_ROMAN + NUM_ROMAKANARULE))
		return	_rpSkkJisx0201RomanRuleTree [iRule - RULETREENO_SKK_JISX0201_ROMAN] ;
	if (RULETREENO_SKK_JISX0201_BASE <= iRule && iRule < (RULETREENO_SKK_JISX0201_BASE + NUM_ROMAKANARULE))
		return	_rpSkkJisx0201RuleTree [iRule - RULETREENO_SKK_JISX0201_BASE] ;
	return	NULL ;
}

BOOL
ImeConfig_bSkkKakuteiEarlyp (void) 
{
	return	_bKakuteiEarly ;
}

BOOL
ImeConfig_bSkkProcessOkuriEarlyp (void) 
{
	return	_sbProcessOkuriEarly ;
}

BOOL
ImeConfig_bSkkEchop (void)
{
	return	_bEcho ;
}

BOOL
ImeConfig_bSkkTryCompletionCharp (int nCH)
{
	if (_siCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'\t')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyTryCompletionKeys, nCH, _siNumTryCompletionKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
ImeConfig_bSkkPreviousCompletionCharp (int nCH)
{
	if (_siCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'.')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyPreviousCompletionKeys, nCH, _siNumPreviousCompletionKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
ImeConfig_bSkkNextCompletionCharp (int nCH)
{
	if (_siCompletionRelatedKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L',')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyNextCompletionKeys, nCH, _siNumNextCompletionKeys) != NULL)? TRUE : FALSE ;
	}
}

BOOL
ImeConfig_bSkkAutoStartHenkanp (void)
{
	return	_sbAutoStartHenkan ;	//FALSE
}

BOOL
ImeConfig_bSkkAutoStartHenkanKeywordp (
	LPCDSTR						pwString,
	int							nStringLength)
{
	/*	�����ϊ��X�^�[�g�L�[���[�h�Ƃ����̂��������̂�Y��Ă����c�B����̓J�X�^�}�C�Y���ڂ��B
	static	LPCDSTR		_rstrSkkAutoStartHenkanKeywords []	= {
		L"��", L"�A", L"�B", L"�D", L"�C", L"�H", L"�v",  L"�I", L"�G", L"�F", L")", L";", L":",
		L"�j", L"�h", L"�z", L"�x", L"�t", L"�r", L"�p",  L"�n", L"�l", L"}",  L"]", L"?", L".",
		L",",  L"!",
	} ;
	 */
	LPCDSTR		pKeywords ;
	int			i ;

	if (pwString == NULL || nStringLength <= 0)
		return	FALSE ;

	pKeywords	= _srAutoStartHenkanKeywords ;
	for (i = 0 ; i < _siNumAutoStartHenkanKeywords && *pKeywords != L'\0' ; i ++) {
		if (! dcsncmp (pKeywords, pwString, nStringLength) && pKeywords [nStringLength] == L'\0')
			return	TRUE ;
		pKeywords	+= dcslen (pKeywords) + 1 ;
	}
	return	FALSE ;
}

BOOL
ImeConfig_bSkkSpecialMidashiCharp (int nCH)
{
	if (_siSpecialMidashiCharKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L'?' || nCH == L'>' || nCH == L'<')? TRUE : FALSE ;
	} else {
		int		i ;
		for (i = 0 ; i < _siNumSpecialMidashiCharKeys && i < ARRAYSIZE (_srbySpecialMidashiCharKeys) ; i ++) {
			if (_srbySpecialMidashiCharKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
ImeConfig_bSkkSetHenkanPointKeyp (int nCH) 
{
	if (_bMaskSkkSetHenkanPointKey)
		return	FALSE ;

	if (_siSetHenkanPointSubrKeyType == KEYBINDTP_DEFAULT) {
		/* (?A ?B ?C ?D ?E ?F ?G ?H ?I ?J ?K ?M ?N ?O ?P ?R ?S ?T ?U ?V ?W ?Y ?Z) */
		return	(L'A' <= nCH && nCH <= L'Z' && nCH != L'L' && nCH != L'Q' && nCH != L'X')? TRUE : FALSE ;
	} else {
		int	i ;
		for (i = 0 ; i < _siNumSetHenkanPointSubrKeys && i < ARRAYSIZE (_srbySetHenkanPointSubrKeys) ; i ++) {
			if (_srbySetHenkanPointSubrKeys [i] == nCH)
				return	TRUE ;
		}
		return	FALSE ;
	}
}

BOOL
ImeConfig_bSkkSetHenkanPointKeyMaskedp (void)
{
	return	_bMaskSkkSetHenkanPointKey ;
}

void
ImeConfig_vMaskSkkSetHenkanPointKey (BOOL bValue)
{
	_bMaskSkkSetHenkanPointKey	= bValue ;
	return ;
}

BOOL
ImeConfig_bSkkStartHenkanCharp (
	int						nCH)
{
	/* ���[�ށA����͂ǂ�����ׂ����B��͂� j-mode-map �Ń`�F�b�N���B
	 *	... space �� skk-insert �Ȃ̂��B����� skk-insert ������ start-henkan ���ƌ������߂ɂ���̂��c
	 *	����͂܂����ȁBkeyfunc �����|���� skk-insert �����ǁc�ɂ��Ȃ��Ƃ��߂��B
	 *	����̓L�[�̒ǉ��̂Ƃ���Őݒ肳���邵���Ȃ��ȁB
	 */
	if (_siStartHenkanKeyType == KEYBINDTP_DEFAULT) {
		return	(nCH == L' ')? TRUE : FALSE ;
	} else {
		return	(memchr (_srbyStartHenkanKeys, nCH, _siNumStartHenkanKeys) != NULL)? TRUE : FALSE ;
	}
}

int
ImeConfig_iSkkARefSkkKanaRomVector (
	int						nCH, 
	LPDSTR					pOkuri,
	int						nOkuri)
{
	/*	���̕\�A�J�X�^�}�C�Y����K�v�͂���̂��낤���H �ۑ�Ƃ��ĐS�ɗ��߂Ă������ƁB
	 */
	static const struct {
		int				nKana ;
		LPCWSTR			wstrRom ;
	}	_rSkkKanaRomVector []	= {
		{ L'��', L"x" },	{ L'��', L"a" },	{ L'��', L"x" },	{ L'��', L"i" },
		{ L'��', L"x" },	{ L'��', L"u" },	{ L'��', L"x" },	{ L'��', L"e" },
		{ L'��', L"x" },	{ L'��', L"o" },	{ L'��', L"k" },	{ L'��', L"g" },
		{ L'��', L"k" },	{ L'��', L"g" },	{ L'��', L"k" },	{ L'��', L"g" },
		{ L'��', L"k" },	{ L'��', L"g" },	{ L'��', L"k" },	{ L'��', L"g" },
		{ L'��', L"s" },	{ L'��', L"z" },	{ L'��', L"s" },	{ L'��', L"j" },
		{ L'��', L"s" },	{ L'��', L"z" },	{ L'��', L"s" },	{ L'��', L"z" },
		{ L'��', L"s" },	{ L'��', L"z" },	{ L'��', L"t" },	{ L'��', L"d" },
		{ L'��', L"t" },	{ L'��', L"d" },	{ L'��', L"t" },	{ L'��', L"t" },
		{ L'��', L"d" },	{ L'��', L"t" },	{ L'��', L"d" },	{ L'��', L"t" },
		{ L'��', L"d" },	{ L'��', L"n" },	{ L'��', L"n" },	{ L'��', L"n" },
		{ L'��', L"n" },	{ L'��', L"n" },	{ L'��', L"h" },	{ L'��', L"b" },

		{ L'��', L"p" },	{ L'��', L"h" },	{ L'��', L"b" },	{ L'��', L"p" },
		{ L'��', L"h" },	{ L'��', L"b" },	{ L'��', L"p" },	{ L'��', L"h" },
		{ L'��', L"b" },	{ L'��', L"p" },	{ L'��', L"h" },	{ L'��', L"b" },
		{ L'��', L"p" },	{ L'��', L"m" },	{ L'��', L"m" },	{ L'��', L"m" },
		{ L'��', L"m" },	{ L'��', L"m" },	{ L'��', L"x" },	{ L'��', L"y" },
		{ L'��', L"x" },	{ L'��', L"y" },	{ L'��', L"x" },	{ L'��', L"y" },
		{ L'��', L"r" },	{ L'��', L"r" },	{ L'��', L"r" },	{ L'��', L"r" },
		{ L'��', L"r" },	{ L'��', L"x" },	{ L'��', L"w" },	{ L'��', L"x" },
		{ L'��', L"x" },	{ L'��', L"w" },	{ L'��', L"n" },
	} ;
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rSkkKanaRomVector) ; i ++) {
		if (nCH == _rSkkKanaRomVector [i].nKana) {
			int		nLength, n ;

			nLength	= lstrlenW (_rSkkKanaRomVector [i].wstrRom) ;
			if (nLength > 0) {
				n	= wcstodcs (pOkuri, nOkuri, _rSkkKanaRomVector [i].wstrRom, nLength) ;
			} else {
				n	= 0 ;
			}
			return	n ;
		}
	}
	return	0 ;
}

int
ImeConfig_iGetSkkShowAnnotationType (void)
{
	return	_snShowAnnotationType ;
}

BOOL
ImeConfig_bSkkEggLikeNewline (void) 
{
	return	_bEggLikeNewline ;
}

BOOL
ImeConfig_bSkkDeleteOkuriWhenQuit (void)
{
	return	_sbDeleteOkuriWhenQuit ;
}

BOOL
ImeConfig_bSkkDeleteImplesKakuteip (void) 
{
	return	_bDeleteImpliesKakutei ;
}

LPCDSTR
ImeConfig_pGetSkkHenkanShowCandidatesKeys (int* pnKeys)
{
	if (pnKeys != NULL)
		*pnKeys	= _snNumShowCandidateKeys ;
	return	_srdchShowCandidateKeys ;
}

BOOL
ImeConfig_bSkkNumericConversionp (void)
{
	return	_sbNumericConversion ;
}

BOOL
ImeConfig_bSkkNumConvertFloatp (void)
{
	return	_sbNumericFloat ;
}

BOOL
ImeConfig_bSkkCompCirculatep (void)
{
	return	_bCompCirculate ;
}

int
ImeConfig_iGetSkkKcodeCharset (void)
{
	return	_iKanjiCodeCharset ;
}

LPCDSTR
ImeConfig_pGetSkkInputByCodeMenuKeys1 (int* pnKeys)
{
	if (pnKeys != NULL) {
		*pnKeys	= _snNumInputCodeMenu1Keys ;
	}
	return	_srdchInputCodeMenu1Keys ;
}

LPCDSTR
ImeConfig_pGetSkkInputByCodeMenuKeys2 (int* pnKeys)
{
	if (pnKeys != NULL) {
		*pnKeys	= _snNumInputCodeMenu2Keys ;
	}
	return	_srdchInputCodeMenu2Keys ;
}

int
ImeConfig_iGetSkkOkuriChar (
	LPCDSTR					pwOkuriChar,
	int						nOkuriCharLen,
	LPDSTR					pwDest,
	int						nDestSize)
{
	int		i, nLen ;

	if (_iOkuriCharAlistType != OKURICHARTP_USERDEFINED)
		return	0 ;

	for (i = 0 ; i < _iNumOkuriCharAlist ; i ++) {
		if (dcsncmp (pwOkuriChar, _srOkuriCharAlist [i].m_bufLeft, nOkuriCharLen) == 0 &&
			_srOkuriCharAlist [i].m_bufLeft [nOkuriCharLen] == L'\0') {
			/*	hit */
			nLen	= MIN (nDestSize, dcslen (_srOkuriCharAlist [i].m_bufRight)) ;
			if (nLen > 0)
				dcsncpy (pwDest, _srOkuriCharAlist [i].m_bufRight, nLen) ;
			return	nLen ;
		}
	}
	return	0 ;
}

BOOL
ImeConfig_bSkkHenkanOkuriStrictlyp (void)
{
	return	_sbHenkanOkuriStrictly ;
}

BOOL
ImeConfig_bSkkHenkanStrictOkuriPrecedencep (void)
{
	return	_sbHenkanStrictOkuriPrecedence ;
}

/*	auto-okuri-process �𗘗p����̂́Askkiserv ���ł���Ǝv���邪�A�ꉞ���̋L�q�͓���Ă����B
 */
BOOL
ImeConfig_bSkkAutoOkuriProcessp (void)
{
	return	_sbAutoOkuriProcess ;
}

const struct CSkkRuleTreeNodeOutput*
ImeConfig_pGetOhRuleTreeNodeOutput	(void)
{
	return	_pOhOutput ;
}

int
ImeConfig_iSkkARefSkkJisx0208LatinVector (
	int						nCH, 
	LPDSTR					pResult,
	int						nResultSize)
{
	if (0 <= nCH && nCH < ARRAYSIZE (_rstrJisx0208LatinVector)  &&
		_rstrJisx0208LatinVector [nCH] != NULL) {
		int		n ;
		n	= dcslen (_rstrJisx0208LatinVector [nCH]) ;
		n	= (n > nResultSize)? nResultSize : n ;
		if (n > 0) 
			dcsncpy (pResult, _rstrJisx0208LatinVector [nCH], n) ;
		return	n ;
	}
	return	-1 ;	/* not hit */
}

/*	�t�����B
 */
int
ImeConfig_iSkkRevRefSkkJisx0208LatinVector (
	int						nCH, 
	LPDSTR					pResult,
	int						nResultSize)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rstrJisx0208LatinVector) ; i ++) {
		if (_rstrJisx0208LatinVector [i] != NULL && 
			*(_rstrJisx0208LatinVector [i] + 0) == nCH &&
			*(_rstrJisx0208LatinVector [i] + 1) == L'\0') {
			if (nResultSize > 0)
				*pResult	= i ;
			return	1 ;
		}
	}
	return	-1 ;	/* not hit */
}

BOOL
ImeConfig_bSkkAutoInsertParen (void)
{
	return	_bAutoInsertParen ;
}

int
ImeConfig_iSkkAssocSkkAutoParenStringAlist	(
	LPCDSTR					pwString,
	int						nStringLen,
	LPDSTR					pwResult,
	int						nResultSize)
{
	int		i ;

	for (i = 0 ; i < _iNumBracketParen ; i ++) {
		if (! dcsncmp (pwString, _srBracketParen [i].m_bufLeft, nStringLen) && 
			_srBracketParen [i].m_bufLeft [nStringLen]	== L'\0') {
			int		n ;
			n	= dcslen (_srBracketParen [i].m_bufRight) ;
			n	= (n > nResultSize)? nResultSize : n ;
			if (n > 0) 
				dcsncpy (pwResult, _srBracketParen [i].m_bufRight, n) ;
			return	n ;
		}
	}
	return	-1 ;	/* not hit */
}

/*	���̐ݒ�͍��̂Ƃ���J�X�^�}�C�Y�ł��Ȃ��B��� FALSE �ɂ��Ă������A����ł����̂��c�H
 */
BOOL
ImeConfig_bSkkAllowsSpacesNewlinesAndTabs	(void)
{
	return	_bAllowsSpacesNewlinesAndTabs ;
}

int
ImeConfig_iGetNumberOfKutotens (void)
{
	return	_iNumKutouten ;
}

LPCDSTR
ImeConfig_pGetCurrentTouten (
	int					iKutoutenType,
	int*				pnLength)
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % _iNumKutouten ;
	if (pnLength != NULL)
		*pnLength	= dcslen (_srKutouten [nIndex].m_bufLeft) ;
	return	_srKutouten [nIndex].m_bufLeft ;
}

LPCDSTR
ImeConfig_pGetCurrentKuten (
	int					iKutoutenType,
	int*				pnLength)
{
	unsigned int		nIndex ;

	nIndex	= (unsigned int)iKutoutenType % _iNumKutouten ;
	if (pnLength != NULL)
		*pnLength	= dcslen (_srKutouten [nIndex].m_bufRight) ;
	return	_srKutouten [nIndex].m_bufRight ;
}

/*	Newline -> Kakutei �̌�Apoint-marker �� buffer �̍Ō�ֈړ������邩�ۂ��B
 *	shift-count �̐�����A���ꂪ TRUE ���ƁuComposition �̑S�m��v�Ɍ�����B
 */
BOOL
ImeConfig_bSkkIsNewlineKakuteiAllp (void)
{
	return	_bNewlineKakuteiAll ;
}

/*	�����I�� CompositionString ���m��ς݂Ƃ��đ����邩�ǂ��������肷��B
 *	��{�I�Ɂu�o�b�t�@�̐擪�v����upoint-marker�̈ʒu�v�u�ϊ��J�n�ʒu�v
 *	�u�����J�n�ʒu�v�̒��ōŏ��̈ʒu�܂ŃV�t�g�����B
 */
BOOL
ImeConfig_bSkkCompositionAutoShiftp (void)
{
	return	_bCompositionAutoShift ;
}

const struct CImeKeymap*
ImeConfig_pGetMajorModeMap (void) 
{
	return	&_sMajorModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkJModeMap (void)
{
	return	&_sSkkJModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkLatinModeMap (void)
{
	return	&_sSkkLatinModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkJisx0208LatinModeMap (void)
{
	return	&_sSkkJisx0208LatinModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetSkkAbbrevModeMap (void)
{
	return	&_sSkkAbbrevModeMap ;
}

const struct CImeKeymap*
ImeConfig_pGetMinibufferMinorModeMap (void)
{
	return	&_sMinibufferMinorModeMap ;
}

const MYCOLORFACESET*
ImeConfig_pGetColorFaceSet (void)
{
	return	_srImeColorFaces ;
}

int
ImeConfig_iGetCountHenkanShowChange (void) 
{
	return	_snShowCandListCount ;
}

void
ImeConfig_vGetDefaultFont (LOGFONT* plf, HDC hDC)
{
	if (plf == NULL)
		return ;

	memcpy (plf, &_slfDefaultFont, sizeof (LOGFONT)) ;
	if (_siDefaultFontSize >= 0) {
		plf->lfWidth	= 0 ;
		plf->lfHeight	= -MulDiv (_siDefaultFontSize, GetDeviceCaps (hDC, LOGPIXELSY), 72) ;
	}
	return ;
}

/*========================================================================
 *	private functions (for ZenkakuVector)
 */
BOOL
imeConfig_bLoadZenkakuVector (void)
{
	HKEY	hSubKey ;
	int		i, nLength ;
	BOOL	bInitialized	= FALSE ;

	imeConfig_vClearZenkakuVector () ;

	/*	���W�X�g���ɃL�[�����݂��Ȃ���΁A�f�t�H���g��ݒ肷��B
	 */
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 	lResult ;
		DWORD	dwType, cbData ;
		LPWSTR	pwData ;
		LPCWSTR	pwSrc ;

		lResult	= RegQueryValueExW (hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) 
			goto	skip_error ;
		if (dwType != REG_MULTI_SZ) 
			goto	skip_error ;

		pwData	= (LPWSTR) MALLOC (cbData) ;
		if (pwData == NULL)
			goto	skip_error ;

		(void) RegQueryValueExW (hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, (BYTE*)pwData, &cbData) ;

		pwSrc	= pwData ;
		while (*pwSrc != L'\0') {
			LPCWSTR	pwBase ;
			int		nChara, nCH, nNeed ;

			/*	�ŏ���3�������L�����N�^�[�R�[�h���A
			 *	���������񂪂��̃R�[�h�œ��͂���镶����A
			 */
			nCH		= *pwSrc ++ ;
			if (nCH < L'0' || nCH > L'9')
				goto	skip_error ;
			nChara	= nCH - TEXT ('0') ;

			nCH		= *pwSrc ++ ;
			if (nCH < L'0' || nCH > L'9')
				goto	skip_error ;
			nChara	= nChara * 10 + (nCH - L'0') ;

			nCH		= *pwSrc ++ ;
			if (nCH < L'0' || nCH > L'9')
				goto	skip_error ;
			nChara	= nChara * 10 + (nCH - L'0') ;
			if (nChara < 0 || nChara >= ARRAYSIZE (_rstrJisx0208LatinVector))
				goto	skip_error ;

			pwBase	= pwSrc ;
			while (*pwSrc != L'\0')
				pwSrc	++ ;

			if (_rstrJisx0208LatinVector [nChara] != NULL) {
				FREE (_rstrJisx0208LatinVector [nChara]) ;
			}
			nNeed	= wcstodcs_n (NULL, 0, pwBase, pwSrc - pwBase) ;
			if (nNeed > 0) {
				LPDSTR	pDest ;
				pDest	= (LPDSTR) MALLOC ((nNeed + 1) * sizeof (DCHAR)) ;
				if (pDest == NULL)
					break ;
				(void) wcstodcs_n (pDest, nNeed, pwBase, pwSrc - pwBase) ;
				pDest [nNeed]	= L'\0' ;
				_rstrJisx0208LatinVector [nChara]	= pDest ;
			} else {
				_rstrJisx0208LatinVector [nChara]	= NULL ;
			}
			pwSrc	++ ;
		}
		bInitialized	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	if (! bInitialized) {
		for (i = 0 ; i < ARRAYSIZE (_rstrJisx0208LatinVector) ; i ++) {
			LPCWSTR	pSrc	= _rstrDefaultJisx0208LatinVector [i] ;

			if (pSrc != NULL) {
				LPDSTR	pDest ;

				nLength	= lstrlenW (pSrc) ;
				pDest	= (LPDSTR) MALLOC (sizeof (DCHAR) * (nLength + 1)) ;
				if (pDest != NULL) {
					int	n	= wcstodcs (pDest, nLength, pSrc, nLength) ;
					pDest [n]	= L'\0' ;
				}
				_rstrJisx0208LatinVector [i]	= pDest ;
			} else {
				_rstrJisx0208LatinVector [i]	= NULL ;
			}
		}
	}
	return	TRUE ;
}

void
imeConfig_vClearZenkakuVector (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rstrJisx0208LatinVector) ; i ++) {
		if (_rstrJisx0208LatinVector [i] != NULL) {
			FREE (_rstrJisx0208LatinVector [i]) ;
			_rstrJisx0208LatinVector [i]	= NULL ;
		}
	}
	return ;
}

/*========================================================================
 *	private functions (for Keybind)
 */
static	void	imeConfig_vInitializeMajorModeMap			(void) ;
static	void	imeConfig_vInitializeSkkJModeMap			(void) ;
static	void	imeConfig_vInitializeSkkLatinModeMap		(void) ;
static	void	imeConfig_vInitializeSkkJisx0208LatinModeMap(void) ;
static	void	imeConfig_vInitializeSkkAbbrevModeMap		(void) ;
static	void	imeConfig_vInitializeMinibufferMinorModeMap (void) ;

BOOL
imeConfig_bLoadKeymap (void)
{
	static	LPCTSTR	srKeymapRegistryNames []	= {
		REGINFO_MAJORMODEMAP,
		REGINFO_JMODEMAP,
		REGINFO_LATINMODEMAP,
		REGINFO_ZENKAKUMODEMAP,	/* jisx0208-latin-mode-map */
		REGINFO_ABBREVMODEMAP,
	} ;
	static	struct CImeKeymap*	rpKeymaps []	= {
		&_sMajorModeMap,
		&_sSkkJModeMap,
		&_sSkkLatinModeMap,
		&_sSkkJisx0208LatinModeMap,
		&_sSkkAbbrevModeMap,
	} ;
	/*	����L�[�̈����BControl + F1 �Ƃ��B(VKEYCODE, MODIFIER, FUNCTION) �̃y�A��
	 *	�Ȃ�B
	 */
	static	LPCTSTR	srKeymapExtraRegisterNames []	= {
		REGINFO_MAJORMODEMAP_EX,
		REGINFO_JMODEMAP_EX,
		REGINFO_LATINMODEMAP_EX,
		REGINFO_ZENKAKUMODEMAP_EX,	/* jisx0208-latin-mode-map */
		REGINFO_ABBREVMODEMAP_EX,
	} ;
	HKEY	hSubKey ;
	int		i ;
	BOOL	bRetval	= FALSE ;
	BOOL	bExistUserDefinedKeymap					= FALSE ;
	BOOL	bExistUserDefinedStartHenkanKey			= FALSE ;
	BOOL	bExistUserDefinedCompletionKey			= FALSE ;
	BOOL	bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
	BOOL	bExistUserDefinedSpecialMidashiCharKey	= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		struct CImeKeymap*	pKeymap ;
		LONG 	lResult ;
		DWORD	dwType, cbData, dwValue ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_KEYMAP_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siKeybindType	= (int) dwValue ;

		for (i = 0 ; i < ARRAYSIZE (srKeymapRegistryNames) ; i ++) {
			lResult	= RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS) 
				break ;
			if (dwType != REG_BINARY || cbData != MAX_KEYBINDS) 
				goto	skip_error ;

			pKeymap	= rpKeymaps [i] ;
			(void) RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, (BYTE*)pKeymap->m_rbyBaseMap, &cbData) ;

			pKeymap->m_nKeyBinds	= 0 ;
			pKeymap->m_pKeyBinds	= NULL ;
		}
		if (i >= ARRAYSIZE (srKeymapRegistryNames))
			bExistUserDefinedKeymap	= TRUE ;

		if (bExistUserDefinedKeymap) {
			BYTE	rbBuffer [512] ;
			BYTE*	pbBuffer	= NULL ;
			DWORD	iBufSize ;

			pbBuffer	= rbBuffer ;
			iBufSize	= sizeof (rbBuffer) ;
			for (i = 0 ; i < ARRAYSIZE (srKeymapExtraRegisterNames) ; i ++) {
				int				iNumKeyBinds, j ;
				const BYTE*		pbData ;
				struct CImeKeyBind*	pKeyBind ;

				/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
				lResult	= RegQueryValueEx (hSubKey, srKeymapExtraRegisterNames [i], NULL, &dwType, NULL, &cbData) ;
				if (lResult != ERROR_SUCCESS || dwType != REG_BINARY)
					continue ;
				if (cbData > iBufSize) {
					if (pbBuffer != rbBuffer) {
						FREE (pbBuffer) ;
					}
					pbBuffer	= MALLOC (cbData) ;
					if (pbBuffer == NULL) {
						/* error */
						break ;
					}
					iBufSize	= cbData ;
				}
				(void) RegQueryValueEx (hSubKey, srKeymapExtraRegisterNames [i], NULL, &dwType, pbBuffer, &cbData) ;

				/*
				 */
				iNumKeyBinds	= cbData / (4 + 2 + 2) ;	/* VKEY(4), MODIFIER(2), FUNCNO(2) */
				if (iNumKeyBinds <= 0)
					continue ;

				rpKeymaps [i]->m_pKeyBinds	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * iNumKeyBinds) ;
				if (rpKeymaps [i]->m_pKeyBinds == NULL) {
					/* error */
					break ;
				}
				rpKeymaps [i]->m_nKeyBinds	= iNumKeyBinds ;

				pbData		= pbBuffer ;
				pKeyBind	= rpKeymaps [i]->m_pKeyBinds ;
				for (j = 0 ; j < iNumKeyBinds ; j ++) {
					unsigned int	uVKey, uModifier ;
					int				iFuncNo ;

					uVKey		= (unsigned int) *pbData ++ ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ <<  8) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 16) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 24) ;
					uModifier	= (unsigned int) *pbData ++ ;
					uModifier	= uModifier | ((unsigned int) *pbData ++ << 8) ;
					iFuncNo		= (unsigned int) *pbData ++ ;
					iFuncNo		= iFuncNo | ((unsigned int) *pbData ++) ;
					if (iFuncNo < 0 || iFuncNo >= NFUNC_INVALID_CHAR) 
						continue ;	/* skip */
					pKeyBind->m_nKeyCode		= uVKey ;
					pKeyBind->m_uKeyMask		= uModifier ;
					pKeyBind->m_nKeyFunction	= iFuncNo ;
					pKeyBind	++ ;
				}
				/* realloc �������Ƃ��낾���ǁc */
				rpKeymaps [i]->m_nKeyBinds	= pKeyBind - rpKeymaps [i]->m_pKeyBinds ;
			}
			if (pbBuffer != rbBuffer && pbBuffer != NULL) {
				FREE (pbBuffer) ;
				pbBuffer	= NULL ;
			}
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siStartHenkanKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbyStartHenkanKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY, NULL, &dwType, (BYTE*)_srbyStartHenkanKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedStartHenkanKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumStartHenkanKeys			= (int) cbData ;
			bExistUserDefinedStartHenkanKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siCompletionRelatedKeyType	= (int) dwValue ;
		if (RegQueryValueEx (hSubKey, REGINFO_TRYCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyTryCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumTryCompletionKeys			= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyPreviousCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumPreviousCompletionKeys	= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_NEXTCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyNextCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumNextCompletionKeys		= (int) cbData ;
			bExistUserDefinedCompletionKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siSetHenkanPointSubrKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySetHenkanPointSubrKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, NULL, &dwType, (BYTE*)_srbySetHenkanPointSubrKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSetHenkanPointSubrKeys			= (int) cbData ;
			bExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siSpecialMidashiCharKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySpecialMidashiCharKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR, NULL, &dwType, (BYTE*)_srbySpecialMidashiCharKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			bExistUserDefinedSpecialMidashiCharKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSpecialMidashiCharKeys			= (int) cbData ;
			bExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_EGGLIKENEWLINE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_bEggLikeNewline	= (dwValue != 0) ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_NEWLINEKAKUTEIALL, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_bNewlineKakuteiAll	= (dwValue != 0) ;
		}
		bRetval	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}

	/* �f�[�^���ςłȂ����A�X�̗v�f���`�F�b�N����B*/
	if (bRetval) {
		for (i = 0 ; i < ARRAYSIZE (rpKeymaps) ; i ++) {
			struct CImeKeymap*	pKeymap ;
			int		j ;

			pKeymap	= rpKeymaps [i] ;
			for (j = 0 ; j < MAX_KEYBINDS ; j ++) {
				if (pKeymap->m_rbyBaseMap [j] < 0 || pKeymap->m_rbyBaseMap [j] >= NUM_SELECTABLE_FUNCTIONS) {
					pKeymap->m_rbyBaseMap [j]	= NFUNC_INVALID_CHAR ;
				}
			}
		}
		if (_siKeybindType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedKeymap)
			_siKeybindType	= KEYBINDTP_DEFAULT ;
		if (_siStartHenkanKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedStartHenkanKey)
			_siStartHenkanKeyType	= KEYBINDTP_DEFAULT ;
		if (_siCompletionRelatedKeyType == KEYBINDTP_USERDEFINED && ! bExistUserDefinedCompletionKey)
			_siCompletionRelatedKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSetHenkanPointSubrKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSetHenkanPointSubrKey) 
			_siSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSpecialMidashiCharKeyType == KEYBINDTP_USERDEFINED && !bExistUserDefinedSpecialMidashiCharKey) 
			_siSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;
	} else {
		/* ���[�h�Ɏ��s�����̂ŁA�f�t�H���g�̐ݒ�ɂ���B*/
		_siKeybindType					= KEYBINDTP_DEFAULT ;
		_siStartHenkanKeyType			= KEYBINDTP_DEFAULT ;
		_siCompletionRelatedKeyType		= KEYBINDTP_DEFAULT ;
		_siSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		_siSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;

		_bEggLikeNewline				= FALSE ;
		_bNewlineKakuteiAll				= TRUE ;
	}
	/*	�L�[�}�b�v�̏������B*/
	if (_siKeybindType == KEYBINDTP_DEFAULT) {
		imeConfig_vInitializeMajorModeMap () ;
		imeConfig_vInitializeSkkJModeMap () ;
		imeConfig_vInitializeSkkLatinModeMap () ;
		imeConfig_vInitializeSkkJisx0208LatinModeMap () ;
		imeConfig_vInitializeSkkAbbrevModeMap () ;	
	}
	imeConfig_vInitializeMinibufferMinorModeMap () ;
	return	TRUE ;
}

void
imeConfig_vInitializeMajorModeMap (void)
{
	static BYTE		_srbDefaultMajorModeMap []	= {
		NFUNC_SET_MARK_COMMAND,				/* C-@ */
		NFUNC_BEGINNING_OF_LINE,			/* C-a */
		NFUNC_BACKWARD_CHAR,				/* C-b */
		NFUNC_INVALID_CHAR,					//NFUNC_MODE_SPECIFIC_COMMAND_PREFIX,	/* C-c */
		NFUNC_DELETE_CHAR,					/* C-d */
		NFUNC_END_OF_LINE,					/* C-e */
		NFUNC_FORWARD_CHAR,					/* C-f */
		NFUNC_KEYBOARD_QUIT,				/* C-g */
		NFUNC_BACKWARD_DELETE_CHAR,			/* C-h */
		NFUNC_INVALID_CHAR,					//NFUNC_INDENT_FOR_TAB_COMMAND,			/* C-i */
		NFUNC_NEWLINE,						//NFUNC_NEWLINE_AND_INDENT,				/* C-j */
		NFUNC_KILL_LINE,					/* C-k */
		NFUNC_INVALID_CHAR,					//NFUNC_RECENTER,						/* C-l */
		NFUNC_NEWLINE,						/* C-m */
		NFUNC_INVALID_CHAR,					//NFUNC_NEXT_LINE,						/* C-n */
		NFUNC_INVALID_CHAR,					//NFUNC_OPEN_LINE,						/* C-o */
		NFUNC_INVALID_CHAR,					//NFUNC_PREVIOUS_LINE,					/* C-p */	
		NFUNC_INVALID_CHAR,					//NFUNC_QUATED_INSERT,					/* C-q */
		NFUNC_INVALID_CHAR,					//NFUNC_ISEARCH_BACKWARD,				/* C-r */
		NFUNC_INVALID_CHAR,					//NFUNC_ISEARCH_FORWARD,				/* C-s */
		NFUNC_TRANSPOSE_CHARS,				/* C-t */
		NFUNC_INVALID_CHAR,					//FUNC_UNIVERSAL_ARGUMENT,				/* C-u */
		NFUNC_INVALID_CHAR,					//NFUNC_SCROLL_UP,						/* C-v */
		NFUNC_KILL_REGION,					/* C-w */
		NFUNC_INVALID_CHAR,					//NFUNC_CONTROL_X_PREFIX,				/* C-x */
		NFUNC_YANK,							/* C-y */
		NFUNC_INVALID_CHAR,					//NFUNC_SCROLL_DOWN,					/* C-z */
		NFUNC_INVALID_CHAR,					//NFUNC_PREFIX_COMMAND,					/* C-[ */
		NFUNC_TOGGLE_IME,					/* C-\\ */
		NFUNC_ABORT_RECURSIVE_EDIT,			/* C-] */
		NFUNC_INVALID_CHAR,					//NFUNC_UNDO,							/* C-_ */
	} ;
	int	i ;
	struct CImeKeyBind*	pKeyBinds ;

	for (i = 0 ; i < ARRAYSIZE (_sMajorModeMap.m_rbyBaseMap) ; i ++) 
		_sMajorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	for (i = 0 ; i < ARRAYSIZE (_srbDefaultMajorModeMap) ; i ++) 
		_sMajorModeMap.m_rbyBaseMap [i]	= _srbDefaultMajorModeMap [i] ;
	for (i = 32 ; i < 127 ; i ++) 
		_sMajorModeMap.m_rbyBaseMap [i]	= NFUNC_SELF_INSERT_CHARACTER ;

	_sMajorModeMap.m_pKeyBinds	= NULL ;
	_sMajorModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
imeConfig_vInitializeSkkJModeMap (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_sSkkJModeMap.m_rbyBaseMap) ; i ++) {
		_sSkkJModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 32 ; i < 127 ; i ++) {
		_sSkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_INSERT ;
	}
	_sSkkJModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	_sSkkJModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_KATAKANA ;

	/*	previous-candidate-char ���ɂ���ׂ����Akeybind ���� previous-candidate-char ��
	 *	���߂�悤�ɂ���ׂ����B�ǂ��炪�������̂��B��҂��I������Ȃ��������R�́A�ǂ�
	 *	minor-mode-map �𗘗p����Ηǂ��̂�������Ȃ��������炩�H
	 */
	_sSkkJModeMap.m_rbyBaseMap ['x']	= NFUNC_SKK_PREVIOUS_CANDIDATE ;

	for (i = 0 ; i < ARRAYSIZE (_sMajorModeMap.m_rbyBaseMap) ; i ++) {
		if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			_sSkkJModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	/*	try-completion-char �� skk-insert �ɂ��킹��B
	 *	try-completion-char �� keybind ����ɂ��邩�c�B���[��A�ł� try-completion �̓���
	 *	�� skk-insert �Ɠ����ɂ��Ă����� (function code �͈Ⴄ���ǁA����͓�����)�A
	 *	keybind �� try-completion �Ȃ� try-completion-charp �� t ��Ԃ��Ƃ����̂́H
	 *
	 *	�����Aabbrev-map �͑f���� try-completion �Ȃ̂ɁA������� skk-insert �o�R�Ƃ����̂�
	 *	�C�ɂȂ�c�B����������闝�R���l�������� try-completion ������̂͊댯���B
	 */
	_sSkkJModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_INSERT ;
	_sSkkJModeMap.m_pKeyBinds	= NULL ;
	_sSkkJModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
imeConfig_vInitializeSkkLatinModeMap (void)
{
	int		i ;
	for (i = 0 ; i < ARRAYSIZE (_sSkkLatinModeMap.m_rbyBaseMap) ; i ++)
		_sSkkLatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkLatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;

	_sSkkLatinModeMap.m_pKeyBinds	= NULL ;
	_sSkkLatinModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
imeConfig_vInitializeSkkJisx0208LatinModeMap (void)
{
	int		i ;
	for (i = 0 ; i < ARRAYSIZE (_sSkkJisx0208LatinModeMap.m_rbyBaseMap) ; i ++)
		_sSkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	for (i = 0 ; i < 128 ; i ++) {
		/*	LatinVector �̏���������ɍs���Ă��Ȃ���΂Ȃ�Ȃ��B*/
		if (_rstrJisx0208LatinVector [i] != NULL) 
			_sSkkJisx0208LatinModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_JISX0208_LATIN_INSERT ;
	}
	_sSkkJisx0208LatinModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_LATIN_HENKAN ;	/* \C-q */

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkJisx0208LatinModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-backward-and-set-henkan-point-char �́c 2stroke key �͎������ĂȂ�����c�B*/

	_sSkkJisx0208LatinModeMap.m_pKeyBinds	= NULL ;
	_sSkkJisx0208LatinModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
imeConfig_vInitializeSkkAbbrevModeMap (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_sSkkAbbrevModeMap.m_rbyBaseMap) ; i ++)
		_sSkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	_sSkkAbbrevModeMap.m_rbyBaseMap ['.']	= NFUNC_SKK_ABBREV_PERIOD ;
	_sSkkAbbrevModeMap.m_rbyBaseMap [',']	= NFUNC_SKK_ABBREV_COMMA ;
	_sSkkAbbrevModeMap.m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_CHARACTERS ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkAbbrevModeMap.m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-start-henkan-char �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	_sSkkAbbrevModeMap.m_rbyBaseMap [' ']	= NFUNC_SKK_START_HENKAN ;

	for (i = 0 ; i < ARRAYSIZE (_sMajorModeMap.m_rbyBaseMap) ; i ++) {
		if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			_sSkkAbbrevModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	_sSkkAbbrevModeMap.m_rbyBaseMap ['\t']	= NFUNC_SKK_TRY_COMPLETION ;

	_sSkkAbbrevModeMap.m_pKeyBinds	= NULL ;
	_sSkkAbbrevModeMap.m_nKeyBinds	= 0 ;
	return ;
}

void
imeConfig_vInitializeMinibufferMinorModeMap (void)
{
	struct CImeKeyBind*	pKeyBind ;
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_sMinibufferMinorModeMap.m_rbyBaseMap) ; i ++)
		_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	_sMinibufferMinorModeMap.m_pKeyBinds	= NULL ;
	_sMinibufferMinorModeMap.m_nKeyBinds	= 0 ;

	/*	MajorModeMap, JModeMap �����āAKey ��ݒ肷��B
	 */
	for (i = 0 ; i < ARRAYSIZE (_sMajorModeMap.m_rbyBaseMap) ; i ++) {
		if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_KEYBOARD_QUIT) 
			_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_ABORT_RECURSIVE_EDIT ;
		if (_sMajorModeMap.m_rbyBaseMap [i] == NFUNC_NEWLINE)
			_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_EXIT_RECURSIVE_EDIT ;
	}
	if (_sMajorModeMap.m_nKeyBinds > 0) {
		pKeyBind	= _sMajorModeMap.m_pKeyBinds ;
		for (i = 0 ; i < _sMajorModeMap.m_nKeyBinds ; i ++) {
			if (pKeyBind->m_nKeyFunction == NFUNC_KEYBOARD_QUIT) {
				imeConfig_bDefineKey (&_sMinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, NFUNC_ABORT_RECURSIVE_EDIT) ;
			} else if (pKeyBind->m_nKeyFunction == NFUNC_NEWLINE) {
				imeConfig_bDefineKey (&_sMinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, NFUNC_EXIT_RECURSIVE_EDIT) ;
			}
			pKeyBind	++ ;
		}
	}
	for (i = 0 ; i < ARRAYSIZE (_sSkkJModeMap.m_rbyBaseMap) ; i ++) {
		if (_sSkkJModeMap.m_rbyBaseMap [i] == NFUNC_SKK_KAKUTEI) {
			_sMinibufferMinorModeMap.m_rbyBaseMap [i]	= NFUNC_SKK_KAKUTEI ;
		}
	}
	if (_sSkkJModeMap.m_nKeyBinds > 0) {
		pKeyBind	= _sSkkJModeMap.m_pKeyBinds ;
		for (i = 0 ; i < _sSkkJModeMap.m_nKeyBinds ; i ++) {
			if (pKeyBind->m_nKeyFunction == NFUNC_SKK_KAKUTEI) 
				imeConfig_bDefineKey (&_sMinibufferMinorModeMap, pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask, NFUNC_SKK_KAKUTEI) ;
			pKeyBind	++ ;
		}
	}
	return ;
}

BOOL
imeConfig_bDefineKey (
	struct CImeKeymap*		pKeymap,
	int						nKeyCode,
	unsigned int			uKeyMask,
	int						nKeyFunction)
{
	struct CImeKeyBind*	pKeyBind ;
	struct CImeKeyBind*	pNewBind ;
	int	i ;

	if (pKeymap == NULL)
		return	FALSE ;

	pKeyBind	= pKeymap->m_pKeyBinds ;
	for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
		if (pKeyBind->m_nKeyCode == nKeyCode && pKeyBind->m_uKeyMask == uKeyMask) {
			pKeyBind->m_nKeyFunction	= nKeyFunction ;
			return	TRUE ;
		}
		pKeyBind	++ ;
	}

	/* Not Found */
	pNewBind	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * (pKeymap->m_nKeyBinds + 1)) ;
	if (pNewBind == NULL)
		return	FALSE ;
	if (pKeymap->m_nKeyBinds > 0)
		memcpy (pNewBind, pKeymap->m_pKeyBinds, sizeof (struct CImeKeyBind) * pKeymap->m_nKeyBinds) ;
	if (pKeymap->m_pKeyBinds != NULL)
		FREE (pKeymap->m_pKeyBinds) ;
	pKeymap->m_pKeyBinds	= pNewBind ;
	pNewBind [pKeymap->m_nKeyBinds].m_nKeyCode	= nKeyCode ;
	pNewBind [pKeymap->m_nKeyBinds].m_uKeyMask	= uKeyMask ;
	pNewBind [pKeymap->m_nKeyBinds].m_nKeyFunction	= nKeyFunction ;
	pKeymap->m_nKeyBinds	++ ;
	return	TRUE ;
}

/*========================================================================
 *	private functions (for Keybind/���[�}�����ȃ��[��)
 */
static	BOOL	imeConfig_bLoadRomaKanaRuleListFromRegistry (void) ;
static	BOOL	imeConfig_bParseRomaKanaRuleLists (HKEY, LPCTSTR*, int, int, struct CSkkRuleTreeNode**, int, BOOL*) ;
static	BOOL	imeConfig_bParseRomaKanaRuleList (LPCTSTR, DWORD, int, int, struct CSkkRuleTreeNode**) ;

BOOL
imeConfig_bLoadRomaKanaRuleList (void)
{
	BOOL	bRetval ;
	int		i ;

	_pOhOutput		= NULL ;
	for (i = 0 ; i < ARRAYSIZE (_rpSkkRuleTree) ; i ++) {
		_rpSkkRuleTree				[i]	= NULL ;
		_rpSkkJisx0201RomanRuleTree	[i]	= NULL ;
		_rpSkkJisx0201RuleTree		[i]	= NULL ;
	}

	bRetval	= imeConfig_bLoadRomaKanaRuleListFromRegistry () ;
	if (! bRetval || _siRomaKanaRuleListType == KEYBINDTP_DEFAULT) {
		_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
		TSkkRuleTree_bInitializeDefault (_rpSkkRuleTree, ARRAYSIZE (_rpSkkRuleTree)) ;
		TSkkRuleTree_bInitializeJisx0201Default (_rpSkkJisx0201RuleTree, ARRAYSIZE (_rpSkkJisx0201RuleTree)) ;
		TSkkRuleTree_bInitializeJisx0201RomanDefault (_rpSkkJisx0201RomanRuleTree, ARRAYSIZE (_rpSkkJisx0201RomanRuleTree)) ;
	}
	return	TRUE ;
}

void
imeConfig_vClearRomaKanaRuleList (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rpSkkRuleTree) ; i ++) {
		TSkkRuleTreeNode_vDestroyTree (_rpSkkRuleTree [i]) ;
		TSkkRuleTreeNode_vDestroyTree (_rpSkkJisx0201RomanRuleTree [i]) ;
		TSkkRuleTreeNode_vDestroyTree (_rpSkkJisx0201RuleTree [i]) ;
		_rpSkkRuleTree				[i]	= NULL ;
		_rpSkkJisx0201RomanRuleTree	[i]	= NULL ;
		_rpSkkJisx0201RuleTree		[i]	= NULL ;
	}
	return ;
}

BOOL
imeConfig_bLoadRomaKanaRuleListFromRegistry (void)
{
	HKEY	hSubKey ;
	BOOL	bExistUserDefinedRomaKanaRule	= FALSE ;
	BOOL	bRetval	= TRUE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_ROMAKANARULE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 	lResult ;
		DWORD	dwType, cbData, dwValue ;

		/* rule-list-type (default or custom) */
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_ROMAKANARULE_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) {
			bRetval	= FALSE ;
			goto	skip_error ;
		}
		_siRomaKanaRuleListType	= (int) dwValue ;

		if (_siRomaKanaRuleListType != KEYBINDTP_DEFAULT) {
			static	LPCTSTR	srRomaKanaRuleTbl []	= {
				REGINFO_ROMAKANARULE,		REGINFO_ROMAKANARULE1,
				REGINFO_ROMAKANARULE2,		REGINFO_ROMAKANARULE3,
			} ;
			static	LPCTSTR	srJisx0201RomanRuleTbl []	= {
				REGINFO_JISX0201ROMANRULE,		REGINFO_JISX0201ROMANRULE1,
				REGINFO_JISX0201ROMANRULE2,		REGINFO_JISX0201ROMANRULE3,
			} ;
			static	LPCTSTR	srJisx0201RuleTbl []	= {
				REGINFO_JISX0201RULE,		REGINFO_JISX0201RULE1,
				REGINFO_JISX0201RULE2,		REGINFO_JISX0201RULE3,
			} ;
			BOOL	bExist1, bExist2, bExist3 ;

			bExist1 = bExist2 = bExist3 = FALSE ;
			if (! imeConfig_bParseRomaKanaRuleLists (hSubKey, srRomaKanaRuleTbl,		ARRAYSIZE (srRomaKanaRuleTbl),		RULETREENO_SKK_BASE,			_rpSkkRuleTree,					ARRAYSIZE (_rpSkkRuleTree), &bExist1) ||
				! imeConfig_bParseRomaKanaRuleLists (hSubKey, srJisx0201RomanRuleTbl,	ARRAYSIZE (srJisx0201RomanRuleTbl),	RULETREENO_SKK_JISX0201_ROMAN,	_rpSkkJisx0201RomanRuleTree,	ARRAYSIZE (_rpSkkJisx0201RomanRuleTree), &bExist2) ||
				! imeConfig_bParseRomaKanaRuleLists (hSubKey, srJisx0201RuleTbl,		ARRAYSIZE (srJisx0201RuleTbl),		RULETREENO_SKK_JISX0201_BASE,	_rpSkkJisx0201RuleTree,			ARRAYSIZE (_rpSkkJisx0201RuleTree), &bExist3))
				bRetval	= FALSE ;
			bExistUserDefinedRomaKanaRule	= bExist1 || bExist2 || bExist3 ;
		}
skip_error:
		RegCloseKey (hSubKey) ;
	}
	if (! bExistUserDefinedRomaKanaRule)
		_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;

	if (! bRetval)
		goto	error_exit ;
	return	TRUE ;

error_exit:
	return	FALSE ;
}

BOOL
imeConfig_bParseRomaKanaRuleLists (
	HKEY						hSubKey,
	LPCTSTR*					ppRomaKanaRuleTbl,
	int							iRomaKanaRuleTblSize,
	int							iRuleBaseOffset,
	struct CSkkRuleTreeNode**	ppRoot,
	int							iRuleSize,
	BOOL*						pbExist)
{
	LPTSTR	pwData	= NULL ;
	LONG 	lResult ;
	DWORD	dwType, cbData ;
	BOOL	bExistUserDefinedRomaKanaRule ;
	int		i ;
	BOOL	bRetval ;

	bExistUserDefinedRomaKanaRule	= FALSE ;
	bRetval	= TRUE ;
	for (i = 0 ; i < MIN (iRuleSize, iRomaKanaRuleTblSize) ; i ++) {
		/* roma-kana-rule �{�́B*/
		lResult	= RegQueryValueEx (hSubKey, ppRomaKanaRuleTbl [i], NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) 
			continue ;
		if (dwType != REG_MULTI_SZ) {
			bRetval	= FALSE ;
			continue ;
		}
		pwData	= (LPTSTR) MALLOC (cbData) ;
		if (pwData == NULL)
			continue ;
		(void) RegQueryValueEx (hSubKey, ppRomaKanaRuleTbl [i], NULL, &dwType, (BYTE*)pwData, &cbData) ;

		if (imeConfig_bParseRomaKanaRuleList (pwData, cbData, iRuleBaseOffset, i, &ppRoot [i])) {
			bExistUserDefinedRomaKanaRule	= TRUE ;
		} else {
			ppRoot [i]	= NULL ;
		}
		FREE (pwData) ;
	}
	for ( ; i < iRuleSize ; i ++) 
		ppRoot [i]	= NULL ;

	if (pbExist)
		*pbExist	= bExistUserDefinedRomaKanaRule ;
	return	bRetval ;
}

BOOL
imeConfig_bParseRomaKanaRuleList (
	LPCTSTR						pwData,
	DWORD						cbData,
	int							iRuleBaseOffset,
	int							iRule,
	struct CSkkRuleTreeNode**	ppRoot)
{
	LPCTSTR	pwSrc, pwSrcEnd ;
	TCHAR	bufState [128], bufNext [128], bufHira [128], bufKata [128] ;
	DCHAR	bufDState [128] ;
	TCHAR	bufNextRule [32] ;
	struct CSkkRuleTreeNode*	pRoot	= NULL ;

	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	while (*pwSrc != TEXT ('\0') && pwSrc < pwSrcEnd) {
		int			nType, nStateLen ;
		BOOL		bTerminated ;
		LPCWSTR		pwNext ;
		int			nNextRule ;

		nType	= *pwSrc ++ ;
		if (! imeConfig_bParseBSEncodedString (&pwSrc, bufState, ARRAYSIZE (bufState) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! imeConfig_bParseBSEncodedString (&pwSrc, bufNext,  ARRAYSIZE (bufNext)  - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! imeConfig_bParseBSEncodedString (&pwSrc, bufNextRule, ARRAYSIZE (bufNextRule) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;

		bufState	[ARRAYSIZE (bufState)		- 1]	= TEXT ('\0') ;
		nStateLen	= wcstodcs_n (bufDState, ARRAYSIZE (bufDState), bufState, lstrlen (bufState)) ;

		bufNext		[ARRAYSIZE (bufNext)		- 1]	= TEXT ('\0') ;
		bufNextRule	[ARRAYSIZE (bufNextRule)	- 1]	= TEXT ('\0') ;
		pwNext	= (bufNext [0] != TEXT ('\0'))? bufNext : NULL ;
#if TARGET_WIN2K
		if (_stscanf (bufNextRule, TEXT ("%d"), &nNextRule) != 1)
			nNextRule	= 0 ;
#else
		if (_sntscanf (bufNextRule, ARRAYSIZE (bufNextRule) - 1, TEXT ("%d"), &nNextRule) != 1)
			nNextRule	= 0 ;
#endif
		switch (nType) {
		case	TEXT ('1'):
			if (! imeConfig_bParseBSEncodedString (&pwSrc, bufHira, ARRAYSIZE (bufHira) - 1, &bTerminated) || bTerminated)
				goto	next_entry ;
			if (! imeConfig_bParseBSEncodedString (&pwSrc, bufKata, ARRAYSIZE (bufKata) - 1, &bTerminated) || ! bTerminated)
				goto	next_entry ;

			bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;
			bufKata [ARRAYSIZE (bufKata)  - 1]	= TEXT ('\0') ;
			if (! TSkkRuleTreeNode_bAddRuleSP (&pRoot, iRuleBaseOffset + iRule, bufDState, nStateLen, pwNext, lstrlen (bufNext), iRuleBaseOffset + nNextRule, bufHira, lstrlen (bufHira), bufKata, lstrlen (bufKata))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('2'):
			if (! imeConfig_bParseBSEncodedString (&pwSrc, bufHira, ARRAYSIZE (bufHira) - 1, &bTerminated) || ! bTerminated)
				goto	next_entry ;
			bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;
			if (! TSkkRuleTreeNode_bAddRuleS (&pRoot, iRuleBaseOffset + iRule, bufDState, nStateLen, pwNext, lstrlen (bufNext), iRuleBaseOffset + nNextRule, bufHira, lstrlen (bufHira))) {
				goto	error_exit ;
			}
			break ;
		case	TEXT ('3'):
			{
				LPCTSTR	pwTemp ;
				int		nFuncNo	= 0 ;

				if (! imeConfig_bParseBSEncodedString (&pwSrc, bufHira, ARRAYSIZE (bufHira) - 1, &bTerminated) || ! bTerminated)
					goto	next_entry ;
				bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;

				pwTemp	= bufHira ;
				while (*pwTemp != TEXT ('\0')) {
					int		nCH	; 
					nCH	= *pwTemp ++ ;
					if (TEXT ('0') <= nCH && nCH <= TEXT ('9')) {
						nFuncNo	= nFuncNo * 10 + (nCH - TEXT ('0')) ;
					} else {
						goto	error_exit ;
					}
				}
				if (! TSkkRuleTreeNode_bAddRuleM (&pRoot, iRuleBaseOffset + iRule, bufDState, nStateLen, pwNext, lstrlen (bufNext), iRuleBaseOffset + nNextRule, nFuncNo)) {
					goto	error_exit ;
				}
			}
			break ;
		default:
			break ;
		}
next_entry:
		/* parse �Ɏ��s�����G���g���̏ꍇ nul �ɓ��B���Ă��Ȃ��̂ŁAnul �܂Ői�߂�B*/
		while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
			pwSrc ++ ;
		pwSrc	++ ;	/* nul �� skip */
	}
	if (ppRoot != NULL)
		*ppRoot	= pRoot ;
	return	TRUE ;
error_exit:
	TSkkRuleTreeNode_vDestroyTree (pRoot) ;
	return	FALSE ;
}

/*========================================================================
 *	private functions (for Keybind)
 */
static	BOOL	imeConfig_bLoadGenericSettingFromRegistry (void) ;

BOOL
imeConfig_bLoadGenericSetting (void)
{
	static const struct {
		LPCTSTR		m_strLeft ;
		LPCTSTR		m_strRight ;
	}	_srDefaultBracketParens []	= {
		{ TEXT("�u"),	TEXT("�v") },	{ TEXT("�w"),	TEXT("�x") },
		{ TEXT("("),	TEXT(")")  },	{ TEXT("�i"),	TEXT("�j") }, 
		{ TEXT("{"),	TEXT("}")  },	{ TEXT("�o"),	TEXT("�p") },
		{ TEXT("�q"),	TEXT("�r") },	{ TEXT("�s"),	TEXT("�t") },
		{ TEXT("["),	TEXT("]")  },	{ TEXT("�m"),	TEXT("�n") },
		{ TEXT("�k"),	TEXT("�l") },	{ TEXT("�y"),	TEXT("�z") }, 
		{ TEXT("\""),	TEXT("\"") },	{ TEXT("�g"),	TEXT("�h") },
		{ TEXT("`"),	TEXT("'")  }, 
	},	_srDefaultKutoutens []	= {
		{ TEXT ("�C"),	TEXT ("�D")	},	{ TEXT ("�A"),	TEXT ("�B") },
	} ;
	const int	en_table []	= { 0, 1 } ;
	const int	jp_table []	= { 1, 0 } ;
	const int*	pTable ;
	int	i ;

	if (! imeConfig_bLoadGenericSettingFromRegistry ()) {
		/* default setting */
		_bKanaModeWhenOpen		= TRUE ;
		_bEcho					= TRUE ;
		_bAutoInsertParen		= TRUE ;
		_bCompositionAutoShift	= TRUE ;
		_bDeleteImpliesKakutei	= TRUE ;
		_bDateAd				= FALSE ;
		_iNumberStyle			= 0 ;
		_iKutoutenType			= KUTOUTEN_TYPE_JP ;

		for (i = 0 ; i < ARRAYSIZE (_srDefaultBracketParens) ; i ++) {
			LPDSTR	pDest ;
			LPCWSTR	pwSrc ;
			int		n, nDestSize, nSrcLen ;
			pDest		= _srBracketParen [i].m_bufLeft ;
			nDestSize	= ARRAYSIZE (_srBracketParen [i].m_bufLeft) ;
			pwSrc		= _srDefaultBracketParens [i].m_strLeft ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n			= wcstodcs_n (pDest, nDestSize-1, pwSrc, nSrcLen) ;
			pDest [n]	= L'\0' ;

			pDest		= _srBracketParen [i].m_bufRight ;
			nDestSize	= ARRAYSIZE (_srBracketParen [i].m_bufRight) ;
			pwSrc		= _srDefaultBracketParens [i].m_strRight ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n			= wcstodcs_n (pDest, nDestSize-1, pwSrc, nSrcLen) ;
			pDest [n]	= L'\0' ;
		}
		_iNumBracketParen		= ARRAYSIZE (_srDefaultBracketParens) ;
	}
	switch (_iKutoutenType) {
	case	KUTOUTEN_TYPE_EN:
		pTable			= en_table ;
		_iNumKutouten	= ARRAYSIZE (en_table) ;
		goto	Set;
	case	KUTOUTEN_TYPE_JP:
		pTable			= jp_table ;
		_iNumKutouten	= ARRAYSIZE (jp_table) ;
Set:
		for (i = 0 ; i < _iNumKutouten ; i ++) {
			LPDSTR	pDest ;
			LPCWSTR	pwSrc ;
			int		n, nDestSize, nSrcLen ;
			pDest		= _srKutouten [i].m_bufLeft ;
			nDestSize	= ARRAYSIZE (_srKutouten [i].m_bufLeft) ;
			pwSrc		= _srDefaultKutoutens [pTable [i]].m_strLeft ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n			= wcstodcs_n (pDest, nDestSize-1, pwSrc, nSrcLen) ;
			pDest [n]	= L'\0' ;

			pDest		= _srKutouten [i].m_bufRight ;
			nDestSize	= ARRAYSIZE (_srKutouten [i].m_bufRight) ;
			pwSrc		= _srDefaultKutoutens [pTable [i]].m_strRight ;
			nSrcLen		= lstrlenW (pwSrc) ;
			n			= wcstodcs_n (pDest, nDestSize-1, pwSrc, nSrcLen) ;
			pDest [n]	= L'\0' ;
		}
		break; 
	default:
		break; 
	}
	return	TRUE ;
}

BOOL
imeConfig_bLoadGenericSettingFromRegistry (void)
{
	static	const struct {
		LPCTSTR		m_strKeyInfo ;
		int			m_iType ;
		void*		m_pvData ;
	}	_srRegValues []	= {
		{	REGINFO_KANAMODEWHENOPEN,		REGKEYTYPE_BOOL,	&_bKanaModeWhenOpen,	},
		{	REGINFO_ECHO,					REGKEYTYPE_BOOL,	&_bEcho,	},
		{	REGINFO_COMPOSITIONAUTOSHIFT,	REGKEYTYPE_BOOL,	&_bCompositionAutoShift,	},
		{	REGINFO_DELETEIMPLIESKAKUTEI,	REGKEYTYPE_BOOL,	&_bDeleteImpliesKakutei,	},
		{	REGINFO_DATEAD,					REGKEYTYPE_INT,		&_bDateAd,	},
		{	REGINFO_NUMBERSTYLE,			REGKEYTYPE_INT,		&_iNumberStyle,	},
		{	REGINFO_KAKUTEIEARLY,			REGKEYTYPE_BOOL,	&_bKakuteiEarly,	},
		{	REGINFO_KUTOUTENTYPE,			REGKEYTYPE_INT,		&_iKutoutenType,	},
		{	REGINFO_AUTOINSERTPAREN,		REGKEYTYPE_INT,		&_iBracketParenType,	},
		{	REGINFO_OKURICHARALISTTYPE,		REGKEYTYPE_INT,		&_iOkuriCharAlistType,	},
	} ;
	HKEY	hSubKey ;
	LONG 	lResult ;
	DWORD	dwType, cbData ;
	int		i ;
	LPTSTR	pwBracketParen		= NULL ;
	LPTSTR	pwKutoutens			= NULL ;
	LPTSTR	pwOkuriCharAlist	= NULL ;
	BOOL	bRetval				= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
		return	FALSE ;

	/*	���ʃy�A�ݒ�̓ǂݍ��݁B*/
	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_BRACKETPARENS, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwBracketParen	= (LPTSTR) MALLOC (cbData) ;
		if (pwBracketParen == NULL)
			goto	skip_error ;
		(void) RegQueryValueEx (hSubKey, REGINFO_BRACKETPARENS, NULL, &dwType, (BYTE*)pwBracketParen, &cbData) ;
	} else {
		_iBracketParenType		= BRACKETPARENTP_DEFAULT ;
	}

	/*	��Ǔ_�ݒ�̓ǂݍ��݁B*/
	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_KUTOUTENS, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwKutoutens	= (LPTSTR) MALLOC (cbData) ;
		if (pwKutoutens == NULL)
			goto	skip_error ;
		(void) RegQueryValueEx (hSubKey, REGINFO_KUTOUTENS, NULL, &dwType, (BYTE*)pwKutoutens, &cbData) ;
	} else {
		_iKutoutenType			= KUTOUTEN_TYPE_JP ;
	}

	/*	���艼���ǂݑւ��ݒ�̓ǂݍ��݁B*/
	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_OKURICHARALIST, NULL, &dwType, NULL, &cbData) ;
	if (lResult == ERROR_SUCCESS) {
		if (dwType != REG_MULTI_SZ)
			goto	skip_error ;
		pwOkuriCharAlist	= (LPTSTR) MALLOC (cbData) ;
		if (pwOkuriCharAlist == NULL)
			goto	skip_error ;
		(void) RegQueryValueEx (hSubKey, REGINFO_OKURICHARALIST, NULL, &dwType, (BYTE*)pwOkuriCharAlist, &cbData) ;
	} else {
		_iOkuriCharAlistType	= OKURICHARTP_DEFAULT ;
	}

	for (i = 0 ; i < ARRAYSIZE (_srRegValues) ; i ++) {
		DWORD	dwValue ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueEx (hSubKey, _srRegValues [i].m_strKeyInfo, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		switch (_srRegValues [i].m_iType) {
		case	REGKEYTYPE_BOOL:
			*(BOOL*)(_srRegValues [i].m_pvData)	= (dwValue != 0) ;
			break ;
		case	REGKEYTYPE_INT:
			*(int*)(_srRegValues [i].m_pvData)	= (int)dwValue ;
			break ;
		default:
			break ;
		}
	}

	bRetval	= TRUE ;

skip_error:
	RegCloseKey (hSubKey) ;

	/* BracketParen �� parse */
	if (bRetval && pwBracketParen != NULL) {
		_iNumBracketParen	= imeConfig_iDecodeStringPairList (pwBracketParen, _srBracketParen, ARRAYSIZE (_srBracketParen)) ;
	}
	/* Kutouten �� parse */
	if (bRetval && pwKutoutens != NULL) {
		_iNumKutouten	= imeConfig_iDecodeStringPairList (pwKutoutens, _srKutouten, ARRAYSIZE (_srKutouten)) ;
	}
	if (bRetval && pwOkuriCharAlist != NULL) {
		_iNumOkuriCharAlist	= imeConfig_iDecodeStringPairList (pwKutoutens, _srOkuriCharAlist, ARRAYSIZE (_srOkuriCharAlist)) ;
	}
	FREE (pwBracketParen) ;
	FREE (pwKutoutens) ;
	FREE (pwOkuriCharAlist) ;
	return	bRetval ;
}

/*========================================================================
 *	private functions for conversion
 */
static	BOOL	imeConfig_bLoadConversionSettingFromRegistry (void) ;

BOOL
imeConfig_bLoadConversionSetting (void)
{
	static	const DCHAR	_srbDefaultCandidateKeys []	= {
		'A', 'S', 'D', 'F', 'J', 'K', 'L', 'Q', 'W', 'U', 'I', 'O', 'Z', 'C', 'V', 'B', 'M', 
	} ;
	static	const DCHAR	_srbDefaultMenu1Keys []	= {
		'A', 'S', 'D', 'F', 'G', 'H', 'Q', 'W', 'E', 'R', 'T', 'Y',
	} ;
	static	const DCHAR	_srbDefaultMenu2Keys []	= {
		'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U',
	} ;
	static	const DCHAR	_srb10Keys []	= {
		'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 
	} ;
	/* 28 keywords */
	static	const WCHAR	_srDefaultAutoStartHenkanKeywords []	= L"��\0�A\0�B\0�D\0�C\0�H\0�v\0�I\0�G\0�F\0)\0;\0:\0�j\0�h\0�z\0�x\0�t\0�r\0�p\0�n�l\0}\0]\0?\0.\0,\0!\0\0" ;

	if (! imeConfig_bLoadConversionSettingFromRegistry ()) {
		_snCandListKeyAssign			= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumShowCandidateKeys			= 0 ;
		_snNumInputCodeMenu1Keys		= 0 ;
		_snNumInputCodeMenu2Keys		= 0 ;

		_snShowCandListCount			= SHOWCANDLIST_COUNT_ZERO+3 ;
		_sbHenkanOkuriStrictly			= FALSE ;
		_sbProcessOkuriEarly			= FALSE ;
		_sbHenkanStrictOkuriPrecedence	= FALSE ;
		_sbAutoStartHenkan				= TRUE ;
		_sbDeleteOkuriWhenQuit			= FALSE ;
		_sbAutoOkuriProcess				= FALSE ;
		_snShowAnnotationType			= SHOW_NO_ANNOTATION ;

		_siNumAutoStartHenkanKeywords	= -1 ;
	}
	switch (_snCandListKeyAssign) {
	case	CANDLIST_KEYASSIGN_DEFAULT:
		_snNumShowCandidateKeys		= ARRAYSIZE (_srbDefaultCandidateKeys) ;
		_snNumInputCodeMenu1Keys	= ARRAYSIZE (_srbDefaultMenu1Keys) ;
		_snNumInputCodeMenu2Keys	= ARRAYSIZE (_srbDefaultMenu2Keys) ;
		memcpy (_srdchShowCandidateKeys,	_srbDefaultCandidateKeys,	sizeof (_srbDefaultCandidateKeys)) ;
		memcpy (_srdchInputCodeMenu1Keys,	_srbDefaultMenu1Keys,		sizeof (_srbDefaultMenu1Keys)) ;
		memcpy (_srdchInputCodeMenu2Keys,	_srbDefaultMenu2Keys,		sizeof (_srbDefaultMenu2Keys)) ;
		break ;
	case	CANDLIST_KEYASSIGN_01234567890:
		_snNumShowCandidateKeys		= ARRAYSIZE (_srb10Keys) ;
		_snNumInputCodeMenu1Keys	= ARRAYSIZE (_srb10Keys) ;
		_snNumInputCodeMenu2Keys	= ARRAYSIZE (_srb10Keys) ;
		memcpy (_srdchShowCandidateKeys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (_srdchInputCodeMenu1Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		memcpy (_srdchInputCodeMenu2Keys,	_srb10Keys, sizeof (_srb10Keys)) ;
		break ;
	default:
		break; 
	}
	if (_siNumAutoStartHenkanKeywords < 0) {
		imeConfig_vInitAutoStartHenkanKeys (_srDefaultAutoStartHenkanKeywords, ARRAYSIZE (_srDefaultAutoStartHenkanKeywords)) ;
	}
	return	TRUE ;
}

BOOL
imeConfig_bLoadConversionSettingFromRegistry (void)
{
	static struct {
		LPCTSTR		m_strInfoKey ;
		BOOL*		m_pbData ;
	}	_srRegBoolValues []	= {
		{	REGINFO_HENKANOKURISTRICTLY,			&_sbHenkanOkuriStrictly,	},
		{	REGINFO_PROCESSOKURIEARLY,				&_sbProcessOkuriEarly,		},
		{	REGINFO_HENKANSTRICTOKURIPRECEDENCE,	&_sbHenkanStrictOkuriPrecedence,	},
		{	REGINFO_AUTOSTARTHENKAN,				&_sbAutoStartHenkan,		},
		{	REGINFO_DELETEOKURIWHENQUIT,			&_sbDeleteOkuriWhenQuit,	},
		{	REGINFO_AUTOOKURIPROCESS,				&_sbAutoOkuriProcess,		},
		/* NumericConversion, NumericFloat ��ǉ��B(2008/07/18) */
		{	REGINFO_NUMERICCONVERSION,				&_sbNumericConversion,		},
		{	REGINFO_NUMERICFLOAT,					&_sbNumericFloat,			},
	} ;
	HKEY	hSubKey ;
	LONG 	lResult ;
	DWORD	dwType, cbData, dwValue ;
	int		i ;
	BYTE	rbBuffer [MAX_NUMMENUKEYS] ;
	BOOL	bRetval	= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_CONVERSION, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) 
		return	FALSE ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_CANDLISTKEYASSIGN, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	_snCandListKeyAssign	= (/*CANDLIST_KEYASSIGN_DEFAULT <= dwValue && */dwValue <= CANDLIST_KEYASSIGN_01234567890)? (int) dwValue : CANDLIST_KEYASSIGN_USERDEFINED ;

	cbData	= sizeof (DWORD) ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATELISTCOUNT, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
		goto	skip_error ;
	_snShowCandListCount	= (int) dwValue ;


	for (i = 0 ; i < ARRAYSIZE (_srRegBoolValues) ; i ++) {
		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueEx (hSubKey, _srRegBoolValues [i].m_strInfoKey, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		*(BOOL*)(_srRegBoolValues [i].m_pbData)	= (dwValue != 0) ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumShowCandidateKeys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_SHOWCANDIDATEKEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++) 
			_srdchShowCandidateKeys [i]	= (DCHAR) rbBuffer [i] ;
		_snNumShowCandidateKeys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumInputCodeMenu1Keys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU1KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++) 
			_srdchInputCodeMenu1Keys [i]	= (DCHAR) rbBuffer [i] ;
		_snNumInputCodeMenu1Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData <= 0 || cbData >= MAX_NUMMENUKEYS) {
		if (_snCandListKeyAssign == CANDLIST_KEYASSIGN_USERDEFINED)
			_snCandListKeyAssign	= CANDLIST_KEYASSIGN_DEFAULT ;
		_snNumInputCodeMenu2Keys	= 0 ;
	} else {
		(void) RegQueryValueEx (hSubKey, REGINFO_INPUTCODEMENU2KEYS, NULL, &dwType, (BYTE*)rbBuffer, &cbData) ;
		for (i = 0 ; i < (int) cbData ; i ++) 
			_srdchInputCodeMenu2Keys [i]	= (DCHAR) rbBuffer [i] ;
		_snNumInputCodeMenu2Keys	= (int) cbData ;
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ || cbData <= 0 || cbData >= sizeof (_srAutoStartHenkanKeywords)) {
		/* default �̐ݒ�B*/
		_srAutoStartHenkanKeywords [0]	= L'\0' ;
		_siNumAutoStartHenkanKeywords	= -1 ;
	} else {
		LPWSTR	pwBuffer ;

		pwBuffer	= MALLOC (sizeof (WCHAR) * cbData) ;
		if (pwBuffer != NULL) {
			(void) RegQueryValueExW (hSubKey, REGINFO_AUTOSTARTHENKANKEYWORD_W, NULL, &dwType, (BYTE*) pwBuffer, &cbData) ;

			imeConfig_vInitAutoStartHenkanKeys (pwBuffer, cbData) ;
			FREE (pwBuffer) ;
		}
	}

	cbData	= 0 ;
	lResult	= RegQueryValueEx (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, NULL, &cbData) ;
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD) {
		_snShowAnnotationType	= SHOW_NO_ANNOTATION ;
	} else {
		DWORD	dwValue ;
		(void) RegQueryValueEx (hSubKey, REGINFO_SHOWANNOTATIONTYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;

		if (dwValue == (DWORD)DISABLE_ANNOTATION) {
			_snShowAnnotationType	= DISABLE_ANNOTATION ;
		} else if (/*0 <= dwValue && */dwValue <= SHOW_ANNOTATION_ALWAYS) {
			_snShowAnnotationType	= (int) dwValue ;
		} else {
			_snShowAnnotationType	= SHOW_NO_ANNOTATION ;
		}
	}
	bRetval	= TRUE ;

skip_error:
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

static	void
imeConfig_vInitAutoStartHenkanKeys (LPCWSTR pwKeys, int nKeyLen)
{
	LPDSTR	pDest, pDestEnd ;
	LPCWSTR	pSrc, pSrcEnd ;
	int		iNumKeywords ;

	/* ���𐔂���B*/
	iNumKeywords	= 0 ;
	pDest			= _srAutoStartHenkanKeywords ;
	pDestEnd		= _srAutoStartHenkanKeywords + ARRAYSIZE (_srAutoStartHenkanKeywords) - 1 ;
	pSrc			= pwKeys ;
	pSrcEnd			= pwKeys + nKeyLen ;

	while (pSrc < pSrcEnd && *pSrc != L'\0' && pDest < pDestEnd) {
		int	nKeywordLen	= lstrlenW (pSrc) ;

		if (nKeywordLen > 0) {
			int		n ;

			n		= wcstodcs_n (pDest, pDestEnd - pDest, pSrc, nKeywordLen) ;
			if ((pDest + n) >= pDestEnd) {
				*pDest ++	= L'\0' ;
				break ;
			}
			pDest	+= n ;
			*pDest ++	= L'\0' ;
			iNumKeywords ++ ;
		}
		pSrc	+= nKeywordLen + 1 ;
	}
	if (pDest < pDestEnd)
		*pDest ++	= L'\0' ;

	_siNumAutoStartHenkanKeywords	= iNumKeywords ;
	return ;
}

/*========================================================================
 *	private functions for colorface
 */
static	BOOL	imeConfig_bLoadColorfaceSettingFromRegistry (const MYCOLORFACESET*) ;
static	BOOL	bIsValidColor		(int) ;
static	BOOL	bIsValidLineType	(int) ;

BOOL
imeConfig_bLoadColorfaceSetting (void)
{
	static	const MYCOLORFACESET		_srDefaultColorFaces []	= {
		/*	���ϊ�������B*/
		{ MYCOLOR_TEXTAUTO,			/* ����(����) */	/* �����F�B*/
		  MYCOLOR_BACKAUTO,			/* ����(�w�i) */ 	/* �w�i�F�B*/
		  MYCOLOR_TEXTAUTO,			/* ����(����) */	/* �����F�B*/
		  MYLINE_THIN_DITHER,		/* �f�B�U(��) */	/* �����^�C�v�B*/
		},
		/*	�ϊ�������B*/
		{ MYCOLOR_HIGHLIGHTTEXT,	/* �I������(����) */	/* �����F�B*/
		  MYCOLOR_HIGHLIGHT,		/* �I������(�w�i) */	/* �w�i�F�B*/
		  MYCOLOR_TEXTAUTO,			/* ����(����) */	 	/* �����F�B*/
		  MYLINE_NO,				/* �Ȃ� */				/* �����^�C�v�B*/
		},
	} ;

	if (! imeConfig_bLoadColorfaceSettingFromRegistry (_srDefaultColorFaces)) 
		memcpy (_srImeColorFaces, _srDefaultColorFaces, sizeof (_srImeColorFaces)) ;
	return	TRUE ; 
}

BOOL
imeConfig_bLoadColorfaceSettingFromRegistry (
	const MYCOLORFACESET*	pDefaultColorFaces)
{
	HKEY	hSubKey ;
	BOOL	bRetval	= FALSE ;
	BYTE	rbStyles [ARRAYSIZE (_srImeColorFaces) * 4] ;
	int		i ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_COLORFACE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 		lResult ;
		DWORD		dwType, cbData ;
		const BYTE*	pbData ;

		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_BINARY || cbData != sizeof (rbStyles))
			goto	skip_error ;

		(void) RegQueryValueEx (hSubKey, REGSUBKEY_COLORFACE, NULL, &dwType, (BYTE*)rbStyles, &cbData) ;

		pbData	= rbStyles ;
		for (i = 0 ; i < ARRAYSIZE (_srImeColorFaces) ; i ++) {
			int		nTextColor, nBackColor, nUnderLineColor, nUnderLineType ;

			nTextColor		= *pbData ++ ;
			nTextColor		= bIsValidColor (nTextColor)? nTextColor : pDefaultColorFaces [i].m_nTextColor ;
			_srImeColorFaces [i].m_nTextColor		= nTextColor ;	
			nBackColor		= *pbData ++ ;
			nBackColor		= bIsValidColor (nBackColor)? nBackColor : pDefaultColorFaces [i].m_nBackColor ;
			_srImeColorFaces [i].m_nBackColor		= nBackColor ;
			nUnderLineColor	= *pbData ++ ;
			nUnderLineColor	= bIsValidColor (nUnderLineColor)? nUnderLineColor : pDefaultColorFaces [i].m_nUnderLineColor ;
			_srImeColorFaces [i].m_nUnderLineColor	= nUnderLineColor ;
			nUnderLineType	= *pbData ++ ;
			nUnderLineType	=  bIsValidLineType (nUnderLineType)? nUnderLineType : pDefaultColorFaces [i].m_nUnderLineType ;
			_srImeColorFaces [i].m_nUnderLineType	= nUnderLineType ;
		}
		bRetval		= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	return	bRetval ;
}

BOOL
bIsValidColor (int nColorType)
{
	return	(nColorType < 0 || nColorType >= MAX_MYCOLOR) ? FALSE : TRUE ;
}

BOOL
bIsValidLineType (int nLineType)
{
	return	(nLineType < 0 || nLineType >= MAX_MYLINE)? FALSE : TRUE ;
}

static	void
imeConfig_vInitializeDefaultFontSetting (void)
{
	HKEY	hSubKey ;
	LOGFONT	lf ;

	memset (&lf, 0, sizeof (lf)) ;
	{
		NONCLIENTMETRICS	param ;

		memset (&param, 0, sizeof (param)) ;
		param.cbSize	= sizeof (param) ;
		if (SystemParametersInfo (SPI_GETNONCLIENTMETRICS, param.cbSize, &param, 0)) {
			memcpy (&lf, &param.lfMessageFont, sizeof (LOGFONT)) ;
		}
	}
	_siDefaultFontSize	= -1 ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_COLORFACE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 		lResult ;
		DWORD		dwType, cbData ;

		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD && cbData == sizeof (DWORD)) {
			DWORD	dwValue ;

			(void) RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTSIZE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
			_siDefaultFontSize	= (int) dwValue ;
		}
		lResult	= RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTFACE, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_SZ && cbData <= sizeof (TCHAR) * LF_FACESIZE) {
			memset (&lf.lfFaceName, 0, sizeof (TCHAR) * LF_FACESIZE) ;
			(void) RegQueryValueEx (hSubKey, REGSUBKEY_DEFAULTFONTFACE, NULL, &dwType, (BYTE*)&lf.lfFaceName, &cbData) ;
		}
		RegCloseKey (hSubKey) ;
	}
	memcpy (&_slfDefaultFont, &lf, sizeof (LOGFONT)) ;
	return ;
}

/*
 */
BOOL
imeConfig_bParseBSEncodedString (
	LPCTSTR*	ppwSrc,
	LPTSTR		pwDest,
	int			nDestSize,
	BOOL*		pbTerminated)
{
	LPCTSTR	pwSrc ;
	LPTSTR	pwDestLast ;
	int		nCH ;

	pwSrc		= *ppwSrc ;
	pwDestLast	= pwDest + nDestSize ;
	while (*pwSrc != TEXT ('\0') && pwDest < pwDestLast) {
		if (*pwSrc == TEXT ('\\')) {
			pwSrc	++ ;
			nCH		= *pwSrc ;
			if (nCH == TEXT ('\0')) {
				break ;
			} else if (nCH == TEXT ('0')) {
				/* �I�[�B*/
				pwSrc ++ ;
				break ;
			} else {
				*pwDest ++	= nCH ;
			}
		} else {
			*pwDest ++	= *pwSrc ;
		}
		pwSrc	++ ;
	}
	if (pwDest < pwDestLast)
		*pwDest	= TEXT ('\0') ;
	*pbTerminated	= (*pwSrc == TEXT ('\0')) ;
	*ppwSrc			= pwSrc ;
	return	TRUE ;
}

int
imeConfig_iDecodeStringPairList (
	LPCTSTR					pwEncodedString,
	struct TStringPair*		pDestBuffer,
	int						iBufferSize)
{
	struct TStringPair*		pDest ;
	struct TStringPair*		pDestEnd ;
	LPCTSTR	pwSrc ;
	TCHAR	bufLeft [BUFSIZE_STRPAIR], bufRight [BUFSIZE_STRPAIR] ;
	BOOL	bTerminated ;

	pwSrc			= pwEncodedString ;
	pDest			= pDestBuffer ;
	pDestEnd		= pDestBuffer + iBufferSize ;
	while (*pwSrc != TEXT ('\0') && pDest < pDestEnd) {
		int	n ;

		if (! imeConfig_bParseBSEncodedString (&pwSrc, bufLeft, ARRAYSIZE (bufLeft) - 1, &bTerminated) || bTerminated) {
			break ;
		}
		bufLeft [ARRAYSIZE (bufLeft) - 1]	= TEXT ('\0') ;

		if (! imeConfig_bParseBSEncodedString (&pwSrc, bufRight, ARRAYSIZE (bufRight) - 1, &bTerminated) || ! bTerminated) {
			break ;
		}
		bufRight [ARRAYSIZE (bufRight) - 1]	= TEXT ('\0') ;

		n	= wcstodcs_n (pDest->m_bufLeft, ARRAYSIZE (pDest->m_bufLeft)-1, bufLeft, lstrlen (bufLeft)) ;
		pDest->m_bufLeft [n]	= L'\0' ;
		n	= wcstodcs_n (pDest->m_bufRight, ARRAYSIZE (pDest->m_bufRight)-1, bufRight, lstrlen (bufRight)) ;
		pDest->m_bufLeft [n]	= L'\0' ;
		if (*pwSrc != TEXT ('\0'))
			break ;
		pwSrc	++ ;
		pDest	++ ;
	}
	return	pDest - pDestBuffer ;
}

