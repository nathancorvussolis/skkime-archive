#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "RuleTreeIterator.h"
#include "RuleTreeNode.h"
#include "ImeConfig.h"

#define	DEFAULT_RULETREE	0

void
SkkRuleTreeIterator_vInit (struct CSkkRuleTreeIterator* piteRuleTree)
{
	if (piteRuleTree == NULL)
		return ;
	piteRuleTree->m_pSkkRuleTree	= NULL ;
	piteRuleTree->m_nPrefixLength	= 0 ;
	piteRuleTree->m_iPreviousSelectBranchChar	= 0 ;
	piteRuleTree->m_iTree			= DEFAULT_RULETREE ;
	return ;
}

void
SkkRuleTreeIterator_vReset (struct CSkkRuleTreeIterator* piteRuleTree)
{
	piteRuleTree->m_pSkkRuleTree				= NULL ;
	piteRuleTree->m_nPrefixLength				= 0 ;
	piteRuleTree->m_iPreviousSelectBranchChar	= 0 ;
	return ;
}

/*	m_pSkkCurrentRuleTree �� Current-State �͌����Ȃ��BIterator ���ɊǗ�����
 *	��B(���R�͓���L���� RuleTree �� State �L�q�Ɋ܂܂��悤�ɂȂ�������)
 */
const DCHAR*	
SkkRuleTreeIterator_pGetPrefix (struct CSkkRuleTreeIterator* piteRuleTree, int* pnLength) 
{
	/*
	 *	(pSkkCurrentRuleTree == NULL || 
	 *	CSkkRuleTreeNode::pGetPrefix (pSkkCurrentRuleTree, &nPrefix) == NULL)
	 *	CSkkRuleTreeNode::pGetPrefix() ���������ŗ��p����K�v������B
	 */
	if (pnLength != NULL)
		*pnLength	= piteRuleTree->m_nPrefixLength ;
	return	(piteRuleTree->m_nPrefixLength <= 0)? NULL : piteRuleTree->m_bufPrefix ;
}

BOOL
SkkRuleTreeIterator_bHavePrefixp (const struct CSkkRuleTreeIterator* piteRuleTree)
{
	return	(piteRuleTree->m_pSkkRuleTree != NULL)? TRUE : FALSE ;
}

int
SkkRuleTreeIterator_iGetRuleTree (struct CSkkRuleTreeIterator* piteRuleTree)
{
	return	piteRuleTree->m_iTree ;
}

BOOL
SkkRuleTreeIterator_bRootp (struct CSkkRuleTreeIterator* piteRuleTree)
{
	return	piteRuleTree->m_pSkkRuleTree == ImeConfig_pGetSkkRuleTree (piteRuleTree->m_iTree) ;
}

void
SkkRuleTreeIterator_vMoveToRoot (struct CSkkRuleTreeIterator* piteRuleTree)
{
	SkkRuleTreeIterator_vReset (piteRuleTree) ;
	piteRuleTree->m_pSkkRuleTree	= ImeConfig_pGetSkkRuleTree (piteRuleTree->m_iTree) ;
	return ;
}

void
SkkRuleTreeIterator_vMoveTree (struct CSkkRuleTreeIterator* piteRuleTree, int iTree)
{
	piteRuleTree->m_iTree	= iTree ;
	return ;
}

BOOL
SkkRuleTreeIterator_bHaveSelectBranchp (struct CSkkRuleTreeIterator* piteRuleTree, int wch)
{
	struct CSkkRuleTreeNode*	pNode	= TSkkRuleTreeNode_pSelectBranch (piteRuleTree->m_pSkkRuleTree, wch) ;
	return	pNode != NULL ;
}

BOOL
SkkRuleTreeIterator_bNextHasBranchListp (struct CSkkRuleTreeIterator* piteRuleTree, int wch)
{
	struct CSkkRuleTreeNode*	pNext ;

	pNext	= TSkkRuleTreeNode_pSelectBranch (piteRuleTree->m_pSkkRuleTree, wch) ;
	if (pNext == NULL)
		return	FALSE ;
	return	TSkkRuleTreeNode_pGetBranchList (pNext) != NULL ;
}

const struct CSkkRuleTreeNodeOutput*
SkkRuleTreeIterator_pGetOutput (struct CSkkRuleTreeIterator* piteRuleTree)
{
	return	(piteRuleTree->m_pSkkRuleTree != NULL)? TSkkRuleTreeNode_pGetOutput (piteRuleTree->m_pSkkRuleTree) : NULL ;
}

BOOL
SkkRuleTreeIterator_bHaveNextState (struct CSkkRuleTreeIterator* piteRuleTree)
{
	LPCDSTR	pwNextState ;
	int	nNextState, nNextTree ;

	if (piteRuleTree == NULL || piteRuleTree->m_pSkkRuleTree == NULL)
		return	FALSE ;

	pwNextState	= TSkkRuleTreeNode_pGetNextState (piteRuleTree->m_pSkkRuleTree, &nNextState, &nNextTree) ;
	if (pwNextState != NULL && nNextState > 0)
		return	TRUE ;
	/*	�����񂪋�ł��A���[���ύX�͎���Ԃ�����Ƃ���B
	 */
	if (nNextTree != piteRuleTree->m_iTree)
		return	TRUE ;
	return	FALSE ;
}

int
SkkRuleTreeIterator_iGetNextState (struct CSkkRuleTreeIterator* piteRuleTree, LPDSTR pwBuffer, int nBufferSize, int* pnNextTree)
{
	LPCDSTR	pNextState ;
	int		nNextState ;
	LPCDSTR	pwSrc ;
	LPCDSTR	pwSrcEnd ;

	if (piteRuleTree->m_pSkkRuleTree == NULL) {
		if (pnNextTree != NULL)
			*pnNextTree	= piteRuleTree->m_iTree ;
		return	0 ;
	}

	pNextState	= TSkkRuleTreeNode_pGetNextState (piteRuleTree->m_pSkkRuleTree, &nNextState, pnNextTree) ;
	if (pNextState == NULL || nNextState <= 0)
		return	0 ;

	/*	pNextState �ɓ��ꕶ���͂���̂��H
	 */
	pwSrc		= pNextState ;
	pwSrcEnd	= pNextState + nNextState ;
	if (pwBuffer == NULL || nBufferSize <= 0) {
		int	nLength	= 0 ;
		while (pwSrc < pwSrcEnd) {
			if (*pwSrc == L'\\') {
				pwSrc	++ ;
				if (pwSrc >= pwSrcEnd)
					break ;
				switch (*pwSrc ++) {
				case	L'\\':
					nLength	++ ;
					break ;
				case	L'I':
					if (0x20 <= piteRuleTree->m_iPreviousSelectBranchChar && piteRuleTree->m_iPreviousSelectBranchChar < 128) {
						nLength	++ ;
					}
					break ;
				default:
					/* ��������B*/
					break ;
				}
			} else {
				nLength	++ ;
			}
		}
		return	nLength ;
	} else {
		LPDSTR	pwDest		= pwBuffer ;
		LPDSTR	pwDestEnd	= pwBuffer + nBufferSize ;
		while (pwDest < pwDestEnd && pwSrc < pwSrcEnd) {
			if (*pwSrc == L'\\') {
				pwSrc	++ ;
				if (pwSrc >= pwSrcEnd)
					break ;
				switch (*pwSrc ++) {
				case	L'\\':
					*pwDest ++	= L'\\' ;
					break ;
				case	L'I':
					if (0x20 <= piteRuleTree->m_iPreviousSelectBranchChar && piteRuleTree->m_iPreviousSelectBranchChar < 128) {
						*pwDest ++	= (DCHAR) piteRuleTree->m_iPreviousSelectBranchChar ;
					}
					break ;
				default:
					/* ��������B*/
					break ;
				}
			} else {
				*pwDest ++	= *pwSrc ++ ;
			}
		}
		return	pwDest - pwBuffer ;
	}
}

void
SkkRuleTreeIterator_vWalk (struct CSkkRuleTreeIterator* piteRuleTree, int wch)
{
	struct CSkkRuleTreeNode*	pNext ;

	pNext	= TSkkRuleTreeNode_pSelectBranch (piteRuleTree->m_pSkkRuleTree, wch) ;
	if (pNext == NULL) {
		SkkRuleTreeIterator_vReset (piteRuleTree) ;
	} else {
		piteRuleTree->m_pSkkRuleTree	= pNext ;
		if (piteRuleTree->m_nPrefixLength < MAXCOMPLEN) {
			piteRuleTree->m_bufPrefix [piteRuleTree->m_nPrefixLength ++]	= (DCHAR) wch ;
		}
		piteRuleTree->m_iPreviousSelectBranchChar	= wch ;
	}
	return ;
}

