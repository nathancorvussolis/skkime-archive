#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif


void
DebugPrintf (
	LPCTSTR	strFormat,
	...)
{
	TCHAR	buf [2048] ;
	va_list	vl ;

	va_start (vl, strFormat) ;
	wvnsprintf (buf, sizeof (buf) / sizeof (buf [0]), strFormat, vl) ;
	va_end (vl) ;
	OutputDebugString (buf) ;
	return ;
}


