#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDoc.h"
#include "ImeBufferP.h"
#include "TMarker.h"
#include "RuleTreeNode.h"
#include "keymap.h"
#include "TMSG.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "lmstate.h"
#include "jstring.h"
#include "ImeConfig.h"

/*=================================================================================
 *	prototypes
 */

/*================================================================ skk-today
 */
static	int	LM_bSkkToday_1 (struct CImeDoc*) ;
static	int	LM_bSkkToday_2 (struct CImeDoc*) ;

int
LM_bSkkToday (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (! pBuffer->m_bSkkMode) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkModeAdJisx0201, LM_bSkkToday_1))
			return	LMR_ERROR ;
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkToday_1) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkToday_1 (
	struct CImeDoc*		pDoc)
{
	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPointSubr, LM_bSkkToday_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkToday_2 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bInsertAndInheritW (pBuffer, L"today", 5)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkStartHenkan) ;
	return	LMR_CONTINUE ;
}


