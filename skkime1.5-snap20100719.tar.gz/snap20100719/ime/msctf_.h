#pragma once

/*	Platform SDK �Ɉˑ����镔���BPlatform SDK �� include path
 *	��ʂ��̂��ǂ��̂��ۂ��B�o����� DDK �ɂ����� header ��
 *	�n���Ă����Ɨǂ��̂����B
 */
#if 1
#undef __in_z
#undef __deref_opt_out_z
#define	__in_z
#define	__deref_opt_out_z
#pragma include_alias(<rpcsal.h>, <C:\Program Files\Microsoft SDKs\Windows\V7.0\Include\rpcsal.h>)
#include "C:\Program Files\Microsoft SDKs\Windows\V7.0\Include\msctf.h"
#include "C:\Program Files\Microsoft SDKs\Windows\V7.0\Include\olectl.h"
#if !defined (TARGET_WIN2K)
#include "C:\Program Files\Microsoft SDKs\Windows\V7.0\Include\uxtheme.h"
#endif
#endif
#if 0
#define	__in_z
#define	__deref_opt_out_z
#pragma include_alias(<rpcsal.h>, <C:\Program Files\Microsoft SDKs\Windows\V6.1\Include\rpcsal.h>)
#include "C:\Program Files\Microsoft SDKs\Windows\V6.1\Include\msctf.h"
#include "C:\Program Files\Microsoft SDKs\Windows\V6.1\Include\olectl.h"
#if !defined (TARGET_WIN2K)
#include "C:\Program Files\Microsoft SDKs\Windows\V6.1\Include\uxtheme.h"
#endif
#endif
#if 0
#undef __in_z
#undef __deref_opt_out_z
#define	__in_z
#define	__deref_opt_out_z
#pragma include_alias(<rpcsal.h>, <C:\Program Files\Microsoft SDKs\Windows\V6.0\Include\rpcsal.h>)
#include "C:\Program Files\Microsoft SDKs\Windows\V6.0\Include\msctf.h"
#include "C:\Program Files\Microsoft SDKs\Windows\V6.0\Include\olectl.h"
#if !defined (TARGET_WIN2K)
#include "C:\Program Files\Microsoft SDKs\Windows\V6.0\Include\uxtheme.h"
#endif
#endif
#if 0
#include "c:\Program Files\Microsoft SDK\include\msctf.h"
#include "c:\Program Files\Microsoft SDK\include\olectl.h"
#if !defined (TARGET_WIN2K)
#include "c:\Program Files\Microsoft SDK\include\uxtheme.h"
#endif
#endif
#if 0
#include "c:\Program Files\Microsoft Platform SDK\include\msctf.h"
#include "c:\Program Files\Microsoft Platform SDK\include\olectl.h"
#if !defined (TARGET_WIN2K)
#include "c:\Program Files\Microsoft Platform SDK\include\uxtheme.h"
#endif
#endif
#if 0
#include "C:\Program Files\Microsoft Platform SDK for Windows Server 2003 R2\include\msctf.h"
#include "C:\Program Files\Microsoft Platform SDK for Windows Server 2003 R2\include\olectl.h"
#if !defined (TARGET_WIN2K)
#include "C:\Program Files\Microsoft Platform SDK for Windows Server 2003 R2\include\uxtheme.h"
#endif
#endif
