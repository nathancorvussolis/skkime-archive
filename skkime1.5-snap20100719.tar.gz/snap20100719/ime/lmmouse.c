#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDocP.h"
#include "ImeBuffer.h"
#include "TMarker.h"
#include "lmstate.h"

/*======================================================================== mouse-drag-region
 */
int
LM_bMouseDragRegion	(
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pCurBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	struct TMarker*		pmkTop ;
	struct TMarker*		pmkMark	= NULL ;
	const struct TMSG*	pEvent ;
	int					nPosition, nLastCmd, nBufferTop, nBufferEnd, nPoint ;

	/*	signal ���ݒ肳��Ă���Γ��삵�Ȃ��B
	 *	�Ƃ������A���̔���𖈉�Ă΂ꂽ���ɏ����̂͂Ȃ��c�B
	 */
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	/*	WM_LM_COMMAND only.
	 */
	pEvent	= ImeDoc_pGetLastCommandEvent (pDoc) ;
	if (pEvent == NULL || pEvent->m_nMessage != WM_LM_COMMAND) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	nPosition	= (int)pEvent->m_lParam ;

	/*	�擪�́u�I�v��ǂݔ�΂��Ȃ��Ƃ����Ȃ��̂ŁB�ށA�ł��A���ꂾ�Ɓc�߂�Ȃ��ꏊ��
	 *	�������獢��Ȃ����ȁH
	 */
	if (ImeDoc_bRecursiveEditp (pDoc) && ImeDoc_bHaveMessagep (pDoc))
		nPosition	-- ;

	/*	�J�[�\�����w�肳�ꂽ�ʒu�ւƈړ�������B*/
	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= TMarker_iGetPosition (pmkTop) ;
	} else {
		nBufferTop	= 0 ;
	}
	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_MARK, &pmkMark))
		pmkMark	= NULL ;

	/* buffertop ���O�ɖ߂邱�Ƃ͂ł��Ȃ��B*/
	nBufferEnd		= TMarker_iGetPosition (pmkEnd) ;
	if (nPosition > nBufferEnd) 
		nPosition	= nBufferEnd ;
	if (nPosition < nBufferTop)
		nPosition	= nBufferTop ;

	nPoint			= TMarker_iGetPosition (pmkPoint) ;
	TMarker_bForward (pmkPoint, nPosition - nPoint) ;

	nLastCmd	= ImeDoc_iGetLastCommand (pDoc) ;
	if (nLastCmd != NFUNC_MOUSE_DRAG_REGION || pmkMark == NULL) {
		/*	�}�[�N���J�[�\���ʒu�ɐݒ肷��B*/
		if (! ImeBuffer_bSetMarker (pCurBuffer, &pmkMark, MARKER_MARK, pmkPoint)) {
			ImeDoc_vSetSignalError (pDoc) ;
			goto	exit_func ;
		}
	}
exit_func:
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*======================================================================== mouse-drag-region-end
 */
static	int	LM_bMouseDragRegionEnd_Exit (struct CImeDoc*) ;

int
LM_bMouseDragRegionEnd (
	struct CImeDoc*		pDoc)
{
	if (! ImeDoc_bCall (pDoc, LM_bMouseDragRegion, LM_bMouseDragRegionEnd_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bMouseDragRegionEnd_Exit (
	struct CImeDoc*		pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	ImeDoc_bSetThisCommand (pDoc, NFUNC_MOUSE_DRAG_REGION_END) ;
	return	LMR_RETURN ;
}

/*======================================================================== mouse-copy
 */
int
LM_bMouseCopy (
	struct CImeDoc*		pDoc)
{
	ImeDoc_vJump (pDoc, LM_bKillRingSave) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== mouse-cut
 */
int
LM_bMouseCut (
	struct CImeDoc*		pDoc)
{
	ImeDoc_vJump (pDoc, LM_bKillRegion) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== mouse-paste
 */
int
LM_bMousePaste (
	struct CImeDoc*		pDoc)
{
	ImeDoc_vJump (pDoc, LM_bYank) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== mouse-delete
 */
int	
LM_bMouseDelete (
	struct CImeDoc*		pDoc)
{
	/*	Delete-Region �̂݁BCutBuffer �ɂ͐G��Ȃ��B
	 */
	struct CImeBuffer*	pCurBuffer ;
	struct TMarker*		pmkPoint ;
	struct TMarker*		pmkEnd ;
	struct TMarker*		pmkTop ;
	struct TMarker*		pmkMark ;
	int			nStart, nEnd, nBufferTop, nBufferEnd ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pCurBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;	

	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bGetMarker (pCurBuffer, MARKER_MARK, &pmkMark)   || pmkMark   == NULL) {
		ImeDoc_bSetMessageW (pDoc, L"The mark is not set now") ;
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (ImeBuffer_bGetMarker (pCurBuffer, MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= TMarker_iGetPosition (pmkTop) ;
	} else {
		nBufferTop	= 0 ;
	}

	nStart	= TMarker_iGetPosition (pmkPoint) ;
	nEnd	= TMarker_iGetPosition (pmkMark) ;
	if (nStart > nEnd) {
		int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	if (nStart == nEnd) 
		goto	exit_func ;

	nBufferEnd	= TMarker_iGetPosition (pmkEnd) ;
	if (nStart < nBufferTop || nEnd > nBufferEnd) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bDeleteRegion (pCurBuffer, nStart, nEnd)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
exit_func:
	ImeDoc_bSetThisCommand (pDoc, NFUNC_KILL_REGION) ;
	return	LMR_RETURN ;
}
