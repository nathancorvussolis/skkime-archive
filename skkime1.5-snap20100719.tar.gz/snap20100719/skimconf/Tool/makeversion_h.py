#! ipy.exe
# -*- coding: utf-8 -*-
import datetime


def main():
	print '#if !defined (version_h)'
	print '#define version_h'
	print '#define SKKIME_VERSION TEXT("SKKIME1.5(build:%s)")' % datetime.date.today().strftime('%Y%m%d')
	print '#endif'


if __name__ == '__main__':
    main()

