#include "stdafx.h"
#include "skimconf.h"
#include "resource.h"
#include "keymap.h"
#include "varbuffer.h"

/*========================================================================
 *	registry definitions
 */
#define	REGPATH_KEYMAP						TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\Generic")
#define	REGINFO_MAJORMODEMAP				TEXT("MajorModeMap")
#define	REGINFO_JMODEMAP					TEXT("JModeMap")
#define	REGINFO_LATINMODEMAP				TEXT("LatinModeMap")
#define	REGINFO_ZENKAKUMODEMAP				TEXT("Jisx0208LatinModeMap")
#define	REGINFO_ABBREVMODEMAP				TEXT("AbbrevModeMap")
#define	REGINFO_MAJORMODEMAP_EX				TEXT("MajorModeMapEx")
#define	REGINFO_JMODEMAP_EX					TEXT("JModeMapEx")
#define	REGINFO_LATINMODEMAP_EX				TEXT("LatinModeMapEx")
#define	REGINFO_ZENKAKUMODEMAP_EX			TEXT("Jisx0208LatinModeMapEx")
#define	REGINFO_ABBREVMODEMAP_EX			TEXT("AbbrevModeMapEx")
#define	REGINFO_KEYMAP_TYPE					TEXT("KeymapType")

/*	�_�C�A���O�̔z�u�̖��ŁA
 *		- REGINFO_TRYCOMPLETIONKEY_TYPE
 *		- REGINFO_PREVIOUSCOMPLETIONKEY_TYPE
 *		- REGINFO_NEXTCOMPLETIONKEYTYPE
 *	��3��1�܂Ƃ߂Ɉ����B
 *		- skk-kakutei-key,
 *		- skk-previous-candidate-char
 *	�ɂ��ẮA������ skk-insert �̓����ɂ͉B��Ă��Ȃ��̂�
 *	keymap �̑��̐ݒ�ɗ��邱�Ƃɂ���B
 *
 *	(keymap �ŃJ�o�[�ł��Ȃ� skk-insert �̒��ɉB��鑀�삪���)	
 */
/*	#define	REGINFO_KAKUTEIKEY_TYPE				TEXT("KakuteiKeyType")
 *	#define	REGINFO_PREVIOUSCANDIDATECHAR_TYPE	TEXT("PreviousCandidateCharType")
 *	#define	REGINFO_KAKUTEIKEY					TEXT("KakuteiKey")
 *	#define	REGINFO_PREVIOUSCANDIDATECHAR		TEXT("PreviousCandidateChar")
 *	keymap �ɗ���̂ŕs�v�B
 */
#define	REGINFO_STARTHENKANKEY_TYPE			TEXT("StartHenkanKeyType")
#define	REGINFO_STARTHENKANKEY				TEXT("StartHenkanKey")
#define	REGINFO_COMPLETIONRELATEDKEY_TYPE	TEXT("CompletionRelatedKeyType")
#define	REGINFO_TRYCOMPLETIONKEY			TEXT("TryCompletionKey")
#define	REGINFO_PREVIOUSCOMPLETIONKEY		TEXT("PreviousCompletionKey")
#define	REGINFO_NEXTCOMPLETIONKEY			TEXT("NextCompletionKey")
#define	REGINFO_SETHENKANPOINTSUBRKEY_TYPE	TEXT("SetHenkanPointSubrKeyType")
#define	REGINFO_SETHENKANPOINTSUBRKEY		TEXT("SetHenkanPointSubrKey")
#define	REGINFO_SPECIALMIDASHICHAR_TYPE		TEXT("SpecialMidashiCharType")
#define	REGINFO_SPECIALMIDASHICHAR			TEXT("SpecialMidashiChar")

#define	REGPATH_ROMAKANARULE				REGPATH_KEYMAP
#define	REGINFO_ROMAKANARULE_TYPE			TEXT("RomaKanaRuleType")
#define	REGINFO_ROMAKANARULE				TEXT("RomaKanaRule")
#define	REGINFO_ROMAKANARULE1				TEXT("RomaKanaRule1")
#define	REGINFO_ROMAKANARULE2				TEXT("RomaKanaRule2")
#define	REGINFO_ROMAKANARULE3				TEXT("RomaKanaRule3")
#define	REGINFO_JISX0201RULE				TEXT("Jisx0201Rule")
#define	REGINFO_JISX0201RULE1				TEXT("Jisx0201Rule1")
#define	REGINFO_JISX0201RULE2				TEXT("Jisx0201Rule2")
#define	REGINFO_JISX0201RULE3				TEXT("Jisx0201Rule3")
#define	REGINFO_JISX0201ROMANRULE			TEXT("Jisx0201RomanRule")
#define	REGINFO_JISX0201ROMANRULE1			TEXT("Jisx0201RomanRule1")
#define	REGINFO_JISX0201ROMANRULE2			TEXT("Jisx0201RomanRule2")
#define	REGINFO_JISX0201ROMANRULE3			TEXT("Jisx0201RomanRule3")

#define	ENABLE_OHHENKAN_DEFAULT_VALUE		TRUE

#define	REGPATH_ZENKAKUVECTOR				REGPATH_KEYMAP
#define	REGINFO_ZENKAKUVECTOR_TYPE			TEXT("ZenkakuVectorType")
#define	REGINFO_ZENKAKUVECTOR				TEXT("ZenkakuVector")
#define	MAX_LENGTH_INPUTVECTOR				(128)
#define	SIZE_INPUTVECTOR					(128)

#define	REGINFO_EGGLIKENEWLINE				TEXT("EggLikeNewline")
#define	REGINFO_NEWLINEKAKUTEIALL			TEXT("NewlineKakuteiAll")

/*========================================================================
 *	definitions
 */
#define	MAX_KEYBINDS		256
#define	MAX_SPECIALKEYS		64
/* KeyCode(4), Modifier(2), Function(2) */
#define	SIZE_PER_1EXTRAKEY	(4+2+2)
#define	NUM_KEYMAPS			5

enum {
	KEYBINDTP_DEFAULT		= 0,
	KEYBINDTP_USERDEFINED,
} ;

#define	ROMAKANALIST_SHORT_LEN	8
#define	ROMAKANALIST_LONG_LEN	256

#define	NUM_ROMAKANARULE	4

enum {
	ROMAKANARULE_TYPE1	= 0,
	ROMAKANARULE_TYPE2,
	ROMAKANARULE_TYPE3,
} ;

enum {
	ROMAKANA_SHOW_HIRA	= 0,
	ROMAKANA_SHOW_KATA,
	ROMAKANA_SHOW_BOTH,
} ;

enum {
	KEYBIND_SHOW_STARTHENKANKEYS		= 0,
	KEYBIND_SHOW_TRYCOMPLETIONKEYS,
	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS,
	KEYBIND_SHOW_NEXTCOMPLETIONKEYS,
	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS,
	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS,
} ;

/*========================================================================
 *	structures
 */
struct CImeKeyBind {
	short				m_nKeyCode ;
	unsigned short		m_uKeyMask ;		/* CONTROL | SHIFT | ALT ���炢���H */
	int					m_nKeyFunction ;	/* �@�\�B*/
} ;

struct CImeKeymap {
	BYTE				m_rbyBaseMap [MAX_KEYBINDS] ;	/* 128 ���Bdefault */
	int					m_nKeyBinds ;	/* �ǉ��B�������݂���΁B*/
	struct CImeKeyBind*	m_pKeyBinds ;
} ;

enum {
	KEYMAP_INDEX_MAJOR	= 0,
	KEYMAP_INDEX_JMODE,
	KEYMAP_INDEX_LATIN,
	KEYMAP_INDEX_JISX0208LATIN,
	KEYMAP_INDEX_ABBREV,
} ;

struct TEditKeymapArg {
	struct CImeKeymap	m_rKeymaps [NUM_KEYMAPS] ;
//	struct CImeKeymap	m_MajorModeMap ;
//	struct CImeKeymap	m_JModeMap ;
//	struct CImeKeymap	m_LatinModeMap ;
//	struct CImeKeymap	m_Jisx0208LatinModeMap ;
//	struct CImeKeymap	m_AbbrevModeMap ;
} ;

struct TDlgEditKeyBindArg {
	UINT	m_uKey ;
	BYTE	m_rbKeyBinds [NUM_KEYMAPS] ;
	const struct CImeKeymap*	m_rpMasterKeymaps [NUM_KEYMAPS] ;
} ;

/*	��ԑJ�ڂɓ���ȈӖ������L����ǉ��������̂ŁA���̕\�L���@�ɂ��čl����B
 *	�D��x���Œ�� default rule ���~�����̂ŁA������c
 *		\?
 *	�ŏ������H wildcard ��1������v�ɂ��킹�āB(���K�\���������o���ƃJ�I�X���c)
 *	�\���̎��ɃI���W�i���� backslash �̈����ɒ��ӁB(�����ł͕\���Ƃ��Ƃ� backslash
 *	�̈����̖��ɗ����邾��)
 */
struct TSkkBaseRuleT1 {
	LPCTSTR	_strState ;
	LPCTSTR	_strNext ;
	int		_iNextRule ;
	struct {
		LPCTSTR	_strKata ;
		LPCTSTR	_strHira ;
	}	_case ;
} ;

struct TSkkBaseRuleT2 {
	LPCTSTR	_strState ;
	LPCTSTR	_strNext ;
	int		_iNextRule ;
	LPCTSTR	_strOutput ;
} ;

struct TSkkBaseRuleT3 {
	LPCTSTR	_strState ;
	LPCTSTR	_strNext ;
	int		_iNextRule ;
	int		_nFunction ;
} ;

struct TSkkBaseRuleNode {
	int		_nType ;	/* type1 or type2 or type3 */
	union {
		struct TSkkBaseRuleT1	_T1 ;
		struct TSkkBaseRuleT2	_T2 ;
		struct TSkkBaseRuleT3	_T3 ;
	} ;

	struct TSkkBaseRuleNode*	_pNext ;
} ;

struct TCustomRomaKanaRuleArg {
	struct TSkkBaseRuleNode*	m_rplstRomaKanaRules		[NUM_ROMAKANARULE] ;
	struct TSkkBaseRuleNode*	m_rplstJisx0201KanaRules	[NUM_ROMAKANARULE] ;
	struct TSkkBaseRuleNode*	m_rplstJisx0201RomanRules	[NUM_ROMAKANARULE] ;
	int							m_iShownRule ;
} ;

struct TEditRomaKanaRuleArg {
	struct TSkkBaseRuleNode*	m_pInitValue ;
	int		m_nType ;
	TCHAR	m_bufState			[ROMAKANALIST_LONG_LEN] ;
	int		m_iRule ; 
	TCHAR	m_bufNextState		[ROMAKANALIST_LONG_LEN] ;
	int		m_iNextRule ; 
	TCHAR	m_bufHiraOrCommon	[ROMAKANALIST_LONG_LEN] ;
	TCHAR	m_bufKata			[ROMAKANALIST_LONG_LEN] ;
	int		m_nFunction ;
	BOOL	m_bEnableRule1 ;
} ;

struct TCustomSpecialKeybindArg {
	BOOL	m_bStartHenkanKeysModified ;
	int		m_iNumStartHenkanKeys ;
	BYTE	m_bufStartHenkanKeys			[MAX_SPECIALKEYS] ;

	BOOL	m_bCompletionKeysModified ;
	int		m_iNumTryCompletionKeys ;
	BYTE	m_bufTryCompletionKeys			[MAX_SPECIALKEYS] ;
	int		m_iNumPreviousCompletionKeys ;
	BYTE	m_bufPreviousCompletionKeys		[MAX_SPECIALKEYS] ;
	int		m_iNumNextCompletionKeys ;
	BYTE	m_bufNextCompletionKeys			[MAX_SPECIALKEYS] ;

	BOOL	m_bSetHenkanPointSubrKeysModified ;
	int		m_iNumSetHenkanPointSubrKeys ;
	BYTE	m_bufSetHenkanPointSubrKeys		[MAX_SPECIALKEYS] ;

	BOOL	m_bSpecialMidashiCharKeysModified ;
	int		m_iNumSpecialMidashiCharKeys ;
	BYTE	m_bufSpecialMidashiCharKeys		[MAX_SPECIALKEYS] ;
} ;

/* �S�p�x�N�g�� */
struct TEditZenkakuVectorArg {
	LPTSTR		m_rpZenkakuVector [SIZE_INPUTVECTOR] ;
} ;

struct TEditZenkakuVectorEntryArg {
	int		m_iChara ;
	TCHAR	m_bufText [SIZE_INPUTVECTOR] ;
} ;

/*========================================================================
 *	prototypes
 */
static	LRESULT	dlgKeybind_lOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	LRESULT	dlgKeybind_lOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgKeybind_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void	dlgKeybind_vSyncControls	(HWND) ;

static	void	dlgKeybind_vEditRomaKanaRule	(HWND) ;
static	void	dlgKeybind_vEditKeymap			(HWND) ;
static	void	dlgKeybind_vEditSpecialKey		(HWND) ;
static	void	dlgKeybind_vEditZenkakuVector	(HWND) ;

static	void	dlgKeybind_vLoadConfig			(HWND, BOOL) ;
static	BOOL	dlgKeybind_bSaveConfig			(void) ;
static	void	dlgKeybind_vInitializeDefaultMajorModeMap			(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultJModeMap				(struct CImeKeymap*, const struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultLatinModeMap			(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultJisx0208LatinModeMap	(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultAbbrevModeMap			(struct CImeKeymap*, const struct CImeKeymap*) ;
static	void	dlgKeybind_vCloneKeymap								(struct CImeKeymap*, const struct CImeKeymap*) ;
static	void	dlgKeyBind_vClearKeymap								(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultStartHenkanKey			(BYTE*, int*) ;
static	void	dlgKeybind_vInitializeDefaultCompletinoRelatedKey	(BYTE*, int*, BYTE*, int*, BYTE*, int*) ;
static	void	dlgKeybind_vInitializeDefaultSetHenkanPointSubrKey (BYTE*, int*) ;
static	void	dlgKeybind_vInitializeDefaultSpecialMidashiCharKey (BYTE*, int*) ;

static	INT_PTR	CALLBACK	dlgEditKeyBindProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgRomaKanaRuleProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgJisx0201RuleProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditSpecialKeybindProc	(HWND, UINT, WPARAM, LPARAM) ;

/* ���[�}�����ȃ��[���̐ݒ�B*/
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pCreateType1Rule (LPCTSTR, LPCTSTR, int, LPCTSTR, LPCTSTR) ;
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pCreateType2Rule (LPCTSTR, LPCTSTR, int, LPCTSTR) ;
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pCreateType3Rule (LPCTSTR, LPCTSTR, int, int) ;
static	void	dlgRomaKanaRule_vRegisterRule			(struct TSkkBaseRuleNode**, struct TSkkBaseRuleNode*) ;
static	BOOL	dlgRomaKanaRule_bUnegisterRule			(struct TSkkBaseRuleNode**, struct TSkkBaseRuleNode*) ;
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pSearchRuleByState	(struct TSkkBaseRuleNode*, LPCTSTR, BOOL) ;
static	struct TSkkBaseRuleNode*	pCopyRomaKanaRuleList	(struct TSkkBaseRuleNode*) ;
static	void	dlgRomaKanaRule_vClearAllRules			(struct TSkkBaseRuleNode**) ;
static	void	dlgRomaKanaRule_vInitializeDefaultRomaKanaRule (struct TSkkBaseRuleNode**) ;
static	void	dlgRomaKanaRule_vInitializeDefaultJisx0201KanaRule (struct TSkkBaseRuleNode**) ;
static	void	dlgRomaKanaRule_vInitializeDefaultJisx0201RomanRule (struct TSkkBaseRuleNode**) ;

static	void	dlgRomaKanaRule_vGetEntryString			(LPTSTR, int, const struct TSkkBaseRuleNode*, int, int, BOOL) ;
static	void	dlgRomaKanaRule_vGetType1EntryString	(LPTSTR, int, const struct TSkkBaseRuleT1*, int, int, BOOL) ;
static	void	dlgRomaKanaRule_vGetType2EntryString	(LPTSTR, int, const struct TSkkBaseRuleT2*, int, BOOL) ;
static	void	dlgRomaKanaRule_vGetType3EntryString	(LPTSTR, int, const struct TSkkBaseRuleT3*, int, BOOL) ;

/* �S�p�x�N�g���̐ݒ�B*/
static	INT_PTR	CALLBACK	dlgZenkakuVectorProc (HWND, UINT, WPARAM, LPARAM) ;
static	BOOL		dlgKeybind_bLoadZenkakuVector		(void) ;
static	BOOL		dlgKeybind_bSaveZenkakuVector		(void) ;
static	void		dlgKeybind_vClearZenkakuVector		(void) ;

/*========================================================================
 *	global variables (default value)
 */
static	LPTSTR		_rstrDefaultSkkJisx0208LatinVector [SIZE_INPUTVECTOR]	= {
	NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,
	NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,
	NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,
	NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,		NULL,
	TEXT("�@"),	TEXT("�I"),	TEXT("�h"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("�f"),
	TEXT("�i"),	TEXT("�j"),	TEXT("��"),	TEXT("�{"),	TEXT("�C"),	TEXT("�|"),	TEXT("�D"),	TEXT("�^"),
	TEXT("�O"),	TEXT("�P"),	TEXT("�Q"),	TEXT("�R"),	TEXT("�S"),	TEXT("�T"),	TEXT("�U"),	TEXT("�V"),
	TEXT("�W"),	TEXT("�X"),	TEXT("�F"),	TEXT("�G"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("�H"),
	TEXT("��"),	TEXT("�`"),	TEXT("�a"),	TEXT("�b"),	TEXT("�c"),	TEXT("�d"),	TEXT("�e"),	TEXT("�f"),
	TEXT("�g"),	TEXT("�h"),	TEXT("�i"),	TEXT("�j"),	TEXT("�k"),	TEXT("�l"),	TEXT("�m"),	TEXT("�n"),
	TEXT("�o"),	TEXT("�p"),	TEXT("�q"),	TEXT("�r"),	TEXT("�s"),	TEXT("�t"),	TEXT("�u"),	TEXT("�v"),
	TEXT("�w"),	TEXT("�x"),	TEXT("�y"),	TEXT("�m"),	TEXT("�_"),	TEXT("�n"),	TEXT("�O"),	TEXT("�Q"),
	TEXT("�e"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),
	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),
	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("��"),
	TEXT("��"),	TEXT("��"),	TEXT("��"),	TEXT("�o"),	TEXT("�b"),	TEXT("�p"),	TEXT("�`"),	NULL,
} ;

static const struct TSkkBaseRuleT1	_rDefaultRomaKanaRuleType1 []	= {
	{ TEXT("a"),	NULL,		0,	{ TEXT("�A"),	TEXT("��") } },
	{ TEXT("bb"),	TEXT("b"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ba"),	NULL,		0,	{ TEXT("�o"),	TEXT("��") } },
	{ TEXT("be"),	NULL,		0,	{ TEXT("�x"),	TEXT("��") } },		{ TEXT("bi"),	NULL,		0,	{ TEXT("�r"),	TEXT("��") } },
	{ TEXT("bo"),	NULL,		0,	{ TEXT("�{"),	TEXT("��") } },		{ TEXT("bu"),	NULL,		0,	{ TEXT("�u"),	TEXT("��") } },
    { TEXT("bya"),	NULL,		0,	{ TEXT("�r��"),	TEXT("�т�") } },	{ TEXT("bye"),	NULL,		0,	{ TEXT("�r�F"),	TEXT("�т�") } },
	{ TEXT("byi"),	NULL,		0,	{ TEXT("�r�B"),	TEXT("�т�") } },	{ TEXT("byo"),	NULL,		0,	{ TEXT("�r��"),	TEXT("�т�") } },
	{ TEXT("byu"),	NULL,		0,	{ TEXT("�r��"),	TEXT("�т�") } },
	{ TEXT("cc"),	TEXT("c"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("cha"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },
    { TEXT("che"),	NULL,		0,	{ TEXT("�`�F"),	TEXT("����") } },	{ TEXT("chi"),	NULL,		0,	{ TEXT("�`"),	TEXT("��") } },
    { TEXT("cho"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },	{ TEXT("chu"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },
	{ TEXT("cya"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },	{ TEXT("cye"),	NULL,		0,	{ TEXT("�`�F"),	TEXT("����") } },
	{ TEXT("cyi"),	NULL,		0,	{ TEXT("�`�B"),	TEXT("����") } },	{ TEXT("cyo"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },
	{ TEXT("cyu"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },
	{ TEXT("dd"),	TEXT("d"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("da"),	NULL,		0,	{ TEXT("�_"),	TEXT("��") } },
	{ TEXT("de"),	NULL,		0,	{ TEXT("�f"),	TEXT("��") } },		{ TEXT("dha"),	NULL,		0,	{ TEXT("�f��"),	TEXT("�ł�") } },
	{ TEXT("dhe"),	NULL,		0,	{ TEXT("�f�F"),	TEXT("�ł�") } },	{ TEXT("dhi"),	NULL,		0,	{ TEXT("�f�B"),	TEXT("�ł�") } },
	{ TEXT("dho"),	NULL,		0,	{ TEXT("�f��"),	TEXT("�ł�") } },	{ TEXT("dhu"),	NULL,		0,	{ TEXT("�f��"),	TEXT("�ł�") } },
	{ TEXT("di"),	NULL,		0,	{ TEXT("�a"),	TEXT("��") } },		{ TEXT("do"),	NULL,		0,	{ TEXT("�h"),	TEXT("��") } },
	{ TEXT("du"),	NULL,		0,	{ TEXT("�d"),	TEXT("��") } },		{ TEXT("dya"),	NULL,		0,	{ TEXT("�a��"),	TEXT("����") } },
	{ TEXT("dye"),	NULL,		0,	{ TEXT("�a�F"),	TEXT("����") } },	{ TEXT("dyi"),	NULL,		0,	{ TEXT("�a�B"),	TEXT("����") } },
	{ TEXT("dyo"),	NULL,		0,	{ TEXT("�a��"),	TEXT("����") } },	{ TEXT("dyu"),	NULL,		0,	{ TEXT("�a��"),	TEXT("����") } },
	{ TEXT("e"),	NULL,		0,	{ TEXT("�G"),	TEXT("��") } },
	{ TEXT("ff"),	TEXT("f"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("fa"),	NULL,		0,	{ TEXT("�t�@"),	TEXT("�ӂ�") } },
	{ TEXT("fe"),	NULL,		0,	{ TEXT("�t�F"),	TEXT("�ӂ�") } },	{ TEXT("fi"),	NULL,		0,	{ TEXT("�t�B"),	TEXT("�ӂ�") } },
	{ TEXT("fo"),	NULL,		0,	{ TEXT("�t�H"),	TEXT("�ӂ�") } },	{ TEXT("fu"),	NULL,		0,	{ TEXT("�t"),	TEXT("��") } },
	{ TEXT("fya"),	NULL,		0,	{ TEXT("�t��"),	TEXT("�ӂ�") } },	{ TEXT("fye"),	NULL,		0,	{ TEXT("�t�F"),	TEXT("�ӂ�") } },
	{ TEXT("fyi"),	NULL,		0,	{ TEXT("�t�B"),	TEXT("�ӂ�") } },	{ TEXT("fyo"),	NULL,		0,	{ TEXT("�t��"),	TEXT("�ӂ�") } },
	{ TEXT("fyu"),	NULL,		0,	{ TEXT("�t��"),	TEXT("�ӂ�") } },
	{ TEXT("gg"),	TEXT("g"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ga"),	NULL,		0,	{ TEXT("�K"),	TEXT("��") } },
	{ TEXT("ge"),	NULL,		0,	{ TEXT("�Q"),	TEXT("��") } },		{ TEXT("gi"),	NULL,		0,	{ TEXT("�M"),	TEXT("��") } },
	{ TEXT("go"),	NULL,		0,	{ TEXT("�S"),	TEXT("��") } },		{ TEXT("gu"),	NULL,		0,	{ TEXT("�O"),	TEXT("��") } },
	{ TEXT("gya"),	NULL,		0,	{ TEXT("�M��"),	TEXT("����") } },	{ TEXT("gye"),	NULL,		0,	{ TEXT("�M�F"),	TEXT("����") } },
	{ TEXT("gyi"),	NULL,		0,	{ TEXT("�M�B"),	TEXT("����") } },	{ TEXT("gyo"),	NULL,		0,	{ TEXT("�M��"),	TEXT("����") } },
	{ TEXT("gyu"),	NULL,		0,	{ TEXT("�M��"),	TEXT("����") } },
	{ TEXT("hh"),	TEXT("h"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ha"),	NULL,		0,	{ TEXT("�n"),	TEXT("��") } },	
	{ TEXT("he"),	NULL,		0,	{ TEXT("�w"),	TEXT("��") } },		{ TEXT("hi"),	NULL,		0,	{ TEXT("�q"),	TEXT("��") } },	
	{ TEXT("ho"),	NULL,		0,	{ TEXT("�z"),	TEXT("��") } },		{ TEXT("hu"),	NULL,		0,	{ TEXT("�t"),	TEXT("��") } },	
	{ TEXT("hya"),	NULL,		0,	{ TEXT("�q��"),	TEXT("�Ђ�") } },	{ TEXT("hye"),	NULL,		0,	{ TEXT("�q�F"),	TEXT("�Ђ�") } },
	{ TEXT("hyi"),	NULL,		0,	{ TEXT("�q�B"),	TEXT("�Ђ�") } },	{ TEXT("hyo"),	NULL,		0,	{ TEXT("�q��"),	TEXT("�Ђ�") } },
	{ TEXT("hyu"),	NULL,		0,	{ TEXT("�q��"),	TEXT("�Ђ�") } },
	{ TEXT("i"),	NULL,		0,	{ TEXT("�C"),	TEXT("��") } },	
	{ TEXT("jj"),	TEXT("j"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ja"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },	
	{ TEXT("je"),	NULL,		0,	{ TEXT("�W�F"),	TEXT("����") } },	{ TEXT("ji"),	NULL,		0,	{ TEXT("�W"),	TEXT("��") } },	
	{ TEXT("jo"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },	{ TEXT("ju"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },
	{ TEXT("jya"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },	{ TEXT("jye"),	NULL,		0,	{ TEXT("�W�F"),	TEXT("����") } },
	{ TEXT("jyi"),	NULL,		0,	{ TEXT("�W�B"),	TEXT("����") } },	{ TEXT("jyo"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },	
	{ TEXT("jyu"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },
	{ TEXT("kk"),	TEXT("k"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ka"),	NULL,		0,	{ TEXT("�J"),	TEXT("��") } },
	{ TEXT("ke"),	NULL,		0,	{ TEXT("�P"),	TEXT("��") } },		{ TEXT("ki"),	NULL,		0,	{ TEXT("�L"),	TEXT("��") } },
	{ TEXT("ko"),	NULL,		0,	{ TEXT("�R"),	TEXT("��") } },		{ TEXT("ku"),	NULL,		0,	{ TEXT("�N"),	TEXT("��") } },
	{ TEXT("kya"),	NULL,		0,	{ TEXT("�L��"),	TEXT("����") } },	{ TEXT("kye"),	NULL,		0,	{ TEXT("�L�F"),	TEXT("����") } },
	{ TEXT("kyi"),	NULL,		0,	{ TEXT("�L�B"),	TEXT("����") } },	{ TEXT("kyo"),	NULL,		0,	{ TEXT("�L��"),	TEXT("����") } },
	{ TEXT("kyu"),	NULL,		0,	{ TEXT("�L��"),	TEXT("����") } },
	{ TEXT("mm"),	TEXT("m"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ma"),	NULL,		0,	{ TEXT("�}"),	TEXT("��") } },
	{ TEXT("me"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("mi"),	NULL,		0,	{ TEXT("�~"),	TEXT("��") } },
	{ TEXT("mo"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("mu"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("mya"),	NULL,		0,	{ TEXT("�~��"),	TEXT("�݂�") } },	{ TEXT("mye"),	NULL,		0,	{ TEXT("�~�F"),	TEXT("�݂�") } },
	{ TEXT("myi"),	NULL,		0,	{ TEXT("�~�B"),	TEXT("�݂�") } },	{ TEXT("myo"),	NULL,		0,	{ TEXT("�~��"),	TEXT("�݂�") } },
	{ TEXT("myu"),	NULL,		0,	{ TEXT("�~��"),	TEXT("�݂�") } },
	{ TEXT("n"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("n'"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("na"),	NULL,		0,	{ TEXT("�i"),	TEXT("��") } },		{ TEXT("ne"),	NULL,		0,	{ TEXT("�l"),	TEXT("��") } },
	{ TEXT("ni"),	NULL,		0,	{ TEXT("�j"),	TEXT("��") } },		{ TEXT("nn"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("no"),	NULL,		0,	{ TEXT("�m"),	TEXT("��") } },		{ TEXT("nu"),	NULL,		0,	{ TEXT("�k"),	TEXT("��") } },
	{ TEXT("nya"),	NULL,		0,	{ TEXT("�j��"),	TEXT("�ɂ�") } },	{ TEXT("nye"),	NULL,		0,	{ TEXT("�j�F"),	TEXT("�ɂ�") } },
	{ TEXT("nyi"),	NULL,		0,	{ TEXT("�j�B"),	TEXT("�ɂ�") } },	{ TEXT("nyo"),	NULL,		0,	{ TEXT("�j��"),	TEXT("�ɂ�") } },
	{ TEXT("nyu"),	NULL,		0,	{ TEXT("�j��"),	TEXT("�ɂ�") } },
	{ TEXT("o"),	NULL,		1,	{ TEXT("�I"),	TEXT("��") } },
	{ TEXT("pp"),	TEXT("p"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("pa"),	NULL,		0,	{ TEXT("�p"),	TEXT("��") } },
	{ TEXT("pe"),	NULL,		0,	{ TEXT("�y"),	TEXT("��") } },		{ TEXT("pi"),	NULL,		0,	{ TEXT("�s"),	TEXT("��") } },
	{ TEXT("po"),	NULL,		0,	{ TEXT("�|"),	TEXT("��") } },		{ TEXT("pu"),	NULL,		0,	{ TEXT("�v"),	TEXT("��") } },
	{ TEXT("pya"),	NULL,		0,	{ TEXT("�s��"),	TEXT("�҂�") } },	{ TEXT("pye"),	NULL,		0,	{ TEXT("�s�F"),	TEXT("�҂�") } },
	{ TEXT("pyi"),	NULL,		0,	{ TEXT("�s�B"),	TEXT("�҂�") } },	{ TEXT("pyo"),	NULL,		0,	{ TEXT("�s��"),	TEXT("�҂�") } },
	{ TEXT("pyu"),	NULL,		0,	{ TEXT("�s��"),	TEXT("�҂�") } },
	{ TEXT("rr"),	TEXT("r"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ra"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("re"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("ri"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("ro"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("ru"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("rya"),	NULL,		0,	{ TEXT("����"),	TEXT("���") } },	{ TEXT("rye"),	NULL,		0,	{ TEXT("���F"),	TEXT("�肥") } },
	{ TEXT("ryi"),	NULL,		0,	{ TEXT("���B"),	TEXT("�股") } },	{ TEXT("ryo"),	NULL,		0,	{ TEXT("����"),	TEXT("���") } },
	{ TEXT("ryu"),	NULL,		0,	{ TEXT("����"),	TEXT("���") } },
	{ TEXT("ss"),	TEXT("s"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("sa"),	NULL,		0,	{ TEXT("�T"),	TEXT("��") } },
	{ TEXT("se"),	NULL,		0,	{ TEXT("�Z"),	TEXT("��") } },		{ TEXT("sha"),	NULL,		0,	{ TEXT("�V��"),	TEXT("����") } },
	{ TEXT("she"),	NULL,		0,	{ TEXT("�V�F"),	TEXT("����") } },	{ TEXT("shi"),	NULL,		0,	{ TEXT("�V"),	TEXT("��") } },
	{ TEXT("sho"),	NULL,		0,	{ TEXT("�V��"),	TEXT("����") } },	{ TEXT("shu"),	NULL,		0,	{ TEXT("�V��"),	TEXT("����") } },
	{ TEXT("si"),	NULL,		0,	{ TEXT("�V"),	TEXT("��") } },		{ TEXT("so"),	NULL,		0,	{ TEXT("�\"),	TEXT("��") } },
	{ TEXT("su"),	NULL,		0,	{ TEXT("�X"),	TEXT("��") } },		{ TEXT("sya"),	NULL,		0,	{ TEXT("�V��"),	TEXT("����") } },
	{ TEXT("sye"),	NULL,		0,	{ TEXT("�V�F"),	TEXT("����") } },	{ TEXT("syi"),	NULL,		0,	{ TEXT("�V�B"),	TEXT("����") } },
	{ TEXT("syo"),	NULL,		0,	{ TEXT("�V��"),	TEXT("����") } },	{ TEXT("syu"),	NULL,		0,	{ TEXT("�V��"),	TEXT("����") } },
	{ TEXT("tt"),	TEXT("t"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ta"),	NULL,		0,	{ TEXT("�^"),	TEXT("��") } },
	{ TEXT("te"),	NULL,		0,	{ TEXT("�e"),	TEXT("��") } },		{ TEXT("tha"),	NULL,		0,	{ TEXT("�e�@"),	TEXT("�Ă�") } },
	{ TEXT("the"),	NULL,		0,	{ TEXT("�e�F"),	TEXT("�Ă�") } },	{ TEXT("thi"),	NULL,		0,	{ TEXT("�e�B"),	TEXT("�Ă�") } },
	{ TEXT("tho"),	NULL,		0,	{ TEXT("�e��"),	TEXT("�Ă�") } },	{ TEXT("thu"),	NULL,		0,	{ TEXT("�e��"),	TEXT("�Ă�") } },
	{ TEXT("ti"),	NULL,		0,	{ TEXT("�`"),	TEXT("��") } },		{ TEXT("to"),	NULL,		0,	{ TEXT("�g"),	TEXT("��") } },
	{ TEXT("tsu"),	NULL,		0,	{ TEXT("�c"),	TEXT("��") } },		{ TEXT("tu"),	NULL,		0,	{ TEXT("�c"),	TEXT("��") } },
	{ TEXT("tya"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },	{ TEXT("tye"),	NULL,		0,	{ TEXT("�`�F"),	TEXT("����") } },
	{ TEXT("tyi"),	NULL,		0,	{ TEXT("�`�B"),	TEXT("����") } },	{ TEXT("tyo"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },
	{ TEXT("tyu"),	NULL,		0,	{ TEXT("�`��"),	TEXT("����") } },
	{ TEXT("u"),	NULL,		0,	{ TEXT("�E"),	TEXT("��") } },
	{ TEXT("vv"),	TEXT("v"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("va"),	NULL,		0,	{ TEXT("���@"),	TEXT("���J��") } },
	{ TEXT("ve"),	NULL,		0,	{ TEXT("���F"),	TEXT("���J��") } },	{ TEXT("vi"),	NULL,		0,	{ TEXT("���B"),	TEXT("���J��") } },
	{ TEXT("vo"),	NULL,		0,	{ TEXT("���H"),	TEXT("���J��") } },	{ TEXT("vu"),	NULL,		0,	{ TEXT("��"),	TEXT("���J") } },
	{ TEXT("ww"),	TEXT("w"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("wa"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("we"),	NULL,		0,	{ TEXT("�E�F"),	TEXT("����") } },	{ TEXT("wi"),	NULL,		0,	{ TEXT("�E�B"),	TEXT("����") } },
	{ TEXT("wo"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("wu"),	NULL,		0,	{ TEXT("�E"),	TEXT("��") } },
	{ TEXT("xx"),	TEXT("x"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("xa"),	NULL,		0,	{ TEXT("�@"),	TEXT("��") } },
	{ TEXT("xe"),	NULL,		0,	{ TEXT("�F"),	TEXT("��") } },		{ TEXT("xi"),	NULL,		0,	{ TEXT("�B"),	TEXT("��") } },
	{ TEXT("xka"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("xke"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("xo"),	NULL,		0,	{ TEXT("�H"),	TEXT("��") } },		{ TEXT("xtsu"),	NULL,		0,	{ TEXT("�b"),	TEXT("��") } },
	{ TEXT("xtu"),	NULL,		0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("xu"),	NULL,		0,	{ TEXT("�D"),	TEXT("��") } },
	{ TEXT("xwa"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("xwe"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("xwi"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("xya"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("xyo"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },		{ TEXT("xyu"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("yy"),	TEXT("y"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("ya"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("ye"),	NULL,		0,	{ TEXT("�C�F"),	TEXT("����") } },	{ TEXT("yo"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("yu"),	NULL,		0,	{ TEXT("��"),	TEXT("��") } },
	{ TEXT("zz"),	TEXT("z"),	0,	{ TEXT("�b"),	TEXT("��") } },		{ TEXT("za"),	NULL,		0,	{ TEXT("�U"),	TEXT("��") } },
	{ TEXT("ze"),	NULL,		0,	{ TEXT("�["),	TEXT("��") } },		{ TEXT("zi"),	NULL,		0,	{ TEXT("�W"),	TEXT("��") } },
	{ TEXT("zo"),	NULL,		0,	{ TEXT("�]"),	TEXT("��") } },		{ TEXT("zu"),	NULL,		0,	{ TEXT("�Y"),	TEXT("��") } },
	{ TEXT("zya"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },	{ TEXT("zye"),	NULL,		0,	{ TEXT("�W�F"),	TEXT("����") } },
	{ TEXT("zyi"),	NULL,		0,	{ TEXT("�W�B"),	TEXT("����") } },	{ TEXT("zyo"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },
	{ TEXT("zyu"),	NULL,		0,	{ TEXT("�W��"),	TEXT("����") } },
} ;

static const struct TSkkBaseRuleT2	_rDefaultRomaKanaRuleType2 []	= {
	{ TEXT("z,"),	NULL,	0,	TEXT("�d") },	{ TEXT("z-"),	NULL,	0,	TEXT("�`") },
	{ TEXT("z."),	NULL,	0,	TEXT("�c") },	{ TEXT("z/"),	NULL,	0,	TEXT("�E") },
	{ TEXT("z["),	NULL,	0,	TEXT("�w") },	{ TEXT("z]"),	NULL,	0,	TEXT("�x") },
    { TEXT("zh"),	NULL,	0,	TEXT("��") },	{ TEXT("zj"),	NULL,	0,	TEXT("��") }, 
	{ TEXT("zk"),	NULL,	0,	TEXT("��") },	{ TEXT("zl"),	NULL,	0,	TEXT("��") },
	{ TEXT("-"),	NULL,	0,	TEXT("�[") },	{ TEXT(":"),	NULL,	0,	TEXT("�F") },
    { TEXT(";"),	NULL,	0,	TEXT("�G") },	{ TEXT("?"),	NULL,	0,	TEXT("�H") }, 
	{ TEXT("["),	NULL,	0,	TEXT("�u") },	{ TEXT("]"),	NULL,	0,	TEXT("�v") },
} ;

static const struct TSkkBaseRuleT3	_rDefaultRomaKanaRuleType3 []	= {
	{ TEXT("."),	NULL,	0,	NFUNC_SKK_CURRENT_KUTEN },
	{ TEXT(","),	NULL,	0,	NFUNC_SKK_CURRENT_TOUTEN },
	{ TEXT("l"),	NULL,	0,	NFUNC_SKK_LATIN_MODE },	
	{ TEXT("q"),	NULL,	0,	NFUNC_SKK_TOGGLE_KANA },
	{ TEXT("L"),	NULL,	0,	NFUNC_SKK_JISX0208_LATIN_MODE },
	{ TEXT("Q"),	NULL,	0,	NFUNC_SKK_SET_HENKAN_POINT_SUBR },
	{ TEXT("X"),	NULL,	0,	NFUNC_SKK_PURGE_FROM_JISYO },
	{ TEXT("/"),	NULL,	0,	NFUNC_SKK_ABBREV_MODE },
	{ TEXT("$"),	NULL,	0,	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT },
	{ TEXT("@"),	NULL,	0,	NFUNC_SKK_TODAY },
	{ TEXT("\\\\"),	NULL,	0,	NFUNC_SKK_INPUT_BY_CODE_OR_MENU },	/* \\ ���� \\\\ �ɏC��(�����\��N�\�ꌎ��\�O��(��)) */
	{ TEXT("\r"),	NULL,	0,	NFUNC_SKK_KAKUTEI },
} ;

static const struct TSkkBaseRuleT1	_rDefaultRomaKanaRuleType1_1 []	= {
	{ TEXT("h\\C"),	TEXT("\\I"),	0,	{ TEXT("�I"),	TEXT("��") } },

	/*	�Ή����郋�[�����Ȃ������ꍇ�ɂ̓��[���O�̂��̂�p����B
	 */
	{ TEXT("\\?"),	TEXT("\\I"),	0,	{ TEXT(""),		TEXT("") } },
	{ TEXT("h\\?"),	TEXT("h\\I"),	0,	{ TEXT(""),		TEXT("") } },
} ;

static struct TSkkBaseRuleT2	_rDefaultJisx0201KanaRuleType2 []	= {
	{ L"a",		NULL, 0, L"�", }, 
    { L"bb",	L"b", 0, L"�", },	{ L"ba",	NULL, 0, L"��", },	{ L"be",	NULL, 0, L"��", }, 
    { L"bi",	NULL, 0, L"��", },	{ L"bo",	NULL, 0, L"��", },	{ L"bu",	NULL, 0, L"��", },	{ L"bya",	NULL, 0, L"�ެ", }, 
    { L"bye",	NULL, 0, L"�ު", },	{ L"byi",	NULL, 0, L"�ި", },	{ L"byo",	NULL, 0, L"�ޮ", },	{ L"byu",	NULL, 0, L"�ޭ", }, 
    { L"cc",	L"c", 0, L"�", },	{ L"cha",	NULL, 0, L"��", },	{ L"che",	NULL, 0, L"��", },	{ L"chi",	NULL, 0, L"�", }, 
    { L"cho",	NULL, 0, L"��", },  { L"chu",	NULL, 0, L"��", },	{ L"cya",	NULL, 0, L"��", },	{ L"cye",	NULL, 0, L"��", }, 
    { L"cyi",	NULL, 0, L"��", },  { L"cyo",	NULL, 0, L"��", },	{ L"cyu",	NULL, 0, L"��", }, 
    { L"dd",	L"d", 0, L"�", },	{ L"da",	NULL, 0, L"��", },	{ L"de",	NULL, 0, L"��", },	{ L"dha",	NULL, 0, L"�ެ", }, 
    { L"dhe",	NULL, 0, L"�ު", },	{ L"dhi",	NULL, 0, L"�ި", },	{ L"dho",	NULL, 0, L"�ޮ", },	{ L"dhu",	NULL, 0, L"�ޭ", }, 
    { L"di",	NULL, 0, L"��", },	{ L"do",	NULL, 0, L"��", },	{ L"du",	NULL, 0, L"��", },	{ L"dya",	NULL, 0, L"�ެ", }, 
    { L"dye",	NULL, 0, L"�ު", },	{ L"dyi",	NULL, 0, L"�ި", },	{ L"dyo",	NULL, 0, L"�ޮ", },	{ L"dyu",	NULL, 0, L"�ޭ", }, 
    { L"e",		NULL, 0, L"�", }, 
    { L"ff",	L"f", 0, L"�", },	{ L"fa",	NULL, 0, L"̧", },  { L"fe",	NULL, 0, L"̪", },  { L"fi",	NULL, 0, L"̨", }, 
    { L"fo",	NULL, 0, L"̫", },  { L"fu",	NULL, 0, L"�", },	{ L"fya",	NULL, 0, L"̬", },  { L"fye",	NULL, 0, L"̪", }, 
    { L"fyi",	NULL, 0, L"̨", },  { L"fyo",	NULL, 0, L"̮", },  { L"fyu",	NULL, 0, L"̭", },  { L"gg",	L"g", 0, L"�", }, 
    { L"ga",	NULL, 0, L"��", },  { L"ge",	NULL, 0, L"��", },  { L"gi",	NULL, 0, L"��", },  { L"go",	NULL, 0, L"��", }, 
    { L"gu",	NULL, 0, L"��", },  { L"gya",	NULL, 0, L"�ެ", },	{ L"gye",	NULL, 0, L"�ު", },	{ L"gyi",	NULL, 0, L"�ި", }, 
    { L"gyo",	NULL, 0, L"�ޮ", },	{ L"gyu",	NULL, 0, L"�ޭ", }, 
    { L"ha",	NULL, 0, L"�", },	{ L"he",	NULL, 0, L"�", },	{ L"hi",	NULL, 0, L"�", },	{ L"ho",	NULL, 0, L"�", }, 
    { L"hu",	NULL, 0, L"�", },	{ L"hya",	NULL, 0, L"ˬ", },  { L"hye",	NULL, 0, L"˪", },  { L"hyi",	NULL, 0, L"˨", }, 
    { L"hyo",	NULL, 0, L"ˮ", },  { L"hyu",	NULL, 0, L"˭", },  { L"i",		NULL, 0, L"�", }, 
    { L"jj",	L"j", 0, L"�", },	{ L"ja",	NULL, 0, L"�ެ", },	{ L"je",	NULL, 0, L"�ު", },	{ L"ji",	NULL, 0, L"��", }, 
    { L"jo",	NULL, 0, L"�ޮ", },	{ L"ju",	NULL, 0, L"�ޭ", },	{ L"jya",	NULL, 0, L"�ެ", },	{ L"jye",	NULL, 0, L"�ު", }, 
    { L"jyi",	NULL, 0, L"�ި", },	{ L"jyo",	NULL, 0, L"�ޮ", },	{ L"jyu",	NULL, 0, L"�ޭ", }, 
    { L"kk",	L"k", 0, L"�", },	{ L"ka",	NULL, 0, L"�", },	{ L"ke",	NULL, 0, L"�", },	{ L"ki",	NULL, 0, L"�", }, 
    { L"ko",	NULL, 0, L"�", },	{ L"ku",	NULL, 0, L"�", },	{ L"kya",	NULL, 0, L"��", },  { L"kye",	NULL, 0, L"��", }, 
    { L"kyi",	NULL, 0, L"��", },	{ L"kyo",	NULL, 0, L"��", },  { L"kyu",	NULL, 0, L"��", }, 
    { L"mm",	L"m", 0, L"�", },	{ L"ma",	NULL, 0, L"�", },	{ L"me",	NULL, 0, L"�", },	{ L"mi",	NULL, 0, L"�", }, 
    { L"mo",	NULL, 0, L"�", },	{ L"mu",	NULL, 0, L"�", },	{ L"mya",	NULL, 0, L"Ь", },  { L"mye",	NULL, 0, L"Ъ", }, 
    { L"myi",	NULL, 0, L"Ш", },	{ L"myo",	NULL, 0, L"Ю", },	{ L"myu",	NULL, 0, L"Э", }, 
    { L"n",		NULL, 0, L"�", },	{ L"n'",	NULL, 0, L"�", },	{ L"na",	NULL, 0, L"�", },	{ L"ne",	NULL, 0, L"�", }, 
    { L"ni",	NULL, 0, L"�", },	{ L"nn",	NULL, 0, L"�", },	{ L"no",	NULL, 0, L"�", },	{ L"nu",	NULL, 0, L"�", }, 
    { L"nya",	NULL, 0, L"Ƭ", },	{ L"nye",	NULL, 0, L"ƪ", },  { L"nyi",	NULL, 0, L"ƨ", },  { L"nyo",	NULL, 0, L"Ʈ", }, 
    { L"nyu",	NULL, 0, L"ƭ", }, 
    { L"o",		NULL, 1, L"�", }, 
    { L"pp",	L"p", 0, L"�", },	{ L"pa",	NULL, 0, L"��", },  { L"pe",	NULL, 0, L"��", },  { L"pi",	NULL, 0, L"��", }, 
    { L"po",	NULL, 0, L"��", },	{ L"pu",	NULL, 0, L"��", },  { L"pya",	NULL, 0, L"�߬", },	{ L"pye",	NULL, 0, L"�ߪ", }, 
    { L"pyi",	NULL, 0, L"�ߨ", },	{ L"pyo",	NULL, 0, L"�߮", },	{ L"pyu",	NULL, 0, L"�߭", }, 
    { L"rr",	L"r", 0, L"�", },	{ L"ra",	NULL, 0, L"�", },	{ L"re",	NULL, 0, L"�", },	{ L"ri",	NULL, 0, L"�", }, 
    { L"ro",	NULL, 0, L"�", },	{ L"ru",	NULL, 0, L"�", },	{ L"rya",	NULL, 0, L"ج", },  { L"rye",	NULL, 0, L"ت", }, 
    { L"ryi",	NULL, 0, L"ب", },	{ L"ryo",	NULL, 0, L"خ", },  { L"ryu",	NULL, 0, L"ح", }, 
    { L"ss",	L"s", 0, L"�", },	{ L"sa",	NULL, 0, L"�", },	{ L"se",	NULL, 0, L"�", },	{ L"sha",	NULL, 0, L"��", }, 
    { L"she",	NULL, 0, L"��", },	{ L"shi",	NULL, 0, L"�", },	{ L"sho",	NULL, 0, L"��", },  { L"shu",	NULL, 0, L"��", }, 
    { L"si",	NULL, 0, L"�", },	{ L"so",	NULL, 0, L"�", },	{ L"su",	NULL, 0, L"�", },	{ L"sya",	NULL, 0, L"��", }, 
    { L"sye",	NULL, 0, L"��", },	{ L"syi",	NULL, 0, L"��", },  { L"syo",	NULL, 0, L"��", },  { L"syu",	NULL, 0, L"��", }, 
    { L"tt",	L"t", 0, L"�", },	{ L"ta",	NULL, 0, L"�", },	{ L"te",	NULL, 0, L"�", },	{ L"tha",	NULL, 0, L"ç", }, 
    { L"the",	NULL, 0, L"ê", },  { L"thi",	NULL, 0, L"è", },  { L"tho",	NULL, 0, L"î", },  { L"thu",	NULL, 0, L"í", }, 
    { L"ti",	NULL, 0, L"�", },	{ L"to",	NULL, 0, L"�", },	{ L"tsu",	NULL, 0, L"�", },	{ L"tu",	NULL, 0, L"�", }, 
    { L"tya",	NULL, 0, L"��", },  { L"tye",	NULL, 0, L"��", },  { L"tyi",	NULL, 0, L"��", },	{ L"tyo",	NULL, 0, L"��", }, 
    { L"tyu",	NULL, 0, L"��", }, 
    { L"u",		NULL, 0, L"�", }, 
    { L"vv",	L"v", 0, L"�", },	{ L"va",	NULL, 0, L"�ާ", },	{ L"ve",	NULL, 0, L"�ު", },	{ L"vi",	NULL, 0, L"�ި", }, 
    { L"vo",	NULL, 0, L"�ޫ", },	{ L"vu",	NULL, 0, L"��", }, 
    { L"ww",	L"w", 0, L"�", },	{ L"wa",	NULL, 0, L"�", },	{ L"we",	NULL, 0, L"��", },  { L"wi",	NULL, 0, L"��", }, 
    { L"wo",	NULL, 0, L"�", },	{ L"wu",	NULL, 0, L"�", }, 
    { L"xx",	L"x", 0, L"�", },	{ L"xa",	NULL, 0, L"�", },	{ L"xe",	NULL, 0, L"�", },	{ L"xi",	NULL, 0, L"�", }, 
    { L"xka",	NULL, 0, L"�", },	{ L"xke",	NULL, 0, L"�", },	{ L"xo",	NULL, 0, L"�", },	{ L"xtsu",	NULL, 0, L"�", }, 
    { L"xtu",	NULL, 0, L"�", },	{ L"xu",	NULL, 0, L"�", },	{ L"xwa",	NULL, 0, L"�", },	{ L"xwe",	NULL, 0, L"�", }, 
    { L"xwi",	NULL, 0, L"�", },	{ L"xya",	NULL, 0, L"�", },	{ L"xyo",	NULL, 0, L"�", },	{ L"xyu",	NULL, 0, L"�", }, 
    { L"yy",	L"y", 0, L"�", },	{ L"ya",	NULL, 0, L"�", },	{ L"ye",	NULL, 0, L"��", },  { L"yo",	NULL, 0, L"�", }, 
    { L"yu",	NULL, 0, L"�", },	 
    { L"zz",	L"z", 0, L"�", },	{ L"z,",	NULL, 0, L"�d", },  { L"z-",	NULL, 0, L"�`", },  { L"z.",	NULL, 0, L"�c", }, 
    { L"z/",	NULL, 0, L"�", },	{ L"z[",	NULL, 0, L"�w", },  { L"z]",	NULL, 0, L"�x", },  { L"za",	NULL, 0, L"��", }, 
    { L"ze",	NULL, 0, L"��", },  { L"zh",	NULL, 0, L"��", },  { L"zi",	NULL, 0, L"��", },  { L"zj",	NULL, 0, L"��", }, 
    { L"zk",	NULL, 0, L"��", },	{ L"zl",	NULL, 0, L"��", },  { L"zo",	NULL, 0, L"��", },	{ L"zu",	NULL, 0, L"��", }, 
    { L"zya",	NULL, 0, L"�ެ", },	{ L"zye",	NULL, 0, L"�ު", },	{ L"zyi",	NULL, 0, L"�ި", },	{ L"zyo",	NULL, 0, L"�ޮ", }, 
    { L"zyu",	NULL, 0, L"�ޭ", }, 
	{ L",",		NULL, 0, L"�", },	{ L".",		NULL, 0, L"�", },	{ L"-",		NULL, 0, L"�", },	{ L":",		NULL, 0, L":", },
	{ L";",		NULL, 0, L";", },	{ L"?",		NULL, 0, L"?", },	{ L"[",		NULL, 0, L"�", },	{ L"]",		NULL, 0, L"�", },
	{ L"(",		NULL, 0, L"(", },	{ L"{",		NULL, 0, L"{", },
} ;

/*	oh�ϊ��̂��߂̃��[���B
 */
static struct TSkkBaseRuleT2	_rDefaultJisx0201KanaRuleType2_1 []	= {
	{ L"\\?",	L"\\I",		0,	L"", },
	{ L"h\\C",	L"\\I",		0,	L"�", },
	{ L"h\\?",	L"h\\I",	0,	L"", },
} ;

static struct TSkkBaseRuleT3	_rDefaultJisx0201KanaRuleType3 []	= {
	{ L"l",		NULL,	0,	NFUNC_SKK_LATIN_MODE },
    { L"q",		NULL,	0,	NFUNC_SKK_TOGGLE_KATAKANA },
    { L"L",		NULL,	0,	NFUNC_SKK_JISX0208_LATIN_MODE },	
    { L"Q",		NULL,	0,	NFUNC_SKK_SET_HENKAN_POINT_SUBR },
    { L"X",		NULL,	0,	NFUNC_SKK_PURGE_FROM_JISYO },
    { L"/",		NULL,	0,	NFUNC_SKK_ABBREV_MODE },
    { L"$",		NULL,	0,	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT },
	{ L"@",		NULL,	0,	NFUNC_SKK_TODAY },
    { L"\\\\",	NULL,	0,	NFUNC_SKK_INPUT_BY_CODE_OR_MENU },
    { L"\r",	NULL,	0,	NFUNC_SKK_KAKUTEI },
} ;

static struct TSkkBaseRuleT2	_rDefaultJisx0201RomanRuleType2 []	= {
	{ L"!", NULL, 0, L"!", },	{ L"\"",NULL, 0, L"\"" },  { L"#", NULL, 0, L"#", },  { L"$", NULL, 0, L"$", },  { L"%", NULL, 0, L"%", }, 
    { L"&", NULL, 0, L"&", },	{ L"'", NULL, 0, L"'", },  { L"(", NULL, 0, L"(", },  { L")", NULL, 0, L")", },  { L"*", NULL, 0, L"*", }, 
    { L"+", NULL, 0, L"+", },	{ L",", NULL, 0, L",", },  { L"-", NULL, 0, L"-", },  { L".", NULL, 0, L".", },  { L"/", NULL, 0, L"/", }, 
    { L"0", NULL, 0, L"0", },	{ L"1", NULL, 0, L"1", },  { L"2", NULL, 0, L"2", },  { L"3", NULL, 0, L"3", },  { L"4", NULL, 0, L"4", }, 
    { L"5", NULL, 0, L"5", },	{ L"6", NULL, 0, L"6", },  { L"7", NULL, 0, L"7", },  { L"8", NULL, 0, L"8", },  { L"9", NULL, 0, L"9", }, 
    { L":", NULL, 0, L":", },	{ L";", NULL, 0, L";", },  { L"<", NULL, 0, L"<", },  { L"=", NULL, 0, L"=", },  { L">", NULL, 0, L">", }, 
    { L"?", NULL, 0, L"?", },	{ L"@", NULL, 0, L"@", }, 
    { L"A", NULL, 0, L"A", },	{ L"B", NULL, 0, L"B", },  { L"C", NULL, 0, L"C", },  { L"D", NULL, 0, L"D", },  { L"E", NULL, 0, L"E", }, 
    { L"F", NULL, 0, L"F", },	{ L"G", NULL, 0, L"G", },  { L"H", NULL, 0, L"H", },  { L"I", NULL, 0, L"I", },  { L"J", NULL, 0, L"J", }, 
    { L"K", NULL, 0, L"K", },	{ L"L", NULL, 0, L"L", },  { L"M", NULL, 0, L"M", },  { L"N", NULL, 0, L"N", },  { L"O", NULL, 0, L"O", }, 
    { L"P", NULL, 0, L"P", },	{ L"Q", NULL, 0, L"Q", },  { L"R", NULL, 0, L"R", },  { L"S", NULL, 0, L"S", },  { L"T", NULL, 0, L"T", }, 
    { L"U", NULL, 0, L"U", },	{ L"V", NULL, 0, L"V", },  { L"W", NULL, 0, L"W", },  { L"X", NULL, 0, L"X", },  { L"Y", NULL, 0, L"Y", }, 
    { L"Z", NULL, 0, L"Z", }, 
    { L"[", NULL, 0, L"[", },	{ L"\\\\", NULL, 0, L"\\\\", },  { L"]", NULL, 0, L"]", },  { L"^", NULL, 0, L"^", },
	{ L"_", NULL, 0, L"_", },	{ L"`", NULL, 0, L"`", }, 
    { L"a", NULL, 0, L"a", },	{ L"b", NULL, 0, L"b", },  { L"c", NULL, 0, L"c", },  { L"d", NULL, 0, L"d", },  { L"e", NULL, 0, L"e", }, 
    { L"f", NULL, 0, L"f", },	{ L"g", NULL, 0, L"g", },  { L"h", NULL, 0, L"h", },  { L"i", NULL, 0, L"i", },  { L"j", NULL, 0, L"j", }, 
    { L"k", NULL, 0, L"k", },	{ L"l", NULL, 0, L"l", },  { L"m", NULL, 0, L"m", },  { L"n", NULL, 0, L"n", },  { L"o", NULL, 0, L"o", }, 
    { L"p", NULL, 0, L"p", },	{ L"q", NULL, 0, L"q", },  { L"r", NULL, 0, L"r", },  { L"s", NULL, 0, L"s", },  { L"t", NULL, 0, L"t", }, 
    { L"u", NULL, 0, L"u", },	{ L"v", NULL, 0, L"v", },  { L"w", NULL, 0, L"w", },  { L"x", NULL, 0, L"x", },  { L"y", NULL, 0, L"y", }, 
    { L"z", NULL, 0, L"z", }, 
    { L"{", NULL, 0, L"{", },	{ L"|", NULL, 0, L"|", },  { L"}", NULL, 0, L"}", },  { L"~", NULL, 0, L"~", }, 
} ;

/*	����L�@���ł���̂́A�Ō��1���������ɂ������B�r���� ? �������Ă��������邾���ł͂Ȃ����낤���B
 *	(�r���� backslash �͂��肾�낤����ǂ�)
 *
 *	������\�ɂ���ɂ́A�Ō��1�����ȊO�̕\���ɂ� \\\\ �������Ă� \\ �Ɍ�����悤�ɁA? �Ƃ��͒e���悤
 *	�ɂ��āc
 */

/*========================================================================
 *	global variables
 */
//static	BYTE		_srbyMajorModeMap				[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkJModeMap				[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkLatinModeMap			[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkJisx0208LatinModeMap	[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkAbbrevModeMap			[MAX_KEYBINDS] ;

static	struct CImeKeymap	_sMajorModeMap				= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkJModeMap				= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkLatinModeMap 			= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkJisx0208LatinModeMap 	= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkAbbrevModeMap 			= { { 0 }, NULL, 0 } ;


static	int			_siRomaKanaRuleListType ;
static	int			_siKeybindType ;
static	int			_siStartHenkanKeyType ;
static	int			_siCompletionKeyType ;
static	int			_siSetHenkanPointSubrKeyType ;
static	int			_siSpecialMidashiCharKeyType ;

static	struct TSkkBaseRuleNode*	_rplstRomaKanaRules			[NUM_ROMAKANARULE]	= { NULL } ;
static	struct TSkkBaseRuleNode*	_rplstJisx0201KanaRules		[NUM_ROMAKANARULE]	= { NULL } ;
static	struct TSkkBaseRuleNode*	_rplstJisx0201RomanRules	[NUM_ROMAKANARULE]	= { NULL } ;
static	BOOL		_bOHHenkan					= TRUE ;

static	int			_siNumStartHenkanKeys ;
static	BYTE		_srbyStartHenkanKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumTryCompletionKeys ;
static	BYTE		_srbyTryCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumPreviousCompletionKeys ;
static	BYTE		_srbyPreviousCompletionKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumNextCompletionKeys ;
static	BYTE		_srbyNextCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumSetHenkanPointSubrKeys ;
static	BYTE		_srbySetHenkanPointSubrKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumSpecialMidashiCharKeys ;
static	BYTE		_srbySpecialMidashiCharKeys		[MAX_SPECIALKEYS] ;

static	BOOL		_sbEggLikeNewline ;
static	BOOL		_sbNewlineKakuteiAll ;

static	int			_siZenkakuVectorType ;
static	LPTSTR		_rpZenkakuVector [SIZE_INPUTVECTOR]	= { NULL } ;

/*	���[�U��`���ڂ����݂��邩�ۂ��BComboBox �ɃG���g���[���ǉ�����邩�ǂ����̃`�F�b�N
 *	�ɗ��p����B
 */
static	BOOL		_sbExistUserDefinedRomaKanaRule				= FALSE ;
static	BOOL		_sbExistUserDefinedKeymap					= FALSE ;
static	BOOL		_sbExistUserDefinedStartHenkanKey			= FALSE ;
static	BOOL		_sbExistUserDefinedCompletionKey			= FALSE ;
static	BOOL		_sbExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
static	BOOL		_sbExistUserDefinedSpecialMidashiCharKey	= FALSE ;
static	BOOL		_sbExistUserDefinedZenkakuVector			= FALSE ;

/*========================================================================
 *	public functions
 */
INT_PTR	CALLBACK
DlgKeybindProc		(
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgKeybind_lOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgKeybind_lOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgKeybind_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	window message handlers
 */
static	int			_sriKeybindComboResId []	= {
	IDC_COMBO_ROMAKANARULE,
	IDC_COMBO_KEYMAP,
	IDC_COMBO_STARTHENKANKEY,
	IDC_COMBO_COMPLETIONRELATEDKEY,
	IDC_COMBO_SETHENKANPOINTSUBRKEY,
	IDC_COMBO_SPECIALMIDASHICHARKEY,
	IDC_COMBO_ZENKAKUVECTOR,
} ;

static	BOOL*		_srpbUserDefinedFlags []	= {
	&_sbExistUserDefinedRomaKanaRule,	
	&_sbExistUserDefinedKeymap,			
	&_sbExistUserDefinedStartHenkanKey,
	&_sbExistUserDefinedCompletionKey,
	&_sbExistUserDefinedSetHenkanPointSubrKey,
	&_sbExistUserDefinedSpecialMidashiCharKey,	
	&_sbExistUserDefinedZenkakuVector,
} ;

static	int*		_srpiKeybindTypes []	= {
	&_siRomaKanaRuleListType,
	&_siKeybindType,
	&_siStartHenkanKeyType,
	&_siCompletionKeyType,
	&_siSetHenkanPointSubrKeyType,
	&_siSpecialMidashiCharKeyType,
	&_siZenkakuVectorType,
} ;

LRESULT
dlgKeybind_lOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	HWND		hwndControl ;
	int			i ;

	dlgKeybind_vLoadConfig (hDlg, TRUE) ;

	for (i = 0 ; i < ARRAYSIZE (_sriKeybindComboResId) ; i ++) {
		hwndControl	= GetDlgItem (hDlg, _sriKeybindComboResId [i]) ;
		if (hwndControl != NULL) {
			int	nIndex ;
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("�W��")) ;
			if (nIndex == CB_ERR)
				continue ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_DEFAULT) ;

			if (*_srpbUserDefinedFlags [i]) {
				nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
				if (nIndex == CB_ERR) 
					continue ;
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			}
			SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) nIndex, (LPARAM) 0) ;
		}
	}
	dlgKeybind_vSyncControls (hDlg) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
dlgKeybind_lOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;
	int*	piData ;

	switch (woControl) {
	case	IDC_COMBO_ROMAKANARULE:
		piData	= &_siRomaKanaRuleListType ;
		goto	combo_common ;
	case	IDC_COMBO_KEYMAP:
		piData	= &_siKeybindType ;
		goto	combo_common ;
	case	IDC_COMBO_SETHENKANPOINTSUBRKEY:
		piData	= &_siSetHenkanPointSubrKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_STARTHENKANKEY:
		piData	= &_siStartHenkanKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_COMPLETIONRELATEDKEY:
		piData	= &_siCompletionKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_SPECIALMIDASHICHARKEY:
		piData	= &_siSpecialMidashiCharKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_ZENKAKUVECTOR:
		piData	= &_siZenkakuVectorType ;
combo_common:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			int		nCurSel, nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (nData != *piData) {
					*piData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_EDIT_ROMAKANARULE:
		dlgKeybind_vEditRomaKanaRule (hDlg) ;
		return	0 ;
	case	IDC_BUTTON_EDIT_KEYMAP:
		dlgKeybind_vEditKeymap (hDlg) ;
		return	0 ;
	case	IDC_BUTTON_EDIT_SPECIALKEY:
		dlgKeybind_vEditSpecialKey (hDlg) ;	/* Special-Chars? */
		return	0 ;
	case	IDC_BUTTON_EDIT_ZENKAKUVECTOR:
		dlgKeybind_vEditZenkakuVector (hDlg) ;
		return	0 ;
	case	IDC_CHECK_EGG_LIKE_NEWLINE:
		if (woNotification == BN_CLICKED) {
			_sbEggLikeNewline	= IsDlgButtonChecked (hDlg, IDC_CHECK_EGG_LIKE_NEWLINE) == BST_CHECKED ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_CHECK_NEWLINE_KAKUTEI_ALL:
		if (woNotification == BN_CLICKED) {
			_sbNewlineKakuteiAll	= IsDlgButtonChecked (hDlg, IDC_CHECK_NEWLINE_KAKUTEI_ALL) == BST_CHECKED ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	default:
		break ;
	}
	return	1 ;
}

INT_PTR
dlgKeybind_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	LPNMHDR	pnmh		= (LPNMHDR) lParam ;

	switch (pnmh->code) {
	case	PSN_APPLY:
		if (dlgKeybind_bSaveConfig ())
			vUpdateTick () ;
		break ;
	case	PSN_RESET:
		dlgKeybind_vLoadConfig (hDlg, FALSE) ;
		dlgKeybind_vSyncControls (hDlg) ;
		break ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgKeybind_vSyncControls (
	HWND			hDlg)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_sriKeybindComboResId) ; i ++) 
		SetDropDownListCurrentSelectionByData (hDlg, _sriKeybindComboResId [i], *_srpiKeybindTypes [i]) ;

	CheckDlgButton (hDlg, IDC_CHECK_EGG_LIKE_NEWLINE,    _sbEggLikeNewline?		BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_NEWLINE_KAKUTEI_ALL, _sbNewlineKakuteiAll?	BST_CHECKED : BST_UNCHECKED) ;
	return ;
}

/*========================================================================
 *	���[�}�����Ȃ̕ϊ����[���̐ݒ�_�C�A���O�B
 */
static	int	dlgRomaKanaRule_iDialogEditRomaKanaRuleLists (HWND, struct TCustomRomaKanaRuleArg*) ;

void
dlgKeybind_vEditRomaKanaRule (
	HWND			hDlg)
{
	struct TCustomRomaKanaRuleArg	arg ;
	int				nResult ;
	HINSTANCE		hInst ;
	int				i ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_siRomaKanaRuleListType == KEYBINDTP_DEFAULT) {
		dlgRomaKanaRule_vInitializeDefaultRomaKanaRule (arg.m_rplstRomaKanaRules) ;
		dlgRomaKanaRule_vInitializeDefaultJisx0201KanaRule (arg.m_rplstJisx0201KanaRules) ;
		dlgRomaKanaRule_vInitializeDefaultJisx0201RomanRule (arg.m_rplstJisx0201RomanRules) ;
	} else {
		/* ���݂̃��[�}�����ȃ��[�����R�s�[����K�v������B*/
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			if (_rplstRomaKanaRules [i] != NULL) {
				arg.m_rplstRomaKanaRules [i]	= pCopyRomaKanaRuleList (_rplstRomaKanaRules [i]) ;
			} else {
				arg.m_rplstRomaKanaRules [i]	= NULL ;
			}
			if (_rplstJisx0201KanaRules [i] != NULL) {
				arg.m_rplstJisx0201KanaRules [i]	= pCopyRomaKanaRuleList (_rplstJisx0201KanaRules [i]) ;
			} else {
				arg.m_rplstJisx0201KanaRules [i]	= NULL ;
			}
			if (_rplstJisx0201RomanRules [i] != NULL) {
				arg.m_rplstJisx0201RomanRules [i]	= pCopyRomaKanaRuleList (_rplstJisx0201RomanRules [i]) ;
			} else {
				arg.m_rplstJisx0201RomanRules [i]	= NULL ;
			}
		}
	}
	arg.m_iShownRule	= 0 ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	/*	IDD_EDIT_ROMAKANARULELIST �� 3page ���� PropertySheet �ɕύX���ꂽ�B
	 *	�ŏ��̃y�[�W���A�]���� RomaKanaRule, ���̃y�[�W�� JISX0201, �Ō�̃y�[�W�� JISX0201-ROMAN
	 *	�ł���B���� PropertySheet �� Apply �͗p�ӂ��Ȃ��c�B
	 */
	nResult	= dlgRomaKanaRule_iDialogEditRomaKanaRuleLists (hDlg, &arg) ;
	if (nResult <= 0) {
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			dlgRomaKanaRule_vClearAllRules (&arg.m_rplstRomaKanaRules		[i]) ;
			dlgRomaKanaRule_vClearAllRules (&arg.m_rplstJisx0201KanaRules	[i]) ;
			dlgRomaKanaRule_vClearAllRules (&arg.m_rplstJisx0201RomanRules	[i]) ;
		}
		return ;
	}
	if (! _sbExistUserDefinedRomaKanaRule) {
		HWND	hwndControl ;
		int		nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_ROMAKANARULE) ;
		nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex == CB_ERR) 
			nIndex	= SendMessage (hwndControl, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex != CB_ERR)
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
		_sbExistUserDefinedRomaKanaRule	= TRUE ;
	}
	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		dlgRomaKanaRule_vClearAllRules (&_rplstRomaKanaRules [i]) ;
		_rplstRomaKanaRules			[i]	= arg.m_rplstRomaKanaRules [i] ;

		dlgRomaKanaRule_vClearAllRules (&_rplstJisx0201KanaRules [i]) ;
		_rplstJisx0201KanaRules		[i]	= arg.m_rplstJisx0201KanaRules [i] ;

		dlgRomaKanaRule_vClearAllRules (&_rplstJisx0201RomanRules [i]) ;
		_rplstJisx0201RomanRules	[i]	= arg.m_rplstJisx0201RomanRules [i] ;
	}
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_ROMAKANARULE, KEYBINDTP_USERDEFINED) ;
	_siRomaKanaRuleListType	= KEYBINDTP_USERDEFINED ;
	return ;
}

int
dlgRomaKanaRule_iDialogEditRomaKanaRuleLists (
	HWND							hDlg,
	struct TCustomRomaKanaRuleArg*	pArg)
{
	static	struct TPropPageSheetConfig			_srPageSheetTbl []	= {
		{ TEXT("���[�}�������[��"),				dlgRomaKanaRuleProc,	IDD_PROPPAGE_ROMAKANARULE, },
		{ TEXT("JISX0201�������[��"),			dlgJisx0201RuleProc,	IDD_PROPPAGE_ROMAKANARULE, },
		{ TEXT("JISX0201���[�}���[��"),			dlgJisx0201RuleProc,	IDD_PROPPAGE_ROMAKANARULE, },
	} ;
	HPROPSHEETPAGE	rPages [3] ;
	PROPSHEETHEADER	psh ;

	psh.dwSize		= sizeof (psh) ;
	psh.dwFlags		= 0 ;
	psh.hwndParent	= hDlg ;

	psh.hInstance	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	psh.pszIcon		= NULL ;
	psh.pszCaption	= TEXT ("���[�����X�g") ;
	psh.nPages		= 0 ;
	psh.nStartPage	= 0 ;
	psh.phpage		= rPages ;
	psh.pfnCallback	= 0 ;

	if (! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [0], pArg->m_rplstRomaKanaRules)	||
		! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [1], pArg->m_rplstJisx0201KanaRules) ||
		! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [2], pArg->m_rplstJisx0201RomanRules))
		return	0 ;
	if (psh.nPages > 0) {
		/* Tick �� update ����B*/
		return	PropertySheet (&psh) ;
	}
	return	0 ;
}

/*========================================================================
 *	�X�y�V�����L�[ (roma-kana-rule-list�̕⑫)�̐ݒ�_�C�A���O�B
 */
void
dlgKeybind_vEditSpecialKey (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg	arg ;
	int				nResult ;
	HINSTANCE		hInst ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_siStartHenkanKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultStartHenkanKey (arg.m_bufStartHenkanKeys, &arg.m_iNumStartHenkanKeys) ;
	} else {
		arg.m_iNumStartHenkanKeys			= _siNumStartHenkanKeys ;
		memcpy (arg.m_bufStartHenkanKeys,			_srbyStartHenkanKeys,		_siNumStartHenkanKeys) ;
	}
	if (_siCompletionKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultCompletinoRelatedKey (arg.m_bufTryCompletionKeys, &arg.m_iNumTryCompletionKeys, arg.m_bufPreviousCompletionKeys, &arg.m_iNumPreviousCompletionKeys, arg.m_bufNextCompletionKeys, &arg.m_iNumNextCompletionKeys) ;
	} else {
		arg.m_iNumTryCompletionKeys			= _siNumTryCompletionKeys ;
		memcpy (arg.m_bufTryCompletionKeys,			_srbyTryCompletionKeys,		_siNumTryCompletionKeys) ;
		arg.m_iNumPreviousCompletionKeys	= _siNumPreviousCompletionKeys ;
		memcpy (arg.m_bufPreviousCompletionKeys,	_srbyPreviousCompletionKeys, _siNumPreviousCompletionKeys) ;
		arg.m_iNumNextCompletionKeys		= _siNumNextCompletionKeys ;
		memcpy (arg.m_bufNextCompletionKeys,	_srbyNextCompletionKeys,		_siNumNextCompletionKeys) ;
	}
	if (_siSetHenkanPointSubrKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultSetHenkanPointSubrKey (arg.m_bufSetHenkanPointSubrKeys, &arg.m_iNumSetHenkanPointSubrKeys) ;
	} else {
		arg.m_iNumSetHenkanPointSubrKeys	= _siNumSetHenkanPointSubrKeys ;
		memcpy (arg.m_bufSetHenkanPointSubrKeys, _srbySetHenkanPointSubrKeys, _siNumSetHenkanPointSubrKeys) ;
	}
	if (_siSpecialMidashiCharKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultSpecialMidashiCharKey (arg.m_bufSpecialMidashiCharKeys, &arg.m_iNumSpecialMidashiCharKeys) ;
	} else {
		arg.m_iNumSpecialMidashiCharKeys	= _siNumSpecialMidashiCharKeys ;
		memcpy (arg.m_bufSpecialMidashiCharKeys, _srbySpecialMidashiCharKeys, _siNumSpecialMidashiCharKeys) ;
	}

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_SPECIALKEYBIND), hDlg, dlgEditSpecialKeybindProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		return ;
	}
	if (arg.m_bStartHenkanKeysModified) {
		if (! _sbExistUserDefinedStartHenkanKey) {
			HWND	hwndControl ;
			int		nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_STARTHENKANKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR) 
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedStartHenkanKey	= TRUE ;
		}
		_siNumStartHenkanKeys	= arg.m_iNumStartHenkanKeys ;
		if (arg.m_iNumStartHenkanKeys > 0)
			memcpy (_srbyStartHenkanKeys, arg.m_bufStartHenkanKeys, arg.m_iNumStartHenkanKeys) ;

		_siStartHenkanKeyType	= KEYBINDTP_USERDEFINED ;
		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_STARTHENKANKEY, KEYBINDTP_USERDEFINED) ;
	}
	if (arg.m_bCompletionKeysModified) {
		if (! _sbExistUserDefinedCompletionKey) {
			HWND	hwndControl ;
			int		nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_COMPLETIONRELATEDKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR) 
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}
		_siNumTryCompletionKeys			= arg.m_iNumTryCompletionKeys ;
		_siNumPreviousCompletionKeys	= arg.m_iNumPreviousCompletionKeys ;
		_siNumNextCompletionKeys		= arg.m_iNumNextCompletionKeys ;
		if (arg.m_iNumTryCompletionKeys > 0)
			memcpy (_srbyTryCompletionKeys, arg.m_bufTryCompletionKeys, arg.m_iNumTryCompletionKeys) ;
		if (arg.m_iNumPreviousCompletionKeys > 0)
			memcpy (_srbyPreviousCompletionKeys, arg.m_bufPreviousCompletionKeys, arg.m_iNumPreviousCompletionKeys) ;
		if (arg.m_iNumNextCompletionKeys > 0)
			memcpy (_srbyNextCompletionKeys, arg.m_bufNextCompletionKeys, arg.m_iNumNextCompletionKeys) ;

		_siCompletionKeyType	= KEYBINDTP_USERDEFINED ;
		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_COMPLETIONRELATEDKEY, KEYBINDTP_USERDEFINED) ;
	}
	if (arg.m_bSetHenkanPointSubrKeysModified) {
		if (! _sbExistUserDefinedSetHenkanPointSubrKey) {
			HWND	hwndControl ;
			int		nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SETHENKANPOINTSUBRKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR) 
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		_siSetHenkanPointSubrKeyType	= KEYBINDTP_USERDEFINED ;
		_siNumSetHenkanPointSubrKeys	= arg.m_iNumSetHenkanPointSubrKeys ;
		memcpy (_srbySetHenkanPointSubrKeys, arg.m_bufSetHenkanPointSubrKeys, MAX_SPECIALKEYS * sizeof (BYTE)) ;

		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_SETHENKANPOINTSUBRKEY, KEYBINDTP_USERDEFINED) ;
	}
	if (arg.m_bSpecialMidashiCharKeysModified) {
		if (! _sbExistUserDefinedSpecialMidashiCharKey) {
			HWND	hwndControl ;
			int		nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SPECIALMIDASHICHARKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR) 
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}
		_siSpecialMidashiCharKeyType	= KEYBINDTP_USERDEFINED ;
		_siNumSpecialMidashiCharKeys	= arg.m_iNumSpecialMidashiCharKeys ;
		memcpy (_srbySpecialMidashiCharKeys, arg.m_bufSpecialMidashiCharKeys, MAX_SPECIALKEYS * sizeof (BYTE)) ;

		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_SPECIALMIDASHICHARKEY, KEYBINDTP_USERDEFINED) ;
	}
	return ;
}

void
dlgKeybind_vEditZenkakuVector (
	HWND			hDlg)
{
	struct TEditZenkakuVectorArg	arg ;
	int				nResult ;
	HINSTANCE		hInst ;
	LPTSTR*			pstrTable ;
	int				i ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_siZenkakuVectorType == KEYBINDTP_DEFAULT) {
		pstrTable	= _rstrDefaultSkkJisx0208LatinVector ;
	} else {
		pstrTable	= _rpZenkakuVector ;
	}
	for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++)
		arg.m_rpZenkakuVector [i]	= pstrTable [i] ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_ZENKAKUVECTOR), hDlg, dlgZenkakuVectorProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		/* �������̉���B*/
		for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
			if (arg.m_rpZenkakuVector [i] != pstrTable [i]) {
				FREE (arg.m_rpZenkakuVector [i]) ;
				arg.m_rpZenkakuVector [i]	= NULL ;
			}
		}
		return ;
	}
	/* ���ڂ�1�ł��ύX���Ă��邩�H */
	for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
		if (arg.m_rpZenkakuVector [i] != pstrTable [i])
			break ;
	}
	if (i >= 128)	/* no update */
		return ;
	if (! _sbExistUserDefinedZenkakuVector) {
		HWND	hwndControl ;
		int		nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_ZENKAKUVECTOR) ;
		nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex == CB_ERR) 
			return ;
		SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
		_sbExistUserDefinedZenkakuVector	= TRUE ;
	}
	_siZenkakuVectorType	= KEYBINDTP_USERDEFINED ;

	for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
		/*	Default ����̏C���́ADefault �� Table ���R�s�[����B���̂��߂ɁA
		 *	!= _rpTable [i] �ł͑ʖځB_rpZenkakuVector [i] �łȂ���΂Ȃ�Ȃ��B
		 */
		if (arg.m_rpZenkakuVector [i] != _rpZenkakuVector [i]) {
			if (_rpZenkakuVector [i] != NULL) {
				FREE (_rpZenkakuVector [i]) ;
			}
			_rpZenkakuVector [i]	= arg.m_rpZenkakuVector [i] ;
		}
	}
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_ZENKAKUVECTOR, KEYBINDTP_USERDEFINED) ;
	return ;
}

/*========================================================================
 *	�L�[�}�b�v�̐ݒ�_�C�A���O�B
 */
static	INT_PTR	CALLBACK	dlgEditKeymapProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditKeymap_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditKeymap_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditKeymap_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void				dlgEditKeymap_vUpdate		(HWND) ;
static	void				dlgEditKeymap_vUpdate1Item	(HWND, UINT) ;
static	void				dlgEditKeymap_vEditKeyBind	(HWND, BOOL) ;
static	void				dlgEditKeymap_vDeleteKeyBind	(HWND) ;
static	void				dlgEditKeymap_vUpdateExtraKeyItem	(HWND, int, int, const struct CImeKeyBind*, int) ;
static	int					dlgEditKeymap_iLookupKeymap	(const struct CImeKeymap*, unsigned int) ;
static	BOOL				dlgEditKeymap_bDefineKeymap	(struct CImeKeymap*, unsigned int, int) ;

#define	IS_EXTRA_KEY(uKey)	(((uKey) & (1 << 31)) != 0)
#define	MAKE_EXTRA_KEYCODE(uVKEY,uMask)	((unsigned short)(uVKEY) | (((unsigned short)(uMask) & 0x7FFF) << 16) | (1L << 31))
#define	EXTRA_KEYCODE_VKEY(uKey)	((uKey) & 0xFFFF)
#define	EXTRA_KEYCODE_MASK(uKey)	(((uKey) >> 16) & 0x7FFF) 

void
dlgKeybind_vEditKeymap (
	HWND			hDlg)
{
	HINSTANCE			hInst ;
	int					nResult ;
	struct TEditKeymapArg	arg ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_siKeybindType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultMajorModeMap			(&arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
		dlgKeybind_vInitializeDefaultJModeMap				(&arg.m_rKeymaps [KEYMAP_INDEX_JMODE], &arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
		dlgKeybind_vInitializeDefaultLatinModeMap			(&arg.m_rKeymaps [KEYMAP_INDEX_LATIN]) ;
		dlgKeybind_vInitializeDefaultJisx0208LatinModeMap	(&arg.m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN]) ;
		dlgKeybind_vInitializeDefaultAbbrevModeMap			(&arg.m_rKeymaps [KEYMAP_INDEX_ABBREV], &arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
	} else {
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_MAJOR],			&_sMajorModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_JMODE],			&_sSkkJModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_LATIN],			&_sSkkLatinModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN],	&_sSkkJisx0208LatinModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_ABBREV],			&_sSkkAbbrevModeMap) ;
	}
	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_KEYMAP), hDlg, dlgEditKeymapProc, (LPARAM) &arg) ;
	if (nResult != IDOK)
		return ;
	if (! _sbExistUserDefinedKeymap) {
		HWND	hwndControl ;
		int		nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_KEYMAP) ;
		nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex == CB_ERR) 
			return ;
		SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
		_sbExistUserDefinedKeymap	= TRUE ;
	}
	dlgKeyBind_vClearKeymap	(&_sMajorModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkJModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkLatinModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkJisx0208LatinModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkAbbrevModeMap) ;
	dlgKeybind_vCloneKeymap (&_sMajorModeMap,				&arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
	dlgKeybind_vCloneKeymap (&_sSkkJModeMap,				&arg.m_rKeymaps [KEYMAP_INDEX_JMODE]) ;
	dlgKeybind_vCloneKeymap (&_sSkkLatinModeMap,			&arg.m_rKeymaps [KEYMAP_INDEX_LATIN]) ;
	dlgKeybind_vCloneKeymap (&_sSkkJisx0208LatinModeMap,	&arg.m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN]) ;
	dlgKeybind_vCloneKeymap (&_sSkkAbbrevModeMap,			&arg.m_rKeymaps [KEYMAP_INDEX_ABBREV]) ;

	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_KEYMAP, KEYBINDTP_USERDEFINED) ;
	_siKeybindType	= KEYBINDTP_USERDEFINED ;
	return ;
}

INT_PTR	CALLBACK
dlgEditKeymapProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		return	dlgEditKeymap_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditKeymap_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditKeymap_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditKeymap_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditKeymapArg*		pArg ;
	HWND	hwndControl ;

	pArg	= (struct TEditKeymapArg*) lParam ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	CheckRadioButton (hDlg, IDC_RADIO_MAJORMODEMAP, IDC_RADIO_ALLMAPS, IDC_RADIO_ALLMAPS) ;

	/*	�R�����̓[���ɐݒ�ł��Ȃ��̂ōŏ��̂��̂����͓o�^���Ă����B
	 */
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hwndControl != NULL) {
		LVCOLUMN	lvColumn ;

		memset (&lvColumn, 0, sizeof (lvColumn)) ;
		lvColumn.mask	= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt	= LVCFMT_LEFT ;
		lvColumn.cx			= 64 ;
		lvColumn.pszText	= TEXT ("key") ;
		ListView_InsertColumn (hwndControl, 0, &lvColumn) ;
	}
	dlgEditKeymap_vUpdate (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditKeymap_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl	= LOWORD (wParam) ;

	switch (woControl) {
	case	IDC_RADIO_MAJORMODEMAP:
	case	IDC_RADIO_JMODEMAP:
	case	IDC_RADIO_LATINMODEMAP:
	case	IDC_RADIO_JISX0208LATINMODEMAP:
	case	IDC_RADIO_ABBREVMODEMAP:
	case	IDC_RADIO_ALLMAPS:
		CheckRadioButton (hDlg, IDC_RADIO_MAJORMODEMAP, IDC_RADIO_ALLMAPS, woControl) ;
		dlgEditKeymap_vUpdate (hDlg) ;
		break ;
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
		dlgEditKeymap_vEditKeyBind (hDlg, woControl == IDC_BUTTON_EDIT) ;
		return	0 ;	/* If application process this message, it must return zero. */
	case	IDC_BUTTON_DELETE:
		dlgEditKeymap_vDeleteKeyBind (hDlg) ;
		return	0 ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;	/* If application process this message, it must return zero. */
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditKeymap_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

void
dlgEditKeymap_vUpdate (
	HWND			hDlg)
{
	static	struct {
		int		m_nWidth ;
		LPTSTR	m_strTitle ;
	}	srAllMapColumnInfo []	= {
		{	64,		TEXT ("major-map")	},
		{	64,		TEXT ("j-mode-map")	},
		{	64,		TEXT ("latin-mode-map")	},
		{	64,		TEXT ("jisx0208-latin-mode-map")	},
		{	64,		TEXT ("abbrev-map")	},
	},	srOneMapColumnInfo []	= {
		{	128,	TEXT ("function")	},
	},	*pColumnInfo ;

	struct TEditKeymapArg*		pArg ;
	HWND		hwndControl ;
	LVCOLUMN	lvColumn ;
	LVITEM		lvi ;
	int			i ;
	TCHAR		szBuffer [64] ;

	pArg		= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hwndControl == NULL)
		return ;

	ListView_DeleteAllItems (hwndControl) ;
	ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;

	memset (&lvColumn, 0, sizeof (lvColumn)) ;
	lvColumn.mask	= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
	lvColumn.fmt	= LVCFMT_LEFT ;

	memset (&lvi, 0, sizeof (lvi)) ;
	if (IsDlgButtonChecked (hDlg, IDC_RADIO_ALLMAPS) == BST_CHECKED) {
		if (ListView_GetColumnWidth (hwndControl, 2) == 0) {
			/*	�R�����̍X�V���K�v�B*/
			for (i = 0 ; i < ARRAYSIZE (srOneMapColumnInfo) ; i ++) 
				ListView_DeleteColumn (hwndControl, 1) ;
			for (i = 0 ; i < ARRAYSIZE (srAllMapColumnInfo) ; i ++) {
				lvColumn.cx			= srAllMapColumnInfo [i].m_nWidth ;
				lvColumn.pszText	= srAllMapColumnInfo [i].m_strTitle ;
				ListView_InsertColumn (hwndControl, i + 1, &lvColumn) ;
			}
		}
		lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvi.state		= 0 ; 
		lvi.stateMask	= 0 ;
		for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
			int		j ;

			for (j = 0 ; j < NUM_KEYMAPS ; j ++) {
				if (pArg->m_rKeymaps [j].m_rbyBaseMap [i] != NFUNC_INVALID_CHAR)
					break ;
			}
			if (j < NUM_KEYMAPS) {
				int		nItem ;

				lvi.iItem		= i ;
				lvi.lParam		= (LPARAM) i ;
				vKey2String (szBuffer, ARRAYSIZE (szBuffer), i) ;
				lvi.pszText		= szBuffer ;
				nItem			= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					for (j = 0 ; j < NUM_KEYMAPS ; j ++) {
						if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), pArg->m_rKeymaps [j].m_rbyBaseMap [i]))
							ListView_SetItemText (hwndControl, nItem, j + 1, szBuffer) ;
					}
				}
			}
		}
		/*	����L�[�o�C���h�̃A�b�v�f�[�g�B
		 */
		for (i = 0 ; i < NUM_KEYMAPS ; i ++) 
			dlgEditKeymap_vUpdateExtraKeyItem (hwndControl, i + 1, NUM_KEYMAPS + 1, pArg->m_rKeymaps [i].m_pKeyBinds, pArg->m_rKeymaps [i].m_nKeyBinds) ;
	} else {
		const CImeKeymap*	pKeymap		= NULL ;

		if (ListView_GetColumnWidth (hwndControl, 2) != 0) {
			/*	�R�����̍X�V���K�v�B*/
			for (i = 0 ; i < ARRAYSIZE (srAllMapColumnInfo) ; i ++) 
				ListView_DeleteColumn (hwndControl, 1) ;
			for (i = 0 ; i < ARRAYSIZE (srOneMapColumnInfo) ; i ++) {
				lvColumn.cx			= srOneMapColumnInfo [i].m_nWidth ;
				lvColumn.pszText	= srOneMapColumnInfo [i].m_strTitle ;
				ListView_InsertColumn (hwndControl, i + 1, &lvColumn) ;
			}
		}
		if (IsDlgButtonChecked (hDlg, IDC_RADIO_MAJORMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JMODE] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_LATINMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_LATIN] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JISX0208LATINMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_ABBREVMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV] ;
		} else {
			return ;
		}
		lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvi.state		= 0 ; 
		lvi.stateMask	= 0 ;
		for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
			if (pKeymap->m_rbyBaseMap [i] != NFUNC_INVALID_CHAR) {
				int		nItem ;

				lvi.iItem		= i ;
				lvi.lParam		= (LPARAM) i ;
				vKey2String (szBuffer, ARRAYSIZE (szBuffer), i) ;
				lvi.pszText		= szBuffer ;
				nItem			= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), pKeymap->m_rbyBaseMap [i]))
						ListView_SetItemText (hwndControl, nItem, 1, szBuffer) ;
				}
			}
		}
		dlgEditKeymap_vUpdateExtraKeyItem (hwndControl, 1, 2, pKeymap->m_pKeyBinds, pKeymap->m_nKeyBinds) ;
	}
	return ;
}

void
dlgEditKeymap_vUpdateExtraKeyItem (
	HWND						hwndControl,
	int							iSubItem,
	int							iMaxSubItem,
	const struct CImeKeyBind*	pKeyBind,
	int							iNumKeyBind)
{
	TCHAR		szBuffer [256] ;
	LVITEM		lvi ;
	LVFINDINFO	lvfi ;
	int			i ;

	if (pKeyBind == NULL || iNumKeyBind <= 0)
		return ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
	lvi.state		= 0 ; 
	lvi.stateMask	= 0 ;

	memset (&lvfi, 0, sizeof (lvfi)) ;
	lvfi.flags	= LVFI_PARAM ;

	for (i = 0 ; i < iNumKeyBind ; i ++) {
		int		nItem ;

		lvfi.lParam	= (LPARAM) MAKE_EXTRA_KEYCODE (pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask) ;
		nItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;
		if (nItem == -1) {
			vKey2StringEx (szBuffer, ARRAYSIZE (szBuffer), pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask) ;
			lvi.iItem	= 0x1000 ;	/* MAX-VALUE�H */
			lvi.lParam	= lvfi.lParam ;
			lvi.pszText	= szBuffer ;

			nItem	= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				int		j ;
				/* �ŏ��ɍ쐬���ꂽ���́A���̃o�C���h��S�� "-" �ɂ��Ă����B*/
				for (j = 1 ; j < iMaxSubItem ; j ++) {
					if (j != iSubItem)
						ListView_SetItemText (hwndControl, nItem, j, TEXT ("-")) ;
				}
			}
		}
		if (nItem != -1) {
			if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), pKeyBind->m_nKeyFunction))
				ListView_SetItemText (hwndControl, nItem, iSubItem, szBuffer) ;
		}
		pKeyBind ++ ;
	}
	return ;
}

void
dlgEditKeymap_vEditKeyBind (
	HWND			hDlg,
	BOOL			bEdit)
{
	struct TEditKeymapArg*		pArg ;
	HWND						hWnd ;
	HINSTANCE					hInstance ;
	int							nCurSel, nResult, i ;
	LV_ITEM						lvi ;
	struct TDlgEditKeyBindArg	arg ;

	pArg	= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hWnd	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hWnd == NULL)
		return ;
	if (bEdit) {
		nCurSel	= ListView_GetSelectionMark (hWnd) ;
		if (nCurSel == -1)
			return ;
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask		= LVIF_PARAM ;
		lvi.iItem		= nCurSel ;
		lvi.iSubItem	= 0 ;
		if (ListView_GetItem (hWnd, &lvi) == -1)
			return ;
		arg.m_uKey				= (UINT) lvi.lParam ;
		for (i = 0 ; i < NUM_KEYMAPS ; i ++)
			arg.m_rbKeyBinds [i]	= dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [i], lvi.lParam) ;
	} else {
		arg.m_uKey				= (UINT) -1 ;
		for (i = 0 ; i < NUM_KEYMAPS ; i ++)
			arg.m_rbKeyBinds [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 0 ; i < NUM_KEYMAPS ; i ++)
		arg.m_rpMasterKeymaps [i]	= &pArg->m_rKeymaps [i] ;

	hInstance	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= DialogBoxParam (hInstance, MAKEINTRESOURCE (IDD_EDIT_KEYBIND), hDlg, dlgEditKeyBindProc, (LPARAM)&arg) ;
	if (nResult != IDOK)
		return ;

	if (arg.m_uKey == (unsigned int)-1) 
		return ;

	if (IS_EXTRA_KEY (arg.m_uKey)) {
		for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
			if (arg.m_rbKeyBinds [i]  != NFUNC_INVALID_CHAR) 
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [i], arg.m_uKey, arg.m_rbKeyBinds [i]) ;
		}
	} else if (0 <= arg.m_uKey && arg.m_uKey < MAX_KEYBINDS) {
		for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
			pArg->m_rKeymaps [i].m_rbyBaseMap [arg.m_uKey]	= arg.m_rbKeyBinds [i] ;
		}
	} else {
		return ;
	}
	/*	ListView �� update ���Ȃ���΂Ȃ�Ȃ��B*/
	dlgEditKeymap_vUpdate1Item (hDlg, arg.m_uKey) ;
	return ;
}

void
dlgEditKeymap_vUpdate1Item (
	HWND			hDlg,
	UINT			uKeyCode)
{
	struct TEditKeymapArg*		pArg ;
	HWND						hwndControl ;
	LVFINDINFO					lvfi ;
	BOOL						bDelete ;
	struct CImeKeymap*			pKeymap ;
	int							iItem, i ;

	pArg		= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (pArg == NULL || hwndControl == NULL)
		return ;

	/*	ExtraKeyItem �������ꍇ�ɍ폜���邩�ǂ����̔��f�͔����B���ɂ����� keybind
	 *	�����邩�ǂ����̃`�F�b�N���K�v�ɂȂ�B
	 */
	bDelete			= FALSE ;

	memset (&lvfi, 0, sizeof (lvfi)) ;
	lvfi.flags	= LVFI_PARAM ;
	lvfi.lParam	= uKeyCode ;
	iItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;

	if (IsDlgButtonChecked (hDlg, IDC_RADIO_MAJORMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JMODE] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_LATINMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_LATIN] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JISX0208LATINMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_ABBREVMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else {
		for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [i], uKeyCode) != NFUNC_INVALID_CHAR)
				break ;
		}
		bDelete		= (i >= NUM_KEYMAPS) ;
		pKeymap		= NULL ;
	}
	if (bDelete) {
		if (iItem != -1)
			ListView_DeleteItem (hwndControl, iItem) ;
	} else {
		TCHAR	szBuffer [256] ;
		int	iFuncCode ;

		if (iItem == -1) {
			LVITEM	lvi ;
			int		iMaxSubItem	= (pKeymap == NULL)? NUM_KEYMAPS : 1 ;

			memset (&lvi, 0, sizeof (lvi)) ;
			lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
			lvi.state		= 0 ; 
			lvi.stateMask	= 0 ;

			if (IS_EXTRA_KEY (uKeyCode)) {
				vKey2StringEx (szBuffer, ARRAYSIZE (szBuffer) - 1, EXTRA_KEYCODE_VKEY (uKeyCode), EXTRA_KEYCODE_MASK (uKeyCode)) ;
				lvi.iItem	= 0x1000 ;	/* MAX-VALUE�H */
			} else {
				vKey2String (szBuffer, ARRAYSIZE (szBuffer) - 1, uKeyCode) ;
				lvi.iItem	= (int) uKeyCode ;
			}
			szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
			lvi.lParam	= uKeyCode ;
			lvi.pszText	= szBuffer ;

			iItem	= ListView_InsertItem (hwndControl, &lvi) ;
			if (iItem != -1) {
				int		j ;
				/* �ŏ��ɍ쐬���ꂽ���́A���̃o�C���h��S�� "-" �ɂ��Ă����B*/
				for (j = 1 ; j <= iMaxSubItem ; j ++) 
					ListView_SetItemText (hwndControl, iItem, j, TEXT ("-")) ;
			}
		}
		if (pKeymap == NULL) {
			for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
				iFuncCode	= dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [i], uKeyCode) ;
				if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), iFuncCode))
					ListView_SetItemText (hwndControl, iItem, i + 1, szBuffer) ;
			}
		} else {
			iFuncCode	= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) ;
			if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), iFuncCode))
				ListView_SetItemText (hwndControl, iItem, 1, szBuffer) ;
		}
	}
	return ;
}

void
dlgEditKeymap_vDeleteKeyBind (
	HWND			hDlg)
{
	struct TEditKeymapArg*		pArg ;
	HWND	hWnd ;
	int		nCurSel, nResult ;
	TCHAR	bufText [256], bufKey [64] ;
	LV_ITEM	lvi ;
	UINT	uKey ;

	pArg	= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hWnd	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (pArg == NULL || hWnd == NULL)
		return ;
	nCurSel	= ListView_GetSelectionMark (hWnd) ;
	if (nCurSel == -1)
		return ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_PARAM ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	if (ListView_GetItem (hWnd, &lvi) == -1)
		return ;

	uKey			= (UINT) lvi.lParam ;
	if (IS_EXTRA_KEY (uKey)) {
		vKey2StringEx (bufKey, ARRAYSIZE (bufKey) - 1, EXTRA_KEYCODE_VKEY (uKey), EXTRA_KEYCODE_MASK (uKey)) ;
	} else {
		vKey2String (bufKey, ARRAYSIZE (bufKey) - 1, uKey) ;
	}
	bufKey [ARRAYSIZE (bufKey) - 1]	= TEXT ('\0') ;
	wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%s ���폜���܂��B��낵���ł����H"), bufKey) ;
	bufText [ARRAYSIZE (bufText) - 1]	= TEXT ('\0') ;

	nResult	= MessageBox (hWnd, bufText, TEXT ("�L�[�o�C���h�̍폜"), MB_YESNO) ;
	if (nResult == IDYES) {
		if (IS_EXTRA_KEY (uKey)) {
			/* INVALID_CHAR �ŏ㏑������B*/
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR],			uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR],			uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JMODE],				uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JMODE],				uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_LATIN],			uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_LATIN],			uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN],	uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN],	uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV],		uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV],		uKey, NFUNC_INVALID_CHAR) ;
		} else {
			if (/*0 <= uKey &&*/ uKey < MAX_KEYBINDS) {
				pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR].m_rbyBaseMap			[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_JMODE].m_rbyBaseMap				[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_LATIN].m_rbyBaseMap			[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN].m_rbyBaseMap	[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV].m_rbyBaseMap			[uKey]	= NFUNC_INVALID_CHAR ;
			}
		}
		ListView_DeleteItem (hWnd, nCurSel) ;
		return ;
	}
	return ;
}

int
dlgEditKeymap_iLookupKeymap (
	const struct CImeKeymap*	pKeymap,
	unsigned int				uKeyCode)
{
	if (uKeyCode == (unsigned int)-1)
		return	NFUNC_INVALID_CHAR ;

	if (IS_EXTRA_KEY (uKeyCode)) {
		/* ����L�[�}�b�v */
		int				i, nKeyCode ;
		unsigned int	uModifier ;

		nKeyCode	= EXTRA_KEYCODE_VKEY (uKeyCode) ;
		uModifier	= EXTRA_KEYCODE_MASK (uKeyCode) ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
			if (pKeymap->m_pKeyBinds [i].m_nKeyCode == nKeyCode &&
				pKeymap->m_pKeyBinds [i].m_uKeyMask == uModifier)
				return	pKeymap->m_pKeyBinds [i].m_nKeyFunction ;
		}
		return	NFUNC_INVALID_CHAR ;
	} else {
		/* �ʏ�B*/
		if (/*uKeyCode < 0 ||*/uKeyCode >= MAX_KEYBINDS)
			return	NFUNC_INVALID_CHAR ;

		return	pKeymap->m_rbyBaseMap [uKeyCode] ;
	}
}

BOOL
dlgEditKeymap_bDefineKeymap (
	struct CImeKeymap*			pKeymap,
	unsigned int				uKeyCode,
	int							iFuncCode)
{
	if (pKeymap == NULL)
		return	FALSE ;
	if (uKeyCode == (unsigned int)-1)
		return	FALSE ;
	if (IS_EXTRA_KEY (uKeyCode)) {
		struct CImeKeyBind*	pNewKeyBinds ;
		int				i, nKeyCode ;
		unsigned int	uModifier ;

		nKeyCode	= EXTRA_KEYCODE_VKEY (uKeyCode) ;
		uModifier	= EXTRA_KEYCODE_MASK (uKeyCode) ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
			if (pKeymap->m_pKeyBinds [i].m_nKeyCode == nKeyCode &&
				pKeymap->m_pKeyBinds [i].m_uKeyMask == uModifier) {
				pKeymap->m_pKeyBinds [i].m_nKeyFunction	= iFuncCode ;
				return	TRUE ;
			}
		}
		/*	���t����Ȃ������ꍇ�B
		 */
		pNewKeyBinds	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * (pKeymap->m_nKeyBinds + 1)) ;
		if (pNewKeyBinds == NULL)
			return	FALSE ;
		if (pKeymap->m_nKeyBinds > 0) 
			memcpy (pNewKeyBinds, pKeymap->m_pKeyBinds, sizeof (struct CImeKeyBind) * pKeymap->m_nKeyBinds) ;
		if (pKeymap->m_pKeyBinds != NULL)
			FREE (pKeymap->m_pKeyBinds) ;
		pKeymap->m_pKeyBinds	= pNewKeyBinds ;

		pKeymap->m_pKeyBinds [pKeymap->m_nKeyBinds].m_nKeyCode		= uKeyCode ;
		pKeymap->m_pKeyBinds [pKeymap->m_nKeyBinds].m_uKeyMask		= uModifier ;
		pKeymap->m_pKeyBinds [pKeymap->m_nKeyBinds].m_nKeyFunction	= iFuncCode ;
		pKeymap->m_nKeyBinds ++ ;
	} else {
		if (/*uKeyCode < 0 ||*/uKeyCode >= MAX_KEYBINDS)
			return	FALSE ;
		pKeymap->m_rbyBaseMap [uKeyCode]	= iFuncCode ;
	}
	return	TRUE ;
}

/*========================================================================
 *	private functions
 */
static	INT_PTR	dlgEditKeyBind_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditKeyBind_iOnCommand		(HWND, WPARAM, LPARAM) ;

static int	_srnComboBoxes [NUM_KEYMAPS]	= {
	IDC_COMBO_MAJORMODE_BIND,		IDC_COMBO_JMODE_BIND,
	IDC_COMBO_LATINMODE_BIND,		IDC_COMBO_JISX0208LATINMODE_BIND,
	IDC_COMBO_ABBREVMODE_BIND,
} ;

INT_PTR	CALLBACK
dlgEditKeyBindProc		(
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgEditKeyBind_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditKeyBind_iOnCommand (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgEditKeyBind_iOnInitDialog (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	struct TDlgEditKeyBindArg*	pArg	= (struct TDlgEditKeyBindArg*) lParam ;
	static struct {
		unsigned int	m_nKeyCode ;
		unsigned int	m_uKeyMask ;
	}	srExtraKeys []	= {
		/* �ǉ�����̂́A�J�[�\�����Ƃ��c�B*/
		{	VK_LEFT,	KEYMASK_NONE	},	{	VK_LEFT,	KEYMASK_CONTROL	},	{	VK_LEFT,	KEYMASK_SHIFT	},
		{	VK_UP,		KEYMASK_NONE	},	{	VK_UP,		KEYMASK_CONTROL	},	{	VK_UP,		KEYMASK_SHIFT	},
		{	VK_DOWN,	KEYMASK_NONE	},	{	VK_DOWN,	KEYMASK_CONTROL	},	{	VK_DOWN,	KEYMASK_SHIFT	},
		{	VK_RIGHT,	KEYMASK_NONE	},	{	VK_RIGHT,	KEYMASK_CONTROL	},	{	VK_RIGHT,	KEYMASK_SHIFT	},
		{	VK_INSERT,	KEYMASK_NONE	},	{	VK_INSERT,	KEYMASK_CONTROL	},	{	VK_INSERT,	KEYMASK_SHIFT	},
		{	VK_DELETE,	KEYMASK_NONE	},	{	VK_DELETE,	KEYMASK_CONTROL	},	{	VK_DELETE,	KEYMASK_SHIFT	},
		{	VK_BACK,	KEYMASK_NONE	},	{	VK_BACK,	KEYMASK_CONTROL	},	{	VK_BACK,	KEYMASK_SHIFT	},
		{	VK_TAB,		KEYMASK_NONE	},	{	VK_TAB,		KEYMASK_CONTROL	},	{	VK_TAB,		KEYMASK_SHIFT	},
		{	VK_HOME,	KEYMASK_NONE	},	{	VK_HOME,	KEYMASK_CONTROL	},	{	VK_HOME,	KEYMASK_SHIFT	},
		{	VK_SPACE,	KEYMASK_NONE	},	{	VK_SPACE,	KEYMASK_CONTROL	},	{	VK_SPACE,	KEYMASK_SHIFT	},
		{	VK_ESCAPE,	KEYMASK_NONE	},	{	VK_ESCAPE,	KEYMASK_CONTROL	},	{	VK_ESCAPE,	KEYMASK_SHIFT	},
		{	VK_KANJI,	KEYMASK_NONE	},	{	VK_KANJI,	KEYMASK_CONTROL	},	{	VK_KANJI,	KEYMASK_SHIFT	},
		{	VK_HELP,	KEYMASK_NONE	},	{	VK_HELP,	KEYMASK_CONTROL	},	{	VK_HELP,	KEYMASK_SHIFT	},
		{	VK_F1,		KEYMASK_NONE	},	{	VK_F1,		KEYMASK_CONTROL	},	{	VK_F1,		KEYMASK_SHIFT	},
		{	VK_F2,		KEYMASK_NONE	},	{	VK_F2,		KEYMASK_CONTROL	},	{	VK_F2,		KEYMASK_SHIFT	},
		{	VK_F3,		KEYMASK_NONE	},	{	VK_F3,		KEYMASK_CONTROL	},	{	VK_F3,		KEYMASK_SHIFT	},
		{	VK_F4,		KEYMASK_NONE	},	{	VK_F4,		KEYMASK_CONTROL	},	{	VK_F4,		KEYMASK_SHIFT	},
		{	VK_F5,		KEYMASK_NONE	},	{	VK_F5,		KEYMASK_CONTROL	},	{	VK_F5,		KEYMASK_SHIFT	},
		{	VK_F6,		KEYMASK_NONE	},	{	VK_F6,		KEYMASK_CONTROL	},	{	VK_F6,		KEYMASK_SHIFT	},
		{	VK_F7,		KEYMASK_NONE	},	{	VK_F7,		KEYMASK_CONTROL	},	{	VK_F7,		KEYMASK_SHIFT	},
		{	VK_F8,		KEYMASK_NONE	},	{	VK_F8,		KEYMASK_CONTROL	},	{	VK_F8,		KEYMASK_SHIFT	},
		{	VK_F9,		KEYMASK_NONE	},	{	VK_F9,		KEYMASK_CONTROL	},	{	VK_F9,		KEYMASK_SHIFT	},
		{	VK_F10,		KEYMASK_NONE	},	{	VK_F10,		KEYMASK_CONTROL	},	{	VK_F10,		KEYMASK_SHIFT	},
		{	VK_F11,		KEYMASK_NONE	},	{	VK_F11,		KEYMASK_CONTROL	},	{	VK_F11,		KEYMASK_SHIFT	},
		{	VK_F12,		KEYMASK_NONE	},	{	VK_F12,		KEYMASK_CONTROL	},	{	VK_F12,		KEYMASK_SHIFT	},
		{	VK_CLEAR,	KEYMASK_NONE	},	{	VK_CLEAR,	KEYMASK_CONTROL	},	{	VK_CLEAR,	KEYMASK_SHIFT	},
		{	VK_RETURN,	KEYMASK_NONE	},	{	VK_RETURN,	KEYMASK_CONTROL	},	{	VK_RETURN,	KEYMASK_SHIFT	},
	} ;
	HWND		hWndControl ;
	TCHAR		buf [256] ;
	int			i, j ;
	BOOL		bSetCurSel ;
	LRESULT		lResult ;

	if (pArg == NULL)
		return	FALSE ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pArg) ;
	hWndControl	= GetDlgItem (hDlg, IDC_COMBO_KEY) ;
	if (hWndControl == NULL)
		return	FALSE ;

	bSetCurSel	= FALSE ;
	/*	�L�[�̒ǉ��B*/
	for (i = 0 ; i < 128 ; i ++) {
		vKey2String (buf, ARRAYSIZE (buf) - 1, i) ;
		buf [ARRAYSIZE (buf) - 1]	= TEXT ('\0') ;
		lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) buf) ;
		if (lResult != CB_ERR) {
			if (! bSetCurSel && ! IS_EXTRA_KEY (pArg->m_uKey) &&  (UINT) i == pArg->m_uKey) {
				(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
				bSetCurSel	= TRUE ;
			}
			(void) SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM) (DWORD) i) ;
		}
	}
	/* ExtraKey �̒ǉ��B*/
	for (i = 0 ; i < ARRAYSIZE (srExtraKeys) ; i ++) {
		vKey2StringEx (buf, ARRAYSIZE (buf) - 1, srExtraKeys [i].m_nKeyCode, srExtraKeys [i].m_uKeyMask) ;
		buf [ARRAYSIZE (buf) - 1]	= TEXT ('\0') ;

		lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) buf) ;
		if (lResult != CB_ERR) {
			if (! bSetCurSel && 
				IS_EXTRA_KEY (pArg->m_uKey) && 
				EXTRA_KEYCODE_VKEY (pArg->m_uKey) == srExtraKeys [i].m_nKeyCode &&
				EXTRA_KEYCODE_MASK (pArg->m_uKey) == srExtraKeys [i].m_uKeyMask) {
				(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
				bSetCurSel	= TRUE ;
			}
			(void) SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM) (DWORD) MAKE_EXTRA_KEYCODE (srExtraKeys [i].m_nKeyCode, srExtraKeys [i].m_uKeyMask)) ;
		}
	}
	if (! bSetCurSel) 
		(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;

	for (i = 0 ; i < ARRAYSIZE (_srnComboBoxes) ; i ++) {
		hWndControl	= GetDlgItem (hDlg, _srnComboBoxes [i]) ;
		if (hWndControl == NULL)
			return	FALSE ;
		(void) SendMessage (hWndControl, CB_RESETCONTENT, (WPARAM) 0, (LPARAM) 0) ;
		bSetCurSel	= FALSE ;
		for (j = 0 ; j < NUM_SELECTABLE_FUNCTIONS ; j ++) {
			TCHAR	szBuffer [64] ;

			if (! bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer) - 1, j))
				continue ;
			szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
			lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM)szBuffer) ;
			if (lResult != CB_ERR) {
				if (j == pArg->m_rbKeyBinds [i]) {
					(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
					bSetCurSel	= TRUE ;
				}
				SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM)(DWORD) j) ;
			}
		}
		lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) TEXT ("-")) ;
		if (lResult != CB_ERR) {
			SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM)(DWORD) NFUNC_INVALID_CHAR) ;
			if (! bSetCurSel) 
				(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
		}
		/*	selection �����킹��B
		 */
	}
	return	FALSE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditKeyBind_iOnCommand (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	struct TDlgEditKeyBindArg*	pArg	= (struct TDlgEditKeyBindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	WORD	woControl		= LOWORD (wParam) ;
	//WORD	woNotification	= HIWORD (wParam) ;

	HWND	hWndControl ;
	int		i, nIndex, nFuncNo ;

	switch (woControl) {
	case	IDOK:
		if (pArg != NULL) {
			hWndControl	= GetDlgItem (hDlg, IDC_COMBO_KEY) ;
			if (hWndControl != NULL) {
				LRESULT	lValue ;

				pArg->m_uKey	= (UINT) -1 ;
				nIndex			= SendMessage (hWndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
				if (nIndex != CB_ERR) {
					/*	CB_ERR �̒l�ɒ��ӁB���� -1 ������ǂ����A���̐摝����ƁA
					 *	EXTRA_KEYCODE �Əd�Ȃ�\��������c�B
					 */
					lValue	= SendMessage (hWndControl, CB_GETITEMDATA, (WPARAM) nIndex, (LPARAM) 0) ;
					if (lValue != CB_ERR) 
						pArg->m_uKey	= (UINT) lValue ;
				}
				for (i = 0 ; i < ARRAYSIZE (_srnComboBoxes) ; i ++) {
					nFuncNo	= NFUNC_INVALID_CHAR ;
					hWndControl	= GetDlgItem (hDlg, _srnComboBoxes [i]) ;
					if (hWndControl != NULL) {
						nIndex	= SendMessage (hWndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
						if (nIndex != CB_ERR) {
							lValue	= SendMessage (hWndControl, CB_GETITEMDATA, (WPARAM) nIndex, (LPARAM) 0) ;
							if (lValue != CB_ERR)
								nFuncNo	= lValue ;
						}
					}
					pArg->m_rbKeyBinds [i]	= nFuncNo ;
	 			}
			} else {
				pArg->m_uKey	= (UINT) -1 ;
			}
		}
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}


/*========================================================================
 *	���[�}�����ȃ��[�����X�g�̕ҏW�_�C�A���O�p�̊֐��B
 */
static	INT_PTR	dlgRomaKanaRule_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgRomaKanaRule_iOnCommand		(HWND, WPARAM, LPARAM, BOOL) ;
static	INT_PTR	dlgRomaKanaRule_iOnNotify		(HWND, WPARAM, LPARAM) ;

static	void	dlgRomaKanaRule_vSyncControls	(HWND) ;
static	void	dlgRomaKanaRule_vSearchNextItem			(HWND) ;
static	void	dlgRomaKanaRule_vEditRomaKanaRule		(HWND, BOOL) ;
static	void	dlgRomaKanaRule_vDeleteRomaKanaRule		(HWND) ;

static	BOOL	dlgRomaKanaRule_bFullUpdateRomaKanaRule			(HWND) ;
static	BOOL	dlgRomaKanaRule_bUpdateRomaKanaRule				(HWND) ;
//static	void	dlgRomaKanaRule_vInitializeRomaKanaRule			(void) ;
static	void	dlgRomaKanaRule_vInitializeDefaultRomaKanaRule	(struct TSkkBaseRuleNode**) ;

static	INT_PTR	CALLBACK	ipDlgEditRomaKanaRuleProc	(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL	dlgRomaKanaRule_bLoadRomaKanaRuleList	(void) ;
static	BOOL	dlgRomaKanaRule_bSaveRomaKanaRuleList	(void) ;

static	BOOL	dlgRomaKanaRule_bLoadEnableOHHenkan		(void) ;
static	BOOL	dlgRomaKanaRule_bSaveEnableOHHenkan		(void) ;
static	int		dlgRomaKanaRule_iGetSelectedRule		(HWND) ;


INT_PTR	CALLBACK
dlgRomaKanaRuleProc (
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgRomaKanaRule_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgRomaKanaRule_iOnCommand (hDlg, wParam, lParam, TRUE) ;
	case	WM_NOTIFY:
		return	dlgRomaKanaRule_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR	CALLBACK
dlgJisx0201RuleProc (
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		{
			INT_PTR	nResult	= dlgRomaKanaRule_iOnInitDialog (hDlg, wParam, lParam) ;

			EnableDlgItem (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA, FALSE) ;
			EnableDlgItem (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA, FALSE) ;
			return	nResult ;
		}
	case	WM_COMMAND:
		return	dlgRomaKanaRule_iOnCommand (hDlg, wParam, lParam, FALSE) ;
	case	WM_NOTIFY:
		return	dlgRomaKanaRule_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgRomaKanaRule_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	PROPSHEETPAGE*	pPropSheetPage ;
	HWND			hwnd ;

	pPropSheetPage	= (PROPSHEETPAGE*) lParam ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pPropSheetPage->lParam) ;

	hwnd	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwnd != NULL)
		ListView_SetExtendedListViewStyle (hwnd, LVS_EX_FULLROWSELECT) ;

	CheckRadioButton (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA) ;
	CheckRadioButton (hDlg, IDC_RADIO_DESCLONG, IDC_RADIO_DESCSHORT, IDC_RADIO_DESCSHORT) ;
	CheckRadioButton (hDlg, IDC_RADIO_SHOWROMAKANARULE0, IDC_RADIO_SHOWROMAKANARULE3, IDC_RADIO_SHOWROMAKANARULE0) ;
	dlgRomaKanaRule_vSyncControls (hDlg) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgRomaKanaRule_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam,
	BOOL			bEnableHiraKata)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_RADIO_SHOWROMAKANARULE0:
	case	IDC_RADIO_SHOWROMAKANARULE1:
	case	IDC_RADIO_SHOWROMAKANARULE2:
	case	IDC_RADIO_SHOWROMAKANARULE3:
		if (woNotification == BN_CLICKED) {
			CheckRadioButton (hDlg, IDC_RADIO_SHOWROMAKANARULE0, IDC_RADIO_SHOWROMAKANARULE3, woControl) ;
			dlgRomaKanaRule_bFullUpdateRomaKanaRule (hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_RADIO_DESCLONG:
	case	IDC_RADIO_DESCSHORT:
		if (woNotification == BN_CLICKED) {
			if (IsDlgButtonChecked (hDlg, (woControl == IDC_RADIO_DESCLONG)? IDC_RADIO_DESCSHORT : IDC_RADIO_DESCLONG) == BST_CHECKED) {
				CheckRadioButton (hDlg, IDC_RADIO_DESCLONG, IDC_RADIO_DESCSHORT, woControl) ;
				dlgRomaKanaRule_bFullUpdateRomaKanaRule (hDlg) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA:
	case	IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA:
		if (woNotification == BN_CLICKED) {
			if (IsDlgButtonChecked (hDlg, (woControl == IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA)? IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA : IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA) == BST_CHECKED) {
				CheckRadioButton (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA, woControl) ;
				dlgRomaKanaRule_bUpdateRomaKanaRule (hDlg) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_SEARCH_ROMKANARULE_NEXT:
		if (woNotification == BN_CLICKED) {
			dlgRomaKanaRule_vSearchNextItem (hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_INSERT_ROMKANARULE:
	case	IDC_BUTTON_EDIT_ROMKANARULE:
		dlgRomaKanaRule_vEditRomaKanaRule (hDlg, bEnableHiraKata) ;
		return	0 ;
	case	IDC_BUTTON_DELETE_ROMKANARULE:
		dlgRomaKanaRule_vDeleteRomaKanaRule (hDlg) ;
		return	0 ;
	case	IDOK:
	case	IDCANCEL:
//		SetWindowLong (hDlg, DWL_MSGRESULT, (woControl == IDOK)? TRUE : FALSE) ;
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgRomaKanaRule_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	int		idControl	= (int) wParam ;
	LPNMHDR	pnmh		= (LPNMHDR) lParam ;

	if (pnmh == NULL)
		return	0 ;

	switch (idControl) {
	case	IDC_LIST_ROMAKANARULE:
		{
			switch (pnmh->code) {
			case	LVN_DELETEALLITEMS:
				EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   FALSE) ;
				EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, FALSE) ;
				break ;
			case	LVN_DELETEITEM:
				{
					LPNMLISTVIEW	pnmv	= (LPNMLISTVIEW) lParam ;
					HWND			hwnd	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
					int	nCurSel ;

					nCurSel	= (hwnd != NULL)? ListView_GetSelectionMark (hwnd) : -1 ;
					if (pnmv != NULL && pnmv->iItem == nCurSel) {
						EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   FALSE) ;
						EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, FALSE) ;
					}
				}
				break ;
			case	NM_CLICK:
			case	NM_RCLICK:
			case	NM_DBLCLK:
			case	NM_RDBLCLK:
			case	LVN_ITEMACTIVATE:
			case	LVN_ITEMCHANGED:
				EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   TRUE) ;
				EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, TRUE) ;
				break ;
			default:
				break ;
			}
		}
		break ;
	default:
		break ;
	}
	return	1 ;
}

void
dlgRomaKanaRule_vSyncControls (
	HWND						hDlg)
{
	dlgRomaKanaRule_bFullUpdateRomaKanaRule (hDlg) ;
	return ;
}

void
dlgRomaKanaRule_vSearchNextItem (
	HWND			hDlg)
{
	TCHAR		bufText [ROMAKANALIST_LONG_LEN], bufMatch [ROMAKANALIST_LONG_LEN] ;
	UINT		nTextLen ;
	HWND		hwndRuleList ;
	LVFINDINFO	lvfi ;
	int			nStart, nItem ;

	hwndRuleList	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndRuleList == NULL)
		return ;

	nTextLen	= GetDlgItemText (hDlg, IDC_EDIT_SEARCH_ROMKANARULE, bufText, ARRAYSIZE (bufText) - 1) ;
	bufText [nTextLen]	= TEXT ('\0') ;
	if (nTextLen <= 0)
		return ;

	nStart		= ListView_GetSelectionMark (hwndRuleList) ;
	memset (&lvfi, 0, sizeof (lvfi)) ;
	lvfi.flags	= LVFI_PARTIAL ;
	lvfi.psz	= bufText ;
	nItem		= ListView_FindItem (hwndRuleList, nStart, &lvfi) ;
	if (nItem == -1)
		return ;

	/* �擪���炫����� match ���Ă��邩�m�F����B*/
	ListView_GetItemText (hwndRuleList, nItem, 0, bufMatch, ARRAYSIZE (bufMatch) - 1) ;
	bufMatch [ARRAYSIZE (bufMatch) - 1]	= TEXT ('\0') ;
	if (_tcsncmp (bufText, bufMatch, nTextLen) != 0)
		return ;

	ListView_EnsureVisible (hwndRuleList, nItem, FALSE) ;
	ListView_SetItemState  (hwndRuleList, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
	ListView_SetSelectionMark (hwndRuleList, nItem) ;

	/* Button �� Enable �ɂ��Ȃ���΁B*/
	EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   TRUE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, TRUE) ;
	return ;
}

void
dlgRomaKanaRule_vEditRomaKanaRule (
	HWND			hDlg,
	BOOL			bEnableHiraKata)
{
	struct TSkkBaseRuleNode**	pplstRules ;
	HINSTANCE					hInstance ;
	struct TEditRomaKanaRuleArg	arg ;
	struct TSkkBaseRuleNode*	pNode ;
	HWND	hwndRuleList ;
	LVITEM	lvi ;
	int		nCurSel, iCurRule ;

	hInstance		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pplstRules		= (struct TSkkBaseRuleNode**) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pplstRules == NULL)
		return ;
	hwndRuleList	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndRuleList == NULL)
		return ;

	pNode	= NULL ;
	nCurSel	= ListView_GetSelectionMark (hwndRuleList) ;
	if (nCurSel != -1) {
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM ;
		lvi.iItem	= nCurSel ;
		if (! ListView_GetItem (hwndRuleList, &lvi) || lvi.lParam == 0)
			return ;
		pNode	= (struct TSkkBaseRuleNode*) lvi.lParam ;
	}

	arg.m_pInitValue	= pNode ;
	arg.m_nType			= -1 ;
	iCurRule			= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;
	arg.m_iRule			= iCurRule ;
	arg.m_bufHiraOrCommon [0]	= TEXT ('\0') ;
	arg.m_bufKata [0]			= TEXT ('\0') ;
	arg.m_nFunction				= NFUNC_INVALID_CHAR ;
	arg.m_bEnableRule1			= bEnableHiraKata ;
	if (DialogBoxParam (hInstance, MAKEINTRESOURCE (IDD_ROMAKANARULE2), hDlg, ipDlgEditRomaKanaRuleProc, (LPARAM) &arg) == IDOK) {
		/* update */
		struct TSkkBaseRuleNode*	pNewNode	= NULL ;
		TCHAR	szNew [ROMAKANALIST_LONG_LEN] ;
		LPCTSTR	pwNextState	= NULL ;
		HWND	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
		BOOL	bRomaKanaRuleShowKata, bRomaKanaRuleShowShort ;

		/* arg.m_pResult ��o�^����B*/
		/*	�������Ɏg�������̂� result �� state ���قȂ��Ă����ꍇ�ł��A���� state ���g���Ă���
		 *	�ꍇ�ɂ� reminder ���o���B�����łȂ��ꍇ�͕������Ă��ĕύX�����񂾂��� ok �Ƃ��邱�Ƃɂ�
		 *	��B
		 */
		/*	update or �ǉ��B
		 */
		pwNextState	= (arg.m_bufNextState [0] != TEXT ('\0'))? arg.m_bufNextState : NULL ;
		switch (arg.m_nType) {
		case	ROMAKANARULE_TYPE1:
			pNewNode	= dlgRomaKanaRule_pCreateType1Rule (arg.m_bufState, pwNextState, arg.m_iNextRule, arg.m_bufHiraOrCommon, arg.m_bufKata) ;
			break ;
		case	ROMAKANARULE_TYPE2:
			pNewNode	= dlgRomaKanaRule_pCreateType2Rule (arg.m_bufState, pwNextState, arg.m_iNextRule, arg.m_bufHiraOrCommon) ;
			break ;
		case	ROMAKANARULE_TYPE3:
			pNewNode	= dlgRomaKanaRule_pCreateType3Rule (arg.m_bufState, pwNextState, arg.m_iNextRule, arg.m_nFunction) ;
			break ;
		default:
			pNewNode	= NULL ;
			break ;
		}
		if (pNewNode == NULL)	/* fatal error ... */
			return ;

		/*	current state �Ō�������B
		 */
		pNode	= dlgRomaKanaRule_pSearchRuleByState (pplstRules [arg.m_iRule], arg.m_bufState, FALSE) ;
		if (pNode != NULL  && pNode != arg.m_pInitValue) {
			TCHAR	bufText [ROMAKANALIST_LONG_LEN*2] ;
			int		n ;

			{
				TCHAR	szOld [ROMAKANALIST_LONG_LEN] ;

				dlgRomaKanaRule_vGetEntryString (szOld, ARRAYSIZE (szOld), pNode,    arg.m_iRule, ROMAKANA_SHOW_BOTH, FALSE) ;
				dlgRomaKanaRule_vGetEntryString (szNew, ARRAYSIZE (szNew), pNewNode, arg.m_iRule, ROMAKANA_SHOW_BOTH, FALSE) ;
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%s �� %s �Œu�������܂��B��낵���ł����H"), szOld, szNew) ;
			}
			bufText [n]	= TEXT ('\0') ;

			if (MessageBox (hDlg, bufText, TEXT ("�m�F"), MB_YESNO) != IDYES) {
				FREE (pNewNode) ;
				return ;
			}
		}

		bRomaKanaRuleShowKata	= IsDlgButtonChecked (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA) == BST_CHECKED ;
		bRomaKanaRuleShowShort	= IsDlgButtonChecked (hDlg, IDC_RADIO_DESCSHORT) == BST_CHECKED ;

		dlgRomaKanaRule_vGetEntryString (szNew, ARRAYSIZE (szNew), pNewNode, arg.m_iRule, bRomaKanaRuleShowKata, bRomaKanaRuleShowShort) ;
		if (pNode != NULL) {
			LVFINDINFO	lvfi ;
			int			nItem ;

			/* �Â� node ����������B*/
			dlgRomaKanaRule_bUnegisterRule (&pplstRules [arg.m_iRule], pNode) ;
			dlgRomaKanaRule_vRegisterRule (&pplstRules [arg.m_iRule], pNewNode) ;

			/*	���ݕ\������Ă��郊�X�g�łȂ���΁AListView �̒��g���X�V����K�v�͂Ȃ��B
			 */
			if (arg.m_iRule == iCurRule) {
				memset (&lvfi, 0, sizeof (lvfi)) ;
				lvfi.flags	= LVFI_PARAM ;
				lvfi.lParam	= (LPARAM) pNode ;
				nItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;
				if (nItem != -1) {
					LVITEM	lvi ;

					memset (&lvi, 0, sizeof (lvi)) ;
					lvi.mask		= LVIF_PARAM | LVIF_TEXT ;
					lvi.lParam		= (LPARAM) pNewNode ;
					lvi.iItem		= nItem ;
					lvi.iSubItem	= 0 ;
					lvi.pszText		= szNew ;
					if (ListView_SetItem (hwndControl, &lvi)) {
						ListView_Update (hwndControl, nItem) ;
					}
				}
			}
			FREE (pNode) ;
		} else {
			/*	���ݕ\������Ă��郊�X�g�łȂ���΁AListView �̒��g���X�V����K�v�͂Ȃ��B
			 */
			if (arg.m_iRule == iCurRule) {
				/* �V���� node ��ǉ�����B*/
				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
				lvi.lParam	= (LPARAM) pNewNode ;
				lvi.pszText	= szNew ;
				if (ListView_InsertItem (hwndControl, &lvi) == -1) {
					FREE (pNewNode) ;
					return ;
				}
			}
			dlgRomaKanaRule_vRegisterRule (&pplstRules [arg.m_iRule], pNewNode) ;
		}
	}
	return ;
}

void
dlgRomaKanaRule_vDeleteRomaKanaRule (
	HWND						hDlg)
{
	struct TSkkBaseRuleNode**	pplstRules ;
	HWND	hwndRuleList ;
	struct TSkkBaseRuleNode*	pNode ;
	TCHAR	bufEntry [512] ;
	TCHAR	bufText [1024] ;
	LVITEM	lvi ;
	int		n, nCurSel, nResult, iRule ;

	pplstRules		= (struct TSkkBaseRuleNode**) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndRuleList	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (pplstRules == NULL || hwndRuleList == NULL)
		return ;
	nCurSel	= 	ListView_GetSelectionMark (hwndRuleList) ;
	if (nCurSel == -1)
		return ;

	iRule		= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask	= LVIF_PARAM ;
	lvi.iItem	= nCurSel ;
	if (! ListView_GetItem (hwndRuleList, &lvi) || lvi.lParam == 0)
		return ;

	pNode	= (struct TSkkBaseRuleNode*) lvi.lParam ;
	dlgRomaKanaRule_vGetEntryString (bufEntry, ARRAYSIZE (bufEntry), pNode, iRule, ROMAKANA_SHOW_BOTH, FALSE) ;
	n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%s ���폜���܂��B��낵���ł����H"), bufEntry) ;
	bufText [n]	= TEXT ('\0') ;

	nResult	= MessageBox (hDlg, bufText, TEXT ("���[�}�������[���̍폜"), MB_YESNO) ;
	if (nResult == IDYES) {
		dlgRomaKanaRule_bUnegisterRule (&pplstRules [iRule], pNode) ;
		FREE (pNode) ;
		ListView_DeleteItem (hwndRuleList, nCurSel) ;
	}
	return ;
}

int
dlgRomaKanaRule_iGetSelectedRule (
	HWND		hDlg)
{
	int		i ;
	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++)
		if (IsDlgButtonChecked (hDlg, IDC_RADIO_SHOWROMAKANARULE0 + i) == BST_CHECKED)
			return	i ;
	return	0 ;
}

/*========================================================================
 *	private functions
 */
/*	����͑S���X�V���Ă��܂��̂Œ��ӁB
 */
BOOL
dlgRomaKanaRule_bFullUpdateRomaKanaRule (
	HWND						hDlg)
{
	struct TSkkBaseRuleNode**		pplstRules ;
	const struct TSkkBaseRuleNode*	pNode ;
	const struct TSkkBaseRuleNode*	pNodeSelected = NULL ;
	HWND	hwndControl	= NULL ;
	TCHAR	szBuffer [ROMAKANALIST_LONG_LEN] ;
	LVITEM	lvi ;
	int		nItem, nRule ;
	BOOL	bRomaKanaRuleShowShort, bRomaKanaRuleShowKata ;

	pplstRules	= (struct TSkkBaseRuleNode**) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pplstRules == NULL)
		return	FALSE ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndControl == NULL)
		return	FALSE ;

	/*	���݃Z���N�V�����}�[�N������m�[�h�͍X�V����Z���N�V�����}�[�N���c�������B
	 *	�}���`�Z���N�V�����ł͂Ȃ��̂ŁA1�L�����邾���� ok 
	 */
	nItem	= ListView_GetSelectionMark (hwndControl) ;
	if (nItem != -1) {
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM ;
		lvi.iItem	= nItem ;
		if (ListView_GetItem (hwndControl, &lvi)) 
			pNodeSelected	= (const struct TSkkBaseRuleNode*) lvi.lParam ;
	}

	bRomaKanaRuleShowKata	= IsDlgButtonChecked (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA) == BST_CHECKED ;
	bRomaKanaRuleShowShort	= IsDlgButtonChecked (hDlg, IDC_RADIO_DESCSHORT) == BST_CHECKED ;

	ListView_DeleteAllItems (hwndControl) ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
	lvi.state		= 0 ; 
	lvi.stateMask	= 0 ;

	nRule	= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;
	pNode	= pplstRules [nRule] ;
	while (pNode != NULL) {
		dlgRomaKanaRule_vGetEntryString (szBuffer, ARRAYSIZE (szBuffer), pNode, nRule, bRomaKanaRuleShowKata, bRomaKanaRuleShowShort) ;
		lvi.iItem		= 0 ;
		lvi.iImage		= 0 ;
		lvi.iSubItem	= 0 ;
		lvi.lParam		= (LPARAM) pNode ;
		lvi.pszText		= szBuffer ;
		nItem			= ListView_InsertItem (hwndControl, &lvi) ;
		pNode	= pNode->_pNext ;
	}
	if (pNodeSelected != NULL) {
		LVFINDINFO	lvfi ;

		memset (&lvfi, 0, sizeof (lvfi)) ;
		lvfi.flags	= LVFI_PARAM ;
		lvfi.lParam	= (LPARAM) pNodeSelected ;
		nItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;
		if (nItem != -1) {
			ListView_SetItemState  (hwndControl, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
			ListView_SetSelectionMark (hwndControl, nItem) ;
		}
	}
	return	TRUE ;
}

BOOL
dlgRomaKanaRule_bUpdateRomaKanaRule (
	HWND						hDlg)
{
	const struct TSkkBaseRuleNode*	pNode ;
	HWND	hwndControl	= NULL ;
	TCHAR	szBuffer [ROMAKANALIST_LONG_LEN] ;
	LVITEM	lvi ;
	int		nIndex, nMaxIndex, iRule ;
	BOOL	bRomaKanaRuleShowKata, bRomaKanaRuleShowShort ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndControl == NULL)
		return	FALSE ;

	bRomaKanaRuleShowKata	= IsDlgButtonChecked (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA) == BST_CHECKED ;
	bRomaKanaRuleShowShort	= IsDlgButtonChecked (hDlg, IDC_RADIO_DESCSHORT) == BST_CHECKED ;
	iRule					= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;

	/*	���݃Z���N�V�����}�[�N������m�[�h�͍X�V����Z���N�V�����}�[�N���c�������B
	 *	�}���`�Z���N�V�����ł͂Ȃ��̂ŁA1�L�����邾���� ok 
	 */
	memset (&lvi, 0, sizeof (lvi)) ;
	nMaxIndex	= ListView_GetItemCount (hwndControl) ;
	for (nIndex = 0 ; nIndex < nMaxIndex ; nIndex ++) {
		lvi.mask	= LVIF_PARAM ;
		lvi.iItem	= nIndex ;
		if (ListView_GetItem (hwndControl, &lvi)) {
			pNode	= (const struct TSkkBaseRuleNode*) lvi.lParam ;
			dlgRomaKanaRule_vGetEntryString (szBuffer, ARRAYSIZE (szBuffer), pNode, iRule, bRomaKanaRuleShowKata, bRomaKanaRuleShowShort) ;
			ListView_SetItemText (hwndControl, nIndex, 0, szBuffer) ;
		}
	}
	return	TRUE ;
}

#if 0
void
dlgRomaKanaRule_vInitializeRomaKanaRule (void)
{
	/* �����Ƀ��W�X�g����ǂނƂ�����Ƃ�����B*/
	if (! dlgRomaKanaRule_bLoadRomaKanaRuleList ()) {
		/* ���W�X�g���ɐݒ肪�Ȃ��ꍇ�̓f�t�H���g�̂𗘗p����B*/
		dlgRomaKanaRule_vInitializeDefaultRomaKanaRule () ;
	}
	return ;
}
#endif

void
dlgRomaKanaRule_vInitializeDefaultRomaKanaRule (
	struct TSkkBaseRuleNode**		pplist)
{
	struct TSkkBaseRuleNode*		pNode ;
	const struct TSkkBaseRuleT1*	pT1 ;
	const struct TSkkBaseRuleT2*	pT2 ;
	const struct TSkkBaseRuleT3*	pT3 ;
	int								nIndex ;

	pT1	= _rDefaultRomaKanaRuleType1 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultRomaKanaRuleType1) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType1Rule (pT1->_strState, pT1->_strNext, pT1->_iNextRule, pT1->_case._strHira, pT1->_case._strKata) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [0], pNode) ;
		pT1	++ ;
	}

	pT1	= _rDefaultRomaKanaRuleType1_1 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultRomaKanaRuleType1_1) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType1Rule (pT1->_strState, pT1->_strNext, pT1->_iNextRule, pT1->_case._strHira, pT1->_case._strKata) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [1], pNode) ;
		pT1	++ ;
	}

	pT2	= _rDefaultRomaKanaRuleType2 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultRomaKanaRuleType2) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType2Rule (pT2->_strState, pT2->_strNext, pT2->_iNextRule, pT2->_strOutput) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [0], pNode) ;
		pT2	++ ;
	}
	pT3	= _rDefaultRomaKanaRuleType3 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultRomaKanaRuleType3) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType3Rule (pT3->_strState, pT3->_strNext, pT3->_iNextRule, pT3->_nFunction) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [0], pNode) ;
		pT3	++ ;
	}
	pplist [2]	= NULL ;
	pplist [3]	= NULL ;
	return ;
}

void
dlgRomaKanaRule_vInitializeDefaultJisx0201KanaRule (
	struct TSkkBaseRuleNode**		pplist)
{
	struct TSkkBaseRuleNode*		pNode ;
	const struct TSkkBaseRuleT2*	pT2 ;
	const struct TSkkBaseRuleT3*	pT3 ;
	int								nIndex ;

	pT2	= _rDefaultJisx0201KanaRuleType2 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultJisx0201KanaRuleType2) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType2Rule (pT2->_strState, pT2->_strNext, pT2->_iNextRule, pT2->_strOutput) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [0], pNode) ;
		pT2	++ ;
	}
	pT2	= _rDefaultJisx0201KanaRuleType2_1 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultJisx0201KanaRuleType2_1) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType2Rule (pT2->_strState, pT2->_strNext, pT2->_iNextRule, pT2->_strOutput) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [1], pNode) ;
		pT2	++ ;
	}
	pT3	= _rDefaultJisx0201KanaRuleType3 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultJisx0201KanaRuleType3) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType3Rule (pT3->_strState, pT3->_strNext, pT3->_iNextRule, pT3->_nFunction) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [0], pNode) ;
		pT3	++ ;
	}
	pplist [2]	= NULL ;
	pplist [3]	= NULL ;
	return ;
}

void
dlgRomaKanaRule_vInitializeDefaultJisx0201RomanRule (
	struct TSkkBaseRuleNode**		pplist)
{
	struct TSkkBaseRuleNode*		pNode ;
	const struct TSkkBaseRuleT2*	pT2 ;
	int								nIndex ;

	pT2	= _rDefaultJisx0201RomanRuleType2 ;
	for (nIndex = 0 ; nIndex < ARRAYSIZE (_rDefaultJisx0201RomanRuleType2) ; nIndex ++) {
		pNode	= dlgRomaKanaRule_pCreateType2Rule (pT2->_strState, pT2->_strNext, pT2->_iNextRule, pT2->_strOutput) ;
		if (pNode != NULL)
			dlgRomaKanaRule_vRegisterRule (&pplist [0], pNode) ;
		pT2	++ ;
	}
	pplist [2]	= NULL ;
	pplist [3]	= NULL ;
	return ;
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pCreateType1Rule (
	LPCTSTR							pwState,		/* 0 �������Ȃ��c */
	LPCTSTR							pwNext,
	int								iNextRule,
	LPCTSTR							pwKana,
	LPCTSTR							pwKatakana)
{
	struct TSkkBaseRuleNode*	pNode ;
	LPTSTR	pwDest ;
	int		nSize, nStateLen, nKanaLen, nKatakanaLen ;

	if (pwState == NULL)
		return	NULL ;

	nSize			= sizeof (struct TSkkBaseRuleNode) ;
	nStateLen		= lstrlen (pwState) ;
	nKanaLen		= (pwKana     != NULL)? lstrlen (pwKana)     : 0 ;
	nKatakanaLen	= (pwKatakana != NULL)? lstrlen (pwKatakana) : 0 ;
	nSize			+= (nStateLen    + 1) * sizeof (TCHAR) ;
	nSize			+= (nKanaLen     + 1) * sizeof (TCHAR) ;
	nSize			+= (nKatakanaLen + 1) * sizeof (TCHAR) ;
	if (pwNext != NULL) 
		nSize		+= (lstrlen (pwNext) + 1) * sizeof (TCHAR) ;
	if (nSize <= sizeof (struct TSkkBaseRuleNode))
		return	NULL ;
	pNode			= (struct TSkkBaseRuleNode*) MALLOC (nSize) ;

	pNode->_nType	= ROMAKANARULE_TYPE1 ;
	pNode->_pNext	= NULL ;

	pwDest			= (LPTSTR) (pNode + 1) ;
	pNode->_T1._strState	= pwDest ;
	lstrcpy (pwDest, pwState) ;
	pwDest			+= nStateLen + 1 ;

	pNode->_T1._case._strHira	= pwDest ;
	if (pwKana != NULL) {
		lstrcpy (pwDest, pwKana) ;
	} else {
		*pwDest	= TEXT ('\0') ;
	}
	pwDest		+= nKanaLen + 1 ;

	pNode->_T1._case._strKata	= pwDest ;
	if (pwKatakana != NULL) {
		lstrcpy (pwDest, pwKatakana) ;
	} else {
		*pwDest	= TEXT ('\0') ;
	}
	pwDest		+= nKatakanaLen + 1 ;

	if (pwNext != NULL) {
		pNode->_T1._strNext	= pwDest ;
		lstrcpy (pwDest, pwNext) ;
	} else {
		pNode->_T1._strNext	= NULL ;
	}
	pNode->_T1._iNextRule	= iNextRule ;
	return	pNode ;
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pCreateType2Rule (
	LPCTSTR							pwState,		/* 0 �������Ȃ��c */
	LPCTSTR							pwNext,
	int								iNextRule,
	LPCTSTR							pwString)
{
	struct TSkkBaseRuleNode*	pNode ;
	LPTSTR	pwDest ;
	int		nSize, nStateLen, nStringLen ;

	if (pwState == NULL)
		return	NULL ;

	nSize			= sizeof (struct TSkkBaseRuleNode) ;
	nStateLen		= lstrlen (pwState) ;
	nStringLen		= (pwString != NULL)? lstrlen (pwString) : 0 ;
	nSize			+= (nStateLen  + 1) * sizeof (TCHAR) ;
	nSize			+= (nStringLen + 1) * sizeof (TCHAR) ;
	if (pwNext != NULL) 
		nSize		+= (lstrlen (pwNext) + 1) * sizeof (TCHAR) ;
	if (nSize <= sizeof (struct TSkkBaseRuleNode))
		return	NULL ;
	pNode			= (struct TSkkBaseRuleNode*) MALLOC (nSize) ;

	pNode->_nType	= ROMAKANARULE_TYPE2 ;
	pNode->_pNext	= NULL ;

	pwDest			= (LPTSTR) (pNode + 1) ;
	pNode->_T2._strState	= pwDest ;
	lstrcpy (pwDest, pwState) ;
	pwDest			+= nStateLen + 1 ;

	pNode->_T2._strOutput	= pwDest ;
	if (pwString != NULL) {
		lstrcpy (pwDest, pwString) ;
	} else {
		*pwDest	= TEXT ('\0') ;
	}
	pwDest		+= nStringLen + 1 ;

	if (pwNext != NULL) {
		pNode->_T2._strNext	= pwDest ;
		lstrcpy (pwDest, pwNext) ;
	} else {
		pNode->_T2._strNext	= NULL ;
	}
	pNode->_T2._iNextRule	= iNextRule ;
	return	pNode ;
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pCreateType3Rule (
	LPCTSTR							pwState,		/* 0 �������Ȃ��c */
	LPCTSTR							pwNext,
	int								iNextRule,
	int								nFuncNo)
{
	struct TSkkBaseRuleNode*	pNode ;
	LPTSTR	pwDest ;
	int		nSize, nStateLen ;

	if (pwState == NULL || nFuncNo < 0 || nFuncNo >= NUM_SELECTABLE_FUNCTIONS)
		return	NULL ;

	nSize			= sizeof (struct TSkkBaseRuleNode) ;
	nStateLen		= lstrlen (pwState) ;
	nSize			+= (nStateLen  + 1) * sizeof (TCHAR) ;
	if (pwNext != NULL) 
		nSize		+= (lstrlen (pwNext) + 1) * sizeof (TCHAR) ;
	if (nSize <= sizeof (struct TSkkBaseRuleNode))
		return	NULL ;
	pNode			= (struct TSkkBaseRuleNode*) MALLOC (nSize) ;

	pNode->_nType	= ROMAKANARULE_TYPE3 ;
	pNode->_pNext	= NULL ;

	pwDest			= (LPTSTR) (pNode + 1) ;
	pNode->_T3._strState	= pwDest ;
	lstrcpy (pwDest, pwState) ;
	pwDest			+= nStateLen + 1 ;
	pNode->_T3._nFunction	= nFuncNo ;

	if (pwNext != NULL) {
		pNode->_T3._strNext	= pwDest ;
		lstrcpy (pwDest, pwNext) ;
	} else {
		pNode->_T3._strNext	= NULL ;
	}
	pNode->_T3._iNextRule	= iNextRule ;
	return	pNode ;
}

struct TSkkBaseRuleNode*
pCopySkkBaseRuleNode (
	struct TSkkBaseRuleNode*		pNode)
{
	switch (pNode->_nType) {
	case	ROMAKANARULE_TYPE1:
		return	dlgRomaKanaRule_pCreateType1Rule (pNode->_T1._strState, pNode->_T1._strNext, pNode->_T1._iNextRule, pNode->_T1._case._strHira, pNode->_T1._case._strKata) ;
	case	ROMAKANARULE_TYPE2:
		return	dlgRomaKanaRule_pCreateType2Rule (pNode->_T2._strState, pNode->_T2._strNext, pNode->_T2._iNextRule, pNode->_T2._strOutput) ;
	case	ROMAKANARULE_TYPE3:
		return	dlgRomaKanaRule_pCreateType3Rule (pNode->_T3._strState, pNode->_T3._strNext, pNode->_T3._iNextRule, pNode->_T3._nFunction) ;
	default:
		return	NULL ;
	}
}

void	dlgRomaKanaRule_vRegisterRule (
	struct TSkkBaseRuleNode**			pplst,
	struct TSkkBaseRuleNode*			pNode)
{
	if (pplst == NULL || pNode == NULL)
		return ;
	pNode->_pNext	= *pplst ;
	*pplst			= pNode ;
	return ;
}

BOOL
dlgRomaKanaRule_bUnegisterRule (
	struct TSkkBaseRuleNode**			pplst,
	struct TSkkBaseRuleNode*			pNodeToUnregister)
{
	struct TSkkBaseRuleNode*	pNode ;
	struct TSkkBaseRuleNode*	pPrevNode ;

	pNode		= *pplst ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		if (pNode == pNodeToUnregister) {
			if (pPrevNode != NULL) {
				pPrevNode->_pNext	= pNode->_pNext ;
			} else {
				*pplst	= pNode->_pNext ;
			}
			pNode->_pNext	= NULL ;
			return	TRUE ;
		}
		pPrevNode	= pNode ;
		pNode		= pNode->_pNext ;
	}
	return	FALSE ;
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pSearchRuleByState (
	struct TSkkBaseRuleNode*	plst,
	LPCTSTR						strState,
	BOOL						bPrefix)
{
	struct TSkkBaseRuleNode*	pNode ;

	if (strState == NULL)
		return	NULL ;

	pNode		= plst ;
	if (bPrefix) {
		int		nStateLen	= lstrlen (strState) ;

		while (pNode != NULL) {
			switch (pNode->_nType) {
			case	ROMAKANARULE_TYPE1:
				if (! _tcsncmp (strState, pNode->_T1._strState, nStateLen))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE2:
				if (! _tcsncmp (strState, pNode->_T2._strState, nStateLen))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE3:
				if (! _tcsncmp (strState, pNode->_T3._strState, nStateLen))
					return	pNode ;
				break ;
			default:
				/* skip */
				break ;
			}
			pNode	= pNode->_pNext ;
		}
	} else {
		while (pNode != NULL) {
			switch (pNode->_nType) {
			case	ROMAKANARULE_TYPE1:
				if (! _tcscmp (strState, pNode->_T1._strState))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE2:
				if (! _tcscmp (strState, pNode->_T2._strState))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE3:
				if (! _tcscmp (strState, pNode->_T3._strState))
					return	pNode ;
				break ;
			default:
				/* skip */
				break ;
			}
			pNode	= pNode->_pNext ;
		}
	}
	return	NULL ;
}

struct TSkkBaseRuleNode*
pCopyRomaKanaRuleList (
	struct TSkkBaseRuleNode*	plst)
{
	struct TSkkBaseRuleNode*	pNewList ;
	struct TSkkBaseRuleNode*	pNode ;
	struct TSkkBaseRuleNode*	pPrevNode ;
	struct TSkkBaseRuleNode*	pNewNode ;

	pNewList	= NULL ;
	pNode		= plst ;
	if (pNode == NULL)
		return	NULL ;

	pNewList	= pCopySkkBaseRuleNode (pNode) ;
	if (pNewList == NULL)
		return	NULL ;
	pPrevNode	= pNewList ;
	pNode		= pNode->_pNext ;

	while (pNode != NULL) {
		pNewNode	= pCopySkkBaseRuleNode (pNode) ;
		if (pNewNode == NULL) {
			dlgRomaKanaRule_vClearAllRules (&pNewList) ;
			return	NULL ;
		}
		pPrevNode->_pNext	= pNewNode ;
		pPrevNode			= pNewNode ;
		pNode	= pNode->_pNext ;
	}
	return	pNewList ;
}

void
dlgRomaKanaRule_vClearAllRules (
	struct TSkkBaseRuleNode**	pplst)
{
	struct TSkkBaseRuleNode*	pNode ;
	struct TSkkBaseRuleNode*	pNextNode ;

	if (pplst == NULL)
		return ;

	pNode		= *pplst ;
	while (pNode != NULL) {
		pNextNode		= pNode->_pNext ;
		FREE (pNode) ;
		pNode			= pNextNode ;
	}
	*pplst	= NULL ;
	return ;
}

void	dlgRomaKanaRule_vGetEntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleNode*	pRule,
	int								iRule,
	int								bKatakana,
	BOOL							bShort)
{
	switch (pRule->_nType) {
	case	ROMAKANARULE_TYPE1:
		dlgRomaKanaRule_vGetType1EntryString (pszBuffer, nBufferSize, &pRule->_T1, iRule, bKatakana, bShort) ;
		break ;
	case	ROMAKANARULE_TYPE2:
		dlgRomaKanaRule_vGetType2EntryString (pszBuffer, nBufferSize, &pRule->_T2, iRule, bShort) ;
		break ;
	case	ROMAKANARULE_TYPE3:
		dlgRomaKanaRule_vGetType3EntryString (pszBuffer, nBufferSize, &pRule->_T3, iRule, bShort) ;
		break ;
	default:
		break ;
	}
	return ;
}

void
dlgRomaKanaRule_vGetType1EntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleT1*	pRule,
	int								iRule,
	int								nKatakana,
	BOOL							bShort)
{
	TCHAR	szState [ROMAKANALIST_LONG_LEN+1], szOutput [ROMAKANALIST_LONG_LEN+1] ;
	int		n, nDestLen ;

	/*	�\�����镶���񂪒��߂���ꍇ�ɂ� ... �ŏȗ����ĕ\�������� (full �\�����ǂ����̓��j���[��
	 *	�d�����B)
	 *	�Ƃ͂����A�{���ɒ��������������ꂽ�ꍇ�ɂ͌��Ǐȗ�����K�v������킯�Łc���̂������
	 *	�������l����ƁA�ǂ�����ׂ����c�H
	 */
	nDestLen	= bShort? ROMAKANALIST_SHORT_LEN : ROMAKANALIST_LONG_LEN ;
	/* function name, string ��S�� */
	n			= iString2PrintableString (szState, nDestLen, pRule->_strState, lstrlen (pRule->_strState)) ;
	szState [n]	= TEXT ('\0') ;
	switch (nKatakana) {
	case	ROMAKANA_SHOW_HIRA:
		n		= iShortStringCopy (szOutput, nDestLen, pRule->_case._strHira, lstrlen (pRule->_case._strHira)) ;
		break ;
	case	ROMAKANA_SHOW_KATA:
		n		= iShortStringCopy (szOutput, nDestLen, pRule->_case._strKata, lstrlen (pRule->_case._strKata)) ;
		break ;
	case	ROMAKANA_SHOW_BOTH:
	default:
		{
			TCHAR	szHira [ROMAKANALIST_LONG_LEN+1], szKata [ROMAKANALIST_LONG_LEN+1] ;

			n		= iShortStringCopy (szHira, nDestLen, pRule->_case._strHira, lstrlen (pRule->_case._strHira)) ;
			szHira [n]	= TEXT ('\0') ;
			n		= iShortStringCopy (szKata, nDestLen, pRule->_case._strKata, lstrlen (pRule->_case._strKata)) ;
			szKata [n]	= TEXT ('\0') ;
			n		= wnsprintf (szOutput, nDestLen, TEXT ("%s/%s"), szHira, szKata) ;
		}
		break ;
	}
	szOutput [n]	= TEXT ('\0') ;

	if (pRule->_strNext != NULL) {
		TCHAR	szNext [ROMAKANALIST_LONG_LEN+1] ;

		n			= iString2PrintableString (szNext, nDestLen, pRule->_strNext, lstrlen (pRule->_strNext)) ;
		szNext [n]	= TEXT ('\0') ;
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d \"%s\")"), szState, szOutput, pRule->_iNextRule, szNext) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:\"%s\")"), szState, szOutput, szNext) ;
		}
	} else {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d)"), szState, szOutput, pRule->_iNextRule) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s"), szState, szOutput) ;
		}
	}
	pszBuffer [n]	= TEXT ('\0') ;
	return ;
}

void
dlgRomaKanaRule_vGetType2EntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleT2*	pRule,
	int								iRule,
	BOOL							bShort)
{
	TCHAR	szState  [ROMAKANALIST_LONG_LEN+1], szOutput [ROMAKANALIST_LONG_LEN+1] ;
	int		n, nDestLen ;

	/*	�\�����镶���񂪒��߂���ꍇ�ɂ� ... �ŏȗ����ĕ\�������� (full �\�����ǂ����̓��j���[��
	 *	�d�����B)
	 *	�Ƃ͂����A�{���ɒ��������������ꂽ�ꍇ�ɂ͌��Ǐȗ�����K�v������킯�Łc���̂������
	 *	�������l����ƁA�ǂ�����ׂ����c�H
	 */
	nDestLen	= bShort? ROMAKANALIST_SHORT_LEN : ROMAKANALIST_LONG_LEN ;

	/* function name, string ��S�� */
	n	= iString2PrintableString (szState, nDestLen, pRule->_strState, lstrlen (pRule->_strState)) ;
	szState [n]	= TEXT ('\0') ;
	/* Output �̏ȗ��͂��Ȃ��̂��H */
	n			= iShortStringCopy (szOutput, nDestLen, pRule->_strOutput, lstrlen (pRule->_strOutput)) ;
	szOutput [n]	= TEXT ('\0') ;
	if (pRule->_strNext != NULL) {
		TCHAR	szNext [ROMAKANALIST_LONG_LEN+1] ;

		n			= iString2PrintableString (szNext, nDestLen, pRule->_strNext, lstrlen (pRule->_strNext)) ;
		szNext [n]	= TEXT ('\0') ;
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d \"%s\")"), szState, szOutput, pRule->_iNextRule, szNext) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:\"%s\")"), szState, szOutput, szNext) ;
		}
	} else {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d)"), szState, szOutput, pRule->_iNextRule) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s"), szState, szOutput) ;
		}
	}
	pszBuffer [n]	= TEXT ('\0') ;
	return ;
}


void
dlgRomaKanaRule_vGetType3EntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleT3*	pRule,
	int								iRule,
	BOOL							bShort)
{
	TCHAR	szState  [ROMAKANALIST_LONG_LEN+1], szFuncName [ROMAKANALIST_LONG_LEN+1], szNext [ROMAKANALIST_LONG_LEN+1] ;
	LPCWSTR	pwNext ;
	int		n ;

	/*	�\�����镶���񂪒��߂���ꍇ�ɂ� ... �ŏȗ����ĕ\�������� (full �\�����ǂ����̓��j���[��
	 *	�d�����B)
	 *	�Ƃ͂����A�{���ɒ��������������ꂽ�ꍇ�ɂ͌��Ǐȗ�����K�v������킯�Łc���̂������
	 *	�������l����ƁA�ǂ�����ׂ����c�H
	 */
	/* function name, string ��S�� */
	if (bShort) {
		n	= iString2PrintableString (szState, ROMAKANALIST_SHORT_LEN, pRule->_strState, lstrlen (pRule->_strState)) ;
		szState [n]	= TEXT ('\0') ;

		if (! bGetKeyFuncName (szFuncName, ROMAKANALIST_SHORT_LEN * 2, pRule->_nFunction))
			szFuncName [0]	= TEXT ('\0') ;
		szFuncName [ROMAKANALIST_SHORT_LEN * 2]	= TEXT ('\0') ;

		if (pRule->_strNext != NULL) {
			n	= iString2PrintableString (szNext, ROMAKANALIST_SHORT_LEN, pRule->_strNext, lstrlen (pRule->_strNext)) ;
			szNext [n]	= TEXT ('\0') ;
			pwNext	= szNext ;
		} else {
			pwNext	= NULL ;
		}
	} else {
		n	= iString2PrintableString (szState, ARRAYSIZE (szState) - 1, pRule->_strState, lstrlen (pRule->_strState)) ;
		szState [n]	= TEXT ('\0') ;

		if (! bGetKeyFuncName (szFuncName, ARRAYSIZE (szFuncName) - 1, pRule->_nFunction))
			szFuncName [0]	= TEXT ('\0') ;
		szFuncName [ARRAYSIZE (szFuncName) - 1]	= TEXT ('\0') ;

		if (pRule->_strNext != NULL) {
			n	= iString2PrintableString (szNext, ARRAYSIZE (szNext) - 1, pRule->_strNext, lstrlen (pRule->_strNext)) ;
			szNext [n]	= TEXT ('\0') ;
			pwNext	= szNext ;
		} else {
			pwNext	= NULL ;
		}
	}
	if (pwNext != NULL) {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d \"%s\")"), szState, szFuncName, pRule->_iNextRule, pwNext) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:\"%s\")"), szState, szFuncName, pwNext) ;
		}
	} else {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d)"), szState, szFuncName, pRule->_iNextRule) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s"), szState, szFuncName) ;
		}
	}
	pszBuffer [n]	= TEXT ('\0') ;
	return ;
}

/*=================================================================================
 */
static	LRESULT		dlgEditRomaKanaRule_lOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	LRESULT		dlgEditRomaKanaRule_lOnCommand		(HWND, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
ipDlgEditRomaKanaRuleProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		return	dlgEditRomaKanaRule_lOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditRomaKanaRule_lOnCommand (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) 0 ;
}

LRESULT
dlgEditRomaKanaRule_lOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	/* ����Őݒ荀�ڂ͏\�����H */
	static struct {
		LPCTSTR		m_strText ;
		int			m_nFunction ;
	}	srComboListInitValues []	= {
#if defined (JAPANESE_MESSAGE)
		{	TEXT ("�����R�[�h�\��"),		NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT,	},
		{	TEXT ("��_"),					NFUNC_SKK_CURRENT_KUTEN,	},
		{	TEXT ("�Ǔ_"),					NFUNC_SKK_CURRENT_TOUTEN,	},
		{	TEXT ("���t"),					NFUNC_SKK_TODAY,	},
		{	TEXT ("�R�[�h����"),			NFUNC_SKK_INPUT_BY_CODE_OR_MENU,	},
		{	TEXT ("������<->�Љ���"),		NFUNC_SKK_TOGGLE_CHARACTERS,	},
		{	TEXT ("���}�[�N�ݒu"),			NFUNC_SKK_SET_HENKAN_POINT_SUBR,	},
		{	TEXT ("�m��"),					NFUNC_SKK_KAKUTEI,	},
		{	TEXT ("Abbrev���[�h"),			NFUNC_SKK_ABBREV_MODE,	},
		{	TEXT ("�����P��폜"),			NFUNC_SKK_PURGE_FROM_JISYO,	},
		{	TEXT ("Latin���[�h"),			NFUNC_SKK_LATIN_MODE,	},
		{	TEXT ("�k�����������[�h"),		NFUNC_SKK_JISX0208_LATIN_MODE,	},
		{	TEXT ("���p�Љ����g�O��"),		NFUNC_SKK_TOGGLE_KATAKANA,	},
		{	TEXT ("JISX0201����<->���[�}"),	NFUNC_SKK_TOGGLE_JISX0201,	},
#else
		{	TEXT ("skk-display-code-for-char-at-point"),	NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT,	},
		{	TEXT ("skk-current-kuten"),			NFUNC_SKK_CURRENT_KUTEN,	},
		{	TEXT ("skk-current-touten"),		NFUNC_SKK_CURRENT_TOUTEN,	},
		{	TEXT ("skk-today"),					NFUNC_SKK_TODAY,	},
		{	TEXT ("skk-input-by-code-or-menu"),	NFUNC_SKK_INPUT_BY_CODE_OR_MENU,	},
		{	TEXT ("skk-toggle-kana"),			NFUNC_SKK_TOGGLE_CHARACTERS,	},
		{	TEXT ("skk-set-henkan-point-subr"),	NFUNC_SKK_SET_HENKAN_POINT_SUBR,	},
		{	TEXT ("skk-kakutei"),				NFUNC_SKK_KAKUTEI,	},
		{	TEXT ("skk-abbrev-mode"),			NFUNC_SKK_ABBREV_MODE,	},
		{	TEXT ("skk-purge-from-jisyo"),		NFUNC_SKK_PURGE_FROM_JISYO,	},
		{	TEXT ("skk-latin-mode"),			NFUNC_SKK_LATIN_MODE,	},
		{	TEXT ("skk-jisx0208-latin-mode"),	NFUNC_SKK_JISX0208_LATIN_MODE,	},
		{	TEXT ("skk-toggle-katakana"),		NFUNC_SKK_TOGGLE_KATAKANA,	},
		{	TEXT ("skk-toggle-jisx0201"),		NFUNC_SKK_TOGGLE_JISX0201,	},
#endif
	} ;
	struct TEditRomaKanaRuleArg*	pArg	= (struct TEditRomaKanaRuleArg*) lParam ;
	HWND	hwndControl ;
	LPCWSTR	pwState, pwNext, pwHira, pwKata, pwCommon ;
	int		i, nFunction, nRadio, nNextRule, nRule, nItems ;
	HICON	hIcon ;


	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pArg) ;
	if (pArg == NULL)
		return	FALSE ;

	if (pArg->m_pInitValue != NULL) {
		struct TSkkBaseRuleNode*	pNode	= pArg->m_pInitValue ;

		switch (pNode->_nType) {
		case	ROMAKANARULE_TYPE1:
			pwState		= pNode->_T1._strState ;
			nRule		= pArg->m_iRule ;
			pwNext		= (pNode->_T1._strNext != NULL)? pNode->_T1._strNext : TEXT ("") ;
			nNextRule	= pNode->_T1._iNextRule ;
			pwHira		= pNode->_T1._case._strHira ;
			pwKata		= pNode->_T1._case._strKata ;
			pwCommon	= TEXT ("") ;
			nRadio		= IDC_RADIO_HIRAKATA ;
			nFunction	= NFUNC_INVALID_CHAR ;
			break ;
		case	ROMAKANARULE_TYPE2:
			pwState		= pNode->_T2._strState ;
			nRule		= pArg->m_iRule ;
			pwNext		= (pNode->_T2._strNext != NULL)? pNode->_T2._strNext : TEXT ("") ;
			nNextRule	= pNode->_T2._iNextRule ;
			pwHira		= TEXT ("") ;
			pwKata		= TEXT ("") ;
			pwCommon	= pNode->_T2._strOutput ;
			nFunction	= NFUNC_INVALID_CHAR ;
			nRadio		= IDC_RADIO_COMMON ;
			break ;
		case	ROMAKANARULE_TYPE3:
		default:
			pwState		= pNode->_T3._strState ;
			nRule		= pArg->m_iRule ;
			pwNext		= (pNode->_T3._strNext != NULL)? pNode->_T3._strNext : TEXT ("") ;
			nNextRule	= pNode->_T3._iNextRule ;
			pwHira		= TEXT ("") ;
			pwKata		= TEXT ("") ;
			pwCommon	= TEXT ("") ;
			nRadio		= IDC_RADIO_MACRO ;
			nFunction	= pNode->_T3._nFunction ;
			break ;
		}
	} else {
		pwState		= TEXT ("") ;
		pwNext		= TEXT ("") ;
		pwHira		= TEXT ("") ;
		pwKata		= TEXT ("") ;
		pwCommon	= TEXT ("") ;
		nRadio		= IDC_RADIO_HIRAKATA ;
		nFunction	= NFUNC_INVALID_CHAR ;
		nRule		= pArg->m_iRule ;
		nNextRule	= pArg->m_iRule ;
	}

	SetDlgItemText (hDlg, IDC_EDIT_STATE,			pwState) ;
	SetDlgItemText (hDlg, IDC_EDIT_NEXTSTATE,		pwNext) ;

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_STATE_RULENO) ;
	if (hwndControl != NULL) {
		TCHAR	buf [32] ;
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			int		nPos, n ;
			n		= wnsprintf (buf, ARRAYSIZE (buf) - 1, TEXT ("%d"), i) ;
			buf [n]	= TEXT ('\0') ;
			nPos	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) 0, (LPARAM) buf) ;
			if (nPos != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) 0, (LPARAM) i) ;
			}
		}
		nItems	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
		for (i = 0 ; i < nItems ; i ++) {
			LRESULT		lData ;
			lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
			if (lData != CB_ERR && lData == nRule) {
				(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) ;
				break ;
			}
		}
		if (i == nItems) 
			(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
	}
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_NEXTSTATE_RULENO) ;
	if (hwndControl != NULL) {
		TCHAR	buf [32] ;
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			int		nPos, n ;
			n		= wnsprintf (buf, ARRAYSIZE (buf) - 1, TEXT ("%d"), i) ;
			buf [n]	= TEXT ('\0') ;
			nPos	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) 0, (LPARAM) buf) ;
			if (nPos != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) 0, (LPARAM) i) ;
			}
		}
		nItems	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
		for (i = 0 ; i < nItems ; i ++) {
			LRESULT		lData ;
			lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
			if (lData != CB_ERR && lData == nNextRule) {
				(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) ;
				break ;
			}
		}
		if (i == nItems) 
			(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
	}
	if (! pArg->m_bEnableRule1 && nRadio == IDC_RADIO_HIRAKATA) 
		nRadio	= IDC_RADIO_COMMON ;

	SetDlgItemText (hDlg, IDC_EDIT_HIRA,			pwHira) ;
	SetDlgItemText (hDlg, IDC_EDIT_KATA,			pwKata) ;
	SetDlgItemText (hDlg, IDC_EDIT_COMMONSTRING,	pwCommon) ;
	CheckRadioButton (hDlg, IDC_RADIO_HIRAKATA,		IDC_RADIO_MACRO, nRadio) ;
	if (pArg->m_bEnableRule1) {
		EnableDlgItem  (hDlg, IDC_RADIO_HIRAKATA,	TRUE) ;
		EnableDlgItem  (hDlg, IDC_EDIT_HIRA,		(nRadio == IDC_RADIO_HIRAKATA)) ;
		EnableDlgItem  (hDlg, IDC_EDIT_KATA,		(nRadio == IDC_RADIO_HIRAKATA)) ;
	} else {
		EnableDlgItem  (hDlg, IDC_RADIO_HIRAKATA,	FALSE) ;
		EnableDlgItem  (hDlg, IDC_EDIT_HIRA,		FALSE) ;
		EnableDlgItem  (hDlg, IDC_EDIT_KATA,		FALSE) ;
	}
	EnableDlgItem  (hDlg, IDC_EDIT_COMMONSTRING,	(nRadio == IDC_RADIO_COMMON)) ;
	EnableDlgItem  (hDlg, IDC_COMBO_MACRO,			(nRadio == IDC_RADIO_MACRO)) ;

	/*	IDC_COMBO_MACRO �̒��g�͏��������Ă����Ȃ��Ƃ����Ȃ��B
	 *	���ł�����ł��ݒ�ł���Ƃ͎v���Ȃ��̂ŁA�@�\�͈ȉ��̂��̂����ɂ���F
	 *		
	 */
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_MACRO) ;
	if (hwndControl != NULL) {
		int		i, nItems ;
		for (i = 0 ; i < ARRAYSIZE (srComboListInitValues) ; i ++) {
			int		nPos ;
			nPos	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) 0, (LPARAM) srComboListInitValues [i].m_strText) ;
			if (nPos != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) 0, (LPARAM) srComboListInitValues [i].m_nFunction) ;
			}
		}
		nItems	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
		for (i = 0 ; i < nItems ; i ++) {
			LRESULT		lData ;
			lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
			if (lData != CB_ERR && lData == nFunction) {
				(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) ;
				break ;
			}
		}
		if (i == nItems) 
			(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
	}
	hIcon	= (HICON) LoadImage ((HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE), MAKEINTRESOURCE (IDI_BTNSPECIAL), IMAGE_ICON, 16, 16, LR_SHARED) ;
	if (hIcon != NULL) {
		hwndControl	= GetDlgItem (hDlg, IDC_BUTTON_STATESPECIAL) ;
		if (hwndControl != NULL) {
			SendMessage (hwndControl, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
		}
		hwndControl	= GetDlgItem (hDlg, IDC_BUTTON_NEXTSTATESPECIAL) ;
		if (hwndControl != NULL) {
			SendMessage (hwndControl, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
		}
	}
	return	FALSE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT
dlgEditRomaKanaRule_lOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditRomaKanaRuleArg*	pArg ;
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	pArg	= (struct TEditRomaKanaRuleArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	1 ;
	
	switch (woControl) {
	case	IDC_BUTTON_STATESPECIAL:
		if (woNotification == BN_CLICKED) {
			HMENU	hMenu	= CreatePopupMenu () ;
			if (hMenu != NULL) {
				if (InsertMenu (hMenu, 1, MF_BYCOMMAND | MF_STRING, 1, TEXT ("�C�ӂ̈ꕶ��")) &&
					InsertMenu (hMenu, 2, MF_BYCOMMAND | MF_STRING, 2, TEXT ("�ꉹ")) &&
					InsertMenu (hMenu, 3, MF_BYCOMMAND | MF_STRING, 3, TEXT ("�q��")) &&
					InsertMenu (hMenu, 4, MF_BYCOMMAND | MF_STRING, 4, TEXT ("\\"))) {
					RECT	rc ;
					int		iCmd ;
					LPCTSTR	pwText ;

					GetWindowRect (GetDlgItem (hDlg, woControl), &rc) ;
					iCmd	= TrackPopupMenuEx (hMenu, TPM_TOPALIGN | TPM_LEFTBUTTON | TPM_RETURNCMD, rc.left, rc.bottom, hDlg, NULL) ;
					switch (iCmd) {
					case	1:
						pwText	= TEXT ("\\?") ;
						break ;
					case	2:
						pwText	= TEXT ("\\V") ;
						break ;
					case	3:
						pwText	= TEXT ("\\C") ;
						break ;
					case	4:
						pwText	= TEXT ("\\\\") ;
						break ;
					default:
						pwText	= NULL ;
						break ;
					}
					if (pwText != NULL) {
						HWND	hWnd	= GetDlgItem (hDlg, IDC_EDIT_STATE) ;
						if (hWnd != NULL)
							(void) SendMessage (hWnd, EM_REPLACESEL, (WPARAM) TRUE, (LPARAM) pwText) ;
					}
				}
				DestroyMenu (hMenu) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_NEXTSTATESPECIAL:
		if (woNotification == BN_CLICKED) {
			HMENU	hMenu	= CreatePopupMenu () ;
			if (hMenu != NULL) {
				if (InsertMenu (hMenu, 0, MF_BYPOSITION | MF_STRING, 1, TEXT ("���͕���")) &&
					InsertMenu (hMenu, 1, MF_BYPOSITION | MF_STRING, 2, TEXT ("\\"))) {
					RECT	rc ;
					int		iCmd ;
					LPCTSTR	pwText ;

					GetWindowRect (GetDlgItem (hDlg, woControl), &rc) ;
					iCmd	= TrackPopupMenuEx (hMenu, TPM_TOPALIGN | TPM_LEFTBUTTON | TPM_RETURNCMD, rc.left, rc.bottom, hDlg, NULL) ;
					switch (iCmd) {
					case	1:
						pwText	= TEXT ("\\I") ;
						break ;
					case	2:
						pwText	= TEXT ("\\\\") ;
						break ;
					default:
						pwText	= NULL ;
						break ;
					}
					if (pwText != NULL) {
						HWND	hWnd	= GetDlgItem (hDlg, IDC_EDIT_NEXTSTATE) ;
						if (hWnd != NULL)
							(void) SendMessage (hWnd, EM_REPLACESEL, (WPARAM) TRUE, (LPARAM) pwText) ;
					}
				}
				DestroyMenu (hMenu) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_RADIO_HIRAKATA:
	case	IDC_RADIO_COMMON:
	case	IDC_RADIO_MACRO:
		if (woNotification == BN_CLICKED) {
			CheckRadioButton (hDlg, IDC_RADIO_HIRAKATA, IDC_RADIO_MACRO, woControl) ;
			EnableDlgItem  (hDlg, IDC_EDIT_HIRA,			(woControl == IDC_RADIO_HIRAKATA)) ;
			EnableDlgItem  (hDlg, IDC_EDIT_KATA,			(woControl == IDC_RADIO_HIRAKATA)) ;
			EnableDlgItem  (hDlg, IDC_EDIT_COMMONSTRING,	(woControl == IDC_RADIO_COMMON)) ;
			EnableDlgItem  (hDlg, IDC_COMBO_MACRO,			(woControl == IDC_RADIO_MACRO)) ;
			return	0 ;
		}
		break ;
	case	IDOK:
		{
			HWND		hwndControl ;
			LRESULT		lCurSel, lData ;
			BOOL		bError	= FALSE ;

			if (! GetDlgItemText (hDlg, IDC_EDIT_STATE,	pArg->m_bufState, ARRAYSIZE (pArg->m_bufState)))
				pArg->m_bufState [0]	= TEXT ('\0') ;
			if (! GetDlgItemText (hDlg, IDC_EDIT_NEXTSTATE, pArg->m_bufNextState, ARRAYSIZE (pArg->m_bufNextState)))
				pArg->m_bufNextState [0]	= TEXT ('\0') ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_STATE_RULENO) ;
			if (hwndControl != NULL) {
				lCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
				if (lCurSel != CB_ERR) {
					lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) lCurSel, (LPARAM) 0) ;
					if (lData != CB_ERR && 0 <= lData && lData < NUM_ROMAKANARULE) {
						pArg->m_iRule	= (int) lData ;
					} else {
						bError			= TRUE ;
					}
				} else {
					bError			= TRUE ;
				}
			}
			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_NEXTSTATE_RULENO) ;
			if (hwndControl != NULL) {
				lCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
				if (lCurSel != CB_ERR) {
					lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) lCurSel, (LPARAM) 0) ;
					if (lData != CB_ERR && 0 <= lData && lData < NUM_ROMAKANARULE) {
						pArg->m_iNextRule	= (int) lData ;
					} else {
						bError			= TRUE ;
					}
				} else {
					bError			= TRUE ;
				}
			}
			if (IsDlgButtonChecked (hDlg, IDC_RADIO_HIRAKATA) != BST_UNCHECKED) {
				if (! GetDlgItemText (hDlg, IDC_EDIT_HIRA,	pArg->m_bufHiraOrCommon,	ARRAYSIZE (pArg->m_bufHiraOrCommon)))
					pArg->m_bufHiraOrCommon [0]	= TEXT ('\0') ;
				if (! GetDlgItemText (hDlg, IDC_EDIT_KATA,	pArg->m_bufKata,			ARRAYSIZE (pArg->m_bufKata)))
					pArg->m_bufKata [0]	= TEXT ('\0') ;
				pArg->m_nType	= ROMAKANARULE_TYPE1 ;
			} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_COMMON) != BST_UNCHECKED) {
				if (! GetDlgItemText (hDlg, IDC_EDIT_COMMONSTRING,	pArg->m_bufHiraOrCommon,	ARRAYSIZE (pArg->m_bufHiraOrCommon))) 
					pArg->m_bufHiraOrCommon [0]	= TEXT ('\0') ;
				pArg->m_nType	= ROMAKANARULE_TYPE2 ;
			} else {
				HWND	hwndControl ;

				/* IDC_RADIO_MACRO */
				pArg->m_nType		= ROMAKANARULE_TYPE3 ;
				pArg->m_nFunction	= NFUNC_INVALID_CHAR ;

				hwndControl	= GetDlgItem (hDlg, IDC_COMBO_MACRO) ;
				if (hwndControl != NULL) {
					int		nCurSel ;

					nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
					if (nCurSel != CB_ERR) {
						LRESULT	lData ;

						lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
						if (lData != CB_ERR) {
							pArg->m_nFunction	= lData ;
						}
					}
				}
			}
			/*	�G���[�`�F�b�N�B*/
			if (pArg->m_bufState [0] == TEXT ('\0')) {
				MessageBox (hDlg, TEXT ("����Ԃ��ݒ肳��Ă��܂���B"), TEXT ("�G���["), MB_ICONWARNING | MB_OK) ;
				return	1 ;
			}
			if (pArg->m_nType == ROMAKANARULE_TYPE3 && pArg->m_nFunction == NFUNC_INVALID_CHAR) {
				MessageBox (hDlg, TEXT ("�}�N�����ݒ肳��Ă��܂���B"), TEXT ("�G���["), MB_ICONWARNING | MB_OK) ;
				return	1 ;
			}
			if (bError) {
				return	1 ;
			}
		}
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

/*========================================================================
 *
 */
static	INT_PTR				dlgEditSpecialKeybind_iOnInitDialog (HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditSpecialKeybind_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditSpecialKeybind_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void				dlgEditSpecialKeybind_vSyncControl	(HWND) ;
static	int					dlgEditSpecialKeybind_iGetShowKeyType	(HWND) ;
static	void				dlgEditSpecialKeybind_vAddKeybind	(HWND) ;
static	void				dlgEditSpecialKeybind_vDeleteKeybind(HWND) ;
static	INT_PTR	CALLBACK	dlgEditSpecialKeyProc	(HWND, UINT, WPARAM, LPARAM) ;


INT_PTR	CALLBACK
dlgEditSpecialKeybindProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		return	dlgEditSpecialKeybind_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditSpecialKeybind_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditSpecialKeybind_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditSpecialKeybind_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
//	struct TCustomSpecialKeybindArg*	pArg ;
	HWND	hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_VIEWITEM) ;
	if (hwndControl != NULL) {
		static const struct {
			LPCTSTR		_strText ;
			int			_iValue ;
		}	srComboInitValues [] = {
			{	TEXT ("�ϊ��J�n�L�["),		KEYBIND_SHOW_STARTHENKANKEYS	},
			{	TEXT ("�⊮�J�n�L�["),		KEYBIND_SHOW_TRYCOMPLETIONKEYS	},
			{	TEXT ("�⊮�O���L�["),	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS	},
			{	TEXT ("�⊮�����L�["),	KEYBIND_SHOW_NEXTCOMPLETIONKEYS	},
			{	TEXT ("�����[�h�J�n�L�["),	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS	},
			{	TEXT ("���ꌩ�o������"),	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS	},
		} ;
		int		nIndex, i ;

		for (i = 0 ; i < ARRAYSIZE (srComboInitValues) ; i ++) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) srComboInitValues [i]._strText) ;
			if (nIndex != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) srComboInitValues [i]._iValue) ;
			}
		}
		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_VIEWITEM, KEYBIND_SHOW_STARTHENKANKEYS) ;
	}
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (hwndControl != NULL) {
//		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_BORDERSELECT) ;
	}
	dlgEditSpecialKeybind_vSyncControl (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditSpecialKeybind_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_COMBO_VIEWITEM:
		if (woNotification == CBN_SELCHANGE) {
			dlgEditSpecialKeybind_vSyncControl (hDlg) ;
		}
		return	0 ;
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		dlgEditSpecialKeybind_vAddKeybind (hDlg) ;
		return	0 ;
	case	IDC_BUTTON_DELETE:
		dlgEditSpecialKeybind_vDeleteKeybind (hDlg) ;
		return	0 ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditSpecialKeybind_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	return	1 ;
	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

void
dlgEditSpecialKeybind_vSyncControl (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg*	pArg ;
	HWND	hwndControl ;
	int		i, iNumKeys ;
	const BYTE*	pbKeys ;
	TCHAR		szBuffer [32] ;
	int		iShowKeyType ;
	LVITEM	lvi ;

	pArg		= (struct TCustomSpecialKeybindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL) 
		return ;
	iShowKeyType	= dlgEditSpecialKeybind_iGetShowKeyType (hDlg) ;
	hwndControl		= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (hwndControl == NULL)
		return ;
	ListView_DeleteAllItems (hwndControl) ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
	/*
				{	TEXT ("�ϊ��J�n�L�["),		KEYBIND_SHOW_STARTHENKANKEYS	},
			{	TEXT ("�⊮�J�n�L�["),		KEYBIND_SHOW_TRYCOMPLETIONKEYS	},
			{	TEXT ("�⊮�O���L�["),	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS	},
			{	TEXT ("�⊮�����L�["),	KEYBIND_SHOW_NEXTCOMPLETIONKEYS	},
			{	TEXT ("�����[�h�J�n�L�["),	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS	},
			{	TEXT ("���ꌩ�o������"),	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS	},
			*/
	switch (iShowKeyType) {
	case	KEYBIND_SHOW_STARTHENKANKEYS:
		pbKeys		= pArg->m_bufStartHenkanKeys ;
		iNumKeys	= pArg->m_iNumStartHenkanKeys ;
		break ;
	case	KEYBIND_SHOW_TRYCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufTryCompletionKeys ;
		iNumKeys	= pArg->m_iNumTryCompletionKeys ;
		break ;
	case	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufPreviousCompletionKeys ;
		iNumKeys	= pArg->m_iNumPreviousCompletionKeys ;
		break ;
	case	KEYBIND_SHOW_NEXTCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufNextCompletionKeys ;
		iNumKeys	= pArg->m_iNumNextCompletionKeys ;
		break ;
	case	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS:
		pbKeys		= pArg->m_bufSetHenkanPointSubrKeys ;
		iNumKeys	= pArg->m_iNumSetHenkanPointSubrKeys ;
		break ;
	case	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS:
		pbKeys		= pArg->m_bufSpecialMidashiCharKeys ;
		iNumKeys	= pArg->m_iNumSpecialMidashiCharKeys ;
		break ;
	default:
		return ;
	}
	for (i = 0 ; i < iNumKeys ; i ++) {
		vKey2String (szBuffer, ARRAYSIZE (szBuffer), pbKeys [i]) ;
		lvi.iItem	= i ;
		lvi.pszText	= szBuffer ;
		lvi.lParam	= (LPARAM) i ;
		(void) ListView_InsertItem (hwndControl, &lvi) ;
	}
	return ;
}

void
dlgEditSpecialKeybind_vAddKeybind (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg*	pArg ;
	HINSTANCE	hInst ;
	HWND	hwndControl ;
	int		iShowKeyType ;
	UINT	uArg ;
	TCHAR	szKey [64], bufText [128] ;
	LVITEM	lvi ;
	int		nResult, nText ;
	BYTE*	pbKeys ;
	int*	piNumKeys ;
	BOOL*	pbModified ;

	hInst		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pArg		= (struct TCustomSpecialKeybindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (pArg == NULL || hwndControl == NULL)
		return ;

	iShowKeyType	= dlgEditSpecialKeybind_iGetShowKeyType (hDlg) ;
	switch (iShowKeyType) {
	case	KEYBIND_SHOW_STARTHENKANKEYS:
		pbKeys		= pArg->m_bufStartHenkanKeys ;
		piNumKeys	= &pArg->m_iNumStartHenkanKeys ;
		pbModified	= &pArg->m_bStartHenkanKeysModified ;
		break ;
	case	KEYBIND_SHOW_TRYCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufTryCompletionKeys ;
		piNumKeys	= &pArg->m_iNumTryCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufPreviousCompletionKeys ;
		piNumKeys	= &pArg->m_iNumPreviousCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_NEXTCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufNextCompletionKeys ;
		piNumKeys	= &pArg->m_iNumNextCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS:
		pbKeys		= pArg->m_bufSetHenkanPointSubrKeys ;
		piNumKeys	= &pArg->m_iNumSetHenkanPointSubrKeys ;
		pbModified	= &pArg->m_bSetHenkanPointSubrKeysModified ;
		break ;
	case	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS:
		pbKeys		= pArg->m_bufSpecialMidashiCharKeys ;
		piNumKeys	= &pArg->m_iNumSpecialMidashiCharKeys ;
		pbModified	= &pArg->m_bSpecialMidashiCharKeysModified ;
		break ;
	default:
		return ;
	}
	/* ����ȏ�L�[���ǉ��ł��Ȃ��̂ł͂Ȃ����ƒ��ׂ�B*/
	if (*piNumKeys >= MAX_SPECIALKEYS)
		return ;
	uArg	= iShowKeyType ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_SPECIALKEY), hDlg, dlgEditSpecialKeyProc, (LPARAM) &uArg) ;
	if (nResult != IDOK)
		return ;
	if (uArg >= MAX_KEYBINDS)
		return ;

	memset (&lvi, 0, sizeof (lvi)) ;
	vKey2String (szKey, ARRAYSIZE (szKey), uArg) ;

	/* �����L�[�����݂�����܂����̂Ń`�F�b�N����B*/
	if (memchr (pbKeys, uArg, *piNumKeys) != NULL) {
		/* �`�͊��ɓo�^����Ă��܂��A�Ƃ����Ƃ��B*/
		nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("�L�[ ``%s'' �͊��ɓo�^����Ă��܂��B"), szKey) ;
		bufText [nText]	= TEXT ('\0') ;
		(void) MessageBox (hDlg, bufText, TEXT ("�G���["), MB_OK) ;
		return ;
	}
	lvi.iItem	= *piNumKeys ;
	pbKeys [*piNumKeys]	= (BYTE) uArg ;
	++ *piNumKeys ;
	*pbModified	= TRUE ;

	/*	vSynControl ���ĂԂƏd���̂ŁAListView_InsertItem �̌Ăяo���ŗ����B
	 */
	lvi.mask	= LVIF_TEXT | LVIF_PARAM ;
	lvi.pszText	= szKey ;
	lvi.lParam	= (LPARAM) lvi.iItem ;
	ListView_InsertItem (hwndControl, &lvi) ;
	return ;
}

void
dlgEditSpecialKeybind_vDeleteKeybind (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg*	pArg ;
	HWND	hwndControl ;
	TCHAR	bufText [128], szKey [64] ;
	int		nCurSel, iKeyIndex, nText, iShowKeyType ;
	BYTE*	pbKeybinds ;
	LVITEM	lvi ;
	int*	piNumKeys ;
	BOOL*	pbModified ;

	pArg		= (struct TCustomSpecialKeybindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (pArg == NULL || hwndControl == NULL)
		return ;

	nCurSel		= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1)
		return ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask	= LVIF_PARAM ;
	lvi.iItem	= nCurSel ;
	if (! ListView_GetItem (hwndControl, &lvi))
		return ;
	iKeyIndex	= (int) lvi.lParam ;

	iShowKeyType	= dlgEditSpecialKeybind_iGetShowKeyType (hDlg) ;
	switch (iShowKeyType) {
	case	KEYBIND_SHOW_STARTHENKANKEYS:
		pbKeybinds	= pArg->m_bufStartHenkanKeys ;
		piNumKeys	= &pArg->m_iNumStartHenkanKeys ;
		pbModified	= &pArg->m_bStartHenkanKeysModified ;
		break ;
	case	KEYBIND_SHOW_TRYCOMPLETIONKEYS:
		pbKeybinds	= pArg->m_bufTryCompletionKeys ;
		piNumKeys	= &pArg->m_iNumTryCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS:
		pbKeybinds	= pArg->m_bufPreviousCompletionKeys ;
		piNumKeys	= &pArg->m_iNumPreviousCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_NEXTCOMPLETIONKEYS:
		pbKeybinds	= pArg->m_bufNextCompletionKeys ;
		piNumKeys	= &pArg->m_iNumNextCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS:
		pbKeybinds	= pArg->m_bufSetHenkanPointSubrKeys ;
		piNumKeys	= &pArg->m_iNumSetHenkanPointSubrKeys ;
		pbModified	= &pArg->m_bSetHenkanPointSubrKeysModified ;
		break ;
	case	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS:
		pbKeybinds	= pArg->m_bufSpecialMidashiCharKeys ;
		piNumKeys	= &pArg->m_iNumSpecialMidashiCharKeys ;
		pbModified	= &pArg->m_bSpecialMidashiCharKeysModified ;
		break ;
	default:
		return ;
	}
	if (iKeyIndex < 0 || iKeyIndex > *piNumKeys || *piNumKeys <= 0)
		return ;

	vKey2String (szKey, ARRAYSIZE (szKey), *(pbKeybinds + iKeyIndex)) ;
	nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("�L�[ ``%s'' ���폜���܂��B��낵���ł����H"), szKey) ;
	bufText [nText]	= TEXT ('\0') ;
	if (MessageBox (hDlg, bufText, TEXT ("�m�F"), MB_YESNO) != IDYES)
		return ;

	if ((iKeyIndex + 1) < *piNumKeys) 
		memmove (pbKeybinds + iKeyIndex, pbKeybinds + iKeyIndex + 1, (*piNumKeys - iKeyIndex - 1)) ;
	-- *piNumKeys ;
	*pbModified	= TRUE ;
	ListView_DeleteItem (hwndControl, nCurSel) ;
	return ;
}

int
dlgEditSpecialKeybind_iGetShowKeyType (
	HWND		hDlg)
{
	HWND		hwndControl ;
	int			nCurSel, nData ;

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_VIEWITEM) ;
	if (hwndControl == NULL)
		return	-1 ;
	nCurSel		= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
	if (nCurSel == CB_ERR)
		return	-1 ;
	nData		= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
	if (nData == CB_ERR)
		return	-1 ;
	return	nData ;
}

INT_PTR	CALLBACK
dlgEditSpecialKeyProc (
	HWND		hDlg,
	UINT		nMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		{
			UINT*	puArg ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
			puArg	= (UINT*) lParam ;

			/* ComboBox �ɃL�[���X�g��o�^����B*/
			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SPECIALKEY) ;
			if (hwndControl != NULL) {
				TCHAR	bufText [64] ;
				int		i, nIndex ;

				for (i = 32 ; i < 127 ; i ++) {
					vKey2String (bufText, ARRAYSIZE (bufText), i) ;
					nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) bufText) ;
					if (nIndex != CB_ERR) {
						SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) i) ;
					}
				}
				SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
			}
			SetDlgItemText (hDlg, IDC_EDIT_DESCRIPTION, (*puArg)? TEXT ("�����}�[�N�J�n�L�[") : TEXT ("����ꌩ�o�������L�[")) ;
			return	(INT_PTR) TRUE ;
		}
	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			//WORD	woNotification	= HIWORD (wParam) ;

			switch (woControl) {
			case	IDOK:
				{
					HWND	hwndControl ;

					hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SPECIALKEY) ;
					if (hwndControl != NULL) {
						int		nCurSel ;
						UINT*	puKey ;
						UINT	uKey	= (UINT)-1 ;

						puKey	= (UINT*) GetWindowLongPtr (hDlg, DWLP_USER) ;
						if (puKey != NULL) {
							nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
							if (nCurSel != -1) {
								uKey	= (UINT) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
							}
							*puKey	= uKey ;
						}
						if (uKey == -1) {
							(void) MessageBox (hDlg, TEXT ("�L�[���ݒ肳��Ă��܂���B"), TEXT ("�G���["), MB_OK) ;
							return	0 ;
						}
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				return	0 ;
			}
		}
	case	WM_NOTIFY:
		return	1 ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*========================================================================
 *	�S�p�x�N�g���̕ҏW
 */
static	INT_PTR		dlgZenkakuVector_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgZenkakuVector_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgZenkakuVector_iOnNotify		(HWND, WPARAM, LPARAM) ;

static	BOOL		dlgZenkakuVector_bInitializeZenkakuList		(HWND) ;
static	BOOL		dlgZenkakuVector_bEditZenkakuVector			(HWND, int) ;
static	void		dlgZenkakuVector_vCreateListItemText		(LPTSTR, int, int, LPCTSTR) ;

static	INT_PTR	CALLBACK	dlgEditZenkakuVectorProc	(HWND, UINT, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
dlgZenkakuVectorProc (
	HWND			hDlg,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgZenkakuVector_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgZenkakuVector_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgZenkakuVector_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgZenkakuVector_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	//PROPSHEETPAGE*	pPropPage	= (PROPSHEETPAGE*) lParam ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	dlgZenkakuVector_bInitializeZenkakuList (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgZenkakuVector_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	//WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_LIST_ZENKAKUVECTOR:
		break ;
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
	case	IDC_BUTTON_DELETE:
		if (dlgZenkakuVector_bEditZenkakuVector (hDlg, woControl)) {
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgZenkakuVector_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_ZENKAKUVECTOR:
		if (pNMHDR->code == NM_CLICK || pNMHDR->code == NM_RCLICK || pNMHDR->code == LVN_ITEMCHANGED ||  pNMHDR->code == NM_SETFOCUS) {
			EnableDlgItem (hDlg, IDC_BUTTON_EDIT,	TRUE) ;
			EnableDlgItem (hDlg, IDC_BUTTON_DELETE,	TRUE) ;
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 0 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
dlgZenkakuVector_bInitializeZenkakuList (
	HWND			hDlg)
{
	struct TEditZenkakuVectorArg*	pArg ;
	HWND			hwndControl ;
	LVITEM			lvi ;
	int				nItem, i ;
	TCHAR			buf [256] ;

	pArg		= (struct TEditZenkakuVectorArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ZENKAKUVECTOR) ;
	if (pArg == NULL || hwndControl == NULL)
		return	FALSE ;

	ListView_DeleteAllItems (hDlg) ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_PARAM | LVIF_TEXT ;
	lvi.iSubItem	= 0 ;
	nItem			= 0 ;
	for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
		if (pArg->m_rpZenkakuVector [i] != NULL) {
			lvi.iItem	= nItem ;
			lvi.lParam	= (LPARAM) i ;

			dlgZenkakuVector_vCreateListItemText (buf, ARRAYSIZE (buf), i, pArg->m_rpZenkakuVector [i]) ;
			lvi.pszText	= buf ;
			if (ListView_InsertItem (hwndControl, &lvi) == -1)
				return	FALSE ;
			nItem		++ ;
		}
	}
	return	TRUE ;
}

BOOL
dlgZenkakuVector_bEditZenkakuVector (
	HWND				hDlg,
	int					nCommandId)
{
	struct TEditZenkakuVectorArg*		pArg ;
	struct TEditZenkakuVectorEntryArg	arg ;
	HWND		hwndControl ;
	int			nResult, nItem ;
	LVFINDINFO	lvfi ;

	arg.m_iChara		= -1 ;
	arg.m_bufText [0]	= TEXT ('\0') ;

	pArg		= (struct TEditZenkakuVectorArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ZENKAKUVECTOR) ;
	if (pArg == NULL || hwndControl == NULL)
		return	FALSE ;

	if (nCommandId != IDC_BUTTON_INSERT) {
		LVITEM	lvi ;
		int		nCurSel ;


		nCurSel	= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel == -1)
			return	FALSE ;
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.iItem	= nCurSel ;
		lvi.mask	= LVIF_PARAM ;
		if (ListView_GetItem (hwndControl, &lvi)) {
			int		nChara ;
			
			nChara	= (int) lvi.lParam ;
			if (0 <= nChara && nChara < SIZE_INPUTVECTOR) {
				arg.m_iChara	= nChara ;
				if (pArg->m_rpZenkakuVector [nChara] != NULL) 
					lstrcpyn (arg.m_bufText, pArg->m_rpZenkakuVector [arg.m_iChara], ARRAYSIZE (arg.m_bufText)) ;
			}
		}
	}
	switch (nCommandId) {
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
		{
			HINSTANCE	hInst ;
			int			nLength ;
			TCHAR		buf [256] ;
			BOOL		bEdit ;


			hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;

			nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_ONEZENKAKUVECTOR), hDlg, dlgEditZenkakuVectorProc, (LPARAM) &arg) ;
			if (nResult != IDOK)
				break ;
			if (nCommandId == IDC_BUTTON_INSERT && 
				0 <= arg.m_iChara && arg.m_iChara < ARRAYSIZE (pArg->m_rpZenkakuVector) &&
				pArg->m_rpZenkakuVector [arg.m_iChara] != NULL) {
				TCHAR	bufText [256] ;
				int		n ;

				if (0x20 < arg.m_iChara && arg.m_iChara < 127) {
					n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� %c �ɂ͊��� \"%s\" �����蓖�Ă��Ă��܂��B�u�������܂����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
				} else {
					n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� 0x%02x �ɂ͊��� \"%s\" �����蓖�Ă��Ă��܂��B�u�������܂����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
				}
				bufText [n]	= TEXT ('\0') ;

				if (MessageBox (hDlg, bufText, TEXT ("�x��"), MB_YESNO) != IDYES) 
					break ;
			}
			/*	�}�X�^�[�Ɠ����������̈�����L���Ă���̂ŁAFREE ����Ƃ܂����B
			if (pArg->m_rpZenkakuVector [arg.m_iChara] != NULL) {
				FREE (_rpZenkakuVector [arg.m_iChara]) ;
				bEdit	= TRUE ;
			}
			*/
			bEdit	= TRUE ;
			nLength	= lstrlen (arg.m_bufText) ;

			pArg->m_rpZenkakuVector [arg.m_iChara]	= (LPTSTR) MALLOC (sizeof (TCHAR) * (nLength + 1)) ;
			if (pArg->m_rpZenkakuVector [arg.m_iChara] == NULL)
				return	FALSE ;
			lstrcpy (pArg->m_rpZenkakuVector [arg.m_iChara], arg.m_bufText) ;

			dlgZenkakuVector_vCreateListItemText (buf, ARRAYSIZE (buf), arg.m_iChara, arg.m_bufText) ;
			if (bEdit) {
				memset (&lvfi, 0, sizeof (lvfi)) ;
				lvfi.flags	= LVFI_PARAM ;
				lvfi.lParam	= (LPARAM) arg.m_iChara ;
				nItem	= ListView_FindItem (hwndControl, -1, &lvfi) ;
				if (nItem != -1) {
					ListView_SetItemText (hwndControl, nItem, 0, buf) ;
				}
			} else {
				LVITEM	lvi ;

				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.iItem	= (int) arg.m_iChara ;
				lvi.mask	= LVIF_TEXT | LVIF_PARAM ;
				lvi.pszText	= buf ;
				lvi.lParam	= (LPARAM) arg.m_iChara ;
				ListView_InsertItem (hwndControl, &lvi) ;
			}
		}
		break ;
	case	IDC_BUTTON_DELETE:
		{
			TCHAR	bufText [256] ;
			int		n ;

			if (! (0 <= arg.m_iChara && arg.m_iChara < ARRAYSIZE (pArg->m_rpZenkakuVector) && pArg->m_rpZenkakuVector [arg.m_iChara] != NULL))
				break ;

			if (0x20 < arg.m_iChara && arg.m_iChara < 127) {
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� %c�A�o��\"%s\" ���폜���܂��B��낵���ł����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
			} else {
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� 0x%02x�A�o��\"%s\" ���폜���܂��B��낵���ł����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
			}
			bufText [n]	= TEXT ('\0') ;
			if (MessageBox (hDlg, bufText, TEXT ("�x��"), MB_YESNO) != IDYES)
				break ;
			/*FREE (_rpZenkakuVector [arg.m_iChara]) ;*/
			pArg->m_rpZenkakuVector [arg.m_iChara]	= NULL ;

			memset (&lvfi, 0, sizeof (lvfi)) ;
			lvfi.flags	= LVFI_PARAM ;
			lvfi.lParam	= (LPARAM) arg.m_iChara ;
			nItem	= ListView_FindItem (hwndControl, -1, &lvfi) ;
			if (nItem != -1) {
				ListView_DeleteItem (hwndControl, nItem) ;
			}
		}
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

void
dlgZenkakuVector_vCreateListItemText (
	LPTSTR			pDest,
	int				nDestSize,
	int				nChara,
	LPCTSTR			strOutput) 
{
	int		n ;

	if (nChara < 0x20 || nChara >= 127) {
		TCHAR	buf [32] ;

		vKey2String (buf, ARRAYSIZE (buf), nChara) ;
		n	= wnsprintf (pDest, nDestSize - 1, TEXT ("[%2x] `%s' = `%s'"), nChara, buf, strOutput) ;
	} else {
		n	= wnsprintf (pDest, nDestSize - 1, TEXT ("[%2x] `%c' = `%s'"), nChara, nChara, strOutput) ;
	}
	pDest [n]	= TEXT ('\0') ;
	return ;
}

/*========================================================================
 */
INT_PTR	CALLBACK
dlgEditZenkakuVectorProc (
	HWND			hDlg,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		{
			struct TEditZenkakuVectorEntryArg*	pArg	= (struct TEditZenkakuVectorEntryArg*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_CHARTOBIND) ;
			if (hwndControl != NULL) {
				TCHAR	buf [64] ;
				int		i, nItem ;

				for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
					vKey2String (buf, ARRAYSIZE (buf), i) ;
					nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) buf) ;
					if (nItem != CB_ERR) {
						SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) i) ;
					}
				}
				if (pArg->m_iChara != -1)
					SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_CHARTOBIND, pArg->m_iChara) ;
			}

			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_CHARVALUE) ;
			if (hwndControl != NULL) {
				SendMessage (hwndControl, EM_SETLIMITTEXT, (WPARAM) (ARRAYSIZE (pArg->m_bufText) - 1), (LPARAM) 0) ;
				SetDlgItemText (hDlg, IDC_EDIT_CHARVALUE, pArg->m_bufText) ;
			}
			return	(INT_PTR) TRUE ;
		}
	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			//WORD	woNotification	= HIWORD (wParam) ;

			switch (woControl) {
			case	IDOK:
				{
					struct TEditZenkakuVectorEntryArg*	pArg ;

					pArg	= (struct TEditZenkakuVectorEntryArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
					if (pArg != NULL) {
						HWND	hwndControl ;
						int		nText ;

						hwndControl	= GetDlgItem (hDlg, IDC_COMBO_CHARTOBIND) ;
						if (hwndControl != NULL) {
							int		nCurSel, nData ;

							nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
							if (nCurSel != CB_ERR) {
								nData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
							} else {
								nData	= CB_ERR ;
							}
							if (nData == CB_ERR) {
								(void) MessageBox (hDlg, TEXT ("���͕������ݒ肳��Ă��܂���B"), TEXT ("�x��"), MB_OK) ;
								break ;
							}
							pArg->m_iChara	= nData ;
						}
						nText	= GetDlgItemText (hDlg, IDC_EDIT_CHARVALUE, pArg->m_bufText, ARRAYSIZE (pArg->m_bufText)) ;
						pArg->m_bufText [nText]	= TEXT ('\0') ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				return	(INT_PTR) TRUE ;
			}
			return	(INT_PTR) TRUE ;
		}
	case	WM_NOTIFY:
		{
			return	(INT_PTR) 1 ;
		}
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 */
void
dlgKeybind_vClearZenkakuVector (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rpZenkakuVector) ; i ++) {
		if (_rpZenkakuVector [i] != NULL) {
			FREE (_rpZenkakuVector [i]) ;
			_rpZenkakuVector [i]	= NULL ;
		}
	}
	return ;
}

/*========================================================================
 *	registry ����c�B
 *	type(0/1/2), state, next, hira/kata or output or function ���B
 */
static	BOOL	dlgKeybind_bLoadKeymapFromRegistry	(void) ;
static	void	dlgKeybind_vLoadDefaultKeymap		(void) ;
static	BOOL	dlgKeybind_bSaveKeymap				(void) ;
static	BOOL	dlgKeybind_bLoadRomaKanaRuleList	(HWND, BOOL) ;
static	BOOL	dlgKeybind_bSaveAllRomaKanaRuleList	(void) ;
static	BOOL	dlgKeybind_bParseRomaKanaRuleLists	(HWND, HKEY, LPCTSTR*, int, LPCTSTR, BOOL, struct TSkkBaseRuleNode**) ;
static	BOOL	dlgKeybind_bParseRomaKanaRuleList	(LPCTSTR, DWORD, int, struct TSkkBaseRuleNode**, BOOL*) ;
static	BOOL	dlgKeybind_bSaveRomaKanaRuleList	(HKEY, LPCTSTR*, int, struct TSkkBaseRuleNode**) ;
static	void	dlgKeybind_vReportRomaKanaRuleListError	(HWND, LPCTSTR, DWORD, LPCTSTR) ;

static	LPCTSTR	srKeymapRegistryNames []	= {
	REGINFO_MAJORMODEMAP,
	REGINFO_JMODEMAP,
	REGINFO_LATINMODEMAP,
	REGINFO_ZENKAKUMODEMAP,	/* jisx0208-latin-mode-map */
	REGINFO_ABBREVMODEMAP,
} ;

static	LPCTSTR	srKeymapExtraRegistryNames []	= {
	REGINFO_MAJORMODEMAP_EX,
	REGINFO_JMODEMAP_EX,
	REGINFO_LATINMODEMAP_EX,
	REGINFO_ZENKAKUMODEMAP_EX,	/* jisx0208-latin-mode-map */
	REGINFO_ABBREVMODEMAP_EX,
} ;

static	struct CImeKeymap*	srpKeymaps []	= {
	&_sMajorModeMap,
	&_sSkkJModeMap,
	&_sSkkLatinModeMap,
	&_sSkkJisx0208LatinModeMap,
	&_sSkkAbbrevModeMap,
} ;

void
dlgKeybind_vLoadConfig (HWND hDlg, BOOL bErrorReport)
{
	if (! dlgKeybind_bLoadKeymapFromRegistry ()) {
		dlgKeybind_vLoadDefaultKeymap () ;
	}
	if (! dlgKeybind_bLoadRomaKanaRuleList (hDlg, bErrorReport)) {
		int	i ;

		_siRomaKanaRuleListType			= KEYBINDTP_DEFAULT ;
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			_rplstRomaKanaRules			[i]	= NULL ;
			_rplstJisx0201KanaRules		[i]	= NULL ;
			_rplstJisx0201RomanRules	[i]	= NULL ;
		}
		_sbExistUserDefinedRomaKanaRule	= FALSE ;
	}
	(void) dlgKeybind_bLoadZenkakuVector () ;
	return ;
}

BOOL
dlgKeybind_bSaveConfig (void)
{
	HKEY	hSubKey ;
	DWORD	dwValue ;

	dlgKeybind_bSaveKeymap () ;
	dlgKeybind_bSaveAllRomaKanaRuleList () ;
	dlgKeybind_bSaveZenkakuVector () ;

	if (! bCreateRegistryKey (REGPATH_KEYMAP, FALSE, &hSubKey)) 
		return	FALSE ;

	dwValue	= (DWORD) _sbEggLikeNewline ;
	if (RegSetValueEx (hSubKey, REGINFO_EGGLIKENEWLINE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	error_exit ;
	dwValue	= (DWORD) _sbNewlineKakuteiAll ;
	if (RegSetValueEx (hSubKey, REGINFO_NEWLINEKAKUTEIALL, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	error_exit ;
error_exit:
	RegCloseKey (hSubKey) ;
	return	TRUE ;
}

BOOL
dlgKeybind_bLoadKeymapFromRegistry (void)
{
	HKEY	hSubKey ;
	int		i ;
	BOOL	bRetval	= FALSE ;

	_sbExistUserDefinedKeymap					= FALSE ;
	_sbExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
	_sbExistUserDefinedSpecialMidashiCharKey	= FALSE ;
	_sbExistUserDefinedCompletionKey			= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 	lResult ;
		DWORD	dwType, cbData, dwValue ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_KEYMAP_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siKeybindType	= (int) dwValue ;

		for (i = 0 ; i < ARRAYSIZE (srKeymapRegistryNames) ; i ++) {
			lResult	= RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS) 
				break ;
			if (dwType != REG_BINARY || cbData != MAX_KEYBINDS) 
				goto	skip_error ;

			(void) RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, srpKeymaps [i]->m_rbyBaseMap, &cbData) ;
		}
		if (i >= ARRAYSIZE (srKeymapRegistryNames))
			_sbExistUserDefinedKeymap	= TRUE ;

		if (_sbExistUserDefinedKeymap) {
			BYTE	rbBuffer [512] ;
			BYTE*	pbBuffer	= NULL ;
			DWORD	iBufSize ;

			pbBuffer	= rbBuffer ;
			iBufSize	= sizeof (rbBuffer) ;
			for (i = 0 ; i < ARRAYSIZE (srKeymapExtraRegistryNames) ; i ++) {
				int				iNumKeyBinds, j ;
				const BYTE*		pbData ;
				struct CImeKeyBind*	pKeyBind ;

				/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
				lResult	= RegQueryValueEx (hSubKey, srKeymapExtraRegistryNames [i], NULL, &dwType, NULL, &cbData) ;
				if (lResult != ERROR_SUCCESS || dwType != REG_BINARY)
					continue ;
				if (cbData > iBufSize) {
					if (pbBuffer != rbBuffer) {
						FREE (pbBuffer) ;
					}
					pbBuffer	= (BYTE*) MALLOC (cbData) ;
					if (pbBuffer == NULL) {
						/* error */
						break ;
					}
					iBufSize	= cbData ;
				}
				(void) RegQueryValueEx (hSubKey, srKeymapExtraRegistryNames [i], NULL, &dwType, pbBuffer, &cbData) ;

				/*
				 */
				iNumKeyBinds	= cbData / SIZE_PER_1EXTRAKEY ;	/* VKEY(4), MODIFIER(2), FUNCNO(2) */
				if (iNumKeyBinds <= 0)
					continue ;

				srpKeymaps [i]->m_pKeyBinds	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * iNumKeyBinds) ;
				if (srpKeymaps [i]->m_pKeyBinds == NULL) {
					/* error */
					break ;
				}
				srpKeymaps [i]->m_nKeyBinds	= iNumKeyBinds ;

				pbData		= pbBuffer ;
				pKeyBind	= srpKeymaps [i]->m_pKeyBinds ;
				for (j = 0 ; j < iNumKeyBinds ; j ++) {
					unsigned int	uVKey, uModifier ;
					int				iFuncNo ;

					uVKey		= (unsigned int) *pbData ++ ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ <<  8) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 16) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 24) ;
					uModifier	= (unsigned int) *pbData ++ ;
					uModifier	= uModifier | ((unsigned int) *pbData ++ << 8) ;
					iFuncNo		= (unsigned int) *pbData ++ ;
					iFuncNo		= iFuncNo | ((unsigned int) *pbData ++) ;
					if (iFuncNo < 0 || iFuncNo >= NFUNC_INVALID_CHAR) 
						continue ;	/* skip */
					pKeyBind->m_nKeyCode		= uVKey ;
					pKeyBind->m_uKeyMask		= uModifier ;
					pKeyBind->m_nKeyFunction	= iFuncNo ;
					pKeyBind	++ ;
				}
				/* realloc �������Ƃ��낾���ǁc */
				srpKeymaps [i]->m_nKeyBinds	= pKeyBind - srpKeymaps [i]->m_pKeyBinds ;
			}
			if (pbBuffer != rbBuffer && pbBuffer != NULL) {
				FREE (pbBuffer) ;
				pbBuffer	= NULL ;
			}
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siStartHenkanKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbyStartHenkanKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY, NULL, &dwType, (BYTE*)_srbyStartHenkanKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			_sbExistUserDefinedStartHenkanKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumStartHenkanKeys				= (int) cbData ;
			_sbExistUserDefinedStartHenkanKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siCompletionKeyType	= (int) dwValue ;
		if (RegQueryValueEx (hSubKey, REGINFO_TRYCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyTryCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumTryCompletionKeys				= (int) cbData ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyPreviousCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumPreviousCompletionKeys		= (int) cbData ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_NEXTCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyNextCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumNextCompletionKeys			= (int) cbData ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) 
			goto	skip_error ;
		_siSetHenkanPointSubrKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySetHenkanPointSubrKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, NULL, &dwType, (BYTE*)_srbySetHenkanPointSubrKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			_sbExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSetHenkanPointSubrKeys				= (int) cbData ;
			_sbExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siSpecialMidashiCharKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySpecialMidashiCharKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR, NULL, &dwType, (BYTE*)_srbySpecialMidashiCharKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			_sbExistUserDefinedSpecialMidashiCharKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSpecialMidashiCharKeys				= (int) cbData ;
			_sbExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_EGGLIKENEWLINE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_sbEggLikeNewline	= (dwValue != 0) ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_NEWLINEKAKUTEIALL, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_sbNewlineKakuteiAll	= (dwValue != 0) ;
		}
		bRetval	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}

	/* �f�[�^���ςłȂ����A�X�̗v�f���`�F�b�N����B*/
	if (bRetval) {
		for (i = 0 ; i < ARRAYSIZE (srpKeymaps) ; i ++) {
			int		j ;
			for (j = 0 ; j < MAX_KEYBINDS ; j ++) {
				if (srpKeymaps [i]->m_rbyBaseMap [j] < 0 || srpKeymaps [i]->m_rbyBaseMap [j] >= NUM_SELECTABLE_FUNCTIONS) {
					srpKeymaps [i]->m_rbyBaseMap[j]	= NFUNC_INVALID_CHAR ;
				}
			}
			for (j = 0 ; j < srpKeymaps [i]->m_nKeyBinds ; j ++) {
				if (srpKeymaps [i]->m_pKeyBinds [j].m_nKeyFunction < 0 ||
					srpKeymaps [i]->m_pKeyBinds [j].m_nKeyFunction >= NUM_SELECTABLE_FUNCTIONS) {
					srpKeymaps [i]->m_pKeyBinds [j].m_nKeyFunction	= NFUNC_INVALID_CHAR ;
				}
			}
		}
		if (_siStartHenkanKeyType == KEYBINDTP_USERDEFINED && ! _sbExistUserDefinedStartHenkanKey)
			_siStartHenkanKeyType	= KEYBINDTP_DEFAULT ;
		if (_siCompletionKeyType == KEYBINDTP_USERDEFINED && ! _sbExistUserDefinedCompletionKey)
			_siCompletionKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSetHenkanPointSubrKeyType == KEYBINDTP_USERDEFINED && !_sbExistUserDefinedSetHenkanPointSubrKey) 
			_siSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSpecialMidashiCharKeyType == KEYBINDTP_USERDEFINED && !_sbExistUserDefinedSpecialMidashiCharKey) 
			_siSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;
	}
	return	bRetval ;
}


void
dlgKeybind_vLoadDefaultKeymap (void)
{
	dlgKeybind_vInitializeDefaultMajorModeMap (&_sMajorModeMap) ;
	dlgKeybind_vInitializeDefaultJModeMap (&_sSkkJModeMap, &_sMajorModeMap) ;
	dlgKeybind_vInitializeDefaultLatinModeMap (&_sSkkLatinModeMap) ;
	dlgKeybind_vInitializeDefaultJisx0208LatinModeMap (&_sSkkJisx0208LatinModeMap) ;
	dlgKeybind_vInitializeDefaultAbbrevModeMap (&_sSkkAbbrevModeMap, &_sMajorModeMap) ;
	return ;
}

void
dlgKeybind_vCloneKeymap (
	struct CImeKeymap*			pDestMap,
	const struct CImeKeymap*	pSrcMap)
{
	if (pDestMap == NULL || pSrcMap == NULL) 
		return ;
	memcpy (pDestMap->m_rbyBaseMap, pSrcMap->m_rbyBaseMap, sizeof (pSrcMap->m_rbyBaseMap)) ;
	if (pSrcMap->m_nKeyBinds > 0) {
		pDestMap->m_pKeyBinds	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * pSrcMap->m_nKeyBinds) ;
		if (pDestMap->m_pKeyBinds == NULL) {
			pDestMap->m_nKeyBinds	= 0 ;
			return ;
		}
		memcpy (pDestMap->m_pKeyBinds, pSrcMap->m_pKeyBinds, sizeof (struct CImeKeyBind) * pSrcMap->m_nKeyBinds) ;
		pDestMap->m_nKeyBinds	= pSrcMap->m_nKeyBinds ;
	} else {
		pDestMap->m_nKeyBinds	= 0 ;
		pDestMap->m_pKeyBinds	= NULL ;
	}
	return ;
}

void
dlgKeyBind_vClearKeymap (
	struct CImeKeymap*			pDestMap)
{
	if (pDestMap == NULL)
		return ;
	if (pDestMap->m_pKeyBinds != NULL) {
		FREE (pDestMap->m_pKeyBinds) ;
		pDestMap->m_pKeyBinds	= NULL ;
	}
	pDestMap->m_nKeyBinds	= 0 ;
	return ;
}

void
dlgKeybind_vInitializeDefaultMajorModeMap (struct CImeKeymap* pMajorModeMap)
{
	static BYTE		_srbDefaultMajorModeMap []	= {
		NFUNC_SET_MARK_COMMAND,				/* C-@ */
		NFUNC_BEGINNING_OF_LINE,			/* C-a */
		NFUNC_BACKWARD_CHAR,				/* C-b */
		NFUNC_INVALID_CHAR,					//NFUNC_MODE_SPECIFIC_COMMAND_PREFIX,	/* C-c */
		NFUNC_DELETE_CHAR,					/* C-d */
		NFUNC_END_OF_LINE,					/* C-e */
		NFUNC_FORWARD_CHAR,					/* C-f */
		NFUNC_KEYBOARD_QUIT,				/* C-g */
		NFUNC_BACKWARD_DELETE_CHAR,			/* C-h */
		NFUNC_INVALID_CHAR,					//NFUNC_INDENT_FOR_TAB_COMMAND,			/* C-i */
		NFUNC_NEWLINE,						//NFUNC_NEWLINE_AND_INDENT,				/* C-j */
		NFUNC_KILL_LINE,					/* C-k */
		NFUNC_INVALID_CHAR,					//NFUNC_RECENTER,						/* C-l */
		NFUNC_NEWLINE,						/* C-m */
		NFUNC_INVALID_CHAR,					//NFUNC_NEXT_LINE,						/* C-n */
		NFUNC_INVALID_CHAR,					//NFUNC_OPEN_LINE,						/* C-o */
		NFUNC_INVALID_CHAR,					//NFUNC_PREVIOUS_LINE,					/* C-p */	
		NFUNC_INVALID_CHAR,					//NFUNC_QUATED_INSERT,					/* C-q */
		NFUNC_INVALID_CHAR,					//NFUNC_ISEARCH_BACKWARD,				/* C-r */
		NFUNC_INVALID_CHAR,					//NFUNC_ISEARCH_FORWARD,				/* C-s */
		NFUNC_TRANSPOSE_CHARS,				/* C-t */
		NFUNC_INVALID_CHAR,					//FUNC_UNIVERSAL_ARGUMENT,				/* C-u */
		NFUNC_INVALID_CHAR,					//NFUNC_SCROLL_UP,						/* C-v */
		NFUNC_KILL_REGION,					/* C-w */
		NFUNC_INVALID_CHAR,					//NFUNC_CONTROL_X_PREFIX,				/* C-x */
		NFUNC_YANK,							/* C-y */
		NFUNC_INVALID_CHAR,					//NFUNC_SCROLL_DOWN,					/* C-z */
		NFUNC_INVALID_CHAR,					//NFUNC_PREFIX_COMMAND,					/* C-[ */
		NFUNC_TOGGLE_IME,					/* C-\\ */
		NFUNC_ABORT_RECURSIVE_EDIT,			/* C-] */
		NFUNC_INVALID_CHAR,					//NFUNC_UNDO,							/* C-_ */
	} ;
	int	i ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++) 
		pMajorModeMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	for (i = 0 ; i < ARRAYSIZE (_srbDefaultMajorModeMap) ; i ++) 
		pMajorModeMap->m_rbyBaseMap [i]	= _srbDefaultMajorModeMap [i] ;
	for (i = 32 ; i < 127 ; i ++) 
		pMajorModeMap->m_rbyBaseMap [i]	= NFUNC_SELF_INSERT_CHARACTER ;

	pMajorModeMap->m_pKeyBinds	= NULL ;
	pMajorModeMap->m_nKeyBinds	= 0 ;
	return ;
}

void
dlgKeybind_vInitializeDefaultJModeMap (
	struct CImeKeymap*			pJModeMap,
	const struct CImeKeymap*	pMajorModeMap)
{
	int		i ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		pJModeMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 32 ; i < 127 ; i ++) {
		pJModeMap->m_rbyBaseMap [i]	= NFUNC_SKK_INSERT ;
	}
	pJModeMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;

	/*	previous-candidate-char ���ɂ���ׂ����Akeybind ���� previous-candidate-char ��
	 *	���߂�悤�ɂ���ׂ����B�ǂ��炪�������̂��B��҂��I������Ȃ��������R�́A�ǂ�
	 *	minor-mode-map �𗘗p����Ηǂ��̂�������Ȃ��������炩�H
	 */
	pJModeMap->m_rbyBaseMap ['x']	= NFUNC_SKK_PREVIOUS_CANDIDATE ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (pMajorModeMap->m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			pJModeMap->m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	/*	try-completion-char �� skk-insert �ɂ��킹��B
	 *	try-completion-char �� keybind ����ɂ��邩�c�B���[��A�ł� try-completion �̓���
	 *	�� skk-insert �Ɠ����ɂ��Ă����� (function code �͈Ⴄ���ǁA����͓�����)�A
	 *	keybind �� try-completion �Ȃ� try-completion-charp �� t ��Ԃ��Ƃ����̂́H
	 *
	 *	�����Aabbrev-map �͑f���� try-completion �Ȃ̂ɁA������� skk-insert �o�R�Ƃ����̂�
	 *	�C�ɂȂ�c�B����������闝�R���l�������� try-completion ������̂͊댯���B
	 */
	pJModeMap->m_rbyBaseMap ['\t']	= NFUNC_SKK_INSERT ;
	pJModeMap->m_nKeyBinds			= 0 ;
	pJModeMap->m_pKeyBinds			= NULL ;
	return ;
}

void
dlgKeybind_vInitializeDefaultLatinModeMap (
	struct CImeKeymap*		pLatinMap)
{
	int		i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		pLatinMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pLatinMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	pLatinMap->m_nKeyBinds			= 0 ;
	pLatinMap->m_pKeyBinds			= NULL ;
	return ;
}

void
dlgKeybind_vInitializeDefaultJisx0208LatinModeMap (
	struct CImeKeymap*		pJisx0208LatinMap)
{
	int		i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		pJisx0208LatinMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	for (i = 0 ; i < 128 ; i ++) {
		/*	_rstrSkkJisx0208LatinVector �̐ݒ肪������ƘA�����Ȃ���΁B
		 */
		if (_rstrDefaultSkkJisx0208LatinVector [i] != NULL) 
			pJisx0208LatinMap->m_rbyBaseMap [i]	= NFUNC_SKK_JISX0208_LATIN_INSERT ;
	}
	pJisx0208LatinMap->m_rbyBaseMap [17]	= NFUNC_SKK_LATIN_HENKAN ;	/* \C-q */

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pJisx0208LatinMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-backward-and-set-henkan-point-char �́c 2stroke key �͎������ĂȂ�����c�B*/
	pJisx0208LatinMap->m_nKeyBinds			= 0 ;
	pJisx0208LatinMap->m_pKeyBinds			= NULL ;
	return ;
}

void
dlgKeybind_vInitializeDefaultAbbrevModeMap (
	struct CImeKeymap*			pAbbrevMap,
	const struct CImeKeymap*	pMajorModeMap)
{
	int		i ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		pAbbrevMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	pAbbrevMap->m_rbyBaseMap ['.']	= NFUNC_SKK_ABBREV_PERIOD ;
	pAbbrevMap->m_rbyBaseMap [',']	= NFUNC_SKK_ABBREV_COMMA ;
	pAbbrevMap->m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_CHARACTERS ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pAbbrevMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-start-henkan-char �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pAbbrevMap->m_rbyBaseMap [' ']	= NFUNC_SKK_START_HENKAN ;

	/*	�{���� m_pKeyBinds �����āANFUNC_SKK_DELETE_BACKWARD_CHAR �̐ݒ������
	 *	���Ƃ����Ȃ��̂����B
	 */
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (pMajorModeMap->m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			pAbbrevMap->m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	pAbbrevMap->m_rbyBaseMap ['\t']	= NFUNC_SKK_TRY_COMPLETION ;
	pAbbrevMap->m_nKeyBinds			= 0 ;
	pAbbrevMap->m_pKeyBinds			= NULL ;
	return ;
}

BOOL
dlgKeybind_bSaveKeymap (void)
{
	HKEY	hSubKey ;
	int		i ;
	DWORD	dwValue ;
	BOOL	bRetval ;

	if (! bCreateRegistryKey (REGPATH_KEYMAP, FALSE, &hSubKey)) 
		return	FALSE ;

	bRetval	= FALSE ;
	dwValue	= (DWORD) _siKeybindType ;
	if (RegSetValueEx (hSubKey, REGINFO_KEYMAP_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) 
		goto	exit_func ;

	/*	�o�^�̘b���c
	 */
	if (_sbExistUserDefinedKeymap) {
		BYTE	rbBuffer [1024] ;
		BYTE*	pbBuffer ;
		int		iBufferSize ;

		for (i = 0 ; i < ARRAYSIZE (srKeymapRegistryNames) ; i ++) {
			BYTE*	pDest ;
			BYTE*	pSrc ;
			int		j ;
			pDest	= rbBuffer ;
			pSrc	= srpKeymaps [i]->m_rbyBaseMap ;
			for (j = 0 ; j < MAX_KEYBINDS ; j ++, pSrc ++, pDest ++)
				*pDest	= (*pSrc < 0 || *pSrc >= NFUNC_INVALID_CHAR)? 0xFF : *pSrc ;
			if (RegSetValueEx (hSubKey, srKeymapRegistryNames [i], 0, REG_BINARY, rbBuffer, MAX_KEYBINDS) != ERROR_SUCCESS) 
				goto	exit_func ;
		}

		/* ExtraKeymap �̘b�B*/
		pbBuffer	= rbBuffer ;
		iBufferSize	= sizeof (rbBuffer) ;
		for (i = 0 ; i < ARRAYSIZE (srKeymapExtraRegistryNames) ; i ++) {
			if (srpKeymaps [i]->m_nKeyBinds > 0) {
				struct CImeKeyBind*	pKeyBind ;
				BYTE*	ptr ;
				int		iNeedSize, j ;

				iNeedSize	= srpKeymaps [i]->m_nKeyBinds * SIZE_PER_1EXTRAKEY ;
				if (iBufferSize < iNeedSize) {
					if (pbBuffer != rbBuffer)
						FREE (pbBuffer) ;
					pbBuffer	= (BYTE*) MALLOC (iNeedSize) ;
					if (pbBuffer == NULL)
						break ;
					iBufferSize	= iNeedSize ;
				}
				ptr			= pbBuffer ;
				pKeyBind	= srpKeymaps [i]->m_pKeyBinds ;
				for (j = 0 ; j < srpKeymaps [i]->m_nKeyBinds ; j ++) {
					int		nFunction ;

					*ptr ++	= ((UINT) pKeyBind->m_nKeyCode >>  0) & 0xFF ;
					*ptr ++	= ((UINT) pKeyBind->m_nKeyCode >>  8) & 0xFF ;
					*ptr ++	= ((UINT) pKeyBind->m_nKeyCode >> 16) & 0xFF ;
					*ptr ++	= ((UINT) pKeyBind->m_nKeyCode >> 24) & 0xFF ;
					*ptr ++	= ((UINT) pKeyBind->m_uKeyMask >>  0) & 0xFF ;
					*ptr ++	= ((UINT) pKeyBind->m_uKeyMask >>  8) & 0xFF ;
					/* INVALID-CHAR �� 255 �ɂ��Ă����B*/
					nFunction	= (pKeyBind->m_nKeyFunction < 0 || pKeyBind->m_nKeyFunction >= NFUNC_INVALID_CHAR)? 255 : pKeyBind->m_nKeyFunction ;
					*ptr ++	= ((UINT) nFunction >> 0) & 0xFF ;
					*ptr ++	= ((UINT) nFunction >> 8) & 0xFF ;
					pKeyBind	++ ;
				}
				if (RegSetValueEx (hSubKey, srKeymapExtraRegistryNames [i], 0, REG_BINARY, pbBuffer, ptr - pbBuffer)  != ERROR_SUCCESS) 
					break ;
			} else {
				/*	�L�[���������B
				 *	�ށA64bit ���� registry key �� 32bit �� 64bit �̕������݂���̂��B
				 *	���������ɑ��삵�Ȃ��Ƃ܂����Ȃ����H
				 */
				RegDeleteKey (hSubKey, srKeymapExtraRegistryNames [i]) ;
			}
		}
		if (pbBuffer != rbBuffer)
			FREE (pbBuffer) ;
	}
	
	dwValue	= (DWORD) _siStartHenkanKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_STARTHENKANKEY_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) 
		goto	exit_func ;
	if (_sbExistUserDefinedStartHenkanKey) {
		if (RegSetValueEx (hSubKey, REGINFO_STARTHENKANKEY, 0, REG_BINARY, (BYTE*) _srbyStartHenkanKeys, _siNumStartHenkanKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}
	dwValue	= (DWORD) _siCompletionKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) 
		goto	exit_func ;
	if (_sbExistUserDefinedCompletionKey) {
		if (RegSetValueEx (hSubKey, REGINFO_TRYCOMPLETIONKEY, 0, REG_BINARY, (BYTE*) _srbyTryCompletionKeys, _siNumTryCompletionKeys) != ERROR_SUCCESS)
			goto	exit_func ;
		if (RegSetValueEx (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, 0, REG_BINARY, (BYTE*) _srbyPreviousCompletionKeys, _siNumPreviousCompletionKeys) != ERROR_SUCCESS)
			goto	exit_func ;
		if (RegSetValueEx (hSubKey, REGINFO_NEXTCOMPLETIONKEY, 0, REG_BINARY, (BYTE*) _srbyNextCompletionKeys, _siNumNextCompletionKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}

	dwValue	= (DWORD) _siSetHenkanPointSubrKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) 
		goto	exit_func ;
	if (_sbExistUserDefinedSetHenkanPointSubrKey) {
		if (RegSetValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, 0, REG_BINARY, (BYTE*) _srbySetHenkanPointSubrKeys, _siNumSetHenkanPointSubrKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}

	dwValue	= (DWORD) _siSpecialMidashiCharKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) 
		goto	exit_func ;
	if (_sbExistUserDefinedSpecialMidashiCharKey) {
		if (RegSetValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR, 0, REG_BINARY, (BYTE*) _srbySpecialMidashiCharKeys, _siNumSpecialMidashiCharKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}

	/*	������ Enter �ݒ肪����B
	 */
exit_func:
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

static	LPCTSTR	srRomaKanaRuleTbl [NUM_ROMAKANARULE]	= {
	REGINFO_ROMAKANARULE,	REGINFO_ROMAKANARULE1,
	REGINFO_ROMAKANARULE2,	REGINFO_ROMAKANARULE3,
} ;

static	LPCTSTR	srJisx0201KanaRuleTbl [NUM_ROMAKANARULE]	= {
	REGINFO_JISX0201RULE,	REGINFO_JISX0201RULE1,
	REGINFO_JISX0201RULE2,	REGINFO_JISX0201RULE3,
} ;

static	LPCTSTR	srJisx0201RomanRuleTbl [NUM_ROMAKANARULE]	= {
	REGINFO_JISX0201ROMANRULE,	REGINFO_JISX0201ROMANRULE1,
	REGINFO_JISX0201ROMANRULE2,	REGINFO_JISX0201ROMANRULE3,
} ;

BOOL
dlgKeybind_bLoadRomaKanaRuleList (HWND hDlg, BOOL bErrorReport)
{
	HKEY	hSubKey ;
	BOOL	bRetval	= TRUE ;

	_sbExistUserDefinedRomaKanaRule	= FALSE ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_ROMAKANARULE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData, dwValue ;
		BOOL	bExist1, bExist2, bExist3 ;

		/* rule-list-type (default or custom) */
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_ROMAKANARULE_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) {
			_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
		} else {
			_siRomaKanaRuleListType	= (int) dwValue ;
		}
#if defined (JAPANESE_MESSAGE)
		bExist1	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srRomaKanaRuleTbl,			NUM_ROMAKANARULE, TEXT("���[�}�����ȃ��[��"),		bErrorReport, _rplstRomaKanaRules) ;
		bExist2	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201KanaRuleTbl,		NUM_ROMAKANARULE, TEXT("JISX0201���ȃ��[��"),		bErrorReport, _rplstJisx0201KanaRules) ;
		bExist3	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201RomanRuleTbl,	NUM_ROMAKANARULE, TEXT("JISX0201���[�}�����[��"),	bErrorReport, _rplstJisx0201RomanRules) ;
#else
		bExist1	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srRomaKanaRuleTbl,			NUM_ROMAKANARULE, TEXT("roma-kana-rule"),		bErrorReport, _rplstRomaKanaRules) ;
		bExist2	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201KanaRuleTbl,		NUM_ROMAKANARULE, TEXT("jisx0201-kana-rule"),	bErrorReport, _rplstJisx0201KanaRules) ;
		bExist3	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201RomanRuleTbl,	NUM_ROMAKANARULE, TEXT("jisx0201-roman-rule"),	bErrorReport, _rplstJisx0201RomanRules) ;
#endif
		_sbExistUserDefinedRomaKanaRule	= bExist1 || bExist2 || bExist3 ;
		RegCloseKey (hSubKey) ;
	}
	if (! _sbExistUserDefinedRomaKanaRule) {
		_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
	}
	return	bRetval;
}

BOOL
dlgKeybind_bParseRomaKanaRuleLists (
	HWND						hDlg,
	HKEY						hSubKey,
	LPCTSTR*					ppszRomaKanaRuleTblName,
	int							nRules,
	LPCTSTR						strRuleDisplayName,
	BOOL						bErrorReport,
	struct TSkkBaseRuleNode**	pplstRules)
{
	LONG 	lResult ;
	DWORD	dwType, cbData ;
	int		i ;
	LPTSTR	pwData	= NULL ;
	BOOL	bExist	= FALSE ;

	for (i = 0 ; i < nRules ; i ++)
		pplstRules [i]	= NULL ;

	for (i = 0 ; i < nRules ; i ++) {
		lResult	= RegQueryValueEx (hSubKey, ppszRomaKanaRuleTblName [i], NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) {
			pplstRules [i]	= NULL ;
			continue ;
		}
		if (dwType != REG_MULTI_SZ) {
			bExist	= FALSE ;
			break ;
		}
		if (cbData > 0) {
			BOOL	bError ;

			pwData	= (LPTSTR) MALLOC (cbData) ;
			if (pwData == NULL)
				continue ;

			(void) RegQueryValueEx (hSubKey, ppszRomaKanaRuleTblName [i], NULL, &dwType, (BYTE*)pwData, &cbData) ;
			bError	= FALSE ;
			if (dlgKeybind_bParseRomaKanaRuleList (pwData, cbData/sizeof(TCHAR), i, &pplstRules [i], &bError)) {
				bExist	= TRUE ;
			}
			if (bErrorReport && bError) {
				TCHAR	bufMessage [128] ;
				int		n ;

				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT("%s%d"), strRuleDisplayName, i) ;
				bufMessage [n]	= TEXT ('\0') ;
				dlgKeybind_vReportRomaKanaRuleListError (hDlg, pwData, cbData/sizeof(TCHAR), bufMessage) ;
			}
			FREE (pwData) ;
		} else {
			pplstRules [i]	= NULL ;
			bExist	= TRUE ;
		}
	}
	return	bExist ;
}

BOOL
dlgKeybind_bParseRomaKanaRuleList (
	LPCTSTR						pwData,
	DWORD						cbData,
	int							nRule,
	struct TSkkBaseRuleNode**	pplst,
	BOOL*						pbError)
{
	LPCTSTR	pwSrc, pwSrcEnd ;
	TCHAR	bufState [128], bufNext [128], bufHira [128], bufKata [128] ;
	TCHAR	bufNextRule [32] ;
	struct TSkkBaseRuleNode*	plstRomaKanaRule	= NULL ;
	BOOL	bError ;

	bError		= FALSE ;
	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	while (*pwSrc != TEXT ('\0') && pwSrc < pwSrcEnd) {
		struct TSkkBaseRuleNode*	pNewNode ;
		int							nType ;
		BOOL						bTerminated ;
		LPCWSTR						pwNext ;
		int							nNextRule ;

		pNewNode	= NULL ;
		nType		= *pwSrc ++ ;
		if (! bParseBSEncodedString (&pwSrc, bufState, ARRAYSIZE (bufState) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! bParseBSEncodedString (&pwSrc, bufNext,  ARRAYSIZE (bufNext)  - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! bParseBSEncodedString (&pwSrc, bufNextRule, ARRAYSIZE (bufNextRule) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;

		bufState	 [ARRAYSIZE (bufState)		- 1]	= TEXT ('\0') ;
		bufNext		 [ARRAYSIZE (bufNext)		- 1]	= TEXT ('\0') ;
		bufNextRule  [ARRAYSIZE (bufNextRule)	- 1]	= TEXT ('\0') ;
		pwNext	= (bufNext [0] != TEXT ('\0'))? bufNext : NULL ;
#if __STDC_WANT_SECURE_LIB__
		if (_snwscanf_s (bufNextRule, ARRAYSIZE (bufNextRule), L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#else
		if (swscanf (bufNextRule, L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#endif

		switch (nType) {
		case	TEXT ('1'):
			if (! bParseBSEncodedString (&pwSrc, bufHira, ARRAYSIZE (bufHira) - 1, &bTerminated) || bTerminated)
				break ;
			if (! bParseBSEncodedString (&pwSrc, bufKata, ARRAYSIZE (bufKata) - 1, &bTerminated) || ! bTerminated)
				break ;

			bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;
			bufKata [ARRAYSIZE (bufKata)  - 1]	= TEXT ('\0') ;
			pNewNode	= dlgRomaKanaRule_pCreateType1Rule (bufState, pwNext, nNextRule, bufHira, bufKata) ;
			break ;
		case	TEXT ('2'):
			if (! bParseBSEncodedString (&pwSrc, bufHira, ARRAYSIZE (bufHira) - 1, &bTerminated) || ! bTerminated)
				break ;
			bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;
			pNewNode	= dlgRomaKanaRule_pCreateType2Rule (bufState, pwNext, nNextRule, bufHira) ;
			break ;
		case	TEXT ('3'):
			{
				int		nFuncNo	= 0 ;

				if (! bParseBSEncodedString (&pwSrc, bufHira, ARRAYSIZE (bufHira) - 1, &bTerminated) || ! bTerminated)
					break ;
				bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;

#if __STDC_WANT_SECURE_LIB__
				if (_snwscanf_s (bufHira, ARRAYSIZE (bufHira), L"%d", &nFuncNo) != 1)
					nFuncNo	= 0 ;
#else
				if (swscanf (bufHira, L"%d", &nFuncNo) != 1)
					nFuncNo	= 0 ;
#endif
				pNewNode	= dlgRomaKanaRule_pCreateType3Rule (bufState, pwNext, nNextRule, nFuncNo) ;
			}
			break ;
		default:
			break ;
		}
next_entry:
		if (pNewNode != NULL) {
			/* NewNode �� list �ɒǉ��B*/
			pNewNode->_pNext	= plstRomaKanaRule ;
			plstRomaKanaRule	= pNewNode ;
		} else {
#if defined (DEBUG) || defined (DBG)
			{
				TCHAR	buf [128] ;
				int		n ;
				n	= _sntprintf (buf, ARRAYSIZE(buf)-1, TEXT ("Skip: state:\"%d\", type:\"%d\"\n"), bufState, nType) ;
				buf [n]	= TEXT ('\0') ;
				OutputDebugString (buf) ;
			}
#endif
			bError	= TRUE ;
			/* error skip */
			while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
				pwSrc ++ ;
		}
		pwSrc	++ ;	/* nul �� skip */
	}
	if (pplst != NULL)
		*pplst	= plstRomaKanaRule ;
	if (pbError != NULL)
		*pbError	= bError ;
	return	TRUE ;
}

void
dlgKeybind_vReportRomaKanaRuleListError (
	HWND						hDlg,
	LPCTSTR						pwData,
	DWORD						cbData,
	LPCTSTR						strMessage)
{
	LPCTSTR	pwSrc, pwSrcEnd ;
	TCHAR	bufTmp [128] ;
	CVarbuffer<WCHAR,256>	vbuf ;
	WCHAR	bufMessage [256] ;
	BOOL	bFirst	= TRUE, bMoreThanTwo	= FALSE ;
	int		n ;

	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	while (*pwSrc != TEXT ('\0') && pwSrc < pwSrcEnd) {
		int			nType, nNextRule ;
		BOOL		bTerminated ;
		LPCWSTR		pwBase ;
		BOOL		bError ;

		bError		= TRUE ;
		pwBase		= pwSrc ;
		nType		= *pwSrc ++ ;
		if (! bParseBSEncodedString (&pwSrc, bufTmp, ARRAYSIZE (bufTmp) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! bParseBSEncodedString (&pwSrc, bufTmp, ARRAYSIZE (bufTmp) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		if (! bParseBSEncodedString (&pwSrc, bufTmp, ARRAYSIZE (bufTmp) - 1, &bTerminated) || bTerminated)
			goto	next_entry ;
		bufTmp  [ARRAYSIZE (bufTmp)	- 1]	= TEXT ('\0') ;
#if __STDC_WANT_SECURE_LIB__
		if (_snwscanf_s (bufTmp, ARRAYSIZE (bufTmp), L"%d", &nNextRule) != 1)
			goto	next_entry ;
#else
		if (swscanf (bufTmp, L"%d", &nNextRule) != 1)
			goto	next_entry ;
#endif
		switch (nType) {
		case	TEXT ('1'):
			if (! bParseBSEncodedString (&pwSrc, bufTmp, ARRAYSIZE (bufTmp) - 1, &bTerminated) || bTerminated)
				break ;
			if (! bParseBSEncodedString (&pwSrc, bufTmp, ARRAYSIZE (bufTmp) - 1, &bTerminated) || ! bTerminated)
				break ;
			bError	= FALSE ;
			break ;
		case	TEXT ('2'):
			if (! bParseBSEncodedString (&pwSrc, bufTmp, ARRAYSIZE (bufTmp) - 1, &bTerminated) || ! bTerminated)
				break ;
			bError	= FALSE ;
			break ;
		case	TEXT ('3'):
			{
				int		nFuncNo	= 0 ;

				if (! bParseBSEncodedString (&pwSrc, bufTmp, ARRAYSIZE (bufTmp) - 1, &bTerminated) || ! bTerminated)
					break ;
#if __STDC_WANT_SECURE_LIB__
				if (_snwscanf_s (bufTmp, ARRAYSIZE (bufTmp), L"%d", &nFuncNo) != 1)
					break ;
#else
				if (swscanf (bufTmp, L"%d", &nFuncNo) != 1)
					break ;
#endif
				bError	= FALSE ;
			}
			break ;
		default:
			break ;
		}
next_entry:
		while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
			pwSrc ++ ;
		if (bError) {
			WCHAR	bufEntry   [128] ;
			LPWSTR	pwDest		= bufEntry ;
			LPCWSTR	pwDestEnd	= bufEntry + ARRAYSIZE(bufEntry) - 1 ;
			LPCWSTR	ptr			= pwBase ;
			while (ptr < pwSrc && pwDest < pwDestEnd) {
				if (*ptr == L'\\' && (ptr+1) < pwSrc && *(ptr+1) == L'0') {
					*pwDest ++	= L',' ;
					ptr		++ ;
				} else {
					*pwDest ++	= *ptr ;
				}
				ptr	++ ;
			}
			*pwDest	= L'\0' ;
			if (bFirst) {
#if defined (JAPANESE_MESSAGE)
				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT("%s�̃G���g��:\"%s\""), strMessage, bufEntry) ;
#else
				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT("%s's entry:\"%s\""), strMessage, bufEntry) ;
#endif
				bFirst	= FALSE ;
			} else {
				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT(",\"%s\""), bufEntry) ;
				bMoreThanTwo	= TRUE ;
			}
			if (! vbuf.bAdd (bufMessage, n))
				break ;
		}
		pwSrc	++ ;	/* nul �� skip */
	}
#if defined (JAPANESE_MESSAGE)
	n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage), TEXT ("�͖����ł��B")) ;
#else
	n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage), TEXT (" %s not valid."), (bMoreThanTwo? TEXT("are") : TEXT("is"))) ;
#endif
	vbuf.bAdd (bufMessage, n) ;
	vbuf.bAdd (L'\0') ;
	MessageBox (hDlg, vbuf.pGetBuffer(), TEXT("Warning"), MB_OK) ;
	return ;
}

BOOL
dlgKeybind_bSaveAllRomaKanaRuleList (void)
{
	HKEY	hSubKey ;
	BOOL	bRetval ;
	DWORD	dwValue ;

	bRetval	= TRUE ;
	if (! bCreateRegistryKey (REGPATH_ROMAKANARULE, FALSE, &hSubKey)) {
		return	FALSE ;
	}
	if (_sbExistUserDefinedRomaKanaRule) {
		if (! dlgKeybind_bSaveRomaKanaRuleList (hSubKey, srRomaKanaRuleTbl,		NUM_ROMAKANARULE, _rplstRomaKanaRules) ||
			! dlgKeybind_bSaveRomaKanaRuleList (hSubKey, srJisx0201KanaRuleTbl,	NUM_ROMAKANARULE, _rplstJisx0201KanaRules) ||
			! dlgKeybind_bSaveRomaKanaRuleList (hSubKey, srJisx0201RomanRuleTbl,	NUM_ROMAKANARULE, _rplstJisx0201RomanRules)) {
			_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
			bRetval	= FALSE ;
		}
	}
	dwValue	= (DWORD) _siRomaKanaRuleListType ;
	if (RegSetValueEx (hSubKey, REGINFO_ROMAKANARULE_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) {
		bRetval	= FALSE ;
	}
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

BOOL
dlgKeybind_bSaveRomaKanaRuleList (
	HKEY						hSubKey,
	LPCTSTR*					ppszRomaKanaRuleTblName,
	int							nRules,
	struct TSkkBaseRuleNode**	pplstRules)
{
	int		i ;
	BOOL	bRetval ;

	bRetval	= FALSE ;
	for (i = 0 ; i < nRules ; i ++) {
		BOOL	bError ;

		if (pplstRules [i] != NULL) {
			LPTSTR						pwData ;
			LPTSTR						pwDest ;
			int							nTotalSize, nDataSize ;
			struct TSkkBaseRuleNode*	pNode ;

			nTotalSize	= 0 ;
			pNode		= pplstRules [i] ;
			while (pNode != NULL) {
				switch (pNode->_nType) {
				case	ROMAKANARULE_TYPE1:
					nTotalSize	++ ;	/* for type */
					nTotalSize	+= iCountBSEncodedString (pNode->_T1._strState) + 2 ;			/* for state */
					nTotalSize	+= iCountBSEncodedString (pNode->_T1._strNext)  + 2 ;			/* for nextstate */
					nTotalSize	+= iCountBSEncodedInteger (pNode->_T1._iNextRule) + 2 ;
					nTotalSize	+= iCountBSEncodedString (pNode->_T1._case._strHira) + 2 ;	/* for hiragana */
					nTotalSize	+= iCountBSEncodedString (pNode->_T1._case._strKata) + 2 ;	/* for katakana */
					nTotalSize	++ ;	/* nul */
					break ;
				case	ROMAKANARULE_TYPE2:
					nTotalSize	++ ;	/* for type */
					nTotalSize	+= iCountBSEncodedString (pNode->_T2._strState) + 2 ;			/* for state */
					nTotalSize	+= iCountBSEncodedString (pNode->_T2._strNext)  + 2 ;			/* for nextstate */
					nTotalSize	+= iCountBSEncodedInteger (pNode->_T2._iNextRule) + 2 ;
					nTotalSize	+= iCountBSEncodedString (pNode->_T2._strOutput) + 2 ;		/* for output */
					nTotalSize	++ ;	/* nul */
					break ;
				case	ROMAKANARULE_TYPE3:
					nTotalSize	++ ;	/* for type */
					nTotalSize	+= iCountBSEncodedString (pNode->_T3._strState) + 2 ;			/* for state */
					nTotalSize	+= iCountBSEncodedString (pNode->_T3._strNext)  + 2 ;			/* for nextstate */
					nTotalSize	+= iCountBSEncodedInteger (pNode->_T3._iNextRule) + 2 ;
					nTotalSize	+= iCountBSEncodedInteger (pNode->_T3._nFunction) + 2 ;
					nTotalSize	++ ;	/* nul */
				default:
					break ;
				}
				pNode	= pNode->_pNext ;
			}
			nTotalSize	++ ;	/* nul */

			pwData	= (LPTSTR) MALLOC (sizeof (TCHAR) * nTotalSize) ;
			if (pwData == NULL)
				goto	exit_func ;

			pNode		= pplstRules [i] ;
			pwDest		= pwData ;
			while (pNode != NULL) {
				int	iCount ;

				switch (pNode->_nType) {
				case	ROMAKANARULE_TYPE1:
					*pwDest ++	= TEXT ('1') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T1._strState); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T1._strNext); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeInteger (pwDest, pNode->_T1._iNextRule) ;
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T1._case._strHira); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T1._case._strKata); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					*pwDest ++	= TEXT ('\0') ;
					break ;
				case	ROMAKANARULE_TYPE2:
					*pwDest ++	= TEXT ('2') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T2._strState); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T2._strNext); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeInteger (pwDest, pNode->_T2._iNextRule) ;
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T2._strOutput); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					*pwDest ++	= TEXT ('\0') ;
					break ;
				case	ROMAKANARULE_TYPE3:
					*pwDest ++	= TEXT ('3') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T3._strState); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeString (pwDest, pNode->_T3._strNext); 
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeInteger (pwDest, pNode->_T3._iNextRule) ;
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					iCount	= iBSEncodeInteger (pwDest, pNode->_T3._nFunction) ;
					pwDest	+= iCount ;	*pwDest ++	= TEXT ('\\') ;	*pwDest ++	= TEXT ('0') ;
					*pwDest ++	= TEXT ('\0') ;
					break ;
				default:
					/* skip */
					break ;
				}
				pNode	= pNode->_pNext ;
			}
			*pwDest ++	= TEXT ('\0') ;
			nDataSize	= pwDest - pwData ;

			bError	= RegSetValueEx (hSubKey, ppszRomaKanaRuleTblName [i], 0, REG_MULTI_SZ, (BYTE*) pwData, sizeof (TCHAR) * nDataSize) != ERROR_SUCCESS ;
			FREE (pwData) ;
			pwData	= NULL ;
			if (bError)
				goto	exit_func ;
		} else {
			RegSetValueEx (hSubKey, ppszRomaKanaRuleTblName [i], 0, REG_MULTI_SZ, NULL, 0) ;
		}
	}
	bRetval	= TRUE ;
exit_func:
	return	bRetval ;
}

void
dlgKeybind_vInitializeDefaultStartHenkanKey (
	BYTE*			pbStartHenkanKeys,
	int*			piNumStartHenkanKeys)
{
	*pbStartHenkanKeys		= ' ' ;
	*piNumStartHenkanKeys	= 1 ;
	return ;
}

void
dlgKeybind_vInitializeDefaultCompletinoRelatedKey (
	BYTE*			pbTryCompletionKeys,
	int*			piNumTryCompletionKeys,
	BYTE*			pbPreviousCompletionKeys,
	int*			piNumPreviousCompletionKeys,
	BYTE*			pbNextCompletionKeys,
	int*			piNumNextCompletionKeys)
{
	*pbTryCompletionKeys			= '\t' ;
	*pbPreviousCompletionKeys		= ',' ;
	*pbNextCompletionKeys			= '.' ;
	*piNumTryCompletionKeys			= 1 ;
	*piNumPreviousCompletionKeys	= 1 ;
	*piNumNextCompletionKeys		= 1 ;
	return ;
}

void
dlgKeybind_vInitializeDefaultSetHenkanPointSubrKey (
	BYTE*			pbSetHenkanPointSubrKeys,
	int*			piNumSetHenkanPointSubrKeys)
{
	static const BYTE		rbDefault []	= {
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'M', 'N', 'O',
		'P', 'R', 'S', 'T', 'U', 'V', 'W', 'Y', 'Z',
	} ;
	memcpy (pbSetHenkanPointSubrKeys, rbDefault, sizeof (rbDefault)) ;
	*piNumSetHenkanPointSubrKeys	= ARRAYSIZE (rbDefault) ;
	return ;
}

void
dlgKeybind_vInitializeDefaultSpecialMidashiCharKey (
	BYTE*			pbSpecialMidashiCharKey,
	int*			piNumSpecialMidashiCharKey)
{
	static const BYTE		rbDefault []	= {
		'?', '>', '<', 
	} ;
	memcpy (pbSpecialMidashiCharKey, rbDefault, sizeof (rbDefault)) ;
	*piNumSpecialMidashiCharKey	= ARRAYSIZE (rbDefault) ;
	return ;
}

BOOL
dlgKeybind_bLoadZenkakuVector (void)
{
	HKEY	hSubKey ;
	BOOL	bInitialized	= FALSE ;

	dlgKeybind_vClearZenkakuVector () ;
	_sbExistUserDefinedZenkakuVector	= FALSE ;

	/*	���W�X�g���ɃL�[�����݂��Ȃ���΁A�f�t�H���g��ݒ肷��B
	 */
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG 	lResult ;
		DWORD	dwType, cbData, dwValue ;
		LPTSTR	pwData ;
		LPCTSTR	pwSrc ;

		cbData	= sizeof (DWORD) ;
		lResult	= RegQueryValueEx (hSubKey, REGINFO_ZENKAKUVECTOR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) ;
		if (lResult != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siZenkakuVectorType	= (int) dwValue ;

		lResult	= RegQueryValueEx (hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) 
			goto	skip_error ;
		if (dwType != REG_MULTI_SZ) 
			goto	skip_error ;

		pwData	= (LPTSTR) MALLOC (cbData) ;
		if (pwData == NULL)
			goto	skip_error ;

		(void) RegQueryValueEx (hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, (BYTE*)pwData, &cbData) ;

		pwSrc	= pwData ;
		while (*pwSrc != TEXT ('\0')) {
			LPCTSTR	pwBase ;
			int		nChara, nCH ;

			/*	�ŏ���3�������L�����N�^�[�R�[�h���A
			 *	���������񂪂��̃R�[�h�œ��͂���镶����A
			 */
			nCH		= *pwSrc ++ ;
			if (nCH < TEXT ('0') || nCH > TEXT ('9'))
				goto	skip_error ;
			nChara	= nCH - TEXT ('0') ;

			nCH		= *pwSrc ++ ;
			if (nCH < TEXT ('0') || nCH > TEXT ('9'))
				goto	skip_error ;
			nChara	= nChara * 10 + (nCH - TEXT ('0')) ;

			nCH		= *pwSrc ++ ;
			if (nCH < TEXT ('0') || nCH > TEXT ('9'))
				goto	skip_error ;
			nChara	= nChara * 10 + (nCH - TEXT ('0')) ;
			if (nChara < 0 || nChara >= SIZE_INPUTVECTOR)
				goto	skip_error ;

			pwBase	= pwSrc ;
			while (*pwSrc != TEXT ('\0'))
				pwSrc	++ ;

			if (_rpZenkakuVector [nChara] != NULL) {
				FREE (_rpZenkakuVector [nChara]) ;
			}
			_rpZenkakuVector [nChara]	= (LPTSTR) MALLOC (((pwSrc - pwBase) + 1) * sizeof (TCHAR)) ;
			if (_rpZenkakuVector [nChara] == NULL)
				break ;
			lstrcpy (_rpZenkakuVector [nChara], pwBase) ;
			pwSrc	++ ;
		}
		bInitialized	= TRUE ;
		_sbExistUserDefinedZenkakuVector	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}
	if (! bInitialized) {
		_sbExistUserDefinedZenkakuVector	= FALSE ;
		_siZenkakuVectorType					= KEYBINDTP_DEFAULT ;
	}
	return	TRUE ;
}

/*	���W�X�g���ւ̃A�N�Z�X�񐔂͏o���邾�����Ȃ������ǂ��̂ł͂Ȃ����Ƌ��l�B
 */
BOOL
dlgKeybind_bSaveZenkakuVector (void)
{
	HKEY	hSubKey ;
	int		i, nTotalLength ;
	BOOL	bRetval	= FALSE ;
	LPTSTR	pwData	= NULL ;
	LPTSTR	pwDest	= NULL ;
	LPCTSTR	pwSrc ;
	DWORD	dwValue ;

	if (_sbExistUserDefinedZenkakuVector) {
		nTotalLength	= 0 ;
		for (i = 0 ; i < ARRAYSIZE (_rpZenkakuVector) ; i ++) {
			if (_rpZenkakuVector [i] != NULL) {
				nTotalLength	+= lstrlen (_rpZenkakuVector [i]) + 1 /* NUL */ + 3 /* chara */ ;
			}
		}

		pwData	= (LPTSTR) MALLOC (sizeof (TCHAR) * (nTotalLength + 1)) ;
		if (pwData == NULL)
			return	FALSE ;

		pwDest	= pwData ;
		for (i = 0 ; i < ARRAYSIZE (_rpZenkakuVector) ; i ++) {
			if (_rpZenkakuVector [i] != NULL) {
				pwSrc	= _rpZenkakuVector [i] ;
				*pwDest ++	= TEXT ('0') + (i / 100) % 10 ;
				*pwDest ++	= TEXT ('0') + (i /  10) % 10 ;
				*pwDest ++	= TEXT ('0') + (i /   1) % 10 ;
				while (*pwSrc != TEXT ('\0')) {
					*pwDest ++	= *pwSrc ++ ;
				}
				*pwDest ++	= TEXT ('\0') ;
			}
		}
		*pwDest	++ = TEXT ('\0') ;
	}
	if (! bCreateRegistryKey (REGPATH_ZENKAKUVECTOR, FALSE, &hSubKey)) {
		FREE (pwData) ;
		return	FALSE ;
	}
	dwValue	= (DWORD) _siZenkakuVectorType ;
	if (RegSetValueEx (hSubKey, REGINFO_ZENKAKUVECTOR_TYPE, 0, REG_DWORD, (BYTE*)&dwValue, sizeof (DWORD)) != ERROR_SUCCESS) {
		bRetval	= FALSE ;
		goto	exit_func ;
	}
	if (_sbExistUserDefinedZenkakuVector && pwDest != NULL) {
		bRetval	= RegSetValueEx (hSubKey, REGINFO_ZENKAKUVECTOR, 0, REG_MULTI_SZ, (BYTE*) pwData, (DWORD)sizeof (TCHAR) * (pwDest - pwData)) == ERROR_SUCCESS ;
	}
exit_func:
	RegCloseKey (hSubKey) ;
	FREE (pwData) ;
	return	bRetval ;
}

