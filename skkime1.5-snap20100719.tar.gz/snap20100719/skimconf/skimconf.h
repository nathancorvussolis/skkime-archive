#pragma once

#include "resource.h"

/*================================================================
 *	Definitions
 */
#define	REGPATH_SKKIME	TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5")
#define	REGPATH_GENERIC	REGPATH_SKKIME TEXT("\\Generic")
#define	REGINFO_TICK	TEXT("Tick")

/*================================================================
 *	structures
 */
struct TMENUITEM {
	unsigned int		m_fMask ;
	int					m_fType ;
	UINT				m_fState ;
	LPCTSTR				m_strText ;
	int					m_wID ;
} ;

struct TPropPageSheetConfig {
	LPCTSTR			m_ptszTitle ;
	INT_PTR			(CALLBACK *m_pDialogProc)(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;
	int				m_nResId ;
} ;

/*================================================================
 *	Prototypes
 */
BOOL	bNewPageSheet			(LPPROPSHEETHEADER, HINSTANCE, struct TPropPageSheetConfig*, void*) ;
int		iShortStringCopy		(LPWSTR, int, LPCWSTR, int) ;
int		iString2PrintableString	(LPTSTR, int, LPCWSTR, int) ;
void	vKey2String				(LPTSTR, int, UINT) ;
void	vKey2StringEx			(LPTSTR, int, UINT, UINT) ;
int		iKeyList2String			(LPTSTR, int, LPCWSTR) ;
BOOL	bGetKeyFuncName			(LPTSTR, int, int) ;

BOOL	EnableDlgItem						(HWND, int, BOOL) ;
BOOL	SetDropDownListCurrentSelectionByData	(HWND, int, int) ;
BOOL	IsRadioButtonChecked				(HWND, int, int, int) ;
BOOL	bCreateRegistryKey					(LPCTSTR, BOOL, HKEY*) ;
int		iPopupMenu							(HWND, const struct TMENUITEM*, int) ;
BOOL	bParseBSEncodedString				(LPCTSTR*, LPTSTR, int, BOOL*) ;
int		iCountBSEncodedString				(LPCTSTR) ;
int		iBSEncodeString						(LPTSTR, LPCTSTR) ;
int		iCountBSEncodedInteger				(int) ;
int		iBSEncodeInteger					(LPTSTR, int) ;
void	vUpdateTick							(void) ;


