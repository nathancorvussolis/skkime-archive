#include <windows.h>
#include <tchar.h>
#include <process.h>
#include <lmcons.h>
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>

int
main (void)
{
	TCHAR				rszCmdLine [MAX_PATH] ;
	TCHAR				rszUserName [UNLEN + 1] ;
	LPTSTR				ptr ;
	STARTUPINFO			si ;
	PROCESS_INFORMATION	pi ;
	LPCTSTR				pTmpName ;
	ULONG				ulUserNameLen ;

	_tsetlocale (LC_ALL, TEXT ("japanese")) ;

	ulUserNameLen	= sizeof (rszUserName) / sizeof (rszUserName [0]) - 1 ;
	if (! GetUserName (rszUserName, &ulUserNameLen)) {
		_ftprintf (stderr, TEXT("GetUserName failed.\n")) ;
		return	EXIT_FAILURE ;
	}
	rszUserName [UNLEN]	= TEXT ('\0') ;

	pTmpName		= _ttmpnam (NULL) ;
	_sntprintf (rszCmdLine, MAX_PATH, TEXT("%s%s"), pTmpName, rszUserName) ;
	_ftprintf (stderr, TEXT ("pipename = \"%s\"\n"), rszCmdLine) ;
	ptr	= rszCmdLine ;
	while (*ptr != TEXT ('\0')) {
		if (*ptr == TEXT ('\\')) 
			*ptr	= TEXT('-') ;
		ptr	++ ;
	}
	memset (&si, 0, sizeof (si)) ;
	memset (&pi, 0, sizeof (pi)) ;
	si.cb	= sizeof (si) ;
	if (!CreateProcess (TEXT ("skkiserv.exe"), rszCmdLine, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
		_ftprintf (stderr, TEXT ("CreateProcess failed.\n")) ;
		return	EXIT_FAILURE ;
	}
	_ftprintf (stderr, TEXT ("Running process(%lx)\n"), pi.dwProcessId) ;
	CloseHandle (pi.hThread) ;
	CloseHandle (pi.hProcess) ;
	return	EXIT_SUCCESS ;
}

