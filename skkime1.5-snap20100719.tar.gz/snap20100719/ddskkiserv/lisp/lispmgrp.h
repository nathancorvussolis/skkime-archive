/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#pragma once

#include "lispmgr.h"
#include "Char.h"
#include "lentity.h"
#include "lbind.h"
#include "kfile.h"

struct tagTLispBind ;
struct tagTLispEntity ;
struct tagTLispManager ;

/*	Constants */
enum {
	/* �f���ł��邱�ƁB*/
	LISPMGR_SIZE_SYMBOL_HASH	= 127,
	LISPMGR_SIZE_INTEGER_HASH	= 13,
	LISPMGR_SIZE_SUBR_HASH		= 23,
	MAX_NEST_COUNT				= 128,
} ;

enum {
	LISPMGR_INDEX_NIL	= 0,
	LISPMGR_INDEX_T,
	LISPMGR_INDEX_MINUS,
	LISPMGR_INDEX_LAMBDA,
	LISPMGR_INDEX_MACRO,
	LISPMGR_INDEX_OPTIONAL,
	LISPMGR_INDEX_REST,
	LISPMGR_INDEX_KEYMAP,
	LISPMGR_INDEX_ERROR,
	LISPMGR_INDEX_EXIT,
	LISPMGR_INDEX_QUIT,
	LISPMGR_INDEX_QUIT_FLAG,
	LISPMGR_INDEX_INHIBIT_QUIT,
	LISPMGR_INDEX_FEATURES,
	LISPMGR_INDEX_INTERACTIVE,
	LISPMGR_INDEX_THIS_COMMAND,
	LISPMGR_INDEX_LAST_COMMAND,
	LISPMGR_INDEX_UNREAD_COMMAND_EVENTS,
	LISPMGR_INDEX_PRE_COMMAND_HOOK,
	LISPMGR_INDEX_POST_COMMAND_HOOK,
	LISPMGR_INDEX_LAST_COMMAND_EVENT,
	LISPMGR_INDEX_UNREAD_COMMAND_CHAR,
	LISPMGR_INDEX_GLOBAL_MAP,
	LISPMGR_INDEX_MINIBUFFER_LOCAL_MAP,
	LISPMGR_INDEX_MINOR_MODE_MAP_ALIST,
	LISPMGR_INDEX_WRONG_TYPE_ARGUMENT,
	LISPMGR_INDEX_BUFFER_FILE_NAME,
	LISPMGR_INDEX_MODE_LINE_FORMAT,
	LISPMGR_INDEX_LOAD_PATH,
	LISPMGR_INDEX_KILL_RING,
	LISPMGR_INDEX_KILL_REGION,
	LISPMGR_INDEX_KILL_RING_YANK_POINTER,
	LISPMGR_INDEX_YANK,

	LISPMGR_INDEX_SKK_SERVER_HOST,
	LISPMGR_INDEX_SKK_SERVER_LIST,
	LISPMGR_INDEX_SKK_PORTNUM,
	LISPMGR_INDEX_SKK_PROCESS_OKURI_EARLY,
	LISPMGR_INDEX_J_HENKAN_KEY,
	LISPMGR_INDEX_J_SEARCH_KEY,
	LISPMGR_INDEX_J_OKURI_ARI,
	LISPMGR_INDEX_J_HENKAN_OKURIGANA,
	LISPMGR_INDEX_J_HENKAN_OKURI_STRICTLY,

	LISPMGR_SIZE_RESERVED,
} ;

/*	Structures */
/*	�����o�̈Ӗ��͎��̒ʂ�B
 *		m_iMarker
 *			GC �Ɏg���}�[�N
 *		m_apSymbolListTop
 *			Intern ����Ă���V���{�����Ǘ����Ă���B
 *		m_apIntegerListTop
 *			�������l�� Integer �� eq �ł���悤�� Integer Entity ���Ǘ�
 *			���Ă���B
 *		m_apSubrListTop
 *			�T�u���[�`���^�̊Ǘ��B
 *		m_pOtherEntityListTop
 *			���ꐫ���ۏ؂���Ȃ��Ă����܂�Ȃ� Entity �͂��̃��X�g�ɂ�
 *			�Ȃ���Ă���B
 *		m_apEntReserved
 *			�p�ɂɎQ�Ƃ���� Symbol �����炩���� Cache ���Ă���Bt ��
 *			nil �ȂǁBIntern ����Ă���B
 *		m_pVoid
 *			�������蓖�Ă��Ă��Ȃ���� (void) �̎��Ɋ��蓖�Ă���ʂ�
 *			�l�B
 *		m_vbufLocalSymbol
 *			�o�b�t�@���V�K�ɍ��ꂽ���Ɏ����I�ɗp�ӂ���郍�[�J���ϐ�
 *			�����݂���ꍇ�A���̕ϐ��c���� SYMBOL �������ɓ���B�����l
 *			�� void �ł���B(�ŏ��� default-value �����̂܂܎Q�Ƃ����
 *			��Ԃł��邪�A���삳���ƒl������)
 *			make-variable-buffer-local �����ƒǉ������B
 */
struct tagTLispManager {
	int						m_iMarker ;
	struct tagTLispEntity*	m_apSymbolListTop  [LISPMGR_SIZE_SYMBOL_HASH] ;
	struct tagTLispEntity*	m_apIntegerListTop [LISPMGR_SIZE_INTEGER_HASH] ;
	struct tagTLispEntity*	m_apSubrListTop    [LISPMGR_SIZE_SUBR_HASH] ;
	struct tagTLispEntity*	m_pEntListNamedMutex ;
	struct tagTLispEntity*	m_pEntListNoNameMutex ;
	struct tagTLispEntity*	m_pEntMiscListTop ;
	struct tagTLispEntity*	m_apEntReserved    [LISPMGR_SIZE_RESERVED] ;
	struct tagTLispEntity*	m_pEntVoid ;
	struct tagTLispEntity*	m_pEntEmpty ;
	TVarbuffer				m_vbufLocalSymbol ;
}	;

struct tagTLispNumber {
	BOOL	m_fFloatp ;
	union {
		float	m_fFloat ;
		long	m_lLong ;
	}		m_Value ;
} ;

typedef struct tagTLispNumber	TLispNumber ;

/*	lispmgr.kc */
#if defined (__cplusplus)
extern "C" {
#endif

BOOL	lispMgr_SetSymbolFunctionValue	(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispMgr_GetSymbolFunctionValue	(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_SetSymbolFunctionValueWithName	(TLispManager*, const Char*, int, TLispEntity*) ;
BOOL	lispMgr_GetSymbolFunctionValueWithName	(TLispManager*, const Char*, int, TLispEntity** const) ;
BOOL	lispMgr_SetSymbolValue			(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispMgr_SetSymbolValueWithName	(TLispManager*, const Char*, int, TLispEntity*) ;
BOOL	lispMgr_GetSymbolValue			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_GetSymbolValueWithName	(TLispManager*, const Char*, int, TLispEntity** const) ;
void	lispMgr_Deallocate				(TLispManager*, void*) ;
BOOL	lispMgr_AllocateEntity			(TLispManager*, size_t, TLispEntity** const) ;
BOOL	lispMgr_CollectGarbage			(TLispManager*) ;
BOOL	lispMgr_RegisterMisc			(TLispManager*, TLispEntity*) ;
BOOL	lispMgr_UnregisterMisc			(TLispManager*, TLispEntity*) ;
void	lispMgr_DestroyEntity			(TLispManager*, TLispEntity*) ;

/*	lispsymbol.c */
BOOL	lispMgr_CreateSymbol			(TLispManager*, const Char*, int, TLispEntity** const) ;
BOOL	lispMgr_CreateSymbolA			(TLispManager*, LPCTSTR, int, TLispEntity** const) ;
BOOL	lispMgr_InternSymbol			(TLispManager*, const Char*, int, TLispEntity** const) ;
BOOL	lispMgr_InternSymbolA			(TLispManager*, LPCTSTR, int, TLispEntity** const) ;
BOOL	lispMgr_CollectSymbolGarbage	(TLispManager*) ;
BOOL	lispMgr_SearchSymbol			(TLispManager*, const Char*, int, TLispEntity** const) ;
BOOL	lispMgr_SearchSymbolA			(TLispManager*, LPCTSTR, int, TLispEntity** const) ;
BOOL	lispMgr_UnregisterSymbol		(TLispManager*, TLispEntity*) ;

/*	lentity.c */
BOOL	lispEntity_Memq					(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity**) ;
BOOL	lispEntity_Member				(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity**) ;
BOOL	lispEntity_Rassoc				(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity**) ;
BOOL	lispEntity_Nconc 				(TLispManager*, TLispEntity*, TLispEntity**) ;
BOOL	lispEntity_Equal				(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispEntity_GetNumberValueOrMarkerPosition	(TLispManager*, TLispEntity*, TLispNumber*) ;
BOOL	lispEntity_GetLength			(TLispManager*, TLispEntity*, int*) ;
BOOL	lispEntity_Format				(TLispManager*, const Char*, int, TLispEntity*, TLispEntity**) ;
BOOL	lispEntity_FormatA				(TLispManager*, LPCTSTR, int, TLispEntity*, TLispEntity**) ;
BOOL	lispEntity_PrincStr				(TLispManager*, TLispEntity*, TVarbuffer*) ;
BOOL	lispEntity_Print				(TLispManager*, TLispEntity*) ;
BOOL	lispEntity_Copy					(TLispManager*, TLispEntity*, TLispEntity**) ;

/*	lispstring.c	*/
BOOL	lispMgr_CreateString			(TLispManager*, const Char*, int, TLispEntity** const) ;
BOOL	lispMgr_StringToCharList		(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_Concat					(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_Substring				(TLispManager*, TLispEntity*, long, long, TLispEntity** const) ;
BOOL	lispEntity_Upcase				(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispEntity_Downcase				(TLispManager*, TLispEntity*, TLispEntity** const) ;

/*	lisplist.c	*/
BOOL	lispMgr_CreateConscell			(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_CreateList				(TLispManager*, TLispEntity**, int, TLispEntity** const) ;
BOOL	lispEntity_PlistGet				(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity** const) ;
BOOL	lispEntity_PlistPut				(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity*, TLispEntity** const) ;
BOOL	lispEntity_CopyList				(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispEntity_Push2List			(TLispManager*, TLispConscell*, TLispEntity*) ;

/*	lnum.c	*/
BOOL	lispMgr_CreateInteger			(TLispManager*, long, TLispEntity** const) ;
BOOL	lispMgr_CreateFloat				(TLispManager*, float, TLispEntity** const) ;
BOOL	lispMgr_CollectIntegerGarbage	(TLispManager*) ;
BOOL	lispMgr_MathGreaterThan			(TLispManager*, TLispEntity*, TLispEntity*, BOOL*) ;
BOOL	lispMgr_MathGreaterEqual		(TLispManager*, TLispEntity*, TLispEntity*, BOOL*) ;
BOOL	lispMgr_MathLessThan			(TLispManager*, TLispEntity*, TLispEntity*, BOOL*) ;
BOOL	lispMgr_MathLessEqual			(TLispManager*, TLispEntity*, TLispEntity*, BOOL*) ;
BOOL	lispMgr_MathEqual				(TLispManager*, TLispEntity*, TLispEntity*, BOOL*) ;

/*	lvector.c	*/
BOOL	lispMgr_CreateVector			(TLispManager*, TLispEntity** const, int, TLispEntity** const) ;
BOOL	lispMgr_CreateVectorFill		(TLispManager*, TLispEntity*, int, TLispEntity** const) ;
void	lispMgr_DestroyVector			(TLispManager*, TLispEntity*) ;
BOOL	lispMgr_Vconcat					(TLispManager*, TLispEntity*, TLispEntity** const) ;

/*	lsubr.c */
BOOL	lispMgr_CreateSubr				(TLispManager*, struct tagLMCMDINFO const*, TLispEntity** const) ;
BOOL	lispSubr_GetName				(TLispManager*, TLispEntity*, const Char**) ;

/*	parser.kc */
TLispEntity*	lispMgr_ParseString		(TLispManager*, const Char*, int, int*) ;
TLispEntity*	lispMgr_ParseStringA	(TLispManager*, const char*, int, int*) ;
TLispEntity*	lispMgr_ParseFile		(TLispManager*, LPCTSTR) ;

/*	lsub.kc */
BOOL	lispMgr_Append					(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_Nreverse				(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_Delete					(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_Delq					(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity** const) ;

/*	lispmarker.c	*/
BOOL	lispMgr_CreateMarker			(TLispManager*, TLispEntity** const) ;
void	lispMgr_DestroyMarker			(TLispManager*, TLispEntity*) ;
BOOL	lispMarker_SetBufferPosition	(TLispManager*, TLispEntity*, TLispEntity*, int) ;
BOOL	lispMarker_SetInsertionType 	(TLispManager*, TLispEntity*, BOOL) ;
BOOL	lispMarker_SetNext				(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispMarker_SetPrevious			(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispMarker_GetInsertionType		(TLispManager*, TLispEntity*, BOOL*) ;
BOOL	lispMarker_GetBufferPosition	(TLispManager*, TLispEntity*, TLispEntity** const, int* const) ;
BOOL	lispMarker_GetNext				(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMarker_GetPrevious			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMarker_MoveWithInsertion	(TLispManager*, TLispEntity*, int, int) ;
BOOL	lispMarker_MoveWithDeletion		(TLispManager*, TLispEntity*, int, int) ;
BOOL	lispMarker_Print				(TLispManager*, TLispEntity*) ;

/*	lispbuffer.c	*/
BOOL	lispMgr_CreateBuffer			(TLispManager*, TLispEntity** const) ;
void	lispMgr_DestroyBuffer			(TLispManager*, TLispEntity*) ;
BOOL	lispBuffer_SetNext				(TLispEntity*, TLispEntity*) ;
BOOL	lispBuffer_SetPrevious			(TLispEntity*, TLispEntity*) ;
BOOL	lispBuffer_GetNext				(TLispEntity*, TLispEntity** const) ;
BOOL	lispBuffer_GetPrevious			(TLispEntity*, TLispEntity** const) ;
BOOL	lispBuffer_MakeSymbolValue		(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispBuffer_SetSymbolValue		(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity*) ;
BOOL	lispBuffer_SetSymbolValueWithName (TLispManager*, TLispEntity*, const Char*, const int, TLispEntity*) ;
BOOL	lispBuffer_GetSymbolValue		(TLispManager*, TLispEntity*, TLispEntity*, TLispEntity** const) ;
BOOL	lispBuffer_GetSymbolValueWithName (TLispManager*, TLispEntity*, const Char*, const int, TLispEntity** const) ;
BOOL	lispBuffer_AddMarker			(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispBuffer_RemoveMarker			(TLispManager*, TLispEntity*) ;
BOOL	lispBuffer_SetName				(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispBuffer_GetName				(TLispManager*, TLispEntity*, TLispEntity**) ;
BOOL	lispBuffer_SetKeymap			(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL	lispBuffer_GetKeymap			(TLispEntity*, TLispEntity**) ;
BOOL	lispBuffer_SetPrompt			(TLispManager*, TLispEntity*, const Char*, int) ;
BOOL	lispBuffer_Point				(TLispManager*, TLispEntity*, int*) ;
BOOL	lispBuffer_PointBufferEnd		(TLispManager*, TLispEntity*, int*) ;
BOOL	lispBuffer_PointMax				(TLispManager*, TLispEntity*, int*) ;
BOOL	lispBuffer_PointBufferTop		(TLispManager*, TLispEntity*, int*) ;
BOOL	lispBuffer_PointMin				(TLispManager*, TLispEntity*, int*) ;
BOOL	lispBuffer_PointMarker			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispBuffer_MarkMarker			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispBuffer_GetString			(TLispManager*, TLispEntity*, TBufStringMarker*, int* const) ;
BOOL	lispBuffer_GetFullString		(TLispManager*, TLispEntity*, TBufStringMarker*, int* const) ;
BOOL	lispBuffer_Narrow				(TLispManager*, TLispEntity*, int, int) ;
BOOL	lispBuffer_Widen				(TLispManager*, TLispEntity*) ;
BOOL	lispBuffer_InsertChar			(TLispManager*, TLispEntity*, int, const Char, int) ;
BOOL	lispBuffer_DeleteChar			(TLispManager*, TLispEntity*, int, int nCount) ;
BOOL	lispBuffer_InsertFileContents	(TLispManager*, TLispEntity*, int, KFILE*, int*) ;
BOOL	lispBuffer_InsertString			(TLispManager*, TLispEntity*, int, const Char*, int) ;
BOOL	lispBuffer_MoveMarkerWithInsertion (TLispManager*, TLispEntity*, int, int) ;
BOOL	lispBuffer_MoveMarkerWithDeletion (TLispManager*, TLispEntity*, int, int) ;
BOOL	lispBuffer_Print				(TLispManager*, TLispEntity*) ;
BOOL	lispBuffer_GetModifiedp			(TLispManager*, TLispEntity*) ;
void	lispBuffer_SetModifiedp			(TLispManager*, TLispEntity*, BOOL) ;

/*	lispfile.c	*/
BOOL	lispMgr_Load					(TLispManager*, const Char*, int, TLispEntity** const) ;

/*	lispkeymap.kc	*/
BOOL	lispMgr_CreateKeymap			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_CreateSparseKeymap		(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispMgr_CopyKeymap				(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL	lispEntity_Keymapp				(TLispManager*, TLispEntity*) ;
BOOL	lispKeymap_Lookup				(TLispManager*, TLispEntity*, TLispEntity*, BOOL, BOOL, int*, TLispEntity** const) ;
BOOL	lispKeymap_LookupWithString		(TLispManager*, TLispEntity*, const Char*, int, BOOL, BOOL, int*, TLispEntity** const) ;
BOOL	lispKeymap_LookupWithVector		(TLispManager*, TLispEntity*, TLispEntity**, int, BOOL, BOOL, int*, TLispEntity** const) ;
BOOL	lispKeymap_LookupWithList		(TLispManager*, TLispEntity*, TLispEntity*, BOOL, BOOL, int*, TLispEntity** const) ;
BOOL	lispKeymap_DefineKeyWithVector	(TLispManager*, TLispEntity*, TLispEntity**, int, TLispEntity*) ;
BOOL	lispKeymap_DefineKey			(TLispManager*, TLispEntity*, const Char*, int, TLispEntity*) ;

BOOL			lispEntity_GetType			(TLispManager*, TLispEntity*, int*) ;
BOOL			lispEntity_AddRef			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Release			(TLispManager*, TLispEntity*) ;
TLispEntity*	lispMgr_GetReservedEntity	(TLispManager*, int) ;
BOOL			lispMgr_CreateNil			(TLispManager*, TLispEntity** const) ;
BOOL			lispMgr_CreateT				(TLispManager*, TLispEntity** const) ;
BOOL			lispMgr_CreateVoid			(TLispManager*, TLispEntity** const) ;
BOOL			lispMgr_CreateEmpty			(TLispManager*, TLispEntity** const) ;
BOOL			lispEntity_Nullp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Symbolp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Integerp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Floatp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Markerp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Numberp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_IntegerOrMarkerp	(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Consp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Listp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Stringp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Vectorp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Arrayp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Bufferp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Sequencep		(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Eq				(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL			lispEntity_GetCar			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL			lispEntity_GetCdr			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL			lispEntity_GetCadr			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL			lispEntity_GetCaar			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL			lispEntity_GetCaddr			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL			lispEntity_GetCddr			(TLispManager*, TLispEntity*, TLispEntity** const) ;
BOOL			lispEntity_SetCar			(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL			lispEntity_SetCdr			(TLispManager*, TLispEntity*, TLispEntity*) ;
BOOL			lispEntity_CountArgument	(TLispManager*, TLispEntity*, int*) ;
BOOL			lispEntity_GetSymbolName	(TLispManager*, TLispEntity*, const Char** const, int*) ;
BOOL			lispEntity_Tp				(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Voidp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Emptyp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_GetLastElement	(TLispManager*, TLispEntity*, TLispEntity**) ;
BOOL			lispEntity_GetIntegerValue	(TLispManager*, TLispEntity*, long*) ;
BOOL			lispEntity_GetFloatValue	(TLispManager*, TLispEntity*, float*) ;
BOOL			lispEntity_GetNumberValue	(TLispManager*, TLispEntity*, TLispNumber*) ;
BOOL			lispEntity_GetNumberOrMarkerValue	(TLispManager*, TLispEntity*, TLispNumber*) ;
BOOL			lispEntity_MatchSymbolNamep	(TLispManager*, TLispEntity*, const Char*, int) ;
BOOL			lispEntity_Lambdap			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Macrop			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Optionalp		(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_Restp			(TLispManager*, TLispEntity*) ;
BOOL			lispEntity_GetVectorValue	(TLispManager*, TLispEntity*, TLispEntity*** const, int*) ;
BOOL			lispEntity_GetVectorElement	(TLispManager*, TLispEntity*, int, TLispEntity** const) ;
BOOL			lispEntity_SetVectorElement	(TLispManager*, TLispEntity*, int, TLispEntity*) ;
BOOL			lispEntity_ShrinkVector		(TLispManager*, TLispEntity*, int) ;
BOOL			lispEntity_GetStringValue	(TLispManager*, TLispEntity*, const Char** const, int*) ;
BOOL			lispEntity_GetStringElement	(TLispManager*, TLispEntity*, int, Char* const) ;
BOOL			lispEntity_SetStringElement	(TLispManager*, TLispEntity*, int, const Char) ;
BOOL			lispEntity_Subrp			(TLispManager*, TLispEntity*) ;
BOOL			lispSubr_GetProc			(TLispManager*, TLispEntity*, struct tagLMCMDINFO const**) ;

BOOL	lispMgr_GetLocalSymbols			(TLispManager*, TLispEntity***, int*) ;
BOOL	lispMgr_AddSymbolToLocalSymbols (TLispManager*, TLispEntity*) ;
void	lispMgr_DestroyEntity			(TLispManager*, TLispEntity*) ;
BOOL	lispMgr_RegisterMisc			(TLispManager*, TLispEntity*) ;
void	lispMgr_Deallocate				(TLispManager*, void*) ;
BOOL	lispMgr_AllocateEntity			(TLispManager*, size_t, TLispEntity** const) ;

#if defined (__cplusplus)
}
#endif

