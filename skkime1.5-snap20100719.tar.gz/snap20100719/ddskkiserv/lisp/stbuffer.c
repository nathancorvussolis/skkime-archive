/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "local.h"
#include <stdio.h>
#include "lmachinep.h"

static	TLMRESULT	lispMachineState_saveCurrentBufferFinalize (TLispMachine*) ;

static	TLMRESULT	lispMachineState_point	(TLispMachine*, BOOL (*)(TLispManager*, TLispEntity*, int*)) ;
static	TLMRESULT	lispMachineState_pointMarker (TLispMachine*, BOOL (*)(TLispManager*, TLispEntity*, int*)) ;

/*
 *	(current-buffer)
 */
TLMRESULT
lispMachineState_CurrentBuffer (
	register TLispMachine*	pLM)
{
	TLispEntity*	pEntCurBuffer ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntCurBuffer) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntCurBuffer) ;
	return	LMR_RETURN ;
}

/*
 *	buffer-string is a built-in function.
 *
 *	current buffer �̓��e�𕶎���Ƃ��ĕԂ��B���� narrowing ����Ă�����A
 *	�o�b�t�@�̌����镔���������Ԃ����B
 *
 *	(buffer-string)
 */
TLMRESULT
lispMachineState_BufferString (
	register TLispMachine*	pLM)
{
	TLispManager*		pLispMgr ;
	TLispEntity*		pEntBuffer ;
	int					nBufferString ;
	int					nPointMin, nPointMax, nPointBTop ;
	TLispEntity*		pRetval ;
	TVarbuffer			vbufSTRING ;
	TBufStringMarker	mkBuffer ;
	register Char*		pTop ;
	register Char*		pString ;
	register int		nString ;
	register BOOL	fRetval ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispBuffer_GetString (pLispMgr, pEntBuffer, &mkBuffer, &nBufferString))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nPointBTop) ;
	lispBuffer_PointMin (pLispMgr, pEntBuffer, &nPointMin) ;
	lispBuffer_PointMax (pLispMgr, pEntBuffer, &nPointMax) ;
	ASSERT (0 <= (nPointMin - nPointBTop) && (nPointMin - nPointBTop) <= nBufferString) ;
	ASSERT (0 <= (nPointMax - nPointBTop) && (nPointMax - nPointBTop) <= nBufferString) ;
	ASSERT (nPointMin <= nPointMax) ;

	if (TFAILED (TVarbuffer_Initialize (&vbufSTRING, sizeof (Char))) ||
		TFAILED (TVarbuffer_Require (&vbufSTRING, nPointMax - nPointMin)))
		return	LMR_ERROR ;
	TBufStringMarker_Forward (&mkBuffer, nPointMin - nPointBTop) ;
	pTop	= TVarbuffer_GetBuffer (&vbufSTRING) ;
	pString	= pTop ;
	nString	= nPointMax - nPointMin ;
	while (nString -- > 0) {
		*pString ++	= TBufStringMarker_GetChar (&mkBuffer) ;
		TBufStringMarker_Forward (&mkBuffer, 1) ;
	}

	fRetval	= lispMgr_CreateString (pLispMgr, pTop, nPointMax - nPointMin, &pRetval) ;
	TVarbuffer_Uninitialize (&vbufSTRING) ;

	if (TFAILED (fRetval))
		return	LMR_ERROR ;

	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pRetval) ;
	return	LMR_RETURN ;
}

/*
 *	buffer-substring is a built-in function.
 *
 *	�J�����g�o�b�t�@�̓��e�̈ꕔ�𕶎���Ƃ��ĕԂ��B2�̈��� START, END ��
 *	�L�����N�^�̈ʒu�ł���B���Ԃ͂ǂ��炪��ł������B�����o�b�t�@���}���`�o
 *	�C�g�Ȃ�A�Ԃ���镶������}���`�o�C�g�ł���B
 *
 *	(buffer-substring START END)
 *
 *	START, END �� integer �܂��� marker�B
 */
TLMRESULT
lispMachineState_BufferSubstring (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*		pEntBuffer ;
	int					nBufString ;
	TLispEntity*		pArglist ;
	TLispEntity*		pStart ;
	TLispEntity*		pEnd ;
	TLispNumber			lnStart, lnEnd ;
	int					nStart, nEnd ;
	TLispEntity*		pRetval ;
	int					nPointMin, nPointMax, nPointBTop ;
	TBufStringMarker	mkBuffer ;
	TVarbuffer			vbufSTRING ;
	register Char*		pTop ;
	register Char*		pString ;
	register int		nString ;
	register BOOL	fRetval ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;

	if (TFAILED (lispEntity_GetCar  (pLispMgr, pArglist, &pStart)) ||
		TFAILED (lispEntity_GetCadr (pLispMgr, pArglist, &pEnd)) ||
		TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispEntity_GetNumberValueOrMarkerPosition (pLispMgr, pStart, &lnStart)) ||
		TFAILED (lispEntity_GetNumberValueOrMarkerPosition (pLispMgr, pEnd,   &lnEnd)) ||
		lnStart.m_fFloatp || lnEnd.m_fFloatp ) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	/*	narrowing �̉e�����󂯂�B*/
	lispBuffer_PointMin (pLispMgr, pEntBuffer, &nPointMin) ;
	lispBuffer_PointMax (pLispMgr, pEntBuffer, &nPointMax) ;
	lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nPointBTop) ;
	ASSERT (nPointMin > 0 && nPointMax > 0) ;

	nStart	= lnStart.m_Value.m_lLong ;
	nEnd	= lnEnd.m_Value.m_lLong ;
	if (nStart > nEnd) {
		int	nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	/*	Out of range �̃`�F�b�N�B*/
	if (nStart < nPointMin || nPointMax < nEnd) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	/*	�o�b�t�@�̐擪�ʒu�� 1 ����BGetString �� buffer-top ���� buffer-end �܂ł�
	 *	�����o���B*/
	lispBuffer_GetString (pLispMgr, pEntBuffer, &mkBuffer, &nBufString) ;
	if (TFAILED (TVarbuffer_Initialize (&vbufSTRING, sizeof (Char))) ||
		TFAILED (TVarbuffer_Require (&vbufSTRING, nEnd - nStart)))
		return	LMR_ERROR ;
	TBufStringMarker_Forward (&mkBuffer, nStart - nPointBTop) ;
	pTop	= TVarbuffer_GetBuffer (&vbufSTRING) ;
	pString	= pTop ;
	nString	= nEnd - nStart ;
	while (nString -- > 0) {
		*pString ++	= TBufStringMarker_GetChar (&mkBuffer) ;
		TBufStringMarker_Forward (&mkBuffer, 1) ;
	}

	fRetval	= lispMgr_CreateString (pLispMgr, pTop, nEnd - nStart, &pRetval) ;
	TVarbuffer_Uninitialize (&vbufSTRING) ;

	if (TFAILED (fRetval))
		return	LMR_ERROR ;

	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pRetval) ;
	return	LMR_RETURN ;
}

/*
 *	(point)
 */
TLMRESULT
lispMachineState_Point (
	register TLispMachine*	pLM)
{
	return	lispMachineState_point (pLM, &lispBuffer_Point) ;
}

/*
 *	(point-min)
 */
TLMRESULT
lispMachineState_PointMin (
	register TLispMachine*	pLM)
{
	return	lispMachineState_point (pLM, &lispBuffer_PointMin) ;
}

/*
 *	(point-max)
 */
TLMRESULT
lispMachineState_PointMax (
	register TLispMachine*	pLM)
{
	return	lispMachineState_point (pLM, &lispBuffer_PointMax) ;
}

/*
 *	(point-marker)
 */
TLMRESULT
lispMachineState_PointMarker (
	register TLispMachine*	pLM)
{
	return	lispMachineState_pointMarker (pLM, &lispBuffer_Point) ;
}

/*
 *	(point-min-marker)
 */
TLMRESULT
lispMachineState_PointMinMarker (
	register TLispMachine*	pLM)
{
	return	lispMachineState_pointMarker (pLM, &lispBuffer_PointMin) ;
}

/*
 *	(point-max-marker)
 */
TLMRESULT
lispMachineState_PointMaxMarker (
	register TLispMachine*	pLM)
{
	return	lispMachineState_pointMarker (pLM, &lispBuffer_PointMax) ;
}

/*	built-in function:
 *		(bobp)
 *
 *	���� point ���o�b�t�@�̐擪�ɂ���� t ��Ԃ��Bnarrowing ����Ă���
 *	�ꍇ�ɂ͂��̉e�����󂯂�B
 */
TLMRESULT
lispMachineState_Bobp (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntRetval ;
	int				nPoint, nPointMin ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispBuffer_Point    (pLispMgr, pEntBuffer, &nPoint)) ||
		TFAILED (lispBuffer_PointMax (pLispMgr, pEntBuffer, &nPointMin))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (nPoint == nPointMin) {
		(void) lispMgr_CreateT   (pLispMgr, &pEntRetval) ;
	} else {
		(void) lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*
 *	(eobp)
 *
 *	���� point ���o�b�t�@�̍Ō�ɂ���� t ��Ԃ��B�����o�b�t�@�� narrow
 *	����Ă���΁A���̉e�����󂯂�B
 */
TLMRESULT
lispMachineState_Eobp (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntRetval ;
	int				nPoint, nPointMax ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispBuffer_Point    (pLispMgr, pEntBuffer, &nPoint)) ||
		TFAILED (lispBuffer_PointMax (pLispMgr, pEntBuffer, &nPointMax))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (nPoint == nPointMax) {
		(void) lispMgr_CreateT   (pLispMgr, &pEntRetval) ;
	} else {
		(void) lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*	built-in function:
 *		(eolp)
 *
 *	�����|�C���g���s�̍Ō�̈ʒu�ɂ���΁At ��Ԃ��B�u�s�̍Ō�v�ɂ�
 *	�o�b�t�@�̍Ō���܂�ł���B
 */
TLMRESULT
lispMachineState_Eolp (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*		pEntBuffer ;
	TLispEntity*		pEntRetval ;
	TBufStringMarker	mkBuffer ;
	int					nPoint, nPointMin, nPointMax, nLength ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispBuffer_Point    (pLispMgr, pEntBuffer, &nPoint)) ||
		TFAILED (lispBuffer_PointMin (pLispMgr, pEntBuffer, &nPointMin)) ||
		TFAILED (lispBuffer_PointMax (pLispMgr, pEntBuffer, &nPointMax)) ||
		TFAILED (lispBuffer_GetString (pLispMgr, pEntBuffer, &mkBuffer, &nLength))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	TBufStringMarker_Forward (&mkBuffer, nPoint - nPointMin) ;
	if (TBufStringMarker_GetChar (&mkBuffer) == '\n' ||
		nPoint == nPointMax) {
		(void) lispMgr_CreateT   (pLispMgr, &pEntRetval) ;
	} else {
		(void) lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*
 *	(insert-char CHARACTER COUNT &optional INHERIT)
 *
 *	INHERIT �� text property �̌p���Ɋւ���ݒ�Ȃ̂ŁA�����ł͖����ł���B
 */
TLMRESULT
lispMachineState_InsertChar (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pArglist ;
	TLispEntity*	pCharacter ;
	TLispEntity*	pCount ;
	TLispEntity*	pNil ;
	TLispEntity*	pEntBuffer ;
	long			lChar, lCount ;
	register Char	cc ;
	int				nPos ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;

	if (TFAILED (lispEntity_GetCar  (pLispMgr, pArglist, &pCharacter)) ||
		TFAILED (lispEntity_GetCadr (pLispMgr, pArglist, &pCount)) ||
		TFAILED (lispEntity_GetIntegerValue (pLispMgr, pCharacter, &lChar)) ||
		TFAILED (lispEntity_GetIntegerValue (pLispMgr, pCount, &lCount)) ||
		TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispBuffer_Point (pLispMgr, pEntBuffer, &nPos))) 
		goto	error ;

	cc	= (Char) lChar ;
	if (Char_Charset (cc) < KCHARSET_ASCII || Char_Charset (cc) >= MAX_CHARSET) {
		if (Char_Charset (cc) != KCHARSET_XCHAR)
			goto	error ;
		cc	= Char_MakeAscii (Char_Code (cc) & 0x7F) ;
	}
	if (TFAILED (lispBuffer_InsertChar (pLispMgr, pEntBuffer, nPos, cc, lCount)))
		goto	error ;
	
	lispMgr_CreateNil (pLispMgr, &pNil) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pNil) ;
	return	LMR_RETURN ;

  error:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

/*
 *	(insert &rest ARG)
 */
TLMRESULT
lispMachineState_Insert (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pArglist ;
	TLispEntity*	pEntChar ;
	TLispEntity*	pNil ;
	TLispEntity*	pEntBuffer ;
	const Char*		pString ;
	Char			ch ;
	long			lChar ;
	int				nPos, nString ;

	ASSERT (pLM != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pArglist) ;

	while (TFAILED (lispEntity_Nullp (pLispMgr, pArglist))) {
		lispEntity_GetCar (pLispMgr, pArglist, &pEntChar) ;
		if (TSUCCEEDED (lispEntity_Stringp (pLispMgr, pEntChar))) {
			lispEntity_GetStringValue (pLispMgr, pEntChar, &pString, &nString) ;
#if defined (DEBUG)
			{
				int	nPoint ;
				lispBuffer_Point (pLispMgr, pEntBuffer, &nPoint) ;
				fprintf (stderr, "insert-char(%d): ", nPoint) ;
				lispEntity_Print (pLispMgr, pEntChar) ;
				fprintf (stderr, ", %d\n", nString) ;
			}
#endif
		} else if (TSUCCEEDED (lispEntity_Integerp (pLispMgr, pEntChar))) {
			lispEntity_GetIntegerValue (pLispMgr, pEntChar, &lChar) ;
			ch		= (Char) lChar ;
			if (Char_Charset (ch) < KCHARSET_ASCII || Char_Charset (ch) >= MAX_CHARSET) {
				if (Char_Charset (ch) != KCHARSET_XCHAR) {
					lispMachineCode_SetError (pLM) ;
					break ;
				}
				ch	= Char_MakeAscii (Char_Code (ch) & 0x7F) ;
			}
			pString	= &ch ;
			nString	= 1 ;
		} else {
			lispMachineCode_SetError (pLM) ;
			break ;
		}
		if (TFAILED (lispBuffer_Point (pLispMgr, pEntBuffer, &nPos)) ||
			TFAILED (lispBuffer_InsertString (pLispMgr, pEntBuffer, nPos, pString, nString))) {
			lispMachineCode_SetError (pLM) ;
			break ;
		}
		lispEntity_GetCdr (pLispMgr, pArglist, &pArglist) ;
	}
	lispMgr_CreateNil (pLispMgr, &pNil) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pNil) ;
	return	LMR_RETURN ;
}

/*
 *	(following-char)
 */
TLMRESULT
lispMachineState_FollowingChar (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*		pEntBuffer ;
	int					nBufString ;
	Char				ch ;
	int					nPointMin, nPointMax, nPointBTop, nPoint ;
	TLispEntity*		pEntRetval ;
	TBufStringMarker	mkBuffer ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispBuffer_GetString (pLispMgr, pEntBuffer, &mkBuffer, &nBufString))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispBuffer_PointMin (pLispMgr, pEntBuffer, &nPointBTop) ;
	lispBuffer_PointMin (pLispMgr, pEntBuffer, &nPointMin) ;
	lispBuffer_PointMax (pLispMgr, pEntBuffer, &nPointMax) ;
	lispBuffer_Point    (pLispMgr, pEntBuffer, &nPoint) ;
	if (nPoint < nPointMin || nPoint >= nPointMax) {
		ch	= 0 ;
	} else {
		TBufStringMarker_Forward (&mkBuffer, nPoint - nPointBTop) ;
		ch	= TBufStringMarker_GetChar (&mkBuffer) ;
	}
	if (TFAILED (lispMgr_CreateInteger (pLispMgr, (long) ch, &pEntRetval)))
		return	LMR_ERROR ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
	
}

/*
 *
 */
TLMRESULT
lispMachineState_PrecedingChar (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntBuffer ;
	int				nStrBuffer ;
	int				nPoint, nPointMin, nPointBTop ;
	register Char	ch ;
	TLispEntity*	pEntRetval ;
	TBufStringMarker	mkBuffer ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	lispBuffer_Point     (pLispMgr, pEntBuffer, &nPoint) ;
	lispBuffer_PointMin  (pLispMgr, pEntBuffer, &nPointMin) ;
	lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nPointBTop) ;
	lispBuffer_GetString (pLispMgr, pEntBuffer, &mkBuffer, &nStrBuffer) ;
	if (nPoint <= nPointMin) {
		ch	= 0 ;
	} else {
		ASSERT ((nPoint - nPointMin) <= nStrBuffer) ;
		TBufStringMarker_Forward (&mkBuffer, nPoint - nPointBTop - 1) ;
		ch	= TBufStringMarker_GetChar (&mkBuffer) ;
	}
#if defined (DEBUG)
	fprintf (stderr, "preceding-char: %lx (point: %d/min: %d)\n", ch, nPoint, nPointMin) ;
#endif
	if (TFAILED (lispMgr_CreateInteger (pLispMgr, ch, &pEntRetval)))
		return	LMR_ERROR ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*
 *	(set-buffer BUFFER)
 *
 *	buffer BUFFER ��ҏW����� current �ɐݒ肷��BBUFFER ��
 *	buffer �������͑��݂���o�b�t�@�̖��O�ł���B
 *	(�������Ȃ���A���̂Ƃ��� skkime �� lisp �͑S�Ẵo�b�t�@
 *	�͖����Ȃ̂Ŗ��O�w��͕s�\�ł���)
 */
TLMRESULT
lispMachineState_SetBuffer (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*			pEntArglist ;
	TLispEntity*			pEntTarget ;
	TLispEntity*			pEntBuffer ;
	const Char*				strBuffer ;
	int						nstrBuffer ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntTarget) ;

	if (TSUCCEEDED (lispEntity_Bufferp (pLispMgr, pEntTarget))) {
		lispMachineCode_SetCurrentBuffer (pLM, pEntTarget) ;
		return	LMR_RETURN ;
	}
	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntTarget, &strBuffer, &nstrBuffer)) ||
		TFAILED (lispMachine_GetBuffer (pLM, strBuffer, nstrBuffer, &pEntBuffer)) ||
		TFAILED (lispEntity_Bufferp (pLispMgr, pEntBuffer))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMachineCode_SetCurrentBuffer (pLM, pEntBuffer) ;
	return	LMR_RETURN ;
}

TLMRESULT
lispMachineState_SaveCurrentBuffer (
	register TLispMachine*	pLM)
{
	TLispEntity*	pEntBuffer ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	ASSERT (pEntBuffer != NULL) ;
	lispMachineCode_PushLReg (pLM, LM_LREG_1) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_1, pEntBuffer) ;
	lispMachineCode_SetState (pLM, &lispMachineState_Progn) ;
	lispMachineCode_PushState (pLM, &lispMachineState_saveCurrentBufferFinalize) ;
	return	LMR_CONTINUE ;
}

TLMRESULT
lispMachineState_saveCurrentBufferFinalize (
	register TLispMachine*	pLM)
{
	TLispEntity*	pEntBuffer ;

	lispMachineCode_GetLReg (pLM, LM_LREG_1, &pEntBuffer) ;
	lispMachineCode_SetCurrentBuffer (pLM, pEntBuffer) ;
	lispMachineCode_PopLReg (pLM, LM_LREG_1) ;
	return	LMR_RETURN ;
}

/*
 *	(make-local-variable VARIABLE)
 *
 *	make-local-variable �� interactive built-in function�B
 *	VARIABLE �� current buffer �ŕʂ̒l�����Ă�悤�ɂ���B����
 *	buffer �͋��ʂ� default value �����L��������Bbuffer-local 
 *	�̒l�� VARIABLE ���ȑO�Ɏ����Ă����̂Ɠ����l����͂��܂�B
 *	���� VARIABLE �� void �Ȃ� void �̂܂܁B
 */
TLMRESULT
lispMachineState_MakeLocalVariable (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*			pEntBuffer ;
	TLispEntity*			pEntArglist ;
	TLispEntity*			pEntSymbol ;
	TLispEntity*			pDummy ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntSymbol)) ||
		TFAILED (lispEntity_Symbolp (pLispMgr, pEntSymbol)) ||
		TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}

	if (TFAILED (lispBuffer_GetSymbolValue (pLispMgr, pEntBuffer, pEntSymbol, &pDummy))) {
		TLispEntity*	pEntValue ;

		/*	default-value �����݂��Ȃ���΁Avoid �̂܂܁B*/
		if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntSymbol, &pEntValue)))
			lispMgr_CreateVoid (pLispMgr, &pEntValue) ;

		if (TFAILED (lispBuffer_MakeSymbolValue (pLispMgr, pEntBuffer, pEntSymbol)))
			return	LMR_ERROR ;
		lispBuffer_SetSymbolValue (pLispMgr, pEntBuffer, pEntSymbol, pEntValue) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntSymbol) ;
	return	LMR_RETURN ;
}

/*
 *	(make-variable-buffer-local VARIABLE)
 */
TLMRESULT
lispMachineState_MakeVariableBufferLocal (
	register TLispMachine* pLM)
{
	register TLispManager*	pLispMgr ;
	TLispEntity*			pEntBuffer ;
	TLispEntity*			pEntArglist ;
	TLispEntity*			pEntSymbol ;
	TLispEntity*			pDummy ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	if (TFAILED (lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntSymbol)) ||
		TFAILED (lispEntity_Symbolp (pLispMgr, pEntSymbol)) ||
		TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}

	if (TFAILED (lispBuffer_GetSymbolValue (pLispMgr, pEntBuffer, pEntSymbol, &pDummy))) {
		TLispEntity*	pEntValue ;

		/*	default-value �����݂��Ȃ���΁Anil �ɐݒ肷��B*/
		if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntSymbol, &pEntValue)) ||
			TSUCCEEDED (lispEntity_Voidp (pLispMgr, pEntValue))) {
			lispMgr_CreateNil (pLispMgr, &pEntValue) ;
			lispMachine_SetCurrentSymbolValue (pLM, pEntSymbol, pEntValue) ;
		}

		if (TFAILED (lispBuffer_MakeSymbolValue (pLispMgr, pEntBuffer, pEntSymbol)))
			return	LMR_ERROR ;
		lispBuffer_SetSymbolValue (pLispMgr, pEntBuffer, pEntSymbol, pEntValue) ;

		/*	�ȍ~ buffer �������x�ɔ��f�����悤�ɏ��� manager �ɗ^����B*/
		lispMgr_AddSymbolToLocalSymbols (pLispMgr, pEntSymbol) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntSymbol) ;
	return	LMR_RETURN ;
}


/*
 *	(char-after &optional POS)
 *
 *	Return character in current buffer at position POS.
 *	POS is an integer or a marker.
 *	If POS is out of range, the value is nil.
 */
TLMRESULT
lispMachineState_CharAfter (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntPOS ;
	TLispEntity*	pEntRetval ;
	int				nBufString ;
	int				nPoint, nPointMin, nPointMax, nPointBTop ;
	TBufStringMarker	mkBuffer ;
	
	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED (lispBuffer_GetString (pLispMgr, pEntBuffer, &mkBuffer, &nBufString))) 
		goto	error ;
	ASSERT (pEntBuffer != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntPOS) ;
	if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntPOS))) {
		lispBuffer_Point (pLispMgr, pEntBuffer, &nPoint) ;
	} else {
		TLispNumber	num ;

		if (TFAILED (lispEntity_GetNumberOrMarkerValue (pLispMgr, pEntPOS, &num)) ||
			TSUCCEEDED (num.m_fFloatp)) 
			goto	error ;
		nPoint	= num.m_Value.m_lLong ;
	}
	lispBuffer_PointMin (pLispMgr, pEntBuffer, &nPointMin) ;
	lispBuffer_PointMax (pLispMgr, pEntBuffer, &nPointMax) ;
	lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nPointBTop) ;
	if (nPoint < nPointMin || nPoint >= nPointMax) {
		lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	} else {
		TBufStringMarker_Forward (&mkBuffer, nPoint - nPointBTop) ;
		lispMgr_CreateInteger (pLispMgr, TBufStringMarker_GetChar (&mkBuffer), &pEntRetval) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;

  error:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

/*
 *	interactive built-in function:
 *		(narrow-to-region START END)
 *
 *	���݂̃o�b�t�@�̃J�����g�̃��[�W������ҏW�̈�Ƃ��Đ�������B�c��
 *	�̃e�L�X�g�͈ꎞ�I�Ɍ����Ȃ��Ȃ��ĐG����Ȃ��Ȃ�B�폜���邱�Ƃ�
 *	�ł��Ȃ��B�����A�o�b�t�@���t�@�C���ɃZ�[�u�����ꍇ�A�����Ȃ��e�L�X�g
 *	�̓t�@�C���Ɋ܂܂��Bsave-restriction �����邱�ƁB
 *
 *	START, END �� integer-or-marker-p �� t ��Ԃ��K�v������B
 */
TLMRESULT
lispMachineState_NarrowToRegion (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntSTART ;
	TLispEntity*	pEntEND ;
	int				nStart, nEnd ;
	long			lStart, lEnd ;
	TLispEntity*	pEntRetval ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	ASSERT (pEntBuffer != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	ASSERT (pEntArglist != NULL) ;
	lispEntity_GetCar  (pLispMgr, pEntArglist, &pEntSTART) ;
	lispEntity_GetCadr (pLispMgr, pEntArglist, &pEntEND) ;
	if (TFAILED (lispEntity_IntegerOrMarkerp (pLispMgr, pEntSTART)) ||
		TFAILED (lispEntity_IntegerOrMarkerp (pLispMgr, pEntEND))) 
		goto	error ;
	if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntSTART, &lStart))) {
		lispMarker_GetBufferPosition (pLispMgr, pEntSTART, NULL, &nStart) ;
	} else {
		nStart	= lStart ;
	}
	if (TFAILED (lispEntity_GetIntegerValue (pLispMgr, pEntEND, &lEnd))) {
		lispMarker_GetBufferPosition (pLispMgr, pEntEND, NULL, &nEnd) ;
	} else {
		nEnd	= lEnd ;
	}
	if (TFAILED (lispBuffer_Narrow (pLispMgr, pEntBuffer, nStart, nEnd)))
		goto	error ;
	lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;

  error:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

/*
 *
 */
TLMRESULT
lispMachineState_Widen (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntBuffer ;
	int				nBufferTop, nBufferEnd ;
	TLispEntity*	pEntRetval ;

	ASSERT (pLM      != NULL) ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	ASSERT (pEntBuffer != NULL) ;

	lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nBufferTop) ;
	lispBuffer_PointBufferEnd (pLispMgr, pEntBuffer, &nBufferEnd) ;
	if (TFAILED (lispBuffer_Narrow (pLispMgr, pEntBuffer, nBufferTop, nBufferEnd))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*	private */
TLMRESULT
lispMachineState_point (
	register TLispMachine*	pLM,
	register BOOL		(*pPointFunc)(TLispManager*, TLispEntity*, int*))
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntRetval ;
	int				nPos ;

	ASSERT (pLM != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED ((*pPointFunc) (pLispMgr, pEntBuffer, &nPos))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	/*	�o�b�t�@�̐擪��1�ɏC������B���̑���͈ÖٓI�ɍs����̂Œ��ӁB*/
	/*	���̏C���� marker �𐔂ɒ������ɏo��B*/
	/*lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nBufferTop) ;*/
	if (TFAILED (lispMgr_CreateInteger (pLispMgr, nPos /*- nBufferTop + 1*/, &pEntRetval)))
		return	LMR_ERROR ;

	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

TLMRESULT
lispMachineState_pointMarker (
	register TLispMachine*	pLM,
	register BOOL		(*pPointFunc)(TLispManager*, TLispEntity*, int*))
{
	register TLispManager*	pLispMgr ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntRetval ;
	int				nPoint ;

	ASSERT (pLM != NULL) ;

	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (TFAILED (lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer)) ||
		TFAILED ((*pPointFunc) (pLispMgr, pEntBuffer, &nPoint))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (TFAILED (lispMgr_CreateMarker (pLispMgr, &pEntRetval)))
		return	LMR_ERROR ;
	lispBuffer_AddMarker (pLispMgr, pEntBuffer, pEntRetval) ;
	lispMarker_SetBufferPosition (pLispMgr, pEntRetval, pEntBuffer, nPoint) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*	built-in function:
 *		(get-buffer-create NAME)
 *
 *	NAME �Ɩ��t����ꂽ�o�b�t�@��Ԃ��A�܂��͂���ȃo�b�t�@�����A����
 *	��Ԃ��B���� NAME �Ɩ��t����ꂽ�o�b�t�@���Ȃ���ΐV�����o�b�t�@��
 *	�����BNAME ���X�y�[�X�ł͂��܂�Ȃ�A�V�����o�b�t�@�� UNDO ���
 *	��ێ����Ȃ��BNAME ��������̑���Ƀo�b�t�@�Ȃ�A���ꂪ�Ԃ����
 *	�l�ł���B���̒l�͌����� nil �ł͂Ȃ��B
 */
TLMRESULT
lispMachineState_GetBufferCreate (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntNAME ;
	TLispEntity*	pEntRetval ;
	const Char*		pStrName ;
	int				nStrName ;
	
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	(void) lispEntity_GetCar (pLispMgr, pEntArglist, &pEntNAME) ;
	if (TSUCCEEDED (lispEntity_GetStringValue (pLispMgr, pEntNAME, &pStrName, &nStrName))) {
		if (TFAILED (lispMachine_GetBuffer (pLM, pStrName, nStrName, &pEntRetval))) {
			if (TFAILED (lispMgr_CreateBuffer (pLispMgr, &pEntRetval)))
				return	LMR_ERROR ;
			lispBuffer_SetName (pLispMgr, pEntRetval, pEntNAME) ;
			lispMachine_InsertBuffer (pLM, pEntRetval) ;
		}
	} else if (TSUCCEEDED (lispEntity_Bufferp (pLispMgr, pEntNAME))) {
		pEntRetval	= pEntNAME ;
	} else {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*
 *	built-in function:
 *		(get-buffer NAME)
 */
TLMRESULT
lispMachineState_GetBuffer (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntNAME ;
	TLispEntity*	pEntRetval ;
	const Char*		pStrName ;
	int				nStrName ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	(void) lispEntity_GetCar (pLispMgr, pEntArglist, &pEntNAME) ;
	if (TSUCCEEDED (lispEntity_GetStringValue (pLispMgr, pEntNAME, &pStrName, &nStrName))) {
		if (TFAILED (lispMachine_GetBuffer (pLM, pStrName, nStrName, &pEntRetval)))
			pEntRetval	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_NIL) ;
	} else if (TSUCCEEDED (lispEntity_Bufferp (pLispMgr, pEntNAME))) {
		pEntRetval	= pEntNAME ;
	} else {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}

/*	interactive built-in function:
 *		(erase-buffer)
 *
 *	�J�����g�o�b�t�@�̒��g�S�̂���������Bnarrowing �̐������������B
 *	�o�b�t�@�͂��̌�{���ɋ�ɂȂ�B
 */
TLMRESULT
lispMachineState_EraseBuffer (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntBuffer ;
	int				nPointBTop, nPointBEnd ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	lispBuffer_Widen (pLispMgr, pEntBuffer) ;
	lispBuffer_PointBufferTop (pLispMgr, pEntBuffer, &nPointBTop) ;
	lispBuffer_PointBufferEnd (pLispMgr, pEntBuffer, &nPointBEnd) ;
	lispBuffer_DeleteChar (pLispMgr, pEntBuffer, nPointBTop, nPointBEnd - nPointBTop) ;
	return	LMR_RETURN ;
}

/*	built-in function:
 *		(generate-new-buffer-name NAME &optional IGNORE)
 *
 *	NAME ���x�[�X�ɂ��ăo�b�t�@�Ƃ��Ă��̖��O�����݂��Ă��Ȃ��������Ԃ��B
 *	���� NAME �Ɩ��t����ꂽ�o�b�t�@�����݂��Ȃ��̂Ȃ�ANAME ��Ԃ��B
 *	�����łȂ���΁A`<NUMBER>' �������Ė��O���C������B�g���Ă��Ȃ����O��
 *	���t����܂� NUMBER �𑝉������Ă����BIGNORE �͂��Ƃ����̖��O�̃o�b�t�@
 *	�����݂��Ă��g���ėǂ����O���w�肷��B
 *
 *	���݁AIGNORE �͖����B���������Ȃ񂾂낤�H
 */
TLMRESULT
lispMachineState_GenerateNewBufferName (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntNAME ;
	const Char*		pStrNAME ;
	int				nStrNAME ;
	TLispEntity*	pEntRetval ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntNAME) ;
	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntNAME, &pStrNAME, &nStrNAME))) 
		goto	error ;
	if (TFAILED (lispMachine_GenerateNewBufferName (pLM, pStrNAME, nStrNAME, &pEntRetval)))
		return	LMR_ERROR ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;

  error:	
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

/*	(generate-new-buffer NAME)
 *
 *	NAME �Ɋ�����O�ł����ăo�b�t�@���쐬�A�Ԃ��B�o�b�t�@�̖��O��
 *	generate-new-buffer-name ���g���đI�����Ă���B
 */
TLMRESULT
lispMachineState_GenerateNewBuffer (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntNAME ;
	const Char*		pStrNAME ;
	int				nStrNAME ;
	TLispEntity*	pEntName ;
	TLispEntity*	pEntBuffer ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntNAME) ;
	if (TFAILED (lispEntity_GetStringValue (pLispMgr, pEntNAME, &pStrNAME, &nStrNAME))) 
		goto	error ;
	if (TFAILED (lispMgr_CreateBuffer (pLispMgr, &pEntBuffer)))
		return	LMR_ERROR ;
	lispEntity_AddRef (pLispMgr, pEntBuffer) ;
	if (TFAILED (lispMachine_GenerateNewBufferName (pLM, pStrNAME, nStrNAME, &pEntName)))
		return	LMR_ERROR ;
	lispBuffer_SetName (pLispMgr, pEntBuffer, pEntName) ;
	lispMachine_InsertBuffer (pLM, pEntBuffer) ;
	lispEntity_Release (pLispMgr, pEntBuffer) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntBuffer) ;
	return	LMR_RETURN ;

  error:
	lispMachineCode_SetError (pLM) ;
	return	LMR_RETURN ;
}

/*	built-in function:
 *		(set-buffer-modified-p FLAG)
 *
 *	FLAG �ɏ]���ăJ�����g�o�b�t�@���C������Ă��邩�A�C������Ă��Ȃ����}�[�N
 *	�t�����s���BFLAG �� non-nil �Ȃ�o�b�t�@�͏C�����ꂽ�Ƀ}�[�N�t�������B
 */
TLMRESULT
lispMachineState_SetBufferModifiedp (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntFLAG ;

	ASSERT (pLM      != NULL) ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	ASSERT (pEntBuffer  != NULL) ;
	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	ASSERT (pEntArglist != NULL) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntFLAG) ;
	ASSERT (pEntFLAG    != NULL) ;
	lispBuffer_SetModifiedp (pLispMgr, pEntBuffer, TFAILED (lispEntity_Nullp (pLispMgr, pEntFLAG))) ;
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntFLAG) ;
	return	LMR_RETURN ;
}

/*	built-in function:
 *		(buffer-modified-p &optional BUFFER)
 *
 *	���� BUFFER ���Ō�Ƀt�@�C�����ǂ܂�āA�܂��̓Z�[�u����Ă���ύX����Ă�
 *	��΁At ��Ԃ��B�������Ȃ��A�܂��� nil �������������ꍇ�ɂ� BUFFER �Ƃ���
 *	�J�����g�o�b�t�@���g�����Ƃ��Ӗ�����B
 */
TLMRESULT
lispMachineState_BufferModifiedp (
	register TLispMachine*	pLM)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TLispEntity*	pEntArglist ;
	TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntRetval ;

	ASSERT (pLM      != NULL) ;
	ASSERT (pLispMgr != NULL) ;

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pEntArglist) ;
	ASSERT (pEntArglist != NULL) ;
	lispEntity_GetCar (pLispMgr, pEntArglist, &pEntBuffer) ;
	if (TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntBuffer))) 
		lispMachineCode_GetCurrentBuffer (pLM, &pEntBuffer) ;
	if (TFAILED (lispEntity_Bufferp (pLispMgr, pEntBuffer))) {
		lispMachineCode_SetError (pLM) ;
		return	LMR_RETURN ;
	}
	if (TSUCCEEDED (lispBuffer_GetModifiedp (pLispMgr, pEntBuffer))) {
		lispMgr_CreateT   (pLispMgr, &pEntRetval) ;
	} else {
		lispMgr_CreateNil (pLispMgr, &pEntRetval) ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pEntRetval) ;
	return	LMR_RETURN ;
}


