#pragma once
#include "local.h"
#include <stdlib.h>
#include <assert.h>

enum {
	VARBUF_DEFAULTSIZE	= sizeof (long) / sizeof (unsigned char) * 64,
} ;

typedef struct {
	unsigned char	m_achInternal [VARBUF_DEFAULTSIZE] ;
	void*			m_pBuffer ;
	int				m_nIndex ;
	int				m_nSize ;
	int				m_nUsage ;
	int				m_nWidth ;
}	TVarbuffer ;

#if defined (__cplusplus)
extern "C" {
#endif
/*	prototypes */
BOOL	TVarbuffer_Initialize	(TVarbuffer*, int) ;
BOOL	TVarbuffer_Uninitialize	(TVarbuffer*) ;
BOOL	TVarbuffer_Clear		(TVarbuffer*) ;
BOOL	TVarbuffer_Sub			(TVarbuffer*, int) ;
BOOL	TVarbuffer_Require		(TVarbuffer*, int) ;
BOOL	TVarbuffer_Add			(TVarbuffer*, const void*, int) ;
void*	TVarbuffer_GetBuffer	(TVarbuffer*) ;
int		TVarbuffer_GetUsage		(TVarbuffer*) ;

#if defined (__cplusplus)
}
#endif 

