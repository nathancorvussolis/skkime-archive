#pragma once

#include "jisyo.h"
#include "varbuffer.h"

#define	MAX_USER_JISYOS					(10)
#define	DEFAULT_KAKUTEI_HISTORY_LIMITS	(100)

#define	REGPATH_SKKIME					TEXT("Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5")


#if defined (__cplusplus)
extern "C" {
#endif

typedef struct tagSkkKakuteiHistoryItem	SkkKakuteiHistoryItem ;

typedef struct tagSkkImeUser {
	TCHAR					m_tszUserName [UNLEN + 1] ;
	SkkJisyo*				m_pLocalJisyo ;
	SkkJisyo*				m_pOkuriJisyo ;	/* okuri-search �̂��߂� fake, local-jisyo �Ɉˑ��B */
	SkkJisyo*				m_rpJisyo    [MAX_USER_JISYOS] ;
	int						m_rnPriority [MAX_USER_JISYOS] ;

	int						m_nKakuteiHistoryLimit ;
	int						m_nKakuteiHistoryItems ;
	SkkKakuteiHistoryItem*	m_plstKakuteiHistory ;
	SkkKakuteiHistoryItem*	m_plstKakuteiHistoryLastItem ;
}	SkkImeUser ;

/*========================================================================
 *	prototypes
 */
SkkImeUser*	SkkImeUser_Create	(LPCTSTR, int) ;
void		SkkImeUser_Destroy	(SkkImeUser*) ;

BOOL		SkkImeUser_Search	(SkkImeUser*, const Char*, int, const Char*, int, int, TVarbuffer*) ;
BOOL		SkkImeUser_SearchEx	(SkkImeUser*, const Char*, int, const Char*, int, int, int, TVarbuffer*, int*) ;
BOOL		SkkImeUser_Record	(SkkImeUser*, const Char*, int, const Char*, int, const Char*, int, BOOL) ;
BOOL		SkkImeUser_Purge	(SkkImeUser*, const Char*, int, const Char*, int, const Char*, int, BOOL) ;
BOOL		SkkImeUser_Save		(SkkImeUser*) ;
BOOL		SkkImeUser_TryCompletion		(SkkImeUser*, const Char*, int, TVarbuffer*) ;
BOOL		SkkImeUser_RecordKakuteiHistory	(SkkImeUser*, const Char*, int, const Char*, int) ;
BOOL		SkkImeUser_GetKakuteiHistory	(SkkImeUser*, TVarbuffer*) ;
BOOL		SkkImeUser_Update	(SkkImeUser*) ;

#if defined (__cplusplus)
}
#endif

