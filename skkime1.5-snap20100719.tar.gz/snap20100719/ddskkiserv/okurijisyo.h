#pragma once

#include "Char.h"

typedef struct tagSkkOkuriSearchJisyo {
	SkkJisyo*					m_pLocalJisyo ;
}	SkkOkuriSearchJisyo ;

/*	prototypes */
SkkJisyo*	SkkOkuriSearchJisyo_Create	(SkkJisyo*) ;


