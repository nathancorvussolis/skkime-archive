/*	JISX0213-2004-std.txt parser
 */
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>

#define	BUFFER_UNITSIZE	(4096)

struct MyNode {
	DWORD	m_dwLeading ;
	DWORD*	m_pdwTable ;
	struct MyNode*	m_pNext ; 
} ;

static	BOOL	bReadTable (FILE* fp) ;
static	BOOL	bMakeCode (DWORD*, const BYTE*, int) ;
static	BOOL	bRegisterCode (const BYTE* pbMB, int nMBLen, const DWORD* pbUnicode, int nUnicodeLen) ;
static	BOOL	bParseNumber (LPCTSTR* ppString, BYTE* pResult, int* pnResultLen) ;
static	void	vDumpTable (void) ;

static	struct MyNode*	s_plst			= NULL ;
static	DWORD*			s_pdwBuffer		= NULL ;
static	DWORD			s_dwBufferUsage	= 0 ;
static	DWORD			s_dwBufferSize	= 0 ;
static	BOOL			s_bWindows		= TRUE ;
static	BOOL			s_bFullwidth	= TRUE ;

int _tmain (int argc, TCHAR* rpArgv [])
{
	FILE*	fp ;
	BOOL	bRetval ;

	if (argc == 2) {
		fp	= _tfopen (rpArgv [1], TEXT ("r")) ;
		if (fp == NULL) {
			_ftprintf (stderr, TEXT ("\"%s\" not found.\n"), rpArgv [1]) ;
			return	EXIT_FAILURE ;
		}
	} else {
		fp	= stdin ;
	}
	bRetval	= bReadTable (fp) ;
	fclose (fp) ;
	if (bRetval)
		vDumpTable () ;
	return	EXIT_SUCCESS ;
}

static	BOOL
bReadTable (FILE* fp)
{
	TCHAR	buf [2048] ;

	while (! feof (fp)) {
		BYTE	bufMB [32] ;
		DWORD	rdwCodes [32] ;
		int		nCodeLen ;
		int		nMBLen ; 
		int		nLength ;
		LPCTSTR	ptr ;

		buf [ARRAYSIZE(buf)-1]	= TEXT ('\0') ;
		if (_fgetts (buf, ARRAYSIZE (buf)-1, fp) == NULL)
			break ;
		nLength	= lstrlen (buf) ;
		if (! ((nLength > 0 && buf [nLength-1] == 0x0A) || (nLength > 1 && buf [nLength-2] == 0x0D && buf [nLength-1] == 0x0A))) {
			/* too long line */
			while (! feof (fp)) {
				int	ch	= _fgettc (fp) ;
				if (ch == TEXT ('\n'))
					break ;
			}
			continue ;
		}
		if (nLength <= 0)
			continue ;
		if (buf [0] == 0x0A || (nLength > 1 && buf [0] == 0x0D && buf [1] == 0x0A))
			continue ;
		if (buf [0] == TEXT ('#'))
			continue ;	/* comment line */

		/* token ���ɐ؂�o���B*/
		ptr		= buf ;
		nMBLen	= 0 ;
		while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0')) {
			if ((*ptr == TEXT ('3') || *ptr == TEXT ('4')) && *(ptr + 1) == TEXT ('-')) {
				/* found */
				bufMB [0]	= (*ptr - TEXT ('3')) + 3 ;
				ptr			+= 2 ;
				nMBLen		= ARRAYSIZE (bufMB)-1 ;
				if (! bParseNumber (&ptr, bufMB+1, &nMBLen)) 
					goto	skip_loop ;
				nMBLen	++ ;
				break ;
			}
			if (*ptr != TEXT (' ') && *ptr != TEXT ('\t'))
				goto	skip_loop ;
			ptr	++ ;
		}
		nCodeLen	= 0 ;
		while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0')) {
			if (*ptr == TEXT ('U') && *(ptr + 1) == TEXT ('+')) {
				/* found */
				DWORD*	pdwCode	= rdwCodes ;
				BYTE	bufUnicode [32] ;
				int		nUnicodeLen ;

				if (s_bFullwidth || s_bWindows) {
					LPCTSTR	pBase	= ptr ;
					BOOL	bFound	= FALSE ;

					while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0') && *ptr != TEXT ('#')) 
						ptr	++ ;
					if (*ptr == TEXT ('#')) {
						ptr	++ ;
						while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0')) {
							if (s_bWindows && ! _tcsncmp (ptr, TEXT ("Windows: U+"), 11)) {
								ptr	+= 9 ;
								bFound	= TRUE ;
								break ;
							}
							if (s_bFullwidth && ! _tcsncmp (ptr, TEXT ("Fullwidth: U+"), 13)) {
								ptr	+= 11 ;
								bFound	= TRUE ;
								break ;
							}
							ptr	++ ;
						}
					}
					if (! bFound) {
						ptr	= pBase ;
					}
				}
				ptr			++ ;
				do {
					ptr	++ ;	// skip '+'
					if (pdwCode > (rdwCodes + ARRAYSIZE (rdwCodes)))
						goto	skip_loop ;
					nUnicodeLen	= ARRAYSIZE (bufUnicode) ;
					if (! bParseNumber (&ptr, bufUnicode, &nUnicodeLen)) 
						goto	skip_loop ;
					if (! bMakeCode (pdwCode, bufUnicode, nUnicodeLen)) {
						goto	skip_loop ;
					}
					pdwCode	++ ;
				}	while (*ptr == TEXT ('+')) ;

				nCodeLen	= pdwCode - rdwCodes ;
#if 0
				{
					int	i ;
					_ftprintf (stderr, TEXT ("U")) ;
					for (i = 0 ; i < nCodeLen ; i ++) {
						_ftprintf (stderr, TEXT ("+%08X"), rdwCodes [i]) ;
					}
					_ftprintf (stderr, TEXT ("\n")) ;
				}
#endif
				break ;
			}
			if (*ptr != TEXT (' ') && *ptr != TEXT ('\t')) {
				BOOL	bFound	= FALSE ;

				/*	��O�K��B
				 */
				if (*ptr == TEXT ('#') && (s_bFullwidth || s_bWindows)) {
					ptr	++ ;
					while (*ptr != TEXT ('\n') && *ptr != TEXT ('\0')) {
						if (s_bWindows && ! _tcsncmp (ptr, TEXT ("Windows: U+"), 11)) {
							ptr	+= 8 ;
							bFound	= TRUE ;
							break ;
						}
						/*
						 */
						if (s_bFullwidth && ! _tcsncmp (ptr, TEXT ("Fullwidth: U+"), 13)) {
							ptr	+= 10 ;
							bFound	= TRUE ;
							break ;
						}
						ptr	++ ;
					}
				}
				if (! bFound)
					goto	skip_loop ;
			}

			ptr	++ ;
		}
		if (! bRegisterCode (bufMB, nMBLen, rdwCodes, nCodeLen)) {
			// error
			break ;
		}
skip_loop:
		;
	}
	return	TRUE ;
}

static	BOOL
bRegisterCode (
	const BYTE*		pbMB,
	int				nMBLen,
	const DWORD*	pdwUnicode,
	int				nUnicodeLen)
{
	DWORD	dwLeading, dwCode, dwUnicode ;

	if (nMBLen > (4 + 2) || nMBLen <= 0 || nUnicodeLen <= 0)
		return	FALSE ;

	dwLeading	= 0 ;
	while (nMBLen > 2) {
		dwLeading	= (dwLeading << 8) | ((DWORD)*pbMB ++) ;
		nMBLen	-- ;
	}
	if (nMBLen == 2) {
		dwCode	= ((DWORD)*pbMB << 8) | ((DWORD)*(pbMB + 1)) ;
	} else {
		dwCode	= (DWORD) *pbMB ;
	}
	{
		struct MyNode*	pNode	= s_plst ;

		while (pNode != NULL) {
			if (pNode->m_dwLeading == dwLeading) {
				//	���������B
				break ;
			}
			pNode	= pNode->m_pNext ;
		}
		if (pNode == NULL) {
			pNode	= (struct MyNode*) malloc (sizeof (struct MyNode) + 0x10000 * sizeof (DWORD)) ;
			if (pNode == NULL)
				return	FALSE ;

			pNode->m_pdwTable	= (DWORD*) (pNode + 1) ;
			memset (pNode->m_pdwTable, 0, sizeof (DWORD) * 0x10000) ;
			pNode->m_dwLeading	= dwLeading ;
			pNode->m_pNext		= s_plst ;
			s_plst				= pNode ;
		}
		if (nUnicodeLen == 1) {
			pNode->m_pdwTable [dwCode]	= pdwUnicode [0] ;
		} else {
			int	i ;

			/*	�ʌ��ɓo�^����B
			 */
			if ((s_dwBufferUsage + nUnicodeLen + 1) > s_dwBufferSize) {
				DWORD*	pdwNewBuffer	= NULL ;
				DWORD	dwNewBufferSize ;

				dwNewBufferSize	= ((s_dwBufferUsage + nUnicodeLen + 1) + BUFFER_UNITSIZE) & (~(DWORD)(BUFFER_UNITSIZE-1)) ;

				pdwNewBuffer	= (DWORD*) malloc (sizeof (DWORD) * dwNewBufferSize) ;
				if (pdwNewBuffer == NULL) {
					_ftprintf (stderr, TEXT ("Out of memory.\n")) ;
					return	FALSE ;
				}
				if (s_pdwBuffer != NULL) {
					memcpy (pdwNewBuffer, s_pdwBuffer, sizeof (DWORD) * s_dwBufferUsage) ;
					free (s_pdwBuffer) ;
				}
				s_pdwBuffer		= pdwNewBuffer ;
				s_dwBufferSize	= dwNewBufferSize ;
			}
			pNode->m_pdwTable [dwCode]	= 0xFF000000UL | (s_dwBufferUsage & 0x00FFFFFFUL) ;

			for (i = 0 ; i < nUnicodeLen ; i ++) {
				s_pdwBuffer [s_dwBufferUsage ++]	= pdwUnicode [i] ;
			}
			s_pdwBuffer [s_dwBufferUsage ++]	= 0 ;
		}
	}
	return	TRUE ;
}

static	BOOL
bMakeCode (
	DWORD*		pdwDest,
	const BYTE*	pbUnicode,
	int			nUnicodeLen)
{
	DWORD	dw ;

	if (nUnicodeLen <= 0 || nUnicodeLen > 4)
		return	FALSE ;
	dw	= 0 ;
	while (nUnicodeLen > 0) {
		dw	= (dw << 8) | ((DWORD) *pbUnicode ++) ;
		nUnicodeLen	-- ;
	}
	*pdwDest	= dw ;
	return	TRUE ;
}

static	BOOL
bParseNumber (
	LPCTSTR*	ppString,
	BYTE*		pResult,
	int*		pnResultLen)
{
	BYTE	buf [256] ;
	LPCTSTR	ptr ;
	BYTE*	pDest ;
	const BYTE*	pDestEnd ;
	const BYTE*	pSrc ;
	const BYTE*	pSrcEnd ;
	int		nResultLen ;

	if (ppString == NULL || pnResultLen == NULL)
		return	FALSE ;

	ptr			= *ppString ;
#if 0
	if (*ptr != TEXT ('0'))
		return	FALSE ;
	ptr	++ ;
	if (*ptr != TEXT ('x'))
		return	FALSE ;
	ptr	++ ;
#endif
	pDest		= buf ;
	pDestEnd	= buf + ARRAYSIZE (buf) ;
	while (*ptr != TEXT ('\0')) {
		if (TEXT ('0') <= *ptr && *ptr <= TEXT ('9')) {
			if (pDest >= pDestEnd)
				return	FALSE ;
			*pDest ++	= *ptr - TEXT ('0') ;
		} else if (TEXT ('A') <= *ptr && *ptr <= TEXT ('F')) {
			if (pDest >= pDestEnd)
				return	FALSE ;
			*pDest ++	= (*ptr - TEXT ('A')) + 10 ;
		} else if (TEXT ('a') <= *ptr && *ptr <= TEXT ('f')) {
			if (pDest >= pDestEnd)
				return	FALSE ;
			*pDest ++	= (*ptr - TEXT ('a')) + 10 ;
		} else {
			break ;
		}
		ptr	++ ;
	}
	if (pDest <= buf)
		return	FALSE ;

	pSrc		= buf ;
	pSrcEnd		= pDest ;

	if (pResult != NULL) {
		int	nLength		= pDest - buf ;
		DWORD	dwValue ;
	
		nResultLen	= *pnResultLen ;
		pDest		= pResult ;
		pDestEnd	= pResult + nResultLen ;

		if (nLength & 1) {
			if (pDest < pDestEnd)
				*pDest ++	= *pSrc ++ ;
		}
		while (pSrc < pSrcEnd) {
			dwValue	=  (*pSrc ++) << 4 ;
			dwValue	|= *pSrc ++ ;
			if (pDest < pDestEnd)
				*pDest ++	= dwValue ;
		}
		nResultLen	= pDest - pResult ;
	} else {
		int	nLength		= pDest - buf ;

		nResultLen	= (nLength + 1) / 2 ;
	}
	*pnResultLen	= nResultLen ;
	*ppString		= ptr ;
	return	TRUE ;
}

static	void
vDumpTable (void)
{
	struct MyNode*	pNode ;

	pNode	= s_plst ;
	while (pNode != NULL) {
		DWORD	dwH, dwL, dw ;

		_tprintf (TEXT ("// 0x%02X\n"), pNode->m_dwLeading) ;
		_tprintf (TEXT ("DWORD\ttable%02X [] = {\n"), pNode->m_dwLeading) ;
		for (dwH = 0x21 ; dwH <= 0x7E ; dwH ++) {
			_tprintf (TEXT ("\t")) ;
			for (dwL = 0x21 ; dwL <= 0x7E ; dwL ++) {
				dw	= (dwH << 8) | dwL ;
				_tprintf (TEXT ("0x%08X, "), pNode->m_pdwTable [dw]) ;
			}
			_tprintf (TEXT ("\t//0x%02X\n"), dwH) ;
		}
		_tprintf (TEXT ("} ;\n\n")) ;
		pNode	= pNode->m_pNext ;
	}

	if (s_pdwBuffer != NULL && s_dwBufferUsage > 0) {
		DWORD	dw= 0 ;

		_tprintf (TEXT ("// Special Table\n")) ;
		_tprintf (TEXT ("DWORD\tspecial_table [] = {\n")) ;
		for (dw = 0 ; dw < s_dwBufferUsage ; dw ++) {
			if ((dw & 7) == 0)
				_tprintf (TEXT ("\t")) ;
			_tprintf (TEXT ("0x%08X, "), s_pdwBuffer [dw]) ;
			if ((dw & 7) == 7 && dw != 0) {
				_tprintf (TEXT ("\n")) ;
			}
		}
		if ((dw & 7) != 0)
			_tprintf (TEXT ("\n")) ;
		_tprintf (TEXT ("} ;\n")) ;
	}
	return ;
}





