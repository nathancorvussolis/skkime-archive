#include "globals.h"
#include "skimic.h"
#include "ToolTipUI.h"

// {60949DAF-EDEA-4760-9B0F-A6C4E5C048D6}
const GUID	CSkkImeToolTipUIElement::m_guidSkkImeToolTipUIElement =  {
	0x60949daf, 0xedea, 0x4760, { 0x9b, 0xf, 0xa6, 0xc4, 0xe5, 0xc0, 0x48, 0xd6 }
} ;

LPCWSTR		CSkkImeToolTipUIElement::m_wstrDescription	= L"SKKIME ToolTip UIElement" ;
TCHAR		CSkkImeToolTipUIElement::m_szClassName []	= TEXT ("SkkImeTextService ToolTipUI Wnd Class") ;

CSkkImeToolTipUIElement::CSkkImeToolTipUIElement (
	CSkkImeTextService*		pTSF)
{
	m_pTSF			= pTSF ;
	m_cRef			= 1 ;
	m_wszText [0]	= L'\0' ;
	m_bShown		= FALSE ;
	m_bOpen			= FALSE ;
	m_hWnd			= NULL ;
	m_dwElementId	= (DWORD) -1 ;
	m_ptWnd.x		= 0 ;
	m_ptWnd.y		= 0 ;
	m_bConsole		= FALSE ;
	DllAddRef () ;
	return ;
}

CSkkImeToolTipUIElement::~CSkkImeToolTipUIElement ()
{
	DllRelease () ;
	return ;
}

STDAPI
CSkkImeToolTipUIElement::QueryInterface (REFIID riid, void **ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
#if defined (__ITfToolTipUIElement_INTERFACE_DEFINED__)
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfToolTipUIElement)) {
		*ppvObj	= (ITfToolTipUIElement *)this ;
#else
	if (IsEqualIID (riid, IID_IUnknown)) {
		*ppvObj	= (IUnknown *)this ;
#endif
#if defined (__ITfUIElementMgr_INTERFACE_DEFINED__)
	} else if (IsEqualIID (riid, IID_ITfUIElement)) {
		*ppvObj	= (ITfUIElement *)this ;
#endif
	} 
	if (*ppvObj) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

ULONG
CSkkImeToolTipUIElement::AddRef () 
{
	m_cRef	++ ;
	return	m_cRef ;
}

ULONG
CSkkImeToolTipUIElement::Release ()
{
	ULONG	cRef	= -- m_cRef ;

	if (cRef == 0)
		delete	this ;

	return	cRef ;
}

STDAPI
CSkkImeToolTipUIElement::GetDescription (BSTR* pbstrDescription) 
{
    BSTR	bstrDesc ;

    if (pbstrDescription == NULL)
        return	E_INVALIDARG ;
	if (m_wstrDescription == NULL)
		return	E_FAIL ;

    *pbstrDescription	= NULL ;
    if ((bstrDesc = SysAllocString(m_wstrDescription)) == NULL)
        return	E_OUTOFMEMORY ;

    *pbstrDescription	= bstrDesc ;
    return	S_OK ;
}

STDAPI
CSkkImeToolTipUIElement::GetGUID (GUID* pguid) 
{
	if (pguid == NULL)
		return	E_INVALIDARG ;

	memcpy (pguid, &m_guidSkkImeToolTipUIElement, sizeof (m_guidSkkImeToolTipUIElement)) ;
	return	S_OK ;
}

STDAPI
CSkkImeToolTipUIElement::Show (BOOL bShow) 
{
	/*
	 *	���� Show �́A
	 *		- BeginUIElement �Ŗ��񂱂������\���������� kick ����� application ���������Ă�
	 *		  �����̂Ȃ̂��A
	 *		- application ���ŏ��Ɏ��O�ŕ\�����邩�ǂ��������肵�āAtrue �� false �𓊂�����
	 *		  ���Ƃ͂��̂܂܂ɂȂ���̂Ȃ̂��A
	 *	�ǂ������^�C�~���O�ŌĂ΂��̂��낤�H
	 */
	m_bShown	= bShow ;
	return	S_OK ;
}

STDAPI
CSkkImeToolTipUIElement::IsShown (BOOL* pbShow) 
{
	if (pbShow == NULL)
		return	E_INVALIDARG ;

	*pbShow	= m_bShown ;
	return	S_OK ;
}

STDAPI
CSkkImeToolTipUIElement::GetString (BSTR* pbstr) 
{
    BSTR	bstrText ;

    if (pbstr == NULL)
        return	E_INVALIDARG ;

    *pbstr	= NULL ;
    if ((bstrText = SysAllocString (m_wszText)) == NULL)
        return	E_OUTOFMEMORY ;

    *pbstr	= bstrText ;
    return	S_OK ;
}

/*========================================================================
 *	�����C���^�[�t�F�[�X�B
 */
BOOL
CSkkImeToolTipUIElement::_Init (BOOL bConsole)
{
	WNDCLASS	wc ;

	if (! bConsole) {
		memset (&wc, 0, sizeof (wc)) ;
		wc.lpfnWndProc		= CSkkImeToolTipUIElement::_WndProc ;
		wc.hInstance		= g_hInst ;
		wc.lpszClassName	= CSkkImeToolTipUIElement::m_szClassName ;
		if (RegisterClass (&wc) == 0) {
			DWORD	dwError	= GetLastError () ;
			if (dwError != ERROR_CLASS_ALREADY_EXISTS) {
				DEBUGPRINTF ((TEXT ("CUIStatus::_RegisterClass (0x%lx) failed.\n"), dwError)) ;
				return	FALSE ;
			}
		}
		/*	tooltip Window ���쐬����B*/
		m_hWnd		= CreateWindowEx (WS_EX_TOOLWINDOW | WS_EX_TOPMOST, (LPTSTR) m_szClassName, NULL, 
				WS_DISABLED | WS_POPUP | WS_BORDER, 0, 0, 1, 1, NULL, NULL, g_hInst, this) ;
		if (m_hWnd == NULL || ! IsWindow (m_hWnd)) {
			return	FALSE ;
		}
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShown	= FALSE ;
	} else {
		/* console mode �ł� Window �����Ȃ��B*/
		m_hWnd		= NULL ;
		m_bShown	= FALSE ;
	}
	m_bConsole	= bConsole ;
	return	TRUE ;
}

void
CSkkImeToolTipUIElement::_Uninit ()
{
	if (m_hWnd != NULL) {
		if (IsWindow (m_hWnd))
			DestroyWindow (m_hWnd) ;
		m_hWnd	= NULL ;
	}
	m_bShown	= FALSE ;
	m_bOpen		= FALSE ;
	m_bConsole	= FALSE ;
	return ;
}

void
CSkkImeToolTipUIElement::_SetText (
	LPCDSTR			dstrText)
{
	if (dstrText == NULL || *dstrText == L'\0') {
		_Clear () ;
	} else {
		_SetText (dstrText, dcslen (dstrText)) ;
	}
	return ;
}

void
CSkkImeToolTipUIElement::_SetText (
	LPCDSTR			dstrText,
	UINT			nTextLen)
{
	int	nLength ;

	if (nTextLen <= 0 || dstrText == NULL) {
		_Clear () ;
		return ;
	}
	nLength	= dcstowcs (m_wszText, MYARRAYSIZE (m_wszText), dstrText, nTextLen) ;
	if (nLength >= MYARRAYSIZE (m_wszText)) {
		m_wszText [MYARRAYSIZE (m_wszText) - 1]	= L'\0' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 2]	= L'.' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 3]	= L'.' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 4]	= L'.' ;
	} else {
		m_wszText [nLength]	= L'\0' ;
	}

	/* Point ���ێ������܂܃T�C�Y��ύX����B*/
	if (m_bShown && m_hWnd != NULL && IsWindow (m_hWnd)) {
		RECT	rc ;
		if (! _AdjustWindowRect (&rc)) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShown	= FALSE ;
		} else {
			MoveWindow (m_hWnd, rc.left, rc.top, rc.right, rc.bottom, TRUE) ;
		}
	}
	return ;
}

void
CSkkImeToolTipUIElement::_SetText (
	LPCWSTR			wstrText)
{
	if (wstrText == NULL || *wstrText == L'\0') {
		_Clear () ;
	} else {
		_SetText (wstrText, lstrlenW (wstrText)) ;
	}
	return ;
}

void
CSkkImeToolTipUIElement::_SetText (
	LPCWSTR			wstrText,
	UINT			nTextLen)
{
	if (nTextLen <= 0 || wstrText == NULL) {
		_Clear () ;
		return ;
	}
	if (nTextLen >= MYARRAYSIZE (m_wszText)) {
#if __STDC_WANT_SECURE_LIB__
		wcsncpy_s (m_wszText, MYARRAYSIZE (m_wszText), wstrText, nTextLen) ;
#else
		wcsncpy (m_wszText, wstrText, MYARRAYSIZE (m_wszText) - 1 - 3) ;
#endif
		m_wszText [MYARRAYSIZE (m_wszText) - 1]	= L'\0' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 2]	= L'.' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 3]	= L'.' ;
		m_wszText [MYARRAYSIZE (m_wszText) - 4]	= L'.' ;
	} else {
#if __STDC_WANT_SECURE_LIB__
		wcsncpy_s (m_wszText, MYARRAYSIZE (m_wszText), wstrText, nTextLen) ;
#else
		wcsncpy (m_wszText, wstrText, nTextLen) ;
#endif
		m_wszText [nTextLen]	= L'\0' ;
	}

	/* Point ���ێ������܂܃T�C�Y��ύX����B*/
	if (m_bShown && m_hWnd != NULL && IsWindow (m_hWnd)) {
		RECT	rc ;
		if (! _AdjustWindowRect (&rc)) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShown	= FALSE ;
		} else {
			MoveWindow (m_hWnd, rc.left, rc.top, rc.right, rc.bottom, TRUE) ;
		}
	}
	return ;
}

void
CSkkImeToolTipUIElement::_Clear () 
{
	m_wszText [0]	= L'\0' ;
	if (m_bShown) {
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShown	= FALSE ;
	}
	return ;
}

BOOL
CSkkImeToolTipUIElement::_Open (
	DWORD			dwId,
	BOOL			bShow) 
{
	if (m_bOpen)
		return	FALSE ;

	m_dwElementId	= dwId ;
	m_bOpen			= TRUE ;
	if (bShow) {
		RECT	rc ;

		GetCursorPos (&m_ptLastCursor) ;
		if (! _AdjustWindowRect (&rc)) {
			ShowWindow (m_hWnd, SW_HIDE) ;
			m_bShown	= FALSE ;
		} else {
#if !defined (not_use_for_x_mouse)
			SetWindowPos (m_hWnd, HWND_TOPMOST, rc.left, rc.top, rc.right, rc.bottom, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOREDRAW | SWP_DEFERERASE | SWP_ASYNCWINDOWPOS) ;
#else
			MoveWindow (m_hWnd, rc.left, rc.top, rc.right, rc.bottom, TRUE) ;
#endif
			ShowWindow (m_hWnd, SW_SHOWNOACTIVATE) ;
			m_bShown	= TRUE ;
		}
	}
	return	TRUE ;
}

void
CSkkImeToolTipUIElement::_Update () 
{
	if (m_bShown) {
		if (m_hWnd != NULL && IsWindow (m_hWnd))
			InvalidateRect (m_hWnd, NULL, FALSE) ;
	}
	return ;
}

void
CSkkImeToolTipUIElement::_Close () 
{
	if (! m_bOpen)
		return ;

	if (m_bShown) {
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShown	= FALSE ;
	}
	m_bOpen	= FALSE ;
	return ;
}

BOOL
CSkkImeToolTipUIElement::_IsActivep (
	BOOL*		pbShown) const
{
	if (pbShown != NULL)
		*pbShown	= m_bShown ;
	return	m_bOpen ;
}

DWORD
CSkkImeToolTipUIElement::_GetUIElementId () const 
{
	return	m_dwElementId ;
}

BOOL
CSkkImeToolTipUIElement::_MoveWindow (int iX, int iY, int iWidth, int iHeight) 
{
	m_ptWnd.x	= iX ;
	m_ptWnd.y	= iY ;
	if (m_bShown && m_hWnd != NULL && IsWindow (m_hWnd)) {
		RECT	rc ;

		GetWindowRect (m_hWnd, &rc) ;
		MoveWindow (m_hWnd, iX, iY, rc.right - rc.left, rc.bottom - rc.top, TRUE) ;
	}
	return	TRUE ;
	UNREFERENCED_PARAMETER (iWidth) ;
	UNREFERENCED_PARAMETER (iHeight) ;
}

void
CSkkImeToolTipUIElement::_Popup (BOOL bFocus)
{
	if (m_bOpen && m_bShown && m_hWnd != NULL && IsWindow (m_hWnd)) {
		if (bFocus) {
#if !defined (not_use_for_x_mouse)
			SetWindowPos (m_hWnd, HWND_TOPMOST, 0, 0, 1, 1, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE | SWP_NOSENDCHANGING | SWP_NOREDRAW | SWP_DEFERERASE | SWP_ASYNCWINDOWPOS) ;
#endif
			ShowWindow (m_hWnd, SW_SHOWNOACTIVATE) ;
		} else {
			ShowWindow (m_hWnd, SW_HIDE) ;
		}
	}
	return ;
}

/*	Window Size �� Guess ����B
 */
BOOL
CSkkImeToolTipUIElement::_AdjustWindowRect (
	RECT*		prcDest)
{
	HDC		hDC ;
	SIZE	sz ;
	RECT	rcWork ;

	hDC		= GetDC (m_hWnd) ;
	sz.cx = sz.cy	= 0 ;
	if (hDC == NULL) 
		return	FALSE ;

	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, 0) ;

	if (GetTextExtentPoint32W (hDC, m_wszText, lstrlenW (m_wszText), &sz)) {
		sz.cx	+= GetSystemMetrics (SM_CXBORDER) * 2 ;
		sz.cy	+= GetSystemMetrics (SM_CYBORDER) * 2 ;
	}
	ReleaseDC (m_hWnd, hDC) ;

	if (prcDest != NULL) {
		POINT	pt, ptOffset, ptBase ;

		pt.x	= m_ptWnd.x ;
		pt.y	= m_ptWnd.y ;
		if (rcWork.right > 0) {
			ptOffset.x	= pt.x % rcWork.right ;
			if (ptOffset.x < 0)
				ptOffset.x	= rcWork.right + ptOffset.x ;
			ptBase.x	= pt.x - ptOffset.x ;
			if ((ptOffset.x + sz.cx) > rcWork.right){
				ptOffset.x	= rcWork.right - sz.cx ;
			if (ptOffset.x < 0)
				ptOffset.x	= 0 ;
			}
			pt.x		= ptBase.x + ptOffset.x ;
		}
		if (rcWork.bottom > 0) {
			ptOffset.y	= pt.y % rcWork.bottom ;
			if (ptOffset.y < 0)
				ptOffset.y	= rcWork.bottom + ptOffset.y ;
			ptBase.y	= pt.y - ptOffset.y ;
			if ((ptOffset.y + sz.cy) > rcWork.bottom){
				ptOffset.y = rcWork.bottom - sz.cy ;
			}
			if (ptOffset.y < 0)
				ptOffset.y	= 0 ;
			pt.y		= ptBase.y + ptOffset.y ;
		}
		prcDest->left	= pt.x ;
		prcDest->top	= pt.y ;
		prcDest->right	= sz.cx ;
		prcDest->bottom	= sz.cy ;
	}
	return	TRUE ;
}

LRESULT	CALLBACK
CSkkImeToolTipUIElement::_WndProc (
	HWND		hWnd,
	UINT		uMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMessage) {
	case	WM_CREATE:
		SetWindowLongPtr (hWnd, GWLP_USERDATA, (LONG_PTR)((CREATESTRUCT *)lParam)->lpCreateParams) ;
		return	0L ;

	case	WM_SETCURSOR:
		{
			CSkkImeToolTipUIElement*	pThis ;

			pThis	= reinterpret_cast <CSkkImeToolTipUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL)
				pThis->_OnSetCursor (wParam, lParam) ;
			return	0L ;
		}
	case	WM_PAINT:
		{
			CSkkImeToolTipUIElement*	pThis ;
			HDC			hDC ;
			PAINTSTRUCT	ps ;

			hDC		= BeginPaint (hWnd, &ps) ;
			pThis	= reinterpret_cast <CSkkImeToolTipUIElement*> (GetWindowLongPtr (hWnd, GWLP_USERDATA)) ;
			if (pThis != NULL) 
				pThis->_OnPaint (hDC) ;
			EndPaint (hWnd, &ps) ;
			return	0L ;
		}
	default:
		break ;
	}
	return	DefWindowProc (hWnd, uMessage, wParam, lParam) ;
}

void
CSkkImeToolTipUIElement::_OnPaint (
	HDC			hDC)
{
	TextOutW (hDC, 0, 0, m_wszText, lstrlenW (m_wszText)) ;
	return ;
}

LRESULT
CSkkImeToolTipUIElement::_OnSetCursor (
	WPARAM		wParam,
	LPARAM		lParam)
{
	POINT	ptCursor ;

	GetCursorPos (&ptCursor) ;
	if (ptCursor.x != m_ptLastCursor.x || ptCursor.y != m_ptLastCursor.y) {
		ShowWindow (m_hWnd, SW_HIDE) ;
		m_bShown	= FALSE ;
		if (m_pTSF != NULL) 
			(void) m_pTSF->_EndToolTipUI () ;
		m_bOpen	= FALSE ;
	}
	m_ptLastCursor.x	= ptCursor.x ;
	m_ptLastCursor.y	= ptCursor.y ;
	return	0L ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}




