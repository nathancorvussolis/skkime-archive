#pragma once

struct IMETEXTATTRIBUTE ;

class CUIStatus : public ITfTextLayoutSink
{
public:
	CUIStatus (CSkkImeTextService* pTSF, CSkkImeMgr* pIME) ;
	~CUIStatus () ;

    /* IUnknown methods	*/
    STDMETHODIMP QueryInterface (REFIID riid, void **ppvObj) ;
    STDMETHODIMP_(ULONG) AddRef (void) ;
    STDMETHODIMP_(ULONG) Release (void) ;

    /*	ITfTextLayoutSink */
    STDMETHODIMP	OnLayoutChange(ITfContext *pContext, TfLayoutCode lcode, ITfContextView *pContextView) ;

	HRESULT		_Open (ITfContext* pContextDocument, ITfRange* pRange) ;
	void		_Close () ;
	void		_Update () ;
	void		_Popup (BOOL fShow) ;
	BOOL		_IsContextStatusWindow (ITfContext* pContext) const ;
	BOOL		_IsActivep (ITfContext* pContext) const ;
	void		_SetTargetRect (const RECT* pRC) ;

private:
    HRESULT		_AdviseTextLayoutSink () ;
    HRESULT		_UnadviseTextLayoutSink () ;

	BOOL		_CreateWindow () ;
	void		_AdjustWindow (ITfContextView* pContextView) ;
#if defined (DEBUG) || defined (_DEBUG)
	void		_QueryWindowPos (ITfContextView* pContextView) ;
#endif
	void		_PaintUIStatusWnd (HWND hwnd, HDC hdc) ;
	BOOL		_Paint (HDC hdc) ;
	BOOL		_TextOut (HDC hdc, int nX, int nY, LPCWSTR wstr, int nwstr, int* pCursor, SIZE* pSZ) ;
	void		_RelayEventToTooltip (HWND hWnd, UINT uMessage) ;
	void		_Drag (UINT uMessage) ;
	int			_GetCursorPos (HDC hDC, LPCWSTR wstring, int nwstring, const POINT* lppoint) ;
	static	LRESULT	CALLBACK	_UIStatusWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) ;

	CSkkImeTextService*	_pTSF ;
	CSkkImeMgr*			_pIME ;
	ITfContext*			_pContext ;
	ITfRange*			_pRange ;
	DWORD				_dwCookieTextLayoutSink ;
	HWND				_hwnd ;
	HWND				_hwndTT ;
	RECT				_rcTarget ;
	BOOL				_bButtonPressed ;
	static const TCHAR	_szUIStatusWndClass [] ;

	LONG				_cRef ;
} ;



	
