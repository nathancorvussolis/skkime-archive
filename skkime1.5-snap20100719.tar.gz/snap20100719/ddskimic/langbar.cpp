#include "globals.h"
#include "skimic.h"
#include "skkimmgr.h"
#include "IME\ImeDoc.h"

#define	REGPATH_CICERO	L"Software\\TT\\Windows\\CurrentVersion\\SKKIME\\1.5\\CICERO"

/*	�L�[�{�[�h�{�^���� GUID�B���炭�͂��̒l�ň�ӂɌ��肷�锤�B
 */
const GUID	c_guidKeyboardItemButton	= {
	0x34745C63, 0xB2F0, 0x4784, { 0x8B, 0x67, 0x5E, 0x12, 0xC8, 0x70, 0x1A, 0x31 }
} ;

BOOL
CSkkImeTextService::_InitLangBarItem ()
{
#if WINVER >= 0x0600
	/*	Vista �� IME Icon �͕s�v�Ȃ悤���B
	 */
	if (! _InitCModeLangBarItem ()) {
		DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitLangBarItem () failed.\n"))) ;
		return	FALSE ;
	}
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_InitLangBarItem () succeeded.\n"))) ;
#else
	if (! _InitCModeLangBarItem () ||
		! _InitIMELangBarItem ())
		return	FALSE ;
#endif
	return	TRUE ;
}

void
CSkkImeTextService::_UninitLangBarItem ()
{
	DEBUGPRINTF ((TEXT ("CSkkImeTextService::_UninitLangBarItem ()\n"))) ;
#if WINVER >= 0x0600
	_UninitCModeLangBarItem () ;
#else
	_UninitCModeLangBarItem () ;
	_UninitIMELangBarItem () ;
#endif
	return ;
}

void
CSkkImeTextService::_UpdateLangBarItem (
	REFGUID			rguid)
{
#if WINVER >= 0x0600
	if (IsEqualGUID (rguid, c_guidConversionModeItemButton)) {
		_UpdateCModeLangBarItem () ;
	}
#else
	if (IsEqualGUID (rguid, c_guidConversionModeItemButton)) {
		_UpdateCModeLangBarItem () ;
	} else if (IsEqualGUID (rguid, c_guidToolItemButton)) {
		_UpdateIMELangBarItem () ;
	}
#endif
	return ;
}

void
CSkkImeTextService::_UpdateLangBarItem ()
{
	ITfLangBarItemMgr*				pLangBarItemMgr	= NULL ;
	ITfLangBarItem*					pItem ;
	//ITfSystemLangBarItem*			pSysItem ;

	if (m_pThreadMgr == NULL)
		return ;

	/*	�L�[�{�[�h�A�C�R���̕\���R���g���[���B*/
	if (m_pThreadMgr->QueryInterface (IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) != S_OK) 
		return ;

	if (pLangBarItemMgr->GetItem (c_guidKeyboardItemButton, &pItem) == S_OK) {
		if (_IsShowLangBarItem (REGKEY_SHOWKEYBRDICON)) {
			ITfSystemDeviceTypeLangBarItem*	pSysDevItem	= NULL ;
#if WINVER >= 0x0600
			ITfSystemLangBarItem*			pSysItem	= NULL ;
#endif
			if (SUCCEEDED (pItem->QueryInterface (IID_ITfSystemDeviceTypeLangBarItem, (void**)&pSysDevItem)) && pSysDevItem != NULL) {
#if WINVER >= 0x0600
				pSysDevItem->SetIconMode (TF_DTLBI_USEPROFILEICON) ;
#else
				pSysDevItem->SetIconMode (0) ;
#endif
				pSysDevItem->Release () ;
			}
			pItem->Show (TRUE) ;
		} else {
			pItem->Show (FALSE) ;
		}
		pItem->Release () ;
	}
	pLangBarItemMgr->Release () ;

	/*	�c��B*/
#if WINVER >= 0x0600
	_UpdateCModeLangBarItem () ;
#else
	_UpdateCModeLangBarItem () ;
	_UpdateIMELangBarItem () ;
#endif
	return ;
}

void
CSkkImeTextService::_SetConversionMode (int nMode)
{
	CImeDoc*	pDoc ;
	BOOL		fUpdate	= FALSE ;

	if (m_pSkkIme == NULL)
		return ;
	pDoc	= m_pSkkIme->GetDocument () ;
	if (pDoc == NULL)
		return ;

	if (! _IsKeyboardOpen ()) {
		if (SUCCEEDED (_SetKeyboardOpen (TRUE)))
			fUpdate	= TRUE ;
	}
	if (pDoc->bSetConversionMode (nMode)) 
		fUpdate	= TRUE ;
	if (fUpdate)
		_UpdateCModeLangBarItem () ;
	return ;
}

CSkkImeMgr*
CSkkImeTextService::_GetCurrentIME ()
{
	return	m_pSkkIme ;
}

void
CSkkImeTextService::_Menu_ToHiragana (
	CSkkImeTextService*		pSkkIme)
{
	pSkkIme->_SetConversionMode (IMECMODE_HIRAGANA) ;
	return ;
}

void
CSkkImeTextService::_Menu_ToZenkata (
	CSkkImeTextService*		pSkkIme)
{
	pSkkIme->_SetConversionMode (IMECMODE_KATAKANA) ;
	return ;
}

void
CSkkImeTextService::_Menu_ToZenei (
	CSkkImeTextService*		pSkkIme)
{
	pSkkIme->_SetConversionMode (IMECMODE_ZENKAKU) ;
	return ;
}

void
CSkkImeTextService::_Menu_ToJisx0201 (
	CSkkImeTextService*		pSkkIme)
{
	pSkkIme->_SetConversionMode (IMECMODE_HANKANA) ;
	return ;
}

void
CSkkImeTextService::_Menu_ToJisx0201Roman (
	CSkkImeTextService*		pSkkIme)
{
	pSkkIme->_SetConversionMode (IMECMODE_HANKANA_ROMAN) ;
	return ;
}

void
CSkkImeTextService::_Menu_ToHanei (
	CSkkImeTextService*		pSkkIme)
{
	pSkkIme->_SetConversionMode (IMECMODE_ASCII) ;
	return ;
}

void
CSkkImeTextService::_Menu_ToDirect (
	CSkkImeTextService*		pSkkIme)
{
	CSkkImeMgr*	pImeMgr ;
	BOOL		fUpdate	= FALSE ;

	pImeMgr	= pSkkIme->_GetCurrentIME () ;
	if (pImeMgr == NULL)
		return ;

	if (pSkkIme->_IsKeyboardOpen ()) {
		pSkkIme->_SetKeyboardOpen (FALSE) ;
		fUpdate	= TRUE ;
#if 0
		ITfDocumentMgr*	pFocusDoc	= NULL ;

		if (pSkkIme->m_pThreadMgr == NULL)
			return ;
		if (pSkkIme->m_pThreadMgr->GetFocus (&pFocusDoc) == S_OK) {
			ITfContext*	pContext	= NULL ;

			if (pFocusDoc->GetTop (&pContext) == S_OK) {
				pSkkIme->_TerminateCompositionInContext (pContext) ;
				pImeMgr->SetFilterMode (FALSE) ;
				fUpdate	= TRUE ;
			}
			pContext->Release () ;
		}
		pFocusDoc->Release () ;
#endif
	}
	if (fUpdate)
		pSkkIme->_UpdateCModeLangBarItem () ;
	return ;
}

DWORD
CSkkImeTextService::_Menu_GetNormalFlag (
	CSkkImeTextService*		pSkkIme)
{
	return 	(pSkkIme->_IsKeyboardDisabled ())? TF_LBMENUF_GRAYED : 0 ;
}

DWORD
CSkkImeTextService::_Menu_GetToggleKeyboardFlag (
	CSkkImeTextService*		pSkkIme)
{
	return	pSkkIme->_IsShowLangBarItem (REGKEY_SHOWKEYBRDICON)? TF_LBMENUF_CHECKED : 0 ;
}

void
CSkkImeTextService::_Menu_Help (
	CSkkImeTextService*		pThis)
{
	if (pThis == NULL)
		return ;
	/* Help ���Ăяo���̂����c�B*/
	return ;
}

void
CSkkImeTextService::_Menu_Property (
	CSkkImeTextService*		pThis)
{
	if (pThis == NULL)
		return ;
	pThis->Show (NULL, SKKIME_LANGID, c_guidSkkImeProfile) ;	/* ���̌Ăяo�����ŗǂ��̂��H */
	return ;
}

void
CSkkImeTextService::_Menu_Reconversion (
	CSkkImeTextService*		pSkkIme)
{
	if (pSkkIme == NULL)
		return ;
	/* reconversion �̐ݒ�͂ǂ��������̂��B*/
	return ;
}

void
CSkkImeTextService::_Menu_ToggleShowKeyboard (
	CSkkImeTextService*		pSkkIme)
{
	DWORD	dwValue, dwDisposition, dwRetval ;
	HKEY	hKey ;

	if (pSkkIme == NULL)
		return ;

	dwValue	= pSkkIme->_IsShowLangBarItem (REGKEY_SHOWKEYBRDICON)? 0L : 1L ;

	if (RegCreateKeyExW (HKEY_CURRENT_USER, REGPATH_CICERO, 0, 0, REG_OPTION_NON_VOLATILE, KEY_WRITE, 0, &hKey, &dwDisposition) != ERROR_SUCCESS)
		return ;
	dwRetval = RegSetValueExW (hKey, REGKEY_SHOWKEYBRDICON, 0, REG_DWORD, (CONST BYTE *)&dwValue, sizeof(DWORD)) ;
	RegCloseKey (hKey) ;
	if (dwRetval == ERROR_SUCCESS)
		pSkkIme->_UpdateLangBarItem () ;
	return ;
}

BOOL
CSkkImeTextService::_IsShowLangBarItem (
	LPCWSTR		wstrKey)
{
	HKEY		hSubKey ;
	LONG		lResult ;
	BOOL		fShow ;

	fShow	= TRUE ;
	lResult = RegOpenKeyExW (HKEY_CURRENT_USER, REGPATH_CICERO, 0, KEY_READ, &hSubKey) ;
	if (lResult == ERROR_SUCCESS) {
		DWORD			dwValue, cbData, dwType ;
		
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueExW (hSubKey, wstrKey, NULL, &dwType, (LPBYTE) &dwValue, &cbData) == ERROR_SUCCESS && dwType == REG_DWORD) 
			fShow = (dwValue != 0) ;
		RegCloseKey (hSubKey) ;
	}
	return	fShow ;
}


