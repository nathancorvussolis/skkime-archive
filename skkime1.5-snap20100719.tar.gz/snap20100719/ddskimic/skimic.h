#pragma once

class	CSkkImeMgr ;
class	CLangBarItemCModeButton ;
class	CLangBarItemIMEButton ;
class	CTReconvCandidateList ;

class	CSkkImeToolTipUIElement ;
class	CSkkImeCandidateListUIElement ;
#if defined (not_work)
class	CSkkImeReadingInfoUIElement ;
#endif
class	CImeConfig ;

/*	���̋y�ьp�����Ă��� class �͂����Ă���̂��H
 */
class	CSkkImeTextService : 
#if defined (__ITfTextInputProcessorEx_INTERFACE_DEFINED__)
							 public ITfTextInputProcessorEx,
#else
							 public ITfTextInputProcessor,
#endif
							 public ITfThreadMgrEventSink,
							 public ITfTextEditSink,
							 public ITfThreadFocusSink,
							 public ITfKeyEventSink,
							 public ITfFunctionProvider,
							 public ITfFnConfigure,
							 public	ITfFnConfigureRegisterWord,
							 public	ITfFnReconversion,
#if defined (not_work)
							 public	ITfFnPropertyUIStatus,
#endif
							 public ITfCompartmentEventSink,
							 public ITfDisplayAttributeProvider,
							 public ITfCompositionSink,
							 public	ITfCleanupContextDurationSink,
							 public ITfCleanupContextSink
{
public:
	CSkkImeTextService () ;
	~CSkkImeTextService () ;

    // IUnknown
    STDMETHODIMP QueryInterface (REFIID riid, void **ppvObj) ;
    STDMETHODIMP_(ULONG) AddRef (void) ;
    STDMETHODIMP_(ULONG) Release (void) ;

    // ITfTextInputProcessor
    STDMETHODIMP	Activate (ITfThreadMgr* pThreadMgr, TfClientId tfClientId) ;
    STDMETHODIMP	Deactivate () ;

	// ITfTextInputProcessorEx
    STDMETHODIMP	ActivateEx (ITfThreadMgr* pThreadMgr, TfClientId tfClientId, DWORD  dwFlags) ;

    // ITfThreadMgrEventSink
    STDMETHODIMP	OnInitDocumentMgr (ITfDocumentMgr* pDocMgr) ;
    STDMETHODIMP	OnUninitDocumentMgr (ITfDocumentMgr* pDocMgr) ;
    STDMETHODIMP	OnSetFocus (ITfDocumentMgr* pDocMgrFocus, ITfDocumentMgr* pDocMgrPrevFocus) ;
    STDMETHODIMP	OnPushContext (ITfContext* pContext);
    STDMETHODIMP	OnPopContext (ITfContext* pContext);

    // ITfThreadFocusSink
    STDMETHODIMP	OnSetThreadFocus () ;
    STDMETHODIMP	OnKillThreadFocus () ;

    // ITfTextEditSink
    STDMETHODIMP	OnEndEdit (ITfContext* pContext, TfEditCookie ecReadOnly, ITfEditRecord* pEditRecord) ;

    // ITfKeyEventSink
    STDMETHODIMP	OnSetFocus (BOOL fForeground) ;
    STDMETHODIMP	OnTestKeyDown (ITfContext *pContext, WPARAM wParam, LPARAM lParam, BOOL *pfEaten) ;
    STDMETHODIMP	OnKeyDown (ITfContext *pContext, WPARAM wParam, LPARAM lParam, BOOL *pfEaten) ;
    STDMETHODIMP	OnTestKeyUp (ITfContext *pContext, WPARAM wParam, LPARAM lParam, BOOL *pfEaten) ;
    STDMETHODIMP	OnKeyUp (ITfContext *pContext, WPARAM wParam, LPARAM lParam, BOOL *pfEaten) ;
    STDMETHODIMP	OnPreservedKey (ITfContext *pContext, REFGUID rguid, BOOL *pfEaten) ;

	// ITfFunctionProvider
	STDMETHODIMP	GetType (GUID* pguid) ;
	STDMETHODIMP	GetDescription (BSTR* pbstrDesc) ;
	STDMETHODIMP	GetFunction (REFGUID rguid, REFIID riid, IUnknown** ppunk) ;

	//	ITfFnConfigure
	STDMETHODIMP	Show (HWND hwndParent, LANGID langid, REFGUID rguidProfile) ;

	//	ITfFnConfigureRegisterWord
	STDMETHODIMP	Show (HWND hwndParent, LANGID langid, REFGUID rguidProfile, BSTR bstrRegistered) ;

	//	for reconversion
	STDMETHODIMP	QueryRange (ITfRange* pRange, ITfRange** ppNewRange, BOOL* pfConvertable) ;
	STDMETHODIMP	GetReconversion (ITfRange* pRange, ITfCandidateList** ppCandList) ;
	STDMETHODIMP	Reconvert (ITfRange* pRange) ;

	//	ITfFnPropertyUIStatus
#if defined (not_work)
	STDMETHODIMP	GetStatus (REFGUID refguidProp, DWORD* pdw) ;
	STDMETHODIMP	SetStatus (REFGUID refguidProp, DWORD  dw) ;
#endif

	//	ITfFuntion
	STDMETHODIMP	GetDisplayName (BSTR* pbstrName) ;

	//	ITfFDisplayAttributeProvider
	STDMETHODIMP	EnumDisplayAttributeInfo (IEnumTfDisplayAttributeInfo** ppEnum) ;
	STDMETHODIMP	GetDisplayAttributeInfo (REFGUID guid, ITfDisplayAttributeInfo** ppInfo) ;

    // ITfCleanupContextDurationSink
	STDMETHODIMP	OnStartCleanupContext () ;
	STDMETHODIMP	OnEndCleanupContext () ;

	//	ITfCleanupContextSink
	STDMETHODIMP	OnCleanupContext (TfEditCookie ecWrite, ITfContext* pic) ;

    // CClassFactory factory callback
    static HRESULT	CreateInstance(IUnknown *pUnkOuter, REFIID riid, void **ppvObj);

	//	ITfCompositionSink
	STDMETHODIMP	OnCompositionTerminated (TfEditCookie ecWrite, ITfComposition* pComposition) ;

	//	ITfComparetmentEventSink
	STDMETHODIMP	OnChange (REFGUID rguidCompartment) ;

    // server registration
    static BOOL		RegisterProfiles () ;
    static void		UnregisterProfiles () ;
    static BOOL		RegisterCategories (BOOL fRegister) ;
    static BOOL		RegisterServer () ;
    static void		UnregisterServer () ;

	// dialog procedures
	static INT_PTR	CALLBACK	_DialogProc_RegisterWord (HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) ;

    // language bar menu handlers
    static void		_Menu_ToHiragana		(CSkkImeTextService *_this) ;
    static void		_Menu_ToZenkata			(CSkkImeTextService *_this) ;
    static void		_Menu_ToZenei			(CSkkImeTextService *_this) ;
    static void		_Menu_ToJisx0201		(CSkkImeTextService *_this) ;
    static void		_Menu_ToJisx0201Roman	(CSkkImeTextService *_this) ;
    static void		_Menu_ToHanei			(CSkkImeTextService *_this) ;
    static void		_Menu_ToDirect			(CSkkImeTextService *_this) ;
	static void		_Menu_Help				(CSkkImeTextService *_this) ;
	static void		_Menu_Property			(CSkkImeTextService *_this) ;
	static void		_Menu_Reconversion		(CSkkImeTextService *_this) ;
	static void		_Menu_ToggleShowKeyboard	(CSkkImeTextService *_this) ;
	static DWORD	_Menu_GetNormalFlag			(CSkkImeTextService *_this) ;
	static DWORD	_Menu_GetToggleKeyboardFlag	(CSkkImeTextService *_this) ;
	void			_SetConversionMode		(int nMode) ;
	void			_UpdateLangBarItem		(REFGUID rguid) ;

	//	
	BOOL			_GetFocusWnd (HWND* phWnd) ;
	TfClientId		_GetClientId () ;
	CSkkImeMgr*		_GetCurrentIME () ;
	ITfThreadMgr*	_GetThreadMgr () ;
	HRESULT			_GetFocusContext (ITfContext** ppContext) ;
	CImeConfig*		_GetIMEConfig () { return m_pConfig ; }

	//	for composition
	BOOL			_StartComposition (ITfContext* pContext) ;
	void			_TerminateComposition (TfEditCookie ec) ;
	void			_TerminateCompositionInContext (ITfContext* pContext) ;
	void			_SetComposition (ITfComposition* pComposition) ;
	BOOL			_IsComposing (ITfComposition** ppComposition = NULL) ;
	void			_ClearCompositionDisplayAttributes (TfEditCookie ec) ;
	BOOL			_SetCompositionDisplayAttributes (TfEditCookie ec, ITfRange*, ITfRange*) ;

	BOOL			_IsKeyboardDisabled () ;
	BOOL			_IsKeyboardOpen () ;
	HRESULT			_SetKeyboardOpen (BOOL fOpen) ;
#if defined (TF_CONVERSIONMODE_NATIVE)
	HRESULT			_GetKeyboardInputModeConversion (unsigned int* piModeConversion) ;
	HRESULT			_SetKeyboardInputModeConversion (unsigned int iModeConversion) ;
#endif
#if defined (TF_SENTENCEMODE_NONE)
	HRESULT			_GetKeyboardInputModeSentence (unsigned int* piModeSentense) ;
	HRESULT			_SetKeyboardInputModeSentence (unsigned int iModeSentense) ;
#endif
	HRESULT			_SetThreadCompartment (REFGUID refguid, VARIANT* pValue) ;
	HRESULT			_GetThreadCompartment (REFGUID refguid, VARIANT* pValue) ;
	HRESULT			_SetContextCompartment (ITfContext* pContext, REFGUID refguid, VARIANT* pValue) ;
	HRESULT			_GetContextCompartment (ITfContext* pContext, REFGUID refguid, VARIANT* pValue) ;

	CSkkImeToolTipUIElement*		_GetToolTipUI () ;
	CSkkImeCandidateListUIElement*	_GetCandidateListUI () ;
	HRESULT			_BeginToolTipUI (DWORD* pdwToolTipId, BOOL* pbShow) ;
	HRESULT			_EndToolTipUI () ;
	HRESULT			_UpdateToolTipUI () ;
	HRESULT			_BeginCandidateListUI (DWORD* pdwToolTipId, BOOL* pbShow) ;
	HRESULT			_EndCandidateListUI () ;
	HRESULT			_UpdateCandidateListUI () ;
	HRESULT			_SyncComposition (ITfContext* pContext, BOOL fToggle, BOOL fCMode) ;

private:
	/* init methods */
    BOOL			_InitCleanupContextSink (ITfContext* pContext) ;
	BOOL			_InitTextEditSink (ITfDocumentMgr* pDocMgr) ;
	BOOL			_InitKeystrokeSink () ;
	BOOL			_InitPreservedKey () ;
	BOOL			_InitLangBarItem () ;
	BOOL			_InitCModeLangBarItem () ;
	BOOL			_InitIMELangBarItem () ;
	BOOL			_InitThreadMgrSink () ;
	BOOL			_InitSkkImeMgr () ;
	BOOL			_InitReconversion () ;
	BOOL			_InitFunctionProvider () ;
	BOOL			_InitThreadCompartment (ITfThreadMgr* pThreadMgr) ;
	BOOL			_InitDisplayAttributeGuidAtom () ;
	BOOL			_InitUIElements (DWORD dwFlags) ;
	BOOL			_InitConfig () ;
	BOOL			_RegisterImeOnKeys () ;
	BOOL			_RegisterImeOffKeys () ;
	void			_UnregisterImeOnKeys () ;
	void			_UnregisterImeOffKeys () ;

	/* uninit methods */
	void			_UninitCleanupContextSink (ITfContext* pContext) ;
	void			_UninitKeystrokeSink () ;
	void			_UninitPreservedKey () ;
	void			_UninitLangBarItem () ;
	void			_UninitCModeLangBarItem () ;
	void			_UninitIMELangBarItem () ;
	void			_UninitThreadMgrSink () ;
	void			_UninitSkkImeMgr () ;
	void			_UninitReconversion () ;
	void			_UninitFunctionProvider () ;
	void			_UninitThreadCompartment (ITfThreadMgr* pThreadMgr) ;
	void			_UninitUIElements () ;

	void			_UpdateLangBarItem () ;
	void			_UpdateCModeLangBarItem () ;
	BOOL			_IsShowLangBarItem (LPCWSTR wstrKey) ;
	void			_UpdateIMELangBarItem () ;

	HRESULT			_ToggleIME (ITfContext* pContext, HRESULT* phrEaten) ;
	HRESULT			_RestoreEditSession () ;

private:
    ITfThreadMgr*				m_pThreadMgr ;
    TfClientId					m_tfClientId ;
    CLangBarItemIMEButton*		m_pIMELangBarItem ;
    CLangBarItemCModeButton*	m_pCModeLangBarItem ;
    DWORD						m_dwThreadMgrEventSinkCookie ;
    DWORD						m_dwThreadFocusSinkCookie ;
    DWORD						m_dwTextEditSinkCookie ;
	DWORD						m_dwCompKeyboardOpenCloseCookie ;
	DWORD						m_dwCompKeyboardDisabledCookie ;
	DWORD						m_dwCompEmptyContextCookie ;
	DWORD						m_dwCompKeyboardInputModeConversionCookie ;
	DWORD						m_dwCompKeyboardInputModeSentenseCookie ;
    ITfContext*					m_pTextEditSinkContext ;
	ITfComposition*				m_pComposition ;
    LONG						m_cRef ;     // COM ref count
	CSkkImeMgr*					m_pSkkIme ;
	CTReconvCandidateList*		m_pRCandidateList ;
	BOOL						m_fCleaningUp ;
    TfGuidAtom					m_gaDisplayAttributeInput ;
    TfGuidAtom					m_gaDisplayAttributeConverted ;
	DWORD						m_dwActivateFlag ;

	/*static const GUID				_GUID_PRESERVEDKEY_TOGGLEIME ;
	  static const TF_PRESERVEDKEY	_ToggleImeKey ;*/
	CSkkImeToolTipUIElement*		m_pToolTipUIElement ;
	CSkkImeCandidateListUIElement*	m_pCandidateListUIElement ;
#if defined (not_work)
	CSkkImeReadingInfoUIElement*	m_pReadingInformationUIElement ;
#endif

	CImeConfig*					m_pConfig ;
} ;

#if defined (DEBUG) || defined (_DEBUG)
HRESULT	DumpCompartment (ITfCompartmentMgr* pMgr) ;
#endif

