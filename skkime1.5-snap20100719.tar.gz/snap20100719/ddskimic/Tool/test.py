import datetime

print datetime.date.today()
print datetime.date.today().strftime('%Y%m%d')

