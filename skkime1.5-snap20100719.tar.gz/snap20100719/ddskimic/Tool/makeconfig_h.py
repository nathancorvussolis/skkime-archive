#! ipy.exe
# -*- coding: utf-8 -*-
import os
import re
import sys

_PATTERN_GUID = re.compile(r'^EXTERN_C\s+const\s+GUID\s+([A-Za-z_]+);');

def main():
	msctf_path = ''.join([os.getenv('MSSdk'), '\\include\\msctf.h'])
	input_file = open(msctf_path, 'r')
	try:
		print '#ifndef DDSKIMIC_CONFIG_H'
		print '#define DDSKIMIC_CONFIG_H 1'
		for line in input_file:
			m = _PATTERN_GUID.match(line)
			if m:
				print '#define HAS_%s 1' % (m.group(1))
		print '#endif'
	finally:
		input_file.close()


if __name__ == '__main__':
    main()

