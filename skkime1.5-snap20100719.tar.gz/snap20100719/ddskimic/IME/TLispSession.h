#pragma once

#include "dchar.h"
#include "TCommuSession.h"

class CTLispSession : public CTCommunicateSession {
public:
	static	BOOL	bSetNumberList (LPCDSTR wstrNumberList) ;
	static	BOOL	bEval (LPCDSTR wstrHenkanKey, int nstrHenkanKey, LPDSTR wstrDest, int nstrDest) ;
} ;

