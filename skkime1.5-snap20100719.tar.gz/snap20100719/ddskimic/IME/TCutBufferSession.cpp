#if !defined (UNITTEST)
#include "globals.h"
#else
#include "StdAfx.h"
#endif
#include "TCutBufferSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
CTCutBufferSession::bSet (
	LPCDSTR		pwText,
	int			iTextLength,
	BOOL		bAppend) 
{
	CTPacket	packet ;
	HANDLE		hPipe ;
	int			nMajor, nMinor, nSize ;
	int			nRecv ;
	BOOL		fRetval	= FALSE ;

	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.bSetHeader  (SKKISERV_PROTO_SETCUTBUFFER, bAppend) ||
		! packet.bAddDString (pwText, iTextLength) ||
		! packet.bSetLength  () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! _bRecv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= packet.iGetDataSize () ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;
	fRetval	= (nMajor == SKKISERV_PROTO_SETCUTBUFFER_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

int
CTCutBufferSession::iGet (
	LPDSTR		pwBuffer,
	int			iBufferSize)
{
	CTPacket	packet ;
	DCHAR*		ptr		= pwBuffer ;
	HANDLE		hPipe ;
	LPCWSTR		pwResult ;
	int			nRecv, nResult ;
	int			nMajor, nMinor, nSize ;
	WORD		wTotalResult ;

	hPipe	= _hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	if (! packet.bSetHeader (SKKISERV_PROTO_GETCUTBUFFER, 0) ||
		! packet.bSetLength () ||
		! _bSend (hPipe, &packet))
		goto	exit_func ;

	if (! _bRecv (hPipe, &packet))
		goto	exit_func ;

	nRecv	= packet.iGetDataSize () ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! packet.bGetHeader (&nMajor, &nMinor, &nSize))
		goto	exit_func ;

	if (nMajor != SKKISERV_PROTO_GETCUTBUFFER_REPLY ||
		! packet.bGetCard16 (SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;

	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	pwResult	= (LPCWSTR)(packet.pGetData () + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	if (wTotalResult > 0) {
		LPDSTR		ptrEnd			= pwBuffer + iBufferSize ;
		int			nTotalResult	= wTotalResult ;
		int			n ;

		/*	����擾�����ʂ͂ǂ�����ATotal Size �𒴂��邱�Ƃ͂����Ă�
		 *	�Ȃ�Ȃ����B
		 */
		if (nResult > nTotalResult)
			nResult		= nTotalResult ;

		if (ptr < ptrEnd) {
			n	= wcstodcs_n (ptr, ptrEnd - ptr, pwResult, nResult) ;
			ptr	+= n ;
		}
		nTotalResult	-= nResult ;

		while (nTotalResult > 0 && ptr < ptrEnd) {
			if (! _bRecv (hPipe, &packet))
				break ;
			nRecv	= packet.iGetDataSize () ;
			if (nRecv < 0)
				break ;
			pwResult	= (LPCWSTR) packet.pGetData () ;
			nResult	= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;
			
			n				= wcstodcs_n (ptr, ptrEnd - ptr, pwResult, nResult) ;
			ptr				+= n ;
			nTotalResult	-= nResult ;
		}
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(ptr - pwBuffer) ;
}



