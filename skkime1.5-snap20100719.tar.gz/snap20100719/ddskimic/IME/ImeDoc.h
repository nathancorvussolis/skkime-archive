#pragma once

#include "dchar.h"
#include "TMSG.h"
#include "keymap.h"
#include "varbuffer.h"

/*=================================================================================
 *	definitions or typedefs for external usage
 */
/*
enum {
	GC_EGG_LIKE_NEWLINE	= 0,
	GC_DELETE_IMPLIES_KAKUTEI,
	GC_USE_NUMERIC_CONVERSION,
	GC_DABBREV_LIKE_COMPLETION,
	GC_KATAKANA_HIRAGANA_HENKAN,
	GC_STYLE,
	GC_DATE_AD,
	GC_SHOW_ANNOTATION,
	GC_KAKUTEI_EARLY,
	GC_PROCESS_OKURI_EARLY,
	GC_DELETE_OKURI_WHEN_QUIT,
	NUMGENERICCONFIG
} ;*/

enum {
	IMECMODE_HIRAGANA	= 0,
	IMECMODE_KATAKANA,
	IMECMODE_ZENKAKU,
	IMECMODE_HANKANA,
	IMECMODE_HANKANA_ROMAN,
	IMECMODE_ASCII,
	IMECMODE_OFF,
} ;

/* IMECANDIDATES �� style */
enum {
	IMECANDSTYLE_UNUSED		= -1,		/* ����������ĂȂ���ԁB*/
	IMECANDSTYLE_READ		= 0,		/* HenkanCandidates */
	IMECANDSTYLE_CODE0,					/* MenuJump */
	IMECANDSTYLE_CODE1,					/* Menu1 */
	IMECANDSTYLE_MINIBUFFERTEXT,		/* �ċA�ҏW���[�h�B*/
	IMECANDSTYLE_UNKNOWN,
} ;

enum {
	SKKUI_OPEN_CANDIDATELIST			= 1,
	SKKUI_UPDATE_CANDIDATE_SELECTION	= 2,
	SKKUI_UPDATE_CANDIDATE_PAGESTART	= 4,
	SKKUI_UPDATE_CANDIDATE_STRING		= 8,	/* ���g���ω������B*/
	SKKUI_UPDATE_CANDIDATE_PAGESIZE		= 16,	/* �y�[�W�T�C�Y���ω������B*/
	SKKUI_UPDATE_CANDIDATE_COUNT		= 32,	/* �y�[�W�T�C�Y���ω������B*/
	SKKUI_CLOSE_CANDIDATELIST			= 64,
} ;

/*	document ���̍X�V���B
 */
enum {
	IMEDOC_UPDATE_CURSOR			= 1 << 0,
	IMEDOC_UPDATE_COMPOSITIONSTRING	= 1 << 1,
	IMEDOC_UPDATE_RESULT			= 1 << 2,
	IMEDOC_UPDATE_UNPROCESSKEY		= 1 << 3,
	IMEDOC_CREATE_CANDIDATELIST		= 1 << 4,
	IMEDOC_UPDATE_CANDIDATELIST		= 1 << 5,
	IMEDOC_CLOSE_CANDIDATELIST		= 1 << 6,
	IMEDOC_UPDATE_CONVERSIONMODE	= 1 << 7,
	IMEDOC_CHECK_NEWLINE			= 1 << 8,
	IMEDOC_NEWLINE					= 1 << 9,
} ;

#define	WM_LM_COMMAND	(WM_USER+113)

/*================================================================
 */
#define	IMEDOC_COUNTHENKANSHOWCHANGE		4
#define	IMEDOC_NUMHENKANSHOWCANDIDATES		7
#define	IMEDOC_MAXCANDPAGESIZE				256

#define	MAX_MESSAGES		(16)
#define	MAXIMEBUFFER		(32)
#define	MAX_RETPC			(32)
#define	MSGBUFSIZE			(256)
#define	NSIZE_IMEDOC_STACK	(16384)
#define	NSIZE_REGSTACK		(64)

#define	MAX_LENGTH_ONE_ANNOTATION	(256)

/*================================================================
 */
class CImeBuffer ;
class CImeDoc ;
class CImeConfig ;

typedef int		(*PLMFUNC)(CImeDoc*) ;

/*================================================================
 */
enum {
	IMECANDUPDATE_SELECTION				= 1,
	IMECANDUPDATE_CURRENT_PAGE			= 2,
	IMECANDUPDATE_COUNT					= 4,
	IMECANDUPDATE_STRING				= 8,
	IMECANDUPDATE_PAGE_INDEX			= 16,
} ;

struct IMECANDIDATES {
	int			m_iStyle ;
	UINT		m_iCount ;			/* �P�ꑍ���B*/
	UINT		m_iSelection ;		/* dummy? */
	UINT		m_iCurrentPage ;
	CVarbuffer <DCHAR, 256>		m_vbufCandidate ;		/* �P��B */
	CVarbuffer <UINT, 128>		m_vbufCandidateIndex ;
	CVarbuffer <UINT, 128>		m_vbufAnnotationIndex ;
	CVarbuffer <UINT, 32>		m_vbufPageIndex ;
	DWORD		m_dwUpdate ;

public:
	IMECANDIDATES () : m_iStyle (IMECANDSTYLE_UNUSED), m_iCount (0), m_iSelection (0), m_iCurrentPage (0), m_dwUpdate (0) {
		return ;
	}

	virtual	~IMECANDIDATES () {
	}

	BOOL	bIsEnabledp () const {
		return	(m_iStyle != IMECANDSTYLE_UNUSED) ;
	}

	void	vClear () {
		m_vbufCandidate.vClear () ;
		m_vbufCandidateIndex.vClear () ;
		m_vbufAnnotationIndex.vClear () ;
		m_vbufPageIndex.vClear () ;
		m_iCount		= 0 ;
		m_iSelection	= 0 ;
		m_iCurrentPage	= 0 ;
		m_iStyle		= IMECANDSTYLE_UNUSED ;
		return ;
	}
} ;

struct TEXTREGION {
	int			m_nCandidate ;
	int			m_nOffset ;
	int			m_nLength ;
} ;

struct IMETEXTATTRIBUTE {
	DCHAR		m_wszWord [MAX_LENGTH_ONE_ANNOTATION] ;
	int			m_nWordLen ;
	int			m_nStartPos, m_nEndPos ;
} ;

/*================================================================
 *	ImeDoc �Ɋւ����`�B
 */
class CImeDoc {
public:
	/*================================================================
	 *	ImeDocument Machine �̓������W�X�^�Ɋւ����`�B
	 */
	enum {
		LMREGTYPE_BOOL,
		LMREGTYPE_NIL,
		LMREGTYPE_INTEGER,
		LMREGTYPE_POINTER,
		LMREGTYPE_CONST_POINTER,
		LMREGTYPE_STRING,
		LMREGTYPE_CONST_STRING,
		LMREGTYPE_STRINGPAIR,
		LMREGTYPE_CONST_STRINGPAIR,
		LMREGTYPE_MESSAGE,
	} ;
	enum {
		LMSIGNAL_NONE	= 0,
		LMSIGNAL_QUIT,
		LMSIGNAL_ERROR,
		LMSIGNAL_ABORT,
		LMSIGNAL_EXIT_MINIBUFFER,
		LMSIGNAL_ABORT_RECURSIVE_EDIT,
	} ;

	enum {
		LMR_STOP,
		LMR_CONTINUE,
		LMR_RETURN,
		LMR_ERROR,
	} ;

	enum {
		LMREG_0	= 0,	LMREG_1,	LMREG_2,	LMREG_3,	LMREG_4,	LMREG_5,	LMREG_6,	LMREG_7,
		LMREGARG_0,		LMREGARG_1,	LMREGARG_2,	LMREGARG_3,	LMREGARG_4,	LMREGARG_5,	LMREGARG_6,	LMREGARG_7,
		LMREGARG_RETVAL,
		MAX_REGS,
	} ;

private:
	struct LMREG {
		int			m_nType ;
		union {
			BOOL		m_bool ;
			int			m_integer ;
			void*		m_pointer ;
			const void*	m_const_pointer ;
			struct {
				LPDSTR	m_pointer ;
				int		m_length ;
			}			m_string ;
			struct {
				LPCDSTR	m_pointer ;
				int		m_length ;
			}			m_cstring ;
			struct {
				LPDSTR	m_left ;
				int		m_nleft ;
				LPDSTR	m_right ;
				int		m_nright ;
			}			m_stringpair ;
			struct {
				LPCDSTR	m_left ;
				int		m_nleft ;
				LPCDSTR	m_right ;
				int		m_nright ;
			}			m_cstringpair ;
			struct TMSG	m_msg ;
		}	m_value ;
	} ;

	struct CImeDocContext {
		PLMFUNC			m_pPC  ;
		PLMFUNC			m_rpRetPC [MAX_RETPC] ;
		int				m_nRetPC ;
		LPBYTE			m_pbStackArea ;
		int				m_nStackAreaSize ;
		int				m_rnStackPos [MAX_RETPC] ;
		int				m_nStackHead ;
		struct LMREG*	m_pRegStack ;
		int				m_nRegStackHead ;
		struct LMREG	m_rREGS [MAX_REGS] ;
		int				m_iThisCommand ;
		int				m_iLastCommand ;
		struct TMSG		m_LastEvent ;
		int				m_iLastCommandChar ;
		CImeBuffer*		m_rpBufferState [MAXIMEBUFFER] ;
		CImeBuffer*		m_rpBuffer [MAXIMEBUFFER] ;
		int				m_nBuffer ;
		CImeBuffer*		m_pCurBuffer ;
		PLMFUNC			m_pPreCommandHook ;
		PLMFUNC			m_pPostCommandHook ;
	} ;
private:
	/*		lisp machine
	 *
	 *	��{�I�Ɉ����͗^�����Ȃ��c�̂ŁADocument Class ����D���c�̂��B
	 */
	PLMFUNC			m_pPC  ;		/* ���s����֐��B*/
	PLMFUNC			m_rpRetPC [MAX_RETPC] ;	/* subroutine call �̏ꍇ�� return */
	int				m_nRetPC ;

	/*	call �������� m_nStackHead �̒l�� m_rnStackPos [m_nRetPC] �ɐς܂��B
	 *	LMR_RETURN �����t���āAm_pPC �����������Ɠ����� m_nStackHead ������
	 *	�����B
	 *	alignment �ɒ��ӁB
	 */
	LPBYTE			m_pbStackArea ;
	int				m_nStackAreaSize ;
	int				m_rnStackPos [MAX_RETPC] ;
	int				m_nStackHead ;

	struct LMREG*	m_pRegStack ;
	int				m_nRegStackHead ;

	/*	m_pPC ��J�ڂ��鎞�̈����n���ɗ��p����B���� call �Ŕj������Ă���\����
	 *	����̂Œ��ӁB�d�v�Ȃ��̂� stack �ɕۑ�����K�v����B
	 *
	 *	���[��AArg �n���ɂ� 8- �𗘗p����ƌ��߂邩�ȁc�B
	 */
	struct LMREG	m_rREGS [MAX_REGS] ;

	/*	return buffer
	 *	LMREGARG_RETVAL �H���̉����BLMREGARG_RETVAL �Ɠ����x�̊��Ԓ��x�����ێ�����
	 *	�Ȃ� LM_bXXX ���z���Ă̎󂯓n���̂��߂ɂ����g����̈�B
	 *	������Areturn ���Ė߂������͑����� my heap �� my stack �ɃR�s�[���ăf�[�^
	 *	��ی삵�Ȃ��Ƃ����Ȃ��B
	 *	return buffer �� document class ��1���������Ă���B
	 */
	DCHAR			m_bufRETURN [MSGBUFSIZE] ;

	/*		signals
	BOOL			m_bSigAbort ;
	BOOL			m_bSigQuit ;
	BOOL			m_bSigError ;
	BOOL			m_bSigAbortReEdit ;
	BOOL			m_bSigExitReEdit ;
	 */
	int				m_nSignal ;

	/*		events, mesages, commands, and so on
	 */
	struct TMSG		m_rMessages [MAX_MESSAGES] ;
	int				m_nUnreadMessages ;

	int				m_iThisCommand ;
	int				m_iLastCommand ;
	struct TMSG		m_LastEvent ;
	int				m_iLastCommandChar ;

	/*		buffers
	 */
	CImeBuffer*			m_rpBuffer [MAXIMEBUFFER] ;
	int					m_nBuffer ;
	CImeBuffer*			m_rpUnusedBuffer [MAXIMEBUFFER] ;
	int					m_nUnusedBuffer ;
	CImeBuffer*			m_pCurBuffer ;

	/*		subwindow messages
	 */
	DCHAR				m_bufMessage [MSGBUFSIZE] ;
	int					m_nbufMessage ;

	/*		hooks
	 */
	PLMFUNC				m_pPreCommandHook ;
	PLMFUNC				m_pPostCommandHook ;

	/*		�X�V���
	 */
	DWORD				m_dwUpdateFlag ;

	/*		FilterEvent ���Ăяo���ꂽ���A���ǂ� Filter ����邱�Ƃ̂Ȃ�����
	 *		Event ���~�ς����B
	 *		WM_NULL �� m_nMessage �ɐݒ肳��Ă���ꍇ�ɂ́AFilter ���ꂽ����
	 *		���Ӗ����Ă���B
	 *		FilterEvent ���Ăяo��������� WM_NULL �ŏ����������B
	 */
	struct TMSG			m_UnprocessEvent ;

	IMECANDIDATES		m_CandInfo ;
	IMECANDIDATES		m_MessageInfo ;

	CImeConfig*			m_pConfig ;

public:
	CImeDoc () ;
	virtual						~CImeDoc () ;

	virtual BOOL				bInit (CImeConfig* pConfig) ;
	virtual	void				vUninit () ;
	virtual	void				vClear (BOOL bFullClear = FALSE) ;
	virtual	LPCDSTR				pGetPreeditText (int* pnTextLen) ;
	virtual	BOOL				bGetPreeditCursor (int* pnCursorPos) const ;
#if !defined (UNITTEST)
	virtual	const IMECANDIDATES*	pGetStatusText () const ;
#else
	virtual	LPCDSTR				pGetStatusText (int* pnTextLen) ;
#endif
	virtual	BOOL				bGetStatusCursor (int* pnCursorPos) const ;
	virtual	BOOL				bIsStatusActivep () const ;
	virtual	BOOL				bQueryFilterEvent (const struct TMSG* pMsg, BOOL* pbFilter) ;
	virtual	BOOL				bFilterEvent (const struct TMSG* pMsg) ;

	virtual	BOOL				bQueryToggleIMEEvent (const struct TMSG* pMsg, BOOL* pbFilter) ;
	virtual	int					iGetReadingText (LPDSTR pwBuffer, int nBufferSize, int nCompPosition, int* pnReadingPosition) ;
	virtual	BOOL				bSetConversionMode	(int nMode) ;
	virtual	int					iGetConversionMode	() ;
	virtual	BOOL				bSetConversionString (LPCDSTR pwText, int nTextLen) ;
	virtual	BOOL				bGetSelectedRegion	(int*, int*) ;
	virtual	BOOL				bGetConvertedRegion	(int*, int*) ;
	virtual	BOOL				bQueryUpdateContext	(int*, int*, BOOL*) ;
	virtual	BOOL				bUpdateContext () ;
	virtual	void				vUpdateConfig () ;
	virtual	BOOL				bRevertText () ;
	virtual	BOOL				bCompleteText () ;
	virtual	void				vSetUpdateFlag (unsigned int) ;
	virtual	void				vClearUpdateFlag () ;
	virtual	unsigned int		uGetUpdateFlag () ;

	virtual	BOOL				bShowHenkanCandidatesModep () const ;
	virtual	BOOL				bInputByCodeOrMenuModep (BOOL*) const ;

	/*
	 */
	virtual	int					iGetCandidateText (LPDSTR pwDest, int nDest, TEXTREGION* pTextHead, int* piNumText, const IMECANDIDATES* pMyCand) ;
	virtual	int					iGetCodeMenuJumpText (LPDSTR pwDest, int nDest,  const IMECANDIDATES* pMyCand) ;
	virtual	int					iGetCodeMenu1Text (LPDSTR pwDest, int nDest,  const IMECANDIDATES* pMyCand) ;
	virtual	BOOL				bHaveMessagep () const ;
	virtual	LPCDSTR				pGetMessage (int* piLength) const ;

	/*	������ -> �p�ӂ��ׂ��O�� interface
	 */
	virtual BOOL				bSetReconvertText (LPCDSTR wstrText, int nTextLen) ;
	virtual	const struct TMSG*	pGetUnprocessEvent () ;

public:
	virtual	void				vSetCurrentBuffer (CImeBuffer*) ;
	virtual	CImeBuffer*			pGetCurrentBuffer () ;
	virtual	BOOL				bGetLastCommandChar (DCHAR*) ;
	virtual	BOOL				bSetMessage (LPCDSTR) ;
	virtual	BOOL				bSetMessage (LPCWSTR) ;
	virtual	BOOL				bSetMessageN (LPCDSTR, int) ;
	virtual	void				vClearMessage () ;
	virtual	BOOL				bRecursiveEditp () const ;

	virtual	BOOL				bIgnoreMessagep (const struct TMSG*) ;
	virtual	BOOL				bLookupKeymap (const struct TMSG*, int*) ;
	virtual	BOOL				bWhereIsInternal (int nFuncNo, struct TMSG*) ; 
	virtual	BOOL				bLookupMajorKeymap (const struct TMSG*, int*) ;
	virtual	PLMFUNC				pLookupLMState (int) ;
	virtual	int					iGetCharFromEvent (const struct TMSG*) ;
	virtual	int					iGetLastCommand	() const ;
	virtual	BOOL				bSetLastCommand	(int nCmd) ;
	virtual	int					iGetThisCommand	() const ;
	virtual	BOOL				bSetThisCommand	(int nCmd) ;
	virtual	int					iGetLastCommandChar	() ;
	virtual	BOOL				bSetLastCommandChar	(int) ;
	virtual	const struct TMSG*	pGetLastCommandEvent () const ;
	virtual	BOOL				bSetUnreadCommandChar(int) ; 
	virtual	BOOL				bSetUnreadCommandEvent (const struct TMSG*) ;
	virtual	BOOL				bEventToCharacter (const struct TMSG*, int*) ; 
	virtual	BOOL				bPushEvent (const struct TMSG*) ;
	virtual	BOOL				bProcessEventp () ;
	virtual	BOOL				bUnprocessEvent (const struct TMSG*) ;

	virtual BOOL				bSkkPreviousCandidateCharp	(int nCH) ;
	virtual	IMECANDIDATES*		pGetCandidateInfo () ;
	virtual	void				vClearCandidateInfo () ;

	virtual	CImeBuffer*			pCreateBuffer (LPCDSTR pwText, int nTextLen, BOOL bSkkModeOn) ;
	virtual	void				vDeleteUnusedBuffer	() ;
	virtual	BOOL				bDeleteBuffer (CImeBuffer*) ;

	virtual	CImeConfig*			pGetConfig () {	return m_pConfig ; }

	/*	state machine interfaces: private?
	 */
	virtual	BOOL				bSignalp () const ;
	virtual	void				vSetSignalError () ;
	virtual	BOOL				bSignalMinibuffp () const ;
	virtual	BOOL				bSignalAbortMinibuffp () const ;
	virtual	void				vClearSignals () ;
	virtual	int					nGetSignal () const ;
	virtual	void				vSetSignal (int iSigNum) ;
	virtual	BOOL				bCall (PLMFUNC, PLMFUNC) ;
	virtual	BOOL				bInteractivep () const ;
	virtual	void				vJump (PLMFUNC) ;
	virtual	void*				pAlloca (int, int) ;
	virtual	void				vSetRegString (int, LPDSTR, int) ;
	virtual	void				vSetRegConstString (int, LPCDSTR, int) ;
	virtual	void				vSetRegBool (int, BOOL) ;
	virtual	void				vSetRegInteger (int, int) ;
	virtual	void				vSetRegPointer (int, void*) ;
	virtual	void				vSetRegConstPointer	(int, const void*) ;
	virtual	void				vSetRegMsg (int, const struct TMSG*) ;
	virtual	void				vSetRegNil (int) ;
	virtual	BOOL				bGetRegBool (int, BOOL*) ;
	virtual	BOOL				bGetRegInteger (int, int*) ;
	virtual	BOOL				bGetRegString (int, LPDSTR*, int*) ;
	virtual	BOOL				bGetRegConstString (int, LPCDSTR*, int*) ;
	virtual	BOOL				bGetRegConstStringPair (int, LPCDSTR*, int*, LPCDSTR*, int*) ;
	virtual	BOOL				bGetRegPointer (int, void**) ;
	virtual	BOOL				bGetRegConstPointer	(int, const void**) ;
	virtual	BOOL				bGetRegMsg (int, struct TMSG*) ;
	virtual	BOOL				bIsRegNilp (int) const ;
	virtual	struct LMREG*		pGetRegValue (int nReg) ;
	virtual	BOOL				bPushReg (int) ;
	virtual	void				vPopReg (int) ;
	virtual	LPDSTR				pGetReturnBuffer (int*) ;
	virtual	int					iGetMinibufferDepth () const ;

private:
	BOOL		_bDefineMajorModeMap () ;
	BOOL		_bDefineSkkJModeMap () ;
	BOOL		_bDefineSkkLatinModeMap () ;
	BOOL		_bDefineSkkJisx0208LatinModeMap	() ;
	BOOL		_bDefineSkkAbbrevModeMap () ;

	CImeBuffer*	_pCreateBuffer (LPCDSTR pwString, int nStringLen) ;
	void		_vDeleteUnusedBuffer () ;
	BOOL		_bDeleteBuffer (CImeBuffer* pBuffer) ;

	BOOL		_bTick () ;
	BOOL		_bInitConfig () ;
	void		_vUninitConfig () ;

	BOOL		_bWhereIsInternal (const struct CImeKeymap*, int, struct TMSG*) ;
	BOOL		_bProcessFunctionp (int) ;
	BOOL		_bLookupKeymap (const struct CImeKeymap*, const struct TMSG*, int*) ;
	int			_iGetKeyMatchScore (unsigned int, unsigned int, unsigned int) ;

	BOOL		_bUpdateCandidateInfoForStatusText () ;

	BOOL		_bInitContextBuffer () ;
	void		_vUninitContextBuffer () ;
	BOOL		_bSaveContext () ;
	void		_vRestoreContext () ;
	BOOL		_bEmulateFilterEvent (const struct TMSG*, BOOL*) ;

	static	struct CImeDocContext	m_ContextBackup ;

private:
#include "LMState.h"

	BOOL		_bCreateSkkInputByCodeOrMenuJumpList (int n1, int n2, int nSkkCodeN1Min, int nSkkCodeN1Max, int nSkkCodeN2Min, int nSkkCodeN2Max, int nCodeMin, int nCodeMax) ;
	BOOL		_bCreateSkkInputByCodeOrMenu1List (int n1, int n2, int nSkkCodeN1Min, int nSkkCodeN1Max, int nSkkCodeN2Min, int nSkkCodeN2Max, int nCodeMin, int nCodeMax) ;
} ;

