#pragma once

#if !defined (DEBUGPRINTF)
#if defined (DEBUG) || defined (_DEBUG)
#define	DEBUGPRINTF(myformat)	DebugPrintf##myformat
#else
#define	DEBUGPRINTF(myformat)	/*myformat*/
#endif
#endif

void	DebugPrintf (LPCTSTR,...) ;
void	vDebugPrintfToFile (LPCTSTR,...) ;

