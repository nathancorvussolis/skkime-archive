#pragma once

#include "dchar.h"

class CSkkRuleTreeNode ;
class CSkkRuleTreeNodeOutput ;
class CImeBuffer ;
class CImeConfig ;

class CSkkRuleTreeIterator {
private:
	const CSkkRuleTreeNode*	m_pSkkRuleTree ;
	int		m_iTree ;
	DCHAR	m_bufPrefix [MAXLEN_PREFIX] ;
	int		m_nPrefixLength ;
	int		m_iPreviousSelectBranchChar ;

public:
	CSkkRuleTreeIterator () : m_pSkkRuleTree (NULL), m_nPrefixLength (0), m_iPreviousSelectBranchChar (0), m_iTree (0) {
		return ;
	}
	virtual	~CSkkRuleTreeIterator () {
		return ;
	}

	/*	m_pSkkCurrentRuleTree �̑���́A������ method �o�R�ōs����B
	 */
	void	vReset () ;


	/*	m_pSkkCurrentRuleTree �� Current-State �͌����Ȃ��BIterator ���ɊǗ�����
	 *	��B(���R�͓���L���� RuleTree �� State �L�q�Ɋ܂܂��悤�ɂȂ�������)
	 */
	const DCHAR*	pGetPrefix (int* pnLength) const ;
	BOOL			bHavePrefixp () const ;
	int				iGetRuleTree () const ;
	BOOL			bRootp (CImeConfig* pConfig) ;
	void			vMoveToRoot (CImeConfig* pConfig) ;
	void			vMoveTree (int iTree) ;
	BOOL			bHaveSelectBranchp (int wch) ;
	BOOL			bNextHasBranchListp (int wch) ;
	const CSkkRuleTreeNodeOutput*	pGetOutput () ;
	BOOL			bHaveNextState () ;
	int				iGetNextState (LPDSTR pwBuffer, int nBufferSize, int* pnNextTree) ;
	void			vWalk (int wch) ;
} ;

