/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * Config.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"
#include "winfile.h"
#include "prsht.h"
#include "resource.h"
#include "config.h"

/*
 *	Definitions
 */
#define MAX_PAGES			(6)

/*
 *	Prototypes
 */
static	long				addPageToSheet (LPPROPSHEETHEADER ppsh, DLGPROC pfn, LPVOID lpResource, LPMYDLGTEMPLATE lpMyDlgTempl, LPMYDLGITEMTEMPLATE lpMyDlgItemTempl) ;
static	LPWORD				lpwAlign (LPWORD lpIn) ;
static	long				CreateDialogTemplate (LPVOID lpBuffer, LPMYDLGTEMPLATE lpMyDlgTempl, LPMYDLGITEMTEMPLATE lpMyDlgItemTempl) ;
static	LRESULT				onRegWordDlgNotify (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				onRegWordDlgInitDialog (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				onAboutDlgNotify (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				onAboutDlgInitDialog (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				onGeneralDlgNotify (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				onGeneralDlgInitDialog (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				onGeneralDlgCommand (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				onDummyProcedure (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam) ;
static	BOOL	PASCAL		loadGenericSetting (HWND hwnd) ;
static	BOOL	PASCAL		saveGenericSetting (HWND hwnd) ;
static	BOOL	PASCAL		getConfigPath (LPTSTR lpPath, LPTSTR lpFileName) ;

/*************************************************************************
 *	ImeConfigure
 *		ImeConfigure �֐��� IME �ɑ΂��ĕ⑫�I�ȏ���v�����邽�߂Ɏg��
 *		Dialog Box ��񋟂���H
 *	BOOL
 *		ImeConfigure(
 *		HKL hKL,
 *		HWND hWnd,
 *		DWORD dwMode,
 *		LPVOID lpData
 *		)
 *	Parameters
 *		hKL
 *			���� IME �̓��͌���̃n���h���B
 *		hWnd
 *			�e Window �̃n���h���B
 *		dwMode
 *			Dialog �̃��[�h�B�ȉ��̂悤�ȃt���O���^������B
 *			IME_CONFIG_GENERAL			��� configuration �̂��߂� Dialog
 *			IME_CONFIG_REGWORD			�P��o�^�̂��߂� Dialog
 *			IME_CONFIG_SELECTDICTIONARY	IME �����I���̂��߂� Dialog
 *		lpData
 *			VOID �^�̃|�C���^�B���� dwMode == IME_CONFIG_REGISTERWORD �Ȃ�A
 *			REGISTERWORD �\���̂ւ̃|�C���^�ƂȂ�B�����Ȃ��Ζ��������B
 *			initial string ���^�����Ȃ�������AIME_CONFIG_REGISTER ���[�h
 *			�ł����Ă��ANULL �ł����Ă��܂�Ȃ��B
 *		Return Values
 *			���̊֐�������������ATRUE�B�����Ȃ��� FALSE�B
 *	Comments
 *		IME �͎��̂悤�ȋ[���R�[�h�ł����� lpData ���`�F�b�N����B
 *
 *	if (dwmode != IME_CONFIG_REGISTERWORD){
 *		// Does original execution
 *	} else if (IsBadReadPtr(lpdata, sizeof(REGISTERWORD))==FALSE){
 *		if (IsBadStringPtr(PREGISTERWORD(lpdata)->lpReading, (UINT)-1)==FALSE){
 *			// Set the reading string to word registering dialogbox
 *		}
 *		if (IsBadStringPtr(PREGISTERWORD(lpdata)->lpWord, (UINT)-1)==FALSE){
 *			// Set the word string to word registering dialogbox
 *		}
 *	}
 *************************************************************************/
BOOL	WINAPI	ImeConfigure (HKL hKL, HWND hWnd, DWORD dwMode, LPVOID lpData)
{
	HPROPSHEETPAGE	rPages [MAX_PAGES] ;
	PROPSHEETHEADER	psh ;
	LPWORD			lpwResource ;
	long			lUsage ;

#if 0
	DebugPrintf (MYTEXT("ImeConfigure ()")) ;
#endif
	lpwResource		= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, 2048) ;
	if (!lpwResource)
		return	FALSE ;

	psh.dwSize		= sizeof (psh) ;
	psh.dwFlags		= PSH_PROPTITLE ;
	psh.hwndParent	= hWnd ;
	/*
	 *	����l�Ƃ��Đݒ肵�����ɂ� hInst �̒l����낵�������炵���̂ŁA
	 *	hInstance �͐e Window ����Ⴄ���Ƃɂ���B
	 */
	psh.hInstance	= (HINSTANCE)GetWindowLong (hWnd, GWL_HINSTANCE) ;
	psh.pszIcon		= NULL ;
	psh.pszCaption	= _T("SKKIME98 ") ;
	psh.nPages		= 0 ;
	psh.nStartPage	= 0 ;
	psh.phpage		= rPages ;
	psh.pfnCallback	= 0 ;
	lUsage			= 0 ;
	switch (dwMode){
	case IME_CONFIG_GENERAL:
		lUsage	+= addPageToSheet (&psh, GeneralDlgProc, lpwResource + lUsage, &genericDlgTemplate, genericDlgItemTemplate) ;
		break ;
	case IME_CONFIG_REGISTERWORD:
		lUsage	+= addPageToSheet (&psh, RegWordDlgProc, lpwResource + lUsage, &regwordDlgTemplate, regwordDlgItemTemplate) ;
		break ;
	case IME_CONFIG_SELECTDICTIONARY:
		lUsage	+= addPageToSheet (&psh, GeneralDlgProc, lpwResource + lUsage, &genericDlgTemplate, genericDlgItemTemplate) ;
		break ;
	default:
		break ;
	}
#if 0
	DebugPrintf (MYTEXT ("PropertySheet ()")) ;
#endif
	if (psh.nPages > 0)
		PropertySheet (&psh) ;
#if 0
	DebugPrintf (MYTEXT ("Exit ImeConfigure ()")) ;
#endif
	HeapFree (GetProcessHeap (), 0, lpwResource) ;
	return	TRUE ;
}

/*************************************************************************
 *	addPageToSheet
 *		PropertySheet �Ɏw�肵���`���̃y�[�W��ǉ�����B
 *	long
 *		addPageToSheet (
 *		LPPROPSHEETHEADER	ppsh,
 *		DLGPROC				pfn,
 *		LPVOID				lpResource,
 *		LPMYDLGTEMPLATE		lpMyDlgTempl,
 *		LPMYDLGITEMTEMPLATE	lpMyDlgItemTempl
 *		)
 *	[�p�����[�^]
 *		ppsh
 *			PropertySheet 
 *		pfn
 *			�ǉ�����y�[�W�� Window Message ���������� DialogProc ��^����B
 *		lpResource
 *			Dialog Template ���i�[����o�b�t�@�BCreatePropertySheet ������
 *			�ɑS�Ă� Dialog Template �������Ă��Ȃ���΃G���[�ɂȂ�B
 *			CreatePropertySheetPage ��������������Ηǂ��̂ł͖����悤���B
 *		lpMyDlgTempl
 *			Dialog ���̂̏����`�����\���̂ւ̃|�C���^�B
 *			Resource Editor �œo�^���� Resource �� Windows logon ����N��
 *			�����Ă���Ə�肭�����Ȃ��̂ŁAHeap �̈�ɓƎ��̌`���ŕۑ�
 *			���Ă���B
 *		lpMyDlgItemTempl
 *			Dialog �̒��ɒ��荞�܂�� item ���`�����\���̂ւ̃|�C���^�B
 *	[�R�����g]
 *		Global �ϐ� hInst �� Instance Handle �Ƃ��Ďg���Ǝ��Ƃ��� Resource
 *		�������Ȃ�������AWindow �� foreground �Ɏ����ė��邱�Ƃ��ł���
 *		�������肷��B
 *		�d�����Ȃ��̂ŁAResource �����O�Ŏ����Ă����āA���̊֐��œǂݍ���
 *		�悤�ɂ��Ă���B
 *************************************************************************/
long	addPageToSheet (LPPROPSHEETHEADER ppsh, DLGPROC pfn, LPVOID lpResource, LPMYDLGTEMPLATE lpMyDlgTempl, LPMYDLGITEMTEMPLATE lpMyDlgItemTempl)
{
	PROPSHEETPAGE	psp ;
	long			lUsage ;
	/* �����̃`�F�b�N�B*/
	if (!ppsh || !pfn || !lpMyDlgTempl)
		return	0 ;
	if (ppsh->nPages >= MAX_PAGES)
		return	0 ;
	lUsage	= CreateDialogTemplate (lpResource, lpMyDlgTempl, lpMyDlgItemTempl) ;
	if (!lUsage)
		return	0 ;
	/* �v���p�e�B�V�[�g�Ƀy�[�W��ǉ�����B*/
	psp.dwSize		= sizeof (psp) ;
	psp.dwFlags		= PSP_DLGINDIRECT ;
	psp.hInstance	= ppsh->hInstance ; /* hInst */
	psp.pResource	= (LPDLGTEMPLATE)lpResource ;
	psp.pszIcon		= 0 ;
	psp.pfnDlgProc	= pfn ;
	psp.pfnCallback	= 0 ;
	psp.pszTitle	= 0 ;
	psp.lParam		= 0 ;
	ppsh->phpage [ppsh->nPages]	= CreatePropertySheetPage (&psp) ;
	if (ppsh->phpage [ppsh->nPages]){
		ppsh->nPages	++ ;
		return	lUsage ;
	}
	return	0 ;
}

/*************************************************************************
 *	lpwAlign
 *		�^����ꂽ�|�C���^�� DWORD ���E���m�ۂ���悤�ɏC������B
 *	LPWORD
 *		lpwAlign (
 *		LPWORD	lpIn
 *		)
 *	[�p�����[�^]
 *		lpIn
 *			DWORD ���E���m�ۂ����� WORD pointer�B(���{�ꂩ�H ����)
 *	[�Ԃ�l]
 *		DWORD ���E��ێ�����悤�C�����ꂽ pointer
 *	[�R�����g]
 *		Dialog Template �� DWORD ���E���ێ����Ȃ��Ƃ����Ȃ��̂ŁA���̊֐�
 *		���K�v�ɂȂ�B
 *		�ڍׂ� VC++ �t���̃w���v���Q�Ƃ̂��ƁB
 *************************************************************************/
LPWORD	lpwAlign (LPWORD lpIn)
{
    ULONG	ul ;
    ul	=   (ULONG) lpIn ;
    ul	+=  3 ;
    ul	>>= 2 ;
    ul	<<= 2 ;
    return	(LPWORD)ul ;
}

/*************************************************************************
 *	CreateDialogTemplate
 *		���O�� Resource ���� Windows �ɕ����� Dialog Template �̌`���ɕϊ�
 *		����B�ϊ����ʂ͑�1������ lpBuffer �Ɋi�[�����B
 *	long
 *		CreateDialogTemplate (
 *		LPVOID				lpBuffer,
 *		LPMYDLGTEMPLATE		lpMyDlgTempl,
 *		LPMYDLGITEMTEMPLATE	lpMyDlgItemTempl
 *		)
 *	[�p�����[�^]
 *		lpBuffer
 *			Windows �ɕ����� Dialog Template ���i�[����o�b�t�@�B
 *		lpMyDlgTempl
 *		lpMyDlgItemTempl
 *	[�Ԃ�l]
 *		Buffer �������[�h�g�������B
 *************************************************************************/
long	CreateDialogTemplate (LPVOID lpBuffer, LPMYDLGTEMPLATE lpMyDlgTempl, LPMYDLGITEMTEMPLATE lpMyDlgItemTempl)
{
    LPWORD				lpw ;
	int					i ;
	int					nChar ;

	if (!lpBuffer || !lpMyDlgTempl)
		return	0 ;

	/*
	 *	DLGTEMPLATE ����������B
	 */
	lpw			= (LPWORD)lpBuffer ;
	*lpw ++		= LOWORD (lpMyDlgTempl->style) ;
	*lpw ++		= HIWORD (lpMyDlgTempl->style) ;
	*lpw ++		= LOWORD (lpMyDlgTempl->dwExtendedStyle) ;
	*lpw ++		= HIWORD (lpMyDlgTempl->dwExtendedStyle) ;
	*lpw ++		= lpMyDlgTempl->cdit ;						/* �A�C�e���̐��B*/
	*lpw ++		= lpMyDlgTempl->x ;
	*lpw ++		= lpMyDlgTempl->y ;
	*lpw ++		= lpMyDlgTempl->cx ;
	*lpw ++		= lpMyDlgTempl->cy ;
    *lpw ++		= 0 ;				/* menu */
    *lpw ++		= 0 ;				/* class */
	if (!lpMyDlgTempl->title){
		nChar		= 1 ;
		*lpw		= (DWORD)0 ;
	} else {
		nChar		= lstrlenW (lpMyDlgTempl->title) + 1 ;
		memcpy (lpw, lpMyDlgTempl->title, sizeof (wchar_t) * nChar) ;
	}
	lpw			+= nChar ;
	if (lpMyDlgTempl->style & DS_SETFONT){
		*lpw ++		= lpMyDlgTempl->fontsize ;
		if (!lpMyDlgTempl->fontname){
			nChar		= 1 ;
			*lpw		= (DWORD)0 ;
		} else {
			nChar		= lstrlenW (lpMyDlgTempl->fontname) + 1 ;
			memcpy (lpw, lpMyDlgTempl->fontname, sizeof (wchar_t) * nChar) ;
		}
		lpw			+= nChar ;
	}

	/*
	 *	�ȉ��ADLGITEMTEMPLATE ����������B
	 */
	for (i = 0 ; i < lpMyDlgTempl->cdit ; i ++){
	    lpw			= lpwAlign (lpw) ;
		*lpw ++		= LOWORD (lpMyDlgItemTempl [i].style) ;
		*lpw ++		= HIWORD (lpMyDlgItemTempl [i].style) ;
		*lpw ++		= LOWORD (lpMyDlgItemTempl [i].dwExtendedStyle) ;
		*lpw ++		= HIWORD (lpMyDlgItemTempl [i].dwExtendedStyle) ;
		*lpw ++		= lpMyDlgItemTempl [i].x ;
		*lpw ++		= lpMyDlgItemTempl [i].y ;
		*lpw ++		= lpMyDlgItemTempl [i].cx ;
		*lpw ++		= lpMyDlgItemTempl [i].cy ;
		*lpw ++		= lpMyDlgItemTempl [i].id ;

		*lpw ++		= (WORD)0xFFFF ;
		*lpw ++		= (WORD)lpMyDlgItemTempl [i].class_id ;

		if (!lpMyDlgItemTempl [i].caption){
			nChar		= 1 ;
			*lpw		= (DWORD)0 ;
		} else {
			nChar		= lstrlenW (lpMyDlgItemTempl [i].caption) + 1 ;
			memcpy (lpw, lpMyDlgItemTempl [i].caption, sizeof (wchar_t) * nChar) ;
		}
		lpw			+= nChar ;
		*lpw ++		= 0 ;
	}
	return	(lpw - (LPWORD)lpBuffer) ;
}

/*
 *
 *	  RegWordConfigure ()
 *
 */
BOOL	CALLBACK	RegWordDlgProc (HWND hDlg, UINT message , WPARAM wParam, LPARAM lParam)
{
	static	MYMSGFUNCPAIR	msgFuncTbl []	= {
		{ WM_NOTIFY,		onRegWordDlgNotify, 	},
		{ WM_INITDIALOG,	onRegWordDlgInitDialog,	},
		{ WM_DESTROY,		onDummyProcedure		},
		{ WM_HELP,			onDummyProcedure		},
		{ WM_CONTEXTMENU,	onDummyProcedure		},
		{ WM_COMMAND,		onDummyProcedure		},
	} ;
	int						i ;
	for (i = 0 ; i < sizeof (msgFuncTbl) / sizeof (MYMSGFUNCPAIR) ; i ++){
		if (msgFuncTbl [i].m_uMsg == message)
			return	(msgFuncTbl [i].m_pFunction)(hDlg, message, wParam, lParam) ;
	}
	return	FALSE ;
} 

BOOL	CALLBACK	AboutDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static	MYMSGFUNCPAIR	msgFuncTbl []	= {
		{ WM_NOTIFY,		onAboutDlgNotify, 		},
		{ WM_INITDIALOG,	onAboutDlgInitDialog,	},
		{ WM_DESTROY,		onDummyProcedure		},
		{ WM_HELP,			onDummyProcedure		},
		{ WM_CONTEXTMENU,	onDummyProcedure		},
		{ WM_COMMAND,		onDummyProcedure		},
	} ;
	int						i ;
	for (i = 0 ; i < sizeof (msgFuncTbl) / sizeof (MYMSGFUNCPAIR) ; i ++){
		if (msgFuncTbl [i].m_uMsg == message)
			return	(msgFuncTbl [i].m_pFunction)(hDlg, message, wParam, lParam) ;
	}
	return	FALSE ;
} 

BOOL	CALLBACK	GeneralDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	static	MYMSGFUNCPAIR	msgFuncTbl []	= {
		{ WM_NOTIFY,		onGeneralDlgNotify, 	},
		{ WM_INITDIALOG,	onGeneralDlgInitDialog,	},
		{ WM_DESTROY,		onDummyProcedure		},
		{ WM_HELP,			onDummyProcedure		},
		{ WM_CONTEXTMENU,	onDummyProcedure		},
		{ WM_COMMAND,		onGeneralDlgCommand		},
	} ;
	int						i ;
	for (i = 0 ; i < sizeof (msgFuncTbl) / sizeof (MYMSGFUNCPAIR) ; i ++){
		if (msgFuncTbl [i].m_uMsg == message)
			return	(msgFuncTbl [i].m_pFunction)(hDlg, message, wParam, lParam) ;
	}
	return	FALSE ;
}

LRESULT	onRegWordDlgNotify (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	NMHDR FAR*		lpnm ;
	char			szRead [128] ;
	char			szString [128] ;
	char			szBuf [128] ;
	DWORD			dwIndex ;
	DWORD			dwStyle ;

	lpnm	= (NMHDR FAR *)lParam ;
	switch(lpnm->code){
	case	PSN_SETACTIVE:
	case	PSN_KILLACTIVE:
	case	PSN_RESET:
	case	PSN_HELP:
		break ;

	case	PSN_APPLY:
		if (!GetDlgItemText (hDlg, IDC_EDIT_READING, szRead, sizeof(szRead))){
			LoadString (hInst, IDS_NOREADING, szBuf, sizeof(szBuf)) ;
			MessageBox (hDlg, szBuf, NULL, MB_OK) ;
			return	FALSE ;
		}
		if (!GetDlgItemText (hDlg, IDC_EDIT_STRING, szString, sizeof(szString))){
			LoadString (hInst, IDS_NOSTRING, szBuf, sizeof(szBuf)) ;
			MessageBox (hDlg, szBuf, NULL, MB_OK) ;
			return	FALSE ;
		}
		dwIndex	= SendDlgItemMessage (hDlg, IDC_COMBO_STYLE, CB_GETCURSEL, 0, 0) ;
		dwStyle	= SendDlgItemMessage (hDlg, IDC_COMBO_STYLE, CB_GETITEMDATA, dwIndex, 0);
		if (!ImeRegisterWord (szRead, dwStyle, szString)){
			LoadString (hInst, IDS_REGWORDRET, szBuf, sizeof(szBuf)) ;
			MessageBox (hDlg, szBuf, NULL, MB_OK) ;
		}
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

LRESULT	onRegWordDlgInitDialog (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	LPPROPSHEETPAGE	lpPropSheet ;
	UINT			nItem ;
	UINT			i ;
	DWORD			dwIndex ;
	DWORD			dwStyle ;
	char			szBuf [128] ;

	SetWindowLong (hDlg, DWL_USER, lParam) ;
	lpPropSheet	= (LPPROPSHEETPAGE)lParam ;
	nItem		= ImeGetRegisterWordStyle (0, NULL) ;
	if (nItem){
		LPSTYLEBUF lpStyleBuf	= (LPSTYLEBUF)GlobalAlloc (GPTR, nItem * sizeof(STYLEBUF)) ;
		if (!lpStyleBuf){
			LoadString (hInst, IDS_NOMEMORY, szBuf, sizeof(szBuf)) ;
			MessageBox (hDlg, szBuf, NULL, MB_OK) ;
			return	TRUE ;
		}
		ImeGetRegisterWordStyle (nItem, lpStyleBuf) ;
		for (i = 0 ; i < nItem ; i++){
			dwIndex	= SendDlgItemMessage (hDlg, IDC_COMBO_STYLE, CB_ADDSTRING, 0, (LPARAM)lpStyleBuf->szDescription) ;
			SendDlgItemMessage (hDlg, IDC_COMBO_STYLE, CB_SETITEMDATA, dwIndex, lpStyleBuf->dwStyle) ;
			lpStyleBuf	++ ;
		}
		GlobalFree ((HANDLE)lpStyleBuf) ;
	}
	return	TRUE ;
}

LRESULT	onAboutDlgNotify (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	NMHDR FAR*		lpnm ;
	lpnm = (NMHDR FAR *)lParam;
	switch(lpnm->code){
	case	PSN_SETACTIVE:
	case	PSN_KILLACTIVE:
	case	PSN_APPLY:
	case	PSN_RESET:
	case	PSN_HELP:
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hDlg) ;
 	UNREFERENCED_PARAMETER (message) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	onAboutDlgInitDialog (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	LPPROPSHEETPAGE	lpPropSheet ;
	SetWindowLong(hDlg, DWL_USER, lParam) ;
	lpPropSheet	= (LPPROPSHEETPAGE)lParam ;
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hDlg) ;
 	UNREFERENCED_PARAMETER (message) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	onGeneralDlgNotify (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	NMHDR	FAR*	lpnm ;
	lpnm	= (NMHDR FAR *)lParam ;
	switch(lpnm->code){
	case PSN_SETACTIVE:
	case PSN_KILLACTIVE:
	case PSN_RESET:
	case PSN_HELP:
		break ;
		
	case PSN_APPLY:
		saveGenericSetting (hDlg) ;
		j_update_skkiserv () ;
		j_load_config (TRUE) ;
		break ;

	default:
		return FALSE ;
	}
	return	TRUE ;
}

LRESULT	onGeneralDlgInitDialog (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	LPPROPSHEETPAGE	lpPropSheet  ;
#if 0
	DebugPrintf (MYTEXT ("WM_INIT_DIALOG")) ;
#endif
	SetWindowLong (hDlg, DWL_USER, lParam) ;
	lpPropSheet	= (LPPROPSHEETPAGE)lParam ;
	loadGenericSetting (hDlg) ;
	(void)SetFocus (GetDlgItem (hDlg, IDC_EDIT_SKKIME_STARTUP)) ;
	return	FALSE ;
 	UNREFERENCED_PARAMETER (message) ;
 	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT	onGeneralDlgCommand (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	LPPROPSHEETPAGE	lpPropSheet = (LPPROPSHEETPAGE)(GetWindowLong (hDlg, DWL_USER)) ;
	WORD			wNotifyCode ;
	WORD			wID ;
	HWND			hwndCtl ;
	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;
#if 0
	DebugPrintf (MYTEXT ("onGeneralDlgCommand (hDlg:%lx, wNotifyCode:%lx, wID:%lx, hwndCtl:%lx)"), hDlg, wNotifyCode, wID, hwndCtl) ;
	DebugPrintf (MYTEXT ("IDC_EDIT: %lx, EN_CHANGE == %lx, GetCurrentPageHwnd == %lx"), GetDlgItem (hDlg, IDC_EDIT_SKKIME_STARTUP), EN_CHANGE, GetParent (hDlg)) ;
#endif
	if (hwndCtl == GetDlgItem (hDlg, IDC_EDIT_SKKIME_STARTUP) && wNotifyCode == EN_CHANGE)
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return TRUE ;
} 

LRESULT	onDummyProcedure (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hDlg) ;
 	UNREFERENCED_PARAMETER (message) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

/*
 *
 */
BOOL	PASCAL	loadGenericSetting (HWND hwnd)
{
	WINFILE			winfile ;
	TCHAR			szSettingFile [MAX_PATH + 1] ;
	long			lFileSize ;
	LPTSTR			lpText ;
	/* ���[�U�ݒ�t�@�C���̑��݂���p�X�𓾂�B*/
	if (!getConfigPath (szSettingFile, SKKIME98Conf_FILE))
		return	FALSE ;
	winfileinit (&winfile) ;
	/* ���[�U�ݒ�t�@�C�����J�����Ƃ��ł��邩�H */
	if (!winfopen (&winfile, szSettingFile, GENERIC_READ, OPEN_EXISTING)){
		SendDlgItemMessage (hwnd, IDC_EDIT_SKKIME_STARTUP, WM_SETTEXT, 0, (LPARAM)TEXT (";;\tuser setting")) ;
		return	TRUE ;
	}
	/* ���[�U�ݒ�t�@�C����ǂݍ��ށB*/
	winfseek (&winfile, 0, FILE_END) ;
	lFileSize	= winftell (&winfile) ;
	winrewind (&winfile) ;
	if (lFileSize > 0){
		lpText	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, lFileSize + 1) ;
		if (lpText){
			winfread (lpText, lFileSize, 1, &winfile) ;
			lpText [lFileSize]	= '\0' ;
			SendDlgItemMessage (hwnd, IDC_EDIT_SKKIME_STARTUP, WM_SETTEXT, 0, (LPARAM)lpText) ;
			/* SetDlgItemText (hwnd, IDC_EDIT_SKKIME_STARTUP, lpText) ; */
			HeapFree (GetProcessHeap (), 0, lpText) ;
		}
	}
	winfclose (&winfile) ;
	return	TRUE ;
}

/*
 *
 */
BOOL	PASCAL	saveGenericSetting (HWND hwnd)
{
	WINFILE			winfile ;
	TCHAR			szSettingFile [MAX_PATH + 1] ;
	long			lTextSize ;
	LPTSTR			lpText ;

	/* ���[�U�ݒ�t�@�C���̑��݂���p�X�𓾂�B*/
	if (!getConfigPath (szSettingFile, SKKIME98Conf_FILE))
		return	FALSE ;
	/* Edit Dialog ������͂��ꂽ�e�L�X�g�𓾂�B*/
	lTextSize	= GetWindowTextLength (GetDlgItem (hwnd, IDC_EDIT_SKKIME_STARTUP)) ;
	if (lTextSize > 0){
		lpText	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, lTextSize + 1) ;
		if (lpText){
			GetWindowText (GetDlgItem (hwnd, IDC_EDIT_SKKIME_STARTUP), lpText, lTextSize + 1) ;
		} else {
			lTextSize	= 0 ;
		}
	} else {
		lpText		= NULL ;
		lTextSize	= 0 ;
	}
	/* ���[�U�ݒ�t�@�C���ɏ����o���B*/
	winfileinit (&winfile) ;
	if (winfopen (&winfile, szSettingFile, GENERIC_WRITE, CREATE_ALWAYS)){
		if (lpText && lTextSize > 0)
			winfwrite (lpText, lTextSize, 1, &winfile) ;
		winfclose (&winfile) ;
	}
	if (lpText)
		HeapFree (GetProcessHeap (), 0, lpText) ;
	return	TRUE ;
}

/*
 *
 */
BOOL	PASCAL	getConfigPath (LPTSTR lpPath, LPTSTR lpFileName)
{
	int	iPathLength ;
	int	iFileNameLength ;
	if (!lpPath || !lpFileName)
		return	FALSE ;
	iPathLength	= GetWindowsDirectory (lpPath, MAX_PATH) ;
	if (iPathLength <= 0)
		return	FALSE ;
	iFileNameLength	= lstrlen (TEXT ("\\") PROGRAMF_DIR TEXT ("\\") SKKIME98Prog_S_DIR TEXT ("\\") SKKIME98Conf_DIR TEXT ("\\")) + lstrlen (lpFileName) ;
	if ((iPathLength + iFileNameLength) > MAX_PATH)
		return	FALSE ;
	lstrcat (lpPath, TEXT ("\\") PROGRAMF_DIR TEXT ("\\") SKKIME98Prog_S_DIR TEXT ("\\") SKKIME98Conf_DIR TEXT ("\\")) ;
	lstrcat	(lpPath, lpFileName) ;
	return	TRUE ;
}

