/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * quote.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "mylocale.h"
#include "skkiserv.h"
#include "mystring.h"
#include "charset.h"
#include "unicode.h"
#if defined (UNIT_TEST)
#include <tchar.h>
#include <stdio.h>
#include <locale.h>
#endif

static	int		j_quote_char_sub (LPMYSTR lpDest, LPMYSTR lpWord) ;

typedef struct _tagCHARSTRPAIR	{
	MYCHAR	m_chara ;
	LPMYSTR	m_lpString ;
}	CHARSTRPAIR, NEAR *PCHARSTRPAIR, FAR *LPCHARSTRPAIR ;

/*
 * ���̂܂܎����o�^����Ă��܂��Ƃ܂����l�B��ϊ�����֐��B
 *----
 */
LPMYSTR
j_quote_char (
	register LPMYSTR lpWord)
{
	LPMYSTR	lpQuotedWord ;
	LPMYSTR	lpSrc ;
	int		iLength ;

	if (!lpWord || !*lpWord)
		return	NULL ;

	if (*lpWord == MYTEXT ('(')){
		iLength	= Mylstrlen (lpWord) ;
		if (iLength > 2 &&
			((MYTEXT ('a') <= lpWord [1] && lpWord [1] <= MYTEXT ('z')) ||
			 (MYTEXT ('A') <= lpWord [1] && lpWord [1] <= MYTEXT ('Z'))) &&
			lpWord [iLength - 1] == MYTEXT (')'))
			return	NULL ;
	}

	/* �����ɏC�����Ȃ��Ƃ����Ȃ������������Ă��邩�ǂ����`�F�b�N����B*/
	lpSrc	= lpWord ;
	while (*lpSrc != MYTEXT ('\0')){
		if (0 <= *lpSrc && *lpSrc < 128){
			/* quote ���Ȃ���΂Ȃ�Ȃ����������t�������ۂ�? */
			if (*lpSrc == MYTEXT ('/') ||
				*lpSrc == MYTEXT ('\n') ||
				*lpSrc == MYTEXT ('\r') ||
				*lpSrc == MYTEXT ('\\') ||
				*lpSrc == MYTEXT ('[') ||
				*lpSrc == MYTEXT (']')){
				/* quote ����B*/
				iLength	= j_quote_char_sub (NULL, lpWord) ;
				if (iLength <= 0)
					return	NULL ;
				lpQuotedWord	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * iLength) ;
				if (!lpQuotedWord)
					return	NULL ;
				(void)j_quote_char_sub (lpQuotedWord, lpWord) ;
				return	lpQuotedWord ;
			}
		}
		lpSrc	++ ;
	}
	return	NULL ;
}

/*
 * ���̂܂܎����o�^����Ă��܂��Ƃ܂����l�B��ϊ�����֐��B
 *----
 * �̃T�u�����ǁB
 */
int
j_quote_char_sub (
	register LPMYSTR		lpDest,
	register LPMYSTR		lpWord)
{
	register LPMYSTR		lpsptr ;
	register int			iBufSize ;
	static CHARSTRPAIR	convpattern []	= {
		{ MYTEXT ('\r'),	MYTEXT ("\\r") },
		{ MYTEXT ('\n'),	MYTEXT ("\\n") },
		{ MYTEXT ('/'),		MYTEXT ("\\057") },
		{ MYTEXT ('\\'),	MYTEXT ("\\\\") },
		{ MYTEXT ('['),		MYTEXT ("\\133") },
		{ MYTEXT ('\"'),	MYTEXT ("\\\"") },
	} ;
	register LPCHARSTRPAIR	cptr ;
	register int			i, nLength ;
#if !defined(MIXED_UNICODE_ANSI) && !defined (UNICODE)
	register int			iLeadChar ;
	iLeadChar	= 0 ;
#endif
	/* �܂��͂��܂��Ȃ���p�ӂ���B*/
	iBufSize	= 0 ;
	if (lpDest != NULL){
		Mylstrcpy (lpDest, MYTEXT ("(concat \"")) ;
		iBufSize	= Mylstrlen (lpDest) ;
		lpDest		+= iBufSize ;
	} else {
		iBufSize	= Mylstrlen (MYTEXT ("(concat \"")) ;
	}
	lpsptr		= lpWord ;
	while (*lpsptr != MYTEXT ('\0')){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (0 <= *lpsptr && *lpsptr < 128){
			cptr	= convpattern ;
			i		= sizeof (convpattern) / sizeof (CHARSTRPAIR) ;
			while (i > 0){
				if (*lpsptr == cptr->m_chara)
					break ;
				cptr	++ ;
				i 		-- ;
			}
			if (i <= 0) {
				if (lpDest != NULL) 
					*lpDest	++	= *lpsptr ;
				iBufSize	++ ;
			} else {
				nLength		= Mylstrlen (cptr->m_lpString) ;
				if (lpDest != NULL) {
					Mylstrcpy (lpDest, cptr->m_lpString) ;
					lpDest		+= nLength ;
				}
				iBufSize	+= nLength ;
			}
		} else {
			if (lpDest != NULL) 
				*lpDest	++	= *lpsptr ;
			iBufSize	++ ;
		}
		lpsptr	++ ;
#else
		if (IsDBCSLeadByte (*lpsptr) && *(lpsptr + 1) != MYTEXT ('\0')) {
			if (lpDest != NULL) {
				*lpDest ++	= *lpsptr ++ ;
				*lpDest ++	= *lpsptr ++ ;
			} else {
				iBufSize	+= 2 ;
				lpsptr		+= 2 ;
			}
		} else {
			cptr	= convpattern ;
			i		= sizeof (convpattern) / sizeof (CHARSTRPAIR) ;
			while (i > 0){
				if (*lpsptr == cptr->m_chara)
					break ;
				cptr	++ ;
				i 		-- ;
			}
			if (i <= 0) {
				if (lpDest != NULL) 
					*lpDest	++	= *lpsptr ;
				iBufSize	++ ;
			} else {
				nLength		= Mylstrlen (cptr->m_lpString) ;
				if (lpDest != NULL) {
					Mylstrcpy (lpDest, cptr->m_lpString) ;
					lpDest		+= nLength ;
				}
				iBufSize	+= nLength ;
			}
			lpsptr		++ ;
		}
#endif
	}
	if (lpDest){
		*lpDest	++	= MYTEXT ('\"') ;
		*lpDest	++	= MYTEXT (')') ;
		*lpDest		= MYTEXT ('\0') ;
	}
	iBufSize	+= 3 ;
	return	iBufSize ;
}

#if defined (UNIT_TEST)
#if defined(MIXED_UNICODE_ANSI)
#define	Myprintf	wprintf
#define	Myfgets		fgetws
#else
#define	Myprintf	_tprintf
#define	Myfgets		_fgetts
#endif

int
_tmain (void)
{
	MYCHAR	szBuffer [1024] ;
	MYCHAR*	p ;
	int		n ;

	setlocale (LC_ALL, "japanese") ;

	while (! feof (stdin)) {
		Myprintf (MYTEXT ("> ")) ;
		fflush (stdout) ;
		if (Myfgets (szBuffer, 1024, stdin) == NULL)
			break ;
		n	= Mylstrlen (szBuffer) ;
		if (n > 0 && szBuffer [n - 1] == MYTEXT ('\n')) {
			szBuffer [n - 1]	= MYTEXT ('\0') ;
			n	-- ;
		}
		if (n <= 0)
			continue ;
		p	= j_quote_char (szBuffer) ;
		if (p != NULL) {
			Myprintf (MYTEXT ("converted: \"%s\"\n"), p) ;
			HeapFree (GetProcessHeap (), 0, p) ;
		} else {
			Myprintf (MYTEXT ("original:  \"%s\"\n"), szBuffer) ;
		}
	}
	return	0 ;
}

#endif

