/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * lispeval.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#ifdef DEBUG
#include <stdio.h>
#endif
#include "windows.h"
#include "tchar.h"
#include "mylocale.h"
#include "skkiserv.h"
#include "jisyo.h"
#include "uirecord.h"
#include "skkserver.h"
#include "lisp.h"
#include "charset.h"
#include "mystring.h"
#include "keymap.h"
#include "unicode.h"

/*
 *	�v���g�^�C�v�錾�B
 */

/*
 *	���ϐ��B
 */
static	SKKLISPENV	skkinputlispGlobalEnvironment ;

/*
 *	interface functions prototypes
 */
static	long			skkiserv_AssocRomKanaSub (LPMYSTR lpBuffer, int iSize, LPMYSTR lpPrefix, LPMYSTR lpVarName, BOOL fKatakana) ;
static	LPLISTBUFFER	skk_search_car (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, BOOL FAR* lpfKakutei, LPSKKLISPENTITY lpSearchEntity) ;
static	LPLISTBUFFER	j_search_jisyo_file (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, LPSKKLISPENTITY lpSearchEntity) ;
static	LPLISTBUFFER	j_search_kakutei_jisyo_file (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, BOOL FAR* lpfKakutei, LPSKKLISPENTITY lpSearchEntity) ;
static	LPLISTBUFFER	j_search_server (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, LPSKKLISPENTITY lpSearchEntity) ;
static	int				skkiserv_GetSymbolFunction2Number (LPSKKLISPENTITY lpEntity) ;
static	BOOL			skkiserv_String2Color (LPCMYSTR lpString, LPBYTE lpBuffer) ;
static	BOOL			skkiserv_Array2Color (LPSKKLISPENTITY lpEntity, LPBYTE lpBuffer) ;

/*
 *	external functions
 */
extern	BOOL		j_date_ad (LPMYSTR lpStr, int iBufSize, int iDateAd, int iNumberStyle) ;

/*
 *	Global Functions	-- �������� -- �������� -- �������� -- �������� -- 
 */

/*
 *	Lisp ���ߎ��s�̂��߂̑��ϐ���(�����ϐ�)����������֐��B
 *----
 *	�N�����ɕK�����͓ǂ�łق����B������Ăяo���O�� eval ���Ȃ����ƁB
 */
BOOL	skkiserv_LispInit  (void)
{
	/* Global ���̏������B*/
	skkinputlispGlobalEnvironment.m_lpVariableListTop	= NULL ;
	skkinputlispGlobalEnvironment.m_lpFunctionListTop	= NULL ;
	skkinputlispGlobalEnvironment.m_lpPrevious			= NULL ;
	skkinputlispGlobalEnvironment.m_lpNext				= NULL ;
	/* Entity List �̏������B*/
	skkinputlisp_InitEntity () ;
	return	TRUE ;
}

/*
 *	Lisp �����������֐��B
 *----
 *	WM_DESTROY ����O�ɂ�������ƌĂяo���Ăق����Ǝv���܂��ł��B
 */
BOOL	skkiserv_LispClear (void)
{
	/* Global ���̉���B*/
	skkinputlisp_DestroyEnvironment (skkinputlispGlobalEnvironment.m_lpNext) ;
	skkinputlisp_DestroyVariables (&skkinputlispGlobalEnvironment) ;
	skkinputlisp_DestroyFunctions (&skkinputlispGlobalEnvironment) ;
	/* Entity List �̉���B*/
	skkinputlisp_ClearAllEntities () ;
	return	TRUE ;
}

BOOL	skkiserv_eval (LPCMYSTR lpString, LPMYSTR lpBuffer, int iBufSize)
{
	LPSKKLISPENTITY	lpEntity ;
	BOOL			fRetValue ;
	lpEntity		= skkinputlisp_String2Entity (lpString) ;
	if (!lpEntity)
		return	FALSE ;
	lpEntity		= skkinputlisp_EvalEntity (lpEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity)
		return	FALSE ;
	/* ������łȂ���΂Ȃ�Ȃ��B*/
	if (lpEntity->m_iType == ENTITY_STRING){
		if (!lpEntity->m_data.m_lpString){
			if (lpBuffer && iBufSize > 0)
				*lpBuffer	= MYTEXT ('\0') ;
		} else {
			if (lpBuffer && iBufSize > 0){
				Mylstrncpy (lpBuffer, lpEntity->m_data.m_lpString, iBufSize) ;
				lpBuffer [iBufSize - 1]	= MYTEXT ('\0') ;
			}
		}
		fRetValue	= TRUE ;
	} else {
		fRetValue	= FALSE ;
	}
	return	fRetValue ;
}

LPSKKLISPENTITY	skkiserv_weakeval (LPCMYSTR lpString)
{
	LPSKKLISPENTITY	lpEntity ;
	lpEntity		= skkinputlisp_String2Entity (lpString) ;
	if (!lpEntity)
		return	NULL ;
	return	skkinputlisp_EvalEntity (lpEntity, &skkinputlispGlobalEnvironment) ;
}

/*
 * j-num-list �ɐ��l�ϊ��̎��̒l������֐��B
 *----
 * j-num-list �ɓ������Ă��܂��Ă��܂��c�B���������֐����K�v���Ǝv����
 * ���āc�B
 */
BOOL	create_j_num_list (LPMYSTR lpString)
{
	LPSKKLISPENTITY	lpEntity ;
	LPMYSTR			lpNewJNumString ;
	LPMYSTR			lpptr ;
	int				iLength ;
	int				iCounter ;
#if !defined(MIXED_UNICODE_ANSI) && !defined (UNICODE)
	int				iPreviousCharacter ;
#endif
	BOOL			fRetValue ;

	if (!lpString)
		return	FALSE ;

	iLength				= 0 ;
	iCounter			= 0 ;
#if !defined(MIXED_UNICODE_ANSI) && !defined (UNICODE)
	iPreviousCharacter	= MYTEXT ('\0') ;
#endif
	for (lpptr = lpString ; *lpptr != MYTEXT ('\0') ; lpptr ++){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (*lpptr == MYTEXT ('/'))
			iCounter	++ ;
#else
		if (iPreviousCharacter){
			iPreviousCharacter	= MYTEXT ('\0') ;
		} else {
			if (IsDBCSLeadByte (*lpptr)){
				iPreviousCharacter	= *lpptr ;
			} else {
				if (*lpptr == MYTEXT ('/'))
					iCounter	++ ;
			}	
		}
#endif
		iLength	++ ;
	}
	if (iCounter <= 0 || iLength <= 0)
		return	TRUE ;

	lpNewJNumString	= HeapAlloc (GetProcessHeap (), 0, sizeof (MYCHAR) * (iLength + iCounter * 2 + 30)) ;
	if (!lpNewJNumString)
		return	FALSE ;
	Mylstrcpy (lpNewJNumString, MYTEXT ("(setq j-num-list (quote (")) ;
	lpptr				= lpNewJNumString + 25 ;
#if !defined(MIXED_UNICODE_ANSI) && !defined (UNICODE)
	iPreviousCharacter	= MYTEXT ('\0') ;
#endif
	while (*lpString){
		*lpptr ++	= MYTEXT ('\x22') ;
		while (*lpString){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (*lpString == MYTEXT ('/'))
				break ;
			*lpptr ++	= *lpString ++ ;
#else
			if (iPreviousCharacter){
				*lpptr	++	= (char)iPreviousCharacter ;
				*lpptr	++	= *lpString ;
				iPreviousCharacter	= MYTEXT ('\0') ;
			} else {
				if (IsDBCSLeadByte (*lpString)){
					iPreviousCharacter	= *lpString	;
				} else {
					if (*lpString == MYTEXT ('/'))
						break ;
					*lpptr	++	= *lpString ;
				}
			}
			lpString	++ ;
#endif 
		}
		if (*lpString == MYTEXT ('/'))
			lpString	++ ;
		*lpptr	++	= MYTEXT ('\x22') ;
		*lpptr	++	= MYTEXT (' ') ;
	}
	*lpptr	++	= MYTEXT (')') ;
	*lpptr	++	= MYTEXT (')') ;
	*lpptr	++	= MYTEXT (')') ;
	*lpptr	++	= MYTEXT ('\0') ;

	lpEntity	= skkinputlisp_String2Entity (lpNewJNumString) ;
	if (!lpEntity)
		return	FALSE ;
	lpEntity	= skkinputlisp_EvalEntity (lpEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity)
		return	FALSE ;
	fRetValue	= (!lpEntity) ;
	HeapFree (GetProcessHeap (), 0, lpNewJNumString) ;
	skkinputlisp_GarbageCollection () ;
	return	fRetValue ;
}

BOOL	j_prefix_check (LPMYSTR lpPrefix)
{
	LPSKKLISPVAR	lpVarNode ;
	LPSKKLISPENTITY	lpEntity ;
	LPSKKLISPENTITY	lpLeftEntity;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (MYTEXT ("skk-prefix-list"), &skkinputlispGlobalEnvironment) ;
	if (!lpVarNode)
		return	FALSE ;
	lpEntity	= lpVarNode->m_lpValue ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpLeftEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (lpLeftEntity->m_iType == ENTITY_STRING &&
			lpLeftEntity->m_data.m_lpString &&
			!Mylstrcmp (lpPrefix, (LPMYSTR)lpLeftEntity->m_data.m_lpString))
			return	TRUE ;
		lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	FALSE ;
}

BOOL	skkiserv_GetInputVector (LPMYSTR lpBuffer, int iBufSize, MYCHAR chara)
{
	LPSKKLISPVAR			lpVarNode ;
	LPSKKLISPENTITY			lpEntity ;
	LPSKKLISPENTITY FAR*	lpEntityPtr ;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (MYTEXT ("skk-input-vector"), &skkinputlispGlobalEnvironment) ;
	if (!lpVarNode)
		return	FALSE ;
	lpEntity	= lpVarNode->m_lpValue ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_ARRAY)
		return	FALSE ;
	if (chara < 0 || chara >= lpEntity->m_data.m_array.m_iLength)
		return	FALSE ;
	lpEntityPtr	= lpEntity->m_data.m_array.m_lpArray ;
	lpEntity	= lpEntityPtr [(int)chara] ;
	if (lpEntity->m_iType != ENTITY_STRING)
		return	FALSE ;
	Mylstrncpy (lpBuffer, lpEntity->m_data.m_lpString, iBufSize) ;
	return	TRUE ;
}

BOOL	skkiserv_GetZenkakuVector (LPMYSTR lpBuffer, int iBufSize, MYCHAR chara)
{
	LPSKKLISPVAR			lpVarNode ;
	LPSKKLISPENTITY			lpEntity ;
	LPSKKLISPENTITY FAR*	lpEntityPtr ;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (MYTEXT ("skk-zenkaku-vector"), &skkinputlispGlobalEnvironment) ;
	if (!lpVarNode)
		return	FALSE ;
	lpEntity	= lpVarNode->m_lpValue ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_ARRAY)
		return	FALSE ;
	if (chara < 0 || chara >= lpEntity->m_data.m_array.m_iLength)
		return	FALSE ;
	lpEntityPtr	= lpEntity->m_data.m_array.m_lpArray ;
	lpEntity	= lpEntityPtr [(int)chara] ;
	if (lpEntity->m_iType != ENTITY_STRING)
		return	FALSE ;
	Mylstrncpy (lpBuffer, lpEntity->m_data.m_lpString, iBufSize) ;
	return	TRUE ;
}

BOOL	skkiserv_GetZenkakuAlist (LPMYSTR lpBuffer, int iBufSize, MYCHAR chara)
{
	LPSKKLISPVAR			lpVarNode ;
	LPSKKLISPENTITY			lpEntity ;
	LPSKKLISPENTITY			lpAlistNode ;
	LPSKKLISPENTITY			lpAlistLeft ;
	LPSKKLISPENTITY			lpAlistRight ;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (MYTEXT ("j-zenkaku-alist"), &skkinputlispGlobalEnvironment) ;
	if (!lpVarNode)
		return	FALSE ;
	lpEntity	= lpVarNode->m_lpValue ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		/* car */
		lpAlistNode	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (lpAlistNode && lpAlistNode->m_iType == ENTITY_CONS){
			lpAlistLeft	= lpAlistNode->m_data.m_conspair.m_lpLeftEntity ;
			if (lpAlistLeft &&
				lpAlistLeft->m_iType == ENTITY_INTEGER &&
				lpAlistLeft->m_data.m_integer == chara){
				lpAlistRight	= lpAlistNode->m_data.m_conspair.m_lpRightEntity ;
				if (lpAlistRight &&
					lpAlistRight->m_iType == ENTITY_STRING &&
					lpAlistRight->m_data.m_lpString){
					Mylstrncpy (lpBuffer, lpAlistRight->m_data.m_lpString, iBufSize) ;
				} else {
					*lpBuffer	= MYTEXT ('\0') ;
				}
				return	TRUE ;
			}
		}
		/* cdr */
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	FALSE ;
 	UNREFERENCED_PARAMETER (iBufSize) ;
}

BOOL	skkiserv_RomKanaRule (LPVOID lpBuffer, int iBufSize, LPMYSTR lpPrefix)
{
	LPMYSTR			lpptr ;
	LPMYSTR			lpString ;
	LPSKKLISPVAR	lpVarNode ;
	LPSKKLISPENTITY	lpEntity ;
	LPSKKLISPENTITY	lpCarEntity ;
	LPSKKLISPENTITY	lpCaarEntity ;
	int				i ;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (MYTEXT ("skk-rom-kana-rule-list"), &skkinputlispGlobalEnvironment) ;
	if (!lpVarNode)
		return	FALSE ;
	lpEntity	= lpVarNode->m_lpValue ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		/* car */
		lpCarEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (lpCarEntity &&
			lpCarEntity->m_iType == ENTITY_CONS){
			lpCaarEntity	= lpCarEntity->m_data.m_conspair.m_lpLeftEntity ;
			if (lpCaarEntity &&
				lpCaarEntity->m_iType == ENTITY_STRING &&
				lpCaarEntity->m_data.m_lpString &&
				!Mylstrcmp (lpCaarEntity->m_data.m_lpString, lpPrefix)){
				/* Found */	
				lpptr	= (LPMYSTR)((LPDWORD)lpBuffer + 4) ;
				i		= 0 ;
				while (i < 2){
					lpCaarEntity	= lpCarEntity->m_data.m_conspair.m_lpLeftEntity ;
					if (!lpCaarEntity)
						return	FALSE ;
					if (lpCaarEntity->m_iType != ENTITY_STRING){
						lpString	= NULL ;
					} else {
						lpString	= lpCaarEntity->m_data.m_lpString ;
					}
					if (!lpString || !*lpString){
						*lpptr						= MYTEXT ('\0') ;
						*((LPDWORD)lpBuffer + i)	= (LPSTR)lpptr - (LPSTR)lpBuffer ;
						lpptr						++ ;
					} else {
						Mylstrcpy (lpptr, lpString) ;
						*((LPDWORD)lpBuffer + i)	= (LPSTR)lpptr - (LPSTR)lpBuffer ;
						lpptr						+= Mylstrlen (lpptr) + 1 ;
					}
					lpCarEntity	= lpCarEntity->m_data.m_conspair.m_lpRightEntity ;
					if (!lpCarEntity || lpCarEntity->m_iType != ENTITY_CONS)
						return	FALSE ;
					i ++ ;
				}
				lpCarEntity	= lpCarEntity->m_data.m_conspair.m_lpLeftEntity ;
				if (!lpCarEntity || lpCarEntity->m_iType != ENTITY_CONS)
					return	FALSE ;
				lpCaarEntity	= lpCarEntity->m_data.m_conspair.m_lpLeftEntity ;
				if (!lpCaarEntity)
					return	FALSE ;
				if (lpCaarEntity->m_iType != ENTITY_STRING){
					lpString	= NULL ;
				} else {
					lpString	= lpCaarEntity->m_data.m_lpString ;
				}
				if (!lpString || !*lpString){
					*lpptr						= MYTEXT ('\0') ;
					*((LPDWORD)lpBuffer + i)	= (LPSTR)lpptr - (LPSTR)lpBuffer ;
					lpptr						++ ;
				} else {
					Mylstrcpy (lpptr, lpString) ;
					*((LPDWORD)lpBuffer + i)	= (LPSTR)lpptr - (LPSTR)lpBuffer ;
					lpptr						+= Mylstrlen (lpptr) + 1 ;
				}
				i ++ ;

				lpCaarEntity	= lpCarEntity->m_data.m_conspair.m_lpRightEntity ;
				if (!lpCaarEntity)
					return	FALSE ;
				if (lpCaarEntity->m_iType != ENTITY_STRING){
					lpString	= NULL ;
				} else {
					lpString	= lpCaarEntity->m_data.m_lpString ;
				}
				if (!lpString || !*lpString){
					*lpptr						= MYTEXT ('\0') ;
					*((LPDWORD)lpBuffer + i)	= (LPSTR)lpptr - (LPSTR)lpBuffer ;
					lpptr						++ ;
				} else {
					Mylstrcpy (lpptr, lpString) ;
					*((LPDWORD)lpBuffer + i)	= (LPSTR)lpptr - (LPSTR)lpBuffer ;
					lpptr						+= Mylstrlen (lpptr) + 1 ;
				}
				return	TRUE ;
			}
		}
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	FALSE ;
}

/*
 *	���[�}�����ȕϊ��e�[�u�����Ђ��֐��B
 *(����)
 *	lpBuffer	�ϊ����ʂ�����o�b�t�@
 *	iSize		�o�b�t�@�̑傫��
 *	lpPrefix	���[�}��
 *	chTable		�V���ɓ��͂��ꂽ�A���t�@�x�b�g
 *	fKatakana	�J�^�J�i���̓��[�h���ۂ�
 */
long	skkiserv_AssocRomKana (LPMYSTR lpBuffer, int iSize, LPMYSTR lpPrefix, MYCHAR chTable, BOOL fKatakana)
{
	LPMYSTR	lpTable ;
	long	lRetvalue ;
	switch (chTable){
	case MYTEXT ('a'):
		lpTable	= MYTEXT ("skk-roma-kana-a") ;
		break ;
	case MYTEXT ('i'):
		lpTable	= MYTEXT ("skk-roma-kana-i") ;
		break ;
	case MYTEXT ('u'):
		lpTable	= MYTEXT ("skk-roma-kana-u") ;
		break ;
	case MYTEXT ('e'):
		lpTable	= MYTEXT ("skk-roma-kana-e") ;
		break ;
	case MYTEXT ('o'):
		lpTable	= MYTEXT ("skk-roma-kana-o") ;
		break ;
	default:
		return	-1 ;
	}
	lRetvalue	= skkiserv_AssocRomKanaSub (lpBuffer, iSize, lpPrefix, lpTable, fKatakana) ;
	if (!lRetvalue){
		(void)skkiserv_AssocRomKanaSub (lpBuffer, iSize, NULL, lpTable, fKatakana) ;
	}
	return	lRetvalue ;
}

/*
 *	�^����ꂽ�ǂ݁i�H�j�Ŏ�������������֐��B
 *	LPLISTBUFFER	�������ʂ��i�[���郊�X�g
 *	lpHenkanKey		�����L�[
 */
LPLISTBUFFER	skk_search (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, BOOL FAR* lpfKakutei)
{
	LPSKKLISPVAR	lpVarNode ;
	LPSKKLISPENTITY	lpEntity ;
	BOOL			fKakutei ;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (MYTEXT ("skk-search-prog-list"), &skkinputlispGlobalEnvironment) ;
	if (!lpVarNode)
		return	lpListBuffer ;
	lpEntity	= lpVarNode->m_lpValue ;
	fKakutei	= FALSE ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpListBuffer	= skk_search_car (lpListBuffer, lpHenkanKey, fOkuri, &fKakutei, lpEntity->m_data.m_conspair.m_lpLeftEntity) ;
		if (fKakutei)
			break ;
		lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;		
	}
	if (lpfKakutei)
		*lpfKakutei		= fKakutei ;
	return	lpListBuffer ;
}

/*
 *	�����ɗ^����ꂽ���O�̕ϐ��̂��l�� nil ���ǂ������肷��֐��B
 *	nil �Ȃ�� TRUE ��Ԃ��B
 */
BOOL	skkiserv_variable_nilp (LPMYSTR lpVariableName)
{
	LPSKKLISPENTITY	lpEntity ;
	BOOL			fRetvalue ;
	fRetvalue	= TRUE ;
	lpEntity	= skkinputlisp_String2Entity (lpVariableName) ;
	if (!lpEntity)
		return	fRetvalue ;
	lpEntity	= skkinputlisp_EvalEntity (lpEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity)
		return	fRetvalue ;
	return	skkinputlisp_IsNil (lpEntity)? TRUE : FALSE ;
}

int		skkiserv_GetKeymap (LPMYSTR lpKeymapName, LPINT lpResult)
{
	SKKLISPENTITY			tmpEntity ;
	LPSKKLISPENTITY			lpEntity ;
	LPSKKLISPENTITY	FAR*	lpArray ;
	int						iLength ;
	int						i ;
	if (!lpKeymapName || !*lpKeymapName)
		return	-1 ;
	tmpEntity.m_iType			= ENTITY_ATOM ;
	tmpEntity.m_data.m_lpString	= lpKeymapName ;
	lpEntity	= skkinputlisp_EvalEntity (&tmpEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity || !skkinputlisp_IsKeymap (lpEntity))
		return	-1 ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	-1 ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_ARRAY)
		return	-1 ;
	iLength		= lpEntity->m_data.m_array.m_iLength ;
	lpArray		= lpEntity->m_data.m_array.m_lpArray ;
	for (i = 0 ; i < iLength ; i ++)
		*lpResult ++	= skkiserv_GetSymbolFunction2Number (lpArray [i]) ;
	return	iLength ;
}

int		skkiserv_GetProcessmap (LPMYSTR lpProcessmapName, LPBYTE lpResult)
{
	SKKLISPENTITY			tmpEntity ;
	LPSKKLISPENTITY			lpEntity ;
	LPSKKLISPENTITY	FAR*	lpArray ;
	int						iLength ;
	int						i ;
	if (!lpProcessmapName || !*lpProcessmapName)
		return	-1 ;
	tmpEntity.m_iType			= ENTITY_ATOM ;
	tmpEntity.m_data.m_lpString	= lpProcessmapName ;
	lpEntity	= skkinputlisp_EvalEntity (&tmpEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity)
		return	-1 ;
	if (skkinputlisp_IsNil (lpEntity))
		return	0 ;
	if (lpEntity->m_iType != ENTITY_ARRAY)
		return	-1 ;
	iLength		= lpEntity->m_data.m_array.m_iLength ;
	lpArray		= lpEntity->m_data.m_array.m_lpArray ;
	for (i = 0 ; i < iLength ; i ++)
		*lpResult ++	= skkinputlisp_IsNil (lpArray [i])? 0 : 1 ;
	return	iLength ;
}

/*
 *
 */
BOOL	skkiserv_LoadFile (LPTSTR lpPath)
{
	WINFILE			winfile ;
	LPMYSTR			lpstart ;
	LPMYSTR			lpptr ;
	long			lFileSize ;
	int				cc ;
	BOOL			fRetvalue ;
	int				iLeadChar ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	unsigned short	c1, c2 ;
#endif
	if (!lpPath)
		return	FALSE ;
	winfileinit (&winfile) ;
	if (!winfopen (&winfile, lpPath, GENERIC_READ, OPEN_EXISTING))
		return	FALSE ;
	winfseek (&winfile, 0, FILE_END) ;
	lFileSize	= winftell (&winfile) ;
	winrewind (&winfile) ;
	if (lFileSize <= 0){
		winfclose (&winfile) ;
		return	FALSE ;
	}
	lpstart	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * (lFileSize + 8 + 1)) ;
	if (!lpstart){
		winfclose (&winfile) ;
		return	FALSE ;
	}
	Mylstrcpy (lpstart, MYTEXT ("(progn ")) ;
	lpptr		= lpstart + 7 ;
	iLeadChar	= '\0' ;
	while ((cc = winfgetc (&winfile)) != EOF){
		if (iLeadChar){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			c1	= iLeadChar ;
			c2	= cc & 0x00FF ;
			c1	= (char)((c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1) ;
			c2	= (char)(c2 -  ((c2 >= 0x80)? 0x20 : 0x1F)) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			*lpptr ++	= UNICODE_JISX0208 (((c1 & 0xFF) << 8) | (c2 & 0xFF)) ;
#else
			*lpptr ++	= (MYCHAR)iLeadChar ;
			*lpptr ++	= (MYCHAR)cc ;
#endif
			iLeadChar	= '\0' ;
		} else {
			if (IsDBCSLeadByte ((char)cc)){
				iLeadChar	= cc & 0x00FF ;
			} else {
				if (cc == _T(';')){
					while (1){
						cc = winfgetc (&winfile) ;
						if (cc == EOF)
							break ;
						if (IsDBCSLeadByte ((char)cc)){
							if (winfgetc (&winfile) == EOF)
								break ;
						} else {
							if (cc == _T('\n') || cc == _T('\r'))
								break ;
						}
					}
				} else {
					switch (cc){
					case _T('\n') :
					case _T('\r') :
						cc	= _T('\x20') ;
					default:
						*lpptr ++	= (MYCHAR)cc ;
						break ;
					}
				}
			}
		}
	}
	*lpptr	++	= MYTEXT (')') ;
	*lpptr		= MYTEXT ('\0') ;
	winfclose (&winfile) ;
	fRetvalue	= (!skkiserv_eval (lpstart, NULL, 0))? FALSE : TRUE ;
	HeapFree (GetProcessHeap (), 0, lpstart) ;
	/* Garbage Collector ���N��������B�d�����낤��...*/
	skkinputlisp_GarbageCollection () ;
	return	fRetvalue ;
}

int		skkiserv_GetConfig (LPBYTE lpBuffer)
{
	/* ���̕ϐ��̒l�����Ԃ� buffer �ɏ�������ł����B���� ad hoc �Ȋ֐��������肷��B*/
	LPMYSTR	lpVariableNames [] = {
		MYTEXT ("skk-egg-like-newline"),
		MYTEXT ("skk-delete-implies-kakutei"),
		MYTEXT ("skk-use-numeric-conversion"),
		MYTEXT ("skk-date-ad"),
		MYTEXT ("skk-number-style"),
		MYTEXT ("skk-dabbrev-like-completion"),
		MYTEXT ("skkinput-delay-result-string"),
		MYTEXT ("skkinput-katakana-hiragana-henkan"),
	} ;
	SKKLISPENTITY	tmpEntity ;
	LPSKKLISPENTITY	lpEntity ;
	int				i ;
	for (i = 0 ; i < sizeof (lpVariableNames) / sizeof (LPMYSTR) ; i ++){
		tmpEntity.m_iType			= ENTITY_ATOM ;
		tmpEntity.m_data.m_lpString	= lpVariableNames [i] ;
		lpEntity	= skkinputlisp_EvalEntity (&tmpEntity, &skkinputlispGlobalEnvironment) ;
		if (!lpEntity){
			*lpBuffer ++	= 0 ;
			continue ;
		}
		switch (lpEntity->m_iType){
		case	ENTITY_INTEGER:
			*lpBuffer ++	= (BYTE)lpEntity->m_data.m_integer ;
			break ;
		case	ENTITY_ATOM:
			if (skkinputlisp_IsNil (lpEntity)){
				*lpBuffer ++	= (BYTE)0 ;
			} else {
				*lpBuffer ++	= (BYTE)1 ;
			}
			break ;
		default:
			*lpBuffer ++	= (BYTE)0 ;
			break ;
		}	
	}
	return	i ;
}

/*
 *	(�֐���)
 *		BOOL	skkiserv_GetColorFace ()
 *	(�R�����g)
 *		�F�̐ݒ��ǂݍ��ފ֐��Bauto �Ƃ� underline �Ƃ��̐ݒ���ł���悤�ɂ�
 *		���������B
 */
int		skkiserv_GetColorFace (LPBYTE lpBuffer)
{
	/* ���̕ϐ��̒l�����Ԃ� buffer �ɏ�������ł����B���� ad hoc �Ȋ֐��������肷��B*/
	LPMYSTR	lpVariableNames [] = {
		MYTEXT ("skkinput-henkan-face"),
		MYTEXT ("skkinput-foreground"),
		MYTEXT ("skkinput-background"),
	} ;
	SKKLISPENTITY	tmpEntity ;
	LPSKKLISPENTITY	lpEntity ;
	int				i ;
	for (i = 0 ; i < sizeof (lpVariableNames) / sizeof (LPMYSTR) ; i ++){
		tmpEntity.m_iType			= ENTITY_ATOM ;
		tmpEntity.m_data.m_lpString	= lpVariableNames [i] ;
		lpEntity					= skkinputlisp_EvalEntity (&tmpEntity, &skkinputlispGlobalEnvironment) ;
		if (!lpEntity){
			*lpBuffer ++	= 0 ;
			*lpBuffer ++	= 0 ;
			*lpBuffer ++	= 0 ;
			*lpBuffer ++	= 0 ;
			continue ;
		}
		switch (lpEntity->m_iType){
		case	ENTITY_ATOM:
			skkiserv_String2Color (lpEntity->m_data.m_lpString, lpBuffer) ;
			lpBuffer	+= 4 ;
			break ;
		case	ENTITY_ARRAY:
			skkiserv_Array2Color (lpEntity, lpBuffer) ;
			lpBuffer	+= 4 ;
			break ;
		default:
			*lpBuffer ++	= 0 ;
			*lpBuffer ++	= 0 ;
			*lpBuffer ++	= 0 ;
			*lpBuffer ++	= 0 ;
			break ;
		}
	}
	return	i ;
}

/*
 *	Private Functions	-- �������� -- �������� -- �������� -- �������� -- 
 */
long	skkiserv_AssocRomKanaSub (LPMYSTR lpBuffer, int iSize, LPMYSTR lpPrefix, LPMYSTR lpVarName, BOOL fKatakana)
{
	LPSKKLISPVAR	lpVarNode ;
	LPSKKLISPENTITY	lpEntity ;
	LPSKKLISPENTITY	lpCarEntity ;
	LPSKKLISPENTITY	lpTmpEntity ;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (lpVarName, &skkinputlispGlobalEnvironment) ;
	if (!lpVarNode)
		return	-1 ;
	lpEntity	= lpVarNode->m_lpValue ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpCarEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (lpCarEntity->m_iType != ENTITY_CONS)
			break ;
		lpTmpEntity	= lpCarEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (((!lpPrefix ||
			  !*(lpPrefix)) &&
			 (!(lpTmpEntity->m_data.m_lpString) ||
			  !*((LPMYSTR)lpTmpEntity->m_data.m_lpString))) ||
			 (lpTmpEntity->m_data.m_lpString &&
			  !Mylstrcmp ((LPMYSTR)(lpTmpEntity->m_data.m_lpString), lpPrefix))){
			 lpTmpEntity	= lpCarEntity->m_data.m_conspair.m_lpRightEntity ;
			 if (lpTmpEntity->m_iType != ENTITY_CONS)
			 	return	-1 ;
			if (fKatakana){
				lpTmpEntity	= lpTmpEntity->m_data.m_conspair.m_lpRightEntity ;
			} else {
				lpTmpEntity	= lpTmpEntity->m_data.m_conspair.m_lpLeftEntity ;
			}
			if (!lpTmpEntity || lpTmpEntity->m_iType != ENTITY_STRING)
				return	-1 ;
			Mylstrcpy (lpBuffer, (LPMYSTR)lpTmpEntity->m_data.m_lpString) ;
			return	1 ;
		}
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	0 ;
}

LPLISTBUFFER	skk_search_car (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, BOOL FAR* lpfKakutei, LPSKKLISPENTITY lpSearchEntity)
{
	LPSKKLISPENTITY	lpEntity ;
	LPSKKLISPENTITY	lpRightEntity ;
	if (!lpSearchEntity || lpSearchEntity->m_iType != ENTITY_CONS)
		return	lpListBuffer ;
	lpEntity	= lpSearchEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_ATOM)
		return	lpListBuffer ;
	lpRightEntity	= lpSearchEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!Mylstrcmp (lpEntity->m_data.m_lpString, MYTEXT ("j-search-jisyo-file"))){
		return	j_search_jisyo_file (lpListBuffer, lpHenkanKey, fOkuri, lpRightEntity) ;
	} else if (!Mylstrcmp (lpEntity->m_data.m_lpString, MYTEXT ("j-search-kakutei-jisyo-file"))){
		return	j_search_kakutei_jisyo_file (lpListBuffer, lpHenkanKey, fOkuri, lpfKakutei, lpRightEntity) ;
	} else if (!Mylstrcmp (lpEntity->m_data.m_lpString, MYTEXT ("j-search-server"))){
		return	j_search_server (lpListBuffer, lpHenkanKey, fOkuri, lpRightEntity) ;
	} else {
		return	lpListBuffer ;
	}
}

/*
 *	�^����ꂽ�L�[�Ŏ�������������֐��B
 *----
 *(����)
 *	LPLISTBUFFER	lpListBuffer	�������ʂ��i�[����o�b�t�@�B
 *	LPMYSTR			lpHenkanKey		�����̌����L�[�B
 *									NUL �ŏI�[����Ă��镶����ł��邱�ƁB
 *	BOOL			fOkuri			���艼���ϊ����ۂ��B
 *	LPSKKLISPENTITY	lpSearchEntity	(j-search-jisyo-file ARG1...) �� ARG1 ...
 *(���l)
 *	���ݎ����̃R�[�h�� EUC-JAPAN �Ɍ��ߑł�����Ă��܂��B
 */
LPLISTBUFFER	j_search_jisyo_file (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, LPSKKLISPENTITY lpSearchEntity)
{
	LPSKKLISPVAR	lpVarNode ;
	LPSKKLISPENTITY	lpEntity ;
	LPMYSTR			lpPath ;
#if defined (MIXED_UNICODE_ANSI)
	TCHAR			szPath [MAX_PATH + 1] ;
	int				iLength ;
#endif
	int				iSkkinputjisyoCodingSystem ;
	/* j-search-jisyo-file �̈������`�F�b�N����B�s�����Ă�����G���[�B*/
	if (!lpSearchEntity || lpSearchEntity->m_iType != ENTITY_CONS)
		return	lpListBuffer ;
	/* ��1������]������B���� = �����t�@�C�����B*/
	lpEntity	= skkinputlisp_EvalEntity (lpSearchEntity->m_data.m_conspair.m_lpLeftEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_STRING)
		return	lpListBuffer ;
	/* ���[�U�����̌������s�� = �o�^����Ă���P��̌������s���B*/
	lpPath		= (LPMYSTR)(lpEntity->m_data.m_lpString) ;
	lpVarNode	= skkinputlisp_GlobalSearchVariable (MYTEXT ("skkinput-jisyo"), &skkinputlispGlobalEnvironment) ;
	if (lpVarNode && lpVarNode->m_lpValue &&
		lpVarNode->m_lpValue->m_iType	== ENTITY_STRING &&
		lpVarNode->m_lpValue->m_data.m_lpString == lpPath){
		/* ���[�U�����̌����������̂ŁA�o�^����Ă���P�ꂩ�猟�����܂��B*/
		lpListBuffer	= SKKSearchCandidateRecordList2 (lpListBuffer, lpHenkanKey, fOkuri) ;
		/* skkinput-jisyo �̊����R�[�h�𓾂�B*/
		iSkkinputjisyoCodingSystem	= j_get_coding_system (MYTEXT ("skkinput-jisyo-code")) ;
		/* �����ă��[�U�������猟�����܂��B*/
#if defined (MIXED_UNICODE_ANSI)
		iLength			= MystrToShiftJis (szPath, MAX_PATH, lpPath, Mylstrlen (lpPath)) ;
		if (iLength > 0){
			szPath [iLength]	= '\0' ;
			lpListBuffer	= j_search_local_jisyo (szPath, iSkkinputjisyoCodingSystem, lpHenkanKey, lpListBuffer, fOkuri) ;
		}
#else
		lpListBuffer	= j_search_local_jisyo (lpPath, iSkkinputjisyoCodingSystem, lpHenkanKey, lpListBuffer, fOkuri) ;
#endif
		return	lpListBuffer ;
	}
	/* ����ȊO�̎����������ꍇ�B*/
	lpSearchEntity	= lpSearchEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpSearchEntity || lpSearchEntity->m_iType != ENTITY_CONS)
		return	lpListBuffer ;
	/*
	 * ����������]������B
	 * ���̌��ʂ� == 0 �Ȃ�΁A�\�[�g����Ă��Ȃ������B
	 *            >  0 �Ȃ�΁A�\�[�g����Ă��鎫���B
	 * �Ƃ������ƂɂȂ�B
	 */
	lpEntity		= skkinputlisp_EvalEntity (lpSearchEntity->m_data.m_conspair.m_lpLeftEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_INTEGER)
		return	lpListBuffer ;
#if defined (MIXED_UNICODE_ANSI)
	iLength			= MystrToShiftJis (szPath, MAX_PATH, lpPath, Mylstrlen (lpPath)) ;
	if (iLength > 0){
		szPath [iLength]	= '\0' ;
		if (lpEntity->m_data.m_integer > 0){
			lpListBuffer	= j_search_sorted_jisyo (szPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
		} else {
			lpListBuffer	= j_search_local_jisyo (szPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
		}
	}
#else
	if (lpEntity->m_data.m_integer > 0){
		lpListBuffer	= j_search_sorted_jisyo (lpPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
	} else {
		lpListBuffer	= j_search_local_jisyo (lpPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
	}
#endif
	return	lpListBuffer ;
}

/*
 *	�^����ꂽ�L�[�Ŋm�莫������������֐��B
 *----
 *(����)
 *	LPLISTBUFFER	lpListBuffer	�������ʂ��i�[����o�b�t�@�B
 *	LPMYSTR			lpHenkanKey		�����̌����L�[�B
 *									NUL �ŏI�[����Ă��镶����ł��邱�ƁB
 *	BOOL			fOkuri			���艼���ϊ����ۂ��B
 *	LPSKKLISPENTITY	lpSearchEntity	(j-search-jisyo-file ARG1...) �� ARG1 ...
 *(���l)
 *	���ݎ����̃R�[�h�� EUC-JAPAN �Ɍ��ߑł�����Ă��܂��B
 *	�m�莫���Ō�₪���t��������A�����Ɋm�肵�܂��B
 */
LPLISTBUFFER	j_search_kakutei_jisyo_file (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, BOOL FAR* lpfKakutei, LPSKKLISPENTITY lpSearchEntity)
{
	LPLISTBUFFER	lpPrevListBuffer ;
	LPLISTBUFFER	lpResultListBuffer ;
	int				iUsed ;
	if (lpListBuffer){
		lpPrevListBuffer	= lpListBuffer ;
		while (lpPrevListBuffer->lpNext)
			lpPrevListBuffer	= lpPrevListBuffer->lpNext ;
		iUsed				= lpPrevListBuffer->iUsed ;
	} else {
		lpPrevListBuffer	= NULL ;
		iUsed				= 0 ;
	}
	lpResultListBuffer	= j_search_jisyo_file (lpListBuffer, lpHenkanKey, fOkuri, lpSearchEntity) ;
	if (lpResultListBuffer){
		lpListBuffer	= lpResultListBuffer ;
		while (lpListBuffer->lpNext)
			lpListBuffer	= lpListBuffer->lpNext ;
		if (lpListBuffer != lpPrevListBuffer || iUsed != lpListBuffer->iUsed)
			*lpfKakutei	= TRUE ;
	}
	return	lpResultListBuffer ;
}

/*
 *	�����T�[�o�Ɍ������˗�����֐��B
 */
LPLISTBUFFER	j_search_server (LPLISTBUFFER lpListBuffer, LPMYSTR lpHenkanKey, BOOL fOkuri, LPSKKLISPENTITY lpSearchEntity)
{
	LPSKKLISPENTITY	lpEntity ;
	LPMYSTR			lpPath ;
#if defined (MIXED_UNICODE_ANSI)
	TCHAR			szPath [MAX_PATH] ;
	int				iLength ;
#endif
	/* �T�[�o�����Ɍ�����������B*/
	if (j_search_server_jisyo (lpHenkanKey, &lpListBuffer))
		return	lpListBuffer ;
	/*
	 *	���s�����ꍇ�̏����B
	 * j-search-server �̈������`�F�b�N����B
	 */
	/* ��1����: �������鎫�������w�肷��B*/
	if (!lpSearchEntity || lpSearchEntity->m_iType != ENTITY_CONS)
		return	lpListBuffer ;
	lpEntity	= skkinputlisp_EvalEntity (lpSearchEntity->m_data.m_conspair.m_lpLeftEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_STRING ||
		!lpEntity->m_data.m_lpString || !*(lpEntity->m_data.m_lpString))
		return	lpListBuffer ;
	lpPath		= lpEntity->m_data.m_lpString ;
	lpSearchEntity	= lpSearchEntity->m_data.m_conspair.m_lpRightEntity ;

	/* ��2�����F�\�[�g����Ă��鎫�����ǂ�����(�{���͂��������g���^����Ȃ�����)���肷��B*/
	lpEntity		= skkinputlisp_EvalEntity (lpSearchEntity->m_data.m_conspair.m_lpLeftEntity, &skkinputlispGlobalEnvironment) ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_INTEGER)
		return	lpListBuffer ;
#if defined (MIXED_UNICODE_ANSI)
	iLength			= MystrToShiftJis (szPath, MAX_PATH, lpPath, Mylstrlen (lpPath)) ;
	if (iLength > 0){
		szPath [iLength]	= '\0' ;
		if (lpEntity->m_data.m_integer > 0){
			lpListBuffer	= j_search_sorted_jisyo (szPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
		} else {
			lpListBuffer	= j_search_local_jisyo (szPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
		}
	}
#else
	if (lpEntity->m_data.m_integer > 0){
		lpListBuffer	= j_search_sorted_jisyo (lpPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
	} else {
		lpListBuffer	= j_search_local_jisyo (lpPath, KANJI_CODE_UNKNOWN, lpHenkanKey, lpListBuffer, fOkuri) ;
	}
#endif
	/* ���̏ꍇ�ɂ͂��������T�[�o�Ƃ̐ڑ��ɂ͍s���Ȃ����ƂɂȂ�B�ǂ��̂��H*/
	j_close_server_jisyo () ;
	return	lpListBuffer ;
}

int		skkiserv_GetSymbolFunction2Number (LPSKKLISPENTITY lpEntity)
{
	static	SYMBOLNUMBER	keysymbolTable [] = {
		{ MYTEXT ("self-insert-character"),				FUNCNO_SELF_INSERT_CHARACTER			},
		{ MYTEXT ("j-self-insert"),						FUNCNO_J_SELF_INSERT					},
		{ MYTEXT ("j-zenkaku-insert"),					FUNCNO_J_ZENKAKU_INSERT					},
		{ MYTEXT ("j-display-code-for-char-at-point"),	FUNCNO_J_DISPLAY_CODE_FOR_CHAR_AT_POINT	},
		{ MYTEXT ("j-set-henkan-point"),				FUNCNO_J_SET_HENKAN_POINT				},
		{ MYTEXT ("j-set-henkan-point-subr"),			FUNCNO_J_SET_HENKAN_POINT_SUBR			},
		{ MYTEXT ("j-insert-a"),						FUNCNO_J_INSERT_A						},
		{ MYTEXT ("j-insert-e"),						FUNCNO_J_INSERT_E						},
		{ MYTEXT ("j-insert-i"),						FUNCNO_J_INSERT_I						},
		{ MYTEXT ("j-insert-o"),						FUNCNO_J_INSERT_O						},
		{ MYTEXT ("j-insert-u"),						FUNCNO_J_INSERT_U,						},
		{ MYTEXT ("j-kana-input"),						FUNCNO_J_KANA_INPUT,					},
		{ MYTEXT ("j-start-henkan"),					FUNCNO_J_START_HENKAN,					},
		{ MYTEXT ("j-insert-comma"),					FUNCNO_J_INSERT_COMMA,					},
		{ MYTEXT ("j-insert-period"),					FUNCNO_J_INSERT_PERIOD,					},
		{ MYTEXT ("j-purge-from-jisyo"),				FUNCNO_J_PURGE_FROM_JISYO,				},
		{ MYTEXT ("j-input-by-code-or-menu"),			FUNCNO_J_INPUT_BY_CODE_OR_MENU,			},
		{ MYTEXT ("j-mode-off"),						FUNCNO_J_MODE_OFF,						},
		{ MYTEXT ("j-toggle-kana"),						FUNCNO_J_TOGGLE_KANA,					},
		{ MYTEXT ("j-previous-candidate"),				FUNCNO_J_PREVIOUS_CANDIDATE,			},
		{ MYTEXT ("j-kakutei"),							FUNCNO_J_KAKUTEI,						},
		{ MYTEXT ("j-abbrev-input"),					FUNCNO_J_ABBREV_INPUT,					},
		{ MYTEXT ("j-abbrev-period"),					FUNCNO_J_ABBREV_PERIOD,					},
		{ MYTEXT ("j-abbrev-comma"),					FUNCNO_J_ABBREV_COMMA,					},
		{ MYTEXT ("j-zenkaku-eiji"),					FUNCNO_J_ZENKAKU_EIJI,					},
		{ MYTEXT ("j-zenkaku-henkan"),					FUNCNO_J_ZENKAKU_HENKAN,				},
		{ MYTEXT ("j-today"),							FUNCNO_J_TODAY,							},
		{ MYTEXT ("j-kanainput-mode-on"),				FUNCNO_J_KANAINPUT_MODE_ON,				},
		{ MYTEXT ("j-newline"),							FUNCNO_J_NEWLINE,						},
		{ MYTEXT ("j-set-mark-command"),				FUNCNO_J_SET_MARK_COMMAND,				},
		{ MYTEXT ("j-forward-char"),					FUNCNO_J_FORWARD_CHAR,					},
		{ MYTEXT ("j-backward-char"),					FUNCNO_J_BACKWARD_CHAR,					},
		{ MYTEXT ("j-delete-char"),						FUNCNO_J_DELETE_CHAR,					},
		{ MYTEXT ("j-delete-backward-char"),			FUNCNO_J_DELETE_BACKWARD_CHAR,			},
		{ MYTEXT ("j-try-completion"),					FUNCNO_J_TRY_COMPLETION,				},
		{ MYTEXT ("j-end-of-line"),						FUNCNO_J_END_OF_LINE,					},
		{ MYTEXT ("j-beginning-of-line"),				FUNCNO_J_BEGINNING_OF_LINE,				},
		{ MYTEXT ("j-kill-line"),						FUNCNO_J_KILL_LINE,						},
		{ MYTEXT ("j-yank"),							FUNCNO_J_YANK,							},
		{ MYTEXT ("j-kill-region"),						FUNCNO_J_KILL_REGION,					},
		{ MYTEXT ("j-kill-ring-save"),					FUNCNO_J_KILL_RING_SAVE,				},
		{ MYTEXT ("j-exchange-point-and-mark"),			FUNCNO_J_EXCHANGE_POINT_AND_MARK,		},
		{ MYTEXT ("j-previous-line"),					FUNCNO_J_PREVIOUS_LINE,					},
		{ MYTEXT ("j-next-line"),						FUNCNO_J_NEXT_LINE,						},
		{ MYTEXT ("j-transpose-chars"),					FUNCNO_J_TRANSPOSE_CHARS,				},
		{ MYTEXT ("j-sendback-key"),					FUNCNO_J_SENDBACK_KEY,					},
		{ MYTEXT ("j-prefix-char"),						FUNCNO_J_PREFIX_CHAR,					},
		{ MYTEXT ("j-keyboard-quit"),					FUNCNO_J_KEYBOARD_QUIT,					},
	} ;
	int	j ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_ATOM || !lpEntity->m_data.m_lpString)
		return	FUNCNO_NOFUNCTION ;
	for (j = 0 ; j < sizeof (keysymbolTable) / sizeof (SYMBOLNUMBER) ; j ++){
		if (!Mylstrcmp (lpEntity->m_data.m_lpString, keysymbolTable [j].m_lpSymbol))
			return	keysymbolTable [j].m_iNumber ;
	}
	return	FUNCNO_NOFUNCTION ;
}

BOOL	skkiserv_String2Color (LPCMYSTR lpString, LPBYTE lpBuffer)
{
	MYCOLOR		pColorTable []	= {
		{ MYTEXT ("auto"),		0,	  0,	  0,	  0 },
		{ MYTEXT ("underline"),	1,	  0,	  0,	  0 },
		{ MYTEXT ("black"),		2,	  0,	  0,	  0 },
		{ MYTEXT ("blue"),		2,	  0,	  0,	255 },
		{ MYTEXT ("red"),		2,	255,	  0,	  0 },
		{ MYTEXT ("purple"),	2,	255,	  0,	255 },
		{ MYTEXT ("green"),		2,	  0,	255,	  0 },
		{ MYTEXT ("cyan"),		2,	  0,	255,	255 },
		{ MYTEXT ("yellow"),	2,	255,	255,	  0 },
		{ MYTEXT ("white"),		2,	255,	255,	255 },
	} ;
	int	i ;
	if (!lpBuffer)
		return	FALSE ;
	if (lpString){
		for (i = 0 ; i < sizeof (pColorTable) / sizeof (MYCOLOR) ; i ++){
			if (!Mylstrcasecmp (lpString, pColorTable [i].m_pName)){
				*lpBuffer	++ = pColorTable [i].m_bType ;
				*lpBuffer	++ = pColorTable [i].m_bRed ;
				*lpBuffer	++ = pColorTable [i].m_bGreen ;
				*lpBuffer	++ = pColorTable [i].m_bBlue ;
				return	TRUE ;
			}
		}
	}
	*lpBuffer	++ = pColorTable [0].m_bType ;
	*lpBuffer	++ = pColorTable [0].m_bRed ;
	*lpBuffer	++ = pColorTable [0].m_bGreen ;
	*lpBuffer	++ = pColorTable [0].m_bBlue ;
	return	TRUE ;
}

BOOL	skkiserv_Array2Color (LPSKKLISPENTITY lpEntity, LPBYTE lpBuffer)
{
	LPSKKLISPENTITY	lpElement ;
	int				i ;
	BYTE			bColor [3] ;
	memset (bColor, 0, sizeof (bColor)) ;
	if (lpEntity->m_iType == ENTITY_ARRAY && lpEntity->m_data.m_array.m_lpArray){
		for (i = 0 ; i < 3 && i < lpEntity->m_data.m_array.m_iLength ; i ++){
			lpElement	= ((LPSKKLISPENTITY*)lpEntity->m_data.m_array.m_lpArray) [i] ;
			lpElement	= skkinputlisp_EvalEntity (lpElement, &skkinputlispGlobalEnvironment) ;
			if (!lpElement || lpElement->m_iType != ENTITY_INTEGER){
				bColor [i]	= 0 ;
			} else {
				bColor [i]	= (BYTE)lpElement->m_data.m_integer ;
			}
		}
	}
	*lpBuffer	++ = 2 ;
	*lpBuffer	++ = bColor [0] ;
	*lpBuffer	++ = bColor [1] ;
	*lpBuffer	++ = bColor [2] ;
	return	TRUE ;
}


