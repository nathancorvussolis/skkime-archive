/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * skkserver.h
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#if !defined(skkserver_h)
#define	skkserver_h

/*
 *	Structures 
 */
typedef struct tagSKKCONN {
	BOOL				m_fInit ;
	const char FAR*		m_pHostName ;
	int					m_iPortNum ;
	struct sockaddr_in	m_address ;
	struct hostent*		m_pHostent ;
	SOCKET				m_hSocket ;
	BOOL				m_fConnect ;
	BOOL				m_fUsed ;
} SKKCONN, NEAR *PSKKCONN, FAR *LPSKKCONN ;

#endif


