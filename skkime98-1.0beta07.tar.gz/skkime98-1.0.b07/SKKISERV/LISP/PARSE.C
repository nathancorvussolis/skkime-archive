#ifdef DEBUG_LV10
#include <stdio.h>
#endif
#include "windows.h"
#include "mylocale.h"
#include "parse.h"
#include "lisp.h"
#include "mystring.h"

/*
 *	Prototypes
 */
static	void		skkinputlisp_SkipString (LPCMYSTR FAR *lpLpString) ;
static	LPCONSLIST	skkinputlisp_String2ConsList (LPCMYSTR FAR* lpLpString) ;
static	BOOL		skkinputlisp_DeleteComment (LPMYSTR lpString) ;
static	void		skkinputlisp_SkipSpace (LPCMYSTR FAR *lpLpString) ;
static	LPMYSTR		skkinputlisp_ConvertQuote (LPCMYSTR lpString) ;
static	void		skkinputlisp_FreeConsList (LPCONSLIST lpConslistTop) ;
static	LPMYSTR		skkinputlisp_CutString (LPCMYSTR FAR* lpLpString) ;
static	LPCONSLIST	skkinputlisp_CopyConsPair (LPCONSLIST lpConsListTop) ;
static	BOOL		skkinputlisp_String2ConsList_ConsPair (LPCMYSTR FAR* lpLpString, LPCONSNODE lpConsNode) ;
static	BOOL		skkinputlisp_String2ConsList_String (LPCMYSTR FAR* lpLpString, LPCONSNODE lpConsNode) ;
static	LPCONSLIST	skkinputlisp_String2ConsList_Array (LPCMYSTR FAR* lpLpString) ;
static	int			skkinputlisp_CountStringLength (LPCMYSTR lpString) ;
static	BOOL		skkinputlisp_CopyConsNode (LPCONSNODE lpConstDest, LPCONSNODE lpConsSrc) ;
#ifdef DEBUG_LV10
static	BOOL	skkinputlisp_DebugPrint (LPMYSTR lpszFormat, ...) ;
static	BOOL		skkinputlisp_PrintConsList (LPCONSLIST lpConsList) ;
static	BOOL		skkinputlisp_PrintConsNode (LPCONSNODE lpConsNode) ;
static	BOOL		skkinputlisp_PrintConsListSub (LPCONSLIST lpConsListNode) ;
#endif

/*************************************************************************
 *	global functions
 *************************************************************************/

LPSKKLISPENTITY	skkinputlisp_String2Entity (LPCMYSTR lpString)
{
	LPMYSTR			lpRealCommand ;
	LPSKKLISPENTITY	lpEntity ;
	LPCONSLIST		lpConsList ;
	CONSNODE		consnode ;
	/* NULL ���ä��顢ɾ���Τ��褦���ʤ���*/
	if (!lpString)
		return	NULL ;
	lpRealCommand	= skkinputlisp_ConvertQuote (lpString) ;
	if (!lpRealCommand)
		return	NULL ;
	lpString	= lpRealCommand ;
	/* ʸ�������Ƭ�ˤ������ʸ���򥹥��åפ��롣*/
	skkinputlisp_SkipSpace (&lpString) ;
	if (*lpString == MYTEXT ('(') || *lpString == MYTEXT ('\x27')){
		/* ���ξ��ˤϴؿ��Ǥ��롣ɾ�����ʤ��Ȥ����ʤ���*/
		lpString	++ ;
		lpConsList	= skkinputlisp_String2ConsList (&lpString) ;
#ifdef DEBUG_LV10
		skkinputlisp_PrintConsList (lpConsList) ;
#endif
		lpEntity	= skkinputlisp_ConsList2Entity (lpConsList) ;
		skkinputlisp_FreeConsList (lpConsList) ;
	} else if (*lpString == MYTEXT ('[')){
		lpString	++ ;
		consnode.m_iType	= TYPE_CONSLIST_ARRAY ;
		consnode.m_lpValue	= skkinputlisp_String2ConsList_Array (&lpString) ;
#ifdef DEBUG_LV10
		skkinputlisp_PrintConsNode (&consnode) ;
		PRINTF (MYTEXT ("\n")) ;
#endif
		lpEntity	= skkinputlisp_ConsNode2Entity (&consnode) ;
		skkinputlisp_FreeConsList (consnode.m_lpValue) ;
	} else {
		skkinputlisp_String2ConsList_String (&lpString, &consnode) ;
#ifdef DEBUG_LV10
		skkinputlisp_PrintConsNode (&consnode) ;
		PRINTF (MYTEXT ("\n")) ;
#endif
		if (consnode.m_iType == TYPE_CONSLIST_STRING){
			lpEntity	= skkinputlisp_ConsNode2Entity (&consnode) ;
			if (consnode.m_lpValue){
				HeapFree (GetProcessHeap (), 0, consnode.m_lpValue) ;
				consnode.m_lpValue	= NULL ;
			}
		} else {
			lpEntity	= NULL ;
		}
	}
	HeapFree (GetProcessHeap (), 0, lpRealCommand) ;
	return	lpEntity ;
}

/*************************************************************************
 *	local functions
 *************************************************************************/

/*
 * ����ʸ������ɤ����Ф��ؿ���
 */
void	skkinputlisp_SkipSpace (LPCMYSTR FAR *lpLpString)
{
	LPCMYSTR	lpptr ;
	if (!lpLpString)
		return ;
	lpptr	= *lpLpString ;
	if (!lpptr)
		return ;
	while (*lpptr){
		if (*lpptr != MYTEXT (' ') &&
			*lpptr != MYTEXT ('\n') &&
			*lpptr != MYTEXT ('\r') &&
			*lpptr != MYTEXT ('\t'))
			break ;
		lpptr	++ ;
	}
	*lpLpString	= lpptr ;
	return ;
}

/*
 * cons list ���������Τ��Ѥ�����ؿ���( ���ա�skkinputlisp_entity 
 * �ǤϤʤ���
 */
void	skkinputlisp_FreeConsList (LPCONSLIST lpConslistTop)
{
	if (!lpConslistTop)
		return ;
	/* �����������롣*/
	if (lpConslistTop->m_left.m_iType == TYPE_CONSLIST_CONSPAIR ||
		lpConslistTop->m_left.m_iType == TYPE_CONSLIST_ARRAY){
		if (lpConslistTop->m_left.m_lpValue)
			skkinputlisp_FreeConsList (lpConslistTop->m_left.m_lpValue) ;
		lpConslistTop->m_left.m_lpValue	= NULL ;
	} else {
		if (lpConslistTop->m_left.m_lpValue)
			HeapFree (GetProcessHeap (), 0, lpConslistTop->m_left.m_lpValue) ;
		lpConslistTop->m_left.m_lpValue	= NULL ;			
	}
	/* �����������롣*/
	if (lpConslistTop->m_right.m_iType == TYPE_CONSLIST_CONSPAIR ||
		lpConslistTop->m_right.m_iType == TYPE_CONSLIST_ARRAY){
		if (lpConslistTop->m_right.m_lpValue)
			skkinputlisp_FreeConsList (lpConslistTop->m_right.m_lpValue) ;
		lpConslistTop->m_right.m_lpValue	= NULL ;
	} else {
		if (lpConslistTop->m_right.m_lpValue)
			HeapFree (GetProcessHeap (), 0, lpConslistTop->m_right.m_lpValue) ;
		lpConslistTop->m_right.m_lpValue	= NULL ;			
	}
	HeapFree (GetProcessHeap (), 0, lpConslistTop) ;
	return ;
}

/*
 * conslist ��Ÿ������ؿ���
 */
LPCONSLIST	skkinputlisp_String2ConsList (LPCMYSTR FAR* lpLpString)
{
	LPCONSLIST	lpConsListNode ;
	LPCMYSTR	lpptr ;
	BOOL		fSuccess ;

	if (!lpLpString || !*lpLpString)
		return	NULL ;
	lpptr	= *lpLpString ;

	lpConsListNode	= HeapAlloc (GetProcessHeap (), 0, sizeof (CONSLIST)) ;
	if (!lpConsListNode)
		return	NULL ;
	lpConsListNode->m_left.m_iType		= lpConsListNode->m_right.m_iType	= TYPE_CONSLIST_STRING ;
    lpConsListNode->m_left.m_lpValue	= lpConsListNode->m_right.m_lpValue	= NULL ;
	fSuccess		= TRUE ;

	skkinputlisp_SkipSpace (&lpptr) ;
	if (*lpptr == MYTEXT ('(')){
		lpptr	++ ;
		skkinputlisp_SkipSpace (&lpptr) ;
		if (*lpptr != MYTEXT (')') && *lpptr){
			if (!skkinputlisp_String2ConsList_ConsPair (&lpptr, &lpConsListNode->m_left)){
				fSuccess	= FALSE ;
				goto		exit_string2conslist ;
			}
		} else {
			lpConsListNode->m_left.m_iType		= TYPE_CONSLIST_CONSPAIR ;
			lpConsListNode->m_left.m_lpValue	= NULL ;
			if (*lpptr == MYTEXT (')'))
				lpptr	++ ;
		}
	} else if (*lpptr == MYTEXT ('[')){
		lpptr	++ ;
		skkinputlisp_SkipSpace (&lpptr) ;
		lpConsListNode->m_left.m_iType	= TYPE_CONSLIST_ARRAY ;
		if (*lpptr != MYTEXT (']') && *lpptr){
			lpConsListNode->m_left.m_lpValue	= skkinputlisp_String2ConsList_Array (&lpptr) ;
			if (!lpConsListNode->m_left.m_lpValue){
				fSuccess	= FALSE ;
				goto		exit_string2conslist ;
			}
		} else {
			lpConsListNode->m_left.m_lpValue	= NULL ;
			if (*lpptr == MYTEXT (']'))
				lpptr	++ ;
		}
	} else {
		if (!skkinputlisp_String2ConsList_String (&lpptr, &lpConsListNode->m_left)){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
	}
	skkinputlisp_SkipSpace (&lpptr) ;
	if (*lpptr == MYTEXT ('.')){
		/* cons pair �ξ�硣*/
		lpptr	++ ;
		skkinputlisp_SkipSpace (&lpptr) ;
		if (*lpptr == MYTEXT ('(')){
			lpptr	++ ;
			skkinputlisp_SkipSpace (&lpptr) ;
			if (*lpptr != MYTEXT (')') && *lpptr){
				if (!skkinputlisp_String2ConsList_ConsPair (&lpptr, &lpConsListNode->m_right)){
					fSuccess	= FALSE ;
					goto		exit_string2conslist ;
				}
			} else {
				lpConsListNode->m_right.m_iType		= TYPE_CONSLIST_CONSPAIR ;
				lpConsListNode->m_right.m_lpValue	= NULL ;
				if (*lpptr == MYTEXT (')'))
					lpptr	++ ;
			}
		} else if (*lpptr == MYTEXT (')')){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		} else {
			skkinputlisp_String2ConsList_String (&lpptr, &lpConsListNode->m_right) ;
		}
		skkinputlisp_SkipSpace (&lpptr) ;
		if (*lpptr == MYTEXT (')')){
			lpptr ++ ;
		} else if (*lpptr){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
	} else if (*lpptr == MYTEXT ('[')){
		lpConsListNode->m_right.m_iType		= TYPE_CONSLIST_CONSPAIR ;
		lpConsListNode->m_right.m_lpValue	= skkinputlisp_String2ConsList (&lpptr) ;
		if (!lpConsListNode->m_right.m_lpValue){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
		skkinputlisp_SkipSpace (&lpptr) ;
	} else if (*lpptr == MYTEXT (')') || !*lpptr){
		lpConsListNode->m_right.m_iType		= TYPE_CONSLIST_CONSPAIR ;
		lpConsListNode->m_right.m_lpValue	= NULL ;
		if (*lpptr)
			lpptr	++ ;
	} else if (*lpptr == MYTEXT ('(')){
		if (!skkinputlisp_String2ConsList_ConsPair (&lpptr, &lpConsListNode->m_right)){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
	} else {
		if (!skkinputlisp_String2ConsList_ConsPair (&lpptr, &lpConsListNode->m_right)){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
	}
exit_string2conslist:
	if (!fSuccess){
		HeapFree (GetProcessHeap (), 0, lpConsListNode) ;
		return	NULL ;
	}
	/* ʸ�����ɤ����ʬ�ޤǿʤ�Ƥ�����*/
	*lpLpString	= lpptr ;
	return	lpConsListNode ;
}

LPMYSTR	skkinputlisp_ConvertQuote (LPCMYSTR lpString)
{
	BOOL		fDoubleQuote ;
	BOOL		fIgnoreNext ;
	int			iLength ;
	int			iNestLevel ;
	LPMYSTR		lpDest ;
	LPMYSTR		lpRetValue ;
	LPCMYSTR	lpptr ;
	BOOL		fNestCheck [MAX_NEST_LEVEL] ;
	BOOL		fSuccess ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	int			iPreviousCharacter ;
#endif

	fSuccess		= TRUE ;
	fDoubleQuote	= FALSE ;
	fIgnoreNext		= FALSE ;
	skkinputlisp_SkipSpace (&lpString) ;
	iLength			= skkinputlisp_CountStringLength (lpString) ;

	lpRetValue		= HeapAlloc (GetProcessHeap (), 0, sizeof (MYCHAR) * (iLength + 1)) ;
	if (!lpRetValue)
		return	NULL ;  
	for (iNestLevel = 0 ; iNestLevel < MAX_NEST_LEVEL ; iNestLevel ++)
		fNestCheck [iNestLevel]	= FALSE ;
	iNestLevel			= 0 ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	iPreviousCharacter	= MYTEXT ('\0') ;
#endif
	lpDest				= lpRetValue ;
	while (*lpString){
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
		if (iPreviousCharacter){
			*lpDest	++	= (MYCHAR)iPreviousCharacter ;
			*lpDest ++	= (MYCHAR)*lpString ++ ;
			iPreviousCharacter	= MYTEXT ('\0') ;
			if (fIgnoreNext)
				fIgnoreNext	= FALSE ;
			continue ;
		}
		if (IsDBCSLeadByte (*lpString)){
			iPreviousCharacter	= *lpString ++ ;
			continue ;
		}
#endif
		if (*lpString == MYTEXT ('\\')){
			fIgnoreNext	= TRUE ;
			*lpDest ++	= *lpString	++ ;
			continue ;
		}
		if (*lpString == MYTEXT ('\x22') && !fIgnoreNext){
			fDoubleQuote	= !fDoubleQuote ;
		}
		if (!fIgnoreNext && !fDoubleQuote){
			switch (*lpString){
			case MYTEXT ('('):
				lpptr	= lpString ;
				lpString	++ ;
				skkinputlisp_SkipSpace (&lpString) ;
				if (*lpString == MYTEXT (')') || !*lpString){
					Mylstrcpy (lpDest, MYTEXT (" nil ")) ;
					lpDest	+= 5 ;
					if (*lpString == MYTEXT (')'))
						lpString	++ ;
					break ;
				}
				lpString	= lpptr ;
			case MYTEXT ('['):
				iNestLevel	++ ;
				if (iNestLevel > MAX_NEST_LEVEL){
					fSuccess	= FALSE ;
					goto	exit_loop ;
				}
				break ;
			case MYTEXT (']'):
			case MYTEXT (')'):
				if (fNestCheck [iNestLevel]){
					*lpDest ++	= MYTEXT (')') ;
					fNestCheck [iNestLevel]	= FALSE ;
				}
				iNestLevel	-- ;
				break ;
			case MYTEXT (' '):
			case MYTEXT ('\t'):
			case MYTEXT ('\0'):
				if (fNestCheck [iNestLevel]){
					*lpDest ++	= MYTEXT (')') ;
					fNestCheck [iNestLevel]	= FALSE ;
				}
				break ;
			case MYTEXT ('\x27'):
				fNestCheck [iNestLevel]	= TRUE ;
				Mylstrcpy (lpDest, MYTEXT ("(quote ")) ;
				lpDest		+= 7 ;
				lpString	++ ;
				continue ;
			default:
				break ;
			}
		}
		*lpDest ++	= *lpString ++ ;
		if (fIgnoreNext)
			fIgnoreNext	= FALSE ;
	}
exit_loop:
	*lpDest	= MYTEXT ('\0') ;
	if (!fSuccess){
		HeapFree (GetProcessHeap (), 0, lpRetValue) ;
		lpRetValue	= NULL ;
	}
	return	lpRetValue ;
}

LPCONSLIST	skkinputlisp_CopyConsPair (LPCONSLIST lpConsListTop)
{
	LPCONSLIST	lpNewConsListTop ;
	BOOL		fSuccess ;
	if (!lpConsListTop)
		return	NULL ;
	lpNewConsListTop	= HeapAlloc (GetProcessHeap (), 0, sizeof (CONSLIST)) ;
	if (!lpNewConsListTop)
		return	NULL ;
	fSuccess			= TRUE ;
	lpNewConsListTop->m_left.m_iType	= lpNewConsListTop->m_right.m_iType		= TYPE_CONSLIST_STRING ;
	lpNewConsListTop->m_left.m_lpValue	= lpNewConsListTop->m_right.m_lpValue	= NULL ;
	if (!skkinputlisp_CopyConsNode (&lpNewConsListTop->m_left,  &lpConsListTop->m_left) ||
		!skkinputlisp_CopyConsNode (&lpNewConsListTop->m_right, &lpConsListTop->m_right)){
		fSuccess		= FALSE ;
	}
	if (!fSuccess){
		skkinputlisp_FreeConsList (lpNewConsListTop) ;
		lpNewConsListTop	= NULL ;
	}
	return	lpNewConsListTop ;
}

BOOL	skkinputlisp_DeleteComment (LPMYSTR lpString)
{
	LPMYSTR		lpptr ;
	BOOL		fDoubleQuote ;
	BOOL		fIgnoreNext ;
	int			iPreviousChara ;

	fDoubleQuote	= FALSE ;
	fIgnoreNext		= FALSE ;

	iPreviousChara	= MYTEXT ('\0') ;
	lpptr			= lpString ;
	while (*lpptr){
		if (!fIgnoreNext && !fDoubleQuote){
			if (*lpptr == MYTEXT ('\\')){
				fIgnoreNext	= TRUE ;
				lpptr		++ ;
				continue ;
			}
		}
		if (!fIgnoreNext && *lpptr == MYTEXT ('\x22')){
			fDoubleQuote	= !fDoubleQuote ;
			lpptr			++ ;
			continue ;
		}
		if (!fIgnoreNext && !fDoubleQuote && 
			iPreviousChara	!= MYTEXT ('?') &&
			*lpptr != MYTEXT (';')){
			*lpptr	= MYTEXT ('\0') ;
			break ;
		}
		if (fIgnoreNext)
			fIgnoreNext	= FALSE ;
		iPreviousChara	= *lpptr ++ ;
	}
	return	TRUE ;
}

/*
 * ʸ������ɤ����Ф��ؿ���
 */
void	skkinputlisp_SkipString (LPCMYSTR FAR *lpLpString)
{
	LPCMYSTR	lpptr ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	int			iPreviousChara ;
#endif
	BOOL		fDoubleQuote ;
	if (!lpLpString)
		return ;
	lpptr			= *lpLpString ;
	fDoubleQuote	= FALSE ;
	if (!lpptr)
		return ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	while (*lpptr){
		if (*lpptr == MYTEXT ('\x22')){
			fDoubleQuote	= !fDoubleQuote ;
		} else if (*lpptr == MYTEXT ('[') ||
				   *lpptr == MYTEXT (']') ||
				   *lpptr == MYTEXT ('(') ||
				   *lpptr == MYTEXT (')') ||
				   *lpptr == MYTEXT (' ') ||
				   *lpptr == MYTEXT ('\t')){
			if (!fDoubleQuote)
				break ;
		}
		lpptr	++ ;
	}
#else
	iPreviousChara	= 0 ;
	while (*lpptr){
		if (iPreviousChara){
			iPreviousChara	= 0 ;
			lpptr	++ ;
		} else {
			if (IsDBCSLeadByte (*lpptr)){
				iPreviousChara	= *lpptr ;
			} else {
				if (*lpptr == MYTEXT ('\x22')){
					fDoubleQuote	= !fDoubleQuote ;
				} else if (*lpptr == MYTEXT ('[') ||
						   *lpptr == MYTEXT (']') ||
						   *lpptr == MYTEXT ('(') ||
						   *lpptr == MYTEXT (')') ||
						   *lpptr == MYTEXT (' ') ||
						   *lpptr == MYTEXT ('\t')){
					if (!fDoubleQuote)
						break ;
				}
			}
			lpptr	++ ;
		}
	}
#endif
	*lpLpString	= lpptr ;
	return ;
}

/*
 * ʸ�����ȴ���Ф��ؿ���
 */
LPMYSTR	skkinputlisp_CutString (LPCMYSTR FAR* lpLpString)
{
	LPCMYSTR	lpptr ;
	LPMYSTR		lpNewString ;
	int			iLength ;

	if (!lpLpString)
		return	NULL ;
	lpptr	= *lpLpString ;
	if (!lpptr)
		return	NULL ;
	skkinputlisp_SkipString (&lpptr) ;
	iLength				= lpptr - *lpLpString ;
	if (Mylstrncmp (*lpLpString, MYTEXT ("nil"), iLength) && iLength > 0){
		lpNewString		= HeapAlloc (GetProcessHeap (), 0, sizeof (MYCHAR) * (iLength + 1)) ;
		Mylstrncpy (lpNewString, *lpLpString, iLength) ;
		lpNewString [iLength]	= MYTEXT ('\0') ;
	} else {
		lpNewString		= NULL ;
	}
	*lpLpString			= lpptr ;
	return	lpNewString ;
}

BOOL	skkinputlisp_String2ConsList_ConsPair (LPCMYSTR FAR* lpLpString, LPCONSNODE lpConsNode)
{
	lpConsNode->m_iType		= TYPE_CONSLIST_CONSPAIR ;
	lpConsNode->m_lpValue	= skkinputlisp_String2ConsList (lpLpString) ;
	if (!lpConsNode->m_lpValue)
		return	FALSE ;
	skkinputlisp_SkipSpace (lpLpString) ;
	return	TRUE ;
}

BOOL	skkinputlisp_String2ConsList_String (LPCMYSTR FAR* lpLpString, LPCONSNODE lpConsNode)
{
	lpConsNode->m_iType		= TYPE_CONSLIST_STRING ;
	lpConsNode->m_lpValue	= skkinputlisp_CutString (lpLpString) ;
	if (!lpConsNode->m_lpValue){
		lpConsNode->m_iType		= TYPE_CONSLIST_CONSPAIR ;
		lpConsNode->m_lpValue	= NULL ;
	}
	return	TRUE ;
}

LPCONSLIST	skkinputlisp_String2ConsList_Array (LPCMYSTR FAR* lpLpString)
{
	LPCONSLIST	lpConsListNode ;
	LPCMYSTR	lpptr ;
	BOOL		fSuccess ;

	/* �������ݤ��롣*/
	lpConsListNode	= HeapAlloc (GetProcessHeap (), 0, sizeof (CONSLIST)) ;
	if (!lpConsListNode)
		return	NULL ;
	lpConsListNode->m_left.m_iType		= lpConsListNode->m_right.m_iType	= TYPE_CONSLIST_STRING ;
	lpConsListNode->m_left.m_lpValue	= lpConsListNode->m_right.m_lpValue	= NULL ;

	fSuccess	= TRUE ;
	lpptr		= *lpLpString ;
	skkinputlisp_SkipSpace (&lpptr) ;
	if (*lpptr == MYTEXT ('.') || *lpptr == MYTEXT (')')){
		fSuccess	= FALSE ;
		goto		exit_string2conslist ;
	} else if (*lpptr == MYTEXT (']')){
		lpptr	++ ;
		*lpLpString	= lpptr ;
		fSuccess	= FALSE ;
		goto		exit_string2conslist ;
	}
	if (*lpptr == MYTEXT ('[')){
		lpptr	++ ;
		skkinputlisp_SkipSpace (&lpptr) ;
		lpConsListNode->m_left.m_iType	= TYPE_CONSLIST_ARRAY ;
		if (*lpptr != MYTEXT (']') && *lpptr){
			lpConsListNode->m_left.m_lpValue	= skkinputlisp_String2ConsList_Array (&lpptr) ;
			if (!lpConsListNode->m_left.m_lpValue){
				fSuccess	= FALSE ;
				goto		exit_string2conslist ;
			}
		} else {
			lpConsListNode->m_left.m_lpValue	= NULL ;
			if (*lpptr == MYTEXT (']'))
				lpptr	++ ;
		}
	} else if (*lpptr == MYTEXT ('(')){
		lpptr	++ ;
		lpConsListNode->m_left.m_iType		= TYPE_CONSLIST_CONSPAIR ;
		lpConsListNode->m_left.m_lpValue	= skkinputlisp_String2ConsList (&lpptr) ;
		if (!lpConsListNode->m_left.m_lpValue){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
	} else {
		fSuccess							= TRUE ;
		if (!skkinputlisp_String2ConsList_String (&lpptr, &lpConsListNode->m_left)){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
	}
	skkinputlisp_SkipSpace (&lpptr) ;
	lpConsListNode->m_right.m_iType	= TYPE_CONSLIST_ARRAY ;
	if (*lpptr != MYTEXT (']') && *lpptr){
		lpConsListNode->m_right.m_lpValue	= skkinputlisp_String2ConsList_Array (&lpptr) ;
		if (!lpConsListNode->m_right.m_lpValue){
			fSuccess	= FALSE ;
			goto		exit_string2conslist ;
		}
	} else {
		if (*lpptr == MYTEXT (']'))
			lpptr	++ ;
		lpConsListNode->m_right.m_lpValue	= NULL ;
	}
exit_string2conslist:
	if (!fSuccess){
		skkinputlisp_FreeConsList (lpConsListNode) ;
		return	NULL ;
	}
	*lpLpString	= lpptr ;
	return	lpConsListNode ;
}

int		skkinputlisp_CountStringLength (LPCMYSTR lpString)
{
	LPCMYSTR	lpptr ;
	BOOL		fDoubleQuote ;
	BOOL		fIgnoreNext ;
	int			iLength ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	int			iPreviousCharacter ;
#endif

	if (!lpString)
		return	0 ;

	fDoubleQuote		= FALSE ;
	fIgnoreNext			= FALSE ;
	iLength				= 0 ;
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
	iPreviousCharacter	= MYTEXT ('\0') ;
#endif

	while (*lpString){
#if !defined (MIXED_UNICODE_ANSI) && !defined (UNICODE)
		if (iPreviousCharacter){
			iLength				+= 2 ;
			lpString			++ ;
			iPreviousCharacter	= MYTEXT ('\0') ;
			if (fIgnoreNext)
				fIgnoreNext		= FALSE ;
			continue ;
		}
		if (IsDBCSLeadByte (*lpString)){
			iPreviousCharacter	= *lpString ++ ;
			continue ;
		}
#endif
		if (*lpString == MYTEXT ('\\')){
			fIgnoreNext	= TRUE ;
			iLength		++ ;
			lpString	++ ;
			continue ;
		}
		if (*lpString == MYTEXT ('\x22') && !fIgnoreNext){
			fDoubleQuote	= !fDoubleQuote ;
		}
		if (*lpString == MYTEXT ('(') && !fDoubleQuote && !fIgnoreNext){
			lpptr		= lpString ;
			lpString	++ ;
			skkinputlisp_SkipSpace (&lpString) ;
			if (*lpString == MYTEXT (')') || !*lpString){
				iLength	+= 5 ;
				if (*lpString == MYTEXT (')'))
					lpString	++ ;
				continue ;
			}
			lpString	= lpptr ;
		}
		if (*lpString == MYTEXT ('\x27') && !fDoubleQuote && !fIgnoreNext){
			iLength	+= 7 ;
		}
		iLength		++ ;
		lpString	++ ;
		if (fIgnoreNext)
			fIgnoreNext	= FALSE ;
	}
	return	iLength ;
}

/*
 * consnode �򥳥ԡ�����ؿ���
 */
BOOL	skkinputlisp_CopyConsNode (LPCONSNODE lpConsDest, LPCONSNODE lpConsSrc)
{
	LPMYSTR	lpSrcString ;
	int		iLength ;
	lpConsDest->m_iType	= lpConsSrc->m_iType ;
	switch (lpConsSrc->m_iType){
	case TYPE_CONSLIST_ARRAY :
	case TYPE_CONSLIST_CONSPAIR :
		if (!lpConsSrc->m_lpValue){
			lpConsDest->m_lpValue	= NULL ;
		} else {
			lpConsDest->m_lpValue	= skkinputlisp_CopyConsPair (lpConsSrc->m_lpValue) ;
			if (!lpConsDest->m_lpValue)
				return	FALSE ;
		}
		break ;
	case TYPE_CONSLIST_STRING :
		if (!lpConsSrc->m_lpValue){
			lpConsDest->m_lpValue	= NULL ;
		} else {
			lpSrcString				= (LPMYSTR)lpConsSrc->m_lpValue ;
			iLength					= Mylstrlen (lpSrcString) ;
			lpConsDest->m_lpValue	= HeapAlloc (GetProcessHeap (), 0, sizeof (MYCHAR) * (iLength + 1)) ;
			if (lpConsDest->m_lpValue)
				Mylstrcpy ((LPMYSTR)lpConsDest->m_lpValue, lpSrcString) ;
			if (!lpConsDest->m_lpValue)
				return	FALSE ;
		}
		break ;
	default :
		break ;
	}
	return	TRUE ;
}

#ifdef DEBUG_LV10
BOOL	skkinputlisp_DebugPrint (LPMYSTR lpszFormat, ...)
{
	MYCHAR	buf [4096] ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	TCHAR	tbuf [8192] ;
#endif
	va_list	marker ;
	int		nCount ;
	va_start (marker, lpszFormat) ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	nCount	= vswprintf (buf, lpszFormat, marker) ;
#else
	nCount	= wvsprintf (buf, lpszFormat, marker) ;
#endif
	va_end (marker) ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	MystrToEucW (tbuf, buf, 4096) ;
	OutputDebugString (tbuf) ;
#else
	OutputDebugString (buf) ;
#endif
	return	TRUE ;
}

BOOL	skkinputlisp_PrintConsList (LPCONSLIST lpConsList)
{
	if (!lpConsList)
		return	FALSE ;
	PRINTF (MYTEXT ("(")) ;
	skkinputlisp_PrintConsListSub (lpConsList) ;
	PRINTF (MYTEXT (")\n")) ;
	return	TRUE ;
}

BOOL	skkinputlisp_PrintConsNode (LPCONSNODE lpConsNode)
{
	if (!lpConsNode)
		return	FALSE ;
	if (lpConsNode->m_iType == TYPE_CONSLIST_STRING){
		if (lpConsNode->m_lpValue){
			PRINTF (MYTEXT ("%s"), (LPMYSTR)lpConsNode->m_lpValue) ;
		} else {
			PRINTF (MYTEXT ("nil")) ;
		}
	} else if (lpConsNode->m_iType == TYPE_CONSLIST_CONSPAIR){
		if (!lpConsNode->m_lpValue){
			PRINTF (MYTEXT ("nil")) ;
		} else {
			PRINTF (MYTEXT ("(")) ;
			skkinputlisp_PrintConsListSub (lpConsNode->m_lpValue) ;
			PRINTF (MYTEXT (")")) ;
		}
	} else if (lpConsNode->m_iType == TYPE_CONSLIST_ARRAY){
		if (!lpConsNode->m_lpValue){
			PRINTF (MYTEXT ("[]")) ;
		} else {
			PRINTF (MYTEXT ("[")) ;
			skkinputlisp_PrintConsListSub (lpConsNode->m_lpValue) ;
			PRINTF (MYTEXT ("]")) ;
		}
	}
	return	TRUE ;
}

/*
 * cons list ��ɽ������Τ����Ѥ����ؿ���
 */
BOOL	skkinputlisp_PrintConsListSub (LPCONSLIST lpConsListNode)
{
	if (!lpConsListNode)
		return	FALSE ;
	skkinputlisp_PrintConsNode (&lpConsListNode->m_left) ;
	PRINTF (MYTEXT (" . ")) ;
	skkinputlisp_PrintConsNode (&lpConsListNode->m_right) ;
	return	TRUE ;
}

#endif

