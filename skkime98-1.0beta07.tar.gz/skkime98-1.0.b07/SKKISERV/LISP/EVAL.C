#ifdef DEBUG
#include <stdio.h>
#endif 
#include "windows.h"
#include "lmcons.h"
#include "tchar.h"
#include "mylocale.h"
#include "lisp.h"
#include "mystring.h"
#include "winfile.h"
#include "unicode.h"

/*
 *	Prototypes
 */
static	LPSKKLISPENTITY	skkinputlisp_eval (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_quote (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_function (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_car (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_cdr (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_cons (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_set (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_setq (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_null (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)  ;
static	LPSKKLISPENTITY	skkinputlisp_and (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_or (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_cond (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_if (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_aref (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_aset (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_defun (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_lambda (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_progn (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_prog1 (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_multiply (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_divide (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_plus (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_minus (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_let (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_leta (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_eq (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_assq (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_concat (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_string_to_int (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_int_to_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_make_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_substring (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_current_time_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_j_date (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_load_file (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_make_keymap (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_define_key (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_copy_keymap (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_while (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_EvalFunc (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_lesser_than (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_lesser_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_greater_than (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_greater_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_integer_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_char_to_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_user_login_name (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;
static	LPSKKLISPENTITY	skkinputlisp_get_windows_directory (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) ;

/*
 *	Global Variables
 */
static	SKKLISPFUNC	skkinputlispFunctionTable[] = {
	{ MYTEXT ("quote"),					skkinputlisp_quote },
	{ MYTEXT ("function"),				skkinputlisp_function },
	{ MYTEXT ("car"),					skkinputlisp_car }, 
	{ MYTEXT ("cdr"),					skkinputlisp_cdr }, 
	{ MYTEXT ("cons"),					skkinputlisp_cons }, 
	{ MYTEXT ("set"),					skkinputlisp_set }, 
	{ MYTEXT ("setq"),					skkinputlisp_setq }, 
	{ MYTEXT ("eval"),					skkinputlisp_eval }, 
	{ MYTEXT ("null"),					skkinputlisp_null },
	{ MYTEXT ("not"),					skkinputlisp_null },
	{ MYTEXT ("and"),					skkinputlisp_and },
	{ MYTEXT ("or"),					skkinputlisp_or },
	{ MYTEXT ("cond"),					skkinputlisp_cond },
	{ MYTEXT ("if"),					skkinputlisp_if },
	{ MYTEXT ("aref"),					skkinputlisp_aref },
	{ MYTEXT ("aset"),					skkinputlisp_aset },
	{ MYTEXT ("defun"),					skkinputlisp_defun },
	{ MYTEXT ("lambda"),				skkinputlisp_lambda },
	{ MYTEXT ("progn"),					skkinputlisp_progn },
	{ MYTEXT ("prog1"),					skkinputlisp_prog1 },
	{ MYTEXT ("*"),						skkinputlisp_multiply },
	{ MYTEXT ("/"),						skkinputlisp_divide },
	{ MYTEXT ("+"),						skkinputlisp_plus },
	{ MYTEXT ("-"),						skkinputlisp_minus },
	{ MYTEXT ("let"),					skkinputlisp_let },
	{ MYTEXT ("let*"),					skkinputlisp_leta },
	{ MYTEXT ("eq"),					skkinputlisp_eq },
	{ MYTEXT ("equal"),					skkinputlisp_equal },
	{ MYTEXT ("assq"),					skkinputlisp_assq },
	{ MYTEXT ("concat"),				skkinputlisp_concat },
	{ MYTEXT ("string-to-int"),			skkinputlisp_string_to_int },
	{ MYTEXT ("int-to-string"),			skkinputlisp_int_to_string },
	{ MYTEXT ("make-string"),			skkinputlisp_make_string },
	{ MYTEXT ("substring"),				skkinputlisp_substring },
	{ MYTEXT ("current-time-string"),	skkinputlisp_current_time_string },
	{ MYTEXT ("j-date"),				skkinputlisp_j_date },
	{ MYTEXT ("load-file"),				skkinputlisp_load_file },
	{ MYTEXT ("make-keymap"),			skkinputlisp_make_keymap },
	{ MYTEXT ("define-key"),			skkinputlisp_define_key },
	{ MYTEXT ("copy-keymap"),			skkinputlisp_copy_keymap },
	{ MYTEXT ("while"),					skkinputlisp_while },
	{ MYTEXT ("<"),						skkinputlisp_lesser_than },
	{ MYTEXT ("<="),					skkinputlisp_lesser_equal },
	{ MYTEXT (">"),						skkinputlisp_greater_than },
	{ MYTEXT (">="),					skkinputlisp_greater_equal },
	{ MYTEXT ("="),						skkinputlisp_integer_equal },
	{ MYTEXT ("char-to-string"),		skkinputlisp_char_to_string },
	{ MYTEXT ("user-login-name"),		skkinputlisp_user_login_name },
	{ MYTEXT ("get-windows-directory"),	skkinputlisp_get_windows_directory },
	{ NULL, 							NULL },
} ;

/*
 *	Global Functions
 */
LPSKKLISPENTITY	skkinputlisp_EvalEntity (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPVAR	lpSkkLispVar ;
	if (!lpEntity)
		return	NULL ;
	switch (lpEntity->m_iType){
	case ENTITY_CONS:
		return	skkinputlisp_EvalFunc (lpEntity, lpEnvironment) ;
	case ENTITY_ATOM:
		if (skkinputlisp_IsNil (lpEntity) ||
			skkinputlisp_IsT (lpEntity))
			return	lpEntity ;
		lpSkkLispVar	= skkinputlisp_GlobalSearchVariable (lpEntity->m_data.m_lpString, lpEnvironment) ;
		if (!lpSkkLispVar)
			return	NULL ;
		return	lpSkkLispVar->m_lpValue ;
	case ENTITY_ARRAY:
	case ENTITY_STRING:
	case ENTITY_INTEGER:
	default:
		return	lpEntity ;
	}
}

/*
 * private functions
 */

LPSKKLISPENTITY	skkinputlisp_eval (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpArg ;
	/* ��1���������o���B*/
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��U��1������]������B*/
	lpArg	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpArg)
		return	NULL ;	
	/* ���̈������ēx�]������B(eval) */
	return	skkinputlisp_EvalEntity (lpArg, lpEnvironment) ;
}

LPSKKLISPENTITY	skkinputlisp_quote (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	/* ��1���������o���B*/
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	return lpEntity->m_data.m_conspair.m_lpLeftEntity ;
}

/*
 *	function:
 *		`quote' �̂悤�ɓ���...�B�{���͂��ꂾ���ł͂Ȃ��̂����Abyte-compile ���Ȃ��̂�
 *		�֌W�����Ƃ��Ă��������B
 */
LPSKKLISPENTITY	skkinputlisp_function (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	/* ��1���������o���B*/
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	return lpEntity->m_data.m_conspair.m_lpLeftEntity ;
}

LPSKKLISPENTITY	skkinputlisp_car (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	/* ��1���������o���B*/
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��1������]������B*/
	lpEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	lpEntity	= skkinputlisp_EvalEntity (lpEntity, lpEnvironment) ;
	/* �]���������ʂ� list (conspair) �łȂ��Ă͂Ȃ�Ȃ��B*/
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* �]���������ʂ̐擪�v�f��Ԃ��B*/
	return	lpEntity->m_data.m_conspair.m_lpLeftEntity ;
}

LPSKKLISPENTITY	skkinputlisp_cdr (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	/* ��1���������o���B*/
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��1������]������B*/
	lpEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	lpEntity	= skkinputlisp_EvalEntity (lpEntity, lpEnvironment) ;
	/* �]���������ʂ� list (conspair) �łȂ��Ă͂Ȃ�Ȃ��B*/
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	return	lpEntity->m_data.m_conspair.m_lpRightEntity ;
}

LPSKKLISPENTITY	skkinputlisp_cons (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpLeftEntity ;
	LPSKKLISPENTITY	lpRightEntity ;
	SKKLISPENTITY	newEntity ;
	/* ��1���������o���B*/
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS ||
		skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��1������]������B*/
	lpLeftEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	/* ��2���������o���B*/
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��2������]������B*/
	lpRightEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpLeftEntity || !lpRightEntity)
		return	NULL ;
	/* ��1�����̕]�����ʂƑ�2�����̕]�����ʂ� conspair �ɂ��ĕԂ��B*/
	newEntity.m_iType							= ENTITY_CONS ;
	newEntity.m_data.m_conspair.m_lpLeftEntity	= lpLeftEntity ;
	newEntity.m_data.m_conspair.m_lpRightEntity	= lpRightEntity ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

LPSKKLISPENTITY	skkinputlisp_set (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpLeftEntity ;
	LPSKKLISPENTITY	lpRightEntity ;
	LPSKKLISPVAR	lpVarNode ;
	LPMYSTR			lpVarName ;
	/* ��1���������o���B*/
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS ||
		skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��1������]������B*/
	lpLeftEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpLeftEntity || lpLeftEntity->m_iType != ENTITY_ATOM)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS || 
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpRightEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpRightEntity)
		return	NULL ;
	lpVarName		= lpLeftEntity->m_data.m_lpString ;
	lpVarNode		= skkinputlisp_CreateGlobalVariable (lpVarName, lpEnvironment) ;
	if (!lpVarNode){
		return	NULL ;
	}
	if (lpVarNode->m_lpValue){
		skkinputlisp_DecReferCount (lpVarNode->m_lpValue) ;
		lpVarNode->m_lpValue	= NULL ;
	}
	skkinputlisp_IncReferCount (lpRightEntity) ;
	lpVarNode->m_lpValue	= lpRightEntity ;
	return	lpRightEntity ;
}

LPSKKLISPENTITY	skkinputlisp_setq (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpLeftEntity ;
	LPSKKLISPENTITY	lpRightEntity ;
	LPSKKLISPVAR	lpVarNode ;
	LPMYSTR			lpVarName ;
	/* ��1���������o���B*/
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS ||
		skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��1������]�����Ȃ��B������ set quote �ƂȂ�B*/
	lpLeftEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpLeftEntity || lpLeftEntity->m_iType != ENTITY_ATOM)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity ||
		lpEntity->m_iType != ENTITY_CONS || 
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpRightEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpRightEntity)
		return	NULL ;
	lpVarName		= lpLeftEntity->m_data.m_lpString ;
	lpVarNode		= skkinputlisp_CreateGlobalVariable (lpVarName, lpEnvironment) ;
	if (!lpVarNode){
		return	NULL ;
	}
	if (lpVarNode->m_lpValue){
		skkinputlisp_DecReferCount (lpVarNode->m_lpValue) ;
		lpVarNode->m_lpValue	= NULL ;
	}
	skkinputlisp_IncReferCount (lpRightEntity) ;
	lpVarNode->m_lpValue	= lpRightEntity ;
	return	lpRightEntity ;
}

/*
 *	(null OBJ):
 *		OBJ �� nil �Ȃ�΁AT ��Ԃ��֐��B
 */
LPSKKLISPENTITY	skkinputlisp_null (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment) 
{
	LPSKKLISPENTITY	lpValue ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpValue	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpValue)
		return	NULL ;
	return	skkinputlisp_IsNil (lpValue)? skkinputlisp_TEntity () : skkinputlisp_NilEntity () ;
}

LPSKKLISPENTITY	skkinputlisp_and (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpResult ;
	if (!lpEntity)
		return	NULL ;
	if (lpEntity->m_iType != ENTITY_CONS)
		return (skkinputlisp_IsNil (lpEntity))? skkinputlisp_TEntity () : NULL ;
	lpResult	= skkinputlisp_TEntity () ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpResult	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		if (skkinputlisp_IsNil (lpResult))
			return	skkinputlisp_NilEntity () ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	lpResult ;
}

/*
 *	(or ...):
 *		������ non-nil ���Ԃ�܂ŏ��Ԃɕ]������Bnon-nil ������������A���̒l��Ԃ��B
 *		���̎��A�c��̈����͕]������Ȃ��B�S�Ă̈����� nil ��Ԃ��΁Anil ��Ԃ��B
 */
LPSKKLISPENTITY	skkinputlisp_or (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpResult ;
	if (!lpEntity)
		return	NULL ;
	if (lpEntity->m_iType != ENTITY_CONS)
		return (skkinputlisp_IsNil (lpEntity))? skkinputlisp_NilEntity () : NULL ;
	lpResult	= skkinputlisp_NilEntity () ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpResult	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		if (!skkinputlisp_IsNil (lpResult))
			return	lpResult ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	lpResult ;
}

/*
 *	(cond CLAUSES ...):
 *		�����ꂩ�̐߂���������܂ŁA�߂�]�����Ă����֐��B�e�߂� (CONDITION BODY...) ��
 *		�悤�Ȍ`�������Ă���BCONDITION ���]������āA���̒l�� non-nil �������ꍇ�ɂ́A
 *		���̐߂͐��������Ƃ����B���̎��ABODY �̎����]������āA��ԍŌ�̒l�� cond-form
 *		�̒l�ƂȂ�B
 *		�����ǂ̐߂��������Ȃ���΁Acond �� nil ��Ԃ��B
 *		�����߂�1�����v�f�������Ȃ��ꍇ�A���Ȃ킿 (CONDITON) �̂悤�ȏꍇ�ł��邪�A
 *		CONDITION �̒l�� non-nil �Ȃ炻�̒l�� cond-form �̒l�ɂȂ�B(?)
 */
LPSKKLISPENTITY	skkinputlisp_cond (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpLeftEntity ;
	LPSKKLISPENTITY	lpResult ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ���Ԃ� (cond A B C...) �� A, B, C �̕�����]������B*/
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		/* ����������]������B*/
		lpLeftEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (!lpLeftEntity)
			return	NULL ;
		if (skkinputlisp_IsNil (lpLeftEntity)){
			lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
			continue ;
		}
		if (lpLeftEntity->m_iType != ENTITY_CONS){
			return	NULL ;
		}
		lpResult	= skkinputlisp_EvalEntity (lpLeftEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		if (!lpResult){
			return	NULL ;
		}
		/* �����̔��茋�ʂ� nil �łȂ���΁A�������ʕ�����]������B*/
		if (!skkinputlisp_IsNil (lpResult)){
			lpLeftEntity	= lpLeftEntity->m_data.m_conspair.m_lpRightEntity ;
			while (lpLeftEntity && lpLeftEntity->m_iType == ENTITY_CONS){
				lpResult		= skkinputlisp_EvalEntity (lpLeftEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
				lpLeftEntity	= lpLeftEntity->m_data.m_conspair.m_lpRightEntity ;
			}
			if (!skkinputlisp_IsNil (lpLeftEntity)){
				return	NULL ;
			}
			return	lpResult ;
		}
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	skkinputlisp_NilEntity () ;
}

/*
 *	(if COND THEN ELSE...):
 *		���� COND �� non-nil �Ȃ�΁ATHEN �����s(�]��)����B�����Ȃ��΁AELSE ... �𒀎�
 *		�]������Bif �� THEN �̒l�������͍Ō�� ELSE �̒l��Ԃ��BTHEN ��1�����łȂ����
 *		�Ȃ�Ȃ��B���AELSE �́Z�������͕�����蓾��B
 *		COND �� nil �� ELSE ��������΁Anil �����̎��̒l�ł���B
 */
LPSKKLISPENTITY	skkinputlisp_if (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpLeftEntity ;
	LPSKKLISPENTITY	lpResult ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpLeftEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpLeftEntity)
		return	NULL ;
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	if (!skkinputlisp_IsNil (lpLeftEntity)){
		return	skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;		
	}
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	lpResult		= skkinputlisp_IsNil (lpEntity)? skkinputlisp_NilEntity () : NULL ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpResult	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	return	lpResult ;
}

/*
 *	(aref �z�� �z��̗v�f�ԍ�)
 */
LPSKKLISPENTITY	skkinputlisp_aref (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpArrayEntity ;
	LPSKKLISPENTITY	lpIntegerEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ��1�����̕]���B��1�����͔z��łȂ���΂Ȃ�Ȃ��B*/
	lpArrayEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpArrayEntity || lpArrayEntity->m_iType != ENTITY_ARRAY)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ��2�����̕]���B��2�����͐����łȂ���΂Ȃ�Ȃ��B*/
	lpIntegerEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpIntegerEntity || lpIntegerEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	if (!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	if (lpIntegerEntity->m_data.m_integer <  0 ||
		lpIntegerEntity->m_data.m_integer >= lpArrayEntity->m_data.m_array.m_iLength)
		return	NULL ;
	return	((LPSKKLISPENTITY FAR *)lpArrayEntity->m_data.m_array.m_lpArray) [lpIntegerEntity->m_data.m_integer] ;
}

/*
 * (aset �z�� �z��̗v�f�ԍ� �������l)
 */
LPSKKLISPENTITY	skkinputlisp_aset (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY			lpArrayEntity ;
	LPSKKLISPENTITY			lpIntegerEntity ;
	LPSKKLISPENTITY			lpValueEntity ;
	LPSKKLISPENTITY FAR*	lpArray ;
	int						iNumber ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ��1�����̕]���B��1�����͔z��łȂ���΂Ȃ�Ȃ��B*/
	lpArrayEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpArrayEntity || lpArrayEntity->m_iType != ENTITY_ARRAY)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ��2�����̕]���B��2�����͐����łȂ���΂Ȃ�Ȃ��B*/
	lpIntegerEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpIntegerEntity || lpIntegerEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ��3�����̕]���B��3�����͐ݒ肷�����(ENTITY)�ł���B*/
	lpValueEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!skkinputlisp_IsNil (lpEntity))
		return	NULL ;
	/* ���̂��C������B*/
	iNumber		= lpIntegerEntity->m_data.m_integer ;
	if (iNumber <  0 || iNumber >= lpArrayEntity->m_data.m_array.m_iLength)
		return	NULL ;
	lpArray		= lpArrayEntity->m_data.m_array.m_lpArray ;
	skkinputlisp_AddReferCount (lpArray [iNumber], - lpArrayEntity->m_lReferCount) ;
	lpArray [iNumber]	= lpValueEntity ;
	skkinputlisp_AddReferCount (lpValueEntity, lpArrayEntity->m_lReferCount) ;
	return	lpValueEntity ;
}

LPSKKLISPENTITY	skkinputlisp_defun (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFunctionName ;
	LPSKKLISPENTITY	lpLambdaEntity ;
	LPSKKLISPENTITY	lpFuncEntity ;
	SKKLISPENTITY	newEntity ;
	LPMYSTR			lpFuncName ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* �֐��������B����� eval ����K�v�͂Ȃ��݂����B*/
	lpFunctionName	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpFunctionName || lpFunctionName->m_iType != ENTITY_ATOM){
#ifdef DEBUG
		printf ("Wrong type argument: symbolp, \n") ;
#endif      
		return	NULL ;
	}
	lpFuncName		= lpFunctionName->m_data.m_lpString ;
	/* �Œ�ł� 2 �͈������K�v�B*/
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	newEntity.m_iType							= ENTITY_ATOM ;
	newEntity.m_data.m_lpString					= MYTEXT ("lambda") ;
	lpLambdaEntity	= skkinputlisp_CreateNewEntity (&newEntity) ;
	if (!lpLambdaEntity)
		return	NULL ;
	newEntity.m_iType							= ENTITY_CONS ;
	newEntity.m_data.m_conspair.m_lpLeftEntity	= lpLambdaEntity ;
	newEntity.m_data.m_conspair.m_lpRightEntity	= lpEntity ;
	lpFuncEntity	= skkinputlisp_CreateNewEntity (&newEntity) ;
	if (!lpFuncEntity)
		return	NULL ;
	/* lpFuncEntity �� lpFunctionName �œo�^����B*/	
	if (!skkinputlisp_CreateGlobalFunction (lpFuncName, lpFuncEntity, lpEnvironment))
		return	NULL ;
	newEntity.m_iType							= ENTITY_ATOM ;
	newEntity.m_data.m_lpString					= lpFuncName ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

/*
 *	lambda:	Lisp Macro �̈��
 *		lambda ����Ԃ��B(lambda ARGS DOCSTRING INTERACTIVE BODY) �̌`���̌Ăяo���́A
 *		self-quoting�A��������lambda���̕]�����ʂ͂��̎����g�ɂȂ�B
 *		lambda ���͊֐��Ƃ��Ĉ����ėǂ��B
 *		ARGS �� defun �ɂ���̂Ɠ����`���̈����̃��X�g���Ƃ�BDOCSTRING �͕�����ŁA
 *		defun �Ɠ����ł���BINTERACTIVE ��...�������B
 */
LPSKKLISPENTITY	skkinputlisp_lambda (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	SKKLISPENTITY	newEntity ;
	LPSKKLISPENTITY	lpLambdaEntity ;
	if (!lpEntity || (lpEntity->m_iType != ENTITY_CONS && !skkinputlisp_IsNil (lpEntity)))
		return	NULL ;
	/* �����͔��������...�B�{�������ɗ����Ƃ������Ƃ� (lambda (..) ...) �̌`���̔�...�B*/
	newEntity.m_iType							= ENTITY_ATOM ;
	newEntity.m_data.m_lpString					= MYTEXT ("lambda") ;
	lpLambdaEntity	= skkinputlisp_CreateNewEntity (&newEntity) ;
	if (!lpLambdaEntity)
		return	NULL ;
	newEntity.m_iType							= ENTITY_CONS ;
	newEntity.m_data.m_conspair.m_lpLeftEntity	= lpLambdaEntity ;
	newEntity.m_data.m_conspair.m_lpRightEntity	= lpEntity ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

/*
 *	(progn BODY ...) :
 *		BODY form �𒀎��]�����A�Ō�� BODY �̒l��Ԃ��B
 */
LPSKKLISPENTITY	skkinputlisp_progn (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpResult ;
	if (!lpEntity || (lpEntity->m_iType != ENTITY_CONS && !skkinputlisp_IsNil (lpEntity)))
		return	NULL ;
	lpResult		= skkinputlisp_NilEntity () ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpResult	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		if (!lpResult)
			return	NULL ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	if (!skkinputlisp_IsNil (lpEntity))
		lpResult	= NULL ;
	return	lpResult ;
}

/*
 *	(prog1 FIRST BODY ...):
 *		FIRST �� BODY �𒀎��A�]�����Ă����֐��BFIRST �̒l���Ԃ�l�ɂȂ�B
 *		�c��̈����̕]���̊Ԃ� FIRST �̒l�͕ۑ�����邪�A���̒l�͔j�������B
 */
LPSKKLISPENTITY	skkinputlisp_prog1 (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpResult ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ��Ԑ擪�̈�����]������B���̌��ʂ��Ԃ�l�ɂȂ�B*/
	lpResult	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpResult)
		return	NULL ;
	/* �c��̃��X�g(BODY) �����Ԃɕ]������B*/
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		if (!skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment))
			return	NULL ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	if (!skkinputlisp_IsNil (lpEntity))
		lpResult	= NULL ;
	return	lpResult ;
}

/*
 *	(* ...)
 *		�����̐ς��Ƃ��ĕԂ��֐��B�����͐����������̓}�[�J�[�����������A�}�[�J�[�͎�������
 *		�Ă͂��Ȃ��̂ŁA�����݂̂ł���B
 */
LPSKKLISPENTITY	skkinputlisp_multiply (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpValue ;
	SKKLISPENTITY	newEntity ;
	int				iValue ;
	if (!lpEntity)
		return	NULL ;
	iValue	= 1 ;
	if (!skkinputlisp_IsNil (lpEntity)){
	 	if (lpEntity->m_iType != ENTITY_CONS)
			return	NULL ;
		while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
			lpValue	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
			if (!lpValue || lpValue->m_iType != ENTITY_INTEGER)
				return	NULL ;
			iValue		= iValue * lpValue->m_data.m_integer ;
			lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		}
		if (!skkinputlisp_IsNil (lpEntity))
			return	NULL ;
	}
	newEntity.m_iType			= ENTITY_INTEGER ;
	newEntity.m_data.m_integer	= iValue ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;	
}

LPSKKLISPENTITY	skkinputlisp_divide (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpValue ;
	SKKLISPENTITY	newEntity ;
	int				iValue ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* �폜���𔲂��o���B*/
	lpValue	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpValue || lpValue->m_iType != ENTITY_INTEGER)
		return	NULL ;
	iValue		= lpValue->m_data.m_integer ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* �����Ŕ폜�������ԂɊ����Ă����B*/
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpValue	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		if (!lpValue || lpValue->m_iType != ENTITY_INTEGER)
			return	NULL ;
		/* �Z�Ŋ����Ă͂Ȃ�Ȃ��B*/
		if (lpValue->m_data.m_integer == 0)
			return	NULL ;
		iValue		= iValue / lpValue->m_data.m_integer ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	if (!skkinputlisp_IsNil (lpEntity))
		return	NULL ;
	newEntity.m_iType			= ENTITY_INTEGER ;
	newEntity.m_data.m_integer	= iValue ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;	
}

/*
 *		�����̘a�����߂�֐��B�����ɂ�(�]���̌��ʂ�)����(�̂���)������������Ă���B
 */
LPSKKLISPENTITY	skkinputlisp_plus (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpValue ;
	SKKLISPENTITY	newEntity ;
	int				iValue ;
	if (!lpEntity)
		return	NULL ;
	iValue	= 0 ;
	if (!skkinputlisp_IsNil (lpEntity)){
		if (lpEntity->m_iType != ENTITY_CONS)
			return	NULL ;
		while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
			lpValue	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
			if (!lpValue || lpValue->m_iType != ENTITY_INTEGER)
				return	NULL ;
			iValue		= iValue + lpValue->m_data.m_integer ;
			lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		}
		if (!skkinputlisp_IsNil (lpEntity))
			return	NULL ;
	}
	newEntity.m_iType			= ENTITY_INTEGER ;
	newEntity.m_data.m_integer	= iValue ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;	
}

/*
 *		�����������͍������߂�֐��B
 *		������1�Ȃ�A���̕��������߂�B1�ȏ�̈��������݂�����A�ŏ��̈�������c���
 *		���������������ʂ����߂�B
 */
LPSKKLISPENTITY	skkinputlisp_minus (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpValue ;
	SKKLISPENTITY	newEntity ;
	int				iValue ;
	if (!lpEntity)
		return	NULL ;
	iValue	= 0 ;
	if (!skkinputlisp_IsNil (lpEntity)){
		if (lpEntity->m_iType != ENTITY_CONS)
			return	NULL ;
		/* �ŏ��̈��������߂�B*/
		lpValue	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		if (!lpValue || lpValue->m_iType != ENTITY_INTEGER)
			return	NULL ;
		iValue		= lpValue->m_data.m_integer ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		if (!lpEntity)
			return	NULL ;
		/* �����͈�����Ȃ����H */
		if (skkinputlisp_IsNil (lpEntity)){
			newEntity.m_iType			= ENTITY_INTEGER ;
			newEntity.m_data.m_integer	= - iValue ;
			return	skkinputlisp_CreateNewEntity (&newEntity) ;
		}
		if (lpEntity->m_iType != ENTITY_CONS)
			return	NULL ;
		/* �ŏ��̈�������c��̈��������������ʂ����߂�B*/
		while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
			lpValue	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
			if (!lpValue || lpValue->m_iType != ENTITY_INTEGER)
				return	NULL ;
			iValue		= iValue - lpValue->m_data.m_integer ;
			lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		}
		/* �������Ō�̈����܂ň������Ƃ��o���܂�����? */
		if (!skkinputlisp_IsNil (lpEntity))
			return	NULL ;
	}
	newEntity.m_iType			= ENTITY_INTEGER ;
	newEntity.m_data.m_integer	= iValue ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;	
}

/*
 *	(let VARLIST BODY ...)
 *		VARLIST �ɏ]���ĕϐ���ݒ肵�Ă���ABODY... ��]������BBODY �̈�ԍŌ�̎��̒l��
 *		let �̒l�ƂȂ�B
 *		VARLIST �̊e�X�̗v�f�̓V���{���ł��邩(���̏ꍇ�� nil �ɏ����������)�A
 *		(SYMBOL VALUEFORM) �̃��X�g(SYMBOL �� VALUEFORM �̒l�ŏ����������)�ł���B
 *		�S�Ă� VALUEFORM �� symbol �������������O�ɕ]�������B
 * (��)
 *		�����ł͂��񂿂������āAVALUEFORM �̕]���� symbol �̏������͒����I�ɍs���Ă���B
 *		������ symbol �̏���������� VALUEFORM �̕]���ɉe�����Ȃ��悤�ɂ��Ă���B
 *		����œ������ɂȂ�Ǝv���̂���...�B�������AVALUEFORM �̕]���ŕ���p����������
 *		�悤�Ȃ��Ƃ����ꂽ��ǂ��Ȃ�̂��낤�H
 */
LPSKKLISPENTITY	skkinputlisp_let (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpVarsEntity ;
	LPSKKLISPENTITY	lpVarEntity ;
	LPSKKLISPENTITY	lpValueEntity ;
	LPSKKLISPENTITY	lpResult ;
	LPSKKLISPENV	lpEnv ;
	LPSKKLISPENV	lpLocalEnv ;
	LPSKKLISPVAR	lpLocalVar ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS){
		return	NULL ;
	}
	lpVarsEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpVarsEntity || (lpVarsEntity->m_iType != ENTITY_CONS && !skkinputlisp_IsNil (lpVarsEntity))){
		return	NULL ;
	}
	lpLocalEnv		= NULL ;
	if (lpVarsEntity->m_iType == ENTITY_CONS){
		/* �Ǐ��ϐ��p�̊����쐬����B*/
		lpLocalEnv		= skkinputlisp_CreateNewEnvironment (lpEnvironment) ;
		if (!lpLocalEnv){
			return	NULL ;
		}
		/* ���ԂɋǏ��ϐ����쐬���āA�����l��ݒ肷��B*/
		while (lpVarsEntity && lpVarsEntity->m_iType == ENTITY_CONS){
			lpVarEntity	= lpVarsEntity->m_data.m_conspair.m_lpLeftEntity ;
			if (!lpVarEntity){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			if (lpVarEntity->m_iType == ENTITY_CONS){
				/* (�ϐ��� �l) �̌`���̏ꍇ�B*/
				lpValueEntity	= lpVarEntity->m_data.m_conspair.m_lpRightEntity ;
				lpVarEntity		= lpVarEntity->m_data.m_conspair.m_lpLeftEntity ;
				if (!lpValueEntity || (lpValueEntity->m_iType != ENTITY_CONS &&	!skkinputlisp_IsNil (lpValueEntity))){
					skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
					return	NULL ;
				}
				if (lpValueEntity->m_iType == ENTITY_CONS){
					lpValueEntity	= skkinputlisp_EvalEntity (lpValueEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
				} else {
					lpValueEntity	= skkinputlisp_NilEntity () ;
				}
			} else {
				/* �ϐ����������ׂĂ���ꍇ�B*/
				lpValueEntity	= skkinputlisp_NilEntity () ;
			}
			/* �ϐ����͐������V���{���ł��邩�H */
			if (!lpVarEntity || lpVarEntity->m_iType != ENTITY_ATOM){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			/* �Ǐ��ϐ����쐬����B*/
			lpLocalVar	= skkinputlisp_CreateLocalVariable (lpVarEntity->m_data.m_lpString, lpLocalEnv) ;
			if (!lpLocalVar){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			/* �Ǐ��ϐ��ɒl��������B*/
			if (lpLocalVar->m_lpValue)
				skkinputlisp_DecReferCount (lpLocalVar->m_lpValue) ;
			lpLocalVar->m_lpValue	= lpValueEntity ;
			skkinputlisp_IncReferCount (lpValueEntity) ;
			lpVarsEntity	= lpVarsEntity->m_data.m_conspair.m_lpRightEntity ;
		}
		if (!skkinputlisp_IsNil (lpVarsEntity)){
			skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
			return	NULL ;
		}
		lpEnv	= lpLocalEnv ;
	} else {
		lpEnv	= lpEnvironment ;
	}
	/* �쐬�����Ǐ����̂��Ƃŏ��ԂɃ��X�g��]�����Ă����B*/
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	lpResult	= skkinputlisp_NilEntity () ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpResult	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnv) ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	/* �������]���ł��Ȃ������ꍇ�ɂ̓G���[�BNULL ��Ԃ��B*/
	if (!skkinputlisp_IsNil (lpEntity)){
		lpResult	= NULL ;
	}
	/* �Ǐ���������Ă����ꍇ�ɂ͉������B*/
	if (lpLocalEnv)
		skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
	return	lpResult ;	
}

/*
 *	(let* VARLIST BODY ...)
 *		VARLIST �ɏ]���ĕϐ���ݒ肵�Ă���ABODY... ��]������BBODY �̈�ԍŌ�̎��̒l��
 *		let �̒l�ƂȂ�B
 *		VARLIST �̊e�X�̗v�f�̓V���{���ł��邩(���̏ꍇ�� nil �ɏ����������)�A
 *		(SYMBOL VALUEFORM) �̃��X�g(SYMBOL �� VALUEFORM �̒l�ŏ����������)�ł���B
 *		VALUEFORM �͊��� VARLIST �ɂ���ď��������ꂽ symbol ���Q�Ƃ��Ȃ���]�������B
 */
LPSKKLISPENTITY	skkinputlisp_leta (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpVarsEntity ;
	LPSKKLISPENTITY	lpVarEntity ;
	LPSKKLISPENTITY	lpValueEntity ;
	LPSKKLISPENTITY	lpResult ;
	LPSKKLISPENV	lpEnv ;
	LPSKKLISPENV	lpLocalEnv ;
	LPSKKLISPVAR	lpLocalVar ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpVarsEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpVarsEntity || (lpVarsEntity->m_iType != ENTITY_CONS && !skkinputlisp_IsNil (lpVarsEntity)))
		return	NULL ;
	lpLocalEnv		= NULL ;
	if (lpVarsEntity->m_iType == ENTITY_CONS){
		/* �Ǐ��ϐ��p�̊����쐬����B*/
		lpLocalEnv		= skkinputlisp_CreateNewEnvironment (lpEnvironment) ;
		if (!lpLocalEnv)
			return	NULL ;
		/* ���ԂɋǏ��ϐ����쐬���āA�����l��ݒ肷��B*/
		while (lpVarsEntity && lpVarsEntity->m_iType == ENTITY_CONS){
			lpVarEntity	= lpVarsEntity->m_data.m_conspair.m_lpLeftEntity ;
			if (!lpVarEntity){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			if (lpVarEntity->m_iType == ENTITY_CONS){
				/* (�ϐ��� �l) �̌`���̏ꍇ�B*/
				lpValueEntity	= lpVarEntity->m_data.m_conspair.m_lpRightEntity ;
				lpVarEntity		= lpVarEntity->m_data.m_conspair.m_lpLeftEntity ;
				if (!lpValueEntity || (lpValueEntity->m_iType != ENTITY_CONS &&	!skkinputlisp_IsNil (lpValueEntity))){
					skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
					return	NULL ;
				}
				if (lpValueEntity->m_iType == ENTITY_CONS){
					/* let* �̏ꍇ�A���ɐݒ肳��Ă���ϐ����e������B����͂��Ȃ킿�]���Ɏg��
					 * ���Ɍ��ݍ�����������邱�Ƃ��Ӗ�����B*/
					lpValueEntity	= skkinputlisp_EvalEntity (lpValueEntity->m_data.m_conspair.m_lpLeftEntity, lpLocalEnv) ;
				} else {
					lpValueEntity	= skkinputlisp_NilEntity () ;
				}
			} else {
				/* �ϐ����������ׂĂ���ꍇ�B*/
				lpValueEntity	= skkinputlisp_NilEntity () ;
			}
			/* �ϐ����͐������V���{���ł��邩�H */
			if (!lpVarEntity || lpVarEntity->m_iType != ENTITY_ATOM){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			/* �Ǐ��ϐ����쐬����B*/
			lpLocalVar	= skkinputlisp_CreateLocalVariable (lpVarEntity->m_data.m_lpString, lpLocalEnv) ;
			if (!lpLocalVar){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			/* �Ǐ��ϐ��ɒl��������B*/
			if (lpLocalVar->m_lpValue)
				skkinputlisp_DecReferCount (lpLocalVar->m_lpValue) ;
			lpLocalVar->m_lpValue	= lpValueEntity ;
			skkinputlisp_IncReferCount (lpValueEntity) ;
			lpVarsEntity	= lpVarsEntity->m_data.m_conspair.m_lpRightEntity ;
		}
		if (!skkinputlisp_IsNil (lpVarsEntity)){
			skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
			return	NULL ;
		}
		lpEnv	= lpLocalEnv ;
	} else {
		lpEnv	= lpEnvironment ;
	}
	/* �쐬�����Ǐ����̂��Ƃŏ��ԂɃ��X�g��]�����Ă����B*/
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	lpResult	= skkinputlisp_NilEntity () ;
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpResult	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnv) ;
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	/* �������]���ł��Ȃ������ꍇ�ɂ̓G���[�BNULL ��Ԃ��B*/
	if (!skkinputlisp_IsNil (lpEntity))
		lpResult	= NULL ;
	/* �Ǐ���������Ă����ꍇ�ɂ͉������B*/
	if (lpLocalEnv)
		skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
	return	lpResult ;	
}

/*
 *	(eq OBJ1 OBJ2):
 *		�����ɗ^����ꂽ OBJ1, OBJ2 ������� lisp object �Ȃ�� T ��Ԃ��֐��B
 */
LPSKKLISPENTITY	skkinputlisp_eq (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFirstArg ;
	LPSKKLISPENTITY	lpSecondArg ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFirstArg	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstArg)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpSecondArg	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpSecondArg)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || !skkinputlisp_IsNil (lpEntity))
		return	NULL ;
	if (lpFirstArg == lpSecondArg)
		return	skkinputlisp_TEntity () ;
	return	skkinputlisp_NilEntity () ;
}

/*
 *	(equal OBJ1 OBJ2):
 *		OBJ1,OBJ2 �������\���A�������e�� Lisp Object �ł��鎞�� T ��Ԃ��֐��B
 *		OBJ1,OBJ2 �͓����^�łȂ���΂Ȃ�Ȃ��B
 */
LPSKKLISPENTITY	skkinputlisp_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFirstArg ;
	LPSKKLISPENTITY	lpSecondArg ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFirstArg	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstArg)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpSecondArg	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstArg)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || !skkinputlisp_IsNil (lpEntity))
		return	NULL ;
	if (skkinputlisp_CompareEntity (lpFirstArg, lpSecondArg))
		return	skkinputlisp_TEntity () ;
	return	skkinputlisp_NilEntity () ;
}

/*
 *	(assq KEY LIST):
 *		���� KEY �� LIST �̗v�f�� car �� 'eq' �Ȃ�΁Anon-nil ��Ԃ��B
 *		���̒l�͎��ۂ́Acar �� KEY �ł����� LIST �̗v�f�ł���B
 *		cons �łȂ� LIST �̗v�f�͖��������B
 */
LPSKKLISPENTITY	skkinputlisp_assq (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpKey ;
	LPSKKLISPENTITY	lpTmpEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* ��1�����A�����L�[�����o���B*/
	lpKey	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpKey)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	/* �����ΏۂƂȂ郊�X�g�y�ш����̐����`�F�b�N����B*/
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* ��2�����ALIST �����o���B*/
	lpEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	/* LIST �̒��̗v�f�� car �� KEY �ł�����̂�T���B*/
	while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
		lpTmpEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
		/* cons �łȂ� LIST �̗v�f�͖�������B*/
		if (lpTmpEntity->m_iType == ENTITY_CONS){
			if (lpKey == lpTmpEntity->m_data.m_conspair.m_lpLeftEntity)
				return	lpTmpEntity ;
		}
		lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	/* ������Ȃ������ꍇ�� NIL ��Ԃ��B*/
	return	skkinputlisp_NilEntity () ;
}

/*
 *		�����ɗ^����ꂽ������y�ѐ������܂Ƃ߂Ĉ�̕�����ɂ��ĕԂ��֐��B
 */
LPSKKLISPENTITY	skkinputlisp_concat (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY			lpResult ;
	LPSKKLISPENTITY			lpArg ;
	LPSKKLISPENTITY FAR*	lpArray ;
	SKKLISPENTITY			newEntity ;
	LPMYSTR					lpResultString ;
	LPMYSTR					lpNewString ;
	MYCHAR					buffer [32] ;
	long					lResultLength ;
	long					lLength ;
	long					i ;
	if (!lpEntity)
		return	NULL ;
	lpResultString	= NULL ;
	lResultLength	= 0 ;
	if (!skkinputlisp_IsNil (lpEntity)){
		if (lpEntity->m_iType != ENTITY_CONS)
			return	NULL ;
		while (lpEntity && lpEntity->m_iType == ENTITY_CONS){
			lpArg		= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
			if (!lpArg){
				if (lpResultString)
					HeapFree (GetProcessHeap (), 0, lpResultString) ;
				return	NULL ;
			}
			/* �����Ƃ��ċ�����Ă���̂́A������������͐����A�z��(�������v�f�͐���) */
			if (lpArg->m_iType == ENTITY_CONS || lpArg->m_iType == ENTITY_ATOM){
				if (lpResultString){
					HeapFree (GetProcessHeap (), 0, lpResultString) ;
					lpResultString	= NULL ;
				}
				return	NULL ;
			}
			switch (lpArg->m_iType){
			case ENTITY_STRING:
				lLength	= Mylstrlen (lpArg->m_data.m_lpString) ;
				if (lLength > 0){
					lResultLength	+=	lLength ;
					lpNewString		= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * (lResultLength + 1)) ;
					if (!lpNewString){
						if (lpResultString){
							HeapFree (GetProcessHeap (), 0, lpResultString) ;
							lpResultString	= NULL ;
						}
						return	NULL ;
					}
					if (!lpResultString){
						*lpNewString	= MYTEXT ('\0') ;
					} else {
						Mylstrcpy (lpNewString, lpResultString) ;
					}
					if (lpResultString){
						HeapFree (GetProcessHeap (), 0, lpResultString) ;
						lpResultString	= NULL ;
					}
					lpResultString		= lpNewString ;
					Mylstrcat (lpResultString, lpArg->m_data.m_lpString) ;
				}
				break ;
			case ENTITY_INTEGER:
				Myltoa (buffer, lpArg->m_data.m_integer) ;
				lLength			= Mylstrlen (buffer) ;
				if (lLength > 0){
					lResultLength	+=	lLength ;
					lpNewString	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * (lResultLength + 1)) ;
					if (!lpNewString){
						if (lpResultString)
							HeapFree (GetProcessHeap (), 0, lpResultString) ;
						return	NULL ;
					}
					if (!lpResultString){
						*lpNewString	= MYTEXT ('\0') ;
					} else {
						Mylstrcpy (lpNewString, lpResultString) ;
					}
					if (lpResultString)
						HeapFree (GetProcessHeap (), 0, lpResultString) ;
					lpResultString		= lpNewString ;
					Mylstrcat (lpResultString, buffer) ;
				}
				break ;
			case ENTITY_ARRAY:
				lpArray			= lpArg->m_data.m_array.m_lpArray ;
				lLength			= lpArg->m_data.m_array.m_iLength ;
				if (lLength > 0){
					lpNewString	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * (lResultLength + lLength + 1)) ;
					if (!lpNewString){
						if (lpResultString)
							HeapFree (GetProcessHeap (), 0, lpResultString) ;
						return	NULL ;
					}
					if (!lpResultString){
						*lpNewString	= MYTEXT ('\0') ;
					} else {
						Mylstrcpy (lpNewString, lpResultString) ;
					}
					if (lpResultString)
						HeapFree (GetProcessHeap (), 0, lpResultString) ;
					lpResultString		= lpNewString ;
					for (i = 0 ; i < lLength ; i ++){
						if (lpArray [i]->m_iType != ENTITY_INTEGER){
							if (lpResultString)
								HeapFree (GetProcessHeap (), 0, lpResultString) ;
							return	NULL ;
						}
						lpResultString [lResultLength + i]	= (MYCHAR)(lpArray [i]->m_data.m_integer & 0x7F) ;
					}
					lResultLength	+=	lLength ;
					lpResultString [lResultLength]	= MYTEXT ('\0') ;
				}
				break ;
			case ENTITY_CONS:
			case ENTITY_ATOM:
			default:
				if (lpResultString)
					HeapFree (GetProcessHeap (), 0, lpResultString) ;
				return	NULL ;
			}
			lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		}
		if (!skkinputlisp_IsNil (lpEntity)){
			if (lpResultString)
				HeapFree (GetProcessHeap (), 0, lpResultString) ;
			return	NULL ;
		}
		newEntity.m_iType			= ENTITY_STRING ;
		newEntity.m_data.m_lpString	= lpResultString ;
		lpResult					= skkinputlisp_CreateNewEntity (&newEntity) ;
		if (lpResultString)
			HeapFree (GetProcessHeap (), 0, lpResultString) ;
		return	lpResult ;
	} else {
		newEntity.m_iType			= ENTITY_STRING ;
		newEntity.m_data.m_lpString	= MYTEXT ("") ;
		return	skkinputlisp_CreateNewEntity (&newEntity) ;
	}
}

LPSKKLISPENTITY	skkinputlisp_int_to_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	SKKLISPENTITY	newEntity ;
	LPSKKLISPENTITY	lpInteger ;
	MYCHAR			buffer [32] ;
	/* �����y�ш����̐��`�F�b�N�B*/
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* �B��̈����ł����1������]������B*/
	lpInteger	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	/* �]�����ʂ͐����Ŗ�����΂Ȃ�Ȃ��B*/
	if (!lpInteger || lpInteger->m_iType != ENTITY_INTEGER)
		return	NULL ;
	Myltoa (buffer, lpInteger->m_data.m_integer) ;
	newEntity.m_iType			= ENTITY_STRING ;
	newEntity.m_data.m_lpString	= buffer ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

LPSKKLISPENTITY	skkinputlisp_string_to_int (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpStringEntity ;
	SKKLISPENTITY	newEntity ;
	/* �����y�ш����̐��`�F�b�N�B*/
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	/* �B��̈����ł����1������]������B*/
	lpStringEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpStringEntity || lpStringEntity->m_iType != ENTITY_STRING)
		return	NULL ;
	newEntity.m_iType			= ENTITY_INTEGER ;
	newEntity.m_data.m_integer	= Myatol (lpStringEntity->m_data.m_lpString) ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

LPSKKLISPENTITY	skkinputlisp_make_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpResult ;
	LPSKKLISPENTITY	lpCharEntity ;
	LPSKKLISPENTITY	lpLengthEntity ;
	SKKLISPENTITY	newEntity ;
	LPMYSTR			lpString ;
	LPMYSTR			lpptr ;
	int				iLength ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpLengthEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpLengthEntity || lpLengthEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	iLength			= lpLengthEntity->m_data.m_integer ;
	if (iLength < 0)
		return	NULL ;
	if (!iLength){
		newEntity.m_iType			= ENTITY_STRING ;
		newEntity.m_data.m_lpString	= MYTEXT ("") ;
		return	skkinputlisp_CreateNewEntity (&newEntity) ;
	}
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpCharEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpCharEntity || lpCharEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	lpString		= HeapAlloc (GetProcessHeap (), 0, sizeof (MYCHAR) * (iLength + 1)) ;
	if (!lpString)
		return	NULL ;
	lpptr			= lpString ;
	while (iLength > 0){
		*lpptr	++	= (MYCHAR)(lpCharEntity->m_data.m_integer & 0x7F) ;
		iLength	-- ;
	}
	newEntity.m_iType			= ENTITY_STRING ;
	newEntity.m_data.m_lpString	= lpString ;
	lpResult		= skkinputlisp_CreateNewEntity (&newEntity) ;
	HeapFree (GetProcessHeap (), 0, lpString) ;
	return	lpResult ;
}

/*
 *	(substring STRING FROM &optional TO):
 *		FROM �Ŏn�܂��āATO �̑O�ŏI��� STRING �̕����������Ԃ��BTO �͕ʂ� nil �ł����Ă�
 *		�폜����Ă��Ă����܂�Ȃ��B���̎��́ASTRING �̏I���܂ŕ�����������Ƃ�B
 *		FROM �� TO �����̐���������A������̍Ōォ�琔���鎖�ɂȂ�B
 */
LPSKKLISPENTITY	skkinputlisp_substring (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpResult ;
	LPSKKLISPENTITY	lpTmpEntity ;
	SKKLISPENTITY	newEntity ;
	LPMYSTR			lpString ;
	LPMYSTR			lpNewString ;
	int				iFrom ;
	int				iTo ;
	int				iLength ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpTmpEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpTmpEntity || lpTmpEntity->m_iType != ENTITY_STRING)
		return	NULL ;
	lpString	= lpTmpEntity->m_data.m_lpString ;
	iLength		= Mylstrlen (lpString) ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpTmpEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpTmpEntity || lpTmpEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	/* �J�n�ʒu�͈̔̓`�F�b�N�B*/
	iFrom		= lpTmpEntity->m_data.m_integer ;
	if (iFrom < 0)
		iFrom	= iLength	+ iFrom ;
	if (iFrom < 0 || iFrom > iLength)
		return	NULL ;
	lpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity)
		return	NULL ;
	/* �J�n�ʒu�����Ȃ������ꍇ�̏����B*/
	if (skkinputlisp_IsNil (lpEntity)){
		newEntity.m_iType			= ENTITY_STRING ;
		newEntity.m_data.m_lpString	= lpString + iFrom ;
		return	skkinputlisp_CreateNewEntity (&newEntity) ;
	}
	if (lpEntity->m_iType != ENTITY_CONS ||
	   !skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpTmpEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpTmpEntity || lpTmpEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	iTo			= lpTmpEntity->m_data.m_integer ;
	if (iTo < 0)
		iTo		= iLength + iTo ;
	if (iTo < iFrom || iTo > iLength)
		return	NULL ;
	lpNewString	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * (iTo - iFrom + 1)) ;
	if (!lpNewString)
		return	NULL ;
	Mylstrncpy (lpNewString, lpString + iFrom, iTo - iFrom) ;
	lpNewString [iTo - iFrom]	= MYTEXT ('\0') ;
	newEntity.m_iType			= ENTITY_STRING ;
	newEntity.m_data.m_lpString	= lpNewString ;
	lpResult	= skkinputlisp_CreateNewEntity (&newEntity) ;
	HeapFree (GetProcessHeap (), 0, lpNewString) ;
	return	lpResult ;
}

/*
 *	(current-time-string &optional SPECIFIED-TIME)
 *		���ݎ�����l�Ԃ̓ǂ߂�`�̕�����ŕԂ��֐��B�`���́A`Sub Sep 16 01:03:52 1973'
 *		�̂悤�ɂȂ�B�����A�������^����ꂽ�ꍇ�ɂ́A���ݎ����̑���ɂ��̎�������L
 *		�̌`���ŕԂ��B�����́A
 *			(HIGH . LOW)
 *		�������́A
 *			(HIGH LOW . IGNORED)
 *		�̌`�łȂ���΂Ȃ�Ȃ��B
 */
LPSKKLISPENTITY	skkinputlisp_current_time_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	SKKLISPENTITY	newEntity ;
	LPSKKLISPENTITY	lpTmpEntity ;
	long			lTimeLow, lTimeHigh ;
	SYSTEMTIME		systime ;
	FILETIME		filetime ;
	DWORD			dwSecs ;
	/* �����̃`�F�b�N�B*/
	if (!lpEntity || (lpEntity->m_iType != ENTITY_CONS && !skkinputlisp_IsNil (lpEntity)))
		return	NULL ;
	if (lpEntity->m_iType != ENTITY_CONS){
		GetLocalTime (&systime) ;
	} else {
		if (!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
			return	NULL ;
		/* �B��̈����ł��鎞���w��𓾂�B*/
		lpEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
		if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
			return	NULL ;
		lpTmpEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (!lpTmpEntity || lpTmpEntity->m_iType != ENTITY_INTEGER)
			return	NULL ;
		lTimeHigh	= lpTmpEntity->m_data.m_integer ;
		lpTmpEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		if (!lpTmpEntity)
			return	NULL ;
		if (lpTmpEntity->m_iType == ENTITY_INTEGER){
			lTimeLow	= lpTmpEntity->m_data.m_integer ;
		} else if (lpTmpEntity->m_iType == ENTITY_CONS){
			lpTmpEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
			if (!lpTmpEntity || lpTmpEntity->m_iType != ENTITY_INTEGER)
				return	NULL ;
			lTimeLow	= lpTmpEntity->m_data.m_integer ;
		} else {
			return	NULL ;
		}
		dwSecs					= lTimeHigh * 0x10000 + lTimeLow ;
		systime.wYear			= 1970 ;
		systime.wMonth			= 1 ;
		systime.wDay			= 1 ;
		systime.wHour			= 0 ;
		systime.wMinute			= 0 ;
		systime.wSecond			= 0 ;
		systime.wMilliseconds	= 0 ;
		SystemTimeToFileTime (&systime, &filetime) ;
		filetime.dwLowDateTime	+= dwSecs ;
		if (filetime.dwLowDateTime < dwSecs)
			filetime.dwHighDateTime	++ ;
		FileTimeToSystemTime (&filetime, &systime) ;
	}
	newEntity.m_iType			= ENTITY_STRING ;
	newEntity.m_data.m_lpString	= Myctime (&systime) ;
	return	skkinputlisp_CreateNewEntity (&newEntity) ;
}

#if 0
/*
 *	Function: (mapconcat FUNCTION SEQUENCE SEPARATOR)
 *		`mapconcat'�́ASEQUENCE�̊e�v�f��FUNCTION��K�p���܂��BFUNCTION����
 *		���l�͕�����łȂ���΂Ȃ炸�A���ʂ͘A������܂��B`mapconcat'�́A�e
 *		�v�f�ɂ��ĕԂ��ꂽ������̊ԂɁA������SEPARATOR��}�����܂��B�ʏ�A
 *		SEPARATOR�ɂ́A�X�y�[�X�A�J���}�ق��̓K���ȋ�Ǔ_���w�肵�܂��B
 */
LPSKKLISPENTITY	skkinputlisp_mapconcat (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	SKKLISPENTITY	newEntity ;
	LPSKKLISPENTITY	lpEntity ;
	
}
#endif

/*
 *	(j-date &optional AND-TIME)
 *		skk-date �Ƃ������O�� skk9.x �ȍ~�͕ύX����Ă��邱�ƂƎv����B
 */
LPSKKLISPENTITY	skkinputlisp_j_date (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	return	NULL ;
}

LPSKKLISPENTITY	skkinputlisp_load_file (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFileNameEntity ;
	WINFILE			winfile ;
	LPTSTR			lpFileName ;
	LPMYSTR			lpstart ;
	LPMYSTR			lpptr ;
	long			lFileSize ;
	int				cc ;
	int				iLeadChar ;
#if defined (MIXED_UNICODE_ANSI)
	TCHAR			szOemPath [MAX_PATH] ;
#endif
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	unsigned short	c1, c2 ;
#endif
	/* �����̃`�F�b�N�B*/
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFileNameEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFileNameEntity || lpFileNameEntity->m_iType != ENTITY_STRING)
		return	NULL ;
	if (!(lpFileNameEntity->m_data.m_lpString) || *(lpFileNameEntity->m_data.m_lpString))
		return	NULL ;
#if defined (MIXED_UNICODE_ANSI)
	CharToOemBuffW (lpFileNameEntity->m_data.m_lpString, szOemPath, MAX_PATH) ;
	lpFileName	= szOemPath ;
#else
	lpFileName	= lpFileNameEntity->m_data.m_lpString ;
#endif
	winfileinit (&winfile) ;
	if (!winfopen (&winfile, lpFileName, GENERIC_READ, OPEN_EXISTING))
		return	NULL ;
	winfseek (&winfile, 0, FILE_END) ;
	lFileSize	= winftell (&winfile) ;
	winrewind (&winfile) ;
	if (lFileSize <= 0){
		winfclose (&winfile) ;
		return	skkinputlisp_TEntity () ;	/* ? */
	}
	lpstart	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (MYCHAR) * (lFileSize + 8 + 1)) ;
	if (!lpstart){
		winfclose (&winfile) ;
		return	NULL ;	/* Lack of memory! */
	}
	Mylstrcpy (lpstart, MYTEXT ("(progn ")) ;
	lpptr		= lpstart + 7 ;
	iLeadChar	= '\0' ;
	while ((cc = winfgetc (&winfile)) != EOF){
		if (iLeadChar){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			c1	= iLeadChar ;
			c2	= cc & 0x00FF ;
			c1	= (char)((c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1) ;
			c2	= (char)(c2 -  ((c2 >= 0x80)? 0x20 : 0x1F)) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			*lpptr ++	= UNICODE_JISX0208 (((c1 & 0xFF) << 8) | (c2 & 0xFF)) ;
#else
			*lpptr ++	= (MYCHAR)iLeadChar ;
			*lpptr ++	= (MYCHAR)cc ;
#endif
			iLeadChar	= '\0' ;
		} else {
			if (IsDBCSLeadByte ((char)cc)){
				iLeadChar	= cc & 0x00FF ;
			} else {
				if (cc == _T(';')){
					while (1){
						cc = winfgetc (&winfile) ;
						if (cc == EOF)
							break ;
						if (IsDBCSLeadByte ((char)cc)){
							if (winfgetc (&winfile) == EOF)
								break ;
						} else {
							if (cc == _T('\n') || cc == _T('\r'))
								break ;
						}
					}
				} else {
					switch (cc){
					case _T('\n') :
					case _T('\r') :
						cc	= _T('\x20') ;
					default:
						*lpptr ++	= (MYCHAR)cc ;
						break ;
					}
				}
			}
		}
	}
	*lpptr	++	= MYTEXT (')') ;
	*lpptr		= MYTEXT ('\0') ;
	winfclose (&winfile) ;
	lpEntity	= skkinputlisp_String2Entity (lpstart) ;
	if (lpEntity)
		lpEntity	= skkinputlisp_EvalEntity (lpEntity, lpEnvironment) ;
	HeapFree (GetProcessHeap (), 0, lpstart) ;
	return	skkinputlisp_TEntity () ;	/* ? */
}

/*
 *	built-in function:	(make-keymap &optional STRING)
 */
LPSKKLISPENTITY	skkinputlisp_make_keymap (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpKeymapNameEntity ;
	LPSKKLISPENTITY	lpKeymapEntity ;
	LPSKKLISPENTITY	lpKeymapAtomEntity ;
	LPSKKLISPENTITY	lpKeymapArrayEntity ;
	LPSKKLISPENTITY	lpNilArray [128] ;
	LPSKKLISPENTITY	lpNilEntity ;
	SKKLISPENTITY	tmpEntity ;
	int				iLoopCounter ;
	/* �����̃`�F�b�N�B*/
	if (!lpEntity)
		return	NULL ;
	/* make-keymap &optional STRING �Ȃ̂� STRING �����݂��邩�ǂ����`�F�b�N����B*/
	if (lpEntity->m_iType == ENTITY_CONS){
		/* STRING �����݂���ꍇ�B*/
		lpKeymapNameEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	} else if (skkinputlisp_IsNil (lpEntity)){
		/* STRING �����݂��Ȃ��ꍇ�B*/
		lpKeymapNameEntity	= NULL ;
	} else {
		/* (make-keymap . HOGE) �� HOGE != nil �̏ꍇ�̓G���[�ɂȂ�B*/
		return	NULL ;
	}
	/* [nil nil nil ... nil] �Ƃ��� ENTITY �쐬�̂��߂̔z�������������B*/
	lpNilEntity			= skkinputlisp_NilEntity () ;
	for (iLoopCounter = 0 ; iLoopCounter < 128 ; iLoopCounter ++)
		lpNilArray [iLoopCounter]	= lpNilEntity ;
	/* atom keymap ���쐬����B*/
	tmpEntity.m_iType						= ENTITY_ATOM ;
	tmpEntity.m_data.m_lpString				= MYTEXT ("keymap") ;
	lpKeymapAtomEntity						= skkinputlisp_CreateNewEntity (&tmpEntity) ;
	/* [nil nil nil nil ... nil] ���쐬����B*/
	tmpEntity.m_iType						= ENTITY_ARRAY ;
	tmpEntity.m_data.m_array.m_iLength		= 128 ;
	tmpEntity.m_data.m_array.m_lpArray		= lpNilArray ;
	lpKeymapArrayEntity						= skkinputlisp_CreateNewEntity (&tmpEntity) ;
	/* (keymap [nil nil nil ... nil] &optional STRING) ���쐬����B*/
	if (lpKeymapNameEntity){
		tmpEntity.m_iType							= ENTITY_CONS ;
		tmpEntity.m_data.m_conspair.m_lpLeftEntity	= lpKeymapNameEntity ;
		tmpEntity.m_data.m_conspair.m_lpRightEntity	= lpNilEntity ;
		lpKeymapEntity								= skkinputlisp_CreateNewEntity (&tmpEntity) ;
	} else {
		lpKeymapEntity							= lpNilEntity ;
	}
	tmpEntity.m_iType							= ENTITY_CONS ;
	tmpEntity.m_data.m_conspair.m_lpLeftEntity	= lpKeymapArrayEntity ;
	tmpEntity.m_data.m_conspair.m_lpRightEntity	= lpKeymapEntity ;
	lpKeymapEntity								= skkinputlisp_CreateNewEntity (&tmpEntity) ;
	tmpEntity.m_iType							= ENTITY_CONS ;
	tmpEntity.m_data.m_conspair.m_lpLeftEntity	= lpKeymapAtomEntity ;
	tmpEntity.m_data.m_conspair.m_lpRightEntity	= lpKeymapEntity ;
	lpKeymapEntity								= skkinputlisp_CreateNewEntity (&tmpEntity) ;
	return	lpKeymapEntity ;
}

/*
 *	build-in function:	(define-key KEYMAP KEY DEF &optional NONMETA)
 */
LPSKKLISPENTITY	skkinputlisp_define_key (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY			lpKeymapEntity ;
	LPSKKLISPENTITY			lpKeyEntity ;
	LPSKKLISPENTITY			lpDefEntity ;
	LPSKKLISPENTITY			lpArrayEntity ;
	LPSKKLISPENTITY FAR*	lpArray ;
	int						iKeyNumber ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpKeymapEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!skkinputlisp_IsKeymap (lpKeymapEntity))
		return	NULL ;
	lpArrayEntity	= lpKeymapEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpArrayEntity || lpArrayEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpArrayEntity	= lpArrayEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpArrayEntity || lpArrayEntity->m_iType != ENTITY_ARRAY)
		return	NULL ;
	/* ���̗v�f�ɍs���B*/
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpKeyEntity		= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpKeyEntity || lpKeyEntity->m_iType != ENTITY_STRING || !lpKeyEntity->m_data.m_lpString)
		return	NULL ;
	iKeyNumber		= (int)*(lpKeyEntity->m_data.m_lpString) ;
	if (iKeyNumber < 0 || iKeyNumber >= lpArrayEntity->m_data.m_array.m_iLength)
		return	NULL ;
	/* ���̗v�f�ɍs���B*/
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpDefEntity		= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpDefEntity)
		return	NULL ;
	lpArray		= lpArrayEntity->m_data.m_array.m_lpArray ;
	skkinputlisp_AddReferCount (lpArray [iKeyNumber], - lpArrayEntity->m_lReferCount) ;
	lpArray [iKeyNumber]	= lpDefEntity ;
	skkinputlisp_AddReferCount (lpDefEntity, lpArrayEntity->m_lReferCount) ;
	return	lpDefEntity ;		
}

/*
 *	(copy-keymap KEYMAP):	a built-in function
 *	KEYMAP �̃R�s�[���쐬���ĕԂ��B
 */
LPSKKLISPENTITY	skkinputlisp_copy_keymap (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpKeymap ;
	LPSKKLISPENTITY	lpArrayEntity ;
	LPSKKLISPENTITY	lpVectorEntity ;
	SKKLISPENTITY	tmpEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpKeymap	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!skkinputlisp_IsKeymap (lpKeymap))
		return	NULL ;
	lpArrayEntity	= lpKeymap->m_data.m_conspair.m_lpRightEntity ;
	if (!lpArrayEntity || lpArrayEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpArrayEntity	= lpArrayEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpArrayEntity || lpArrayEntity->m_iType != ENTITY_ARRAY)
		return	NULL ;
	lpVectorEntity	= skkinputlisp_CreateNewEntity (lpArrayEntity) ;
	if (!lpVectorEntity)
		return	NULL ;
	tmpEntity.m_iType							= ENTITY_CONS ;
	tmpEntity.m_data.m_conspair.m_lpLeftEntity	= lpVectorEntity ;
	tmpEntity.m_data.m_conspair.m_lpRightEntity	= skkinputlisp_NilEntity () ;
	lpEntity		= skkinputlisp_CreateNewEntity (&tmpEntity) ;
	if (!lpEntity)
		return	NULL ;
	tmpEntity.m_data.m_conspair.m_lpLeftEntity	= lpKeymap->m_data.m_conspair.m_lpLeftEntity ;
	tmpEntity.m_data.m_conspair.m_lpRightEntity	= lpEntity ;
	return	skkinputlisp_CreateNewEntity (&tmpEntity) ;
}

LPSKKLISPENTITY	skkinputlisp_while (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpTestEntity ;
	LPSKKLISPENTITY	lpBodyEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpTestEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	while (!skkinputlisp_IsNil (skkinputlisp_EvalEntity (lpTestEntity, lpEnvironment))){
		lpBodyEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		while (lpBodyEntity && lpBodyEntity->m_iType == ENTITY_CONS){
			if (!skkinputlisp_EvalEntity (lpBodyEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment))
				return	NULL ;
			lpBodyEntity	= lpBodyEntity->m_data.m_conspair.m_lpRightEntity ;
		}
	}
	return	skkinputlisp_NilEntity () ;
}

LPSKKLISPENTITY	skkinputlisp_lesser_than (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFirstEntity ;
	LPSKKLISPENTITY	lpSecondEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFirstEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstEntity || lpFirstEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpSecondEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpSecondEntity || lpSecondEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	return	(lpFirstEntity->m_data.m_integer < lpSecondEntity->m_data.m_integer)?
		skkinputlisp_TEntity () : skkinputlisp_NilEntity () ;
}

LPSKKLISPENTITY	skkinputlisp_lesser_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFirstEntity ;
	LPSKKLISPENTITY	lpSecondEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFirstEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstEntity || lpFirstEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpSecondEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpSecondEntity || lpSecondEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	return	(lpFirstEntity->m_data.m_integer <= lpSecondEntity->m_data.m_integer)?
		skkinputlisp_TEntity () : skkinputlisp_NilEntity () ;
}

LPSKKLISPENTITY	skkinputlisp_greater_than (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFirstEntity ;
	LPSKKLISPENTITY	lpSecondEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFirstEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstEntity || lpFirstEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpSecondEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpSecondEntity || lpSecondEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	return	(lpFirstEntity->m_data.m_integer > lpSecondEntity->m_data.m_integer)?
		skkinputlisp_TEntity () : skkinputlisp_NilEntity () ;
}

LPSKKLISPENTITY	skkinputlisp_greater_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFirstEntity ;
	LPSKKLISPENTITY	lpSecondEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFirstEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstEntity || lpFirstEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpSecondEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpSecondEntity || lpSecondEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	return	(lpFirstEntity->m_data.m_integer >= lpSecondEntity->m_data.m_integer)?
		skkinputlisp_TEntity () : skkinputlisp_NilEntity () ;
}

/*
 *	built-in function:	(= NUM1 NUM2)
 *	NUM1, NUM2 �����҂Ƃ��ɐ����ł���A���̒l����������� t ��Ԃ��B
 */
LPSKKLISPENTITY	skkinputlisp_integer_equal (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFirstEntity ;
	LPSKKLISPENTITY	lpSecondEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpFirstEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpFirstEntity || lpFirstEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	lpEntity		= lpEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpSecondEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpSecondEntity || lpSecondEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	return	(lpFirstEntity->m_data.m_integer == lpSecondEntity->m_data.m_integer)?
		skkinputlisp_TEntity () : skkinputlisp_NilEntity () ;
}

LPSKKLISPENTITY	skkinputlisp_char_to_string (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpArgEntity ;
	SKKLISPENTITY	tmpEntity ;
	MYCHAR			buf [2] ;
	if (!lpEntity || lpEntity->m_iType != ENTITY_CONS ||
		!skkinputlisp_IsNil (lpEntity->m_data.m_conspair.m_lpRightEntity))
		return	NULL ;
	lpArgEntity	= skkinputlisp_EvalEntity (lpEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
	if (!lpArgEntity || lpArgEntity->m_iType != ENTITY_INTEGER)
		return	NULL ;
	/*
	 *	������̒����������Ă��Ȃ��̂ŁA������ == 0 �Ȃ� NUL TERMINATED ����Ă���Ǝv����
	 *	���܂��o�O������B������̊Ǘ��~�X�ł���B��������������ƒ����Ȃ��ƂȁB
	 */
	buf [0]						= (MYCHAR)lpArgEntity->m_data.m_integer ;
	buf [1]						= MYTEXT ('\0') ;
	tmpEntity.m_iType			= ENTITY_STRING ;
	tmpEntity.m_data.m_lpString	= buf ;
	return	skkinputlisp_CreateNewEntity (&tmpEntity) ;
}

/*
 *	���� logon ���Ă��郆�[�U�[�̖��O�𓾂�֐��B
 *	build-in function:	(user-login-name)
 */
LPSKKLISPENTITY	skkinputlisp_user_login_name (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	SKKLISPENTITY	tmpEntity ;
	TCHAR			userNameBuffer [UNLEN + 1] ;
	DWORD			dwUserNameLength ;
#if defined (MIXED_UNICODE_ANSI)
	MYCHAR			szUserNameBufferW [UNLEN + 1] ;
	long			lUserNameBufWLength ;
#endif
	if (!lpEntity || !skkinputlisp_IsNil (lpEntity))
		return	NULL ;
	dwUserNameLength	= UNLEN ;
	if (!GetUserName (userNameBuffer, &dwUserNameLength))
		return	skkinputlisp_NilEntity () ;
	userNameBuffer [UNLEN]		= MYTEXT ('\0') ;
	tmpEntity.m_iType			= ENTITY_STRING ;
#if defined (MIXED_UNICODE_ANSI)
	lUserNameBufWLength	= shiftJisToMystr (szUserNameBufferW, UNLEN, userNameBuffer, dwUserNameLength) ;
	if (lUserNameBufWLength <= 0)
		return	NULL ;
	szUserNameBufferW [lUserNameBufWLength]	= MYTEXT ('\0') ;
	tmpEntity.m_data.m_lpString	= szUserNameBufferW ;
#else
	tmpEntity.m_data.m_lpString	= userNameBuffer ;
#endif
	return	skkinputlisp_CreateNewEntity (&tmpEntity) ;
}

/*
 *	���� logon ���Ă��郆�[�U�[�̖��O�𓾂�֐��B
 *	build-in function:	(get-windows-directory)
 */
LPSKKLISPENTITY	skkinputlisp_get_windows_directory (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	SKKLISPENTITY	tmpEntity ;
	TCHAR			szWindowsDir [MAX_PATH] ;
	long			lPathLength ;
#if defined (MIXED_UNICODE_ANSI)
	MYCHAR			szWindowsDirW [MAX_PATH + 1] ;
#endif
	if (!lpEntity || !skkinputlisp_IsNil (lpEntity))
		return	NULL ;
	lPathLength	= GetWindowsDirectory (szWindowsDir, MAX_PATH) ;
	if (lPathLength <= 0)
		return	NULL ;
	tmpEntity.m_iType			= ENTITY_STRING ;
#if defined (MIXED_UNICODE_ANSI)
	lPathLength	= shiftJisToMystr (szWindowsDirW, MAX_PATH, szWindowsDir, lPathLength) ;
	if (lPathLength <= 0)
		return	NULL ;
	szWindowsDirW [lPathLength]	= MYTEXT ('\0') ;
	tmpEntity.m_data.m_lpString	= szWindowsDirW ;
#else
	tmpEntity.m_data.m_lpString	= szWindowsDir ;
#endif
	return	skkinputlisp_CreateNewEntity (&tmpEntity) ;
}

/*
 *	((lambda ARGS DOCSTRING BODY) VALUES):
 *		lambda �����֐��Ƃ��ĕ]������֐��BARGS �ɑΉ����� VALUES �̒l�𒀎��ݒ肵�Ă����B
 *		�u���ɐݒ肳��Ă��� symbol ���Q�Ƃ��Ȃ���H�v�Ƃ������Ƃ͖����Ǝv�����B
 *		&optional �܂ł͎������Ă��邪�Ainteractive �͖������ł���B
 */
LPSKKLISPENTITY	skkinputlisp_evallambda (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpLambdaEntity ;
	LPSKKLISPENTITY	lpVarsEntity ;
	LPSKKLISPENTITY	lpVarEntity ;
	LPSKKLISPENTITY	lpValuesEntity ;
	LPSKKLISPENTITY	lpValueEntity ;
	LPSKKLISPENTITY	lpResult ;
	LPSKKLISPENV	lpEnv ;
	LPSKKLISPENV	lpLocalEnv ;
	LPSKKLISPVAR	lpLocalVar ;
	BOOL			fOptional ;

	lpLambdaEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	lpLocalEnv		= NULL ;
	if (!lpLambdaEntity || lpLambdaEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpLambdaEntity	= lpLambdaEntity->m_data.m_conspair.m_lpRightEntity ;
	if (!lpLambdaEntity)
		return	NULL ;
	if (skkinputlisp_IsNil (lpLambdaEntity))
		return	skkinputlisp_NilEntity () ;
	if (lpLambdaEntity->m_iType != ENTITY_CONS)
		return	NULL ;
	lpVarsEntity	= lpLambdaEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpVarsEntity || (lpVarsEntity->m_iType != ENTITY_CONS && !skkinputlisp_IsNil (lpVarsEntity)))
		return	NULL ;
	if (lpVarsEntity->m_iType == ENTITY_CONS){
		/* �Ǐ��ϐ��p�̊����쐬����B*/
		lpLocalEnv		= skkinputlisp_CreateNewEnvironment (lpEnvironment) ;
		if (!lpLocalEnv)
			return	NULL ;
		/* �Ǐ��ϐ������Ԃɍ쐬���āA�l��������B*/
		lpValuesEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
		fOptional		= FALSE ;
		while (lpVarsEntity   && lpVarsEntity->m_iType == ENTITY_CONS){
			/* �Ǐ��ϐ��̖��O�𓾂�B*/
			lpVarEntity	= lpVarsEntity->m_data.m_conspair.m_lpLeftEntity ;
			if (lpVarEntity->m_iType != ENTITY_ATOM ||
				!lpVarEntity->m_data.m_lpString){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			if (!Mylstrcmp (lpVarEntity->m_data.m_lpString, MYTEXT ("&optional"))){
				lpVarsEntity	= lpVarsEntity->m_data.m_conspair.m_lpRightEntity ;
				fOptional		= TRUE ;
				continue ;
			}
			/* �Ǐ��ϐ��ɑ��������̂𓾂�B*/
			if (lpValuesEntity && lpValuesEntity->m_iType == ENTITY_CONS){
				lpValueEntity	= skkinputlisp_EvalEntity
					 (lpValuesEntity->m_data.m_conspair.m_lpLeftEntity, lpEnvironment) ;
				if (!lpValueEntity){
					skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
					return	NULL ;
				}
				lpValuesEntity	= lpValuesEntity->m_data.m_conspair.m_lpRightEntity ;
			} else if (fOptional){
				lpValueEntity	= skkinputlisp_NilEntity () ;
			} else {
				break ;
			}
			/* �Ǐ��ϐ����쐬����B*/
			lpLocalVar		= skkinputlisp_CreateLocalVariable
				 (lpVarEntity->m_data.m_lpString, lpLocalEnv) ;			
			if (!lpLocalVar){
				skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
				return	NULL ;
			}
			/* �Ǐ��ϐ��ɒl��������B*/
			if (lpLocalVar->m_lpValue)
				skkinputlisp_DecReferCount (lpLocalVar->m_lpValue) ;
			lpLocalVar->m_lpValue	= lpValueEntity ;
			skkinputlisp_IncReferCount (lpValueEntity) ;
			/* ���X�g�̎��̗v�f�����ɍs���B*/
			lpVarsEntity	= lpVarsEntity->m_data.m_conspair.m_lpRightEntity ;
		}
		/* �ϐ��y�т��̒l�̃��X�g�������ɏI����Ă��Ȃ���΁A�G���[���Ǝv���B*/
		if (!lpVarsEntity || !lpValuesEntity ||
			!skkinputlisp_IsNil (lpVarsEntity) || !skkinputlisp_IsNil (lpValuesEntity)){
			skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
			return	NULL ;
		}
		lpEnv		= lpLocalEnv ;
	} else {
		/* ���̏ꍇ�A�Ǐ��ϐ��͑��݂��Ȃ��B*/
		lpEnv		= lpEnvironment ;
	}
	lpLambdaEntity	= lpLambdaEntity->m_data.m_conspair.m_lpRightEntity ;
	lpResult		= skkinputlisp_NilEntity () ;
	while (lpLambdaEntity && lpLambdaEntity->m_iType == ENTITY_CONS){
		lpResult	= skkinputlisp_EvalEntity (lpLambdaEntity->m_data.m_conspair.m_lpLeftEntity, lpEnv) ;
		if (!lpResult)
			break ;
		lpLambdaEntity	= lpLambdaEntity->m_data.m_conspair.m_lpRightEntity ;
	}
	if (!skkinputlisp_IsNil (lpLambdaEntity))
		lpResult	= NULL ;
	if (lpLocalEnv)
		skkinputlisp_DestroyEnvironment (lpLocalEnv) ;
	return	lpResult ;
}

LPSKKLISPENTITY	skkinputlisp_EvalFunc (LPSKKLISPENTITY lpEntity, LPSKKLISPENV lpEnvironment)
{
	LPSKKLISPENTITY	lpFuncEntity ;
	LPSKKLISPENTITY	lpLambdaEntity ;
	LPSKKLISPUFUNC	lpUFunc ;
	SKKLISPENTITY	newEntity ;
	int				i ;
	lpFuncEntity	= lpEntity->m_data.m_conspair.m_lpLeftEntity ;
	if (!lpFuncEntity)
		return	NULL ;
	switch (lpFuncEntity->m_iType){
	case ENTITY_ATOM:
		if (!lpFuncEntity->m_data.m_lpString)
			return	skkinputlisp_NilEntity () ;
		for (i = 0 ; skkinputlispFunctionTable [i].m_lpName ; i ++){
			if (!Mylstrcmp (skkinputlispFunctionTable [i].m_lpName, lpFuncEntity->m_data.m_lpString))
				return	(skkinputlispFunctionTable [i].m_lpFunction)(lpEntity->m_data.m_conspair.m_lpRightEntity, lpEnvironment) ;
		}
		lpUFunc	= skkinputlisp_GlobalSearchFunction (lpFuncEntity->m_data.m_lpString, lpEnvironment) ;
		if (lpUFunc){
			newEntity.m_iType	= ENTITY_CONS ;
			newEntity.m_data.m_conspair.m_lpLeftEntity	= lpUFunc->m_lpFunction ;
			newEntity.m_data.m_conspair.m_lpRightEntity	= lpEntity->m_data.m_conspair.m_lpRightEntity ;
			return	skkinputlisp_evallambda (&newEntity, lpEnvironment) ;
		}
		break ;
	case ENTITY_CONS:
		/* lambda form ���ǂ��������Ń`�F�b�N����Blambda form �łȂ���Ύ��s���Ȃ��B*/
		lpLambdaEntity	= lpFuncEntity->m_data.m_conspair.m_lpLeftEntity ;
		if (!lpLambdaEntity ||
			lpLambdaEntity->m_iType != ENTITY_ATOM ||
			Mylstrcmp (lpLambdaEntity->m_data.m_lpString, MYTEXT ("lambda")))
			return	NULL ;
		return	skkinputlisp_evallambda (lpEntity, lpEnvironment) ;
	default:
		break ;
	}
	return	NULL ;
}


