/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * listbuf.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "mylocale.h"
#include "skkiserv.h"

/*
 * ���X�g���܂邲�Ɖ������֐��B
 */
BOOL	SKKFreeListBuffer (LPLISTBUFFER FAR* lppVectorTop)
{
	LPLISTBUFFER	lpVector ;
	LPLISTBUFFER	lpNextVector ;
	if (lppVectorTop == NULL)
		return	FALSE ;
	lpVector		= *lppVectorTop ;
	while (lpVector != NULL){
		lpNextVector	= lpVector->lpNext ;
		HeapFree (GetProcessHeap (), 0, lpVector) ;
		lpVector		= lpNextVector ;
	}
	*lppVectorTop	= NULL ;
	return	TRUE ;
}

/*
 * �V�����m�[�h�ɗp���郁�������m�ۂ���֐��B
 */
LPLISTBUFFER	SKKAllocListBuffer (void)
{
	LPLISTBUFFER	lpVector ;
	lpVector	= HeapAlloc (GetProcessHeap (), 0, sizeof (LISTBUFFER)) ;
	if (lpVector != NULL){
		lpVector->text [0]	= MYTEXT ('\0') ;
		lpVector->iUsed		= 0 ;
		lpVector->lpNext	= NULL ;
	}
	return	lpVector ;
}

/*
 * Search Vector �ɐV�����m�[�h��t��������֐��B
 */
LPLISTBUFFER	SKKAddListBuffer (LPLISTBUFFER lpVectorTop, LPMYSTR lpStr, int iLength, LPLISTBUFFER FAR* lppVectorRet, int FAR* lpiPosRet)
{
	LPLISTBUFFER	lpVector ;
	LPLISTBUFFER	lpNextVector ;
	int				iUsed ;
	int				iCopyLength, iRest ;

	/* �擪�� NULL �������ꍇ�ɂ͐擪���m�ۂ���B*/
	if (lpVectorTop == NULL){
		lpVectorTop	= lpVector	= SKKAllocListBuffer () ;
		iUsed		= 0 ;
	} else {
		lpVector		= lpVectorTop ;
		/* ��ԍŌ�̃m�[�h�����t����B*/
		while (lpVector->lpNext)
			lpVector	= lpVector->lpNext ;
		iUsed			= lpVector->iUsed ;
	}
	/* �o�^���J�n����擪�ʒu���L������B*/
	if (lppVectorRet != NULL)
		*lppVectorRet	= lpVector ;
	if (lpiPosRet != NULL)
		*lpiPosRet		= iUsed ;

	/* �t���������������񂪋�łȂ��̂Ȃ�c�B*/
	if (iLength <= 0)
		iLength	= Mylstrlen (lpStr) ;
	while (lpVector != NULL && iLength > 0){
		iRest					= TEXTBUFSIZE - 1 - iUsed ;
		iCopyLength				= (iLength < iRest)? iLength : iRest ;
		memcpy (lpVector->text + iUsed, lpStr, iCopyLength * sizeof (MYCHAR)) ;
		iUsed					+= iCopyLength ;
		lpVector->text [iUsed]	= MYTEXT ('\0') ;
		lpVector->iUsed			= iUsed ;
		lpStr					+= iCopyLength ;
		iLength					-= iCopyLength ;
		if (iCopyLength > 0){
			lpNextVector		= SKKAllocListBuffer () ;
			lpVector->lpNext	= lpNextVector ;
			iUsed				= 0 ;
		} else {
			lpVector->lpNext	= NULL ;
			lpNextVector		= NULL ;
		}
		lpVector				= lpNextVector ;
	}
	return	lpVectorTop ;
}

long			SKKGetLengthOfListBuffer (LPLISTBUFFER lpListBufferTop)
{
	long	lCount ;
	lCount	= 0 ;
	while (lpListBufferTop != NULL){
		lpListBufferTop	= lpListBufferTop->lpNext ;
		lCount	++ ;
	}
	return	lCount ;	
}

LPLISTBUFFER	SKKGetElementOfListBuffer (LPLISTBUFFER lpListBufferTop, long lNumber)
{
	while (lpListBufferTop && lNumber > 0){
		lpListBufferTop	= lpListBufferTop->lpNext ;
		lNumber	-- ;
	}
	if (lNumber)
		return	NULL ;
	return	lpListBufferTop ;
}

