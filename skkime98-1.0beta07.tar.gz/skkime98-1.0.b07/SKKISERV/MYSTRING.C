/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * mystring.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "mylocale.h"
#include "skkiserv.h"
#include "unicode.h"

/*
 *	Global Variables
 */
static	LPMYSTR	skk_kanji_num_list [] = {
	MYTEXT ("�Z"),	MYTEXT ("��"),	MYTEXT ("��"),	MYTEXT ("�O"),
	MYTEXT ("�l"),	MYTEXT ("��"),	MYTEXT ("�Z"),	MYTEXT ("��"),
	MYTEXT ("��"),	MYTEXT ("��"),
} ;

static	LPMYSTR	skk_numeric_unit [] = {
	MYTEXT ("��"),	MYTEXT ("��"),	MYTEXT ("��"),	MYTEXT ("��"),
	MYTEXT ("��"),	MYTEXT ("�R"),	MYTEXT ("��"),	MYTEXT ("�a"),
	MYTEXT ("��"),	MYTEXT ("��"),	MYTEXT ("��"),	MYTEXT ("��"),
	MYTEXT ("�P�͍�"),				MYTEXT ("���m�_"),
	MYTEXT ("�ߗR��"),				MYTEXT ("�s�v�c"),
	MYTEXT ("���ʑ吔"),
} ;

static	LPMYSTR	skk_week_alist []	= {
	MYTEXT ("��"),	MYTEXT ("��"),	MYTEXT ("��"),
	MYTEXT ("��"),	MYTEXT ("��"),	MYTEXT ("��"),
	MYTEXT ("�y"),
} ;

/*
 *	Prototypes
 */
static	int		ShiftJisToEucJapan (char FAR* lpDest, char FAR* lpSrc, int iSize) ;
static	LPMYSTR	j_num_exp (LPMYSTR lpJNumList, int iType, LPMYSTR FAR* lpDest, int FAR* lpBufSize) ;
static	LPMYSTR	j_identity (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize) ;
static	LPMYSTR	j_zenkaku_num_str (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize) ;
static	LPMYSTR	j_kanji_num_str (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize) ;
static	LPMYSTR	j_kanji_num_str2 (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize) ;
static	LPMYSTR	j_shogi_num_str (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize) ;

/*
 *	Functions
 */
void	Myltoa (LPMYSTR lp, long lValue)
{
	long	lMaxDigit, lDigit ;
	long	ll ;
	if (lValue < 0){
		*lp	++	= MYTEXT ('-') ;
		lValue	= lValue * (-1) ;
	}
	if (lValue != 0){
		ll	= lValue ;
		for (lMaxDigit = 0 ; ll != 0 ; lMaxDigit ++)
			ll	= ll / 10 ;
		for (lDigit = 0 ; lDigit < lMaxDigit ; lDigit ++){
			lp [lMaxDigit - lDigit - 1]	= (MYCHAR)(MYTEXT ('0') + lValue % 10) ;
			lValue						= lValue / 10 ;
		}
		lp [lMaxDigit] = MYTEXT ('\0') ;
	} else {
		*lp	++ = MYTEXT ('0') ;
		*lp	++ = MYTEXT ('\0') ;
	}
	return ;
}

long	Myatol (LPMYSTR lpString)
{
	long	lValue ;
	long	lSign ;

	lValue	= 0 ;
	if (!lpString || !*lpString)
		return	lValue ;
	if (*lpString == MYTEXT ('+')){
		lSign	= 1 ;
		lpString	++ ;
	} else if (*lpString == MYTEXT ('-')){
		lSign	= -1 ;
		lpString	++ ;
	} else {
		lSign	= 1 ;
	}
	while (*lpString && MYTEXT ('0') <= *lpString && *lpString <= MYTEXT ('9')){
		lValue	= lValue * 10 + (*lpString - MYTEXT ('0')) ;
		lpString	++ ;
	}
	return	lSign * lValue ;
}

LPMYSTR	Myctime (LPSYSTEMTIME lpsystime)
{
	static	MYCHAR	ctimebuf [25] ;
	static	LPMYSTR	ctimeWeekTbl []	= {
		MYTEXT ("Sun"),	MYTEXT ("Mon"),	MYTEXT ("Tue"),	MYTEXT ("Wed"),
		MYTEXT ("Thr"),	MYTEXT ("Fri"),	MYTEXT ("Sat"),
	} ;
	static	LPMYSTR	ctimeMonthTbl []	= {
		MYTEXT ("Jan"),	MYTEXT ("Feb"),	MYTEXT ("Mar"),	MYTEXT ("Apr"),
		MYTEXT ("May"),	MYTEXT ("Jun"),	MYTEXT ("Jul"),	MYTEXT ("Aug"),
		MYTEXT ("Sep"),	MYTEXT ("Oct"),	MYTEXT ("Nov"),	MYTEXT ("Dec"),
	} ;
	ctimebuf [0]	= MYTEXT ('\0') ;
	Mylstrcat (ctimebuf, ctimeWeekTbl [lpsystime->wDayOfWeek]) ;
	Mylstrcat (ctimebuf, MYTEXT (" ")) ;
	Mylstrcat (ctimebuf, ctimeMonthTbl [lpsystime->wMonth - 1]) ;
	Mylstrcat (ctimebuf, MYTEXT (" ")) ;
	ctimebuf [8]	= (MYCHAR)((lpsystime->wDay / 10) % 10 + MYTEXT ('0')) ;
	ctimebuf [9]	= (MYCHAR)(lpsystime->wDay % 10 + MYTEXT ('0')) ;
	ctimebuf [10]	= MYTEXT (' ') ;
	ctimebuf [11]	= (MYCHAR)((lpsystime->wHour / 10) % 10 + MYTEXT ('0')) ;
	ctimebuf [12]	= (MYCHAR)( lpsystime->wHour % 10       + MYTEXT ('0')) ;
	ctimebuf [13]	= MYTEXT (':') ;
	ctimebuf [14]	= (MYCHAR)((lpsystime->wMinute / 10) % 10 + MYTEXT ('0')) ;
	ctimebuf [15]	= (MYCHAR)( lpsystime->wMinute % 10       + MYTEXT ('0')) ;
	ctimebuf [16]	= MYTEXT (':') ;
	ctimebuf [17]	= (MYCHAR)((lpsystime->wSecond / 10) % 10 + MYTEXT ('0')) ;
	ctimebuf [18]	= (MYCHAR)( lpsystime->wSecond % 10       + MYTEXT ('0')) ;
	ctimebuf [19]	= MYTEXT (' ') ;
	ctimebuf [20]	= (MYCHAR)((lpsystime->wYear / 1000) % 10 + MYTEXT ('0')) ;
	ctimebuf [21]	= (MYCHAR)((lpsystime->wYear /  100) % 10 + MYTEXT ('0')) ;
	ctimebuf [22]	= (MYCHAR)((lpsystime->wYear /   10) % 10 + MYTEXT ('0')) ;
	ctimebuf [23]	= (MYCHAR)( lpsystime->wYear         % 10 + MYTEXT ('0')) ;
	ctimebuf [24]	= MYTEXT ('\0') ;
	return	(LPMYSTR)ctimebuf ;
}

#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)

int MylstrcmpW (LPCWSTR lp0, LPCWSTR lp1)
{
	while (*lp0 && *lp1 && (*lp0 == *lp1)){
		lp0 ++ ;
		lp1 ++ ;
	}
	return	(*lp0 - *lp1) ;
}

int MylstrncmpW (LPCWSTR lp0, LPCWSTR lp1, int iNum)
{
	while(iNum > 0 && *lp0 && *lp1 && (*lp0 == *lp1)){
		lp0 ++ ;
		lp1 ++ ;
		iNum -- ;
	}
	return	(iNum > 0)? (*lp0 - *lp1) : 0 ;
}

int MylstrcpyW (LPWSTR lp0, LPCWSTR lp1)
{
	int n	= 0 ;

	while(*lp1){
		*lp0	= *lp1 ;
		lp0 ++ ;
		lp1 ++ ;
		n ++ ;
	}
	*lp0	= *lp1 ;
	return	n ;
}

int	MylstrncpyW (LPWSTR lp0, LPCWSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

int	MylstrcatW (LPWSTR lp0, LPCWSTR lp1)
{
	int n	= 0 ;
	while (*lp0)
		lp0 ++ ;
	while(*lp1){
		*lp0	= *lp1 ;
		lp0 ++ ;
		lp1 ++ ;
		n ++ ;
	}
	*lp0	= *lp1 ;
	return	n ;
}

int	MylstrncatW (LPWSTR lp0, LPCWSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (*lp0)
		lp0	++ ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

LPWSTR MyCharPrevW(LPWSTR lpStart, LPWSTR lpCur)
{
	LPWSTR lpRet = lpStart;
	if (lpCur > lpStart)
		lpRet = lpCur - 1;

	return lpRet;
}

LPWSTR	MyCharNextW(LPWSTR lp)
{
	return lp++;
}

LPWSTR	MylstrcpynW (LPWSTR lp0, LPCWSTR lp1, int nCount)
{
	int n;
	for (n = 0; *lp1 && n < nCount - 1; *lp0++ = *lp1++, n++)
		;
	*lp0 = L'\0' ;
	return	lp0 ;
}

int	MystrToEucW (char FAR* lpDest, LPMYSTR lpSrc, int iSize)
{
	BYTE			bCodeMap ;
	unsigned short	sCode ;
	unsigned char	buf [4] ;
	int				iCopy ;
	int				iSizeBack ;
	iSizeBack	= iSize ;
	while (*lpSrc && iSize > 0){
		bCodeMap	= GetOriginalCode (&sCode, *lpSrc) ;
		switch (bCodeMap){
		case MYCODEMAP_JISX0212:
			buf [0]	= 0x8F ;
			buf [1]	= ((sCode >> 8) & 0x00FF) | 0x80 ;
			buf [2]	= ((sCode     ) & 0x00FF) | 0x80 ;
			iCopy	= 3 ;
			break ;
		case MYCODEMAP_JISX0201:
			buf [0]	= 0x8E ;
			buf [1]	= ((sCode     ) & 0x00FF) | 0x80 ;
			iCopy	= 2 ;
			break ;
		case MYCODEMAP_JISX0208:
			buf [0]	= ((sCode >> 8) & 0x00FF) | 0x80 ;
			buf [1]	= ((sCode     ) & 0x00FF) | 0x80 ;
			iCopy	= 2 ;
			break ;
		case MYCODEMAP_ASCII:
			buf [0]	= (sCode     ) & 0x007F ;
			iCopy	= 1 ;
			break ;
		default:
			iCopy	= 0 ;
			break ;
		}
		if (iSize < iCopy)
			break ;
		memcpy (lpDest, buf, sizeof (char) * iCopy) ;
		lpDest	+= iCopy ;
		iSize	-= iCopy ;
		lpSrc	++ ;
	}
	if (iSize > 0)
		*lpDest	= '\0' ;
	return	(iSizeBack - iSize) ;
}

/*
 *	!lpDest �̎��ɂ́A�K�v�Ƃ���o�b�t�@�̃T�C�Y�𓾂邱�Ƃ��ł���B
 */
int	MystrToShiftJis (LPSTR lpDest, int iDestSize, LPCMYSTR lpSrc, int iSrcSize)
{
	BYTE			bCodeMap ;
	unsigned char	buf [4] ;
	int				iCopy ;
	int				iUsage ;
	unsigned short	sCode ;
	unsigned short	c1, c2 ;
	iUsage	= 0 ;
	while (*lpSrc && iSrcSize > 0){
		bCodeMap	= GetOriginalCode (&sCode, *lpSrc) ;
		switch (bCodeMap){
		case MYCODEMAP_JISX0208:
			c1		= ((sCode >> 8) & 0x00FF) | 0x80 ;
			c2		= ((sCode     ) & 0x00FF) | 0x80 ;
			c1		= ((c1 - 0x7F) >> 1) + 0x70 ;
			buf [0]	= (c1 >= 0xA0)? (c1 + 0x40) : c1 ;
			c2		= c2 - ((sCode & 0x0100)? 0x61 : 0x03) ;
			buf [1]	= (c2 >= 0x7F)? (c2 + 1) : c2 ;
			iCopy	= 2 ;
			break ;
		case MYCODEMAP_JISX0201:
		case MYCODEMAP_ASCII:
			buf [0]	= (sCode     ) & 0x00FF ;
			iCopy	= 1 ;
			break ;
		case MYCODEMAP_JISX0212:
		default:
			iCopy	= 0 ;
			break ;
		}
		if (iCopy > 0){
			if (lpDest){
				if (iDestSize < iCopy)
					break ;
				memcpy (lpDest, buf, sizeof (char) * iCopy) ;
				lpDest		+= iCopy ;
				iDestSize	-= iCopy ;
			}
			iUsage		+= iCopy ;
		}
		iSrcSize	-- ;
		lpSrc		++ ;
	}
	return	iUsage ;
}

int	shiftJisToMystr (LPMYSTR lpDest, int iDestSize, LPCSTR lpSrc, int iSrcSize)
{
	unsigned short	c1, c2 ;
	int				iLeadChar ;
	int				iSizeBackup ;
	if (!lpDest || !lpSrc)
		return	0 ;
	iLeadChar	= '\0' ;
	iSizeBackup	= iDestSize ;
	while (*lpSrc && iSrcSize > 0 && iDestSize > 0){
		if (iLeadChar){
			c1	= iLeadChar ;
			c2	= *lpSrc & 0x00FF ;
			c1	= (char)((c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1) ;
			c2	= (char)(c2 -  ((c2 >= 0x80)? 0x20 : 0x1F)) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			if (iDestSize > 0){
				*lpDest ++	= UNICODE_JISX0208 (((c1 & 0xFF) << 8) | (c2 & 0xFF)) ;
				iDestSize	-- ;
			}
			iLeadChar	= 0 ;
		} else {
			if (IsDBCSLeadByte (*lpSrc)){
				iLeadChar	= *lpSrc & 0x00FF ;
			} else if (0xA1 <= (unsigned char)*lpSrc && (unsigned char)*lpSrc <= 0xDF){
				if (iDestSize > 0){
					*lpDest ++	= UNICODE_JISX0201 (*lpSrc) ;
					iDestSize	-- ;
				}
			} else {
				if (iDestSize > 0){
					*lpDest ++	= *lpSrc & 0x00FF ;
					iDestSize	-- ;
				}
			}
		}
		lpSrc		++ ;
		iSrcSize	-- ;
	}
	return	iSizeBackup - iDestSize ;
}

#else

int	MylstrlenA (LPCSTR lp)
{
	int	n ;
	n	= 0 ;
	while (*lp){
		lp	++ ;
		n	++ ;
	}
	return	n ;
}

int	MylstrncpyA (LPSTR lp0, LPCSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

int	MylstrncatA (LPSTR lp0, LPCSTR lp1, int iNum)
{
	int	iN	= iNum ;
	while (*lp0)
		lp0	++ ;
	while (iNum > 0 && *lp1){
		*lp0 ++	= *lp1 ++ ;
		iNum	-- ;
	}
	if (iNum > 0){
		*lp0	= *lp1 ;
	}
	return	(iN - iNum) ;
}

int		MystrToEucA (char FAR* lpDest, LPMYSTR lpSrc, int iSize)
{
	return	ShiftJisToEucJapan (lpDest, lpSrc, iSize) ;
}

#endif

int MylstrncmpA (LPCSTR lp0, LPCSTR lp1, int iNum)
{
	while(iNum > 0 && *lp0 && *lp1 && (*lp0 == *lp1)){
		lp0 ++ ;
		lp1 ++ ;
		iNum -- ;
	}
	return (iNum > 0)? (*lp0 - *lp1) : 0 ;
}

BOOL	j_date_ad (LPMYSTR lpStr, int iBufSize, int iDateAd, int iNumberStyle)
{
	MYCHAR		tempBuffer [32] ;
	SYSTEMTIME	ltime ;
	int			iYear ;
	int			iLength ;
	LPMYSTR		lpDest ;

	/* �\�����@���f�t�H���g���ǂ����𒲂ׂ�B*/
	if (iDateAd < 0)
		iDateAd	= 0 ;
	if (iNumberStyle < 0)
    	iNumberStyle = 0 ;
	/* 1970/1/1����̌o�ߎ����𓾂�B*/
	GetLocalTime (&ltime) ;

	/* ����N�̉����������j���ł��邩�𓾂�B*/
	iYear	= ltime.wYear ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	iLength	= 2 ;
#else
	iLength	= 4 ;
#endif
	if (!iDateAd){
		if (iBufSize <= iLength){
			*lpStr	= MYTEXT ('\0') ;
			return	TRUE ;
		}
		/* �N�������߂�B*/
		if (iYear <= 1867){
			Mylstrcpy (lpStr, MYTEXT ("����")) ;
		} else if (iYear < 1911){
			iYear	-= 1867 ;
			Mylstrcpy (lpStr, MYTEXT ("����")) ;
		} else if (iYear < 1925){
			iYear	 -= 1911 ;
			Mylstrcpy (lpStr, MYTEXT ("�吳")) ;
		} else if (iYear < 1988 ){
			iYear	-= 1925 ;
			Mylstrcpy (lpStr, MYTEXT ("���a")) ;
		} else {
			iYear	-= 1988 ;
			Mylstrcpy (lpStr, MYTEXT ("����")) ;
		}
		lpDest		= lpStr + iLength ;
		iBufSize	-= iLength ;
	} else {
		/* �N���͖����ɂȂ�B*/
		*lpStr		= MYTEXT ('\0') ;
		lpDest		= lpStr ;
	}
	Myltoa (tempBuffer, iYear) ;

	if (iYear == 1 && iDateAd){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		iLength	= 2 ;
#else
		iLength	= 4 ;
#endif
		if (iBufSize < iLength){
			*lpDest	= MYTEXT ('\0') ;
			return	TRUE ;
		}
		Mylstrcpy (lpDest, MYTEXT ("���N")) ;
		lpDest		+= iLength ;
		iBufSize	-= iLength ;
	} else {
		/* �N��W�J����B*/
		j_num_exp (tempBuffer, iNumberStyle + MYTEXT ('0'), &lpDest, &iBufSize) ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		iLength	= 1 ;
#else
		iLength	= 2 ;
#endif
		if (iBufSize < iLength){
			*lpDest	= MYTEXT ('\0') ;
			return	TRUE ;
		}
		Mylstrcpy (lpDest, MYTEXT ("�N")) ;
		lpDest		+= iLength ;
		iBufSize	-= iLength ;
	}
	/* ����N�̉����������j���ł��邩�𓾂�B*/
	Myltoa (tempBuffer, ltime.wMonth) ;
	/* ����W�J����B*/
	j_num_exp (tempBuffer, iNumberStyle + MYTEXT ('0'), &lpDest, &iBufSize) ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	iLength	= 1 ;
#else
	iLength	= 2 ;
#endif
	if (iBufSize < iLength){
		*lpDest	= MYTEXT ('\0') ;
		return	TRUE ;
	}
	Mylstrcpy (lpDest, MYTEXT ("��")) ;
	lpDest		+= iLength ;
	iBufSize	-= iLength ;

	Myltoa (tempBuffer, ltime.wDay) ;
	j_num_exp (tempBuffer, iNumberStyle + MYTEXT ('0'), &lpDest, &iBufSize) ;
	if (iBufSize < iLength){
		*lpDest	= MYTEXT ('\0') ;
		return	TRUE ;
	}
	Mylstrcpy (lpDest, MYTEXT ("��")) ;
	lpDest		+= iLength ;
	iBufSize	-= iLength ;
	/* �j���������B*/
	if (iBufSize < 1){
		*lpDest	= MYTEXT ('\0') ;
		return	TRUE ;
	}
	*lpDest		++	= MYTEXT ('(') ;
	iBufSize	-- ;
	iLength			= Mylstrlen (skk_week_alist [ltime.wDayOfWeek]) ;
	if (iBufSize < iLength){
		*lpDest	= MYTEXT ('\0') ;
		return	TRUE ;
	}
	Mylstrcpy (lpDest, skk_week_alist [ltime.wDayOfWeek]) ;
	lpDest		+= iLength ;
	iBufSize	-= iLength ;
	if (iBufSize){
		*lpDest		++	= MYTEXT (')') ;
		iBufSize	-- ;
	}
	*lpDest	= MYTEXT ('\0') ;
	return	TRUE ;
}

/*
 * # �𐔎��ɓW�J����֐��B
 *---
 * dbufsize �� dptr �̗e�ʂł��B�e�ʃI�[�o������邽�߂ɂ��炩���ߓn��
 * �Ă��܂��B����� skkinput ���C�Ӓ��̕������ҏW�ł��Ȃ����Ƃ��痈
 * �Ă��܂��B�������Aeditor ����Ȃ��̂����� 
 * (Japanese-Input-Method-Editor �Ƃ� Windows'95 �ł͌����炵���ł���
 * ��) �C�Ӓ��̕ҏW���\�ȕK�v�͂Ȃ��Ǝv���܂����ǂˁB
 */
LPMYSTR	j_num_exp (LPMYSTR lpJNumList, int iType, LPMYSTR FAR* lpDest, int FAR* lpBufSize)
{
	switch (iType){
	case MYTEXT ('0'):
		return	j_identity (lpJNumList, lpDest, lpBufSize) ;
	case MYTEXT ('1'):
		return	j_zenkaku_num_str (lpJNumList, lpDest, lpBufSize) ;
	case MYTEXT ('2'):
		return	j_kanji_num_str (lpJNumList, lpDest, lpBufSize) ;
	case MYTEXT ('3'):
		return	j_kanji_num_str2 (lpJNumList, lpDest, lpBufSize) ;
	case MYTEXT ('9'):
		return	j_shogi_num_str (lpJNumList, lpDest, lpBufSize) ;
	default:
		break ;
	}
	while (*lpJNumList && *lpJNumList != MYTEXT ('/'))
		lpJNumList ++ ;
	return	lpJNumList ;
}

LPMYSTR	j_identity (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize)
{
	LPMYSTR	lpptr ;
	int		iBufSize ;

	lpptr		= *lpDest ;
	iBufSize	= *lpBufSize ;
	while (*lpSrc && *lpSrc != MYTEXT ('/') && iBufSize){
		*lpptr	++ = *lpSrc ++ ;
		iBufSize	-- ;
	}
	while (*lpSrc && *lpSrc != MYTEXT ('/'))
		lpSrc ++ ;
	*lpptr		= MYTEXT ('\0') ;
	*lpDest		= lpptr ;
	*lpBufSize	= iBufSize ;
	return	lpSrc ;
}

LPMYSTR	j_zenkaku_num_str (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize)
{
	LPMYSTR	lpptr ;
	int		iBufSize ;
#if !defined(MIXED_UNICODE_ANSI) && !defined (UNICODE)
	int		chara ;
#endif
	lpptr		= *lpDest ;
	iBufSize	= *lpBufSize ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	while (*lpSrc && *lpSrc != MYTEXT ('/') && iBufSize){
		*lpptr	++	= MYTEXT ('�O') + *lpSrc - MYTEXT ('0') ;
		lpSrc	++ ;
		iBufSize-- ;
	}
#else
	while (*lpSrc && *lpSrc != MYTEXT ('/')){
		if (iBufSize < 2){
			iBufSize	= 0 ;
			break ;
		}
		chara		= 0x824F + (*lpSrc - MYTEXT ('0')) ;
		*lpptr	++	= (MYCHAR)((chara >> 8) & 0x00FF) ;
		*lpptr	++	= (MYCHAR)(chara & 0x00FF) ;
		lpSrc	++ ;
		iBufSize	-= 2 ;
	}
#endif
	while (*lpSrc && *lpSrc != MYTEXT ('/'))
		lpSrc ++ ;
	*lpptr		= MYTEXT ('\0') ;
	*lpDest		= lpptr ;
	*lpBufSize	= iBufSize ;
	return	lpSrc ;
}

/*
 *	�����������\���ɂ���֐��B
 */
LPMYSTR	j_kanji_num_str (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize)
{
	LPMYSTR	lpptr ;
	int		iBufSize ;

	lpptr		= *lpDest ;
	iBufSize	= *lpBufSize ;

#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	while (*lpSrc && *lpSrc != MYTEXT ('/') && iBufSize){
		*lpptr		++	= *skk_kanji_num_list [*lpSrc - MYTEXT ('0')] ;
		lpSrc		++ ;
		iBufSize	-- ;
	}
#else
	while (*lpSrc && *lpSrc != MYTEXT ('/')){
		if (iBufSize < 2){
			iBufSize	= 0 ;
			break ;
		}
		*lpptr		++	= *(skk_kanji_num_list [*lpSrc - MYTEXT ('0')] + 0) ;
		*lpptr		++	= *(skk_kanji_num_list [*lpSrc - MYTEXT ('0')] + 1) ;
		lpSrc		++ ;
		iBufSize		-= 2 ;
	}
#endif
	while (*lpSrc && *lpSrc != MYTEXT ('/'))
		lpSrc ++ ;
	*lpptr		= MYTEXT ('\0') ;
	*lpDest		= lpptr ;
	*lpBufSize	= iBufSize ;
	return	lpSrc ;
}

LPMYSTR	j_kanji_num_str2 (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize)
{
	LPMYSTR	lpptr ;
	LPMYSTR	lplsrc ;
	int		iBufSize ;
	int		iLength ;
	int		iDigitNumber ;
	BOOL	fSilent ;

	lpptr		= *lpDest ;
	iBufSize	= *lpBufSize ;

	/* Source �̕����񒷂����߂�B*/
	lplsrc		= lpSrc ;
	iLength		= 0 ;
	while (*lplsrc && *lplsrc != MYTEXT ('/')){
		lplsrc	++ ;
		iLength	++ ;
	}
	/* ���̗�͕\������Ȃ��̂Ŗ��������񂾂��ǁc�B*/
	while (*lpSrc == MYTEXT ('0')){
		lpSrc	++ ;
		iLength	-- ;
	}
	if (!iLength){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
		if (iBufSize >= 1){
			*lpptr		++	= *skk_kanji_num_list [0] ;
			iBufSize	-- ;
		}
#else
		if (iBufSize >= 2){
			*lpptr		++	= *(skk_kanji_num_list [0] + 0) ;
			*lpptr		++	= *(skk_kanji_num_list [0] + 1) ;
			iBufSize		-= 2 ;
		}
#endif
	} else {
		iDigitNumber	= ((iLength - 1) / 4) - 1 ;
		/* �傫�߂��鐔�ł����H */
		if (iDigitNumber < 17){
			fSilent	= TRUE ;
			while (iLength > 0){
				if (*lpSrc > MYTEXT ('1') || (*lpSrc != MYTEXT ('0') && (iLength % 4) == 1)){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
					if (iBufSize >= 1){
						*lpptr		++	= *skk_kanji_num_list [*lpSrc - MYTEXT ('0')] ;
						iBufSize	-- ;
					} else {
						iBufSize	= 0 ;
						break ;
					}
#else
					if (iBufSize >= 2){
						*lpptr		++	= (MYCHAR)*(skk_kanji_num_list [*lpSrc - MYTEXT ('0')] + 0) ;
						*lpptr		++	= (MYCHAR)*(skk_kanji_num_list [*lpSrc - MYTEXT ('0')] + 1) ;
						iBufSize		-= 2 ;
					} else {
						iBufSize	= 0 ;
						break ;
					}
#endif
				}
				if (*lpSrc != MYTEXT ('0')){
					/* �\�A�S�A��̈ʂɈ�ł��Z�łȂ����̂�����΁A�ق��Ă��� *
					 * ���c�B�����ŁA�ق��Ă��Ȃ����Ă̂́A���Ƃ����Ƃ��\����   *
					 * ����ĈӖ��B���Ȃ݂ɁA��̈ʂ̎����Z�łȂ�������A���Ƃ� *
					 * �ƕ\���������Ȃ񂾂���c�˂��B*/
					if (iLength % 4 == 2){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						if (iBufSize >= 1){
							*lpptr		++	= MYTEXT ('�\') ;
							iBufSize	-- ;
						} else {
							iBufSize	= 0 ;
							break ;
						}
#else
						if (iBufSize >= 2){
							*lpptr		++	= (MYCHAR)0x8F ;
							*lpptr		++	= (MYCHAR)0x5C ;
							iBufSize		-= 2 ;
						} else {
							iBufSize	= 0 ;
							break ;
						}
#endif
					} else if (iLength % 4 == 3){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						if (iBufSize >= 1){
							*lpptr		++	= MYTEXT ('�S') ;
							iBufSize	-- ;
						} else {
							iBufSize	= 0 ;
							break ;
						}
#else
						if (iBufSize >= 2){
							*lpptr		++	= (char)0x95 ;
							*lpptr		++	= (char)0x53 ;
							iBufSize		-= 2 ;
						} else {
							iBufSize	= 0 ;
							break ;
						}
#endif
					} else if (iLength % 4 == 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
						if (iBufSize >= 1){
							*lpptr		++	= MYTEXT ('��') ;
							iBufSize	-- ;
						} else {
							iBufSize	= 0 ;
							break ;
						}
#else
						if (iBufSize >= 2){
							*lpptr		++	= (MYCHAR)0x90 ;
							*lpptr		++	= (MYCHAR)0xE7 ;
							iBufSize		-= 2 ;
						} else {
							iBufSize	= 0 ;
							break ;
						}
#endif
					}
					fSilent	= FALSE ;
				}
				if (!fSilent || *lpSrc != MYTEXT ('0')){
					iDigitNumber	= iLength - 1 ;
					if (iDigitNumber % 4 == 0){
						iDigitNumber	= iDigitNumber / 4 - 1 ;
						/* ���Ƃ����Ƃ����Ƃ����������̂�\������H */
						if (iDigitNumber >= 0){
							lplsrc	= skk_numeric_unit [iDigitNumber] ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
							while (*lplsrc != MYTEXT ('\0') && iBufSize){
								*lpptr		++	= *lplsrc ++ ;
								iBufSize	-- ;
							}
							if (iBufSize <= 0)
								break ;
#else
							while (*lplsrc != MYTEXT ('\0') && iBufSize){
								if (IsDBCSLeadByte (*lplsrc)){
									if (iBufSize < 2){
										iBufSize	= 0 ;
										break ;
									}
									*lpptr	++	= *lplsrc ++ ;
									*lpptr	++	= *lplsrc ++ ;
									iBufSize	-= 2 ;
								} else {
									*lpptr ++	= *lplsrc ++ ;
									iBufSize	-- ;
								}
							}
							if (iBufSize <= 0)
								break ;
#endif
							/* �\��������ق邱�Ƃɂ���B*/
							fSilent	= TRUE ;
						}
					}
				}
				iLength	-- ;
				lpSrc	++ ;
			}
		}
	}
	while (*lpSrc != MYTEXT ('/') && *lpSrc)
		lpSrc	++ ;
	*lpptr		= MYTEXT ('\0') ;
	*lpDest		= lpptr ;
	*lpBufSize	= iBufSize ;
	return	lpSrc ;
}

LPMYSTR	j_shogi_num_str (LPMYSTR lpSrc, LPMYSTR FAR* lpDest, int FAR* lpBufSize)
{
	LPMYSTR	lpptr		= *lpDest ;
	int		iBufSize	= *lpBufSize ;
#ifdef FAKIMEM
	if (*lpSrc != MYTEXT ('/') && *lpSrc != MYTEXT ('\0') && iBufSize > 1){
		*lpptr ++	= MYTEXT ('�O') + (*lpSrc - MYTEXT ('0')) ;
		iBufSize	-- ;
		lpSrc  ++ ;
	} else {
		iBufSize	= 0 ;
		goto	exit_j_shogi_num_str ;
	}
#else
	int		chara ;
	if (*lpSrc != MYTEXT ('/') && *lpSrc != MYTEXT ('\0') && iBufSize >= 2){
		chara		= 0x824F + (*lpSrc - MYTEXT ('0')) ;
		*lpptr ++	= (MYCHAR)((chara >> 8) & 0x00FF) ;
		*lpptr ++	= (MYCHAR)(chara & 0x00FF) ;
		lpSrc  ++ ;
		iBufSize	-= 2 ;
	} else {
		iBufSize	= 0 ;
		goto	exit_j_shogi_num_str ;
	}
#endif
	/* �񕶎��ڂ͊����ɂȂ�B*/
	if (*lpSrc != MYTEXT ('/') && *lpSrc != MYTEXT ('\0') && iBufSize >= 2){
#ifdef FAKIMEM
		*lpptr ++	= *skk_kanji_num_list [*lpSrc - MYTEXT ('0')] ;
		iBufSize	-- ;
#else
		*lpptr ++	= *(skk_kanji_num_list [*lpSrc - MYTEXT ('0')] + 0) ;
		*lpptr ++	= *(skk_kanji_num_list [*lpSrc - MYTEXT ('0')] + 1) ;
		iBufSize	-= 2 ;
#endif
		lpSrc  ++ ;
	} else {
		iBufSize	= 0 ;
		goto	exit_j_shogi_num_str ;
	}
exit_j_shogi_num_str:
	while (*lpSrc != MYTEXT ('/') && *lpSrc != MYTEXT ('\0'))
		lpSrc	++ ;
	*lpptr		= MYTEXT ('\0') ;
	*lpDest		= lpptr ;
	*lpBufSize	= iBufSize ;
	return	lpSrc ;
}

int	ShiftJisToEucJapan (char FAR* lpDest, char FAR* lpSrc, int iSize)
{
	unsigned short	c1, c2 ;
	int				iUsage ;
	iUsage	= iSize ;
	c1		= '\0' ;
	while (iUsage > 0 && *lpSrc != '\0'){
		if (c1 != '\0'){
			c2	= (char)(*lpSrc & 0x00FF) ;
			c1	= (char)((c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1) ;
			c2	= (char)(c2 -  ((c2 >= 0x80)? 0x20 : 0x1F)) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			if (iUsage < 2)
				break ;
			*lpDest ++	= (char)((c1 & 0x00FF) | 0x80) ;
			iUsage	-- ;
			*lpDest ++	= (char)((c2 & 0x00FF) | 0x80) ;
			iUsage	-- ;
			lpSrc	++ ;
			c1			= '\0' ;
		} else {
			if (IsDBCSLeadByte (*lpSrc)){
				c1			= (char)(*lpSrc & 0x00FF) ;
				lpSrc	++ ;
			} else if (0xA1 <= *lpSrc && *lpSrc <= 0xDF){
				c1			= '\0' ;
				if (iUsage < 2)
					break ;
				*lpDest ++	= (char)0x8E ;
				iUsage	-- ;
				*lpDest ++	= *lpSrc ++ ;
				iUsage	-- ;
			} else {
				c1			= '\0' ;
				*lpDest	++	= *lpSrc ++ ;
				iUsage	-- ;
			}
		}
	}
	if (iUsage > 0)
		*lpDest	= '\0' ;
	return	(iSize - iUsage) ;
}

