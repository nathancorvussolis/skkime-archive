/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * kanji.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "mylocale.h"
#include "mystring.h"
#include "skkiserv.h"
#include "unicode.h"

/*
 *	�}�N���̒�`�B
 */
#define IS_SHIFTJIS_2BYTE_CODE1(c)		(((((unsigned char)c) >= 0x81 && ((unsigned char)c) <= 0x9F) || (((unsigned char)c) >= 0xE0 && ((unsigned char)c) <= 0xEF))? TRUE : FALSE)
#define IS_SHIFTJIS_2BYTE_CODE2(c)		(((((unsigned char)c) >= 0x40 && ((unsigned char)c) <= 0x7E) || (((unsigned char)c) >= 0x80 && ((unsigned char)c) <= 0xFC))? TRUE : FALSE)
#define IS_SHIFTJIS_JISX201_KATAKANA(c)	((((unsigned char)c) >= 0xA1 && ((unsigned char)c) <= 0xDF)? TRUE : FALSE)

/*
 *	Private Prototypes
 */
static	BOOL			j_read_euc_one_line (LPMYSTR lpBuffer, int iBufSize, LPWINFILE lpFile) ;
static	BOOL			j_read_jis_one_line (LPMYSTR lpBuffer, int iBufSize, LPWINFILE lpFile) ;
static	BOOL			j_read_sjis_one_line (LPMYSTR lpBuffer, int iBufSize, LPWINFILE lpFile) ;
static	BOOL			j_put_euc_string (LPWINFILE lpFile, LPCMYSTR lpString) ;
static	BOOL			j_put_jis_string (LPWINFILE lpFile, LPCMYSTR lpString) ;
static	BOOL			j_put_sjis_string (LPWINFILE lpFile, LPCMYSTR lpString) ;

/*
 *	Functions 
 */

BOOL	eucjp_init (LPISO2022STATE lpState)
{
	lpState->m_fEscapeSequence	= FALSE ;
	lpState->m_iEscapeState		= 0 ;
	lpState->m_iLeadChara		= '\0' ;
	lpState->m_fSingleShift		= FALSE ;
	lpState->m_iCharset [0]		= KCHARSET_ASCII ;
	lpState->m_iCharset [1]		= KCHARSET_JISX0208_1983 ;
	lpState->m_iCharset [2]		= KCHARSET_JISX0201_1976 ;
	lpState->m_iCharset [3]		= KCHARSET_JISX0212_1990 ;
	lpState->m_iGL [0]			= 0 ;
	lpState->m_iGL [1]			= -1 ;
	lpState->m_iGR [0]			= 1 ;
	lpState->m_iGR [1]			= -1 ;
	return	TRUE ;
}

/*
 *	iso-2022-jp-2 ��ԑJ�ڋ@�B������������֐��B
 *-----
 *(���e)
 *	iso-2022-jp-2 �̍s���ł̏�Ԃɂ��킹��B
 *	�m���c�s���ł́A
 *		G0 �����W���́A�A�X�L�[�B
 *		G1 �����W���́AJISX0201-1976 �̉E���ʁB
 *		G2 �����W���́A�s��B
 *		G3 �����W���́A�s��B
 *		GL �� G0 �����W�����w���A
 *		GR �� G1 �����W�����w���B
 *	�ɂȂ锤�B
 *	JISX0201-1976 �̉E���ʂ̈����ɂ��Ă͗ǂ��킩��Ȃ��B
 *	Mule �Ȃǂɐ����������R�[�h�������Ȃ��Ă�������c�Ƃ��Ă����B
 */
BOOL	iso2022jp_init (LPISO2022STATE lpState)
{
	lpState->m_fEscapeSequence	= FALSE ;
	lpState->m_iEscapeState		= 0 ;
	lpState->m_iLeadChara		= '\0' ;
	lpState->m_fSingleShift		= FALSE ;
	lpState->m_iCharset [0]		= KCHARSET_ASCII ;
	lpState->m_iCharset [1]		= KCHARSET_JISX0201_1976 ;
	lpState->m_iCharset [2]		= KCHARSET_NOTHING ;
	lpState->m_iCharset [3]		= KCHARSET_NOTHING ;
	lpState->m_iGL [0]			= 0 ;
	lpState->m_iGL [1]			= -1 ;
	lpState->m_iGR [0]			= 1 ;
	lpState->m_iGR [1]			= -1 ;
	return	TRUE ;
}

#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)

int		eucjp_charW (LPISO2022STATE lpState, int iChara, LPWORD lpwOutput)
{
	if (lpState->m_iLeadChara){
		switch (lpState->m_iCharset [lpState->m_iGR [0]]){
		case	KCHARSET_JISX0208_1983:
			if (lpState->m_fSingleShift)
				return	-1 ;
			*lpwOutput		= UNICODE_JISX0208 ((lpState->m_iLeadChara << 8) | iChara) ;
			lpState->m_iLeadChara	= '\0' ;
			return	TRUE ;
		case	KCHARSET_JISX0212_1990:
			if (!lpState->m_fSingleShift)
				return	-1 ;
			lpState->m_iGR [0]		= 1 ;
			lpState->m_iLeadChara	= '\0' ;
			lpState->m_fSingleShift	= FALSE ;
			return	TRUE ;
		default:
			lpState->m_iGR [0]		= 1 ;
			lpState->m_iLeadChara	= '\0' ;
			lpState->m_fSingleShift	= FALSE ;
			return	-1 ;
		}
	}
	if (iChara <= (0x80 + 0x20)){
		if (lpState->m_fSingleShift || lpState->m_iLeadChara){
			lpState->m_fSingleShift	= FALSE ;
			lpState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		if (iChara < 0x80){
			*lpwOutput	= iChara ;
			return	TRUE ;
		} else if (iChara == 0x8E){
			lpState->m_iGR [0]		= 2 ;
			lpState->m_fSingleShift	= TRUE ;
			return	FALSE ;
		} else if (iChara == 0x8F){
			lpState->m_iGR [0]		= 3 ;
			lpState->m_fSingleShift	= TRUE ;
			return	FALSE ;
		} else {
			return	-1 ;
		}
	}
	switch (lpState->m_iCharset [lpState->m_iGR [0]]){
	case	KCHARSET_JISX0201_1976:
		if (!lpState->m_fSingleShift)
			return	-1 ;
		*lpwOutput				= UNICODE_JISX0201 (iChara) ;
		lpState->m_iGR [0]		= 1 ;
		lpState->m_fSingleShift	= FALSE ;
		return	TRUE ;
	case	KCHARSET_JISX0208_1983:
	case	KCHARSET_JISX0212_1990:
		lpState->m_iLeadChara	= iChara & 0x00FF ;
		return	FALSE ;
	default:
		return	-1 ;
	}
}

/*
 *	iso-2022-jp-2 ��ԑJ�ڋ@�B���G�~�����[�g����֐��B
 *-----
 *(����)
 *	lpState		iso-2022-jp-2 ��ԑJ�ڋ@�B�̌��݂̏�ԁB
 *	iChara		���̓A���t�@�x�b�g�B
 *	lpwOutput	�o�̓A���t�@�x�b�g(�����݂����ꍇ)��Ԃ��o�b�t�@�̃|�C���^�B
 *(�Ԃ�l)
 *	0			�o�̓A���t�@�x�b�g�͑��݂��Ȃ��B
 *	1			�o�̓A���t�@�x�b�g�����݂���B
 *	-1			�G���[�����BMS�����R�[�h�� Unicode (�R�[�h�y�[�W:���{) �ň����Ȃ��������������Ă��G���[�B
 */
int		iso2022jp_charW (LPISO2022STATE lpState, int iChara, LPWORD lpwOutput)
{
	if (lpState->m_fEscapeSequence){
		/*
		 *	���Ȃ�蔲���� iso-2022-jp-2 �̃G�X�P�[�v�V�[�P���X���ߕ��B
		 *	switch �` case ���́A������Ɓc�ʂ̌`�Ŏ����������悤�ȁB
		 */
		switch (lpState->m_iEscapeState){
		case 0:
			switch (iChara){
			case '$':
				lpState->m_iEscapeState	= 1 ;
				break ;
			case '(':
				lpState->m_iEscapeState	= 3 ;
				break ;
			case 'N':
				/*	shingle-shift-seq */
				lpState->m_iEscapeState	= 5 ;
				break ;
			case '.':
				/* 96 character sets ESC sequence */
				lpState->m_iEscapeState	= 4 ;
				break ;
			default:
				/*	�m��Ȃ��G�X�P�[�v�V�[�P���X�������ꍇ�̏����B*/
				lpState->m_iEscapeState	= 0 ;
				lpState->m_fEscapeSequence = FALSE ;
				break ;
			}
			break ;
		case 1:
			switch (iChara){
			case '@':
				/*	G0 �� JISC6226-1978 (94^2�����W�������蓖�Ă�j*/
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1978 ;
				break ;
			case 'B':
				/*	G0 �� JISX0208-1983 (94^2�����W�������蓖�Ă�) */
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1983 ;
				break ;
			case 'A':
				/*	G0 �� GB2312-1980 (94^2 �����W�������蓖�Ă�) */
				lpState->m_iCharset [0] = KCHARSET_GB2312_1980 ;
				break ;
			case '(':
				lpState->m_iEscapeState = 2 ;
				break ;
			default:
				break ;
			}
			goto	exit_escapeseq ;
		case 2:
			switch (iChara){
			case '@':
				/*	G0 �� JISC6226-1978 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1978 ;
				break ;
			case 'B':
				/*	G0 �� JISX0208-1983 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1983 ;
				break ;
			case '(':
				/*	G0 �� KSC6501-1987 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_KSC5601_1987 ;
				break ;
			case 'D':
				/*	G0 �� JISX0212-1990 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_JISX0212_1990 ;
				break ;
			default:
				break ;
			}
			goto	exit_escapeseq ;
		case 3:
			if (iChara == 'B'){
				/*	G0 �� ASCII (94^1�����W��) �����蓖�Ă�B*/
				lpState->m_iCharset [0]	= KCHARSET_ASCII ;
			} else if (iChara == 'J'){
				/*	G0 �� JISX0201-1976(Roman) (94^1�����W��) �����蓖�Ă�B*/
				lpState->m_iCharset [0]	= KCHARSET_JISX0201_1976 ;
			}
			goto	exit_escapeseq ;
		case 4:
			if (iChara == 'A'){
				/*	G2 �� ISO8859-1 �����蓖�Ă�B*/
				lpState->m_iCharset [2]	= KCHARSET_ISO8859_1 ;
			} else if (iChara == 'F'){
				/*	G2 �� ISO8859-7 �����蓖�Ă�B*/
				lpState->m_iCharset [2]	= KCHARSET_ISO8859_7 ;
			}
			goto	exit_escapeseq ;
		case 5:
			/* Single-Shift-Char */
			lpState->m_iLeadChara		= '\0' ;
			lpState->m_fSingleShift		= TRUE ;
			lpState->m_iGR [1]			= lpState->m_iGR [0] ;
			lpState->m_iGR [0]			= 2 ;
		default:
		exit_escapeseq:
			lpState->m_iEscapeState		= 0 ;
			lpState->m_fEscapeSequence	= FALSE ;
			break ;
		}
		return	FALSE ;
	}
	if (lpState->m_fSingleShift){
		lpState->m_fSingleShift	= FALSE ;
		lpState->m_iLeadChara	= '\0' ;
		lpState->m_iGR [0]		= lpState->m_iGR [1] ;
		return	-1 ;
	}
	if (iChara <= 0x20){
		if (lpState->m_iLeadChara){
			lpState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		if (iChara == 0x1b){
			lpState->m_fEscapeSequence	= TRUE ;
			lpState->m_iEscapeState		= 0 ;
			return	FALSE ;
		} else {
			*lpwOutput	= iChara ;
			return	TRUE ;
		}
	} else if (iChara < 0x80){
		if (lpState->m_iGL [0] < 0 || lpState->m_iGL [0] > 2)
			return	-1 ;
		switch (lpState->m_iCharset [lpState->m_iGL [0]]){
		case	KCHARSET_ASCII:
		case	KCHARSET_JISX0201_1976:
			if (lpState->m_iLeadChara){
				lpState->m_iLeadChara	= '\0' ;
				return	-1 ;
			}
			*lpwOutput	= iChara ;
			return	TRUE ;
		case	KCHARSET_JISX0208_1978:
		case	KCHARSET_JISX0208_1983:
			if (lpState->m_iLeadChara){
				*lpwOutput	= UNICODE_JISX0208 ((lpState->m_iLeadChara << 8) | iChara) ;
				lpState->m_iLeadChara	= '\0' ;
				return	TRUE ;
			} else {
				lpState->m_iLeadChara	= iChara & 0x00FF ;
				return	FALSE ;
			}
		case	KCHARSET_JISX0212_1990:
			if (lpState->m_iLeadChara){
				*lpwOutput	= UNICODE_JISX0212 ((lpState->m_iLeadChara << 8) | iChara) ;
				lpState->m_iLeadChara	= '\0' ;
				return	TRUE ;
			} else {
				lpState->m_iLeadChara	= iChara & 0x00FF ;
				return	FALSE ;
			}
		default:
			return	-1 ;
		}
	}
	if (lpState->m_iGR [0] < 0 || lpState->m_iGR [0] > 2)
		return	-1 ;
	switch (lpState->m_iCharset [lpState->m_iGR [0]]){
	case	KCHARSET_JISX0201_1976:
		if (lpState->m_iLeadChara){
			lpState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		*lpwOutput	= UNICODE_JISX0201 (iChara) ;
		return	TRUE ;
	default:
		break ;
	}
	return	-1 ;
}

#endif

int		eucjp_charA (LPISO2022STATE lpState, int iChara, LPWORD lpwOutput)
{
	WORD	cch, ccl ;
	if (lpState->m_iLeadChara){
		switch (lpState->m_iCharset [lpState->m_iGR [0]]){
		case	KCHARSET_JISX0208_1983:
			if (lpState->m_fSingleShift)
				return	-1 ;
			/* JISX0208-1983 �����W���Ɋ܂܂�镶����SHIFTJIS����������B*/
			cch				= ((lpState->m_iLeadChara - 0x7F) >> 1) + 0x70 ;
			cch				= (cch >= 0xA0)? cch + 0x40 : cch ;
			ccl				= iChara - ((lpState->m_iLeadChara & 1)? 0x61 : 0x03) ;
			ccl				= (ccl >= 0x7F)? ccl + 1 : ccl ;
			*lpwOutput		= ((cch & 0x00FF) << 8) | (ccl & 0x00FF) ;
			lpState->m_iLeadChara	= '\0' ;
			return	TRUE ;
		case	KCHARSET_JISX0212_1990:
		default:
			lpState->m_iGR [0]		= 1 ;
			lpState->m_iLeadChara	= '\0' ;
			lpState->m_fSingleShift	= FALSE ;
			return	-1 ;
		}
	}
	if (iChara <= (0x80 + 0x20)){
		if (lpState->m_fSingleShift || lpState->m_iLeadChara){
			lpState->m_fSingleShift	= FALSE ;
			lpState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		if (iChara < 0x80){
			*lpwOutput	= iChara ;
			return	TRUE ;
		} else if (iChara == 0x8E){
			lpState->m_iGR [0]		= 2 ;
			lpState->m_fSingleShift	= TRUE ;
			return	FALSE ;
		} else if (iChara == 0x8F){
			lpState->m_iGR [0]		= 3 ;
			lpState->m_fSingleShift	= TRUE ;
			return	FALSE ;
		} else {
			return	-1 ;
		}
	}
	switch (lpState->m_iCharset [lpState->m_iGR [0]]){
	case	KCHARSET_JISX0201_1976:
		if (!lpState->m_fSingleShift)
			return	-1 ;
		*lpwOutput				= iChara & 0x00FF ;
		lpState->m_iGR [0]		= 1 ;
		lpState->m_fSingleShift	= FALSE ;
		return	TRUE ;
	case	KCHARSET_JISX0208_1983:
	case	KCHARSET_JISX0212_1990:
		lpState->m_iLeadChara	= iChara & 0x00FF ;
		return	FALSE ;
	default:
		return	-1 ;
	}
}

/*
 *	iso-2022-jp-2 ��ԑJ�ڋ@�B���G�~�����[�g����֐��B
 *-----
 *(����)
 *	lpState		iso-2022-jp-2 ��ԑJ�ڋ@�B�̌��݂̏�ԁB
 *	iChara		���̓A���t�@�x�b�g�B
 *	lpwOutput	�o�̓A���t�@�x�b�g(�����݂����ꍇ)��Ԃ��o�b�t�@�̃|�C���^�B
 *(�Ԃ�l)
 *	0			�o�̓A���t�@�x�b�g�͑��݂��Ȃ��B
 *	1			�o�̓A���t�@�x�b�g�����݂���B
 *	-1			�G���[�����BMS�����R�[�h�� Unicode (�R�[�h�y�[�W:���{) �ň����Ȃ��������������Ă��G���[�B
 */
int		iso2022jp_charA (LPISO2022STATE lpState, int iChara, LPWORD lpwOutput)
{
	WORD	ccl, cch ;
	if (lpState->m_fEscapeSequence){
		/*
		 *	���Ȃ�蔲���� iso-2022-jp-2 �̃G�X�P�[�v�V�[�P���X���ߕ��B
		 *	switch �` case ���́A������Ɓc�ʂ̌`�Ŏ����������悤�ȁB
		 */
		switch (lpState->m_iEscapeState){
		case 0:
			switch (iChara){
			case '$':
				lpState->m_iEscapeState	= 1 ;
				break ;
			case '(':
				lpState->m_iEscapeState	= 3 ;
				break ;
			case 'N':
				/*	shingle-shift-seq */
				lpState->m_iEscapeState	= 5 ;
				break ;
			case '.':
				/* 96 character sets ESC sequence */
				lpState->m_iEscapeState	= 4 ;
				break ;
			default:
				/*	�m��Ȃ��G�X�P�[�v�V�[�P���X�������ꍇ�̏����B*/
				lpState->m_iEscapeState	= 0 ;
				lpState->m_fEscapeSequence = FALSE ;
				break ;
			}
			break ;
		case 1:
			switch (iChara){
			case '@':
				/*	G0 �� JISC6226-1978 (94^2�����W�������蓖�Ă�j*/
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1978 ;
				break ;
			case 'B':
				/*	G0 �� JISX0208-1983 (94^2�����W�������蓖�Ă�) */
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1983 ;
				break ;
			case 'A':
				/*	G0 �� GB2312-1980 (94^2 �����W�������蓖�Ă�) */
				lpState->m_iCharset [0] = KCHARSET_GB2312_1980 ;
				break ;
			case '(':
				lpState->m_iEscapeState = 2 ;
				break ;
			default:
				break ;
			}
			goto	exit_escapeseq ;
		case 2:
			switch (iChara){
			case '@':
				/*	G0 �� JISC6226-1978 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1978 ;
				break ;
			case 'B':
				/*	G0 �� JISX0208-1983 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_JISX0208_1983 ;
				break ;
			case '(':
				/*	G0 �� KSC6501-1987 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_KSC5601_1987 ;
				break ;
			case 'D':
				/*	G0 �� JISX0212-1990 (94^2�����W��)�����蓖�Ă� */
				lpState->m_iCharset [0] = KCHARSET_JISX0212_1990 ;
				break ;
			default:
				break ;
			}
			goto	exit_escapeseq ;
		case 3:
			if (iChara == 'B'){
				/*	G0 �� ASCII (94^1�����W��) �����蓖�Ă�B*/
				lpState->m_iCharset [0]	= KCHARSET_ASCII ;
			} else if (iChara == 'J'){
				/*	G0 �� JISX0201-1976(Roman) (94^1�����W��) �����蓖�Ă�B*/
				lpState->m_iCharset [0]	= KCHARSET_JISX0201_1976 ;
			}
			goto	exit_escapeseq ;
		case 4:
			if (iChara == 'A'){
				/*	G2 �� ISO8859-1 �����蓖�Ă�B*/
				lpState->m_iCharset [2]	= KCHARSET_ISO8859_1 ;
			} else if (iChara == 'F'){
				/*	G2 �� ISO8859-7 �����蓖�Ă�B*/
				lpState->m_iCharset [2]	= KCHARSET_ISO8859_7 ;
			}
			goto	exit_escapeseq ;
		case 5:
			/* Single-Shift-Char */
			lpState->m_iLeadChara		= '\0' ;
			lpState->m_fSingleShift		= TRUE ;
			lpState->m_iGR [1]			= lpState->m_iGR [0] ;
			lpState->m_iGR [0]			= 2 ;
		default:
		exit_escapeseq:
			lpState->m_iEscapeState		= 0 ;
			lpState->m_fEscapeSequence	= FALSE ;
			break ;
		}
		return	FALSE ;
	}
	if (lpState->m_fSingleShift){
		lpState->m_fSingleShift	= FALSE ;
		lpState->m_iLeadChara	= '\0' ;
		lpState->m_iGR [0]		= lpState->m_iGR [1] ;
		return	-1 ;
	}
	if (iChara <= 0x20){
		if (lpState->m_iLeadChara){
			lpState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		if (iChara == 0x1b){
			lpState->m_fEscapeSequence	= TRUE ;
			lpState->m_iEscapeState		= 0 ;
			return	FALSE ;
		} else {
			*lpwOutput	= iChara ;
			return	TRUE ;
		}
	} else if (iChara < 0x80){
		if (lpState->m_iGL [0] < 0 || lpState->m_iGL [0] > 2)
			return	-1 ;
		switch (lpState->m_iCharset [lpState->m_iGL [0]]){
		case	KCHARSET_ASCII:
		case	KCHARSET_JISX0201_1976:
			if (lpState->m_iLeadChara){
				lpState->m_iLeadChara	= '\0' ;
				return	-1 ;
			}
			*lpwOutput	= iChara ;
			return	TRUE ;
		case	KCHARSET_JISX0208_1978:
		case	KCHARSET_JISX0208_1983:
			if (lpState->m_iLeadChara){
				/* JISX0208-1983 �����W���Ɋ܂܂�镶����SHIFTJIS����������B*/
				cch			= ((lpState->m_iLeadChara + 1) >> 1) + 0x70 ;
				cch			= ((cch >= 0xA0)? cch + 0x40 : cch) ;
				ccl			= iChara + ((lpState->m_iLeadChara & 1)? 0x1F : 0x7D) ;
				ccl			= ((ccl >= 0x7F)? ccl + 1 : ccl) ;
				*lpwOutput	= ((cch & 0x00FF) << 8) | (ccl & 0x00FF) ;
				lpState->m_iLeadChara	= '\0' ;
				return	TRUE ;
			} else {
				lpState->m_iLeadChara	= iChara & 0x00FF ;
				return	FALSE ;
			}
		case	KCHARSET_JISX0212_1990:
			if (lpState->m_iLeadChara){
				lpState->m_iLeadChara	= '\0' ;
				return	-1 ;
			} else {
				lpState->m_iLeadChara	= iChara & 0x00FF ;
				return	FALSE ;
			}
		default:
			return	-1 ;
		}
	}
	if (lpState->m_iGR [0] < 0 || lpState->m_iGR [0] > 2)
		return	-1 ;
	switch (lpState->m_iCharset [lpState->m_iGR [0]]){
	case	KCHARSET_JISX0201_1976:
		if (lpState->m_iLeadChara){
			lpState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		*lpwOutput	= iChara ;
		return	TRUE ;
	default:
		break ;
	}
	return	-1 ;
}

int		j_detect_coding_system_with_filename (LPCTSTR lpFileName, int nCheckBytes)
{
	WINFILE	winfile ;
	int		iCodingSystem ;
	winfileinit (&winfile) ;
	if (!lpFileName || !winfopen ((LPWINFILE)&winfile, lpFileName, GENERIC_READ, OPEN_EXISTING))
		return	KANJI_CODE_UNKNOWN ;
	iCodingSystem	= j_detect_coding_system (&winfile, nCheckBytes) ;
	winfclose ((LPWINFILE)&winfile) ;
	return	iCodingSystem ;
}

/*
 *	�����̕����R�[�h���������ʂ���̂ɗp�����郁�\�b�h�B
 */
int		j_detect_coding_system (LPWINFILE lpFile, int nCheckBytes)
{
	int						cc ;
	int						iLoopCounter ;
	BOOL					fProbabilityCodingSystem [3] ;
	char					bufShiftJisChar [8] ;
	int						iBufShiftJisUsage ;
	char					bufEucJpChar [8] ;
	int						iBufEucJpUsage ;
	char					bufIso2022JpChar [8] ;
	int						iBufIso2022JpUsage ;
	/* iso-2022-jp-2 �ɋ�����Ă���G�X�P�[�v�V�[�P���X�B*/
	const char*				iso2022jpEscapeSequences [] = {
		"\x1b$@",	"\x1b$B",	"\x1b$(@",	"\x1b$(B",	"\x1b(B",	"\x1b(J",	
		"\x1b$A",	"\x1b$(C",	"\x1b$(D",	"\x1b.A",	"\x1b.F",	NULL,
	} ;
	/* �����R�[�h�̗D�揇�ʃe�[�u���B*/
	const int				priorityListOfCodingSystem [] = {
		KANJI_CODE_EUC, KANJI_CODE_SJIS, KANJI_CODE_JIS, -1,
	} ;
	winrewind (lpFile) ;
	for (iLoopCounter = 0 ; iLoopCounter < sizeof (fProbabilityCodingSystem) / sizeof (BOOL) ; iLoopCounter ++)
		fProbabilityCodingSystem [iLoopCounter]	= TRUE ;
	iBufShiftJisUsage	= 0 ;
	iBufEucJpUsage		= 0 ;
	iBufIso2022JpUsage	= 0 ;
	while (nCheckBytes > 0 && (cc = winfgetc (lpFile)) != EOF){
		/*	SHIFTJIS �R�[�h�ŕ���������Ă���Ɖ��肵���ꍇ�A�ǂ̕����ɑ�������̂����߂�B*/
		if (iBufShiftJisUsage <= 0){
			if (!IS_SHIFTJIS_2BYTE_CODE1 (cc)){
				if (!IS_SHIFTJIS_JISX201_KATAKANA (cc) && cc >= 0x80)
					fProbabilityCodingSystem [KANJI_CODE_SJIS] = FALSE ;
			} else {
				bufShiftJisChar [iBufShiftJisUsage ++]	= cc ;
			}
		} else {
			if (!IS_SHIFTJIS_2BYTE_CODE2 (cc))
				fProbabilityCodingSystem [KANJI_CODE_SJIS] = FALSE ;
			iBufShiftJisUsage	= 0 ;
		}
		/*	EUC-JP �ŕ���������Ă���Ɖ��肵���ꍇ�A�ǂ̕����ɑ�������̂����߂�B*/
		if (iBufEucJpUsage <= 0){
			if (cc == 0x8E || cc == 0x8F || (0xA1 <= cc && cc <= 0xFE)){
				bufEucJpChar [iBufEucJpUsage ++]	= cc ;
			} else if (cc >= 0x80){
				fProbabilityCodingSystem [KANJI_CODE_EUC]	= FALSE ;
			}
		} else {
			if (0xA1 <= cc && cc <= 0xFE){
				switch (bufEucJpChar [0]){
				case 0x8F:
					if (iBufEucJpUsage < 2){
						bufEucJpChar [iBufEucJpUsage ++]	= cc ;
					} else {
						iBufEucJpUsage	= 0 ;
					}
					break ;
				case 0x8E:
				default:
					if (iBufEucJpUsage >= 2)
						fProbabilityCodingSystem [KANJI_CODE_EUC]	= FALSE ;
					iBufEucJpUsage	= 0 ;
					break ;
				}
			} else {
				fProbabilityCodingSystem [KANJI_CODE_EUC]	= FALSE ;
				iBufEucJpUsage	= 0 ;
			}
		}
		/*	JUNET �ŕ���������Ă���Ɖ��肵���ꍇ�A�ǂ̕����ɑ�������̂����߂�B*/
		if (iBufIso2022JpUsage <= 0){
			if (cc == 0x1b){
				bufIso2022JpChar [iBufIso2022JpUsage ++]	= cc ;
			} else if (cc >= 0x80){
				fProbabilityCodingSystem [KANJI_CODE_JIS]	= FALSE ;
			}
		} else {
			/*	������ Escape Sequence �Ȃ̂��H*/
			bufIso2022JpChar [iBufIso2022JpUsage ++]	= cc ;
			for (iLoopCounter = 0 ; iso2022jpEscapeSequences [iLoopCounter] != NULL ; iLoopCounter ++){
				if (!MylstrncmpA (bufIso2022JpChar, iso2022jpEscapeSequences [iLoopCounter], iBufIso2022JpUsage)){
					if (!(iso2022jpEscapeSequences [iLoopCounter])[iBufIso2022JpUsage]){
						fProbabilityCodingSystem [KANJI_CODE_EUC]	= FALSE ;
						fProbabilityCodingSystem [KANJI_CODE_SJIS]	= FALSE ;
						iBufIso2022JpUsage	= 0 ;
					}
					break ;
				}
			}
			if (!iso2022jpEscapeSequences [iLoopCounter]){
				fProbabilityCodingSystem [KANJI_CODE_JIS]	= FALSE ;
				iBufIso2022JpUsage	= 0 ;
			}
		}
		nCheckBytes -- ;
	}
	winrewind (lpFile) ;
	/*	�����R�[�h�̗D�揇�ʂɉ����� *�炵��* ���������@��Ԃ��B*/
	for (iLoopCounter = 0 ; iLoopCounter < 3 ; iLoopCounter ++){
		if (fProbabilityCodingSystem [priorityListOfCodingSystem [iLoopCounter]])
			return priorityListOfCodingSystem [iLoopCounter] ;
	}
	return	KANJI_CODE_EUC ;
}

BOOL	j_read_one_line (LPMYSTR lpString, int iSize, LPWINFILE lpFile, int iCodingSystem)
{
	switch (iCodingSystem){
	case	KANJI_CODE_JIS:
		return	j_read_jis_one_line (lpString, iSize, lpFile) ;
	case	KANJI_CODE_SJIS:
		return	j_read_sjis_one_line (lpString, iSize, lpFile) ;
	case	KANJI_CODE_EUC:
	default:
		return	j_read_euc_one_line (lpString, iSize, lpFile) ;
	}
}

/*
 *	�t�@�C���̒��ł��镶���񂪗���܂œǂݔ�΂��֐��B
 */
BOOL	j_skip_file_until (LPWINFILE lpFile, LPCMYSTR lpString, int iCodingSystem)
{
	switch (iCodingSystem){
	case	KANJI_CODE_JIS:
		return	j_skip_jis_file_until (lpFile, lpString) ;
	case	KANJI_CODE_SJIS:
		return	j_skip_sjis_file_until (lpFile, lpString) ;
	case	KANJI_CODE_EUC:
	default:
		return	j_skip_euc_file_until (lpFile, lpString) ;
	}
}

BOOL	j_put_string (LPWINFILE lpFile, LPCMYSTR lpString, int iCodingSystem)
{
	switch (iCodingSystem){
	case	KANJI_CODE_JIS:
		return	j_put_jis_string (lpFile, lpString) ;
	case	KANJI_CODE_SJIS:
		return	j_put_sjis_string (lpFile, lpString) ;
	case	KANJI_CODE_EUC:
	default:
		return	j_put_euc_string (lpFile, lpString) ;
	}
}

/*
 *	Local Functions
 */

/*
 *	�t�@�C������1�s�f�[�^��ǂ݂��݁A���̕�����������EUC-JP�ł���ƍl���āASHIFTJIS ��
 *	�ϊ����ĕԂ��֐��B
 *---------------
 *	���݃t�@�C���̐擪�����Ă���ʒu�ɂ���Ɖ��肷��B
 * 	��������J�n���Ă��镶����ň����ɗ^����ꂽ������ƈ�v������̂�T���B
 *	!MIXED_UNICODE_ANSI, !UNICODE �Ȃ�΁ALPMYSTR �� SHIFTJIS STRING �ł��邱�Ƃ�Y��Ȃ��悤�ɁB
 */
BOOL	j_read_euc_one_line (LPMYSTR lpBuffer, int iBufSize, LPWINFILE lpFile)
{
	LPMYSTR				lpptr ;
	int					iChara ;
	ISO2022STATE		eucjpState ;
	WORD				wChara ;
	int					iRet ;

	if (!lpFile || !lpBuffer)
		return	FALSE ;

	eucjp_init (&eucjpState) ;
	iChara		= 0 ;
	lpptr		= lpBuffer ;
	for ( ; ; ){
		iChara	= winfgetc (lpFile) ;
		/* ������̍Ō�܂ň�v���Ă����ꍇ�A�t�@�C���̂��̍s�̍Ō�܂œǂ݂���ł��邩���ׂ�B*/
		if (iChara == EOF || iChara == '\n' || iChara == '\r')
			break ;
		iRet	= MyEucJpChar (&eucjpState, iChara, &wChara) ;
		if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iBufSize > 0){
				*lpptr	++	= wChara ;
				iBufSize	-- ;
			}
#else
			if (wChara > 0x100){
				if (iBufSize > 1){
					*lpptr		++	= (wChara >> 8) ;
					iBufSize	-- ;
					*lpptr		++	= (wChara & 0x00FF) ;
					iBufSize	-- ;
				} else {
					*lpptr		= '\0' ;
					iBufSize	= 0 ;
				}
			} else {
				if (iBufSize > 0){
					*lpptr		++	= (wChara & 0x00FF) ;
					iBufSize	-- ;
				}
			}
#endif
		}
	}
	*lpptr		= MYTEXT ('\0') ;
	return	(iChara == EOF)? FALSE : TRUE ;
}

BOOL	j_read_jis_one_line (LPMYSTR lpBuffer, int iBufSize, LPWINFILE lpFile)
{
	LPMYSTR				lpptr ;
	int					iChara ;
	ISO2022STATE		iso2022jpState ;
	WORD				wChara ;
	int					iRet ;

	if (!lpFile || !lpBuffer)
		return	FALSE ;

	iChara				= 0 ;
	lpptr				= lpBuffer ;

	/*
	 *	iso2022jp �ł� GL �� G0 ���Ăяo����Ă���Ƃ���B
	 * �iG0 �� GL �ɌĂяo�����f�t�H���g�̃o�b�t�@�ł���)
	 */
	/* �s���ł̉���B*/
	iso2022jp_init (&iso2022jpState) ;	
	for ( ; ; ){
		iChara	= winfgetc (lpFile) ;
		if (iChara == EOF || iChara == '\n' || iChara == '\r')
			break ;
		iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &wChara) ;
		if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iBufSize > 0){
				*lpptr		++	= wChara ;
				iBufSize	-- ;
			}
#else
			if (wChara > 0x100){
				if (iBufSize > 1){
					*lpptr		++	= wChara >> 8 ;
					iBufSize	-- ;
					*lpptr		++	= wChara & 0x00FF ;
					iBufSize	-- ;
				} else {
					*lpptr			= MYTEXT ('\0') ;
					iBufSize		= 0 ;
				}
			} else {
				if (iBufSize > 0){
					*lpptr		++	= wChara & 0x00FF ;
					iBufSize	-- ;
				}
			}
#endif
		}
	}
	*lpptr	= MYTEXT ('\0') ;
	return	(iChara == EOF)? FALSE : TRUE ;
}

BOOL	j_read_sjis_one_line (LPMYSTR lpBuffer, int iBufSize, LPWINFILE lpFile)
{
	LPMYSTR				lpptr ;
	int					iChara ;
	int					iLeadChara ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	unsigned char		c1, c2 ;
#endif

	if (!lpFile || !lpBuffer)
		return	FALSE ;

	/* ��v�����𕶎���̐擪�ɖ߂��B*/
	lpptr		= lpBuffer ;
	iLeadChara	= MYTEXT ('\0') ;

	for (; ;){
		iChara	= winfgetc (lpFile) ;
		if (iChara == EOF || iChara == '\n' || iChara == '\r')
			break ;
		if (iLeadChara){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			c1	= (unsigned char)iLeadChara ;
			c2	= (unsigned char)iChara ;
			c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
			c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			if (iBufSize > 0){
				*lpptr	++	= UNICODE_JISX0208 ((c1 << 8) | c2) ;
				iBufSize	-- ;
			}
#else
			if (iBufSize > 1){
				*lpptr	++	= (unsigned char)iLeadChara ;
				iBufSize	-- ;
				*lpptr	++	= (unsigned char)iChara ;
				iBufSize	-- ;
			} else {
				*lpptr		= '\0' ;
				iBufSize	= 0 ;
			}
#endif
			iLeadChara	= '\0' ;
		} else {
			if (IsDBCSLeadByte ((char)iChara)){
				iLeadChara	= iChara ;
			} else {
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (iChara < 0 || iChara > 127)
					iChara		= UNICODE_JISX0201 (iChara) ;
				if (iBufSize > 0){
					*lpptr		++	= iChara ;
					iBufSize	-- ;
				}
#else
				if (iBufSize > 0){
					*lpptr		++	= (unsigned char)iChara ;
					iBufSize	-- ;
				}
#endif
			}
		}
	}
	*lpptr		= MYTEXT ('\0') ;
	return	(iChara == EOF)? TRUE : FALSE ;
}

/*
 * ���݃t�@�C���̐擪�����Ă���ʒu�ɂ���Ɖ��肷��B
 * ��������J�n���Ă��镶����ň����ɗ^����ꂽ������ƈ�v������̂�T���B
 * !MIXED_UNICODE_ANSI, !UNICODE �Ȃ�΁ALPMYSTR �� SHIFTJIS STRING �ł��邱�Ƃ�Y��Ȃ��悤�ɁB
 */
BOOL	j_skip_euc_file_until (LPWINFILE lpFile, LPCMYSTR lpString)
{
	LPCMYSTR			lpptr ;
	int					iChara ;
	ISO2022STATE		eucjpState ;
	WORD				wChara ;
	int					iRet ;

	if (!lpFile || !lpString)
		return	FALSE ;

	iChara	= '\0' ;
	for (; ;){
		eucjp_init (&eucjpState) ;
		lpptr		= lpString ;		/* ��v�����𕶎���̐擪�ɖ߂��B*/
		while (*lpptr){
			iChara	= winfgetc (lpFile) ;
			if (iChara == EOF)
				return	FALSE ;
			iRet	= MyEucJpChar (&eucjpState, iChara, &wChara) ;
			if (!iRet)
				continue ;
			if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (*lpptr != wChara)
					goto	not_match ;
				lpptr	++ ;
#else
				if (wChara > 0x100){
					if ((unsigned char)*lpptr != (wChara >> 8))
						goto	not_match ;
					lpptr	++ ;
				}
				if ((unsigned char)*lpptr != (wChara & 0x00FF))
					goto	not_match ;
				lpptr	++ ;
#endif
			} else {
				goto	not_match ;
			}
		}
		/* ������̍Ō�܂ň�v���Ă����ꍇ�A�t�@�C���̂��̍s�̍Ō�܂œǂ݂���ł��邩���ׂ�B*/
		if (!*lpptr){
			iChara	= winfgetc (lpFile) ;
			if (iChara == EOF || iChara == '\n' || iChara == '\r')
				return	TRUE ;
		}
	not_match:
		/* ���̍s����ڎw���B*/
		while (iChara != '\r' && iChara != '\n'){
			iChara	= winfgetc (lpFile) ;
			if (iChara == EOF)
				return	FALSE ;
		}
	}
	return	FALSE ;	/* Cannot reach here. */
}

BOOL	j_skip_sjis_file_until (LPWINFILE lpFile, LPCMYSTR lpString)
{
	LPCMYSTR			lpptr ;
	int					iChara ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	int					iLeadChara ;
	unsigned char		c1, c2 ;
#endif

	if (!lpFile || !lpString)
		return	FALSE ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	iLeadChara	= '\0' ;
#endif
	iChara		= '\0' ;
	for (; ;){
		/* ��v�����𕶎���̐擪�ɖ߂��B*/
		lpptr	= lpString ;
		while (*lpptr){
			iChara	= winfgetc (lpFile) ;
			if (iChara == EOF)
				return	FALSE ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
			if (iLeadChara){
				c1	= (unsigned char)iLeadChara ;
				c2	= (unsigned char)iChara ;
				c1	= (c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1 ;
				c2	= c2 -  ((c2 >= 0x80)? 0x20 : 0x1F) ;
				if (c2 >= 0x7F){
					c2	-= 0x5E ;
				} else {
					c1	-- ;
				}
				if ((unsigned short)*lpptr != UNICODE_JISX0208 ((c1 << 8) | c2))
					break ;
				lpptr	++ ;
				iLeadChara	= '\0' ;
			} else {
				if (IsDBCSLeadByte ((char)iChara)){
					iLeadChara	= iChara ;
				} else {
					if (iChara < 0 || iChara > 127)
						iChara		= UNICODE_JISX0201 (iChara) ;
					if ((WCHAR)*lpptr != iChara)
						break ;
					lpptr	++ ;
				}
			}
#else
			if ((unsigned char)*lpptr != iChara)
				break ;
			lpptr	++ ;
#endif
		}
		/* ������̍Ō�܂ň�v���Ă����ꍇ�A�t�@�C���̂��̍s�̍Ō�܂œǂ݂���ł��邩���ׂ�B*/
		if (!*lpptr){
			iChara	= winfgetc (lpFile) ;
			if (iChara == EOF || iChara == '\n' || iChara == '\r')
				return	TRUE ;
		}
		/* ���̍s����ڎw���B*/
		while (iChara != '\r' && iChara != '\n'){
			iChara	= winfgetc (lpFile) ;
			if (iChara == EOF)
				return	FALSE ;
		}
	}
	return	FALSE ;	/* Cannot reach here. */
}

BOOL	j_skip_jis_file_until (LPWINFILE lpFile, LPCMYSTR lpString)
{
	LPCMYSTR			lpptr ;
	int					iChara ;
	BOOL				fNotMatch ;
	ISO2022STATE		iso2022jpState ;
	WORD				woChara ;
	int					iRet ;

	if (!lpFile || !lpString)
		return	FALSE ;

	/*
	 *	iso2022jp �ł� GL �� G0 ���Ăяo����Ă���Ƃ���B
	 * �iG0 �� GL �ɌĂяo�����f�t�H���g�̃o�b�t�@�ł���)
	 */
	for (; ;){
		/* �s���ł̉���B*/
		iso2022jp_init (&iso2022jpState) ;

		lpptr		= lpString ;
		fNotMatch	= FALSE ;
		for (; ;){
			iChara	= winfgetc (lpFile) ;
			if (iChara == EOF || iChara == '\n' || iChara == '\r')
				break ;
			iRet	= MyIso2022JpChar (&iso2022jpState, iChara, &woChara) ;
			if (!iRet)
				continue ;
			if (iRet > 0){
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
				if (*lpptr != woChara)
					fNotMatch	= TRUE ;
				if (*lpptr)
					lpptr	++ ;
#else
				if (woChara > 0x100){
					if ((unsigned char)*lpptr != (woChara >> 8))
						fNotMatch	= TRUE ;
					if (*lpptr)
						lpptr	++ ;
				}
				if ((unsigned char)*lpptr != (woChara & 0x00FF))
					fNotMatch	= TRUE ;
				if (*lpptr)
					lpptr	++ ;
#endif
			} else {
				fNotMatch	= TRUE ;
			}
		}
		if (!fNotMatch && !*lpptr)
			return	TRUE ;
		if (iChara == EOF)
			break ;
	}
	return	FALSE ;
}

#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)

BOOL	j_put_euc_string (LPWINFILE lpFile, LPCMYSTR lpString)
{
	unsigned short	sCode ;
	BYTE			bCodeMap ;
	while (*lpString){
		bCodeMap	= GetOriginalCode ((unsigned short FAR *)&sCode, *lpString ++) ;
		switch (bCodeMap){
		case MYCODEMAP_ASCII:
			winfputc ((char)(sCode & 0x7F), lpFile) ;
			break ;
		case MYCODEMAP_JISX0201:
			if (sCode > 127){
				winfputc ((char)'\x8E', lpFile) ;
				winfputc ((char)(sCode & 0xFF), lpFile) ;
			} else {
				winfputc ((char)(sCode & 0x7F), lpFile) ;
			}
			break ;
		case MYCODEMAP_JISX0208:
			winfputc ((char)(((sCode >> 8) & 0xFF) | 0x80), lpFile) ;
			winfputc ((char)(((sCode >> 0) & 0xFF) | 0x80), lpFile) ;
			break ;
		case MYCODEMAP_JISX0212:
			winfputc ('\x8F', lpFile) ;
			winfputc ((char)(((sCode >> 8) & 0xFF) | 0x80), lpFile) ;
			winfputc ((char)(((sCode >> 0) & 0xFF) | 0x80), lpFile) ;
			break ;
		default:
			break ;
		}
	}
	return	TRUE ;
}

BOOL	j_put_jis_string (LPWINFILE lpFile, LPCMYSTR lpString)
{
	unsigned short	sCode ;
	BYTE			bCodeMap ;
	int				iCharset_G0 ;
	int				iCharset_G1 ;
	int				iCharset_G2 ;

	iCharset_G0	= KCHARSET_ASCII ;
	iCharset_G1	= KCHARSET_JISX0201_1976 ;
	iCharset_G2	= KCHARSET_NOTHING ;

	while (*lpString){
		bCodeMap	= GetOriginalCode ((unsigned short FAR *)&sCode, *lpString ++) ;
		switch (bCodeMap){
		case MYCODEMAP_JISX0201:
			if (sCode > 127)
				break ;
		case MYCODEMAP_ASCII:
			if (iCharset_G0 != KCHARSET_ASCII){
				winfputc ('\x1b', lpFile) ;
				winfputc ('(', lpFile) ;
				winfputc ('B', lpFile) ;
				iCharset_G0	= KCHARSET_ASCII ;
			}
			winfputc ((char)(sCode & 0x7F), lpFile) ;
			break ;
		case MYCODEMAP_JISX0208:
			if (iCharset_G0 != KCHARSET_JISX0208_1983){
				winfputc ('\x1b', lpFile) ;
				winfputc ('$', lpFile) ;
				winfputc ('B', lpFile) ;
				iCharset_G0	= KCHARSET_JISX0208_1983 ;
			}
			winfputc ((char)((sCode >> 8) & 0x7F), lpFile) ;
			winfputc ((char)((sCode >> 0) & 0x7F), lpFile) ;
			break ;
		case MYCODEMAP_JISX0212:
			break ;
		}
	}
	if (iCharset_G0 != KCHARSET_ASCII){
		winfputc ('\x1b', lpFile) ;
		winfputc ('(', lpFile) ;
		winfputc ('B', lpFile) ;
		iCharset_G0	= KCHARSET_ASCII ;
	}
	return	TRUE ;
}

BOOL	j_put_sjis_string (LPWINFILE lpFile, LPCMYSTR lpString)
{
	unsigned short	sCode ;
	unsigned char	cc ;
	BYTE			bCodeMap ;
	while (*lpString){
		bCodeMap	= GetOriginalCode ((unsigned short FAR *)&sCode, *lpString ++) ;
		switch (bCodeMap){
		case MYCODEMAP_ASCII:
			winfputc ((char)(sCode & 0x7F), lpFile) ;
			break ;
		case MYCODEMAP_JISX0201:
			winfputc ((char)(sCode & 0xFF), lpFile) ;
			break ;
		case MYCODEMAP_JISX0208:
			cc				= ((((sCode >> 8) & 0xFF) - 0x7F) >> 1) + 0x70 ;
			cc				= (cc >= 0xA0)? cc + 0x40 : cc ;
			winfputc (cc, lpFile) ;
			cc				= (sCode & 0xFF) - (((sCode >> 8) & 1)? 0x61 : 0x03) ;
			cc				= (cc >= 0x7F)? cc + 1 : cc ;
			winfputc (cc, lpFile) ;
			break ;
		case MYCODEMAP_JISX0212:
			break ;
		}
	}
	return	TRUE ;
}

#else

BOOL	j_put_euc_string (LPWINFILE lpFile, LPCMYSTR lpString)
{
	int				iLeadChara ;
	unsigned char	c1, c2 ;
	iLeadChara	= '\0' ;
	while (*lpString){
		if (iLeadChara){
			c1	= (unsigned char)iLeadChara ;
			c2	= (unsigned char)*lpString ;
			c2	= (unsigned char)(*lpString & 0x00FF) ;
			c1	= (unsigned char)((c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1) ;
			c2	= (unsigned char)(c2 -  ((c2 >= 0x80)? 0x20 : 0x1F)) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			winfputc ((char)((c1 & 0x00FF) | 0x80), lpFile) ;
			winfputc ((char)((c2 & 0x00FF) | 0x80), lpFile) ;
			iLeadChara	= '\0' ;
		} else {
			if (IsDBCSLeadByte (*lpString)){
				iLeadChara	= *lpString ;
			} else {
				if (*lpString < 0 || *lpString > 127)
					winfputc ('\x8E', lpFile) ;
				winfputc ((unsigned char)*lpString, lpFile) ;
			}
		}
		lpString ++ ;
	}
	return	TRUE ;
}

BOOL	j_put_jis_string (LPWINFILE lpFile, LPCMYSTR lpString)
{
	int				iLeadChara ;
	unsigned char	c1, c2 ;
	int				charset_G0, charset_G1, charset_G2 ;

	charset_G0	= KCHARSET_ASCII ;
	charset_G1	= KCHARSET_JISX0201_1976 ;
	charset_G2	= KCHARSET_NOTHING ;
	iLeadChara	= '\0' ;

	while (*lpString){
		if (iLeadChara){
			if (charset_G0 != KCHARSET_JISX0208_1983){
				winfputc ('\x1b', lpFile) ;
				winfputc ('$', lpFile) ;
				winfputc ('B', lpFile) ;
				charset_G0	= KCHARSET_JISX0208_1983 ;
			}
			c1	= (unsigned char)iLeadChara ;
			c2	= (unsigned char)*lpString ;
			c2	= (unsigned char)(*lpString & 0x00FF) ;
			c1	= (unsigned char)((c1 - ((0xE0 <= c1 && c1 <= 0xFC)? 0xB0 : 0x70)) << 1) ;
			c2	= (unsigned char)(c2 -  ((c2 >= 0x80)? 0x20 : 0x1F)) ;
			if (c2 >= 0x7F){
				c2	-= 0x5E ;
			} else {
				c1	-- ;
			}
			winfputc ((char)(c1 & 0x007F), lpFile) ;
			winfputc ((char)(c2 & 0x007F), lpFile) ;
			iLeadChara	= '\0' ;
		} else {
			if (IsDBCSLeadByte (*lpString)){
				iLeadChara	= *lpString ;
			} else if (*lpString < 0 || *lpString > 127){
				/* ???? Fail */
			} else {
				if (charset_G0 != KCHARSET_ASCII){
					winfputc ('\x1b', lpFile) ;
					winfputc ('(', lpFile) ;
					winfputc ('B', lpFile) ;
					charset_G0	= KCHARSET_ASCII ;
				}
				winfputc ((unsigned char)*lpString, lpFile) ;
			}
		}
		lpString ++ ;
	}
	if (charset_G0 != KCHARSET_ASCII){
		winfputc ('\x1b', lpFile) ;
		winfputc ('(', lpFile) ;
		winfputc ('B', lpFile) ;
		charset_G0	= KCHARSET_ASCII ;
	}
	return	TRUE ;
}

BOOL	j_put_sjis_string (LPWINFILE lpFile, LPCMYSTR lpString)
{
	winfwrite (lpString, sizeof (MYCHAR), Mylstrlen (lpString), lpFile) ;
	return	TRUE ;
}

#endif

BOOL	SKKWriteVectorIndexToFile (LPWINFILE lpFile, int iCodingSystem, LPVECTORINDEX lpVectorIndex)
{
	MYCHAR			buffer [MAXCOMPSIZE + 1] ;
	winfputc ('/', lpFile) ;
	while (lpVectorIndex){
		buffer [0]				= MYTEXT ('\0') ;
		if (lpVectorIndex->iLength > 0){
			CopyCandidate (buffer, MAXCOMPSIZE,
						   lpVectorIndex->lpBuffer, lpVectorIndex->iPosition, lpVectorIndex->iLength) ;
			buffer [MAXCOMPSIZE]	= MYTEXT ('\0') ;
			j_put_string (lpFile, buffer, iCodingSystem) ;
			winfputc ('/', lpFile) ;
		}
		lpVectorIndex		= lpVectorIndex->lpNext ;
	}
	winfputc ('\x0A', lpFile) ;
	return	TRUE ;
}

