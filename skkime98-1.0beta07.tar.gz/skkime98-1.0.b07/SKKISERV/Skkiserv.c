/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * skkiserv.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "stdio.h"
#include "windows.h"
#include "lmcons.h"
#include "tchar.h"
#include "skkiserv.h"
#include "mystring.h"
#include "lisp.h"
#include "lmcons.h"

/*
 *	Prototypes
 */
static	BOOL				skkiservRegisterClass (HINSTANCE hInstance) ;
static	BOOL				skkiservInitSharedMemory (void) ;
static	LRESULT	CALLBACK	skkiservWindowProc (HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservOnCreate (HWND hwnd) ;
static	void				skkiservOnDestroy (HWND hwnd) ;
static	void				skkiservOnTimer (void) ;
static	LRESULT				skkiservInit (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservLock (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservUnlock (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservSearchKakuteiJisho (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservSearchInitialJisho (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservSearchRecord (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservSearchPurge (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservGetSearchResult (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservSearchServerJisho (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservRecord (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservPurge (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservTryCompletion (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservTryPurgeCompletion (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservLispEval (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservQueryJPrefix (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservQueryRomaKana (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservQueryRomaKanaRule (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservQueryInputVector (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservQueryZenkakuVector (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservJSearch (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservGetKeymap (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservGetConfig (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservGetProcessmap (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservGetClipboard (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	LRESULT				skkiservSetClipboard (HWND hwnd, WPARAM wParam, LPARAM lParam) ;
static	BOOL				skkiserv_LoadStartup (void) ;


/*
 *	Global Variables
 */
static	LPTSTR			lptszClassName			= SKKISERVER_CLASSNAME ;
static	LPTSTR			lptszWindowName			= SKKISERVER_WINDOWNAME ;
static	HINSTANCE		hSkkiservInstance ;
static	HANDLE			hSkkiservJishoMutex		= NULL ;
static	HANDLE			hSkkiservMapObj 		= NULL ;
static	LPVOID			lpSkkiservShareMemory	= NULL ;
static	BOOL			fSkkinputLocalJishoDirty ;
static	BOOL			fSkkinputLocalJishoIdle ;
static	LPLISTBUFFER	lpSearchResult ;
static	DWORD			dwServerLockProcessId ;

/*
 *	Functions
 */

BOOL	skkiservRegisterClass (HINSTANCE hInstance)
{
	WNDCLASSEX	wc ;
	wc.cbSize			= sizeof (WNDCLASSEX) ;
	wc.style			= CS_HREDRAW | CS_VREDRAW ;
	wc.lpfnWndProc		= skkiservWindowProc ;
	wc.cbClsExtra		= 0 ;
	wc.cbWndExtra		= 0 ;
	wc.hInstance		= hInstance ;
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW) ;
	wc.hIcon			= NULL ;
	wc.lpszMenuName 	= (LPSTR)NULL ;
	wc.lpszClassName	= lptszClassName ;
	wc.hbrBackground	= NULL ;
	wc.hIconSm			= NULL ;
	if (!RegisterClassEx ((LPWNDCLASSEX)&wc))
		return	FALSE ;
	return	TRUE ;
}

BOOL	skkiservInitSharedMemory (void)
{
	BOOL	fInit ;
	hSkkiservMapObj = CreateFileMapping (
						(HANDLE) 0xFFFFFFFF,	/* use paging file */
						NULL,					/* no security attributes */
						PAGE_READWRITE,			/* read/write access */
						0,						/* size: high 32-bits */
						SHMEMSIZE,				/* size: low 32-bits */
						SKKISERVER_SHAREMEMNAME) ;	/* name of map object */
	if (!hSkkiservMapObj) 
		return	FALSE ;
	fInit	= (GetLastError() != ERROR_ALREADY_EXISTS) ; 
	/* Get a pointer to the file-mapped shared memory. */
	lpSkkiservShareMemory	= MapViewOfFile (
						hSkkiservMapObj,	/* object to map view of */
						FILE_MAP_WRITE,		/* read/write access */
						0,					/* high offset:  map from */
						0,					/* low offset:   beginning */
						0) ;				/* default: map entire file */
	if (!lpSkkiservShareMemory) 
		return	FALSE ;
	if (fInit) 
		memset (lpSkkiservShareMemory, '\0', SHMEMSIZE) ;
	return	TRUE ;
}

int WINAPI WinMain (HINSTANCE	hInstance,		/* handle to current instance */
					HINSTANCE	hPrevInstance,	/* handle to previous instance */
					LPSTR		lpCmdLine,		/* pointer to command line */
					int			nCmdShow)		/* show state of window */
{
	HWND	hwndMain ;
	MSG		msg ;
	HANDLE	hMutex ;
	DWORD	dwValue ;

 	hMutex	= CreateMutex (NULL, FALSE, lptszWindowName) ;
	if (!hMutex){
		ExitProcess (-1) ;
		return	-1 ;
	}
	dwValue	= WaitForSingleObject (hMutex, 0) ;
	if (dwValue == WAIT_TIMEOUT || dwValue == WAIT_FAILED){
		CloseHandle (hMutex) ;
		ExitProcess (-1) ;
		return	-1 ;
	}
	dwServerLockProcessId	= GetCurrentProcessId () ;
	if (!hPrevInstance && !skkiservRegisterClass (hInstance)){
		ReleaseMutex (hMutex) ;
		CloseHandle (hMutex) ;
		ExitProcess (-1) ;
		return	-1 ;
	}
	hSkkiservInstance	= hInstance ;
	hwndMain		= CreateWindowEx (WS_EX_TOOLWINDOW, lptszClassName, lptszWindowName, 0,
									  0, 0, 1, 1,
									  (HWND)NULL, (HMENU)NULL, hInstance, NULL) ;
	if (!hwndMain){
		ReleaseMutex (hMutex) ;
		CloseHandle (hMutex) ;
		ExitProcess (-1) ;
		return	-1 ;
	}
	ShowWindow (hwndMain, SW_HIDE) ;

	while (GetMessage (&msg, NULL, 0, 0)){
		TranslateMessage (&msg) ;
		DispatchMessage (&msg) ;
	}

	ReleaseMutex (hMutex) ;
	CloseHandle (hMutex) ;
	ExitProcess (msg.wParam) ;
	return	msg.wParam ;
 	UNREFERENCED_PARAMETER (lpCmdLine) ;
 	UNREFERENCED_PARAMETER (nCmdShow) ;
}


LRESULT	CALLBACK	skkiservWindowProc (HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam)
{
	static	LRESULT (*skkiservCommandProc [])(HWND hwnd, WPARAM wParam, LPARAM lParam) = {
		skkiservInit,
		skkiservLock,
		skkiservUnlock,
		skkiservRecord,
		skkiservPurge,
		skkiservSearchPurge,
		skkiservTryCompletion,
		skkiservTryPurgeCompletion,
		skkiservLispEval,
		skkiservQueryJPrefix,
		skkiservQueryRomaKana,
		skkiservQueryRomaKanaRule,
		skkiservQueryInputVector,
		skkiservQueryZenkakuVector,
		skkiservGetSearchResult,
		skkiservJSearch,
		skkiservGetKeymap,
		skkiservGetConfig,
		skkiservGetProcessmap,
		skkiservGetClipboard,
		skkiservSetClipboard,
	} ;
#ifdef DEBUG
	skkiservLogFile (_TEXT ("skkiserv(%lx)/(%ld): HWND(%lx), MSG(%lx), WPARAM(%lx), LPARAM(%lx)\n"),
					 GetCurrentProcessId (), GetTickCount (), hWnd, nMessage, wParam, lParam) ;
#endif
	switch (nMessage){
	case WM_CREATE:
		return	skkiservOnCreate (hWnd) ;

	case WM_DESTROY:
		skkiservOnDestroy (hWnd) ;
		PostQuitMessage (0) ;
		break ;

	case WM_TIMER:
		skkiservOnTimer () ;
		break ;

	default:
		if (WM_SKKISERV_CONTROL_MSG_START <= nMessage && nMessage < WM_SKKISERV_CONTROL_MSG_END)
			return	(skkiservCommandProc [nMessage - WM_SKKISERV_CONTROL_MSG_START])(hWnd, wParam, lParam) ;
		return	DefWindowProc (hWnd, nMessage, wParam, lParam) ;
	}
	return	TRUE ;
}

/*
 *	WM_CREATE ���b�Z�[�W�̏����֐��B
 */
LRESULT	skkiservOnCreate (HWND hwnd)
{
	WSADATA			wsaData ;
	HWND			hOtherWnd ;

	hOtherWnd	= FindWindow (lptszClassName, lptszWindowName) ;
	if (hOtherWnd && hOtherWnd != hwnd)
		return	-1 ;

	/* WinSock �𗘗p���邽�߂̑O�������s���B*/
	WSAStartup (0x0101, &wsaData) ;
	skkiserv_InitConnection () ;

	/* lisp ��������������B*/
	skkiserv_LispInit () ;
	SKKInitCandidateRecord () ;
	SKKInitVectorHashTable () ;
	j_init_sorted_jisyos () ;
	j_init_local_jisyo_table () ;

	/* �T�[�o�[�A�N�Z�X�̔r������I�u�W�F�N�g���쐬����B*/
	hSkkiservJishoMutex	= CreateMutex (NULL, FALSE, NULL) ;
	if (!hSkkiservJishoMutex)
		return	-1L ;
	/* �T�[�o�[�ƃN���C�A���g�Ԃ̃��b�Z�[�W�̂����Ɏg�����L���������쐬����B*/
	if (!skkiservInitSharedMemory ())
		return	-1L ;
#if defined (MIXED_UNICODE_ANSI) || defined (UNICODE)
	/* Unicode ���� JISX0208-1983, JISX0201-1976, JISX0212-1990 �ւ̕ϊ��\���쐬����B*/
	SKKInitUnicodeInvMap () ;
#endif
	skkiserv_LoadStartup () ;
	skkiserv_CreateClientSocket () ;

	fSkkinputLocalJishoIdle		= TRUE ;
	fSkkinputLocalJishoDirty	= FALSE ;
	lpSearchResult				= NULL ;
	/* �����̎����Z�[�u�ɗp����^�C�}�[��ݒ肷��B*/
	SetTimer (hwnd, TIMERID_JISHO_UPDATE, 30 * 1000, NULL) ;
	return	0L ;
}

void	skkiservOnDestroy (HWND hwnd)
{
	j_close_server_jisyo () ;
	j_close_sorted_jisyos () ;
	j_clear_local_jisyo_table () ;
	WSACleanup () ;
	if (lpSearchResult)
		SKKFreeListBuffer (&lpSearchResult) ;
	KillTimer (hwnd, TIMERID_JISHO_UPDATE) ;
	if (lpSkkiservShareMemory){
		(void)UnmapViewOfFile (lpSkkiservShareMemory) ; 
		lpSkkiservShareMemory	= NULL ;
	}
	if (hSkkiservMapObj){
		(void)CloseHandle (hSkkiservMapObj) ;
		hSkkiservMapObj	= NULL ;
	}
	if (hSkkiservJishoMutex){
		ReleaseMutex (hSkkiservJishoMutex) ;
		CloseHandle (hSkkiservJishoMutex) ;
		hSkkiservJishoMutex	= NULL ;
	}
	SKKClearVectorHashTable () ;
	SKKClearCandidateRecord () ;
	skkiserv_LispClear () ;
	return ;
}

/*
 *	�����̎����Z�[�u�Ɏg�� WM_TIMER �̏����֐��B
 */
void	skkiservOnTimer (void)
{
	DWORD			dwResult ;
	/*
	 *	Secure Mode �ł͎����̃Z�[�u���s���Ă͂Ȃ�Ȃ��B
	 *	�Z�L�����e�B�̖�肩�炩�ȁB�����t�@�C���� command.com ���Ƃ�
	 *	�����ꌾ����ƕ|���̂ŁB
	 */
	if (hSkkiservJishoMutex){
		/* �T�[�o�[�����b�N����B*/
		dwResult	= WaitForSingleObject (hSkkiservJishoMutex, 0) ;
		if (dwResult != WAIT_TIMEOUT){
			/* �����̍X�V�`�F�b�N�B*/
			if (fSkkinputLocalJishoIdle){
				if (fSkkinputLocalJishoDirty){
					if (SKKUpdateLocalJisho ())
						fSkkinputLocalJishoDirty	= FALSE ;
				}
			}
			/* Garbage Collector ���N��������B�d�����낤��...*/
			skkinputlisp_GarbageCollection () ;
			ReleaseMutex (hSkkiservJishoMutex) ;
		}
	}
	fSkkinputLocalJishoIdle	= TRUE ;
	return ;
}

/*
 *	�T�[�o�ɏ�������v������ WM_INIT (����� WM_USER �̂����肩��K���ɂƂ��Ă���) �̏����֐��B
 */
LRESULT	skkiservInit (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	BOOL	fRetvalue ;
	fRetvalue	= skkiserv_LoadStartup () ;
	/* ���̎��A�T�[�o�[�Ƃ̐ڑ��ݒ肪�ω������\��������̂ŁAsocket ����蒼���B*/
	skkiserv_CreateClientSocket () ;
	return	fRetvalue ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservLock (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	DWORD			dwResult ;
	if (hSkkiservJishoMutex){
		if (dwServerLockProcessId != (DWORD)wParam){
			dwResult	= WaitForSingleObject (hSkkiservJishoMutex, 0) ;
			if (dwResult == WAIT_TIMEOUT){
#ifdef DEBUG
				skkiservLogFile (_TEXT ("skkiserv(%lx)/(%ld): lock failed. (process:%lx/thread:%lx)\n"),
								 GetCurrentProcessId (), GetTickCount (), wParam, lParam) ;
#endif
				return	FALSE ;
			}
			dwServerLockProcessId	= (DWORD)wParam ;
#ifdef DEBUG
			skkiservLogFile (_TEXT ("skkiserv(%lx)/(%ld): lock succeeded. (process:%lx/thread:%lx)\n"),
							 GetCurrentProcessId (), GetTickCount (), wParam, lParam) ;
#endif
		}
	}
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
 	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT	skkiservUnlock (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	if (hSkkiservJishoMutex){
		if (dwServerLockProcessId != (DWORD)wParam){
#ifdef DEBUG
			skkiservLogFile (_TEXT ("skkiserv(%lx)/(%ld): unlock failed. (process:%lx/thread:%lx)\n"),
							 GetCurrentProcessId (), GetTickCount (), wParam, lParam) ;
#endif
			return	FALSE ;
		}
#ifdef DEBUG
		skkiservLogFile (_TEXT ("skkiserv(%lx)/(%ld): unlock succeeded. (process:%lx/thread:%lx)\n"),
						 GetCurrentProcessId (), GetTickCount (), wParam, lParam) ;
#endif
		dwServerLockProcessId	= GetCurrentProcessId () ;
		ReleaseMutex (hSkkiservJishoMutex) ;
	}
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
 	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT	skkiservSearchPurge (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	fSkkinputLocalJishoIdle		= FALSE ;
	if (lpSearchResult)
		SKKFreeListBuffer (&lpSearchResult) ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	lpSearchResult	= SKKSearchCandidatePurgeList2 (lpSearchResult, szHenkanKey, (BOOL)wParam) ;
	if (!lpSearchResult)
		return	0 ;
	Mylstrncpy ((LPMYSTR)lpSkkiservShareMemory, lpSearchResult->text, MSGBUFSIZE) ;
	return	SKKGetLengthOfListBuffer (lpSearchResult) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservRecord (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	LPMYSTR			lpWord ;
	LPMYSTR			lpQuotedWord ;

	fSkkinputLocalJishoIdle		= FALSE ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	lpWord						= (LPMYSTR)lpSkkiservShareMemory + MAXCOMPSIZE ;
	lpQuotedWord				= j_quote_char (lpWord) ;
	SKKRecordNewCandidate (szHenkanKey, (lpQuotedWord)? lpQuotedWord : lpWord, (BOOL)wParam) ;
	if (lpQuotedWord){
		HeapFree (GetProcessHeap (), 0, lpQuotedWord) ;
		lpQuotedWord	= NULL ;
	}
	fSkkinputLocalJishoDirty	= TRUE ;
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservPurge (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;

	fSkkinputLocalJishoIdle		= FALSE ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	SKKPurgeCandidate (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory + MAXCOMPSIZE, (BOOL)wParam) ;
	fSkkinputLocalJishoDirty	= TRUE ;
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservTryCompletion (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	fSkkinputLocalJishoIdle		= FALSE ;
	if (lpSearchResult)
		SKKFreeListBuffer (&lpSearchResult) ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	lpSearchResult	= j_try_completion_record2 (lpSearchResult, szHenkanKey) ;
	lpSearchResult	= j_try_completion_local_jisyo (szHenkanKey, lpSearchResult) ;
	if (!lpSearchResult)
		return	0 ;
	Mylstrncpy ((LPMYSTR)lpSkkiservShareMemory, lpSearchResult->text, MSGBUFSIZE) ;
	return	SKKGetLengthOfListBuffer (lpSearchResult) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservTryPurgeCompletion (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	fSkkinputLocalJishoIdle		= FALSE ;
	if (lpSearchResult)
		SKKFreeListBuffer (&lpSearchResult) ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	lpSearchResult	= j_try_completion_purge2 (lpSearchResult, szHenkanKey) ;
	if (!lpSearchResult)
		return	0 ;
	Mylstrncpy ((LPMYSTR)lpSkkiservShareMemory, lpSearchResult->text, MSGBUFSIZE) ;
	return	SKKGetLengthOfListBuffer (lpSearchResult) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservLispEval (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	UINT			nLength ;

	fSkkinputLocalJishoIdle		= FALSE ;
	if (wParam){
		/* ���l�ϊ��L�[�������B*/
		nLength = MyGlobalGetAtomName ((ATOM)wParam, szHenkanKey, MAXCOMPSIZE) ;
		szHenkanKey [nLength]		= MYTEXT ('\0') ;
		create_j_num_list (szHenkanKey) ;
	}
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	if (!skkiserv_eval (szHenkanKey, lpSkkiservShareMemory, MSGBUFSIZE))
		return	FALSE ;
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservQueryJPrefix (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	UINT			nLength ;
	fSkkinputLocalJishoIdle		= FALSE ;
	if (!wParam){
		nLength	= 0 ;
	} else {
		Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
		nLength	= Mylstrlen (szHenkanKey) ;
	}
	szHenkanKey [nLength ++]	= (MYCHAR)lParam ;
	szHenkanKey [nLength]		= MYTEXT ('\0') ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	return	j_prefix_check (szHenkanKey) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
}

LRESULT	skkiservQueryRomaKana (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	MYCHAR			chara ;
	BOOL			fKatakana ;
	fSkkinputLocalJishoIdle		= FALSE ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	chara						= (MYCHAR)wParam ;
	fKatakana					= (BOOL)lParam ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	return	skkiserv_AssocRomKana (lpSkkiservShareMemory, MSGBUFSIZE, szHenkanKey, chara, fKatakana) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
}

LRESULT	skkiservQueryRomaKanaRule (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	fSkkinputLocalJishoIdle		= FALSE ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	return	skkiserv_RomKanaRule (lpSkkiservShareMemory, MSGBUFSIZE, szHenkanKey) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservQueryInputVector (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	fSkkinputLocalJishoIdle		= FALSE ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	return	skkiserv_GetInputVector (lpSkkiservShareMemory, MSGBUFSIZE, (MYCHAR)lParam) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT	skkiservQueryZenkakuVector (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	fSkkinputLocalJishoIdle		= FALSE ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	return	skkiserv_GetZenkakuVector (lpSkkiservShareMemory, MSGBUFSIZE, (MYCHAR)lParam) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT	skkiservJSearch (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szHenkanKey [MAXCOMPSIZE + 1] ;
	BOOL			fKakutei ;
	fSkkinputLocalJishoIdle		= FALSE ;
	if (lpSearchResult)
		SKKFreeListBuffer (&lpSearchResult) ;
	Mylstrcpy (szHenkanKey, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	lpSearchResult	= skk_search (lpSearchResult, szHenkanKey, (BOOL)wParam, &fKakutei) ;
	if (!lpSearchResult)
		return	0 ;
	Mylstrncpy ((LPMYSTR)lpSkkiservShareMemory, lpSearchResult->text, MSGBUFSIZE) ;
	return	(DWORD)SKKGetLengthOfListBuffer (lpSearchResult) | ((fKakutei)? 0x80000000L : 0) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
 	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT	skkiservGetSearchResult (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	LPLISTBUFFER	lpListBuffer ;
	fSkkinputLocalJishoIdle		= FALSE ;
	lpListBuffer	= SKKGetElementOfListBuffer (lpSearchResult, (long)wParam) ;
	if (!lpListBuffer)
		return	FALSE ;
	Mylstrncpy ((LPMYSTR)lpSkkiservShareMemory, lpListBuffer->text, MSGBUFSIZE) ;
	return	TRUE ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservGetKeymap (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szKeymapName [MAXCOMPSIZE + 1] ;
	Mylstrcpy (szKeymapName, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	return	skkiserv_GetKeymap (szKeymapName, lpSkkiservShareMemory) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservGetConfig (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	LRESULT	lValue ;
	lValue	= 0 ;
	lValue	+= skkiserv_GetConfig (lpSkkiservShareMemory) ;
	lValue	+= skkiserv_GetColorFace ((LPBYTE)lpSkkiservShareMemory + lValue) ;
	return	lValue ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservGetProcessmap (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	MYCHAR			szKeymapName [MAXCOMPSIZE + 1] ;
	Mylstrcpy (szKeymapName, (LPMYSTR)lpSkkiservShareMemory) ;
	((LPMYSTR)lpSkkiservShareMemory) [0]	= MYTEXT ('\0') ;
	return	skkiserv_GetProcessmap (szKeymapName, lpSkkiservShareMemory) ;
 	UNREFERENCED_PARAMETER (hwnd) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	skkiservGetClipboard (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	HGLOBAL	hGlobal ;
	LPMYSTR	lpDest ;
	LPTSTR	lptstr ;
	int		iBufSize ;
	long	lUsage ;
	if (!IsClipboardFormatAvailable (CF_TEXT))
		return	0 ;
	if (!OpenClipboard (hwnd))
		return	0 ;
	lpDest		= (LPMYSTR)lpSkkiservShareMemory ;
	iBufSize	= (int)wParam ;
	lUsage		= 0 ;
	hGlobal		= GetClipboardData (CF_TEXT) ;
	if (hGlobal){
		lptstr	= GlobalLock (hGlobal) ;
		if (lptstr){
#if defined (MIXED_UNICODE_ANSI)
			lUsage	= shiftJisToMystr (lpDest, iBufSize, lptstr, lstrlen (lptstr)) ;
#else	/* defined (MIXED_UNICODE_ANSI) */
#if defined (UNICODE)
			while (*lptstr && iBufSize > 0){
				*lpDest ++	= *lptstr ++ ;
				iBufSize	-- ;
				lUsage		++ ;
			}
#else	/* defined (UNICODE) */
			while (*lptstr && iBufSize > 0){
				if (IsDBCSLeadByte (*lptstr)){
					if (iBufSize < 2)
						break ;
					*lpDest ++	= *lptstr ++ ;
					iBufSize	-- ;
					lUsage		++ ;
				}
				*lpDest ++	= *lptstr ++ ;
				iBufSize	-- ;
				lUsage		++ ;
			}
#endif	/* defined (UNICODE) */
			if (iBufSize > 0)
				*lpDest	= MYTEXT ('\0') ;
#endif	/* defined (MIXED_UNICODE_ANSI) */
			GlobalUnlock (hGlobal) ;
		}
	}
	CloseClipboard () ;
	return	(LRESULT)lUsage ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

/*
 *	�N���b�v�{�[�h�ɕ�������Z�b�g����֐��B
 */
LRESULT	skkiservSetClipboard (HWND hwnd, WPARAM wParam, LPARAM lParam)
{
	HGLOBAL	hGlobal ;
	LPMYSTR	lpSrc ;
	LPTSTR	lptstr ;
	int		iLength ;
	int		iNeedSize ;
	BOOL	fAppend ;
	if (!OpenClipboard (hwnd))
		return	FALSE ;
	EmptyClipboard () ;
	lpSrc		= (LPMYSTR)lpSkkiservShareMemory ;
	iLength		= (int)wParam ;
	fAppend		= (BOOL)lParam ;
#if defined (MIXED_UNICODE_ANSI)
	/* ���̏ꍇ�AMYCHAR != TCHAR�BTCHAR = char, MYCHAR = wchar �ƂȂ��Ă���B*/
	iNeedSize	= MystrToShiftJis (0, 0, lpSrc, iLength) ;
#else	/* defined (MIXED_UNICODE_ANSI) */
	iNeedSize	= iLength ;
#endif
	hGlobal	= GlobalAlloc (GMEM_DDESHARE, (iNeedSize + 1) * sizeof (TCHAR)) ;
	if (!hGlobal){
		CloseClipboard () ;
		return	FALSE ;
	}
	lptstr	= GlobalLock (hGlobal) ;
#if defined (MIXED_UNICODE_ANSI)
	iLength		= MystrToShiftJis (lptstr, iNeedSize, lpSrc, iLength) ;
#else
	/* ���̏ꍇ�AMYCHAR == TCHAR ����������B*/
	memcpy (lptstr, lpSrc, sizeof (TCHAR) * iLength) ;
#endif
	lptstr [iLength]	= MYTEXT ('\0') ;
	GlobalUnlock (hGlobal) ;
	SetClipboardData (CF_TEXT, hGlobal) ;
	CloseClipboard () ;
	return	TRUE ;
}

BOOL	skkiserv_LoadStartup (void)
{
	TCHAR	startupPath [MAX_PATH + 1] ;
	int		iPathLength ;
	/* default �̐ݒ��ǂݍ��ށB*/
	iPathLength	= GetWindowsDirectory (startupPath, MAX_PATH) ;
	if (iPathLength > 0){
		if (lstrcpyn (startupPath + iPathLength,
					  "\\" PROGRAMF_DIR "\\" SKKIME98Prog_S_DIR "\\" SKKIME98Conf_DIR "\\" SKKIME98StartupFile,
					  MAX_PATH - iPathLength)){
			startupPath [MAX_PATH]	= TEXT ('\0') ;
			skkiserv_LoadFile (startupPath) ;
		}
		/* user ���̐ݒ�t�@�C����ǂݍ��ށB*/
		if (lstrcpyn (startupPath + iPathLength,
					  "\\" PROGRAMF_DIR "\\" SKKIME98Prog_S_DIR "\\" SKKIME98Conf_DIR "\\" SKKIME98Conf_FILE,
					  MAX_PATH - iPathLength)){
			startupPath [MAX_PATH]	= TEXT ('\0') ;
			skkiserv_LoadFile (startupPath) ;
		}
	}
	/* Garbage Collector ���N��������B�d�����낤��...*/
	skkinputlisp_GarbageCollection () ;
	return	TRUE ;
}

