/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * uistate.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"
#include "skkui.h"
#include "skkel.h"
#include "listbuf.h"
#include "skksvect.h"
#include "skksubs.h"
#include "resource.h"

/*
 *	�v���g�^�C�v�錾�B
 */
static	void	PASCAL	PaintStatus (HWND hStatusWnd , HDC hDC, DWORD dwPushedStatus) ;
static	void	PASCAL	ButtonStatus (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) ;
static	BOOL			statusWindowLeftMenu (HIMC hIMC, HWND hwnd) ;
static	BOOL			statusWindowRightMenu (HIMC hIMC, HWND hwnd) ;
static	int				showStatusWindowLeftMenu (HIMC hIMC, HWND hwnd) ;
static	int				showStatusWindowRightMenu (HIMC hIMC, HWND hwnd) ;
static	BOOL			insertInputModeMenu (HIMC hIMC, HMENU hMenu, int FAR* lpiPosition) ;
static	HBITMAP			createStatusCModeBitmap (HWND hwnd) ;
static	HBITMAP			createStatusOnOffBitmap (HWND hwnd) ;

/*
 *	Global Functions
 */

/*
 *	Status Window �� WINDOWPROC�B
 *(�R�����g)
 *	Status Window ����Window Message�͂��̊֐��ɑ����ė��܂��̂ŁA
 *	Window Message �ɑΉ������������s���܂��B���̊֐����̂� Window
 *	Message �̐U�蕪�������ł����ǁB
 *(����)
 *	hWnd	Window Message ���󂯎���� Composition Window �� Handle
 *	message	Window Message
 *	wParam	Window Message �̈�������1
 *	lParam	Window Message �̈�������2
 */
LRESULT CALLBACK StatusWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT	ps ;
	HWND		hUIWnd ;
	HDC			hDC ;
	HBITMAP		hbmpStatus ;
	HIMC		hIMC ;

	switch (message){
	case	WM_UI_UPDATE:
		InvalidateRect (hWnd, NULL, FALSE) ;
		break ;

	case	WM_PAINT:
		hDC = BeginPaint (hWnd, &ps) ;
		PaintStatus (hWnd, hDC, 0) ;
		EndPaint (hWnd, &ps) ;
		break ;

	case	WM_ERASEBKGND:
		break ;

	case	WM_MOUSEACTIVATE:
		return	MA_NOACTIVATE ;

	case	WM_NCMOUSEMOVE:
	case	WM_MOUSEMOVE:
	case	WM_LBUTTONUP:
	case	WM_RBUTTONUP:
	case	WM_LBUTTONDOWN:
	case	WM_RBUTTONDOWN:
		ButtonStatus (hWnd, message, wParam, lParam) ;
		break ;

	case	WM_MOVE:
		hUIWnd = (HWND)GetWindowLong (hWnd, FIGWL_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_STATEMOVE, wParam, lParam) ;
		break ;

	case	WM_CREATE:
#ifdef STATUSWINDOW_LARGE
		SetWindowLong (hWnd, FIGWL_STATUSORGBMP,	(LONG)LoadBitmap (hInst, TEXT ("STATUSBMP"))) ;
		SetWindowLong (hWnd, FIGWL_CLOSEORGBMP,		(LONG)LoadBitmap (hInst, TEXT ("ONOFFBMP"))) ;
#else
		SetWindowLong (hWnd, FIGWL_STATUSORGBMP,	(LONG)LoadBitmap (hInst, TEXT ("STATUSSBMP"))) ;
		SetWindowLong (hWnd, FIGWL_CLOSEORGBMP,		(LONG)LoadBitmap (hInst, TEXT ("ONOFFSBMP"))) ;
#endif
		SetWindowLong (hWnd, FIGWL_STATUSBMP,		(LONG)createStatusCModeBitmap (hWnd)) ;
		SetWindowLong (hWnd, FIGWL_CLOSEBMP,		(LONG)createStatusOnOffBitmap (hWnd)) ;
		SetWindowLong (hWnd, FIGWL_MOUSE,			0L) ;
		SetWindowLong (hWnd, FIGWL_PUSHSTATUS,		0L) ;
		SetWindowLong (hWnd, FIGWL_CURSOR,			0L) ;
		SetWindowLong (hWnd, FIGWL_PREVCMODE,		0L) ;
		break ;

	case	WM_SYSCOLORCHANGE:
		hbmpStatus = (HBITMAP)GetWindowLong (hWnd, FIGWL_STATUSBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		hbmpStatus = (HBITMAP)GetWindowLong (hWnd, FIGWL_CLOSEBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		SetWindowLong (hWnd, FIGWL_STATUSBMP,		(LONG)createStatusCModeBitmap (hWnd)) ;
		SetWindowLong (hWnd, FIGWL_CLOSEBMP,		(LONG)createStatusOnOffBitmap (hWnd)) ;
		break ;

	case	WM_DESTROY:
		hbmpStatus = (HBITMAP)GetWindowLong (hWnd, FIGWL_STATUSORGBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		hbmpStatus = (HBITMAP)GetWindowLong (hWnd, FIGWL_CLOSEORGBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		hbmpStatus = (HBITMAP)GetWindowLong (hWnd, FIGWL_STATUSBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		hbmpStatus = (HBITMAP)GetWindowLong (hWnd, FIGWL_CLOSEBMP) ;
		if (hbmpStatus)
			DeleteObject (hbmpStatus) ;
		SetWindowLong (hWnd, FIGWL_MOUSE, 0L) ;
		SetWindowLong (hWnd, FIGWL_PUSHSTATUS, 0L) ;
		break ;

	default:
		if (!MyIsIMEMessage(message))
			return	DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return 0 ;
}

/*
 *	Status Window ���N���b�N���ꂽ���ɂ��̏ꏊ�Ɋ��蓖�Ă�ꂽ�@�\�������𒲂ׂ�֐��B
 *----
 */
DWORD	PASCAL	CheckPushedStatus (HWND hStatusWnd, LPPOINT lppt)
{
	POINT	pt ;
	RECT	rc ;
	if (lppt){
		pt	= *lppt ;
		ScreenToClient (hStatusWnd, &pt) ;
		GetClientRect  (hStatusWnd, &rc) ;
		if (!PtInRect (&rc, pt))
			return	0L ;
		if (pt.x < STATUSONOFF_BTNX){
			if (pt.y < 10){
				return	PUSHED_STATUS_ONOFF ;
			} else {
				return	PUSHED_STATUS_MOVE ;
			}
		}
		return	PUSHED_STATUS_MODE ;
	}
	return	0L ;
}

/*
 *	���̓��[�h�����Ȃ̂��𒲂ׂ�֐�(?)
 */
int		PASCAL	BTYFromCmode (LPINPUTCONTEXT lpIMC)
{
	/*
	 *	IME �o�R�̓��͂łȂ� ---> ���ړ��̓��[�h�ł���B
	 *	IME �o�R�̓��͂ł��� ---> fdwConversion ������B
	 */
	if (!lpIMC->fOpen)
		return	BTY_DIRECTINPUT ;
	/*
	 *	
	 */
	if (lpIMC->fdwConversion & IME_CMODE_FULLSHAPE){
		if (!(lpIMC->fdwConversion & IME_CMODE_LANGUAGE))
			return	BTY_ZENEI ;
		else if ((lpIMC->fdwConversion & IME_CMODE_LANGUAGE) == IME_CMODE_NATIVE)
			return	BTY_KANA ;
		else
			return	BTY_KATAKANA ;
	} else {
		return	BTY_ASCII ;
	}
}

void	PASCAL	PaintStatus (HWND hStatusWnd, HDC hDC, DWORD dwPushedStatus)
{
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	HDC				hMemDC ;
	HBITMAP			hbmpOld ;
	int				src_x, src_y ;
	int				y ;
	HWND			hSvrWnd ;
	POINT			pt ;
	HBITMAP		hbmpStatus ;
	HBRUSH		hOldBrush, hBrush ;

	hSvrWnd		= (HWND)GetWindowLong (hStatusWnd, FIGWL_SVRWND) ;
	hIMC		= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;

	if (hIMC){
		lpIMC	= ImmLockIMC (hIMC) ;
	} else {
		lpIMC	= 0 ;
	}
	hMemDC	= CreateCompatibleDC (hDC) ;

	GetCursorPos (&pt) ;
	ScreenToClient (hStatusWnd, &pt) ;
	if (hIMC){
		SKKSetConversionMode (hIMC) ;
		y			= BTYFromCmode (lpIMC) ;
	} else {
		y			= GetWindowLong (hStatusWnd, FIGWL_PREVCMODE) ;
	}
	hbmpStatus	= (HBITMAP)GetWindowLong (hStatusWnd, FIGWL_CLOSEBMP) ;
	hbmpOld		= (HBITMAP)SelectObject (hMemDC, hbmpStatus) ;
	if (hIMC){
		if (y == BTY_DIRECTINPUT){
			src_y	= 0 ;
		} else {
			src_y	= STATUSONOFF_BTNY ;
		}
		if (dwPushedStatus & PUSHED_STATUS_ONOFF){
			src_x	= STATUSONOFF_BTNX * 2 ;
		} else if (STATUSONOFF_X <= pt.x && pt.x < STATUSCMODE_X &&
				   STATUSONOFF_Y <= pt.y && pt.y < 10){
			src_x	= STATUSONOFF_BTNX * 1 ;
		} else {
			src_x	= 0 ;
		}
	}  else {
		src_x	= 0 ;
		src_y	= 0 ;
	}
	BitBlt (hDC, STATUSONOFF_X, STATUSONOFF_Y, STATUSONOFF_BTNX, STATUSONOFF_BTNY,
			hMemDC, src_x, src_y, SRCCOPY) ;
	SelectObject (hMemDC, hbmpOld) ;

	hbmpStatus	= (HBITMAP)GetWindowLong (hStatusWnd, FIGWL_STATUSBMP) ;
	hbmpOld		= (HBITMAP)SelectObject (hMemDC, hbmpStatus) ;
	if (hIMC){
		if (dwPushedStatus & PUSHED_STATUS_MODE){
			src_x	= STATUSCMODE_BTNX * 2 ;
		} else if (STATUSCMODE_X <= pt.x && pt.x < STATUS_BTNX &&
				   STATUSCMODE_Y <= pt.y && pt.y < STATUS_BTNY){
			src_x	= STATUSCMODE_BTNX * 1 ;
		} else {
			src_x	= 0 ;
		}
	} else {
		src_x	= STATUSCMODE_BTNX * 3 ;
	}
	BitBlt (hDC, STATUSCMODE_X, STATUSCMODE_Y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hMemDC, src_x, y, SRCCOPY) ;
	SelectObject (hMemDC, hbmpOld) ;
	DeleteDC (hMemDC) ;
	if (hIMC){
		ImmUnlockIMC (hIMC) ;
		SetWindowLong (hStatusWnd, FIGWL_PREVCMODE, y) ;
	}
	return ;
}

void	PASCAL	ChangeMouseCursor (HWND hwnd)
{
	POINT	pt ;
	HCURSOR	hCursor ;
	/* �}�E�X�J�[�\���̈ʒu�𓾂�B*/
	GetCursorPos (&pt) ;
	ScreenToClient (hwnd, &pt) ;
	hCursor	= (HCURSOR)GetWindowLong (hwnd, FIGWL_CURSOR) ;
	/* �}�E�X�J�[�\���̈ʒu����J�[�\���̌`����ǂ̂悤�ɂ��邩���肷��B*/
	if (STATUSONOFF_X <= pt.x && pt.x < STATUSCMODE_X &&
		10            <= pt.y && pt.y < STATUSONOFF_BTNY){
		/* ���݂̃J�[�\����ۑ�����B��񂫂�B*/
		if (!hCursor)
			SetWindowLong (hwnd, FIGWL_CURSOR, (LONG)GetCursor ()) ;
		/* �J�[�\���̌`���ύX����B*/
		(void)SetCursor (LoadCursor (NULL, IDC_SIZEALL)) ;
	} else {
		/* �ȑO�̃J�[�\���ɖ߂��B*/
		if (hCursor)
			SetCursor (hCursor) ;
		SetWindowLong (hwnd, FIGWL_CURSOR, 0L) ;
	}
	return ;
}

void	PASCAL	ButtonStatus (HWND hStatusWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT	pt ;
	HDC		hDC ;
	DWORD	dwMouse ;
	DWORD	dwPushedStatus ;
	DWORD	dwTemp ;
	DWORD	fdwConversion ;
	HIMC	hIMC ;
	HWND	hSvrWnd ;
	BOOL	fOpen ;
	HMENU	hMenu ;
	static	POINT	ptdif ;
	static	RECT	drc ;
	static	RECT	rc ;

	hDC	= GetDC (hStatusWnd) ;
	switch (message){
	case WM_RBUTTONDOWN:
	case WM_LBUTTONDOWN:
		dwMouse			= GetWindowLong (hStatusWnd, FIGWL_MOUSE) ;
		if (!(dwMouse & FIM_FOCUS))
			break ;
		GetCursorPos (&pt) ;
		dwPushedStatus	= CheckPushedStatus (hStatusWnd, &pt) ;
		GetWindowRect (hStatusWnd, &drc) ;
		ptdif.x			= pt.x - drc.left ;
		ptdif.y			= pt.y - drc.top ;
		rc				= drc ;
		rc.right		-= rc.left ;
		rc.bottom		-= rc.top ;
		SetWindowLong (hStatusWnd, FIGWL_MOUSE, dwMouse | FIM_CAPUTURED) ;
		SetWindowLong (hStatusWnd, FIGWL_PUSHSTATUS, (DWORD)dwPushedStatus) ;
		PaintStatus (hStatusWnd, hDC, dwPushedStatus) ;
		break ;

	case WM_NCMOUSEMOVE:
	case WM_MOUSEMOVE:
		dwMouse			= GetWindowLong (hStatusWnd, FIGWL_MOUSE) ;
		dwPushedStatus	= (DWORD)GetWindowLong (hStatusWnd, FIGWL_PUSHSTATUS) ;
		if (dwPushedStatus){
			if (dwPushedStatus & PUSHED_STATUS_MOVE){
				if (dwMouse & FIM_MOVED){
					DrawUIBorder (&drc) ;
					GetCursorPos (&pt) ;
					drc.left	= pt.x - ptdif.x ;
					drc.top		= pt.y - ptdif.y ;
					drc.right	= drc.left + rc.right ;
					drc.bottom	= drc.top + rc.bottom ;
					DrawUIBorder (&drc) ;
				} else if (dwMouse & FIM_CAPUTURED){
					DrawUIBorder (&drc) ;
					SetWindowLong (hStatusWnd, FIGWL_MOUSE, dwMouse | FIM_MOVED) ;
				}
			}
		} else {
			GetCursorPos (&pt) ;
			ScreenToClient (hStatusWnd, &pt) ;
			GetClientRect (hStatusWnd, &rc) ;
			if (pt.x < rc.left || pt.y < rc.top || pt.x >= rc.right || pt.y >= rc.bottom){
				if (dwMouse & FIM_FOCUS){
					/* Mouse Cursor �� Window �ɓ����ė����B*/
					ReleaseCapture () ;
					dwMouse	= dwMouse & ~FIM_FOCUS ;
					SetWindowLong (hStatusWnd, FIGWL_MOUSE, dwMouse) ;
				}
			} else {
				if (!(dwMouse & FIM_FOCUS)){
					/* Mouse Cursor �� Window �ɓ����ė����B*/
					SetCapture (hStatusWnd) ;
					dwMouse	= dwMouse | FIM_FOCUS ;
					SetWindowLong (hStatusWnd, FIGWL_MOUSE, dwMouse) ;
				}
			}
			ChangeMouseCursor (hStatusWnd) ;
			PaintStatus (hStatusWnd, hDC, 0) ;
		}
		break ;

	case WM_RBUTTONUP:
		dwMouse	= GetWindowLong (hStatusWnd, FIGWL_MOUSE) ;
		if (dwMouse & FIM_CAPUTURED){
			if (dwMouse & FIM_MOVED){
				DrawUIBorder (&drc) ;
				GetCursorPos (&pt) ;
				MoveWindow (hStatusWnd,
							pt.x - ptdif.x,
							pt.y - ptdif.y,
							rc.right,
							rc.bottom, TRUE) ;
			}
		}
		hSvrWnd	= (HWND)GetWindowLong (hStatusWnd, FIGWL_SVRWND) ;
		hIMC	= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;
		if (hIMC)
			statusWindowRightMenu (hIMC, hStatusWnd) ;
		PaintStatus (hStatusWnd, hDC, 0) ;
		SetWindowLong (hStatusWnd, FIGWL_MOUSE, dwMouse & FIM_FOCUS) ;
		SetWindowLong (hStatusWnd, FIGWL_PUSHSTATUS, 0L) ;
		break ;

	case WM_LBUTTONUP:
		dwMouse	= GetWindowLong (hStatusWnd, FIGWL_MOUSE) ;
		if (dwMouse & FIM_CAPUTURED){
			if (dwMouse & FIM_MOVED){
				DrawUIBorder (&drc) ;
				GetCursorPos (&pt) ;
				MoveWindow (hStatusWnd,
							pt.x - ptdif.x,
							pt.y - ptdif.y,
							rc.right,
							rc.bottom, TRUE) ;
			}
		}
		hSvrWnd	= (HWND)GetWindowLong (hStatusWnd, FIGWL_SVRWND) ;
		hIMC	= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;
		if (hIMC){
			GetCursorPos (&pt) ;
			dwPushedStatus	= GetWindowLong (hStatusWnd, FIGWL_PUSHSTATUS) ;
			dwPushedStatus	&= CheckPushedStatus (hStatusWnd, &pt) ;
			if (dwPushedStatus & PUSHED_STATUS_MODE){
				statusWindowLeftMenu (hIMC, hStatusWnd) ;
			} else if (dwPushedStatus & PUSHED_STATUS_ONOFF){
				BOOL	fOpen	= ImmGetOpenStatus (hIMC) ;
				fOpen	= !fOpen ;
				ImmSetOpenStatus (hIMC, fOpen) ;
			}
		}
		PaintStatus (hStatusWnd, hDC, 0) ;
		SetWindowLong (hStatusWnd, FIGWL_MOUSE, dwMouse & FIM_FOCUS) ;
		SetWindowLong (hStatusWnd, FIGWL_PUSHSTATUS, 0L) ;
		break ;
	default:
		break ;
	}
	ReleaseDC (hStatusWnd, hDC) ;
	return ;
}

void	PASCAL	UpdateStatusWindow (LPUIEXTRA lpUIExtra)
{
	if (IsWindow (lpUIExtra->uiStatus.hWnd))
		SendMessage (lpUIExtra->uiStatus.hWnd, WM_UI_UPDATE, 0, 0L) ;
	return ;
}

/*
 *	Private Functions
 */

/*
 *	�ϊ����[�h�̃r�b�g�}�b�v���쐬����֐��B
 *-----
 *(�R�����g)
 *	�ϊ����[�h = �������[�h�A���ړ��̓��[�h�Ȃ� ��\������̂Ɏg�� bitmap ��
 *	Resource ����ǂݍ��ށB
 *(����)
 *	HWND	hwnd		���̃r�b�g�}�b�v�𗘗p���� Window�B
 */
HBITMAP	createStatusCModeBitmap (HWND hwnd)
{
	HDC		hDC ;
	HDC		hMemDC ;
	HDC		hSrcMemDC ;
	HDC		hOrgMemDC ;
	HBRUSH	hbrushOld ;
	HBITMAP	hbmpStatus, hbmpOld ;
	HBITMAP	hbmpSrcOld,	hbmpSrc ;
	HBITMAP	hbmpOrgOld, hbmpOrg ;
	int		y ;
	int		i ;

	hDC			= CreateDC ("DISPLAY", NULL, NULL, NULL) ;
	hbmpStatus	= CreateCompatibleBitmap (hDC, STATUSCMODE_BTNX * 4, STATUSCMODE_BTNY * 5) ;
	hMemDC		= CreateCompatibleDC (hDC) ;
	hbmpOld		= SelectObject (hMemDC, hbmpStatus) ;
	hbrushOld	= SelectObject (hMemDC, GetSysColorBrush (COLOR_3DFACE)) ;
	PatBlt (hMemDC, 0, 0, STATUSCMODE_BTNX * 4, STATUSCMODE_BTNY * 5, PATCOPY) ;
	SelectObject (hMemDC, hbrushOld) ;

	hbmpOrg		= (HBITMAP)GetWindowLong (hwnd, FIGWL_STATUSORGBMP) ;
	hOrgMemDC	= CreateCompatibleDC (hDC) ;
	hbmpOrgOld	= SelectObject (hOrgMemDC, hbmpOrg) ;
	hbmpSrc		= CreateCompatibleBitmap (hDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * 9) ;
	hSrcMemDC	= CreateCompatibleDC (hDC) ;
	hbmpSrcOld	= SelectObject (hSrcMemDC, hbmpSrc) ;
	BitBlt (hSrcMemDC, 0,					0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 9, hOrgMemDC, 0, 0, SRCCOPY) ;
	BitBlt (hSrcMemDC, STATUSCMODE_BTNX,	0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 9, hOrgMemDC, 0, 0, NOTSRCCOPY) ;

	for (i = 0 ; i < 4 ; i ++){
		BitBlt (hMemDC, STATUSCMODE_BTNX * i, 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 5,
				hSrcMemDC, 0, 0, SRCAND) ;
	}
	for (y = 0 ; y < 5 ; y ++){
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 5, SRCINVERT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 6, SRCINVERT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 7, SRCINVERT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 8, SRCINVERT) ;
	}
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DLIGHT)) ;
	PatBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DSHADOW)) ;
	PatBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 1, STATUSCMODE_BTNX, STATUSCMODE_BTNY, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 5, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 0, SRCAND) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 6, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 1, SRCAND) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 7, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 0, SRCAND) ;
	BitBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 8, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
			hSrcMemDC, 0, STATUSCMODE_BTNY * 1, SRCAND) ;
	for (y = 0 ; y < 5 ; y ++){
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 5, SRCPAINT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 6, SRCPAINT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 7, SRCPAINT) ;
		BitBlt (hMemDC, STATUSCMODE_BTNX * 2, STATUSCMODE_BTNY * y, STATUSCMODE_BTNX, STATUSCMODE_BTNY,
				hSrcMemDC, 0, STATUSCMODE_BTNY * 8, SRCPAINT) ;
	}

	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_GRAYTEXT)) ;
	PatBlt (hSrcMemDC, 0, STATUSCMODE_BTNY * 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 5, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	BitBlt (hSrcMemDC, 0, 0, STATUSCMODE_BTNX * 1, STATUSCMODE_BTNY * 5,
			hSrcMemDC, STATUSCMODE_BTNX, 0, SRCAND) ;
	BitBlt (hMemDC, STATUSCMODE_BTNX * 3, 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 5,
			hSrcMemDC, 0, 0, SRCPAINT) ;
	BitBlt (hMemDC, STATUSCMODE_BTNX * 3, 0, STATUSCMODE_BTNX, STATUSCMODE_BTNY * 5,
			hOrgMemDC, STATUSCMODE_BTNX * 1, 0, SRCPAINT) ;
	SelectObject (hOrgMemDC, hbmpOrgOld) ;
	DeleteDC (hOrgMemDC) ;

	SelectObject (hSrcMemDC, hbmpSrcOld) ;
	DeleteDC (hSrcMemDC) ;
	DeleteObject (hbmpSrc) ;
	SelectObject (hMemDC, hbmpOld) ;
	DeleteDC (hMemDC) ;
	DeleteDC (hDC) ;
	return	hbmpStatus ;
}

HBITMAP	createStatusOnOffBitmap (HWND hwnd)
{
	HDC		hDC ;
	HDC		hMemDC ;
	HDC		hSrcMemDC ;
	HDC		hOrgMemDC ;
	HBRUSH	hbrushOld ;
	HBITMAP	hbmpStatus, hbmpOld ;
	HBITMAP	hbmpSrcOld,	hbmpSrc ;
	HBITMAP	hbmpOrgOld, hbmpOrg ;

	hDC			= CreateDC ("DISPLAY", NULL, NULL, NULL) ;
	hbmpStatus	= CreateCompatibleBitmap (hDC, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2) ;
	hMemDC		= CreateCompatibleDC (hDC) ;
	hbmpOld		= SelectObject (hMemDC, hbmpStatus) ;
	hbrushOld	= SelectObject (hMemDC, GetSysColorBrush (COLOR_3DFACE)) ;
	PatBlt (hMemDC, 0, 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2, PATCOPY) ;
	SelectObject (hMemDC, hbrushOld) ;

	hbmpOrg		= (HBITMAP)GetWindowLong (hwnd, FIGWL_CLOSEORGBMP) ;
	hOrgMemDC	= CreateCompatibleDC (hDC) ;
	hbmpOrgOld	= SelectObject (hOrgMemDC, hbmpOrg) ;
	hbmpSrc		= CreateCompatibleBitmap (hDC, 36, 100) ;
	hSrcMemDC	= CreateCompatibleDC (hDC) ;
	hbmpSrcOld	= SelectObject (hSrcMemDC, hbmpSrc) ;
	BitBlt (hSrcMemDC, 0, 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 5, hOrgMemDC, 0, 0, SRCCOPY) ;
	SelectObject (hOrgMemDC, hbmpOrgOld) ;
	DeleteDC (hOrgMemDC) ;

	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 2, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 2, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 0, SRCPAINT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 1, SRCPAINT) ;
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DLIGHT)) ;
	PatBlt (hSrcMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	hbrushOld	= SelectObject (hSrcMemDC, GetSysColorBrush (COLOR_3DSHADOW)) ;
	PatBlt (hSrcMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, PATCOPY) ;
	SelectObject (hSrcMemDC, hbrushOld) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 4, SRCINVERT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 4, SRCINVERT) ;
	BitBlt (hSrcMemDC, 0, STATUSONOFF_BTNY * 3, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2,
			hSrcMemDC, 0, STATUSONOFF_BTNY * 0, SRCAND) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 2, 
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCPAINT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 0, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, 
			hSrcMemDC, 0, STATUSONOFF_BTNY * 4, SRCPAINT) ;
	BitBlt (hMemDC, 0, STATUSONOFF_BTNY * 1, STATUSONOFF_BTNX * 3, STATUSONOFF_BTNY * 1, 
			hSrcMemDC, 0, STATUSONOFF_BTNY * 3, SRCPAINT) ;
	SelectObject (hSrcMemDC, hbmpSrcOld) ;
	DeleteObject (hbmpSrc) ;
	DeleteDC (hSrcMemDC) ;
	SelectObject (hMemDC, hbmpOld) ;
	DeleteDC (hMemDC) ;
	DeleteDC (hDC) ;
	return	hbmpStatus ;
}

/*
 *	status window �����N���b�N���ꂽ���̃��j���[�������֐��B
 *-----
 *(�R�����g)
 *	showStatusWindowLeftMenu () ���Ăяo���� PopupMenu ��\������B
 *	showStatusWindowLeftMenu () �̕Ԃ�l�� PopupMenu �̂ǂ̍��ڂ��I������
 *	���̂�������A��������ē��̓��[�h�̐؂�ւ����s���B
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
BOOL	statusWindowLeftMenu (HIMC hIMC, HWND hwnd)
{
	BOOL				fOpen ;
	int					nCmd ;
	/* �|�b�v�A�b�v���j���[��\������B*/
	nCmd	= showStatusWindowLeftMenu (hIMC, hwnd) ;
	if (nCmd < 0 || nCmd == IDCANCEL)
		return	TRUE ;
	if (IDM_CMODE_TO_ASCII <= nCmd && nCmd <= IDM_CMODE_TO_ZENEI){
		SKKChangeConversionMode (hIMC, nCmd) ;
	} else if (nCmd == IDM_CMODE_TO_DIRECTINPUT){
		fOpen	= ImmGetOpenStatus (hIMC) ;
		if (fOpen)
			ImmSetOpenStatus (hIMC, FALSE) ;
	} else {
		return	FALSE ;
	}
	return	TRUE ;
}

/*
 *	status window ���E�N���b�N���ꂽ���̃��j���[�������֐��B
 *-----
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
BOOL	statusWindowRightMenu (HIMC hIMC, HWND hwnd)
{
	HWND	hUIWnd ;
	BOOL	fOpen ;
	int		nCmd ;
	nCmd	= showStatusWindowRightMenu (hIMC, hwnd) ;
	if (nCmd < 0 || nCmd == IDCANCEL)
		return	TRUE ;
	switch (nCmd){
	case	IDM_SHOW_PROPERTY_WINDOW:
		ImmConfigureIME (GetKeyboardLayout(0), NULL, IME_CONFIG_GENERAL, 0) ;
		break ;
	case	IDM_HIDE_TOOLBAR:
		skkinput_hide_toolbar	= TRUE ;
		SetRegDwordValue (TEXT ("\\Window"), TEXT (REGKEY_HIDETOOLBAR), 1) ;
		hUIWnd	= (HWND)GetWindowLong (hwnd, FIGWL_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_STATEHIDE, (WPARAM)0, (LPARAM)0) ;
		UpdateIndicIcon (hIMC) ;
		break ;
	default:
		if (IDM_CMODE_TO_ASCII <= nCmd && nCmd <= IDM_CMODE_TO_ZENEI){
			SKKChangeConversionMode (hIMC, nCmd) ;
		} else if (nCmd == IDM_CMODE_TO_DIRECTINPUT){
			fOpen	= ImmGetOpenStatus (hIMC) ;
			if (fOpen)
				ImmSetOpenStatus (hIMC, FALSE) ;
		}
		break ;
	}
	return	TRUE ;
}

/*
 *	Status Window �����N���b�N�������̃��j���[���쐬�A���[�U�̑I�����ʂ𓾂�֐��B
 *----
 *(�R�����g)
 *	���j���[���쐬�Ƃ����̂́ACreatePopupMenu () ����Ƃ������ƂŁA
 *	���[�U�̑I�����ʂ𓾂�Ƃ����̂́ATrackPopupMenu () ���Ă��܂��Ƃ������ƁB
 *	���̊֐��� TrackPopupMenu �̕Ԃ�l��Ԃ��܂��B
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
int		showStatusWindowLeftMenu (HIMC hIMC, HWND hwnd)
{
	static	MYMENUITEMINFO	myLeftMenuItemInfoTbl []	= {
	  { MIIM_TYPE,
		MFT_SEPARATOR,
		0,							NULL, },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,
		IDCANCEL,					TEXT ("�L�����Z��"), },
	} ;
	HMENU			hMenu ;
	POINT			pos ;
	int				nCmd ;
	MENUITEMINFO	menuItemInfo ;
	LPINPUTCONTEXT	lpIMC ;
	int				i ;
	int				iPosition ;

	GetCursorPos ((LPPOINT)&pos) ;
	/* �|�b�v�A�b�v���j���[���쐬����B*/
	hMenu	= CreatePopupMenu () ;
	if (!hMenu)
		return	-1 ;
	iPosition	= 0 ;
	insertInputModeMenu (hIMC, hMenu, &iPosition) ;
	/* �|�b�v�A�b�v���j���[�̍��ڂ�����������B*/
	for (i = 0 ; i < sizeof (myLeftMenuItemInfoTbl) / sizeof (MYMENUITEMINFO) ; i ++){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= myLeftMenuItemInfoTbl [i].m_fMask ;
		menuItemInfo.fType			= myLeftMenuItemInfoTbl [i].m_fType ;
		menuItemInfo.wID			= myLeftMenuItemInfoTbl [i].m_wID ;
		if (menuItemInfo.fMask & MIIM_STATE)
			menuItemInfo.fState	= MFS_ENABLED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= myLeftMenuItemInfoTbl [i].m_dwTypeData ;
		if (!menuItemInfo.dwTypeData){
			menuItemInfo.cch		= 0 ;
		} else {
			menuItemInfo.cch		= lstrlen (menuItemInfo.dwTypeData) ;
		}
		InsertMenuItem (hMenu, iPosition, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		iPosition	++ ;
	}
	/* �|�b�v�A�b�v���j���[��\�����A�I�����ʂ𓾂�B*/
	nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTALIGN | TPM_BOTTOMALIGN, pos.x, pos.y, 0, hwnd, NULL) ;
	DestroyMenu (hMenu) ;
	return	nCmd ;
}

/*
 *	Status Window ���E�N���b�N�������̃��j���[���쐬�A���[�U�̑I�����ʂ𓾂�֐��B
 *----
 *(�R�����g)
 *	showStatusWindowLeftMenu ���Q�Ƃ̂��ƁB
 *(����)
 *	HWND 	hwnd		���̃��j���[�� Owner �ƂȂ� Window�B
 *	HIMC	hIMC		Handle of Input Method Context ���������ȁH
 */
int		showStatusWindowRightMenu (HIMC hIMC, HWND hwnd)
{
	HMENU			hMenu ;
	HMENU			hSubMenu ;
	POINT			pos ;
	int				nCmd ;
	int				iMenuItem ;
	MENUITEMINFO	menuItemInfo ;
	static	MYMENUITEMINFO	myRightMenuItemInfoTbl []	= {
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,
		IDM_HIDE_TOOLBAR,			TEXT ("�^�X�N�o�[�ɓ����(&I)"), },
	  { MIIM_TYPE,
		MFT_SEPARATOR,
		0,							0, },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,
		IDM_SHOW_PROPERTY_WINDOW,	TEXT ("�v���p�e�B(&R)"), },
	  { MIIM_TYPE,
		MFT_SEPARATOR,
		0,							0, },
	  { MIIM_STATE | MIIM_TYPE | MIIM_SUBMENU,
		MFT_STRING,
		0,							TEXT ("���̓��[�h(&N)"), },
	  { MIIM_TYPE,
		MFT_SEPARATOR,
		0,							0, },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,
		IDCANCEL,					TEXT ("�L�����Z��"), },
	} ;

	GetCursorPos ((LPPOINT)&pos) ;
	hMenu		= CreatePopupMenu () ;
	if (!hMenu)
		return	-1 ;
	hSubMenu	= CreatePopupMenu () ;
	if (!hSubMenu){
		DestroyMenu (hMenu) ;
		return	-1 ;
	}
	iMenuItem	= 0 ;
	insertInputModeMenu (hIMC, hSubMenu, &iMenuItem) ;

	iMenuItem	= 0 ;
	while (iMenuItem < sizeof (myRightMenuItemInfoTbl) / sizeof (MYMENUITEMINFO)){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= myRightMenuItemInfoTbl [iMenuItem].m_fMask ;
		menuItemInfo.fType			= myRightMenuItemInfoTbl [iMenuItem].m_fType ;
		menuItemInfo.wID			= myRightMenuItemInfoTbl [iMenuItem].m_wID ;
		if (menuItemInfo.fMask & MIIM_STATE)
			menuItemInfo.fState		= MFS_ENABLED ;
		menuItemInfo.hSubMenu		= (menuItemInfo.fMask & MIIM_SUBMENU)? hSubMenu : 0 ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= myRightMenuItemInfoTbl [iMenuItem].m_dwTypeData ;
		if (!menuItemInfo.dwTypeData){
			menuItemInfo.cch		= 0 ;
		} else {
			menuItemInfo.cch		= lstrlen (myRightMenuItemInfoTbl [iMenuItem].m_dwTypeData) ;
		}
		InsertMenuItem (hMenu, iMenuItem, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		iMenuItem	++ ;
	}
	nCmd	= TrackPopupMenu (hMenu, TPM_RETURNCMD | TPM_RIGHTALIGN | TPM_BOTTOMALIGN, pos.x, pos.y, 0, hwnd, NULL) ;
	DestroyMenu (hMenu) ;
	DestroyMenu (hSubMenu) ;
	return	nCmd ;
}

BOOL	insertInputModeMenu (HIMC hIMC, HMENU hMenu, int FAR* lpiPosition)
{
	static	MYMENUITEMINFO	myMenuItemInfoTbl []	= {
	  {	MIIM_CHECKMARKS | MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_RADIOCHECK | MFT_STRING,
		IDM_CMODE_TO_ASCII,			TEXT ("�A�X�L�[(&S)"), },
	  { MIIM_CHECKMARKS | MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_RADIOCHECK | MFT_STRING,
		IDM_CMODE_TO_ROMANHIRA,		TEXT ("���[�}��������(&H)"), },
	  {	MIIM_CHECKMARKS | MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_RADIOCHECK | MFT_STRING,
		IDM_CMODE_TO_ROMANKATA,		TEXT ("���[�}���Љ���(&K)"), },
	  { MIIM_CHECKMARKS | MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_RADIOCHECK | MFT_STRING,
		IDM_CMODE_TO_ZENEI,			TEXT ("�S�p�p��(&E)"), },
	  { MIIM_CHECKMARKS | MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_RADIOCHECK | MFT_STRING,
		IDM_CMODE_TO_DIRECTINPUT,	TEXT ("���ړ���(&C)"), },
	} ;
	int				myInputModeTbl[]	= { 4, 1, 2, 3, 0 } ;
	LPINPUTCONTEXT	lpIMC ;
	int				iNum ;
	int				i ;
	int				iPosition ;
	MENUITEMINFO	menuItemInfo ;

	/* �����̐������`�F�b�N�B*/
	if (!hMenu || !lpiPosition)
		return	FALSE ;
	/* ���݂̓��̓��[�h�𓾂�B*/
	lpIMC	= (LPINPUTCONTEXT)ImmLockIMC (hIMC) ;
	if (!lpIMC)
		return	FALSE ;
	iNum	= myInputModeTbl [BTYFromCmode (lpIMC) / STATUS_BTNY] ;
	ImmUnlockIMC (hIMC) ;
	iPosition	= *lpiPosition ;
	/* ���j���[��ǉ�����B*/
	for (i = 0 ; i < sizeof (myMenuItemInfoTbl) / sizeof (MYMENUITEMINFO) ; i ++){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= myMenuItemInfoTbl [i].m_fMask ;
		menuItemInfo.fType			= myMenuItemInfoTbl [i].m_fType ;
		menuItemInfo.wID			= myMenuItemInfoTbl [i].m_wID ;
		menuItemInfo.fState			= (i == iNum)? MFS_CHECKED : MFS_UNCHECKED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= myMenuItemInfoTbl [i].m_dwTypeData ;
		menuItemInfo.cch			= lstrlen (menuItemInfo.dwTypeData) ;
		InsertMenuItem (hMenu, iPosition, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		iPosition	++ ;
	}
	*lpiPosition	= iPosition ;
	return	TRUE ;
}

