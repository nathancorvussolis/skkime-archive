/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * uiguide.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "imm.h"
#include "skkime98.h"

/*
 *	�v���g�^�C�v�錾�B
 */
static	LRESULT	onGuideUiHide (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;
static	LRESULT	onGuideUiUpdate (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;
static	LRESULT	onGuidePaint (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;
static	LRESULT	onGuideMouseCommand (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;
static	LRESULT	onGuideMove (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;
static	LRESULT	onGuideCreate (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;
static	LRESULT	onGuideDestroy (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;

/*
 *	GuideWndProc ()
 *	IME UI window procedure
 */
LRESULT	CALLBACK	GuideWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static	MYMSGFUNCPAIR	guideMsgFuncTbl [] = {
		{ WM_UI_HIDE,	onGuideUiHide,			},
		{ WM_UI_UPDATE,	onGuideUiUpdate,		},
		{ WM_PAINT,		onGuidePaint,			},
		{ WM_MOUSEMOVE,	onGuideMouseCommand,	},
		{ WM_SETCURSOR,	onGuideMouseCommand,	},
		{ WM_LBUTTONUP,	onGuideMouseCommand,	},
		{ WM_RBUTTONUP,	onGuideMouseCommand,	},
		{ WM_MOVE,		onGuideMove,			},
		{ WM_CREATE,	onGuideCreate,			},
		{ WM_DESTROY,	onGuideDestroy,			},
	} ;
	LPMYMSGFUNCPAIR	lpMsgFuncTbl ;
	int				i ;

	lpMsgFuncTbl	= guideMsgFuncTbl ;
	for (i = 0 ; i < sizeof (guideMsgFuncTbl) / sizeof (MYMSGFUNCPAIR) ; i ++){
		if (message == lpMsgFuncTbl->m_uMsg)
			return	(lpMsgFuncTbl->m_pFunction)(hWnd, message, wParam, lParam) ;
		lpMsgFuncTbl	++ ;
	}
	if (!MyIsIMEMessage(message))
		return DefWindowProc (hWnd, message, wParam, lParam) ;
	return	0 ;
}

LRESULT	onGuideUiHide (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	ShowWindow (hwnd, SW_HIDE) ;
	return	0 ;
 	UNREFERENCED_PARAMETER (uMessage) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	onGuideUiUpdate (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	InvalidateRect (hwnd, NULL, FALSE) ;
	return	0 ;
 	UNREFERENCED_PARAMETER (uMessage) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	onGuidePaint (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT	ps ;
	HDC			hDC ;
	hDC	= BeginPaint (hwnd, &ps) ;
	PaintGuide (hwnd, hDC, NULL, 0) ;
	EndPaint (hwnd, &ps) ;
	return	0 ;
 	UNREFERENCED_PARAMETER (uMessage) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	onGuideMouseCommand (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	ButtonGuide (hwnd, uMessage, wParam, lParam) ;
	if ((uMessage == WM_SETCURSOR) &&
		(HIWORD(lParam) != WM_LBUTTONDOWN) &&
		(HIWORD(lParam) != WM_RBUTTONDOWN)) 
		return	DefWindowProc (hwnd, uMessage, wParam, lParam) ;
	if ((uMessage == WM_LBUTTONUP) || (uMessage == WM_RBUTTONUP)){
		SetWindowLong (hwnd, FIGWL_MOUSE, 0L) ;
		SetWindowLong (hwnd, FIGWL_PUSHSTATUS, 0L) ;
	}
	return	0 ;
}

LRESULT	onGuideMove (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	HWND	hUIWnd ;
	hUIWnd	= (HWND)GetWindowLong (hwnd, FIGWL_SVRWND) ;
	if (IsWindow (hUIWnd))
		SendMessage (hUIWnd, WM_UI_GUIDEMOVE, wParam, lParam) ;
	return	0 ;
 	UNREFERENCED_PARAMETER (uMessage) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	onGuideCreate (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	HBITMAP		hbmpGuide ;
	RECT		rc ;
	hbmpGuide	= LoadBitmap (hInst, "CLOSEBMP") ;
	SetWindowLong (hwnd, FIGWL_CLOSEBMP, (LONG)hbmpGuide) ;
	GetClientRect (hwnd, &rc) ;
	return	0 ;
 	UNREFERENCED_PARAMETER (uMessage) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT	onGuideDestroy (HWND hwnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	HBITMAP		hbmpGuide ;
	hbmpGuide	= (HBITMAP)GetWindowLong (hwnd, FIGWL_CLOSEBMP) ;
	DeleteObject (hbmpGuide) ;
	return	0 ;
 	UNREFERENCED_PARAMETER (uMessage) ;
 	UNREFERENCED_PARAMETER (wParam) ;
 	UNREFERENCED_PARAMETER (lParam) ;
}

/*
 *
 *	CheckPushedGuide ()
 *
 */
DWORD	PASCAL	CheckPushedGuide (HWND hGuideWnd, LPPOINT lppt)
{
	POINT	pt ;
	RECT	rc ;

	if (lppt){
		pt	= *lppt ;
		ScreenToClient (hGuideWnd, &pt) ;
		GetClientRect (hGuideWnd, &rc) ;
		if (!PtInRect (&rc, pt))
			return	0 ;

		rc.left		= rc.right-STCLBT_DX-2 ; 
		rc.top		= STCLBT_Y ;
		rc.right	= rc.left + STCLBT_DX ;
		rc.bottom	= rc.top + STCLBT_DY ;
		if (PtInRect(&rc, pt))
			return PUSHED_GUIDE_CLOSE ;
	}
	return	0 ;
}

/*
 *
 *	PaintGuide()
 *
 */
void	PASCAL	PaintGuide (HWND hGuideWnd , HDC hDC, LPPOINT lppt, DWORD dwPushedGuide)
{
	HIMC		hIMC ;
	HDC			hMemDC ;
	HBITMAP		hbmpOld ;
	HWND		hSvrWnd ;
	HANDLE		hGLStr ;
	LPSTR		lpGLStr ;
	DWORD		dwLevel ;
	DWORD		dwSize ;

	hSvrWnd = (HWND)GetWindowLong (hGuideWnd, FIGWL_SVRWND) ;
	hIMC	= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;
	if (hIMC){
		HBITMAP	hbmpGuide ;
		HBRUSH	hOldBrush ;
		HBRUSH	hBrush ;
		int		nCyCap = GetSystemMetrics (SM_CYSMCAPTION) ;
		RECT	rc ;

		hMemDC		= CreateCompatibleDC (hDC) ;

		hBrush		= CreateSolidBrush (GetSysColor (COLOR_ACTIVECAPTION)) ;
		hOldBrush	= SelectObject (hDC, hBrush) ;
		GetClientRect (hGuideWnd, &rc) ;
		rc.bottom	= nCyCap ;
		FillRect (hDC, &rc, hBrush) ;
		SelectObject (hDC, hOldBrush) ;
		DeleteObject (hBrush) ;

		hbmpGuide	= (HBITMAP)GetWindowLong (hGuideWnd, FIGWL_CLOSEBMP) ;
		hbmpOld		= SelectObject (hMemDC, hbmpGuide) ;

		if (!(dwPushedGuide & PUSHED_GUIDE_CLOSE)){
			BitBlt (hDC, rc.right - STCLBT_DX - 2, STCLBT_Y, STCLBT_DX, STCLBT_DY,
				    hMemDC, 0, 0, SRCCOPY) ;
		} else {
			BitBlt (hDC, rc.right - STCLBT_DX - 2, STCLBT_Y, STCLBT_DX, STCLBT_DY,
				    hMemDC, STCLBT_DX, 0, SRCCOPY) ;
		}

		dwLevel	= ImmGetGuideLine (hIMC, GGL_LEVEL, NULL, 0) ;
		if (dwLevel){
			dwSize	= ImmGetGuideLine (hIMC, GGL_STRING, NULL, 0) + 1 ;
			if ((dwSize > 1) && (hGLStr = GlobalAlloc (GHND, dwSize))){
				lpGLStr	= (LPSTR)GlobalLock(hGLStr) ;
				if (lpGLStr){
					COLORREF	rgb		= 0 ;
					HBRUSH		hbrLGR	= GetStockObject (LTGRAY_BRUSH) ;
					HBRUSH		hbr ;

					hbr	= SelectObject (hDC, hbrLGR) ;
					GetClientRect (hGuideWnd, &rc) ;
					PatBlt (hDC, 0, nCyCap, rc.right, rc.bottom - nCyCap, PATCOPY) ;
					SelectObject (hDC, hbr) ;

					switch (dwLevel){
					case GL_LEVEL_FATAL:
					case GL_LEVEL_ERROR:
						rgb	= RGB(255,0,0) ;
						break ;
					case GL_LEVEL_WARNING:
						rgb	= RGB(0,0,255) ;
						break ;
					case GL_LEVEL_INFORMATION:
					default:
						rgb	= RGB(0,0,0) ;
						break ;
					}

					dwSize	= ImmGetGuideLine (hIMC, GGL_STRING, lpGLStr, dwSize) ;
					if (dwSize){
						SetTextColor (hDC, rgb) ;
						SetBkMode (hDC, TRANSPARENT) ;
						TextOut (hDC, 0, nCyCap, lpGLStr, dwSize) ;
					}
					GlobalUnlock (hGLStr) ;
				}
				GlobalFree (hGLStr) ;
			}
		}
		SelectObject (hMemDC, hbmpOld) ;
		DeleteDC (hMemDC) ;
	}
	return ;
}

/*
 *
 *	ButtonGuide (hGuideWnd, message, wParam, lParam)
 *
 */
void PASCAL ButtonGuide( HWND hGuideWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT			pt ;
	HDC				hDC ;
	DWORD			dwMouse ;
	DWORD			dwPushedGuide ;
	DWORD			dwTemp ;
	HIMC			hIMC ;
	HWND			hSvrWnd ;
	static	POINT	ptdif ;
	static	RECT	drc ;
	static	RECT	rc ;
	static	DWORD	dwCurrentPushedGuide ;

	hDC	= GetDC (hGuideWnd) ;
	switch (message){
	case WM_SETCURSOR:
		if (HIWORD(lParam) == WM_LBUTTONDOWN ||
			HIWORD(lParam) == WM_RBUTTONDOWN){
			GetCursorPos (&pt) ;
			SetCapture (hGuideWnd) ;
			GetWindowRect (hGuideWnd, &drc) ;
			ptdif.x	= pt.x - drc.left ;
			ptdif.y	= pt.y - drc.top ;
			rc		= drc ;
			rc.right	-= rc.left ;
			rc.bottom	-= rc.top ;
			SetWindowLong (hGuideWnd, FIGWL_MOUSE, FIM_CAPUTURED) ;
			SetWindowLong (hGuideWnd, FIGWL_PUSHSTATUS, dwPushedGuide = CheckPushedGuide (hGuideWnd, &pt)) ;
			PaintGuide (hGuideWnd, hDC, &pt, dwPushedGuide) ;
			dwCurrentPushedGuide	= dwPushedGuide ;
		}
		break ;

	case WM_MOUSEMOVE:
		dwMouse 		= GetWindowLong (hGuideWnd, FIGWL_MOUSE) ;
		dwPushedGuide	= GetWindowLong (hGuideWnd, FIGWL_PUSHSTATUS) ;
		if (!dwPushedGuide){
			if (dwMouse & FIM_MOVED){
				DrawUIBorder (&drc) ;
				GetCursorPos (&pt) ;
				drc.left	= pt.x - ptdif.x ;
				drc.top		= pt.y - ptdif.y ;
				drc.right	= drc.left + rc.right ;
				drc.bottom	= drc.top + rc.bottom ;
				DrawUIBorder (&drc) ;
			} else if (dwMouse & FIM_CAPUTURED){
				DrawUIBorder (&drc) ;
				SetWindowLong (hGuideWnd, FIGWL_MOUSE, dwMouse | FIM_MOVED) ;
			}
		} else {
			GetCursorPos (&pt) ;
			dwTemp	= CheckPushedGuide (hGuideWnd, &pt) ;
			if ((dwTemp ^ dwCurrentPushedGuide) & dwPushedGuide)
				PaintGuide (hGuideWnd, hDC, &pt, dwPushedGuide & dwTemp) ;
				dwCurrentPushedGuide	= dwTemp ;
		}
		break ;

	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		dwMouse	= GetWindowLong (hGuideWnd, FIGWL_MOUSE) ;
		if (dwMouse & FIM_CAPUTURED){
			ReleaseCapture () ;
			if (dwMouse & FIM_MOVED){
				DrawUIBorder (&drc) ;
				GetCursorPos (&pt) ;
				MoveWindow (hGuideWnd,
							pt.x - ptdif.x,
							pt.y - ptdif.y,
							rc.right,
							rc.bottom, TRUE) ;
			}
		}
		hSvrWnd = (HWND)GetWindowLong (hGuideWnd, FIGWL_SVRWND) ;
		hIMC	= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;
		if (hIMC){
			GetCursorPos(&pt);
			dwPushedGuide = GetWindowLong (hGuideWnd, FIGWL_PUSHSTATUS);
			dwPushedGuide &= CheckPushedGuide (hGuideWnd, &pt) ;
			if (!dwPushedGuide) {
			} else if (dwPushedGuide == PUSHED_GUIDE_CLOSE) {
				PostMessage (hGuideWnd, WM_UI_HIDE, 0, 0) ;
			}
		}
		PaintGuide(hGuideWnd,hDC,NULL,0);
		break ;
	}
	ReleaseDC (hGuideWnd,hDC) ;
	return ;
}

/*
 *
 *	UpdateGuideWindow(lpUIExtra)
 *
 */
void	PASCAL	UpdateGuideWindow(LPUIEXTRA lpUIExtra)
{
	if (IsWindow (lpUIExtra->uiGuide.hWnd))
		SendMessage (lpUIExtra->uiGuide.hWnd, WM_UI_UPDATE, 0, 0L) ;
	return ;
}

