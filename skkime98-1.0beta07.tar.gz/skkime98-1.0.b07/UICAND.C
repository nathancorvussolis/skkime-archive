/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * UICAND.C
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"

/*
 *	�v���g�^�C�v�錾�B
 */
static	BOOL	PASCAL	moveCandidateWindowDefault (HWND hUIWnd, LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra) ;
static	BOOL	PASCAL	moveCandidateWindowExclude (HWND hUIWnd, LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra) ;
static	BOOL	PASCAL	moveCandidateWindowPosition (HWND hUIWnd, LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra) ;

/*
 *	---- �֐��̒�` ---- ��������---- �֐��̒�` ---- ��������----
 */

/*
 *	Candidate Window �� WINDOWPROC�B
 *(�R�����g)
 *	Candidate Window ����Window Message�͂��̊֐��ɑ����ė��܂��̂ŁA
 *	Window Message �ɑΉ������������s���܂��B���̊֐����̂� Window
 *	Message �̐U�蕪�������ł����ǁB
 *(����)
 *	hWnd	Window Message ���󂯎���� Composition Window �� Handle
 *	message	Window Message
 *	wParam	Window Message �̈�������1
 *	lParam	Window Message �̈�������2
 *(����)
 *	Candidate Window �͕ϊ���⃊�X�g��\������̂Ɏg�� Window �ł��B
 */
LRESULT	CALLBACK	CandWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND hUIWnd;

	switch (message){
	case WM_PAINT:
		PaintCandWindow (hWnd) ;
		break;

	case WM_SETCURSOR:
	case WM_MOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		DragUI (hWnd, message, wParam, lParam) ;
		if ((message == WM_SETCURSOR) &&
			(HIWORD(lParam) != WM_LBUTTONDOWN) &&
			(HIWORD(lParam) != WM_RBUTTONDOWN)) 
				return DefWindowProc (hWnd, message, wParam, lParam) ;
		if ((message == WM_LBUTTONUP) || (message == WM_RBUTTONUP))
			SetWindowLong (hWnd, FIGWL_MOUSE, 0L) ;
		break ;

	case WM_MOVE:
		hUIWnd	= (HWND)GetWindowLong (hWnd, FIGWL_SVRWND) ;
		if (IsWindow (hUIWnd))
			SendMessage (hUIWnd, WM_UI_CANDMOVE, wParam, lParam) ;
		break;

	default:
		if (!MyIsIMEMessage (message))
			return DefWindowProc (hWnd, message, wParam, lParam) ;
		break ;
	}
	return	0L ;
}

BOOL	PASCAL	GetCandPosFromCompWnd (LPUIEXTRA lpUIExtra, LPPOINT lppt)
{
	RECT rc ;

	if (lpUIExtra->dwCompStyle){
		if (lpUIExtra->uiComp [0].bShow){
			GetWindowRect (lpUIExtra->uiComp[0].hWnd, &rc) ;
			lppt->x	= rc.left ;
			lppt->y	= rc.bottom + 1 ;
			return	TRUE ;
		}
	} else {
		if (lpUIExtra->uiDefComp.bShow){
			GetWindowRect (lpUIExtra->uiDefComp.hWnd, &rc) ;
			lppt->x	= rc.left ;
			lppt->y	= rc.bottom + 1 ;
			return	TRUE ;
		}
	}
	return	FALSE ;
}

BOOL	PASCAL	GetCandPosFromCompForm (LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra, LPPOINT lppt)
{
	TEXTMETRIC	tm ;
	if (lpUIExtra->dwCompStyle){
		if (lpIMC && lpIMC->fdwInit & INIT_COMPFORM){
			GetCompFontMetrics (lpUIExtra, &tm) ;
			if (!lpUIExtra->bVertical){
				lppt->x	= lpIMC->cfCompForm.ptCurrentPos.x ;
				lppt->y	= lpIMC->cfCompForm.ptCurrentPos.y + tm.tmHeight ;
			} else {
				lppt->x	= lpIMC->cfCompForm.ptCurrentPos.x ;
				lppt->y	= lpIMC->cfCompForm.ptCurrentPos.y + tm.tmMaxCharWidth ;
			}
			return	TRUE ;
		}
	} else {
		if (GetCandPosFromCompWnd (lpUIExtra, lppt)){
			ScreenToClient (lpIMC->hWnd, lppt) ;
			return	TRUE ;
		}
	}
	return	FALSE ;
}

/*
 *	���\���ɗp���� Window ���쐬����֐��B
 */
void	PASCAL	CreateCandWindow (HWND hUIWnd, LPUIEXTRA lpUIExtra, LPINPUTCONTEXT lpIMC)
{
	LONG	lInst ;
	POINT	pt ;

	if (GetCandPosFromCompWnd (lpUIExtra, &pt)){
		lpUIExtra->uiCand.pt.x	= pt.x ;
		lpUIExtra->uiCand.pt.y	= pt.y ;
	}
	lInst	= GetWindowLong (hUIWnd, GWL_HINSTANCE) ;

	if (!IsWindow(lpUIExtra->uiCand.hWnd)){
		lpUIExtra->uiCand.hWnd = 
				CreateWindowEx (WS_EX_WINDOWEDGE,
								(LPSTR)szCandClassName, NULL,
								WS_COMPDEFAULT | WS_DLGFRAME,
								lpUIExtra->uiCand.pt.x,
								lpUIExtra->uiCand.pt.y,
								1, 1,
								hUIWnd, NULL, (HINSTANCE)lInst, NULL) ;
	}
	SetWindowLong (lpUIExtra->uiCand.hWnd, FIGWL_SVRWND, (DWORD)hUIWnd) ;
	ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
	lpUIExtra->uiCand.bShow	= FALSE ;
	return ;
}

void	PASCAL	PaintCandWindow (HWND hCandWnd)
{
	PAINTSTRUCT		ps ;
	HIMC			hIMC ;
	LPINPUTCONTEXT	lpIMC ;
	LPCANDIDATEINFO lpCandInfo ;
	LPCANDIDATELIST lpCandList ;
	HBRUSH			hbr ;
	HDC				hDC ;
	RECT			rc ;
	LPMYSTR			lpstr ;
	int				height ;
	DWORD 			i ;
	SIZE			sz ;
	SIZE			szKey ;
	SIZE			szSpace ;
	HWND			hSvrWnd ;
	HBRUSH 			hBrushParent ;
	LPSTR			lpCandidateKey []	= { "A:", "S:", "D:", "F:", "J:", "K:", "L:" } ;
	int				x ;
	int				iCount ;
	HDC				hPDC ;

	GetClientRect (hCandWnd, &rc) ;
	hDC				= BeginPaint (hCandWnd, &ps) ;

	hPDC			= GetDC (GetParent (hCandWnd)) ;
	hBrushParent	= CreateSolidBrush (GetBkColor (hPDC)) ;
	hbr				= SelectObject (hDC, hBrushParent) ;
	PatBlt (hDC, 0, 0, rc.right - rc.left, rc.bottom - rc.top, PATCOPY) ;
	SelectObject (hDC, hbr) ;
	DeleteObject (hBrushParent) ;
	ReleaseDC (GetParent (hCandWnd), hPDC) ;
	SetTextColor (hDC, RGB (0, 0, 0)) ;
	SetBkMode (hDC, TRANSPARENT) ;

	hSvrWnd	= (HWND)GetWindowLong (hCandWnd, FIGWL_SVRWND) ;
	hIMC	= (HIMC)GetWindowLong (hSvrWnd, IMMGWL_IMC) ;
	if (hIMC != NULL){
		lpIMC		= ImmLockIMC (hIMC) ;
		lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
		if (lpCandInfo != NULL){
			lpCandList	= (LPCANDIDATELIST)((LPSTR)lpCandInfo  + lpCandInfo->dwOffset[0]) ;
			x			= 0 ;
			iCount		= 0 ;
			i			= lpCandList->dwPageStart ;
			/* �󔒕����̑傫���𔲂��Ă����B*/
			GetTextExtentPoint32 (hDC, " ", 1, &szSpace) ;
			/* dwPageStart �ŕ\������₩�� dwPageSize �������\������B*/
			while (i < (lpCandList->dwPageStart + lpCandList->dwPageSize) &&
				   i < lpCandList->dwCount &&
				   iCount < 7 &&
				   x < (rc.right - rc.left)){
				GetTextExtentPoint32 (hDC, lpCandidateKey [iCount], 2, &szKey) ;
				lpstr	= (LPMYSTR)((LPSTR)lpCandList + lpCandList->dwOffset[i]) ;
				MyGetTextExtentPoint (hDC, lpstr, Mylstrlen(lpstr), &sz) ;
				TextOut   (hDC, x,            0, lpCandidateKey [iCount], 2) ;
				MyTextOut (hDC, x + szKey.cx, 0, lpstr,                   Mylstrlen(lpstr)) ;
				x		+= szKey.cx + sz.cx ;
				TextOut   (hDC, x,            0, " ", 1) ;
				x		+= szSpace.cx ;
				iCount	++ ;
				i		++ ;
			}
			if (x < (rc.right - rc.left)){
				MYCHAR	buffer [32] ;
				Mylstrcpy (buffer, MYTEXT (" [�c�� ")) ;
				Myltoa    (buffer + Mylstrlen (buffer), lpCandList->dwCount - i) ;
				Mylstrcat (buffer, MYTEXT ("]")) ;
				MyTextOut (hDC, x, 0, buffer, Mylstrlen (buffer)) ;
			}
			ImmUnlockIMCC (lpIMC->hCandInfo) ;
		}
		ImmUnlockIMC (hIMC) ;
	}
	EndPaint (hCandWnd, &ps) ;
	return ;
}

void	PASCAL	HideCandWindow (LPUIEXTRA lpUIExtra)
{
	RECT	rc ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, (LPRECT)&rc);
		lpUIExtra->uiCand.pt.x	= rc.left ;
		lpUIExtra->uiCand.pt.y	= rc.top ;
		MoveWindow (lpUIExtra->uiCand.hWnd, -1 , -1 , 0 , 0, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd, SW_HIDE) ;
		lpUIExtra->uiCand.bShow	= FALSE ;
	}
	return ;
}

void	PASCAL	 MoveCandWindow (HWND hUIWnd, LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra, BOOL fForceComp)
{
	POINT			pt ;
	CANDIDATEFORM	caf ;

	if (fForceComp){
		if (GetCandPosFromCompForm (lpIMC, lpUIExtra, &pt)){
			caf.dwIndex			= 0 ;
			caf.dwStyle			= CFS_CANDIDATEPOS ;
			caf.ptCurrentPos.x	= pt.x ;
			caf.ptCurrentPos.y	= pt.y ;
			ImmSetCandidateWindow (lpUIExtra->hIMC, &caf) ;
		}
		return ;
	}
	if (lpIMC->cfCandForm [0].dwIndex == -1){
		moveCandidateWindowDefault (hUIWnd, lpIMC, lpUIExtra) ;
		return ;
	}
	if (!IsCandidate (lpIMC))
		return ;

	if (lpIMC->cfCandForm [0].dwStyle == CFS_EXCLUDE){
		moveCandidateWindowExclude (hUIWnd, lpIMC, lpUIExtra) ;
	}  else if (lpIMC->cfCandForm[0].dwStyle == CFS_CANDIDATEPOS){
		moveCandidateWindowPosition (hUIWnd, lpIMC, lpUIExtra) ;
	}
	return ;
}

BOOL	PASCAL	AdjustCandidateWindowSize (HWND hwnd, LPSIZE lpSize)
{
	HDC			hDC ;
	TEXTMETRIC	tm ;
	int			iWidth, iHeight ;
	hDC		= GetDC (hwnd) ;
	if (!hDC)
		return	FALSE ;
	GetTextMetrics (hDC, &tm) ;
	ReleaseDC (hwnd, hDC) ;
	iWidth	= tm.tmAveCharWidth * DEFAULT_MINIBUF_CHARWIDTH + 2 * GetSystemMetrics (SM_CXEDGE) ;
	iHeight	= tm.tmHeight + 2 * GetSystemMetrics (SM_CYEDGE) ;
	if (lpSize){
		if (lpSize->cx < iWidth)
			lpSize->cx	= iWidth ;
		lpSize->cy	= iHeight ;
	}
	return	TRUE ;
}

BOOL	PASCAL	IsCrossRectangle (LPPOINT lpPoint, LPSIZE lpSize, LPRECT lpRect)
{
	if (lpRect->right <= lpPoint->x)
		return	FALSE ;
	if ((lpPoint->x + lpSize->cx) < lpRect->left)
		return	FALSE ;
	if (lpRect->bottom <= lpPoint->y)
		return	FALSE ;
	if ((lpPoint->y + lpSize->cy) < lpRect->top)
		return	FALSE ;
	return	TRUE ;
}

/*
 *	----- �������� Private �֐� ----- �������� Private �֐� ----- �������� Private �֐� -----
 */

BOOL	PASCAL	moveCandidateWindowDefault (HWND hUIWnd, LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	POINT	pt ;
	SIZE	sizeCandWnd ;

	if (IsWindow (lpUIExtra->uiCand.hWnd)){
		GetWindowRect(lpUIExtra->uiCand.hWnd, (LPRECT)&rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom = 0 ;
	}
	if (GetCandPosFromCompWnd (lpUIExtra, &pt)){
		/* ��⑋�̑傫�����v�Z����B*/
		GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;
		sizeCandWnd.cx	= rcUIWnd.right	- rcUIWnd.left	+ 2 * GetSystemMetrics (SM_CXBORDER) + 2 * GetSystemMetrics (SM_CXEDGE) ;
		sizeCandWnd.cy	= rc.bottom		- rc.top		+ 2 * GetSystemMetrics (SM_CYBORDER) + 2 * GetSystemMetrics (SM_CYEDGE) ;
		AdjustCandidateWindowSize (hUIWnd, &sizeCandWnd) ;

		lpUIExtra->uiCand.pt.x	= pt.x ;
		lpUIExtra->uiCand.pt.y	= pt.y ;

		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd, SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiCand.bShow	= TRUE ;
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
		SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x,(WORD)pt.y)) ;
	}
	return	TRUE ;
}

BOOL	PASCAL	moveCandidateWindowExclude (HWND hUIWnd, LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra)
{
	RECT	rc ;
	RECT	rcWork ;
	RECT	rcExclude ;
	RECT	rcUIWnd ;
	POINT	pt ;
	SIZE	sizeCandWnd ;

	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;

	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetClientRect (lpUIExtra->uiCand.hWnd, &rc) ;
	} else {
		rc.left	= rc.top	= rc.bottom	= rc.right	= 0 ;
	}
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;

	/* ��⑋��\�����Ă͂����Ȃ��̈�𓾂�B*/
	pt.x	= lpIMC->cfCandForm [0].rcArea.left ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.top ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.left		= pt.x ;
	rcExclude.top		= pt.y ;
	pt.x	= lpIMC->cfCandForm [0].rcArea.right ;
	pt.y	= lpIMC->cfCandForm [0].rcArea.bottom ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
	rcExclude.right		= pt.x ;
	rcExclude.bottom	= pt.y ;

	/* ��⑋�̈ʒu�Ƒ傫�������肷��B*/
	sizeCandWnd.cx	= rcUIWnd.right	- rcUIWnd.left	+ 2 * GetSystemMetrics (SM_CXBORDER) + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom		- rc.top		+ 2 * GetSystemMetrics (SM_CYBORDER) + 2 * GetSystemMetrics (SM_CYEDGE) ;
	AdjustCandidateWindowSize (hUIWnd, &sizeCandWnd) ;

	pt.x	= 0 ;
	pt.y	= rcUIWnd.bottom - rcUIWnd.top ;
	ClientToScreen (lpIMC->hWnd, &pt) ;

	/* Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B*/
	if ((pt.x + sizeCandWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - sizeCandWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + sizeCandWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - sizeCandWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	/* Window ���w�肵���̈�ɂ������Ă��Ȃ����ǂ����`�F�b�N����B*/
	if (IsCrossRectangle (&pt, &sizeCandWnd, &rcExclude)){
		pt.y	= rcExclude.bottom ;
		if ((pt.y + sizeCandWnd.cy) > rcWork.bottom)
			pt.y	= rcExclude.top - sizeCandWnd.cy ;
	}
	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, &rc) ;
		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd,SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiCand.bShow	= TRUE ;
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

BOOL	PASCAL	moveCandidateWindowPosition (HWND hUIWnd, LPINPUTCONTEXT lpIMC, LPUIEXTRA lpUIExtra)
{
	RECT	rc ;
	RECT	rcUIWnd ;
	RECT	rcWork ;
	SIZE	sizeCandWnd ;
	POINT	pt ;

	pt.x	= lpIMC->cfCandForm[0].ptCurrentPos.x ;
	pt.y	= lpIMC->cfCandForm[0].ptCurrentPos.y ;
	ClientToScreen (lpIMC->hWnd, &pt) ;
		
	/* Windows �̍�Ɨ̈�𓾂�B(Desktop �̑傫������) */
	SystemParametersInfo (SPI_GETWORKAREA, 0, &rcWork, FALSE) ;
	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		GetWindowRect (lpUIExtra->uiCand.hWnd, &rc) ;
	} else {
		rc.left = rc.right = rc.top = rc.bottom	= 0 ;
	}
	GetWindowRect (lpIMC->hWnd, &rcUIWnd) ;

	/* ��⑋�̑傫�����v�Z����B*/
	sizeCandWnd.cx	= rcUIWnd.right	- rcUIWnd.left	+ 2 * GetSystemMetrics (SM_CXBORDER) + 2 * GetSystemMetrics (SM_CXEDGE) ;
	sizeCandWnd.cy	= rc.bottom		- rc.top		+ 2 * GetSystemMetrics (SM_CYBORDER) + 2 * GetSystemMetrics (SM_CYEDGE) ;
	AdjustCandidateWindowSize (hUIWnd, &sizeCandWnd) ;

	/* Window ����ʊO�ɏo�Ă��܂����Ƃ������悤�ɒ�������B*/
	if ((pt.x + sizeCandWnd.cx) > rcWork.right){
		pt.x	= rcWork.right - sizeCandWnd.cx ;
		if (pt.x < 0)
			pt.x	= 0 ;
	}
	if ((pt.y + sizeCandWnd.cy) > rcWork.bottom){
		pt.y = rcWork.bottom - sizeCandWnd.cy ;
		if (pt.y < 0)
			pt.y	= 0 ;
	}
	if (IsWindow(lpUIExtra->uiCand.hWnd)){
		MoveWindow (lpUIExtra->uiCand.hWnd, pt.x, pt.y, sizeCandWnd.cx, sizeCandWnd.cy, TRUE) ;
		ShowWindow (lpUIExtra->uiCand.hWnd, SW_SHOWNOACTIVATE) ;
		lpUIExtra->uiCand.bShow	= TRUE ;
		InvalidateRect (lpUIExtra->uiCand.hWnd, NULL, FALSE) ;
	}
	SendMessage (hUIWnd, WM_UI_CANDMOVE, 0, MAKELONG((WORD)pt.x, (WORD)pt.y)) ;
	return	TRUE ;
}

