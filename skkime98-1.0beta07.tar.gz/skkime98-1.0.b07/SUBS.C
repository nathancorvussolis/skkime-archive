/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * subs.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "imm.h"
#include "skkime98.h"
#include "unicode.h"
#include "resource.h"

void	PASCAL InitCompStr (LPCOMPOSITIONSTRING lpCompStr, DWORD dwClrFlag)
{
	lpCompStr->dwSize = sizeof (MYCOMPSTR) ;

	if (dwClrFlag & CLR_UNDET){
		lpCompStr->dwCompReadAttrOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->bCompReadAttr - (DWORD)lpCompStr;
		lpCompStr->dwCompReadClauseOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->dwCompReadClause - (DWORD)lpCompStr;
		lpCompStr->dwCompReadStrOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->szCompReadStr - (DWORD)lpCompStr;
		lpCompStr->dwCompAttrOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->bCompAttr - (DWORD)lpCompStr;
		lpCompStr->dwCompClauseOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->dwCompClause - (DWORD)lpCompStr;
		lpCompStr->dwCompStrOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->szCompStr - (DWORD)lpCompStr;

		lpCompStr->dwCompStrLen			= 0 ;
		lpCompStr->dwCompReadStrLen		= 0 ;
		lpCompStr->dwCompAttrLen		= 0 ;
		lpCompStr->dwCompReadAttrLen	= 0 ;
		lpCompStr->dwCompClauseLen		= 0 ;
		lpCompStr->dwCompReadClauseLen	= 0 ;

		*GETLPCOMPSTR (lpCompStr)		= MYTEXT('\0') ;
		*GETLPCOMPREADSTR (lpCompStr)	= MYTEXT('\0') ;

		lpCompStr->dwCursorPos			= 0 ;
	}
	if (dwClrFlag & CLR_RESULT){
		lpCompStr->dwResultStrOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->szResultStr - (DWORD)lpCompStr;
		lpCompStr->dwResultClauseOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->dwResultClause - (DWORD)lpCompStr;
		lpCompStr->dwResultReadStrOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->szResultReadStr - (DWORD)lpCompStr;
		lpCompStr->dwResultReadClauseOffset = 
			(DWORD)((LPMYCOMPSTR)lpCompStr)->dwResultReadClause - (DWORD)lpCompStr;

		lpCompStr->dwResultStrLen			= 0 ;
		lpCompStr->dwResultClauseLen		= 0 ;
		lpCompStr->dwResultReadStrLen		= 0 ;
		lpCompStr->dwResultReadClauseLen	= 0 ;

		*GETLPRESULTSTR(lpCompStr)			= MYTEXT ('\0') ;
		*GETLPRESULTREADSTR(lpCompStr)		= MYTEXT ('\0') ;
	}
	return ;
}

void	PASCAL ClearCompStr (LPCOMPOSITIONSTRING lpCompStr, DWORD dwClrFlag)
{
	lpCompStr->dwSize	= sizeof(MYCOMPSTR) ;

	if (dwClrFlag & CLR_UNDET){
		lpCompStr->dwCompStrOffset						= 0 ;
		lpCompStr->dwCompClauseOffset					= 0 ;
		lpCompStr->dwCompAttrOffset						= 0 ;
		lpCompStr->dwCompReadStrOffset					= 0 ;
		lpCompStr->dwCompReadClauseOffset				= 0 ;
		lpCompStr->dwCompReadAttrOffset					= 0 ;
		lpCompStr->dwCompStrLen							= 0 ;
		lpCompStr->dwCompClauseLen 						= 0 ;
		lpCompStr->dwCompAttrLen 						= 0 ;
		lpCompStr->dwCompReadStrLen 					= 0 ;
		lpCompStr->dwCompReadClauseLen 					= 0 ;
		lpCompStr->dwCompReadAttrLen 					= 0 ;
		((LPMYCOMPSTR)lpCompStr)->szCompStr[0] 			= MYTEXT ('\0') ;
		((LPMYCOMPSTR)lpCompStr)->szCompReadStr[0]		= MYTEXT ('\0') ;
		lpCompStr->dwCursorPos							= 0 ;
	}
	if (dwClrFlag & CLR_RESULT){
		lpCompStr->dwResultStrOffset					= 0 ;
		lpCompStr->dwResultClauseOffset					= 0 ;
		lpCompStr->dwResultReadStrOffset				= 0 ;
		lpCompStr->dwResultReadClauseOffset				= 0 ;
		lpCompStr->dwResultStrLen						= 0 ;
		lpCompStr->dwResultClauseLen					= 0 ;
		lpCompStr->dwResultReadStrLen					= 0 ;
		lpCompStr->dwResultReadClauseLen				= 0 ;
		((LPMYCOMPSTR)lpCompStr)->szResultStr[0]		= MYTEXT ('\0') ;
		((LPMYCOMPSTR)lpCompStr)->szResultReadStr[0]	= MYTEXT ('\0') ;
	}
	return ;
}

void	PASCAL ClearCandidate (LPCANDIDATEINFO lpCandInfo)
{
	lpCandInfo->dwSize			= 0L ;
	lpCandInfo->dwCount			= 0L ;
	lpCandInfo->dwOffset[0]		= 0L ;
	
	((LPMYCAND)lpCandInfo)->cl.dwSize		= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwStyle		= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwCount		= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwSelection	= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwPageStart	= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwPageSize	= 0L ;
	((LPMYCAND)lpCandInfo)->cl.dwOffset[0]	= 0L ;
	return ;
}

/*
 *
 *	IsCompStr (hIMC)
 *
 */
BOOL	PASCAL IsCompStr(HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	BOOL				fRet	= FALSE ;

	lpIMC	= ImmLockIMC(hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize(lpIMC->hCompStr) < sizeof (COMPOSITIONSTRING)){
		ImmUnlockIMC (hIMC) ;
		return	FALSE ;
	}

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC(lpIMC->hCompStr) ;
	fRet		= (lpCompStr->dwCompStrLen > 0) ;

	ImmUnlockIMCC (lpIMC->hCompStr) ;
	ImmUnlockIMC (hIMC) ;

	return	fRet ;
}

BOOL PASCAL IsConvertedCompStr (HIMC hIMC)
{
	LPINPUTCONTEXT		lpIMC ;
	LPCOMPOSITIONSTRING	lpCompStr ;
	BOOL				fRet	= FALSE ;

	lpIMC = ImmLockIMC(hIMC) ;
	if (!lpIMC)
		return	FALSE ;

	if (ImmGetIMCCSize(lpIMC->hCompStr) < sizeof (MYCOMPSTR)){
		ImmUnlockIMC (hIMC) ;
		return	FALSE ;
	}

	lpCompStr	= (LPCOMPOSITIONSTRING)ImmLockIMCC (lpIMC->hCompStr) ;

	if (lpCompStr->dwCompStrLen > 0)
		fRet	= (((LPMYCOMPSTR)lpCompStr)->bCompAttr[0] > 0) ;

	ImmUnlockIMCC (lpIMC->hCompStr) ;
	ImmUnlockIMC (hIMC) ;

	return	fRet ;
}

BOOL PASCAL IsCandidate(LPINPUTCONTEXT lpIMC)
{
	LPCANDIDATEINFO	lpCandInfo ;
	BOOL			fRet	= FALSE ;

	if (ImmGetIMCCSize (lpIMC->hCandInfo) < sizeof (CANDIDATEINFO)){
		return	FALSE ;
	}
	lpCandInfo	= (LPCANDIDATEINFO)ImmLockIMCC (lpIMC->hCandInfo) ;
	fRet		= (lpCandInfo->dwCount > 0) ;
	ImmUnlockIMCC (lpIMC->hCandInfo) ;
	return	fRet ;
}

/*
 *
 *	  GetMyHKL()
 *
 */
HKL PASCAL GetMyHKL ()
{
	DWORD	dwSize ;
	DWORD	dwi ;
	HKL		hKL	= 0 ;
	HKL*	lphkl ;

	dwSize	= GetKeyboardLayoutList (0, NULL) ;
	lphkl	= (HKL *)GlobalAlloc(GPTR, dwSize * sizeof(DWORD)) ;
	if (!lphkl)
		return NULL ;
	GetKeyboardLayoutList (dwSize, lphkl) ;
	for (dwi = 0 ; dwi < dwSize ; dwi++){
		char	szFile [32] ;
		HKL		hKLTemp	= *(lphkl + dwi) ;
		ImmGetIMEFileName (hKLTemp, szFile, sizeof(szFile)) ;

		if (!lstrcmpi (szFile, MyFileName)){
			 hKL	= hKLTemp ;
			 goto	exit ;
		}
	}
exit:
	GlobalFree ((HANDLE)lphkl) ;
	return	hKL ;
}

/*
 *
 *	UpdateIndicIcon (hIMC)
 *
 */
void	PASCAL	UpdateIndicIcon (HIMC hIMC)
{
	HWND			hwndIndicate ;
	LPINPUTCONTEXT	lpIMC ;
	ATOM			atomTip ;
	int				iMode ;
	int				iIconIndex ;
	char*			pTipTable []		= {
		"���ړ���",	"���ȓ���",	"�J�i����",	"�S�p", "�A�X�L�[����", "����",
	} ;
	int				iIconIndexTbl []	= {
		6, 3, 4, 5, 2, 7,
	} ;
	if (!hMyKL){
	   hMyKL	= GetMyHKL () ;
	   if (!hMyKL)
		   return ;
	}
	hwndIndicate	= FindWindow (INDICATOR_CLASS, NULL) ;
	if (!IsWindow (hwndIndicate))
		return ;
	iMode			= 0 ;
	if (hIMC){
		if (ImmGetOpenStatus (hIMC)){
			lpIMC = ImmLockIMC (hIMC) ;
			if (lpIMC)
				iMode	= BTYFromCmode (lpIMC) / STATUS_BTNY ;
			ImmUnlockIMC (hIMC) ;
		}
	} else {
		iMode	= skkinput_hide_toolbar? 5 : 0 ;
	}
	if (!skkinput_hide_toolbar){
		atomTip		= GlobalAddAtom ("SKKIME98 Open") ;
		iIconIndex	= (iMode != 0)? 1 : (-1) ;
		PostMessage (hwndIndicate,					INDICM_SETIMEICON,
					 iIconIndex,					(LPARAM)hMyKL) ;
		PostMessage (hwndIndicate,					INDICM_SETIMETOOLTIPS,
					 (iMode != 0)? atomTip : (-1),	(LPARAM)hMyKL) ;
	} else {
		atomTip		= GlobalAddAtom (pTipTable [iMode]) ;
		iIconIndex	= iIconIndexTbl [iMode] ;
		PostMessage (hwndIndicate,					INDICM_SETIMEICON,
					 iIconIndex,					(LPARAM)hMyKL) ;
		PostMessage (hwndIndicate,					INDICM_SETIMETOOLTIPS,
					 atomTip,						(LPARAM)hMyKL) ;
	}
	PostMessage (hwndIndicate,						INDICM_REMOVEDEFAULTMENUITEMS,
				 (WPARAM)(skkinput_hide_toolbar)? (RDMI_LEFT | RDMI_RIGHT) : 0,
				 (LPARAM)hMyKL) ;
	return ;
}

/*
 *	�N���b�v�{�[�h����Ɋւ��� Context Menu ���쐬����֐��B
 */
HMENU	PASCAL	MyCreateClipboardMenu (LPMYCOMPSTR lpMyCompStr)
{
	static	MYMENUITEMINFO	myClipboardMenuItemInfoTbl []	= {
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,		IDM_CUT,			TEXT ("�؂���"), },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,		IDM_PASTE,			TEXT ("�\��t��"), },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,		IDM_COPY,			TEXT ("�R�s�["), },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,		IDM_DELETE,			TEXT ("�폜"), },
	  { MIIM_TYPE,
		MFT_SEPARATOR,	0,					0, },
	  { MIIM_STATE | MIIM_TYPE | MIIM_ID,
		MFT_STRING,		IDCANCEL,			TEXT ("�L�����Z��"), },
	} ;
	HMENU					hMenu ;
	LPMYMENUITEMINFO		lpMyMenu ;
	MENUITEMINFO			menuItemInfo ;
	int						i ;
	long					lStartPos, lEndPos, lMinibufLen ;

	/* �����̐������`�F�b�N�B*/
	if (!lpMyCompStr)
		return	0 ;
	hMenu		= CreatePopupMenu () ;
	if (!hMenu)
		return	0 ;
	/* �܂����j���[�̍��ڂ�ݒ肷��B*/
	lpMyMenu	= myClipboardMenuItemInfoTbl ;
	for (i = 0 ; i < 6 ; i ++){
		menuItemInfo.cbSize			= sizeof (MENUITEMINFO) ;
		menuItemInfo.fMask			= lpMyMenu->m_fMask ;
		menuItemInfo.fType			= lpMyMenu->m_fType ;
		menuItemInfo.wID			= lpMyMenu->m_wID ;
		menuItemInfo.fState			= MFS_ENABLED ;
		menuItemInfo.hbmpChecked	= NULL ;
		menuItemInfo.hbmpUnchecked	= NULL ;
		menuItemInfo.hbmpItem		= NULL ;
		menuItemInfo.dwTypeData		= lpMyMenu->m_dwTypeData ;
		menuItemInfo.cch			= lstrlen (menuItemInfo.dwTypeData) ;
		InsertMenuItem (hMenu, i, TRUE, (LPMENUITEMINFO)&menuItemInfo) ;
		lpMyMenu	++ ;
	}
	/* �̈�I�����L���ł��邩�ǂ����𔻒肷��B*/	
	lStartPos	= (long)lpMyCompStr->dwMinibufRegionStartPos ;
	lEndPos		= (long)lpMyCompStr->dwMinibufRegionEndPos ;
	lMinibufLen	= (long)lpMyCompStr->dwMinibufStrLen ;
	if (lStartPos == lEndPos || lMinibufLen <= 0 || 
		lStartPos < 0 || lEndPos < 0 ||
		lStartPos > lMinibufLen || lEndPos > lMinibufLen){
		EnableMenuItem (hMenu, 0, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 2, MF_BYPOSITION | MF_GRAYED) ;
		EnableMenuItem (hMenu, 3, MF_BYPOSITION | MF_GRAYED) ;
	}
	/* �N���b�v�{�[�h�Ƀe�L�X�g�����݂��邩�ǂ����`�F�b�N����B*/
	if (!IsClipboardFormatAvailable (CF_TEXT))
		EnableMenuItem (hMenu, 1, MF_BYPOSITION | MF_GRAYED) ;
	return	hMenu ;
}

