/* # SKKIME'98 (Simple Kana-Kanji Input Method Editor for Windows'98)
 * listbuf.c
 * This file is part of skkime'98.
 * Copyright (C) 1999
 * Takashi SAKAMOTO (tatari_sakamoto@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "windows.h"
#include "tchar.h"
#include "skkime98.h"
#include "listbuf.h"

/*
 * �V�����m�[�h�ɗp���郁�������m�ۂ���֐��B
 */
LPLISTBUFFER	PASCAL	SKKAllocListBuffer (void)
{
	LPLISTBUFFER	lpListBuffer ;
	lpListBuffer	= HeapAlloc (GetProcessHeap (), HEAP_ZERO_MEMORY, sizeof (LISTBUFFER)) ;
	if (lpListBuffer){
		lpListBuffer->text [0]	= MYTEXT ('\0') ;
		lpListBuffer->iUsed		= 0 ;
		lpListBuffer->lpNext	= NULL ;
	}
	return	lpListBuffer ;
}

/*
 * Search Vector �ɐV�����m�[�h��t��������֐��B
 */
LPLISTBUFFER	PASCAL	SKKAddListBuffer (LPLISTBUFFER lpListBufferTop, LPMYSTR lpStr, int iLength, LPLISTBUFFER FAR* lppListBufferRet, int FAR* lpiPosRet)
{
	LPLISTBUFFER	lpListBuffer ;
	LPLISTBUFFER	lpNextListBuffer ;
	int				iOverLen ;
	int				iUsed ;
	int				iCopyLength, iRest ;

	/* �擪�� NULL �������ꍇ�ɂ͐擪���m�ۂ���B*/
	if (lpListBufferTop == NULL){
		lpListBufferTop	= SKKAllocListBuffer () ;
		lpListBuffer	= lpListBufferTop ;
		iUsed			= 0 ;
	} else {
		lpListBuffer	= lpListBufferTop ;
		/* ��ԍŌ�̃m�[�h�����t����B*/
		while (lpListBuffer->lpNext)
			lpListBuffer	= lpListBuffer->lpNext ;
		iUsed			= lpListBuffer->iUsed ;
	}
	/* �o�^���J�n����擪�ʒu���L������B*/
	if (lppListBufferRet != NULL)
		*lppListBufferRet	= lpListBuffer ;
	if (lpiPosRet != NULL)
		*lpiPosRet			= iUsed ;

	/* �t���������������񂪋�łȂ��̂Ȃ�c�B*/
	if (iLength <= 0)
		iLength	= Mylstrlen (lpStr) ;
	while (lpListBuffer != NULL && iLength > 0){
		iRest						= TEXTBUFSIZE - 1 - iUsed ;
		iCopyLength					= (iLength < iRest)? iLength : iRest ;
		memcpy (lpListBuffer->text + iUsed, lpStr, iCopyLength * sizeof (MYCHAR)) ;
		iUsed						+= iCopyLength ;
		lpListBuffer->text [iUsed]	= MYTEXT ('\0') ;
		lpListBuffer->iUsed			= iUsed ;
		lpStr						+= iCopyLength ;
		iLength						-= iCopyLength ;
		if (iCopyLength > 0){
			lpNextListBuffer		= SKKAllocListBuffer () ;
			lpListBuffer->lpNext	= lpNextListBuffer ;
			iUsed					= 0 ;
		} else {
			lpNextListBuffer		= NULL ;
			lpListBuffer->lpNext	= NULL ;
		}
		lpListBuffer				= lpNextListBuffer ;
	}
	return	lpListBufferTop ;
}

/*
 * ���X�g���܂邲�Ɖ������֐��B
 */
BOOL	PASCAL	SKKFreeListBuffer (LPLISTBUFFER FAR* lppListBuffer)
{
	LPLISTBUFFER	lpListBuffer ;
	LPLISTBUFFER	lpNextListBuffer ;
	if (lppListBuffer == NULL)
		return	FALSE ;
	lpListBuffer	= *lppListBuffer ;
	while (lpListBuffer != NULL){
		lpNextListBuffer	= lpListBuffer->lpNext ;
		HeapFree (GetProcessHeap (), 0, lpListBuffer) ;
		lpListBuffer		= lpNextListBuffer ;
	}
	*lppListBuffer	= NULL ;
	return	TRUE ;
}

