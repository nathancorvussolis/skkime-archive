#pragma once

enum {
	KCODE_CHARSET_KATAKANA_JISX0201,
	KCODE_CHARSET_JAPANESE_JISX0208,
	KCODE_CHARSET_JAPANESE_JISX0212,
	KCODE_CHARSET_UNICODE,
} ;

BOOL	bSkkHexChar					(int) ;
int		iSkkCharToHex				(int) ;
BOOL	bJisx0208LatinCharp			(int) ;
BOOL	bHiraganaCharp				(int) ;
BOOL	bKatakanaCharp				(int) ;
BOOL	bCJKKanjip					(int) ;
BOOL	bSkkAsciiCharp				(int) ;
BOOL	bMakeUnicodeChar			(int, int, int, int*) ;
int		iSkkKatakanaToHiragana		(LPDSTR, int, LPCDSTR, int, BOOL) ;
int		iSkkHiraganaToKatakana		(LPDSTR, int, LPCDSTR, int, BOOL) ;
int		iSkkLatinToJisx0208Latin	(LPDSTR, int, LPCDSTR, int) ;
int		iSkkJisx0208LatinToLatin	(LPDSTR, int, LPCDSTR, int) ;
int		iSkkJisx0201Hankaku			(LPDSTR, int, LPCDSTR, int) ;
int		iSkkJisx0201Zenkaku			(LPDSTR, int, LPCDSTR, int) ;
int		iSkkComputeHenkanKey2		(LPDSTR, int, LPCDSTR, int, LPCDSTR, int) ;
int		iSkkNumComputeHenkanKey		(LPCDSTR, int, LPDSTR, int, LPDSTR, int, BOOL) ;
BOOL	bSettoji					(LPCDSTR, int) ;
BOOL	bSetsubiji					(LPCDSTR, int) ;
int		iConcatString				(LPDSTR, int, ...) ;
int		wmemindex					(LPCWSTR, LPCWSTR, int) ;
int		lstrncmpW					(LPCWSTR, LPCWSTR, int) ;
int		lstrncpyW					(LPWSTR, LPCWSTR, int) ;
void	vCopyString					(LPDSTR*, LPCDSTR, LPCDSTR) ;
void	vCopyStringW				(LPDSTR*, LPCDSTR, LPCWSTR) ;
void	vCopyStringN				(LPDSTR*, LPCDSTR, LPCDSTR, int) ;
void	vCopyStringNW				(LPDSTR*, LPCDSTR, LPCWSTR, int) ;
BOOL	bStringLispFormatp			(LPCDSTR, int) ;
BOOL	bStringNumericWordp			(LPCDSTR, int) ;
LPDSTR	pGetDString					(LPDSTR, int, LPCWSTR, int, int*) ;








