#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "TCutBufferSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
TCutBufferSession_bSet (
	LPCDSTR		pSrc,
	int			nSrc,
	BOOL		fAppend)
{
	struct CTPacket		packet ;
	HANDLE		hPipe ;
	int			nMajor, nMinor, nSize ;
	int			nRecv ;
	BOOL		fRetval	= FALSE ;

	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader  (&packet, SKKISERV_PROTO_SETCUTBUFFER, fAppend) ||
		! TPacket_bAddDString (&packet, pSrc, nSrc) ||
		! TPacket_bSetLength  (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	fRetval	= (nMajor == SKKISERV_PROTO_SETCUTBUFFER_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

int	
TCutBufferSession_iGet (
	LPDSTR		pDest,
	int			nDest)
{
	struct CTPacket	packet ;
	HANDLE		hPipe ;
	LPCWSTR		pwResult ;
	int			nRecv, nResult ;
	int			nMajor, nMinor, nSize ;
	WORD		wTotalResult ;
	LPDSTR		ptr				= pDest ;

	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader (&packet, SKKISERV_PROTO_GETCUTBUFFER, 0) ||
		! TPacket_bSetLength (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;

	if (! TCommunicateSession_bRecv (hPipe, &packet))
		goto	exit_func ;

	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;

	if (nMajor != SKKISERV_PROTO_GETCUTBUFFER_REPLY ||
		! TPacket_bGetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;

	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	pwResult	= (LPCWSTR)(TPacket_pGetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	if (wTotalResult > 0) {
		int			nTotalResult	= wTotalResult ;
		int			n ;
		LPCDSTR		pDestEnd		= pDest + nDest ;

		/*	����擾�����ʂ͂ǂ�����ATotal Size �𒴂��邱�Ƃ͂����Ă�
		 *	�Ȃ�Ȃ����B
		 */
		if (nResult > nTotalResult)
			nResult		= nTotalResult ;

		if (ptr < pDestEnd) {
			n	= wcstodcs_n (ptr, pDestEnd - ptr, pwResult, nResult) ;
			ptr				+= n ;
		}
		nTotalResult	-= nResult ;

		while (nTotalResult > 0 && ptr < pDestEnd) {
			if (! TCommunicateSession_bRecv (hPipe, &packet))
				break ;
			nRecv	= TPacket_iGetDataSize (&packet) ;
			if (nRecv < 0)
				break ;
			pwResult	= (LPCWSTR) TPacket_pGetData (&packet) ;
			nResult		= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;

			n	= wcstodcs_n (ptr, pDestEnd - ptr, pwResult, nResult) ;
			ptr	+= n ;
			nTotalResult	-= nResult ;
		}
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	ptr - pDest ;
}

