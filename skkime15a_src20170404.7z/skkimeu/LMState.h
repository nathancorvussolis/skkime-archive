#pragma once

int		LM_iMessageLoop			(struct CImeDoc*) ;
int		LM_bSelfInsertCharacter (struct CImeDoc*) ;
int		LM_bBackwardChar		(struct CImeDoc*) ;
int		LM_bForwardChar			(struct CImeDoc*) ;
int		LM_bDeleteChar			(struct CImeDoc*) ;
int		LM_bBackwardDeleteChar	(struct CImeDoc*) ;
int		LM_bTransposeChars		(struct CImeDoc*) ;
int		LM_bEndOfLine			(struct CImeDoc*) ;
int		LM_bBeginningOfLine		(struct CImeDoc*) ;
int		LM_bSetMarkCommand		(struct CImeDoc*) ;
int		LM_bKeyboardQuit		(struct CImeDoc*) ;
int		LM_bNextCommandEvent	(struct CImeDoc*) ;
int		LM_bReadFromMinibuffer	(struct CImeDoc*) ;
int		LM_bYesOrNop			(struct CImeDoc*) ;
int		LM_bAbortRecursiveEdit	(struct CImeDoc*) ;
int		LM_bExitRecursiveEdit	(struct CImeDoc*) ;
int		LM_bNewline				(struct CImeDoc*) ;
int		LM_bUnprecessEvent		(struct CImeDoc*) ;
int		LM_bBackwardWord		(struct CImeDoc*) ;
int		LM_bForwardWord			(struct CImeDoc*) ;

/*	skk-side
 */
int		LM_bSkkPreCommand			(struct CImeDoc*) ;
int		LM_bSkkPostCommand			(struct CImeDoc*) ;
int		LM_bSkkMode					(struct CImeDoc*) ;
int		LM_bSkkLatinMode			(struct CImeDoc*) ;
int		LM_bSkkJisx0208LatinMode	(struct CImeDoc*) ;
int		LM_bSkkAbbrevMode			(struct CImeDoc*) ;
int		LM_bSkkInsert				(struct CImeDoc*) ;
int		LM_bSkkEmulateOriginalMap	(struct CImeDoc*) ;
int		LM_bSkkSetHenkanPoint		(struct CImeDoc*) ;
int		LM_bSkkKanaInput			(struct CImeDoc*) ;
int		LM_bSkkHenkan				(struct CImeDoc*) ;
int		LM_bSkkSetHenkanPointSubr	(struct CImeDoc*) ;
int		LM_bSkkKakutei				(struct CImeDoc*) ;
int		LM_bSkkStartHenkan			(struct CImeDoc*) ;
int		LM_bSkkSetOkurigana			(struct CImeDoc*) ;
int		LM_bSkkPreviousCandidate	(struct CImeDoc*) ;
int		LM_bSkkDeleteBackwardChar	(struct CImeDoc*) ;
int		LM_bSkkTryCompletion		(struct CImeDoc*) ;
int		LM_bSkkAbbrevComma			(struct CImeDoc*) ;
int		LM_bSkkAbbrevPeriod			(struct CImeDoc*) ;
int		LM_bSkkToggleCharacters		(struct CImeDoc*) ;
int		LM_bSkkHiraganaRegion		(struct CImeDoc*) ;
int		LM_bSkkKatakanaRegion		(struct CImeDoc*) ;
int		LM_bSkkJisx0208LatinRegion	(struct CImeDoc*) ;
int		LM_bSkkLatinRegion			(struct CImeDoc*) ;
int		LM_bSkkJisx0208LatinInsert	(struct CImeDoc*) ;

int		LM_bSkkAdKeyboardQuit		(struct CImeDoc*) ;
int		LM_bSkkAdAbortRecursiveEdit	(struct CImeDoc*) ;
int		LM_bSkkAdExitMinibuffer		(struct CImeDoc*) ;

int		LM_bSkkAdNextLine			(struct CImeDoc*) ;
int		LM_bSkkAdPreviousLine		(struct CImeDoc*) ;
int		LM_bSkkAdNewline			(struct CImeDoc*) ;

int		LM_bSkkAutoStartHenkan		(struct CImeDoc*) ;
int		LM_bSkkInsertStr			(struct CImeDoc*) ;
int		LM_bSkkKanaCleanup			(struct CImeDoc*) ;
int		LM_bSkkToggleKutouten		(struct CImeDoc*) ;
int		LM_bSkkCurrentKuten			(struct CImeDoc*) ;
int		LM_bSkkCurrentTouten		(struct CImeDoc*) ;

int		LM_bSkkPurgeFromJisyo		(struct CImeDoc*) ;

int		LM_bSkkHenkanSkkRegionByFunc(struct CImeDoc*) ;

/*	skk-comp-side
 */
int		LM_bSkkComp					(struct CImeDoc*) ;
int		LM_bSkkCompDo				(struct CImeDoc*) ;
int		LM_bSkkCompPrevious			(struct CImeDoc*) ;
int		LM_bSkkCompPreviousNext		(struct CImeDoc*) ;

/*	skk-kcode-side
 */
int		LM_bSkkInputByCodeOrMenu	(struct CImeDoc*) ;

/*	�ǉ�: 
 */
int		LM_bSkkSetCharBeforeAsOkurigana	(struct CImeDoc*) ;

int		LM_bKillRegion				(struct CImeDoc*) ;
int		LM_bKillRingSave			(struct CImeDoc*) ;
int		LM_bYank					(struct CImeDoc*) ;

int		LM_bMouseDragRegion			(struct CImeDoc*) ;
int		LM_bMouseDragRegionEnd		(struct CImeDoc*) ;
int		LM_bMouseCopy				(struct CImeDoc*) ;
int		LM_bMouseCut				(struct CImeDoc*) ;
int		LM_bMousePaste				(struct CImeDoc*) ;
int		LM_bMouseDelete				(struct CImeDoc*) ;

/*	skk-gadget-side
 */
int		LM_bSkkToday				(struct CImeDoc*) ;

/*	skk-jisx0201-side
 */
int		LM_bSkkModeAdJisx0201				(struct CImeDoc* pThis) ;
int		LM_bSkkKakuteiAdJisx0201			(struct CImeDoc* pThis) ;
int		LM_bSkkLatinModeAdJisx0201			(struct CImeDoc* pThis) ;
int		LM_bSkkJisx0208LatinModeAdJisx0201	(struct CImeDoc* pThis) ;
int		LM_bSkkAbbrevModeAdJisx0201			(struct CImeDoc* pThis) ;
int		LM_bSkkSetOkuriganaAdJisx0201		(struct CImeDoc* pThis) ;
int		LM_bSkkInsertAdJisx0201				(struct CImeDoc* pThis) ;

int		LM_bSkkJisx0201ModeOn			(struct CImeDoc* pThis) ;
int		LM_bSkkJisx0201ZenkakuRegion	(struct CImeDoc* pThis) ;
int		LM_bSkkJisx0201Region			(struct CImeDoc* pThis) ;
int		LM_bSkkToggleKatakana			(struct CImeDoc* pThis) ;
int		LM_bSkkToggleJisx0201			(struct CImeDoc* pThis) ;
int		LM_bSkkJisx0201Mode				(struct CImeDoc* pThis) ;
int		LM_bSkkJisx0201Henkan			(struct CImeDoc* pThis) ;

