#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "TLispSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
TLispSession_bEval (
	LPCDSTR		dstrHenkanKey,
	int			nstrHenkanKey,
	LPDSTR		pdResult,
	int			nResultSize)
{
	struct CTPacket		packet ;
	HANDLE		hPipe ;
	int			nMajor = -1, nMinor, nSize ;
	WORD		wTotalResult ;
	LPCWSTR		wstrResult ;
	int			nResult, nRecv ;
	BOOL		fRetval	= FALSE ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader  (&packet, SKKISERV_PROTO_EVAL, 0) ||
		! TPacket_bAddDString (&packet, dstrHenkanKey, nstrHenkanKey) ||
		! TPacket_bSetLength  (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nMajor != SKKISERV_PROTO_EVAL_REPLY)
		goto	exit_func ;
	if (! TPacket_bGetCard16 (&packet, SKKISERV_PROTO_HEADER_SIZE, &wTotalResult))
		goto	exit_func ;
	if ((int)(wTotalResult * sizeof (WCHAR) + 2 + SKKISERV_PROTO_HEADER_SIZE) > nSize)
		goto	exit_func ;

	wstrResult	= (LPCWSTR)(TPacket_pGetData (&packet) + SKKISERV_PROTO_HEADER_SIZE + 2) ;
	nResult		= (nRecv - SKKISERV_PROTO_HEADER_SIZE - 2) / sizeof (WCHAR) ;
	if (wTotalResult > 0) {
		int		nTotalResult	= wTotalResult ;
		LPDSTR	pDest			= pdResult ;
		LPCDSTR	pDestEnd		= pdResult + nResultSize ;
		int		n ;

		if (nResult > nTotalResult)
			nResult		= nTotalResult ;

		n	= wcstodcs_n (pDest, pDestEnd - pDest, wstrResult, nResult) ;
		pDest			+= n ;
		nTotalResult	-= nResult ;

		while (nTotalResult > 0 && pDest < pDestEnd) {
			if (! TCommunicateSession_bRecv (hPipe, &packet))
				break ;
			nRecv	= TPacket_iGetDataSize (&packet) ;
			if (nRecv < 0)
				break ;
			wstrResult	= (LPCWSTR) TPacket_pGetData (&packet) ;
			nResult		= nRecv / sizeof (WCHAR) ;

			if (nResult > nTotalResult)
				nResult		= nTotalResult ;

			n	= wcstodcs_n (pDest, pDestEnd - pDest, wstrResult, nResult) ;
			pDest			+= n ;
			nTotalResult	-= nResult ;
		}
		if (pDest < pDestEnd) 
			*pDest	= L'\0' ;
		fRetval	= TRUE ;
	}
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}

BOOL
TLispSession_bSetNumberList (
	LPCDSTR	dstrNumberList)
{
	struct CTPacket		packet ;
	HANDLE		hPipe ;
	int			nMajor = -1, nMinor, nSize ;
	int			nRecv ;
	BOOL		fRetval	= FALSE ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;

	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader (&packet, SKKISERV_PROTO_SETJNUMLIST, 0))
		goto	exit_func ;
	if (dstrNumberList != NULL && *dstrNumberList != L'\0') {
		LPCDSTR		dptr ;
		int			ndptr ;

		if (! TPacket_bAddString (&packet, L"/", 1))
			goto	exit_func ;

		dptr	= dstrNumberList ;
		if (dptr != NULL) {
			while (dptr != L'\0') {
				ndptr	= dcslen (dptr) ;
				if (! TPacket_bAddDString (&packet, dptr, ndptr) ||
					! TPacket_bAddString  (&packet, L"/", 1))
					goto	exit_func ;
				dptr	+= ndptr + 1 ;
			}
		}
	}
	if (! TPacket_bSetLength (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	if (! TCommunicateSession_bRecv (hPipe, &packet))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
	if (nRecv < (SKKISERV_PROTO_HEADER_SIZE + 2))
		goto	exit_func ;
	if (! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	fRetval	= (nMajor == SKKISERV_PROTO_SETJNUMLIST_REPLY) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	fRetval ;
}


