#pragma once

#include "ImeBuffer.h"
#include "TMarker.h"
#include "RuleTreeIterator.h"

#define	MAXPREFIXLEN	(MAXCOMPLEN)
#define	MAXBUFMARKER	(16)

enum {
	LFALSE					= 0,
	LOFF					= LFALSE,
	LTRUE,
	LON						= LTRUE,
	LACTIVE,

	MAXLEN_PREFIX			= 256,
	MAXLEN_HENKAN_KEY		= 256,
	MAXLEN_HENKAN_OKURIGANA	= 256,

	MAXLEN_KAKUTEI_MIDASI	= MAXLEN_HENKAN_KEY,
	MAXLEN_KAKUTEI_WORD		= MAXCOMPLEN,
} ;

struct CImeDoc ;
struct CSkkRuleTreeNode ;
struct CTSearchSession ;

struct CImeBufferProperty {
	int							m_nBegin ;
	int							m_nEnd ;
	LPCDSTR						m_pwText ;
	int							m_nTextLen ;
	struct CImeBufferProperty*	m_pNext ;
} ;

struct CImeBuffer {
	struct CImeDoc*			m_pDoc ;
	struct CImeBuffer*		m_pParent ;

	/*	common buffer-local-variables
	 */
	DCHAR					m_bufComp [MAXCOMPLEN] ;
	int						m_nbufComp ;

	struct TMarker*			m_rpmkMarker [MAX_RESERVED_MARKERS] ;
	struct TMarker			m_rMarker [MAXBUFMARKER] ;
	int						m_nMarker ;

	/*	skk �� buffer-local-variables
	 */
	struct CSkkRuleTreeIterator	m_iteSkkRuleTree ;
	struct TMarker*				m_pmkPoint ;
	struct TMarker*				m_pmkMark ;
	struct TMarker*				m_pmkSkkKanaStartPoint ;
	struct TMarker*				m_pmkSkkPreviousPoint ;
	struct TMarker*				m_pmkSkkHenkanStartPoint ;
	struct TMarker*				m_pmkSkkHenkanEndPoint ;
	struct TMarker*				m_pmkSkkOkuriganaStartPoint ;

	DCHAR				m_bufSkkPrefix [MAXLEN_PREFIX] ;
	int					m_nSkkPrefixLen ;
	DCHAR				m_bufSkkHenkanKey [MAXLEN_HENKAN_KEY] ;
	int					m_nSkkHenkanKeyLen ;

	int					m_bSkkModeInvoked ;

	/* ���͂̏�ԂɊւ��郂�[�h�B*/
	int					m_bSkkMode ;
	int					m_bSkkLatinMode ;
	int					m_bSkkJMode ;
	int					m_bSkkJisx0208LatinMode ;
	int					m_bSkkAbbrevMode ;
	int					m_bSkkJisx0201Mode ;
	int					m_bSkkJisx0201Roman ;
	int					m_bSkkKatakana ;

	/* �ϊ�����Ɋւ��郂�[�h�B*/
	int					m_bSkkHenkanMode ;
//	int					m_bSkkHenkanOkurigana ;
	int					m_bSkkKakuteiFlag ;
	int					m_bSkkAfterPrefix ;

	int					m_bSkkHenkanInMinibuffFlag ;
	int					m_iSkkHenkanCount ;
	int					m_bSkkExitShowCandidates ;

	DCHAR				m_bufSkkHenkanOkurigana [MAXLEN_HENKAN_OKURIGANA] ;
	int					m_nSkkHenkanOkuriganaLen ;
	DCHAR				m_bufSkkOkuriChar [MAXLEN_HENKAN_OKURIGANA] ;
	int					m_nSkkOkuriCharLen ;
	int					m_bSkkOkurigana ;
	int					m_iSkkOkuriIndexMin ;
	int					m_iSkkOkuriIndexMax ;

	/* �m�藚���Ɋւ��� member variable */
	DCHAR				m_bufKakuteiMidasi [MAXLEN_KAKUTEI_MIDASI] ;
	int					m_nKakuteiMidasiLen ;
	DCHAR				m_bufKakuteiWord [MAXLEN_KAKUTEI_WORD] ;
	int					m_nKakuteiWordLen ;

	/* �ϊ���⌟���Ɋւ��� skk-current-search-prog-list �����c�B*/
	struct CTSearchSession*	m_pSkkCurrentSearchProgSession ;
	struct CTSearchSession*	m_pSkkCompSession ;

	/* #4 �o�^�̎��ɗ��p����B*/
	struct CTS4Mapping*	m_plstSkkS4NumericMapping ;

	/* ��Ǔ_�B*/
	int					m_bSkkCurrentKutotenType ;

	/* */
	DCHAR				m_bufLatestShiftText [MAXCOMPLEN] ;
	int					m_nLatestShiftTextLen ;

	BOOL				m_bSkkHenkanShowCandidatesMode ;
	BOOL				m_bSkkInputByCodeOrMenuMode ;
	BOOL				m_bSkkInputByCodeOrMenu1Mode ;

	/*	next-line, previous-line �̂��߂ɗ��p����B���Anext-line �� previous-line
	 *	���{���ɕK�v�Ȃ̂��H�Ƃ����^��́c����B
	 */
	int					m_nLineOffset ;

	/*	buffer property
	 */	
	struct CImeBufferProperty*	m_plstProperty ;
} ;

/*========================================================================
 *	prototyles
 */
#if defined (__cplusplus)
extern "C" {
#endif

BOOL	imeBuffer_bSkkKakuteiCleanupBuffer	(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkKakuteiInitialize		(struct CImeBuffer*, LPCDSTR, int) ;
BOOL	imeBuffer_bSkkInsertStr				(struct CImeBuffer*, LPCDSTR, int) ;

BOOL	imeBuffer_bSkkSetMarker				(struct CImeBuffer*, struct TMarker**, int, const struct TMarker*) ;
BOOL	imeBuffer_bSkkErasePrefix			(struct CImeBuffer*, BOOL) ;
BOOL	imeBuffer_bSkkInsertPrefix			(struct CImeBuffer*, LPCDSTR, int) ;
BOOL	imeBuffer_bSkkModeInvoke			(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkModeExit				(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkModeOff				(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkJModeOn				(struct CImeBuffer*, int) ;
BOOL	imeBuffer_bSkkLatinModeOn			(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkJisx0208LatinModeOn	(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkAbbrevModeOn			(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkJisx0201ModeOn		(struct CImeBuffer*, int) ;
BOOL	imeBuffer_bSkkChangeMarker			(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkChangeMarkerToWhite	(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkInsertStr				(struct CImeBuffer*, LPCDSTR, int) ;
BOOL	imeBuffer_bSkkKakuteiCleanupBuffer	(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkKakuteiInitialize		(struct CImeBuffer*, LPCDSTR, int) ;
BOOL	imeBuffer_bSkkMode					(struct CImeBuffer*, int) ;
BOOL	imeBuffer_bSkkUpdateKakuteiHistory	(struct CImeBuffer*, LPCDSTR, int, LPCDSTR, int) ;
BOOL	imeBuffer_bSkkDeleteHenkanMarkers	(struct CImeBuffer*, BOOL) ;
BOOL	imeBuffer_bSkkDeleteOkuriMark		(struct CImeBuffer*) ;
BOOL	imeBuffer_bSkkInsertNewWord			(struct CImeBuffer*, LPCDSTR, int) ;
BOOL	imeBuffer_bSkkNumUpdateJisyo		(struct CImeBuffer*) ;
int		imeBuffer_iSkkOkuriganaPrefix		(struct CImeBuffer*, LPCDSTR, int, LPDSTR, int) ;
LPCDSTR	imeBuffer_pSkkGetCurrentCandidate	(struct CImeBuffer*) ;
BOOL	imeBuffer_bValidRegionp				(struct CImeBuffer*, int, int) ;
#if !defined (UNITTEST)
BOOL	imeBuffer_bInitializeHenkanCandidateList	(struct CImeBuffer*, int) ;
BOOL	imeBuffer_bShowInputByCodeOrMenuJump		(struct CImeBuffer*, int, int, int, int, int, int, int, int) ;
BOOL	imeBuffer_bShowInputByCodeOrMenu1Jump		(struct CImeBuffer*, int, int, int, int, int, int, int, int, int) ;
#endif
#if defined (__cplusplus)
}
#endif


