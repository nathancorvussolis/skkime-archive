#pragma once

struct TMSG {
	int				m_nMessage ;
	WPARAM			m_wParam ;
	LPARAM			m_lParam ;
	unsigned int	m_rParam ;
	int				m_nTime ;
	POINT			m_pt ;
} ;

