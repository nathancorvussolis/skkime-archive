#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "TJisyoUpdateSession.h"
#include "TCommuSession.h"
#include "TPacket.h"
#include "TProtocol.h"

BOOL
TRecordSession_bUpdate (
	LPCDSTR		wstrHenkanKey,
	int			nstrHenkanKey,
	LPCDSTR		wstrResult,
	int			nstrResult,
	LPCDSTR		wstrOkurigana,
	int			nOkuriganaLen,
	BOOL		bOkurigana)
{
	struct CTPacket		packet ;
	HANDLE				hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader  (&packet, SKKISERV_PROTO_RECORD, bOkurigana) ||
		! TPacket_bAddDString (&packet, wstrHenkanKey, nstrHenkanKey)       ||
		! TPacket_bAddDString (&packet, wstrResult,    nstrResult)          ||
		! TPacket_bAddDString (&packet, wstrOkurigana, nOkuriganaLen)       ||
		! TPacket_bSetLength  (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_RECORD_REPLY) ;
}

BOOL
TPurgeSession_bUpdate (
	LPCDSTR		wstrHenkanKey,
	int			nstrHenkanKey,
	LPCDSTR		wstrResult,
	int			nstrResult,
	LPCDSTR		wstrOkurigana,
	int			nOkuriganaLen,
	BOOL		bOkurigana)
{
	struct CTPacket		packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader (&packet, SKKISERV_PROTO_PURGE, bOkurigana)	||
		! TPacket_bAddDString (&packet, wstrHenkanKey, nstrHenkanKey)		||
		! TPacket_bAddDString (&packet, wstrResult,    nstrResult)			||
		! TPacket_bAddDString (&packet, wstrOkurigana, nOkuriganaLen)		||
		! TPacket_bSetLength (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_PURGE_REPLY) ;
} 

BOOL
TJisyoSaveSession_bSynchronize (void) 
{
	struct CTPacket		packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader (&packet, SKKISERV_PROTO_SAVELOCALJISYO, 0) ||
		! TPacket_bSetLength (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_SAVELOCALJISYO_REPLY) ;
}

BOOL
TRecordKakuteiHistorySession_bUpdate (
	LPCDSTR		wstrMidasi,
	int			nMidasiLen,
	LPCDSTR		wstrWord,
	int			nWordLen)
{
	struct CTPacket			packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;
	
	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;
	
	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader  (&packet, SKKISERV_PROTO_RECORDKAKUTEIHISTORY, 0)	||
		! TPacket_bAddDString (&packet, wstrMidasi,		nMidasiLen)				||
		! TPacket_bAddDString (&packet, wstrWord,		nWordLen)				||
		! TPacket_bSetLength  (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;
	
	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_RECORDKAKUTEIHISTORY_REPLY) ;
}


