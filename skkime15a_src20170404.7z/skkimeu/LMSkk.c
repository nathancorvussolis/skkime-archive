#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "ImeDoc.h"
#include "ImeBufferP.h"
#include "TMarker.h"
#include "RuleTreeNode.h"
#include "keymap.h"
#include "TMSG.h"
#include "TSearchSession.h"
#include "TJisyoUpdateSession.h"
#include "lmstate.h"
#include "jstring.h"
#include "ImeConfig.h"

/*=================================================================================
 *	prototypes
 */
static	int		LM_bSkkProcessPrefixOrSuffix	(struct CImeDoc*) ;
static	int		LM_bSkkUpdateJisyo				(struct CImeDoc*) ;
static	int		LM_bSkkModeExit					(struct CImeDoc*) ;
static	int		LM_bSkkChangeMarker				(struct CImeDoc*) ;
static	int		LM_bSkkHenkan1					(struct CImeDoc*) ;
static	int		LM_bSkkHenkanInMinibuff			(struct CImeDoc*) ;
static	int		LM_bSkkHenkanShowCandidates		(struct CImeDoc*) ;
static	int		LM_bSkkRemoveCommon				(struct CImeDoc*) ;


/*================================================================ skk-pre-command
 */
int
LM_bSkkPreCommand (
	struct CImeDoc*		pDoc)
{
	static BYTE	_srSkkKanaCleanupCommandList []	= {
		NFUNC_SKK_UNDO,
		NFUNC_SKK_KAKUTEI,
		NFUNC_SKK_DELETE_BACKWARD_CHAR,
		NFUNC_SKK_INSERT,
		NFUNC_SKK_PREVIOUS_CANDIDATE,
	} ;
	int		i ;

	/*
	 *	(defun skk-pre-command ()
	 *  (when (and (memq last-command
	 *		   '(skk-insert skk-previous-candidate))
	 *	     (null (memq this-command
	 *			 skk-kana-cleanup-command-list)))
	 *    (skk-kana-cleanup t)))
	*/
	if (ImeDoc_iGetLastCommand (pDoc) != NFUNC_SKK_INSERT && 
		ImeDoc_iGetLastCommand (pDoc) != NFUNC_SKK_PREVIOUS_CANDIDATE) {
		return	LMR_RETURN ;
	}
	for (i = 0 ; i < ARRAYSIZE (_srSkkKanaCleanupCommandList) ; i ++)
		if (_srSkkKanaCleanupCommandList [i] == ImeDoc_iGetThisCommand (pDoc))
			return	LMR_RETURN ;
	ImeDoc_vSetRegBool (pDoc, LMREGARG_0, TRUE) ;
	ImeDoc_vJump (pDoc, LM_bSkkKanaCleanup) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-post-command
 */
int
LM_bSkkPostCommand (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nPrefix ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/*
	 * (defun skk-after-point-move ()
	 *	(when (and (not (and skk-previous-point
	 *				(= skk-previous-point (point))))
	 *				(skk-get-prefix skk-current-rule-tree))
	 *		(skk-with-point-move
	 *		(skk-erase-prefix 'clean))))
	 */
	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;

	if (! (pBuffer->m_pmkSkkPreviousPoint != NULL &&
		TMarker_iGetPosition (pBuffer->m_pmkSkkPreviousPoint) == TMarker_iGetPosition (pBuffer->m_pmkPoint)) && 
		(! SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) || SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) == NULL)) {
		imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	}

	/*	completion �̉����B���̃^�C�~���O�Ŏ��s����ׂ����H
	 */
	if (pBuffer->m_pSkkCompSession != NULL && ImeDoc_iGetThisCommand (pDoc) != NFUNC_SKK_COMP_DO) {
		TSearchSession_vDestroy (pBuffer->m_pSkkCompSession) ;
		pBuffer->m_pSkkCompSession	= NULL ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-insert
 */
static	int		LM_bSkkInsert_Exit				(struct CImeDoc*) ;

int
LM_bSkkInsert (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	BOOL	bRetval	= TRUE ;
	DCHAR	wch ;
	int		nPrefix ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetLastCommandChar (pDoc, &wch)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;

	if (pBuffer->m_bSkkHenkanMode && ImeConfig_bSkkSpecialMidashiCharp (wch)) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkProcessPrefixOrSuffix, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (ImeConfig_bSkkSetHenkanPointKeyp (wch) &&
		(pBuffer->m_bSkkOkurigana || 
		//pBuffer->m_pSkkCurrentRuleTree == NULL ||
		 ! SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) ||
		/*	(null (skk-get-prefix skk-current-rule-tree)) ����������̂́Askk-rule-tree ��
		 *	root ���w���Ă����ꍇ�ł���B
		 */
		 SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) == NULL ||
		 ! SkkRuleTreeIterator_bHaveSelectBranchp (piteSkkRuleTree, wch))) {
//		TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) == NULL || 
//		TSkkRuleTreeNode_pSelectBranch (pBuffer->m_pSkkCurrentRuleTree, wch) == NULL)) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPoint, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->m_bSkkHenkanMode && ImeConfig_bSkkStartHenkanCharp (wch)) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkStartHenkan, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->m_bSkkHenkanMode != LON) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkKanaInput, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->m_bSkkHenkanMode == LON && ImeConfig_bSkkTryCompletionCharp (wch)) {
		/* completion �̊J�n�B*/
		ImeDoc_vSetRegBool (pDoc, LMREGARG_0, (ImeDoc_iGetLastCommand (pDoc) != NFUNC_SKK_COMP_DO)? TRUE : FALSE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkCompDo, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else if (pBuffer->m_bSkkHenkanMode == LON && 
		(ImeConfig_bSkkNextCompletionCharp (wch) || ImeConfig_bSkkPreviousCompletionCharp (wch)) &&
		ImeDoc_iGetLastCommand (pDoc) == NFUNC_SKK_COMP_DO) {
		/* completion �̑����B*/
		ImeDoc_vSetRegInteger (pDoc, LMREGARG_0, wch) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkCompPreviousNext, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	} else {
		/* ����ȊO�B*/
		if (! ImeDoc_bCall (pDoc, LM_bSkkKanaInput, LM_bSkkInsert_Exit))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkInsert_Exit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/* skk-point-move �̌��ʁB*/
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}


/*================================================================ skk-process-prefix-or-suffix
 */
static	int		LM_bSkkProcessPrefixOrSuffix_1	(struct CImeDoc*) ;
static	int		LM_bSkkProcessPrefixOrSuffix_2	(struct CImeDoc*) ;
static	int		LM_bSkkProcessPrefixOrSuffix_3	(struct CImeDoc*) ;

int
LM_bSkkProcessPrefixOrSuffix (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	DCHAR	wch ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkProcessPrefixOrSuffix_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else if (pBuffer->m_bSkkHenkanMode == LON) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_0, TRUE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKanaCleanup, LM_bSkkProcessPrefixOrSuffix_3))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else if (ImeDoc_bGetLastCommandChar (pDoc, &wch)) {
		LPDSTR	pwString ;

		pwString	= ImeDoc_pAlloca (pDoc, sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pwString == NULL)
			return	LMR_ERROR ;
		*pwString	= wch ;
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwString, 1) ;
		ImeDoc_vJump (pDoc, LM_bSkkInsertStr) ;
		return	LMR_CONTINUE ;
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkEmulateOriginalMap) ;
		return	LMR_CONTINUE ;
	}
}

int
LM_bSkkProcessPrefixOrSuffix_1 (
	struct CImeDoc*		pDoc)
{
	if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPointSubr, LM_bSkkProcessPrefixOrSuffix_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkProcessPrefixOrSuffix_2 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	ImeBuffer_bInsertAndInheritW (pBuffer, L">", 1) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
LM_bSkkProcessPrefixOrSuffix_3 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nPoint, nHenkanStartPoint ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	ImeBuffer_bInsertAndInheritW (pBuffer, L">", 1) ;
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, pBuffer->m_pmkPoint) ;
	pBuffer->m_iSkkHenkanCount	= 0 ;
	nPoint				= (pBuffer->m_pmkPoint != NULL)? TMarker_iGetPosition (pBuffer->m_pmkPoint) : 0 ;
	nHenkanStartPoint	= (pBuffer->m_pmkSkkHenkanStartPoint != NULL)? TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) : 0 ;
	pBuffer->m_nSkkHenkanKeyLen	= nPoint - nHenkanStartPoint ;
	if (pBuffer->m_nSkkHenkanKeyLen > 0) {
		dcsncpy (pBuffer->m_bufSkkHenkanKey, pBuffer->m_bufComp + nHenkanStartPoint, (nPoint - nHenkanStartPoint));
	} else {
		pBuffer->m_nSkkHenkanKeyLen	= 0 ;
	}
	pBuffer->m_nSkkPrefixLen	= 0 ;
	pBuffer->m_bSkkAfterPrefix	= LTRUE ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkan) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kana-input
 */
static	int		LM_bSkkKanaInput_1		(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_1_1	(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_3		(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_3_1	(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_3_2	(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_4		(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_4_0	(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_4_0_1	(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_4_1	(struct CImeDoc*) ;
static	int		LM_bSkkKanaInput_Exit	(struct CImeDoc*) ;

/*	LMREG_0				nQueueLen
 *	LMREG_1				pwQueue
 *	LMREG_2				pData
 *	LMREG_3				pNext
 */
int
LM_bSkkKanaInput (
	struct CImeDoc*		pDoc)
{
	DCHAR*		pwQueue ;
	LPDSTR		pwBuffer ;
	int			nQueue ;

	pwQueue	= ImeDoc_pAlloca (pDoc, 64 * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwQueue == NULL)
		return	LMR_ERROR ;

	pwBuffer	= ImeDoc_pAlloca (pDoc, sizeof (DCHAR) * MAXCOMPLEN, __alignof (DCHAR)) ;
	if (pwBuffer == NULL)
		return	LMR_ERROR ;

	if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1) ||
		! ImeDoc_bPushReg (pDoc, LMREG_2) || ! ImeDoc_bPushReg (pDoc, LMREG_3) ||
		! ImeDoc_bPushReg (pDoc, LMREG_4) || ! ImeDoc_bPushReg (pDoc, LMREG_5))
		return	LMR_ERROR ;

	nQueue				= 0 ;
	pwQueue [nQueue ++]	= ImeDoc_iGetLastCommandChar (pDoc) ;
	ImeDoc_vSetRegInteger	(pDoc, LMREG_0, nQueue) ;
	ImeDoc_vSetRegString	(pDoc, LMREG_1, pwQueue,	64) ;
	ImeDoc_vSetRegString	(pDoc, LMREG_5, pwBuffer,	MAXCOMPLEN) ;
	ImeDoc_vJump (pDoc, LM_bSkkKanaInput_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaInput_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	DCHAR*		pwQueue ;
	int			nQueueLen, nQueueSize ;
//	LPCDSTR		pNextState ;
	LPCDSTR		pdPrefix ;
	int			nNextState, i, nPrefix ;
	DCHAR		bufNextState [64] ;
	DCHAR		bufTempNextState [16] ;
	struct CSkkRuleTreeNode*	pNext ;
	const struct CSkkRuleTreeNodeOutput*	pData	= NULL ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;
	if (! ImeDoc_bGetRegString  (pDoc, LMREG_1, &pwQueue, &nQueueSize)) {
		pwQueue		= NULL ;
		nQueueSize	= 0 ;
	}
	if (nQueueLen <= 0) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	if (! SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) || SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) == NULL) {
//	if (pBuffer->m_pSkkCurrentRuleTree == NULL || TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) == NULL) {
		/* ���̏ꏊ�������̊J�n�ʒu�Ƃ���B*/
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkKanaStartPoint, MARKER_SKK_KANA_START_POINT, pBuffer->m_pmkPoint) ;
		/* Rule-Tree �̍��ɖ߂�B*/
		SkkRuleTreeIterator_vMoveToRoot (piteSkkRuleTree) ;
//		pBuffer->m_pSkkCurrentRuleTree	= ImeConfig_pGetSkkRuleTree () ;
		pdPrefix	= NULL ;
		nPrefix	= 0 ;
	} else {
		imeBuffer_bSkkErasePrefix (pBuffer, FALSE) ;
		pdPrefix	= SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) ;
	}
	/* skk-prefix �� skk-get-prefix + last-command-char */
	if ((nPrefix + 1) > MAXLEN_PREFIX) {
		/* �v���t�B�N�X�o�b�t�@�[����ꂽ�ꍇ�c�B*/
		imeBuffer_bSkkErasePrefix (pBuffer, FALSE) ;
		pBuffer->m_nSkkPrefixLen		= 0 ;
		SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//		pBuffer->m_pSkkCurrentRuleTree	= NULL ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (nPrefix > 0) 
		dcsncpy (pBuffer->m_bufSkkPrefix, pdPrefix, nPrefix) ;
	pBuffer->m_bufSkkPrefix [nPrefix]	= ImeDoc_iGetLastCommandChar (pBuffer->m_pDoc) ;
	pBuffer->m_nSkkPrefixLen			= nPrefix + 1 ;

//	pNext	= TSkkRuleTreeNode_pSelectBranch (pBuffer->m_pSkkCurrentRuleTree, pwQueue [0]) ;
	pData	= NULL ;
	if (SkkRuleTreeIterator_bHaveSelectBranchp (piteSkkRuleTree, pwQueue [0])) {
//	if (pNext != NULL) {
		if (SkkRuleTreeIterator_bNextHasBranchListp (piteSkkRuleTree, pwQueue [0])) {
			int		iCH ;
//		if (TSkkRuleTreeNode_pGetBranchList (pNext) != NULL) {
			if (pBuffer->m_bSkkHenkanMode == LACTIVE &&
				ImeConfig_bSkkKakuteiEarlyp () && !ImeConfig_bSkkProcessOkuriEarlyp ()) {
				/* !! */
				ImeDoc_vSetRegConstString	(pDoc, LMREGARG_0, NULL, 0) ;
				ImeDoc_vSetRegInteger		(pDoc, LMREG_0, nQueueLen) ;
				ImeDoc_vSetRegConstPointer	(pDoc, LMREG_2, pData) ;
				ImeDoc_vSetRegInteger		(pDoc, LMREG_3, pwQueue [0]) ;
//				ImeDoc_vSetRegPointer		(pDoc, LMREG_3, pNext) ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_1_1))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			}
			iCH	= pwQueue [0] ;
			memmove (pwQueue, pwQueue + 1, sizeof (pwQueue [0]) * (nQueueLen - 1)) ;
			nQueueLen	-- ;
			SkkRuleTreeIterator_vWalk (piteSkkRuleTree, iCH) ;
//			pBuffer->m_pSkkCurrentRuleTree	= pNext ;
		} else {
//			LPCDSTR	pNextState ;
			int		nNextState, i, nNextTree ;

			SkkRuleTreeIterator_vWalk (piteSkkRuleTree, pwQueue [0]) ;
			pData		= SkkRuleTreeIterator_pGetOutput (piteSkkRuleTree) ;
			nNextState	= SkkRuleTreeIterator_iGetNextState (piteSkkRuleTree, bufNextState, ARRAYSIZE (bufNextState), &nNextTree) ;
			SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, nNextTree) ;
//			pData		= TSkkRuleTreeNode_pGetOutput (pNext) ;
//			pNextState	= TSkkRuleTreeNode_pGetNextState (pNext, &nNextState) ;
			if ((nNextState + nQueueLen - 1) < nQueueSize) {
				memmove (pwQueue + nNextState, pwQueue + 1, sizeof (pwQueue [0]) * (nQueueLen - 1)) ;
				for (i = 0 ; i < nNextState ; i ++)
					pwQueue [i]	= bufNextState [i] ;
				nQueueLen	= nNextState + nQueueLen - 1 ;
			} else {
				/* �L���[����ꂽ�ꍇ�c�B���̏������������̂��ǂ����͓�B*/
				SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//				pBuffer->m_pSkkCurrentRuleTree	= NULL ;

				/* exit state �ցB*/
				ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
				return	LMR_CONTINUE ;
			}
			SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//			pBuffer->m_pSkkCurrentRuleTree	= NULL ;
		}
	} else {
		const struct CSkkRuleTreeNodeOutput*	pD ;

		pD	= SkkRuleTreeIterator_pGetOutput (piteSkkRuleTree) ;
//		pD	= pBuffer->m_pSkkCurrentRuleTree != NULL? TSkkRuleTreeNode_pGetOutput (pBuffer->m_pSkkCurrentRuleTree) : NULL ;
		if (pD != NULL) {
			int		nNextTree ;

			nNextState	= 0 ;
			pData		= pD ;
			if (SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree)) {
				nNextState	= SkkRuleTreeIterator_iGetNextState (piteSkkRuleTree, bufNextState, ARRAYSIZE (bufNextState), &nNextTree) ;
			} else {
				nNextTree	= SkkRuleTreeIterator_iGetRuleTree (piteSkkRuleTree) ;
			}
			SkkRuleTreeIterator_vMoveTree (piteSkkRuleTree, nNextTree) ;

//			pNextState	= NULL ;
//			if (pBuffer->m_pSkkCurrentRuleTree != NULL) 
//				pNextState	= TSkkRuleTreeNode_pGetNextState (pBuffer->m_pSkkCurrentRuleTree, &nNextState) ;
			if ((nNextState + nQueueLen) < nQueueSize) {
				if (nNextState > 0) {
					memmove (pwQueue + nNextState, pwQueue, sizeof (pwQueue [0]) * nQueueLen) ;
					for (i = 0 ; i < nNextState ; i ++)
						pwQueue [i]	= bufNextState [i] ;
					nQueueLen	= nNextState + nQueueLen ;
				}
			} else {
				/* �L���[����ꂽ�ꍇ�c�B���̏������������̂��ǂ����͓�B*/
				SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//				pBuffer->m_pSkkCurrentRuleTree	= NULL ;

				/* exit state �ցB*/
				ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
				return	LMR_CONTINUE ;
			}
			SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//			pBuffer->m_pSkkCurrentRuleTree	= NULL ;
		} else {
#if 0
			const struct CSkkRuleTreeNodeOutput*	pDD	= NULL ;

			/*	skk-kana-input-search-function �� ``oh'' �ϊ������邩�ۂ��� check �ɕύX����B
			 *	�C�ӂ� lisp function �����s����`���Ƃ����͔̂�����B
			 *	���� oh �ɂ��Ă� preceding-char ��K�v�Ƃ��錵�����������@�ł��邽�߁c���Ȃ�
			 *	�����B
			 *	(defcustom skk-kana-input-search-function
			 *	  #'(lambda ()
			 *		  (save-match-data
			 *		(and (string-match "^h\\([bcdfghjklmnpqrstvwxz]\\)$" skk-prefix)
			 *			 (member (char-to-string (preceding-char)) '("��" "�I"))
			 *			 (cons '("�I" . "��") (match-string 1 skk-prefix)))))
			 *
			 *	���� ad hoc �Ȍ`�� code �ɖ��ߍ���ł���c�B
			 */
			if (TRUE && 
				pBuffer->m_nSkkPrefixLen == 2 && pBuffer->m_bufSkkPrefix [0] == L'h' && (L'b' <= pBuffer->m_bufSkkPrefix [1] && pBuffer->m_bufSkkPrefix [1] <= L'z') &&
				pBuffer->m_bufSkkPrefix [1] != L'e' && pBuffer->m_bufSkkPrefix [1] != L'i' && pBuffer->m_bufSkkPrefix [1] != L'o' && pBuffer->m_bufSkkPrefix [1] != L'u') {
				/*	������ preceding-char �����邱�ƂɂȂ�B
				 */
				int		nPoint			= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
				int		nPrecedingChar	= -1 ;

				if (0 < nPoint && nPoint <= pBuffer->m_nbufComp) {
					nPrecedingChar	= pBuffer->m_bufComp [nPoint - 1] ;
				} else if (nPoint == 0) {
					/*	���O�ɃA�v���P�[�V�����ɓn���������̍Ō�ƂƂ�B
					 *	�������A���́u���O�Ɂv���N���A������@�́c�p�ӂ��؂��̂��낤���H
					 */
					nPrecedingChar	= (pBuffer->m_nLatestShiftTextLen > 0)? pBuffer->m_bufLatestShiftText [pBuffer->m_nLatestShiftTextLen - 1] : -1 ;
				}
				if (nPrecedingChar == L'��' || nPrecedingChar == L'�I') {
					pDD			= ImeConfig_pGetOhRuleTreeNodeOutput () ;
					/*pDD		= TSkkRuleTreeNodeOutput_pCreateStringPairInstance (L"��", 1, L"�I", 1) ;*/

					pNextState	= bufTempNextState ;
					nNextState	= 1 ;
					bufTempNextState [0]	= pBuffer->m_bufSkkPrefix [1] ;
				}
			} else {
				pDD	= NULL ;
			}
			if (pDD != NULL) {
				/*					  (setq data (car dd)
										queue (nconc (string-to-char-list (cdr dd))
													 (cdr queue))
				 */
				if ((nNextState + nQueueLen - 1) < nQueueSize) {
					memmove (pwQueue + nNextState, pwQueue + 1, sizeof (pwQueue [0]) * (nQueueLen - 1)) ;
					for (i = 0 ; i < nNextState ; i ++)
						pwQueue [i]	= pNextState [i] ;
					nQueueLen	= nQueueLen + nNextState - 1 ;
				} else {
					SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//					pBuffer->m_pSkkCurrentRuleTree	= NULL ;

					/* exit state �ցB*/
					ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
					return	LMR_CONTINUE ;
				}
				pData							= pDD ;
				SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//				pBuffer->m_pSkkCurrentRuleTree	= NULL ;
			} else if (SkkRuleTreeIterator_bRootp (piteSkkRuleTree)) {
//			} else if (pBuffer->m_pSkkCurrentRuleTree == ImeConfig_pGetSkkRuleTree ()) {
				nQueueLen						= 0 ;
				SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//				pBuffer->m_pSkkCurrentRuleTree	= NULL ;
			} else {
				SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
//				pBuffer->m_pSkkCurrentRuleTree	= NULL ;
			}
#else
			/*	oh ���Ȃ���΁ApDD == NULL �͕K�������B
			 */
			if (SkkRuleTreeIterator_bRootp (piteSkkRuleTree)) {
				nQueueLen						= 0 ;
				SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
			} else {
				SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
			}
#endif
		}
	}


	ImeDoc_vSetRegInteger		(pDoc, LMREG_0, nQueueLen) ;
	ImeDoc_vSetRegConstPointer	(pDoc, LMREG_2, pData) ;

	/* pData ���n���Ȃ��Ƃ����Ȃ��B*/
	ImeDoc_vJump (pDoc, LM_bSkkKanaInput_3) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaInput_1_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	DCHAR*		pwQueue ;
	int			nQueueLen, nQueueSize ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;
	int			wch ;
//	struct CSkkRuleTreeNode*	pNext ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;
	if (! ImeDoc_bGetRegString  (pDoc, LMREG_1, &pwQueue, &nQueueSize)) {
		pwQueue		= NULL ;
		nQueueSize	= 0 ;
	}

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	if (ImeDoc_bGetRegInteger (pDoc, LMREG_3, &wch)) {
		SkkRuleTreeIterator_vWalk (piteSkkRuleTree, wch) ;
	} else {
		SkkRuleTreeIterator_vReset (piteSkkRuleTree) ;
	}
//	if (! ImeDoc_bGetRegPointer (pDoc, LMREG_3, &pNext)) 
//		pNext	= NULL ;

	/* !! */
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkKanaStartPoint, MARKER_SKK_KANA_START_POINT, pBuffer->m_pmkPoint) ;

	memmove (pwQueue, pwQueue + 1, sizeof (pwQueue [0]) * (nQueueLen - 1)) ;
	nQueueLen	-- ;
//	pBuffer->m_pSkkCurrentRuleTree	= pNext ;

	ImeDoc_vSetRegInteger (pDoc, LMREG_0, nQueueLen) ;
	ImeDoc_vJump (pDoc, LM_bSkkKanaInput_3) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaInput_3 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int						nQueueLen ;
	LPCDSTR					pPrefix ;
	int						nPrefix ;
	struct CSkkRuleTreeIterator*			piteSkkRuleTree ;
	const struct CSkkRuleTreeNodeOutput*	pData	= NULL ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;
	if (! ImeDoc_bGetRegConstPointer (pDoc, LMREG_2, &pData))
		pData	= NULL ;

	if (pData == NULL) {
		pPrefix	= SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) ;
//		pPrefix	= (pBuffer->m_pSkkCurrentRuleTree != NULL)? TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) : NULL ;
		if (pPrefix != NULL && nPrefix > 0) {
			dcsncpy (pBuffer->m_bufSkkPrefix, pPrefix, nPrefix) ;
			pBuffer->m_nSkkPrefixLen	= nPrefix ;
			imeBuffer_bSkkInsertPrefix (pBuffer, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;
		} else {
			if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
				/* !! */
				ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_3_1))
					return	LMR_ERROR ;
				/* !! */
			} else {
				ImeDoc_vJump (pDoc, LM_bSkkKanaInput_3_1) ;
			}
			return	LMR_CONTINUE ;
		}
		//ImeDoc_vJump (pDoc, LM_bSkkKanaInput_1) ;
		//return	LMR_CONTINUE ;
	} else {
		int		nType ;

		pBuffer->m_nSkkPrefixLen	= 0 ;
		/*
		 *	  (when (functionp data)
		 *		(setq data (funcall data (skk-make-raw-arg arg))))
		 */
		/*	�ǂ��g���������̂��Y�ނ��ǁAdata �� stringp �̂��Ƃ������̎����ł͍l���Ȃ��B
		 *	���R�́c�����炻�̃R�[�h�������ɂ́A��񂪑���Ȃ�����B�����܂����̂��A�ǂ�
		 *	�����������ǂ������̂��A�ォ��ēx���������B
		 */
		nType	= TSkkRuleTreeNodeOutput_iGetType (pData) ;
		if (nType == NTYPE_MACRO) {
			int		nFuncNo ;

			/* �����c�B*/
			if (TSkkRuleTreeNodeOutput_bGetMacro (pData, &nFuncNo)) {
				PLMFUNC	pPC ;
				/* !! */
				pPC		= ImeDoc_pLookupLMState (pDoc, nFuncNo) ;
				if (pPC != NULL) {
					/*	argument �� clear ���Ă����K�v������Ǝv���c�����B
					 *	����Aarg �͓����I�ɂ����g��Ȃ����� call-interactive �� function
					 *	�� nil ���Ǝv������ł��邵���v���H
					 *	(Fri Jun 09 12:01:33 2006)
					 */
					if (! ImeDoc_bCall (pDoc, pPC, LM_bSkkKanaInput_3_2))
						return	LMR_ERROR ;
					return	LMR_CONTINUE ;
				}
				/* !! */
			}
			/*	�I�I ������ loop �̓��ɖ߂�̂͗ǂ��Ȃ��̂�������Ȃ����ǁc�B
			 *	���� '("" . "") �Ȍ��ʂ� macro ���Ԃ���Ƃ��ĂȂ��̂Łc
			 *	�����A�Ԃ�l��p�̃��W�X�^�Ƃ��p�ӂ��Ȃ��Ɩ{���͑ʖڂ����c�B
			 *	�ƂȂ�ƁALMR_RETURN ���鎞�� set ���Ȃ��Ƃ����Ȃ��ȁc�B
			 */
			ImeDoc_vJump (pDoc, LM_bSkkKanaInput_1) ;
			return	LMR_CONTINUE ;
		}
		if (nType == NTYPE_STRINGPAIR || nType == NTYPE_STRING) {
			LPCDSTR		wptr ;
			int			nwptr ;

			if (nType == NTYPE_STRINGPAIR) {
				if (pBuffer->m_bSkkKatakana) {
					if (! TSkkRuleTreeNodeOutput_bGetRString (pData, &wptr, &nwptr)) {
						wptr	= NULL ;
						nwptr	= 0 ;
					}
				} else {
					if (! TSkkRuleTreeNodeOutput_bGetLString (pData, &wptr, &nwptr)) {
						wptr	= NULL ;
						nwptr	= 0 ;
					}
				}
			} else {
				if (! TSkkRuleTreeNodeOutput_bGetString (pData, &wptr, &nwptr)) {
					wptr	= NULL ;
					nwptr	= 0 ;
				}
			}
			/* insert-paren �� through �c�B*/
			if (pBuffer->m_bSkkHenkanMode == LACTIVE &&
				ImeConfig_bSkkKakuteiEarlyp () && !ImeConfig_bSkkProcessOkuriEarlyp ()) {
				/* !! */
				ImeDoc_vSetRegString (pDoc, LMREGARG_0, NULL, 0) ;
				/* wptr, nwptr �� heap �̏���w���Ă���̂ŁA�����ł͉������Ȃ��ƍl���ėǂ��B*/
				ImeDoc_vSetRegConstString (pDoc, LMREG_4, wptr, nwptr) ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_4))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
				/* !! */
			}
			ImeDoc_vSetRegConstString (pDoc, LMREG_4, wptr, nwptr) ;
			ImeDoc_vJump (pDoc, LM_bSkkKanaInput_4) ;
			return	LMR_CONTINUE ;
		}
	}
	/*
	 */
	ImeDoc_vJump (pDoc, LM_bSkkKanaInput_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaInput_3_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int						nQueueLen ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;

	pBuffer->m_nSkkPrefixLen	= 0 ;
	if (! (nQueueLen > 0 || (ImeDoc_iGetThisCommand (pBuffer->m_pDoc) != NFUNC_SKK_INSERT && pBuffer->m_bSkkHenkanMode))) {
		/* !! */
		if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkKanaInput_1))
			return	LMR_ERROR ;
		/* !! */
		return	LMR_CONTINUE ;
	}
	/* while (nQueueLen > 0) �̃��[�v�̓��ւƖ߂�B*/
	ImeDoc_vJump (pDoc, LM_bSkkKanaInput_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaInput_3_2 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPDSTR					pwBuffer ;
	LPDSTR					pwString = NULL, pwLeft = NULL, pwRight = NULL ;
	LPCDSTR					pwResult ;
	int						nString, nLeft, nRight, n, nResultLen, nBufferSize ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	pwResult	= NULL ;
	nResultLen	= 0 ;
	if (! ImeDoc_bGetRegString (pDoc, LMREG_5, &pwBuffer, &nBufferSize)) {
		pwBuffer	= NULL ;
		nBufferSize	= 0 ;
	}

	/*	���͂��́upwString�v�͒N���m�ۂ����̈�Ȃ̂��Ƃ������Ƃ��B���̊֐������O�ɗp�ӂ��Ă���
	 *	�Ƃ����͓̂���Bargument �ɓ����Ƃ����̂́u�C�ӂ� function ���Ă΂�邩���v�̏󋵂ł�
	 *	���������ɂȂ��Bheap �̂悤�Ȃ��̂�p�ӂ���K�v������̂��낤���c�B
	 *
	 *	return buffer �Ƃ������̂�p�ӂ��邩�BRETVAL �̊g�������BLMREGARG_RETVAL �Ɠ����x�̊��Ԓ��x
	 *	�����ێ�����Ȃ� funcall �������Ă̎󂯓n���̂��߂ɂ����g����̈�B
	 *	������Areturn ���Ė߂������͑����� my heap �� my stack �ɃR�s�[���ăf�[�^��ی삵�Ȃ��Ƃ���
	 *	�Ȃ��B
	 *	return buffer �� document class ��1���������Ă���B
	 */
	if (ImeDoc_bGetRegConstString (pDoc, LMREGARG_RETVAL, &pwString, &nString)) {
		/*	���� pwString �� m_bufRETURN ���w���Ă���̂ŁAFREE �͂��Ȃ��ŗǂ��B(�Ƃ��������ɂ���)
		 */
		if (pwString != NULL && nString > 0) {
			n			= MIN (nString, nBufferSize) ;
			dcsncpy (pwBuffer, pwString, n) ;
			pwResult	= pwBuffer ;
			nResultLen	= n ;
		}
	} else if (ImeDoc_bGetRegConstStringPair (pDoc, LMREGARG_RETVAL, &pwLeft, &nLeft, &pwRight, &nRight)) {
		/*	���� pwLeft, pwRight �� m_bufRETURN ���w���Ă���̂ŁAFREE �͂��Ȃ��ŗǂ��B(�Ƃ���������
		 *	����)
		 */
		pwString	= (pBuffer->m_bSkkKatakana)? pwRight : pwLeft ;
		nString		= (pBuffer->m_bSkkKatakana)? nLeft   : nRight ;
		if (pwString != NULL && nString > 0) {
			n			= MIN (nString, nBufferSize) ;
			dcsncpy (pwBuffer, pwString, n) ;
			pwResult	= pwBuffer ;
			nResultLen	= n ;
		}
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_1) ;
		return	LMR_CONTINUE ;
	}
	/* insert-paren �� through �c�B*/
	if (pBuffer->m_bSkkHenkanMode == LACTIVE &&
		ImeConfig_bSkkKakuteiEarlyp () && !ImeConfig_bSkkProcessOkuriEarlyp ()) {
		ImeDoc_vSetRegString (pDoc, LMREGARG_0, NULL, 0) ;
		/* wptr, nwptr �� heap �̏���w���Ă���̂ŁA�����ł͉������Ȃ��ƍl���ėǂ��B*/
		ImeDoc_vSetRegConstString (pDoc, LMREG_4, pwString, nString) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkKanaInput_4))
			return	LMR_ERROR ;
	} else {
		ImeDoc_vSetRegConstString (pDoc, LMREG_4, pwString, nString) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_4) ;
	}
	return	LMR_CONTINUE ;
}

/*	skk-kana-input �� skk-insert-str �����̏����Bdata ���m�肵�� buffer �ɕ����񂪑}�������B
 */
int
LM_bSkkKanaInput_4 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPCDSTR					wptr ;
	int						nwptr ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_4, &wptr, &nwptr)) {
		wptr	= NULL ;
		nwptr	= 0 ;
	}
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, wptr, nwptr) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkInsertStr, LM_bSkkKanaInput_4_0))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

/*	skk-kana-input �r���ł� skk-auto-insert-paren �̏����Bbuffer �ɑ}�����ꂽ����������āAparen
 *	�Ȃ� pair ��ǉ��B
 */
int
LM_bSkkKanaInput_4_0 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPCDSTR					wptr ;
	int						nwptr ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_4, &wptr, &nwptr)) {
		wptr	= NULL ;
		nwptr	= 0 ;
	}
	/*	skk-auto-insert-paren �̏����B
	 */
	if (nwptr > 0 && ImeConfig_bSkkAutoInsertParen ()) {
		DCHAR	bufPairStr [MAXCOMPLEN] ;
		int		nPairStr ;

			/*
		      (when pair
				(while (> count1 0)
				  (if (not (string= pair (char-to-string (following-char))))
				      (progn
						(setq inserted (1+ inserted))
						(skk-insert-str pair)))
				  (setq count1 (1- count1)))
				(unless (= inserted 0)
				  (backward-char inserted)))
				  */
		nPairStr	= ImeConfig_iSkkAssocSkkAutoParenStringAlist (wptr, nwptr, bufPairStr, ARRAYSIZE (bufPairStr)) ;
		if (nPairStr > 0) {
			if (! ImeBuffer_bFollowingStringEqualp (pBuffer, bufPairStr, nPairStr)) {
				LPDSTR	pwBuffer ;
				int		n, nBufferSize ;

				/*	LMREG_5 �Ɋm�ۂ���Ă����o�b�t�@�𗘗p����B
				 *	����́Aparen ����Ɏg���� result ��ێ����Ă����ꏊ�ł��邪�A
				 *	���� result �͎g��Ȃ��̂ŁB
				 */
				if (! ImeDoc_bGetRegString (pDoc, LMREG_5, &pwBuffer, &nBufferSize)) {
					pwBuffer	= NULL ;
					nBufferSize	= 0 ;
				}
				n	= MIN (nBufferSize, nPairStr) ;
				if (n > 0)
					dcsncpy (pwBuffer, bufPairStr, n) ;
				ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwBuffer, n) ;

				/*	���݂̃J�[�\���ʒu���L������c�B�{���̓}�[�J���g�������̂����c�X�^�b�N���
				 *	�}�[�J��������Ɖ���ł��邩�ǂ����������̂ŁB(�G���[�A��O�����̓r����)
				 *
				 *	������ REG_4 �� integer �ɕς��Ă��܂��Ă���B
				 */
				ImeDoc_vSetRegInteger (pDoc, LMREG_4, TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;

				if (! ImeDoc_bCall (pDoc, LM_bSkkInsertStr, LM_bSkkKanaInput_4_0_1))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			}
		}
	}
	ImeDoc_vJump (pDoc, LM_bSkkKanaInput_4_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaInput_4_0_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int	nPoint ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL && ImeDoc_bGetRegInteger (pDoc, LMREG_4, &nPoint)) {
		int		nCurPoint ;
		nCurPoint	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
		ImeBuffer_bBackwardChar (pBuffer, nCurPoint - nPoint) ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkKanaInput_4_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaInput_4_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int						nQueueLen ;

	/* Exit-State �͕K���o�R���Ȃ��Ƃ����Ȃ��B*/
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nQueueLen))
		nQueueLen	= 0 ;

	if (pBuffer->m_bSkkOkurigana && nQueueLen <= 0) {
		/* !! */
		if (! ImeDoc_bCall (pDoc, LM_bSkkSetOkuriganaAdJisx0201, LM_bSkkKanaInput_1))
			return	LMR_ERROR ;
		/* !! */
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput_1) ;
	}
	return	LMR_CONTINUE ;
}


int
LM_bSkkKanaInput_Exit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
	} else {
		/* skk-point-move �̌��ʁB*/
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	}

	/* ������ pop ������ signal �̗L���Ɋւ�炸���s���Ȃ���΂Ȃ�Ȃ��B*/
	ImeDoc_vPopReg (pDoc, LMREG_5) ;
	ImeDoc_vPopReg (pDoc, LMREG_4) ;
	ImeDoc_vPopReg (pDoc, LMREG_3) ;
	ImeDoc_vPopReg (pDoc, LMREG_2) ;
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-start-henkan
 */
static	int	LM_bSkkStartHenkan_1	(struct CImeDoc*) ;
static	int	LM_bSkkStartHenkan_2	(struct CImeDoc*) ;

int
LM_bSkkStartHenkan (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
		pBuffer->m_iSkkHenkanCount	++ ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkan) ;
	} else {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_0, TRUE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKanaCleanup, LM_bSkkStartHenkan_1))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkStartHenkan_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nPrefix, nPos, nHenkanStartPoint ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	if (SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) && SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) != NULL) {
//	if (pBuffer->m_pSkkCurrentRuleTree != NULL && TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) != NULL) {
		/* skk-error "Have unfixed skk-prefix" */
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	nPos	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
	if (pBuffer->m_pmkSkkHenkanStartPoint == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	nHenkanStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
	if (nPos < nHenkanStartPoint) {
		/* skk-error "Henkan end point must be after henkan start point" */
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_nSkkHenkanKeyLen	= nPos - nHenkanStartPoint ;
	dcsncpy (pBuffer->m_bufSkkHenkanKey, pBuffer->m_bufComp + nHenkanStartPoint, pBuffer->m_nSkkHenkanKeyLen) ;
	if (pBuffer->m_bSkkKatakana) {
		pBuffer->m_nSkkHenkanKeyLen	= iSkkKatakanaToHiragana (pBuffer->m_bufSkkHenkanKey, ARRAYSIZE (pBuffer->m_bufSkkHenkanKey), pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, FALSE) ;
	}
	if (pBuffer->m_bSkkOkurigana) {
		int		i ;

		for (i = pBuffer->m_nSkkHenkanKeyLen - 1 ; i >= 0 ; i --) {
			if (pBuffer->m_bufSkkHenkanKey [i] != L' ')
				break ;
		}
		if (i < 0 || pBuffer->m_bufSkkHenkanKey [i] == L'*') {
			/* skk-error "No okurgana!" */
			ImeDoc_vSetSignalError (pDoc) ;
			return	LMR_RETURN ;
		}
	}
	if (FALSE /* skk-allow-spaces-newlines-and-tabs */) {
		LPDSTR	wpSrc, wpDest, wptrEnd ;
		wpSrc	= pBuffer->m_bufSkkHenkanKey ;
		wpDest	= pBuffer->m_bufSkkHenkanKey ;
		wptrEnd	= pBuffer->m_bufSkkHenkanKey + pBuffer->m_nSkkHenkanKeyLen ;
		while (wpSrc < wptrEnd) {
			if (*wpSrc == L' ' || *wpSrc == L'\n' || *wpSrc == L'\r' || *wpSrc == L'\t') {
				while (wpSrc < wptrEnd && (*wpSrc == L' ' || *wpSrc == L'\n' || *wpSrc == L'\r' || *wpSrc == L'\t'))
					wpSrc	++ ;
				if (wpSrc >= wptrEnd)
					break ;
			}
			if (wpDest != wpSrc)
				*wpDest ++	= *wpSrc ++ ;
		}
		pBuffer->m_nSkkHenkanKeyLen	= wpDest - pBuffer->m_bufSkkHenkanKey ;
	} else {
		LPDSTR	wpSrc, wptrEnd ;
		wpSrc	= pBuffer->m_bufSkkHenkanKey ;
		wptrEnd	= pBuffer->m_bufSkkHenkanKey + pBuffer->m_nSkkHenkanKeyLen ;
		while (wpSrc < wptrEnd && (*wpSrc != L'\n' && *wpSrc != L'\r'))
			wpSrc	++ ;
		if (wpSrc < wptrEnd) {
			/* skk-error "Henkan key may not contain a new line character" */
			ImeDoc_vSetSignalError (pDoc) ;
			return	LMR_RETURN ;
		}
		wpSrc	= pBuffer->m_bufSkkHenkanKey ;
		while (wpSrc < wptrEnd && (*wpSrc != L' ' && *wpSrc != L'\t'))
			wpSrc	++ ;
		pBuffer->m_nSkkHenkanKeyLen	= wpSrc - pBuffer->m_bufSkkHenkanKey ;
	}
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, pBuffer->m_pmkPoint) ;
	pBuffer->m_iSkkHenkanCount	= 0 ;

	if (! ImeDoc_bCall (pDoc, LM_bSkkHenkan, LM_bSkkStartHenkan_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkStartHenkan_2 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_bSkkAbbrevMode && pBuffer->m_bSkkHenkanMode == LACTIVE) {
		imeBuffer_bSkkJModeOn (pBuffer, pBuffer->m_bSkkKatakana) ;
		pBuffer->m_bSkkAbbrevMode	= LTRUE ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-previous-candidate
 */
static	int		LM_bSkkPreviousCandidate_1		(struct CImeDoc*) ;
static	int		LM_bSkkPreviousCandidate_Exit	(struct CImeDoc*) ;

int
LM_bSkkPreviousCandidate (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_bSkkHenkanMode != LACTIVE) {
		if (ImeDoc_iGetLastCommand (pDoc) != NFUNC_SKK_KAKUTEI_HENKAN) {
			/* last-command-char �͍��̂Ƃ����� characterp ���H */
			if (! ImeDoc_bCall (pDoc, LM_bSkkKanaInput, LM_bSkkPreviousCandidate_Exit))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		} else {
			if (! ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint))) {
				ImeDoc_vSetSignalError (pDoc) ;
				ImeDoc_vJump (pDoc, LM_bSkkPreviousCandidate_Exit) ;
				return	LMR_CONTINUE ;
			}
			if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPointSubr, LM_bSkkPreviousCandidate_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	} else if (pBuffer->m_nSkkHenkanKeyLen == 0) {
		ImeDoc_vJump (pDoc, LM_bSkkPreviousCandidate_Exit) ;
		return	LMR_CONTINUE ;
	} else {
		struct TMarker*	pmkMark		= NULL ;

		if (TMarker_iGetPosition (pBuffer->m_pmkPoint) != pBuffer->m_nbufComp) {
			pmkMark		= ImeBuffer_pMakeMarker (pBuffer, TRUE) ;
			if (pmkMark != NULL) {
				TMarker_bSetPosition (pmkMark, pBuffer->m_pmkPoint) ;
				TMarker_bForward (pmkMark, 1) ;
			}
		}
		if (pBuffer->m_iSkkHenkanCount == 0) {
			int	nSkkPrefixLen ;

			if (pBuffer->m_nSkkOkuriCharLen > 0) {
				if (pBuffer->m_nSkkHenkanKeyLen > 0)
					pBuffer->m_nSkkHenkanKeyLen	-- ;
			}
			if (pBuffer->m_bSkkKatakana) {
				pBuffer->m_nSkkHenkanKeyLen	= iSkkHiraganaToKatakana (pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, FALSE) ;
			}
			pBuffer->m_iSkkHenkanCount			= -1 ;
			/* skk-henkan-in-minibuff-flag = nil */
			pBuffer->m_bSkkHenkanInMinibuffFlag	= LFALSE ;
			/* skk-henkan-list = nil */
			pBuffer->m_nSkkOkuriCharLen			= 0 ;
			pBuffer->m_iSkkOkuriIndexMin		= -1 ;
			pBuffer->m_iSkkOkuriIndexMax		= -1 ;
			pBuffer->m_bSkkOkurigana			= LFALSE ;
			/*	[2009/01/10] �ǉ��B����ϊ����삩�� PreviousCandidate �ő���Ȃ��ϊ�
			 *	����ɖ߂������ɁA�N���A����K�v�����邽�߁B
			 */
			pBuffer->m_nSkkHenkanOkuriganaLen	= 0 ;

			/*	skk-process-okueri-early �̏ꍇ�A�u��s�v�̒i�K�ŕϊ����\�ɂȂ�̂ŁA
			 *	skk-prefix �����݂����Ԃ̂܂� skk-previous-candidates �ɗ��邱�Ƃ�
			 *	�\�ɂȂ�B���̎��Askk-prefix �� nil �ɖ߂��Ă��܂��ẮA�us�v��
			 *	�c���Ă��܂����ƂɂȂ�B
			 */
			nSkkPrefixLen	= 0 ;
			if (pBuffer->m_nSkkPrefixLen > 0) {
				if (pBuffer->m_pmkSkkKanaStartPoint != NULL && TMarker_bIsValidp (pBuffer->m_pmkSkkKanaStartPoint)) {
					int	nKanaStartPoint ;

					nKanaStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkKanaStartPoint) ;
					if (nKanaStartPoint < 0 || (nKanaStartPoint + pBuffer->m_nSkkPrefixLen) > pBuffer->m_nbufComp) {
						/* error */
					} else {
						if (memcmp (pBuffer->m_bufComp + nKanaStartPoint, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen * sizeof (DCHAR)) == 0) {
							nSkkPrefixLen	= pBuffer->m_nSkkPrefixLen ;
						}
					}
				}
			}
			pBuffer->m_nSkkPrefixLen		= nSkkPrefixLen ;

			/* (when (skk-numeric-p) ... */
			/*	���ȊJ�n�ʒu�� delete-region �ɂ���Ĕj�󂳂ꂽ��Ainsert �ŕ����ł��Ȃ�
			 *	�̂ňꎞ�I�ɃJ�[�\���}�[�J�ɕύX����B
			 */
			(void) TMarker_bSetCursor (pBuffer->m_pmkSkkKanaStartPoint, TRUE) ;
			ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint)) ;
			ImeBuffer_iInsert (pBuffer, pBuffer->m_pmkSkkHenkanEndPoint, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen) ;
			(void) TMarker_bSetCursor (pBuffer->m_pmkSkkKanaStartPoint, FALSE) ;
			imeBuffer_bSkkChangeMarkerToWhite (pBuffer) ;
		} else {
			pBuffer->m_iSkkHenkanCount	-- ;
			/*	skk-insert-new-word ... skk-get-current-candidate ... skk-henkan-list �̌`�����C�ɂȂ�ȁB
			 *	���ʂ� skk-get-current-candidate-1 �� car �� cdr ���Ƃ�Ƃǂ��Ȃ�H
			 */
			if (pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
				LPCDSTR	dstrNewWord ;

				dstrNewWord	= imeBuffer_pSkkGetCurrentCandidate (pBuffer) ;
				if (dstrNewWord != NULL) {
					if (! imeBuffer_bSkkInsertNewWord (pBuffer, dstrNewWord, dcslen (dstrNewWord)))
						return	FALSE ;
				}
			}
		}
		if (pmkMark != NULL) {
			TMarker_bSetPosition (pBuffer->m_pmkPoint, pmkMark) ;
			TMarker_bBackward (pBuffer->m_pmkPoint, 1) ;
			ImeBuffer_bDeleteMarker (pBuffer, pmkMark) ;
		} else {
			/* (point-max) �܂� cursor ���ړ��B*/
			TMarker_bForward (pBuffer->m_pmkPoint, pBuffer->m_nbufComp - TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;
		}
		if (pBuffer->m_bSkkAbbrevMode && pBuffer->m_iSkkHenkanCount == -1) {
			/* skk-abbrev-mode-on */
			imeBuffer_bSkkAbbrevModeOn (pBuffer) ;
		}
		ImeDoc_vJump (pDoc, LM_bSkkPreviousCandidate_Exit) ;
		return	LMR_CONTINUE ;
	}
}

int
LM_bSkkPreviousCandidate_1 (
	struct CImeDoc*		pDoc)
{
	/* skk-get-last-henkan-datum �͂Ȃ��c
	 */
	ImeDoc_bSetThisCommand (pDoc, NFUNC_SKK_UNDO_KAKUTEI_HENKAN) ;
	ImeDoc_vJump (pDoc, LM_bSkkPreviousCandidate_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkPreviousCandidate_Exit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan
 */
/*	recursive-edit �ɓ���^�C�~���O���N���e�B�J���B
 */
static	int		LM_bSkkHenkan_1		(struct CImeDoc*) ;
static	int		LM_bSkkHenkan_3		(struct CImeDoc*) ;
static	int		LM_bSkkHenkan_4		(struct CImeDoc*) ;
static	int		LM_bSkkHenkan_Exit	(struct CImeDoc*) ;

int
LM_bSkkHenkan (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkMark			= NULL ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_nSkkHenkanKeyLen == 0) {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
		ImeDoc_vJump (pDoc, LM_bSkkKakuteiAdJisx0201) ;
		return	LMR_CONTINUE ;
	} 

	if (! ImeDoc_bPushReg (pDoc, LMREG_1))
		return	LMR_ERROR ;

	if (TMarker_iGetPosition (pBuffer->m_pmkPoint) != pBuffer->m_nbufComp) {
		pmkMark		= ImeBuffer_pMakeMarker (pBuffer, TRUE) ;
		if (pmkMark != NULL) {
			TMarker_bSetPosition (pmkMark, pBuffer->m_pmkPoint) ;
			TMarker_bForward (pmkMark, 1) ;
		}
	}
	ImeDoc_vSetRegPointer (pDoc, LMREG_1, pmkMark) ;

	if (pBuffer->m_bSkkHenkanMode != LACTIVE) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkChangeMarker, LM_bSkkHenkan_1))
			return	LMR_ERROR ;
	} else {
		if (! ImeDoc_bCall (pDoc, LM_bSkkHenkan1, LM_bSkkHenkan_3))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkan_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int					iSearchType ;
	LPCDSTR				pwOkurigana ;
	int					nOkurigana ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}

	/* (skk-current-search-prog-list skk-search-prog-list) */
	if (pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
		TSearchSession_vDestroy (pBuffer->m_pSkkCurrentSearchProgSession) ;
	}
	/* ���艼������̏ꍇ�͒��Ӂc*/
	/*  okurigana (or skk-henkan-okurigana skk-okuri-char)) */
	if (pBuffer->m_nSkkHenkanOkuriganaLen > 0) {
		pwOkurigana	= pBuffer->m_bufSkkHenkanOkurigana ;
		nOkurigana	= pBuffer->m_nSkkHenkanOkuriganaLen ;
	} else {
		pwOkurigana	= pBuffer->m_bufSkkOkuriChar ;
		nOkurigana	= pBuffer->m_nSkkOkuriCharLen ;
	}
	if (nOkurigana > 0) {
		/*	! ������ ImeDoc_bSkkHenkanOkuriStrictlyp �̌��ʂ��K�v���I �Ƃ����L���Ă����BWed Jul 05 22:06:11 2006
		 */
		if (ImeConfig_bSkkHenkanOkuriStrictlyp ()) {
			iSearchType	= SEARCH_OKURI_STRICT ;
		} else if (ImeConfig_bSkkHenkanStrictOkuriPrecedencep ()) {
			iSearchType	= SEARCH_OKURI_STRICT_PRECEDENCE ;
		} else {
			iSearchType	= SEARCH_OKURI_ARI ;
		}
		pBuffer->m_pSkkCurrentSearchProgSession	= TOkuriHenkanSession_pCreate (pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, pwOkurigana, nOkurigana, iSearchType, ImeConfig_bSkkNumericConversionp (), ImeConfig_bSkkNumConvertFloatp ()) ;
	} else {
		if (ImeConfig_bSkkAutoOkuriProcessp ()) {
			/* �ʏ�̌��� + ���艼�������邩������Ȃ������̑g�ݍ��킹�B*/
			iSearchType	= SEARCH_OKURI_AUTO ;
		} else {
			iSearchType	= SEARCH_OKURI_NASHI ;
		}
		pBuffer->m_pSkkCurrentSearchProgSession	= THenkanSession_pCreate (pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, iSearchType, ImeConfig_bSkkNumericConversionp (), ImeConfig_bSkkNumConvertFloatp ()) ;
	}
	if (! ImeDoc_bCall (pDoc, LM_bSkkHenkan1, LM_bSkkHenkan_3))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkan_3 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int			nResultLen ;
	LPCDSTR		pwResult ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_RETVAL, &pwResult, &nResultLen))
		nResultLen	= -1 ;

	if (nResultLen < 0) {
		/* signal ���󂯂��ꍇ�� < 0 ���߂�Ƃ���B*/
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (nResultLen > 0) {
		/*	ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwResult, nResultLen) ;
		 *	LMREGARG_RETVAL �͂��̂܂܂� LM_bSkkHenkan_4 �ւƔ�ԁB
		 */
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_4) ;
	} else {
		/* ���̏ꍇ�́Askk-henkan-in-minibuff �ɓ���B*/
		if (! ImeDoc_bCall (pDoc, LM_bSkkHenkanInMinibuff, LM_bSkkHenkan_4))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkan_4 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				pNewWord ;
	int					nNewWordLen ;
	struct TMarker*		pmkMark	= NULL ;
	BOOL				bKakuteiHenkan	= FALSE ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_RETVAL, &pNewWord, &nNewWordLen)) {
		pNewWord	= NULL ;
		nNewWordLen	= 0 ;
	} else {
		/*	skk-henkan-in-minibuff �̕Ԃ�l�� m_bufRETURN �𗘗p���邪�ALM_bSkkHenkan_3 ����
		 *	�~��ė����ꍇ�ɂ́c
		 */
		LPDSTR		pwBuffer ;

		if (nNewWordLen > 0) {
			pwBuffer	= ImeDoc_pAlloca (pDoc, sizeof (DCHAR) * nNewWordLen, __alignof (DCHAR)) ;
			if (pwBuffer == NULL)
				return	LMR_ERROR ;
			dcsncpy (pwBuffer, pNewWord, nNewWordLen) ;
			pNewWord	= pwBuffer ;
		} else {
			pNewWord	= NULL ;
		}
		nNewWordLen	= nNewWordLen ;

		bKakuteiHenkan	= pBuffer->m_bSkkKakuteiFlag ;
	}
	if (! ImeDoc_bGetRegPointer (pDoc, LMREG_1, &pmkMark))
		pmkMark			= NULL ;

	if (nNewWordLen > 0) {
		/* skk-insert-new-word new-word */
		imeBuffer_bSkkInsertNewWord (pBuffer, pNewWord, nNewWordLen) ;
	}
	if (pmkMark != NULL) {
		TMarker_bSetPosition (pBuffer->m_pmkPoint, pmkMark) ;
		TMarker_bBackward (pBuffer->m_pmkPoint, 1) ;
		ImeBuffer_bDeleteMarker (pBuffer, pmkMark) ;
	} else {
		/* (point-max) �܂� cursor ���ړ��B*/
		TMarker_bForward (pBuffer->m_pmkPoint, pBuffer->m_nbufComp - TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;
	}
	if (bKakuteiHenkan) {
		/* (skk-kakutei new-word) */
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pNewWord, nNewWordLen) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkHenkan_Exit))
			return	LMR_ERROR ;
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkHenkan_Exit) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkan_Exit (
	struct CImeDoc*			pDoc)
{
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-set-henkan-point-subr
 */
static	int		LM_bSkkSetHenkanPointSubr_1 (struct CImeDoc*) ;

int
LM_bSkkSetHenkanPointSubr (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/* cancel �͂Ȃ��B*/
	if (pBuffer->m_bSkkHenkanMode) {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkSetHenkanPointSubr_1))
			return	LMR_ERROR ;
	} else {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_0, FALSE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKanaCleanup, LM_bSkkSetHenkanPointSubr_1))
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkSetHenkanPointSubr_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nPrefix ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	if (! SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) || SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) == NULL) {
//	if (pBuffer->m_pSkkCurrentRuleTree == NULL || TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) == NULL) {
		ImeBuffer_bInsertAndInheritW (pBuffer, L"��", 1) ;
	} else {
		imeBuffer_bSkkErasePrefix (pBuffer, FALSE) ;
		ImeBuffer_bInsertAndInheritW (pBuffer, L"��", 1) ;
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkKanaStartPoint, MARKER_SKK_KANA_START_POINT, pBuffer->m_pmkPoint) ;
		imeBuffer_bSkkInsertPrefix (pBuffer, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;
	}
	pBuffer->m_bSkkHenkanMode		= LON ;
	pBuffer->m_pmkSkkHenkanEndPoint	= NULL ;
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanStartPoint, MARKER_SKK_HENKAN_START_POINT, pBuffer->m_pmkPoint) ;

	/*	���̏����̓G���[���������Ă��K�����s����Ȃ���΂Ȃ�Ȃ��I
	 */
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-set-henkan-point
 */
static	int		LM_bSkkSetHenkanPoint_1		(struct CImeDoc*) ;
static	int		LM_bSkkSetHenkanPoint_2		(struct CImeDoc*) ;
static	int		LM_bSkkSetHenkanPoint_3		(struct CImeDoc*) ;
static	int		LM_bSkkSetHenkanPoint_4		(struct CImeDoc*) ;
static	int		LM_bSkkSetHenkanPoint_Exit	(struct CImeDoc*) ;

int
LM_bSkkSetHenkanPoint (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		iLastCommandChar, iLastChar	;
	BOOL	bNormal, bSokuon, bHenkanActive ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	iLastCommandChar	= ImeDoc_iGetLastCommandChar (pBuffer->m_pDoc) ;
	iLastChar			= (L'A' <= iLastCommandChar && iLastCommandChar <= L'Z')? (iLastCommandChar + (L'a' - L'A')) : iLastCommandChar ;
	bNormal				= (iLastChar != iLastCommandChar) ;
	bSokuon				= (pBuffer->m_nSkkPrefixLen == 1 && pBuffer->m_bufSkkPrefix [0] == iLastChar && iLastChar != L'o') ;
	bHenkanActive		= (pBuffer->m_bSkkHenkanMode == LACTIVE) ;

	if (! ImeDoc_bPushReg (pDoc, LMREG_1) ||
		! ImeDoc_bPushReg (pDoc, LMREG_2) ||
		! ImeDoc_bPushReg (pDoc, LMREG_3))
		return	LMR_ERROR ;

	ImeDoc_vSetRegInteger (pDoc, LMREG_1, iLastChar) ;
	ImeDoc_vSetRegBool    (pDoc, LMREG_3, bNormal) ;

	if (pBuffer->m_bSkkHenkanMode != LON) {
		if (bNormal) {
			if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPointSubr, LM_bSkkSetHenkanPoint_Exit))
				return	LMR_ERROR ;
		} else {
			/* ! bNormal */
			if (pBuffer->m_bSkkHenkanMode) {
				if (bHenkanActive) {
					if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPointSubr, LM_bSkkSetHenkanPoint_4))
						return	LMR_ERROR ;
				} else {
					if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPointSubr, LM_bSkkSetHenkanPoint_Exit))
						return	LMR_ERROR ;
				}
			} else {
				if (bHenkanActive) {
					if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkSetHenkanPoint_Exit))
						return	LMR_ERROR ;
				}
			}
		}
	} else if (! bNormal) {
		DCHAR	wch	= iLastChar ;
		int		nSkkHenkanStartPoint, nPoint ;

		ImeBuffer_bInsertAndInherit (pBuffer, &wch, 1) ;
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanStartPoint, MARKER_SKK_HENKAN_START_POINT, pBuffer->m_pmkPoint) ;
		pBuffer->m_iSkkHenkanCount		= 0 ;
		if (pBuffer->m_pmkSkkHenkanStartPoint == NULL) {
			ImeDoc_vSetSignalError (pDoc) ;
			return	LMR_RETURN ;
		}
		nSkkHenkanStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
		nPoint					= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
		if (nPoint >= nSkkHenkanStartPoint) {
			pBuffer->m_nSkkHenkanKeyLen	= nPoint - nSkkHenkanStartPoint ;
			dcsncpy (pBuffer->m_bufSkkHenkanKey, pBuffer->m_bufComp + nSkkHenkanStartPoint, pBuffer->m_nSkkHenkanKeyLen) ;
		} else {
			pBuffer->m_nSkkHenkanKeyLen	= 0 ;
		}
		pBuffer->m_nSkkPrefixLen	= 0 ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkHenkan, LM_bSkkSetHenkanPoint_Exit))
			return	LMR_ERROR ;
	} else {
		BOOL	bProcess	= FALSE ;
		int		nPrefix ;
		struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

		piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
		if (! SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) || SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) == NULL) {
//		if (pBuffer->m_pSkkCurrentRuleTree == NULL || TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) == NULL) {
			ImeDoc_vSetRegInteger (pDoc, LMREG_2, bSokuon) ;
			ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_1) ;
		} else if (pBuffer->m_pmkSkkKanaStartPoint != NULL && pBuffer->m_pmkSkkHenkanStartPoint != NULL && TMarker_iGetPosition (pBuffer->m_pmkSkkKanaStartPoint) != TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) {
			ImeDoc_vSetRegInteger (pDoc, LMREG_2, bSokuon) ;
			if (! bSokuon) {
				ImeDoc_vSetRegBool    (pDoc, LMREGARG_0, FALSE) ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkKanaCleanup, LM_bSkkSetHenkanPoint_1))
					return	LMR_ERROR ;
			} else {
				ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_1) ;
			}
		} else {
			ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
		}
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkSetHenkanPoint_Exit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	BOOL	bNormal ;
	int		iLastChar ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREG_3, &bNormal)) 
		bNormal	= FALSE ;
	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_1, &iLastChar)) {
		bNormal		= FALSE ;
		iLastChar	= -1 ;
	}
	ImeDoc_vPopReg (pDoc, LMREG_3) ;
	ImeDoc_vPopReg (pDoc, LMREG_2) ;
	ImeDoc_vPopReg (pDoc, LMREG_1) ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (bNormal) {
		int		iLastCommandChar ;

		iLastCommandChar	= ImeDoc_iGetLastCommandChar (pBuffer->m_pDoc) ;
		if (iLastCommandChar != iLastChar) {
			struct CSkkRuleTreeIterator*	piteSkkRuleTree ;
			int		nPrefix ;

			piteSkkRuleTree		= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
			if (piteSkkRuleTree != NULL && SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) &&
				SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) != NULL && nPrefix > 0 &&
				SkkRuleTreeIterator_bHaveSelectBranchp (piteSkkRuleTree, iLastCommandChar)) {
				iLastChar = iLastCommandChar ;
			}
		}
		ImeDoc_bSetLastCommandChar (pDoc, iLastChar) ;
		ImeDoc_vJump (pDoc, LM_bSkkKanaInput) ;
		return	LMR_CONTINUE ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
LM_bSkkSetHenkanPoint_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	BOOL	bProcess		= FALSE ;
	BOOL	bSokuon			= FALSE ;
	BOOL	bNormal			= TRUE ;
	int		iLastChar		= -1 ;

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_1, &iLastChar))
		iLastChar	= -1 ;
	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_2, &bSokuon))
		bSokuon		= FALSE ;
	if (! ImeDoc_bGetRegBool (pDoc, LMREG_3, &bNormal))
		bNormal		= TRUE ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (pBuffer->m_bSkkOkurigana) {
		ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (pBuffer->m_pmkSkkHenkanStartPoint != NULL && TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) == TMarker_iGetPosition (pBuffer->m_pmkPoint)) {
		bProcess	= TRUE ;
	} else {
		DCHAR	wch ;	/* char-before �͌����ɂ͓��삵�Ȃ��B*/
		int		nPoint ;

		nPoint	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
		wch		= (nPoint > 0)? pBuffer->m_bufComp [nPoint - 1] : L'\0' ;
		if ((L'0' <= wch && wch <= L'9') || wch == L'��' || (L'�O' <= wch && wch <= L'�X')) {
			bProcess	= FALSE ;
		} else {
			bProcess	= TRUE ;
		}
	}
	if (bProcess) {
		if (ImeConfig_bSkkProcessOkuriEarlyp ()) {
			DCHAR	buf [2] ;
			LPDSTR	pDest, pDestEnd ;
			int		n ;

			imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, pBuffer->m_pmkPoint) ;

			/* skk-okuri-char �̐ݒ�B*/
			buf [0]				= iLastChar ;
			pBuffer->m_nSkkOkuriCharLen	= ImeConfig_iGetSkkOkuriChar (buf, 1, pBuffer->m_bufSkkOkuriChar, ARRAYSIZE (pBuffer->m_bufSkkOkuriChar)) ;
			if (pBuffer->m_nSkkOkuriCharLen <= 0) {
				pBuffer->m_bufSkkOkuriChar [0]	= iLastChar ;
				pBuffer->m_nSkkOkuriCharLen		= 1 ;
			}
			pDest		= pBuffer->m_bufSkkHenkanKey ;
			pDestEnd	= pBuffer->m_bufSkkHenkanKey + ARRAYSIZE (pBuffer->m_bufSkkHenkanKey) ;
			if (bSokuon) {
				n			= MIN (pDestEnd - pDest, TMarker_iGetPosition (pBuffer->m_pmkSkkKanaStartPoint) - TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) ;
				if (n < 0) {
					ImeDoc_vSetSignalError (pDoc) ;
					ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
					return	LMR_CONTINUE ;
				}
				vCopyStringN (&pDest, pDestEnd, pBuffer->m_bufComp + TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), n) ;
				vCopyStringW (&pDest, pDestEnd, pBuffer->m_bSkkKatakana? L"�b" : L"��") ;
				vCopyStringN (&pDest, pDestEnd, pBuffer->m_bufSkkOkuriChar, pBuffer->m_nSkkOkuriCharLen) ;

				pBuffer->m_nSkkHenkanKeyLen	= pDest - pBuffer->m_bufSkkHenkanKey ;
				imeBuffer_bSkkErasePrefix (pBuffer, FALSE) ;
				ImeBuffer_bInsertAndInheritW (pBuffer, pBuffer->m_bSkkKatakana? L"�b" : L"��", 1) ;
				pBuffer->m_nSkkPrefixLen	= 0 ;
				pBuffer->m_iSkkHenkanCount	= 0 ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkHenkan, LM_bSkkSetHenkanPoint_2))
					return	LMR_ERROR ;

				return	LMR_CONTINUE ;
			} else {
				n			= MIN (pDestEnd - pDest, TMarker_iGetPosition (pBuffer->m_pmkPoint) - TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) ;
				if (n < 0) {
					ImeDoc_vSetSignalError (pDoc) ;
					ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
					return	LMR_CONTINUE ;
				}
				if (n > 0) {
					vCopyStringN (&pDest, pDestEnd, pBuffer->m_bufComp + TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), n) ;
				}
				vCopyStringN (&pDest, pDestEnd, pBuffer->m_bufSkkOkuriChar, pBuffer->m_nSkkOkuriCharLen) ;

				pBuffer->m_nSkkHenkanKeyLen	= pDest - pBuffer->m_bufSkkHenkanKey ;
				ImeBuffer_bInsertAndInheritW (pBuffer, L" ", 1) ;
				pBuffer->m_nSkkPrefixLen	= 0 ;
				pBuffer->m_iSkkHenkanCount	= 0 ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkHenkan, LM_bSkkSetHenkanPoint_2))
					return	LMR_ERROR ;

				return	LMR_CONTINUE ;
			}
			/* ... */
		} else {
			if (TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) != TMarker_iGetPosition (pBuffer->m_pmkPoint)) {
				int		nPrefix ;
				struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

				if (bSokuon) {
					imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;
					ImeBuffer_bInsertAndInheritW (pBuffer, pBuffer->m_bSkkKatakana? L"�b" : L"��", 1) ;
				}

				/*	������ "IwakU" �Ɠ��͂��āA"IwaKu" �Ɠ����̓���������鏈��������B
				 */
				piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
				if (! bSokuon && 
					SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) &&
					SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) != NULL &&
//					pBuffer->m_pSkkCurrentRuleTree != NULL && 
//					TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) != NULL &&
					bNormal &&
					pBuffer->m_nSkkPrefixLen > 0 &&
					TMarker_iGetPosition (pBuffer->m_pmkPoint) >= pBuffer->m_nSkkPrefixLen &&
					memcmp (pBuffer->m_bufComp + TMarker_iGetPosition (pBuffer->m_pmkPoint) - pBuffer->m_nSkkPrefixLen, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen * sizeof (DCHAR)) == 0) {

					/*	�]���̕��@���ƁAMakSu �̂悤�Ȍ���͂�����ƁA
					 *	(1) "����k|" (����: S) (| �̓J�[�\���ʒu)
					 *	(2) "����s|" 
					 *	(3) "����s|" (����: u)
					 *	(4) "��s��"
					 *	�Ƃ����ϊ������Ă��܂��̂ŁA�C���B����́Askk-kana-input �̑��ɔ��f��
					 *	�䂾�˂�ׂ��ŁA������ okurigana ���Ǝv���Ă��܂��̂͂悭�Ȃ��悤���B
					 *	���ƁAMatsU �̂悤�ȓ��͂��\�ɁBprefix-len == 1�̔���͂͂������B
					 */
					if (pBuffer->m_bSkkOkurigana) {
						if (pBuffer->m_pmkSkkOkuriganaStartPoint != NULL && 
							TMarker_bIsValidp (pBuffer->m_pmkSkkOkuriganaStartPoint) && 
							pBuffer->m_bufComp [TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint)] == L'*') {
							ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint) + 1) ;
						}
						pBuffer->m_bSkkOkurigana	= LFALSE ;
					}
					if (pBuffer->m_pmkSkkKanaStartPoint != NULL && TMarker_bIsValidp (pBuffer->m_pmkSkkKanaStartPoint)) {
						ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkKanaStartPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;
					}
					imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkOkuriganaStartPoint, MARKER_SKK_OKURIGANA_START_POINT, pBuffer->m_pmkPoint) ;
					ImeBuffer_bInsertAndInheritW (pBuffer, L"*", 1) ;
					imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkKanaStartPoint, MARKER_SKK_KANA_START_POINT, pBuffer->m_pmkPoint) ;
					imeBuffer_bSkkInsertPrefix (pBuffer, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;

					pBuffer->m_nSkkOkuriCharLen		= pBuffer->m_nSkkPrefixLen ;
					dcsncpy (pBuffer->m_bufSkkOkuriChar, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;
					pBuffer->m_bSkkOkurigana		= LTRUE ;
				} else {
					imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkOkuriganaStartPoint, MARKER_SKK_OKURIGANA_START_POINT, pBuffer->m_pmkPoint) ;
					ImeBuffer_bInsertAndInheritW (pBuffer, L"*", 1) ;
					imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkKanaStartPoint, MARKER_SKK_KANA_START_POINT, pBuffer->m_pmkPoint) ;
					pBuffer->m_nSkkOkuriCharLen		= 1 ;
					pBuffer->m_bufSkkOkuriChar [0]	= iLastChar ;
					pBuffer->m_bSkkOkurigana		= LTRUE ;
				}
			}
		}
	}
	ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkSetHenkanPoint_2 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	BOOL			bSokuon ;

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_2, &bSokuon)) 
		bSokuon	= FALSE ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeBuffer_bDeleteBackwardChar (pBuffer, bSokuon? 2 : 1)) {
		ImeDoc_vSetSignalError (pDoc) ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkSetHenkanPoint_3 (
	struct CImeDoc*			pDoc)
{
	if (! ImeDoc_bCall (pDoc, LM_bSkkSetCharBeforeAsOkurigana, LM_bSkkSetHenkanPoint_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkSetHenkanPoint_4 (
	struct CImeDoc*		pDoc)
{
	ImeDoc_vJump (pDoc, LM_bSkkSetHenkanPoint_Exit) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-mode
 */
static	int		LM_bSkkMode_1	(struct CImeDoc*) ;

int
LM_bSkkMode (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (! pBuffer->m_bSkkMode) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkModeExit, LM_bSkkMode_1))
			return	LMR_ERROR ;
	} else {
		if (! pBuffer->m_bSkkModeInvoked)
			imeBuffer_bSkkModeInvoke (pBuffer) ;
		ImeDoc_vJump (pDoc, LM_bSkkMode_1) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkMode_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	/* ... pre-command-hook, post-command-hook �̓x�^�Ɏ�������Ƃ��āA
	 *	run-hooks �͕s�\�B*/
	imeBuffer_bSkkJModeOn (pBuffer, LFALSE) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-mode-exit
 */
static	int		LM_bSkkModeExit_1 (struct CImeDoc*) ;

int
LM_bSkkModeExit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (! ImeDoc_bPushReg (pDoc, LMREG_0))
		return	LMR_ERROR ;

	/* 0 �� LM_bSkkKakuteiAdJisx0201 �ւ̈����B*/
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
	ImeDoc_vSetRegBool   (pDoc, LMREG_0, pBuffer->m_bSkkMode) ;
	pBuffer->m_bSkkMode	= TRUE ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkModeExit_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkModeExit_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	BOOL				bSkkMode ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREG_0, &bSkkMode))
		bSkkMode	= FALSE ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_bSkkMode	= bSkkMode ;
	imeBuffer_bSkkModeOff (pBuffer) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-latin-mode
 */
static	int		LM_bSkkLatinMode_1 (struct CImeDoc*) ;

int
LM_bSkkLatinMode (
	struct CImeDoc*				pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkLatinMode_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkLatinMode_1 (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*		pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	imeBuffer_bSkkLatinModeOn (pBuffer) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0208-latin-mode
 */
static	int		LM_bSkkJisx0208LatinMode_1 (struct CImeDoc*) ;

int
LM_bSkkJisx0208LatinMode (
	struct CImeDoc*				pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkJisx0208LatinMode_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkJisx0208LatinMode_1 (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*		pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	imeBuffer_bSkkJisx0208LatinModeOn (pBuffer) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-abbrev-mode
 */
static	int		LM_bSkkAbbrevMode_1 (struct CImeDoc*) ;
static	int		LM_bSkkAbbrevMode_2 (struct CImeDoc*) ;

int
LM_bSkkAbbrevMode (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*		pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkAbbrevMode_1))
			return	LMR_ERROR ;
	} else if (pBuffer->m_bSkkHenkanMode == LON) {
		/* "���Ɂ����[�h�ɓ����Ă��܂�" "Already in �� mode" */
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkAbbrevMode_1) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkAbbrevMode_1 (
	struct CImeDoc*				pDoc)
{
	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	if (! ImeDoc_bCall (pDoc, LM_bSkkSetHenkanPointSubr, LM_bSkkAbbrevMode_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkAbbrevMode_2 (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*		pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	imeBuffer_bSkkAbbrevModeOn (pBuffer) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-set-okurigana
 */
static	int		LM_bSkkSetOkurigana_1 (struct CImeDoc*) ;

int
LM_bSkkSetOkurigana (
	struct CImeDoc*				pDoc)
{
	struct CImeBuffer*	pBuffer ;
	DCHAR	wbuf [32] ;
	int		nOkuriStartPos, nPoint, nHenkanStartPoint, nHenkanEndPoint, nOkuriganaPrefix ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, pBuffer->m_pmkSkkOkuriganaStartPoint) ;
	/* save-point �Ȃ̂� marker �� point ��ۑ�����B*/
	nOkuriStartPos	= TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint) ;
	if (pBuffer->m_bufComp [nOkuriStartPos] != L'*') {
		const DCHAR	ch	= L'*' ;
		ImeBuffer_iInsertByPosition (pBuffer, nOkuriStartPos, &ch, 1) ;
	}
	nPoint			= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;

	/* ���艼���� start point �ɂ� '*' �����݂���B*/
	pBuffer->m_nSkkHenkanOkuriganaLen	= nPoint - nOkuriStartPos - 1 ;
	if (pBuffer->m_nSkkHenkanOkuriganaLen > 0) {
		pBuffer->m_nSkkHenkanOkuriganaLen	= (pBuffer->m_nSkkHenkanOkuriganaLen > MAXLEN_HENKAN_OKURIGANA)? MAXLEN_HENKAN_OKURIGANA : pBuffer->m_nSkkHenkanOkuriganaLen ;
		dcsncpy (pBuffer->m_bufSkkHenkanOkurigana, pBuffer->m_bufComp + nOkuriStartPos + 1, pBuffer->m_nSkkHenkanOkuriganaLen) ;
	}

	nHenkanStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
	nHenkanEndPoint		= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint) ;
	pBuffer->m_nSkkHenkanKeyLen		= nHenkanEndPoint - nHenkanStartPoint ;
	dcsncpy (pBuffer->m_bufSkkHenkanKey, pBuffer->m_bufComp + nHenkanStartPoint, (nHenkanEndPoint - nHenkanStartPoint)) ;

	nOkuriganaPrefix	= imeBuffer_iSkkOkuriganaPrefix (pBuffer, pBuffer->m_bufSkkHenkanOkurigana, pBuffer->m_nSkkHenkanOkuriganaLen, wbuf, ARRAYSIZE (wbuf)) ;
	if (nOkuriganaPrefix > 0) {
		if ((pBuffer->m_nSkkHenkanKeyLen + nOkuriganaPrefix) <= MAXLEN_HENKAN_KEY) {
			dcsncpy (pBuffer->m_bufSkkHenkanKey + pBuffer->m_nSkkHenkanKeyLen, wbuf, nOkuriganaPrefix) ;
			pBuffer->m_nSkkHenkanKeyLen	+= nOkuriganaPrefix ;
		}
	} else {
		if ((pBuffer->m_nSkkHenkanKeyLen + pBuffer->m_nSkkOkuriCharLen) <= MAXLEN_HENKAN_KEY) {
			dcsncpy (pBuffer->m_bufSkkHenkanKey + pBuffer->m_nSkkHenkanKeyLen, pBuffer->m_bufSkkOkuriChar, pBuffer->m_nSkkOkuriCharLen) ;
			pBuffer->m_nSkkHenkanKeyLen	+= pBuffer->m_nSkkOkuriCharLen ;
		}
	}
	pBuffer->m_nSkkPrefixLen	= 0 ;

	if (pBuffer->m_bSkkKatakana) {
		pBuffer->m_nSkkHenkanKeyLen			= iSkkKatakanaToHiragana (pBuffer->m_bufSkkHenkanKey, ARRAYSIZE (pBuffer->m_bufSkkHenkanKey), pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, FALSE) ;
		pBuffer->m_nSkkHenkanOkuriganaLen	= iSkkKatakanaToHiragana (pBuffer->m_bufSkkHenkanOkurigana, ARRAYSIZE (pBuffer->m_bufSkkHenkanOkurigana), pBuffer->m_bufSkkHenkanOkurigana, pBuffer->m_nSkkHenkanOkuriganaLen, FALSE) ;
	}
	ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint) + 1) ;
	pBuffer->m_iSkkHenkanCount	= 0 ;

	if (! ImeDoc_bCall (pDoc, LM_bSkkHenkan, LM_bSkkSetOkurigana_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkSetOkurigana_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	pBuffer->m_bSkkOkurigana	= LFALSE ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-delete-backward-char
 */
static	int		LM_bSkkDeleteBackwardChar_1		(struct CImeDoc*) ;
static	int		LM_bSkkDeleteBackwardChar_Exit	(struct CImeDoc*) ;

int
LM_bSkkDeleteBackwardChar (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
		if (! ImeConfig_bSkkDeleteImplesKakuteip () && TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint) == TMarker_iGetPosition (pBuffer->m_pmkPoint)) {
			if (! ImeDoc_bCall (pDoc, LM_bSkkPreviousCandidate, LM_bSkkDeleteBackwardChar_Exit))
				return	LMR_ERROR ;
			/* overwrite-mode �͂Ȃ��B*/
			return	LMR_CONTINUE ;
		} else {
			if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkDeleteBackwardChar_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	} else if (pBuffer->m_bSkkHenkanMode && TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) >= TMarker_iGetPosition (pBuffer->m_pmkPoint)) {
		pBuffer->m_iSkkHenkanCount	= 0 ;
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkDeleteBackwardChar_Exit))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else {
		struct CSkkRuleTreeIterator*	piteSkkRuleTree ;
		int		nPrefix ;

		imeBuffer_bSkkDeleteOkuriMark (pBuffer) ;
		piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
		if (SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) && SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) != NULL) {
//		if (pBuffer->m_pSkkCurrentRuleTree != NULL && TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) != NULL) {
			imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;
		} else {
			pBuffer->m_pmkSkkKanaStartPoint	= NULL ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkDeleteBackwardChar_Exit))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	ImeDoc_vJump (pDoc, LM_bSkkDeleteBackwardChar_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkDeleteBackwardChar_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int		nCount	= 1 ;	/* num-arg = 1 �Ɖ���B*/

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkDeleteBackwardChar_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkDeleteBackwardChar_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (pBuffer->m_nSkkPrefixLen > nCount) {
		pBuffer->m_nSkkPrefixLen	-- ;
	} else {
		pBuffer->m_nSkkPrefixLen	= 0 ;
	}
	if (TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint) >= TMarker_iGetPosition (pBuffer->m_pmkPoint)) {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkDeleteBackwardChar_Exit))
			return	LMR_ERROR ;
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkDeleteBackwardChar_Exit) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkDeleteBackwardChar_Exit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-kakutei
 */
static	int		LM_bSkkKakutei_1 (struct CImeDoc*) ;
static	int		LM_bSkkKakutei_2 (struct CImeDoc*) ;
static	int		LM_bSkkKakutei_3 (struct CImeDoc*) ;
static	int		LM_bSkkKakutei_4 (struct CImeDoc*) ;
static	int		LM_bSkkKakutei_5 (struct CImeDoc*) ;

/*	skk-update-jisyo �̒��� minibuffer-flag �� true �Ȃ� yes-or-no-p ���Ă΂�Ă��܂����߂�
 *	���� skk-kakutei �͂��̈ʒu�ɂȂ���΂Ȃ�Ȃ��B
 */
int
LM_bSkkKakutei (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				wstrWord ;
	int					nWordLen ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/*	�m��word ���ς܂�Ă��邩�ǂ����`�F�b�N����B*/
	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &wstrWord, &nWordLen)) {
		wstrWord	= NULL ;
		nWordLen	= 0 ;
	}
	if (pBuffer->m_bSkkHenkanMode) {
		LPDSTR	pwKakuteiMidasi,   pwKakuteiWord ;
		int		nKakuteiMidasiLen, nKakuteiWordLen ;

		pwKakuteiMidasi	= (LPDSTR) ImeDoc_pAlloca (pDoc, MAXLEN_KAKUTEI_MIDASI * sizeof (DCHAR), __alignof (DCHAR)) ;
		pwKakuteiWord	= (LPDSTR) ImeDoc_pAlloca (pDoc, MAXLEN_KAKUTEI_WORD   * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pwKakuteiMidasi == NULL || pwKakuteiWord == NULL)
			return	LMR_ERROR ;

		if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
			/* �����̍X�V���ꂱ��B���͂����͎������Ȃ��B����������̂���B*/
			/* (skk-update-jisyo kakutei-word) */
			if (nWordLen <= 0 && pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
				wstrWord	= TSearchSession_pGetReferCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
				if (wstrWord == NULL)
					wstrWord	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
				nWordLen	= (wstrWord != NULL)? dcslen (wstrWord) : 0 ;
			}
		/*
		(when (or (and (not skk-search-excluding-word-pattern-function)
				       kakutei-word)
				  (and kakutei-word
				       skk-search-excluding-word-pattern-function
				       (not (funcall
						     skk-search-excluding-word-pattern-function
						     kakutei-word))))
		  (skk-update-jisyo kakutei-word)

		  */
			/*	_bSkkUpdateJisyo �̌Ăяo���Œ��O�̊m����(���o��+�P��)���X�V����Ă��܂��̂�
			 *	�����ŕۑ����Ă����B
			 */
			nKakuteiMidasiLen	= pBuffer->m_nKakuteiMidasiLen ;
			if (nKakuteiMidasiLen > 0) {
				dcsncpy (pwKakuteiMidasi, pBuffer->m_bufKakuteiMidasi, nKakuteiMidasiLen) ;
				nKakuteiWordLen		= pBuffer->m_nKakuteiWordLen ;
				dcsncpy (pwKakuteiWord,  pBuffer->m_bufKakuteiWord,    nKakuteiWordLen) ;
			} else {
				nKakuteiWordLen		= 0 ;
			}

			if (nWordLen > 0) {
				LPDSTR	pDest ;

				/*	���́A���� wstrWord, nWordLen �� LM_bSkkUpdateJisyo �ɓn����Ȃ���΂Ȃ�Ȃ����A
				 *	���̎w���Ă���̈悪�ۏ؂���Ȃ���������Ȃ��Ƃ������Ƃ��B
				 *
				 *	���z�@�B�� stack ����̈�m�ۂ��āA�����ɕۑ�����c���B���� alignment �����B
				 */
				pDest	= (LPDSTR) ImeDoc_pAlloca (pDoc, nWordLen * sizeof (DCHAR), __alignof (DCHAR)) ;
				if (pDest == NULL) {
					/* fatal error */
					return	LMR_ERROR ;
				}
				dcsncpy (pDest, wstrWord, nWordLen) ;

				if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1))
					return	LMR_ERROR ;
				ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pDest, nWordLen) ;
				ImeDoc_vSetRegBool   (pDoc, LMREGARG_1, FALSE) ;
				ImeDoc_vSetRegString (pDoc, LMREG_0, pwKakuteiWord,   nKakuteiWordLen) ;
				ImeDoc_vSetRegString (pDoc, LMREG_1, pwKakuteiMidasi, nKakuteiMidasiLen) ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkUpdateJisyo, LM_bSkkKakutei_1)) 
					return	LMR_ERROR ;

				/*	���̕t�߂œǂ݉����Ƃ��� MidashiWord ��u���Ă����Ƃ�����Ƃ��K�v�ɂȂ�ɈႢ�Ȃ��c�B
				 *	���̏��� shift ����č폜���ꂽ�肵����A��������Ƃ��������ł������B
				 *
				 *	���ɑ��������ǁA�v����m�F�I
				 *
				 *	����A�ǂ݉������g����̂͊m���ł͂Ȃ��ϊ����Ȃ̂ł͂Ȃ����H�Ƃ����^�₪�B������
				 *	�^�C�~���O�ŕK�v�Ƃ����̂����؂�Ȃ��Ƃ����Ȃ��B
				 */
				if (! ImeDoc_bRecursiveEditp (pDoc)) {
					ImeBuffer_bSetReadingProperty (pBuffer, pBuffer->m_pmkSkkHenkanStartPoint, pBuffer->m_pmkSkkHenkanEndPoint, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen) ;
				}
				return	LMR_CONTINUE ;
			} else {
				if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1))
					return	LMR_ERROR ;
				ImeDoc_vSetRegString (pDoc, LMREG_0, pwKakuteiWord,   nKakuteiWordLen) ;
				ImeDoc_vSetRegString (pDoc, LMREG_1, pwKakuteiMidasi, nKakuteiMidasiLen) ;
				ImeDoc_vJump (pDoc, LM_bSkkKakutei_1) ;
				return	LMR_CONTINUE ;
			}
		} else {
			int		nHenkanStartPoint ;

			/* pBuffer->m_bSkkHenkanMode ==LON */
			/*
			 *		;; �����[�h�Ŋm�肵���ꍇ�B�֋X�I�Ɍ��݂̃|�C���g�܂ł����o���������
			 *		;; ���ė������X�V����B
			 *		(when (and (> skk-kakutei-history-limit 0)
			 *				   (< skk-henkan-start-point (point))
			 *				   (skk-save-point
			 *				    (goto-char skk-henkan-start-point)
			 *				    (eq (skk-what-char-type) 'hiragana)))
			 *		  (skk-update-kakutei-history
			 *		   (buffer-substring-no-properties
			 *		    skk-henkan-start-point (point))))))
			 */
			if (pBuffer->m_pmkSkkHenkanStartPoint != NULL && TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) < TMarker_iGetPosition (pBuffer->m_pmkPoint)) {
				nHenkanStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
				if (0 <= nHenkanStartPoint && nHenkanStartPoint < pBuffer->m_nbufComp && TEXT('��') <= pBuffer->m_bufComp [nHenkanStartPoint] && pBuffer->m_bufComp [nHenkanStartPoint] <= TEXT('��')) {
					imeBuffer_bSkkUpdateKakuteiHistory (pBuffer, pBuffer->m_bufComp + nHenkanStartPoint, TMarker_iGetPosition (pBuffer->m_pmkPoint) - nHenkanStartPoint, NULL, 0) ;
				}
			}
		}
		ImeDoc_vJump (pDoc, LM_bSkkKakutei_4) ;
		return	LMR_CONTINUE ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkKakutei_5) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKakutei_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPDSTR	pwCombWord		= NULL ;
	LPDSTR	pwSkkHenkanKey	= NULL ;
	LPDSTR	pwKakuteiMidasi,   pwKakuteiWord ;
	int		nKakuteiMidasiLen, nKakuteiWordLen ;
	int		nCombWordLen, nSkkHenkanKeyLen, nHenkanStartPoint ;

	/*	�m�茩�o���ƃ��W�X�^�̕��A�܂ł͕K���s���B
	 */
	if (! ImeDoc_bGetRegString (pDoc, LMREG_0, &pwKakuteiWord, &nKakuteiWordLen)) {
		pwKakuteiWord	= NULL ;
		nKakuteiWordLen	= 0 ;
	}
	if (! ImeDoc_bGetRegString (pDoc, LMREG_1, &pwKakuteiMidasi, &nKakuteiMidasiLen)) {
		pwKakuteiMidasi		= NULL ;
		nKakuteiMidasiLen	= 0 ;
	}
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	pwSkkHenkanKey	= (LPDSTR) ImeDoc_pAlloca (pDoc, pBuffer->m_nSkkHenkanKeyLen * sizeof (DCHAR), __alignof (DCHAR)) ;
	pwCombWord		= (LPDSTR) ImeDoc_pAlloca (pDoc, MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwSkkHenkanKey == NULL || pwCombWord == NULL)
		return	LMR_ERROR ;

	if (pBuffer->m_bSkkAfterPrefix && ! bSettoji (pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen)) {

		if (nKakuteiWordLen > 0 && bSettoji (pwKakuteiMidasi, nKakuteiMidasiLen)) {
			/* skk-henkan-key �̑ޔ��B*/
			if (pBuffer->m_nSkkHenkanKeyLen > 0) {
				dcsncpy (pwSkkHenkanKey, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen) ;
			}
			nSkkHenkanKeyLen	= pBuffer->m_nSkkHenkanKeyLen ;

			/*	skk-henkan-start-point ����̌��ʂ��A(nth 1 list2) �ɓ������c���B
			 */
			nHenkanStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) - pBuffer->m_nKakuteiWordLen - 1 /* ``��''�̕��B*/ ;

			/*	���O�̕ϊ������� application ���ɓn����Ă���\��������B���̏ꍇ�A���̏����͓��Ă͂܂�Ȃ��c�B
			 */
			if (nHenkanStartPoint >= 0 && (nHenkanStartPoint + nKakuteiWordLen) <= pBuffer->m_nbufComp && dcsncmp (pBuffer->m_bufComp + nHenkanStartPoint, pwKakuteiWord, nKakuteiWordLen) == 0) {
				pBuffer->m_nSkkHenkanKeyLen	= iConcatString (pBuffer->m_bufSkkHenkanKey, ARRAYSIZE (pBuffer->m_bufSkkHenkanKey), pwKakuteiMidasi, nKakuteiMidasiLen - 1, pBuffer->m_bufKakuteiMidasi, pBuffer->m_nKakuteiMidasiLen, NULL) ;
				nCombWordLen				= iConcatString (pwCombWord,                 MAXCOMPLEN,                             pwKakuteiWord,   nKakuteiWordLen,       pBuffer->m_bufKakuteiWord,   pBuffer->m_nKakuteiWordLen,   NULL) ;

				/*	���́A���� wstrWord, nWordLen �� LM_bSkkUpdateJisyo �ɓn����Ȃ���΂Ȃ�Ȃ����A
				 *	���̎w���Ă���̈悪�ۏ؂���Ȃ���������Ȃ��Ƃ������Ƃ��B
				 *
				 *	���z�@�B�� stack ����̈�m�ۂ��āA�����ɕۑ�����c���B���� alignment �����B
				 */
				if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1))
					return	LMR_ERROR ;
				ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwCombWord, nCombWordLen) ;
				ImeDoc_vSetRegBool   (pDoc, LMREGARG_1, FALSE) ;
				ImeDoc_vSetRegString (pDoc, LMREG_0, pwSkkHenkanKey, nSkkHenkanKeyLen) ;
				ImeDoc_vSetRegBool   (pDoc, LMREG_1, TRUE) ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkUpdateJisyo, LM_bSkkKakutei_2)) {
					return	LMR_ERROR ;
				}
				return	LMR_CONTINUE ;
			}
		}
		pBuffer->m_bSkkAfterPrefix	= LFALSE ;

	} else if (pBuffer->m_nKakuteiWordLen > 0 && bSetsubiji (pBuffer->m_bufKakuteiMidasi, pBuffer->m_nKakuteiMidasiLen)) {

		/* skk-henkan-key �̑ޔ��B*/
		if (pBuffer->m_nSkkHenkanKeyLen > 0)
			dcsncpy (pwSkkHenkanKey, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen) ;
		nSkkHenkanKeyLen	= pBuffer->m_nSkkHenkanKeyLen ;

		pBuffer->m_nSkkHenkanKeyLen	= iConcatString (pBuffer->m_bufSkkHenkanKey, ARRAYSIZE (pBuffer->m_bufSkkHenkanKey), pwKakuteiMidasi, nKakuteiMidasiLen, pBuffer->m_bufKakuteiMidasi + 1, pBuffer->m_nKakuteiMidasiLen - 1, NULL) ;
		nCombWordLen				= iConcatString (pwCombWord,                 MAXCOMPLEN,                             pwKakuteiWord,   nKakuteiWordLen,   pBuffer->m_bufKakuteiWord,       pBuffer->m_nKakuteiWordLen,       NULL) ;

		/*	skk-update-jisyo �̌Ăяo���B
		 */
		if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1))
			return	LMR_ERROR ;
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwCombWord, nCombWordLen) ;
		ImeDoc_vSetRegBool   (pDoc, LMREGARG_1, FALSE) ;
		ImeDoc_vSetRegString (pDoc, LMREG_0, pwSkkHenkanKey, nSkkHenkanKeyLen) ;
		ImeDoc_vSetRegBool   (pDoc, LMREG_1, FALSE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkUpdateJisyo, LM_bSkkKakutei_2)) {
			return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;
	}

	ImeDoc_vJump (pDoc, LM_bSkkKakutei_3) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKakutei_2 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPDSTR				pwSkkHenkanKey ;
	int					nSkkHenkanKeyLen ;
	int					nRetval	= LMR_RETURN ;
	BOOL				bAfterPrefix ;

	if (ImeDoc_bSignalp (pDoc)) 
		goto	exit_func ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	/*	���� REG[2] �̒l���ۑ�����Ă��邩�ۂ��ɐs����B�܂�j�󂷂�ꍇ�ɂ͕ۑ����Ă����A�ƁH
	 */
	if (! ImeDoc_bGetRegString (pDoc, LMREG_0, &pwSkkHenkanKey, &nSkkHenkanKeyLen)) {
		pwSkkHenkanKey		= NULL ;
		nSkkHenkanKeyLen	= 0 ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREG_1, &bAfterPrefix)) {
		bAfterPrefix		= FALSE ;
	}
	if (bAfterPrefix) {
		pBuffer->m_bSkkAfterPrefix	= LFALSE ;
	}

	/* skk-henkan-key �̕����B*/
	if (nSkkHenkanKeyLen > 0)
		dcsncpy (pBuffer->m_bufSkkHenkanKey, pwSkkHenkanKey, nSkkHenkanKeyLen) ;
	pBuffer->m_nSkkHenkanKeyLen	= nSkkHenkanKeyLen ;

	ImeDoc_vJump (pDoc, LM_bSkkKakutei_3) ;
	nRetval	= LMR_CONTINUE ;

exit_func:
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	nRetval ;
}

/*
 *	(when (skk-numeric-p)
 *		(setq converted (skk-get-current-candidate))
 *		(skk-num-update-jisyo kakutei-word converted))))
 */
int
LM_bSkkKakutei_3 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! imeBuffer_bSkkNumUpdateJisyo (pBuffer)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkKakutei_4) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKakutei_4 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_bSkkMode) {
		imeBuffer_bSkkKakuteiCleanupBuffer (pBuffer) ;
		/* skk-kakutei-end-function �͎����\��͂Ȃ��B*/
		/* skk-kakutei-initialize? */
		imeBuffer_bSkkKakuteiInitialize (pBuffer, NULL, 0) ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkKakutei_5) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKakutei_5 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/* skk-do-auto-fill */
	if (pBuffer->m_bSkkMode) {
		if (! (pBuffer->m_bSkkJMode || pBuffer->m_bSkkJisx0201Mode)) {
			imeBuffer_bSkkJModeOn (pBuffer, pBuffer->m_bSkkKatakana) ;
		} 
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkModeAdJisx0201) ;
		return	LMR_CONTINUE ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-emulate-original-map
 */
int
LM_bSkkEmulateOriginalMap (
	struct CImeDoc*		pDoc)
{
	const struct TMSG*	pMsg ;
	int					nFuncNo, nOrigFunc ;
	PLMFUNC				pPC	= NULL ;

	/*	major-map �� lookup ���� function ��ǉ����� call ����B
	 */
	pMsg	= ImeDoc_pGetLastCommandEvent (pDoc) ;
	if (pMsg == NULL)
		return	LMR_RETURN ;

	if (! ImeDoc_bLookupKeymap (pDoc, pMsg, &nOrigFunc))
		nOrigFunc	= NFUNC_INVALID_CHAR ;
	if (! ImeDoc_bLookupMajorKeymap (pDoc, pMsg, &nFuncNo)) 
		nFuncNo	= NFUNC_INVALID_CHAR ;

	/*	emulate-original-map �̌Ăяo�����������[�v�ɂȂ�Ȃ��悤�ɁA
	 *	���Ƃ��Ƃ̌Ăяo���� original-map �̌Ăяo������v���Ă����ꍇ�ɂ́A
	 *	�������Ȃ��B
	 */
	if (nFuncNo == nOrigFunc && nFuncNo != NFUNC_INVALID_CHAR) {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	}

	pPC		= ImeDoc_pLookupLMState (pDoc, nFuncNo) ;
	if (pPC == NULL) {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		return	LMR_RETURN ;	/* �������삪���蓖�Ă��ĂȂ��ꍇ�B*/
	}
	ImeDoc_vJump (pDoc, pPC) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kana-clean-up
 */
static	int		LM_bSkkHenkan1_1 (struct CImeDoc*) ;

/*	�������Ԃ��Bm_bufRETURN, LMREGARG_RETVAL �̃R���r�B
 */
int
LM_bSkkHenkan1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				dstrNewWord	= NULL ;
	int					nRetval		= 0 ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_iSkkHenkanCount == 0) {
		/* kakutei jisyo �� search ���Ȃ��Ƃ����̂́c��������ǂ����䂷�ׂ����H */

		if (pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
			do {
				dstrNewWord		= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
				if (dstrNewWord != NULL)
					break ;
			}	while (TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) ;

			if (dstrNewWord != NULL && pBuffer->m_bSkkKakuteiFlag) {
				ImeDoc_bSetLastCommand (pBuffer->m_pDoc, NFUNC_SKK_KAKUTEI_HENKAN) ;
			}
		}
	} else {
		if (pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
			int		iCount ;

			while (TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) {
				dstrNewWord		= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
				if (dstrNewWord != NULL)
					break ;
			}
			/* ����͏����u���Ă����B*/
			iCount	= ImeConfig_iGetCountHenkanShowChange () ;
			if (iCount < SHOWCANDLIST_COUNT_NOSHOW) {
				if (dstrNewWord != NULL && pBuffer->m_iSkkHenkanCount > iCount) {
					ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates) ;
					/* LMREGARG_RETVAL �� LM_bSkkHenkanShowCandidates �̒l�����̂܂܎g���B*/
					return	LMR_CONTINUE ;
				}
			}
		}
	}
	if (dstrNewWord != NULL) {
		LPDSTR	pwRetbuff ;
		int		nNewWordLen	= dcslen (dstrNewWord) ;
		int		nRetbuffSize ;

		pwRetbuff	= ImeDoc_pGetReturnBuffer (pDoc, &nRetbuffSize) ;
		if (pwRetbuff == NULL)
			return	LMR_ERROR ;

		nRetval	= (nNewWordLen < nRetbuffSize)? nNewWordLen : nRetbuffSize ;
		if (nRetval > 0)
			dcsncpy (pwRetbuff, dstrNewWord, nRetval) ;
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwRetbuff, nRetval) ;
	} else {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, NULL, 0) ;
	}
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan-in-minibuff
 */
static	int		LM_bSkkHenkanInMinibuff_1		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanInMinibuff_S2		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanInMinibuff_S3		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanInMinibuff_S4		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanInMinibuff_Exit	(struct CImeDoc*) ;

/*	�����Ƃ��āALMREGARG_0 �ɓ��͌��ʂ̕�������i�[���邽�߂̗̈��^���邱�ƁB
 *	�Ԃ�l�́A���͌��ʂ̕����񒷂� LMREGARG_RETVAL �ɐ����^�œ���B
 */
int
LM_bSkkHenkanInMinibuff (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPDSTR	pdText ;
	int		nTextDLen, iDepth ;
	DCHAR	bufKeyword [MAXCOMPLEN] ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, -1) ;
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, -1) ;
		return	LMR_RETURN ;
	}
	pdText	= (LPDSTR) ImeDoc_pAlloca (pDoc, MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pdText == NULL)
		return	LMR_ERROR ;
	if (! ImeDoc_bPushReg (pDoc, LMREG_0) ||
		! ImeDoc_bPushReg (pDoc, LMREG_1) ||
		! ImeDoc_bPushReg (pDoc, LMREG_2))
		return	LMR_ERROR ;
	ImeDoc_vSetRegString (pDoc, LMREG_0, pdText, MAXCOMPLEN) ;

	if (ImeConfig_bSkkNumericConversionp () && TSearchSession_bNumericp (pBuffer->m_pSkkCurrentSearchProgSession)) {
		nTextDLen	= iSkkNumComputeHenkanKey (pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, bufKeyword, MAXCOMPLEN, NULL, 0, ImeConfig_bSkkNumConvertFloatp ()) ;
	} else if (pBuffer->m_nSkkOkuriCharLen > 0) {
		nTextDLen	= iSkkComputeHenkanKey2 (bufKeyword, MAXCOMPLEN, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, pBuffer->m_bufSkkHenkanOkurigana, pBuffer->m_nSkkHenkanOkuriganaLen) ;
	} else {
		nTextDLen	= (pBuffer->m_nSkkHenkanKeyLen < MAXCOMPLEN)? pBuffer->m_nSkkHenkanKeyLen : MAXCOMPLEN ;
		dcsncpy (bufKeyword, pBuffer->m_bufSkkHenkanKey, nTextDLen) ;
	}
	if (nTextDLen < MAXCOMPLEN) {
		bufKeyword [nTextDLen]	= L'\0' ;
	} else {
		bufKeyword [MAXCOMPLEN - 1]	= L'\0' ;
	}
	iDepth	= ImeDoc_iGetMinibufferDepth (pDoc) ;
	if (iDepth > 8)
		iDepth	= 8 ;

//	nTextDLen	= wnsprintfW (pdText, MAXCOMPLEN, L"%s�����o�^%s %s ", L"[[[[[[[[[" + (8-iDepth), L"]]]]]]]]]" + (8-iDepth), bufKeyword) ;
	{
		LPDSTR	pdDest		= pdText ;
		LPCDSTR	pdDestEnd	= pdText + MAXCOMPLEN ;
		int		i ;

		for (i = 0 ; i <= iDepth && pdDest < pdDestEnd ; i ++) {
			*pdDest ++	= L'[' ;
		}
		vCopyStringW (&pdDest, pdDestEnd, L"�����o�^") ;
		for (i = 0 ; i <= iDepth && pdDest < pdDestEnd ; i ++) {
			*pdDest ++	= L']' ;
		}
		if (pdDest < pdDestEnd)
			*pdDest ++	= L' ' ;
		vCopyString (&pdDest, pdDestEnd, bufKeyword) ;
		if (pdDest < pdDestEnd)
			*pdDest ++	= L' ' ;
		nTextDLen		= pdDest - pdText ;
	}

	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pdText, nTextDLen) ;
	ImeDoc_vSetRegBool (pDoc, LMREGARG_1, pBuffer->m_bSkkJMode) ;
	if (! ImeDoc_bCall (pDoc, LM_bReadFromMinibuffer, LM_bSkkHenkanInMinibuff_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanInMinibuff_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPCDSTR					pwRead = NULL ;
	int						nRead ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (ImeDoc_bSignalp (pDoc)) {
		if (ImeDoc_nGetSignal (pDoc) != LMSIGNAL_QUIT) {
			ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
			return	LMR_CONTINUE ;
		} else {
			/* condition-case �� signal �������Ă���̂ŁB*/
			ImeDoc_vClearSignals (pDoc) ;
			nRead	= 0 ;
		}
	} else {
		if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_RETVAL, &pwRead, &nRead))
			nRead	= -1 ;
	}
	if (nRead < 0) {
		/* buffer �쐬���s�H */
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (ImeDoc_iGetLastCommand (pDoc) == NFUNC_ABORT_RECURSIVE_EDIT) {
		/* quit */
		nRead	= 0 ;
	}
	if (nRead == 0) {
		if (pBuffer->m_bSkkHenkanShowCandidatesMode) { /* skk-exit-show-candidates */
		} else {
			pBuffer->m_iSkkHenkanCount	-- ;
		}
		if (pBuffer->m_iSkkHenkanCount == -1) {
			pBuffer->m_nSkkHenkanOkuriganaLen	= 0 ;
			pBuffer->m_bSkkOkurigana			= LFALSE ;
			pBuffer->m_nSkkOkuriCharLen			= 0 ;
			imeBuffer_bSkkChangeMarkerToWhite (pBuffer) ;
		}
	} else {
		LPCDSTR	wptr ;
		int		nptr ;

		wptr	= pwRead + nRead - 1 ;
		nptr	= nRead ;
		while (nptr > 0 && 
#if defined (UNICODE) || defined (_UNICODE)
			(*wptr == TEXT(' ') || *wptr == TEXT('�@'))
#else
			(*wptr == L' ' || *wptr == L'�@')
#endif
			) {
			wptr	-- ;
			nptr	-- ;
		}
		nRead	= wptr - pwRead + 1 ;

		/*	������ #4 �̏��������Ȃ���΂Ȃ�Ȃ��̂Řb�͂����ȒP�ł͂Ȃ��B#4 �̏����A#4 �� replace
		 *	������ candidate �� insert �܂Ŏ��s���Ȃ���΂Ȃ�Ȃ��B
		 */
		/*	#4 ���܂܂ꂽ������ł��邩�H �������Aconcat �ň͂܂ꂽ������ #4 �͖������Ȃ��Ƃ����Ȃ��̂��H
		 *	��������͊ȒP�ł͂Ȃ��̂����c�B�Ƃ������Aconcat �̌��ʂ��X�ɐ��l�ϊ��Ƃ��� combo �͂���̂��H
		 *	���� concat (lisp �L�q)�� #4 �͑g�ݍ��킹���Ȃ��Ƃ��������u�����Ƃɂ���B
		 */
		if (nRead > 0 && TSearchSession_bNumericp (pBuffer->m_pSkkCurrentSearchProgSession) &&  !bStringLispFormatp (pwRead, nRead)) {
			LPDSTR		pwText, pwDest, pwDestEnd ;
			LPCDSTR		pwNumeric, pwEnd ;
			/*	���ʂ� #4 �̑��݂��`�F�b�N�ł��邩���B
			 */
			/*	MAXCOMPLEN �ȏ�̕�����͓��͂ł��Ȃ��̂ŁAwpText �Ƃ��� MAXCOMPLEN �����m�ۂ���
			 *	�Ζ��Ȃ��Ǝv���B
			 */
			pwText		= ImeDoc_pAlloca (pDoc, sizeof (DCHAR) * (nRead + MAXCOMPLEN + 1), __alignof (DCHAR)) ;
			if (pwText == NULL)
				return	LMR_ERROR ;	/* critical error */

			pwNumeric	= TSearchSession_pGetNumericList (pBuffer->m_pSkkCurrentSearchProgSession) ;
			pwDest		= pwText + nRead ;
			pwDestEnd	= pwDest + MAXCOMPLEN ;
			wptr		= pwRead ;
			pwEnd		= pwRead + nRead ;
			while (wptr < pwEnd) {
				if (*wptr == L'#') {
					LPCDSTR	wptrBase ;

					wptr	++ ;
					/*	���̏ꍇ�ɂ� #4 �ł���Ȃ��Ɋ֌W�Ȃ� numeric-list ��1�� skip ���Ȃ��Ƃ����Ȃ��B
					 */
					wptrBase	= wptr ;
					while (wptr < pwEnd && (L'0' <= *wptr && *wptr <= L'9'))
						wptr	++ ;
					if (wptr == (wptrBase + 1) && wptrBase < pwEnd && *wptrBase == L'4') {
						/*	���̍��ځB*/
						/*	�Ή����鐔�l�����݂��Ȃ���Ζ�������B*/
						if (*pwNumeric != L'\0') {
							LPDSTR	wptrDestBak	= pwDest ;
							/*	wptrNumeric �ɑ΂��ĐV�ɐ��l�o�^�����Ȃ��Ƃ����Ȃ��B*/
							vCopyString (&pwDest, pwDestEnd, pwNumeric) ;
							if (pwDest >= pwDestEnd) {
								/*	�o�b�t�@���I�[�o�[�����ꍇ�ɁA�I�[�o�[���钼�O�܂ł͔F�߂�̂��A
								 *	�S���S���j������̂��H
								 */
								pwDest	= wptrDestBak ;
								break ;
							}
							*pwDest ++	= L'\0' ;
						}
					}
					/*	wptrNumeric �����̍��ڂֈړ�������B
					 */
					if (*pwNumeric != L'\0') {
						pwNumeric	+= dcslen (pwNumeric) + 1 ;
					}
				} else {
					wptr	++ ;
				}
			}
			if (pwDest < pwDestEnd) {
				*pwDest ++	= L'\0' ;

				/*	#4 �o�^�̏����ւƕ��򂷂�B*/
				TS4Mapping_vClearList (pBuffer->m_plstSkkS4NumericMapping) ;
				pBuffer->m_plstSkkS4NumericMapping	= NULL ;

				dcsncpy (pwText, pwRead, nRead) ;
				ImeDoc_vSetRegConstString (pDoc, LMREG_1, pwText, nRead) ;
				ImeDoc_vSetRegConstString (pDoc, LMREG_2, pwText + nRead, pwDest - (pwText + nRead)) ;
				ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_S2) ;
				return	LMR_CONTINUE ;
			}
		}

		/* (setq skk-henkan-list (nconc skk-henkan-list (list new-one))) �����B*/
		if (nRead > 0 && pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
			/*	�V�K�Ɍ��� insert ���鎞�� #4 expand �� control �ł��邾�낤���H �����Z���K�v���낤�B
			 */
			if (! TSearchSession_bInsertCandidate (pBuffer->m_pSkkCurrentSearchProgSession, pwRead, nRead)) {
				ImeDoc_vSetSignalError (pDoc) ;
				ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
				return	LMR_CONTINUE ;
			}
		}
		pBuffer->m_bSkkKakuteiFlag	= TRUE ;
	}
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwRead, nRead) ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanInMinibuff_Exit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		TS4Mapping_vClearList (pBuffer->m_plstSkkS4NumericMapping) ;
		pBuffer->m_plstSkkS4NumericMapping	= NULL ;
	}
	ImeDoc_vPopReg (pDoc, LMREG_2) ;
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	return	LMR_RETURN ;
}

int
LM_bSkkHenkanInMinibuff_S2 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPDSTR		pdText ;
	LPCDSTR		pdNumeric ;
	int			nTextSize, nNumeric, iDepth, nText ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegString (pDoc, LMREG_0, &pdText, &nTextSize)) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_2, &pdNumeric, &nNumeric)) {
		pdNumeric	= NULL ;
		nNumeric	= 0 ;
	}
	if (nNumeric <= 0 || pdNumeric == NULL || *pdNumeric == L'\0') {
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_S4) ;
		return	LMR_CONTINUE ;
	}

	/*	"[#4�o�^] %s "
	 */
	iDepth	= ImeDoc_iGetMinibufferDepth (pDoc) ;
	if (iDepth > 8)
		iDepth	= 8 ;
	//nText	= wnsprintfW (pdText, nTextSize, L"%s�����o�^(#4)%s %s ", L"[[[[[[[[[" + (8-iDepth), L"]]]]]]]]]" + (8-iDepth), pdNumeric) ;
	{
		LPDSTR	pdDest		= pdText ;
		LPCDSTR	pdDestEnd	= pdText + nTextSize ;
		int	i ;

		for (i = 0 ; i <= iDepth && pdDest < pdDestEnd ; i ++)
			*pdDest ++	= L'[' ;
		vCopyStringW (&pdDest, pdDestEnd, L"�����o�^(#4)") ;
		for (i = 0 ; i <= iDepth && pdDest < pdDestEnd ; i ++)
			*pdDest ++	= L']' ;
		if (pdDest < pdDestEnd)
			*pdDest ++	= L' ' ;
		vCopyString (&pdDest, pdDestEnd, pdNumeric) ;
		if (pdDest < pdDestEnd)
			*pdDest ++	= L' ' ;
		nText	= pdDest - pdText ;
	}

	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pdText, nText) ;

	ImeDoc_vSetRegBool (pDoc, LMREGARG_1, pBuffer->m_bSkkJMode) ;
	if (! ImeDoc_bCall (pDoc, LM_bReadFromMinibuffer, LM_bSkkHenkanInMinibuff_S3))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanInMinibuff_S3 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPCDSTR					pwRead = NULL ;
	int						nRead ;
	LPCDSTR					pwNumeric ;
	int						nNumericSize, nNumericLen ;
	struct CTS4Mapping*		pNode ;

	/*	�������� quit �̔���܂ł́A���� bSkkHenkanInMinibuff_1 �Ɠ��������ł���B
	 */
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (ImeDoc_bSignalp (pDoc)) {
		if (ImeDoc_nGetSignal (pDoc) != LMSIGNAL_QUIT) {
			ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
			return	LMR_CONTINUE ;
		} else {
			/* condition-case �� signal �������Ă���̂ŁB*/
			ImeDoc_vClearSignals (pDoc) ;
			nRead	= 0 ;
		}
	} else {
		if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_RETVAL, &pwRead, &nRead))
			nRead	= -1 ;
	}

	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_2, &pwNumeric, &nNumericSize)) {
		pwNumeric		= NULL ;
		nNumericSize	= 0 ;
	}

	if (nRead < 0 || nNumericSize <= 0) {
		/* buffer �쐬���s�H */
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (ImeDoc_iGetLastCommand (pDoc) == NFUNC_ABORT_RECURSIVE_EDIT) {
		/* quit */
		nRead	= 0 ;
	}

	/*	�������� #4 ����B
	 */
	if (nRead > 0) {
		LPCDSTR	wptr ;
		int		nptr ;

		wptr	= pwRead + nRead - 1 ;
		nptr	= nRead ;
		while (nptr > 0 && 
#if defined (UNICODE) || defined (_UNICODE)
			(*wptr == TEXT(' ') || *wptr == TEXT('�@'))
#else
			(*wptr == L' ' || *wptr == L'�@')
#endif
			) {
			wptr	-- ;
			nptr	-- ;
		}
		nRead	= wptr - pwRead + 1 ;
	}

	/*	#4 �� mapping ���L������B*/
	pNode	= TS4Mapping_pCreate (pwNumeric, pwRead, nRead) ;
	if (pNode == NULL) {
		/* fatal */
		return	LMR_ERROR ;
	}
	/*	buffer-local variable �Ƃ������ƂŁApbuffer �̈ꕔ�Ƃ��ċL��������B
	 *	REG �̏ゾ�����ƁA������ꂸ�ɂЂǂ����ƂɂȂ肻���������̂ŁB
	 */
	if (! TS4Mapping_bInsertLast (&pBuffer->m_plstSkkS4NumericMapping, pNode)) {
		TS4Mapping_vClearList (pBuffer->m_plstSkkS4NumericMapping) ;
		pBuffer->m_plstSkkS4NumericMapping	= NULL ;
		return	LMR_ERROR ;
	}
	
	/*	���� numeric ���ւƈړ�������B
	 */
	nNumericLen		= dcslen (pwNumeric) ;
	pwNumeric		+= (nNumericLen + 1) ;
	nNumericSize	-= (nNumericLen + 1) ;
	if (nNumericSize <= 0) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_S4) ;
	} else {
		ImeDoc_vSetRegConstString (pDoc, LMREG_2, pwNumeric, nNumericSize) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_S2) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanInMinibuff_S4 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR		pdRead ;
	int			nReadDLen ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_1, &pdRead, &nReadDLen)) {
		pdRead	= NULL ;
		nReadDLen	= 0 ;
	}

	/* (setq skk-henkan-list (nconc skk-henkan-list (list new-one))) �����B*/
	if (nReadDLen > 0 && pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
		BOOL	bFound	= FALSE ;

		/*	�V�K�Ɍ��� insert ���鎞�� #4 expand �� control �ł��邾�낤���H �����Z���K�v���낤�B
		 */
		if (! TSearchSession_bInsertCandidateWithS4Mapping (pBuffer->m_pSkkCurrentSearchProgSession, pdRead, nReadDLen, pBuffer->m_plstSkkS4NumericMapping)) {
			ImeDoc_vSetSignalError (pDoc) ;
			ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
			return	LMR_CONTINUE ;
		}

		/*	���l�ϊ��̖�肩�����ǂݒ����K�v������B
//		pdRead	= TSearchSession_pGetReferCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
//		if (pdRead == NULL)
		 */
		pdRead	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
		if (pdRead != NULL) {
			nReadDLen	= dcslen (pdRead) ;
			if (nReadDLen > 0) {
				LPDSTR		pdRetbuf ;
				int			nRetbufSize ;

				pdRetbuf	= ImeDoc_pGetReturnBuffer (pDoc, &nRetbufSize) ;
				if (pdRetbuf != NULL && nRetbufSize > 0) {
					nReadDLen	= MIN (nRetbufSize, nReadDLen) ;
					dcsncpy (pdRetbuf, pdRead, nReadDLen) ;
					pdRead	= pdRetbuf ;
					bFound	= TRUE ;
				}
			}
		}
		if (! bFound) {
			pdRead	= NULL ;
			nReadDLen	= 0 ;
		}
	} else {
		pdRead	= NULL ;
		nReadDLen	= 0 ;
	}
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pdRead, nReadDLen) ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkanInMinibuff_Exit) ;
	return	LMR_CONTINUE ;
}

/*================================================================ skk-kana-clean-up
 */
static	int		LM_bSkkTryCompletion_1		(struct CImeDoc*) ;
static	int		LM_bSkkTryCompletion_Exit	(struct CImeDoc*) ;

int
LM_bSkkTryCompletion (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_bSkkHenkanMode == LON) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_0, (ImeDoc_iGetLastCommand (pDoc) != NFUNC_SKK_COMP_DO)? TRUE : FALSE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkCompDo, LM_bSkkTryCompletion_1))
			return	LMR_ERROR ;
	} else {
		if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkTryCompletion_Exit)) 
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkTryCompletion_1 (
	struct CImeDoc*		pDoc)
{
	if (! ImeDoc_bSignalp (pDoc)) {
		ImeDoc_bSetThisCommand (pDoc, NFUNC_SKK_COMP_DO) ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkTryCompletion_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkTryCompletion_Exit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-abbrev-comma
 */
int
LM_bSkkAbbrevComma (
	struct CImeDoc*		pDoc)
{
	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	if (ImeDoc_iGetLastCommand (pDoc) == NFUNC_SKK_COMP_DO) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkCompPrevious, LM_bSkkTryCompletion_1))
			return	LMR_ERROR ;
	} else {
		if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkTryCompletion_Exit)) 
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

/*================================================================ skk-abbrev-period
 */
int
LM_bSkkAbbrevPeriod (
	struct CImeDoc*		pDoc)
{
	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	if (ImeDoc_iGetLastCommand (pDoc) == NFUNC_SKK_COMP_DO) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_0, FALSE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkCompDo, LM_bSkkTryCompletion_1))
			return	LMR_ERROR ;
	} else {
		if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkTryCompletion_Exit)) 
			return	LMR_ERROR ;
	}
	return	LMR_CONTINUE ;
}

/*================================================================ skk-set-char-before-as-okurigana
 */
int
LM_bSkkSetCharBeforeAsOkurigana (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	BOOL				bNoSokuon	= FALSE ;
	int					iPt1, iOkuri = -1, iSokuon = -1 ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	iPt1	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
	if (iPt1 > 0) {
		iOkuri	= pBuffer->m_bufComp [iPt1 - 1] ;
	} else {
		iOkuri	= -1 ;
	}
	if (iOkuri >= 0) {
		int		iOkuriganaStartPoint, iBufferEnd ;
		struct TMarker*	pmkBufferEnd	= NULL ;

		if (! bNoSokuon) {
			iSokuon	= (iPt1 > 1)? pBuffer->m_bufComp [iPt1 - 2] : -1 ;
			if (
#if defined (UNICODE) || defined (_UNICODE)
				iSokuon != TEXT('��') && iSokuon != TEXT('�b')
#else
				iSokuon != L'��' && iSokuon != L'�b'
#endif
				)
				iSokuon	= -1 ;
		}
		if (! ImeBuffer_bSetMarker (pBuffer, &pBuffer->m_pmkSkkOkuriganaStartPoint, MARKER_SKK_OKURIGANA_START_POINT, pBuffer->m_pmkPoint) ||
			pBuffer->m_pmkSkkOkuriganaStartPoint == NULL) {
			ImeDoc_vSetSignalError (pDoc) ;
			return	LMR_RETURN ;
		}
		(void) TMarker_bBackward (pBuffer->m_pmkSkkOkuriganaStartPoint, iSokuon >= 0? 2 : 1) ;

		iOkuriganaStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkOkuriganaStartPoint) ;
		if (! ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkBufferEnd) || pmkBufferEnd == NULL) {
			iBufferEnd	= pBuffer->m_nbufComp ;
		} else {
			iBufferEnd	= TMarker_iGetPosition (pmkBufferEnd) ;
		}
		pBuffer->m_nSkkOkuriCharLen	= imeBuffer_iSkkOkuriganaPrefix (pBuffer, pBuffer->m_bufComp + iOkuriganaStartPoint, iBufferEnd - iOkuriganaStartPoint, pBuffer->m_bufSkkOkuriChar, ARRAYSIZE (pBuffer->m_bufSkkOkuriChar)) ;

		/*	original �ɂ́A������ skk-okurigana �� t �ɂ���R�[�h�͂Ȃ����A�����ǉ�����B
		 *	skk-henkan �ɑΉ�����code�� skk-okurigana �����Ă���̂ŁAnil �̂܂܂��Ƒ���ϊ��ɂȂ�Ȃ��B
		 */
		pBuffer->m_bSkkOkurigana	= LTRUE ;

		/*	���̏����͕K�v���낤���H
		if (pBuffer->m_pSkkCurrentSearchProgSession == NULL) {
		}
		*/
		ImeDoc_vJump (pDoc, LM_bSkkSetOkuriganaAdJisx0201) ;
		return	LMR_CONTINUE ;
	}
	return	LMR_RETURN ;
}


/*================================================================ skk-toggle-kutouten
 */
int
LM_bSkkToggleKutouten (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int					iCount ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	/*	��Ǔ_�^�C�v�𑝂₵�����Ƃ����l�͂���̂��낤���H 
	 *	�W���ł� 'en, 'jp �����Ȃ����Aalist �Ƃ������Ƃ͒ǉ����ł���Ƃ������ƂŁc
	 *	�����A���̏ꍇ�ɂ� toggle-kutoten ���ꎩ�̂��Ē�`���Ȃ��Ƃ����Ȃ����ǁB
	 */
	iCount	= ImeConfig_iGetNumberOfKutotens () ;
	if (iCount > 0) {
		pBuffer->m_bSkkCurrentKutotenType	= (pBuffer->m_bSkkCurrentKutotenType + 1) % iCount ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-current-kuten
 */
/*	interactive-function �ł͂Ȃ��̂����c�B
 */
int
LM_bSkkCurrentKuten (
	struct CImeDoc*		pDoc)
{
	LPCDSTR		pwKuten ;
	int			nKutenLen ;
//	LPDSTR		pwResult ;
//	int			nResultSize ;

	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
#if 0
	pwResult	= ImeDoc_pGetReturnBuffer (pDoc, &nResultSize) ;
	pwKuten		= ImeDoc_pGetCurrentKuten (pDoc, pBuffer->m_bSkkCurrentKutotenType, &nKutenLen) ;
	if (pwKuten != NULL && pwResult != NULL) {
		int		n	= MIN (nResultSize, nKutenLen) ;
		dcsncpy (pwResult, pwKuten, nKutenLen) ;
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwResult, nKutenLen) ;
	} else {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	}
#else
	pwKuten		= ImeConfig_pGetCurrentKuten (pBuffer->m_bSkkCurrentKutotenType, &nKutenLen) ;
	if (pwKuten != NULL) {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwKuten, nKutenLen) ;
	} else {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	}
#endif
	return	LMR_RETURN ;
}

/*================================================================ skk-current-touten
 */
/*	interactive-function �ł͂Ȃ��̂����c�ǂ����邩�B
 */
int
LM_bSkkCurrentTouten (
	struct CImeDoc*		pDoc)
{
	LPCDSTR		pwTouten ;
	int			nToutenLen ;
//	LPDSTR		pwResult ;
//	int			nResultSize ;

	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
#if 0
	pwResult	= ImeDoc_pGetReturnBuffer (pDoc, &nResultSize) ;
	pwTouten	= ImeDoc_pGetCurrentTouten (pDoc, pBuffer->m_bSkkCurrentKutotenType, &nToutenLen) ;
	if (pwTouten != NULL && pwResult != NULL) {
		int		n	= MIN (nResultSize, nToutenLen) ;
		dcsncpy (pwResult, pwTouten, nToutenLen) ;
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwResult, nToutenLen) ;
	} else {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	}
#else
	/*	�q�[�v��� pwTouten ���m�ۂ���Ă���̂ŁAReturn Buffer �ɃR�s�[����K�v�͂Ȃ��B
	 */
	pwTouten	= ImeConfig_pGetCurrentTouten (pBuffer->m_bSkkCurrentKutotenType, &nToutenLen) ;
	if (pwTouten != NULL) {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwTouten, nToutenLen) ;
	} else {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	}
#endif
	return	LMR_RETURN ;
}

/*================================================================ skk-toggle-characters
 */
static	int		LM_bSkkToggleCharacters_1 (struct CImeDoc*) ;
static	int		LM_bSkkToggleCharacters_2 (struct CImeDoc*) ;

int
LM_bSkkToggleCharacters (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bPushReg (pDoc, LMREG_0))
		return	LMR_ERROR ;

	if (pBuffer->m_bSkkHenkanMode == LON) {
		struct TMarker*		pmkHenkanStartPoint ;
		struct TMarker*		pmkPoint ;
		int					nEndPos, nPosition, nCH ;
		int					(*pFunc)(struct CImeDoc*) ;
		BOOL				bVContract	= FALSE ;

		if (! ImeBuffer_bGetMarker (pBuffer, MARKER_SKK_HENKAN_START_POINT, &pmkHenkanStartPoint) || pmkHenkanStartPoint == NULL ||
			! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
			ImeDoc_vSetSignalError (pDoc) ;
			return	LMR_RETURN ;
		}
		nEndPos		= TMarker_iGetPosition (pmkPoint) ;
		nPosition	= TMarker_iGetPosition (pmkHenkanStartPoint) ;
		pFunc		= NULL ;
		while (nPosition < nEndPos && nPosition < pBuffer->m_nbufComp) {
			nCH	= pBuffer->m_bufComp [nPosition] ;
			if (bHiraganaCharp (nCH)) {
				pFunc		= &LM_bSkkKatakanaRegion ;
				bVContract	= TRUE ;
				break ;
			} else if (bKatakanaCharp (nCH)) {
				pFunc		= &LM_bSkkHiraganaRegion ;
				break ;
			} else if (bJisx0208LatinCharp (nCH)) {
				pFunc		= &LM_bSkkLatinRegion ;
				break ;
			} else if (bSkkAsciiCharp (nCH)) {
				pFunc		= &LM_bSkkJisx0208LatinRegion ;
				break ;
			}
			nPosition	++ ;
		}
		ImeDoc_vSetRegPointer (pDoc, LMREGARG_0, pFunc) ;
		ImeDoc_vSetRegBool (pDoc, LMREGARG_1, bVContract) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkHenkanSkkRegionByFunc, LM_bSkkToggleCharacters_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else if (ImeDoc_bRecursiveEditp (pDoc) && ! pBuffer->m_bSkkJMode) {
		imeBuffer_bSkkJModeOn (pBuffer, FALSE) ;
	} else {
		pBuffer->m_bSkkKatakana	= ! pBuffer->m_bSkkKatakana ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkToggleCharacters_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkToggleCharacters_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) 
		ImeDoc_vSetRegBool   (pDoc, LMREG_0, pBuffer->m_bSkkKatakana) ;
	ImeDoc_vSetRegString (pDoc, LMREGARG_0, NULL, 0) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkToggleCharacters_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkToggleCharacters_2 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	BOOL					bSkkKatakana ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREG_0, &bSkkKatakana))
		bSkkKatakana	= FALSE ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (pBuffer->m_bSkkJMode) {
		imeBuffer_bSkkJModeOn (pBuffer, bSkkKatakana) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan-skk-region-by-func
 */
static	int		LM_bSkkHenkanSkkRegionByFunc_1		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanSkkRegionByFunc_Exit	(struct CImeDoc*) ;

int
LM_bSkkHenkanSkkRegionByFunc (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		return	LMR_RETURN ;
	} else if (pBuffer->m_bSkkHenkanMode == LON) {
		int		(*pFunc)(struct CImeDoc*) ;
		int		nHenkanStartPoint, nPoint, nPrefix ;
		BOOL	bVContract ;
		struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkHenkanEndPoint, MARKER_SKK_HENKAN_END_POINT, pBuffer->m_pmkPoint) ;
		nHenkanStartPoint	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
		nPoint				= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
		if (nHenkanStartPoint < nPoint && 0 <= nHenkanStartPoint && nHenkanStartPoint < pBuffer->m_nbufComp &&
			bHiraganaCharp (pBuffer->m_bufComp [nHenkanStartPoint])) {
			imeBuffer_bSkkUpdateKakuteiHistory (pBuffer, pBuffer->m_bufComp + nHenkanStartPoint, nPoint - nHenkanStartPoint, NULL, 0) ;
		}
		piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
		if (SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree)) {
//		if (TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) != NULL) {
			/* ���͓r���̉����v���t�B�N�X������܂��B*/
			ImeDoc_bSetMessageW (pDoc, L"���͓r���̉����v���t�B�N�X������܂�") ;
			ImeDoc_vSetSignalError (pDoc) ;
			ImeDoc_vJump (pDoc, LM_bSkkHenkanSkkRegionByFunc_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (nPoint < nHenkanStartPoint) {
			ImeDoc_bSetMessageW (pDoc, L"�J�[�\�����ϊ��J�n�n�_���O�ɂ���܂�") ;
			ImeDoc_vSetSignalError (pDoc) ;
			ImeDoc_vJump (pDoc, LM_bSkkHenkanSkkRegionByFunc_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (! ImeConfig_bSkkAllowsSpacesNewlinesAndTabs ()) {
			int		nPos ;

			for (nPos = nHenkanStartPoint ; nPos < nPoint && nPos < pBuffer->m_nbufComp ; nPos ++) {
				int		nCH	= pBuffer->m_bufComp [nPos] ;
				if (nCH == L' ' || nCH == L'\t' || nCH == L'\n' || nCH == L'\r') {
					ImeDoc_bSetMessageW (pDoc, L"�ϊ��L�[�ɉ��s���܂܂�Ă��܂�") ;
					ImeDoc_vSetSignalError (pDoc) ;
					ImeDoc_vJump (pDoc, LM_bSkkHenkanSkkRegionByFunc_Exit) ;
					return	LMR_CONTINUE ;
				}
			}
		}
		if (! ImeDoc_bGetRegPointer (pDoc, LMREGARG_0, (void**)&pFunc)) {
			ImeDoc_vSetSignalError (pDoc) ;
			ImeDoc_vJump (pDoc, LM_bSkkHenkanSkkRegionByFunc_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_1, &bVContract))
			bVContract	= FALSE ;
		if (pFunc != NULL) {
			ImeDoc_vSetRegInteger (pDoc, LMREGARG_0, nHenkanStartPoint) ;
			ImeDoc_vSetRegInteger (pDoc, LMREGARG_1, nPoint) ;
			ImeDoc_vSetRegBool (pDoc, LMREGARG_2, bVContract) ;
			if (! ImeDoc_bCall (pDoc, pFunc, LM_bSkkHenkanSkkRegionByFunc_1))
				return	LMR_ERROR ;
		} else {
			ImeDoc_vJump (pDoc, LM_bSkkHenkanSkkRegionByFunc_1) ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkHenkanSkkRegionByFunc_Exit))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
}

int
LM_bSkkHenkanSkkRegionByFunc_1 (
	struct CImeDoc*			pDoc)
{
	if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkHenkanSkkRegionByFunc_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanSkkRegionByFunc_Exit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/* skk-point-move �̌��ʁB*/
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-katakana-region
 */
int
LM_bSkkKatakanaRegion (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nStartPos, nEndPos, nLength, nReplaceText ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	BOOL	bVContract	= FALSE ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREGARG_0, &nStartPos) || ! ImeDoc_bGetRegInteger (pDoc, LMREGARG_1, &nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! imeBuffer_bValidRegionp (pBuffer, nStartPos, nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_2, &bVContract))
		bVContract	= FALSE ;

	nLength	= iSkkHiraganaToKatakana (bufTemp, ARRAYSIZE (bufTemp), pBuffer->m_bufComp + nStartPos, nEndPos - nStartPos, bVContract) ;

	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
		ImeBuffer_bDeleteRegion (pBuffer, nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nReplaceText) ;
		ImeBuffer_iInsertByPosition (pBuffer, nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-hiragana-region
 */
int
LM_bSkkHiraganaRegion (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nStartPos, nEndPos, nLength, nReplaceText ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	BOOL	bVExtract ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREGARG_0, &nStartPos) || ! ImeDoc_bGetRegInteger (pDoc, LMREGARG_1, &nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! imeBuffer_bValidRegionp (pBuffer, nStartPos, nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_2, &bVExtract))
		bVExtract	= FALSE ;
	nLength	= iSkkKatakanaToHiragana (bufTemp, ARRAYSIZE (bufTemp), pBuffer->m_bufComp + nStartPos, nEndPos - nStartPos, bVExtract) ;

	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
		ImeBuffer_bDeleteRegion (pBuffer, nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nReplaceText) ;
		ImeBuffer_iInsertByPosition (pBuffer, nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0208-latin-region
 */
int
LM_bSkkJisx0208LatinRegion (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nStartPos, nEndPos, nLength, nReplaceText ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pSrc, pSrcEnd ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREGARG_0, &nStartPos) || ! ImeDoc_bGetRegInteger (pDoc, LMREGARG_1, &nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! imeBuffer_bValidRegionp (pBuffer, nStartPos, nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	pDest		= bufTemp ;
	pDestEnd	= bufTemp + ARRAYSIZE (bufTemp) ;
	pSrc		= pBuffer->m_bufComp + nStartPos ;
	pSrcEnd		= pBuffer->m_bufComp + nEndPos ;
	while (pSrc < pSrcEnd && pDest < pDestEnd) {
		if (L' ' <= *pSrc && *pSrc <= L'~') {
			DCHAR	bufCH [MAXCOMPLEN] ;
			int		nLen	= ImeConfig_iSkkARefSkkJisx0208LatinVector (*pSrc, bufCH, ARRAYSIZE (bufCH)) ;

			if (nLen >= 0) {
				LPCDSTR	ptr ;

				ptr		= bufCH ;
				while (pDest < pDestEnd && nLen > 0) {
					*pDest ++	= *ptr ++ ;
					pSrc++;		// �C�� ���N���u����Ă��񂾂��̃o�O�c
					nLen--;
				}
			} else {
				*pDest ++	= *pSrc ++ ;
			}
		} else {
			*pDest ++	= *pSrc ++ ;
		}
	}

	nLength			= pDest - bufTemp ;
	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
		ImeBuffer_bDeleteRegion (pBuffer, nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nReplaceText) ;
		ImeBuffer_iInsertByPosition (pBuffer, nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-latin-region
 */
int
LM_bSkkLatinRegion (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int		nStartPos, nEndPos, nLength, nReplaceText ;
	DCHAR	bufTemp [MAXCOMPLEN] ;
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pSrc,  pSrcEnd ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREGARG_0, &nStartPos) || ! ImeDoc_bGetRegInteger (pDoc, LMREGARG_1, &nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! imeBuffer_bValidRegionp (pBuffer, nStartPos, nEndPos)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	pDest		= bufTemp ;
	pDestEnd	= bufTemp + ARRAYSIZE (bufTemp) ;
	pSrc		= pBuffer->m_bufComp + nStartPos ;
	pSrcEnd		= pBuffer->m_bufComp + nEndPos ; 
	while (pSrc < pSrcEnd && pDest < pDestEnd) {
		if (L'�@' <= *pSrc && *pSrc <= L'�`') {
			DCHAR	bufCH [16] ;
			int		nLen ;

			/*	skk-jisx0208-latin-vector ���t�Ɉ����B*/
			nLen	= ImeConfig_iSkkRevRefSkkJisx0208LatinVector (*pSrc, bufCH, ARRAYSIZE (bufCH)) ;
			if (nLen >= 0) {
				LPCDSTR	ptr ;

				ptr		= bufCH ;
				while (pDest < pDestEnd && nLen > 0) {
					*pDest ++	= *ptr ++ ;
				}
			} else {
				*pDest ++	= *pSrc ++ ;
			}
		} else {
			*pDest ++	= *pSrc ++ ;
		}
	}

	nLength			= pDest - bufTemp ;
	nReplaceText	= nEndPos - nStartPos ;
	if (nLength < nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
		ImeBuffer_bDeleteRegion (pBuffer, nStartPos + nLength, nEndPos) ;
	} else if (nLength > nReplaceText) {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nReplaceText) ;
		ImeBuffer_iInsertByPosition (pBuffer, nEndPos, bufTemp + nReplaceText, nLength - nReplaceText) ;
	} else {
		ImeBuffer_iOverwriteByPosition (pBuffer, nStartPos, bufTemp, nLength) ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-jisx0208-latin-insert
 */
static	int		LM_bSkkJisx0208LatinInsert_1	(struct CImeDoc*) ;
static	int		LM_bSkkJisx0208LatinInsert_2	(struct CImeDoc*) ;
static	int		LM_bSkkJisx0208LatinInsert_Exit	(struct CImeDoc*) ;

int
LM_bSkkJisx0208LatinInsert (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	DCHAR				bufResult [MAXCOMPLEN] ;
	LPDSTR				pwResult ;
	int					iCH ;
	int					nResult ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	iCH		= ImeDoc_iGetLastCommandChar (pDoc) ;
	nResult	= ImeConfig_iSkkARefSkkJisx0208LatinVector (iCH, bufResult, ARRAYSIZE (bufResult)) ;
	if (nResult < 0) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkJisx0208LatinInsert_Exit))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	pwResult	= ImeDoc_pAlloca (pDoc, nResult * sizeof (DCHAR), __alignof (DCHAR)) ;
	if (pwResult == NULL)
		return	LMR_ERROR ;
	if (! ImeDoc_bPushReg (pDoc, LMREG_0))
		return	LMR_ERROR ;

	dcsncpy (pwResult, bufResult, nResult) ;
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwResult, nResult) ;
	ImeDoc_vSetRegConstString (pDoc, LMREG_0,    pwResult, nResult) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkInsertStr, LM_bSkkJisx0208LatinInsert_1))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkJisx0208LatinInsert_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				pwResult ;
	int					nResult ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkJisx0208LatinInsert_Exit) ;
		return	LMR_CONTINUE ;
	}

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkJisx0208LatinInsert_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_0, &pwResult, &nResult)) {
		pwResult	= NULL ;
		nResult		= 0 ;
	}

	/*	�y�A���́c�B���܂�L���ł͂Ȃ��̂�����ǂ������͂��Ă����B
	 */
	if (nResult > 0 && ImeConfig_bSkkAutoInsertParen ()) {
		DCHAR	bufPairStr [MAXCOMPLEN] ;
		int		nPairStr ;

		nPairStr	= ImeConfig_iSkkAssocSkkAutoParenStringAlist (pwResult, nResult, bufPairStr, ARRAYSIZE (bufPairStr)) ;
		if (nPairStr > 0) {
			LPDSTR			pwPairStr ;
			struct TMarker*	pmkPoint ;
			struct TMarker*	pmkMark ;

			pwPairStr	= ImeDoc_pAlloca (pDoc, nPairStr * sizeof (DCHAR), __alignof (DCHAR)) ;
			if (pwPairStr == NULL)
				return	LMR_ERROR ;

			pmkMark		= ImeBuffer_pMakeMarker (pBuffer, FALSE) ;
			if (pmkMark == NULL || ! ImeBuffer_bGetMarker (pBuffer, MARKER_POINT, &pmkPoint) || pmkPoint == NULL) {
				ImeDoc_vSetSignalError (pDoc) ;
				ImeDoc_vJump (pDoc, LM_bSkkJisx0208LatinInsert_Exit) ;
				return	LMR_CONTINUE ;
			}
			TMarker_bSetPosition (pmkMark, pmkPoint) ;

			dcsncpy (pwPairStr, bufPairStr, nPairStr) ;
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwPairStr, nPairStr) ;
			ImeDoc_vSetRegPointer (pDoc, LMREG_0, pmkMark) ;

			/*	���̃R�[�h�� insert �񐔂𐔂��āA�J�[�\���� backward ���Ă��邪�c�B�������� insert
			 *	�񐔂́A���ۂ� insert ���ꂽ�ʂƈقȂ�\���������Č������B
			 *	marker ���g���� cursor �ʒu���L������̂��ǂ����B
			 */
			if (! ImeDoc_bCall (pDoc, LM_bSkkInsertStr, LM_bSkkJisx0208LatinInsert_2))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	ImeDoc_vJump (pDoc, LM_bSkkJisx0208LatinInsert_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkJisx0208LatinInsert_2 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	struct TMarker*		pmkMark ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		/* �������� buffer �s�݂ł̓}�[�J�̔j�����ł��Ȃ��B*/
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkJisx0208LatinInsert_Exit) ;
		return	LMR_CONTINUE ;
	}
	/*	signal ��Ԃł��낤�ƂȂ��낤�ƁAmarker ��j�����Ȃ��Ƃ܂����B
	 */
	if (! ImeDoc_bGetRegPointer (pDoc, LMREG_0, (void**)&pmkMark)) {
		pmkMark	= NULL ;
	}
	if (pmkMark != NULL) {
		TMarker_bSetPosition (pBuffer->m_pmkPoint, pmkMark) ;
		ImeBuffer_bDeleteMarker (pBuffer, pmkMark) ;
	}
	ImeDoc_vJump (pDoc, LM_bSkkJisx0208LatinInsert_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkJisx0208LatinInsert_Exit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		/* skk-point-move �̌��ʁB*/
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	}
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-kana-clean-up
 */
static	int		LM_bSkkKanaCleanup_1 (struct CImeDoc*) ;
static	int		LM_bSkkKanaCleanup_2 (struct CImeDoc*) ;

int
LM_bSkkKanaCleanup (
	struct CImeDoc*		pDoc)
{
	const struct CSkkRuleTreeNodeOutput*	pData	= NULL ;
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				wstrKana ;
	int					nKanaLen, nNextState ;
	BOOL				bForce ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	/*	Register �o�R�ň�����n���̂��c�H
	 */
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_0, &bForce)) {
		bForce	= FALSE ;
	}

	piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
	/* 	������ BOOL bForce ���ǂ�����Ď󂯎��̂��c�B*/
	if (SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) && ! SkkRuleTreeIterator_bHaveNextState (piteSkkRuleTree)) {
//	if (pBuffer->m_pSkkCurrentRuleTree != NULL && TSkkRuleTreeNode_pGetNextState (pBuffer->m_pSkkCurrentRuleTree, &nNextState) == NULL) {
		pData	= SkkRuleTreeIterator_pGetOutput (piteSkkRuleTree) ;
//		pData	= TSkkRuleTreeNode_pGetOutput (pBuffer->m_pSkkCurrentRuleTree) ;
	} else {
		pData	= NULL ;
	}
	if (bForce || pData != NULL) {
		imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;

		wstrKana	= NULL ;
		nKanaLen	= 0 ;
		if (pData != NULL) {
			int		nType	= TSkkRuleTreeNodeOutput_iGetType (pData) ;
			if (nType == NTYPE_MACRO) {
				int		nFuncNo ;
				PLMFUNC	pPC	= NULL ;

				/*	�ށAskk-kana-cleanup ���܂����̂��B������ execute ���Ȃ��Ƃ����Ȃ��̂ŁA��x�����Ԃ��Ȃ���΁c�B
				 */
				TSkkRuleTreeNodeOutput_bGetMacro (pData, &nFuncNo) ;
				pPC	= ImeDoc_pLookupLMState (pDoc, nFuncNo) ;
				if (pPC == NULL) {
					ImeDoc_vSetSignalError (pDoc) ;
					return	LMR_RETURN ;
				}
				if (! ImeDoc_bCall (pDoc, pPC, LM_bSkkKanaCleanup_1))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			} else {
				if (nType == NTYPE_STRINGPAIR) {
					if (pBuffer->m_bSkkKatakana) {
						TSkkRuleTreeNodeOutput_bGetRString (pData, &wstrKana, &nKanaLen) ;
					} else {
						TSkkRuleTreeNodeOutput_bGetLString (pData, &wstrKana, &nKanaLen) ;
					}
				} else if (nType == NTYPE_STRING) {
					TSkkRuleTreeNodeOutput_bGetString (pData, &wstrKana, &nKanaLen) ;
				}
			}
		}
		if (wstrKana != NULL && nKanaLen > 0) {
			LPDSTR	pwString ;

			pwString	= ImeDoc_pAlloca (pDoc, nKanaLen * sizeof (DCHAR), __alignof (DCHAR)) ;
			if (pwString == NULL) 
				return	LMR_ERROR ;
			dcsncpy (pwString, wstrKana, nKanaLen) ;
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwString, nKanaLen) ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkInsertStr, LM_bSkkKanaCleanup_2))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
		pBuffer->m_pmkSkkKanaStartPoint	= NULL ;
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
LM_bSkkKanaCleanup_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				pwString, pwLeft, pwRight ;
	int					nStringLen, nLeft, nRight, nResultLen ;
	LPDSTR				pwResult ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/*	Macro �����s������̏����B�{���͂��̌��ʂ� string �Ł`�Ƃ����\���B
	 */
	if (ImeDoc_bGetRegConstString (pDoc, LMREGARG_RETVAL, &pwString, &nStringLen)) {
		/* ... */
	} else if (ImeDoc_bGetRegConstStringPair (pDoc, LMREGARG_RETVAL, &pwLeft, &nLeft, &pwRight, &nRight)) {
		pwString	= (pBuffer->m_bSkkKatakana)? pwRight : pwLeft ;
		nStringLen	= (pBuffer->m_bSkkKatakana)? nRight  : nLeft ;
	} else {
		pwString	= NULL ;
		nStringLen	= 0 ;
	}
	if (pwString != NULL && nStringLen > 0) {
		pwResult	= ImeDoc_pAlloca (pDoc, nStringLen * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pwResult == NULL)
			return	LMR_ERROR ;
		dcsncpy (pwResult, pwString, nStringLen) ;
		nResultLen	= nStringLen ;
	} else {
		pwResult	= NULL ;
		nResultLen	= 0 ;
	}
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pwResult, nResultLen) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkInsertStr, LM_bSkkKanaCleanup_2))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKanaCleanup_2 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	pBuffer->m_pmkSkkKanaStartPoint	= NULL ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-insert-str
 */
/*
(defun skk-insert-str (str)
  "STR ��}������B�K�v�ł���� `self-insert-after-hook' ���R�[������B
`overwrite-mode' �ł���΁A�K�؂ɏ㏑�����s���B"
  (insert-and-inherit str)
  (if (eq skk-henkan-mode 'on)
      ;;
      (when (and skk-auto-start-henkan
				 (not skk-okurigana))
		(skk-auto-start-henkan str))
    ;;
    (when (and (boundp 'self-insert-after-hook)
		       self-insert-after-hook)
      (funcall self-insert-after-hook
		       (- (point) (length str))
		       (point)))
    (when overwrite-mode
      (skk-del-char-with-pad (skk-ovwrt-len (string-width str)))))
  ;; SKK 9.6 �ł͂��̃^�C�~���O�� fill ���s���Ă������ASKK 10 �ł͍s���Ă�
  ;; �Ȃ������B
  (when (and skk-j-mode
		     (not skk-henkan-mode))
    (skk-do-auto-fill)))
		*/
int
LM_bSkkInsertStr (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				pwString ;
	int					nStringLen ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &pwString, &nStringLen)) {
		pwString	= NULL ;
		nStringLen	= 0 ;
	}
	ImeBuffer_bInsertAndInherit (pBuffer, pwString, nStringLen) ;
	if (pBuffer->m_bSkkHenkanMode == LON) {
		if (ImeConfig_bSkkAutoStartHenkanp () && ! pBuffer->m_bSkkOkurigana) {
			ImeDoc_vJump (pDoc, LM_bSkkAutoStartHenkan) ;
			return	LMR_CONTINUE ;
		}
	} else {
		/* self-insert-after-hook �̎����͂Ȃ��B*/
		/* overwrite-mode �̎������Ȃ��B*/
	}
	/* skk-do-auto-fill �� editor ���̋@�\�ł���Ǝv���̂Ŏ����͂Ȃ��B*/
	return	LMR_RETURN ;
}

/*================================================================ skk-auto-start-henkan
 */
static	int		LM_bSkkAutoStartHenkan_1	(struct CImeDoc*) ;
static	int		LM_bSkkAutoStartHenkan_Exit	(struct CImeDoc*) ;

int
LM_bSkkAutoStartHenkan (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				pwString ;
	int					nStringLen ;
	struct TMarker*		pmkMark ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1))
		return	LMR_ERROR ;

	/*	skk-save-point ���������Ă���̂�Y��Ă���I
	 */
	pmkMark	= ImeBuffer_pMakeMarker (pBuffer, TRUE) ;
	if (pmkMark == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	TMarker_bSetPosition (pmkMark, pBuffer->m_pmkPoint) ;
	ImeDoc_vSetRegPointer (pDoc, LMREG_0, pmkMark) ;

	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &pwString, &nStringLen)) {
		pwString	= NULL ;
		nStringLen	= 0 ;
	}
	if (ImeConfig_bSkkAutoStartHenkanKeywordp (pwString, nStringLen)) {
		if (! ImeBuffer_bBackwardChar (pBuffer, 1)) {
			ImeDoc_vSetSignalError (pDoc) ;
			ImeDoc_vJump (pDoc, LM_bSkkAutoStartHenkan_Exit) ;
			return	LMR_CONTINUE ;
		}
		if (pBuffer->m_pmkSkkHenkanStartPoint != NULL && TMarker_bIsValidp (pBuffer->m_pmkSkkHenkanStartPoint) &&
			TMarker_iGetPosition (pBuffer->m_pmkPoint) > TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) {
			LPDSTR		pwSkkPrefix ;

			/* let skk-prefix "" �� emulation�Bskk-prefix ���ꎞ�I�ɑޔ�����B*/
			if (pBuffer->m_nSkkPrefixLen > 0) {
				pwSkkPrefix	= ImeDoc_pAlloca (pDoc, pBuffer->m_nSkkPrefixLen * sizeof (DCHAR), __alignof (DCHAR)) ;
				if (pwSkkPrefix == NULL)
					return	LMR_ERROR ;
				dcsncpy (pwSkkPrefix, pBuffer->m_bufSkkPrefix, pBuffer->m_nSkkPrefixLen) ;
			} else {
				pwSkkPrefix	= NULL ;
			}
			if (! ImeDoc_bPushReg (pDoc, LMREG_1))
				return	LMR_ERROR ;
			ImeDoc_vSetRegConstString (pDoc, LMREG_1, pwSkkPrefix, pBuffer->m_nSkkPrefixLen) ;

			pBuffer->m_nSkkPrefixLen	= 0 ;
			ImeDoc_vSetRegNil (pDoc, LMREGARG_0) ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkStartHenkan, LM_bSkkAutoStartHenkan_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	ImeDoc_vJump (pDoc, LM_bSkkAutoStartHenkan_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkAutoStartHenkan_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR				pwSkkPrefix ;
	int					nSkkPrefix ;

	if (ImeDoc_bSignalp (pDoc)) 
		goto	exit_func ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	/* skk-prefix �̕��A�B*/
	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_1, &pwSkkPrefix, &nSkkPrefix)) {
		pwSkkPrefix	= NULL ;
		nSkkPrefix	= 0 ;
	}
	if (nSkkPrefix > 0) 
		dcsncpy (pBuffer->m_bufSkkPrefix, pwSkkPrefix, nSkkPrefix) ;
	pBuffer->m_nSkkPrefixLen	= nSkkPrefix ;

exit_func:
	ImeDoc_vJump (pDoc, LM_bSkkAutoStartHenkan_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkAutoStartHenkan_Exit (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;

	/*	�J�[�\���}�[�J�̈ʒu�����B
	 */
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		struct TMarker*	pmkMark ;

		/*	�ۑ����Ă������}�[�J�Ƀ|�C���g�����킹��B
		 */
		if (ImeDoc_bGetRegPointer (pDoc, LMREG_0, (void**)&pmkMark) && pmkMark != NULL && TMarker_bIsValidp (pmkMark)) {
			TMarker_bSetPosition (pBuffer->m_pmkPoint, pmkMark) ;
			ImeBuffer_bDeleteMarker (pBuffer, pmkMark) ;
		}
	}
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-change-marker
 */
static	int		LM_bSkkChangeMarker_1 (struct CImeDoc*) ;

int
LM_bSkkChangeMarker (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int					nPosition ;

	if (ImeDoc_bSignalp (pDoc)) {
		return	LMR_RETURN ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_pmkSkkHenkanStartPoint == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	nPosition	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) - 1 ;
	if (nPosition < 0) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (pBuffer->m_bufComp [nPosition] != L'��') {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkChangeMarker_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	TMarker_bSetPosition (pBuffer->m_pmkPoint, pBuffer->m_pmkSkkHenkanStartPoint) ;
	TMarker_bBackward (pBuffer->m_pmkPoint, 1) ;
	ImeBuffer_bInsertAndInheritW (pBuffer, L"��", 1) ;
	ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint) + 1) ;
	pBuffer->m_bSkkHenkanMode	= LACTIVE ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

int
LM_bSkkChangeMarker_1 (
	struct CImeDoc*		pDoc)
{
	/* (skk-error "It seems that you have delete ��") */
	ImeDoc_vSetSignalError (pDoc) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-purge-from-jisyo
 */
/*
;;; jisyo related functions
(defun skk-purge-from-jisyo (&optional arg)
  "�����[�h�Ō��݂̌��������o�b�t�@�����������B"
  (interactive "*P")
  (skk-with-point-move
   (cond
    ((not (eq skk-henkan-mode 'active))
     (skk-emulate-original-map arg))
    ((and (eq skk-henkan-mode 'active)
		  (not (string= skk-henkan-key ""))
		  (yes-or-no-p
		   (format
		    (if skk-japanese-message-and-error
				"%s /%s/%s����������폜���܂��B�ǂ��ł����H"
		      "Really purge \"%s /%s/%s\"?")
		    skk-henkan-key
		    (skk-get-current-candidate)
		    (cond
		     ((not (and skk-henkan-okurigana
						(or skk-henkan-okuri-strictly
						    skk-henkan-strict-okuri-precedence)))
		      " ")
		     (skk-japanese-message-and-error
		      (format " (���艼��: %s) " skk-henkan-okurigana))
		     (t
		      (format " (okurigana: %s) " skk-henkan-okurigana))))))
     ;; skk-henkan-start-point ���� point �܂ō폜���Ă��܂��Ă��A�ϊ�����
     ;; �� (�J�[�\���𓮂������ƂȂ�) skk-purge-from-jisyo ���ĂׂΖ��Ȃ�
     ;; ���A�J�[�\�����Ⴄ�ꏊ�ֈړ����Ă����ꍇ�́A�폜���ׂ��łȂ����̂�
     ;; �ō폜���Ă��܂��\��������B�����ŁA���艼��������΂��̒�������
     ;; �߂� end �����߁A����̕ϊ��Ɋ֘A�����������𐳊m�ɐ؂���悤��
     ;; ����B
     (let ((end (if skk-henkan-okurigana
				    (+ (length skk-henkan-okurigana)
				       skk-henkan-end-point)
				  skk-henkan-end-point))
		   (word (skk-get-current-candidate)))
       (skk-update-jisyo word 'purge)
       ;; Emacs 19.28 ���� Overlay �������Ă����Ȃ��ƁA���� insert �����
       ;; skk-henkan-key �ɉ��̂� Overlay ���������Ă��܂��B
       (when skk-use-face
		 (skk-henkan-face-off))
       (delete-region skk-henkan-start-point end)
       (skk-change-marker-to-white)
       (skk-kakutei)))))
  nil) */

static	int		LM_bSkkPurgeFromJisyo_1		(struct CImeDoc*) ;
static	int		LM_bSkkPurgeFromJisyo_2		(struct CImeDoc*) ;
static	int		LM_bSkkPurgeFromJisyo_3		(struct CImeDoc*) ;
static	int		LM_bSkkPurgeFromJisyo_4		(struct CImeDoc*) ;
static	int		LM_bSkkPurgeFromJisyo_5		(struct CImeDoc*) ;
static	int		LM_bSkkPurgeFromJisyo_Exit	(struct CImeDoc*) ;

int
LM_bSkkPurgeFromJisyo (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (! ImeDoc_bPushReg (pDoc, LMREG_0) ||
		! ImeDoc_bPushReg (pDoc, LMREG_1) ||
		! ImeDoc_bPushReg (pDoc, LMREG_2) ||
		! ImeDoc_bPushReg (pDoc, LMREG_3))
		return	LMR_ERROR ;

	if (pBuffer->m_bSkkHenkanMode != LACTIVE) {
		if (! ImeDoc_bCall (pDoc, LM_bSkkEmulateOriginalMap, LM_bSkkPurgeFromJisyo_Exit))
			return	LMR_ERROR ;
	} else {
		if (pBuffer->m_bSkkHenkanMode == LACTIVE && pBuffer->m_nSkkHenkanKeyLen > 0) {
			LPDSTR	pdText ;
			DCHAR	bufOkurigana [128] ;
			LPCDSTR	pwCandidate ;
			LPDSTR	pdDest, pdDestEnd ;
			int		nText ;

			pwCandidate	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
			if (pwCandidate == NULL) {
				ImeDoc_vSetSignalError (pDoc) ;
				return	LMR_RETURN ;
			}

#define	TEMP_TEXTBUFSIZE	384
			pdText	= ImeDoc_pAlloca (pDoc, sizeof (DCHAR) * TEMP_TEXTBUFSIZE, __alignof (DCHAR)) ;
			if (pdText == NULL)
				return	LMR_ERROR ;
			ImeDoc_vSetRegString (pDoc, LMREG_0, pdText, TEMP_TEXTBUFSIZE) ;

			if (! (pBuffer->m_bSkkOkurigana && (ImeConfig_bSkkHenkanOkuriStrictlyp () || ImeConfig_bSkkHenkanStrictOkuriPrecedencep ()))) {
				bufOkurigana [0]	= L' ' ;
				bufOkurigana [1]	= L'\0' ;
			} else {
				pdDest		= bufOkurigana ;
				pdDestEnd	= bufOkurigana + ARRAYSIZE (bufOkurigana) - 1 ;
				vCopyStringW (&pdDest, pdDestEnd, L" (���艼��: ") ;
				vCopyStringN (&pdDest, pdDestEnd, pBuffer->m_bufSkkHenkanOkurigana, pBuffer->m_nSkkHenkanOkuriganaLen) ;
				vCopyStringW (&pdDest, pdDestEnd, L") ") ;
				*pdDest		= L'\0' ;
			}

			pdDest		= pdText ;
			pdDestEnd	= pdText + TEMP_TEXTBUFSIZE - 1 ;
			vCopyStringN (&pdDest, pdDestEnd, pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen) ;
			vCopyStringW (&pdDest, pdDestEnd, L" /") ;
			vCopyString  (&pdDest, pdDestEnd, pwCandidate) ;
			if (pdDest < pdDestEnd)
				*pdDest ++	= L'/' ;
			vCopyString  (&pdDest, pdDestEnd, bufOkurigana) ;
			vCopyStringW (&pdDest, pdDestEnd, L"����������폜���܂��B��낵���ł����H") ;
			*pdDest	= L'\0' ;
			nText	= pdDest - pdText ;
#undef	TEMP_TEXTBUFSIZE

			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pdText, nText) ;
			/*	yes-or-no ���Ăяo���B
			 */
			if (! ImeDoc_bCall (pDoc, LM_bYesOrNop, LM_bSkkPurgeFromJisyo_1))
				return	LMR_ERROR ;
		} else {
			ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		}
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkPurgeFromJisyo_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	BOOL				bRetval ;

	if (ImeDoc_bSignalp (pDoc)) {
		if (ImeDoc_nGetSignal (pDoc) == LMSIGNAL_QUIT) 
			ImeDoc_vClearSignals (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_RETVAL, &bRetval)) {
		bRetval	= FALSE ;
	}
	if (bRetval) {
		LPCDSTR		pdWord ;
		int			nWordDLen ;

		/*	skk-henkan-okurigana �̏��� skk-update-jisyo �̌���c���Ă�����̂Ɖ��肵��
		 *	�����ł͐����Ȃ��B
		 */
		pdWord		= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
		nWordDLen	= dcslen (pdWord) ;

		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pdWord, nWordDLen) ;
		ImeDoc_vSetRegBool        (pDoc, LMREGARG_1, TRUE) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkUpdateJisyo, LM_bSkkPurgeFromJisyo_2))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	} else {
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_2) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkPurgeFromJisyo_2 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! TSearchSession_bNumericp (pBuffer->m_pSkkCurrentSearchProgSession) ||
		TSearchSession_pGetReferCandidate (pBuffer->m_pSkkCurrentSearchProgSession) == NULL) {
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_5) ;
		return	LMR_CONTINUE ;
	}
	/*	������ #4 �ϊ��������ꍇ�ɂ� #4 �Ή��̍폜���q�˂�K�v�����邪�c
	 */
	ImeDoc_vSetRegInteger (pDoc, LMREG_1, 0) ;
	ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_3) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkPurgeFromJisyo_3 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	struct CTS4Candidate*	pS4Node ;
	int						nTextSize, num, i ;
	LPDSTR					pdText, pdDest, pdDestEnd ;
	LPCDSTR					pdNumKeyword, pdNumResult ;
	int						nNumKeywordLen, nNumResultLen ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	if (! ImeDoc_bGetRegString (pDoc, LMREG_0, &pdText, &nTextSize) || 
		! ImeDoc_bGetRegInteger (pDoc, LMREG_1, &num)) {
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	/* #4 �̃`�F�b�N���s���B*/
	pS4Node	= TSearchSession_pGetNumericLink (pBuffer->m_pSkkCurrentSearchProgSession) ;
	
	for (i = 0 ; i < num && pS4Node != NULL ; i ++) {
		pS4Node	= TSearchSession_pGetNextNumericLink	(pBuffer->m_pSkkCurrentSearchProgSession, pS4Node) ;
	}
	while (pS4Node != NULL) {
		/*	"[#4�폜] %s /%s/ ����������폜���܂����H"
		 *	�����c�d�����������ꍇ�ɂ͂����Ƃ����������B
		 */
		pdNumKeyword	= TSearchSession_pGetNumericKeyword (pBuffer->m_pSkkCurrentSearchProgSession, pS4Node, &nNumKeywordLen) ;
		pdNumResult		= TSearchSession_pGetNumericResult  (pBuffer->m_pSkkCurrentSearchProgSession, pS4Node, &nNumResultLen) ;
		if (pdNumKeyword != NULL && nNumKeywordLen > 0 && pdNumResult != NULL && nNumResultLen > 0)
			break ;
		pS4Node	= TSearchSession_pGetNextNumericLink	(pBuffer->m_pSkkCurrentSearchProgSession, pS4Node) ;
		num	++ ;
	}
	if (pS4Node == NULL) {
		/* �I���B*/
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_5) ;
		return	LMR_CONTINUE ;
	}

	ImeDoc_vSetRegInteger     (pDoc, LMREG_1, num) ;
	ImeDoc_vSetRegConstString (pDoc, LMREG_2, pdNumKeyword, nNumKeywordLen) ;
	ImeDoc_vSetRegConstString (pDoc, LMREG_3, pdNumResult,  nNumResultLen) ;

	pdDest			= pdText ;
	pdDestEnd		= pdText + nTextSize ;
	vCopyStringW (&pdDest, pdDestEnd, L"[#4�폜] ") ;
	vCopyStringN (&pdDest, pdDestEnd, pdNumKeyword, nNumKeywordLen) ;
	vCopyStringW (&pdDest, pdDestEnd, L" /") ;
	vCopyStringN (&pdDest, pdDestEnd, pdNumResult, nNumResultLen) ;
	vCopyStringW (&pdDest, pdDestEnd, L"/ ����������폜���܂��B��낵���ł����H") ;
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pdText, pdDest - pdText) ;
	if (! ImeDoc_bCall (pDoc, LM_bYesOrNop, LM_bSkkPurgeFromJisyo_4))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkPurgeFromJisyo_4 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPDSTR					pwText ;
	LPCDSTR					pwNumKeyword, pwNumResult ;
	int						nNumKeywordLen, nNumResultLen, num, nTextSize ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	/*	�ϊ��L�[���ꎞ�I�ɕۑ�����B*/
	if (! ImeDoc_bGetRegString (pDoc, LMREG_0, &pwText, &nTextSize) || 
		! ImeDoc_bGetRegInteger (pDoc, LMREG_1, &num) ||
		! ImeDoc_bGetRegConstString (pDoc, LMREG_2, &pwNumKeyword, &nNumKeywordLen) ||
		! ImeDoc_bGetRegConstString (pDoc, LMREG_3, &pwNumResult,  &nNumResultLen)) {
		/* error */
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	/*  skk-update-jisyo ���Ăяo���B
	 *	�͕s�\�B
	 *	���R�́cHenkanKey �� numeric-convertion ����Ă��܂��� # �ɗ��Ƃ���Ă��܂�����B
	 */
	TPurgeSession_bUpdate (pwNumKeyword, nNumKeywordLen, pwNumResult, nNumResultLen, NULL, 0, FALSE) ;

	/*  ���� S4Node ���w���B*/
	num	++ ;
	ImeDoc_vSetRegInteger (pDoc, LMREG_1, num) ;

	ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_3) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkPurgeFromJisyo_5 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int					nStart, nEnd ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkPurgeFromJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}

	nStart	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint) ;
	nEnd	= TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint) ; 
	if (pBuffer->m_nSkkHenkanOkuriganaLen > 0) {
		nEnd	+= pBuffer->m_nSkkHenkanOkuriganaLen ;
	}
	ImeBuffer_bDeleteRegion (pBuffer, nStart, nEnd) ;
	imeBuffer_bSkkChangeMarkerToWhite (pBuffer) ;

	ImeDoc_vSetRegNil (pDoc, LMREGARG_0) ;
	if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkPurgeFromJisyo_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkPurgeFromJisyo_Exit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	ImeDoc_vPopReg (pDoc, LMREG_3) ;
	ImeDoc_vPopReg (pDoc, LMREG_2) ;
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/* skk-point-move �̌��ʁB*/
	imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-update-jisyo
 */
static	int		LM_bSkkUpdateJisyo_1	(struct CImeDoc*) ;
static	int		LM_bSkkUpdateJisyo_2	(struct CImeDoc*) ;
static	int		LM_bSkkUpdateJisyo_Exit	(struct CImeDoc*) ;

/*	LMARG_0:		pWord, nWordLen (STRING)
 *	LMARG_1:		bPurge (BOOL)
 */
int
LM_bSkkUpdateJisyo (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPDSTR	pMidashi ;
	int		nMidashiLen ;
	LPCDSTR	pWord ;
	int		nWordLen ;
	BOOL	bPurge ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &pWord, &nWordLen)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	/* bPurge ���͏ȗ��\�B*/
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_1, &bPurge)) {
		bPurge	= FALSE ;
	}

	if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1))
		return	LMR_ERROR ;

	/*	���ꂾ�Ɩ{���ɐ��l�ϊ������s���Ă��邩���炩����Ȃ��悤�Ɏv����ȁc�B
	 */
	if (ImeConfig_bSkkNumericConversionp () && (bStringNumericWordp (pWord, nWordLen) || bStringLispFormatp (pWord, nWordLen))) {
		pMidashi	= ImeDoc_pAlloca (pDoc, MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pMidashi == NULL) 
			return	LMR_ERROR ;
		nMidashiLen	= iSkkNumComputeHenkanKey (pBuffer->m_bufSkkHenkanKey, pBuffer->m_nSkkHenkanKeyLen, pMidashi, MAXCOMPLEN, NULL, 0, ImeConfig_bSkkNumConvertFloatp ()) ;
	} else {
		pMidashi	= pBuffer->m_bufSkkHenkanKey ;
		nMidashiLen	= pBuffer->m_nSkkHenkanKeyLen ;
	}
	if (pBuffer->m_iSkkOkuriIndexMin > -1) {
		LPDSTR	pNewWord ;
		pNewWord	= ImeDoc_pAlloca (pDoc, MAXCOMPLEN * sizeof (DCHAR), __alignof (DCHAR)) ;
		if (pNewWord == NULL)
			LMR_ERROR ;
		ImeDoc_vSetRegString (pDoc, LMREG_0, pNewWord, MAXCOMPLEN) ;
		ImeDoc_vSetRegBool   (pDoc, LMREG_1, bPurge) ;

		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pWord, nWordLen) ;
		ImeDoc_vSetRegString (pDoc, LMREGARG_1, pNewWord, MAXCOMPLEN) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkRemoveCommon, LM_bSkkUpdateJisyo_1))
			return	LMR_ERROR ;
	} else {
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pWord,    nWordLen) ;
		ImeDoc_vSetRegBool        (pDoc, LMREGARG_1, bPurge) ;
		ImeDoc_vSetRegConstString (pDoc, LMREGARG_2, pMidashi, nMidashiLen) ;
		ImeDoc_vJump (pDoc, LM_bSkkUpdateJisyo_2) ;
	}
	return	LMR_CONTINUE ;
}

int
LM_bSkkUpdateJisyo_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPDSTR		pWord ;
	int			nMaxWordSize, nWordLen ;
	LPCDSTR		pMidashi ;
	int			nMidashiLen ;
	BOOL		bPurge ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREGARG_RETVAL, &nWordLen)) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegString (pDoc, LMREG_0, &pWord, &nMaxWordSize)) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkUpdateJisyo_Exit) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREG_1, &bPurge))
		bPurge	= FALSE ;

	pMidashi	= pBuffer->m_bufSkkHenkanKey ;
	nMidashiLen	= pBuffer->m_nSkkHenkanKeyLen ;
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, pWord, nWordLen) ;
	ImeDoc_vSetRegBool        (pDoc, LMREGARG_1, bPurge) ;
	ImeDoc_vSetRegConstString (pDoc, LMREGARG_2, pMidashi, nMidashiLen) ;
	ImeDoc_vJump (pDoc, LM_bSkkUpdateJisyo_2) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkUpdateJisyo_2 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPDSTR	pWord ;
	LPCDSTR	pMidashi, pOkurigana ;
	int		nWordLen, nMidashiLen, nOkuriganaLen ;
	BOOL	bPurge, bOkuri ;
	BOOL	(*pUpdateProc)(LPCDSTR, int, LPCDSTR, int, LPCDSTR, int, BOOL) = NULL ;
	const DCHAR	c_Zero	= L'\0' ;

	if (ImeDoc_bSignalp (pDoc))
		goto	exit_func ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &pWord, &nWordLen)) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_1, &bPurge)) 
		bPurge	= FALSE ;
	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_2, &pMidashi, &nMidashiLen)) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	if (pBuffer->m_nSkkHenkanOkuriganaLen > 0) {
		pOkurigana		= pBuffer->m_bufSkkHenkanOkurigana ;
		nOkuriganaLen	= pBuffer->m_nSkkHenkanOkuriganaLen ;
	} else if (pBuffer->m_nSkkOkuriCharLen > 0) {
		pOkurigana		= pBuffer->m_bufSkkOkuriChar ;
		nOkuriganaLen	= pBuffer->m_nSkkOkuriCharLen ;
	} else {
		pOkurigana		= NULL ;
		nOkuriganaLen	= 0 ;
	}
	/* okurigana, midashi, word, purge/record �̃y�A�œo�^����B*/
	if (! bPurge) {
		pUpdateProc	= TRecordSession_bUpdate ;
	} else {
		pUpdateProc	= TPurgeSession_bUpdate ;
	}
	if (pUpdateProc == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	bOkuri	= FALSE ;
	if (nOkuriganaLen > 0) {
		/*	skk-process-okuri-early �̎��ɂ́A���艼�������ł������̂�������Ȃ��B
		 */
		if (ImeConfig_bSkkProcessOkuriEarlyp ()) {
			pOkurigana		= &c_Zero ; 
			nOkuriganaLen	= 0 ;
		}
		bOkuri	= TRUE ;
	} else {
		/*	skk-process-okuri-early �̎��ɂ́A���艼�������ł������̂�������Ȃ��B
		 */
		if (ImeConfig_bSkkProcessOkuriEarlyp () && 
			pBuffer->m_bSkkJMode && 
			pBuffer->m_nSkkHenkanKeyLen > 1 && 
			(ImeConfig_bSkkSetHenkanPointKeyp (towupper (pBuffer->m_bufSkkHenkanKey [pBuffer->m_nSkkHenkanKeyLen - 1])) ||
			ImeConfig_bSkkSetHenkanPointKeyp (towlower (pBuffer->m_bufSkkHenkanKey [pBuffer->m_nSkkHenkanKeyLen - 1])))) {
			pOkurigana		= &c_Zero ; 
			nOkuriganaLen	= 0 ;
			bOkuri			= TRUE ;
		}
	}
	if ((*pUpdateProc) (pMidashi, nMidashiLen, pWord, nWordLen, pOkurigana, nOkuriganaLen, bOkuri)) {
		/* ���̌��o���� Word �Œ��O�� kakutei-history �Ƃ��ċL������B*/
		if (! bOkuri) 
			imeBuffer_bSkkUpdateKakuteiHistory (pBuffer, pMidashi, nMidashiLen, pWord, nWordLen) ;
	}
exit_func:
	ImeDoc_vJump (pDoc, LM_bSkkUpdateJisyo_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkUpdateJisyo_Exit (
	struct CImeDoc*		pDoc)
{
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-remove-common
 */

static	int	LM_bSkkRemoveCommon_1 (struct CImeDoc*) ;

/*	�Ԃ�l: LMREGARG_RETVAL �� WordResult �� length
 */
int
LM_bSkkRemoveCommon (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPCDSTR		pWord ;
	int			nWordLen ;
	LPDSTR		pwWordResult ;
	int			nWordResultSize ;
	LPCDSTR		pMidashi ;
	int			nMidashiLen, nNewWordLen ;

	if (ImeDoc_bSignalp (pDoc))
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREGARG_0, &pWord, &nWordLen) ||
		! ImeDoc_bGetRegString      (pDoc, LMREGARG_1, &pwWordResult, &nWordResultSize)) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if ((pBuffer->m_pSkkCurrentSearchProgSession != NULL && TSearchSession_bNumericp (pBuffer->m_pSkkCurrentSearchProgSession)) ||
		pBuffer->m_bSkkAbbrevMode ||
		! (pBuffer->m_bSkkHenkanInMinibuffFlag || (pBuffer->m_iSkkOkuriIndexMin <= pBuffer->m_iSkkHenkanCount && pBuffer->m_iSkkHenkanCount <= pBuffer->m_iSkkOkuriIndexMax))) {
		ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, 0) ;
		return	LMR_RETURN ;
	}

	pMidashi	= pBuffer->m_bufSkkHenkanKey ;
	nMidashiLen	= pBuffer->m_nSkkHenkanKeyLen ;
	if (nMidashiLen >= 2 && nWordLen >= 2) {
		int		nMidashiTail, nWordTail ;

		if (bSkkAsciiCharp (pMidashi [nMidashiLen - 1]) && pMidashi [nMidashiLen - 1] == pWord [nWordLen - 1]) {
			nMidashiLen	-- ;
			nWordLen	-- ;
		}
		nMidashiTail	= pMidashi [nMidashiLen - 1] ;
		nWordTail		= pWord [nWordLen - 1] ;
		if (nMidashiTail == nWordTail && ((L'��' <= nMidashiTail && nMidashiTail <= L'��') || nMidashiTail == L'�A' || nMidashiTail == L'�B' || nMidashiTail == L'�C' || nMidashiTail == L'�D')) {
			int		nPos, nPos2, nChar ;

			nPos	= nWordLen - 1 ;
			while (nPos > 0) {
				nChar	= pWord [nPos - 1] ;
				if (bCJKKanjip (nChar)) { /* unicode �Ŋ������ǂ���������āc�ǂ����邩�B*/
					break ;
				}
				nPos	-- ;
			}
			nPos2	= nMidashiLen - (nWordLen - nPos) ;

			if (nMidashiLen == nWordLen && memcmp (pMidashi + nPos2, pWord + nPos, sizeof (DCHAR) * nMidashiLen) == 0) {
				DCHAR	bufHenkanOkurigana	[2] ;
				DCHAR	bufNewSkkHenkanKey	[MAXCOMPLEN] ;
				DCHAR	bufNewWord			[MAXCOMPLEN] ;
				DCHAR	bufNewSkkOkuriChar	[MAXCOMPLEN] ;
				int		nOkuriFirst, nHenkanOkuriganaLen, nNewSkkOkuriCharLen, nNewSkkHenkanKeyLen ;

				nOkuriFirst				= pWord [nPos] ;
				bufHenkanOkurigana [0]	= nOkuriFirst ;
				nHenkanOkuriganaLen		= 1 ;
				if (nOkuriFirst == L'��' && (nPos + 2) <= nWordLen) {
					bufHenkanOkurigana [1]	= pWord [nPos + 1] ;
					nHenkanOkuriganaLen	++ ;
				}

				nNewWordLen			= nPos ;
				if (nNewWordLen >= ARRAYSIZE (bufNewWord)) {
					ImeDoc_vSetSignalError (pDoc) ;
					return	LMR_RETURN ;
				}
				dcsncpy (bufNewWord, pWord, nNewWordLen) ;
				bufNewWord [nNewWordLen]	= L'\0' ;
				nNewSkkOkuriCharLen	= imeBuffer_iSkkOkuriganaPrefix (pBuffer, bufHenkanOkurigana, nHenkanOkuriganaLen, bufNewSkkOkuriChar, ARRAYSIZE (bufNewSkkOkuriChar)) ;

				nNewSkkHenkanKeyLen	= nPos2 + nNewSkkOkuriCharLen ;
				if ((nPos2 + nNewSkkOkuriCharLen) >= ARRAYSIZE (bufNewSkkHenkanKey)) {
					ImeDoc_vSetSignalError (pDoc) ;
					return	LMR_RETURN ;
				}
				dcsncpy (bufNewSkkHenkanKey,         pMidashi + 0,       nPos2) ;
				dcsncpy (bufNewSkkHenkanKey + nPos2, bufNewSkkOkuriChar, nNewSkkOkuriCharLen) ;
				bufNewSkkHenkanKey [nNewSkkHenkanKeyLen]	= L'\0' ;

				if (nNewWordLen > nWordResultSize) {
					ImeDoc_vSetSignalError (pDoc) ;
					return	LMR_RETURN ;
				}

				if (!pBuffer->m_bSkkHenkanInMinibuffFlag) {
					dcsncpy (pBuffer->m_bufSkkHenkanKey, bufNewSkkHenkanKey, nNewSkkHenkanKeyLen) ;
					pBuffer->m_nSkkHenkanKeyLen	= nNewSkkHenkanKeyLen ;
					dcsncpy (pBuffer->m_bufSkkOkuriChar, bufNewSkkOkuriChar, nNewSkkOkuriCharLen) ;
					pBuffer->m_nSkkOkuriCharLen	= nNewSkkOkuriCharLen ;

					dcsncpy (pwWordResult, bufNewWord, nNewWordLen) ;
				} else {
					DCHAR	bufText [256] ;
					int		nText ;
					LPDSTR	pwText, pwNewWord, pwNewSkkHenkanKey, pwNewSkkOkuriChar ;

					{
						/* Shall I register this as okuri-ari word: %s /%s/ ? */
//						nText	= wnsprintfW (bufText, ARRAYSIZE (bufText), L"Shall I register this as okuri-ari word: %s /%s/ ? ", bufNewSkkHenkanKey, bufNewWord) ;
						LPDSTR	pdDest		= bufText ;
						LPCDSTR	pdDestEnd	= bufText + ARRAYSIZE (bufText) ;

						vCopyStringW (&pdDest, pdDestEnd, L"Shall I register this as okuri-ari word: ") ;
						vCopyString  (&pdDest, pdDestEnd, bufNewSkkHenkanKey) ;
						vCopyStringW (&pdDest, pdDestEnd, L" /") ;
						vCopyString  (&pdDest, pdDestEnd, bufNewWord) ;
						vCopyStringW (&pdDest, pdDestEnd, L"/ ? ") ;
						nText		= pdDest - bufText ;
					}
					if (! ImeDoc_bPushReg (pDoc, LMREG_0) || ! ImeDoc_bPushReg (pDoc, LMREG_1) ||
						! ImeDoc_bPushReg (pDoc, LMREG_2) || ! ImeDoc_bPushReg (pDoc, LMREG_3))
						return	LMR_ERROR ;

#define	SAFE_ALLOCA_STRING(pDest,pSrc,nSize,nAlign)	\
	if ((nSize) > 0) { \
		(pDest) = ImeDoc_pAlloca (pDoc, (nSize), (nAlign)) ; \
		if ((pDest) == NULL) \
			return LMR_ERROR ; \
		memcpy ((pDest), (pSrc), (nSize)) ; \
	} else { \
		(pDest) = NULL ; \
	}
					SAFE_ALLOCA_STRING (pwNewWord,			bufNewWord,			nNewWordLen				* sizeof (DCHAR), __alignof (DCHAR)) ;
					SAFE_ALLOCA_STRING (pwNewSkkHenkanKey,	bufNewSkkHenkanKey,	nNewSkkHenkanKeyLen		* sizeof (DCHAR), __alignof (DCHAR)) ;
					SAFE_ALLOCA_STRING (pwNewSkkOkuriChar,	bufNewSkkOkuriChar,	nNewSkkOkuriCharLen		* sizeof (DCHAR), __alignof (DCHAR)) ;
					SAFE_ALLOCA_STRING (pwText,				bufText,			nText					* sizeof (DCHAR), __alignof (DCHAR)) ;
#undef	SAFE_ALLOCA_STRING
					ImeDoc_vSetRegConstString (pDoc, LMREG_0, pwNewWord,			nNewWordLen) ;
					ImeDoc_vSetRegConstString (pDoc, LMREG_1, pwNewSkkHenkanKey,	nNewSkkHenkanKeyLen) ;
					ImeDoc_vSetRegConstString (pDoc, LMREG_2, pwNewSkkOkuriChar,	nNewSkkOkuriCharLen) ;
					ImeDoc_vSetRegString      (pDoc, LMREG_3, pwWordResult,			nWordResultSize) ;
					ImeDoc_vSetRegString (pDoc, LMREGARG_0, pwText, nText) ;
					if (! ImeDoc_bCall (pDoc, LM_bYesOrNop, LM_bSkkRemoveCommon_1))
						return	LMR_ERROR ;
					return	LMR_CONTINUE ;
				}
			}
		}
	}
	ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, nNewWordLen) ;
	return	LMR_RETURN ;
}

/*
					// yes-or-no-p �Ŏ��s������ skk-henkan-okurigana �� nil �� skk-okuri-char �� nil ���B
					if (! ImeDoc_bYesOrNop (pBuffer->m_pDoc, bufText, nText, &bRetval)) {
						return	FALSE ;
					}
					if (bRetval) {
						memcpy (pBuffer->m_bufSkkHenkanKey, bufNewSkkHenkanKey, sizeof (DCHAR) * nNewSkkHenkanKeyLen) ;
						pBuffer->m_nSkkHenkanKeyLen	= nNewSkkHenkanKeyLen ;
						memcpy (pBuffer->m_bufSkkOkuriChar, bufNewSkkOkuriChar, sizeof (DCHAR) * nNewSkkOkuriCharLen) ;
						pBuffer->m_nSkkOkuriCharLen	= nNewSkkOkuriCharLen ;

						memcpy (pwWordResult, bufNewWord, sizeof (DCHAR) * nNewWordLen) ;
					} else {
						pBuffer->m_nSkkHenkanOkuriganaLen	= 0 ;
						pBuffer->m_nSkkOkuriCharLen			= 0 ;
					}
					ImeDoc_vClearMessage (pBuffer->m_pDoc) ;
 */
int
LM_bSkkRemoveCommon_1 (
	struct CImeDoc*		pDoc)
{
	struct CImeBuffer*	pBuffer ;
	LPCDSTR	pNewSkkHenkanKey, pNewSkkOkuriChar, pNewWord ;
	int		nNewSkkHenkanKeyLen, nNewSkkOkuriCharLen, nNewWordLen ;
	LPDSTR	pwWordResult ;
	int		nWordResultSize ;
	BOOL	bYesOrNo ;

	if (ImeDoc_bSignalp (pDoc))
		goto	exit_func ;
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		goto	exit_func ;
	}
	if (! ImeDoc_bGetRegBool (pDoc, LMREGARG_RETVAL, &bYesOrNo)) 
		goto	exit_func ;
	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_0, &pNewWord, &nNewWordLen)) {
		pNewWord			= NULL ;
		nNewWordLen			= 0 ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_1, &pNewSkkHenkanKey, &nNewSkkHenkanKeyLen)) {
		pNewSkkHenkanKey	= NULL ;
		nNewSkkHenkanKeyLen	= 0 ;
	}
	if (! ImeDoc_bGetRegConstString (pDoc, LMREG_2, &pNewSkkOkuriChar, &nNewSkkOkuriCharLen)) {
		pNewSkkOkuriChar	= NULL ;
		nNewSkkOkuriCharLen	= 0 ;
	}
	if (! ImeDoc_bGetRegString (pDoc, LMREG_3, &pwWordResult, &nWordResultSize)) {
		pwWordResult	= NULL ;
		nWordResultSize	= 0 ;
	}
	if (bYesOrNo) {
		if (nNewSkkHenkanKeyLen > 0)
			dcsncpy (pBuffer->m_bufSkkHenkanKey, pNewSkkHenkanKey, nNewSkkHenkanKeyLen) ;
		pBuffer->m_nSkkHenkanKeyLen	= nNewSkkHenkanKeyLen ;
		if (nNewSkkOkuriCharLen > 0)
			dcsncpy (pBuffer->m_bufSkkOkuriChar, pNewSkkOkuriChar, nNewSkkOkuriCharLen) ;
		pBuffer->m_nSkkOkuriCharLen	= nNewSkkOkuriCharLen ;

		if (nNewWordLen > 0) {
			nNewWordLen	= MIN (nNewWordLen, nWordResultSize) ;
			if (nNewWordLen > 0 && pwWordResult != NULL)
				dcsncpy (pwWordResult, pNewWord, nNewWordLen) ;
		}
	} else {
		pBuffer->m_nSkkHenkanOkuriganaLen	= 0 ;
		pBuffer->m_nSkkOkuriCharLen			= 0 ;
		nNewWordLen							= 0 ;
	}
	ImeDoc_vClearMessage (pDoc) ;
	ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, nNewWordLen) ;

exit_func:
	ImeDoc_vPopReg (pDoc, LMREG_3) ;
	ImeDoc_vPopReg (pDoc, LMREG_2) ;
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	return	LMR_RETURN ;
}

/*================================================================ skk-henkan-show-candidates
 */
/*	�����̓���͗ǂ��Ȃ��B���̂Ȃ���ꗗ��\������@�\�� Windows ���� interface �����邩��B
 *	�܂��A���͌�ł��킹��Ƃ������ƂŃX���[����B
 */
static	int		LM_bSkkHenkanShowCandidates_1		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanShowCandidates_2		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanShowCandidates_3		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanShowCandidates_4		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanShowCandidates_5		(struct CImeDoc*) ;
static	int		LM_bSkkHenkanShowCandidates_Exit_0	(struct CImeDoc*) ;
static	int		LM_bSkkHenkanShowCandidates_Exit	(struct CImeDoc*) ;

/*	�Ԃ�l: LMREGARG_RETVAL �ɑI���������̕�����
 *			LMREGARG_0	�ɗ^����ꂽ�o�b�t�@�ɑI���������(�̕�����)���R�s�[
 */
int
LM_bSkkHenkanShowCandidates (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;

	if (ImeDoc_bSignalp (pDoc)) 
		return	LMR_RETURN ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}
	if (! ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanEndPoint))) {
		ImeDoc_vSetSignalError (pDoc) ;
		return	LMR_RETURN ;
	}

	//strCandidateKey	= ImeDoc_pGetSkkHenkanShowCandidatesKeys (pBuffer->m_pDoc, &nCandidateKey) ;
	//nMaxShow		= (nCandidateKey < 7)? nCandidateKey : 7 ;	/* candidate-key ��7�Œ�ɂ��ׂ����H */
	//nLoop			= 0 ;

	pBuffer->m_bSkkHenkanShowCandidatesMode	= TRUE ;

	if (! ImeDoc_bPushReg (pDoc, LMREG_1) || ! ImeDoc_bPushReg (pDoc, LMREG_2) ||
		! ImeDoc_bPushReg (pDoc, LMREG_3) || ! ImeDoc_bPushReg (pDoc, LMREG_4))
		return	LMR_ERROR ;

	ImeDoc_vSetRegInteger	(pDoc, LMREG_1, 0) ;			/* nLoop */
	ImeDoc_vSetRegBool		(pDoc, LMREG_2, FALSE) ;		/* bUpdateShow */
	ImeDoc_vSetRegInteger	(pDoc, LMREG_4, 0) ;			/* nShow */
	ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanShowCandidates_Exit (
	struct CImeDoc*			pDoc)
{
	ImeDoc_vPopReg (pDoc, LMREG_4) ;
	ImeDoc_vPopReg (pDoc, LMREG_3) ;
	ImeDoc_vPopReg (pDoc, LMREG_2) ;
	ImeDoc_vPopReg (pDoc, LMREG_1) ;
	return	LMR_RETURN ;
}

int
LM_bSkkHenkanShowCandidates_1 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	int		nCandidateKey, nLoop, nMaxShow ;
	DCHAR	buffer [512] ;
	LPDSTR	pDest, pDestEnd ;
	LPCDSTR	pCandidateKey ;
	BOOL	bSearchContinue ;
	int		nShow, nHenkanCount, iShowAnnotation ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_1, &nLoop))
		nLoop		= 0 ;

	pCandidateKey	= ImeConfig_pGetSkkHenkanShowCandidatesKeys (&nCandidateKey) ;
	nMaxShow		= (nCandidateKey < IMEDOC_NUMHENKANSHOWCANDIDATES)? nCandidateKey : IMEDOC_NUMHENKANSHOWCANDIDATES ;	/* candidate-key ��7�Œ�ɂ��ׂ����H */

	/* �P���7���\������Ηǂ������̂悤���B���G�ɏ������Ƃ͂Ȃ��B*/
	nHenkanCount	= pBuffer->m_iSkkHenkanCount + nLoop * nMaxShow ;
	pDest			= buffer ;
	pDestEnd		= buffer + ARRAYSIZE (buffer) ;
	nShow			= 0 ;
	iShowAnnotation	= ImeConfig_iGetSkkShowAnnotationType () ;

	buffer [0]	= L'\0' ;
	if (pBuffer->m_pSkkCurrentSearchProgSession != NULL) {
#if defined (UNITTEST)
		LPCDSTR		pSrc ;
		int			nLeft ;
		DCHAR		buf [64] ;

		while (nShow < nMaxShow) {
			LPCDSTR		wstrNewWord ;
			if (pDest < pDestEnd) 
				*pDest ++	= *pCandidateKey ++ ;
			if (pDest < pDestEnd)
				*pDest ++	= L':' ;
			wstrNewWord		=TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
			if (wstrNewWord != NULL) {
				int		nNewWordLen ;

				nNewWordLen	= lstrlenW (wstrNewWord) ;
				/* lisp function ��������Ă��邩�ǂ������`�F�b�N����B*/
				/* Annotation ���O���K�v������B*/
				if (iShowAnnotation != DISABLE_ANNOTATION) {
					pSrc	= wstrNewWord + nNewWordLen - 1 ;
					while (pSrc >= wstrNewWord && *pSrc != L';')
						pSrc -- ;
					if (pSrc >= wstrNewWord && *pSrc == L';') 
						nNewWordLen	= pSrc - wstrNewWord ;
				}
				pSrc		= wstrNewWord ;
				while (pDest < pDestEnd && nNewWordLen > 0) {
					*pDest ++	= *pSrc ++ ;
					nNewWordLen	-- ;
				}
			} else {
				/* ���̏ꍇ�͖�������ׂ����B*/
			}
			if (pDest < pDestEnd)
				*pDest ++	= L' ' ;
				nShow	++ ;
			if (!TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession))
				break ;
		}
		nLeft	= TSearchSession_iGetNumberOfCandidate (pBuffer->m_pSkkCurrentSearchProgSession, &bSearchContinue) - nHenkanCount - nShow ;
		wnsprintf (buf, ARRAYSIZE (buf) - 1, L"[�c�� %d%s]", nLeft, (bSearchContinue? L"+" : L"")) ;
		buf [ARRAYSIZE (buf) - 1]	= L'\0' ;
		pSrc	= buf ;
		while (pDest < pDestEnd && *pSrc != L'\0') {
			*pDest ++	= *pSrc ++ ;
		}
		ImeDoc_bSetMessageN (pDoc, buffer, pDest - buffer) ;
#else
		if (! imeBuffer_bInitializeHenkanCandidateList (pBuffer, nHenkanCount)) {
			/* fatal error */
			return	LMR_ERROR ;
		}
		/*
		 *	ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_UPDATE_CANDIDATES or IMEDOC_UPDATE_CANDIDATES) ;
		 *	���͍쐬�ƍX�V�������Ȃ̂ŁB
		 */
		ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_UPDATE_CANDIDATELIST) ;
#endif
	} else {
		ImeDoc_vClearMessage (pDoc) ;	/* ����̓G���[�ł́H */
		ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, -1) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	ImeDoc_vSetRegInteger (pDoc, LMREG_4, nShow) ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_2) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanShowCandidates_2 (
	struct CImeDoc*			pDoc)
{
	ImeDoc_vSetRegBool (pDoc, LMREG_2, FALSE) ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_3) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanShowCandidates_3 (
	struct CImeDoc*			pDoc)
{
	int			nLoop ;
	BOOL		bUpdateShow ;

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_1, &nLoop))
		nLoop	= 0 ;
	if (! ImeDoc_bGetRegBool    (pDoc, LMREG_2, &bUpdateShow))
		bUpdateShow	= FALSE ;
#if !defined (UNITTEST)
#else
	if (bUpdateShow) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_1) ;
		return	LMR_CONTINUE ;
	}
#endif
	if (! ImeDoc_bCall (pDoc, LM_bNextCommandEvent, LM_bSkkHenkanShowCandidates_4))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanShowCandidates_4 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	struct TMSG				ev ;
	int						n, nCH, nShow, nCandidateKey, nLoop, nMaxShow ;
	LPCDSTR					pCandidateKey ;
	BOOL					bKeyChar, bUpdateShow ;

	if (! ImeDoc_bGetRegMsg (pDoc, LMREGARG_RETVAL, &ev)) {
		/* FALSE exit */
		ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, -1) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}

	/* �C�x���g���L�����N�^�[�ɕϊ�����B*/
	bKeyChar	= ImeDoc_bEventToCharacter (&ev, &nCH) ;
	if (! bKeyChar) {
		/* original map �̎��s�́H */
		nCH	= -1 ;
//		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_3) ;
//		return	LMR_CONTINUE ;
	}

	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_4, &nShow))
		nShow	= 0 ;

	/* ������ skk-key-num-alist �ƌ���ׂāA��₪�I�΂ꂽ�����`�F�b�N����B*/
	pCandidateKey	= ImeConfig_pGetSkkHenkanShowCandidatesKeys (&nCandidateKey) ;
	nMaxShow		= (nCandidateKey < IMEDOC_NUMHENKANSHOWCANDIDATES)? nCandidateKey : IMEDOC_NUMHENKANSHOWCANDIDATES ;	/* candidate-key ��7�Œ�ɂ��ׂ����H */
	n				= 0 ;
	bUpdateShow		= FALSE ;

#if !defined (UNITTEST)
	/*	nShow �͍Čv�Z����Ȃ��̂ŁAMaxShow �ɌŒ肵�Ă��܂��B(!UNITETEST ���_)
	 */
	nShow			= nMaxShow ;
#endif
	while (n < nShow && n < nCandidateKey) {
		if (towlower (pCandidateKey [n]) == towlower (nCH)) {
			/* found */
			break ;
		}
		n	++ ;
	}
	if (! ImeDoc_bGetRegInteger (pDoc, LMREG_1, &nLoop))
		nLoop	= 0 ;
	if (n < nShow && n < nCandidateKey) {
		int		nBack ;
		LPCDSTR	wstrNewWord ;
#if !defined (UNITTEST)
		TVarbuffer*	pvbufCandInfo ;
#endif

		/* ����I������B*/
#if !defined (UNITTEST)
		nBack	= n ;
		while (nBack > 0 && TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession))
			nBack	-- ;
		if (nBack != 0) {
			/*	�����Ă����ʂȃL�[���������B*/
			while (nBack < n && TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession))
				nBack	++ ;
			goto	exit_func ;
		}
#else
		nBack	= nShow - n - 1 ;
		while (nBack > 0 && TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) 
			nBack	-- ;
#endif

		wstrNewWord	= TSearchSession_pGetCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
		if (wstrNewWord != NULL) {
			LPDSTR		pwRetbuff ;
			int			n, nNewWordLen, nRetbuffSize ;

			pwRetbuff	= ImeDoc_pGetReturnBuffer (pDoc, &nRetbuffSize) ;
			if (pwRetbuff == NULL)
				return	LMR_ERROR ;

			nNewWordLen	= dcslen (wstrNewWord) ;
			n			= MIN (nNewWordLen, nRetbuffSize) ;
			if (n > 0)
				dcsncpy (pwRetbuff, wstrNewWord, n) ;
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_RETVAL, pwRetbuff, n) ;

			/*
			 */
			pBuffer->m_bSkkKakuteiFlag	= TRUE ;
		} else {
			ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
		}
#if !defined (UNITTEST)
		/* _Exit_ �őS�ċz�����ׂ����H */
		ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_CLOSE_CANDIDATELIST) ;

		pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pDoc) ;
		if (pvbufCandInfo != NULL)
			TVarbuffer_Clear (pvbufCandInfo) ;
#endif
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	} else {
		int		iFuncNo ;

		if (! ImeDoc_bLookupKeymap (pDoc, &ev, &iFuncNo)) 
			iFuncNo	= NFUNC_NOFUNCTION ;

		/* ����ȊO�̃L�[�̏ꍇ�B�K�� SPC �͌���B*/
		if (nCH == L' ' || iFuncNo == NFUNC_SKK_START_HENKAN) {
#if !defined (UNITTEST)
			/*	NextCandidate ���̐��������s���̔���� minibuffer-mode �Ɉڍs���ׂ����ǂ�����
			 *	�`�F�b�N�ł��Ȃ��BnMaxShow �����񂵂Ă݂�K�v������B
			 */
			n	= 0 ;
			while (n <= nMaxShow && TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) 
				n	++ ;
			if (n == (nMaxShow + 1)) {
				TVarbuffer*	pvbufCandInfo ;

				nLoop	++ ;
				(void) TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;

				pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pDoc) ;
				if (pvbufCandInfo != NULL) {
					LPMYCAND	pMyCand ;

					pMyCand		= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
					if (pMyCand != NULL) {
						LPCANDIDATELIST	pCandidateList ;

						pCandidateList	= (LPCANDIDATELIST)&(pMyCand->cl) ;
						pCandidateList->dwPageStart	+= nMaxShow ;
						pCandidateList->dwSelection	+= nMaxShow ;
					}
#if !defined (UNITTEST)
					ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_UPDATE_CANDIDATELIST) ;
#endif	
				}
			} else {
#if !defined (UNITTEST)
				TVarbuffer*	pvbufCandInfo ;
#endif
				/*	�ʖځB�ċA�o�^���[�h�Ɉڍs���邱�ƁB
				/*	�ċA���[�h�ł́ACandidate-List �͕���B�������A�߂��ė������̏󋵎���ł�
				 *	�ēx��邱�ƂɂȂ邪�c�B
				 */
				ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_CLOSE_CANDIDATELIST) ;
#if !defined (UNITTEST)
				pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pDoc) ;
				if (pvbufCandInfo != NULL)
					TVarbuffer_Clear (pvbufCandInfo) ;
#endif
				ImeDoc_vSetRegInteger (pDoc, LMREG_3, n) ;
				if (! ImeDoc_bCall (pDoc, LM_bSkkHenkanInMinibuff, LM_bSkkHenkanShowCandidates_5))
					return	LMR_ERROR ;
				return	LMR_CONTINUE ;
			}
#else
			if (! TSearchSession_bNextCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) {
#if 1
				ImeDoc_vSetRegInteger (pDoc, LMREG_3, nShow) ;
				/*	�ċA�o�^���[�h�Ɉړ�����B*/
				/*	�ċA�o�^���[�h����߂��ė������ɂ܂� skk-henkan-show-candidates-mode �ł���
				 *	�ꍇ�ɂ́ACANDIDATELIST ���č\�z���Ȃ��Ƃ����Ȃ� > Windows IME
				 *	���̂܂܏������p�������肵�Ȃ����ƁB
				 */
				if (! ImeDoc_bCall (pDoc, LM_bSkkHenkanInMinibuff, LM_bSkkHenkanShowCandidates_5))
					return	LMR_ERROR ;

				/*	�I���W�i���̓���́A
				 *	1. skk-exit-show-candidates �� skk-henkan-count ��ݒ肵�A
				 *	   skk-henkan1 �֓��͂� nil �ł������Ƃ��Ė߂�B
				 *	2. skk-henkan1 �͕Ԃ�l nil �� skk-henkan �ւƖ߂��Askk-henkan �͕Ԃ�l�� nil ������
				 *	   �ꍇ�ɂ́Askk-henkan-in-minibuff ���Ăяo���B
				 *	3. skk-henkan-in-minibuff �� cancel ������ (keyboard-quit �Ȃ�����return)�A
				 *	   skk-exit-show-candidates ���Q�Ƃ��āA�ݒ肳��Ă���΂��̒l�������l�Ƃ���
				 *	   skk-henkan-show-candidates ���Ăяo���B
				 *
				 *	���� skk-henkan ���o�R���� skk-henkan-in-minibuff ���� skk-henkan-show-candidates ��
				 *	�ēx�Ăяo�����\�����ǂ��Ȃ̂��͕�����Ȃ����Astack ���]�v�ɕK�v�ɂȂ肻����������
				 *	�ŁA�������� skk-henkan-in-minibuff ���Ăяo���Ă���B
				 */
#else
				/*
				       (let ((last-showed-index (+ 4 (* loop max-candidates))))
						 (setq skk-exit-show-candidates
						       ;; cdr ���́A�����o�^�ɓ���O�ɍŌ�ɕ\����
						       ;; �����Q�̒��ōŏ��̌����w���C���f�N�X
						       (cons loop last-showed-index))
						 ;; �����o�^�ɓ���Bskk-henkan-count ��
						 ;; skk-henkan-list �̍Ō�̌��̎� (���݂��Ȃ�
						 ;; --- nil)���w���B
						 (setq skk-henkan-count (+ last-showed-index n)
						       loop nil))))
							   */
				int	nLastShowedIndex ;

				nLastShowedIndex	= 4 + nLoop * nMaxShow ;
				pBuffer->m_iSkkHenkanCount	= nLastShowedIndex + n ;
				ImeDoc_vSetRegInteger (pDoc, LMREGARG_0, 0) ;
				ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
#endif
				return	LMR_CONTINUE ;
			} else {
				nLoop	++ ;
				(void)TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession) ;
				/* ���̌��̕\���ցc�B*/
			}
#endif
			bUpdateShow	= TRUE ;
		} else if (nCH == L'.') {
#if !defined (UNITTEST)
			TVarbuffer*	pvbufCandInfo ;
#endif
			/* �����o�^�Ɉړ�����L�[�̏ꍇ�Bdefault �� '.' */
#if !defined (UNITTEST)
			ImeDoc_vSetRegInteger (pDoc, LMREG_3, 0) ;	/* �ړ������ĂȂ�����A0�ŗǂ����H */
#else
			ImeDoc_vSetRegInteger (pDoc, LMREG_3, nShow) ;
#endif
			/*	�ċA�o�^���[�h�Ɉړ�����B*/
			/*	�ċA�o�^���[�h����߂��ė������ɂ܂� skk-henkan-show-candidates-mode �ł���
			 *	�ꍇ�ɂ́ACANDIDATELIST ���č\�z���Ȃ��Ƃ����Ȃ� > Windows IME
			 *	���̂܂܏������p�������肵�Ȃ����ƁB
			 */
			if (! ImeDoc_bCall (pDoc, LM_bSkkHenkanInMinibuff, LM_bSkkHenkanShowCandidates_5))
				return	LMR_ERROR ;
#if !defined (UNITTEST)
			/*	�ċA���[�h�ł́ACandidate-List �͕���B�������A�߂��ė������̏󋵎���ł�
			 *	�ēx��邱�ƂɂȂ邪�c�B
			 */
			ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_CLOSE_CANDIDATELIST) ;

			pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pDoc) ;
			if (pvbufCandInfo != NULL)
				TVarbuffer_Clear (pvbufCandInfo) ;
#endif
			return	LMR_CONTINUE ;
		} else if (nCH == L'x' || iFuncNo == NFUNC_SKK_PREVIOUS_CANDIDATE) {
#if !defined (UNITTEST)
			TVarbuffer*	pvbufCandInfo ;
#endif
			/* 1�O�ɖ߂�L�[�̏ꍇ�B(skk-previous-candidate-char) default �� 'x' */
			if (nLoop <= 0) {
				struct TMSG	msg ;

				pBuffer->m_iSkkHenkanCount	= ImeConfig_iGetCountHenkanShowChange () + 1 ;

				/* skk-previous-candidate �� bind ���ꂽ������ unread-event �ɐݒ肵�Ă���悤�����c�B*/
#if 1
				msg.m_nMessage	= WM_LM_COMMAND ;
				msg.m_nTime		= GetTickCount () ;
				msg.m_wParam	= NFUNC_SKK_PREVIOUS_CANDIDATE ;
				msg.m_lParam	= 0 ;
				msg.m_rParam	= 0 ;
				msg.m_pt.x		= msg.m_pt.y	= 0 ;
				ImeDoc_bSetUnreadCommandEvent (pBuffer->m_pDoc, &msg) ;
#else
				/*	LookupKeymap �� WM_CHAR �𗝉����Ȃ��B����͂܂����B���A'x' �� previous-candidate
				 *	�� bind ����ĂȂ��\���������B������܂����B
				 */
				ImeDoc_bSetUnreadCommandChar (pBuffer->m_pDoc, L'x') ;
#endif
				ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
				ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0);
#if !defined (UNITTEST)
				ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_CLOSE_CANDIDATELIST) ;

				pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pDoc) ;
				if (pvbufCandInfo != NULL)
					TVarbuffer_Clear (pvbufCandInfo) ;
#endif
				return	LMR_CONTINUE ;
			} else {
				int		nBack ;
#if !defined (UNITTEST)
				TVarbuffer*	pvbufCandInfo ;

				/*	�����\�����鎞�� NextCandidate �𗘗p���� SearchSession ���X�V���Ă��Ȃ��̂ŁA
				 *	�߂�ʂ� nMaxShow �����ł���B
				 *
				 *		-------------------------- �O��
				 *				nMaxShow �̌��
				 *		-------------------------- ����
				 *				nShow ����\��
				 *		-------------------------- ���ݎw���Ă���ʒu�B
				 *
				 *	���ꂪ�A
				 *		-------------------------- �O��
				 *				nMaxShow �̌��
				 *		-------------------------- ���񂩂��ݎw���Ă���ʒu�ɂȂ� (!UNITTEST��)
				 */
				nBack	= nMaxShow ;
				while (nBack > 0 && TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) 
					nBack	-- ;

				/*	�������A���̏����̒��g�ŃG���[������������A�ǂ�����񂾂낤�H 
				 *	Lock ���s�Ƃ��B
				 */
				pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pDoc) ;
				if (pvbufCandInfo != NULL) {
					LPMYCAND	pMyCand ;

					pMyCand		= (LPMYCAND) TVarbuffer_GetBuffer (pvbufCandInfo) ;
					if (pMyCand != NULL) {
						LPCANDIDATELIST	pCandidateList	= (LPCANDIDATELIST)&(pMyCand->cl) ;
						pCandidateList->dwPageStart	-= nMaxShow ;
						pCandidateList->dwSelection	-= nMaxShow ;
					}
				}
				ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_UPDATE_CANDIDATELIST) ;
#else
				nBack	= nMaxShow + nShow ;
				while (nBack > 0 && TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) 
					nBack	-- ;
#endif
				nLoop	-- ;
				bUpdateShow	= TRUE ;
			}
		} else if (nCH == 0x07 || (iFuncNo == NFUNC_KEYBOARD_QUIT || iFuncNo == NFUNC_ABORT_RECURSIVE_EDIT)) {
#if !defined (UNITTEST)
			TVarbuffer*	pvbufCandInfo ;
#endif
			struct TMSG	msg ;

			/* quit �� bind ����Ă���ꍇ�B*/
			/* signal ���g���� keyboard-quit ���Ăяo���Ă���悤�����c�B*/
#if 1
			msg.m_nMessage	= WM_LM_COMMAND ;
			msg.m_wParam	= NFUNC_KEYBOARD_QUIT ;
			msg.m_lParam	= 0 ;
			msg.m_pt.x		= msg.m_pt.y	= 0 ;
			msg.m_nTime		= GetTickCount () ;
			ImeDoc_bSetUnreadCommandEvent (pDoc, &msg) ;
#else
			ImeDoc_bSetUnreadCommandChar (pDoc, 0x07) ;
#endif
			ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
			ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0);
#if !defined (UNITTEST)
			ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_CLOSE_CANDIDATELIST) ;

			pvbufCandInfo	= ImeDoc_pGetCandidateInfoBuffer (pDoc) ;
			if (pvbufCandInfo != NULL)
				TVarbuffer_Clear (pvbufCandInfo) ;
#endif
			pBuffer->m_bSkkKakuteiFlag	= FALSE ;
			return	LMR_CONTINUE ;
		} else {
			/*	����ȊO�͖����ȃL�[�ł��ƕ\������̂����Asit-for �����݂ł��Ȃ�(application�ɐ��䂪�߂�)�̂�
			 *	�\�����邱�Ƃ̓��[�U�[�ɂƂ��Ďז��ł����Ȃ����B
			 */
			WCHAR	bufText [256] ;
			int		nText ;
			if (0x21 <= nCH && nCH < 0x7E) {
				nText	= wnsprintfW (bufText, ARRAYSIZE (bufText), L"`%c' is not valid here!", (WCHAR)nCH) ;
			} else {
				nText	= wnsprintfW (bufText, ARRAYSIZE (bufText), L"0x%0x is not valid here!", nCH) ;
			}
			ImeDoc_bSetMessageNW (pDoc, bufText, nText) ;
		}
	}
exit_func:
	ImeDoc_vSetRegInteger (pDoc, LMREG_1, nLoop) ;
	ImeDoc_vSetRegBool    (pDoc, LMREG_2, bUpdateShow) ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_3) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanShowCandidates_5 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	LPCDSTR		pwResult ;
	int			nShow, nResultLen ;

	if (ImeDoc_bSignalp (pDoc)) {
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	if (ImeDoc_bGetRegConstString (pDoc, LMREGARG_RETVAL, &pwResult, &nResultLen) && nResultLen > 0) {
		/* return n */
		/* ImeDoc_vSetRegInteger (pDoc, LMREGARG_RETVAL, n) ; */
		ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit_0) ;
		return	LMR_CONTINUE ;
	}
	if (ImeDoc_bGetRegInteger (pDoc, LMREG_4, &nShow)) {
		while (nShow > 1 && TSearchSession_bPreviousCandidate (pBuffer->m_pSkkCurrentSearchProgSession)) 
			nShow	-- ;
	}
	ImeDoc_vSetRegBool (pDoc, LMREG_2, TRUE) ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkHenkanShowCandidates_Exit_0 (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		pBuffer->m_bSkkHenkanShowCandidatesMode	= FALSE ;
		/* skk-point-move �̌��ʁB*/
		imeBuffer_bSkkSetMarker (pBuffer, &pBuffer->m_pmkSkkPreviousPoint, MARKER_SKK_PREVIOUS_POINT, pBuffer->m_pmkPoint) ;
	}
	ImeDoc_vClearMessage (pDoc) ;
	ImeDoc_vJump (pDoc, LM_bSkkHenkanShowCandidates_Exit) ;
	return	LMR_CONTINUE ;
}

/*================================================================ ad-keyboard-quit (around)
 */
static	int		LM_bSkkKeyboardQuit_PostprocessPreviousCandidateCharForDeleteOkuriHenkanQuit (struct CImeDoc*) ;
static	int		LM_bSkkKeyboardQuit_1 (struct CImeDoc*) ;

/*	around (���Ƃ̊֐��̎��s���܂�)�� emulation�Bad-do-it �͂��Ƃ̊֐��̎��s�������ɓ��邱�Ƃ�
 *	�����B
 *	�Ԃ�l: LMREGARG_RETVAL: ad-do-it ���ǂ����B�{���� ad-do-it ���ĂԈʒu�͔C�ӂȂ̂ŕԂ�l��
 *			�����͓̂K�؂ł͂Ȃ��c�B
 */
int
LM_bSkkAdKeyboardQuit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->m_bSkkMode) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->m_bSkkHenkanMode) {
		int		nPrefix ;

		piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
		if (SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) && SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) != NULL) {
//		if (pBuffer->m_pSkkCurrentRuleTree != NULL && TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) != NULL) {
			imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;
		} else {
			ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
			return	LMR_RETURN ;
		}
	} else if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
		pBuffer->m_iSkkHenkanCount	= 0 ;
		if (ImeConfig_bSkkDeleteOkuriWhenQuit () && pBuffer->m_nSkkHenkanOkuriganaLen > 0) {
			/*	���艼���̒������L�����Ă����B
			 */
			if (! ImeDoc_bPushReg (pDoc, LMREG_0))
				return	LMR_ERROR ;
			ImeDoc_vSetRegInteger (pDoc, LMREG_0, pBuffer->m_nSkkHenkanOkuriganaLen) ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkPreviousCandidate, LM_bSkkKeyboardQuit_PostprocessPreviousCandidateCharForDeleteOkuriHenkanQuit))
				return	LMR_ERROR ;
		} else {
			if (! ImeDoc_bCall (pDoc, LM_bSkkPreviousCandidate, LM_bSkkKeyboardQuit_1))
				return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (ImeDoc_iGetLastCommand (pDoc) == NFUNC_SKK_COMP_DO) {
			if (pBuffer->m_pmkSkkHenkanStartPoint != NULL)
				ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;
			/* skk-comp-key */
			if (pBuffer->m_pSkkCompSession != NULL) {
				LPCDSTR	pSkkCompKey ;
				int		nSkkCompKey ;

				pSkkCompKey	= TSearchSession_pGetKeyword (pBuffer->m_pSkkCompSession, &nSkkCompKey) ;
				ImeBuffer_iInsert (pBuffer, pBuffer->m_pmkPoint, pSkkCompKey, nSkkCompKey) ;

				TSearchSession_vDestroy (pBuffer->m_pSkkCompSession) ;
				pBuffer->m_pSkkCompSession	= NULL ;
			}
		} else {
			imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;
			if (pBuffer->m_pmkSkkHenkanStartPoint != NULL && TMarker_iGetPosition (pBuffer->m_pmkPoint) > TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) {
				ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) ;
			}
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkKeyboardQuit_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, TRUE) ;
	return	LMR_RETURN ;
}

int
LM_bSkkKeyboardQuit_PostprocessPreviousCandidateCharForDeleteOkuriHenkanQuit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*	pBuffer ;
	int					nCount ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetSignalError (pDoc) ;
	} else {
		if (! ImeDoc_bGetRegInteger (pDoc, LMREG_0, &nCount))
			nCount	= 0 ;
		if (! ImeBuffer_bDeleteBackwardChar (pBuffer, nCount)) {
			ImeDoc_vSetSignalError (pDoc) ;
		}
	}
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	ImeDoc_vJump (pDoc, LM_bSkkKeyboardQuit_1) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkKeyboardQuit_1 (
	struct CImeDoc*			pDoc)
{
	/* ... */
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, TRUE) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-abort-recursive-edit (around)
 */
#define	LM_bSkkAbortRecursiveEdit_PostprocessPreviousCandidateCharForDeleteOkuriHenkanQuit	LM_bSkkKeyboardQuit_PostprocessPreviousCandidateCharForDeleteOkuriHenkanQuit
#define	LM_bSkkAbortRecursiveEdit_1	LM_bSkkKeyboardQuit_1

/*	around (���Ƃ̊֐��̎��s���܂�)�� emulation
 */
int
LM_bSkkAdAbortRecursiveEdit (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	struct CSkkRuleTreeIterator*	piteSkkRuleTree	= NULL ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	/*	�ȉ��� hook ����菜�����삪�K�v���H�F
	 *  (skk-remove-minibuffer-setup-hook
	 *   'skk-j-mode-on 'skk-setup-minibuffer
	 *   #'(lambda () (add-hook 'pre-command-hook 'skk-pre-command nil 'local)))
	 */
	if (! pBuffer->m_bSkkMode) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	if (! pBuffer->m_bSkkHenkanMode) {
		int		nPrefix ;

		piteSkkRuleTree	= ImeBuffer_pSkkGetSkkRuleTreeIterator (pBuffer) ;
		if (SkkRuleTreeIterator_bHavePrefixp (piteSkkRuleTree) && SkkRuleTreeIterator_pGetPrefix (piteSkkRuleTree, &nPrefix) != NULL) {
//		if (pBuffer->m_pSkkCurrentRuleTree != NULL && TSkkRuleTreeNode_pGetPrefix (pBuffer->m_pSkkCurrentRuleTree, &nPrefix) != NULL) {
			imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;
		} else {
			ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
			return	LMR_RETURN ;
		}
	} else if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
		pBuffer->m_iSkkHenkanCount	= 0 ;
		if (ImeConfig_bSkkDeleteOkuriWhenQuit () && pBuffer->m_nSkkHenkanOkuriganaLen > 0) {
			/*	���艼���̒������L�����Ă����B
			 */
			if (! ImeDoc_bPushReg (pDoc, LMREG_0))
				return	LMR_ERROR ;
			ImeDoc_vSetRegInteger (pDoc, LMREG_0, pBuffer->m_nSkkHenkanOkuriganaLen) ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkPreviousCandidate, LM_bSkkAbortRecursiveEdit_PostprocessPreviousCandidateCharForDeleteOkuriHenkanQuit))
				return	LMR_ERROR ;
		} else {
			if (! ImeDoc_bCall (pDoc, LM_bSkkPreviousCandidate, LM_bSkkAbortRecursiveEdit_1))
				return	LMR_ERROR ;
		}
		return	LMR_CONTINUE ;
	} else {
		if (ImeDoc_iGetLastCommand (pDoc) == NFUNC_SKK_COMP_DO) {
			if (pBuffer->m_pmkSkkHenkanStartPoint != NULL)
				ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint), TMarker_iGetPosition (pBuffer->m_pmkPoint)) ;
			/* skk-comp-key */
			if (pBuffer->m_pSkkCompSession != NULL) {
				LPCDSTR	pSkkCompKey ;
				int		nSkkCompKey ;

				pSkkCompKey	= TSearchSession_pGetKeyword (pBuffer->m_pSkkCompSession, &nSkkCompKey) ;
				ImeBuffer_iInsert (pBuffer, pBuffer->m_pmkPoint, pSkkCompKey, nSkkCompKey) ;

				TSearchSession_vDestroy (pBuffer->m_pSkkCompSession) ;
				pBuffer->m_pSkkCompSession	= NULL ;
			}
		} else {
			imeBuffer_bSkkErasePrefix (pBuffer, TRUE) ;
			if (pBuffer->m_pmkSkkHenkanStartPoint != NULL && TMarker_iGetPosition (pBuffer->m_pmkPoint) > TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) {
				ImeBuffer_bDeleteRegion (pBuffer, TMarker_iGetPosition (pBuffer->m_pmkPoint), TMarker_iGetPosition (pBuffer->m_pmkSkkHenkanStartPoint)) ;
			}
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkAbortRecursiveEdit_1))
				return	LMR_ERROR ;
			return	LMR_CONTINUE ;
		}
	}
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, TRUE) ;
	return	LMR_RETURN ;
}

#undef	LM_bSkkAbortRecursiveEdit_PostprocessPreviousCandidateCharForDeleteOkuriHenkanQuit
#undef	LM_bSkkAbortRecursiveEdit_1

/*================================================================ ad-exit-minibuffer (around)
 */
static	int		LM_bSkkExitMinibuffer_1		(struct CImeDoc*) ;

/*	around (���Ƃ̊֐��̎��s���܂�)�� emulation
 */
int
LM_bSkkAdExitMinibuffer (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		return	LMR_RETURN ;
	}
	/*  (skk-remove-minibuffer-setup-hook
	 *   'skk-j-mode-on 'skk-setup-minibuffer
	 *   #'(lambda ()
	 *       (add-hook 'pre-command-hook 'skk-pre-command nil 'local)))
	 *
	 *	���̈������ǂ�����ׂ����c�B
	 */
	if (! (pBuffer->m_bSkkJMode || pBuffer->m_bSkkJisx0201Mode || pBuffer->m_bSkkAbbrevMode)) {
		/* through */
	} else {
		BOOL	bNoNewline ;

		bNoNewline	= (ImeConfig_bSkkEggLikeNewline () && pBuffer->m_bSkkHenkanMode) ;
		if (! ImeDoc_bPushReg (pDoc, LMREG_0))
			return	LMR_ERROR ;

		ImeDoc_vSetRegBool (pDoc, LMREG_0, bNoNewline) ;
		if (pBuffer->m_bSkkMode) {
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
			if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkExitMinibuffer_1))
				return	LMR_ERROR ;
		} else {
			ImeDoc_vJump (pDoc, LM_bSkkExitMinibuffer_1) ;
		}
		return	LMR_CONTINUE ;
	}
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;	/* ad-do-it */
	return	LMR_RETURN ;
}

int
LM_bSkkExitMinibuffer_1 (
	struct CImeDoc*			pDoc)
{
	BOOL					bNoNewline ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREG_0, &bNoNewline))
		bNoNewline	= TRUE ;
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, bNoNewline) ;
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-next-line (before)
 */
/*
 *	(defadvice next-line (before skk-ad activate)
 *	  (when (eq skk-henkan-mode 'active)
 *	    (skk-kakutei)))
 */
int
LM_bSkkAdNextLine (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	/*	before advice �Ȃ̂� ad-do-it �̎w��͂Ȃ��B�Ƃ������A�K���{�͎̂��s�����B
	 */
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
			ImeDoc_vJump (pDoc, LM_bSkkKakuteiAdJisx0201) ;
			return	LMR_CONTINUE ;
		}
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-previous-line (before)
 */
/*
 *	(defadvice previous-line (before skk-ad activate)
 *	  (when (eq skk-henkan-mode 'active)
 *	    (skk-kakutei)))
 */
int
LM_bSkkAdPreviousLine (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;

	/*	before advice �Ȃ̂� ad-do-it �̎w��͂Ȃ��B�Ƃ������A�K���{�͎̂��s�����B
	 */
	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer != NULL) {
		if (pBuffer->m_bSkkHenkanMode == LACTIVE) {
			ImeDoc_vSetRegConstString (pDoc, LMREGARG_0, NULL, 0) ;
			ImeDoc_vJump (pDoc, LM_bSkkKakuteiAdJisx0201) ;
			return	LMR_CONTINUE ;
		}
	}
	ImeDoc_vSetRegNil (pDoc, LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*================================================================ ad-newline (around)
 */
static	int		LM_bSkkAdNewline_1		(struct CImeDoc*) ;
static	int		LM_bSkkAdNewline_Exit	(struct CImeDoc*) ;
	
	/*
(skk-defadvice newline (around skk-ad activate)
  "`skk-egg-like-newline' ��������A�ϊ����͊m��̂ݍs���A���s���Ȃ��B"
  (interactive "*P")
  (if (not (or skk-j-mode
	       skk-jisx0201-mode
	       skk-abbrev-mode))
      ad-do-it
    (let (;;(arg (ad-get-arg 0))
	  ;; `skk-kakutei' �����s����� `skk-henkan-mode' �̒l��
	  ;; �������� nil �ɂȂ�̂ŁA�ۑ����Ă����K�v������B
	  (no-newline (and skk-egg-like-newline
			   skk-henkan-mode))
	  (auto-fill-function (if (interactive-p)
				  auto-fill-function
				nil)))
      ;; fill ����Ă� nil ���A���Ă��� :-<
      ;;(if (skk-kakutei)
      ;;    (setq arg (1- arg)))
      ;;(if skk-mode
      ;;    (let ((opos (point)))
      ;;      ;; skk-kakutei (skk-do-auto-fill) �ɂ���čs���܂�Ԃ��ꂽ��
      ;;      ;; arg �� 1 ���炷�B
      ;;      (skk-kakutei)
      ;;      (if (and (not (= opos (point))) (integerp arg))
      ;;          (ad-set-arg 0 (1- arg)))))
      (when skk-mode
	(skk-kakutei))
      (undo-boundary)
      (unless no-newline
	ad-do-it))))*/
int
LM_bSkkAdNewline (
	struct CImeDoc*			pDoc)
{
	struct CImeBuffer*		pBuffer ;
	BOOL		bNoNewline ;

	pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
	if (pBuffer == NULL) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_NEWLINE) ;
		return	LMR_RETURN ;
	}
	if (! (pBuffer->m_bSkkJMode || pBuffer->m_bSkkJisx0201Mode || pBuffer->m_bSkkAbbrevMode)) {
		ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
		ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_NEWLINE) ;
		return	LMR_RETURN ;
	}
	if (! ImeDoc_bPushReg (pDoc, LMREG_0))
		return	LMR_ERROR ;

	/*	newline �őS�m��@�\������̂Ȃ���l���Ȃ���΁B
	 */
	bNoNewline	= (ImeConfig_bSkkEggLikeNewline () && pBuffer->m_bSkkHenkanMode)? TRUE : FALSE ;
	ImeDoc_vSetRegBool (pDoc, LMREG_0, bNoNewline) ;

	if (pBuffer->m_bSkkMode) {
		ImeDoc_vSetRegNil (pDoc, LMREGARG_0) ;
		if (! ImeDoc_bCall (pDoc, LM_bSkkKakuteiAdJisx0201, LM_bSkkAdNewline_1))
			return	LMR_ERROR ;
		return	LMR_CONTINUE ;
	}
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, FALSE) ;
	ImeDoc_vJump (pDoc, LM_bSkkAdNewline_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkAdNewline_1 (
	struct CImeDoc*			pDoc)
{
	BOOL	bNoNewline ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREG_0, &bNoNewline))
		bNoNewline	= TRUE ;

	/*	newline �őS�m��ɂ���ꍇ�ɂ� QueryShiftCount �̐����� skk-kakutei �̒���ł���
	 *	���Ƃ���ӂ݂āApoint-marker ���ŏI�ʒu�ֈړ�������Ηǂ��B
	 */
	if (ImeConfig_bSkkIsNewlineKakuteiAllp () && ! ImeDoc_bIsStatusActivep (pDoc)) {
		struct CImeBuffer*	pBuffer ;

		pBuffer	= ImeDoc_pGetCurrentBuffer (pDoc) ;
		if (pBuffer != NULL && TMarker_bIsValidp (pBuffer->m_pmkPoint)) {
			struct TMarker*	pmkBufferEnd	= NULL ;

			/*	point marker ���s���ւƈړ�������B*/
			if (ImeBuffer_bGetMarker (pBuffer, MARKER_BUFFEREND, &pmkBufferEnd) && pmkBufferEnd != NULL) {
				TMarker_bSetPosition (pBuffer->m_pmkPoint, pmkBufferEnd) ;
			} else {
				int		nPoint	= TMarker_iGetPosition (pBuffer->m_pmkPoint) ;
				if (0 <= nPoint && nPoint < pBuffer->m_nbufComp) {
					TMarker_bForward (pBuffer->m_pmkPoint, pBuffer->m_nbufComp - nPoint) ;
				}
			}
		}
	}
	ImeDoc_vSetRegBool (pDoc, LMREGARG_RETVAL, bNoNewline) ;
	ImeDoc_vJump (pDoc, LM_bSkkAdNewline_Exit) ;
	return	LMR_CONTINUE ;
}

int
LM_bSkkAdNewline_Exit (
	struct CImeDoc*			pDoc)
{
	BOOL	bNoNewline ;

	if (! ImeDoc_bGetRegBool (pDoc, LMREG_0, &bNoNewline))
		bNoNewline	= TRUE ;
	if (! bNoNewline) {
		/*	newline �� unprocess event �ɕϊ�����B*/
		ImeDoc_bUnprocessEvent (pDoc, ImeDoc_pGetLastCommandEvent (pDoc)) ;
	}
	ImeDoc_vPopReg (pDoc, LMREG_0) ;
	ImeDoc_vSetUpdateFlag (pDoc, IMEDOC_NEWLINE) ;
	return	LMR_RETURN ;
}




