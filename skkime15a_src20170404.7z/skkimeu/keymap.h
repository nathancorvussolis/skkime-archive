#pragma once

/*	special-keys [] = {
 *		VK_LEFT, VK_UP, VK_DOWN, VK_RIGHT, VK_INSERT, VK_DELETE, VK_BACK, VK_TAB, VK_HOME,
 *		VK_SPACE, VK_ESCAPE, VK_KANJI, VK_HELP, VK_F1, VK_F2, VK_F3, VK_F4, VK_F5, VK_F6,
 *		VK_F7, VK_F8, VK_F9, VK_F10, VK_F11, VK_F12, VK_CLEAR, VK_RETURN,
 *
 *		VK_LBUTTON, VK_RBUTTON, VK_MENU1, VK_MENU2, VK_MENU3, VK_MENU4,
 *	}
 *
 *	�����̏����� list �ɓ���邩�H
 */

#include "../common/nfunc.h"
