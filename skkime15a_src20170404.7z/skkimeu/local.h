#pragma once

#if defined (UNITTEST)

#include <windows.h>
#include <wchar.h>
#include <tchar.h>
#include <assert.h>
#include <shlwapi.h>

#define	ASSERT(x)			assert((x))
#if !defined (ARRAYSIZE)
#define	ARRAYSIZE(array)	(sizeof (array) / sizeof (array[0]))
#endif
#if !defined(MIN)
#define	MIN(lvalue,rvalue)	(((lvalue) < (rvalue))? (lvalue) : (rvalue))
#endif
#if !defined(MAX)
#define	MAX(lvalue,rvalue)	(((lvalue) < (rvalue))? (rvalue) : (lvalue))
#endif

#if defined (DEBUG)
#include "debug.h"
#define	DEBUGPRINTF(arg)	DebugPrintf##arg
#define	DEBUGPRINTFW(arg)	DebugPrintfW##arg
#else
#define	DEBUGPRINTF(arg)	/*arg*/
#define	DEBUGPRINTFW(arg)	/*arg*/
#endif
#define	MALLOC(size)		malloc((size))
#define	FREE(ptr)			free((ptr))

#else

#include "windows.h"
#include "tchar.h"
#include "immdev.h"
#include "skki1_5.h"
#include <shlwapi.h>

#define	MALLOC(size)		HeapAlloc(GetProcessHeap(), 0, (size))
#define	FREE(ptr)			HeapFree(GetProcessHeap(), 0, (ptr))

#if !defined (ARRAYSIZE)
#define	ARRAYSIZE(array)	(sizeof (array) / sizeof (array[0]))
#endif
#if !defined(MIN)
#define	MIN(lvalue,rvalue)	(((lvalue) < (rvalue))? (lvalue) : (rvalue))
#endif
#if !defined(MAX)
#define	MAX(lvalue,rvalue)	(((lvalue) < (rvalue))? (rvalue) : (lvalue))
#endif

#if !defined (SAFE_FREE)
#define	SAFE_FREE(ptr)		{ if ((ptr) != NULL) { FREE((ptr)) ; (ptr) = NULL ; } }
#endif

#endif



