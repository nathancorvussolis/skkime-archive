#if defined (UNITTEST)
#include "StdAfx.h"
#else
#include "local.h"
#endif
#include "RuleTreeNodeP.h"
#include "keymap.h"
#include "ImeConfig.h"
#include "jstring.h"

enum {
	SYSCHAR_INVALID		= -1,
	SYSCHAR_DEFAULT		= 65536,
	SYSCHAR_VOWEL,
	SYSCHAR_CONSONANT,
} ;

static	int	TSkkRuleTreeNode_iGetRuleCharacter (LPCDSTR*, LPCDSTR) ;
static	int	TSkkRuleTreeNode_iGetRule			(const struct CSkkRuleTreeNode*) ;

struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNodeOutput_pCreateStringPairInstance (
	LPCDSTR							dstrLeft,
	int								nLeftLen,
	LPCDSTR							dstrRight,
	int								nRightLen)
{
	struct CSkkRuleTreeNodeOutput*	pNode ;
	DCHAR*	pwDest ;
	int		nSize ;

	nSize	= sizeof (struct CSkkRuleTreeNodeOutput) + nLeftLen * sizeof (DCHAR) + nRightLen * sizeof (DCHAR) ;
	if (nSize < sizeof (struct CSkkRuleTreeNodeOutput))
		return	NULL ;
	pNode	= (struct CSkkRuleTreeNodeOutput*) MALLOC (nSize) ;
	if (pNode == NULL)
		return	NULL ;
	pwDest			= (DCHAR*) (pNode + 1) ;
	pNode->m_nType	= NTYPE_STRINGPAIR ;
	if (dstrLeft != NULL) {
		pNode->m_uValue.m_stringpair.m_strHira	= pwDest ;
		dcsncpy (pwDest, dstrLeft, nLeftLen) ;
		pNode->m_uValue.m_stringpair.m_nHira	= nLeftLen ;
		pwDest	+= nLeftLen ;
	} else {
		pNode->m_uValue.m_stringpair.m_strHira	= NULL ;
		pNode->m_uValue.m_stringpair.m_nHira	= 0 ;
	}
	if (dstrRight != NULL) {
		pNode->m_uValue.m_stringpair.m_strKata	= pwDest ;
		dcsncpy (pwDest, dstrRight, nRightLen) ;
		pNode->m_uValue.m_stringpair.m_nKata	= nRightLen ;
		pwDest	+= nRightLen ;
	} else {
		pNode->m_uValue.m_stringpair.m_strKata	= NULL ;
		pNode->m_uValue.m_stringpair.m_nKata	= 0 ;
	}
	return	pNode ;
}

struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNodeOutput_pCreateStringInstance (
	LPCDSTR							wstrString,
	int								nStringLen)
{
	struct CSkkRuleTreeNodeOutput*	pNode ;
	DCHAR*	pwDest ;
	int		nSize ;

	nSize	= sizeof (struct CSkkRuleTreeNodeOutput) + nStringLen * sizeof (DCHAR) ;
	if (nSize < sizeof (struct CSkkRuleTreeNodeOutput))
		return	NULL ;
	pNode	= (struct CSkkRuleTreeNodeOutput*) MALLOC (nSize) ;
	if (pNode == NULL)
		return	NULL ;
	pwDest			= (DCHAR*) (pNode + 1) ;
	pNode->m_nType	= NTYPE_STRING ;
	if (wstrString != NULL) {
		pNode->m_uValue.m_string.m_strValue	= pwDest ;
		memcpy (pwDest, wstrString, nStringLen * sizeof (DCHAR)) ;
		pNode->m_uValue.m_string.m_nValue	= nStringLen ;
	} else {
		pNode->m_uValue.m_string.m_strValue	= NULL ;
		pNode->m_uValue.m_string.m_nValue	= 0 ;
	}
	return	pNode ;
}

struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNodeOutput_pCreateMacroInstance (
	int								nMacro)
{
	struct CSkkRuleTreeNodeOutput*	pNode ;

	pNode	= (struct CSkkRuleTreeNodeOutput*) MALLOC (sizeof (struct CSkkRuleTreeNodeOutput)) ;
	if (pNode == NULL)
		return	NULL ;
	pNode->m_nType				= NTYPE_MACRO ;
	pNode->m_uValue.m_nMacro	= nMacro ;
	return	pNode ;
}

void
TSkkRuleTreeNodeOutput_vDestroy (
	struct CSkkRuleTreeNodeOutput*	pNode)
{
	if (pNode == NULL)
		return ;
	FREE (pNode) ;
	return ;
}

int
TSkkRuleTreeNodeOutput_iGetType		(
	const struct CSkkRuleTreeNodeOutput*	pNode)
{
	return	(pNode != NULL)? pNode->m_nType : -1 ;
}

BOOL
TSkkRuleTreeNodeOutput_bGetMacro	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	int*									pnFuncNo)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_MACRO)
		return	FALSE ;
	if (pnFuncNo != NULL)
		*pnFuncNo	= pNode->m_uValue.m_nMacro ;
	return	TRUE ;
}

BOOL
TSkkRuleTreeNodeOutput_bGetString	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	LPCDSTR*								ppwString,
	int*									pnStringLen)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_STRING)
		return	FALSE ;
	if (ppwString != NULL)
		*ppwString	= pNode->m_uValue.m_string.m_strValue ;
	if (pnStringLen != NULL)
		*pnStringLen	= pNode->m_uValue.m_string.m_nValue ;
	return	TRUE ;
}


BOOL
TSkkRuleTreeNodeOutput_bGetLString	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	LPCDSTR*								ppwString,
	int*									pnStringLen)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_STRINGPAIR)
		return	FALSE ;
	if (ppwString != NULL)
		*ppwString	= pNode->m_uValue.m_stringpair.m_strHira ;
	if (pnStringLen != NULL)
		*pnStringLen	= pNode->m_uValue.m_stringpair.m_nHira ;
	return	TRUE ;
}


BOOL
TSkkRuleTreeNodeOutput_bGetRString	(
	const struct CSkkRuleTreeNodeOutput*	pNode,
	LPCDSTR*								ppwString,
	int*									pnStringLen)
{
	if (pNode == NULL || pNode->m_nType != NTYPE_STRINGPAIR)
		return	FALSE ;
	if (ppwString != NULL)
		*ppwString	= pNode->m_uValue.m_stringpair.m_strKata ;
	if (pnStringLen != NULL)
		*pnStringLen	= pNode->m_uValue.m_stringpair.m_nKata ;
	return	TRUE ;
}

/*===============================================================
 *	struct CSkkRuleTreeNode public functions
 */
LPCDSTR
TSkkRuleTreeNode_pGetPrefix (
	const struct CSkkRuleTreeNode*			pNode,
	int*									pnLength)
{
	if (pNode == NULL)
		return	NULL ;
	if (pnLength != NULL)
		*pnLength	= pNode->_nPrefix ;
	return	pNode->_pPrefix ;
}

LPCDSTR
TSkkRuleTreeNode_pGetNextState	(
	const struct CSkkRuleTreeNode*			pNode,
	int*									pnLength,
	int*									pnNextRule)
{
	if (pNode == NULL) {
		if (pnNextRule != NULL)
			*pnNextRule	= 0 ;
		return	NULL ;
	}
	if (pnLength != NULL)
		*pnLength	= pNode->_nNextState ;
	if (pnNextRule != NULL)
		*pnNextRule	= pNode->_nNextRule ;
	return	pNode->_pNextState ;
}

const struct CSkkRuleTreeNodeOutput*
TSkkRuleTreeNode_pGetOutput		(
	const struct CSkkRuleTreeNode*			pNode)
{
	return	(pNode != NULL)? pNode->_pOutput : NULL ;
}

/*===============================================================
 *	static public methods
 */
struct CSkkRuleTreeNode*
TSkkRuleTreeNode_pCreateInstance (
	int								nChar, 
	LPCDSTR							wstrPrefix,
	int								nPrefixLen,
	LPCDSTR							wstrNext,
	int								nNextLen,
	int								iNextRule,
	struct CSkkRuleTreeNodeOutput*	pOutput)
{
	struct CSkkRuleTreeNode*	pNode ;
	int					nSize ;
	DCHAR*				pwDest ;

	nSize	= sizeof (struct CSkkRuleTreeNode) + sizeof (DCHAR) * nPrefixLen + sizeof (DCHAR) * nNextLen ;
	pNode	= (struct CSkkRuleTreeNode*) MALLOC (nSize) ;
	if (pNode == NULL)
		return	NULL ;

	pNode->_nCH	= nChar ;
	pwDest		= (DCHAR*) (pNode + 1) ;
	if (nPrefixLen > 0) {
		pNode->_pPrefix	= pwDest ;
		memcpy (pNode->_pPrefix, wstrPrefix, sizeof (DCHAR) * nPrefixLen) ;
		pwDest			+= nPrefixLen ;
	} else {
		pNode->_pPrefix	= NULL ;
		nPrefixLen		= 0 ;
	}
	pNode->_nPrefix	= nPrefixLen ;

	if (nNextLen > 0) {
		pNode->_pNextState	= pwDest ;
		memcpy (pNode->_pNextState, wstrNext, sizeof (DCHAR) * nNextLen) ;
		pwDest		+= nNextLen ;
	} else {
		pNode->_pNextState	= NULL ;
		nNextLen	= 0 ;
	}
	pNode->_nNextState	= nNextLen ;
	pNode->_nNextRule	= iNextRule ;
	pNode->_pOutput		= pOutput ;
	pNode->_pChild		= NULL ;
	pNode->_pBrother	= NULL ;
	return	pNode ;
}

void
TSkkRuleTreeNode_vDestroy (
	struct CSkkRuleTreeNode*	pNode)
{
	if (pNode == NULL)
		return ;

	TSkkRuleTreeNodeOutput_vDestroy (pNode->_pOutput) ;
	pNode->_pOutput	= NULL ;
	FREE (pNode) ;
	return ;
}

void
TSkkRuleTreeNode_vSetBrother (
	struct CSkkRuleTreeNode*		pRoot,
	struct CSkkRuleTreeNode*		pBrother)
{
	pRoot->_pBrother	= pBrother ;
	return ;
}

void
TSkkRuleTreeNode_vSetChild (
	struct CSkkRuleTreeNode*		pRoot,
	struct CSkkRuleTreeNode*		pChild)
{
	pRoot->_pChild	= pChild ;
	return ;
}

void
TSkkRuleTreeNode_vSetOutput (
	struct CSkkRuleTreeNode*		pNode,
	struct CSkkRuleTreeNodeOutput*	pOutput)
{
	if (pNode == NULL)
		return ;
	if (pNode->_pOutput != NULL) {
		TSkkRuleTreeNodeOutput_vDestroy (pNode->_pOutput) ;
	}
	pNode->_pOutput	= pOutput ;
	return ;
}

struct CSkkRuleTreeNode*
TSkkRuleTreeNode_pGetBranchList (
	struct CSkkRuleTreeNode*		pRoot)
{
	return	pRoot != NULL? TSkkRuleTreeNode_pGetChild (pRoot) : NULL ;
}

BOOL
TSkkRuleTreeNode_bMatchChar (int nSystemChar, int nInputChar, int* pnScore)
{
	switch (nSystemChar) {
	case	SYSCHAR_DEFAULT:
		if (pnScore != NULL)
			*pnScore	= 0 ;	/* �Œ�_���B*/
		return	TRUE ;
	case	SYSCHAR_VOWEL:
		if	(nInputChar == 'a' || nInputChar == 'i' || nInputChar == 'u' || nInputChar == 'e' || nInputChar == 'o') {
			if (pnScore != NULL)
				*pnScore	= 50 ;
			return	TRUE ;
		}
		break ;
	case	SYSCHAR_CONSONANT:
		if	(('a' <= nInputChar && nInputChar <= 'z') && ! (nInputChar == 'a' || nInputChar == 'i' || nInputChar == 'u' || nInputChar == 'e' || nInputChar == 'o')) {
			if (pnScore != NULL)
				*pnScore	= 50 ;
			return	TRUE ;
		}
		break ;
	default:
		if (nSystemChar == nInputChar) {
			if (pnScore != NULL)
				*pnScore	= 100 ;
			return	TRUE ;
		}
		break ;
	}
	return	FALSE ;
}

struct CSkkRuleTreeNode*
TSkkRuleTreeNode_pSelectBranch (
	struct CSkkRuleTreeNode*	pRoot,
	int							nChar)
{
	struct CSkkRuleTreeNode*	pNode ;
	struct CSkkRuleTreeNode*	pHitNode ;
	int	nCurScore ;

	if (pRoot == NULL)
		return	NULL ;

	pNode		= TSkkRuleTreeNode_pGetChild (pRoot) ;
	pHitNode	= NULL ;
	nCurScore	= -1 ;
	while (pNode != NULL) {
		int	nScore ;
		if (TSkkRuleTreeNode_bMatchChar (TSkkRuleTreeNode_iGetChar (pNode), nChar, &nScore)) {
			if (nCurScore < nScore) {
				pHitNode	= pNode ;
				nCurScore	= nScore ;
			}
			if (nScore == 100)
				break ;
		}
		pNode	= TSkkRuleTreeNode_pGetBrother (pNode) ;
	}
	return	pHitNode ;
}

/*	�Ԃ�l�́A�T���ɐ�������������(���ǂ�Ȃ��Ȃ����炻���܂�)
 *	���̎��_�ł̃m�[�h�� ppResult �ɓ������B
 */
int
TSkkRuleTreeNode_iSearchTree (
	struct CSkkRuleTreeNode*	pTree,
	LPCDSTR						pString,
	int							nString,
	struct CSkkRuleTreeNode**	ppResult)
{
	struct CSkkRuleTreeNode*	pParent ;
	struct CSkkRuleTreeNode*	pNode ;
	LPCDSTR		wptr, wptrEnd ;
	int			nCH ;

	pNode		= pTree != NULL? TSkkRuleTreeNode_pGetChild (pTree) : NULL ;
	pParent		= pTree ;
	wptr		= pString ;
	wptrEnd		= pString + nString ;
	while (wptr < wptrEnd) {
		LPCDSTR	wptrBack	= wptr ;
		nCH		= TSkkRuleTreeNode_iGetRuleCharacter (&wptr, wptrEnd) ;

		/* �Z�푤�̒T���B*/
		while (pNode != NULL) {
			if (TSkkRuleTreeNode_iGetChar (pNode) == nCH)
				break ;
			pNode	= TSkkRuleTreeNode_pGetBrother (pNode) ;
		}
		if (pNode == NULL) {
			/* �����ł����B��v���Ă����Ƃ���܂ŕԂ��B*/
			if (ppResult != NULL)
				*ppResult	= pParent ;
#if defined (DEBUG)
			_tprintf (TEXT ("iSeachTree: not found\n")) ;
#endif
			return	wptrBack - pString ;
		}
		if (wptr >= wptrEnd) {
			/* ���������B*/
			if (ppResult != NULL)
				*ppResult	= pNode ;
#if defined (DEBUG)
			_tprintf (TEXT ("iSeachTree: found\n")) ;
			TSkkRuleTreeNode_vDebugOut (pNode) ;
			TSkkRuleTreeNode_vDebugOut (pParent) ;
#endif
			return	wptr - pString ;
		}
#if defined (DEBUG)
		_tprintf (TEXT ("iSearchTree: -> goto child\n")) ;
		TSkkRuleTreeNode_vDebugOut (pNode) ;
#endif
		pParent	= pNode ;
		pNode	= TSkkRuleTreeNode_pGetChild (pNode) ;
	}
	if (ppResult != NULL)
		*ppResult	= pTree ;
	return	0 ;
}

BOOL
TSkkRuleTreeNode_bAddRuleSP (
	struct CSkkRuleTreeNode**	ppTree,
	int							iTree,
	LPCDSTR						dstrPrefix,
	int							nPrefixLen,
	LPCWSTR						wstrNext,
	int							nNextLen,
	int							iNextRule,
	LPCWSTR						wstrHira,
	int							nHiraLen,
	LPCWSTR						wstrKata,
	int							nKataLen)
{
	struct CSkkRuleTreeNode*	pRoot ;
	struct CSkkRuleTreeNode*	pAddPoint ;
	struct CSkkRuleTreeNode*	pAddTree ;
	struct CSkkRuleTreeNode*	pAddTreeRoot	= NULL ;
	struct CSkkRuleTreeNodeOutput*	pOutput	= NULL ;
	LPCDSTR						pwPtr ;
	LPCDSTR						pwPtrEnd ;
	int							nCH, nOffset = 0 ;
	DCHAR	dbufHira [32], dbufKata [32], dbufNext [32] ;
	LPDSTR						dstrHira	= NULL ;
	LPDSTR						dstrKata	= NULL ;
	LPDSTR						dstrNext	= NULL ;
	BOOL						bRetval		= TRUE ;

	/* prefix �����݂��Ȃ��̂͋�����Ȃ��Bprefix �Ȃ��͔ԕ��݂̂ł���B*/
	if (ppTree == NULL || dstrPrefix == NULL || nPrefixLen <= 0)
		return	FALSE ;

	pRoot		= *ppTree ;
	/* �ԕ���p�ӂ���B����� original �̍\���ɂ��킹�Ă���B*/
	if (pRoot == NULL) {
		pRoot	= TSkkRuleTreeNode_pCreateInstance (0, NULL, 0, NULL, 0, iTree, NULL) ;
		if (pRoot == NULL)
			return	FALSE ;
		*ppTree	= pRoot ;
	}
	nOffset		= TSkkRuleTreeNode_iSearchTree (pRoot, dstrPrefix, nPrefixLen, &pAddPoint) ;

	pwPtr		= dstrPrefix + nOffset ;
	pwPtrEnd	= dstrPrefix + nPrefixLen ;
	if (pwPtr < pwPtrEnd) {
		struct CSkkRuleTreeNode*		pCurAddPoint		= NULL ;
		int	nKataDLen, nHiraDLen, nNextDLen ;

		/*	�S���̐V�K�o�^�ł���ꍇ�B*/
		/*
		 *	shu �Ƃ��āAs �����݂���ꍇ�ɂ� nOffset = 1�B
		 *
		 *	���[�g -> ``s'' -> ...
		 *
		 *	���� ``s'' �� pAddPoint �Ƃ��Č��t�����Ă���B��������A
		 *
		 *	(1) ``h'' -> ``u'' �̃����N���쐬����B
		 *	(2) ``s'' �̎q���Ƃ��Ēǉ�����B
		 *		����ɂ�� ``s'' -> ``h'' -> ``u'' �� rule-tree ���쐬�����B
		 *
		 *	���� ``s'' �̎q�������݂����ꍇ�ɂ́A
		 *
		 *	(2)' ``h''->``u'' �� ``h'' �̌Z��ɂ��Ƃ��Ƃ� ``s'' �̎q����ǉ�����B
		 *	(3)  ``s'' �̎q���Ƃ��� ``h'' ���Ȃ��B
		 *
		 *	���̃��[���Ɉᔽ���Ȃ��悤�Ƀ��[���؂̍\�����g�����Ȃ���΂Ȃ�Ȃ��B
		 *	nCH �� INT �Ȃ̂ŁA�����̕������ԈႦ�Ȃ���Ίg���Ɏ��s���邱�Ƃ͂Ȃ�
		 *	�̂�������Ȃ��B
		 *	nCH �ɓ��ꕶ������ꂽ�ꍇ�́u���ݏ�Ԃ̊Ǘ��v�����B�����͂ǂ��ɂ���
		 *	�Ȃ���΂Ȃ�Ȃ��B����̓��[���؂̒��ɓ����̂͂܂�����������Ȃ��B
		 *	nCH �̓��ꕶ���g������
		 *		SelectBranch
		 *	�͕ω�����B
		 *	����Ԃ� m_pPrefix, m_nPrefix ������A����̎��ۂ�ۑ�����ꏊ���K�v�B
		 *	���ۂ̏�Ԃ́AiCH, m_pPrefix, m_nPrefix ����쐬����锤�B
		 */
		pAddTreeRoot	= NULL ;
		while (pwPtr < pwPtrEnd) {
			LPCDSTR	pwPtrBack	= pwPtr ;

			nCH			= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
			if (nCH == SYSCHAR_INVALID) {
				return	FALSE ;
			}
			if (pwPtr >= pwPtrEnd) {
				pwPtr	= pwPtrBack ;
				break ;
			}
			pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, pwPtr - dstrPrefix, NULL, 0, iTree, NULL) ;
			if (pAddTree == NULL) {
				TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
				return	FALSE ;
			}

			ASSERT (pAddPoint != NULL && pRoot != NULL) ;
			/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
			if (pAddTreeRoot == NULL) {
				pAddTreeRoot	= pAddTree ;
				pCurAddPoint	= pAddTree ;
			} else {
				TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
				TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
				pCurAddPoint	= pAddTree ;
			}
		}

		/*	Output ���쐬����B
		 */
		dstrHira	= pGetDString (dbufHira, ARRAYSIZE (dbufHira), wstrHira, nHiraLen, &nHiraDLen) ;
		dstrKata	= pGetDString (dbufKata, ARRAYSIZE (dbufKata), wstrKata, nKataLen, &nKataDLen) ;

		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringPairInstance (dstrHira, nHiraDLen, dstrKata, nKataDLen) ;
		if (pOutput == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}

		/*	Output �̂Ȃ��� RuleTree �̃m�[�h���쐬����B
		 */
		nCH	= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
		if (nCH == SYSCHAR_INVALID) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		dstrNext	= pGetDString (dbufNext, ARRAYSIZE (dbufNext), wstrNext, nNextLen, &nNextDLen) ;

		pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, nPrefixLen, dstrNext, nNextDLen, iNextRule, pOutput) ;
		if (pAddTree == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
		ASSERT (pAddPoint != NULL && pRoot != NULL) ;
		if (pAddTreeRoot != NULL) {
			ASSERT (pCurAddPoint != NULL && pCurAddPoint != pAddPoint) ;
			TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
			TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
		} else {
			pAddTreeRoot	= pAddTree ;
		}

		/*	���̒i�K�ł��Ƃ̖؂Ƀ}�[�W����B
		 */
		TSkkRuleTreeNode_vSetBrother (pAddTreeRoot, TSkkRuleTreeNode_pGetChild (pAddPoint)) ;
		TSkkRuleTreeNode_vSetChild (pAddPoint, pAddTreeRoot) ;
	} else {
		/*	NextState �̍X�V���Ȃ��Ƃ����Ȃ��̂ł́B
		 */
		int	nHiraDLen, nKataDLen ;

		dstrHira	= pGetDString (dbufHira, ARRAYSIZE (dbufHira), wstrHira, nHiraLen, &nHiraDLen) ;
		dstrKata	= pGetDString (dbufKata, ARRAYSIZE (dbufKata), wstrKata, nKataLen, &nKataDLen) ;

		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringPairInstance (dstrHira, nHiraDLen, dstrKata, nKataDLen) ;
		if (pOutput == NULL) {
			bRetval	= FALSE ;
			goto	Exit ;
		}
		TSkkRuleTreeNode_vSetOutput (pAddPoint, pOutput) ;
	}
Exit:
	if (dstrHira != dbufHira && dstrHira != NULL)
		FREE (dstrHira) ;
	if (dstrKata != dbufKata && dstrKata != NULL)
		FREE (dstrKata) ;
	if (dstrNext != dbufNext && dstrNext != NULL)
		FREE (dstrKata) ;
	return	bRetval ; ;
}

BOOL
TSkkRuleTreeNode_bAddRuleS (
	struct CSkkRuleTreeNode**	ppTree,
	int							iTree,
	LPCDSTR						dstrPrefix,
	int							nPrefixLen,
	LPCWSTR						wstrNext,
	int							nNextLen,
	int							iNextRule,
	LPCWSTR						wstrString,
	int							nString)
{
	struct CSkkRuleTreeNode*	pRoot ;
	struct CSkkRuleTreeNode*	pAddPoint ;
	struct CSkkRuleTreeNode*	pAddTree ;
	struct CSkkRuleTreeNode*	pAddTreeRoot	= NULL ;
	struct CSkkRuleTreeNodeOutput*	pOutput	= NULL ;
	LPCDSTR						pwPtr ;
	LPCDSTR						pwPtrEnd ;
	int							nCH, nOffset = 0 ;
	DCHAR	dbufString [32], dbufNext [32] ;
	LPDSTR						dstrString	= NULL ;
	LPDSTR						dstrNext	= NULL ;
	BOOL						bRetval		= TRUE ;

	/* prefix �����݂��Ȃ��̂͋�����Ȃ��Bprefix �Ȃ��͔ԕ��݂̂ł���B*/
	if (ppTree == NULL || dstrPrefix == NULL || nPrefixLen <= 0)
		return	FALSE ;

	pRoot		= *ppTree ;
	/* �ԕ���p�ӂ���B����� original �̍\���ɂ��킹�Ă���B*/
	if (pRoot == NULL) {
		pRoot	= TSkkRuleTreeNode_pCreateInstance (0, NULL, 0, NULL, 0, iTree, NULL) ;
		if (pRoot == NULL)
			return	FALSE ;
		*ppTree	= pRoot ;
	}
	nOffset		= TSkkRuleTreeNode_iSearchTree (pRoot, dstrPrefix, nPrefixLen, &pAddPoint) ;

	pwPtr		= dstrPrefix + nOffset ;
	pwPtrEnd	= dstrPrefix + nPrefixLen ;
	if (pwPtr < pwPtrEnd) {
		struct CSkkRuleTreeNode*		pCurAddPoint		= NULL ;
		int	nNextDLen, nStrDLen ;

		/*	�S���̐V�K�o�^�ł���ꍇ�B*/
		/*
		 *	shu �Ƃ��āAs �����݂���ꍇ�ɂ� nOffset = 1�B
		 *
		 *	���[�g -> ``s'' -> ...
		 *
		 *	���� ``s'' �� pAddPoint �Ƃ��Č��t�����Ă���B��������A
		 *
		 *	(1) ``h'' -> ``u'' �̃����N���쐬����B
		 *	(2) ``s'' �̎q���Ƃ��Ēǉ�����B
		 *		����ɂ�� ``s'' -> ``h'' -> ``u'' �� rule-tree ���쐬�����B
		 *
		 *	���� ``s'' �̎q�������݂����ꍇ�ɂ́A
		 *
		 *	(2)' ``h''->``u'' �� ``h'' �̌Z��ɂ��Ƃ��Ƃ� ``s'' �̎q����ǉ�����B
		 *	(3)  ``s'' �̎q���Ƃ��� ``h'' ���Ȃ��B
		 *
		 *	���̃��[���Ɉᔽ���Ȃ��悤�Ƀ��[���؂̍\�����g�����Ȃ���΂Ȃ�Ȃ��B
		 *	nCH �� INT �Ȃ̂ŁA�����̕������ԈႦ�Ȃ���Ίg���Ɏ��s���邱�Ƃ͂Ȃ�
		 *	�̂�������Ȃ��B
		 *	nCH �ɓ��ꕶ������ꂽ�ꍇ�́u���ݏ�Ԃ̊Ǘ��v�����B�����͂ǂ��ɂ���
		 *	�Ȃ���΂Ȃ�Ȃ��B����̓��[���؂̒��ɓ����̂͂܂�����������Ȃ��B
		 *	nCH �̓��ꕶ���g������
		 *		SelectBranch
		 *	�͕ω�����B
		 *	����Ԃ� m_pPrefix, m_nPrefix ������A����̎��ۂ�ۑ�����ꏊ���K�v�B
		 *	���ۂ̏�Ԃ́AiCH, m_pPrefix, m_nPrefix ����쐬����锤�B
		 */
		pAddTreeRoot	= NULL ;
		while (pwPtr < pwPtrEnd) {
			LPCDSTR	pwPtrBack	= pwPtr ;

			nCH			= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
			if (nCH == SYSCHAR_INVALID) {
				return	FALSE ;
			}
			if (pwPtr >= pwPtrEnd) {
				pwPtr	= pwPtrBack ;
				break ;
			}
			pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, pwPtr - dstrPrefix, NULL, 0, iTree, NULL) ;
			if (pAddTree == NULL) {
				TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
				return	FALSE ;
			}

			ASSERT (pAddPoint != NULL && pRoot != NULL) ;
			/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
			if (pAddTreeRoot == NULL) {
				pAddTreeRoot	= pAddTree ;
				pCurAddPoint	= pAddTree ;
			} else {
				TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
				TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
				pCurAddPoint	= pAddTree ;
			}
		}

		/*	Output ���쐬����B
		 */
		dstrString	= pGetDString (dbufString, ARRAYSIZE (dbufString), wstrString, nString, &nStrDLen) ;
		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringInstance (dstrString, nStrDLen) ;
		if (pOutput == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}

		/*	Output �̂Ȃ��� RuleTree �̃m�[�h���쐬����B
		 */
		nCH	= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
		if (nCH == SYSCHAR_INVALID) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		dstrNext	= pGetDString (dbufNext, ARRAYSIZE (dbufNext), wstrNext, nNextLen, &nNextDLen) ;

		pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, nPrefixLen, dstrNext, nNextDLen, iNextRule, pOutput) ;
		if (pAddTree == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
		ASSERT (pAddPoint != NULL && pRoot != NULL) ;
		if (pAddTreeRoot != NULL) {
			ASSERT (pCurAddPoint != NULL && pCurAddPoint != pAddPoint) ;
			TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
			TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
		} else {
			pAddTreeRoot	= pAddTree ;
		}

		/*	���̒i�K�ł��Ƃ̖؂Ƀ}�[�W����B
		 */
		TSkkRuleTreeNode_vSetBrother (pAddTreeRoot, TSkkRuleTreeNode_pGetChild (pAddPoint)) ;
		TSkkRuleTreeNode_vSetChild (pAddPoint, pAddTreeRoot) ;
	} else {
		int	nStrDLen ;
		/*	NextState �̍X�V���Ȃ��Ƃ����Ȃ��̂ł́B
		 */
		dstrString	= pGetDString (dbufString, ARRAYSIZE (dbufString), wstrString, nString, &nStrDLen) ;
		pOutput		= TSkkRuleTreeNodeOutput_pCreateStringInstance (dstrString, nStrDLen) ;
		if (pOutput == NULL) {
			bRetval	= FALSE ;
			goto	Exit ;
		}
		TSkkRuleTreeNode_vSetOutput (pAddPoint, pOutput) ;
	}
Exit:
	if (dstrString != dbufString && dstrString != NULL)
		FREE (dstrString) ;
	if (dstrNext != dbufNext && dstrNext != NULL)
		FREE (dstrNext) ;
	return	bRetval ; ;
}

BOOL
TSkkRuleTreeNode_bAddRuleM (
	struct CSkkRuleTreeNode**	ppTree,
	int							iTree,
	LPCDSTR						dstrPrefix,
	int							nPrefixLen,
	LPCWSTR						wstrNext,
	int							nNextLen,
	int							iNextRule,
	int							nMacro) 
{
	struct CSkkRuleTreeNode*	pRoot ;
	struct CSkkRuleTreeNode*	pAddPoint ;
	struct CSkkRuleTreeNode*	pAddTree ;
	struct CSkkRuleTreeNode*	pAddTreeRoot	= NULL ;
	struct CSkkRuleTreeNodeOutput*	pOutput	= NULL ;
	LPCDSTR						pwPtr ;
	LPCDSTR						pwPtrEnd ;
	int							nCH, nOffset = 0 ;
	DCHAR						dbufNext [32] ;
	LPDSTR						dstrNext	= NULL ;
	BOOL						bRetval		= TRUE ;
	/* prefix �����݂��Ȃ��̂͋�����Ȃ��Bprefix �Ȃ��͔ԕ��݂̂ł���B*/
	if (ppTree == NULL || dstrPrefix == NULL || nPrefixLen <= 0)
		return	FALSE ;

	pRoot		= *ppTree ;
	/* �ԕ���p�ӂ���B����� original �̍\���ɂ��킹�Ă���B*/
	if (pRoot == NULL) {
		pRoot	= TSkkRuleTreeNode_pCreateInstance (0, NULL, 0, NULL, 0, iTree, NULL) ;
		if (pRoot == NULL)
			return	FALSE ;
		*ppTree	= pRoot ;
	}
	nOffset		= TSkkRuleTreeNode_iSearchTree (pRoot, dstrPrefix, nPrefixLen, &pAddPoint) ;

	pwPtr		= dstrPrefix + nOffset ;
	pwPtrEnd	= dstrPrefix + nPrefixLen ;
	if (pwPtr < pwPtrEnd) {
		struct CSkkRuleTreeNode*		pCurAddPoint		= NULL ;
		int	nNextDLen ;

		/*	�S���̐V�K�o�^�ł���ꍇ�B*/
		/*
		 *	shu �Ƃ��āAs �����݂���ꍇ�ɂ� nOffset = 1�B
		 *
		 *	���[�g -> ``s'' -> ...
		 *
		 *	���� ``s'' �� pAddPoint �Ƃ��Č��t�����Ă���B��������A
		 *
		 *	(1) ``h'' -> ``u'' �̃����N���쐬����B
		 *	(2) ``s'' �̎q���Ƃ��Ēǉ�����B
		 *		����ɂ�� ``s'' -> ``h'' -> ``u'' �� rule-tree ���쐬�����B
		 *
		 *	���� ``s'' �̎q�������݂����ꍇ�ɂ́A
		 *
		 *	(2)' ``h''->``u'' �� ``h'' �̌Z��ɂ��Ƃ��Ƃ� ``s'' �̎q����ǉ�����B
		 *	(3)  ``s'' �̎q���Ƃ��� ``h'' ���Ȃ��B
		 *
		 *	���̃��[���Ɉᔽ���Ȃ��悤�Ƀ��[���؂̍\�����g�����Ȃ���΂Ȃ�Ȃ��B
		 *	nCH �� INT �Ȃ̂ŁA�����̕������ԈႦ�Ȃ���Ίg���Ɏ��s���邱�Ƃ͂Ȃ�
		 *	�̂�������Ȃ��B
		 *	nCH �ɓ��ꕶ������ꂽ�ꍇ�́u���ݏ�Ԃ̊Ǘ��v�����B�����͂ǂ��ɂ���
		 *	�Ȃ���΂Ȃ�Ȃ��B����̓��[���؂̒��ɓ����̂͂܂�����������Ȃ��B
		 *	nCH �̓��ꕶ���g������
		 *		SelectBranch
		 *	�͕ω�����B
		 *	����Ԃ� m_pPrefix, m_nPrefix ������A����̎��ۂ�ۑ�����ꏊ���K�v�B
		 *	���ۂ̏�Ԃ́AiCH, m_pPrefix, m_nPrefix ����쐬����锤�B
		 */
		pAddTreeRoot	= NULL ;
		while (pwPtr < pwPtrEnd) {
			LPCDSTR	pwPtrBack	= pwPtr ;

			nCH			= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
			if (nCH == SYSCHAR_INVALID) {
				return	FALSE ;
			}
			if (pwPtr >= pwPtrEnd) {
				pwPtr	= pwPtrBack ;
				break ;
			}
			pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, pwPtr - dstrPrefix, NULL, 0, iTree, NULL) ;
			if (pAddTree == NULL) {
				TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
				return	FALSE ;
			}

			ASSERT (pAddPoint != NULL && pRoot != NULL) ;
			/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
			if (pAddTreeRoot == NULL) {
				pAddTreeRoot	= pAddTree ;
				pCurAddPoint	= pAddTree ;
			} else {
				TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
				TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
				pCurAddPoint	= pAddTree ;
			}
		}

		/*	Output ���쐬����B
		 */
		pOutput		= TSkkRuleTreeNodeOutput_pCreateMacroInstance (nMacro) ;
		if (pOutput == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			return	FALSE ;
		}

		/*	Output �̂Ȃ��� RuleTree �̃m�[�h���쐬����B
		 */
		nCH	= TSkkRuleTreeNode_iGetRuleCharacter (&pwPtr, pwPtrEnd) ;
		if (nCH == SYSCHAR_INVALID) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			return	FALSE ;
		}
		dstrNext	= pGetDString (dbufNext, ARRAYSIZE (dbufNext), wstrNext, nNextLen, &nNextDLen) ;
		pAddTree	= TSkkRuleTreeNode_pCreateInstance (nCH, dstrPrefix, nPrefixLen, dstrNext, nNextDLen, iNextRule, pOutput) ;
		if (pAddTree == NULL) {
			TSkkRuleTreeNode_vDestroyTree (pAddTreeRoot) ;
			TSkkRuleTreeNodeOutput_vDestroy (pOutput) ;
			bRetval	= FALSE ;
			goto	Exit ;
		}
		/*	addpoint �� addtree ��ǉ�����B�\�[�g���Ȃ��Ȃ�y�����c�B*/
		ASSERT (pAddPoint != NULL && pRoot != NULL) ;
		if (pAddTreeRoot != NULL) {
			ASSERT (pCurAddPoint != NULL && pCurAddPoint != pAddPoint) ;
			TSkkRuleTreeNode_vSetBrother (pAddTree, TSkkRuleTreeNode_pGetChild (pCurAddPoint)) ;
			TSkkRuleTreeNode_vSetChild (pCurAddPoint, pAddTree) ;
		} else {
			pAddTreeRoot	= pAddTree ;
		}

		/*	���̒i�K�ł��Ƃ̖؂Ƀ}�[�W����B
		 */
		TSkkRuleTreeNode_vSetBrother (pAddTreeRoot, TSkkRuleTreeNode_pGetChild (pAddPoint)) ;
		TSkkRuleTreeNode_vSetChild (pAddPoint, pAddTreeRoot) ;
	} else {
		/*	NextState �̍X�V���Ȃ��Ƃ����Ȃ��̂ł́B
		 */
		pOutput		= TSkkRuleTreeNodeOutput_pCreateMacroInstance (nMacro) ;
		if (pOutput == NULL)
			return	FALSE ;
		TSkkRuleTreeNode_vSetOutput (pAddPoint, pOutput) ;
	}
Exit:
	if (dstrNext != dbufNext && dstrNext != NULL)
		FREE (dstrNext) ;
	return	bRetval ; ;
}

BOOL
TSkkRuleTreeNode_bDeleteRule (
	struct CSkkRuleTreeNode**	ppTree,
	LPCDSTR						pString,
	int							nString)
{
	struct CSkkRuleTreeNode*	pTree ;
	struct CSkkRuleTreeNode*	pParent ;
	struct CSkkRuleTreeNode*	pNode ;
	struct CSkkRuleTreeNode*	pPrev ;
	LPCDSTR		wptr ;
	int			nptr, nCH ;

	pTree	= *ppTree ;
	pNode	= pTree != NULL? TSkkRuleTreeNode_pGetChild (pTree) : NULL ;
	pParent	= pTree ;
	wptr	= pString ;
	nptr	= nString ;

	/*	�܂� brother �����ւ̒T�������s����B*/
	while (pNode != NULL && nptr > 0) {
		nCH		= *wptr ;
		pPrev	= NULL ;
		while (pNode != NULL) {
			if (TSkkRuleTreeNode_iGetChar (pNode) == nCH) 
				break ;
			pPrev	= pNode ;
			pNode	= TSkkRuleTreeNode_pGetBrother (pNode) ;
		}
		/* �Y���Ȃ��B*/
		if (pNode == NULL)
			return	FALSE ;

		wptr	++ ;
		nptr	-- ;
		if (nptr <= 0) {
			/* ���̈ʒu�ō폜�B*/
			if (pPrev == NULL) {
				/* �e����̃����N��\��ւ���B*/
				if (pParent != NULL) {
					TSkkRuleTreeNode_vSetChild (pParent, TSkkRuleTreeNode_pGetBrother (pNode)) ;
				} else {
					*ppTree				= TSkkRuleTreeNode_pGetBrother (pNode) ;
				}
				TSkkRuleTreeNode_vSetBrother (pNode, NULL) ;
			} else {
				/*	�Z��̃����N��\��ւ���B
				 *	�c�q����������q���͑S�ł���B
				 */
				TSkkRuleTreeNode_vSetBrother (pPrev, TSkkRuleTreeNode_pGetBrother (pNode)) ;
				TSkkRuleTreeNode_vSetBrother (pNode, NULL) ;
			}
			TSkkRuleTreeNode_vDestroyTree (pNode) ;
			break ;
		}
		pParent	= pNode ;
		pNode	= TSkkRuleTreeNode_pGetChild (pNode) ;
	}
	return	TRUE ;
}

void
TSkkRuleTreeNode_vDestroyTree (
	struct CSkkRuleTreeNode*	pRoot)
{
	struct CSkkRuleTreeNode*	pBrother ;
	struct CSkkRuleTreeNode*	pChild ;

	if (pRoot == NULL)
		return ;

	pBrother	= TSkkRuleTreeNode_pGetBrother (pRoot) ;
	pChild		= TSkkRuleTreeNode_pGetChild (pRoot) ;
	TSkkRuleTreeNode_vSetBrother (pRoot, NULL) ;
	TSkkRuleTreeNode_vSetChild (pRoot, NULL) ;
	TSkkRuleTreeNode_vDestroy (pRoot) ;

	if (pBrother != NULL)
		TSkkRuleTreeNode_vDestroyTree (pBrother) ;
	if (pChild != NULL)
		TSkkRuleTreeNode_vDestroyTree (pChild) ;
	return ;
}

int
TSkkRuleTreeNode_iGetRuleCharacter (
	LPCDSTR*	ppwPtr,
	LPCDSTR		pwPtrEnd)
{
	LPCDSTR	pwPtr ;
	int		nCH ;

	if (ppwPtr == NULL || pwPtrEnd == NULL)
		return	SYSCHAR_INVALID ;

	pwPtr	= *ppwPtr ;
	if (pwPtr == NULL)
		return	SYSCHAR_INVALID ;

	if (*pwPtr == L'\\') {
		pwPtr	++ ;
		if (pwPtr >= pwPtrEnd) {
			nCH	= SYSCHAR_INVALID ;
		} else {
			switch (*pwPtr) {
			case '\\':
				nCH	= '\\' ;
				break ;
			case	'V':	/* Vowel */
				nCH	= SYSCHAR_VOWEL ;
				break ;
			case	'C':
				nCH	= SYSCHAR_CONSONANT ;
				break ;
			case	'?':
				nCH	= SYSCHAR_DEFAULT ;
				break ;
			default:
				nCH	= SYSCHAR_INVALID ; 
				break ;
			}
		}
	} else {
		nCH	= *pwPtr ;
	}
	pwPtr	++ ;
	*ppwPtr	= pwPtr ;
	return	nCH ;
}

/*===============================================================
 *	public methods
 */

#if 0
void
TSkkRuleTreeNode_vDebugOut (const struct CSkkRuleTreeNode* pNode)
{
	DCHAR	buf [256] ;
	DCHAR	bufPrefix [128], bufNextState [128] ;
	int		n ;

	if (pNode->_pPrefix != NULL && pNode->_nPrefix > 0) {
		n	= (pNode->_nPrefix < (ARRAYSIZE (bufPrefix) - 1))? pNode->_nPrefix : (ARRAYSIZE (bufPrefix) - 1) ;
		memcpy (bufPrefix, pNode->_pPrefix, n * sizeof (DCHAR)) ;
		bufPrefix [n]	= L'\0' ;
	} else {
		bufPrefix [0]	= L'\0' ;
	}
	if (pNode->_pNextState != NULL && pNode->_nNextState > 0) {
		n	= (pNode->_nNextState < (ARRAYSIZE (bufNextState) - 1))? pNode->_nNextState : (ARRAYSIZE (bufNextState) - 1) ;
		memcpy (bufNextState, pNode->_pNextState, n * sizeof (DCHAR)) ;
		bufNextState [n]	= L'\0' ;
	} else {
		bufNextState [0]	= L'\0' ;
	}
	if (pNode->_pOutput != NULL) {
		switch (TSkkRuleTreeNodeOutput_iGetType (pNode->_pOutput)) {
		case	NTYPE_STRINGPAIR:
			{
				LPCDSTR	pHira, pKata ;
				int		nHira, nKata ;
				DCHAR	bufHira [128], bufKata [128] ;

				if (! TSkkRuleTreeNodeOutput_bGetLString (pNode->_pOutput, &pHira, &nHira) ||
					! TSkkRuleTreeNodeOutput_bGetRString (pNode->_pOutput, &pKata, &nKata)) {
					break ;
				}
				if (pHira != NULL && nHira > 0) {
					n	= (nHira < (ARRAYSIZE (bufHira) - 1))? nHira : (ARRAYSIZE (bufHira) - 1) ;
					memcpy (bufHira, pHira, nHira * sizeof (DCHAR)) ;
					bufHira [n]	= L'\0' ;
				} else {
					bufHira [0]	= L'\0' ;
				}
				if (pKata != NULL && nKata > 0) {
					n	= (nKata < (ARRAYSIZE (bufKata) - 1))? nKata : (ARRAYSIZE (bufKata) - 1) ;
					memcpy (bufKata, pKata, nKata * sizeof (DCHAR)) ;
					bufKata [n]	= L'\0' ;
				} else {
					bufKata [0]	= L'\0' ;
				}
				wnsprintfW (buf, ARRAYSIZE (buf) - 1, L"Prefix(\"%s\"), Next(\"%s\"), Hira(\"%s\"), Kata(\"%s\")\n", bufPrefix, bufNextState, bufHira, bufKata) ;
				buf [ARRAYSIZE (buf) - 1]	= L'\0' ;
			}
			break ;

		case	NTYPE_STRING:
			{
				DCHAR	bufString [128] ;
				LPCDSTR	pString ;
				int		nString ;
				if (! TSkkRuleTreeNodeOutput_bGetString (pNode->_pOutput, &pString, &nString)) {
					break ;
				}
				if (pString != NULL && nString > 0) {
					n	= (nString < (ARRAYSIZE (bufString) - 1))? nString : (ARRAYSIZE (bufString) - 1) ;
					memcpy (bufString, pString, nString * sizeof (DCHAR)) ;
				} else {
					bufString [0]	= L'\0' ;
				}
				wnsprintfW (buf, ARRAYSIZE (buf) - 1, L"Prefix(\"%s\"), Next(\"%s\"), String(\"%s\")\n", bufPrefix, bufNextState, bufString) ;
				buf [ARRAYSIZE (buf) - 1]	= L'\0' ;
			}
			break ;

		case	NTYPE_MACRO:
			{
				int		nMacro ;
				if (! TSkkRuleTreeNodeOutput_bGetMacro (pNode->_pOutput, &nMacro)) {
					break ;
				}
				wnsprintfW (buf, ARRAYSIZE (buf) - 1, L"Prefix(\"%s\"), Next(\"%s\"), Macro(%d)\n", bufPrefix, bufNextState, nMacro) ;
				buf [ARRAYSIZE (buf) - 1]	= L'\0' ;
			}
			break ;
		default:
			break ;
		}
		wprintf (L"%s\n", buf) ;
	} else {
		wprintf (L"nil\n", buf) ;
	}
	return ;
}
#endif

#if defined (UNIT_TEST)
/*	�P�̃e�X�g�̂��߂̃R�[�h�B
 */
int
_tmain (void)
{
	struct CSkkRuleTreeNode*	pRoot	= NULL ;
	struct CSkkRuleTreeNode*	pNode	= NULL ;
	int		i, n ;
	char	buf [12] ;

	/*
struct TSkkBaseRuleT1 {
	LPCTSTR	_strState ;
	LPCTSTR	_strNext ;
	struct {
		LPCTSTR	_strHira ;
		LPCTSTR	_strKata ;
	}	_case ;
} ;*/
	_tsetlocale (LC_CTYPE, TEXT ("")) ;

	/* debugger �� process �� attach ���邽�߂̗]�T�����B*/
	_tprintf (TEXT ("> ")) ;
	fflush (stdout) ;
	fgets (buf, 10, stdin) ;

	for (i = 0 ; i < ARRAYSIZE (_rT1) ; i ++) {
		int	nPrefix, nNextState, nHira, nKata ;

		nPrefix		= (_rT1 [i]._strState      != NULL)? lstrlenW (_rT1 [i]._strState)      : 0 ;
		nNextState	= (_rT1 [i]._strNext       != NULL)? lstrlenW (_rT1 [i]._strNext)       : 0 ;
		nHira		= (_rT1 [i]._case._strHira != NULL)? lstrlenW (_rT1 [i]._case._strHira) : 0 ;
		nKata		= (_rT1 [i]._case._strKata != NULL)? lstrlenW (_rT1 [i]._case._strKata) : 0 ;
		if (! TSkkRuleTreeNode_bAddRule (&pRoot, _rT1 [i]._strState, nPrefix, _rT1 [i]._strNext, nNextState, _rT1 [i]._case._strHira, nHira, _rT1 [i]._case._strKata, nKata)) {
			_tprintf (TEXT ("TSkkRuleTreeNode_bAddRule: failed. (%d)\n"), i) ;
			break ;
		}
	}
	if (pRoot != NULL) {
		_tprintf (TEXT ("Root ...\n")) ;
		TSkkRuleTreeNode_vDebugOut (pRoot) ;
	}
	n	= TSkkRuleTreeNode_iSearchTree (pRoot, L"b", 1, &pNode) ;
	_tprintf (TEXT ("Search ... \"b\" ... hit(%d)\n"), n) ;
	if (pNode != NULL) {
		TSkkRuleTreeNode_vDebugOut (pNode) ;
	}
	n	= TSkkRuleTreeNode_iSearchTree (pRoot, L"fya", 3, &pNode) ;
	_tprintf (TEXT ("Search ... \"fya\" ... hit(%d)\n"), n) ;
	if (pNode != NULL) {
		TSkkRuleTreeNode_vDebugOut (pNode) ;
	}
	return	0 ;
}
#endif

