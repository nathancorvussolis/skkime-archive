#include "stdafx.h"
#include "skimconf.h"
#include "resource.h"

/*========================================================================
 *	Registry-related definitions
 */
#define	REGINFO_KANAMODEWHENOPEN		TEXT("KanaModeWhenOpen")
#define	REGINFO_ECHO					TEXT("Echo")
#define	REGINFO_AUTOINSERTPAREN			TEXT("AutoInsertParen")
#define	REGINFO_COMPOSITIONAUTOSHIFT	TEXT("CompTextAutoShift")
#define	REGINFO_DELETEIMPLIESKAKUTEI	TEXT("DeleteImpliesKakutei")
#define	REGINFO_DATEAD					TEXT("DateAd")
#define	REGINFO_NUMBERSTYLE				TEXT("NumberStyle")
#define	REGINFO_BRACKETPARENS			TEXT("CustomBracketParens")
#define	REGINFO_KUTOUTENTYPE			TEXT("KutoutenType")
#define	REGINFO_KUTOUTENS				TEXT("CustomKutoutens")
#define	REGINFO_KAKUTEIEARLY			TEXT("KakuteiEarly")
#define	REGINFO_OKURICHARALISTTYPE		TEXT("OkuriCharAlistType")
#define	REGINFO_OKURICHARALIST			TEXT("OkuriCharAlist")

/*========================================================================
 *	Definitions
 */
enum {
	REGKEYTYPE_UNKNOWN	= -1,
	REGKEYTYPE_BOOL		= 0,
	REGKEYTYPE_INT,
} ;

enum {
	KUTOUTEN_TYPE_JP	= 0,
	KUTOUTEN_TYPE_EN,
	KUTOUTEN_TYPE_CUSTOM,
} ;

enum {
	BRACKETPARENTP_NONE	= 0,
	BRACKETPARENTP_DEFAULT,
	BRACKETPARENTP_USERDEFINED,
} ;

enum {
	OKURICHARTP_NONE	= 0,
	OKURICHARTP_DEFAULT,
	OKURICHARTP_USERDEFINED,
} ;

#define	SIZE_LBRACKET		32
#define	SIZE_RBRACKET		SIZE_LBRACKET
#define	SIZE_KUTEN			32
#define	SIZE_TOUTEN			SIZE_KUTEN
#define	BUFSIZE_STRPAIR		32

#define	SEPCHAR	TEXT(',')

/*========================================================================
 *	structures
 */
struct TStringPairNode {
	TCHAR					m_bufLeft  [BUFSIZE_STRPAIR] ;
	TCHAR					m_bufRight [BUFSIZE_STRPAIR] ;
	struct TStringPairNode*	m_pPrev ;
	struct TStringPairNode*	m_pNext ;
} ;

struct TEditKutoutenListArg {
	struct TStringPairNode*	m_plstKutouten ;
} ;

struct TEditBracketParenListArg {
	struct TStringPairNode*	m_plstBracketParen ;
} ;

struct TEditOkuriCharAlistArg {
	struct TStringPairNode*	m_plstOkuriCharPair ;
} ;

/*========================================================================
 *	prototypes
 */
static	INT_PTR				dlgGeneric_iOnInitDialog		(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgGeneric_iOnCommand			(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgGeneric_iOnNotify			(HWND, WPARAM, LPARAM) ;
static	void				dlgGeneric_vSyncControls		(HWND) ;
static	void				dlgGeneric_vEditBracket			(HWND) ;
static	void				dlgGeneric_vEditKutouten		(HWND) ;
static	void				dlgGeneric_vEditOkuriCharAlist	(HWND) ;
static	INT_PTR	CALLBACK	dlgEditBracketListProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditKutoutenListProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditOkuriCharAlistProc		(HWND, UINT, WPARAM, LPARAM) ;

static	void				dlgGeneric_bLoadRegistrySetting		(void) ;
static	BOOL				dlgGeneric_bSaveRegistrySetting		(void) ;
static	struct TStringPairNode*	dlgGeneric_pDecodeStringPairList	(LPCTSTR) ;
static	LPTSTR				dlgGeneric_pEncodeStringPairList	(struct TStringPairNode*, int*) ;

static	struct TStringPairNode*		pCreateStringPair			(LPCTSTR, LPCTSTR) ;
static	struct TStringPairNode*		pCopyStringPairList			(struct TStringPairNode*) ;
static	void						vDestroyStringPairList		(struct TStringPairNode**) ;
static	struct TStringPairNode*		pFindStringPair				(struct TStringPairNode*, LPCTSTR) ;
static	void						vInsertStringPair			(struct TStringPairNode**, struct TStringPairNode*) ;

static	struct TStringPairNode*		pCreateDefaultBracketParenList	(void) ;
static	struct TStringPairNode*		pCreateDefaultKutoutenList		(int) ;

/*========================================================================
 *	global variables
 */
static	BOOL					_bKanaModeWhenOpen		= TRUE ;
static	BOOL					_bEcho					= TRUE ;
static	BOOL					_bCompositionAutoShift	= TRUE ;
static	BOOL					_bDeleteImpliesKakutei	= TRUE ;
static	BOOL					_bKakuteiEarly			= TRUE ;

static	int						_bDateAd				= FALSE ;
static	int						_iNumberStyle			= 0 ;

static	int						_iKutoutenType			= KUTOUTEN_TYPE_JP ;
static	struct TStringPairNode*	_plstKutoutens			= NULL ;

static	int						_iBracketParenType		= BRACKETPARENTP_NONE ;
static	struct TStringPairNode*	_plstBracketParens		= NULL ;
static	int						_iOkuriCharAlistType	= OKURICHARTP_NONE ;
static	struct TStringPairNode*	_plstOkuriCharAlist		= NULL ;

static	BOOL					_bExistUserDefinedBracketParen		= FALSE ;
static	BOOL					_bExistUserDefinedOkuriCharAlist	= FALSE ;
static	BOOL					_bExistUserDefinedKutoutenList		= FALSE ;

static	HICON					_hiconArrowUp			= NULL ;
static	HICON					_hiconArrowDown			= NULL ;

/*========================================================================
 *	public functions
 */
INT_PTR	CALLBACK
DlgGenericProc (
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgGeneric_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgGeneric_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgGeneric_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgGeneric_iOnInitDialog (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	static	struct {
		LPCTSTR	m_strTitle ;
		int		m_nValue ;
	}	_srKutoutenList []	= {
		{	TEXT ("�u�A�v�u�B�v�������l�Łu�C�v�u�D�v�Ɛؑ�"),	KUTOUTEN_TYPE_JP	},
		{	TEXT ("�u�C�v�u�D�v�������l�Łu�A�v�u�B�v�Ɛؑ�"),	KUTOUTEN_TYPE_EN	},
	} ;
	PROPSHEETPAGE*	pPropPage	= (PROPSHEETPAGE*) lParam ;
	HWND			hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pPropPage->lParam) ;

	dlgGeneric_bLoadRegistrySetting();

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_KUTOUTEN) ;
	if (hwndControl != NULL) {
		int		i ;
		LRESULT	nItem ;

		for (i = 0 ; i < ARRAYSIZE (_srKutoutenList) ; i ++) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) _srKutoutenList [i].m_strTitle) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) _srKutoutenList [i].m_nValue) ;
			}
		}
		if (_bExistUserDefinedKutoutenList) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) KUTOUTEN_TYPE_CUSTOM) ;
			}
		}
	}
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_BRACKETPAREN) ;
	if (hwndControl != NULL) {
		LRESULT	nItem ;
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("����")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) BRACKETPARENTP_NONE) ;
		}
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("�W��(�L��)")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) BRACKETPARENTP_DEFAULT) ;
		}
		if (_bExistUserDefinedBracketParen) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`(�L��)")) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) BRACKETPARENTP_USERDEFINED) ;
			}
		}
	}
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_OKURICHARALIST) ;
	if (hwndControl != NULL) {
		LRESULT	nItem ;
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("����")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) OKURICHARTP_NONE) ;
		}
		nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("�W��(�L��)")) ;
		if (nItem != CB_ERR) {
			(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) OKURICHARTP_DEFAULT) ;
		}
		if (_bExistUserDefinedOkuriCharAlist) {
			nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`(�L��)")) ;
			if (nItem != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) OKURICHARTP_USERDEFINED) ;
			}
		}
	}
	dlgGeneric_vSyncControls (hDlg) ;
	return	(INT_PTR) FALSE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgGeneric_iOnCommand (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_CHECK_KANA_MODE_WHEN_OPEN:
		_bKanaModeWhenOpen	= IsDlgButtonChecked (hDlg, IDC_CHECK_KANA_MODE_WHEN_OPEN) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_SKK_ECHO:
		_bEcho	= IsDlgButtonChecked (hDlg, IDC_CHECK_SKK_ECHO) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_COMPOSITION_AUTO_SHIFT:
		_bCompositionAutoShift	= IsDlgButtonChecked (hDlg, IDC_CHECK_COMPOSITION_AUTO_SHIFT) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_DELETE_IMPLIES_KAKUTEI:
		_bDeleteImpliesKakutei	= IsDlgButtonChecked (hDlg, IDC_CHECK_DELETE_IMPLIES_KAKUTEI) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_CHECK_KAKUTEI_EARLY:
		_bKakuteiEarly		= IsDlgButtonChecked (hDlg, IDC_CHECK_KAKUTEI_EARLY) == BST_CHECKED ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_RADIO_DATE_SEIREKI:
	case	IDC_RADIO_DATE_GENGOU:
		if (woControl != (IDC_RADIO_DATE_SEIREKI + _bDateAd)) {
			_bDateAd	= (woControl == IDC_RADIO_DATE_GENGOU) ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
		}
		CheckRadioButton (hDlg, IDC_RADIO_DATE_SEIREKI, IDC_RADIO_DATE_GENGOU, woControl) ;
		return	(INT_PTR) 0 ;
	case	IDC_RADIO_NUMBER_HANEI:
	case	IDC_RADIO_NUMBER_ZENEI:
	case	IDC_RADIO_NUMBER_KANSUJI:
		if (woControl != (_iNumberStyle + IDC_RADIO_NUMBER_HANEI)) {
			_iNumberStyle	= woControl - IDC_RADIO_NUMBER_HANEI ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
		}
		CheckRadioButton (hDlg, IDC_RADIO_NUMBER_HANEI, IDC_RADIO_NUMBER_KANSUJI, woControl) ;
		return	(INT_PTR) 0 ;
	case	IDC_COMBO_OKURICHARALIST:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			LRESULT	nCurSel ;
			int nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (_iOkuriCharAlistType != nData) {
					_iOkuriCharAlistType	= nData ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
		}
		return	(INT_PTR) 0 ;
	case	IDC_COMBO_BRACKETPAREN:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			LRESULT	nCurSel ;
			int		nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (_iBracketParenType != nData) {
					_iBracketParenType	= nData ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
		}
		return	(INT_PTR) 0 ;
	case	IDC_COMBO_KUTOUTEN:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			LRESULT	nCurSel ;
			int		nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (_iKutoutenType != nData) {
					_iKutoutenType	= nData ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
		}
		return	(INT_PTR) 0 ;
	case	IDC_BUTTON_EDIT_BRACKET:
		dlgGeneric_vEditBracket (hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_BUTTON_EDIT_KUTOUTEN:
		dlgGeneric_vEditKutouten (hDlg) ;
		return	(INT_PTR) 0 ;
	case	IDC_BUTTON_EDIT_OKURI_CHAR_ALIST:
		dlgGeneric_vEditOkuriCharAlist (hDlg) ;
		return	(INT_PTR) 0 ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
}

INT_PTR
dlgGeneric_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	LPNMHDR	pnmh		= (LPNMHDR) lParam ;

	if (pnmh == NULL)
		return	0 ;

	switch (pnmh->code) {
	case	PSN_APPLY:
		if (dlgGeneric_bSaveRegistrySetting())
			vUpdateTick () ;
		break ;
	case	PSN_RESET:
		{
			dlgGeneric_bLoadRegistrySetting();
			/* �X�V���ꂽ�ݒ�𔽉f����B*/
			dlgGeneric_vSyncControls (hDlg) ;
		}
		break ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgGeneric_vEditBracket (
	HWND			hDlg)
{
	HINSTANCE	hInst ;
	int			nResult ;
	struct TEditBracketParenListArg	arg ;

	// �u�����v�܂��́u�W��(�L��)�v�܂��̓��X�g���̂����݂��Ȃ��ꍇ�̂݃f�t�H���g�l���g�p����
	arg.m_plstBracketParen = (
		_iBracketParenType == BRACKETPARENTP_NONE ||
		_iBracketParenType == BRACKETPARENTP_DEFAULT ||
		_plstBracketParens == NULL) ?
		pCreateDefaultBracketParenList() : pCopyStringPairList(_plstBracketParens);

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_BRACKETLIST), hDlg, dlgEditBracketListProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		vDestroyStringPairList (&arg.m_plstBracketParen) ;
		return ;
	}
	/* ���[�U��`�ɕ\����؂�ւ���B*/
	if (! _bExistUserDefinedBracketParen) {
		HWND	hwndControl ;
		LRESULT	nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_BRACKETPAREN) ;
		if (hwndControl != NULL) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) BRACKETPARENTP_USERDEFINED) ;
			}
		}
		_bExistUserDefinedBracketParen	= TRUE ;
	}
	_iBracketParenType	= BRACKETPARENTP_USERDEFINED ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_BRACKETPAREN,	_iBracketParenType) ;

	vDestroyStringPairList (&_plstBracketParens) ;
	_plstBracketParens	= arg.m_plstBracketParen ;
	PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return ;
}

void
dlgGeneric_vSyncControls (
	HWND			hDlg)
{
	CheckDlgButton (hDlg, IDC_CHECK_KANA_MODE_WHEN_OPEN,	_bKanaModeWhenOpen?		BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_SKK_ECHO,				_bEcho?					BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_COMPOSITION_AUTO_SHIFT,	_bCompositionAutoShift?	BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_DELETE_IMPLIES_KAKUTEI,	_bDeleteImpliesKakutei?	BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_KAKUTEI_EARLY,			_bKakuteiEarly?			BST_CHECKED : BST_UNCHECKED) ;

	CheckRadioButton (hDlg, IDC_RADIO_DATE_SEIREKI, IDC_RADIO_DATE_GENGOU, _bDateAd? IDC_RADIO_DATE_GENGOU : IDC_RADIO_DATE_SEIREKI) ;
	CheckRadioButton (hDlg, IDC_RADIO_NUMBER_HANEI, IDC_RADIO_NUMBER_KANSUJI, IDC_RADIO_NUMBER_HANEI + _iNumberStyle) ;

	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_BRACKETPAREN,	_iBracketParenType) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_OKURICHARALIST,	_iOkuriCharAlistType) ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_KUTOUTEN,		_iKutoutenType) ;
	return ;
}

void
dlgGeneric_vEditKutouten (
	HWND			hDlg)
{
	HINSTANCE	hInst ;
	int			nResult ;
	struct TEditKutoutenListArg	arg ;

	// �uJP�v�܂��́uEN�v�܂��̓��X�g���̂����݂��Ȃ��ꍇ�̂݃f�t�H���g�l���g�p����
	arg.m_plstKutouten = (
		_iKutoutenType == KUTOUTEN_TYPE_JP ||
		_iKutoutenType == KUTOUTEN_TYPE_EN ||
		_plstKutoutens == NULL) ?
		pCreateDefaultKutoutenList(_iKutoutenType) : pCopyStringPairList(_plstKutoutens);

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_KUTOUTENLIST), hDlg, dlgEditKutoutenListProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		vDestroyStringPairList (&arg.m_plstKutouten) ;
		return ;
	}

	/* ������� custom type �ɂȂ�B*/
	vDestroyStringPairList (&_plstKutoutens) ;
	_plstKutoutens	= arg.m_plstKutouten ;
	_iKutoutenType	= KUTOUTEN_TYPE_CUSTOM ;

	/* ���[�U��`�ɕ\����؂�ւ���B*/
	if (! _bExistUserDefinedKutoutenList) {
		HWND	hwndControl ;
		LRESULT	nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_KUTOUTEN) ;
		if (hwndControl != NULL) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KUTOUTEN_TYPE_CUSTOM) ;
			}
		}
		_bExistUserDefinedKutoutenList	= TRUE ;
	}

	/* ComboBox �� Selection ��ύX���Ȃ���΁B*/
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_KUTOUTEN, _iKutoutenType) ;
	PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return ;
}

void
dlgGeneric_vEditOkuriCharAlist (
	HWND				hDlg)
{
	HINSTANCE						hInst ;
	int								nResult ;
	struct TEditOkuriCharAlistArg	arg ;

	// �u�����v�܂��́u�W��(�L��)�v�܂��̓��X�g���̂����݂��Ȃ��ꍇ�̂݃f�t�H���g�l���g�p����
	arg.m_plstOkuriCharPair = (
		_iOkuriCharAlistType == OKURICHARTP_NONE ||
		_iOkuriCharAlistType == OKURICHARTP_DEFAULT ||
		_plstOkuriCharAlist == NULL) ?
		NULL : pCopyStringPairList(_plstOkuriCharAlist);

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_OKURICHARALIST), hDlg, dlgEditOkuriCharAlistProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		vDestroyStringPairList (&arg.m_plstOkuriCharPair) ;
		return ;
	}
	/* ���[�U��`�ɕ\����؂�ւ���B*/
	if (! _bExistUserDefinedOkuriCharAlist) {
		HWND	hwndControl ;
		LRESULT	nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_OKURICHARALIST) ;
		if (hwndControl != NULL) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex != CB_ERR) {
				(void) SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) OKURICHARTP_USERDEFINED) ;
			}
		}
		_bExistUserDefinedOkuriCharAlist	= TRUE ;
	}
	_iOkuriCharAlistType	= OKURICHARTP_USERDEFINED ;
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_OKURICHARALIST,	_iOkuriCharAlistType) ;

	vDestroyStringPairList (&_plstOkuriCharAlist) ;
	_plstOkuriCharAlist	= arg.m_plstOkuriCharPair ;
	PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return ;
}

////////////////////////////////////////////////////////////////////

/// �Œ蒷�G���g������p�e�[�u��
static const struct {
	LPCTSTR info;
	DWORD* dest;
} _srGenericRegNumber[] = {
	{ REGINFO_KUTOUTENTYPE,			(DWORD*)&_iKutoutenType },
	{ REGINFO_AUTOINSERTPAREN,		(DWORD*)&_iBracketParenType },
	{ REGINFO_OKURICHARALISTTYPE,	(DWORD*)&_iOkuriCharAlistType },

	{ REGINFO_KANAMODEWHENOPEN,		(DWORD*)&_bKanaModeWhenOpen },
	{ REGINFO_ECHO,					(DWORD*)&_bEcho },
	{ REGINFO_COMPOSITIONAUTOSHIFT,	(DWORD*)&_bCompositionAutoShift },
	{ REGINFO_DELETEIMPLIESKAKUTEI,	(DWORD*)&_bDeleteImpliesKakutei },
	{ REGINFO_KAKUTEIEARLY,			(DWORD*)&_bKakuteiEarly },

	{ REGINFO_DATEAD,				(DWORD*)&_bDateAd },
	{ REGINFO_NUMBERSTYLE,			(DWORD*)&_iNumberStyle },
};

/// �ϒ��G���g������p�e�[�u��
static const struct {
	LPCTSTR info;
	struct TStringPairNode** node;
	BOOL* exist;
} _srGenericRegString[] = {
	{ REGINFO_KUTOUTENS,		&_plstKutoutens,		&_bExistUserDefinedKutoutenList },
	{ REGINFO_BRACKETPARENS ,	&_plstBracketParens,	&_bExistUserDefinedBracketParen },
	{ REGINFO_OKURICHARALIST,	&_plstOkuriCharAlist,	&_bExistUserDefinedOkuriCharAlist },
};

/// Generic�ݒ�̓ǂݍ���
/**
�Y�����郌�W�X�g���G���g��������Βl��ǂݍ��݁A�Ȃ��ꍇ�̓f�t�H���g�l��ݒ肷��B
�����I�ɃG���g�������݂���ꍇ�͓ǂ߂镔�������ǂݍ��ށB
*/
void dlgGeneric_bLoadRegistrySetting()
{
//	#include "../common/kutouten.h"
//	#include "../common/bracket.h"

	HKEY hSubKey;
	int i;

	// �f�t�H���g�l�ݒ�
	_iKutoutenType			= KUTOUTEN_TYPE_JP;
	_iBracketParenType		= BRACKETPARENTP_NONE;
	_iOkuriCharAlistType	= OKURICHARTP_NONE;

	_bKanaModeWhenOpen		= TRUE;
	_bEcho					= TRUE;
	_bCompositionAutoShift	= TRUE;
	_bDeleteImpliesKakutei	= TRUE;
	_bKakuteiEarly			= TRUE;

	_bDateAd				= FALSE;
	_iNumberStyle			= 0;

	vDestroyStringPairList(&_plstKutoutens);
	vDestroyStringPairList(&_plstBracketParens);
	vDestroyStringPairList(&_plstOkuriCharAlist);

	_plstKutoutens			= NULL;
	_plstBracketParens		= NULL;
	_plstOkuriCharAlist		= NULL;

	_bExistUserDefinedKutoutenList		= FALSE;
	_bExistUserDefinedBracketParen		= FALSE;
	_bExistUserDefinedOkuriCharAlist	= FALSE;

	if (RegOpenKeyEx(HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS)
		return;

	// �Œ蒷�G���g��
	for (i = 0; i < countof(_srGenericRegNumber); i++) {
		DWORD dwType, cbData = sizeof(DWORD);
		DWORD dwValue;
		LONG lResult = RegQueryValueEx(hSubKey, _srGenericRegNumber[i].info, NULL, &dwType, (BYTE*)&dwValue, &cbData);
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD) {
			ASSERT(sizeof(DWORD) == sizeof(int) && sizeof(DWORD) == sizeof(BOOL));
			*_srGenericRegNumber[i].dest = dwValue;	// BOOL�����̂܂܂ł����񂿂Ⴄ
		}
	}

	// �ϒ��G���g��
	for (i = 0; i < countof(_srGenericRegString); i++) {
		DWORD dwType, cbData = 0;
		LONG lResult = RegQueryValueEx(hSubKey, _srGenericRegString[i].info, NULL, &dwType, NULL, &cbData);
		if (lResult == ERROR_SUCCESS && dwType == REG_MULTI_SZ) {
			LPTSTR p = (LPTSTR)MALLOC(cbData);
			if (p == NULL) continue;
			RegQueryValueEx(hSubKey, _srGenericRegString[i].info, NULL, &dwType, (BYTE*)p, &cbData);
			struct TStringPairNode* pl = dlgGeneric_pDecodeStringPairList(p);
			if (pl) {
				vDestroyStringPairList(_srGenericRegString[i].node);
				*_srGenericRegString[i].node = pl;
				*_srGenericRegString[i].exist = TRUE;
				FREE(p);
			}
		}
	}

	RegCloseKey(hSubKey);

	// �ȉ��̏�����2�̃e�[�u���̍\����l����v���Ă��邱�Ƃ𗘗p���ċ��ʉ��ł��邪
	// �ǐ����ɒ[�ɒቺ���銄�ɂ͂قƂ�ǃT�C�Y�Z�k�̃����b�g���Ȃ������Ȃ̂ŕ��u

	// ��Ǔ_����
	if (!_bExistUserDefinedKutoutenList && (DWORD)_iKutoutenType >= KUTOUTEN_TYPE_CUSTOM)
		_iKutoutenType = KUTOUTEN_TYPE_JP;

	// ���ʒ���
	if (!_bExistUserDefinedBracketParen && (DWORD)_iBracketParenType >= BRACKETPARENTP_USERDEFINED)
		_iBracketParenType = BRACKETPARENTP_NONE;

	// ���蒲��
	if (!_bExistUserDefinedOkuriCharAlist && (DWORD)_iOkuriCharAlistType >= OKURICHARTP_USERDEFINED)
		_iOkuriCharAlistType = OKURICHARTP_NONE;
}

/// Generic�ݒ�̕ۑ�
/**
����̈ӌ����ő�����d���ăG���R�[�h�����ƃ�����������������W�X�g���������݂͈̔͊O�ōs�Ȃ��ł�p�ӂ������A���݂̓R�[�h�T�C�Y�팸�̂��ߕʂ̔ł��g�p���Ă���B

�������ݎ��s�����������ꍇ�A�����f����B
*/
BOOL dlgGeneric_bSaveRegistrySetting()
{
	int i;

#if 1	// �R�[�h�T�C�Y�D���
	HKEY hSubKey;
	if (!bCreateRegistryKey(REGPATH_GENERIC, FALSE, &hSubKey))
		return FALSE;

	// �Œ蒷�G���g��
	for (i = 0; i < countof(_srGenericRegNumber); i++) {
		ASSERT(sizeof(DWORD) == sizeof(int) && sizeof(DWORD) == sizeof(BOOL));
		if (RegSetValueEx(hSubKey, _srGenericRegNumber[i].info, 0, REG_DWORD, (BYTE*)_srGenericRegNumber[i].dest, sizeof(DWORD)) != ERROR_SUCCESS) {
			RegCloseKey(hSubKey);
			return FALSE;
		}
	}

	// �ϒ��G���g��
	for (i = 0; i < countof(_srGenericRegString); i++) {
		DWORD nBuf;
		LPTSTR pBuf = dlgGeneric_pEncodeStringPairList(*_srGenericRegString[i].node, (int*)&nBuf);
		if (*_srGenericRegString[i].exist && pBuf && nBuf)
			RegSetValueEx(hSubKey, _srGenericRegString[i].info, 0, REG_MULTI_SZ, (BYTE*)pBuf, sizeof(TCHAR) * nBuf);
		FREE(pBuf);
	}

	RegCloseKey(hSubKey);
#else	// ����̈ӌ����d��
	// ����R�����g���
	/*	���W�X�g���̃L�[���J���Ă�����Ԃ��ŏ��ɂ������c���̕��������̂��낤�B
	*/
	// ���̂������Ɏ^������b�I

	// �G���R�[�h�������ɍs�Ȃ�
	LPTSTR pBuf[countof(_srGenericRegString)];
	DWORD nBuf[countof(_srGenericRegString)];
	for (i = 0; i < countof(_srGenericRegString); i++) {
		pBuf[i] = dlgGeneric_pEncodeStringPairList(*_srGenericRegString[i].node, &nBuf[i]);
	}

	HKEY hSubKey;
	if (!bCreateRegistryKey(REGPATH_GENERIC, FALSE, &hSubKey))
		return FALSE;

	// �Œ蒷�G���g��
	for (i = 0; i < countof(_srGenericRegNumber); i++) {
		ASSERT(sizeof(DWORD) == sizeof(int) && sizeof(DWORD) == sizeof(BOOL));
		if (RegSetValueEx(hSubKey, _srGenericRegNumber[i].info, 0, REG_DWORD, (BYTE*)_srGenericRegNumber[i].dest, sizeof(DWORD)) != ERROR_SUCCESS) {
			RegCloseKey(hSubKey);
			return FALSE;
		}
	}

	// �ϒ��G���g�� @todo �e�[�u��3�퓯���i�s�Ȃ̂ō\���̉����Ă܂Ƃ߂�
	for (i = 0; i < countof(_srGenericRegString); i++) {
		if (*_srGenericRegString[i].exist && pBuf[i] && nBuf[i])
			RegSetValueEx(hSubKey, _srGenericRegString[i].info, 0, REG_MULTI_SZ, (BYTE*)pBuf[i], sizeof(TCHAR) * nBuf[i]);
	}

	RegCloseKey(hSubKey);

	// ���������
	for (i = 0; i < countof(_srGenericRegString); i++) FREE(pBuf[i]);
#endif

	return TRUE;
}

/// ���W�X�g���Ɋi�[���ꂽMULTI_SZ�𕶎���y�A�Ƃ��Ď擾
/**
����A\\0����B\\0\0
����C\\0����D\\0\0\0
�Ƃ���'\\' '0'�̃G�X�P�[�v�V�[�P���X�ŋ�؂�ꂽMULTI_SZ������
�s�����O�̃Z�p���[�^�͏ȗ��\(������)

�����ł̒ǉ��@�\�Ƃ��Ĉȉ��̃p�^�[�������e��1�����Z�k�\�Ƃ���
����A,����B\0
����C,����D\0\0

�s���ȃf�[�^��ǂ݂��񂾏ꍇ�͏����𒆒f����B����ɓǂݍ��߂������͏������Ɏc���B
*/
struct TStringPairNode* dlgGeneric_pDecodeStringPairList(LPCTSTR pwEncodedString)
{
	struct TStringPairNode*		plstStringPair ;
	struct TStringPairNode*		pNode ;
	LPCTSTR	pwSrc ;
	TCHAR	bufLeft [SIZE_LBRACKET], bufRight [SIZE_RBRACKET] ;

	plstStringPair	= NULL ;
	pwSrc			= pwEncodedString ;
	while (*pwSrc) {
		if (bParseBSEncodedString(&pwSrc, bufLeft, countof(bufLeft))) {
			// vDestroyStringPairList (&plstStringPair) ;
			break ;
		}
		// bufLeft [ARRAYSIZE (bufLeft) - 1]	= TEXT ('\0') ;

		if (!bParseBSEncodedString(&pwSrc, bufRight, countof(bufRight))) {
			// vDestroyStringPairList (&plstStringPair) ;
			break ;
		}
		// bufRight [ARRAYSIZE (bufRight) - 1]	= TEXT ('\0') ;

		pNode	= pCreateStringPair (bufLeft, bufRight) ;
		if (pNode == NULL) {
			// vDestroyStringPairList (&plstStringPair) ;
			break ;
		}
		vInsertStringPair (&plstStringPair, pNode) ;

		// MULTI_SZ�s���`�F�b�N�ς݂̂��ߕs�v
		// if (*pwSrc) break;
		pwSrc	++ ;
	}
	return	plstStringPair ;
}

/// ������y�A��MULTI_SZ�ɃG���R�[�h
LPTSTR dlgGeneric_pEncodeStringPairList(
	struct TStringPairNode*	plstStringPair,
	int*					pnSize)
{
	struct TStringPairNode*	pNode ;
	int						nSize ;

	nSize = 0;
	pNode = plstStringPair;
	while (pNode) {
		nSize +=
			iCountBSEncodedString(pNode->m_bufLeft) +
			iCountBSEncodedString(pNode->m_bufRight) +
			2;	// SEPCHAR + NUL
		pNode = pNode->m_pNext;
	}
	nSize++;	// NUL

	LPTSTR pwData = (LPTSTR)MALLOC(sizeof(TCHAR) * nSize);
	if (pwData) {
		LPTSTR pwDest = pwData;
		pNode = plstStringPair;
		while (pNode) {
			pwDest = iBSEncodeString(pwDest, pNode->m_bufLeft);
			*pwDest++ = SEPCHAR;
			pwDest = iBSEncodeString(pwDest, pNode->m_bufRight);
			*pwDest++ = TEXT('\0');
			pNode = pNode->m_pNext;
		}
		*pwDest = TEXT('\0');
	} else {
		nSize = 0;
	}
	if (pnSize) *pnSize = nSize;
	return pwData;
}

/*========================================================================
 *	���ʂ̃y�A���X�g����B
 */
struct TStringPairNode*
pCreateStringPair (
	LPCTSTR		strLeftt,
	LPCTSTR		strRight)
{
	struct TStringPairNode*	pNode ;

	if (strLeftt == NULL)
		return	NULL ;
	strRight	= (strRight == NULL)? TEXT ("") : strRight ;

	pNode	= (struct TStringPairNode*) MALLOC (sizeof (struct TStringPairNode)) ;
	if (pNode == NULL)
		return	NULL ;

	lstrcpyn (pNode->m_bufLeft,  strLeftt, ARRAYSIZE (pNode->m_bufLeft)) ;
	lstrcpyn (pNode->m_bufRight, strRight, ARRAYSIZE (pNode->m_bufRight)) ;
	pNode->m_pNext	= pNode->m_pPrev	= NULL ;
	return	pNode ;
}

/// �f�t�H���g�̊��ʃ��X�g�𐶐�
struct TStringPairNode* pCreateDefaultBracketParenList()
{
	#include "../common/bracket.h"

	return dlgGeneric_pDecodeStringPairList(_srDefaultBracketParen);
}

struct TStringPairNode*
pCopyStringPairList (
	struct TStringPairNode*	plstStringPair)
{
	struct TStringPairNode*	pSrc ;
	struct TStringPairNode*	pNode ;
	struct TStringPairNode*	pNewTop ;
	struct TStringPairNode*	pPrevNode ;

	if (plstStringPair == NULL)
		return	NULL ;

	pSrc	= plstStringPair ;
	pNewTop	= pCreateStringPair (pSrc->m_bufLeft, pSrc->m_bufRight) ;
	if (pNewTop == NULL)
		return	NULL ;
	pSrc		= pSrc->m_pNext ;
	pPrevNode	= pNewTop ;
	while (pSrc != NULL) {
		pNode	= pCreateStringPair (pSrc->m_bufLeft, pSrc->m_bufRight) ;
		if (pNode == NULL) {
			vDestroyStringPairList (&pNewTop) ;
			return	NULL ;
		}
		pPrevNode->m_pNext	= pNode ;
		pNode->m_pPrev		= pPrevNode ;
		pPrevNode			= pNode ;
		pSrc	= pSrc->m_pNext ;
	}
	return	pNewTop ;
}

void
vDestroyStringPairList (
	struct TStringPairNode**	pplstStringPair)
{
	struct TStringPairNode*	pNextNode ;
	struct TStringPairNode*	pNode ;

	if (pplstStringPair == NULL)
		return ;

	pNode	= *pplstStringPair ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		FREE (pNode) ;
		pNode		= pNextNode ;
	}
	*pplstStringPair	= NULL ;
	return ;
}

struct TStringPairNode*
pFindStringPair  (
	struct TStringPairNode*		plstStringPair,
	LPCTSTR						strLBracket)
{
	struct TStringPairNode*	pNode ;

	if (strLBracket == NULL || plstStringPair == NULL)
		return	NULL ;

	pNode	= plstStringPair ;
	while (pNode != NULL) {
		if (! lstrcmp (pNode->m_bufLeft, strLBracket))
			return	pNode ;
		pNode	= pNode->m_pNext ;
	}
	return	NULL ;
}

void
vInsertStringPair (
	struct TStringPairNode**	pplstStringPair,
	struct TStringPairNode*		pNewNode)
{
	struct TStringPairNode*		pTop ;
	struct TStringPairNode*		pNode ;

	if (pplstStringPair == NULL || pNewNode == NULL)
		return ;

	pTop	= *pplstStringPair ;
	if (pTop != NULL) {
		pNode		= pTop ;
		while (pNode->m_pNext != NULL && pNode != pNewNode) {
			pNode	= pNode->m_pNext ;
		}
		if (pNode == pNewNode)
			return ;
		pNode->m_pNext		= pNewNode ;
		pNewNode->m_pPrev	= pNode ;
		pNewNode->m_pNext	= NULL ;
	} else {
		*pplstStringPair	= pNewNode ;
		pNewNode->m_pPrev	= pNewNode->m_pNext	= NULL ;
	}
	return ;
}

/// �f�t�H���g�̋�Ǔ_���X�g�𐶐�
struct TStringPairNode* pCreateDefaultKutoutenList(int iKutoutenType)
{
	#include "../common/kutouten.h"

	return dlgGeneric_pDecodeStringPairList(iKutoutenType == KUTOUTEN_TYPE_JP ? _srDefaultKutoutenJP : _srDefaultKutoutenEN);
}

/*========================================================================
 *	for IDD_EDIT_BRACKETLIST
 */
static	INT_PTR		dlgEditBracketList_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgEditBracketList_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	BOOL		dlgEditBracketList_bEditBracket		(HWND, int) ;
static	BOOL		dlgEditBracketList_bRemoveBracket	(HWND) ;
static	INT_PTR		CALLBACK	dlgEditBracketProc		(HWND, UINT, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
dlgEditBracketListProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		return	dlgEditBracketList_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditBracketList_iOnCommand (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditBracketList_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditBracketParenListArg*	pArg ;
	HWND	hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	pArg	= (struct TEditBracketParenListArg*) lParam ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_BRACKET) ;
	if (hwndControl != NULL) {
		LV_COLUMN	lvColumn ;

		memset (&lvColumn, 0, sizeof (lvColumn)) ;

		ListView_DeleteAllItems (hwndControl) ;
		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;

		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.cx			= 48 ;
		lvColumn.pszText	= TEXT ("�J����") ;
		ListView_InsertColumn (hwndControl, 0, &lvColumn) ;
		lvColumn.pszText	= TEXT ("������") ;
		ListView_InsertColumn (hwndControl, 1, &lvColumn) ;
	}
	if (pArg != NULL && hwndControl != NULL) {
		LVITEM					lvi ;
		struct TStringPairNode*	pNode ;
		int						nCount, nItem ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
		nCount	= 0 ;
		pNode	= pArg->m_plstBracketParen ;
		while (pNode != NULL) {
			lvi.iItem		= nCount ;
			lvi.iSubItem	= 0 ;
			lvi.pszText		= pNode->m_bufLeft ;
			lvi.lParam		= (LPARAM) pNode ;
			nItem	= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufRight) ;
				nCount	++ ;
			}
			pNode	= pNode->m_pNext ;
		}
	}
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditBracketList_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	/*WORD	woNotification	= HIWORD (wParam) ;*/

	switch (woControl) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		dlgEditBracketList_bEditBracket (hDlg, woControl) ;
		break ;
	case	IDC_BUTTON_DELETE:
		dlgEditBracketList_bRemoveBracket (hDlg) ;
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

/** @todo
���݂̖��_�B�Č����@�B
0: �폜���ł��Ȃ��BIDC_BUTTON_DELETE �����蓖�Ă��Ă��Ȃ��������߁B�����ς݁B
1: �����̊��ʂ�ҏW����Ɖ�ʂ��X�V����Ȃ��B��������ł͕ω����Ă���B
2: �V�K�ǉ��セ�̊��ʂ��폜����ƍ폜���j���[���o�Ȃ��B
*/

BOOL
dlgEditBracketList_bEditBracket (
	HWND			hDlg,
	int				nControlId)
{
	struct TEditBracketParenListArg*	pArg ;
	struct TStringPairNode		arg ;
	struct TStringPairNode*		pNode			= NULL ;
	struct TStringPairNode*		pNodeOverride	= NULL ;
	HWND		hwndControl ;
	HINSTANCE	hInst ;

	pArg		= (struct TEditBracketParenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hInst		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_BRACKET) ;
	if (hwndControl == NULL)
		return	FALSE ;

	memset (&arg, 0, sizeof (arg)) ;
	if (nControlId == IDC_BUTTON_EDIT) {
		int		nCurSel ;

		nCurSel	= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel != -1) {
			LVITEM	lvi ;
			memset (&lvi, 0, sizeof (lvi)) ;
			lvi.iItem		= nCurSel ;
			lvi.iSubItem	= 0 ;
			lvi.mask		= LVIF_PARAM ;
			if (ListView_GetItem (hwndControl, &lvi)) {
				pNode	= (struct TStringPairNode*) lvi.lParam ;

				lstrcpyn (arg.m_bufLeft,  pNode->m_bufLeft,  ARRAYSIZE (arg.m_bufLeft)) ;
				lstrcpyn (arg.m_bufRight, pNode->m_bufRight, ARRAYSIZE (arg.m_bufRight)) ;
			}
		}
	}
	if (DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_BRACKET), hDlg, dlgEditBracketProc, (LPARAM) &arg) != IDOK)
		return	TRUE ;
	if (arg.m_bufLeft [0] == TEXT ('\0')) {
		(void) MessageBox (hDlg, TEXT ("���ʂ��w�肳��Ă��܂���B"), TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
		return	TRUE ;
	}

	/*	�ǉ��̏ꍇ�͉������Ȃ��Ă��ǂ����A�u�������̏ꍇ�ɂ� MessageBox �ŋ������߂�B�����L�[�� LBRACKET */
	pNodeOverride	= pFindStringPair  (pArg->m_plstBracketParen, arg.m_bufLeft) ;
	if (pNodeOverride != NULL) {
		/* �����ɓ������Ƃ������Ƃ́ALBRACKET �Ɋ��ɓ���������������� node �����݂���Ƃ������ƁB*/
		if (pNodeOverride != pNode) {
			TCHAR	bufText [256] ;
			int		n ;
			n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���Ɋ���``%s''�ɂ͕�����``%s''���Ή��t�����Ă��܂��B������``%s''�Œu�������܂����H"), pNodeOverride->m_bufLeft, pNodeOverride->m_bufRight, arg.m_bufRight) ;
			if (MessageBox (hDlg, bufText, TEXT ("�x��"), MB_ICONWARNING | MB_OKCANCEL) != IDOK)
				return	TRUE ;
			lstrcpyn (pNodeOverride->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNodeOverride->m_bufRight)) ;
		} else {
			lstrcpyn (pNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNode->m_bufRight)) ;
		}
		/* �\���� update ����B*/
	} else {
		/* pNode != NULL �Ȃ�ύX�B�ύX�Ƃ������Ƃł���΁A�ȑO�̃m�[�h��u�������Ȃ���΁B*/
		if (pNode != NULL) {
			lstrcpyn (pNode->m_bufLeft,  arg.m_bufLeft,  ARRAYSIZE (pNode->m_bufLeft)) ;
			lstrcpyn (pNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNode->m_bufRight)) ;
		} else {
			struct TStringPairNode*	pNewNode ;

			/* �������̂��Ȃ� => �ǉ�����B*/
			pNewNode	= pCreateStringPair (arg.m_bufLeft, arg.m_bufRight) ;
			if (pNewNode != NULL) {
				LVITEM	lvi ;
				int		nItem ;

				vInsertStringPair (&pArg->m_plstBracketParen, pNewNode) ;

				/* ListView �ɒǉ��B*/
				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.mask		= LVIF_TEXT | LVIF_PARAM ;
				lvi.iItem		= ListView_GetItemCount (hwndControl) ;
				lvi.iSubItem	= 0 ;
				lvi.pszText		= pNewNode->m_bufLeft ;
				nItem			= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					ListView_SetItemText (hwndControl, nItem, 1, pNewNode->m_bufRight) ;
				}
			}
		}
	}
	return	TRUE ;
}

BOOL
dlgEditBracketList_bRemoveBracket (
	HWND			hDlg)
{
	struct TEditBracketParenListArg*	pArg ;
	int		nCurSel, n ;
	LVITEM	lvi ;
	struct TStringPairNode*	pNode ;
	struct TStringPairNode*	pPrevNode ;
	struct TStringPairNode*	pNextNode ;
	HWND	hwndControl ;
	TCHAR	bufText [256] ;

	pArg		= (struct TEditBracketParenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_BRACKET) ;
	if (hwndControl == NULL)
		return	FALSE ;

	nCurSel	= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1)
		return	FALSE ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	lvi.mask		= LVIF_PARAM ;
	if (! ListView_GetItem (hwndControl, &lvi))
		return	FALSE ;
	pNode		= (struct TStringPairNode*) lvi.lParam ;
	if (pNode == NULL)
		return	FALSE ;

	n			= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("``%s''��``%s''�̃y�A���폜���܂��B��낵���ł����H"), pNode->m_bufLeft, pNode->m_bufRight) ;
	bufText [n]	= TEXT ('\0') ;
	if (MessageBox (hDlg, bufText, TEXT ("���ʁA�����ʂ̍폜�m�F"), MB_ICONQUESTION | MB_OKCANCEL) != IDOK)
		return	TRUE ;

	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext	= pNextNode ;
	} else {
		pArg->m_plstBracketParen	= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pPrevNode ;
	}
	FREE (pNode) ;

	ListView_DeleteItem (hwndControl, nCurSel) ;
	return	TRUE ;
}

/*========================================================================
 *	for IDD_EDIT_BRACKET
 */
INT_PTR	CALLBACK
dlgEditBracketProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		{
			struct TStringPairNode*	pArg	= (struct TStringPairNode*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pArg) ;

			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_LBRACKET) ;
			if (hwndControl != NULL)
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufLeft), (LPARAM) 0) ;
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_RBRACKET) ;
			if (hwndControl != NULL)
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufRight), (LPARAM) 0) ;
			if (pArg != NULL) {
				SetDlgItemText (hDlg, IDC_EDIT_LBRACKET, pArg->m_bufLeft) ;
				SetDlgItemText (hDlg, IDC_EDIT_RBRACKET, pArg->m_bufRight) ;
			}
		}
		return	(INT_PTR) TRUE ;

	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			/*WORD	woNotification	= HIWORD (wParam) ;*/
			switch (woControl) {
			case	IDOK:
				{
					struct TStringPairNode*	pArg ;

					pArg	= (struct TStringPairNode*) GetWindowLongPtr (hDlg, DWLP_USER) ;
					if (pArg != NULL) {
						GetDlgItemText (hDlg, IDC_EDIT_LBRACKET, pArg->m_bufLeft, ARRAYSIZE (pArg->m_bufLeft)) ;
						GetDlgItemText (hDlg, IDC_EDIT_RBRACKET, pArg->m_bufRight, ARRAYSIZE (pArg->m_bufRight)) ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				break ;
			default:
				break ;
			}
		}
		return	(INT_PTR) 1 ;

	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*========================================================================
 *	for IDD_EDIT_KUTOUTENLIST
 */
static	INT_PTR		dlgEditKutoutenList_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgEditKutoutenList_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgEditKutoutenList_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	BOOL		dlgEditKutoutenList_bEditKutouten	(HWND, int) ;
static	BOOL		dlgEditKutoutenList_bChangeKutoutenOrder	(HWND, BOOL) ;
static	BOOL		dlgEditKutoutenList_bRemoveKutouten	(HWND) ;
static	void		dlgEditKutoutenList_vUpdateKutoutenItem	(HWND, int, struct TStringPairNode*) ;
static	INT_PTR	CALLBACK	dlgEditKutoutenProc			(HWND, UINT, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
dlgEditKutoutenListProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		return	dlgEditKutoutenList_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditKutoutenList_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditKutoutenList_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditKutoutenList_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditKutoutenListArg*	pArg ;
	HINSTANCE		hInst ;
	HWND			hwndControl, hwndButton ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	pArg		= (struct TEditKutoutenListArg*) lParam ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl != NULL) {
		LV_COLUMN			lvColumn;
		static	LPTSTR		rpText []	= { TEXT ("����"), TEXT ("�_�E�Ǔ_"), TEXT ("�ہE��_") } ;
		int					i ;

		ListView_DeleteAllItems (hwndControl) ;
		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;
		memset (&lvColumn, 0, sizeof (lvColumn)) ;
		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		for (i = 0 ; i < ARRAYSIZE (rpText) ; i ++) {
			lvColumn.pszText	= rpText [i] ;
			lvColumn.cx			= i ? 58 : 48 ;
			ListView_InsertColumn (hwndControl, i, &lvColumn) ;
		}
	}
	if (pArg != NULL && hwndControl != NULL) {
		struct TStringPairNode*	pNode	= NULL ;
		LVITEM		lvi ;
		int			nItem, nCount ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM ;
		nCount		= 0 ;
		pNode		= pArg->m_plstKutouten ;
		while (pNode != NULL) {
			lvi.iItem		= nCount ;
			lvi.iSubItem	= 0 ;
			lvi.lParam		= (LPARAM) pNode ;
			nItem			= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				TCHAR	bufText [16] ;
				int		n ;
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d:"), nCount) ;
				bufText [n]	= TEXT ('\0') ;
				ListView_SetItemText (hwndControl, nItem, 0, bufText) ;
				ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufLeft) ;
				ListView_SetItemText (hwndControl, nItem, 2, pNode->m_bufRight) ;
			}
			nCount	++ ;
			pNode	= pNode->m_pNext ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWUP) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWUP), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowUp		= hIcon ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWDOWN) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWDOWN), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowDown	= hIcon ;
		}
	}
#if 1
	EnableDlgItem (hDlg, IDC_BUTTON_EDIT,		FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_DELETE,		FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,	FALSE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,	FALSE) ;
#endif
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditKutoutenList_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	/*WORD	woNotification	= HIWORD (wParam) ;*/

	switch (woControl) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		dlgEditKutoutenList_bEditKutouten (hDlg, woControl) ;
		break ;

	case	IDC_BUTTON_DELETE:
		dlgEditKutoutenList_bRemoveKutouten (hDlg) ;
		break ;
	case	IDC_BUTTON_ARROWUP:
	case	IDC_BUTTON_ARROWDOWN:
		dlgEditKutoutenList_bChangeKutoutenOrder (hDlg, woControl == IDC_BUTTON_ARROWUP) ;
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditKutoutenList_iOnNotify (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_KUTOUTEN:
		{
			switch (pNMHDR->code) {
			case	NM_SETFOCUS:
			case	NM_CLICK:
			case	NM_RCLICK:
			case	LVN_ITEMCHANGED:
				{
					HWND	hwndControl ;
					int		nCurSel ;

					hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
					if (hwndControl == NULL)
						break ;
					nCurSel	= ListView_GetSelectionMark (hwndControl) ;
					EnableDlgItem (hDlg, IDC_BUTTON_EDIT,		(nCurSel != -1)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_DELETE,		(nCurSel != -1)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,	(nCurSel > 0)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,	(0 <= nCurSel && nCurSel < ListView_GetItemCount (hwndControl)-1)) ;
				}
				if (pNMHDR->code == NM_RCLICK) {
					/* �ǉ��A�ύX�A�폜�� Context ���j���[�̕\���B*/
					static struct TMENUITEM 	rmi []	= {
						{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ǉ�"), IDC_BUTTON_ADD, },
						{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ύX"), IDC_BUTTON_EDIT, },
						{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�폜"), IDC_BUTTON_DELETE, },
					} ;
					/*NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;*/
					int				iCode ;

					iCode	= iPopupMenu (hDlg, rmi, ARRAYSIZE (rmi)) ;
					switch (iCode) {
					case	IDC_BUTTON_ADD:
					case	IDC_BUTTON_EDIT:
						dlgEditKutoutenList_bEditKutouten (hDlg, iCode) ;
						break ;
					case	IDC_BUTTON_DELETE:
						dlgEditKutoutenList_bRemoveKutouten (hDlg) ;
						break ;
					default:
						break ;
					}
				}
				break ;
			case	NM_KILLFOCUS:
			case	NM_DBLCLK:
				break ;
			default:
				break ;
			}
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 0 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
dlgEditKutoutenList_bEditKutouten (
	HWND			hDlg,
	int				nControlId)
{
	struct TEditKutoutenListArg*	pArg ;
	struct TStringPairNode	arg ;
	struct TStringPairNode*	pNode	= NULL ;
	HINSTANCE	hInst ;
	HWND		hwndControl ;
	int			nResult, nCurSel ;

	hInst		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pArg		= (struct TEditKutoutenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;

	nCurSel		= -1 ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl == NULL)
		return	FALSE ;

	memset (&arg, 0, sizeof (arg)) ;
	if (nControlId == IDC_BUTTON_EDIT) {
		LVITEM	lvi ;

		nCurSel	= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel != -1) {
			memset (&lvi, 0, sizeof (lvi)) ;
			lvi.iItem		= nCurSel ;
			lvi.iSubItem	= 0 ;
			lvi.mask		= LVIF_PARAM ;
			if (ListView_GetItem (hwndControl, &lvi)) {
				pNode	= (struct TStringPairNode*) lvi.lParam ;
				if (pNode != NULL) {
					lstrcpyn (arg.m_bufLeft,  pNode->m_bufLeft,  ARRAYSIZE (arg.m_bufLeft)) ;
					lstrcpyn (arg.m_bufRight, pNode->m_bufRight, ARRAYSIZE (arg.m_bufRight)) ;
				}
			}
		}
	}
	nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_KUTOUTEN), hDlg, dlgEditKutoutenProc, (LPARAM) &arg) ;
	if (nResult != IDOK)
		return	TRUE ;

	/* �ҏW�c�B*/
	if (pNode != NULL) {
		lstrcpyn (pNode->m_bufLeft,  arg.m_bufLeft,  ARRAYSIZE (pNode->m_bufLeft)) ;
		lstrcpyn (pNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pNode->m_bufRight)) ;
		/* �\�����X�V����B*/
		dlgEditKutoutenList_vUpdateKutoutenItem (hwndControl, nCurSel, pNode) ;
	} else {
		struct TStringPairNode*	pNewNode ;
		LVITEM	lvi ;
		int		nItem ;

		/* �ǉ��B*/
		pNewNode	= pCreateStringPair (arg.m_bufLeft, arg.m_bufRight) ;
		if (pNewNode == NULL)
			return	FALSE ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask		= LVIF_PARAM ;
		lvi.iItem		= ListView_GetItemCount (hwndControl) ;
		lvi.iSubItem	= 0 ;
		lvi.lParam		= (LPARAM) pNewNode ;
		nItem		= ListView_InsertItem (hwndControl, &lvi) ;
		if (nItem == -1) {
			FREE (pNewNode) ;
			return	FALSE ;
		}
		vInsertStringPair (&pArg->m_plstKutouten, pNewNode) ;
		dlgEditKutoutenList_vUpdateKutoutenItem (hwndControl, nItem, pNewNode) ;
	}
	return	TRUE ;
}

BOOL
dlgEditKutoutenList_bChangeKutoutenOrder (
	HWND			hDlg,
	BOOL			bUp)
{
	struct TEditKutoutenListArg*	pArg ;
	HWND	hwndControl ;
	LVITEM	lvi ;
	int		nCurSel, nPrevItem, nItem ;
	struct TStringPairNode*	pPrevNode ;
	struct TStringPairNode*	pNode ;

	pArg		= (struct TEditKutoutenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl == NULL)
		return	FALSE ;
	nCurSel	= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1)
		return	FALSE ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	lvi.mask		= LVIF_PARAM ;
	if (! ListView_GetItem (hwndControl, &lvi))
		return	FALSE ;
	pNode			= (struct TStringPairNode*) lvi.lParam ;

	if (bUp) {
		pPrevNode	= pNode->m_pPrev ;
		if (pPrevNode == NULL)
			return	FALSE ;
		nPrevItem	= nCurSel - 1 ;
		nItem		= nCurSel ;
	} else {
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
		if (pNode == NULL)
			return	FALSE ;
		nPrevItem	= nCurSel ;
		nItem		= nCurSel + 1 ;
	}
	pNode->m_pPrev				= pPrevNode->m_pPrev ;
	if (pPrevNode->m_pPrev != NULL) {
		pPrevNode->m_pPrev->m_pNext	= pNode ;
	} else {
		/* ���X�g�̐擪�̌����B*/
		pArg->m_plstKutouten	= pNode ;
	}

	pPrevNode->m_pNext			= pNode->m_pNext ;
	if (pNode->m_pNext != NULL)
		pNode->m_pNext->m_pPrev		= pPrevNode ;

	pNode->m_pNext				= pPrevNode ;
	pPrevNode->m_pPrev			= pNode ;

	/* ListView �̍X�V�B*/
	lvi.mask		= LVIF_PARAM | LVIF_STATE ;
	lvi.iItem		= nItem ;
	lvi.lParam		= (LPARAM) pPrevNode ;
	lvi.state		= bUp? 0 : LVIS_SELECTED ;
	lvi.stateMask	= LVIS_SELECTED ;
	ListView_SetItem (hwndControl, &lvi) ;
	ListView_SetItemText (hwndControl, nItem, 1, pPrevNode->m_bufLeft) ;
	ListView_SetItemText (hwndControl, nItem, 2, pPrevNode->m_bufRight) ;
	lvi.iItem		= nPrevItem ;
	lvi.lParam		= (LPARAM) pNode ;
	lvi.state		= bUp? LVIS_SELECTED : 0 ;
	lvi.stateMask	= LVIS_SELECTED ;
	ListView_SetItem (hwndControl, &lvi) ;
	ListView_SetItemText (hwndControl, nPrevItem, 1, pNode->m_bufLeft) ;
	ListView_SetItemText (hwndControl, nPrevItem, 2, pNode->m_bufRight) ;

	nCurSel			= bUp? nPrevItem : nItem ;
	ListView_SetSelectionMark (hwndControl, nCurSel) ;
	ListView_Update (hwndControl, nPrevItem) ;
	ListView_Update (hwndControl, nItem) ;

	EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,	(nCurSel > 0)) ;
	EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,	(0 <= nCurSel && nCurSel < ListView_GetItemCount (hwndControl)-1)) ;
	return	TRUE ;
}

BOOL
dlgEditKutoutenList_bRemoveKutouten	(
	HWND			hDlg)
{
	struct TEditKutoutenListArg*	pArg ;
	HWND	hwndControl ;
	TCHAR	bufText [256] ;
	int		nCurSel, n ;
	LVITEM	lvi ;
	struct TStringPairNode*	pNode ;
	struct TStringPairNode*	pNextNode ;
	struct TStringPairNode*	pPrevNode ;

	pArg		= (struct TEditKutoutenListArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	FALSE ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KUTOUTEN) ;
	if (hwndControl == NULL)
		return	FALSE ;
	nCurSel	= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1)
		return	FALSE ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	lvi.mask		= LVIF_PARAM ;
	if (! ListView_GetItem (hwndControl, &lvi))
		return	FALSE ;
	pNode			= (struct TStringPairNode*) lvi.lParam ;
	if (pNode == NULL)
		return	FALSE ;
	n				= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("�Ǔ_�u%s�v�Ƌ�_�u%s�v���폜���܂��B��낵���ł����H"), pNode->m_bufLeft, pNode->m_bufRight) ;
	bufText [n]		= TEXT ('\0') ;
	if (MessageBox (hDlg, bufText, TEXT ("��Ǔ_�̍폜�m�F"), MB_ICONQUESTION | MB_OKCANCEL) != IDOK)
		return	TRUE ;

	pPrevNode		= pNode->m_pPrev ;
	pNextNode		= pNode->m_pNext ;
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext	= pNextNode ;
	} else {
		pArg->m_plstKutouten	= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pPrevNode ;
	}
	FREE (pNode) ;

	ListView_DeleteItem (hwndControl, nCurSel) ;

	/*	��Ǔ_�̔ԍ�[%d:]��ύX����B*/
	while (nCurSel < ListView_GetItemCount (hwndControl)) {
		lvi.iItem		= nCurSel ;
		lvi.iSubItem	= 0 ;
		lvi.mask		= LVIF_PARAM ;
		if (! ListView_GetItem (hwndControl, &lvi))
			break ;
		pNode	= (struct TStringPairNode*) lvi.lParam ;
		if (pNode != NULL)
			dlgEditKutoutenList_vUpdateKutoutenItem (hwndControl, nCurSel, pNode) ;
		nCurSel	++ ;
	}
	return	TRUE ;
}

void
dlgEditKutoutenList_vUpdateKutoutenItem (
	HWND					hwndControl,
	int						nItem,
	struct TStringPairNode*	pNode)
{
	TCHAR	bufText [16] ;
	int		n ;

	if (hwndControl == NULL || ! IsWindow (hwndControl) || pNode == NULL)
		return ;

	n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%d:"), nItem) ;
	bufText [n]	= TEXT ('\0') ;
	ListView_SetItemText (hwndControl, nItem, 0, bufText) ;
	ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufLeft) ;
	ListView_SetItemText (hwndControl, nItem, 2, pNode->m_bufRight) ;
	return ;
}

INT_PTR	CALLBACK
dlgEditKutoutenProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		{
			struct TStringPairNode*	pArg	= (struct TStringPairNode*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_TOUTEN) ;
			if (hwndControl != NULL)
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufLeft), 0) ;
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_KUTEN) ;
			if (hwndControl != NULL)
				SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufRight), 0) ;
			if (pArg != NULL) {
				SetDlgItemText (hDlg, IDC_EDIT_TOUTEN, pArg->m_bufLeft) ;
				SetDlgItemText (hDlg, IDC_EDIT_KUTEN,  pArg->m_bufRight) ;
			}
		}
		return	(INT_PTR) TRUE ;

	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			/*WORD	woNotification	= HIWORD (wParam) ;*/
			switch (woControl) {
			case	IDOK:
				{
					struct TStringPairNode*	pArg	= (struct TStringPairNode*) GetWindowLongPtr (hDlg, DWLP_USER) ;

					if (pArg != NULL) {
						GetDlgItemText (hDlg, IDC_EDIT_TOUTEN, pArg->m_bufLeft,  ARRAYSIZE (pArg->m_bufLeft)) ;
						GetDlgItemText (hDlg, IDC_EDIT_KUTEN,  pArg->m_bufRight, ARRAYSIZE (pArg->m_bufRight)) ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, woControl) ;
				break ;
			default:
				break ;
			}
		}
		return	(INT_PTR) 1 ;

	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*========================================================================
 *	private functions for IDD_EDIT_OKURICHARALIST
 */
static	INT_PTR	dlgEditOkuriCharAlist_iOnInitDialog (HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditOkuriCharAlist_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditOkuriCharAlist_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void	dlgEditOkuriCharAlist_vEditOkuriCharPair	(HWND, int) ;

static	INT_PTR	CALLBACK	dlgEditOkuriCharPairProc (HWND, UINT, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
dlgEditOkuriCharAlistProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		return	dlgEditOkuriCharAlist_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditOkuriCharAlist_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditOkuriCharAlist_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditOkuriCharAlist_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditOkuriCharAlistArg*	pArg	= (struct TEditOkuriCharAlistArg*) lParam ;
	HWND	hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_OKURICHARALIST) ;
	if (hwndControl != NULL) {
		LV_COLUMN	lvColumn ;

		memset (&lvColumn, 0, sizeof (lvColumn)) ;

		ListView_DeleteAllItems (hwndControl) ;
		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;

		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.cx			= 80 ;
		lvColumn.pszText	= TEXT ("�ǂݑւ���") ;
		ListView_InsertColumn (hwndControl, 0, &lvColumn) ;
		lvColumn.pszText	= TEXT ("�ǂݑւ���") ;
		ListView_InsertColumn (hwndControl, 1, &lvColumn) ;
	}
	if (hwndControl != NULL && pArg != NULL) {
		struct TStringPairNode*	pNode	= pArg->m_plstOkuriCharPair ;
		LVITEM	lvi ;
		int		nCount, nItem ;

		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
		nCount		= 0 ;
		while (pNode != NULL) {
			lvi.iItem	= nCount ;
			lvi.pszText	= pNode->m_bufLeft ;
			lvi.lParam	= (LPARAM) pNode ;
			nItem		= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				ListView_SetItemText (hwndControl, nItem, 1, pNode->m_bufRight) ;
				nCount	++ ;
			}
			pNode		= pNode->m_pNext ;
		}
	}
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditOkuriCharAlist_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	/*WORD	woNotification	= HIWORD (wParam) ;*/

	switch (woControl) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
	case	IDC_BUTTON_DELETE:
		dlgEditOkuriCharAlist_vEditOkuriCharPair (hDlg, woControl) ;
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditOkuriCharAlist_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_OKURICHARALIST:
		{
			switch (pNMHDR->code) {
			case	NM_SETFOCUS:
			case	NM_CLICK:
			case	NM_RCLICK:
			case	LVN_ITEMCHANGED:
				{
					HWND	hwndControl	= pNMHDR->hwndFrom ;
					int		nCurSel ;

					nCurSel	= ListView_GetSelectionMark (hwndControl) ;
					EnableDlgItem (hDlg, IDC_BUTTON_EDIT,		(nCurSel != -1)) ;
					EnableDlgItem (hDlg, IDC_BUTTON_DELETE,		(nCurSel != -1)) ;
				}
			default:
				break ;
			}
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgEditOkuriCharAlist_vEditOkuriCharPair (
	HWND			hDlg,
	int				iControlId)
{
	struct TEditOkuriCharAlistArg*	pArg ;
	struct TStringPairNode	arg ;
	struct TStringPairNode*	pCurNode ;
	HWND			hwndControl ;
	LVITEM			lvi ;
	TCHAR			bufText [256] ;
	int				nText, nCurSel ;

	pArg		= (struct TEditOkuriCharAlistArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_OKURICHARALIST) ;
	if (hwndControl == NULL || pArg == NULL)
		return ;

	if (iControlId != IDC_BUTTON_ADD) {
		nCurSel		= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel == -1)
			return ;
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.iItem	= nCurSel ;
		lvi.mask	= LVIF_PARAM ;
		if (! ListView_GetItem (hwndControl, &lvi))
			return ;	/* error */
		pCurNode	= (struct TStringPairNode*) lvi.lParam ;
		if (pCurNode == NULL)
			return ;	/* error */
		lstrcpyn (arg.m_bufLeft,  pCurNode->m_bufLeft,  ARRAYSIZE (arg.m_bufLeft)) ;
		lstrcpyn (arg.m_bufRight, pCurNode->m_bufRight, ARRAYSIZE (arg.m_bufRight)) ;
	} else {
		nCurSel		= -1 ;
		arg.m_bufLeft [0]	= arg.m_bufRight [0]	= TEXT ('\0') ;
		pCurNode	= NULL ;
	}
	arg.m_pPrev			= arg.m_pNext			= NULL ;

	switch (iControlId) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		{
			HINSTANCE				hInst ;
			int						nResult ;
			struct TStringPairNode*	pNodeOverride ;

			hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
			nResult	= (int) DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_OKURICHARPAIR), hDlg, dlgEditOkuriCharPairProc, (LPARAM) &arg) ;
			if (nResult != IDOK)
				return ;
			if (arg.m_bufLeft [0] == TEXT ('\0') || arg.m_bufRight [0] == TEXT ('\0')) {
				(void) MessageBox (hDlg, TEXT ("���艼���ɋ󕶎�����w�肷�邱�Ƃ͂ł��܂���B"), TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
				return ;
			}
			pNodeOverride	= pFindStringPair (pArg->m_plstOkuriCharPair, arg.m_bufLeft) ;
			if ((iControlId == IDC_BUTTON_ADD  && pNodeOverride != NULL) ||
				(iControlId == IDC_BUTTON_EDIT && pNodeOverride != NULL && pNodeOverride != pCurNode)) {
				nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���艼�� ``%s'' �̓ǂݑւ��͊��� ``%s'' �ɐݒ肳��Ă��܂��B"), pNodeOverride->m_bufLeft, pNodeOverride->m_bufRight) ;
				bufText [nText]	= TEXT ('\0') ;
				(void) MessageBox (hDlg, bufText, TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
				return ;
			}
			if (pNodeOverride == NULL) {
				struct TStringPairNode*	pNewNode ;
				int		nItem ;

				pNewNode	= pCreateStringPair (arg.m_bufLeft, arg.m_bufRight) ;
				if (pNewNode == NULL)
					return ;

				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.iItem	= ListView_GetItemCount (hwndControl) ;
				lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
				lvi.pszText	= pNewNode->m_bufLeft ;
				lvi.lParam	= (LPARAM) pNewNode ;
				nItem		= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					ListView_SetItemText (hwndControl, nItem, 1, pNewNode->m_bufRight) ;
					vInsertStringPair (&pArg->m_plstOkuriCharPair, pNewNode) ;
				} else {
					FREE (pNewNode) ;
				}
			} else {
				lstrcpyn (pCurNode->m_bufLeft,  arg.m_bufLeft,  ARRAYSIZE (pCurNode->m_bufLeft)) ;
				lstrcpyn (pCurNode->m_bufRight, arg.m_bufRight, ARRAYSIZE (pCurNode->m_bufRight)) ;
				ListView_SetItemText (hwndControl, nCurSel, 0, pCurNode->m_bufLeft) ;
				ListView_SetItemText (hwndControl, nCurSel, 1, pCurNode->m_bufRight) ;
			}
		}
		break ;
	case	IDC_BUTTON_DELETE:
		{
			struct TStringPairNode*	pPrevNode ;
			struct TStringPairNode*	pNextNode ;

			if (pCurNode == NULL)
				break ;

			nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���艼���̓ǂݑւ��K�� ``%s'' �� ``%s'' �Ƃ��ď�������A���폜���܂��B��낵���ł����H"), pCurNode->m_bufLeft, pCurNode->m_bufRight) ;
			bufText [nText]	= TEXT ('\0') ;
			if (MessageBox (hDlg, bufText, TEXT ("���艼���̓ǂ݊����K���̍폜�m�F"), MB_ICONQUESTION | MB_OKCANCEL) != IDOK)
				return ;

			pPrevNode	= pCurNode->m_pPrev ;
			pNextNode	= pCurNode->m_pNext ;
			if (pPrevNode == NULL) {
				pArg->m_plstOkuriCharPair	= pNextNode ;
			} else {
				pPrevNode->m_pNext			= pNextNode ;
			}
			if (pNextNode != NULL) {
				pNextNode->m_pPrev	= pCurNode->m_pPrev ;
			}
			FREE (pCurNode) ;
		}
		break ;
	default:
		break ;
	}
	return ;
}

INT_PTR	CALLBACK
dlgEditOkuriCharPairProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		{
			struct TStringPairNode*	pArg	= (struct TStringPairNode*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
			if (pArg != NULL) {
				SetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_SRC,  pArg->m_bufLeft) ;
				SetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_DEST, pArg->m_bufRight) ;
			}
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_OKURICHAR_SRC) ;
			if (hwndControl != NULL) {
				(void) SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufLeft), (LPARAM) 0) ;
			}
			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_OKURICHAR_DEST) ;
			if (hwndControl != NULL) {
				(void) SendMessage (hwndControl, EM_LIMITTEXT, (WPARAM) ARRAYSIZE (pArg->m_bufRight), (LPARAM) 0) ;
			}
		}
		return	(INT_PTR) TRUE ;
	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			/*WORD	woNotification	= HIWORD (wParam) ;	*/

			switch (woControl) {
			case	IDOK:
				{
					struct TStringPairNode*	pArg ;

					pArg	= (struct TStringPairNode*) GetWindowLongPtr (hDlg, DWLP_USER) ;
					if (pArg != NULL) {
						GetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_SRC,  pArg->m_bufLeft,  ARRAYSIZE (pArg->m_bufLeft)) ;
						GetDlgItemText (hDlg, IDC_EDIT_OKURICHAR_DEST, pArg->m_bufRight, ARRAYSIZE (pArg->m_bufRight)) ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				break ;
			default:
				break ;
			}
		}
		return	(INT_PTR) 1 ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

