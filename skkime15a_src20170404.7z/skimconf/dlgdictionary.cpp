#include "stdafx.h"
#include "skimconf.h"
#include "resource.h"
#include "TCommuSession.h"
#include "TPacket.h"

#define	MAX_HOSTNAME		256
#define	MAX_REGVALUE_SIZE	512

#define	REGKEY_USERJISYO				TEXT("User")
#define REGKEY_ENTRY					TEXT("Dict%d")

#define	SKKIME_DEFAULT_JISYO_SETTING1	TEXT("user=enable")
#define	SKKIME_DEFAULT_JISYO_SETTING2	TEXT("okuri=enable")

#include "../common/userdict.h"
#define	SKKSERV_DEFAULT_PORTNUM			1178

enum {
	JISYOTYPE_USER	= 0,
	JISYOTYPE_SERVER,
	JISYOTYPE_FILE,
	JISYOTYPE_OKURI,
} ;

/*========================================================================
 *	structures
 */
struct THostAndPort {
	TCHAR	m_rszHost [MAX_HOSTNAME] ;
	int		m_nPort ;
	struct THostAndPort*	m_pPrev ;
	struct THostAndPort*	m_pNext ;
} ;

struct TFileJisyoInfo {
	TCHAR	m_rszPath [MAX_PATH + 1] ;
	BOOL	m_bSorted ;
} ;

struct TServerJisyoInfo {
	TCHAR	m_rszAuxJisyoPath [MAX_PATH + 1] ;
	BOOL	m_bAuxJisyo ;
	BOOL	m_bAuxJisyoSorted ;
	/* ������ host/port �ɓ���(������ɋ߂����炢��_����������)�� request ��������B*/
	struct THostAndPort*	m_plstHost ;
} ;

struct TUserJisyoInfo {
	BOOL	m_bEnabled ;		/* �L�� or �����B�폜�ł��Ȃ����[�U�����͗L���Ɩ�����؂�ւ�����B*/
} ;

struct TJisyoNode {
	int		m_nType ;
	int		m_nIndex ;			/* �����̌��������B�\�[�g���邽�߂ɕK�v�B*/
	union {
		struct TFileJisyoInfo	m_File ;
		struct TServerJisyoInfo	m_Server ;
		struct TUserJisyoInfo	m_User ;
	} ;
	struct TJisyoNode*	m_pPrev ;
	struct TJisyoNode*	m_pNext ;
} ;

struct TEditJisyoArg {
	int		m_nType ;
	TCHAR	m_rszJisyoPath [MAX_PATH + 1] ;
	BOOL	m_bAuxJisyo ;
	BOOL	m_bAuxJisyoSorted ;
	struct THostAndPort*	m_plstHost ;
	struct TJisyoNode*		m_pInitValue ;
} ;

/*========================================================================
 *	prototypes
 */
static	INT_PTR		dlgDictionary_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgDictionary_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgDictionary_iOnNotify		(HWND, WPARAM, LPARAM) ;

static	void		dlgDictionary_vSyncControls	(HWND) ;
static	BOOL		dlgDictionary_bEditDictionary		(HWND, int, int) ;

//static	void		dlgDictionary_vUnregisterJisyo		(struct TJisyoNode*) ;
//static	void		dlgDictionary_vDestroyJisyo			(struct TJisyoNode*) ;
//static	BOOL		dlgDictionary_bMoveSelectedJisyo	(HWND, BOOL) ;

static	INT_PTR	CALLBACK	dlgEditUserJisyoProc	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditServerJisyoProc	(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditFileJisyoProc	(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL					dlgDictionary_bSetDictionaryItemText	(HWND, int, struct TJisyoNode*) ;
static	struct THostAndPort*	dlgDictionary_pNewPortAndHostNode		(LPCTSTR, int, int) ;
static	struct THostAndPort*	dlgDictionary_pCopyPortAndHostList		(struct THostAndPort*) ;

static	BOOL					dlgDictionary_bInitSearchJisyoList		(LPCTSTR, struct TJisyoNode**, LPTSTR) ;
static	void					dlgDictionary_vInitDefaultSearchJisyoList	(struct TJisyoNode**, LPTSTR) ;
static	void					dlgDictionary_vDestroyJisyoList			(struct TJisyoNode**) ;
static	BOOL					dlgDictionary_bUpdateSearchJisyoList	(LPCTSTR, struct TJisyoNode*, LPCTSTR) ;
static	struct TJisyoNode*		dlgDictionary_pNewJisyoNode				(int, LPCTSTR) ;
static	void					dlgDictionary_vRegisterJisyo			(struct TJisyoNode**, struct TJisyoNode*, struct TJisyoNode*) ;
static	void					dlgDictionary_vUnregisterJisyo			(struct TJisyoNode**, struct TJisyoNode*) ;
static	void					dlgDictionary_vDestroyJisyo				(struct TJisyoNode*) ;

static	struct THostAndPort*	dlgDictionary_pNewPortAndHostNode		(LPCTSTR, int, int) ;
static	void	dlgDictionary_vRegisterHostAndPort		(struct THostAndPort*, struct THostAndPort**, struct THostAndPort*) ;
static	void	dlgDictionary_vUnregisterHostAndPort	(struct THostAndPort*, struct THostAndPort**) ;
static	void	dlgDictionary_vDeleteHostList			(struct THostAndPort*) ;

static	BOOL	dlgDictionary_bHostlist2string		(LPTSTR, int, struct THostAndPort*) ;
static	BOOL	dlgDictionary_bMoveSelectedJisyo	(HWND, BOOL) ;

static	struct TJisyoNode*		dlgDictionary_bParseJisyoSetting		(LPCTSTR, int) ;
static	BOOL					dlgDictionary_bParseJisyoNumber			(LPCTSTR, int*) ;
static	BOOL					dlgDictionary_bInsertJisyoInSearchList	(struct TJisyoNode**, struct TJisyoNode*) ;
static	struct THostAndPort*	dlgDictionary_pParsePortAndHost			(LPCTSTR, int) ;

BOOL					dlgDictionary_bSyncSkkiserv (void) ;

/*========================================================================
 *	global variables
 */
static	TCHAR				_rszUserJisyoPath [MAX_PATH+1]	= TEXT ("") ;
static	struct TJisyoNode*	_plstSearchJisyos				= NULL ;

static	HICON				_hiconArrowUp					= NULL ;
static	HICON				_hiconArrowDown					= NULL ;


/*========================================================================
 *	public functions
 */
INT_PTR	CALLBACK
DlgDictioanryProc	(
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		return	dlgDictionary_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgDictionary_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgDictionary_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}


/*========================================================================
 *	private functions
 */
INT_PTR
dlgDictionary_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	HINSTANCE		hInst ;
	LPPROPSHEETPAGE	pPropSheet ;
	HWND	hwndListSearchDict ;
	HWND	hwndButton ;

	hInst			= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pPropSheet		= (LPPROPSHEETPAGE) lParam ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pPropSheet->lParam) ;

	hwndListSearchDict	= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
	if (hwndListSearchDict != NULL) {
		LV_COLUMN			lvColumn;
		static LPTSTR	rpszDicType []	= {
			TEXT ("���[�U����"),	TEXT ("�T�[�o����"),
			TEXT ("�t�@�C������"),	TEXT ("�\�[�g�σt�@�C������"),
		} ;

		ListView_DeleteAllItems (hwndListSearchDict) ;
		ListView_SetExtendedListViewStyle (hwndListSearchDict, LVS_EX_FULLROWSELECT) ;
		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.cx			= 120 ;
		lvColumn.pszText	= TEXT ("���") ;
		ListView_InsertColumn (hwndListSearchDict, 0, &lvColumn) ;
		lvColumn.cx			= 240 ;
		lvColumn.pszText	= TEXT ("�ݒ�") ;
		ListView_InsertColumn (hwndListSearchDict, 1, &lvColumn) ;
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWUP) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWUP), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowUp		= hIcon ;
		}
	}
	hwndButton	= GetDlgItem (hDlg, IDC_BUTTON_ARROWDOWN) ;
	if (hwndButton != NULL) {
		HICON	hIcon ;
		hIcon	= (HICON) LoadImage (hInst, MAKEINTRESOURCE (IDI_ARROWDOWN), IMAGE_ICON, 16, 16, LR_SHARED) ;
		if (hIcon != NULL) {
			SendMessage (hwndButton, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
			_hiconArrowDown	= hIcon ;
		}
	}

	if (! dlgDictionary_bInitSearchJisyoList (REGPATH_DICTIONARY, &_plstSearchJisyos, _rszUserJisyoPath) /*&&
		! dlgDictionary_bInitSearchJisyoList (REGPATH_OLDDICTIONARY, &_plstSearchJisyos, _rszUserJisyoPath)*/)
		dlgDictionary_vInitDefaultSearchJisyoList (&_plstSearchJisyos, _rszUserJisyoPath) ;
	dlgDictionary_vSyncControls (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgDictionary_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_EDIT_USRDICPATH:
		/*	�G�f�B�b�g�{�b�N�X��ҏW����ƁAAPPLY ���L���ɂȂ�Ȃ���΁B*/
		if (woNotification == EN_CHANGE)
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
		break ;

	case	IDC_BUTTON_BROWSE_USRDICTPATH:
	{
		OPENFILENAME	ofn ;
		TCHAR			szPath [MAX_PATH + 1] ;

		if (woNotification == BN_CLICKED) {
			if (! ExpandEnvironmentStrings (_rszUserJisyoPath, szPath, MAX_PATH))
				lstrcpyn (szPath, _rszUserJisyoPath, MAX_PATH) ;
			szPath [MAX_PATH]	= TEXT ('\0') ;
			memset (&ofn, 0, sizeof (ofn)) ;
			ofn.lStructSize			= sizeof (OPENFILENAME) ;
			ofn.hwndOwner			= hDlg ;
			ofn.hInstance			= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
			ofn.lpstrFilter			= TEXT ("All\0*.*\0") ;
			ofn.lpstrCustomFilter	= NULL ;
			ofn.nFilterIndex		= 1 ;
			ofn.lpstrFile			= szPath ;
			ofn.nMaxFile			= MAX_PATH ;
			ofn.lpstrFileTitle		= NULL ;
			ofn.lpstrInitialDir		= TEXT ("") ;
			ofn.lpstrTitle			= TEXT ("���[�U�����̑I��") ;
			ofn.Flags				= OFN_CREATEPROMPT | OFN_HIDEREADONLY | OFN_LONGNAMES | OFN_NONETWORKBUTTON ;
			ofn.lpstrDefExt			= NULL ;
			ofn.lpfnHook			= NULL ;
			if (GetOpenFileName (&ofn) != 0) {
				lstrcpyn (_rszUserJisyoPath, szPath, MAX_PATH) ;
				_rszUserJisyoPath [MAX_PATH]	= TEXT ('\0') ;
				SetDlgItemText (hDlg, IDC_EDIT_USRDICPATH, szPath) ;
				PropSheet_Changed (GetParent (hDlg), hDlg) ;
			}
			return	0 ;
		}
		return	1 ;
	}
	case	IDC_BUTTON_SAVEUSERJISYO:
	{
		/*	skkiserv �Ɏ����̕ۑ���v������B*/
		return	1 ;
	}
	case	IDC_BUTTON_REPAIR_USRDICT:
		return	1 ;
	case	IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST:
	case	IDC_BUTTON_ADD_FILE_JISYO:
	case	IDC_BUTTON_ADD_SERVER_JISYO:
	{
		if (woNotification == BN_CLICKED) {
			HWND	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
			int		nItem ;

			if (hwndLV == NULL)
				return	1 ;
			nItem	= ListView_GetSelectionMark (hwndLV) ;
			dlgDictionary_bEditDictionary (hDlg, nItem, woControl) ;
			return	0 ;
		}
		return	1 ;
	}
	case	IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST:
	{
		if (woNotification == BN_CLICKED) {
			HWND				hwndLV		= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
			int					nItem ;
			struct TJisyoNode*	pNode ;
			LVITEM				lvI ;

			if (hwndLV == NULL)
				return	1 ;

			nItem			= ListView_GetSelectionMark (hwndLV) ;
			if (nItem < 0)
				return	1 ;
			lvI.mask		= LVIF_PARAM ;
			lvI.iItem		= nItem ;
			if (! ListView_GetItem (hwndLV, &lvI)) {
				pNode		= NULL ;
			} else {
				pNode		= (struct TJisyoNode*)lvI.lParam ;
			}
			if (pNode == NULL)
				return	1 ;

			ListView_DeleteItem (hwndLV, nItem) ;
			dlgDictionary_vUnregisterJisyo (&_plstSearchJisyos, pNode) ;
			dlgDictionary_vDestroyJisyo (pNode) ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
	}
	case	IDC_BUTTON_ARROWUP:
		if (woNotification == BN_CLICKED) {
			if (dlgDictionary_bMoveSelectedJisyo (hDlg, TRUE))
				PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_ARROWDOWN:
		if (woNotification == BN_CLICKED) {
			if (dlgDictionary_bMoveSelectedJisyo (hDlg, FALSE))
				PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgDictionary_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_SEARCHDICT:
		{
			switch (pNMHDR->code) {
			case	NM_SETFOCUS:
			case	NM_CLICK:
			case	NM_RCLICK:
			case	LVN_ITEMCHANGED:
				{
					int		nCurSel ;
					BOOL	bEditJisyo		= FALSE ;
					BOOL	bRemoveJisyo	= FALSE ;
					BOOL	bArrowUp		= FALSE ;
					BOOL	bArrowDown		= FALSE ;

					nCurSel	= ListView_GetSelectionMark (pNMHDR->hwndFrom) ;
					if (nCurSel != -1) {
						LVITEM	lvi ;

						memset (&lvi, 0, sizeof (lvi)) ;
						lvi.iItem	= nCurSel ;
						lvi.mask	= LVIF_PARAM ;
						if (ListView_GetItem (pNMHDR->hwndFrom, &lvi)) {
							struct TJisyoNode*	pNode	= (struct TJisyoNode*) lvi.lParam ;
							if (pNode != NULL) {
								bEditJisyo		= TRUE ; //(pNode->m_nType != JISYOTYPE_USER && pNode->m_nType != JISYOTYPE_OKURI)? TRUE : FALSE ;
								bRemoveJisyo	= (pNode->m_nType != JISYOTYPE_USER && pNode->m_nType != JISYOTYPE_OKURI)? TRUE : FALSE ;
							}
						}
						bArrowUp	= (nCurSel > 0)? TRUE : FALSE ;
						bArrowDown	= (nCurSel < (ListView_GetItemCount (pNMHDR->hwndFrom) - 1))? TRUE : FALSE ;
					}
					EnableDlgItem (hDlg, IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST,		bEditJisyo) ;
					EnableDlgItem (hDlg, IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST,	bRemoveJisyo) ;
					EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,						bArrowUp) ;
					EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,						bArrowDown) ;
				}
				break ;
			default:
				break ;
			}
		}
		break ;
	default:
		{
			switch (pNMHDR->code) {
			case	PSN_APPLY:
				if (dlgDictionary_bUpdateSearchJisyoList (REGPATH_DICTIONARY, _plstSearchJisyos, _rszUserJisyoPath))
					vUpdateTick () ;

				/*	�����̍X�V�� skkiserv ���ɓ`�B����Ȃ���΂Ȃ�Ȃ��B
				 *	pipe ���g���āA���b�Z�[�W�𓊂���B
				 */
				dlgDictionary_bSyncSkkiserv () ;
				break ;
			case	PSN_RESET:
				dlgDictionary_vDestroyJisyoList (&_plstSearchJisyos) ;
				if (! dlgDictionary_bInitSearchJisyoList (REGPATH_DICTIONARY, &_plstSearchJisyos, _rszUserJisyoPath) /*&&
					! dlgDictionary_bInitSearchJisyoList (REGPATH_OLDDICTIONARY, &_plstSearchJisyos, _rszUserJisyoPath)*/)
					dlgDictionary_vSyncControls (hDlg) ;
				break ;
			default:
				break ;
			}
		}
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}



void
dlgDictionary_vSyncControls (
	HWND		hDlg)
{
	HWND	hwndEditUsrDicPath ;
	HWND	hwndListSearchDict ;

	hwndEditUsrDicPath	= GetDlgItem (hDlg, IDC_EDIT_USRDICPATH) ;
	if (hwndEditUsrDicPath != NULL) {
		TCHAR	szPath [MAX_PATH + 1] ;
		if (! ExpandEnvironmentStrings (_rszUserJisyoPath, szPath, MAX_PATH)) {
			SendMessage (hwndEditUsrDicPath, WM_SETTEXT, 0, (LPARAM) _rszUserJisyoPath) ;
		} else {
			SendMessage (hwndEditUsrDicPath, WM_SETTEXT, 0, (LPARAM) szPath) ;
		}
		SendMessage (hwndEditUsrDicPath, EM_SETLIMITTEXT, (WPARAM) MAX_PATH, 0) ;
	}

	hwndListSearchDict	= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
	if (hwndListSearchDict != NULL) {
		struct TJisyoNode*	pNode ;
		LVITEM				lvI ;
		int					n, nCurSel ;

		ListView_DeleteAllItems (hwndListSearchDict) ;
		nCurSel	= ListView_GetSelectionMark (hwndListSearchDict) ;

		lvI.mask		= LVIF_PARAM | LVIF_STATE ;
		lvI.state		= 0 ;
		lvI.stateMask	= 0 ;
		lvI.iSubItem	= 0 ;
		lvI.pszText		= 0 ;
		pNode	= _plstSearchJisyos ;
		n		= 0 ;
		while (pNode != NULL) {
			int				nItem ;
			lvI.iItem		= n ;
			lvI.iImage		= n ;
			lvI.lParam		= (LPARAM) pNode ;
			nItem			= ListView_InsertItem (hwndListSearchDict, &lvI) ;
			if (nItem != -1)
				dlgDictionary_bSetDictionaryItemText (hwndListSearchDict, nItem, pNode) ;
			pNode	= pNode->m_pNext ;
			n		++ ;
		}
		if (nCurSel != -1) {
			BOOL	bEditJisyo, bRemoveJisyo, bArrowUp, bArrowDown ;

			ListView_SetSelectionMark (hwndListSearchDict, nCurSel) ;
			ListView_SetItemState (hwndListSearchDict, nCurSel, LVIS_SELECTED, LVIS_SELECTED) ;

			bEditJisyo = bRemoveJisyo = bArrowUp = bArrowDown = FALSE ;
			memset (&lvI, 0, sizeof (lvI)) ;
			lvI.iItem	= nCurSel ;
			lvI.mask	= LVIF_PARAM ;
			if (ListView_GetItem (hwndListSearchDict, &lvI)) {
				struct TJisyoNode*	pNode	= (struct TJisyoNode*) lvI.lParam ;
				if (pNode != NULL) {
					bEditJisyo		= (pNode->m_nType != JISYOTYPE_USER)? TRUE : FALSE ;
					bRemoveJisyo	= (pNode->m_nType != JISYOTYPE_USER)? TRUE : FALSE ;
				}
			}
			bArrowUp	= (nCurSel > 0)? TRUE : FALSE ;
			bArrowDown	= (nCurSel < (ListView_GetItemCount (hwndListSearchDict) - 1))? TRUE : FALSE ;

			EnableDlgItem (hDlg, IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST,		bEditJisyo) ;
			EnableDlgItem (hDlg, IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST,	bRemoveJisyo) ;
			EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,						bArrowUp) ;
			EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,						bArrowDown) ;
		} else {
			EnableDlgItem (hDlg, IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST,		FALSE) ;
			EnableDlgItem (hDlg, IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST,	FALSE) ;
			EnableDlgItem (hDlg, IDC_BUTTON_ARROWUP,						FALSE) ;
			EnableDlgItem (hDlg, IDC_BUTTON_ARROWDOWN,						FALSE) ;
		}
	}
	return ;
}

BOOL
dlgDictionary_bEditDictionary (
	HWND		hDlg,
	int			nItem,
	int			nCommand)
{
	HWND					hwndLV ;
	HINSTANCE				hInst ;
	LVITEM					lvI ;
	INT_PTR					nRetval;
	int						nPath ;
	struct TJisyoNode*		pNode ;
	struct TJisyoNode*		pNewNode ;
	struct TEditJisyoArg	arg ;

	hInst		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	hwndLV		= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
	if (hwndLV == NULL)
		return	FALSE ;

	memset (&lvI, 0, sizeof (lvI)) ;
	memset (&arg, 0, sizeof (arg)) ;
	lvI.mask		= LVIF_PARAM ;
	lvI.iItem		= nItem ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		pNode		= NULL ;
	} else {
		pNode		= (struct TJisyoNode *)lvI.lParam ;
	}

	switch (nCommand) {
	case	IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST:
	{
		if (pNode == NULL)
			return	FALSE ;

		switch (pNode->m_nType) {
		case	JISYOTYPE_USER:
		case	JISYOTYPE_OKURI:
			arg.m_nType			= pNode->m_nType ;
			arg.m_pInitValue	= pNode ;
			nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_USERJISYO), hDlg, dlgEditUserJisyoProc, (LPARAM) &arg) ;
			break ;
		case	JISYOTYPE_SERVER:
			arg.m_nType			= JISYOTYPE_SERVER ;
			arg.m_pInitValue	= pNode ;
			nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_SERVERJISYO), hDlg, dlgEditServerJisyoProc, (LPARAM) &arg) ;
			break ;
		case	JISYOTYPE_FILE:
			arg.m_nType			= JISYOTYPE_FILE ;
			arg.m_pInitValue	= pNode ;
			nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_FILEJISYO), hDlg, dlgEditFileJisyoProc, (LPARAM) &arg) ;
			break ;
		default:
			return	FALSE ;
		}
		break ;
	}
	case	IDC_BUTTON_ADD_FILE_JISYO:
	{
		arg.m_nType			= JISYOTYPE_FILE ;
		arg.m_pInitValue	= NULL ;
		nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_FILEJISYO), hDlg, dlgEditFileJisyoProc, (LPARAM) &arg) ;
		break ;
	}
	case	IDC_BUTTON_ADD_SERVER_JISYO:
	{
		arg.m_nType			= JISYOTYPE_SERVER ;
		arg.m_pInitValue	= NULL ;
		nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_SERVERJISYO), hDlg, dlgEditServerJisyoProc, (LPARAM) &arg) ;
		break ;
	}
	case	IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST:
	{
		if (pNode == NULL || pNode->m_nType == JISYOTYPE_USER)
			return	FALSE ;
		ListView_DeleteItem (hwndLV, nItem) ;
		dlgDictionary_vUnregisterJisyo (&_plstSearchJisyos, pNode) ;
		dlgDictionary_vDestroyJisyo (pNode) ;
		return	TRUE ;
	}
	default:
		return	FALSE ;
	}

	/*	nRetval ����͂��ē���B
	 */
	if (nRetval != IDOK)
		return	TRUE ;

	switch (arg.m_nType) {
	case	JISYOTYPE_SERVER:
		if (arg.m_plstHost == NULL) {
			return	FALSE ;
		}
		break ;
	case	JISYOTYPE_FILE:
		if (arg.m_rszJisyoPath [0] == TEXT ('\0')) {
			return	FALSE ;
		}
		break ;
	case	JISYOTYPE_USER:
	case	JISYOTYPE_OKURI:
		pNode->m_User.m_bEnabled	= arg.m_bAuxJisyo ;
		dlgDictionary_bSetDictionaryItemText (hwndLV, nItem, pNode) ;
		PropSheet_Changed (GetParent (hDlg), hDlg) ;
		return	TRUE ;
	default:
		return	FALSE ;
	}

	nPath		= lstrlen (arg.m_rszJisyoPath) ;
	pNewNode	= dlgDictionary_pNewJisyoNode (arg.m_nType, arg.m_rszJisyoPath) ;
	if (pNewNode == NULL) {
		if (arg.m_plstHost != NULL) {
			dlgDictionary_vDeleteHostList (arg.m_plstHost) ;
			arg.m_plstHost	= NULL ;
		}
		return	FALSE ;
	}
	if (arg.m_nType == JISYOTYPE_SERVER) {
		pNewNode->m_Server.m_bAuxJisyo			= arg.m_bAuxJisyo ;
		pNewNode->m_Server.m_bAuxJisyoSorted	= arg.m_bAuxJisyoSorted ;
		pNewNode->m_Server.m_plstHost			= arg.m_plstHost ;
		arg.m_plstHost		= NULL ;
	} else if (arg.m_nType == JISYOTYPE_FILE) {
		pNewNode->m_File.m_bSorted	= arg.m_bAuxJisyoSorted ;
	} else {
		dlgDictionary_vDestroyJisyo (pNewNode) ;
		return	FALSE ;
	}

	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM | LVIF_STATE ;
	lvI.lParam		= (LPARAM) pNewNode ;
	if (nCommand == IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST) {
		lvI.iItem	= nItem ;
		ListView_SetItem (hwndLV, &lvI) ;

		dlgDictionary_vRegisterJisyo (&_plstSearchJisyos, pNewNode, pNode) ;
		dlgDictionary_vUnregisterJisyo (&_plstSearchJisyos, pNode) ;
		dlgDictionary_vDestroyJisyo (pNode) ;
		dlgDictionary_bSetDictionaryItemText (hwndLV, nItem, pNewNode) ;
	} else {
		dlgDictionary_vRegisterJisyo (&_plstSearchJisyos, pNewNode, pNode) ;

		lvI.iItem	= (pNode == NULL)? 0 : (nItem + 1) ;
		nItem		= ListView_InsertItem (hwndLV, &lvI) ;
		if (nItem != -1) {
			dlgDictionary_bSetDictionaryItemText (hwndLV, nItem, pNewNode) ;
		}
	}
	PropSheet_Changed (GetParent (hDlg), hDlg) ;
	return	TRUE ;
}

/*=================================================================================
 *	Dialog Function for IDD_EDIT_SERVERJISYO
 */
static	INT_PTR				dlgEditServerJisyo_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditServerJisyo_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditServerJisyo_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	INT_PTR CALLBACK	dlgEditHostPortProc					(HWND, UINT, WPARAM, LPARAM) ;
static	BOOL				dlgDictionary_bEditHostPort			(HWND, int, int) ;


INT_PTR	CALLBACK
dlgEditServerJisyoProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgEditServerJisyo_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditServerJisyo_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditServerJisyo_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgEditServerJisyo_iOnInitDialog (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	struct TEditJisyoArg*	pArg ;
	struct THostAndPort*	pHost ;
	struct TJisyoNode*		pInitValue ;
	int				nItem, n ;
	LV_COLUMN		lvColumn;
	LVITEM			lvI ;
	HWND			hwndAuxPath, hwndCheck, hwndLV ;
	TCHAR			szBuffer [32] ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	pArg			= (struct TEditJisyoArg*) lParam ;
	if (pArg == NULL)
		return	TRUE ;

	pInitValue		= pArg->m_pInitValue ;

	hwndAuxPath		= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
	if (hwndAuxPath != NULL) {
		SendMessage   (hwndAuxPath, EM_LIMITTEXT, (WPARAM) MAX_PATH, 0) ;
		SetWindowText (hwndAuxPath, (pInitValue != NULL)? pInitValue->m_Server.m_rszAuxJisyoPath : TEXT ("")) ;
	}

	/*	���X�g���R�s�[����B�I���W���𑀍삷��킯�ɂ͂����Ȃ��̂ŁB*/
	pArg->m_plstHost= dlgDictionary_pCopyPortAndHostList ((pInitValue != NULL)? pInitValue->m_Server.m_plstHost : NULL) ;

	hwndLV			= GetDlgItem (hDlg, IDC_LIST_SERVER_DICT) ;
	if (hwndLV != NULL) {
		ListView_DeleteAllItems (hwndLV) ;
		ListView_SetExtendedListViewStyle (hwndLV, LVS_EX_FULLROWSELECT) ;

		lvColumn.mask		= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt		= LVCFMT_LEFT ;
		lvColumn.pszText	= TEXT ("�z�X�g��") ;
		lvColumn.cx			= 120 ;
		ListView_InsertColumn (hwndLV, 0, &lvColumn) ;
		lvColumn.pszText	= TEXT ("�|�[�g�ԍ�") ;
		ListView_InsertColumn (hwndLV, 1, &lvColumn) ;

		pHost			= (pInitValue != NULL)? pInitValue->m_Server.m_plstHost : NULL ;
		memset (&lvI, 0, sizeof (lvI)) ;
		lvI.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		n				= 0 ;
		while (pHost != NULL) {
			lvI.iItem	= n ;
			lvI.pszText	= pHost->m_rszHost ;
			lvI.lParam	= (LPARAM) pHost ;
			nItem		= ListView_InsertItem (hwndLV, &lvI) ;
			if (nItem != -1) {
				wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%d"), pHost->m_nPort) ;
				szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
				ListView_SetItemText (hwndLV, nItem, 1, szBuffer) ;
			}
			pHost		= pHost->m_pNext ;
			n			++ ;
		}
	}

	CheckDlgButton (hDlg, IDC_CHECK_FILE_DICT_SORTEDP, (pArg->m_bAuxJisyoSorted)? BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_ENABLE_AUX_JISYO,  (pArg->m_bAuxJisyo)? BST_CHECKED : BST_UNCHECKED) ;
	if (hwndAuxPath != NULL)
		EnableWindow (hwndAuxPath, pArg->m_bAuxJisyo) ;
	hwndCheck	= GetDlgItem (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) ;
	if (hwndCheck != NULL)
		EnableWindow (hwndCheck, pArg->m_bAuxJisyo) ;

	return	TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditServerJisyo_iOnCommand (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	WORD					wNotifyCode ;
	WORD					wID ;
	HWND					hwndCtl ;
	struct TEditJisyoArg*	pArg ;

	pArg		= (struct TEditJisyoArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	wNotifyCode	= HIWORD (wParam) ;
	wID			= LOWORD (wParam) ;
	hwndCtl		= (HWND) lParam ;

	switch (wID) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_MODIFY:
	case	IDC_BUTTON_REMOVE:
	{
		if (wNotifyCode == BN_CLICKED) {
			HWND	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SERVER_DICT) ;
			int		nItem ;

			if (hwndLV == NULL)
				break ;
			nItem	= ListView_GetSelectionMark (hwndLV) ;
			dlgDictionary_bEditHostPort (hDlg, nItem, wID) ;
			return	FALSE ;
		}
		break ;
	}
	case	IDC_CHECK_FILE_DICT_SORTEDP:
	{
		if (wNotifyCode == BN_CLICKED) {
			UINT	uCheck ;

			uCheck		= IsDlgButtonChecked (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) ;
			pArg->m_bAuxJisyoSorted	= (uCheck == BST_CHECKED)? TRUE : FALSE ;
			return	FALSE ;
		}
	}
	case	IDC_CHECK_ENABLE_AUX_JISYO:
	{
		if (wNotifyCode == BN_CLICKED) {
			UINT	uCheck ;
			BOOL	fEnable ;

			uCheck		= IsDlgButtonChecked (hDlg, IDC_CHECK_ENABLE_AUX_JISYO) ;
			fEnable		= (uCheck == BST_CHECKED)? TRUE : FALSE ;
			if (fEnable != pArg->m_bAuxJisyo) {
				HWND	hwndCheck, hwndEdit ;

				hwndEdit	= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
				hwndCheck	= GetDlgItem (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) ;
				if (hwndEdit != NULL)
					EnableWindow (hwndEdit,  fEnable) ;
				if (hwndCheck != NULL)
					EnableWindow (hwndCheck, fEnable) ;
				pArg->m_bAuxJisyo	= fEnable ;
			}
			return	FALSE ;
		}
		break ;
	}
	case	IDC_BUTTON_BROWSE_FILE_DICT_PATH:
	{
		OPENFILENAME	ofn ;
		TCHAR			szPath [MAX_PATH + 1] ;

		if (wNotifyCode == BN_CLICKED) {
			lstrcpyn (szPath, pArg->m_rszJisyoPath, MAX_PATH) ;
			szPath [MAX_PATH]	= TEXT ('\0') ;
			memset (&ofn, 0, sizeof (ofn)) ;
			ofn.lStructSize			= sizeof (OPENFILENAME) ;
			ofn.hwndOwner			= hDlg ;
			ofn.hInstance			= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
			ofn.lpstrFilter			= TEXT ("All\0*.*\0") ;
			ofn.lpstrCustomFilter	= NULL ;
			ofn.nFilterIndex		= 1 ;
			ofn.lpstrFile			= szPath ;
			ofn.nMaxFile			= MAX_PATH ;
			ofn.lpstrFileTitle		= NULL ;
			ofn.lpstrInitialDir		= TEXT ("") ;
			ofn.lpstrTitle			= TEXT ("�⏕�����̑I��") ;
			ofn.Flags				= OFN_HIDEREADONLY | OFN_LONGNAMES | OFN_NONETWORKBUTTON | OFN_PATHMUSTEXIST ;
			ofn.lpstrDefExt			= NULL ;
			ofn.lpfnHook			= NULL ;
			if (GetOpenFileName (&ofn) != 0) {
				lstrcpyn (pArg->m_rszJisyoPath, szPath, MAX_PATH) ;
				pArg->m_rszJisyoPath [MAX_PATH]	= TEXT ('\0') ;
				SetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, szPath) ;
			}
			return	FALSE ;
		}
		break ;
	}
	case	IDOK:
	case	IDCANCEL:
	{
		if (wID == IDOK) {
			if (pArg != NULL) {
				HWND	hwndAuxPath ;

				hwndAuxPath		= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
				pArg->m_rszJisyoPath [0]	= TEXT ('\0') ;
				if (hwndAuxPath != NULL)
					GetWindowText (hwndAuxPath, pArg->m_rszJisyoPath, MAX_PATH) ;

				pArg->m_bAuxJisyoSorted	= (IsDlgButtonChecked (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) == BST_CHECKED)? TRUE : FALSE ;

				/*	host-port �̗�́c�����e�i���X����Ă���̂�
				 *	�����Ŕ����o���K�v�͂Ȃ��B*/
			} else {
				wID	= IDCANCEL ;
			}
		}
		if (wID == IDCANCEL) {
			dlgDictionary_vDeleteHostList (pArg->m_plstHost) ;
			pArg->m_plstHost	= NULL ;
		}
		EndDialog (hDlg, wID) ;
		return	FALSE ;
	}
	default:
		break ;
	}
	return	(INT_PTR)TRUE ;
}

INT_PTR
dlgEditServerJisyo_iOnNotify (
	HWND		hDlg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;
	static struct TMENUITEM 	rmi []	= {
		{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ǉ�"), IDC_BUTTON_ADD, },
		{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�ҏW"), IDC_BUTTON_MODIFY, },
		{ MIIM_ID | MIIM_STRING, 0,  0,	TEXT("�폜"), IDC_BUTTON_REMOVE, },
	} ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_SERVER_DICT:
		if (pNMHDR->code == NM_RCLICK) {
			NMITEMACTIVATE*	pNM 	= (NMITEMACTIVATE*) lParam ;
			int	n ;

			n	= iPopupMenu (hDlg, rmi, ARRAYSIZE (rmi)) ;
			if (n > 0)
				dlgDictionary_bEditHostPort (hDlg, pNM->iItem, n) ;
		}
		break ;
	default:
		break ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
dlgDictionary_bEditHostPort (
	HWND		hDlg,
	int			nItem,
	int			nCommand)
{
	struct TEditJisyoArg*	pArg ;
	struct THostAndPort		arg ;
	HINSTANCE				hInst ;
	HWND					hwndLV ;
	LVITEM					lvI ;
	struct THostAndPort*	pNode ;
	INT_PTR					nRetval ;
	TCHAR					szBuffer [32] ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pArg	= (struct TEditJisyoArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndLV	= GetDlgItem (hDlg, IDC_LIST_SERVER_DICT) ;
	if (hwndLV == NULL || pArg == NULL)
		return	FALSE ;

	memset (&arg, 0, sizeof (arg)) ;
	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM ;
	lvI.iItem		= nItem ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		pNode		= NULL ;
	} else {
		pNode		= (struct THostAndPort*)lvI.lParam ;
	}
	switch (nCommand) {
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_MODIFY:
	{
		struct THostAndPort*	pNewNode ;
		int						nHostnameLen ;

		arg.m_rszHost [0]	= TEXT ('\0') ;
		arg.m_nPort			= 1178 ;
		if (pNode != NULL) {
			if (pNode->m_rszHost [0] != TEXT ('\0'))
				lstrcpyn (arg.m_rszHost, pNode->m_rszHost, MAX_HOSTNAME) ;
			arg.m_nPort	= pNode->m_nPort ;
		}
		nRetval	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_HOSTPORT), hDlg, dlgEditHostPortProc, (LPARAM)&arg) ;
		if (nRetval != IDOK)
			return	TRUE ;
		nHostnameLen	= lstrlen (arg.m_rszHost) ;
		if (arg.m_nPort <= 0 || nHostnameLen <= 0)
			break;	// return	FALSE ;
		pNewNode	= dlgDictionary_pNewPortAndHostNode (arg.m_rszHost, lstrlen (arg.m_rszHost), arg.m_nPort) ;
		if (pNewNode == NULL) {
			break;	// return	FALSE ;	// out of memory
		}
		dlgDictionary_vRegisterHostAndPort (pNewNode, &pArg->m_plstHost, pNode) ;
		dlgDictionary_vUnregisterHostAndPort (pNode, &pArg->m_plstHost) ;

		memset (&lvI, 0, sizeof (lvI)) ;
		lvI.mask		= LVIF_PARAM | LVIF_STATE ;
		lvI.lParam		= (LPARAM) pNewNode ;
		if (pNode != NULL) {
			lvI.iItem	= nItem ;
			ListView_SetItem (hwndLV, &lvI) ;
		} else {
			nItem		= ListView_InsertItem (hwndLV, &lvI) ;
		}
		ListView_SetItemText (hwndLV, nItem, 0, pNewNode->m_rszHost) ;
		wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT("%d"), pNewNode->m_nPort) ;
		szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
		ListView_SetItemText (hwndLV, nItem, 1, szBuffer) ;
		return	TRUE ;
	}
	case	IDC_BUTTON_REMOVE:
	{
		if (pNode == NULL)
			break;	// return	FALSE ;
		ListView_DeleteItem (hwndLV, nItem) ;
		dlgDictionary_vUnregisterHostAndPort (pNode, &pArg->m_plstHost) ;
		return	TRUE ;
	}
//	default:
//		return	FALSE ;
	}
//	return	TRUE ;
	return	FALSE ;
}

/*=================================================================================
 *	Dialog Function for IDD_EDIT_HOSTPORT
 */
INT_PTR CALLBACK
dlgEditHostPortProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	struct THostAndPort*	pArg ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		HWND	hwndEditHost, hwndEditPort ;
		TCHAR	szBuffer [32] ;

		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
		pArg			= (struct THostAndPort*) lParam ;
		hwndEditHost	= GetDlgItem (hDlg, IDC_EDIT_HOSTNAME) ;
		hwndEditPort	= GetDlgItem (hDlg, IDC_EDIT_PORTNUM) ;
		if (pArg == NULL || hwndEditHost == NULL || hwndEditPort == NULL)
			break ;
		SendMessage   (hwndEditHost, EM_LIMITTEXT, (WPARAM) MAX_PATH, 0) ;
		SetWindowText (hwndEditHost, pArg->m_rszHost) ;
		SendMessage   (hwndEditPort, EM_LIMITTEXT, (WPARAM) 32, 0) ;
		wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, TEXT ("%d"), pArg->m_nPort) ;
		szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
		SetWindowText (hwndEditPort, szBuffer) ;
		return	(INT_PTR) TRUE ;
	}
	case	WM_COMMAND:
		switch (LOWORD (wParam)) {
		case	IDOK:
			pArg	= (struct THostAndPort*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				BOOL	fSuccess ;
				UINT	uVal ;

				GetDlgItemText (hDlg, IDC_EDIT_HOSTNAME, pArg->m_rszHost, MAX_PATH) ;
				uVal	= GetDlgItemInt  (hDlg, IDC_EDIT_PORTNUM,  &fSuccess, TRUE) ;
				if (fSuccess)
					pArg->m_nPort	= (int)uVal ;
			} else {
				wParam	= IDCANCEL ;
			}
			/*	fall through */
		case	IDCANCEL:
			EndDialog (hDlg, (INT_PTR)LOWORD (wParam)) ;
			return	(INT_PTR) 0 ;
		default:
			break ;
		}
		return	(INT_PTR) 1 ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*=================================================================================
 *	Dialog Function for IDD_EDIT_FILEJISYO
 */
INT_PTR	CALLBACK
dlgEditFileJisyoProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	struct TEditJisyoArg*	pArg ;
	HWND	hwndEditPath ;

	switch (uMsg) {
	case	WM_INITDIALOG:
	{
		struct TJisyoNode*	pInitValue ;
		UINT	uCheck ;

		SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
		pArg			= (struct TEditJisyoArg*) lParam ;
		hwndEditPath	= GetDlgItem (hDlg, IDC_EDIT_FILE_DICT_PATH) ;
		if (pArg == NULL || hwndEditPath == NULL)
			break ;
		SendMessage   (hwndEditPath, EM_LIMITTEXT, (WPARAM) MAX_PATH, 0) ;

		pInitValue	= pArg->m_pInitValue ;
		SetWindowText (hwndEditPath, (pInitValue != NULL)? pInitValue->m_File.m_rszPath : TEXT ("")) ;
		uCheck	= (pInitValue != NULL && pInitValue->m_File.m_bSorted)? BST_CHECKED : BST_UNCHECKED ;
		CheckDlgButton (hDlg, IDC_CHECK_FILE_DICT_SORTEDP, uCheck) ;
		return	TRUE ;
	}
	case	WM_COMMAND:
	{
		WORD	wNotifyCode	= HIWORD (wParam) ;
		WORD	wID			= LOWORD (wParam) ;
		/*HWND	hwndCtl		= (HWND) lParam ;*/

		switch (wID) {
		case	IDC_BUTTON_BROWSE_FILE_DICT_PATH:
		{
			OPENFILENAME	ofn ;
			TCHAR			szPath [MAX_PATH + 1] ;

			pArg	= (struct TEditJisyoArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg == NULL)
				break ;

			if (wNotifyCode == BN_CLICKED) {
				GetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, szPath, MAX_PATH) ;
				szPath [MAX_PATH]	= TEXT ('\0') ;
				memset (&ofn, 0, sizeof (ofn)) ;
				ofn.lStructSize			= sizeof (OPENFILENAME) ;
				ofn.hwndOwner			= hDlg ;
				ofn.hInstance			= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
				ofn.lpstrFilter			= TEXT ("All\0*.*\0") ;
				ofn.lpstrCustomFilter	= NULL ;
				ofn.nFilterIndex		= 1 ;
				ofn.lpstrFile			= szPath ;
				ofn.nMaxFile			= MAX_PATH ;
				ofn.lpstrFileTitle		= NULL ;
				ofn.lpstrInitialDir		= TEXT ("") ;
				ofn.lpstrTitle			= TEXT ("�����t�@�C���̑I��") ;
				ofn.Flags				= OFN_HIDEREADONLY | OFN_LONGNAMES | OFN_NONETWORKBUTTON | OFN_PATHMUSTEXIST ;
				ofn.lpstrDefExt			= NULL ;
				ofn.lpfnHook			= NULL ;
				if (GetOpenFileName (&ofn) != 0)
					SetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, szPath) ;
			}
			return	0 ;
		}
		case	IDOK:
		{
			pArg			= (struct TEditJisyoArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
			if (pArg != NULL) {
				if (IsDlgButtonChecked (hDlg, IDC_CHECK_FILE_DICT_SORTEDP) == BST_CHECKED) {
					pArg->m_bAuxJisyoSorted	= TRUE ;
				} else {
					pArg->m_bAuxJisyoSorted	= FALSE ;
				}
				GetDlgItemText (hDlg, IDC_EDIT_FILE_DICT_PATH, pArg->m_rszJisyoPath, MAX_PATH) ;
			} else {
				wParam	= IDCANCEL ;
			}
		}
		/*	fall through */
		case	IDCANCEL:
			EndDialog (hDlg, (INT_PTR) wID) ;
			return	0 ;
		default:
			break ;
		}
		return	1 ;
	}
	default:
		break ;
	}
	return	FALSE ;
}

/*=================================================================================
 *	Dialog Function for IDD_EDIT_USERJISYO
 */
INT_PTR	CALLBACK
dlgEditUserJisyoProc (
	HWND		hDlg,
	UINT		uMsg,
	WPARAM		wParam,
	LPARAM		lParam)
{
	struct TEditJisyoArg*	pArg ;

	switch (uMsg) {
	case	WM_INITDIALOG:
		{
			struct TJisyoNode*	pInitValue ;
			int					iCheckedRadio ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

			iCheckedRadio	= IDC_RADIO_ENABLE ;
			pArg			= (struct TEditJisyoArg*) lParam ;
			if (pArg != NULL) {
				pInitValue	= pArg->m_pInitValue ;
				if (pInitValue != NULL && (pInitValue->m_nType == JISYOTYPE_USER || pInitValue->m_nType == JISYOTYPE_OKURI)) {
					iCheckedRadio	= pInitValue->m_User.m_bEnabled? IDC_RADIO_ENABLE : IDC_RADIO_DISABLE ;
				}
			}
			CheckRadioButton (hDlg, IDC_RADIO_ENABLE, IDC_RADIO_DISABLE, iCheckedRadio) ;
		}
		return	TRUE ;
	case	WM_COMMAND:
		{
			/*WORD	wNotifyCode	= HIWORD (wParam) ;*/
			WORD	wID			= LOWORD (wParam) ;
			/*HWND	hwndCtl		= (HWND) lParam ;*/

			switch (wID) {
			case	IDC_RADIO_ENABLE:
			case	IDC_RADIO_DISABLE:
				{
					pArg	= (struct TEditJisyoArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
					if (pArg != NULL) {
						pArg->m_bAuxJisyo	= (wID == IDC_RADIO_ENABLE) ;
					}
					CheckRadioButton (hDlg, IDC_RADIO_ENABLE, IDC_RADIO_DISABLE, wID) ;
				}
				return	0 ;

			case	IDOK:
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR)wID) ;
				return	0 ;

			default:
				break ;
			}
		}
		return	1 ;
	default:
		break ;
	}
	return	FALSE ;
}


/*=================================================================================
 *	private functions
 */
BOOL
dlgDictionary_bSetDictionaryItemText (
	HWND				hwndLV,
	int					nItem,
	struct TJisyoNode*	pNode)
{
	TCHAR	rszBuffer [256] ;
	LPTSTR	strJisyo ;
	LPTSTR	strArg ;

	if (hwndLV == NULL || nItem < 0 || pNode == NULL)
		return	FALSE ;

	switch (pNode->m_nType) {
	case	JISYOTYPE_SERVER:
		strJisyo	= TEXT ("�T�[�o����") ;
		dlgDictionary_bHostlist2string (rszBuffer, ARRAYSIZE (rszBuffer), pNode->m_Server.m_plstHost) ;
		strArg		= rszBuffer ;
		break ;
	case	JISYOTYPE_FILE:
		strJisyo	= (pNode->m_File.m_bSorted)? TEXT ("�\�[�g�ς݃t�@�C������") : TEXT ("�t�@�C������") ;
		strArg		= pNode->m_File.m_rszPath ;
		break ;
	case	JISYOTYPE_USER:
		strJisyo	= TEXT ("���[�U����") ;
		strArg		= pNode->m_User.m_bEnabled? TEXT ("�L��") : TEXT ("����") ;
		break ;
	case	JISYOTYPE_OKURI:
		strJisyo	= TEXT ("���[�U����(��������)") ;
		strArg		= pNode->m_User.m_bEnabled? TEXT ("�L��") : TEXT ("����") ;
		break ;
	default:
		return	FALSE ;
	}
	ListView_SetItemText (hwndLV, nItem, 0, strJisyo) ;
	ListView_SetItemText (hwndLV, nItem, 1, strArg) ;
	return	TRUE ;
}

struct THostAndPort*
dlgDictionary_pCopyPortAndHostList (
	struct THostAndPort*		plstHost)
{
	struct THostAndPort*	pTopNode ;
	struct THostAndPort*	pLastNode ;
	struct THostAndPort*	pNode ;
	struct THostAndPort*	pOrg ;

	pLastNode	= NULL ;
	pOrg		= plstHost ;
	while (pOrg != NULL) {
		pNode	= (struct THostAndPort*) MALLOC (sizeof (struct THostAndPort)) ;
		if (pNode == NULL)
			break ;
		lstrcpyn (pNode->m_rszHost, pOrg->m_rszHost, ARRAYSIZE (pNode->m_rszHost)) ;
		pNode->m_nPort		= pOrg->m_nPort ;
		pNode->m_pNext		= NULL ;
		pNode->m_pPrev		= pLastNode ;
		if (pLastNode != NULL)
			pLastNode->m_pNext	= pNode ;
		pLastNode			= pNode ;
		pOrg				= pOrg->m_pNext ;
	}
	if (pLastNode != NULL) {
		struct THostAndPort*	pPrevNode ;

		pNode	= pLastNode ;
		while (pPrevNode = pNode->m_pPrev, pPrevNode != NULL)
			pNode	= pPrevNode ;
		pTopNode	= pNode ;
	} else {
		pTopNode	= NULL ;
	}
	return	pTopNode ;
}

/*========================================================================
 *	���W�X�g������܂��B
 */
BOOL
dlgDictionary_bInitSearchJisyoList (
	LPCTSTR				pstrSubKey,
	struct TJisyoNode**	pplstSearchJisyo,
	LPTSTR				strUserJisyoPath)
{
	HKEY				hSubKey ;
	TCHAR				szRegPathInfo [MAX_PATH + 1] ;
	TCHAR				rbyData [MAX_REGVALUE_SIZE] ;
	DWORD				dwRegPathInfo, dwType, cbData ;
	struct TJisyoNode*	pNode ;

	*pplstSearchJisyo	= NULL ;

	/*	���W�X�g������ݒ��ǂށB*/
	if (RegOpenKeyEx (HKEY_CURRENT_USER, pstrSubKey, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		int		nIndex ;
		int		nDict ;
		LONG	lResult ;

		for (nIndex = 0 ; nIndex < (WORD)-1 ; nIndex ++) {
			dwRegPathInfo	= ARRAYSIZE (szRegPathInfo) ;
			cbData			= ARRAYSIZE (rbyData) ;
			lResult	= RegEnumValue (hSubKey, (DWORD)nIndex, szRegPathInfo, &dwRegPathInfo, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			if (dlgDictionary_bParseJisyoNumber (szRegPathInfo, &nDict)) {
				/*	nDict �����������ԍ��B*/
				lResult	= RegQueryValueEx (hSubKey, szRegPathInfo, NULL, &dwType, NULL, &cbData) ;
				if (lResult != ERROR_SUCCESS || dwType != REG_SZ)
					continue ;
				/*	Too big value. */
				if (cbData >= sizeof (rbyData))
					continue ;
				cbData	= sizeof (rbyData) ;
				(void) RegQueryValueEx (hSubKey, szRegPathInfo, NULL, NULL, (BYTE *)rbyData, &cbData) ;

				pNode	= dlgDictionary_bParseJisyoSetting (rbyData, nDict) ;
				if (pNode != NULL)
					dlgDictionary_bInsertJisyoInSearchList (pplstSearchJisyo, pNode) ;
			}
		}

		lResult	= RegQueryValueEx (hSubKey, REGKEY_USERJISYO, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS || (dwType != REG_SZ && dwType != REG_EXPAND_SZ) || cbData > sizeof (TCHAR) * MAX_PATH) {
			lstrcpy (strUserJisyoPath, SKKIME_DEFAULT_USERJISYO) ;
		} else {
			cbData	= MAX_PATH ;
			RegQueryValueEx (hSubKey, REGKEY_USERJISYO, NULL, &dwType, (BYTE *)strUserJisyoPath, &cbData) ;
			strUserJisyoPath [MAX_PATH]	= TEXT ('\0') ;
		}
		RegCloseKey (hSubKey) ;
		return	TRUE ;
	}
	return	FALSE ;
}

void
dlgDictionary_vInitDefaultSearchJisyoList (
	struct TJisyoNode**	pplstSearchJisyo,
	LPTSTR				strUserJisyoPath)
{
	static LPCTSTR		srDefaultJisyos []	= {
		SKKIME_DEFAULT_JISYO_SETTING1,
		SKKIME_DEFAULT_JISYO_SETTING2,
	} ;
	struct TJisyoNode*	pNode ;
	int					i ;

	/*	�f�t�H���g�̐ݒ������B
	 *	�f�t�H���g�̐ݒ�ł́A���[�U�����̌������擪�ɁA
	 *	�����đ��艼���̓��ꌟ�� (auto-okuri-process �ł̂ݎg����) �����ԁB
	 */
	for (i = 0 ; i < ARRAYSIZE (srDefaultJisyos) ; i ++) {
		pNode	= dlgDictionary_bParseJisyoSetting (srDefaultJisyos [i], i) ;
		if (pNode == NULL)
			return ;
		dlgDictionary_bInsertJisyoInSearchList (pplstSearchJisyo, pNode) ;
	}

	/*	���[�U�����̃p�X�̓f�t�H���g�́A
	 *		%USERPROFILE%\Application Data\skk\skki1_0\skki1_0u.dic
	 *	�ł���B �� �ς����B�G�N�X�|�[�g�@�\�����܂ł͂Ȃ�ׂ��󂢈ʒu�ɒu���ق����g���₷���B
	 */
	lstrcpy (strUserJisyoPath, SKKIME_DEFAULT_USERJISYO) ;
	return ;
}

void
dlgDictionary_vDestroyJisyoList (
	struct TJisyoNode**	pplstSearchJisyo)
{
	struct TJisyoNode*	pNode ;
	struct TJisyoNode*	pNextNode ;

	pNode	= *pplstSearchJisyo ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		dlgDictionary_vDestroyJisyo (pNode) ;
		pNode		= pNextNode ;
	}
	*pplstSearchJisyo	= NULL ;
	return ;
}

BOOL
dlgDictionary_bUpdateSearchJisyoList (
	LPCTSTR				pstrSubKey,
	struct TJisyoNode*	plstSearchJisyo,
	LPCTSTR				strUserJisyoPath)
{
	TCHAR					rbufTemp [MAX_PATH + 1] ;
	TCHAR					szData [MAX_REGVALUE_SIZE] ;
	HKEY					hSubKey ;
	BOOL					fRetval	= TRUE ;
	struct TJisyoNode*		pNode ;
	int						nLength, nDest, nDict ;
	LPCTSTR					strFormat ;
	LPTSTR					pDest ;
	struct THostAndPort*	pHostPortNode ;

	if (! bCreateRegistryKey (pstrSubKey, TRUE, &hSubKey)) {
		return	FALSE ;
	}

	pNode	= plstSearchJisyo ;
	nDict	= 0 ;
	while (pNode != NULL) {
		pDest	= szData ;
		nDest	= ARRAYSIZE (szData) ;
		switch (pNode->m_nType) {
		case	JISYOTYPE_USER:
			if (pNode->m_User.m_bEnabled) {
				lstrcpy (pDest, TEXT ("user=enable")) ;
				pDest	+= 11 ;	/* lstrlen ("user=enable") == 11 */
				nDest	-= 11 ;
			} else {
				lstrcpy (pDest, TEXT ("user=disable")) ;
				pDest	+= 12 ;	/* lstrlen ("user=disable") == 12 */
				nDest	-= 12 ;
			}
			break ;
		case	JISYOTYPE_OKURI:
			if (pNode->m_User.m_bEnabled) {
				lstrcpy (pDest, TEXT ("okuri=enable")) ;
				pDest	+= 12 ;	/* lstrlen ("okuri=enable") == 12 */
				nDest	-= 12 ;
			} else {
				lstrcpy (pDest, TEXT ("okuri=disable")) ;
				pDest	+= 13 ;	/* lstrlen ("okuri=disable") == 13 */
				nDest	-= 13 ;
			}
			break ;
		case	JISYOTYPE_SERVER:
			lstrcpy (pDest, TEXT ("server=")) ;
			pDest	+= 7 ;	/* lstrlen ("server=") == 7 */
			nDest	-= 7 ;
			pHostPortNode	= pNode->m_Server.m_plstHost ;
			strFormat		= TEXT ("%d/%s") ;
			while (pHostPortNode != NULL) {
				if (pHostPortNode->m_nPort >= 0 &&
					pHostPortNode->m_rszHost [0] != TEXT ('\0') &&
					lstrlen (pHostPortNode->m_rszHost) < (MAX_PATH - 16)) {
					nLength	= wnsprintf (rbufTemp, ARRAYSIZE (rbufTemp) - 1, strFormat, pHostPortNode->m_nPort, pHostPortNode->m_rszHost) ;
					rbufTemp [nLength]	= TEXT ('\0') ;
					if (nDest > nLength) {
						lstrcpy (pDest, rbufTemp) ;
						pDest		+= nLength ;
						nDest		-= nLength ;
						strFormat	= TEXT (",%d/%s") ;
					} else {
						/* ����ȏ�ۑ��ł��Ȃ��Ǝv���Ə����𔲂���B*/
						break ;
					}
				}
				pHostPortNode	= pHostPortNode->m_pNext ;
			}
			/*	�⏕�����̐ݒ�͂��邩�H */
			if (pNode->m_Server.m_rszAuxJisyoPath [0] != TEXT ('\0')) {
				nLength	= lstrlen (pNode->m_Server.m_rszAuxJisyoPath) ;
				if (nDest > (nLength + 8)) {	/* lstrlen (",aux:??=") == 8 */
					lstrcpy (pDest, TEXT (",aux:")) ;
					pDest	+= 5 ;
					*pDest	++ = (TCHAR)((pNode->m_Server.m_bAuxJisyoSorted)? TEXT ('s') : TEXT ('f')) ;
					*pDest	++ = (TCHAR)((pNode->m_Server.m_bAuxJisyo)?       TEXT ('e') : TEXT ('d')) ;
					*pDest	++ = TEXT ('=') ;
					nDest	-= 8 ;
					lstrcpy (pDest, pNode->m_Server.m_rszAuxJisyoPath) ;
					pDest	+= nLength ;
					nDest	-= nLength ;
				}
			}
			break ;
		case	JISYOTYPE_FILE:
			if (pNode->m_File.m_bSorted) {
				lstrcpy (pDest, TEXT ("sort=")) ;
			} else {
				lstrcpy (pDest, TEXT ("file=")) ;
			}
			pDest	+= 5 ;	/* lstrlen ("sort=") == 5 && lstrlen ("file=") == 5 */
			nDest	-= 5 ;
			nLength	= lstrlen (pNode->m_File.m_rszPath) ;
			if ((nLength + (pDest - szData) + 1) >= MAX_REGVALUE_SIZE) {
				goto	skip ;
			}
			lstrcpy (pDest, pNode->m_File.m_rszPath) ;
			pDest	+= nLength ;
			nDest	-= nLength ;
			break ;
		default:
			goto	skip ;
		}
		nLength	= wnsprintf (rbufTemp, ARRAYSIZE (rbufTemp) - 1, REGKEY_ENTRY, nDict) ;
		rbufTemp [nLength]	= TEXT ('\0') ;
		if (RegSetValueEx (hSubKey, rbufTemp, 0, REG_SZ, (BYTE *)szData, sizeof (TCHAR) * (DWORD)((pDest - szData) + 1)) != ERROR_SUCCESS) {
			fRetval	= FALSE ;
		} else {
			fRetval	= TRUE ;
		}
		nDict	++ ;
	skip:
		pNode	= pNode->m_pNext ;
	}

	nLength	= lstrlen (strUserJisyoPath) ;
	if (nLength > 0) {
		if (RegSetValueEx (hSubKey, REGKEY_USERJISYO, 0, REG_SZ, (BYTE *)strUserJisyoPath, sizeof (TCHAR) * (nLength + 1)) != ERROR_SUCCESS) {
			fRetval	= FALSE ;
		}
	}
	RegCloseKey (hSubKey) ;
	return	fRetval ;
}

BOOL
dlgDictionary_bParseJisyoNumber (
	LPCTSTR		pstrString,
	int*		pnDict)
{
	int	nValue ;

	if (_tcsncmp (pstrString, TEXT ("Dict"), 4))
		return	FALSE ;

	pstrString	+= 4 ;
	if (*pstrString == TEXT ('\0'))
		return	FALSE ;

	nValue	= 0 ;
	while (*pstrString != TEXT ('\0')) {
		if (! (TEXT ('0') <= *pstrString && *pstrString <= TEXT ('9')))
			return	FALSE ;
		nValue	= nValue * 10 + (*pstrString - TEXT ('0')) ;
		if (nValue < 0)
			return	FALSE ;
		pstrString	++ ;
	}
	*pnDict	= nValue ;
	return	TRUE ;
}

/*	�����̐ݒ蕶����͎��̒ʂ�ł���F
 *		�T�[�o�����̏ꍇ�Aserver=port1/host1,port2/host2,aux=aux-dictionarypath
 *		(����͍Ō�̗v�f)
 *		���[�U�����̏ꍇ�Auser=(�����͂Ȃ�)
 *		���̑������t�@�C���Afile=path
 *
 *	aux:??= �Ɖ��ρBaux:s �� sort ����Ă���Baux:f �ł����� file�Baux:e �� enable �ŁA
 *	aux:d �� disable�B�g�ݍ��킹�ł́A
 *		(s or f) and (e or d) �ɂȂ�B
 *	aux:se �Ƃ� aux:fe �Ƃ� aux:sd �Ƃ� aux:fd �Ƃ��B
 */
struct TJisyoNode*
dlgDictionary_bParseJisyoSetting (
	LPCTSTR		pstrSetting,
	int			nIndex)
{
	struct TJisyoNode*	pNode	= NULL ;

	if (! _tcsncmp (pstrSetting, TEXT ("server="), 7)) {
		LPCTSTR				ptr	;
		LPCTSTR				pStart ;
		LPCTSTR				pAuxPath		= NULL ;
		int					nServer ;
		struct THostAndPort*	pHostPortNode ;
		struct THostAndPort*	plstHostPort	= NULL ;
		BOOL				fEnableAuxJisyo	= FALSE ;
		BOOL				fSortedAuxJisyo	= FALSE ;

		nServer	= 0 ;
		pStart	= pstrSetting + 7 ;
		while (*pStart != TEXT ('\0')) {
			ptr		= pStart ;
			while (*ptr != TEXT ('\0') && *ptr != TEXT (','))
				ptr	++ ;
			/*	�⏕�����̐ݒ肪���t�������ꍇ�A����ɑ����T�[�o��
			 *	�ݒ�͑��݂��Ȃ��B*/
			if (! _tcsncmp (pStart, TEXT ("aux:"), 4)) {
				pStart		+= 4 ;
				if (*pStart == TEXT('s') || *pStart == TEXT('f')) {
					fSortedAuxJisyo	= (*pStart == TEXT('s'))? TRUE : FALSE ;
					pStart	++ ;
				}
				if (*pStart == TEXT('e') || *pStart == TEXT('d')) {
					fEnableAuxJisyo	= (*pStart == TEXT ('e'))? TRUE : FALSE ;
					pStart	++ ;
				}
				/*	���̏ꍇ�ɂ̓G���[�B����̓V�r�A�B*/
				if (*pStart == TEXT('=')) {
					pAuxPath	= pStart + 1 ;
				} else {
					pAuxPath	= NULL ;
				}
				break ;
			}
			/*	port/host �̃T�[�o�̐ݒ�𔲂��o���B*/
			pHostPortNode	= dlgDictionary_pParsePortAndHost (pStart, ptr - pStart) ;
			if (pHostPortNode != NULL) {
				pHostPortNode->m_pNext	= plstHostPort ;
				if (plstHostPort != NULL)
					plstHostPort->m_pPrev	= pHostPortNode ;
				plstHostPort			= pHostPortNode ;
			}
			if (*ptr == TEXT ('\0'))
				break ;
			pStart	= ptr + 1 ;
		}
		pNode	= dlgDictionary_pNewJisyoNode (JISYOTYPE_SERVER, pAuxPath) ;
		if (pNode != NULL) {
			pNode->m_Server.m_bAuxJisyo			= fEnableAuxJisyo ;
			pNode->m_Server.m_bAuxJisyoSorted	= fSortedAuxJisyo ;
			pNode->m_Server.m_plstHost			= plstHostPort ;
		} else {
			/* plstHostPort ��j���B*/
		}
	} else if (! _tcsncmp (pstrSetting, TEXT ("user="),  5) ||
			   ! _tcsncmp (pstrSetting, TEXT ("okuri="), 6)) {
		BOOL	bOkuri ;
		BOOL	bEnabled ;

		bOkuri	= ! _tcsncmp (pstrSetting, TEXT ("okuri="), 6)? TRUE : FALSE ;
		pNode	= dlgDictionary_pNewJisyoNode (bOkuri? JISYOTYPE_OKURI : JISYOTYPE_USER, NULL) ;
		pstrSetting	+= 5 ;
		if (*pstrSetting == TEXT ('\0')) {
			bEnabled	= TRUE ;
		} else {
			bEnabled	= _tcsncmp (pstrSetting, TEXT ("disable"), 7) != 0? TRUE : FALSE ;
		}
		pNode->m_User.m_bEnabled	= bEnabled ;
	} else if (! _tcsncmp (pstrSetting, TEXT ("file="), 5) ||
			   ! _tcsncmp (pstrSetting, TEXT ("sort="), 5)) {
		BOOL	bSorted ;

		bSorted	= _tcsncmp (pstrSetting, TEXT ("sort="), 5) ? FALSE : TRUE ;

		pstrSetting	+= 5 ;
		if (*pstrSetting == TEXT ('\0'))
			return	NULL ;

		pNode	= dlgDictionary_pNewJisyoNode (JISYOTYPE_FILE, pstrSetting) ;
		if (pNode != NULL)
			pNode->m_File.m_bSorted	= bSorted ;
	}
	if (pNode != NULL) {
		pNode->m_nIndex		= nIndex ;
		pNode->m_pNext		= NULL ;
		pNode->m_pPrev		= NULL ;
	}
	return	pNode ;
}

struct THostAndPort*
dlgDictionary_pParsePortAndHost (
	 LPCTSTR		pstrPortAndHost,
	 int			nPortAndHost)
{
	 LPCTSTR	ptr		= pstrPortAndHost ;
	 int		nPort	= 0 ;
	 LPCTSTR	pHostname ;
	 int		nHostnameLen ;

	if (*ptr != TEXT ('/')) {
		while (nPortAndHost > 0 && *ptr != TEXT ('/')) {
			if (! (TEXT ('0') <= *ptr && *ptr <= TEXT ('9')))
				return	NULL ;
			nPort	= nPort * 10 + (*ptr - TEXT ('0')) ;
			ptr				++ ;
			nPortAndHost	-- ;
		}
		if (nPort < 0 || nPort >= 65536)
			return	NULL ;
	} else {
		nPort	= SKKSERV_DEFAULT_PORTNUM ;
	}
	if (nPortAndHost <= 0 || *ptr != TEXT ('/'))
		return	NULL ;

	/*	"/" ��ǂݔ�΂��B*/
	nPortAndHost	-- ;
	ptr				++ ;

	nHostnameLen	= nPortAndHost ;
	pHostname		= ptr ;
	if (nHostnameLen <= 0)
		return	NULL ;

	/*	�ȉ��A�S�āA�ƌ��������Ƃ��낾���Ahostname �Ƃ��ĕs�K�؂ȕ���
	 *	������Ύ̂Ă����Ă��炤�B�^�ʖڂȃp�[�Y�͂��Ȃ��B
	 *	host part �ɗ��p�\�ȕ����� HTTP-URL �� RFC ���Q�l�ɂ��Ă���B*/
	while (nPortAndHost > 0 &&
		   ((TEXT ('0') <= *ptr && *ptr <= TEXT ('9')) ||
			(TEXT ('a') <= *ptr && *ptr <= TEXT ('z')) ||
			(TEXT ('A') <= *ptr && *ptr <= TEXT ('Z')) ||
			*ptr == TEXT ('-') ||
			*ptr == TEXT ('.'))) {
		ptr				++ ;
		nPortAndHost	-- ;
	}
	if (nPortAndHost != 0)
		return	NULL ;

	return	dlgDictionary_pNewPortAndHostNode (pHostname, nHostnameLen, nPort) ;
}

BOOL
dlgDictionary_bInsertJisyoInSearchList (
	struct TJisyoNode**	plstTop,
	struct TJisyoNode*	pNewNode)
{
	struct TJisyoNode*	pNode ;
	struct TJisyoNode*	pPrevNode ;

	pNode		= *plstTop ;
	pPrevNode	= NULL ;
	while (pNode != NULL && pNode->m_nIndex < pNewNode->m_nIndex) {
		pPrevNode	= pNode ;
		pNode		= pNode->m_pNext ;
	}
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext	= pNewNode ;
	} else {
		*plstTop			= pNewNode ;
	}
	pNewNode->m_pPrev	= pPrevNode ;
	pNewNode->m_pNext	= pNode ;
	if (pNode != NULL)
		pNode->m_pPrev	= pNewNode ;
	return	TRUE ;
}

struct TJisyoNode*
dlgDictionary_pNewJisyoNode (
	int			nType,
	LPCTSTR		strPath)
{
	struct TJisyoNode*	pNode ;

	pNode	= (struct TJisyoNode*) MALLOC (sizeof (struct TJisyoNode)) ;
	if (pNode == NULL)
		return	NULL ;

	pNode->m_nType		= nType ;
	pNode->m_nIndex		= 0 ;
	pNode->m_pPrev		= NULL ;
	pNode->m_pNext		= NULL ;

	switch (nType) {
	case	JISYOTYPE_USER:
	case	JISYOTYPE_OKURI:
		break ;
	case	JISYOTYPE_FILE:
		if (strPath != NULL) {
			lstrcpyn (pNode->m_File.m_rszPath, strPath, ARRAYSIZE (pNode->m_File.m_rszPath)) ;
		} else {
			pNode->m_File.m_rszPath [0]	= TEXT ('\0') ;
		}
		pNode->m_File.m_bSorted	= FALSE ;
		break ;
	case	JISYOTYPE_SERVER:
		pNode->m_Server.m_plstHost	= NULL ;
		if (strPath != NULL) {
			lstrcpyn (pNode->m_Server.m_rszAuxJisyoPath, strPath, ARRAYSIZE (pNode->m_Server.m_rszAuxJisyoPath)) ;
		} else {
			pNode->m_Server.m_rszAuxJisyoPath [0]	= TEXT ('\0') ;
		}
		pNode->m_Server.m_bAuxJisyo			= FALSE ;
		pNode->m_Server.m_bAuxJisyoSorted	= FALSE ;
		break ;
	default:
		break ;
	}
	return	pNode ;
}

void
dlgDictionary_vRegisterJisyo (
	struct TJisyoNode**		plstTop,
	struct TJisyoNode*		pNode,
	struct TJisyoNode*		pPrevNode)
{
	struct TJisyoNode*	pNextNode ;

	if (pNode == NULL || plstTop == NULL)
		return ;

	if (pPrevNode == NULL) {
		pNextNode				= *plstTop ;
		pNode->m_pNext			= pNextNode ;
		*plstTop				= pNode ;
		pNode->m_pPrev			= NULL ;
	} else {
		pNextNode				= pPrevNode->m_pNext ;
		pPrevNode->m_pNext		= pNode ;
		pNode->m_pNext			= pNextNode ;
		pNode->m_pPrev			= pPrevNode ;
	}
	if (pNextNode != NULL)
		pNextNode->m_pPrev		= pNode ;
	return ;
}

void
dlgDictionary_vUnregisterJisyo (
	struct TJisyoNode**		plstTop,
	struct TJisyoNode*		pNode)
{
	struct TJisyoNode*	pPrevNode ;
	struct TJisyoNode*	pNextNode ;

	if (pNode == NULL || plstTop == NULL)
		return ;
	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode != NULL) {
		pPrevNode->m_pNext		= pNextNode ;
	} else {
		// pNode == slstSkkinputSearchJisyo
		*plstTop				= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev		= pPrevNode ;
	}
	pNode->m_pPrev	= NULL ;
	pNode->m_pNext	= NULL ;
	return ;
}

void
dlgDictionary_vDestroyJisyo (
	struct TJisyoNode*		pNode)
{
	if (pNode == NULL)
		return ;
	if (pNode->m_nType == JISYOTYPE_SERVER && pNode->m_Server.m_plstHost != NULL) {
		dlgDictionary_vDeleteHostList (pNode->m_Server.m_plstHost) ;
		pNode->m_Server.m_plstHost	= NULL ;
	}
	FREE (pNode) ;
	return ;
}

void
dlgDictionary_vDeleteHostList (
	struct THostAndPort*	lstHost)
{
	struct THostAndPort*	pNode ;
	struct THostAndPort*	pNextNode ;

	pNode	= lstHost ;
	while (pNode != NULL) {
		pNextNode	= pNode->m_pNext ;
		FREE (pNode) ;
		pNode		= pNextNode ;
	}
	return ;
}

struct THostAndPort*
dlgDictionary_pNewPortAndHostNode (
	LPCTSTR		strHost,
	int			nHost,
	int			nPort)
{
	struct THostAndPort*	pNode ;
	int		nHostLen ;

	pNode				= (struct THostAndPort*) MALLOC (sizeof (struct THostAndPort)) ;
	if (pNode == NULL)
		return	NULL ;

	pNode->m_pPrev		= NULL ;
	pNode->m_pNext		= NULL ;
	nHostLen			= (nHost > ARRAYSIZE (pNode->m_rszHost)-1)? (ARRAYSIZE (pNode->m_rszHost) - 1) : nHost ;
#if defined (_MSC_VER) && (_MSC_VER >= 1400) && !defined (WIN64)
	_tcsncpy_s (pNode->m_rszHost, ARRAYSIZE (pNode->m_rszHost), strHost, nHostLen) ;
#else
	_tcsncpy (pNode->m_rszHost, strHost, nHostLen) ;
#endif
	pNode->m_rszHost [nHostLen]	= TEXT ('\0') ;
	pNode->m_nPort		= nPort ;
	return	pNode ;
}

void
dlgDictionary_vRegisterHostAndPort (
	struct THostAndPort*	pNode,
	struct THostAndPort**	plstPortAndHost,
	struct THostAndPort*	pPrevNode)
{
	struct THostAndPort*	pNextNode ;

	if (pNode == NULL || plstPortAndHost == NULL)
		return ;
	if (pPrevNode == NULL) {
		pNextNode			= *plstPortAndHost ;
		*plstPortAndHost	= pNode ;
	} else {
		pNextNode			= pPrevNode->m_pNext ;
		pPrevNode->m_pNext	= pNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pNode ;
	}
	pNode->m_pPrev			= pPrevNode ;
	pNode->m_pNext			= pNextNode ;
	return ;
}

void
dlgDictionary_vUnregisterHostAndPort (
	struct THostAndPort*	pNode,
	struct THostAndPort**	plstPortAndHost)
{
	struct THostAndPort*	pPrevNode ;
	struct THostAndPort*	pNextNode ;

	if (pNode == NULL || plstPortAndHost == NULL)
		return ;
	pPrevNode	= pNode->m_pPrev ;
	pNextNode	= pNode->m_pNext ;
	if (pPrevNode == NULL) {
		*plstPortAndHost	= pNextNode ;
	} else {
		pPrevNode->m_pNext	= pNextNode ;
	}
	if (pNextNode != NULL) {
		pNextNode->m_pPrev	= pPrevNode ;
	}
	pNode->m_pPrev	= NULL ;
	pNode->m_pNext	= NULL ;
	return ;
}

BOOL
dlgDictionary_bHostlist2string (
	LPTSTR					pDest,
	int						nDest,
	struct THostAndPort*	plstHost)
{
	struct THostAndPort*	pNode ;
	LPCTSTR		pszFmt ;
	TCHAR		szBuffer [256] ;
	int			nLength ;

	pNode	= plstHost ;
	pszFmt	= TEXT ("%s/%d") ;
	while (pNode != NULL) {
		/*	32bit integer �� 10 �i�ŕ\��������10��������Α��v�H
		 *	16bit -> 65536 < 70000, 70000^2 = 4900000000 -> 10���B�}�C�i�X��
		 *	�\�������� 11�����B
		 *	3 �� " ,/" ��3�����B
		 */
		if (lstrlen (pNode->m_rszHost) < (256 - 11 - 3) &&
			pNode->m_nPort >= 0) {
			nLength	= wnsprintf (szBuffer, ARRAYSIZE (szBuffer) - 1, pszFmt, pNode->m_rszHost, pNode->m_nPort) ;
			szBuffer [nLength]	= TEXT ('\0') ;
			if (nDest < nLength) {
				memcpy (pDest, szBuffer, sizeof (TCHAR) * nLength) ;
				pDest	+= nLength ;
				nDest	-= nLength ;
				*pDest	= TEXT ('\0') ;
				pszFmt	= TEXT (", %s/%d") ;
			} else {
				memcpy (pDest, szBuffer, sizeof (TCHAR) * (nDest - 1)) ;
				*(pDest + nDest - 1)	= TEXT ('\0') ;
				break ;
			}
		}
		pNode	= pNode->m_pNext ;
	}
	return	TRUE ;
}


BOOL
dlgDictionary_bMoveSelectedJisyo (
	HWND				hDlg,
	BOOL				fPrev)
{
	HWND				hwndLV ;
	struct TJisyoNode*	pMoveNode ;
	LVITEM				lvI ;
	int					nItem ;
	LVFINDINFO			lvfI ;

	hwndLV			= GetDlgItem (hDlg, IDC_LIST_SEARCHDICT) ;
	if (hwndLV == NULL)
		return	FALSE ;

	memset (&lvI, 0, sizeof (lvI)) ;
	lvI.mask		= LVIF_PARAM ;
	nItem			= ListView_GetSelectionMark (hwndLV) ;
	lvI.iItem		= nItem ;
	if (! ListView_GetItem (hwndLV, &lvI)) {
		return	FALSE ;
	}

	pMoveNode	= (struct TJisyoNode*) lvI.lParam ;
	if (pMoveNode == NULL) {
		return	FALSE ;
	}

	memset (&lvfI, 0, sizeof (lvfI)) ;
	lvfI.flags		= LVFI_PARAM ;
	if (fPrev) {
		if (pMoveNode->m_pPrev != NULL) {
			struct TJisyoNode*	pPrevNode	= pMoveNode->m_pPrev ;
			int		nPrevItem ;

			lvfI.lParam		= (LPARAM) pPrevNode ;
			nPrevItem		= ListView_FindItem (hwndLV, -1, &lvfI) ;
			if (nPrevItem >= 0) {
				dlgDictionary_vUnregisterJisyo (&_plstSearchJisyos, pMoveNode) ;
				dlgDictionary_vRegisterJisyo   (&_plstSearchJisyos, pMoveNode, pPrevNode->m_pPrev) ;

				ListView_DeleteItem (hwndLV, nItem) ;
				memset (&lvI, 0, sizeof (lvI)) ;
				lvI.mask		= LVIF_PARAM ;
				lvI.iItem		= nPrevItem ;
				lvI.lParam		= (LPARAM) pMoveNode ;
				nItem			= ListView_InsertItem (hwndLV, &lvI) ;
				dlgDictionary_bSetDictionaryItemText (hwndLV, nItem, pMoveNode) ;
				ListView_SetSelectionMark (hwndLV, nItem) ;
				ListView_SetItemState (hwndLV, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
			}
		}
	} else {
		if (pMoveNode->m_pNext != NULL) {
			struct TJisyoNode*	pNextNode	= pMoveNode->m_pNext ;
			int		nNextItem ;

			lvfI.lParam		= (LPARAM) pNextNode ;
			nNextItem		= ListView_FindItem (hwndLV, -1, &lvfI) ;
			if (nNextItem >= 0) {
				dlgDictionary_vUnregisterJisyo (&_plstSearchJisyos, pMoveNode) ;
				dlgDictionary_vRegisterJisyo   (&_plstSearchJisyos, pMoveNode, pNextNode) ;

				ListView_DeleteItem (hwndLV, nItem) ;
				memset (&lvI, 0, sizeof (lvI)) ;
				lvI.mask		= LVIF_PARAM ;
				lvI.iItem		= nNextItem ;
				lvI.lParam		= (LPARAM) pMoveNode ;
				nItem			= ListView_InsertItem (hwndLV, &lvI) ;
				dlgDictionary_bSetDictionaryItemText (hwndLV, nItem, pMoveNode) ;
				ListView_SetSelectionMark (hwndLV, nItem) ;
				ListView_SetItemState (hwndLV, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
			}
		}
	}
	return	TRUE ;
}

BOOL
dlgDictionary_bSyncSkkiserv (void)
{
	struct CTPacket		packet ;
	register HANDLE		hPipe ;
	int					nMajor = -1, nMinor, nSize, nRecv ;

	hPipe	= TCommunicateSession_hOpenServer () ;
	if (hPipe == INVALID_HANDLE_VALUE)
		return	FALSE ;

	TPacket_bInitialize (&packet) ;
	if (! TPacket_bSetHeader (&packet, SKKISERV_PROTO_UPDATE, 0) ||
		! TPacket_bSetLength (&packet) ||
		! TCommunicateSession_bSend (hPipe, &packet))
		goto	exit_func ;

	if (! TCommunicateSession_bRecv (hPipe, &packet) ||
		! TPacket_bGetHeader (&packet, &nMajor, &nMinor, &nSize))
		goto	exit_func ;
	nRecv	= TPacket_iGetDataSize (&packet) ;
  exit_func:
	DisconnectNamedPipe (hPipe) ;
	CloseHandle (hPipe) ;
	return	(nMajor == SKKISERV_PROTO_UPDATE_REPLY) ;
}

