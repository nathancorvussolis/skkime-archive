#include "stdafx.h"
#include "skimconf.h"
#include "resource.h"
#include "../common/nfunc.h"
#include "../common/keymask.h"
#include "varbuffer.h"

/*========================================================================
 *	registry definitions
 */
#define	REGPATH_KEYMAP						REGPATH_GENERIC
#define	REGINFO_KEYMAP_TYPE					TEXT("KeymapType")
#define	REGINFO_MAJORMODEMAP				TEXT("MajorModeMap")
#define	REGINFO_JMODEMAP					TEXT("JModeMap")
#define	REGINFO_LATINMODEMAP				TEXT("LatinModeMap")
#define	REGINFO_ZENKAKUMODEMAP				TEXT("Jisx0208LatinModeMap")
#define	REGINFO_ABBREVMODEMAP				TEXT("AbbrevModeMap")
#define	REGINFO_MAJORMODEMAP_EX				TEXT("MajorModeMapEx")
#define	REGINFO_JMODEMAP_EX					TEXT("JModeMapEx")
#define	REGINFO_LATINMODEMAP_EX				TEXT("LatinModeMapEx")
#define	REGINFO_ZENKAKUMODEMAP_EX			TEXT("Jisx0208LatinModeMapEx")
#define	REGINFO_ABBREVMODEMAP_EX			TEXT("AbbrevModeMapEx")

/*	�_�C�A���O�̔z�u�̖��ŁA
 *		- REGINFO_TRYCOMPLETIONKEY_TYPE
 *		- REGINFO_PREVIOUSCOMPLETIONKEY_TYPE
 *		- REGINFO_NEXTCOMPLETIONKEYTYPE
 *	��3��1�܂Ƃ߂Ɉ����B
 *		- skk-kakutei-key,
 *		- skk-previous-candidate-char
 *	�ɂ��ẮA������ skk-insert �̓����ɂ͉B��Ă��Ȃ��̂�
 *	keymap �̑��̐ݒ�ɗ��邱�Ƃɂ���B
 *
 *	(keymap �ŃJ�o�[�ł��Ȃ� skk-insert �̒��ɉB��鑀�삪���)
 */
/*	#define	REGINFO_KAKUTEIKEY_TYPE				TEXT("KakuteiKeyType")
 *	#define	REGINFO_PREVIOUSCANDIDATECHAR_TYPE	TEXT("PreviousCandidateCharType")
 *	#define	REGINFO_KAKUTEIKEY					TEXT("KakuteiKey")
 *	#define	REGINFO_PREVIOUSCANDIDATECHAR		TEXT("PreviousCandidateChar")
 *	keymap �ɗ���̂ŕs�v�B
 */
#define	REGINFO_STARTHENKANKEY_TYPE			TEXT("StartHenkanKeyType")
#define	REGINFO_STARTHENKANKEY				TEXT("StartHenkanKey")
#define	REGINFO_COMPLETIONRELATEDKEY_TYPE	TEXT("CompletionRelatedKeyType")
#define	REGINFO_TRYCOMPLETIONKEY			TEXT("TryCompletionKey")
#define	REGINFO_PREVIOUSCOMPLETIONKEY		TEXT("PreviousCompletionKey")
#define	REGINFO_NEXTCOMPLETIONKEY			TEXT("NextCompletionKey")
#define	REGINFO_SETHENKANPOINTSUBRKEY_TYPE	TEXT("SetHenkanPointSubrKeyType")
#define	REGINFO_SETHENKANPOINTSUBRKEY		TEXT("SetHenkanPointSubrKey")
#define	REGINFO_SPECIALMIDASHICHAR_TYPE		TEXT("SpecialMidashiCharType")
#define	REGINFO_SPECIALMIDASHICHAR			TEXT("SpecialMidashiChar")

#define	REGPATH_ROMAKANARULE				REGPATH_KEYMAP
#define	REGINFO_ROMAKANARULE_TYPE			TEXT("RomaKanaRuleType")
#define	REGINFO_ROMAKANARULE				TEXT("RomaKanaRule")
#define	REGINFO_ROMAKANARULE1				TEXT("RomaKanaRule1")
#define	REGINFO_ROMAKANARULE2				TEXT("RomaKanaRule2")
#define	REGINFO_ROMAKANARULE3				TEXT("RomaKanaRule3")
#define	REGINFO_JISX0201RULE				TEXT("Jisx0201Rule")
#define	REGINFO_JISX0201RULE1				TEXT("Jisx0201Rule1")
#define	REGINFO_JISX0201RULE2				TEXT("Jisx0201Rule2")
#define	REGINFO_JISX0201RULE3				TEXT("Jisx0201Rule3")
#define	REGINFO_JISX0201ROMANRULE			TEXT("Jisx0201RomanRule")
#define	REGINFO_JISX0201ROMANRULE1			TEXT("Jisx0201RomanRule1")
#define	REGINFO_JISX0201ROMANRULE2			TEXT("Jisx0201RomanRule2")
#define	REGINFO_JISX0201ROMANRULE3			TEXT("Jisx0201RomanRule3")

#define	REGPATH_ZENKAKUVECTOR				REGPATH_KEYMAP
#define	REGINFO_ZENKAKUVECTOR_TYPE			TEXT("ZenkakuVectorType")
#define	REGINFO_ZENKAKUVECTOR				TEXT("ZenkakuVector")
#define	SIZE_INPUTVECTOR					128

#define	REGINFO_EGGLIKENEWLINE				TEXT("EggLikeNewline")
#define	REGINFO_NEWLINEKAKUTEIALL			TEXT("NewlineKakuteiAll")

/*========================================================================
 *	definitions
 */
#define	MAX_KEYBINDS		256
#define	MAX_SPECIALKEYS		64
/* KeyCode(4), Modifier(2), Function(2) */
#define	SIZE_PER_1EXTRAKEY	(4+2+2)
#define	NUM_KEYMAPS			5

enum {
	KEYBINDTP_DEFAULT		= 0,
	KEYBINDTP_USERDEFINED,
} ;

#define	ROMAKANALIST_SHORT_LEN	8
#define	ROMAKANALIST_LONG_LEN	256

#define	NUM_ROMAKANARULE	4

enum {
	ROMAKANARULE_TYPE1	= 0,
	ROMAKANARULE_TYPE2,
	ROMAKANARULE_TYPE3,
} ;

enum {
	ROMAKANA_SHOW_HIRA	= 0,
	ROMAKANA_SHOW_KATA,
	ROMAKANA_SHOW_BOTH,
} ;

enum {
	KEYBIND_SHOW_STARTHENKANKEYS		= 0,
	KEYBIND_SHOW_TRYCOMPLETIONKEYS,
	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS,
	KEYBIND_SHOW_NEXTCOMPLETIONKEYS,
	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS,
	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS,
} ;

#define	SEPCHAR	TEXT(',')

/*========================================================================
 *	structures
 */
struct CImeKeyBind {
	short				m_nKeyCode ;
	unsigned short		m_uKeyMask ;		/* CONTROL | SHIFT | ALT ���炢���H */
	int					m_nKeyFunction ;	/* �@�\�B*/
} ;

struct CImeKeymap {
	BYTE				m_rbyBaseMap [MAX_KEYBINDS] ;	/* 128 ���Bdefault */
	int					m_nKeyBinds ;	/* �ǉ��B�������݂���΁B*/
	struct CImeKeyBind*	m_pKeyBinds ;
} ;

enum {
	KEYMAP_INDEX_MAJOR	= 0,
	KEYMAP_INDEX_JMODE,
	KEYMAP_INDEX_LATIN,
	KEYMAP_INDEX_JISX0208LATIN,
	KEYMAP_INDEX_ABBREV,
} ;

struct TEditKeymapArg {
	struct CImeKeymap	m_rKeymaps [NUM_KEYMAPS] ;
//	struct CImeKeymap	m_MajorModeMap ;
//	struct CImeKeymap	m_JModeMap ;
//	struct CImeKeymap	m_LatinModeMap ;
//	struct CImeKeymap	m_Jisx0208LatinModeMap ;
//	struct CImeKeymap	m_AbbrevModeMap ;
} ;

struct TDlgEditKeyBindArg {
	UINT	m_uKey ;
	BYTE	m_rbKeyBinds [NUM_KEYMAPS] ;
	const struct CImeKeymap*	m_rpMasterKeymaps [NUM_KEYMAPS] ;
} ;

/*	��ԑJ�ڂɓ���ȈӖ������L����ǉ��������̂ŁA���̕\�L���@�ɂ��čl����B
 *	�D��x���Œ�� default rule ���~�����̂ŁA������c
 *		\?
 *	�ŏ������H wildcard ��1������v�ɂ��킹�āB(���K�\���������o���ƃJ�I�X���c)
 *	�\���̎��ɃI���W�i���� backslash �̈����ɒ��ӁB(�����ł͕\���Ƃ��Ƃ� backslash
 *	�̈����̖��ɗ����邾��)
 */

#include "../common/roma_kana.h"

/*	����L�@���ł���̂́A�Ō��1���������ɂ������B�r���� ? �������Ă��������邾���ł͂Ȃ����낤���B
 *	(�r���� backslash �͂��肾�낤����ǂ�)
 *
 *	������\�ɂ���ɂ́A�Ō��1�����ȊO�̕\���ɂ� \\\\ �������Ă� \\ �Ɍ�����悤�ɁA? �Ƃ��͒e���悤
 *	�ɂ��āc
 */
// �l�I�ɂ͐擪1�����ɂ��K�v

/// �J�^�J�i�E�Ђ炪�ȂɑΉ����郋�[��
struct TSkkBaseRuleT1 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextRule ;
	struct {
		LPCWSTR	_strKata ;
		LPCWSTR	_strHira ;
	}	_case ;
} ;

/// ������ɑΉ����郋�[��
struct TSkkBaseRuleT2 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextRule ;
	LPCWSTR	_strOutput ;
} ;

/// �֐��ɑΉ����郋�[��
struct TSkkBaseRuleT3 {
	LPCWSTR	_strState ;
	LPCWSTR	_strNext ;
	int		_iNextRule ;
	int		_nFunction ;
} ;

struct TSkkBaseRuleNode {
	int		_nType ;	/* type1 or type2 or type3 */
	union {
		struct TSkkBaseRuleT1	_T1 ;
		struct TSkkBaseRuleT2	_T2 ;
		struct TSkkBaseRuleT3	_T3 ;
	} ;

	struct TSkkBaseRuleNode*	_pNext ;
} ;

struct TCustomRomaKanaRuleArg {
	struct TSkkBaseRuleNode*	m_rplstRomaKanaRules		[NUM_ROMAKANARULE] ;
	struct TSkkBaseRuleNode*	m_rplstJisx0201KanaRules	[NUM_ROMAKANARULE] ;
	struct TSkkBaseRuleNode*	m_rplstJisx0201RomanRules	[NUM_ROMAKANARULE] ;
	int							m_iShownRule ;
} ;

struct TEditRomaKanaRuleArg {
	struct TSkkBaseRuleNode*	m_pInitValue ;
	int		m_nType ;
	TCHAR	m_bufState			[ROMAKANALIST_LONG_LEN] ;
	int		m_iRule ;
	TCHAR	m_bufNextState		[ROMAKANALIST_LONG_LEN] ;
	int		m_iNextRule ;
	TCHAR	m_bufHiraOrCommon	[ROMAKANALIST_LONG_LEN] ;
	TCHAR	m_bufKata			[ROMAKANALIST_LONG_LEN] ;
	int		m_nFunction ;
	BOOL	m_bEnableRule1 ;
} ;

struct TCustomSpecialKeybindArg {
	BOOL	m_bStartHenkanKeysModified ;
	int		m_iNumStartHenkanKeys ;
	BYTE	m_bufStartHenkanKeys			[MAX_SPECIALKEYS] ;

	BOOL	m_bCompletionKeysModified ;
	int		m_iNumTryCompletionKeys ;
	BYTE	m_bufTryCompletionKeys			[MAX_SPECIALKEYS] ;
	int		m_iNumPreviousCompletionKeys ;
	BYTE	m_bufPreviousCompletionKeys		[MAX_SPECIALKEYS] ;
	int		m_iNumNextCompletionKeys ;
	BYTE	m_bufNextCompletionKeys			[MAX_SPECIALKEYS] ;

	BOOL	m_bSetHenkanPointSubrKeysModified ;
	int		m_iNumSetHenkanPointSubrKeys ;
	BYTE	m_bufSetHenkanPointSubrKeys		[MAX_SPECIALKEYS] ;

	BOOL	m_bSpecialMidashiCharKeysModified ;
	int		m_iNumSpecialMidashiCharKeys ;
	BYTE	m_bufSpecialMidashiCharKeys		[MAX_SPECIALKEYS] ;
} ;

/* �S�p�x�N�g�� */
struct TEditZenkakuVectorArg {
	LPTSTR		m_rpZenkakuVector [SIZE_INPUTVECTOR] ;
} ;

struct TEditZenkakuVectorEntryArg {
	int		m_iChara ;
	TCHAR	m_bufText [SIZE_INPUTVECTOR] ;
} ;

/*========================================================================
 *	prototypes
 */
static	LRESULT	dlgKeybind_lOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	LRESULT	dlgKeybind_lOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgKeybind_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void	dlgKeybind_vSyncControls	(HWND) ;

static	void	dlgKeybind_vEditRomaKanaRule	(HWND) ;
static	void	dlgKeybind_vEditKeymap			(HWND) ;
static	void	dlgKeybind_vEditSpecialKey		(HWND) ;
static	void	dlgKeybind_vEditZenkakuVector	(HWND) ;

static	void	dlgKeybind_vLoadConfig			(HWND, BOOL) ;
static	BOOL	dlgKeybind_bSaveConfig			(void) ;
static	void	dlgKeybind_vInitializeDefaultMajorModeMap			(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultJModeMap				(struct CImeKeymap*, const struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultLatinModeMap			(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultJisx0208LatinModeMap	(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultAbbrevModeMap			(struct CImeKeymap*, const struct CImeKeymap*) ;
static	void	dlgKeybind_vCloneKeymap								(struct CImeKeymap*, const struct CImeKeymap*) ;
static	void	dlgKeyBind_vClearKeymap								(struct CImeKeymap*) ;
static	void	dlgKeybind_vInitializeDefaultStartHenkanKey			(BYTE*, int*) ;
static	void	dlgKeybind_vInitializeDefaultCompletinoRelatedKey	(BYTE*, int*, BYTE*, int*, BYTE*, int*) ;
static	void	dlgKeybind_vInitializeDefaultSetHenkanPointSubrKey (BYTE*, int*) ;
static	void	dlgKeybind_vInitializeDefaultSpecialMidashiCharKey (BYTE*, int*) ;

static	INT_PTR	CALLBACK	dlgEditKeyBindProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgRomaKanaRuleProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgJisx0201RuleProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR	CALLBACK	dlgEditSpecialKeybindProc	(HWND, UINT, WPARAM, LPARAM) ;

/* ���[�}�����ȃ��[���̐ݒ�B*/
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pCreateType1Rule (LPCTSTR, LPCTSTR, int, LPCTSTR, LPCTSTR) ;
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pCreateType2Rule (LPCTSTR, LPCTSTR, int, LPCTSTR) ;
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pCreateType3Rule (LPCTSTR, LPCTSTR, int, int) ;
static	void	dlgRomaKanaRule_vRegisterRule			(struct TSkkBaseRuleNode**, struct TSkkBaseRuleNode*) ;
static	BOOL	dlgRomaKanaRule_bUnegisterRule			(struct TSkkBaseRuleNode**, struct TSkkBaseRuleNode*) ;
static	struct TSkkBaseRuleNode*	dlgRomaKanaRule_pSearchRuleByState	(struct TSkkBaseRuleNode*, LPCTSTR, BOOL) ;
static	struct TSkkBaseRuleNode*	pCopyRomaKanaRuleList	(struct TSkkBaseRuleNode*) ;
static	void	dlgRomaKanaRule_vClearAllRules			(struct TSkkBaseRuleNode**) ;
static void dlgRomaKanaRule_vInitializeDefaultRomaKanaRule(TCustomRomaKanaRuleArg* arg);

static	void	dlgRomaKanaRule_vGetEntryString			(LPTSTR, int, const struct TSkkBaseRuleNode*, int, int, BOOL) ;
static	void	dlgRomaKanaRule_vGetType1EntryString	(LPTSTR, int, const struct TSkkBaseRuleT1*, int, int, BOOL) ;
static	void	dlgRomaKanaRule_vGetType2EntryString	(LPTSTR, int, const struct TSkkBaseRuleT2*, int, BOOL) ;
static	void	dlgRomaKanaRule_vGetType3EntryString	(LPTSTR, int, const struct TSkkBaseRuleT3*, int, BOOL) ;

/* �S�p�x�N�g���̐ݒ�B*/
static	INT_PTR	CALLBACK	dlgZenkakuVectorProc (HWND, UINT, WPARAM, LPARAM) ;
static	BOOL		dlgKeybind_bLoadZenkakuVector		(void) ;
static	BOOL		dlgKeybind_bSaveZenkakuVector		(void) ;
static	void		dlgKeybind_vClearZenkakuVector		(void) ;

/*========================================================================
 *	global variables (default value)
 */
#include "../common/jisx0208_vector.h"

/*========================================================================
 *	global variables
 */
//static	BYTE		_srbyMajorModeMap				[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkJModeMap				[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkLatinModeMap			[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkJisx0208LatinModeMap	[MAX_KEYBINDS] ;
//static	BYTE		_srbySkkAbbrevModeMap			[MAX_KEYBINDS] ;

static	struct CImeKeymap	_sMajorModeMap				= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkJModeMap				= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkLatinModeMap			= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkJisx0208LatinModeMap	= { { 0 }, NULL, 0 } ;
static	struct CImeKeymap	_sSkkAbbrevModeMap			= { { 0 }, NULL, 0 } ;

static	int			_siRomaKanaRuleListType ;
static	int			_siKeybindType ;
static	int			_siStartHenkanKeyType ;
static	int			_siCompletionKeyType ;
static	int			_siSetHenkanPointSubrKeyType ;
static	int			_siSpecialMidashiCharKeyType ;

static	struct TSkkBaseRuleNode*	_rplstRomaKanaRules			[NUM_ROMAKANARULE]	= { NULL } ;
static	struct TSkkBaseRuleNode*	_rplstJisx0201KanaRules		[NUM_ROMAKANARULE]	= { NULL } ;
static	struct TSkkBaseRuleNode*	_rplstJisx0201RomanRules	[NUM_ROMAKANARULE]	= { NULL } ;

static	int			_siNumStartHenkanKeys ;
static	BYTE		_srbyStartHenkanKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumTryCompletionKeys ;
static	BYTE		_srbyTryCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumPreviousCompletionKeys ;
static	BYTE		_srbyPreviousCompletionKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumNextCompletionKeys ;
static	BYTE		_srbyNextCompletionKeys			[MAX_SPECIALKEYS] ;
static	int			_siNumSetHenkanPointSubrKeys ;
static	BYTE		_srbySetHenkanPointSubrKeys		[MAX_SPECIALKEYS] ;
static	int			_siNumSpecialMidashiCharKeys ;
static	BYTE		_srbySpecialMidashiCharKeys		[MAX_SPECIALKEYS] ;

static	BOOL		_sbEggLikeNewline ;
static	BOOL		_sbNewlineKakuteiAll ;

static	int			_siZenkakuVectorType ;
static	LPTSTR		_rpZenkakuVector [SIZE_INPUTVECTOR]	= { NULL } ;

/*	���[�U��`���ڂ����݂��邩�ۂ��BComboBox �ɃG���g���[���ǉ�����邩�ǂ����̃`�F�b�N
 *	�ɗ��p����B
 */
static	BOOL		_sbExistUserDefinedRomaKanaRule				= FALSE ;
static	BOOL		_sbExistUserDefinedKeymap					= FALSE ;
static	BOOL		_sbExistUserDefinedStartHenkanKey			= FALSE ;
static	BOOL		_sbExistUserDefinedCompletionKey			= FALSE ;
static	BOOL		_sbExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
static	BOOL		_sbExistUserDefinedSpecialMidashiCharKey	= FALSE ;
static	BOOL		_sbExistUserDefinedZenkakuVector			= FALSE ;

/*========================================================================
 *	public functions
 */
INT_PTR	CALLBACK
DlgKeybindProc		(
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgKeybind_lOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgKeybind_lOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgKeybind_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 *	window message handlers
 */
static	int			_sriKeybindComboResId []	= {
	IDC_COMBO_ROMAKANARULE,
	IDC_COMBO_KEYMAP,
	IDC_COMBO_STARTHENKANKEY,
	IDC_COMBO_COMPLETIONRELATEDKEY,
	IDC_COMBO_SETHENKANPOINTSUBRKEY,
	IDC_COMBO_SPECIALMIDASHICHARKEY,
	IDC_COMBO_ZENKAKUVECTOR,
} ;

static	BOOL*		_srpbUserDefinedFlags []	= {
	&_sbExistUserDefinedRomaKanaRule,
	&_sbExistUserDefinedKeymap,
	&_sbExistUserDefinedStartHenkanKey,
	&_sbExistUserDefinedCompletionKey,
	&_sbExistUserDefinedSetHenkanPointSubrKey,
	&_sbExistUserDefinedSpecialMidashiCharKey,
	&_sbExistUserDefinedZenkakuVector,
} ;

static	int*		_srpiKeybindTypes []	= {
	&_siRomaKanaRuleListType,
	&_siKeybindType,
	&_siStartHenkanKeyType,
	&_siCompletionKeyType,
	&_siSetHenkanPointSubrKeyType,
	&_siSpecialMidashiCharKeyType,
	&_siZenkakuVectorType,
} ;

LRESULT
dlgKeybind_lOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	HWND		hwndControl ;
	int			i ;

	dlgKeybind_vLoadConfig (hDlg, TRUE) ;

	for (i = 0 ; i < ARRAYSIZE (_sriKeybindComboResId) ; i ++) {
		hwndControl	= GetDlgItem (hDlg, _sriKeybindComboResId [i]) ;
		if (hwndControl != NULL) {
			LRESULT	nIndex ;
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("�W��")) ;
			if (nIndex == CB_ERR)
				continue ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_DEFAULT) ;

			if (*_srpbUserDefinedFlags [i]) {
				nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
				if (nIndex == CB_ERR)
					continue ;
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			}
			SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) nIndex, (LPARAM) 0) ;
		}
	}
	dlgKeybind_vSyncControls (hDlg) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

LRESULT
dlgKeybind_lOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;
	int*	piData ;

	switch (woControl) {
	case	IDC_COMBO_ROMAKANARULE:
		piData	= &_siRomaKanaRuleListType ;
		goto	combo_common ;
	case	IDC_COMBO_KEYMAP:
		piData	= &_siKeybindType ;
		goto	combo_common ;
	case	IDC_COMBO_SETHENKANPOINTSUBRKEY:
		piData	= &_siSetHenkanPointSubrKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_STARTHENKANKEY:
		piData	= &_siStartHenkanKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_COMPLETIONRELATEDKEY:
		piData	= &_siCompletionKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_SPECIALMIDASHICHARKEY:
		piData	= &_siSpecialMidashiCharKeyType ;
		goto	combo_common ;
	case	IDC_COMBO_ZENKAKUVECTOR:
		piData	= &_siZenkakuVectorType ;
combo_common:
		if (woNotification == CBN_SELCHANGE) {
			HWND	hwndControl	= (HWND) lParam ;
			LRESULT	nCurSel, nData ;

			nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
			if (nCurSel != CB_ERR) {
				nData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
				if (nData != *piData) {
					*piData	= (int) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
					PropSheet_Changed (GetParent (hDlg), hDlg) ;
				}
			}
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_EDIT_ROMAKANARULE:
		dlgKeybind_vEditRomaKanaRule (hDlg) ;
		return	0 ;
	case	IDC_BUTTON_EDIT_KEYMAP:
		dlgKeybind_vEditKeymap (hDlg) ;
		return	0 ;
	case	IDC_BUTTON_EDIT_SPECIALKEY:
		dlgKeybind_vEditSpecialKey (hDlg) ;	/* Special-Chars? */
		return	0 ;
	case	IDC_BUTTON_EDIT_ZENKAKUVECTOR:
		dlgKeybind_vEditZenkakuVector (hDlg) ;
		return	0 ;
	case	IDC_CHECK_EGG_LIKE_NEWLINE:
		if (woNotification == BN_CLICKED) {
			_sbEggLikeNewline	= IsDlgButtonChecked (hDlg, IDC_CHECK_EGG_LIKE_NEWLINE) == BST_CHECKED ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_CHECK_NEWLINE_KAKUTEI_ALL:
		if (woNotification == BN_CLICKED) {
			_sbNewlineKakuteiAll	= IsDlgButtonChecked (hDlg, IDC_CHECK_NEWLINE_KAKUTEI_ALL) == BST_CHECKED ;
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	default:
		break ;
	}
	return	1 ;
}

INT_PTR
dlgKeybind_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	LPNMHDR	pnmh		= (LPNMHDR) lParam ;

	switch (pnmh->code) {
	case	PSN_APPLY:
		if (dlgKeybind_bSaveConfig ())
			vUpdateTick () ;
		break ;
	case	PSN_RESET:
		dlgKeybind_vLoadConfig (hDlg, FALSE) ;
		dlgKeybind_vSyncControls (hDlg) ;
		break ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

void
dlgKeybind_vSyncControls (
	HWND			hDlg)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_sriKeybindComboResId) ; i ++)
		SetDropDownListCurrentSelectionByData (hDlg, _sriKeybindComboResId [i], *_srpiKeybindTypes [i]) ;

	CheckDlgButton (hDlg, IDC_CHECK_EGG_LIKE_NEWLINE,    _sbEggLikeNewline?		BST_CHECKED : BST_UNCHECKED) ;
	CheckDlgButton (hDlg, IDC_CHECK_NEWLINE_KAKUTEI_ALL, _sbNewlineKakuteiAll?	BST_CHECKED : BST_UNCHECKED) ;
	return ;
}

/*========================================================================
 *	���[�}�����Ȃ̕ϊ����[���̐ݒ�_�C�A���O�B
 */
static	INT_PTR	dlgRomaKanaRule_iDialogEditRomaKanaRuleLists (HWND, struct TCustomRomaKanaRuleArg*) ;

void
dlgKeybind_vEditRomaKanaRule (
	HWND			hDlg)
{
	struct TCustomRomaKanaRuleArg	arg ;
	INT_PTR			nResult ;
	HINSTANCE		hInst ;
	int				i ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_siRomaKanaRuleListType == KEYBINDTP_DEFAULT) {
		dlgRomaKanaRule_vInitializeDefaultRomaKanaRule(&arg);
	} else {
		/* ���݂̃��[�}�����ȃ��[�����R�s�[����K�v������B*/
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			if (_rplstRomaKanaRules [i] != NULL) {
				arg.m_rplstRomaKanaRules [i]	= pCopyRomaKanaRuleList (_rplstRomaKanaRules [i]) ;
			} else {
				arg.m_rplstRomaKanaRules [i]	= NULL ;
			}
			if (_rplstJisx0201KanaRules [i] != NULL) {
				arg.m_rplstJisx0201KanaRules [i]	= pCopyRomaKanaRuleList (_rplstJisx0201KanaRules [i]) ;
			} else {
				arg.m_rplstJisx0201KanaRules [i]	= NULL ;
			}
			if (_rplstJisx0201RomanRules [i] != NULL) {
				arg.m_rplstJisx0201RomanRules [i]	= pCopyRomaKanaRuleList (_rplstJisx0201RomanRules [i]) ;
			} else {
				arg.m_rplstJisx0201RomanRules [i]	= NULL ;
			}
		}
	}
	arg.m_iShownRule	= 0 ;

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	/*	IDD_EDIT_ROMAKANARULELIST �� 3page ���� PropertySheet �ɕύX���ꂽ�B
	 *	�ŏ��̃y�[�W���A�]���� RomaKanaRule, ���̃y�[�W�� JISX0201, �Ō�̃y�[�W�� JISX0201-ROMAN
	 *	�ł���B���� PropertySheet �� Apply �͗p�ӂ��Ȃ��c�B
	 */
	nResult	= dlgRomaKanaRule_iDialogEditRomaKanaRuleLists (hDlg, &arg) ;
	if (nResult <= 0) {
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			dlgRomaKanaRule_vClearAllRules (&arg.m_rplstRomaKanaRules		[i]) ;
			dlgRomaKanaRule_vClearAllRules (&arg.m_rplstJisx0201KanaRules	[i]) ;
			dlgRomaKanaRule_vClearAllRules (&arg.m_rplstJisx0201RomanRules	[i]) ;
		}
		return ;
	}
	if (! _sbExistUserDefinedRomaKanaRule) {
		HWND	hwndControl ;
		LRESULT	nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_ROMAKANARULE) ;
		nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex == CB_ERR)
			nIndex	= SendMessage (hwndControl, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex != CB_ERR)
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
		_sbExistUserDefinedRomaKanaRule	= TRUE ;
	}
	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
		dlgRomaKanaRule_vClearAllRules (&_rplstRomaKanaRules [i]) ;
		_rplstRomaKanaRules			[i]	= arg.m_rplstRomaKanaRules [i] ;

		dlgRomaKanaRule_vClearAllRules (&_rplstJisx0201KanaRules [i]) ;
		_rplstJisx0201KanaRules		[i]	= arg.m_rplstJisx0201KanaRules [i] ;

		dlgRomaKanaRule_vClearAllRules (&_rplstJisx0201RomanRules [i]) ;
		_rplstJisx0201RomanRules	[i]	= arg.m_rplstJisx0201RomanRules [i] ;
	}
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_ROMAKANARULE, KEYBINDTP_USERDEFINED) ;
	_siRomaKanaRuleListType	= KEYBINDTP_USERDEFINED ;
	return ;
}

INT_PTR
dlgRomaKanaRule_iDialogEditRomaKanaRuleLists (
	HWND							hDlg,
	struct TCustomRomaKanaRuleArg*	pArg)
{
	static	struct TPropPageSheetConfig			_srPageSheetTbl []	= {
		{ TEXT("���[�}�������[��"),				dlgRomaKanaRuleProc,	IDD_PROPPAGE_ROMAKANARULE, },
		{ TEXT("JISX0201�������[��"),			dlgJisx0201RuleProc,	IDD_PROPPAGE_ROMAKANARULE, },
		{ TEXT("JISX0201���[�}���[��"),			dlgJisx0201RuleProc,	IDD_PROPPAGE_ROMAKANARULE, },
	} ;
	HPROPSHEETPAGE	rPages [3] ;
	PROPSHEETHEADER	psh ;

	psh.dwSize		= sizeof (psh) ;
	psh.dwFlags		= 0 ;
	psh.hwndParent	= hDlg ;

	psh.hInstance	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	psh.pszIcon		= NULL ;
	psh.pszCaption	= TEXT ("���[�����X�g") ;
	psh.nPages		= 0 ;
	psh.nStartPage	= 0 ;
	psh.phpage		= rPages ;
	psh.pfnCallback	= 0 ;

	if (! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [0], pArg->m_rplstRomaKanaRules)	||
		! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [1], pArg->m_rplstJisx0201KanaRules) ||
		! bNewPageSheet (&psh, psh.hInstance, &_srPageSheetTbl [2], pArg->m_rplstJisx0201RomanRules))
		return	0 ;
	if (psh.nPages > 0) {
		/* Tick �� update ����B*/
		return	PropertySheet (&psh) ;
	}
	return	0 ;
}

/*========================================================================
 *	�X�y�V�����L�[ (roma-kana-rule-list�̕⑫)�̐ݒ�_�C�A���O�B
 */
void
dlgKeybind_vEditSpecialKey (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg	arg ;
	INT_PTR			nResult ;
	HINSTANCE		hInst ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_siStartHenkanKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultStartHenkanKey (arg.m_bufStartHenkanKeys, &arg.m_iNumStartHenkanKeys) ;
	} else {
		arg.m_iNumStartHenkanKeys			= _siNumStartHenkanKeys ;
		memcpy (arg.m_bufStartHenkanKeys,			_srbyStartHenkanKeys,		_siNumStartHenkanKeys) ;
	}
	if (_siCompletionKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultCompletinoRelatedKey (arg.m_bufTryCompletionKeys, &arg.m_iNumTryCompletionKeys, arg.m_bufPreviousCompletionKeys, &arg.m_iNumPreviousCompletionKeys, arg.m_bufNextCompletionKeys, &arg.m_iNumNextCompletionKeys) ;
	} else {
		arg.m_iNumTryCompletionKeys			= _siNumTryCompletionKeys ;
		memcpy (arg.m_bufTryCompletionKeys,			_srbyTryCompletionKeys,		_siNumTryCompletionKeys) ;
		arg.m_iNumPreviousCompletionKeys	= _siNumPreviousCompletionKeys ;
		memcpy (arg.m_bufPreviousCompletionKeys,	_srbyPreviousCompletionKeys, _siNumPreviousCompletionKeys) ;
		arg.m_iNumNextCompletionKeys		= _siNumNextCompletionKeys ;
		memcpy (arg.m_bufNextCompletionKeys,	_srbyNextCompletionKeys,		_siNumNextCompletionKeys) ;
	}
	if (_siSetHenkanPointSubrKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultSetHenkanPointSubrKey (arg.m_bufSetHenkanPointSubrKeys, &arg.m_iNumSetHenkanPointSubrKeys) ;
	} else {
		arg.m_iNumSetHenkanPointSubrKeys	= _siNumSetHenkanPointSubrKeys ;
		memcpy (arg.m_bufSetHenkanPointSubrKeys, _srbySetHenkanPointSubrKeys, _siNumSetHenkanPointSubrKeys) ;
	}
	if (_siSpecialMidashiCharKeyType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultSpecialMidashiCharKey (arg.m_bufSpecialMidashiCharKeys, &arg.m_iNumSpecialMidashiCharKeys) ;
	} else {
		arg.m_iNumSpecialMidashiCharKeys	= _siNumSpecialMidashiCharKeys ;
		memcpy (arg.m_bufSpecialMidashiCharKeys, _srbySpecialMidashiCharKeys, _siNumSpecialMidashiCharKeys) ;
	}

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_SPECIALKEYBIND), hDlg, dlgEditSpecialKeybindProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		return ;
	}
	if (arg.m_bStartHenkanKeysModified) {
		if (! _sbExistUserDefinedStartHenkanKey) {
			HWND	hwndControl ;
			LRESULT	nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_STARTHENKANKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR)
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedStartHenkanKey	= TRUE ;
		}
		_siNumStartHenkanKeys	= arg.m_iNumStartHenkanKeys ;
		if (arg.m_iNumStartHenkanKeys > 0)
			memcpy (_srbyStartHenkanKeys, arg.m_bufStartHenkanKeys, arg.m_iNumStartHenkanKeys) ;

		_siStartHenkanKeyType	= KEYBINDTP_USERDEFINED ;
		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_STARTHENKANKEY, KEYBINDTP_USERDEFINED) ;
	}
	if (arg.m_bCompletionKeysModified) {
		if (! _sbExistUserDefinedCompletionKey) {
			HWND	hwndControl ;
			LRESULT	nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_COMPLETIONRELATEDKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR)
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}
		_siNumTryCompletionKeys			= arg.m_iNumTryCompletionKeys ;
		_siNumPreviousCompletionKeys	= arg.m_iNumPreviousCompletionKeys ;
		_siNumNextCompletionKeys		= arg.m_iNumNextCompletionKeys ;
		if (arg.m_iNumTryCompletionKeys > 0)
			memcpy (_srbyTryCompletionKeys, arg.m_bufTryCompletionKeys, arg.m_iNumTryCompletionKeys) ;
		if (arg.m_iNumPreviousCompletionKeys > 0)
			memcpy (_srbyPreviousCompletionKeys, arg.m_bufPreviousCompletionKeys, arg.m_iNumPreviousCompletionKeys) ;
		if (arg.m_iNumNextCompletionKeys > 0)
			memcpy (_srbyNextCompletionKeys, arg.m_bufNextCompletionKeys, arg.m_iNumNextCompletionKeys) ;

		_siCompletionKeyType	= KEYBINDTP_USERDEFINED ;
		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_COMPLETIONRELATEDKEY, KEYBINDTP_USERDEFINED) ;
	}
	if (arg.m_bSetHenkanPointSubrKeysModified) {
		if (! _sbExistUserDefinedSetHenkanPointSubrKey) {
			HWND	hwndControl ;
			LRESULT	nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SETHENKANPOINTSUBRKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR)
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		_siSetHenkanPointSubrKeyType	= KEYBINDTP_USERDEFINED ;
		_siNumSetHenkanPointSubrKeys	= arg.m_iNumSetHenkanPointSubrKeys ;
		memcpy (_srbySetHenkanPointSubrKeys, arg.m_bufSetHenkanPointSubrKeys, MAX_SPECIALKEYS * sizeof (BYTE)) ;

		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_SETHENKANPOINTSUBRKEY, KEYBINDTP_USERDEFINED) ;
	}
	if (arg.m_bSpecialMidashiCharKeysModified) {
		if (! _sbExistUserDefinedSpecialMidashiCharKey) {
			HWND	hwndControl ;
			LRESULT	nIndex ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SPECIALMIDASHICHARKEY) ;
			nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
			if (nIndex == CB_ERR)
				return ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
			_sbExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}
		_siSpecialMidashiCharKeyType	= KEYBINDTP_USERDEFINED ;
		_siNumSpecialMidashiCharKeys	= arg.m_iNumSpecialMidashiCharKeys ;
		memcpy (_srbySpecialMidashiCharKeys, arg.m_bufSpecialMidashiCharKeys, MAX_SPECIALKEYS * sizeof (BYTE)) ;

		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_SPECIALMIDASHICHARKEY, KEYBINDTP_USERDEFINED) ;
	}
	return ;
}

void
dlgKeybind_vEditZenkakuVector (
	HWND			hDlg)
{
	struct TEditZenkakuVectorArg	arg ;
	INT_PTR			nResult ;
	HINSTANCE		hInst ;
	// LPTSTR*		pstrTable ;
	int				i ;

	if (_siZenkakuVectorType == KEYBINDTP_DEFAULT) {
		for (i = 0; i < SIZE_INPUTVECTOR; i ++) {
			LPTSTR p = NULL;
			TCHAR c = i < TEXT(' ') ? TEXT('\0') : _rcDefaultJisx0208LatinVector[i - TEXT(' ')];
			if (c) {
				p = (LPTSTR)MALLOC(sizeof(TCHAR) * 2);
				if (p) {
					p[0] = c;
					p[1] = TEXT('\0');
				}
			}
			arg.m_rpZenkakuVector[i] = p;
		}
	} else {
		for (i = 0; i < SIZE_INPUTVECTOR; i ++) arg.m_rpZenkakuVector[i] = _rpZenkakuVector[i];
	}

	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_ZENKAKUVECTOR), hDlg, dlgZenkakuVectorProc, (LPARAM) &arg) ;
	if (nResult != IDOK) {
		/* �������̉���B*/
		for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
			if (arg.m_rpZenkakuVector[i] != _rpZenkakuVector[i]) {
				FREE (arg.m_rpZenkakuVector [i]) ;
			}
		}
		return ;
	}
#if 0	// ���̍��ڂɂ͍X�V�`�F�b�N�͂Ȃ��B����Ɉ�ѐ����Ȃ����[�U�̍������������ߍ폜
	/* ���ڂ�1�ł��ύX���Ă��邩�H */
	for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
		if (arg.m_rpZenkakuVector [i] != pstrTable [i])
			break ;
	}
	if (i >= 128)	/* no update */
		return ;
#endif
	if (! _sbExistUserDefinedZenkakuVector) {
		HWND	hwndControl ;
		LRESULT	nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_ZENKAKUVECTOR) ;
		nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex == CB_ERR)
			return ;
		SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
		_sbExistUserDefinedZenkakuVector	= TRUE ;
	}
	_siZenkakuVectorType	= KEYBINDTP_USERDEFINED ;

	// ���̔ł̓f�t�H���g�l�̃|�C���^��FREE�����肪��������(�������Ȃ����L����)
	// ���̔ł̓f�t�H���g�l�͕K��MALLOC�Ő�������邩����v���B���Ȃ��B
	for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
		// �K�v�ȕ������|�C���^�̏��L�����ڂ�
		if (arg.m_rpZenkakuVector [i] != _rpZenkakuVector [i]) {
			FREE (_rpZenkakuVector [i]) ;
			_rpZenkakuVector [i]	= arg.m_rpZenkakuVector [i] ;
		}
	}
	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_ZENKAKUVECTOR, KEYBINDTP_USERDEFINED) ;
	return ;
}

/*========================================================================
 *	�L�[�}�b�v�̐ݒ�_�C�A���O�B
 */
static	INT_PTR	CALLBACK	dlgEditKeymapProc			(HWND, UINT, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditKeymap_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditKeymap_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditKeymap_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void				dlgEditKeymap_vUpdate		(HWND) ;
static	void				dlgEditKeymap_vUpdate1Item	(HWND, UINT) ;
static	void				dlgEditKeymap_vEditKeyBind	(HWND, BOOL) ;
static	void				dlgEditKeymap_vDeleteKeyBind	(HWND) ;
static	void				dlgEditKeymap_vUpdateExtraKeyItem	(HWND, int, int, const struct CImeKeyBind*, int) ;
static	int					dlgEditKeymap_iLookupKeymap	(const struct CImeKeymap*, unsigned int) ;
static	BOOL				dlgEditKeymap_bDefineKeymap	(struct CImeKeymap*, unsigned int, int) ;

#define	IS_EXTRA_KEY(uKey)	(((uKey) & (1 << 31)) != 0)
#define	MAKE_EXTRA_KEYCODE(uVKEY,uMask)	((unsigned short)(uVKEY) | (((unsigned short)(uMask) & 0x7FFF) << 16) | (1L << 31))
#define	EXTRA_KEYCODE_VKEY(uKey)	((uKey) & 0xFFFF)
#define	EXTRA_KEYCODE_MASK(uKey)	(((uKey) >> 16) & 0x7FFF)

void
dlgKeybind_vEditKeymap (
	HWND			hDlg)
{
	HINSTANCE			hInst ;
	INT_PTR				nResult ;
	struct TEditKeymapArg	arg ;

	memset (&arg, 0, sizeof (arg)) ;
	if (_siKeybindType == KEYBINDTP_DEFAULT) {
		dlgKeybind_vInitializeDefaultMajorModeMap			(&arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
		dlgKeybind_vInitializeDefaultJModeMap				(&arg.m_rKeymaps [KEYMAP_INDEX_JMODE], &arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
		dlgKeybind_vInitializeDefaultLatinModeMap			(&arg.m_rKeymaps [KEYMAP_INDEX_LATIN]) ;
		dlgKeybind_vInitializeDefaultJisx0208LatinModeMap	(&arg.m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN]) ;
		dlgKeybind_vInitializeDefaultAbbrevModeMap			(&arg.m_rKeymaps [KEYMAP_INDEX_ABBREV], &arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
	} else {
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_MAJOR],			&_sMajorModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_JMODE],			&_sSkkJModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_LATIN],			&_sSkkLatinModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN],	&_sSkkJisx0208LatinModeMap) ;
		dlgKeybind_vCloneKeymap (&arg.m_rKeymaps [KEYMAP_INDEX_ABBREV],			&_sSkkAbbrevModeMap) ;
	}
	hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_KEYMAP), hDlg, dlgEditKeymapProc, (LPARAM) &arg) ;
	if (nResult != IDOK)
		return ;
	if (! _sbExistUserDefinedKeymap) {
		HWND	hwndControl ;
		LRESULT	nIndex ;

		hwndControl	= GetDlgItem (hDlg, IDC_COMBO_KEYMAP) ;
		nIndex		= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) TEXT ("���[�U��`")) ;
		if (nIndex == CB_ERR)
			return ;
		SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) KEYBINDTP_USERDEFINED) ;
		_sbExistUserDefinedKeymap	= TRUE ;
	}
	dlgKeyBind_vClearKeymap	(&_sMajorModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkJModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkLatinModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkJisx0208LatinModeMap) ;
	dlgKeyBind_vClearKeymap	(&_sSkkAbbrevModeMap) ;
	dlgKeybind_vCloneKeymap (&_sMajorModeMap,				&arg.m_rKeymaps [KEYMAP_INDEX_MAJOR]) ;
	dlgKeybind_vCloneKeymap (&_sSkkJModeMap,				&arg.m_rKeymaps [KEYMAP_INDEX_JMODE]) ;
	dlgKeybind_vCloneKeymap (&_sSkkLatinModeMap,			&arg.m_rKeymaps [KEYMAP_INDEX_LATIN]) ;
	dlgKeybind_vCloneKeymap (&_sSkkJisx0208LatinModeMap,	&arg.m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN]) ;
	dlgKeybind_vCloneKeymap (&_sSkkAbbrevModeMap,			&arg.m_rKeymaps [KEYMAP_INDEX_ABBREV]) ;

	SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_KEYMAP, KEYBINDTP_USERDEFINED) ;
	_siKeybindType	= KEYBINDTP_USERDEFINED ;
	return ;
}

INT_PTR	CALLBACK
dlgEditKeymapProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		return	dlgEditKeymap_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditKeymap_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditKeymap_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditKeymap_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditKeymapArg*		pArg ;
	HWND	hwndControl ;

	pArg	= (struct TEditKeymapArg*) lParam ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	CheckRadioButton (hDlg, IDC_RADIO_MAJORMODEMAP, IDC_RADIO_ALLMAPS, IDC_RADIO_ALLMAPS) ;

	/*	�R�����̓[���ɐݒ�ł��Ȃ��̂ōŏ��̂��̂����͓o�^���Ă����B
	 */
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hwndControl != NULL) {
		LVCOLUMN	lvColumn ;

		memset (&lvColumn, 0, sizeof (lvColumn)) ;
		lvColumn.mask	= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
		lvColumn.fmt	= LVCFMT_LEFT ;
		lvColumn.cx			= 48 ;
		lvColumn.pszText	= TEXT ("�L�[") ;
		ListView_InsertColumn (hwndControl, 0, &lvColumn) ;
	}
	dlgEditKeymap_vUpdate (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditKeymap_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl	= LOWORD (wParam) ;

	switch (woControl) {
	case	IDC_RADIO_MAJORMODEMAP:
	case	IDC_RADIO_JMODEMAP:
	case	IDC_RADIO_LATINMODEMAP:
	case	IDC_RADIO_JISX0208LATINMODEMAP:
	case	IDC_RADIO_ABBREVMODEMAP:
	case	IDC_RADIO_ALLMAPS:
		CheckRadioButton (hDlg, IDC_RADIO_MAJORMODEMAP, IDC_RADIO_ALLMAPS, woControl) ;
		dlgEditKeymap_vUpdate (hDlg) ;
		break ;
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
		dlgEditKeymap_vEditKeyBind (hDlg, woControl == IDC_BUTTON_EDIT) ;
		return	0 ;	/* If application process this message, it must return zero. */
	case	IDC_BUTTON_DELETE:
		dlgEditKeymap_vDeleteKeyBind (hDlg) ;
		return	0 ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;	/* If application process this message, it must return zero. */
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditKeymap_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

void
dlgEditKeymap_vUpdate (
	HWND			hDlg)
{
	static	struct {
		int		m_nWidth ;
		LPTSTR	m_strTitle ;
	}	srAllMapColumnInfo []	= {
		{	68,		TEXT ("���ړ��� (major-map)")	},
		{	68,		TEXT ("���{�� (j-mode-map)")	},
		{	68,		TEXT ("�p�� latin-mode-map")	},
		{	68,		TEXT ("�S�p�p�� (jisx0208-latin-mode-map)")	},
		{	68,		TEXT ("�p�P�� (abbrev-map)")	},
	},	srOneMapColumnInfo []	= {
		{	256,	TEXT ("�@�\")	},
	},	*pColumnInfo ;

	struct TEditKeymapArg*		pArg ;
	HWND		hwndControl ;
	LVCOLUMN	lvColumn ;
	LVITEM		lvi ;
	int			i ;
	TCHAR		szBuffer [64] ;

	pArg		= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hwndControl == NULL)
		return ;

	ListView_DeleteAllItems (hwndControl) ;
	ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_FULLROWSELECT) ;

	memset (&lvColumn, 0, sizeof (lvColumn)) ;
	lvColumn.mask	= LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM ;
	lvColumn.fmt	= LVCFMT_LEFT ;

	memset (&lvi, 0, sizeof (lvi)) ;
	if (IsDlgButtonChecked (hDlg, IDC_RADIO_ALLMAPS) == BST_CHECKED) {
		if (ListView_GetColumnWidth (hwndControl, 2) == 0) {
			/*	�R�����̍X�V���K�v�B*/
			for (i = 0 ; i < ARRAYSIZE (srOneMapColumnInfo) ; i ++)
				ListView_DeleteColumn (hwndControl, 1) ;
			for (i = 0 ; i < ARRAYSIZE (srAllMapColumnInfo) ; i ++) {
				lvColumn.cx			= srAllMapColumnInfo [i].m_nWidth ;
				lvColumn.pszText	= srAllMapColumnInfo [i].m_strTitle ;
				ListView_InsertColumn (hwndControl, i + 1, &lvColumn) ;
			}
		}
		lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvi.state		= 0 ;
		lvi.stateMask	= 0 ;
		for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
			int		j ;

			for (j = 0 ; j < NUM_KEYMAPS ; j ++) {
				if (pArg->m_rKeymaps [j].m_rbyBaseMap [i] != NFUNC_INVALID_CHAR)
					break ;
			}
			if (j < NUM_KEYMAPS) {
				int		nItem ;

				lvi.iItem		= i ;
				lvi.lParam		= (LPARAM) i ;
				vKey2String (szBuffer, ARRAYSIZE (szBuffer), i) ;
				lvi.pszText		= szBuffer ;
				nItem			= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					for (j = 0 ; j < NUM_KEYMAPS ; j ++) {
						if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), pArg->m_rKeymaps [j].m_rbyBaseMap [i]))
							ListView_SetItemText (hwndControl, nItem, j + 1, szBuffer) ;
					}
				}
			}
		}
		/*	����L�[�o�C���h�̃A�b�v�f�[�g�B
		 */
		for (i = 0 ; i < NUM_KEYMAPS ; i ++)
			dlgEditKeymap_vUpdateExtraKeyItem (hwndControl, i + 1, NUM_KEYMAPS + 1, pArg->m_rKeymaps [i].m_pKeyBinds, pArg->m_rKeymaps [i].m_nKeyBinds) ;
	} else {
		const CImeKeymap*	pKeymap		= NULL ;

		if (ListView_GetColumnWidth (hwndControl, 2) != 0) {
			/*	�R�����̍X�V���K�v�B*/
			for (i = 0 ; i < ARRAYSIZE (srAllMapColumnInfo) ; i ++)
				ListView_DeleteColumn (hwndControl, 1) ;
			for (i = 0 ; i < ARRAYSIZE (srOneMapColumnInfo) ; i ++) {
				lvColumn.cx			= srOneMapColumnInfo [i].m_nWidth ;
				lvColumn.pszText	= srOneMapColumnInfo [i].m_strTitle ;
				ListView_InsertColumn (hwndControl, i + 1, &lvColumn) ;
			}
		}
		if (IsDlgButtonChecked (hDlg, IDC_RADIO_MAJORMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JMODE] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_LATINMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_LATIN] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JISX0208LATINMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN] ;
		} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_ABBREVMODEMAP) == BST_CHECKED) {
			pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV] ;
		} else {
			return ;
		}
		lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
		lvi.state		= 0 ;
		lvi.stateMask	= 0 ;
		for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
			if (pKeymap->m_rbyBaseMap [i] != NFUNC_INVALID_CHAR) {
				int		nItem ;

				lvi.iItem		= i ;
				lvi.lParam		= (LPARAM) i ;
				vKey2String (szBuffer, ARRAYSIZE (szBuffer), i) ;
				lvi.pszText		= szBuffer ;
				nItem			= ListView_InsertItem (hwndControl, &lvi) ;
				if (nItem != -1) {
					if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), pKeymap->m_rbyBaseMap [i]))
						ListView_SetItemText (hwndControl, nItem, 1, szBuffer) ;
				}
			}
		}
		dlgEditKeymap_vUpdateExtraKeyItem (hwndControl, 1, 2, pKeymap->m_pKeyBinds, pKeymap->m_nKeyBinds) ;
	}
	return ;
}

void
dlgEditKeymap_vUpdateExtraKeyItem (
	HWND						hwndControl,
	int							iSubItem,
	int							iMaxSubItem,
	const struct CImeKeyBind*	pKeyBind,
	int							iNumKeyBind)
{
	TCHAR		szBuffer [256] ;
	LVITEM		lvi ;
	LVFINDINFO	lvfi ;
	int			i ;

	if (pKeyBind == NULL || iNumKeyBind <= 0)
		return ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
	lvi.state		= 0 ;
	lvi.stateMask	= 0 ;

	memset (&lvfi, 0, sizeof (lvfi)) ;
	lvfi.flags	= LVFI_PARAM ;

	for (i = 0 ; i < iNumKeyBind ; i ++) {
		int		nItem ;

		lvfi.lParam	= (LPARAM) MAKE_EXTRA_KEYCODE (pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask) ;
		nItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;
		if (nItem == -1) {
			vKey2StringEx (szBuffer, ARRAYSIZE (szBuffer), pKeyBind->m_nKeyCode, pKeyBind->m_uKeyMask) ;
			lvi.iItem	= 0x1000 ;	/* MAX-VALUE�H */
			lvi.lParam	= lvfi.lParam ;
			lvi.pszText	= szBuffer ;

			nItem	= ListView_InsertItem (hwndControl, &lvi) ;
			if (nItem != -1) {
				int		j ;
				/* �ŏ��ɍ쐬���ꂽ���́A���̃o�C���h��S�� "-" �ɂ��Ă����B*/
				for (j = 1 ; j < iMaxSubItem ; j ++) {
					if (j != iSubItem)
						ListView_SetItemText (hwndControl, nItem, j, TEXT ("-")) ;
				}
			}
		}
		if (nItem != -1) {
			if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), pKeyBind->m_nKeyFunction))
				ListView_SetItemText (hwndControl, nItem, iSubItem, szBuffer) ;
		}
		pKeyBind ++ ;
	}
	return ;
}

void
dlgEditKeymap_vEditKeyBind (
	HWND			hDlg,
	BOOL			bEdit)
{
	struct TEditKeymapArg*		pArg ;
	HWND						hWnd ;
	HINSTANCE					hInstance ;
	int							nCurSel, i ;
	INT_PTR						nResult ;
	LV_ITEM						lvi ;
	struct TDlgEditKeyBindArg	arg ;

	pArg	= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hWnd	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (hWnd == NULL)
		return ;
	if (bEdit) {
		nCurSel	= ListView_GetSelectionMark (hWnd) ;
		if (nCurSel == -1)
			return ;
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask		= LVIF_PARAM ;
		lvi.iItem		= nCurSel ;
		lvi.iSubItem	= 0 ;
		if (ListView_GetItem (hWnd, &lvi) == -1)
			return ;
		arg.m_uKey				= (UINT) lvi.lParam ;
		for (i = 0 ; i < NUM_KEYMAPS ; i ++)
			arg.m_rbKeyBinds [i]	= (BYTE)dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [i], lvi.lParam) ;
	} else {
		arg.m_uKey				= (UINT) -1 ;
		for (i = 0 ; i < NUM_KEYMAPS ; i ++)
			arg.m_rbKeyBinds [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 0 ; i < NUM_KEYMAPS ; i ++)
		arg.m_rpMasterKeymaps [i]	= &pArg->m_rKeymaps [i] ;

	hInstance	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	nResult	= DialogBoxParam (hInstance, MAKEINTRESOURCE (IDD_EDIT_KEYBIND), hDlg, dlgEditKeyBindProc, (LPARAM)&arg) ;
	if (nResult != IDOK)
		return ;

	if (arg.m_uKey == (unsigned int)-1)
		return ;

	if (IS_EXTRA_KEY (arg.m_uKey)) {
		for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
			if (arg.m_rbKeyBinds [i]  != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [i], arg.m_uKey, arg.m_rbKeyBinds [i]) ;
		}
	} else if (0 <= arg.m_uKey && arg.m_uKey < MAX_KEYBINDS) {
		for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
			pArg->m_rKeymaps [i].m_rbyBaseMap [arg.m_uKey]	= arg.m_rbKeyBinds [i] ;
		}
	} else {
		return ;
	}
	/*	ListView �� update ���Ȃ���΂Ȃ�Ȃ��B*/
	dlgEditKeymap_vUpdate1Item (hDlg, arg.m_uKey) ;
	return ;
}

void
dlgEditKeymap_vUpdate1Item (
	HWND			hDlg,
	UINT			uKeyCode)
{
	struct TEditKeymapArg*		pArg ;
	HWND						hwndControl ;
	LVFINDINFO					lvfi ;
	BOOL						bDelete ;
	struct CImeKeymap*			pKeymap ;
	int							iItem, i ;

	pArg		= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (pArg == NULL || hwndControl == NULL)
		return ;

	/*	ExtraKeyItem �������ꍇ�ɍ폜���邩�ǂ����̔��f�͔����B���ɂ����� keybind
	 *	�����邩�ǂ����̃`�F�b�N���K�v�ɂȂ�B
	 */
	bDelete			= FALSE ;

	memset (&lvfi, 0, sizeof (lvfi)) ;
	lvfi.flags	= LVFI_PARAM ;
	lvfi.lParam	= uKeyCode ;
	iItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;

	if (IsDlgButtonChecked (hDlg, IDC_RADIO_MAJORMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JMODE] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_LATINMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_LATIN] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_JISX0208LATINMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_ABBREVMODEMAP) == BST_CHECKED) {
		pKeymap		= &pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV] ;
		bDelete		= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) == NFUNC_INVALID_CHAR ;
	} else {
		for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [i], uKeyCode) != NFUNC_INVALID_CHAR)
				break ;
		}
		bDelete		= (i >= NUM_KEYMAPS) ;
		pKeymap		= NULL ;
	}
	if (bDelete) {
		if (iItem != -1)
			ListView_DeleteItem (hwndControl, iItem) ;
	} else {
		TCHAR	szBuffer [256] ;
		int	iFuncCode ;

		if (iItem == -1) {
			LVITEM	lvi ;
			int		iMaxSubItem	= (pKeymap == NULL)? NUM_KEYMAPS : 1 ;

			memset (&lvi, 0, sizeof (lvi)) ;
			lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
			lvi.state		= 0 ;
			lvi.stateMask	= 0 ;

			if (IS_EXTRA_KEY (uKeyCode)) {
				vKey2StringEx (szBuffer, ARRAYSIZE (szBuffer) - 1, EXTRA_KEYCODE_VKEY (uKeyCode), EXTRA_KEYCODE_MASK (uKeyCode)) ;
				lvi.iItem	= 0x1000 ;	/* MAX-VALUE�H */
			} else {
				vKey2String (szBuffer, ARRAYSIZE (szBuffer) - 1, uKeyCode) ;
				lvi.iItem	= (int) uKeyCode ;
			}
			szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
			lvi.lParam	= uKeyCode ;
			lvi.pszText	= szBuffer ;

			iItem	= ListView_InsertItem (hwndControl, &lvi) ;
			if (iItem != -1) {
				int		j ;
				/* �ŏ��ɍ쐬���ꂽ���́A���̃o�C���h��S�� "-" �ɂ��Ă����B*/
				for (j = 1 ; j <= iMaxSubItem ; j ++)
					ListView_SetItemText (hwndControl, iItem, j, TEXT ("-")) ;
			}
		}
		if (pKeymap == NULL) {
			for (i = 0 ; i < NUM_KEYMAPS ; i ++) {
				iFuncCode	= dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [i], uKeyCode) ;
				if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), iFuncCode))
					ListView_SetItemText (hwndControl, iItem, i + 1, szBuffer) ;
			}
		} else {
			iFuncCode	= dlgEditKeymap_iLookupKeymap (pKeymap, uKeyCode) ;
			if (bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer), iFuncCode))
				ListView_SetItemText (hwndControl, iItem, 1, szBuffer) ;
		}
	}
	return ;
}

void
dlgEditKeymap_vDeleteKeyBind (
	HWND			hDlg)
{
	struct TEditKeymapArg*		pArg ;
	HWND	hWnd ;
	int		nCurSel, nResult ;
	TCHAR	bufText [256], bufKey [64] ;
	LV_ITEM	lvi ;
	UINT	uKey ;

	pArg	= (struct TEditKeymapArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hWnd	= GetDlgItem (hDlg, IDC_LIST_KEYBIND) ;
	if (pArg == NULL || hWnd == NULL)
		return ;
	nCurSel	= ListView_GetSelectionMark (hWnd) ;
	if (nCurSel == -1)
		return ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_PARAM ;
	lvi.iItem		= nCurSel ;
	lvi.iSubItem	= 0 ;
	if (ListView_GetItem (hWnd, &lvi) == -1)
		return ;

	uKey			= (UINT) lvi.lParam ;
	if (IS_EXTRA_KEY (uKey)) {
		vKey2StringEx (bufKey, ARRAYSIZE (bufKey) - 1, EXTRA_KEYCODE_VKEY (uKey), EXTRA_KEYCODE_MASK (uKey)) ;
	} else {
		vKey2String (bufKey, ARRAYSIZE (bufKey) - 1, uKey) ;
	}
	bufKey [ARRAYSIZE (bufKey) - 1]	= TEXT ('\0') ;
	wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%s ���폜���܂��B��낵���ł����H"), bufKey) ;
	bufText [ARRAYSIZE (bufText) - 1]	= TEXT ('\0') ;

	nResult	= MessageBox (hWnd, bufText, TEXT ("�L�[�o�C���h�̍폜�m�F"), MB_ICONQUESTION | MB_OKCANCEL) ;
	if (nResult == IDOK) {
		if (IS_EXTRA_KEY (uKey)) {
			/* INVALID_CHAR �ŏ㏑������B*/
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR],			uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR],			uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JMODE],				uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JMODE],				uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_LATIN],			uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_LATIN],			uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN],	uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN],	uKey, NFUNC_INVALID_CHAR) ;
			if (dlgEditKeymap_iLookupKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV],		uKey) != NFUNC_INVALID_CHAR)
				dlgEditKeymap_bDefineKeymap (&pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV],		uKey, NFUNC_INVALID_CHAR) ;
		} else {
			if (/*0 <= uKey &&*/ uKey < MAX_KEYBINDS) {
				pArg->m_rKeymaps [KEYMAP_INDEX_MAJOR].m_rbyBaseMap			[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_JMODE].m_rbyBaseMap				[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_LATIN].m_rbyBaseMap			[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_JISX0208LATIN].m_rbyBaseMap	[uKey]	= NFUNC_INVALID_CHAR ;
				pArg->m_rKeymaps [KEYMAP_INDEX_ABBREV].m_rbyBaseMap			[uKey]	= NFUNC_INVALID_CHAR ;
			}
		}
		ListView_DeleteItem (hWnd, nCurSel) ;
		return ;
	}
	return ;
}

int
dlgEditKeymap_iLookupKeymap (
	const struct CImeKeymap*	pKeymap,
	unsigned int				uKeyCode)
{
	if (uKeyCode == (unsigned int)-1)
		return	NFUNC_INVALID_CHAR ;

	if (IS_EXTRA_KEY (uKeyCode)) {
		/* ����L�[�}�b�v */
		int				i, nKeyCode ;
		unsigned int	uModifier ;

		nKeyCode	= EXTRA_KEYCODE_VKEY (uKeyCode) ;
		uModifier	= EXTRA_KEYCODE_MASK (uKeyCode) ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
			if (pKeymap->m_pKeyBinds [i].m_nKeyCode == nKeyCode &&
				pKeymap->m_pKeyBinds [i].m_uKeyMask == uModifier)
				return	pKeymap->m_pKeyBinds [i].m_nKeyFunction ;
		}
		return	NFUNC_INVALID_CHAR ;
	} else {
		/* �ʏ�B*/
		if (/*uKeyCode < 0 ||*/uKeyCode >= MAX_KEYBINDS)
			return	NFUNC_INVALID_CHAR ;

		return	pKeymap->m_rbyBaseMap [uKeyCode] ;
	}
}

BOOL
dlgEditKeymap_bDefineKeymap (
	struct CImeKeymap*			pKeymap,
	unsigned int				uKeyCode,
	int							iFuncCode)
{
	if (pKeymap == NULL)
		return	FALSE ;
	if (uKeyCode == (unsigned int)-1)
		return	FALSE ;
	if (IS_EXTRA_KEY (uKeyCode)) {
		struct CImeKeyBind*	pNewKeyBinds ;
		int				i, nKeyCode ;
		unsigned int	uModifier ;

		nKeyCode	= EXTRA_KEYCODE_VKEY (uKeyCode) ;
		uModifier	= EXTRA_KEYCODE_MASK (uKeyCode) ;
		for (i = 0 ; i < pKeymap->m_nKeyBinds ; i ++) {
			if (pKeymap->m_pKeyBinds [i].m_nKeyCode == nKeyCode &&
				pKeymap->m_pKeyBinds [i].m_uKeyMask == uModifier) {
				pKeymap->m_pKeyBinds [i].m_nKeyFunction	= iFuncCode ;
				return	TRUE ;
			}
		}
		/*	���t����Ȃ������ꍇ�B
		 */
		pNewKeyBinds	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * (pKeymap->m_nKeyBinds + 1)) ;
		if (pNewKeyBinds == NULL)
			return	FALSE ;
		if (pKeymap->m_nKeyBinds > 0)
			memcpy (pNewKeyBinds, pKeymap->m_pKeyBinds, sizeof (struct CImeKeyBind) * pKeymap->m_nKeyBinds) ;
		if (pKeymap->m_pKeyBinds != NULL)
			FREE (pKeymap->m_pKeyBinds) ;
		pKeymap->m_pKeyBinds	= pNewKeyBinds ;

		pKeymap->m_pKeyBinds [pKeymap->m_nKeyBinds].m_nKeyCode		= (short)uKeyCode ;
		pKeymap->m_pKeyBinds [pKeymap->m_nKeyBinds].m_uKeyMask		= (unsigned short)uModifier ;
		pKeymap->m_pKeyBinds [pKeymap->m_nKeyBinds].m_nKeyFunction	= iFuncCode ;
		pKeymap->m_nKeyBinds ++ ;
	} else {
		if (/*uKeyCode < 0 ||*/uKeyCode >= MAX_KEYBINDS)
			return	FALSE ;
		pKeymap->m_rbyBaseMap [uKeyCode]	= (BYTE)iFuncCode ;
	}
	return	TRUE ;
}

/*========================================================================
 *	private functions
 */
static	INT_PTR	dlgEditKeyBind_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgEditKeyBind_iOnCommand		(HWND, WPARAM, LPARAM) ;

static int	_srnComboBoxes [NUM_KEYMAPS]	= {
	IDC_COMBO_MAJORMODE_BIND,		IDC_COMBO_JMODE_BIND,
	IDC_COMBO_LATINMODE_BIND,		IDC_COMBO_JISX0208LATINMODE_BIND,
	IDC_COMBO_ABBREVMODE_BIND,
} ;

INT_PTR	CALLBACK
dlgEditKeyBindProc		(
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgEditKeyBind_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditKeyBind_iOnCommand (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgEditKeyBind_iOnInitDialog (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	struct TDlgEditKeyBindArg*	pArg	= (struct TDlgEditKeyBindArg*) lParam ;
	static struct {
		unsigned int	m_nKeyCode ;
		unsigned int	m_uKeyMask ;
	}	srExtraKeys []	= {
		/* �ǉ�����̂́A�J�[�\�����Ƃ��c�B*/
		{	VK_UP,			KEYMASK_NONE	},
		{	VK_DOWN,		KEYMASK_NONE	},
		{	VK_LEFT,		KEYMASK_NONE	},
		{	VK_RIGHT,		KEYMASK_NONE	},
		{	VK_RETURN,		KEYMASK_NONE	},
		{	VK_SPACE,		KEYMASK_NONE	},
		{	VK_BACK,		KEYMASK_NONE	},
		{	VK_TAB,			KEYMASK_NONE	},
		{	VK_INSERT,		KEYMASK_NONE	},
		{	VK_DELETE,		KEYMASK_NONE	},
		{	VK_HOME,		KEYMASK_NONE	},
		{	VK_END,			KEYMASK_NONE	},
		{	VK_PRIOR,		KEYMASK_NONE	},
		{	VK_NEXT,		KEYMASK_NONE	},
		{	VK_ESCAPE,		KEYMASK_NONE	},
		{	VK_KANA,		KEYMASK_NONE	},
		{	VK_CONVERT,		KEYMASK_NONE	},
		{	VK_NONCONVERT,	KEYMASK_NONE	},
		{	VK_F1,			KEYMASK_NONE	},
		{	VK_F2,			KEYMASK_NONE	},
		{	VK_F3,			KEYMASK_NONE	},
		{	VK_F4,			KEYMASK_NONE	},
		{	VK_F5,			KEYMASK_NONE	},
		{	VK_F6,			KEYMASK_NONE	},
		{	VK_F7,			KEYMASK_NONE	},
		{	VK_F8,			KEYMASK_NONE	},
		{	VK_F9,			KEYMASK_NONE	},
		{	VK_F10,			KEYMASK_NONE	},
		{	VK_F11,			KEYMASK_NONE	},
		{	VK_F12,			KEYMASK_NONE	},

		{	VK_UP,			KEYMASK_SHIFT	},
		{	VK_DOWN,		KEYMASK_SHIFT	},
		{	VK_LEFT,		KEYMASK_SHIFT	},
		{	VK_RIGHT,		KEYMASK_SHIFT	},
		{	VK_RETURN,		KEYMASK_SHIFT	},
		{	VK_SPACE,		KEYMASK_SHIFT	},
		{	VK_BACK,		KEYMASK_SHIFT	},
		{	VK_TAB,			KEYMASK_SHIFT	},
		{	VK_INSERT,		KEYMASK_SHIFT	},
		{	VK_DELETE,		KEYMASK_SHIFT	},
		{	VK_HOME,		KEYMASK_SHIFT	},
		{	VK_END,			KEYMASK_SHIFT	},
		{	VK_PRIOR,		KEYMASK_SHIFT	},
		{	VK_NEXT,		KEYMASK_SHIFT	},
		{	VK_ESCAPE,		KEYMASK_SHIFT	},
		{	VK_KANA,		KEYMASK_SHIFT	},
		{	VK_CONVERT,		KEYMASK_SHIFT	},
		{	VK_NONCONVERT,	KEYMASK_SHIFT	},
		{	VK_F1,			KEYMASK_SHIFT	},
		{	VK_F2,			KEYMASK_SHIFT	},
		{	VK_F3,			KEYMASK_SHIFT	},
		{	VK_F4,			KEYMASK_SHIFT	},
		{	VK_F5,			KEYMASK_SHIFT	},
		{	VK_F6,			KEYMASK_SHIFT	},
		{	VK_F7,			KEYMASK_SHIFT	},
		{	VK_F8,			KEYMASK_SHIFT	},
		{	VK_F9,			KEYMASK_SHIFT	},
		{	VK_F10,			KEYMASK_SHIFT	},
		{	VK_F11,			KEYMASK_SHIFT	},
		{	VK_F12,			KEYMASK_SHIFT	},

		{	VK_UP,			KEYMASK_CONTROL	},
		{	VK_DOWN,		KEYMASK_CONTROL	},
		{	VK_LEFT,		KEYMASK_CONTROL	},
		{	VK_RIGHT,		KEYMASK_CONTROL	},
		{	VK_RETURN,		KEYMASK_CONTROL	},
		{	VK_SPACE,		KEYMASK_CONTROL	},
		{	VK_BACK,		KEYMASK_CONTROL	},
		{	VK_TAB,			KEYMASK_CONTROL	},
		{	VK_INSERT,		KEYMASK_CONTROL	},
		{	VK_DELETE,		KEYMASK_CONTROL	},
		{	VK_HOME,		KEYMASK_CONTROL	},
		{	VK_END,			KEYMASK_CONTROL	},
		{	VK_PRIOR,		KEYMASK_CONTROL	},
		{	VK_NEXT,		KEYMASK_CONTROL	},
		{	VK_ESCAPE,		KEYMASK_CONTROL	},
		{	VK_KANA,		KEYMASK_CONTROL	},
		{	VK_CONVERT,		KEYMASK_CONTROL	},
		{	VK_NONCONVERT,	KEYMASK_CONTROL	},
		{	VK_F1,			KEYMASK_CONTROL	},
		{	VK_F2,			KEYMASK_CONTROL	},
		{	VK_F3,			KEYMASK_CONTROL	},
		{	VK_F4,			KEYMASK_CONTROL	},
		{	VK_F5,			KEYMASK_CONTROL	},
		{	VK_F6,			KEYMASK_CONTROL	},
		{	VK_F7,			KEYMASK_CONTROL	},
		{	VK_F8,			KEYMASK_CONTROL	},
		{	VK_F9,			KEYMASK_CONTROL	},
		{	VK_F10,			KEYMASK_CONTROL	},
		{	VK_F11,			KEYMASK_CONTROL	},
		{	VK_F12,			KEYMASK_CONTROL	},

		{	VK_UP,			KEYMASK_MENU	},
		{	VK_DOWN,		KEYMASK_MENU	},
		{	VK_LEFT,		KEYMASK_MENU	},
		{	VK_RIGHT,		KEYMASK_MENU	},
		{	VK_RETURN,		KEYMASK_MENU	},
		{	VK_SPACE,		KEYMASK_MENU	},
		{	VK_BACK,		KEYMASK_MENU	},
		{	VK_TAB,			KEYMASK_MENU	},
		{	VK_INSERT,		KEYMASK_MENU	},
		{	VK_DELETE,		KEYMASK_MENU	},
		{	VK_HOME,		KEYMASK_MENU	},
		{	VK_END,			KEYMASK_MENU	},
		{	VK_PRIOR,		KEYMASK_MENU	},
		{	VK_NEXT,		KEYMASK_MENU	},
		{	VK_ESCAPE,		KEYMASK_MENU	},
		{	VK_KANA,		KEYMASK_MENU	},
		{	VK_CONVERT,		KEYMASK_MENU	},
		{	VK_NONCONVERT,	KEYMASK_MENU	},
		{	VK_F1,			KEYMASK_MENU	},
		{	VK_F2,			KEYMASK_MENU	},
		{	VK_F3,			KEYMASK_MENU	},
		{	VK_F4,			KEYMASK_MENU	},
		{	VK_F5,			KEYMASK_MENU	},
		{	VK_F6,			KEYMASK_MENU	},
		{	VK_F7,			KEYMASK_MENU	},
		{	VK_F8,			KEYMASK_MENU	},
		{	VK_F9,			KEYMASK_MENU	},
		{	VK_F10,			KEYMASK_MENU	},
		{	VK_F11,			KEYMASK_MENU	},
		{	VK_F12,			KEYMASK_MENU	},

		// �P�Ɠ��̓L�[
		{	VK_KANJI,		KEYMASK_NONE	},	// ALT+����
		{	0xF3,			KEYMASK_NONE	},	// ���p/�S�p ���p��
		{	0xF4,			KEYMASK_NONE	},	// ���p/�S�p �S�p��
	} ;
	HWND		hWndControl ;
	TCHAR		buf [256] ;
	int			i, j ;
	BOOL		bSetCurSel ;
	LRESULT		lResult ;

	if (pArg == NULL)
		return	FALSE ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pArg) ;
	hWndControl	= GetDlgItem (hDlg, IDC_COMBO_KEY) ;
	if (hWndControl == NULL)
		return	FALSE ;

	bSetCurSel	= FALSE ;
	/*	�L�[�̒ǉ��B*/
	for (i = 0 ; i < 128 ; i ++) {
		vKey2String (buf, ARRAYSIZE (buf) - 1, i) ;
		buf [ARRAYSIZE (buf) - 1]	= TEXT ('\0') ;
		lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) buf) ;
		if (lResult != CB_ERR) {
			if (! bSetCurSel && ! IS_EXTRA_KEY (pArg->m_uKey) &&  (UINT) i == pArg->m_uKey) {
				(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
				bSetCurSel	= TRUE ;
			}
			(void) SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM) (DWORD) i) ;
		}
	}
	/* ExtraKey �̒ǉ��B*/
	for (i = 0 ; i < ARRAYSIZE (srExtraKeys) ; i ++) {
		vKey2StringEx (buf, ARRAYSIZE (buf) - 1, srExtraKeys [i].m_nKeyCode, srExtraKeys [i].m_uKeyMask) ;
		buf [ARRAYSIZE (buf) - 1]	= TEXT ('\0') ;

		lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) buf) ;
		if (lResult != CB_ERR) {
			if (! bSetCurSel &&
				IS_EXTRA_KEY (pArg->m_uKey) &&
				EXTRA_KEYCODE_VKEY (pArg->m_uKey) == srExtraKeys [i].m_nKeyCode &&
				EXTRA_KEYCODE_MASK (pArg->m_uKey) == srExtraKeys [i].m_uKeyMask) {
				(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
				bSetCurSel	= TRUE ;
			}
			(void) SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM) (DWORD) MAKE_EXTRA_KEYCODE (srExtraKeys [i].m_nKeyCode, srExtraKeys [i].m_uKeyMask)) ;
		}
	}
	if (! bSetCurSel)
		(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;

	for (i = 0 ; i < ARRAYSIZE (_srnComboBoxes) ; i ++) {
		hWndControl	= GetDlgItem (hDlg, _srnComboBoxes [i]) ;
		if (hWndControl == NULL)
			return	FALSE ;
		(void) SendMessage (hWndControl, CB_RESETCONTENT, (WPARAM) 0, (LPARAM) 0) ;
		bSetCurSel	= FALSE ;
		for (j = 0 ; j < NUM_SELECTABLE_FUNCTIONS ; j ++) {
			TCHAR	szBuffer [64] ;

			if (! bGetKeyFuncName (szBuffer, ARRAYSIZE (szBuffer) - 1, j))
				continue ;
			szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
			lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM)szBuffer) ;
			if (lResult != CB_ERR) {
				if (j == pArg->m_rbKeyBinds [i]) {
					(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
					bSetCurSel	= TRUE ;
				}
				SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM)(DWORD) j) ;
			}
		}

		// ����͕s�v @see skimconf.cpp: _srpFunctionNameTable �̃����o�Ɋ܂܂�Ă���
		// lResult	= SendMessage (hWndControl, CB_ADDSTRING, (WPARAM) 0, (LPARAM) TEXT ("-")) ;

		if (lResult != CB_ERR) {	// ���[�vj�����͕K���ʉ߂���̂Ɍx�����o���R���p�C���̂ЂƂ��āc
			// ������s�v
			// SendMessage (hWndControl, CB_SETITEMDATA, (WPARAM) lResult, (LPARAM)(DWORD) NFUNC_INVALID_CHAR) ;
			// �����I������Ȃ��������͂Ƃ肠�����Ō�̃A�C�e����I��ł���
			if (! bSetCurSel)
				(void) SendMessage (hWndControl, CB_SETCURSEL, (WPARAM) lResult, (LPARAM) 0) ;
		}
		/*	selection �����킹��B
		 */
	}
	return	FALSE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditKeyBind_iOnCommand (
	HWND				hDlg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	struct TDlgEditKeyBindArg*	pArg	= (struct TDlgEditKeyBindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	WORD	woControl		= LOWORD (wParam) ;
	//WORD	woNotification	= HIWORD (wParam) ;

	HWND	hWndControl ;
	LRESULT	nIndex ;
	int		i, nFuncNo ;

	switch (woControl) {
	case	IDOK:
		if (pArg != NULL) {
			hWndControl	= GetDlgItem (hDlg, IDC_COMBO_KEY) ;
			if (hWndControl != NULL) {
				LRESULT	lValue ;

				pArg->m_uKey	= (UINT) -1 ;
				nIndex			= SendMessage (hWndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
				if (nIndex != CB_ERR) {
					/*	CB_ERR �̒l�ɒ��ӁB���� -1 ������ǂ����A���̐摝����ƁA
					 *	EXTRA_KEYCODE �Əd�Ȃ�\��������c�B
					 */
					lValue	= SendMessage (hWndControl, CB_GETITEMDATA, (WPARAM) nIndex, (LPARAM) 0) ;
					if (lValue != CB_ERR)
						pArg->m_uKey	= (UINT) lValue ;
				}
				for (i = 0 ; i < ARRAYSIZE (_srnComboBoxes) ; i ++) {
					nFuncNo	= NFUNC_INVALID_CHAR ;
					hWndControl	= GetDlgItem (hDlg, _srnComboBoxes [i]) ;
					if (hWndControl != NULL) {
						nIndex	= SendMessage (hWndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
						if (nIndex != CB_ERR) {
							lValue	= SendMessage (hWndControl, CB_GETITEMDATA, (WPARAM) nIndex, (LPARAM) 0) ;
							if (lValue != CB_ERR)
								nFuncNo	= lValue ;
						}
					}
					pArg->m_rbKeyBinds [i]	= (BYTE)nFuncNo ;
				}
			} else {
				pArg->m_uKey	= (UINT) -1 ;
			}
		}
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

/*========================================================================
 *	���[�}�����ȃ��[�����X�g�̕ҏW�_�C�A���O�p�̊֐��B
 */
static	INT_PTR	dlgRomaKanaRule_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR	dlgRomaKanaRule_iOnCommand		(HWND, WPARAM, LPARAM, BOOL) ;
static	INT_PTR	dlgRomaKanaRule_iOnNotify		(HWND, WPARAM, LPARAM) ;

static	void	dlgRomaKanaRule_vSyncControls	(HWND) ;
static	void	dlgRomaKanaRule_vSearchNextItem			(HWND) ;
static	void	dlgRomaKanaRule_vEditRomaKanaRule		(HWND, BOOL) ;
static	void	dlgRomaKanaRule_vDeleteRomaKanaRule		(HWND) ;

static	BOOL	dlgRomaKanaRule_bFullUpdateRomaKanaRule			(HWND) ;
static	BOOL	dlgRomaKanaRule_bUpdateRomaKanaRule				(HWND) ;

static	INT_PTR	CALLBACK	ipDlgEditRomaKanaRuleProc	(HWND, UINT, WPARAM, LPARAM) ;

static	BOOL	dlgRomaKanaRule_bLoadRomaKanaRuleList	(void) ;
static	BOOL	dlgRomaKanaRule_bSaveRomaKanaRuleList	(void) ;

static	int		dlgRomaKanaRule_iGetSelectedRule		(HWND) ;

INT_PTR	CALLBACK
dlgRomaKanaRuleProc (
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgRomaKanaRule_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgRomaKanaRule_iOnCommand (hDlg, wParam, lParam, TRUE) ;
	case	WM_NOTIFY:
		return	dlgRomaKanaRule_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR	CALLBACK
dlgJisx0201RuleProc (
	HWND				hDlg,
	UINT				uMsg,
	WPARAM				wParam,
	LPARAM				lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		{
			INT_PTR	nResult	= dlgRomaKanaRule_iOnInitDialog (hDlg, wParam, lParam) ;

			EnableDlgItem (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA, FALSE) ;
			EnableDlgItem (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA, FALSE) ;
			return	nResult ;
		}
	case	WM_COMMAND:
		return	dlgRomaKanaRule_iOnCommand (hDlg, wParam, lParam, FALSE) ;
	case	WM_NOTIFY:
		return	dlgRomaKanaRule_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgRomaKanaRule_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	PROPSHEETPAGE*	pPropSheetPage ;
	HWND			hwnd ;

	pPropSheetPage	= (PROPSHEETPAGE*) lParam ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pPropSheetPage->lParam) ;

	hwnd	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwnd != NULL)
		ListView_SetExtendedListViewStyle (hwnd, LVS_EX_FULLROWSELECT) ;

	CheckRadioButton (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA) ;
	CheckRadioButton (hDlg, IDC_RADIO_DESCLONG, IDC_RADIO_DESCSHORT, IDC_RADIO_DESCSHORT) ;
	CheckRadioButton (hDlg, IDC_RADIO_SHOWROMAKANARULE0, IDC_RADIO_SHOWROMAKANARULE3, IDC_RADIO_SHOWROMAKANARULE0) ;
	dlgRomaKanaRule_vSyncControls (hDlg) ;
	return	TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgRomaKanaRule_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam,
	BOOL			bEnableHiraKata)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_RADIO_SHOWROMAKANARULE0:
	case	IDC_RADIO_SHOWROMAKANARULE1:
	case	IDC_RADIO_SHOWROMAKANARULE2:
	case	IDC_RADIO_SHOWROMAKANARULE3:
		if (woNotification == BN_CLICKED) {
			CheckRadioButton (hDlg, IDC_RADIO_SHOWROMAKANARULE0, IDC_RADIO_SHOWROMAKANARULE3, woControl) ;
			dlgRomaKanaRule_bFullUpdateRomaKanaRule (hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_RADIO_DESCLONG:
	case	IDC_RADIO_DESCSHORT:
		if (woNotification == BN_CLICKED) {
			if (IsDlgButtonChecked (hDlg, (woControl == IDC_RADIO_DESCLONG)? IDC_RADIO_DESCSHORT : IDC_RADIO_DESCLONG) == BST_CHECKED) {
				CheckRadioButton (hDlg, IDC_RADIO_DESCLONG, IDC_RADIO_DESCSHORT, woControl) ;
				dlgRomaKanaRule_bFullUpdateRomaKanaRule (hDlg) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA:
	case	IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA:
		if (woNotification == BN_CLICKED) {
			if (IsDlgButtonChecked (hDlg, (woControl == IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA)? IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA : IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA) == BST_CHECKED) {
				CheckRadioButton (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA, woControl) ;
				dlgRomaKanaRule_bUpdateRomaKanaRule (hDlg) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_SEARCH_ROMKANARULE_NEXT:
		if (woNotification == BN_CLICKED) {
			dlgRomaKanaRule_vSearchNextItem (hDlg) ;
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_INSERT_ROMKANARULE:
	case	IDC_BUTTON_EDIT_ROMKANARULE:
		dlgRomaKanaRule_vEditRomaKanaRule (hDlg, bEnableHiraKata) ;
		return	0 ;
	case	IDC_BUTTON_DELETE_ROMKANARULE:
		dlgRomaKanaRule_vDeleteRomaKanaRule (hDlg) ;
		return	0 ;
	case	IDOK:
	case	IDCANCEL:
//		SetWindowLong (hDlg, DWL_MSGRESULT, (woControl == IDOK)? TRUE : FALSE) ;
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgRomaKanaRule_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	int		idControl	= (int) wParam ;
	LPNMHDR	pnmh		= (LPNMHDR) lParam ;

	if (pnmh == NULL)
		return	0 ;

	switch (idControl) {
	case	IDC_LIST_ROMAKANARULE:
		{
			switch (pnmh->code) {
			case	LVN_DELETEALLITEMS:
				EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   FALSE) ;
				EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, FALSE) ;
				break ;
			case	LVN_DELETEITEM:
				{
					LPNMLISTVIEW	pnmv	= (LPNMLISTVIEW) lParam ;
					HWND			hwnd	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
					int	nCurSel ;

					nCurSel	= (hwnd != NULL)? ListView_GetSelectionMark (hwnd) : -1 ;
					if (pnmv != NULL && pnmv->iItem == nCurSel) {
						EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   FALSE) ;
						EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, FALSE) ;
					}
				}
				break ;
			case	NM_CLICK:
			case	NM_RCLICK:
			case	NM_DBLCLK:
			case	NM_RDBLCLK:
			case	LVN_ITEMACTIVATE:
			case	LVN_ITEMCHANGED:
				EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   TRUE) ;
				EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, TRUE) ;
				break ;
			default:
				break ;
			}
		}
		break ;
	default:
		break ;
	}
	return	1 ;
}

void
dlgRomaKanaRule_vSyncControls (
	HWND						hDlg)
{
	dlgRomaKanaRule_bFullUpdateRomaKanaRule (hDlg) ;
	return ;
}

void
dlgRomaKanaRule_vSearchNextItem (
	HWND			hDlg)
{
	TCHAR		bufText [ROMAKANALIST_LONG_LEN], bufMatch [ROMAKANALIST_LONG_LEN] ;
	UINT		nTextLen ;
	HWND		hwndRuleList ;
	LVFINDINFO	lvfi ;
	int			nStart, nItem ;

	hwndRuleList	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndRuleList == NULL)
		return ;

	nTextLen	= GetDlgItemText (hDlg, IDC_EDIT_SEARCH_ROMKANARULE, bufText, ARRAYSIZE (bufText) - 1) ;
	bufText [nTextLen]	= TEXT ('\0') ;
	if (nTextLen <= 0)
		return ;

	nStart		= ListView_GetSelectionMark (hwndRuleList) ;
	memset (&lvfi, 0, sizeof (lvfi)) ;
	lvfi.flags	= LVFI_PARTIAL ;
	lvfi.psz	= bufText ;
	nItem		= ListView_FindItem (hwndRuleList, nStart, &lvfi) ;
	if (nItem == -1)
		return ;

	/* �擪���炫����� match ���Ă��邩�m�F����B*/
	ListView_GetItemText (hwndRuleList, nItem, 0, bufMatch, ARRAYSIZE (bufMatch) - 1) ;
	bufMatch [ARRAYSIZE (bufMatch) - 1]	= TEXT ('\0') ;
	if (_tcsncmp (bufText, bufMatch, nTextLen) != 0)
		return ;

	ListView_EnsureVisible (hwndRuleList, nItem, FALSE) ;
	ListView_SetItemState  (hwndRuleList, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
	ListView_SetSelectionMark (hwndRuleList, nItem) ;

	/* Button �� Enable �ɂ��Ȃ���΁B*/
	EnableDlgItem (hDlg, IDC_BUTTON_EDIT_ROMKANARULE,   TRUE) ;
	EnableDlgItem (hDlg, IDC_BUTTON_DELETE_ROMKANARULE, TRUE) ;
	return ;
}

void
dlgRomaKanaRule_vEditRomaKanaRule (
	HWND			hDlg,
	BOOL			bEnableHiraKata)
{
	struct TSkkBaseRuleNode**	pplstRules ;
	HINSTANCE					hInstance ;
	struct TEditRomaKanaRuleArg	arg ;
	struct TSkkBaseRuleNode*	pNode ;
	HWND	hwndRuleList ;
	LVITEM	lvi ;
	int		nCurSel, iCurRule ;

	hInstance		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pplstRules		= (struct TSkkBaseRuleNode**) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pplstRules == NULL)
		return ;
	hwndRuleList	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndRuleList == NULL)
		return ;

	pNode	= NULL ;
	nCurSel	= ListView_GetSelectionMark (hwndRuleList) ;
	if (nCurSel != -1) {
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM ;
		lvi.iItem	= nCurSel ;
		if (! ListView_GetItem (hwndRuleList, &lvi) || lvi.lParam == 0)
			return ;
		pNode	= (struct TSkkBaseRuleNode*) lvi.lParam ;
	}

	arg.m_pInitValue	= pNode ;
	arg.m_nType			= -1 ;
	iCurRule			= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;
	arg.m_iRule			= iCurRule ;
	arg.m_bufHiraOrCommon [0]	= TEXT ('\0') ;
	arg.m_bufKata [0]			= TEXT ('\0') ;
	arg.m_nFunction				= NFUNC_INVALID_CHAR ;
	arg.m_bEnableRule1			= bEnableHiraKata ;
	if (DialogBoxParam (hInstance, MAKEINTRESOURCE (IDD_ROMAKANARULE2), hDlg, ipDlgEditRomaKanaRuleProc, (LPARAM) &arg) == IDOK) {
		/* update */
		struct TSkkBaseRuleNode*	pNewNode	= NULL ;
		TCHAR	szNew [ROMAKANALIST_LONG_LEN] ;
		LPCTSTR	pwNextState	= NULL ;
		HWND	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
		BOOL	bRomaKanaRuleShowKata, bRomaKanaRuleShowShort ;

		/* arg.m_pResult ��o�^����B*/
		/*	�������Ɏg�������̂� result �� state ���قȂ��Ă����ꍇ�ł��A���� state ���g���Ă���
		 *	�ꍇ�ɂ� reminder ���o���B�����łȂ��ꍇ�͕������Ă��ĕύX�����񂾂��� ok �Ƃ��邱�Ƃɂ�
		 *	��B
		 */
		/*	update or �ǉ��B
		 */
		pwNextState	= (arg.m_bufNextState [0] != TEXT ('\0'))? arg.m_bufNextState : NULL ;
		switch (arg.m_nType) {
		case	ROMAKANARULE_TYPE1:
			pNewNode	= dlgRomaKanaRule_pCreateType1Rule (arg.m_bufState, pwNextState, arg.m_iNextRule, arg.m_bufHiraOrCommon, arg.m_bufKata) ;
			break ;
		case	ROMAKANARULE_TYPE2:
			pNewNode	= dlgRomaKanaRule_pCreateType2Rule (arg.m_bufState, pwNextState, arg.m_iNextRule, arg.m_bufHiraOrCommon) ;
			break ;
		case	ROMAKANARULE_TYPE3:
			pNewNode	= dlgRomaKanaRule_pCreateType3Rule (arg.m_bufState, pwNextState, arg.m_iNextRule, arg.m_nFunction) ;
			break ;
		default:
			pNewNode	= NULL ;
			break ;
		}
		if (pNewNode == NULL)	/* fatal error ... */
			return ;

		/*	current state �Ō�������B
		 */
		pNode	= dlgRomaKanaRule_pSearchRuleByState (pplstRules [arg.m_iRule], arg.m_bufState, FALSE) ;
		if (pNode != NULL  && pNode != arg.m_pInitValue) {
			TCHAR	bufText [ROMAKANALIST_LONG_LEN*2] ;
			int		n ;

			{
				TCHAR	szOld [ROMAKANALIST_LONG_LEN] ;

				dlgRomaKanaRule_vGetEntryString (szOld, ARRAYSIZE (szOld), pNode,    arg.m_iRule, ROMAKANA_SHOW_BOTH, FALSE) ;
				dlgRomaKanaRule_vGetEntryString (szNew, ARRAYSIZE (szNew), pNewNode, arg.m_iRule, ROMAKANA_SHOW_BOTH, FALSE) ;
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%s �� %s �Œu�������܂��B��낵���ł����H"), szOld, szNew) ;
			}
			bufText [n]	= TEXT ('\0') ;

			if (MessageBox (hDlg, bufText, TEXT ("���[���̒u�������m�F"), MB_ICONQUESTION | MB_OKCANCEL) != IDOK) {
				FREE (pNewNode) ;
				return ;
			}
		}

		bRomaKanaRuleShowKata	= IsDlgButtonChecked (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA) == BST_CHECKED ;
		bRomaKanaRuleShowShort	= IsDlgButtonChecked (hDlg, IDC_RADIO_DESCSHORT) == BST_CHECKED ;

		dlgRomaKanaRule_vGetEntryString (szNew, ARRAYSIZE (szNew), pNewNode, arg.m_iRule, bRomaKanaRuleShowKata, bRomaKanaRuleShowShort) ;
		if (pNode != NULL) {
			LVFINDINFO	lvfi ;
			int			nItem ;

			/* �Â� node ����������B*/
			dlgRomaKanaRule_bUnegisterRule (&pplstRules [arg.m_iRule], pNode) ;
			dlgRomaKanaRule_vRegisterRule (&pplstRules [arg.m_iRule], pNewNode) ;

			/*	���ݕ\������Ă��郊�X�g�łȂ���΁AListView �̒��g���X�V����K�v�͂Ȃ��B
			 */
			if (arg.m_iRule == iCurRule) {
				memset (&lvfi, 0, sizeof (lvfi)) ;
				lvfi.flags	= LVFI_PARAM ;
				lvfi.lParam	= (LPARAM) pNode ;
				nItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;
				if (nItem != -1) {
					LVITEM	lvi ;

					memset (&lvi, 0, sizeof (lvi)) ;
					lvi.mask		= LVIF_PARAM | LVIF_TEXT ;
					lvi.lParam		= (LPARAM) pNewNode ;
					lvi.iItem		= nItem ;
					lvi.iSubItem	= 0 ;
					lvi.pszText		= szNew ;
					if (ListView_SetItem (hwndControl, &lvi)) {
						ListView_Update (hwndControl, nItem) ;
					}
				}
			}
			FREE (pNode) ;
		} else {
			/*	���ݕ\������Ă��郊�X�g�łȂ���΁AListView �̒��g���X�V����K�v�͂Ȃ��B
			 */
			if (arg.m_iRule == iCurRule) {
				/* �V���� node ��ǉ�����B*/
				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
				lvi.lParam	= (LPARAM) pNewNode ;
				lvi.pszText	= szNew ;
				if (ListView_InsertItem (hwndControl, &lvi) == -1) {
					FREE (pNewNode) ;
					return ;
				}
			}
			dlgRomaKanaRule_vRegisterRule (&pplstRules [arg.m_iRule], pNewNode) ;
		}
	}
	return ;
}

void
dlgRomaKanaRule_vDeleteRomaKanaRule (
	HWND						hDlg)
{
	struct TSkkBaseRuleNode**	pplstRules ;
	HWND	hwndRuleList ;
	struct TSkkBaseRuleNode*	pNode ;
	TCHAR	bufEntry [512] ;
	TCHAR	bufText [1024] ;
	LVITEM	lvi ;
	int		n, nCurSel, nResult, iRule ;

	pplstRules		= (struct TSkkBaseRuleNode**) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndRuleList	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (pplstRules == NULL || hwndRuleList == NULL)
		return ;
	nCurSel	= ListView_GetSelectionMark (hwndRuleList) ;
	if (nCurSel == -1)
		return ;

	iRule		= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask	= LVIF_PARAM ;
	lvi.iItem	= nCurSel ;
	if (! ListView_GetItem (hwndRuleList, &lvi) || lvi.lParam == 0)
		return ;

	pNode	= (struct TSkkBaseRuleNode*) lvi.lParam ;
	dlgRomaKanaRule_vGetEntryString (bufEntry, ARRAYSIZE (bufEntry), pNode, iRule, ROMAKANA_SHOW_BOTH, FALSE) ;
	n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("%s ���폜���܂��B��낵���ł����H"), bufEntry) ;
	bufText [n]	= TEXT ('\0') ;

	nResult	= MessageBox (hDlg, bufText, TEXT ("���[�}�������[���̍폜�m�F"), MB_ICONQUESTION | MB_OKCANCEL) ;
	if (nResult == IDOK) {
		dlgRomaKanaRule_bUnegisterRule (&pplstRules [iRule], pNode) ;
		FREE (pNode) ;
		ListView_DeleteItem (hwndRuleList, nCurSel) ;
	}
	return ;
}

int
dlgRomaKanaRule_iGetSelectedRule (
	HWND		hDlg)
{
	int		i ;
	for (i = 0 ; i < NUM_ROMAKANARULE ; i ++)
		if (IsDlgButtonChecked (hDlg, IDC_RADIO_SHOWROMAKANARULE0 + i) == BST_CHECKED)
			return	i ;
	return	0 ;
}

/*========================================================================
 *	private functions
 */
/*	����͑S���X�V���Ă��܂��̂Œ��ӁB
 */
BOOL
dlgRomaKanaRule_bFullUpdateRomaKanaRule (
	HWND						hDlg)
{
	struct TSkkBaseRuleNode**		pplstRules ;
	const struct TSkkBaseRuleNode*	pNode ;
	const struct TSkkBaseRuleNode*	pNodeSelected = NULL ;
	HWND	hwndControl	= NULL ;
	TCHAR	szBuffer [ROMAKANALIST_LONG_LEN] ;
	LVITEM	lvi ;
	int		nItem, nRule ;
	BOOL	bRomaKanaRuleShowShort, bRomaKanaRuleShowKata ;

	pplstRules	= (struct TSkkBaseRuleNode**) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pplstRules == NULL)
		return	FALSE ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndControl == NULL)
		return	FALSE ;

	/*	���݃Z���N�V�����}�[�N������m�[�h�͍X�V����Z���N�V�����}�[�N���c�������B
	 *	�}���`�Z���N�V�����ł͂Ȃ��̂ŁA1�L�����邾���� ok
	 */
	nItem	= ListView_GetSelectionMark (hwndControl) ;
	if (nItem != -1) {
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.mask	= LVIF_PARAM ;
		lvi.iItem	= nItem ;
		if (ListView_GetItem (hwndControl, &lvi))
			pNodeSelected	= (const struct TSkkBaseRuleNode*) lvi.lParam ;
	}

	bRomaKanaRuleShowKata	= IsDlgButtonChecked (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA) == BST_CHECKED ;
	bRomaKanaRuleShowShort	= IsDlgButtonChecked (hDlg, IDC_RADIO_DESCSHORT) == BST_CHECKED ;

	ListView_DeleteAllItems (hwndControl) ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_TEXT | LVIF_PARAM | LVIF_STATE ;
	lvi.state		= 0 ;
	lvi.stateMask	= 0 ;

	nRule	= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;
	pNode	= pplstRules [nRule] ;
	while (pNode != NULL) {
		dlgRomaKanaRule_vGetEntryString (szBuffer, ARRAYSIZE (szBuffer), pNode, nRule, bRomaKanaRuleShowKata, bRomaKanaRuleShowShort) ;
		lvi.iItem		= 0 ;
		lvi.iImage		= 0 ;
		lvi.iSubItem	= 0 ;
		lvi.lParam		= (LPARAM) pNode ;
		lvi.pszText		= szBuffer ;
		nItem			= ListView_InsertItem (hwndControl, &lvi) ;
		pNode	= pNode->_pNext ;
	}
	if (pNodeSelected != NULL) {
		LVFINDINFO	lvfi ;

		memset (&lvfi, 0, sizeof (lvfi)) ;
		lvfi.flags	= LVFI_PARAM ;
		lvfi.lParam	= (LPARAM) pNodeSelected ;
		nItem		= ListView_FindItem (hwndControl, -1, &lvfi) ;
		if (nItem != -1) {
			ListView_SetItemState  (hwndControl, nItem, LVIS_SELECTED, LVIS_SELECTED) ;
			ListView_SetSelectionMark (hwndControl, nItem) ;
		}
	}
	return	TRUE ;
}

BOOL
dlgRomaKanaRule_bUpdateRomaKanaRule (
	HWND						hDlg)
{
	const struct TSkkBaseRuleNode*	pNode ;
	HWND	hwndControl	= NULL ;
	TCHAR	szBuffer [ROMAKANALIST_LONG_LEN] ;
	LVITEM	lvi ;
	int		nIndex, nMaxIndex, iRule ;
	BOOL	bRomaKanaRuleShowKata, bRomaKanaRuleShowShort ;

	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ROMAKANARULE) ;
	if (hwndControl == NULL)
		return	FALSE ;

	bRomaKanaRuleShowKata	= IsDlgButtonChecked (hDlg, IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA) == BST_CHECKED ;
	bRomaKanaRuleShowShort	= IsDlgButtonChecked (hDlg, IDC_RADIO_DESCSHORT) == BST_CHECKED ;
	iRule					= dlgRomaKanaRule_iGetSelectedRule (hDlg) ;

	/*	���݃Z���N�V�����}�[�N������m�[�h�͍X�V����Z���N�V�����}�[�N���c�������B
	 *	�}���`�Z���N�V�����ł͂Ȃ��̂ŁA1�L�����邾���� ok
	 */
	memset (&lvi, 0, sizeof (lvi)) ;
	nMaxIndex	= ListView_GetItemCount (hwndControl) ;
	for (nIndex = 0 ; nIndex < nMaxIndex ; nIndex ++) {
		lvi.mask	= LVIF_PARAM ;
		lvi.iItem	= nIndex ;
		if (ListView_GetItem (hwndControl, &lvi)) {
			pNode	= (const struct TSkkBaseRuleNode*) lvi.lParam ;
			dlgRomaKanaRule_vGetEntryString (szBuffer, ARRAYSIZE (szBuffer), pNode, iRule, bRomaKanaRuleShowKata, bRomaKanaRuleShowShort) ;
			ListView_SetItemText (hwndControl, nIndex, 0, szBuffer) ;
		}
	}
	return	TRUE ;
}

/// char�����񂩂�wchar������� (1�o�C�g������p)
static void alnumtowsz(wchar* wsz, sizet n, const char* sz)
{
	ASSERT(wsz);
	ASSERT(n > 0);
	ASSERT(sz);

	sizet i;
	for (i = 0; i < n - 1; i++) {
		if (sz[i] == '\0') break;
		wsz[i] = sz[i];
	}
	wsz[i] = L'\0';
}

/// �f�t�H���g���[���̐ݒ�
void dlgRomaKanaRule_vInitializeDefaultRomaKanaRule(TCustomRomaKanaRuleArg* arg)
{
	ASSERT(arg);

	for (TSkkBaseRule* p = _rDefaultRomaKanaRule; p < _rDefaultRomaKanaRule + countof(_rDefaultRomaKanaRule); p++) {
		wchar wszRule[8];
		ASSERT(p->szRule);
		alnumtowsz(wszRule, countof(wszRule), p->szRule);
		wchar wszNext[8];
		const wchar* pNext;
		if (p->szNext) {
			pNext = wszNext;
			alnumtowsz(wszNext, countof(wszNext), p->szNext);
		} else {
			pNext = NULL;
		}
		ASSERT(p->nRule < NUM_ROMAKANARULE);
		sizet n = p->nRule;
		TSkkBaseRuleNode* pNode;
		if (p->nFunc == 0) {
			// �����o�^
			if (p->wszOut) {
				if (p->wszKata) {
					pNode = dlgRomaKanaRule_pCreateType1Rule(wszRule, pNext, p->nNext, p->wszOut, p->wszKata);
					if (pNode) dlgRomaKanaRule_vRegisterRule(&arg->m_rplstRomaKanaRules[n], pNode);
				} else {
					pNode = dlgRomaKanaRule_pCreateType2Rule(wszRule, pNext, p->nNext, p->wszOut);
					if (pNode) dlgRomaKanaRule_vRegisterRule(&arg->m_rplstRomaKanaRules[n], pNode);
				}
			}
			if (p->wszKana) {	// JIS X 0201�������݂���ꍇ�͓o�^
				pNode = dlgRomaKanaRule_pCreateType2Rule(wszRule, pNext, p->nNext, p->wszKana);
				if (pNode) dlgRomaKanaRule_vRegisterRule(&arg->m_rplstJisx0201KanaRules[n], pNode);
			}
		} else {
			// �֐��o�^
			pNode = dlgRomaKanaRule_pCreateType3Rule(wszRule, pNext, p->nNext, p->nFunc);
			if (pNode) dlgRomaKanaRule_vRegisterRule(&arg->m_rplstRomaKanaRules[n], pNode);
			if (p->wszKana == NULL) {	// JIS X 0201�������݂���ꍇ�͓o�^
				pNode = dlgRomaKanaRule_pCreateType3Rule(wszRule, pNext, p->nNext, p->nFunc);
				if (pNode) dlgRomaKanaRule_vRegisterRule(&arg->m_rplstJisx0201KanaRules[n], pNode);
			}
		}
	}
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pCreateType1Rule (
	LPCTSTR							pwState,		/* 0 �������Ȃ��c */
	LPCTSTR							pwNext,
	int								iNextRule,
	LPCTSTR							pwKana,
	LPCTSTR							pwKatakana)
{
	struct TSkkBaseRuleNode*	pNode ;
	LPTSTR	pwDest ;
	int		nSize, nStateLen, nKanaLen, nKatakanaLen ;

	if (pwState == NULL)
		return	NULL ;

	nSize			= sizeof (struct TSkkBaseRuleNode) ;
	nStateLen		= lstrlen (pwState) ;
	nKanaLen		= (pwKana     != NULL)? lstrlen (pwKana)     : 0 ;
	nKatakanaLen	= (pwKatakana != NULL)? lstrlen (pwKatakana) : 0 ;
	nSize			+= (nStateLen    + 1) * sizeof (TCHAR) ;
	nSize			+= (nKanaLen     + 1) * sizeof (TCHAR) ;
	nSize			+= (nKatakanaLen + 1) * sizeof (TCHAR) ;
	if (pwNext != NULL)
		nSize		+= (lstrlen (pwNext) + 1) * sizeof (TCHAR) ;
	if (nSize <= sizeof (struct TSkkBaseRuleNode))
		return	NULL ;
	pNode			= (struct TSkkBaseRuleNode*) MALLOC (nSize) ;
	if (pNode == NULL) return NULL;

	pNode->_nType	= ROMAKANARULE_TYPE1 ;
	pNode->_pNext	= NULL ;

	pwDest			= (LPTSTR) (pNode + 1) ;
	pNode->_T1._strState	= pwDest ;
	lstrcpy (pwDest, pwState) ;
	pwDest			+= nStateLen + 1 ;

	pNode->_T1._case._strHira	= pwDest ;
	if (pwKana != NULL) {
		lstrcpy (pwDest, pwKana) ;
	} else {
		*pwDest	= TEXT ('\0') ;
	}
	pwDest		+= nKanaLen + 1 ;

	pNode->_T1._case._strKata	= pwDest ;
	if (pwKatakana != NULL) {
		lstrcpy (pwDest, pwKatakana) ;
	} else {
		*pwDest	= TEXT ('\0') ;
	}
	pwDest		+= nKatakanaLen + 1 ;

	if (pwNext != NULL) {
		pNode->_T1._strNext	= pwDest ;
		lstrcpy (pwDest, pwNext) ;
	} else {
		pNode->_T1._strNext	= NULL ;
	}
	pNode->_T1._iNextRule	= iNextRule ;
	return	pNode ;
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pCreateType2Rule (
	LPCTSTR							pwState,		/* 0 �������Ȃ��c */
	LPCTSTR							pwNext,
	int								iNextRule,
	LPCTSTR							pwString)
{
	struct TSkkBaseRuleNode*	pNode ;
	LPTSTR	pwDest ;
	int		nSize, nStateLen, nStringLen ;

	if (pwState == NULL)
		return	NULL ;

	nSize			= sizeof (struct TSkkBaseRuleNode) ;
	nStateLen		= lstrlen (pwState) ;
	nStringLen		= (pwString != NULL)? lstrlen (pwString) : 0 ;
	nSize			+= (nStateLen  + 1) * sizeof (TCHAR) ;
	nSize			+= (nStringLen + 1) * sizeof (TCHAR) ;
	if (pwNext != NULL)
		nSize		+= (lstrlen (pwNext) + 1) * sizeof (TCHAR) ;
	if (nSize <= sizeof (struct TSkkBaseRuleNode))
		return	NULL ;
	pNode			= (struct TSkkBaseRuleNode*) MALLOC (nSize) ;
	if (pNode == NULL) return NULL;

	pNode->_nType	= ROMAKANARULE_TYPE2 ;
	pNode->_pNext	= NULL ;

	pwDest			= (LPTSTR) (pNode + 1) ;
	pNode->_T2._strState	= pwDest ;
	lstrcpy (pwDest, pwState) ;
	pwDest			+= nStateLen + 1 ;

	pNode->_T2._strOutput	= pwDest ;
	if (pwString != NULL) {
		lstrcpy (pwDest, pwString) ;
	} else {
		*pwDest	= TEXT ('\0') ;
	}
	pwDest		+= nStringLen + 1 ;

	if (pwNext != NULL) {
		pNode->_T2._strNext	= pwDest ;
		lstrcpy (pwDest, pwNext) ;
	} else {
		pNode->_T2._strNext	= NULL ;
	}
	pNode->_T2._iNextRule	= iNextRule ;
	return	pNode ;
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pCreateType3Rule (
	LPCTSTR							pwState,		/* 0 �������Ȃ��c */
	LPCTSTR							pwNext,
	int								iNextRule,
	int								nFuncNo)
{
	struct TSkkBaseRuleNode*	pNode ;
	LPTSTR	pwDest ;
	int		nSize, nStateLen ;

	if (pwState == NULL || nFuncNo < 0 || nFuncNo >= NUM_SELECTABLE_FUNCTIONS)
		return	NULL ;

	nSize			= sizeof (struct TSkkBaseRuleNode) ;
	nStateLen		= lstrlen (pwState) ;
	nSize			+= (nStateLen  + 1) * sizeof (TCHAR) ;
	if (pwNext != NULL)
		nSize		+= (lstrlen (pwNext) + 1) * sizeof (TCHAR) ;
	if (nSize <= sizeof (struct TSkkBaseRuleNode))
		return	NULL ;
	pNode			= (struct TSkkBaseRuleNode*) MALLOC (nSize) ;
	if (pNode == NULL) return NULL;

	pNode->_nType	= ROMAKANARULE_TYPE3 ;
	pNode->_pNext	= NULL ;

	pwDest			= (LPTSTR) (pNode + 1) ;
	pNode->_T3._strState	= pwDest ;
	lstrcpy (pwDest, pwState) ;
	pwDest			+= nStateLen + 1 ;
	pNode->_T3._nFunction	= nFuncNo ;

	if (pwNext != NULL) {
		pNode->_T3._strNext	= pwDest ;
		lstrcpy (pwDest, pwNext) ;
	} else {
		pNode->_T3._strNext	= NULL ;
	}
	pNode->_T3._iNextRule	= iNextRule ;
	return	pNode ;
}

struct TSkkBaseRuleNode*
pCopySkkBaseRuleNode (
	struct TSkkBaseRuleNode*		pNode)
{
	switch (pNode->_nType) {
	case	ROMAKANARULE_TYPE1:
		return	dlgRomaKanaRule_pCreateType1Rule (pNode->_T1._strState, pNode->_T1._strNext, pNode->_T1._iNextRule, pNode->_T1._case._strHira, pNode->_T1._case._strKata) ;
	case	ROMAKANARULE_TYPE2:
		return	dlgRomaKanaRule_pCreateType2Rule (pNode->_T2._strState, pNode->_T2._strNext, pNode->_T2._iNextRule, pNode->_T2._strOutput) ;
	case	ROMAKANARULE_TYPE3:
		return	dlgRomaKanaRule_pCreateType3Rule (pNode->_T3._strState, pNode->_T3._strNext, pNode->_T3._iNextRule, pNode->_T3._nFunction) ;
	default:
		return	NULL ;
	}
}

/// ���X�g�Ƀm�[�h��}��
void dlgRomaKanaRule_vRegisterRule(struct TSkkBaseRuleNode** pplst, struct TSkkBaseRuleNode* pNode)
{
	ASSERT(pplst);
	if (pNode == NULL) return;
	ASSERT(pNode->_pNext == NULL);

#if 1
	// �����ɑ}��
	struct TSkkBaseRuleNode* pPrev = NULL;
	struct TSkkBaseRuleNode* p = *pplst;
	while (p) {
		pPrev = p;
		p = p->_pNext;
	}
	if (pPrev == NULL) {
		*pplst = pNode;
		return;
	}
	pPrev->_pNext = pNode;
#else
	// �擪�ɑ}��
	pNode->_pNext	= *pplst ;
	*pplst			= pNode ;
	return ;
#endif
}

BOOL
dlgRomaKanaRule_bUnegisterRule (
	struct TSkkBaseRuleNode**			pplst,
	struct TSkkBaseRuleNode*			pNodeToUnregister)
{
	struct TSkkBaseRuleNode*	pNode ;
	struct TSkkBaseRuleNode*	pPrevNode ;

	pNode		= *pplst ;
	pPrevNode	= NULL ;
	while (pNode != NULL) {
		if (pNode == pNodeToUnregister) {
			if (pPrevNode != NULL) {
				pPrevNode->_pNext	= pNode->_pNext ;
			} else {
				*pplst	= pNode->_pNext ;
			}
			pNode->_pNext	= NULL ;
			return	TRUE ;
		}
		pPrevNode	= pNode ;
		pNode		= pNode->_pNext ;
	}
	return	FALSE ;
}

struct TSkkBaseRuleNode*
dlgRomaKanaRule_pSearchRuleByState (
	struct TSkkBaseRuleNode*	plst,
	LPCTSTR						strState,
	BOOL						bPrefix)
{
	struct TSkkBaseRuleNode*	pNode ;

	if (strState == NULL)
		return	NULL ;

	pNode		= plst ;
	if (bPrefix) {
		int		nStateLen	= lstrlen (strState) ;

		while (pNode != NULL) {
			switch (pNode->_nType) {
			case	ROMAKANARULE_TYPE1:
				if (! _tcsncmp (strState, pNode->_T1._strState, nStateLen))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE2:
				if (! _tcsncmp (strState, pNode->_T2._strState, nStateLen))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE3:
				if (! _tcsncmp (strState, pNode->_T3._strState, nStateLen))
					return	pNode ;
				break ;
			default:
				/* skip */
				break ;
			}
			pNode	= pNode->_pNext ;
		}
	} else {
		while (pNode != NULL) {
			switch (pNode->_nType) {
			case	ROMAKANARULE_TYPE1:
				if (! _tcscmp (strState, pNode->_T1._strState))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE2:
				if (! _tcscmp (strState, pNode->_T2._strState))
					return	pNode ;
				break ;
			case	ROMAKANARULE_TYPE3:
				if (! _tcscmp (strState, pNode->_T3._strState))
					return	pNode ;
				break ;
			default:
				/* skip */
				break ;
			}
			pNode	= pNode->_pNext ;
		}
	}
	return	NULL ;
}

/// ���X�g�̕���
struct TSkkBaseRuleNode* pCopyRomaKanaRuleList(struct TSkkBaseRuleNode* plst)
{
	// ���Ԃɕ���
	struct TSkkBaseRuleNode*	pNewList ;
	struct TSkkBaseRuleNode*	pNode ;
	struct TSkkBaseRuleNode*	pPrevNode ;
	struct TSkkBaseRuleNode*	pNewNode ;

	pNewList	= NULL ;
	pNode		= plst ;
	if (pNode == NULL)
		return	NULL ;

	pNewList	= pCopySkkBaseRuleNode (pNode) ;
	if (pNewList == NULL)
		return	NULL ;
	pPrevNode	= pNewList ;
	pNode		= pNode->_pNext ;

	while (pNode != NULL) {
		pNewNode	= pCopySkkBaseRuleNode (pNode) ;
		if (pNewNode == NULL) {
			dlgRomaKanaRule_vClearAllRules (&pNewList) ;
			return	NULL ;
		}
		pPrevNode->_pNext	= pNewNode ;
		pPrevNode			= pNewNode ;
		pNode	= pNode->_pNext ;
	}
	return	pNewList ;
}

void
dlgRomaKanaRule_vClearAllRules (
	struct TSkkBaseRuleNode**	pplst)
{
	struct TSkkBaseRuleNode*	pNode ;
	struct TSkkBaseRuleNode*	pNextNode ;

	if (pplst == NULL)
		return ;

	pNode		= *pplst ;
	while (pNode != NULL) {
		pNextNode		= pNode->_pNext ;
		FREE (pNode) ;
		pNode			= pNextNode ;
	}
	*pplst	= NULL ;
	return ;
}

void	dlgRomaKanaRule_vGetEntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleNode*	pRule,
	int								iRule,
	int								bKatakana,
	BOOL							bShort)
{
	switch (pRule->_nType) {
	case	ROMAKANARULE_TYPE1:
		dlgRomaKanaRule_vGetType1EntryString (pszBuffer, nBufferSize, &pRule->_T1, iRule, bKatakana, bShort) ;
		break ;
	case	ROMAKANARULE_TYPE2:
		dlgRomaKanaRule_vGetType2EntryString (pszBuffer, nBufferSize, &pRule->_T2, iRule, bShort) ;
		break ;
	case	ROMAKANARULE_TYPE3:
		dlgRomaKanaRule_vGetType3EntryString (pszBuffer, nBufferSize, &pRule->_T3, iRule, bShort) ;
		break ;
	default:
		break ;
	}
	return ;
}

void
dlgRomaKanaRule_vGetType1EntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleT1*	pRule,
	int								iRule,
	int								nKatakana,
	BOOL							bShort)
{
	TCHAR	szState [ROMAKANALIST_LONG_LEN+1], szOutput [ROMAKANALIST_LONG_LEN+1] ;
	int		n, nDestLen ;

	/*	�\�����镶���񂪒��߂���ꍇ�ɂ� ... �ŏȗ����ĕ\�������� (full �\�����ǂ����̓��j���[��
	 *	�d�����B)
	 *	�Ƃ͂����A�{���ɒ��������������ꂽ�ꍇ�ɂ͌��Ǐȗ�����K�v������킯�Łc���̂������
	 *	�������l����ƁA�ǂ�����ׂ����c�H
	 */
	nDestLen	= bShort? ROMAKANALIST_SHORT_LEN : ROMAKANALIST_LONG_LEN ;
	/* function name, string ��S�� */
	n			= iString2PrintableString (szState, nDestLen, pRule->_strState, lstrlen (pRule->_strState)) ;
	szState [n]	= TEXT ('\0') ;
	switch (nKatakana) {
	case	ROMAKANA_SHOW_HIRA:
		n		= iShortStringCopy (szOutput, nDestLen, pRule->_case._strHira, lstrlen (pRule->_case._strHira)) ;
		break ;
	case	ROMAKANA_SHOW_KATA:
		n		= iShortStringCopy (szOutput, nDestLen, pRule->_case._strKata, lstrlen (pRule->_case._strKata)) ;
		break ;
	case	ROMAKANA_SHOW_BOTH:
	default:
		{
			TCHAR	szHira [ROMAKANALIST_LONG_LEN+1], szKata [ROMAKANALIST_LONG_LEN+1] ;

			n		= iShortStringCopy (szHira, nDestLen, pRule->_case._strHira, lstrlen (pRule->_case._strHira)) ;
			szHira [n]	= TEXT ('\0') ;
			n		= iShortStringCopy (szKata, nDestLen, pRule->_case._strKata, lstrlen (pRule->_case._strKata)) ;
			szKata [n]	= TEXT ('\0') ;
			n		= wnsprintf (szOutput, nDestLen, TEXT ("%s/%s"), szHira, szKata) ;
		}
		break ;
	}
	szOutput [n]	= TEXT ('\0') ;

	if (pRule->_strNext != NULL) {
		TCHAR	szNext [ROMAKANALIST_LONG_LEN+1] ;

		n			= iString2PrintableString (szNext, nDestLen, pRule->_strNext, lstrlen (pRule->_strNext)) ;
		szNext [n]	= TEXT ('\0') ;
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d \"%s\")"), szState, szOutput, pRule->_iNextRule, szNext) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:\"%s\")"), szState, szOutput, szNext) ;
		}
	} else {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d)"), szState, szOutput, pRule->_iNextRule) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s"), szState, szOutput) ;
		}
	}
	pszBuffer [n]	= TEXT ('\0') ;
	return ;
}

void
dlgRomaKanaRule_vGetType2EntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleT2*	pRule,
	int								iRule,
	BOOL							bShort)
{
	TCHAR	szState  [ROMAKANALIST_LONG_LEN+1], szOutput [ROMAKANALIST_LONG_LEN+1] ;
	int		n, nDestLen ;

	/*	�\�����镶���񂪒��߂���ꍇ�ɂ� ... �ŏȗ����ĕ\�������� (full �\�����ǂ����̓��j���[��
	 *	�d�����B)
	 *	�Ƃ͂����A�{���ɒ��������������ꂽ�ꍇ�ɂ͌��Ǐȗ�����K�v������킯�Łc���̂������
	 *	�������l����ƁA�ǂ�����ׂ����c�H
	 */
	nDestLen	= bShort? ROMAKANALIST_SHORT_LEN : ROMAKANALIST_LONG_LEN ;

	/* function name, string ��S�� */
	n	= iString2PrintableString (szState, nDestLen, pRule->_strState, lstrlen (pRule->_strState)) ;
	szState [n]	= TEXT ('\0') ;
	/* Output �̏ȗ��͂��Ȃ��̂��H */
	n			= iShortStringCopy (szOutput, nDestLen, pRule->_strOutput, lstrlen (pRule->_strOutput)) ;
	szOutput [n]	= TEXT ('\0') ;
	if (pRule->_strNext != NULL) {
		TCHAR	szNext [ROMAKANALIST_LONG_LEN+1] ;

		n			= iString2PrintableString (szNext, nDestLen, pRule->_strNext, lstrlen (pRule->_strNext)) ;
		szNext [n]	= TEXT ('\0') ;
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d \"%s\")"), szState, szOutput, pRule->_iNextRule, szNext) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:\"%s\")"), szState, szOutput, szNext) ;
		}
	} else {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d)"), szState, szOutput, pRule->_iNextRule) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s"), szState, szOutput) ;
		}
	}
	pszBuffer [n]	= TEXT ('\0') ;
	return ;
}

void
dlgRomaKanaRule_vGetType3EntryString (
	LPTSTR							pszBuffer,
	int								nBufferSize,
	const struct TSkkBaseRuleT3*	pRule,
	int								iRule,
	BOOL							bShort)
{
	TCHAR	szState  [ROMAKANALIST_LONG_LEN+1], szFuncName [ROMAKANALIST_LONG_LEN+1], szNext [ROMAKANALIST_LONG_LEN+1] ;
	LPCWSTR	pwNext ;
	int		n ;

	/*	�\�����镶���񂪒��߂���ꍇ�ɂ� ... �ŏȗ����ĕ\�������� (full �\�����ǂ����̓��j���[��
	 *	�d�����B)
	 *	�Ƃ͂����A�{���ɒ��������������ꂽ�ꍇ�ɂ͌��Ǐȗ�����K�v������킯�Łc���̂������
	 *	�������l����ƁA�ǂ�����ׂ����c�H
	 */
	/* function name, string ��S�� */
	if (bShort) {
		n	= iString2PrintableString (szState, ROMAKANALIST_SHORT_LEN, pRule->_strState, lstrlen (pRule->_strState)) ;
		szState [n]	= TEXT ('\0') ;

		if (! bGetKeyFuncName (szFuncName, ROMAKANALIST_SHORT_LEN * 2, pRule->_nFunction))
			szFuncName [0]	= TEXT ('\0') ;
		szFuncName [ROMAKANALIST_SHORT_LEN * 2]	= TEXT ('\0') ;

		if (pRule->_strNext != NULL) {
			n	= iString2PrintableString (szNext, ROMAKANALIST_SHORT_LEN, pRule->_strNext, lstrlen (pRule->_strNext)) ;
			szNext [n]	= TEXT ('\0') ;
			pwNext	= szNext ;
		} else {
			pwNext	= NULL ;
		}
	} else {
		n	= iString2PrintableString (szState, ARRAYSIZE (szState) - 1, pRule->_strState, lstrlen (pRule->_strState)) ;
		szState [n]	= TEXT ('\0') ;

		if (! bGetKeyFuncName (szFuncName, ARRAYSIZE (szFuncName) - 1, pRule->_nFunction))
			szFuncName [0]	= TEXT ('\0') ;
		szFuncName [ARRAYSIZE (szFuncName) - 1]	= TEXT ('\0') ;

		if (pRule->_strNext != NULL) {
			n	= iString2PrintableString (szNext, ARRAYSIZE (szNext) - 1, pRule->_strNext, lstrlen (pRule->_strNext)) ;
			szNext [n]	= TEXT ('\0') ;
			pwNext	= szNext ;
		} else {
			pwNext	= NULL ;
		}
	}
	if (pwNext != NULL) {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d \"%s\")"), szState, szFuncName, pRule->_iNextRule, pwNext) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:\"%s\")"), szState, szFuncName, pwNext) ;
		}
	} else {
		if (pRule->_iNextRule != iRule) {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s(��:#%d)"), szState, szFuncName, pRule->_iNextRule) ;
		} else {
			n	= wnsprintf (pszBuffer, nBufferSize - 1, TEXT ("%s = %s"), szState, szFuncName) ;
		}
	}
	pszBuffer [n]	= TEXT ('\0') ;
	return ;
}

/*=================================================================================
 */
static	LRESULT		dlgEditRomaKanaRule_lOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	LRESULT		dlgEditRomaKanaRule_lOnCommand		(HWND, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
ipDlgEditRomaKanaRuleProc (
	HWND			hDlg,
	UINT			uMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMessage) {
	case	WM_INITDIALOG:
		return	dlgEditRomaKanaRule_lOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditRomaKanaRule_lOnCommand (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) 0 ;
}

LRESULT
dlgEditRomaKanaRule_lOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
#if 1
	/// �ݒ荀�ڂɕ\������R�}���h�Ƃ��̏���
	/// �ނ��뎩���\�[�g�ɂ��đS��ޓ���Ă���������
	static BYTE srComboListInit[] = {
		NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT,
		NFUNC_SKK_SET_HENKAN_POINT_SUBR,
		NFUNC_SKK_PURGE_FROM_JISYO,
		NFUNC_SKK_KAKUTEI,

		NFUNC_SKK_ABBREV_MODE,
		NFUNC_SKK_JISX0208_LATIN_MODE,
		NFUNC_SKK_LATIN_MODE,

		NFUNC_SKK_TOGGLE_JISX0201,
		NFUNC_SKK_TOGGLE_KATAKANA,
		NFUNC_SKK_TOGGLE_CHARACTERS,

		NFUNC_SKK_TODAY,
		NFUNC_SKK_INPUT_BY_CODE_OR_MENU,
		NFUNC_SKK_CURRENT_KUTEN,
		NFUNC_SKK_CURRENT_TOUTEN,
	};
#else
	/* ����Őݒ荀�ڂ͏\�����H */
	static struct {
		LPCTSTR		m_strText ;
		int			m_nFunction ;
	}	srComboListInitValues []	= {
#ifndef ENGLISH_MESSAGE
		{ TEXT("�����R�[�h�\�� (display-code)"),			NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT, },
		{ TEXT("�ڈ�ݒu (set-henkan-point)"),				NFUNC_SKK_SET_HENKAN_POINT_SUBR, },
		{ TEXT("�����P��폜 (purge-from-jisyo)"),			NFUNC_SKK_PURGE_FROM_JISYO, },
		{ TEXT("�m�� (kakutei)"),							NFUNC_SKK_KAKUTEI, },

		{ TEXT("�p�P��ϊ����[�h (abbrev-mode)"),			NFUNC_SKK_ABBREV_MODE, },
		{ TEXT("�S�p�p�����[�h (jisx0208-latin-mode)"),		NFUNC_SKK_JISX0208_LATIN_MODE, },
		{ TEXT("�p�����[�h (latin-mode)"),					NFUNC_SKK_LATIN_MODE, },

		{ TEXT("���p�J�i/����p�� (toggle-jisx0201)"),		NFUNC_SKK_TOGGLE_JISX0201, },
		{ TEXT("�Ђ炪��/���p�J�i (toggle-katakana)"),		NFUNC_SKK_TOGGLE_KATAKANA, },
		{ TEXT("�Ђ炪��/�J�^�J�i (toggle-characters)"),	NFUNC_SKK_TOGGLE_CHARACTERS, },

		{ TEXT("���t���� (today)"),							NFUNC_SKK_TODAY, },
		{ TEXT("�R�[�h���� (input-by-code-or-menu)"),		NFUNC_SKK_INPUT_BY_CODE_OR_MENU, },
		{ TEXT("�ہE��_���� (current-kuten)"),				NFUNC_SKK_CURRENT_KUTEN, },
		{ TEXT("�_�E�Ǔ_���� (current-touten)"),			NFUNC_SKK_CURRENT_TOUTEN, },
#else
		{ TEXT("skk-display-code-for-char-at-point"),		NFUNC_SKK_DISPLAY_CODE_FOR_CHAR_AT_POINT, },
		{ TEXT("skk-current-kuten"),						NFUNC_SKK_CURRENT_KUTEN, },
		{ TEXT("skk-current-touten"),						NFUNC_SKK_CURRENT_TOUTEN, },
		{ TEXT("skk-today"),								NFUNC_SKK_TODAY, },
		{ TEXT("skk-input-by-code-or-menu"),				NFUNC_SKK_INPUT_BY_CODE_OR_MENU, },
		{ TEXT("skk-toggle-characters"),					NFUNC_SKK_TOGGLE_CHARACTERS, },
		{ TEXT("skk-set-henkan-point-subr"),				NFUNC_SKK_SET_HENKAN_POINT_SUBR, },
		{ TEXT("skk-kakutei"),								NFUNC_SKK_KAKUTEI, },
		{ TEXT("skk-abbrev-mode"),							NFUNC_SKK_ABBREV_MODE, },
		{ TEXT("skk-purge-from-jisyo"),						NFUNC_SKK_PURGE_FROM_JISYO, },
		{ TEXT("skk-latin-mode"),							NFUNC_SKK_LATIN_MODE, },
		{ TEXT("skk-jisx0208-latin-mode"),					NFUNC_SKK_JISX0208_LATIN_MODE, },
		{ TEXT("skk-toggle-katakana"),						NFUNC_SKK_TOGGLE_KATAKANA, },
		{ TEXT("skk-toggle-jisx0201"),						NFUNC_SKK_TOGGLE_JISX0201, },
#endif
	} ;
#endif

	struct TEditRomaKanaRuleArg*	pArg	= (struct TEditRomaKanaRuleArg*) lParam ;
	HWND	hwndControl ;
	LPCWSTR	pwState, pwNext, pwHira, pwKata, pwCommon ;
	LRESULT	i ;
	int		nFunction, nRadio, nNextRule, nRule ;
	HICON	hIcon ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) pArg) ;
	if (pArg == NULL)
		return	FALSE ;

	if (pArg->m_pInitValue != NULL) {
		struct TSkkBaseRuleNode*	pNode	= pArg->m_pInitValue ;

		switch (pNode->_nType) {
		case	ROMAKANARULE_TYPE1:
			pwState		= pNode->_T1._strState ;
			nRule		= pArg->m_iRule ;
			pwNext		= (pNode->_T1._strNext != NULL)? pNode->_T1._strNext : TEXT ("") ;
			nNextRule	= pNode->_T1._iNextRule ;
			pwHira		= pNode->_T1._case._strHira ;
			pwKata		= pNode->_T1._case._strKata ;
			pwCommon	= TEXT ("") ;
			nRadio		= IDC_RADIO_HIRAKATA ;
			nFunction	= NFUNC_INVALID_CHAR ;
			break ;
		case	ROMAKANARULE_TYPE2:
			pwState		= pNode->_T2._strState ;
			nRule		= pArg->m_iRule ;
			pwNext		= (pNode->_T2._strNext != NULL)? pNode->_T2._strNext : TEXT ("") ;
			nNextRule	= pNode->_T2._iNextRule ;
			pwHira		= TEXT ("") ;
			pwKata		= TEXT ("") ;
			pwCommon	= pNode->_T2._strOutput ;
			nFunction	= NFUNC_INVALID_CHAR ;
			nRadio		= IDC_RADIO_COMMON ;
			break ;
		case	ROMAKANARULE_TYPE3:
		default:
			pwState		= pNode->_T3._strState ;
			nRule		= pArg->m_iRule ;
			pwNext		= (pNode->_T3._strNext != NULL)? pNode->_T3._strNext : TEXT ("") ;
			nNextRule	= pNode->_T3._iNextRule ;
			pwHira		= TEXT ("") ;
			pwKata		= TEXT ("") ;
			pwCommon	= TEXT ("") ;
			nRadio		= IDC_RADIO_MACRO ;
			nFunction	= pNode->_T3._nFunction ;
			break ;
		}
	} else {
		pwState		= TEXT ("") ;
		pwNext		= TEXT ("") ;
		pwHira		= TEXT ("") ;
		pwKata		= TEXT ("") ;
		pwCommon	= TEXT ("") ;
		nRadio		= IDC_RADIO_HIRAKATA ;
		nFunction	= NFUNC_INVALID_CHAR ;
		nRule		= pArg->m_iRule ;
		nNextRule	= pArg->m_iRule ;
	}

	SetDlgItemText (hDlg, IDC_EDIT_STATE,			pwState) ;
	SetDlgItemText (hDlg, IDC_EDIT_NEXTSTATE,		pwNext) ;

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_STATE_RULENO) ;
	if (hwndControl != NULL) {
#if NUM_ROMAKANARULE <= 10
		TCHAR buf[2];		// 10�ȉ��Ȃ�ꌅ�ŏ\��
		buf[1] = TEXT('\0');
#else
		TCHAR	buf [12] ;	// 32�r�b�g�͍ő�10�� �� �I�[1���� �� 4�̔{����
#endif
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
#if NUM_ROMAKANARULE <= 10
			buf[0] = TEXT('0') + (TCHAR)i;
#else
			int		n ;
			n		= wnsprintf (buf, ARRAYSIZE (buf) - 1, TEXT ("%d"), i) ;
			// buf [n]	= TEXT ('\0') ;		// ������Ȃ�ł���肷��
#endif
			// �R���g���[���̖����ɕ������ǉ������l��^����
			SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) buf) ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) i, (LPARAM) i) ;
/*
			LRESULT	nPos ;
			nPos	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) buf) ;
			if (nPos != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) i, (LPARAM) i) ;
			}
*/
		}
		// ASSERT(0 <= nRule && nRule < NUM_ROMAKANARULE);	// ���I������ dlgRomaKanaRule_iGetSelectedRule(hDlg) ��0��Ԃ��K�����͈̔͂Ɏ��܂�
		// ���݂̃��[���ɃJ�[�\�������킹��
		SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) nRule, (LPARAM) 0) ;
/*
		nItems	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
		for (i = 0 ; i < nItems ; i ++) {
			LRESULT		lData ;
			lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
			if (lData != CB_ERR && lData == nRule) {
				(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) ;
				break ;
			}
		}
		if (i == nItems)
			(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
*/
	}
	/// @todo ��������̃��[�v�Ɠ����ɉ񂷂ׂ��B���s�t�@�C���̃T�C�Y���x�̗����Ƀ����b�g(���ɃT�C�Y)�B�C�͂̂��鎞�ɒ���
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_NEXTSTATE_RULENO) ;
	if (hwndControl != NULL) {
#if NUM_ROMAKANARULE <= 10
		TCHAR buf[2];		// 10�ȉ��Ȃ�ꌅ�ŏ\��
		buf[1] = TEXT('\0');
#else
		TCHAR	buf [12] ;	// 32�r�b�g�͍ő�10�� �� �I�[1���� �� 4�̔{����
#endif
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
#if NUM_ROMAKANARULE <= 10
			buf[0] = TEXT('0') + (TCHAR)i;
#else
			int		n ;
			n		= wnsprintf (buf, ARRAYSIZE (buf) - 1, TEXT ("%d"), i) ;
			// buf [n]	= TEXT ('\0') ;		// ������Ȃ�ł���肷��
#endif
			// �R���g���[���̖����ɕ������ǉ������l��^����
			SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) buf) ;
			SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) i, (LPARAM) i) ;
/*
			LRESULT	nPos ;
			nPos	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) buf) ;
			if (nPos != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) i, (LPARAM) i) ;
			}
*/
		}
		// ASSERT(0 <= nNextRule && nNextRule < NUM_ROMAKANARULE);	// ���I������ dlgRomaKanaRule_iGetSelectedRule(hDlg) ��0��Ԃ��K�����͈̔͂Ɏ��܂�
		// ���݂̃��[���ɃJ�[�\�������킹��
		SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) nNextRule, (LPARAM) 0) ;
/*
		nItems	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
		for (i = 0 ; i < nItems ; i ++) {
			LRESULT		lData ;
			lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
			if (lData != CB_ERR && lData == nNextRule) {
				(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) ;
				break ;
			}
		}
		if (i == nItems)
			(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
*/
	}
	if (! pArg->m_bEnableRule1 && nRadio == IDC_RADIO_HIRAKATA)
		nRadio	= IDC_RADIO_COMMON ;

	SetDlgItemText (hDlg, IDC_EDIT_HIRA,			pwHira) ;
	SetDlgItemText (hDlg, IDC_EDIT_KATA,			pwKata) ;
	SetDlgItemText (hDlg, IDC_EDIT_COMMONSTRING,	pwCommon) ;
	CheckRadioButton (hDlg, IDC_RADIO_HIRAKATA,		IDC_RADIO_MACRO, nRadio) ;
	if (pArg->m_bEnableRule1) {
		EnableDlgItem  (hDlg, IDC_RADIO_HIRAKATA,	TRUE) ;
		EnableDlgItem  (hDlg, IDC_EDIT_HIRA,		(nRadio == IDC_RADIO_HIRAKATA)) ;
		EnableDlgItem  (hDlg, IDC_EDIT_KATA,		(nRadio == IDC_RADIO_HIRAKATA)) ;
	} else {
		EnableDlgItem  (hDlg, IDC_RADIO_HIRAKATA,	FALSE) ;
		EnableDlgItem  (hDlg, IDC_EDIT_HIRA,		FALSE) ;
		EnableDlgItem  (hDlg, IDC_EDIT_KATA,		FALSE) ;
	}
	EnableDlgItem  (hDlg, IDC_EDIT_COMMONSTRING,	(nRadio == IDC_RADIO_COMMON)) ;
	EnableDlgItem  (hDlg, IDC_COMBO_MACRO,			(nRadio == IDC_RADIO_MACRO)) ;

	/*	IDC_COMBO_MACRO �̒��g�͏��������Ă����Ȃ��Ƃ����Ȃ��B
	 *	���ł�����ł��ݒ�ł���Ƃ͎v���Ȃ��̂ŁA�@�\�͈ȉ��̂��̂����ɂ���F
	 *
	 */
	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_MACRO) ;
	if (hwndControl != NULL) {
		int	i ;
#if 1
		// ���ł�����ł��ݒ�ł���悤�ɂ��邽�߂̕z��
		for (i = 0; i < countof(srComboListInit); i++) {
			BYTE n = srComboListInit[i];
			TCHAR sz[64];
			bGetKeyFuncName(sz, countof(sz), n);
			::SendMessage(hwndControl, CB_INSERTSTRING, 0, (LPARAM)sz);
			::SendMessage(hwndControl, CB_SETITEMDATA, 0, (LPARAM)n);
		}
#else
		for (i = 0 ; i < ARRAYSIZE (srComboListInitValues) ; i ++) {
			LRESULT	nPos ;
			nPos	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) 0, (LPARAM) srComboListInitValues [i].m_strText) ;
			if (nPos != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) 0, (LPARAM) srComboListInitValues [i].m_nFunction) ;
			}
		}
#endif
		LRESULT	nItems	= SendMessage (hwndControl, CB_GETCOUNT, (WPARAM) 0, (LPARAM) 0) ;
		for (i = 0 ; i < nItems ; i ++) {
			LRESULT		lData ;
			lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) i, (LPARAM) 0) ;
			if (lData != CB_ERR && lData == nFunction) {
				(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) i, (LPARAM) 0) ;
				break ;
			}
		}
		if (i == nItems)
			(void) SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
	}
	hIcon	= (HICON) LoadImage ((HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE), MAKEINTRESOURCE (IDI_BTNSPECIAL), IMAGE_ICON, 16, 16, LR_SHARED) ;
	if (hIcon != NULL) {
		hwndControl	= GetDlgItem (hDlg, IDC_BUTTON_STATESPECIAL) ;
		if (hwndControl != NULL) {
			SendMessage (hwndControl, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
		}
		hwndControl	= GetDlgItem (hDlg, IDC_BUTTON_NEXTSTATESPECIAL) ;
		if (hwndControl != NULL) {
			SendMessage (hwndControl, BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon) ;
		}
	}
	return	FALSE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

LRESULT
dlgEditRomaKanaRule_lOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	struct TEditRomaKanaRuleArg*	pArg ;
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	pArg	= (struct TEditRomaKanaRuleArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return	1 ;

	switch (woControl) {
	case	IDC_BUTTON_STATESPECIAL:
		if (woNotification == BN_CLICKED) {
			HMENU	hMenu	= CreatePopupMenu () ;
			if (hMenu != NULL) {
				if (InsertMenu (hMenu, 1, MF_BYCOMMAND | MF_STRING, 1, TEXT ("�C�ӂ̈ꕶ��")) &&
					InsertMenu (hMenu, 2, MF_BYCOMMAND | MF_STRING, 2, TEXT ("�ꉹ")) &&
					InsertMenu (hMenu, 3, MF_BYCOMMAND | MF_STRING, 3, TEXT ("�q��")) &&
					InsertMenu (hMenu, 4, MF_BYCOMMAND | MF_STRING, 4, TEXT ("\\"))) {
					RECT	rc ;
					int		iCmd ;
					LPCTSTR	pwText ;

					GetWindowRect (GetDlgItem (hDlg, woControl), &rc) ;
					iCmd	= TrackPopupMenuEx (hMenu, TPM_TOPALIGN | TPM_LEFTBUTTON | TPM_RETURNCMD, rc.left, rc.bottom, hDlg, NULL) ;
					switch (iCmd) {
					case	1:
						pwText	= TEXT ("\\?") ;
						break ;
					case	2:
						pwText	= TEXT ("\\V") ;
						break ;
					case	3:
						pwText	= TEXT ("\\C") ;
						break ;
					case	4:
						pwText	= TEXT ("\\\\") ;
						break ;
					default:
						pwText	= NULL ;
						break ;
					}
					if (pwText != NULL) {
						HWND	hWnd	= GetDlgItem (hDlg, IDC_EDIT_STATE) ;
						if (hWnd != NULL)
							(void) SendMessage (hWnd, EM_REPLACESEL, (WPARAM) TRUE, (LPARAM) pwText) ;
					}
				}
				DestroyMenu (hMenu) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_BUTTON_NEXTSTATESPECIAL:
		if (woNotification == BN_CLICKED) {
			HMENU	hMenu	= CreatePopupMenu () ;
			if (hMenu != NULL) {
				if (InsertMenu (hMenu, 0, MF_BYPOSITION | MF_STRING, 1, TEXT ("���͕���")) &&
					InsertMenu (hMenu, 1, MF_BYPOSITION | MF_STRING, 2, TEXT ("\\"))) {
					RECT	rc ;
					int		iCmd ;
					LPCTSTR	pwText ;

					GetWindowRect (GetDlgItem (hDlg, woControl), &rc) ;
					iCmd	= TrackPopupMenuEx (hMenu, TPM_TOPALIGN | TPM_LEFTBUTTON | TPM_RETURNCMD, rc.left, rc.bottom, hDlg, NULL) ;
					switch (iCmd) {
					case	1:
						pwText	= TEXT ("\\I") ;
						break ;
					case	2:
						pwText	= TEXT ("\\\\") ;
						break ;
					default:
						pwText	= NULL ;
						break ;
					}
					if (pwText != NULL) {
						HWND	hWnd	= GetDlgItem (hDlg, IDC_EDIT_NEXTSTATE) ;
						if (hWnd != NULL)
							(void) SendMessage (hWnd, EM_REPLACESEL, (WPARAM) TRUE, (LPARAM) pwText) ;
					}
				}
				DestroyMenu (hMenu) ;
			}
			return	0 ;
		}
		break ;
	case	IDC_RADIO_HIRAKATA:
	case	IDC_RADIO_COMMON:
	case	IDC_RADIO_MACRO:
		if (woNotification == BN_CLICKED) {
			CheckRadioButton (hDlg, IDC_RADIO_HIRAKATA, IDC_RADIO_MACRO, woControl) ;
			EnableDlgItem  (hDlg, IDC_EDIT_HIRA,			(woControl == IDC_RADIO_HIRAKATA)) ;
			EnableDlgItem  (hDlg, IDC_EDIT_KATA,			(woControl == IDC_RADIO_HIRAKATA)) ;
			EnableDlgItem  (hDlg, IDC_EDIT_COMMONSTRING,	(woControl == IDC_RADIO_COMMON)) ;
			EnableDlgItem  (hDlg, IDC_COMBO_MACRO,			(woControl == IDC_RADIO_MACRO)) ;
			return	0 ;
		}
		break ;
	case	IDOK:
		{
			HWND		hwndControl ;
			LRESULT		lCurSel, lData ;
			BOOL		bError	= FALSE ;

			if (! GetDlgItemText (hDlg, IDC_EDIT_STATE,	pArg->m_bufState, ARRAYSIZE (pArg->m_bufState)))
				pArg->m_bufState [0]	= TEXT ('\0') ;
			if (! GetDlgItemText (hDlg, IDC_EDIT_NEXTSTATE, pArg->m_bufNextState, ARRAYSIZE (pArg->m_bufNextState)))
				pArg->m_bufNextState [0]	= TEXT ('\0') ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_STATE_RULENO) ;
			if (hwndControl != NULL) {
				lCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
				if (lCurSel != CB_ERR) {
					lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) lCurSel, (LPARAM) 0) ;
					if (lData != CB_ERR && 0 <= lData && lData < NUM_ROMAKANARULE) {
						pArg->m_iRule	= (int) lData ;
					} else {
						bError			= TRUE ;
					}
				} else {
					bError			= TRUE ;
				}
			}
			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_NEXTSTATE_RULENO) ;
			if (hwndControl != NULL) {
				lCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
				if (lCurSel != CB_ERR) {
					lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) lCurSel, (LPARAM) 0) ;
					if (lData != CB_ERR && 0 <= lData && lData < NUM_ROMAKANARULE) {
						pArg->m_iNextRule	= (int) lData ;
					} else {
						bError			= TRUE ;
					}
				} else {
					bError			= TRUE ;
				}
			}
			if (IsDlgButtonChecked (hDlg, IDC_RADIO_HIRAKATA) != BST_UNCHECKED) {
				if (! GetDlgItemText (hDlg, IDC_EDIT_HIRA,	pArg->m_bufHiraOrCommon,	ARRAYSIZE (pArg->m_bufHiraOrCommon)))
					pArg->m_bufHiraOrCommon [0]	= TEXT ('\0') ;
				if (! GetDlgItemText (hDlg, IDC_EDIT_KATA,	pArg->m_bufKata,			ARRAYSIZE (pArg->m_bufKata)))
					pArg->m_bufKata [0]	= TEXT ('\0') ;
				pArg->m_nType	= ROMAKANARULE_TYPE1 ;
			} else if (IsDlgButtonChecked (hDlg, IDC_RADIO_COMMON) != BST_UNCHECKED) {
				if (! GetDlgItemText (hDlg, IDC_EDIT_COMMONSTRING,	pArg->m_bufHiraOrCommon,	ARRAYSIZE (pArg->m_bufHiraOrCommon)))
					pArg->m_bufHiraOrCommon [0]	= TEXT ('\0') ;
				pArg->m_nType	= ROMAKANARULE_TYPE2 ;
			} else {
				HWND	hwndControl ;

				/* IDC_RADIO_MACRO */
				pArg->m_nType		= ROMAKANARULE_TYPE3 ;
				pArg->m_nFunction	= NFUNC_INVALID_CHAR ;

				hwndControl	= GetDlgItem (hDlg, IDC_COMBO_MACRO) ;
				if (hwndControl != NULL) {
					LRESULT	nCurSel ;

					nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
					if (nCurSel != CB_ERR) {
						LRESULT	lData ;

						lData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
						if (lData != CB_ERR) {
							pArg->m_nFunction	= lData ;
						}
					}
				}
			}
			/*	�G���[�`�F�b�N�B*/
			if (pArg->m_bufState [0] == TEXT ('\0')) {
				MessageBox (hDlg, TEXT ("����Ԃ��ݒ肳��Ă��܂���B"), TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
				return	1 ;
			}
			if (pArg->m_nType == ROMAKANARULE_TYPE3 && pArg->m_nFunction == NFUNC_INVALID_CHAR) {
				MessageBox (hDlg, TEXT ("�}�N�����ݒ肳��Ă��܂���B"), TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
				return	1 ;
			}
			if (bError) {
				return	1 ;
			}
		}
	case	IDCANCEL:
		EndDialog (hDlg, woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

/*========================================================================
 *
 */
static	INT_PTR				dlgEditSpecialKeybind_iOnInitDialog (HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditSpecialKeybind_iOnCommand	(HWND, WPARAM, LPARAM) ;
static	INT_PTR				dlgEditSpecialKeybind_iOnNotify		(HWND, WPARAM, LPARAM) ;
static	void				dlgEditSpecialKeybind_vSyncControl	(HWND) ;
static	int					dlgEditSpecialKeybind_iGetShowKeyType	(HWND) ;
static	void				dlgEditSpecialKeybind_vAddKeybind	(HWND) ;
static	void				dlgEditSpecialKeybind_vDeleteKeybind(HWND) ;
static	INT_PTR	CALLBACK	dlgEditSpecialKeyProc	(HWND, UINT, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
dlgEditSpecialKeybindProc (
	HWND			hDlg,
	UINT			nMessage,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		return	dlgEditSpecialKeybind_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgEditSpecialKeybind_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgEditSpecialKeybind_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

INT_PTR
dlgEditSpecialKeybind_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
//	struct TCustomSpecialKeybindArg*	pArg ;
	HWND	hwndControl ;

	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_VIEWITEM) ;
	if (hwndControl != NULL) {
		static const struct {
			LPCTSTR		_strText ;
			int			_iValue ;
		}	srComboInitValues [] = {
			{	TEXT ("�ϊ��J�n�L�["),		KEYBIND_SHOW_STARTHENKANKEYS	},
			{	TEXT ("�⊮�J�n�L�["),		KEYBIND_SHOW_TRYCOMPLETIONKEYS	},
			{	TEXT ("�⊮�O���L�["),	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS	},
			{	TEXT ("�⊮�����L�["),	KEYBIND_SHOW_NEXTCOMPLETIONKEYS	},
			{	TEXT ("�����[�h�J�n�L�["),	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS	},
			{	TEXT ("���ꌩ�o������"),	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS	},
		} ;
		int		i ;
		LRESULT	nIndex ;

		for (i = 0 ; i < ARRAYSIZE (srComboInitValues) ; i ++) {
			nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) srComboInitValues [i]._strText) ;
			if (nIndex != CB_ERR) {
				SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) srComboInitValues [i]._iValue) ;
			}
		}
		SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_VIEWITEM, KEYBIND_SHOW_STARTHENKANKEYS) ;
	}
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (hwndControl != NULL) {
//		ListView_SetExtendedListViewStyle (hwndControl, LVS_EX_BORDERSELECT) ;
	}
	dlgEditSpecialKeybind_vSyncControl (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgEditSpecialKeybind_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_COMBO_VIEWITEM:
		if (woNotification == CBN_SELCHANGE) {
			dlgEditSpecialKeybind_vSyncControl (hDlg) ;
		}
		return	0 ;
	case	IDC_BUTTON_ADD:
	case	IDC_BUTTON_EDIT:
		dlgEditSpecialKeybind_vAddKeybind (hDlg) ;
		return	0 ;
	case	IDC_BUTTON_DELETE:
		dlgEditSpecialKeybind_vDeleteKeybind (hDlg) ;
		return	0 ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgEditSpecialKeybind_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	return	1 ;
	UNREFERENCED_PARAMETER (hDlg) ;
	UNREFERENCED_PARAMETER (wParam) ;
	UNREFERENCED_PARAMETER (lParam) ;
}

void
dlgEditSpecialKeybind_vSyncControl (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg*	pArg ;
	HWND	hwndControl ;
	int		i, iNumKeys ;
	const BYTE*	pbKeys ;
	TCHAR		szBuffer [32] ;
	int		iShowKeyType ;
	LVITEM	lvi ;

	pArg		= (struct TCustomSpecialKeybindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	if (pArg == NULL)
		return ;
	iShowKeyType	= dlgEditSpecialKeybind_iGetShowKeyType (hDlg) ;
	hwndControl		= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (hwndControl == NULL)
		return ;
	ListView_DeleteAllItems (hwndControl) ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask	= LVIF_PARAM | LVIF_TEXT ;
	/*
				{	TEXT ("�ϊ��J�n�L�["),		KEYBIND_SHOW_STARTHENKANKEYS	},
			{	TEXT ("�⊮�J�n�L�["),		KEYBIND_SHOW_TRYCOMPLETIONKEYS	},
			{	TEXT ("�⊮�O���L�["),	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS	},
			{	TEXT ("�⊮�����L�["),	KEYBIND_SHOW_NEXTCOMPLETIONKEYS	},
			{	TEXT ("�����[�h�J�n�L�["),	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS	},
			{	TEXT ("���ꌩ�o������"),	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS	},
			*/
	switch (iShowKeyType) {
	case	KEYBIND_SHOW_STARTHENKANKEYS:
		pbKeys		= pArg->m_bufStartHenkanKeys ;
		iNumKeys	= pArg->m_iNumStartHenkanKeys ;
		break ;
	case	KEYBIND_SHOW_TRYCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufTryCompletionKeys ;
		iNumKeys	= pArg->m_iNumTryCompletionKeys ;
		break ;
	case	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufPreviousCompletionKeys ;
		iNumKeys	= pArg->m_iNumPreviousCompletionKeys ;
		break ;
	case	KEYBIND_SHOW_NEXTCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufNextCompletionKeys ;
		iNumKeys	= pArg->m_iNumNextCompletionKeys ;
		break ;
	case	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS:
		pbKeys		= pArg->m_bufSetHenkanPointSubrKeys ;
		iNumKeys	= pArg->m_iNumSetHenkanPointSubrKeys ;
		break ;
	case	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS:
		pbKeys		= pArg->m_bufSpecialMidashiCharKeys ;
		iNumKeys	= pArg->m_iNumSpecialMidashiCharKeys ;
		break ;
	default:
		return ;
	}
	for (i = 0 ; i < iNumKeys ; i ++) {
		vKey2String (szBuffer, ARRAYSIZE (szBuffer), pbKeys [i]) ;
		lvi.iItem	= i ;
		lvi.pszText	= szBuffer ;
		lvi.lParam	= (LPARAM) i ;
		(void) ListView_InsertItem (hwndControl, &lvi) ;
	}
	return ;
}

void
dlgEditSpecialKeybind_vAddKeybind (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg*	pArg ;
	HINSTANCE	hInst ;
	HWND	hwndControl ;
	int		iShowKeyType ;
	UINT	uArg ;
	TCHAR	szKey [64], bufText [128] ;
	LVITEM	lvi ;
	INT_PTR	nResult ;
	int		nText ;
	BYTE*	pbKeys ;
	int*	piNumKeys ;
	BOOL*	pbModified ;

	hInst		= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;
	pArg		= (struct TCustomSpecialKeybindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (pArg == NULL || hwndControl == NULL)
		return ;

	iShowKeyType	= dlgEditSpecialKeybind_iGetShowKeyType (hDlg) ;
	switch (iShowKeyType) {
	case	KEYBIND_SHOW_STARTHENKANKEYS:
		pbKeys		= pArg->m_bufStartHenkanKeys ;
		piNumKeys	= &pArg->m_iNumStartHenkanKeys ;
		pbModified	= &pArg->m_bStartHenkanKeysModified ;
		break ;
	case	KEYBIND_SHOW_TRYCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufTryCompletionKeys ;
		piNumKeys	= &pArg->m_iNumTryCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufPreviousCompletionKeys ;
		piNumKeys	= &pArg->m_iNumPreviousCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_NEXTCOMPLETIONKEYS:
		pbKeys		= pArg->m_bufNextCompletionKeys ;
		piNumKeys	= &pArg->m_iNumNextCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS:
		pbKeys		= pArg->m_bufSetHenkanPointSubrKeys ;
		piNumKeys	= &pArg->m_iNumSetHenkanPointSubrKeys ;
		pbModified	= &pArg->m_bSetHenkanPointSubrKeysModified ;
		break ;
	case	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS:
		pbKeys		= pArg->m_bufSpecialMidashiCharKeys ;
		piNumKeys	= &pArg->m_iNumSpecialMidashiCharKeys ;
		pbModified	= &pArg->m_bSpecialMidashiCharKeysModified ;
		break ;
	default:
		return ;
	}
	/* ����ȏ�L�[���ǉ��ł��Ȃ��̂ł͂Ȃ����ƒ��ׂ�B*/
	if (*piNumKeys >= MAX_SPECIALKEYS)
		return ;
	uArg	= iShowKeyType ;
	nResult	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_SPECIALKEY), hDlg, dlgEditSpecialKeyProc, (LPARAM) &uArg) ;
	if (nResult != IDOK)
		return ;
	if (uArg >= MAX_KEYBINDS)
		return ;

	memset (&lvi, 0, sizeof (lvi)) ;
	vKey2String (szKey, ARRAYSIZE (szKey), uArg) ;

	/* �����L�[�����݂�����܂����̂Ń`�F�b�N����B*/
	if (memchr (pbKeys, uArg, *piNumKeys) != NULL) {
		/* �`�͊��ɓo�^����Ă��܂��A�Ƃ����Ƃ��B*/
		nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("�L�[ ``%s'' �͊��ɓo�^����Ă��܂��B"), szKey) ;
		bufText [nText]	= TEXT ('\0') ;
		(void) MessageBox (hDlg, bufText, TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
		return ;
	}
	lvi.iItem	= *piNumKeys ;
	pbKeys [*piNumKeys]	= (BYTE) uArg ;
	++ *piNumKeys ;
	*pbModified	= TRUE ;

	/*	vSynControl ���ĂԂƏd���̂ŁAListView_InsertItem �̌Ăяo���ŗ����B
	 */
	lvi.mask	= LVIF_TEXT | LVIF_PARAM ;
	lvi.pszText	= szKey ;
	lvi.lParam	= (LPARAM) lvi.iItem ;
	ListView_InsertItem (hwndControl, &lvi) ;
	return ;
}

void
dlgEditSpecialKeybind_vDeleteKeybind (
	HWND			hDlg)
{
	struct TCustomSpecialKeybindArg*	pArg ;
	HWND	hwndControl ;
	TCHAR	bufText [128], szKey [64] ;
	int		nCurSel, iKeyIndex, nText, iShowKeyType ;
	BYTE*	pbKeybinds ;
	LVITEM	lvi ;
	int*	piNumKeys ;
	BOOL*	pbModified ;

	pArg		= (struct TCustomSpecialKeybindArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_SPECIALKEYBIND) ;
	if (pArg == NULL || hwndControl == NULL)
		return ;

	nCurSel		= ListView_GetSelectionMark (hwndControl) ;
	if (nCurSel == -1)
		return ;

	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask	= LVIF_PARAM ;
	lvi.iItem	= nCurSel ;
	if (! ListView_GetItem (hwndControl, &lvi))
		return ;
	iKeyIndex	= (int) lvi.lParam ;

	iShowKeyType	= dlgEditSpecialKeybind_iGetShowKeyType (hDlg) ;
	switch (iShowKeyType) {
	case	KEYBIND_SHOW_STARTHENKANKEYS:
		pbKeybinds	= pArg->m_bufStartHenkanKeys ;
		piNumKeys	= &pArg->m_iNumStartHenkanKeys ;
		pbModified	= &pArg->m_bStartHenkanKeysModified ;
		break ;
	case	KEYBIND_SHOW_TRYCOMPLETIONKEYS:
		pbKeybinds	= pArg->m_bufTryCompletionKeys ;
		piNumKeys	= &pArg->m_iNumTryCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_PREVIOUSCOMPLETIONKEYS:
		pbKeybinds	= pArg->m_bufPreviousCompletionKeys ;
		piNumKeys	= &pArg->m_iNumPreviousCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_NEXTCOMPLETIONKEYS:
		pbKeybinds	= pArg->m_bufNextCompletionKeys ;
		piNumKeys	= &pArg->m_iNumNextCompletionKeys ;
		pbModified	= &pArg->m_bCompletionKeysModified ;
		break ;
	case	KEYBIND_SHOW_SETHENKANPOINTSUBRKEYS:
		pbKeybinds	= pArg->m_bufSetHenkanPointSubrKeys ;
		piNumKeys	= &pArg->m_iNumSetHenkanPointSubrKeys ;
		pbModified	= &pArg->m_bSetHenkanPointSubrKeysModified ;
		break ;
	case	KEYBIND_SHOW_SPECIALMIDASHICHARKEYS:
		pbKeybinds	= pArg->m_bufSpecialMidashiCharKeys ;
		piNumKeys	= &pArg->m_iNumSpecialMidashiCharKeys ;
		pbModified	= &pArg->m_bSpecialMidashiCharKeysModified ;
		break ;
	default:
		return ;
	}
	if (iKeyIndex < 0 || iKeyIndex > *piNumKeys || *piNumKeys <= 0)
		return ;

	vKey2String (szKey, ARRAYSIZE (szKey), *(pbKeybinds + iKeyIndex)) ;
	nText	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("�L�[ ``%s'' ���폜���܂��B��낵���ł����H"), szKey) ;
	bufText [nText]	= TEXT ('\0') ;
	if (MessageBox (hDlg, bufText, TEXT ("����L�[�o�C���h�̍폜�m�F"), MB_ICONQUESTION | MB_OKCANCEL) != IDOK)
		return ;

	if ((iKeyIndex + 1) < *piNumKeys)
		memmove (pbKeybinds + iKeyIndex, pbKeybinds + iKeyIndex + 1, (*piNumKeys - iKeyIndex - 1)) ;
	-- *piNumKeys ;
	*pbModified	= TRUE ;
	ListView_DeleteItem (hwndControl, nCurSel) ;
	return ;
}

int
dlgEditSpecialKeybind_iGetShowKeyType (
	HWND		hDlg)
{
	HWND		hwndControl ;
	LRESULT		nCurSel, nData ;

	hwndControl	= GetDlgItem (hDlg, IDC_COMBO_VIEWITEM) ;
	if (hwndControl == NULL)
		return	-1 ;
	nCurSel		= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
	if (nCurSel == CB_ERR)
		return	-1 ;
	nData		= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
	if (nData == CB_ERR)
		return	-1 ;
	return	nData ;
}

INT_PTR	CALLBACK
dlgEditSpecialKeyProc (
	HWND		hDlg,
	UINT		nMessage,
	WPARAM		wParam,
	LPARAM		lParam)
{
	switch (nMessage) {
	case	WM_INITDIALOG:
		{
			UINT*	puArg ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
			puArg	= (UINT*) lParam ;

			/* ComboBox �ɃL�[���X�g��o�^����B*/
			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SPECIALKEY) ;
			if (hwndControl != NULL) {
				TCHAR	bufText [64] ;
				int		i ;
				LRESULT	nIndex ;

				for (i = 32 ; i < 127 ; i ++) {
					vKey2String (bufText, ARRAYSIZE (bufText), i) ;
					nIndex	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) bufText) ;
					if (nIndex != CB_ERR) {
						SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nIndex, (LPARAM) i) ;
					}
				}
				SendMessage (hwndControl, CB_SETCURSEL, (WPARAM) -1, (LPARAM) 0) ;
			}
			SetDlgItemText (hDlg, IDC_EDIT_DESCRIPTION, (*puArg)? TEXT ("�����}�[�N�J�n�L�[") : TEXT ("����ꌩ�o�������L�[")) ;
			return	(INT_PTR) TRUE ;
		}
	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			//WORD	woNotification	= HIWORD (wParam) ;

			switch (woControl) {
			case	IDOK:
				{
					HWND	hwndControl ;

					hwndControl	= GetDlgItem (hDlg, IDC_COMBO_SPECIALKEY) ;
					if (hwndControl != NULL) {
						LRESULT	nCurSel ;
						UINT*	puKey ;
						UINT	uKey	= (UINT)-1 ;

						puKey	= (UINT*) GetWindowLongPtr (hDlg, DWLP_USER) ;
						if (puKey != NULL) {
							nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
							if (nCurSel != -1) {
								uKey	= (UINT) SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
							}
							*puKey	= uKey ;
						}
						if (uKey == -1) {
							(void) MessageBox (hDlg, TEXT ("�L�[���ݒ肳��Ă��܂���B"), TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
							return	0 ;
						}
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				return	0 ;
			}
		}
	case	WM_NOTIFY:
		return	1 ;
	default:
		break ;
	}
	return	(INT_PTR) FALSE ;
}

/*========================================================================
 *	�S�p�x�N�g���̕ҏW
 */
static	INT_PTR		dlgZenkakuVector_iOnInitDialog	(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgZenkakuVector_iOnCommand		(HWND, WPARAM, LPARAM) ;
static	INT_PTR		dlgZenkakuVector_iOnNotify		(HWND, WPARAM, LPARAM) ;

static	BOOL		dlgZenkakuVector_bInitializeZenkakuList		(HWND) ;
static	BOOL		dlgZenkakuVector_bEditZenkakuVector			(HWND, int) ;
static	void		dlgZenkakuVector_vCreateListItemText		(LPTSTR, int, int, LPCTSTR) ;

static	INT_PTR	CALLBACK	dlgEditZenkakuVectorProc	(HWND, UINT, WPARAM, LPARAM) ;

INT_PTR	CALLBACK
dlgZenkakuVectorProc (
	HWND			hDlg,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		return	dlgZenkakuVector_iOnInitDialog (hDlg, wParam, lParam) ;
	case	WM_COMMAND:
		return	dlgZenkakuVector_iOnCommand (hDlg, wParam, lParam) ;
	case	WM_NOTIFY:
		return	dlgZenkakuVector_iOnNotify (hDlg, wParam, lParam) ;
	default:
		break ;
	}
	return	FALSE ;
}

INT_PTR
dlgZenkakuVector_iOnInitDialog (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	//PROPSHEETPAGE*	pPropPage	= (PROPSHEETPAGE*) lParam ;
	SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;
	dlgZenkakuVector_bInitializeZenkakuList (hDlg) ;
	return	(INT_PTR) TRUE ;
	UNREFERENCED_PARAMETER (wParam) ;
}

INT_PTR
dlgZenkakuVector_iOnCommand (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	WORD	woControl		= LOWORD (wParam) ;
	//WORD	woNotification	= HIWORD (wParam) ;

	switch (woControl) {
	case	IDC_LIST_ZENKAKUVECTOR:
		break ;
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
	case	IDC_BUTTON_DELETE:
		if (dlgZenkakuVector_bEditZenkakuVector (hDlg, woControl)) {
			PropSheet_Changed (GetParent (hDlg), hDlg) ;
			return	0 ;
		}
		break ;
	case	IDOK:
	case	IDCANCEL:
		EndDialog (hDlg, (INT_PTR) woControl) ;
		return	0 ;
	default:
		break ;
	}
	return	(INT_PTR) 1 ;
	UNREFERENCED_PARAMETER (lParam) ;
}

INT_PTR
dlgZenkakuVector_iOnNotify (
	HWND			hDlg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	NMHDR	FAR*	pNMHDR	= (NMHDR *) lParam ;

	switch (pNMHDR->idFrom) {
	case	IDC_LIST_ZENKAKUVECTOR:
		if (pNMHDR->code == NM_CLICK || pNMHDR->code == NM_RCLICK || pNMHDR->code == LVN_ITEMCHANGED ||  pNMHDR->code == NM_SETFOCUS) {
			EnableDlgItem (hDlg, IDC_BUTTON_EDIT,	TRUE) ;
			EnableDlgItem (hDlg, IDC_BUTTON_DELETE,	TRUE) ;
		}
		break ;
	default:
		break ;
	}
	return	(INT_PTR) 0 ;
	UNREFERENCED_PARAMETER (wParam) ;
}

BOOL
dlgZenkakuVector_bInitializeZenkakuList (
	HWND			hDlg)
{
	struct TEditZenkakuVectorArg*	pArg ;
	HWND			hwndControl ;
	LVITEM			lvi ;
	int				nItem, i ;
	TCHAR			buf [256] ;

	pArg		= (struct TEditZenkakuVectorArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ZENKAKUVECTOR) ;
	if (pArg == NULL || hwndControl == NULL)
		return	FALSE ;

	ListView_DeleteAllItems (hDlg) ;
	memset (&lvi, 0, sizeof (lvi)) ;
	lvi.mask		= LVIF_PARAM | LVIF_TEXT ;
	lvi.iSubItem	= 0 ;
	nItem			= 0 ;
	for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
		if (pArg->m_rpZenkakuVector [i] != NULL) {
			lvi.iItem	= nItem ;
			lvi.lParam	= (LPARAM) i ;

			dlgZenkakuVector_vCreateListItemText (buf, ARRAYSIZE (buf), i, pArg->m_rpZenkakuVector [i]) ;
			lvi.pszText	= buf ;
			if (ListView_InsertItem (hwndControl, &lvi) == -1)
				return	FALSE ;
			nItem		++ ;
		}
	}
	return	TRUE ;
}

BOOL
dlgZenkakuVector_bEditZenkakuVector (
	HWND				hDlg,
	int					nCommandId)
{
	struct TEditZenkakuVectorArg*		pArg ;
	struct TEditZenkakuVectorEntryArg	arg ;
	HWND		hwndControl ;
	INT_PTR		nResult ;
	int			nItem ;
	LVFINDINFO	lvfi ;

	arg.m_iChara		= -1 ;
	arg.m_bufText [0]	= TEXT ('\0') ;

	pArg		= (struct TEditZenkakuVectorArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
	hwndControl	= GetDlgItem (hDlg, IDC_LIST_ZENKAKUVECTOR) ;
	if (pArg == NULL || hwndControl == NULL)
		return	FALSE ;

	if (nCommandId != IDC_BUTTON_INSERT) {
		LVITEM	lvi ;
		int		nCurSel ;

		nCurSel	= ListView_GetSelectionMark (hwndControl) ;
		if (nCurSel == -1)
			return	FALSE ;
		memset (&lvi, 0, sizeof (lvi)) ;
		lvi.iItem	= nCurSel ;
		lvi.mask	= LVIF_PARAM ;
		if (ListView_GetItem (hwndControl, &lvi)) {
			int		nChara ;

			nChara	= (int) lvi.lParam ;
			if (0 <= nChara && nChara < SIZE_INPUTVECTOR) {
				arg.m_iChara	= nChara ;
				if (pArg->m_rpZenkakuVector [nChara] != NULL)
					lstrcpyn (arg.m_bufText, pArg->m_rpZenkakuVector [arg.m_iChara], ARRAYSIZE (arg.m_bufText)) ;
			}
		}
	}
	switch (nCommandId) {
	case	IDC_BUTTON_INSERT:
	case	IDC_BUTTON_EDIT:
		{
			HINSTANCE	hInst ;
			int			nLength ;
			TCHAR		buf [256] ;
			BOOL		bEdit ;

			hInst	= (HINSTANCE) GetWindowLongPtr (hDlg, GWLP_HINSTANCE) ;

			nResult	= DialogBoxParam (hInst, MAKEINTRESOURCE (IDD_EDIT_ONEZENKAKUVECTOR), hDlg, dlgEditZenkakuVectorProc, (LPARAM) &arg) ;
			if (nResult != IDOK)
				break ;
			if (nCommandId == IDC_BUTTON_INSERT &&
				0 <= arg.m_iChara && arg.m_iChara < ARRAYSIZE (pArg->m_rpZenkakuVector) &&
				pArg->m_rpZenkakuVector [arg.m_iChara] != NULL) {
				TCHAR	bufText [256] ;
				int		n ;

				if (0x20 < arg.m_iChara && arg.m_iChara < 127) {
					n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� %c �ɂ͊��� \"%s\" �����蓖�Ă��Ă��܂��B�u�������܂����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
				} else {
					n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� 0x%02x �ɂ͊��� \"%s\" �����蓖�Ă��Ă��܂��B�u�������܂����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
				}
				bufText [n]	= TEXT ('\0') ;

				if (MessageBox (hDlg, bufText, TEXT ("�x��"), MB_ICONWARNING | MB_OKCANCEL) != IDOK)
					break ;
			}
			/*	�}�X�^�[�Ɠ����������̈�����L���Ă���̂ŁAFREE ����Ƃ܂����B
			if (pArg->m_rpZenkakuVector [arg.m_iChara] != NULL) {
				FREE (_rpZenkakuVector [arg.m_iChara]) ;
				bEdit	= TRUE ;
			}
			*/
			bEdit	= TRUE ;
			nLength	= lstrlen (arg.m_bufText) ;

			pArg->m_rpZenkakuVector [arg.m_iChara]	= (LPTSTR) MALLOC (sizeof (TCHAR) * (nLength + 1)) ;
			if (pArg->m_rpZenkakuVector [arg.m_iChara] == NULL)
				return	FALSE ;
			lstrcpy (pArg->m_rpZenkakuVector [arg.m_iChara], arg.m_bufText) ;

			dlgZenkakuVector_vCreateListItemText (buf, ARRAYSIZE (buf), arg.m_iChara, arg.m_bufText) ;
			if (bEdit) {
				memset (&lvfi, 0, sizeof (lvfi)) ;
				lvfi.flags	= LVFI_PARAM ;
				lvfi.lParam	= (LPARAM) arg.m_iChara ;
				nItem	= ListView_FindItem (hwndControl, -1, &lvfi) ;
				if (nItem != -1) {
					ListView_SetItemText (hwndControl, nItem, 0, buf) ;
				}
			} else {
				LVITEM	lvi ;

				memset (&lvi, 0, sizeof (lvi)) ;
				lvi.iItem	= (int) arg.m_iChara ;
				lvi.mask	= LVIF_TEXT | LVIF_PARAM ;
				lvi.pszText	= buf ;
				lvi.lParam	= (LPARAM) arg.m_iChara ;
				ListView_InsertItem (hwndControl, &lvi) ;
			}
		}
		break ;
	case	IDC_BUTTON_DELETE:
		{
			TCHAR	bufText [256] ;
			int		n ;

			if (! (0 <= arg.m_iChara && arg.m_iChara < ARRAYSIZE (pArg->m_rpZenkakuVector) && pArg->m_rpZenkakuVector [arg.m_iChara] != NULL))
				break ;

			if (0x20 < arg.m_iChara && arg.m_iChara < 127) {
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� %c�A�o��\"%s\" ���폜���܂��B��낵���ł����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
			} else {
				n	= wnsprintf (bufText, ARRAYSIZE (bufText) - 1, TEXT ("���� 0x%02x�A�o��\"%s\" ���폜���܂��B��낵���ł����H"), arg.m_iChara, pArg->m_rpZenkakuVector [arg.m_iChara]) ;
			}
			bufText [n]	= TEXT ('\0') ;
			if (MessageBox (hDlg, bufText, TEXT ("�����̍폜�m�F"), MB_ICONQUESTION | MB_OKCANCEL) != IDOK)
				break ;
			/*FREE (_rpZenkakuVector [arg.m_iChara]) ;*/
			pArg->m_rpZenkakuVector [arg.m_iChara]	= NULL ;

			memset (&lvfi, 0, sizeof (lvfi)) ;
			lvfi.flags	= LVFI_PARAM ;
			lvfi.lParam	= (LPARAM) arg.m_iChara ;
			nItem	= ListView_FindItem (hwndControl, -1, &lvfi) ;
			if (nItem != -1) {
				ListView_DeleteItem (hwndControl, nItem) ;
			}
		}
		break ;
	default:
		return	FALSE ;
	}
	return	TRUE ;
}

void
dlgZenkakuVector_vCreateListItemText (
	LPTSTR			pDest,
	int				nDestSize,
	int				nChara,
	LPCTSTR			strOutput)
{
	int		n ;

	if (nChara < 0x20 || nChara >= 127) {
		TCHAR	buf [32] ;

		vKey2String (buf, ARRAYSIZE (buf), nChara) ;
		n	= wnsprintf (pDest, nDestSize - 1, TEXT ("[%2x] `%s' = `%s'"), nChara, buf, strOutput) ;
	} else {
		n	= wnsprintf (pDest, nDestSize - 1, TEXT ("[%2x] `%c' = `%s'"), nChara, nChara, strOutput) ;
	}
	pDest [n]	= TEXT ('\0') ;
	return ;
}

/*========================================================================
 */
INT_PTR	CALLBACK
dlgEditZenkakuVectorProc (
	HWND			hDlg,
	UINT			uMsg,
	WPARAM			wParam,
	LPARAM			lParam)
{
	switch (uMsg) {
	case	WM_INITDIALOG:
		{
			struct TEditZenkakuVectorEntryArg*	pArg	= (struct TEditZenkakuVectorEntryArg*) lParam ;
			HWND	hwndControl ;

			SetWindowLongPtr (hDlg, DWLP_USER, (LONG_PTR) lParam) ;

			hwndControl	= GetDlgItem (hDlg, IDC_COMBO_CHARTOBIND) ;
			if (hwndControl != NULL) {
				TCHAR	buf [64] ;
				int		i ;
				LRESULT	nItem ;

				for (i = 0 ; i < SIZE_INPUTVECTOR ; i ++) {
					vKey2String (buf, ARRAYSIZE (buf), i) ;
					nItem	= SendMessage (hwndControl, CB_INSERTSTRING, (WPARAM) -1, (LPARAM) buf) ;
					if (nItem != CB_ERR) {
						SendMessage (hwndControl, CB_SETITEMDATA, (WPARAM) nItem, (LPARAM) i) ;
					}
				}
				if (pArg->m_iChara != -1)
					SetDropDownListCurrentSelectionByData (hDlg, IDC_COMBO_CHARTOBIND, pArg->m_iChara) ;
			}

			hwndControl	= GetDlgItem (hDlg, IDC_EDIT_CHARVALUE) ;
			if (hwndControl != NULL) {
				SendMessage (hwndControl, EM_SETLIMITTEXT, (WPARAM) (ARRAYSIZE (pArg->m_bufText) - 1), (LPARAM) 0) ;
				SetDlgItemText (hDlg, IDC_EDIT_CHARVALUE, pArg->m_bufText) ;
			}
			return	(INT_PTR) TRUE ;
		}
	case	WM_COMMAND:
		{
			WORD	woControl		= LOWORD (wParam) ;
			//WORD	woNotification	= HIWORD (wParam) ;

			switch (woControl) {
			case	IDOK:
				{
					struct TEditZenkakuVectorEntryArg*	pArg ;

					pArg	= (struct TEditZenkakuVectorEntryArg*) GetWindowLongPtr (hDlg, DWLP_USER) ;
					if (pArg != NULL) {
						HWND	hwndControl ;
						int		nText ;

						hwndControl	= GetDlgItem (hDlg, IDC_COMBO_CHARTOBIND) ;
						if (hwndControl != NULL) {
							LRESULT	nCurSel, nData ;

							nCurSel	= SendMessage (hwndControl, CB_GETCURSEL, (WPARAM) 0, (LPARAM) 0) ;
							if (nCurSel != CB_ERR) {
								nData	= SendMessage (hwndControl, CB_GETITEMDATA, (WPARAM) nCurSel, (LPARAM) 0) ;
							} else {
								nData	= CB_ERR ;
							}
							if (nData == CB_ERR) {
								(void) MessageBox (hDlg, TEXT ("���͕������ݒ肳��Ă��܂���B"), TEXT ("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
								break ;
							}
							pArg->m_iChara	= nData ;
						}
						nText	= GetDlgItemText (hDlg, IDC_EDIT_CHARVALUE, pArg->m_bufText, ARRAYSIZE (pArg->m_bufText)) ;
						pArg->m_bufText [nText]	= TEXT ('\0') ;
					}
				}
			case	IDCANCEL:
				EndDialog (hDlg, (INT_PTR) woControl) ;
				return	(INT_PTR) TRUE ;
			}
			return	(INT_PTR) TRUE ;
		}
	case	WM_NOTIFY:
		{
			return	(INT_PTR) 1 ;
		}
	default:
		break ;
	}
	return	FALSE ;
}

/*========================================================================
 */
void
dlgKeybind_vClearZenkakuVector (void)
{
	int		i ;

	for (i = 0 ; i < ARRAYSIZE (_rpZenkakuVector) ; i ++) {
//		if (_rpZenkakuVector [i] != NULL) {
			FREE (_rpZenkakuVector [i]) ;
			_rpZenkakuVector [i]	= NULL ;
//		}
	}
	return ;
}

/*========================================================================
 *	registry ����c�B
 *	type(0/1/2), state, next, hira/kata or output or function ���B
 */
static	BOOL	dlgKeybind_bLoadKeymapFromRegistry	(void) ;
static	void	dlgKeybind_vLoadDefaultKeymap		(void) ;
static	BOOL	dlgKeybind_bSaveKeymap				(void) ;
static	BOOL	dlgKeybind_bLoadRomaKanaRuleList	(HWND, BOOL) ;
static	BOOL	dlgKeybind_bSaveAllRomaKanaRuleList	(void) ;
static	BOOL	dlgKeybind_bParseRomaKanaRuleLists	(HWND, HKEY, LPCTSTR*, int, LPCTSTR, BOOL, struct TSkkBaseRuleNode**) ;
static	BOOL	dlgKeybind_bParseRomaKanaRuleList	(LPCTSTR, DWORD, int, struct TSkkBaseRuleNode**, BOOL*) ;
static	BOOL	dlgKeybind_bSaveRomaKanaRuleList	(HKEY, LPCTSTR*, int, struct TSkkBaseRuleNode**) ;
static	void	dlgKeybind_vReportRomaKanaRuleListError	(HWND, LPCTSTR, DWORD, LPCTSTR) ;

static	LPCTSTR	srKeymapRegistryNames []	= {
	REGINFO_MAJORMODEMAP,
	REGINFO_JMODEMAP,
	REGINFO_LATINMODEMAP,
	REGINFO_ZENKAKUMODEMAP,	/* jisx0208-latin-mode-map */
	REGINFO_ABBREVMODEMAP,
} ;

static	LPCTSTR	srKeymapExtraRegistryNames []	= {
	REGINFO_MAJORMODEMAP_EX,
	REGINFO_JMODEMAP_EX,
	REGINFO_LATINMODEMAP_EX,
	REGINFO_ZENKAKUMODEMAP_EX,	/* jisx0208-latin-mode-map */
	REGINFO_ABBREVMODEMAP_EX,
} ;

static	struct CImeKeymap*	srpKeymaps []	= {
	&_sMajorModeMap,
	&_sSkkJModeMap,
	&_sSkkLatinModeMap,
	&_sSkkJisx0208LatinModeMap,
	&_sSkkAbbrevModeMap,
} ;

void
dlgKeybind_vLoadConfig (HWND hDlg, BOOL bErrorReport)
{
	if (! dlgKeybind_bLoadKeymapFromRegistry ()) {
		dlgKeybind_vLoadDefaultKeymap () ;
	}
	if (! dlgKeybind_bLoadRomaKanaRuleList (hDlg, bErrorReport)) {
		int	i ;

		_siRomaKanaRuleListType			= KEYBINDTP_DEFAULT ;
		for (i = 0 ; i < NUM_ROMAKANARULE ; i ++) {
			_rplstRomaKanaRules			[i]	= NULL ;
			_rplstJisx0201KanaRules		[i]	= NULL ;
			_rplstJisx0201RomanRules	[i]	= NULL ;
		}
		_sbExistUserDefinedRomaKanaRule	= FALSE ;
	}
	(void) dlgKeybind_bLoadZenkakuVector () ;
	return ;
}

BOOL
dlgKeybind_bSaveConfig (void)
{
	HKEY	hSubKey ;
	DWORD	dwValue ;

	dlgKeybind_bSaveKeymap () ;
	dlgKeybind_bSaveAllRomaKanaRuleList () ;
	dlgKeybind_bSaveZenkakuVector () ;

	if (! bCreateRegistryKey (REGPATH_KEYMAP, FALSE, &hSubKey))
		return	FALSE ;

	dwValue	= (DWORD) _sbEggLikeNewline ;
	if (RegSetValueEx (hSubKey, REGINFO_EGGLIKENEWLINE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	error_exit ;
	dwValue	= (DWORD) _sbNewlineKakuteiAll ;
	if (RegSetValueEx (hSubKey, REGINFO_NEWLINEKAKUTEIALL, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	error_exit ;
error_exit:
	RegCloseKey (hSubKey) ;
	return	TRUE ;
}

BOOL
dlgKeybind_bLoadKeymapFromRegistry (void)
{
	HKEY	hSubKey ;
	int		i ;
	BOOL	bRetval	= FALSE ;

	_sbExistUserDefinedKeymap					= FALSE ;
	_sbExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
	_sbExistUserDefinedSpecialMidashiCharKey	= FALSE ;
	_sbExistUserDefinedCompletionKey			= FALSE ;

	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_KEYMAP, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		LONG	lResult ;
		DWORD	dwType, cbData, dwValue ;

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_KEYMAP_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siKeybindType	= (int) dwValue ;

		for (i = 0 ; i < ARRAYSIZE (srKeymapRegistryNames) ; i ++) {
			lResult	= RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS)
				break ;
			if (dwType != REG_BINARY || cbData != MAX_KEYBINDS)
				goto	skip_error ;

			(void) RegQueryValueEx (hSubKey, srKeymapRegistryNames [i], NULL, &dwType, srpKeymaps [i]->m_rbyBaseMap, &cbData) ;
		}
		if (i >= ARRAYSIZE (srKeymapRegistryNames))
			_sbExistUserDefinedKeymap	= TRUE ;

		if (_sbExistUserDefinedKeymap) {
			BYTE	rbBuffer [512] ;
			BYTE*	pbBuffer	= NULL ;
			DWORD	iBufSize ;

			pbBuffer	= rbBuffer ;
			iBufSize	= sizeof (rbBuffer) ;
			for (i = 0 ; i < ARRAYSIZE (srKeymapExtraRegistryNames) ; i ++) {
				int				iNumKeyBinds, j ;
				const BYTE*		pbData ;
				struct CImeKeyBind*	pKeyBind ;

				/* ���̑��̃o�C���h�͋�ɂ��Ă����B*/
				lResult	= RegQueryValueEx (hSubKey, srKeymapExtraRegistryNames [i], NULL, &dwType, NULL, &cbData) ;
				if (lResult != ERROR_SUCCESS || dwType != REG_BINARY)
					continue ;
				if (cbData > iBufSize) {
					if (pbBuffer != rbBuffer) {
						FREE (pbBuffer) ;
					}
					pbBuffer	= (BYTE*) MALLOC (cbData) ;
					if (pbBuffer == NULL) {
						/* error */
						break ;
					}
					iBufSize	= cbData ;
				}
				(void) RegQueryValueEx (hSubKey, srKeymapExtraRegistryNames [i], NULL, &dwType, pbBuffer, &cbData) ;

				/*
				 */
				iNumKeyBinds	= cbData / SIZE_PER_1EXTRAKEY ;	/* VKEY(4), MODIFIER(2), FUNCNO(2) */
				if (iNumKeyBinds <= 0)
					continue ;

				srpKeymaps [i]->m_pKeyBinds	= (struct CImeKeyBind*) MALLOC (sizeof (struct CImeKeyBind) * iNumKeyBinds) ;
				if (srpKeymaps [i]->m_pKeyBinds == NULL) {
					/* error */
					break ;
				}
				srpKeymaps [i]->m_nKeyBinds	= iNumKeyBinds ;

				pbData		= pbBuffer ;
				pKeyBind	= srpKeymaps [i]->m_pKeyBinds ;
				for (j = 0 ; j < iNumKeyBinds ; j ++) {
					unsigned int	uVKey, uModifier ;
					int				iFuncNo ;

					uVKey		= (unsigned int) *pbData ++ ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ <<  8) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 16) ;
					uVKey		= uVKey | ((unsigned int) *pbData ++ << 24) ;
					uModifier	= (unsigned int) *pbData ++ ;
					uModifier	= uModifier | ((unsigned int) *pbData ++ << 8) ;
					iFuncNo		= (unsigned int) *pbData ++ ;
					pbData++;	// iFuncNo		= iFuncNo | ((unsigned int) *pbData ++ << 8) ;
					if (iFuncNo >= NUM_SELECTABLE_FUNCTIONS)
						continue ;	/* skip */
					pKeyBind->m_nKeyCode		= (short)uVKey ;
					pKeyBind->m_uKeyMask		= (unsigned short)uModifier ;
					pKeyBind->m_nKeyFunction	= iFuncNo ;
					pKeyBind	++ ;
				}
				/* realloc �������Ƃ��낾���ǁc */
				srpKeymaps [i]->m_nKeyBinds	= pKeyBind - srpKeymaps [i]->m_pKeyBinds ;
			}
			if (pbBuffer != rbBuffer && pbBuffer != NULL) {
				FREE (pbBuffer) ;
				pbBuffer	= NULL ;
			}
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siStartHenkanKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbyStartHenkanKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_STARTHENKANKEY, NULL, &dwType, (BYTE*)_srbyStartHenkanKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			_sbExistUserDefinedStartHenkanKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumStartHenkanKeys				= (int) cbData ;
			_sbExistUserDefinedStartHenkanKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siCompletionKeyType	= (int) dwValue ;
		if (RegQueryValueEx (hSubKey, REGINFO_TRYCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyTryCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumTryCompletionKeys				= (int) cbData ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyPreviousCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumPreviousCompletionKeys		= (int) cbData ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}
		if (RegQueryValueEx (hSubKey, REGINFO_NEXTCOMPLETIONKEY, NULL, &dwType, (BYTE*)_srbyNextCompletionKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumNextCompletionKeys			= (int) cbData ;
			_sbExistUserDefinedCompletionKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siSetHenkanPointSubrKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySetHenkanPointSubrKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, NULL, &dwType, (BYTE*)_srbySetHenkanPointSubrKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			_sbExistUserDefinedSetHenkanPointSubrKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSetHenkanPointSubrKeys				= (int) cbData ;
			_sbExistUserDefinedSetHenkanPointSubrKey	= TRUE ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD)
			goto	skip_error ;
		_siSpecialMidashiCharKeyType	= (int) dwValue ;
		cbData	= sizeof (_srbySpecialMidashiCharKeys) ;
		if (RegQueryValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR, NULL, &dwType, (BYTE*)_srbySpecialMidashiCharKeys, &cbData) != ERROR_SUCCESS) {
			/* �L�[�����݂��Ȃ��Ȃ�A�J�X�^�����ڂ͂Ȃ������ōς܂��B*/
			_sbExistUserDefinedSpecialMidashiCharKey	= FALSE ;
		} else {
			if (dwType != REG_BINARY)
				goto	skip_error ;
			_siNumSpecialMidashiCharKeys				= (int) cbData ;
			_sbExistUserDefinedSpecialMidashiCharKey	= TRUE ;
		}

		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_EGGLIKENEWLINE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_sbEggLikeNewline	= (dwValue != 0) ;
		}
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_NEWLINEKAKUTEIALL, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS) {
			goto	skip_error ;
		} else {
			if (dwType != REG_DWORD)
				goto	skip_error ;
			_sbNewlineKakuteiAll	= (dwValue != 0) ;
		}
		bRetval	= TRUE ;
skip_error:
		RegCloseKey (hSubKey) ;
	}

	/* �f�[�^���ςłȂ����A�X�̗v�f���`�F�b�N����B*/
	if (!_sbExistUserDefinedKeymap && _siKeybindType != KEYBINDTP_DEFAULT)
		_siKeybindType = KEYBINDTP_DEFAULT;
	if (bRetval) {
		for (i = 0 ; i < ARRAYSIZE (srpKeymaps) ; i ++) {
			int		j ;
			for (j = 0 ; j < MAX_KEYBINDS ; j ++) {
				if (srpKeymaps [i]->m_rbyBaseMap [j] < 0 || srpKeymaps [i]->m_rbyBaseMap [j] >= NUM_SELECTABLE_FUNCTIONS) {
					srpKeymaps [i]->m_rbyBaseMap[j]	= NFUNC_INVALID_CHAR ;
				}
			}
			for (j = 0 ; j < srpKeymaps [i]->m_nKeyBinds ; j ++) {
				if (srpKeymaps [i]->m_pKeyBinds [j].m_nKeyFunction < 0 ||
					srpKeymaps [i]->m_pKeyBinds [j].m_nKeyFunction >= NUM_SELECTABLE_FUNCTIONS) {
					srpKeymaps [i]->m_pKeyBinds [j].m_nKeyFunction	= NFUNC_INVALID_CHAR ;
				}
			}
		}
		if (_siStartHenkanKeyType == KEYBINDTP_USERDEFINED && ! _sbExistUserDefinedStartHenkanKey)
			_siStartHenkanKeyType	= KEYBINDTP_DEFAULT ;
		if (_siCompletionKeyType == KEYBINDTP_USERDEFINED && ! _sbExistUserDefinedCompletionKey)
			_siCompletionKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSetHenkanPointSubrKeyType == KEYBINDTP_USERDEFINED && !_sbExistUserDefinedSetHenkanPointSubrKey)
			_siSetHenkanPointSubrKeyType	= KEYBINDTP_DEFAULT ;
		if (_siSpecialMidashiCharKeyType == KEYBINDTP_USERDEFINED && !_sbExistUserDefinedSpecialMidashiCharKey)
			_siSpecialMidashiCharKeyType	= KEYBINDTP_DEFAULT ;
	}
	return	bRetval ;
}

void
dlgKeybind_vLoadDefaultKeymap (void)
{
	_sbEggLikeNewline = TRUE;
	dlgKeybind_vInitializeDefaultMajorModeMap (&_sMajorModeMap) ;
	dlgKeybind_vInitializeDefaultJModeMap (&_sSkkJModeMap, &_sMajorModeMap) ;
	dlgKeybind_vInitializeDefaultLatinModeMap (&_sSkkLatinModeMap) ;
	dlgKeybind_vInitializeDefaultJisx0208LatinModeMap (&_sSkkJisx0208LatinModeMap) ;
	dlgKeybind_vInitializeDefaultAbbrevModeMap (&_sSkkAbbrevModeMap, &_sMajorModeMap) ;
	return ;
}

/// �L�[�}�b�v�̕���
void dlgKeybind_vCloneKeymap(struct CImeKeymap* pDestMap, const struct CImeKeymap* pSrcMap)
{
	ASSERT(pDestMap);
	ASSERT(pSrcMap);

	// �L�[�}�b�v�������R�s�[
	memcpy (pDestMap->m_rbyBaseMap, pSrcMap->m_rbyBaseMap, sizeof (pSrcMap->m_rbyBaseMap)) ;

	// �L���ȃL�[�o�C���h�����J�E���g
	int n = 0;
	for (int i = 0; i < pSrcMap->m_nKeyBinds; i++) {
		if (pSrcMap->m_pKeyBinds[i].m_nKeyFunction != NFUNC_INVALID_CHAR) n++;
	}

	// �L�[�o�C���h�������R�s�[
	if (n > 0) {
		pDestMap->m_pKeyBinds = (struct CImeKeyBind*)MALLOC(sizeof(struct CImeKeyBind) * n);
		if (pDestMap->m_pKeyBinds == NULL) {
			pDestMap->m_nKeyBinds = 0;
			return;
		}
		n = 0;
		for (int i = 0; i < pSrcMap->m_nKeyBinds; i++) {
			if (pSrcMap->m_pKeyBinds[i].m_nKeyFunction != NFUNC_INVALID_CHAR) {
				pDestMap->m_pKeyBinds[n++] = pSrcMap->m_pKeyBinds[i];
			}
		}
		pDestMap->m_nKeyBinds = n;
	} else {
		pDestMap->m_pKeyBinds = NULL;
		pDestMap->m_nKeyBinds = 0;
	}
	return;
}

void
dlgKeyBind_vClearKeymap (
	struct CImeKeymap*			pDestMap)
{
	if (pDestMap == NULL)
		return ;
	if (pDestMap->m_pKeyBinds != NULL) {
		FREE (pDestMap->m_pKeyBinds) ;
		pDestMap->m_pKeyBinds	= NULL ;
	}
	pDestMap->m_nKeyBinds	= 0 ;
	return ;
}

void
dlgKeybind_vInitializeDefaultMajorModeMap (struct CImeKeymap* pMajorModeMap)
{
	#include "../common/major.h"

	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		pMajorModeMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	for (i = 0 ; i < ARRAYSIZE (_srbDefaultMajorModeMap) ; i ++)
		pMajorModeMap->m_rbyBaseMap [i]	= _srbDefaultMajorModeMap [i] ;
	for (i = 32 ; i < 127 ; i ++)
		pMajorModeMap->m_rbyBaseMap [i]	= NFUNC_SELF_INSERT_CHARACTER ;

	pMajorModeMap->m_pKeyBinds	= NULL ;
	pMajorModeMap->m_nKeyBinds	= 0 ;
}

void
dlgKeybind_vInitializeDefaultJModeMap (
	struct CImeKeymap*			pJModeMap,
	const struct CImeKeymap*	pMajorModeMap)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		pJModeMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;
	}
	for (i = 32 ; i < 127 ; i ++) {
		pJModeMap->m_rbyBaseMap [i]	= NFUNC_SKK_INSERT ;
	}
	pJModeMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	pJModeMap->m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_KATAKANA ;

	/*	previous-candidate-char ���ɂ���ׂ����Akeybind ���� previous-candidate-char ��
	 *	���߂�悤�ɂ���ׂ����B�ǂ��炪�������̂��B��҂��I������Ȃ��������R�́A�ǂ�
	 *	minor-mode-map �𗘗p����Ηǂ��̂�������Ȃ��������炩�H
	 */
	pJModeMap->m_rbyBaseMap ['x']	= NFUNC_SKK_PREVIOUS_CANDIDATE ;

	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (pMajorModeMap->m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			pJModeMap->m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	/*	try-completion-char �� skk-insert �ɂ��킹��B
	 *	try-completion-char �� keybind ����ɂ��邩�c�B���[��A�ł� try-completion �̓���
	 *	�� skk-insert �Ɠ����ɂ��Ă����� (function code �͈Ⴄ���ǁA����͓�����)�A
	 *	keybind �� try-completion �Ȃ� try-completion-charp �� t ��Ԃ��Ƃ����̂́H
	 *
	 *	�����Aabbrev-map �͑f���� try-completion �Ȃ̂ɁA������� skk-insert �o�R�Ƃ����̂�
	 *	�C�ɂȂ�c�B����������闝�R���l�������� try-completion ������̂͊댯���B
	 */
	pJModeMap->m_rbyBaseMap ['\t']	= NFUNC_SKK_INSERT ;

	pJModeMap->m_nKeyBinds	= 0 ;
	pJModeMap->m_pKeyBinds	= NULL ;
}

void
dlgKeybind_vInitializeDefaultLatinModeMap (
	struct CImeKeymap*		pLatinMap)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		pLatinMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pLatinMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;

	pLatinMap->m_pKeyBinds	= NULL ;
	pLatinMap->m_nKeyBinds	= 0 ;
}

void
dlgKeybind_vInitializeDefaultJisx0208LatinModeMap (
	struct CImeKeymap*		pJisx0208LatinMap)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		pJisx0208LatinMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	for (i = TEXT(' '); i <= 0x7E; i ++) {
		/*	_rcDefaultJisx0208LatinVector �̐ݒ肪������ƘA�����Ȃ���΁B
		 */
		// �Œ�l�e�[�u���̘A�����̓R���p�C���O�ɔ������Ă��邽�ߊȗ���
		// �Ȃ�TSF/IME���̃f�t�H���g�l�͓ǂݍ��񂾃x�N�^�̒l���瓮�I�ɐݒ肳���
		// if (_rcDefaultJisx0208LatinVector[i - TEXT(' ')])
		pJisx0208LatinMap->m_rbyBaseMap[i] = NFUNC_SKK_JISX0208_LATIN_INSERT;
	}
	pJisx0208LatinMap->m_rbyBaseMap [17]	= NFUNC_SKK_LATIN_HENKAN ;	/* \C-q */

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pJisx0208LatinMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-backward-and-set-henkan-point-char �́c 2stroke key �͎������ĂȂ�����c�B*/

	pJisx0208LatinMap->m_pKeyBinds			= NULL ;
	pJisx0208LatinMap->m_nKeyBinds			= 0 ;
}

void
dlgKeybind_vInitializeDefaultAbbrevModeMap (
	struct CImeKeymap*			pAbbrevMap,
	const struct CImeKeymap*	pMajorModeMap)
{
	int	i ;
	for (i = 0 ; i < MAX_KEYBINDS ; i ++)
		pAbbrevMap->m_rbyBaseMap [i]	= NFUNC_INVALID_CHAR ;

	pAbbrevMap->m_rbyBaseMap ['.']	= NFUNC_SKK_ABBREV_PERIOD ;
	pAbbrevMap->m_rbyBaseMap [',']	= NFUNC_SKK_ABBREV_COMMA ;
	pAbbrevMap->m_rbyBaseMap [17]	= NFUNC_SKK_TOGGLE_CHARACTERS ;

	/* skk-kakutei-key �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pAbbrevMap->m_rbyBaseMap [10]	= NFUNC_SKK_KAKUTEI ;
	/* skk-start-henkan-char �����Đݒ肵�Ȃ��Ƃ����Ȃ��B*/
	pAbbrevMap->m_rbyBaseMap [' ']	= NFUNC_SKK_START_HENKAN ;

	/*	�{���� m_pKeyBinds �����āANFUNC_SKK_DELETE_BACKWARD_CHAR �̐ݒ������
	 *	���Ƃ����Ȃ��̂����B
	 */
	for (i = 0 ; i < MAX_KEYBINDS ; i ++) {
		if (pMajorModeMap->m_rbyBaseMap [i] == NFUNC_BACKWARD_DELETE_CHAR) {
			pAbbrevMap->m_rbyBaseMap [i]	= NFUNC_SKK_DELETE_BACKWARD_CHAR ;
		}
	}
	pAbbrevMap->m_rbyBaseMap ['\t']	= NFUNC_SKK_TRY_COMPLETION ;

	pAbbrevMap->m_pKeyBinds	= NULL ;
	pAbbrevMap->m_nKeyBinds	= 0 ;
}

BOOL
dlgKeybind_bSaveKeymap (void)
{
	HKEY	hSubKey ;
	int		i ;
	DWORD	dwValue ;
	BOOL	bRetval ;

	if (! bCreateRegistryKey (REGPATH_KEYMAP, FALSE, &hSubKey))
		return	FALSE ;

	bRetval	= FALSE ;
	dwValue	= (DWORD) _siKeybindType ;
	if (RegSetValueEx (hSubKey, REGINFO_KEYMAP_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	exit_func ;

	/*	�o�^�̘b���c
	 */
	if (_sbExistUserDefinedKeymap) {
		BYTE	rbBuffer [1024] ;
		BYTE*	pbBuffer ;
		int		iBufferSize ;

		// �L�[�}�b�v�̕ۑ�
		for (i = 0; i < countof(srKeymapRegistryNames); i++) {
			BYTE* pDest = rbBuffer;
			BYTE* pSrc = srpKeymaps[i]->m_rbyBaseMap;
			for (int j = 0; j < MAX_KEYBINDS; j++) {
				ASSERT(*pSrc < NUM_SELECTABLE_FUNCTIONS);
				*pDest++ = *pSrc++;
			}
			if (::RegSetValueEx(hSubKey, srKeymapRegistryNames[i], 0, REG_BINARY, rbBuffer, MAX_KEYBINDS) != ERROR_SUCCESS)
				goto exit_func;
		}

		// �L�[�o�C���h�̕ۑ�
		pbBuffer = rbBuffer;
		iBufferSize = sizeof(rbBuffer);
		for (i = 0; i < countof(srKeymapExtraRegistryNames); i++) {
			if (srpKeymaps[i]->m_nKeyBinds > 0) {
				CImeKeyBind* pKeyBind;
				BYTE* ptr;
				int iNeedSize, j;

				iNeedSize = srpKeymaps[i]->m_nKeyBinds * SIZE_PER_1EXTRAKEY;
				if (iBufferSize < iNeedSize) {
					if (pbBuffer != rbBuffer) FREE(pbBuffer);
					pbBuffer = (BYTE*)MALLOC(iNeedSize);
					if (pbBuffer == NULL) break;
					iBufferSize = iNeedSize;
				}
				ptr = pbBuffer;
				pKeyBind = srpKeymaps[i]->m_pKeyBinds;
				for (j = 0; j < srpKeymaps[i]->m_nKeyBinds; j++) {
					*ptr++ = (BYTE)pKeyBind->m_nKeyCode;	// >> 0 �Ń��[�j���O�������Ȃ��R���p�C���̂ЂƂ��āc
					*ptr++ = pKeyBind->m_nKeyCode >> 8;
					*ptr++ = pKeyBind->m_nKeyCode >> 16;
					*ptr++ = pKeyBind->m_nKeyCode >> 24;
					*ptr++ = (BYTE)pKeyBind->m_uKeyMask;
					*ptr++ = pKeyBind->m_uKeyMask >> 8;
					ASSERT(pKeyBind->m_nKeyFunction < NUM_SELECTABLE_FUNCTIONS);
					*ptr++ = (BYTE)pKeyBind->m_nKeyFunction;
					*ptr++ = 0;	// *ptr++ = pKeyBind->m_nKeyFunction >> 8;
					pKeyBind++;
				}
				::RegSetValueEx(hSubKey, srKeymapExtraRegistryNames[i], 0, REG_BINARY, pbBuffer, ptr - pbBuffer);
			} else {
				// ���W�X�g���l������
				// SysWOW64���ɐG���K�v�͂Ȃ�
				::RegDeleteValue(hSubKey, srKeymapExtraRegistryNames[i]);
			}
		}
		if (pbBuffer != rbBuffer) FREE(pbBuffer);
	}

	dwValue	= (DWORD) _siStartHenkanKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_STARTHENKANKEY_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	exit_func ;
	if (_sbExistUserDefinedStartHenkanKey) {
		if (RegSetValueEx (hSubKey, REGINFO_STARTHENKANKEY, 0, REG_BINARY, (BYTE*) _srbyStartHenkanKeys, _siNumStartHenkanKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}
	dwValue	= (DWORD) _siCompletionKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_COMPLETIONRELATEDKEY_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	exit_func ;
	if (_sbExistUserDefinedCompletionKey) {
		if (RegSetValueEx (hSubKey, REGINFO_TRYCOMPLETIONKEY, 0, REG_BINARY, (BYTE*) _srbyTryCompletionKeys, _siNumTryCompletionKeys) != ERROR_SUCCESS)
			goto	exit_func ;
		if (RegSetValueEx (hSubKey, REGINFO_PREVIOUSCOMPLETIONKEY, 0, REG_BINARY, (BYTE*) _srbyPreviousCompletionKeys, _siNumPreviousCompletionKeys) != ERROR_SUCCESS)
			goto	exit_func ;
		if (RegSetValueEx (hSubKey, REGINFO_NEXTCOMPLETIONKEY, 0, REG_BINARY, (BYTE*) _srbyNextCompletionKeys, _siNumNextCompletionKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}

	dwValue	= (DWORD) _siSetHenkanPointSubrKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	exit_func ;
	if (_sbExistUserDefinedSetHenkanPointSubrKey) {
		if (RegSetValueEx (hSubKey, REGINFO_SETHENKANPOINTSUBRKEY, 0, REG_BINARY, (BYTE*) _srbySetHenkanPointSubrKeys, _siNumSetHenkanPointSubrKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}

	dwValue	= (DWORD) _siSpecialMidashiCharKeyType ;
	if (RegSetValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS)
		goto	exit_func ;
	if (_sbExistUserDefinedSpecialMidashiCharKey) {
		if (RegSetValueEx (hSubKey, REGINFO_SPECIALMIDASHICHAR, 0, REG_BINARY, (BYTE*) _srbySpecialMidashiCharKeys, _siNumSpecialMidashiCharKeys) != ERROR_SUCCESS)
			goto	exit_func ;
	}

	/*	������ Enter �ݒ肪����B
	 */
exit_func:
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

static	LPCTSTR	srRomaKanaRuleTbl [NUM_ROMAKANARULE]	= {
	REGINFO_ROMAKANARULE,	REGINFO_ROMAKANARULE1,
	REGINFO_ROMAKANARULE2,	REGINFO_ROMAKANARULE3,
} ;

static	LPCTSTR	srJisx0201KanaRuleTbl [NUM_ROMAKANARULE]	= {
	REGINFO_JISX0201RULE,	REGINFO_JISX0201RULE1,
	REGINFO_JISX0201RULE2,	REGINFO_JISX0201RULE3,
} ;

static	LPCTSTR	srJisx0201RomanRuleTbl [NUM_ROMAKANARULE]	= {
	REGINFO_JISX0201ROMANRULE,	REGINFO_JISX0201ROMANRULE1,
	REGINFO_JISX0201ROMANRULE2,	REGINFO_JISX0201ROMANRULE3,
} ;

BOOL
dlgKeybind_bLoadRomaKanaRuleList (HWND hDlg, BOOL bErrorReport)
{
	HKEY	hSubKey ;
	BOOL	bRetval	= TRUE ;

	_sbExistUserDefinedRomaKanaRule	= FALSE ;
	if (RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_ROMAKANARULE, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS) {
		DWORD	dwType, cbData, dwValue ;
		BOOL	bExist1, bExist2, bExist3 ;

		/* rule-list-type (default or custom) */
		cbData	= sizeof (dwValue) ;
		if (RegQueryValueEx (hSubKey, REGINFO_ROMAKANARULE_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData) != ERROR_SUCCESS || dwType != REG_DWORD) {
			_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
		} else {
			_siRomaKanaRuleListType	= (int) dwValue ;
		}
#ifndef ENGLISH_MESSAGE
		bExist1	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srRomaKanaRuleTbl,			NUM_ROMAKANARULE, TEXT("���[�}�����ȃ��[��"),		bErrorReport, _rplstRomaKanaRules) ;
		bExist2	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201KanaRuleTbl,		NUM_ROMAKANARULE, TEXT("JISX0201���ȃ��[��"),		bErrorReport, _rplstJisx0201KanaRules) ;
		bExist3	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201RomanRuleTbl,	NUM_ROMAKANARULE, TEXT("JISX0201���[�}�����[��"),	bErrorReport, _rplstJisx0201RomanRules) ;
#else
		bExist1	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srRomaKanaRuleTbl,			NUM_ROMAKANARULE, TEXT("roma-kana-rule"),		bErrorReport, _rplstRomaKanaRules) ;
		bExist2	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201KanaRuleTbl,		NUM_ROMAKANARULE, TEXT("jisx0201-kana-rule"),	bErrorReport, _rplstJisx0201KanaRules) ;
		bExist3	= dlgKeybind_bParseRomaKanaRuleLists (hDlg, hSubKey, srJisx0201RomanRuleTbl,	NUM_ROMAKANARULE, TEXT("jisx0201-roman-rule"),	bErrorReport, _rplstJisx0201RomanRules) ;
#endif
		_sbExistUserDefinedRomaKanaRule	= bExist1 || bExist2 || bExist3 ;
		RegCloseKey (hSubKey) ;
	}
	if (! _sbExistUserDefinedRomaKanaRule) {
		_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
	}
	return	bRetval;
}

BOOL
dlgKeybind_bParseRomaKanaRuleLists (
	HWND						hDlg,
	HKEY						hSubKey,
	LPCTSTR*					ppszRomaKanaRuleTblName,
	int							nRules,
	LPCTSTR						strRuleDisplayName,
	BOOL						bErrorReport,
	struct TSkkBaseRuleNode**	pplstRules)
{
	LONG	lResult ;
	DWORD	dwType, cbData ;
	int		i ;
	LPTSTR	pwData	= NULL ;
	BOOL	bExist	= FALSE ;

	for (i = 0 ; i < nRules ; i ++)
		pplstRules [i]	= NULL ;

	for (i = 0 ; i < nRules ; i ++) {
		lResult	= RegQueryValueEx (hSubKey, ppszRomaKanaRuleTblName [i], NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS) {
			pplstRules [i]	= NULL ;
			continue ;
		}
		if (dwType != REG_MULTI_SZ) {
			bExist	= FALSE ;
			break ;
		}
		if (cbData > 0) {
			BOOL	bError ;

			pwData	= (LPTSTR) MALLOC (cbData) ;
			if (pwData == NULL)
				continue ;

			(void) RegQueryValueEx (hSubKey, ppszRomaKanaRuleTblName [i], NULL, &dwType, (BYTE*)pwData, &cbData) ;
			bError	= FALSE ;
			if (dlgKeybind_bParseRomaKanaRuleList (pwData, cbData/sizeof(TCHAR), i, &pplstRules [i], &bError)) {
				bExist	= TRUE ;
			}
			if (bErrorReport && bError) {
				TCHAR	bufMessage [128] ;
				int		n ;

				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT("%s%d"), strRuleDisplayName, i) ;
				bufMessage [n]	= TEXT ('\0') ;
				dlgKeybind_vReportRomaKanaRuleListError (hDlg, pwData, cbData/sizeof(TCHAR), bufMessage) ;
			}
			FREE (pwData) ;
		} else {
			pplstRules [i]	= NULL ;
			bExist	= TRUE ;
		}
	}
	return	bExist ;
}

BOOL
dlgKeybind_bParseRomaKanaRuleList (
	LPCTSTR						pwData,
	DWORD						cbData,
	int							nRule,
	struct TSkkBaseRuleNode**	pplst,
	BOOL*						pbError)
{
	LPCTSTR	pwSrc, pwSrcEnd ;
	TCHAR	bufState [128], bufNext [128], bufHira [128], bufKata [128] ;
	TCHAR	bufNextRule [32] ;
	struct TSkkBaseRuleNode*	plstRomaKanaRule	= NULL ;
	BOOL	bError ;

	bError		= FALSE ;
	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	struct TSkkBaseRuleNode* pPrev = NULL;
	while (*pwSrc != TEXT ('\0') && pwSrc < pwSrcEnd) {
		struct TSkkBaseRuleNode*	pNewNode ;
		int							nType ;
		LPCWSTR						pwNext ;
		int							nNextRule ;

		pNewNode	= NULL ;
		nType		= *pwSrc ++ ;
		if (bParseBSEncodedString(&pwSrc, bufState, countof(bufState)))
			goto	next_entry ;
		if (bParseBSEncodedString(&pwSrc, bufNext, countof(bufNext)))
			goto	next_entry ;
		if (bParseBSEncodedString(&pwSrc, bufNextRule, countof(bufNextRule)))
			goto	next_entry ;
		// bufState		[ARRAYSIZE (bufState)		- 1]	= TEXT ('\0') ;
		// bufNext		[ARRAYSIZE (bufNext)		- 1]	= TEXT ('\0') ;
		// bufNextRule	[ARRAYSIZE (bufNextRule)	- 1]	= TEXT ('\0') ;

		pwNext	= (bufNext [0] != TEXT ('\0'))? bufNext : NULL ;
#if __STDC_WANT_SECURE_LIB__
		if (_snwscanf_s (bufNextRule, ARRAYSIZE (bufNextRule), L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#else
		if (swscanf (bufNextRule, L"%d", &nNextRule) != 1)
			nNextRule	= nRule ;
#endif

		switch (nType) {
		case	TEXT ('1'):
			if (bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
				break ;
			if (!bParseBSEncodedString(&pwSrc, bufKata, countof(bufKata)))
				break ;
			// bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;
			// bufKata [ARRAYSIZE (bufKata) - 1]	= TEXT ('\0') ;

			pNewNode	= dlgRomaKanaRule_pCreateType1Rule (bufState, pwNext, nNextRule, bufHira, bufKata) ;
			break ;
		case	TEXT ('2'):
			if (!bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
				break ;
			// bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;

			pNewNode	= dlgRomaKanaRule_pCreateType2Rule (bufState, pwNext, nNextRule, bufHira) ;
			break ;
		case	TEXT ('3'):
			{
				int		nFuncNo	= 0 ;

				if (!bParseBSEncodedString(&pwSrc, bufHira, countof(bufHira)))
					break ;
				// bufHira [ARRAYSIZE (bufHira) - 1]	= TEXT ('\0') ;

#if __STDC_WANT_SECURE_LIB__
				if (_snwscanf_s (bufHira, ARRAYSIZE (bufHira), L"%d", &nFuncNo) != 1)
					nFuncNo	= 0 ;
#else
				if (swscanf (bufHira, L"%d", &nFuncNo) != 1)
					nFuncNo	= 0 ;
#endif
				pNewNode	= dlgRomaKanaRule_pCreateType3Rule (bufState, pwNext, nNextRule, nFuncNo) ;
			}
			break ;
		default:
			break ;
		}
next_entry:
		if (pNewNode != NULL) {
#if 1
			// �����ɒǉ�
			if (pPrev == NULL) {
				plstRomaKanaRule = pNewNode;
				pPrev = pNewNode;
			} else {
				pPrev->_pNext = pNewNode;
				pPrev = pNewNode;
			}
#else
			/* NewNode �� list �ɒǉ��B*/
			pNewNode->_pNext	= plstRomaKanaRule ;
			plstRomaKanaRule	= pNewNode ;
#endif
		} else {
#if defined (DEBUG) || defined (_DEBUG)
			{
				TCHAR	buf [128] ;
				int		n ;
				n	= _sntprintf (buf, ARRAYSIZE(buf)-1, TEXT ("Skip: state:\"%d\", type:\"%d\"\n"), bufState, nType) ;
				buf [n]	= TEXT ('\0') ;
				OutputDebugString (buf) ;
			}
#endif
			bError	= TRUE ;
			/* error skip */
			while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
				pwSrc ++ ;
		}
		pwSrc	++ ;	/* nul �� skip */
	}
	if (pplst != NULL)
		*pplst	= plstRomaKanaRule ;
	if (pbError != NULL)
		*pbError	= bError ;
	return	TRUE ;
}

void
dlgKeybind_vReportRomaKanaRuleListError (
	HWND						hDlg,
	LPCTSTR						pwData,
	DWORD						cbData,
	LPCTSTR						strMessage)
{
	LPCTSTR	pwSrc, pwSrcEnd ;
	TCHAR	bufTmp [128] ;
	CVarbuffer<WCHAR,256>	vbuf ;
	WCHAR	bufMessage [256] ;
	BOOL	bFirst	= TRUE, bMoreThanTwo	= FALSE ;
	int		n ;

	pwSrc		= pwData ;
	pwSrcEnd	= pwData + cbData ;
	while (*pwSrc != TEXT ('\0') && pwSrc < pwSrcEnd) {
		int			nType, nNextRule ;
		LPCWSTR		pwBase ;
		BOOL		bError ;

		bError		= TRUE ;
		pwBase		= pwSrc ;
		nType		= *pwSrc ++ ;
		if (bParseBSEncodedString(&pwSrc, bufTmp, countof(bufTmp)))
			goto	next_entry ;
		if (bParseBSEncodedString(&pwSrc, bufTmp, countof(bufTmp)))
			goto	next_entry ;
		if (bParseBSEncodedString(&pwSrc, bufTmp, countof(bufTmp)))
			goto	next_entry ;
		// bufTmp [ARRAYSIZE (bufTmp) - 1]	= TEXT ('\0') ;
#if __STDC_WANT_SECURE_LIB__
		if (_snwscanf_s (bufTmp, ARRAYSIZE (bufTmp), L"%d", &nNextRule) != 1)
			goto	next_entry ;
#else
		if (swscanf (bufTmp, L"%d", &nNextRule) != 1)
			goto	next_entry ;
#endif
		switch (nType) {
		case	TEXT ('1'):
			if (bParseBSEncodedString(&pwSrc, bufTmp, countof(bufTmp)))
				break ;
			if (!bParseBSEncodedString(&pwSrc, bufTmp, countof(bufTmp)))
				break ;
			bError	= FALSE ;
			break ;
		case	TEXT ('2'):
			if (!bParseBSEncodedString(&pwSrc, bufTmp, countof(bufTmp)))
				break ;
			bError	= FALSE ;
			break ;
		case	TEXT ('3'):
			{
				int		nFuncNo	= 0 ;

				if (!bParseBSEncodedString(&pwSrc, bufTmp, countof(bufTmp)))
					break ;
				// bufTmp [ARRAYSIZE (bufTmp) - 1]	= TEXT ('\0') ;
#if __STDC_WANT_SECURE_LIB__
				if (_snwscanf_s (bufTmp, ARRAYSIZE (bufTmp), L"%d", &nFuncNo) != 1)
					break ;
#else
				if (swscanf (bufTmp, L"%d", &nFuncNo) != 1)
					break ;
#endif
				bError	= FALSE ;
			}
			break ;
		default:
			break ;
		}
next_entry:
		while (*pwSrc != L'\0' && pwSrc < pwSrcEnd)
			pwSrc ++ ;
		if (bError) {
			WCHAR	bufEntry   [128] ;
			LPWSTR	pwDest		= bufEntry ;
			LPCWSTR	pwDestEnd	= bufEntry + ARRAYSIZE(bufEntry) - 1 ;
			LPCWSTR	ptr			= pwBase ;
			while (ptr < pwSrc && pwDest < pwDestEnd) {
				if (*ptr == L'\\' && (ptr+1) < pwSrc && *(ptr+1) == L'0') {
					*pwDest ++	= L',' ;
					ptr		++ ;
				} else {
					*pwDest ++	= *ptr ;
				}
				ptr	++ ;
			}
			*pwDest	= L'\0' ;
			if (bFirst) {
#ifndef ENGLISH_MESSAGE
				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT("%s�̃G���g��:\"%s\""), strMessage, bufEntry) ;
#else
				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT("%s's entry:\"%s\""), strMessage, bufEntry) ;
#endif
				bFirst	= FALSE ;
			} else {
				n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage)-1, TEXT(",\"%s\""), bufEntry) ;
				bMoreThanTwo	= TRUE ;
			}
			if (! vbuf.bAdd (bufMessage, n))
				break ;
		}
		pwSrc	++ ;	/* nul �� skip */
	}
#ifndef ENGLISH_MESSAGE
	n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage), TEXT ("�͖����ł��B")) ;
#else
	n	= _sntprintf (bufMessage, ARRAYSIZE(bufMessage), TEXT (" %s not valid."), (bMoreThanTwo? TEXT("are") : TEXT("is"))) ;
#endif
	vbuf.bAdd (bufMessage, n) ;
	vbuf.bAdd (L'\0') ;
	MessageBox (hDlg, vbuf.pGetBuffer(), TEXT("�G���["), MB_ICONERROR | MB_OKCANCEL) ;
	return ;
}

BOOL
dlgKeybind_bSaveAllRomaKanaRuleList (void)
{
	HKEY	hSubKey ;
	BOOL	bRetval ;
	DWORD	dwValue ;

	bRetval	= TRUE ;
	if (! bCreateRegistryKey (REGPATH_ROMAKANARULE, FALSE, &hSubKey)) {
		return	FALSE ;
	}
	if (_sbExistUserDefinedRomaKanaRule) {
		if (! dlgKeybind_bSaveRomaKanaRuleList (hSubKey, srRomaKanaRuleTbl,		NUM_ROMAKANARULE, _rplstRomaKanaRules) ||
			! dlgKeybind_bSaveRomaKanaRuleList (hSubKey, srJisx0201KanaRuleTbl,	NUM_ROMAKANARULE, _rplstJisx0201KanaRules) ||
			! dlgKeybind_bSaveRomaKanaRuleList (hSubKey, srJisx0201RomanRuleTbl,	NUM_ROMAKANARULE, _rplstJisx0201RomanRules)) {
			_siRomaKanaRuleListType	= KEYBINDTP_DEFAULT ;
			bRetval	= FALSE ;
		}
	}
	dwValue	= (DWORD) _siRomaKanaRuleListType ;
	if (RegSetValueEx (hSubKey, REGINFO_ROMAKANARULE_TYPE, 0, REG_DWORD, (BYTE*) &dwValue, sizeof (DWORD)) != ERROR_SUCCESS) {
		bRetval	= FALSE ;
	}
	RegCloseKey (hSubKey) ;
	return	bRetval ;
}

/// ���[�}�����ȕϊ����[���̕ۑ�
BOOL dlgKeybind_bSaveRomaKanaRuleList(
	HKEY						hSubKey,
	LPCTSTR*					ppszRomaKanaRuleTblName,
	int							nRules,
	struct TSkkBaseRuleNode**	pplstRules)
{
	int		i ;
	BOOL	bRetval ;

	bRetval	= FALSE ;
	for (i = 0 ; i < nRules ; i ++) {
		BOOL	bError ;

		if (pplstRules [i] != NULL) {
			LPTSTR						pwData ;
			LPTSTR						pwDest ;
			int							nSize ;
			struct TSkkBaseRuleNode*	pNode ;

			nSize = 0 ;
			pNode = pplstRules[i];
			while (pNode) {
				switch (pNode->_nType) {
				case ROMAKANARULE_TYPE1:
					nSize +=
						1 +															// Type
						iCountBSEncodedString(pNode->_T1._strState)			+ 1 +	// State
						iCountBSEncodedString(pNode->_T1._strNext)			+ 1 +	// NextState
						iCountBSEncodedInteger(pNode->_T1._iNextRule)		+ 1 +
						iCountBSEncodedString(pNode->_T1._case._strHira)	+ 1 +	// �Ђ炪��
						iCountBSEncodedString(pNode->_T1._case._strKata)	+		// �J�^�J�i
						1;															// NUL
					if (iCountBSEncodedString(pNode->_T1._case._strKata) == 0) nSize++;
					break;
				case ROMAKANARULE_TYPE2:
					nSize +=
						1 +															// Type
						iCountBSEncodedString(pNode->_T2._strState)			+ 1 +	// State
						iCountBSEncodedString(pNode->_T2._strNext)			+ 1 +	// NextState
						iCountBSEncodedInteger(pNode->_T2._iNextRule)		+ 1 +
						iCountBSEncodedString(pNode->_T2._strOutput)		+		// Output
						1;															// NUL
					if (iCountBSEncodedString(pNode->_T2._strOutput) == 0) nSize++;
					break;
				case ROMAKANARULE_TYPE3:
					nSize +=
						1 +															// Type
						iCountBSEncodedString(pNode->_T3._strState)			+ 1 +	// State
						iCountBSEncodedString(pNode->_T3._strNext)			+ 1 +	// NextState
						iCountBSEncodedInteger(pNode->_T3._iNextRule)		+ 1 +
						iCountBSEncodedInteger(pNode->_T3._nFunction)		+		// Function
						1;															// NUL
					break;
				}
				pNode = pNode->_pNext;
			}
			nSize++;																// NUL

			pwData	= (LPTSTR) MALLOC (sizeof (TCHAR) * nSize) ;
			if (pwData == NULL)
				goto	exit_func ;

			pwDest = pwData;
			pNode = pplstRules[i];
			while (pNode) {
				LPTSTR pwEdge;
				switch (pNode->_nType) {
				case ROMAKANARULE_TYPE1:
					*pwDest++ = TEXT('1');
					pwDest = iBSEncodeString(pwDest, pNode->_T1._strState);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeString(pwDest, pNode->_T1._strNext);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeInteger(pwDest, pNode->_T1._iNextRule);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeString(pwDest, pNode->_T1._case._strHira);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeString(pwEdge = pwDest, pNode->_T1._case._strKata);
					if (pwEdge == pwDest) *pwDest++ = SEPCHAR;
					*pwDest++ = TEXT('\0');
					break;
				case ROMAKANARULE_TYPE2:
					*pwDest++ = TEXT('2');
					pwDest = iBSEncodeString(pwDest, pNode->_T2._strState);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeString(pwDest, pNode->_T2._strNext);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeInteger(pwDest, pNode->_T2._iNextRule);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeString(pwEdge = pwDest, pNode->_T2._strOutput);
					if (pwEdge == pwDest) *pwDest++ = SEPCHAR;
					*pwDest++ = TEXT('\0');
					break ;
				case ROMAKANARULE_TYPE3:
					*pwDest++ = TEXT('3');
					pwDest = iBSEncodeString(pwDest, pNode->_T3._strState);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeString(pwDest, pNode->_T3._strNext);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeInteger(pwDest, pNode->_T3._iNextRule);
					*pwDest++ = SEPCHAR;
					pwDest = iBSEncodeInteger(pwDest, pNode->_T3._nFunction);
					*pwDest++ = TEXT('\0');
					break ;
				}
				pNode = pNode->_pNext;
			}
			*pwDest++ = TEXT('\0');
			ASSERT(nSize == pwDest - pwData);

			bError	= RegSetValueEx (hSubKey, ppszRomaKanaRuleTblName [i], 0, REG_MULTI_SZ, (BYTE*) pwData, sizeof (TCHAR) * nSize) != ERROR_SUCCESS ;
			FREE (pwData) ;
			if (bError)
				goto	exit_func ;
		} else {
			RegSetValueEx (hSubKey, ppszRomaKanaRuleTblName [i], 0, REG_MULTI_SZ, NULL, 0) ;
		}
	}
	bRetval	= TRUE ;
exit_func:
	return	bRetval ;
}

void
dlgKeybind_vInitializeDefaultStartHenkanKey (
	BYTE*			pbStartHenkanKeys,
	int*			piNumStartHenkanKeys)
{
	*pbStartHenkanKeys		= ' ' ;
	*piNumStartHenkanKeys	= 1 ;
	return ;
}

void
dlgKeybind_vInitializeDefaultCompletinoRelatedKey (
	BYTE*			pbTryCompletionKeys,
	int*			piNumTryCompletionKeys,
	BYTE*			pbPreviousCompletionKeys,
	int*			piNumPreviousCompletionKeys,
	BYTE*			pbNextCompletionKeys,
	int*			piNumNextCompletionKeys)
{
	*pbTryCompletionKeys			= '\t' ;
	*pbPreviousCompletionKeys		= ',' ;
	*pbNextCompletionKeys			= '.' ;
	*piNumTryCompletionKeys			= 1 ;
	*piNumPreviousCompletionKeys	= 1 ;
	*piNumNextCompletionKeys		= 1 ;
	return ;
}

void
dlgKeybind_vInitializeDefaultSetHenkanPointSubrKey (
	BYTE*			pbSetHenkanPointSubrKeys,
	int*			piNumSetHenkanPointSubrKeys)
{
	static const BYTE		rbDefault []	= {
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'M', 'N', 'O',
		'P', 'R', 'S', 'T', 'U', 'V', 'W', 'Y', 'Z',
	} ;
	memcpy (pbSetHenkanPointSubrKeys, rbDefault, sizeof (rbDefault)) ;
	*piNumSetHenkanPointSubrKeys	= ARRAYSIZE (rbDefault) ;
	return ;
}

void
dlgKeybind_vInitializeDefaultSpecialMidashiCharKey (
	BYTE*			pbSpecialMidashiCharKey,
	int*			piNumSpecialMidashiCharKey)
{
	static const BYTE		rbDefault []	= {
		'?', '>', '<',
	} ;
	memcpy (pbSpecialMidashiCharKey, rbDefault, sizeof (rbDefault)) ;
	*piNumSpecialMidashiCharKey	= ARRAYSIZE (rbDefault) ;
	return ;
}

/// �S�p�x�N�^�̓ǂݍ���
BOOL dlgKeybind_bLoadZenkakuVector()
{
	HKEY hSubKey;
	if (RegOpenKeyEx(HKEY_CURRENT_USER, REGPATH_ZENKAKUVECTOR, 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) goto skip_error;

	DWORD dwType, dwValue;
	DWORD cbData = sizeof(DWORD);
	LONG lResult;
	lResult = RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR_TYPE, NULL, &dwType, (BYTE*)&dwValue, &cbData);
	if (lResult != ERROR_SUCCESS || dwType != REG_DWORD) goto skip_scope1;
	_siZenkakuVectorType = (int)dwValue;

	lResult = RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, NULL, &cbData);
	if (lResult != ERROR_SUCCESS || dwType != REG_MULTI_SZ) goto skip_scope1;

	LPTSTR pwData = (LPTSTR)MALLOC(cbData);
	if (pwData == NULL) {
	skip_scope1:
		RegCloseKey(hSubKey);
		goto skip_error;
	}

	RegQueryValueEx(hSubKey, REGINFO_ZENKAKUVECTOR, NULL, &dwType, (BYTE*)pwData, &cbData);
	RegCloseKey(hSubKey);

	dlgKeybind_vClearZenkakuVector();

	LPCTSTR pwSrc = pwData;
	while (*pwSrc) {
		// �ΏۃL�����N�^�ǂݍ���
		TCHAR c = *pwSrc++;
		if (c < TEXT(' ') || c >= SIZE_INPUTVECTOR) goto skip_scope2;

		LPCTSTR pwBase = pwSrc;
		while (*pwSrc++);		// ��r���Z�q�͐�΂ɏ��������Ȃ��ł�����
		size_t n = pwSrc - pwBase;

		FREE(_rpZenkakuVector[c]);
		_rpZenkakuVector[c] = (LPTSTR)MALLOC(n * sizeof(TCHAR));
		if (_rpZenkakuVector[c] == NULL) {
		skip_scope2:
			FREE(pwData);
			goto skip_error;
		}

		lstrcpy(_rpZenkakuVector[c], pwBase);	// memcpy(_rpZenkakuVector[c], pwBase, n);
	}
	FREE(pwData);

	_sbExistUserDefinedZenkakuVector = TRUE;
	return TRUE;

skip_error:
	// �z��O�̊��ł̓f�t�H���g�l���g�p
	dlgKeybind_vClearZenkakuVector();
	_siZenkakuVectorType = KEYBINDTP_DEFAULT;
	_sbExistUserDefinedZenkakuVector = FALSE;
	return FALSE;
}

/// �S�p�x�N�^�̏�������
BOOL dlgKeybind_bSaveZenkakuVector()
{
	LPTSTR pwData = NULL;
	UINT nSize = 0;

	if (_sbExistUserDefinedZenkakuVector) {
		for (UINT i = TEXT(' '); i < countof(_rpZenkakuVector); i++) {
			if (_rpZenkakuVector[i]) {
				nSize +=
					1 +								// ����
					lstrlen(_rpZenkakuVector[i]) +	// ������
					1;								// �I�[
			}
		}
		nSize++;	// �I�[

		pwData = (LPTSTR)MALLOC(nSize * sizeof(TCHAR));
		if (pwData == NULL) return FALSE;

		LPTSTR pwDest = pwData;
		for (UINT i = TEXT(' '); i < countof(_rpZenkakuVector); i++) {
			if (_rpZenkakuVector[i]) {
				// �ΏۃL�����N�^��������
				*pwDest++ = (TCHAR)i;
				LPCTSTR pwSrc = _rpZenkakuVector[i];
				while (*pwDest++ = *pwSrc++);		// ��r���Z�q�͐�΂ɏ��������Ȃ��ł�����
			}
		}
		*pwDest++ = TEXT('\0');
		ASSERT((INT_PTR)nSize == pwDest - pwData);
	}

	// ����R�����g��� ����̕��j�𑸏d(�Ƃ�����1���ږ��ɓǂݏ�������Ȃ�Ė���)
	/*	���W�X�g���ւ̃A�N�Z�X�񐔂͏o���邾�����Ȃ������ǂ��̂ł͂Ȃ����Ƌ��l�B
	 */
	BOOL bResult = FALSE;
	HKEY hSubKey;
	if (bCreateRegistryKey(REGPATH_ZENKAKUVECTOR, FALSE, &hSubKey)) {
		bResult = TRUE;
		if (RegSetValueEx(hSubKey, REGINFO_ZENKAKUVECTOR_TYPE, 0, REG_DWORD, (BYTE*)&_siZenkakuVectorType, sizeof(DWORD)) != ERROR_SUCCESS)
			bResult = FALSE;
		if (pwData)
			if (RegSetValueEx(hSubKey, REGINFO_ZENKAKUVECTOR, 0, REG_MULTI_SZ, (BYTE*)pwData, nSize * sizeof(TCHAR)) != ERROR_SUCCESS)
				bResult = FALSE;
		RegCloseKey(hSubKey);
	}

	FREE(pwData);
	return bResult;
}

