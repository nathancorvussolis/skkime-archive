//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by skimconf.rc
//

/// WDK7�ł͒�`�ς�
// #define CREATEPROCESS_MANIFEST_RESOURCE_ID 1

/// ���g�p
// #define IDC_MYICON                      2
// #define RT_MANIFEST                     24
// #define IDS_APP_TITLE                   103
// #define IDD_ABOUTBOX                    103
// #define IDM_ABOUT                       104
// #define IDM_EXIT                        105
// #define IDI_SKIMCONF                    107
// #define IDI_SMALL                       108
// #define IDC_TESTCONFIG                  109
// #define IDC_SKIMCONF                    109
// #define IDR_MAINFRAME                   128
// #define IDD_EDIT_KEYBIND_EX             130
// #define IDD_ROMAKANARULE                133
// #define IDR_RT_MANIFEST1                154
// #define IDD_PROPPAGE_LARGE              159
// #define IDD_ZENKAKUVECTOR2              164
// #define IDD_DIALOG1                     166
// #define IDD_DIALOG2                     170
// #define IDD_CHOOSEFONT                  170
// #define IDC_RADIO1                      1150
// #define IDC_RADIO4                      1164
// #define IDC_EDIT1                       1151
// #define IDC_EDIT2                       1153
// #define IDC_CHECK1                      1154
// #define IDC_COMBO1                      1152
// #define IDC_COMBO2                      1165
// #define IDC_COMBO3                      1166
// #define IDC_EDIT_STATE2                 1156
// #define IDC_COMBO_STATE2                1157

/// �A�C�R��
#define IDI_MAIN                        100
#define IDI_ARROWUP                     101
#define IDI_ARROWDOWN                   102
#define IDI_ARROWUP2                    103
#define IDI_ARROWDOWN2                  104
#define IDI_RIGHTARROW                  105
#define IDI_BTNSPECIAL                  106

/// �_�C�A���O
#define IDD_PROPPAGE_CONVERSION         107
#define IDD_PROPPAGE_GENERIC            108
#define IDD_PROPPAGE_ROMAKANARULE       110
#define IDD_EDIT_KEYBIND                131
#define IDD_MENUKEYS                    134
#define IDD_KEYBOARD                    135
#define IDD_PROPPAGE_DICTIONARY         136
#define IDD_EDIT_SERVERJISYO            137
#define IDD_EDIT_FILEJISYO              138
#define IDD_EDIT_HOSTPORT               139
#define IDD_EDIT_KUTOUTENLIST           145
#define IDD_EDIT_BRACKETLIST            146
#define IDD_EDIT_KUTOUTEN               147
#define IDD_EDIT_BRACKET                148
#define IDD_PROPPAGE_COLOR              149
#define IDD_PROPPAGE_ZENKAKUVECTOR      150
#define IDD_EDIT_ONEZENKAKUVECTOR       151
#define IDD_EDIT_OKURICHARALIST         155
#define IDD_EDIT_OKURICHARPAIR          156
#define IDD_EDIT_AUTOSTARTHENKAN        157
#define IDD_EDIT_AUTOSTARTHENKAN_KEYWORD 158
#define IDD_PROPPAGE_KEYBIND            159
#define IDD_EDIT_SPECIALKEYBIND         160
#define IDD_EDIT_ROMAKANARULELIST       161
#define IDD_EDIT_KEYMAP                 162
#define IDD_EDIT_SPECIALKEY             163
#define IDD_EDIT_ZENKAKUVECTOR          164
#define IDD_EDIT_USERJISYO              165
#define IDD_ROMAKANARULE2               166

/// �R���g���[��
#define IDC_LIST_KEYBIND                1000
#define IDC_RADIO_DISABLE_ANNOTATION    1001
#define IDC_RADIO_SHOW_NO_ANNOTATION    1002
#define IDC_RADIO_SHOW_ANNOTATION_IN_CANDLIST 1003
#define IDC_RADIO_SHOW_ANNOTATION_ALWAYS 1004
#define IDC_EDIT_USRDICPATH             1010
#define IDC_BUTTON_BROWSE_USRDICTPATH   1011
#define IDC_BUTTON_REPAIR_USRDICT       1012
#define IDC_COMBO_JISX0208LATINMODE_BIND 1013
#define IDC_LIST_SEARCHDICT             1013
#define IDC_COMBO_LATINMODE_BIND        1014
#define IDC_BUTTON_ADD_FILE_JISYO       1014
#define IDC_BUTTON_INSERT_ROMKANARULE   1015
#define IDC_COMBO_ABBREVMODE_BIND       1015
#define IDC_BUTTON_REMOVE_DICT_FROM_SEARCHLIST 1015
#define IDC_BUTTON_EDIT_ROMKANARULE     1016
#define IDC_BUTTON_EDIT_DICT_IN_SEARCHLIST 1016
#define IDC_BUTTON_DELETE_ROMKANARULE   1017
#define IDC_BUTTON_ADD_SERVER_JISYO     1017
#define IDC_BUTTON_SAVEUSERJISYO        1018
#define IDC_CHECK_PROCESS_OKURI_EARLY   1022
#define IDC_CHECK_DELETE_OKURI_WHEN_QUIT 1023
#define IDC_COMBO_MAJORMODE_BIND        1023
#define IDC_EDIT_FILE_DICT_PATH         1023
#define IDC_COMBO_JMODE_BIND            1024
#define IDC_CHECK_FILE_DICT_SORTEDP     1024
#define IDC_LIST_SERVER_DICT            1025
#define IDC_CHECK_SKK_ECHO              1025
#define IDC_CHECK_AUTO_START_HENKAN     1026
#define IDC_COMBO_KEY                   1026
#define IDC_BUTTON_REMOVE               1026
#define IDC_BUTTON_BROWSE_FILE_DICT_PATH 1027
#define IDC_BUTTON_ADD_NEW_JISYO_SERVER 1028
#define IDC_BUTTON_ADD                  1028
#define IDC_CHECK_AUTO_INSERT_PAREN     1029
#define IDC_BUTTON_MODIFY               1029
#define IDC_CHECK_HENKAN_OKURI_STRICTLY 1030
#define IDC_LIST_ROMAKANARULE           1030
#define IDC_RADIO_SHOW_ROMAKANARULE_WITH_KANA 1031
#define IDC_RADIO_SHOW_ROMAKANARULE_WITH_KATA 1032
#define IDC_EDIT_SEARCH_ROMKANARULE     1033
#define IDC_BUTTON_SEARCH_ROMKANARULE_NEXT 1035
#define IDC_LIST_SELECTFACE             1038
#define IDC_EDIT_KEYPREVIEW             1043
#define IDC_BUTTON_INSERT               1052
#define IDC_BUTTON_EDIT                 1053
#define IDC_BUTTON_DELETE               1054
#define IDC_RADIO_DESCLONG              1054
#define IDC_RADIO_DESCSHORT             1055
#define IDC_EDIT_STATE                  1056
#define IDC_LIST_ZENKAKUVECTOR          1056
#define IDC_EDIT_NEXTSTATE              1057
#define IDC_CHECK_ENABLE_AUX_JISYO      1057
#define IDC_RADIO_HIRAKATA              1058
#define IDC_COMBO_BACKCOLOR             1058
#define IDC_COMBO_CHARTOBIND            1058
#define IDC_RADIO_COMMON                1059
#define IDC_EDIT_HOSTNAME               1059
#define IDC_COMBO_FORECOLOR             1059
#define IDC_EDIT_CHARVALUE              1059
#define IDC_RADIO_MACRO                 1060
#define IDC_COMBO_UNDERLINE             1060
#define IDC_COMBO_MACRO                 1061
#define IDC_COMBO_ULCOLOR               1061
#define IDC_EDIT_COMMONSTRING           1062
#define IDC_EDIT_HIRA                   1063
#define IDC_EDIT_KATA                   1064
#define IDC_EDIT_PORTNUM                1065
#define IDC_COMBO_NEXTSTATE2            1065
#define IDC_CHECK_EGG_LIKE_NEWLINE      1066
#define IDC_LIST_MENU1_KEYS             1066
#define IDC_CHECK_DELETE_IMPLIES_KAKUTEI 1067
#define IDC_LIST_CANDIDATE_KEYS         1067
#define IDC_LIST_MENU2_KEYS             1068
#define IDC_CHECK_HENKAN_STRICT_OKURI_PRECEDENCE 1070
#define IDC_RADIO_CTRL_LEFT             1072
#define IDC_RADIO_CTRL_RIGHT            1073
#define IDC_BUTTON_ARROWUP              1074
#define IDC_RADIO_CTRL_BOTH             1074
#define IDC_BUTTON_FN                   1075
#define IDC_BUTTON_ARROWDOWN            1075
#define IDC_RADIO_CTRL_NONE             1075
#define IDC_RADIO_SHIFT_LEFT            1076
#define IDC_RADIO_SHIFT_RIGHT           1077
#define IDC_RADIO_SHIFT_BOTH            1078
#define IDC_RADIO_SHIFT_NONE            1079
#define IDC_RADIO_MENU_LEFT             1080
#define IDC_RADIO_MENU_RIGHT            1081
#define IDC_RADIO_MENU_BOTH             1082
#define IDC_RADIO_MENU_NONE             1083
#define IDC_BUTTON_CONFIGCANDKEY        1087
#define IDC_CHECK_KANA_MODE_WHEN_OPEN   1088
#define IDC_RADIO_DATE_SEIREKI          1089
#define IDC_COMBO_CANDLIST_KEYASSIGN    1090
#define IDC_RADIO_DATE_GENGOU           1090
#define IDC_COMBO_SHOWCANDLIST_COUNT    1091
#define IDC_RADIO_NUMBER_HANEI          1091
#define IDC_COMBO_KEYCODE               1092
#define IDC_RADIO_NUMBER_ZENEI          1092
#define IDC_RADIO_NUMBER_KANSUJI        1093
#define IDC_COMBO_KUTOUTEN              1094
#define IDC_BUTTON_EDIT_KUTOUTEN        1095
#define IDC_LIST_KUTOUTEN               1097
#define IDC_LIST_BRACKET                1100
#define IDC_EDIT_KUTEN                  1104
#define IDC_EDIT_LBRACKET               1105
#define IDC_EDIT_RBRACKET               1106
#define IDC_EDIT_TOUTEN                 1107
#define IDC_BUTTON_PREVIEW              1109
#define IDC_CHECK_NEWLINE_KAKUTEI_ALL   1110
#define IDC_CHECK_OHHENKAN              1110
#define IDC_CHECK_NUMERICCONVERSION     1110
#define IDC_CHECK_COMPOSITION_AUTO_SHIFT 1111
#define IDC_BUTTON_APPLYKEYMAP          1111
#define IDC_BUTTON_EDIT_AUTOSTARTHENKAN_KEYWORD 1111
#define IDC_CHECK_NUMERICFLOAT          1112
#define IDC_CHECK_KAKUTEI_EARLY         1114
#define IDC_CHECK_OKURI_CHAR_ALIST      1115
#define IDC_BUTTON_EDIT_OKURI_CHAR_ALIST 1116
#define IDC_CHECK_AUTO_OKURI_PROCESS    1117
#define IDC_LIST_OKURICHARALIST         1118
#define IDC_BUTTON_EDIT_BRACKET         1121
#define IDC_EDIT_OKURICHAR_SRC          1121
#define IDC_EDIT_OKURICHAR_DEST         1122
#define IDC_EDIT_KEYWORD                1125
#define IDC_LIST_AUTOSTARTHENKAN_KEYWORD 1126
#define IDC_COMBO_VIEWITEM              1127
#define IDC_COMBO_SPECIALKEY            1127
#define IDC_COMBO_ZENKAKUVECTOR         1127
#define IDC_COMBO_OKURICHARALIST        1128
#define IDC_BUTTON_EDIT_ROMAKANARULE    1128
#define IDC_COMBO_KEYMAP                1129
#define IDC_BUTTON_EDIT_KEYMAP          1130
#define IDC_COMBO_STARTHENKANKEY        1131
#define IDC_COMBO_KAKUTEIKEY            1132
#define IDC_BUTTON_EDIT_SPECIALKEY      1133
#define IDC_LIST_SPECIALKEYBIND         1133
#define IDC_COMBO_TRYCOMPLETIONKEY      1134
#define IDC_COMBO_SETHENKANPOINTSUBRKEY 1135
#define IDC_RADIO_MAJORMODEMAP          1136
#define IDC_COMBO_NEXTCOMPKEY           1136
#define IDC_RADIO_JMODEMAP              1137
#define IDC_COMBO_PREVCOMPKEY           1137
#define IDC_RADIO_LATINMODEMAP          1138
#define IDC_COMBO_SPECIALMDASHICHARKEY  1138
#define IDC_COMBO_SPECIALMIDASHICHARKEY 1138
#define IDC_RADIO_JISX0208LATINMODEMAP  1139
#define IDC_RADIO_ABBREVMODEMAP         1140
#define IDC_COMBO_SPECIALMIDASHICHARKEY3 1140
#define IDC_COMBO_COMPLTIONRELATEDKEY   1140
#define IDC_COMBO_COMPLETIONRELATEDKEY  1140
#define IDC_RADIO_ALLMAPS               1141
#define IDC_COMBO_BRACKETPAREN          1142
#define IDC_COMBO_ROMAKANARULE          1143
#define IDC_EDIT_DESCRIPTION            1145
#define IDC_BUTTON_EDIT_ZENKAKUVECTOR   1147
#define IDC_RADIO_ENABLE                1148
#define IDC_RADIO_DISABLE               1149
#define IDC_COMBO_STATE_RULENO          1152
#define IDC_COMBO_NEXTSTATE_RULENO      1153
#define IDC_EDIT_MINIBUFFERFONT         1153
#define IDC_CHECK_ADVANCED_ROMAKANARULE 1154
#define IDC_BUTTON_STATESPECIAL         1161
#define IDC_RADIO_SHOWROMAKANARULE0     1161
#define IDC_BUTTON_NEXTSTATESPECIAL     1162
#define IDC_RADIO_SHOWROMAKANARULE1     1162
#define IDC_RADIO_SHOWROMAKANARULE2     1163
#define IDC_RADIO_SHOWROMAKANARULE3     1164
#define IDC_BUTTON_CHANGE_MINIBUFFERFONT 1164

/// ����{�^��
#define IDC_SOFTKEY_MIN					0x800
#define IDC_SOFTKEY_MAX					0x900

#define IDC_BUTTON_ESC                  0x800

#define IDC_BUTTON_BREAK                0x803
#define IDC_BUTTON_BACKSPACE            0x808
#define IDC_BUTTON_TAB                  0x809
#define IDC_BUTTON_ENTER                0x80A
#define IDC_BUTTON_UP                   0x81C
#define IDC_BUTTON_DOWN                 0x81D
#define IDC_BUTTON_LEFT                 0x81E
#define IDC_BUTTON_RIGHT                0x81F
#define IDC_BUTTON_SPACE                0x820
#define IDC_BUTTON_QUOTE                0x827
#define IDC_BUTTON_COMMA                0x82C
#define IDC_BUTTON_MINUS                0x82D
#define IDC_BUTTON_PERIOD               0x82E
#define IDC_BUTTON_SLASH                0x82F
#define IDC_BUTTON_0                    0x830
#define IDC_BUTTON_1                    0x831
#define IDC_BUTTON_2                    0x832
#define IDC_BUTTON_3                    0x833
#define IDC_BUTTON_4                    0x834
#define IDC_BUTTON_5                    0x835
#define IDC_BUTTON_6                    0x836
#define IDC_BUTTON_7                    0x837
#define IDC_BUTTON_8                    0x838
#define IDC_BUTTON_9                    0x839
#define IDC_BUTTON_SEMICOLON            0x83B
#define IDC_BUTTON_EQUAL                0x83D
#define IDC_BUTTON_A                    0x841
#define IDC_BUTTON_B                    0x842
#define IDC_BUTTON_C                    0x843
#define IDC_BUTTON_D                    0x844
#define IDC_BUTTON_E                    0x845
#define IDC_BUTTON_F                    0x846
#define IDC_BUTTON_G                    0x847
#define IDC_BUTTON_H                    0x848
#define IDC_BUTTON_I                    0x849
#define IDC_BUTTON_J                    0x84A
#define IDC_BUTTON_K                    0x84B
#define IDC_BUTTON_L                    0x84C
#define IDC_BUTTON_M                    0x84D
#define IDC_BUTTON_N                    0x84E
#define IDC_BUTTON_O                    0x84F
#define IDC_BUTTON_P                    0x850
#define IDC_BUTTON_Q                    0x851
#define IDC_BUTTON_R                    0x852
#define IDC_BUTTON_S                    0x853
#define IDC_BUTTON_T                    0x854
#define IDC_BUTTON_U                    0x855
#define IDC_BUTTON_V                    0x856
#define IDC_BUTTON_W                    0x857
#define IDC_BUTTON_X                    0x858
#define IDC_BUTTON_Y                    0x859
#define IDC_BUTTON_Z                    0x85A
#define IDC_BUTTON_LBRACKET             0x85B
#define IDC_BUTTON_BACKSLASH            0x85C
#define IDC_BUTTON_RBRACKET             0x85D
#define IDC_BUTTON_BACKQUOTE            0x860

#define IDC_SOFTKEY_INSERT              0x8C0
#define IDC_SOFTKEY_DELETE              0x8C1
#define IDC_BUTTON_CAPS                 0x8C2
#define IDC_BUTTON_LSHIFT               0x8E0
#define IDC_BUTTON_RSHIFT               0x8E1
#define IDC_BUTTON_LALT                 0x8E2
#define IDC_BUTTON_RALT                 0x8E3
#define IDC_BUTTON_RCTRL                0x8E4
#define IDC_BUTTON_LCTRL                0x8E5
#define IDC_BUTTON_F1                   0x8F1
#define IDC_BUTTON_F2                   0x8F2
#define IDC_BUTTON_F3                   0x8F3
#define IDC_BUTTON_F4                   0x8F4
#define IDC_BUTTON_F5                   0x8F5
#define IDC_BUTTON_F6                   0x8F6
#define IDC_BUTTON_F7                   0x8F7
#define IDC_BUTTON_F8                   0x8F8
#define IDC_BUTTON_F9                   0x8F9

#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        512
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         2048
#define _APS_NEXT_SYMED_VALUE           256
#endif
#endif
