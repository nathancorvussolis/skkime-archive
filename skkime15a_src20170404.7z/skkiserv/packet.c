#include "local.h"
#include "protocol.h"
#include "packet.h"
#include "kstring.h"
// #include "kanji.h"

BOOL
TPacket_SetHeader (
	register TVarbuffer*	pvbufPacket,
	register int			nMajor,
	register int			nMinor)
{
	BYTE	rbyCH [4] ;

	assert (pvbufPacket != NULL) ;

	rbyCH [0]	= (BYTE) nMajor ;
	rbyCH [1]	= (BYTE) nMinor ;
	return	TVarbuffer_Add (pvbufPacket, &rbyCH, 4) ;
}

BOOL
TPacket_AddPad (
	register TVarbuffer*	pvbufPacket)
{
	register int	nPad ;

	assert (pvbufPacket != NULL) ;

	nPad	= TVarbuffer_GetUsage (pvbufPacket) ;
	nPad	= (4 - (nPad & 3)) & 3 ;
	return	TVarbuffer_Require (pvbufPacket, nPad) ;
}

BOOL
TPacket_AddCard32 (
	register TVarbuffer*	pvbufPacket,
	register DWORD			dwDATA)
{
	BYTE	rbyCH [4] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= (BYTE)(dwDATA >>  0) ;
	rbyCH [1]	= (BYTE)(dwDATA >>  8) ;
	rbyCH [2]	= (BYTE)(dwDATA >> 16) ;
	rbyCH [3]	= (BYTE)(dwDATA >> 24) ;
	return	TVarbuffer_Add (pvbufPacket, rbyCH, 4) ;
}

BOOL
TPacket_AddCard16 (
	register TVarbuffer*	pvbufPacket,
	register WORD			woDATA)
{
	BYTE	rbyCH [2] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= (BYTE)(woDATA >>  0) ;
	rbyCH [1]	= (BYTE)(woDATA >>  8) ;
	return	TVarbuffer_Add (pvbufPacket, rbyCH, 2) ;
}

BOOL
TPacket_AddCard8 (
	register TVarbuffer*	pvbufPacket,
	register BYTE			byDATA)
{
	BYTE	rbyCH [1] ;

	/*	little endian �Ŋi�[����B*/
	rbyCH [0]	= byDATA ;
	return	TVarbuffer_Add (pvbufPacket, rbyCH, 1) ;
}

BOOL
TPacket_SetLength (
	register TVarbuffer*	pvbufPacket)
{
	register BYTE*	ptr ;
	register int	nPacket ;

	nPacket	= TVarbuffer_GetUsage  (pvbufPacket) ;
	if (nPacket <  SKKISERV_PROTO_HEADER_SIZE ||
		nPacket >= 0x10000)
		return	FALSE ;

	ptr		= (BYTE *)TVarbuffer_GetBuffer (pvbufPacket) + 2 ;
	*ptr ++	= (BYTE)(nPacket >> 0) ;
	*ptr ++	= (BYTE)(nPacket >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_SetCard16 (
	register TVarbuffer*	pvbufPacket,
	register int			nPos,
	register WORD			dwVALUE)
{
	register BYTE*	ptr ;
	register int	nUsage ;

	assert (pvbufPacket != NULL) ;

	nUsage	= TVarbuffer_GetUsage  (pvbufPacket) ;
	if (nPos < 0 || nPos >= nUsage)
		return	FALSE ;

	ptr		= (BYTE *)TVarbuffer_GetBuffer (pvbufPacket) + nPos ;
	*ptr ++	= (BYTE)(dwVALUE >> 0) ;
	*ptr ++	= (BYTE)(dwVALUE >> 8) ;
	return	TRUE ;
}

BOOL
TPacket_AddKanji (
	register TVarbuffer*	pvbufPacket,
	register const Char*	pString,
	register int			nString)
{
	WCHAR					wbuf [128] ;
	WCHAR*					pwBuffer	= NULL ;
	register int			nPos, nWChar ;

	nPos	= TVarbuffer_GetUsage (pvbufPacket) ;
	if (TFAILED (TPacket_AddCard16 (pvbufPacket, 0)))
		return	FALSE ;

	nWChar	= internal2wstr (NULL, 0, pString, nString) ;
	if (nWChar < 0 || nWChar >= 0x10000)
		return	FALSE ;

	if (nWChar < ARRAYSIZE (wbuf)) {
		(void) internal2wstr (wbuf, ARRAYSIZE (wbuf), pString, nString) ;
		pwBuffer	= wbuf ;
	} else {
		pwBuffer	= (WCHAR*) MALLOC (sizeof (WCHAR) * nWChar) ;
		if (pwBuffer == NULL)
			return	FALSE ;
		(void) internal2wstr (pwBuffer, nWChar, pString, nString) ;
	}
	{
		BOOL	bRetval ;

		bRetval	= TVarbuffer_Add (pvbufPacket, pwBuffer, nWChar * sizeof (WCHAR)) ;
		if (pwBuffer != wbuf) {
			FREE (pwBuffer) ;
		}
		if (TFAILED (bRetval))
			return	FALSE ;
	}
	if (TFAILED (TPacket_AddPad (pvbufPacket)))
		return	FALSE ;

	DEBUGPRINTF ((TEXT ("TPacket_AddKanji (pos:%d, len:%d)\n"), nPos, nWChar)) ;

	return	TPacket_SetCard16 (pvbufPacket, nPos, (WORD)nWChar) ;
}

BOOL
TPacket_AddString (
	register TVarbuffer*	pvbufPacket,
	register LPCWSTR		pString,
	register int			nString)
{
	register int			nPos ;

	if (nString < 0 || nString >= 0x10000)
		return	FALSE ;
	if (nString != 0 && pString == NULL)
		return	FALSE ;

	if (TFAILED (TPacket_AddCard16 (pvbufPacket, (WORD)nString)))
		return	FALSE ;

	nPos	= TVarbuffer_GetUsage (pvbufPacket) ;
	if (nString > 0) {
		register LPBYTE			ptr ;

		if (TFAILED (TVarbuffer_Require (pvbufPacket, sizeof (wchar_t) * nString)))
			return	FALSE ;

		ptr		= (LPBYTE)TVarbuffer_GetBuffer (pvbufPacket) + nPos ;
		memcpy (ptr, pString, nString * sizeof (wchar_t)) ;
	}
	if (TFAILED (TPacket_AddPad (pvbufPacket)))
		return	FALSE ;
	return	TRUE ;
}


