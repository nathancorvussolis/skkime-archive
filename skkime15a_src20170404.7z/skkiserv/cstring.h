#if !defined (cstring_h)
#define	cstring_h

// #include "local.h"
// #include "Char.h"

int		Cstrlen		(const Char*) ;
int		Cstrcmp		(const Char*, const Char*) ;
int		Cstrncmp	(const Char*, const Char*, int) ;
int		Cstrnccmp	(const Char*, const char*, int) ;
Char*	Cstrcpy		(Char*, const Char*) ;
Char*	Cstrncpy	(Char*, const Char*, int) ;
LPTSTR	cstrtostr	(LPTSTR, const Char*, int) ;
Char*	strtocstr	(Char*, LPCTSTR, int) ;
int		cmemcmp		(const Char*, int, const Char*, int) ;
int		cmemccmp	(const Char*, int, LPCTSTR, int) ;
BOOL	catoi		(const Char*, int, long* const) ;
int		quoteCstring(Char*, const Char*, int) ;

#endif

