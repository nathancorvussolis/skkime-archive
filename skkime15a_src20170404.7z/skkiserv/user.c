#include "local.h"
#include "user.h"
#include "localjisyo.h"
#include "serverjisyo.h"
#include "genericjisyo.h"
#include "sortedjisyo.h"
#include "okurijisyo.h"
// #include "urlparser.h"

#if defined (USER_UNIT_TEST)
#include <stdio.h>
#include "kstring.h"
#include "lmcons.h"
#undef  DEBUGPRINTF
#define	DEBUGPRINTF(arg)	_tprintf##arg
#endif

/*========================================================================
 *	definitions
 */
#define	MAX_REGVALUE_SIZE					256

#include "../common/regpath.h"
#define	REGPATH_DICTIONARY					REGPATH_SKKIME TEXT("\\Dictionaries")
#define	REGKEY_USERJISYO					TEXT("User")
#define REGKEY_ENTRY						TEXT("Dict%d")

#include "../common/userdict.h"
#define	DEFAULT_SKKSERV_PORTNUM				1178

/// REGPATH_GENERIC �̃G���g�� (GUI���ɊY���G���g�����Ȃ��̂Œ���)
#define	REGKEY_KAKUTEI_HISTORY_LIMIT		TEXT("KakuteiHistoryLimit")
#define	MAX_KAKUTEI_HISTORY_LIMIT			1024

#define	REGPATH_CONVERSION					REGPATH_GENERIC
#define	REGINFO_HENKANOKURISTRICTLY			TEXT("HenkanOkuriStrictly")
#define	REGINFO_PROCESSOKURIEARLY			TEXT("ProcessOkuriEarly")
#define	REGINFO_HENKANSTRICTOKURIPRECEDENCE	TEXT("HenkanStrictOkuriPrecedence")
#define	REGINFO_AUTOOKURIPROCESS			TEXT("AutoOkuriProcess")

enum {
	DEFAULT_HENKAN_OKURI_STRICTLY			= FALSE,
	DEFAULT_PROCESS_OKURI_EARLY				= FALSE,
	DEFAULT_HENKAN_STRICT_OKURI_PRECEDENCE	= FALSE,
	DEFAULT_AUTO_OKURI_PROCESS				= FALSE,
} ;

/*========================================================================
 *	structures
 */
struct tagSkkKakuteiHistoryItem {
	const Char*		m_pMidasi ;
	int				m_nMidasiLen ;
	const Char*		m_pWord ;
	int				m_nWordLen ;
	struct tagSkkKakuteiHistoryItem*	m_pNext ;
} ;

/*========================================================================
 *	prototypes
 */
static	SkkImeUser*	skkImeUser_create				(LPCTSTR, int) ;
static	void		skkImeUser_destroy				(SkkImeUser*) ;
static	SkkJisyo*	skkImeUser_createJisyo			(SkkImeUser*, LPCTSTR) ;
static	int			skkImeUser_checkFilePath		(LPCTSTR, BOOL*) ;
static	BOOL		skkImeUser_setup				(SkkImeUser*) ;
static	BOOL		skkImeUser_resetup				(SkkImeUser*) ;
static	BOOL		skkImeUser_getUserJisyoPath		(LPTSTR) ;
static	BOOL		skkImeUser_setupSearchJisyoList	(SkkImeUser*) ;
static	SkkJisyo*	skkimeUser_parseJisyoSetting	(SkkImeUser*, LPCTSTR) ;
static	BOOL		skkimeUser_insertJisyo			(SkkImeUser*, int, SkkJisyo*) ;

static	SkkKakuteiHistoryItem*	skkimeUser_pCreateKakuteiHistoryItem (const Char*, int, const Char*, int) ;
static	void		skkimeUser_vDeleteKakuteiHistoryItem	(SkkKakuteiHistoryItem*) ;
static	BOOL		skkimeUser_bInitKakuteiHistoryLimit		(SkkImeUser*) ;


SkkImeUser*
SkkImeUser_Create (
	register LPCTSTR		pUserName,
	register int			nUserName)
{
	if (nUserName >= UNLEN)
		return	NULL ;

	return	skkImeUser_create (pUserName, nUserName) ;
}

void
SkkImeUser_Destroy (
	register SkkImeUser*	pUser)
{
	if (pUser == NULL)
		return ;

	skkImeUser_destroy (pUser) ;
	FREE (pUser) ;
	return ;
}

/*========================================================================*
 *	�����̌����B
 *---
 *	���艼�������݂���ꍇ�ɂ͓���ȑ��삪�K�v��������Ȃ��B
 */
BOOL
SkkImeUser_Search (
	SkkImeUser*		pUser,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	TVarbuffer*		pvbuf)
{
	register SkkJisyo**	pJisyo ;
	register int		i ;

	assert (pUser != NULL) ;

	if (pKey == NULL || nKey <= 0)
		return	FALSE ;

	pJisyo	= pUser->m_rpJisyo ;
	for (i = 0 ; i < MAX_USER_JISYOS ; i ++) {
		if (*pJisyo != NULL) {
			if (! SkkJisyo_Search (*pJisyo, pKey, nKey, pOkurigana, nOkurigana, nOkuriType, pvbuf)) {
				DEBUGPRINTF ((TEXT ("DIC%d: faild\n"), i)) ;
				return	FALSE ;
			}
		}
		pJisyo	++ ;
	}
	return	TRUE ;
}

BOOL
SkkImeUser_SearchEx (
	SkkImeUser*		pUser,
	const Char*		pKey,
	int				nKey,
	const Char*		pOkurigana,
	int				nOkurigana,
	int				nOkuriType,
	int				nDict,
	TVarbuffer*		pvbuf,
	int*			pnNext)
{
	SkkJisyo**	pJisyo ;
	int		i ;

	assert (pUser != NULL) ;

	if (pKey == NULL || nKey <= 0)
		return	FALSE ;

	/*	�w�肳�ꂽ�ʒu���珇�ԂɌ��t�������ŏ��̎�������������B*/
	pJisyo	= &pUser->m_rpJisyo [nDict] ;
	for (i = nDict ; i < MAX_USER_JISYOS ; i ++) {
		if (*pJisyo != NULL) {
			if (SkkJisyo_Search (*pJisyo, pKey, nKey, pOkurigana, nOkurigana, nOkuriType, pvbuf)) {
#if defined (DEBUG) || defined (_DEBUG)
				if (pvbuf != NULL && TVarbuffer_GetUsage (pvbuf) > 0) {
					int		nUsage	= TVarbuffer_GetUsage (pvbuf) ;
					LPCWSTR	ptr		= (LPCWSTR) TVarbuffer_GetBuffer (pvbuf) ;
					DEBUGPRINTF ((TEXT ("Search(%d): lastchar = 0x%04X/%d\n"), i, *(ptr + nUsage - 1), nUsage)) ;
				}
#endif
				pJisyo	++ ;
				i		++ ;
				break ;
			}
		}
		pJisyo	++ ;
	}
	/*	search next */
	while (i < MAX_USER_JISYOS) {
		if (*pJisyo != NULL)
			break ;
		pJisyo	++ ;
		i		++ ;
	}
	*pnNext	= (i < MAX_USER_JISYOS)? i : -1 ;
	return	TRUE ;
}


/*	�����̃Z�[�u�B
 */
BOOL
SkkImeUser_Save (
	register SkkImeUser*	pUser)
{
	assert (pUser != NULL) ;

	if (pUser->m_pLocalJisyo == NULL)
		return	FALSE ;

	return	SkkJisyo_Save (pUser->m_pLocalJisyo) ;
}

/*	�ϊ����̃R���v���[�V�����B
 */
BOOL
SkkImeUser_TryCompletion (
	register SkkImeUser*	pUser,
	register const Char*	pKey,
	register int			nKey,
	register TVarbuffer*	pvbuf)
{
	register SkkJisyo**	pJisyo ;
	register int		i ;

	assert (pUser != NULL) ;

	if (pKey == NULL || nKey <= 0)
		return	FALSE ;

	pJisyo	= pUser->m_rpJisyo ;
	for (i = 0 ; i < MAX_USER_JISYOS ; i ++) {
		if (*pJisyo != NULL) {
			if (! SkkJisyo_TryCompletion (*pJisyo, pKey, nKey, pvbuf))
				return	FALSE ;
		}
		pJisyo	++ ;
	}
	return	TRUE ;
}

/*[�@�\]
 *	���[�U�����̃Z�[�u�y�ю����ݒ�̍ēǂݍ��݁B�������A���[�U������
 *	path �������Ȃ� reload ���Ȃ��B���R�� save �������_�ŁA����
 *	process �������Ă������[�U�����ƃt�@�C���̒��g�������ɂȂ邩��B
 *	(�����Ă�����̂�������x�ǂݍ��ނ́H)
 */
BOOL
SkkImeUser_Update (
	register SkkImeUser*	pUser)
{
	SkkImeUser_Save (pUser) ;
	return	skkImeUser_resetup (pUser) ;
}

/*	�P��o�^�B
 */
BOOL
SkkImeUser_Record (
	SkkImeUser*		pUser,
	const Char*		pKey,
	int				nKey,
	const Char*		pResult,
	int				nResult,
	const Char*		pOkurigana,
	int				nOkurigana,
	BOOL			bOkuri)
{
	BOOL	bRetval ;

	assert (pUser != NULL) ;

	if (pUser->m_pLocalJisyo == NULL)
		return	FALSE ;

	bRetval	= SkkJisyo_Record (pUser->m_pLocalJisyo, pKey, nKey, pResult, nResult, pOkurigana, nOkurigana, bOkuri) ;
	if (bRetval && ! bOkuri)
		return	SkkImeUser_RecordKakuteiHistory (pUser, pKey, nKey, pResult, nResult) ;

	return	bRetval ;
}

/*	�P��폜�B
 */
BOOL
SkkImeUser_Purge (
	SkkImeUser*		pUser,
	const Char*		pKey,
	int				nKey,
	const Char*		pResult,
	int				nResult,
	const Char*		pOkurigana,
	int				nOkurigana,
	BOOL			bOkuri)
{
	assert (pUser != NULL) ;

	if (pUser->m_pLocalJisyo == NULL)
		return	FALSE ;

	return	SkkJisyo_Purge (pUser->m_pLocalJisyo, pKey, nKey, pResult, nResult, pOkurigana, nOkurigana, bOkuri) ;
}

/*	skk-kakutei-history �͑��肠��̏ꍇ�͓o�^����Ȃ��̂ŁApOkurigana/nOkurigana/bOkuri ��
 *	�����ɑ��݂��Ȃ��B
 */
BOOL
SkkImeUser_RecordKakuteiHistory (
	SkkImeUser*		pUser,
	const Char*		pKey,
	int				nKey,
	const Char*		pResult,
	int				nResult)
{
	SkkKakuteiHistoryItem*	pNewItem ;

	/*	skk-kakutei-history �� limit �� default �� 100�Bregistry ���� limit ���N�����ɓǂނׂ����Ƃ͎v���c�B
	 */
	if (pUser->m_nKakuteiHistoryItems >= pUser->m_nKakuteiHistoryLimit) {
		SkkKakuteiHistoryItem*	pItem ;
		SkkKakuteiHistoryItem*	pNextItem ;
		int		nItemToDelete, nDeleted ;

		nItemToDelete	= (pUser->m_nKakuteiHistoryItems - pUser->m_nKakuteiHistoryLimit) + 1 ;
		pItem			= pUser->m_plstKakuteiHistory ;
		for (nDeleted = 0 ; nDeleted < nItemToDelete && pItem != NULL ; nDeleted ++) {
			pNextItem	= pItem->m_pNext ;
			skkimeUser_vDeleteKakuteiHistoryItem (pItem) ;
			pItem		= pNextItem ;
		}
		pUser->m_nKakuteiHistoryItems	-= nDeleted ;
		pUser->m_plstKakuteiHistory		= pItem ;
		if (pItem == NULL) {
			pUser->m_plstKakuteiHistoryLastItem	= NULL ;
			pUser->m_nKakuteiHistoryItems		= 0 ;
		}
	}
	if (pUser->m_nKakuteiHistoryLimit <= 0)
		return	TRUE ;	/* done */

	pNewItem	= skkimeUser_pCreateKakuteiHistoryItem (pKey, nKey, pResult, nResult) ;
	if (pNewItem == NULL)
		return	FALSE ;

	if (pUser->m_plstKakuteiHistory == NULL) {
		pUser->m_plstKakuteiHistory			= pNewItem ;
		pUser->m_plstKakuteiHistoryLastItem	= pNewItem ;
		pUser->m_nKakuteiHistoryItems	= 0 ;
	} else {
		if (pUser->m_plstKakuteiHistoryLastItem == NULL)
			return	FALSE ;	/* fatal error */
		pUser->m_plstKakuteiHistoryLastItem->m_pNext	= pNewItem ;
		pUser->m_plstKakuteiHistoryLastItem				= pNewItem ;
	}
	pUser->m_nKakuteiHistoryItems	++ ;
	return	TRUE ;
}

/*	�q�X�g���[����ׂ邾���Ȃ̂ŃL�[���[�h��n���K�v�͂Ȃ��B
 */
BOOL
SkkImeUser_GetKakuteiHistory (
	SkkImeUser*				pUser,
	register TVarbuffer*	pvbuf)
{
	SkkKakuteiHistoryItem*	pNode ;
	static const Char		chSpace	= ' ' ;

	pNode	= pUser->m_plstKakuteiHistory ;
	while (pNode != NULL) {
		/* SEPARATOR �𖄂߂�B*/
		if (! TVarbuffer_Add (pvbuf, &chSpace, 1) ||
			! TVarbuffer_Add (pvbuf, pNode->m_pMidasi, pNode->m_nMidasiLen))
			return	FALSE ;
		pNode	= pNode->m_pNext ;
	}
	return	TRUE ;
}

/*========================================================================
 *	private functions
 */
SkkImeUser*
skkImeUser_create (
	register LPCTSTR		pUserName,
	register int			nUserName)
{
	register SkkImeUser*	pUser ;
	register int			i ;

	if (nUserName >= UNLEN)
		return	NULL ;

	pUser	= MALLOC (sizeof (SkkImeUser)) ;
	if (pUser == NULL)
		return	NULL ;

	/*	���[�J�������� PATH �̓��[�U�������ӂɌ��肳���B
	 */
	memcpy (pUser->m_tszUserName, pUserName, sizeof (TCHAR) * nUserName) ;
	pUser->m_tszUserName [nUserName]	= TEXT('\0') ;

	for (i = 0 ; i < MAX_USER_JISYOS ; i ++) {
		pUser->m_rnPriority [i]	= -1 ;
		pUser->m_rpJisyo    [i]	= NULL ;
	}
	pUser->m_pLocalJisyo				= NULL ;
	pUser->m_pOkuriJisyo				= NULL ;


	pUser->m_nKakuteiHistoryItems		= 0 ;
	pUser->m_plstKakuteiHistoryLastItem	= NULL ;
	pUser->m_plstKakuteiHistory			= NULL ;
	pUser->m_nKakuteiHistoryLimit		= DEFAULT_KAKUTEI_HISTORY_LIMITS ;

	skkImeUser_setup (pUser) ;
	return	pUser ;
}

void
skkImeUser_destroy (
	register SkkImeUser*	pUser)
{
	register int	i ;

	if (pUser == NULL)
		return ;

	/*	�������̔j���B
	 */
	for (i = 0 ; i < MAX_USER_JISYOS ; i ++) {
		if (pUser->m_rpJisyo [i] != NULL &&
			pUser->m_rpJisyo [i] != pUser->m_pLocalJisyo &&
			pUser->m_rpJisyo [i] != pUser->m_pOkuriJisyo)
			SkkJisyo_Destroy (pUser->m_rpJisyo [i]) ;
		pUser->m_rpJisyo [i]	= NULL ;
	}
	if (pUser->m_pLocalJisyo != NULL)
		SkkJisyo_Destroy (pUser->m_pLocalJisyo) ;
	if (pUser->m_pOkuriJisyo != NULL)
		SkkJisyo_Destroy (pUser->m_pOkuriJisyo) ;
	pUser->m_pLocalJisyo	= NULL ;

	/*	�m�藚�𑤂̔j���B
	 */
	if (pUser->m_plstKakuteiHistory != NULL) {
		SkkKakuteiHistoryItem*	pNode	= pUser->m_plstKakuteiHistory ;
		SkkKakuteiHistoryItem*	pNextNode ;

		while (pNode != NULL) {
			pNextNode	= pNode->m_pNext ;
			skkimeUser_vDeleteKakuteiHistoryItem (pNode) ;
			pNode		= pNextNode ;
		}
	}
	pUser->m_nKakuteiHistoryItems		= 0 ;
	pUser->m_plstKakuteiHistoryLastItem	= NULL ;
	pUser->m_plstKakuteiHistory			= NULL ;
	pUser->m_nKakuteiHistoryLimit		= DEFAULT_KAKUTEI_HISTORY_LIMITS ;
	return ;
}

BOOL
skkImeUser_setup (
	register SkkImeUser*	pUser)
{
	TCHAR	szPath [MAX_PATH + 1] ;

#if defined (DEBUG) || defined (_DEBUG)
	DEBUGPRINTF ((TEXT ("skkImeUser_setup (%p): enter\n"), pUser)) ;
#endif
	skkImeUser_getUserJisyoPath (szPath) ;
	pUser->m_pLocalJisyo	= SkkLocalJisyo_CreateT (szPath) ;
	pUser->m_pOkuriJisyo	= SkkOkuriSearchJisyo_Create (pUser->m_pLocalJisyo) ;

	skkimeUser_bInitKakuteiHistoryLimit (pUser) ;
	return	skkImeUser_setupSearchJisyoList (pUser) ;
}

BOOL
skkImeUser_resetup (
	register SkkImeUser*	pUser)
{
	register int	i ;

	assert (pUser != NULL) ;

	skkImeUser_destroy (pUser) ;
	for (i = 0 ; i < MAX_USER_JISYOS ; i ++) {
		pUser->m_rnPriority [i]	= -1 ;
		pUser->m_rpJisyo    [i]	= NULL ;
	}
	pUser->m_pLocalJisyo	= NULL ;
	pUser->m_pOkuriJisyo	= NULL ;
	return	skkImeUser_setup (pUser) ;
}

BOOL
skkImeUser_getUserJisyoPath (
	register LPTSTR			pszPath)
{
#if 1
	HKEY				hSubKey ;
	TCHAR				rbyData [MAX_REGVALUE_SIZE] ;
	DWORD				dwType, cbData ;
	register DWORD		dwRetval ;

	/*	���W�X�g������ݒ��ǂށB*/
	dwRetval	= RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_DICTIONARY, 0, KEY_READ, &hSubKey) ;
	if (dwRetval == ERROR_SUCCESS) {
		register LONG	lResult ;

		lResult	= RegQueryValueEx (hSubKey, REGKEY_USERJISYO, NULL, &dwType, NULL, &cbData) ;
		if (lResult != ERROR_SUCCESS ||
			(dwType != REG_SZ && dwType != REG_EXPAND_SZ) ||
			cbData > MAX_PATH) {
			if (! ExpandEnvironmentStrings (SKKIME_DEFAULT_USERJISYO, pszPath, MAX_PATH)) {
				pszPath [0]	= TEXT ('\0') ;
			} else {
				pszPath [MAX_PATH]	= TEXT ('\0') ;
			}
		} else {
			cbData	= ARRAYSIZE (rbyData) ;
			(void) RegQueryValueEx (hSubKey, REGKEY_USERJISYO, NULL, &dwType, (BYTE *)rbyData, &cbData) ;
			if (! ExpandEnvironmentStrings (rbyData, pszPath, MAX_PATH)) {
				pszPath [0]	= TEXT ('\0') ;
			} else {
				pszPath [MAX_PATH]	= TEXT ('\0') ;
			}
		}
		RegCloseKey (hSubKey) ;
	} else {
		/*	�f�t�H���g�̐ݒ������B
		 *	�f�t�H���g�̐ݒ�ł́A���[�U�����̌������擪�ɂ��邾���H
		 */
		if (! ExpandEnvironmentStrings (SKKIME_DEFAULT_USERJISYO, pszPath, MAX_PATH)) {
			pszPath [0]	= TEXT ('\0') ;
		} else {
			pszPath [MAX_PATH]	= TEXT ('\0') ;
		}
	}
#else
	if (! ExpandEnvironmentStrings (TEXT("C:\\TMP\\x4\\skk-jisyo.txt"), pszPath, MAX_PATH)) {
		pszPath [0]	= TEXT ('\0') ;
	} else {
		pszPath [MAX_PATH]	= TEXT ('\0') ;
	}
#endif
	return	TRUE ;
}

BOOL
skkImeUser_setupSearchJisyoList (
	register SkkImeUser*	pUser)
{
	HKEY				hSubKey ;
	TCHAR				szPath [MAX_PATH + 1] ;
	TCHAR				rbyData [MAX_REGVALUE_SIZE] ;
	DWORD				dwPath, dwType, cbData ;
	register DWORD		dwRetval ;
	register SkkJisyo*	pJisyo ;

	/*	���W�X�g������ݒ��ǂށB*/
	dwRetval	= RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_DICTIONARY, 0, KEY_READ, &hSubKey) ;
	if (dwRetval == ERROR_SUCCESS) {
		register int	nIndex ;
		int				nDict ;
		register LONG	lResult ;

		for (nIndex = 0 ; nIndex < INT_MAX ; nIndex ++) {
			szPath [0]	= TEXT ('\0') ;
			dwPath		= ARRAYSIZE (szPath) ;
			cbData		= ARRAYSIZE (rbyData) ;
			lResult	= RegEnumValue (hSubKey, (DWORD)nIndex, szPath, &dwPath, NULL, NULL, NULL, NULL) ;
			if (lResult != ERROR_SUCCESS)
				break ;
#if __STDC_WANT_SECURE_LIB__
			if (_stscanf_s (szPath, REGKEY_ENTRY, &nDict) != 1)
				continue ;
#else
			if (_stscanf (szPath, REGKEY_ENTRY, &nDict) != 1)
				continue ;
#endif

			/*	nDict �����������ԍ��B*/
			lResult	= RegQueryValueEx (hSubKey, szPath, NULL, &dwType, NULL, &cbData) ;
			if (lResult != ERROR_SUCCESS || dwType != REG_SZ)
				continue ;
			/*	Too big value. */
			if (cbData >= sizeof(TCHAR) * MAX_REGVALUE_SIZE)
				continue ;
			cbData	= ARRAYSIZE (rbyData) ;
			(void) RegQueryValueEx (hSubKey, szPath, NULL, NULL, (BYTE *)rbyData, &cbData) ;

			pJisyo	= skkimeUser_parseJisyoSetting (pUser, rbyData) ;
			if (pJisyo != NULL)
				skkimeUser_insertJisyo (pUser, nDict, pJisyo) ;
		}
		RegCloseKey (hSubKey) ;
	} else {
		/*	�f�t�H���g�̐ݒ������B
		 *	�f�t�H���g�̐ݒ�ł́A���[�U�����̌������擪�ɁA���� okuri-search �����邾���c�B
		 */
		if (pUser->m_pLocalJisyo != NULL) {
			skkimeUser_insertJisyo (pUser, 0, pUser->m_pLocalJisyo) ;
			if (pUser->m_pOkuriJisyo != NULL)
				skkimeUser_insertJisyo (pUser, 1, pUser->m_pOkuriJisyo) ;
		}
	}
	return	TRUE ;
}

SkkJisyo*
skkimeUser_parseJisyoSetting (
	register SkkImeUser*	pUser,
	register LPCTSTR		strJisyo)
{
	if (pUser == NULL || strJisyo == NULL)
		return	NULL ;

#if defined (DEBUG) || defined (_DEBUG)
	DEBUGPRINTF ((TEXT ("skkimeUser_parseJisyoSetting (%p, \"%s\")\n"), pUser, strJisyo)) ;
#endif
	if (! _tcsncmp (strJisyo, TEXT ("server="), 7))
		return	SkkServerJisyo_Create (strJisyo + 7) ;

	/*	���[�U�����y�ё��艼�������͐ݒ肪������������ANULL ��Ԃ��B
	 */
	if (! _tcsncmp (strJisyo, TEXT ("user="), 5)) {
		return	(! _tcsncmp (strJisyo + 5, TEXT ("disable"), 7))? NULL : pUser->m_pLocalJisyo ;
	}
	if (! _tcsncmp (strJisyo, TEXT ("okuri="), 6)) {
		return	(! _tcsncmp (strJisyo + 6, TEXT ("disable"), 7))? NULL : pUser->m_pOkuriJisyo ;
	}

	if (! _tcsncmp (strJisyo, TEXT ("file="), 5))
		return	SkkGenericJisyo_CreateT (strJisyo + 5) ;

	if (! _tcsncmp (strJisyo, TEXT ("sort="), 5))
		return	SkkSortedJisyo_CreateT (strJisyo + 5,  -1) ;

	return	NULL ;
}

BOOL
skkimeUser_insertJisyo (
	register SkkImeUser*	pUser,
	register int			nPriority,
	register SkkJisyo*		pJisyo)
{
	register SkkJisyo**	ppJisyoTop ;
	register SkkJisyo*	pLastJisyo ;
	register int*		pnPriorTop ;
	register int*		pnPriority ;
	register int		i, nLastPrior ;

	if (pUser == NULL || pJisyo == NULL || nPriority < 0)
		return	FALSE ;

	ppJisyoTop	= pUser->m_rpJisyo ;
	pnPriorTop	= pUser->m_rnPriority ;
	pnPriority	= pnPriorTop ;
	for (i = 0 ; i < MAX_USER_JISYOS && *pnPriority >= 0 ; i ++, pnPriority ++) {
		if (*pnPriority  > nPriority) {
			register int	nMove	= MAX_USER_JISYOS - i - 1 ;
			nLastPrior	= pnPriorTop [MAX_USER_JISYOS - 1] ;
			pLastJisyo	= ppJisyoTop [MAX_USER_JISYOS - 1] ;
			if (nMove > 0) {
				memmove (ppJisyoTop + i + 1, ppJisyoTop + i, nMove * sizeof (SkkJisyo*)) ;
				memmove (pnPriorTop + i + 1, pnPriorTop + i, nMove * sizeof (int)) ;
			}
			ppJisyoTop [i]	= pJisyo ;
			pnPriorTop [i]	= nPriority ;
			/*	���ӂꂽ�����͎̂Ă���B*/
			if (pLastJisyo != NULL && pLastJisyo != pUser->m_pLocalJisyo)
				SkkJisyo_Destroy (pLastJisyo) ;
			return	TRUE ;
		}
	}
	if (i >= MAX_USER_JISYOS)
		return	FALSE ;
	pUser->m_rnPriority [i]	= nPriority ;
	pUser->m_rpJisyo    [i]	= pJisyo ;
	return	TRUE ;
}

/*========================================================================
 *	�m�藚���Ɋւ��� function
 *---
 *	�m�藚���́u��v�̃R���v���[�V��������ŗ��p����B
 */
BOOL
skkimeUser_bInitKakuteiHistoryLimit (
	SkkImeUser*			pUser)
{
	HKEY	hSubKey ;
	DWORD	dwRetval, dwValue ;

	dwValue		= DEFAULT_KAKUTEI_HISTORY_LIMITS ;
	dwRetval	= RegOpenKeyEx (HKEY_CURRENT_USER, REGPATH_GENERIC, 0, KEY_READ, &hSubKey) ;
	if (dwRetval == ERROR_SUCCESS) {
		LONG	lResult ;
		DWORD	dwType, cbData, dwValue ;

		cbData	= 0 ;
		lResult	= RegQueryValueEx (hSubKey, REGKEY_KAKUTEI_HISTORY_LIMIT, NULL, &dwType, NULL, &cbData) ;
		if (lResult == ERROR_SUCCESS && dwType == REG_DWORD && cbData == sizeof (dwValue)) {
		} else {
			(void) RegQueryValueEx (hSubKey, REGKEY_KAKUTEI_HISTORY_LIMIT, NULL, &dwType, (LPBYTE)&dwValue, &cbData) ;
		}
		RegCloseKey (hSubKey) ;
	}
	dwValue	= (dwValue > MAX_KAKUTEI_HISTORY_LIMIT)? MAX_KAKUTEI_HISTORY_LIMIT : dwValue ;
	pUser->m_nKakuteiHistoryLimit	= dwValue ;
	return	TRUE ;
}

SkkKakuteiHistoryItem*
skkimeUser_pCreateKakuteiHistoryItem (
	const Char*					pMidasi,
	int							nMidasiLen,
	const Char*					pWord,
	int							nWordLen)
{
	SkkKakuteiHistoryItem*	pItem ;
	Char*	pChar ;
	int		nSize ;

	if (nMidasiLen <= 0 || pMidasi == NULL || nWordLen < 0 || (nMidasiLen + nWordLen) < nMidasiLen)
		return	NULL ;

	nSize	= sizeof (SkkKakuteiHistoryItem) + (nMidasiLen + nWordLen) * sizeof (Char) ;
	if (nSize < sizeof (SkkKakuteiHistoryItem))
		return	NULL ;
	pItem	= (SkkKakuteiHistoryItem*) malloc (nSize) ;
	if (pItem == NULL)
		return	NULL ;

	pItem->m_pNext		= NULL ;
	pItem->m_nWordLen	= nWordLen ;
	pChar				= (Char*)(pItem + 1) ;

	/* ���o���͕K���K�v�B*/
	pItem->m_pMidasi	= pChar ;
	pItem->m_nMidasiLen	= nMidasiLen ;
	memcpy (pChar, pMidasi, nMidasiLen * sizeof (Char)) ;
	pChar				+= nMidasiLen ;

	if (pWord != NULL && nWordLen > 0) {
		pItem->m_pWord		= pChar ;
		pItem->m_nWordLen	= nWordLen ;
		memcpy (pChar, pWord, nWordLen * sizeof (Char)) ;
	} else {
		pItem->m_pWord		= NULL ;
		pItem->m_nWordLen	= 0 ;
	}
	return	pItem ;
}

void
skkimeUser_vDeleteKakuteiHistoryItem (
	SkkKakuteiHistoryItem*		pItem)
{
	if (pItem == NULL)
		return ;
	free (pItem) ;
	return ;
}

#if defined (USER_UNIT_TEST)
#if 0
int
_tmain (void)
{
	register SkkImeUser*	pUser ;
	WSADATA					wsaData ;
	register WORD			wVersion ;
	TCHAR					rszUserName [UNLEN + 1] ;
	ULONG					ulUserNameLen ;
	TCHAR				szBuffer [256] ;
	TVarbuffer			vbufResult ;
	Char				szCKey [256] ;
	register Char*		pCResult ;
	register int		nCResult, nwKey, n, nCKey ;
	register int		nRetval	= EXIT_FAILURE ;

	_tsetlocale (LC_ALL, TEXT ("japanese")) ;

	wVersion	= MAKEWORD (2, 0) ;
	if (WSAStartup (wVersion, &wsaData) != 0)
		return	EXIT_FAILURE ;
	if (LOBYTE (wsaData.wVersion) != 2 || HIBYTE (wsaData.wVersion) < 0) {
		_ftprintf (stderr, TEXT ("WinSock version mismatch. (%x)\n"), wsaData.wVersion) ;
		goto	exit_func ;
	}

	ulUserNameLen	= sizeof (rszUserName) / sizeof (rszUserName [0]) - 1 ;
	if (! GetUserName (rszUserName, &ulUserNameLen))
		goto	exit_func ;
	rszUserName [UNLEN]	= TEXT ('\0') ;

	pUser	= SkkImeUser_Create (rszUserName, ulUserNameLen) ;
	if (pUser == NULL)
		goto	exit_func ;

	TVarbuffer_Initialize (&vbufResult, sizeof (Char)) ;
	while (! feof (stdin)) {
		_tprintf (TEXT ("> ")) ;
		fflush (stdout) ;
		if (_fgetts (szBuffer, ARRAYSIZE (szBuffer), stdin) == NULL)
			break ;
		nwKey	= lstrlen (szBuffer) ;
		while (nwKey > 0 &&
			   (szBuffer [nwKey - 1] == TEXT ('\n') ||
				szBuffer [nwKey - 1] == TEXT ('\r')))
			nwKey	-- ;
		if (nwKey <= 0)
			continue ;
		nCKey	= wstr2internal (szCKey, ARRAYSIZE (szCKey), szBuffer, nwKey) ;
		if (nCKey >= ARRAYSIZE (szCKey)) {
			_tprintf (TEXT ("Too long keyword\n")) ;
			continue ;
		}
		if (SkkImeUser_Search (pUser, szCKey, nCKey, FALSE, &vbufResult)) {
			pCResult	= TVarbuffer_GetBuffer (&vbufResult) ;
			nCResult	= TVarbuffer_GetUsage  (&vbufResult) ;
			n			= internal2wstr (szBuffer, ARRAYSIZE (szBuffer), pCResult, nCResult) ;
			if (n >= ARRAYSIZE (szBuffer)) {
				_tprintf (TEXT ("Result is long(%d/%d) ... \n"), n, nCResult) ;
				szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
			} else {
				szBuffer [n]	= TEXT ('\0') ;
			}
			_tprintf (TEXT ("200 OK \"%s\"\n"), szBuffer) ;
		} else {
			_tprintf (TEXT ("404 Not found\n")) ;
		}
		TVarbuffer_Clear (&vbufResult) ;
	}
	TVarbuffer_Uninitialize (&vbufResult) ;
	nRetval	= EXIT_SUCCESS ;

  exit_func:
	WSACleanup () ;
	return	nRetval ;
}

#else

#undef	MYCHAR
#undef	LPMYSTR
#define	MYCHAR			TCHAR
#define	LPMYSTR			LPTSTR

#include "test/listbuf.h"
#include "test/skksvect.h"

int
show_candidates (
	register LPLISTBUFFER		pListBuffer)
{
	LPVECTORINDEX	rpVectorHashTable [VNODEHASHSIZE] ;
	LPVECTORINDEX	pVectorTop	= NULL ;
	int				nVectorLength ;
	LPVECTORINDEX	pVector ;
	MYCHAR			szWord [256] ;
	register int	i ;

	SKKInitVectorHashTable (rpVectorHashTable) ;
	pVectorTop	= SKKMakeSearchVectorIndex (rpVectorHashTable, pListBuffer, &nVectorLength) ;
	pVector		= pVectorTop ;
	_tprintf (TEXT ("vectors= %d\n"), nVectorLength) ;
	for (i = 0 ; pVector != NULL && i < nVectorLength ; i ++) {
		CopyCandidate (szWord, ARRAYSIZE (szWord), pVector->lpBuffer, pVector->iPosition, pVector->iLength) ;
		if (pVector->iLength < ARRAYSIZE (szWord)) {
			szWord [pVector->iLength]	= TEXT ('\0') ;
		} else {
			szWord [ARRAYSIZE (szWord) - 1]	= TEXT ('\0') ;
		}
		_tprintf (TEXT ("(%d): \"%s\"\n"), i, szWord) ;
		pVector	= pVector->lpNext ;
	}
	SKKClearVectorHashTable (rpVectorHashTable) ;
	return	0 ;
}

int
_tmain (void)
{
	register SkkImeUser*	pUser ;
	WSADATA					wsaData ;
	register WORD			wVersion ;
	TCHAR					rszUserName [UNLEN + 1] ;
	ULONG					ulUserNameLen ;
	TCHAR				szBuffer [256] ;
	TVarbuffer			vbufResult ;
	Char				szCKey [256] ;
	register Char*		pCResult ;
	register int		nCResult, nwKey, n, nCKey ;
	register int		nRetval	= EXIT_FAILURE ;
	LPLISTBUFFER		pListBuffer ;

	_tsetlocale (LC_ALL, TEXT ("japanese")) ;

	wVersion	= MAKEWORD (2, 0) ;
	if (WSAStartup (wVersion, &wsaData) != 0)
		return	EXIT_FAILURE ;
	if (LOBYTE (wsaData.wVersion) != 2 || HIBYTE (wsaData.wVersion) < 0) {
		_ftprintf (stderr, TEXT ("WinSock version mismatch. (%x)\n"), wsaData.wVersion) ;
		goto	exit_func ;
	}

	ulUserNameLen	= sizeof (rszUserName) / sizeof (rszUserName [0]) - 1 ;
	if (! GetUserName (rszUserName, &ulUserNameLen))
		goto	exit_func ;
	rszUserName [UNLEN]	= TEXT ('\0') ;

	pUser	= SkkImeUser_Create (rszUserName, ulUserNameLen) ;
	if (pUser == NULL)
		goto	exit_func ;

	TVarbuffer_Initialize (&vbufResult, sizeof (Char)) ;
	while (! feof (stdin)) {
		_tprintf (TEXT ("> ")) ;
		fflush (stdout) ;
		if (_fgetts (szBuffer, ARRAYSIZE (szBuffer), stdin) == NULL)
			break ;
		nwKey	= lstrlen (szBuffer) ;
		while (nwKey > 0 &&
			   (szBuffer [nwKey - 1] == TEXT ('\n') ||
				szBuffer [nwKey - 1] == TEXT ('\r')))
			nwKey	-- ;
		if (nwKey <= 0)
			continue ;
		nCKey	= wstr2internal (szCKey, ARRAYSIZE (szCKey), szBuffer, nwKey) ;
		if (nCKey >= ARRAYSIZE (szCKey)) {
			_tprintf (TEXT ("Too long keyword\n")) ;
			continue ;
		}
		if (SkkImeUser_Search (pUser, szCKey, nCKey, FALSE, &vbufResult)) {
			pCResult	= TVarbuffer_GetBuffer (&vbufResult) ;
			nCResult	= TVarbuffer_GetUsage  (&vbufResult) ;
			n			= internal2wstr (szBuffer, ARRAYSIZE (szBuffer), pCResult, nCResult) ;
			if (n >= ARRAYSIZE (szBuffer)) {
				_tprintf (TEXT ("Result is long(%d/%d) ... \n"), n, nCResult) ;
				szBuffer [ARRAYSIZE (szBuffer) - 1]	= TEXT ('\0') ;
			} else {
				szBuffer [n]	= TEXT ('\0') ;
			}
			_tprintf (TEXT ("200 OK \"%s\"\n"), szBuffer) ;
			pListBuffer	= NULL ;
			pListBuffer	= SKKAddListBuffer (pListBuffer, szBuffer, n, NULL, NULL) ;
			show_candidates (pListBuffer) ;
			SKKFreeListBuffer (&pListBuffer) ;
		} else {
			_tprintf (TEXT ("404 Not found\n")) ;
		}
		TVarbuffer_Clear (&vbufResult) ;
	}
	TVarbuffer_Uninitialize (&vbufResult) ;
	nRetval	= EXIT_SUCCESS ;

  exit_func:
	WSACleanup () ;
	return	nRetval ;
}

#endif

#endif

