#if !defined (immsec_h)
#define	immsec_h

#if defined (__cplusplus)
extern "C" {
#endif

PSECURITY_ATTRIBUTES	CreateSecurityAttributes (void) ;
VOID					FreeSecurityAttributes (PSECURITY_ATTRIBUTES psa) ;

#if defined (__cplusplus)
}
#endif

#endif



