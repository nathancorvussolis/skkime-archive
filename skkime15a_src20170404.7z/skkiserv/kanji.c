#include "local.h"
// #include <assert.h>
// #include "Char.h"
#include "kanji.h"
#include "kstring.h"

/*========================================================================
 *	Macro
 *========================================================================*/
#ifndef MAKE_WORD
#define	MAKE_WORD(wHigh,wLow)	((((WORD)((BYTE)(wHigh))) << 8) | ((WORD)((BYTE)(wLow))))
#endif

/*========================================================================
 *	�L���萔�B
 *========================================================================*/
enum {
	KCHARSET_JISX0201_1976_KATAKANA		= (MAX_CHARSET + 1),

	KCODING_SYSTEM_CHECK_FALSE			= (0),
	KCODING_SYSTEM_CHECK_TRUE			= (1),
	KCODING_SYSTEM_CHECK_TRUE_EXCLUSIVE	= (2),
} ;

enum {
	ISO2022JPSTATE_ESCAPE	= 0,
	ISO2022JPSTATE_G0_94_2_CHARSET1,
	ISO2022JPSTATE_G0_94_2_CHARSET2,
	ISO2022JPSTATE_G0_94_1_CHARSET,
	ISO2022JPSTATE_G2_96_1_CHARSET,
	ISO2022JPSTATE_SINGLE_SHIFT,
} ;

enum {
	CTEXTSTATE_ESCAPE			= 0,
	CTEXTSTATE_GL_94CHARSET,
	CTEXTSTATE_94NCHARSET,
	CTEXTSTATE_GL_94NCHARSET,
	CTEXTSTATE_GR_94NCHARSET,
	CTEXTSTATE_GR_94CHARSET,
	CTEXTSTATE_GR_96CHARSET,
} ;

/*========================================================================*
 *	�^��`�B
 *========================================================================*/
typedef struct {
	int		m_nLineFeed ;		/* 0x0A */
	int		m_nCarriageReturn ;	/* 0x0D */
	int		m_nCRLF ;
	BOOL	m_fPostCR ;
}	NEWLINEINFO ;


/*========================================================================*
 *	�v���g�^�C�v�錾�B
 *========================================================================*/
static	void	guessUnicodeTextNewlineType			(const char*, int, int, int*) ;
static	int		detectKanjiCodingSystem				(const char*, int, int*) ;
static	int		checkShiftJisCodingSystem			(char*, int*, int) ;
static	int		checkEucJpCodingSystem				(char*, int*, int) ;
static	int		checkIso2022Jp2CodingSystem			(char*, int*, int) ;
static	BOOL	checkNewline						(Char, NEWLINEINFO*) ;
static	int		restartEucJpStateMachine			(PKANJISTATEMACHINE) ;
static	int		transferEucJpStateMachine			(PKANJISTATEMACHINE, int, Char*) ;
static	int		rtransferEucJpStateMachine			(PKANJISTATEMACHINE, Char, char*) ;
static	int		restartIso2022JpStateMachine		(PKANJISTATEMACHINE) ;
static	int		transferIso2022JpStateMachine		(PKANJISTATEMACHINE, int, Char*) ;
static	int		iso2022jpEscapeSequenceState0		(PISO2022STATE, int) ;
static	int		iso2022jpEscapeSequenceState1		(PISO2022STATE, int) ;
static	int		iso2022jpEscapeSequenceState2		(PISO2022STATE, int) ;
static	int		iso2022jpEscapeSequenceState3		(PISO2022STATE, int) ;
static	int		iso2022jpEscapeSequenceState4		(PISO2022STATE, int) ;
static	int		iso2022jpEscapeSequenceState5 		(PISO2022STATE, int) ;
static	int		iso2022jpEscapeSequenceDefault		(PISO2022STATE, int) ;
static	int		rtransferIso2022JpStateMachine		(PKANJISTATEMACHINE, Char, char*) ;
static	int		restartShiftJisStateMachine			(PKANJISTATEMACHINE) ;
static	int		transferShiftJisStateMachine		(PKANJISTATEMACHINE, int, Char*) ;
static	int		rtransferShiftJisStateMachine		(PKANJISTATEMACHINE, Char, char*) ;
static	int		restartCompoundTextStateMachine		(PKANJISTATEMACHINE) ;
static	int		transferCompoundTextStateMachine	(PKANJISTATEMACHINE, int, Char*) ;
static	int		ctextEscapeSequenceState0			(PCTEXTSTATE, int) ;
static	int		ctextEscapeSequenceState1			(PCTEXTSTATE, int) ;
static	int		ctextEscapeSequenceState2			(PCTEXTSTATE, int) ;
static	int		ctextEscapeSequenceState3			(PCTEXTSTATE, int) ;
static	int		ctextEscapeSequenceState4			(PCTEXTSTATE, int) ;
static	int		ctextEscapeSequenceState5			(PCTEXTSTATE, int) ;
static	int		ctextEscapeSequenceState6			(PCTEXTSTATE, int) ;
static	int		ctextEscapeSequenceDefault			(PCTEXTSTATE, int) ;
static	int		rtransferCompoundTextStateMachine	(PKANJISTATEMACHINE, Char, char*) ;
static	int		restartUnicodeStateMachine			(PKANJISTATEMACHINE) ;
static	int		transferUnicodeStateMachine			(PKANJISTATEMACHINE, int, Char*) ;
static	int		rtransferUnicodeStateMachine		(PKANJISTATEMACHINE, Char, char*) ;


/*========================================================================
 *	�O���[�o���֐��̒�`�B
 *========================================================================*/
/*
 *	�����R�[�h��͏�ԋ@�B�̏��������s���B
 *[����]
 *	pKSM			��ԑJ�ڋ@�B�B
 *	iCodingSystem	�R�[�f�B���O��@(EUC/SHIFTJIS/...)
 */
int
InitializeKanjiFiniteStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register int				iCodingSystem)
{
	static	int		(*pRestartFuncTbl [])(PKANJISTATEMACHINE pKSM)	= {
		restartEucJpStateMachine,
		restartIso2022JpStateMachine,
		restartShiftJisStateMachine,
		restartCompoundTextStateMachine,
		restartUnicodeStateMachine,
		restartUnicodeStateMachine,
	} ;
	static	int		(*pTransferFuncTbl [])(PKANJISTATEMACHINE pKSM, int iChara, Char* pOutput)	= {
		transferEucJpStateMachine,
		transferIso2022JpStateMachine,
		transferShiftJisStateMachine,
		transferCompoundTextStateMachine,
		transferUnicodeStateMachine,
		transferUnicodeStateMachine,
	} ;
	static	int		(*pRtransferFuncTbl [])(PKANJISTATEMACHINE pKSM, Char cc, char* pOutput)	= {
		rtransferEucJpStateMachine,
		rtransferIso2022JpStateMachine,
		rtransferShiftJisStateMachine,
		rtransferCompoundTextStateMachine,
		rtransferUnicodeStateMachine,
		rtransferUnicodeStateMachine,
	} ;

	assert (pKSM != NULL) ;
	assert (KCODING_SYSTEM_EUCJP <= iCodingSystem && iCodingSystem < MAX_KCODING_SYSTEM) ;

	pKSM->m_pRestartFunc	= pRestartFuncTbl   [iCodingSystem] ;
	pKSM->m_pTransferFunc	= pTransferFuncTbl  [iCodingSystem] ;
	pKSM->m_pRtransferFunc	= pRtransferFuncTbl [iCodingSystem] ;

	if (iCodingSystem == KCODING_SYSTEM_UNICODE || iCodingSystem == KCODING_SYSTEM_UNICODE_BIG) {
		PUNICODESTATE	pState = &pKSM->m_state.m_unicode ;
		pState->m_bBigEndian	= (iCodingSystem == KCODING_SYSTEM_UNICODE_BIG) ;
	}
	return	(pKSM->m_pRestartFunc)(pKSM) ;
}

/*
 *	�����R�[�h��ԑJ�ڋ@�B��������Ԃɖ߂�/�ݒ肷��B
 *[����]
 *	pKSM		��ԑJ�ڋ@�B�B
 */
int
RestartKanjiFiniteStateMachine (
	register PKANJISTATEMACHINE	pKSM)
{
	assert (pKSM != NULL) ;
	assert (pKSM->m_pRestartFunc != NULL) ;
	return	(pKSM->m_pRestartFunc)(pKSM) ;
}

/*
 *	�����R�[�h��ԑJ�ڋ@�B��1�������͂�^���A��ԑJ�ڂ�����B
 *[����]
 *	pKSM		��ԑJ�ڋ@�B�B
 *	iChara		���̓V���{��
 *	pOutput		�o�̓V���{��
 *[�Ԃ�l]
 *	FALSE		�o�̓V���{���͑��݂��Ȃ��B
 *	TRUE		�o�̓V���{�������݂���B
 *	-1			�G���[�����B
 */
int
TransferKanjiFiniteStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register int				iChara,
	register Char*				pOutput)
{
	assert (pKSM != NULL) ;
	assert (pKSM->m_pTransferFunc != NULL) ;
	assert (pOutput != NULL) ;
	return	(pKSM->m_pTransferFunc)(pKSM, iChara, pOutput) ;
}

/*
 *
 */
int
RtransferKanjiFiniteStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register Char				cc,
	register char*				pOutput)
{
	assert (pKSM != NULL) ;
	assert (pKSM->m_pRtransferFunc != NULL) ;
	assert (pOutput != NULL) ;
	return	(pKSM->m_pRtransferFunc)(pKSM, cc, pOutput) ;
}

/*
 *	�t�@�C���̕����������𔻕ʂ��܂��B
 *	�������A���ۂɂ͌���s�\�ȏꍇ�����݂���̂łǂ��ɂ������ɂ��B
 *	�������A���݂̔���͊Ԉ���Ă���c�B
 */
int
DetectKanjiCodingSystem (
	const char*		pBytes,
	int				nCheckBytes,
	int*			pNewlineType)
{
	int		iCodingSystem ;

	iCodingSystem	= detectKanjiCodingSystem (pBytes, nCheckBytes, pNewlineType) ;
	if (iCodingSystem == KCODING_SYSTEM_UNICODE) {
		if (nCheckBytes >= 2 && pBytes [0] == 0xFE && pBytes [1] == 0xFF) {
			iCodingSystem	= KCODING_SYSTEM_UNICODE_BIG ;
		}
		guessUnicodeTextNewlineType (pBytes, nCheckBytes, iCodingSystem, pNewlineType) ;
	}
	return	iCodingSystem ;
}

/*========================================================================*
 *	���̃\�[�X�̒��ł̂ݗ��p�����Ǐ��I�Ȋ֐��B
 *========================================================================*/
void
guessUnicodeTextNewlineType (
	const char*		pBytes,
	int				nCheckBytes,
	int				iCodingSystem,
	int*			pNewlineType)
{
	const char*	ptr			= pBytes ;
	const char*	ptrEnd_1	= ptr + nCheckBytes ;
	WCHAR			wch ;
	NEWLINEINFO		newlineinfo ;
	int				iNewlineType ;

	memset (&newlineinfo, 0, sizeof (newlineinfo)) ;
	if (iCodingSystem == KCODING_SYSTEM_UNICODE_BIG) {
		while (ptr < ptrEnd_1) {
			wch	= MAKE_WORD (*ptr, *(ptr + 1)) ;
			checkNewline (Char_Make (KCHARSET_UNICODE, wch), &newlineinfo) ;
			ptr	+= 2 ;
		}
	} else {
		while (ptr < ptrEnd_1) {
			wch	= MAKE_WORD (*(ptr + 1), *ptr) ;
			checkNewline (Char_Make (KCHARSET_UNICODE, wch), &newlineinfo) ;
			ptr	+= 2 ;
		}
	}
	if (newlineinfo.m_nCRLF > 0) {
		iNewlineType	= KNEWLINE_MSDOS ;
	} else if (newlineinfo.m_nLineFeed > 0) {
		iNewlineType	= KNEWLINE_UNIX ;
	} else if (newlineinfo.m_nCarriageReturn > 0) {
		iNewlineType	= KNEWLINE_MAC ;
	} else {
		iNewlineType	= KNEWLINE_UNKNOWN ;
	}
	if (pNewlineType != NULL)
		*pNewlineType	= iNewlineType ;
	return ;
}

int
detectKanjiCodingSystem (
	const char*		pBytes,
	int				nCheckBytes,
	int*			pNewlineType)
{
	register int	cc ;
	register int	i ;
	BOOL			fProbabilityCodingSystem [MAX_KCODING_SYSTEM] ;
	char			bufShiftJisChar [8] ;
	int				iBufShiftJisUsage ;
	char			bufEucJpChar [8] ;
	int				iBufEucJpUsage ;
	char			bufIso2022JpChar [8] ;
	int				iBufIso2022JpUsage ;
	NEWLINEINFO		newlineinfo ;
	register int	iNewlineType ;

	/*
	 *	�����R�[�h�̗D�揇�ʃe�[�u���B
	 */
	const int				priorityListOfCodingSystem [MAX_KCODING_SYSTEM] = {
		KCODING_SYSTEM_SHIFTJIS,
		KCODING_SYSTEM_EUCJP,
		KCODING_SYSTEM_ISO2022JP2,
	} ;

	assert (pBytes != NULL || nCheckBytes <= 0) ;

	/*
	 *	�ǂ̕����R�[�h���u���l�Ɋm���炵���v�Ƃ������Ƃɂ��܂��B
	 */
	for (i = 0 ; i < MAX_KCODING_SYSTEM ; i ++)
		fProbabilityCodingSystem [i]	= TRUE ;
	fProbabilityCodingSystem [KCODING_SYSTEM_UNICODE_BIG]	= FALSE ;

	newlineinfo.m_nCarriageReturn	= 0 ; 
	newlineinfo.m_nLineFeed			= 0 ; 
	newlineinfo.m_nCRLF				= 0 ;
	newlineinfo.m_fPostCR			= FALSE ;

	/*
	 *	Lead Character �͑��݂��Ȃ��A�Ƃ��Ă����܂��B
	 */
	iBufShiftJisUsage	= 0 ;
	iBufEucJpUsage		= 0 ;
	iBufIso2022JpUsage	= 0 ;

	while (nCheckBytes > 0){
		cc	= *pBytes ;

		/*
		 *	SHIFTJIS �R�[�h�ŕ���������Ă���Ɖ��肵���ꍇ�B
		 */
		if (fProbabilityCodingSystem [KCODING_SYSTEM_SHIFTJIS] &&
			!checkShiftJisCodingSystem (bufShiftJisChar, &iBufShiftJisUsage, cc))
			fProbabilityCodingSystem [KCODING_SYSTEM_SHIFTJIS] = FALSE ;

		/*
		 *	EUC-JP �ŕ���������Ă���Ɖ��肵���ꍇ�B
		 */
		if (fProbabilityCodingSystem [KCODING_SYSTEM_EUCJP] &&
			!checkEucJpCodingSystem (bufEucJpChar, &iBufEucJpUsage, cc))
			fProbabilityCodingSystem [KCODING_SYSTEM_EUCJP]	= FALSE ;

		/*
		 *	JUNET �ŕ���������Ă���Ɖ��肵���ꍇ�B
		 */
		if (fProbabilityCodingSystem [KCODING_SYSTEM_ISO2022JP2]){
			switch (checkIso2022Jp2CodingSystem (bufIso2022JpChar, &iBufIso2022JpUsage, cc)){
			case	KCODING_SYSTEM_CHECK_FALSE:
				/*
				 *	�������g�ł��邱�Ƃ͂Ȃ��B
				 */
				fProbabilityCodingSystem [KCODING_SYSTEM_ISO2022JP2]	= FALSE ;
				break ;
			case	KCODING_SYSTEM_CHECK_TRUE_EXCLUSIVE:
				/*
				 *	���������D��x����̕����������͂��肦�Ȃ��Ƃ���B
				 */
				for (i = 0 ; i < MAX_KCODING_SYSTEM ; i ++){
					if (priorityListOfCodingSystem [i] == KCODING_SYSTEM_ISO2022JP2)
						break ;
					fProbabilityCodingSystem [priorityListOfCodingSystem [i]]	= FALSE ;
				}
				break ;
			case	KCODING_SYSTEM_CHECK_TRUE:
			default:
				break ;
			}
		}

		checkNewline (cc, &newlineinfo) ;

		pBytes		++ ;
		nCheckBytes -- ;
	}

	if (newlineinfo.m_nCRLF > 0) {
		iNewlineType	= KNEWLINE_MSDOS ;
	} else if (newlineinfo.m_nLineFeed > 0) {
		iNewlineType	= KNEWLINE_UNIX ;
	} else if (newlineinfo.m_nCarriageReturn > 0) {
		iNewlineType	= KNEWLINE_MAC ;
	} else {
		iNewlineType	= KNEWLINE_UNKNOWN ;
	}
	if (pNewlineType != NULL)
		*pNewlineType	= iNewlineType ;

	/*
	 *	�����R�[�h�̗D�揇�ʂɉ����� *�炵��* ���������@��Ԃ��B
	 */
	for (i = 0 ; i < MAX_KCODING_SYSTEM ; i ++){
		if (fProbabilityCodingSystem [priorityListOfCodingSystem [i]])
			return	priorityListOfCodingSystem [i] ;
	}

	/*
	 *	�S�ł����ꍇ�ɂ́c�K�� Unicode �ɂȂ�BUnicode �Ƃ���
	 *	�ӂ��킵���Ȃ��R�[�h���Ă����͖̂����Ǝv������B
	 */
	return	KCODING_SYSTEM_UNKNOWN ;
}

/*========================================================================*
 *	���{�� EUC �̏����Ɋւ���֐��̒�`�B
 *========================================================================*/
/*
 *	Extended Unix Code �̏�ԑJ�ڋ@�B������������B
 */
int
restartEucJpStateMachine (
	register PKANJISTATEMACHINE	pKSM)
{
	register PISO2022STATE	pState ;

	assert (pKSM != NULL) ;

	pState	= &pKSM->m_state.m_iso2022 ;
	pState->m_fEscapeSequence	= FALSE ;
	pState->m_iEscapeState		=  0 ;
	pState->m_iLeadChara		= '\0' ;
	pState->m_fSingleShift		= FALSE ;
	pState->m_iCharset [0]		= KCHARSET_ASCII ;
	pState->m_iCharset [1]		= KCHARSET_JISX0208_1983 ;
	pState->m_iCharset [2]		= KCHARSET_JISX0201_1976 ;
	pState->m_iCharset [3]		= KCHARSET_JISX0212_1990 ;
	pState->m_iGL [0]			=  0 ;
	pState->m_iGL [1]			= -1 ;
	pState->m_iGR [0]			=  1 ;
	pState->m_iGR [1]			= -1 ;
	return	TRUE ;
}

/*
 *	Extended Unix Code �̏�ԋ@�B��J�ڂ�����B
 *----
 *	pState		��ԋ@�B�̌���ԁB
 *	iChara		���̓V���{���B
 *	pOutput		�o�̓V���{���B
 */
int
transferEucJpStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register int				iChara,
	register Char*				pOutput)
{
	register PISO2022STATE	pState ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	if (iChara == -1) {
		return	0 ;
	}

	pState	= &pKSM->m_state.m_iso2022 ;

	if (pState->m_iLeadChara){
		switch (pState->m_iCharset [pState->m_iGR [0]]){
		case	KCHARSET_JISX0208_1983:
			if (pState->m_fSingleShift)
				return	-1 ;
			
			*pOutput				= Char_Make (KCHARSET_JISX0208_1983, ((pState->m_iLeadChara << 8) | iChara) & 0x7F7F) ;
			pState->m_iLeadChara	= '\0' ;
			return	1 ;
		case	KCHARSET_JISX0212_1990:
			if (!pState->m_fSingleShift)
				return	-1 ;
			*pOutput				= Char_Make (KCHARSET_JISX0212_1990, ((pState->m_iLeadChara << 8) | iChara) & 0x7F7F) ;
			pState->m_iGR [0]		= 1 ;
			pState->m_iLeadChara	= '\0' ;
			pState->m_fSingleShift	= FALSE ;
			return	1 ;
		default:
			pState->m_iGR [0]		= 1 ;
			pState->m_iLeadChara	= '\0' ;
			pState->m_fSingleShift	= FALSE ;
			return	0 ;
		}
	}
	if (iChara <= (0x80 + 0x20)){
		if (pState->m_fSingleShift || pState->m_iLeadChara){
			pState->m_fSingleShift	= FALSE ;
			pState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		if (iChara < 0x80){
			*pOutput	= Char_MakeAscii ((char)iChara) ;
			return	1 ;
		} else if (iChara == 0x8E){
			pState->m_iGR [0]		= 2 ;
			pState->m_fSingleShift	= TRUE ;
			return	0 ;
		} else if (iChara == 0x8F){
			pState->m_iGR [0]		= 3 ;
			pState->m_fSingleShift	= TRUE ;
			return	0 ;
		} else {
			return	-1 ;
		}
	}
	switch (pState->m_iCharset [pState->m_iGR [0]]){
	case	KCHARSET_JISX0201_1976:
		if (!pState->m_fSingleShift)
			return	-1 ;
		*pOutput				= Char_Make (KCHARSET_JISX0201_1976, iChara) ;
		pState->m_iGR [0]		= 1 ;
		pState->m_fSingleShift	= FALSE ;
		return	1 ;
	case	KCHARSET_JISX0208_1983:
	case	KCHARSET_JISX0212_1990:
		pState->m_iLeadChara	= iChara & 0x00FF ;
		return	0 ;
	default:
		return	-1 ;
	}
}

/*
 *(��)
 *	�t�ϊ��Ƃ������Ƃ� r(everse)transfer �Ƃ������O�ɂ��Ă���B
 */
int
rtransferEucJpStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register Char				cc,
	register char*				pOutput)
{
	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	switch (Char_Charset (cc)) {
	case	KCHARSET_JISX0208_1978:
	/*case	KCHARSET_JISX0208_1983:*/
		*pOutput	++	= (char)((Char_Code (cc) >> 8) | 0x80) ;
		*pOutput	++	= (char)((Char_Code (cc) >> 0) | 0x80) ;
		return	2 ;

	case	KCHARSET_JISX0201_1976:
		if (Char_Code (cc) >= 128) {
			*pOutput	++	= '\x8E' ;
			*pOutput	++	= (char)Char_Code (cc) ;
			return	2 ;
		} else {
			*pOutput	++	= (char)Char_Code (cc) ;
			return	1 ;
		}

	case	KCHARSET_JISX0212_1990:
		*pOutput	++	= '\x8F' ;
		*pOutput	++	= (char)((Char_Code (cc) >> 8) | 0x80) ;
		*pOutput	++	= (char)((Char_Code (cc) >> 0) | 0x80) ;
		return	3 ;

	default:
		if (Char_IsAscii (cc)) {
			*pOutput	++	= (char)Char_Code (cc) ;
			return	1 ;
		}
		break ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (pKSM) ;
}

/*========================================================================
 *	ISO2022-JP-2 �̏����Ɋւ���֐��̒�`�B
 *========================================================================*/
/*
 *	iso-2022-jp-2 ��ԑJ�ڋ@�B������������B
 *-----
 *(���e)
 *	iso-2022-jp-2 �̍s���ł̏�Ԃɂ��킹��B
 *	�m���c�s���ł́A
 *		G0 �����W���́A�A�X�L�[�B
 *		G1 �����W���́AJISX0201-1976 �̉E���ʁB
 *		G2 �����W���́A�s��B
 *		G3 �����W���́A�s��B
 *		GL �� G0 �����W�����w���A
 *		GR �� G1 �����W�����w���B
 *	�ɂȂ锤�B
 *	JISX0201-1976 �̉E���ʂ̈����ɂ��Ă͗ǂ��킩��Ȃ��B
 *	Mule �Ȃǂɐ����������R�[�h�������Ȃ��Ă�������c�Ƃ��Ă����B
 */
int
restartIso2022JpStateMachine (
	register PKANJISTATEMACHINE	pKSM)
{
	register PISO2022STATE	pState ;

	assert (pKSM != NULL) ;

	pState						= &pKSM->m_state.m_iso2022 ;
	pState->m_fEscapeSequence	= FALSE ;
	pState->m_iEscapeState		= 0 ;
	pState->m_iLeadChara		= '\0' ;
	pState->m_fSingleShift		= FALSE ;
	pState->m_iCharset [0]		= KCHARSET_ASCII ;
	pState->m_iCharset [1]		= KCHARSET_JISX0201_1976 ;
	pState->m_iCharset [2]		= KCHARSET_NOTHING ;
	pState->m_iCharset [3]		= KCHARSET_NOTHING ;
	pState->m_iGL [0]			= 0 ;
	pState->m_iGL [1]			= -1 ;
	pState->m_iGR [0]			= 1 ;
	pState->m_iGR [1]			= -1 ;
	return	TRUE ;
}

/*
 *	iso-2022-jp-2 ��ԑJ�ڋ@�B���G�~�����[�g����֐��B
 *-----
 *(����)
 *	lpState		iso-2022-jp-2 ��ԑJ�ڋ@�B�̌��݂̏�ԁB
 *	iChara		���̓A���t�@�x�b�g�B
 *	pOutput		�o�̓A���t�@�x�b�g(�����݂����ꍇ)��Ԃ��o�b�t�@�̃|�C���^�B
 *(�Ԃ�l)
 *	0			�o�̓A���t�@�x�b�g�͑��݂��Ȃ��B
 *	1			�o�̓A���t�@�x�b�g�����݂���B
 *	-1			�G���[�����BMS�����R�[�h�� Unicode (�R�[�h�y�[�W:���{) �ň����Ȃ��������������Ă��G���[�B
 */
int
transferIso2022JpStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register int				iChara,
	register Char*				pOutput)
{
	static	int	(*apIso2022jpEscapeSequenceHandlerTable [])(PISO2022STATE, int)	= {
		iso2022jpEscapeSequenceState0,
		iso2022jpEscapeSequenceState1,
		iso2022jpEscapeSequenceState2,
		iso2022jpEscapeSequenceState3,
		iso2022jpEscapeSequenceState4,
		iso2022jpEscapeSequenceState5,
		iso2022jpEscapeSequenceDefault,
	} ;
	register PISO2022STATE	pState ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	if (iChara == -1)
		return	0 ;

	pState	= &pKSM->m_state.m_iso2022 ;

	/*
	 *	�G�X�P�[�v�V�[�P���X�̉�͒��Ȃ�΁A�ǂ̒����܂œǂݍ��񂾂���
	 *	�����𕪂���B
	 */
	if (pState->m_fEscapeSequence){
		assert (0 <= pState->m_iEscapeState && pState->m_iEscapeState <= 6) ;
		return	(apIso2022jpEscapeSequenceHandlerTable [pState->m_iEscapeState]) (pState, iChara) ;
	}

	/*
	 *	�����łȂ��c���炩�̕�����ǂݍ��񂾏ꍇ�B
	 */
	if (pState->m_fSingleShift){
		pState->m_fSingleShift	= FALSE ;
		pState->m_iLeadChara	= '\0' ;
		pState->m_iGR [0]		= pState->m_iGR [1] ;
		return	-1 ;
	}
	if (iChara <= 0x20){
		if (pState->m_iLeadChara){
			pState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		if (iChara == 0x1b){
			pState->m_fEscapeSequence	= TRUE ;
			pState->m_iEscapeState		= ISO2022JPSTATE_ESCAPE ;
			return	0 ;
		} else {
			*pOutput	= Char_MakeAscii ((char)iChara) ;
			return	1 ;
		}
	} else if (iChara < 0x80){
		int	iCharset ;

		if (pState->m_iGL [0] < 0 || pState->m_iGL [0] > 2)
			return	-1 ;

		switch (pState->m_iCharset [pState->m_iGL [0]]){
		case	KCHARSET_ASCII:
			if (pState->m_iLeadChara){
				pState->m_iLeadChara	= '\0' ;
				return	-1 ;
			}
			*pOutput	= Char_Make (pState->m_iCharset [pState->m_iGL [0]], iChara & 0x00FF) ;
			return	1 ;

		case	KCHARSET_JISX0201_1976_KATAKANA:
			if (pState->m_iLeadChara){
				pState->m_iLeadChara	= '\0' ;
				return	-1 ;
			}
			*pOutput	= Char_Make (KCHARSET_JISX0201_1976, (iChara & 0x00FF) | 0x80) ;
			return	1 ;

		case	KCHARSET_JISX0208_1978:
#if KCHARSET_JISX0208_1978 != KCHARSET_JISX0208_1983
		case	KCHARSET_JISX0208_1983:
#endif
			iCharset	= KCHARSET_JISX0208_1983 ;
			goto	process_2byte_char ;

		case	KCHARSET_JISX0212_1990:
			iCharset	= KCHARSET_JISX0212_1990 ;
			goto	process_2byte_char ;

#if KCHARSET_JISX0208_1978 != KCHARSET_JISX0213_2000_PLANE1
		case	KCHARSET_JISX0213_2000_PLANE1:
			iCharset	= KCHARSET_JISX0213_2000_PLANE1 ;
			goto	process_2byte_char ;
#endif
#if KCHARSET_JISX0213_2000_PLANE2 != KCHARSET_JISX0212_1990
		case	KCHARSET_JISX0213_2000_PLANE2:
			iCharset	= KCHARSET_JISX0213_2000_PLANE2 ;
			goto	process_2byte_char ;
#endif
#if KCHARSET_JISX0213_2004_PLANE1 != KCHARSET_JISX0208_1978
		case	KCHARSET_JISX0213_2004_PLANE1:
			iCharset	= KCHARSET_JISX0213_2004_PLANE1 ;
#endif
process_2byte_char:
			if (pState->m_iLeadChara){
				*pOutput				= Char_Make (iCharset, (pState->m_iLeadChara << 8) | iChara) ;
				pState->m_iLeadChara	= '\0' ;
				return	1 ;
			} else {
				pState->m_iLeadChara	= iChara & 0x00FF ;
				return	0 ;
			}

		default:
			return	-1 ;
		}
	}
	if (pState->m_iGR [0] < 0 || pState->m_iGR [0] > 2)
		return	-1 ;

	switch (pState->m_iCharset [pState->m_iGR [0]]){
	case	KCHARSET_JISX0201_1976:
		if (pState->m_iLeadChara){
			pState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
		*pOutput	= Char_Make (KCHARSET_JISX0201_1976, iChara) ;
		return	1 ;
	default:
		break ;
	}

	return	-1 ;
}

/*
 *	�G�X�P�[�v�V�[�P���X�̏����B
 *(��)
 *	�}�W�b�N�i���o�[�������Ă��Ĕ��ɋC�ɓ���Ȃ��B���Ƃ�����ׂ��B
 *
 *
 *	[���0]	"ESC" ����̏��
 *		+--------------+--------------+---------------------+
 *		| ���̓V���{�� | �J�ڐ�̏�� | ���̑�              |
 *		+--------------+--------------+---------------------+
 *		|     '$'      | ��� 1       |                     |
 *		+--------------+--------------+---------------------+
 *		|     '('      | ��� 3       |                     |
 *		+--------------+--------------+---------------------+
 *		|     'N'      | ��� 5       |                     |
 *		+--------------+--------------+---------------------+
 *		|     '.'      | ��� 4       |                     |
 *		+--------------+--------------+---------------------+
 *		|   ����ȊO   | ��~         | �G���[              |
 *		+--------------+--------------+---------------------+
 *
 *	[���1]	"ESC $"
 *		+--------------+--------------+---------------------+
 *		| ���̓V���{�� | �J�ڐ�̏�� | ���̑�              |
 *		+--------------+--------------+---------------------+
 *		|     '@'      | ��~         | G0 �� JISC6226-1978 |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|     'B'      | ��~         | G0 �� JISX0208-1983 |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|     'A'      | ��~         | G0 �� GB2312-1980   |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|     '('      | ��� 2       |                     |
 *		+--------------+--------------+---------------------+
 *		|   ����ȊO   | ��~         | �G���[              |
 *		+--------------+--------------+---------------------+
 *
 *	[���2]	"ESC $ ("
 *		+--------------+--------------+---------------------+
 *		| ���̓V���{�� | �J�ڐ�̏�� | ���̑�              |
 *		+--------------+--------------+---------------------+
 *		|     '@'      | ��~         | G0 �� JISC6226-1978 |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|     'B'      | ��~         | G0 �� JISX0208-1983 |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|     '('      | ��~         | G0 �� KSC6501-1987  |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|     'D'      | ��~         | G0 �� JISX0212-1990 |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|     'O'      | ��~         | G0 �� JISX0213-2000 |
 *		|              |              | Plane1�����蓖�Ă�B|
 *		+--------------+--------------+---------------------+
 *		|     'P'      | ��~         | G0 �� JISX0213-2000 |
 *		|              |              | Plane2�����蓖�Ă�B|
 *		+--------------+--------------+---------------------+
 *		|     'Q'      | ��~         | G0 �� JISX0213-2004 |
 *		|              |              | Plane1�����蓖�Ă�B|
 *		+--------------+--------------+---------------------+
 *		|   ����ȊO   | ��~         | �G���[              |
 *		+--------------+--------------+---------------------+
 *
 *	[���3]	"ESC ("
 *		+--------------+--------------+---------------------+
 *		| ���̓V���{�� | �J�ڐ�̏�� | ���̑�              |
 *		+--------------+--------------+---------------------+
 *		|     'B'      | ��~         | G0 �� ASCII ������  |
 *		|              |              | ���Ă�B            |
 *		+--------------+--------------+---------------------+
 *		|     'J'      | ��~         | G0 �� JISX0201-1976 |
 *		|              |              | �����蓖�Ă�B      |
 *		+--------------+--------------+---------------------+
 *		|   ����ȊO   | ��~         | �G���[              |
 *		+--------------+--------------+---------------------+
 *
 *	[���4]	"ESC ."
 *		+--------------+--------------+---------------------+
 *		| ���̓V���{�� | �J�ڐ�̏�� | ���̑�              |
 *		+--------------+--------------+---------------------+
 *		|     'A'      | ��~         | G2 �� ISO8859-1 ��  |
 *		|              |              | ���蓖�Ă�B        |
 *		+--------------+--------------+---------------------+
 *		|     'F'      | ��~         | G2 �� ISO8859-7 ��  |
 *		|              |              | ���蓖�Ă�B        |
 *		+--------------+--------------+---------------------+
 *		|   ����ȊO   | ��~         | �G���[              |
 *		+--------------+--------------+---------------------+
 *
 *	[���5]	"ESC N"
 *		�Ԉ���Ă���C������B
 *		Shingle Shift Sequence?
 */
int
iso2022jpEscapeSequenceState0 (
	register PISO2022STATE	pState,
	register int			iChara)
{
	switch (iChara){
	case '$':
		pState->m_iEscapeState	= ISO2022JPSTATE_G0_94_2_CHARSET1 ;
		break ;
	case '(':
		pState->m_iEscapeState	= ISO2022JPSTATE_G0_94_1_CHARSET ;
		break ;
	case 'N':
		/*	shingle-shift-seq */
		pState->m_iEscapeState	= ISO2022JPSTATE_SINGLE_SHIFT ;
		break ;
	case '.':
		/* 96 character sets ESC sequence */
		pState->m_iEscapeState	= ISO2022JPSTATE_G2_96_1_CHARSET ;
		break ;
	default:
		/*	�m��Ȃ��G�X�P�[�v�V�[�P���X�������ꍇ�̏����B*/
		pState->m_iEscapeState		= ISO2022JPSTATE_ESCAPE ;
		pState->m_fEscapeSequence	= FALSE ;
		break ;
	}
	return	FALSE ;
}

/*
 *	�G�X�P�[�v�V�[�P���X�̏����B
 *(��)
 */
int
iso2022jpEscapeSequenceState1 (
	register PISO2022STATE	pState,
	register int			iChara)
{
	switch (iChara){
	case '@':
		/*	G0 �� JISC6226-1978 (94^2�����W�������蓖�Ă�j*/
		pState->m_iCharset [0] = KCHARSET_JISX0208_1978 ;
		break ;
	case 'B':
		/*	G0 �� JISX0208-1983 (94^2�����W�������蓖�Ă�) */
		pState->m_iCharset [0] = KCHARSET_JISX0208_1983 ;
		break ;
	case 'A':
		/*	G0 �� GB2312-1980 (94^2 �����W�������蓖�Ă�) */
		pState->m_iCharset [0] = KCHARSET_GB2312_1980 ;
		break ;
	case '(':
		pState->m_iEscapeState = ISO2022JPSTATE_G0_94_2_CHARSET2 ;
		break ;
	default:
		break ;
	}
	return	iso2022jpEscapeSequenceDefault (pState, iChara) ;
}

/*
 *	�G�X�P�[�v�V�[�P���X�̏����B
 *(��)
 */
int
iso2022jpEscapeSequenceState2 (
	register PISO2022STATE	pState,
	register int			iChara)
{
	switch (iChara){
	case '@':
		/*	G0 �� JISC6226-1978 (94^2�����W��)�����蓖�Ă� */
		pState->m_iCharset [0] = KCHARSET_JISX0208_1978 ;
		break ;
	case 'B':
		/*	G0 �� JISX0208-1983 (94^2�����W��)�����蓖�Ă� */
		pState->m_iCharset [0] = KCHARSET_JISX0208_1983 ;
		break ;
	case '(':
		/*	G0 �� KSC6501-1987 (94^2�����W��)�����蓖�Ă� */
		pState->m_iCharset [0] = KCHARSET_KSC5601_1987 ;
		break ;
	case 'D':
		/*	G0 �� JISX0212-1990 (94^2�����W��)�����蓖�Ă� */
		pState->m_iCharset [0] = KCHARSET_JISX0212_1990 ;
		break ;
	case	'O':
		/*	G0 �� JISX0213-2000 plane1 (94^2�����W��)�����蓖�Ă� */
		pState->m_iCharset [0] = KCHARSET_JISX0213_2000_PLANE1 ;
		break ;
	case	'P':
		/*	G0 �� JISX0213-2000 plane2 (94^2�����W��)�����蓖�Ă� */
		pState->m_iCharset [0] = KCHARSET_JISX0213_2000_PLANE2 ;
		break ;
	case	'Q':
		/*	G0 �� JISX0213-2004 plane1 (94^2�����W��)�����蓖�Ă� */
		pState->m_iCharset [0] = KCHARSET_JISX0213_2004_PLANE1 ;
		break ;
	default:
		break ;
	}
	return	iso2022jpEscapeSequenceDefault (pState, iChara) ;
}

/*
 *	�G�X�P�[�v�V�[�P���X�̏����B
 *(��)
 */
int
iso2022jpEscapeSequenceState3 (
	register PISO2022STATE		pState,
	register int				iChara)
{
	switch (iChara) {
	case	'B':
		/*	G0 �� ASCII (94^1�����W��) �����蓖�Ă�B*/
		pState->m_iCharset [0]	= KCHARSET_ASCII ;
		break ;
	case	'J':
		/*	G0 �� JISX0201-1976(Roman) (94^1�����W��) �����蓖�Ă�B*/
		pState->m_iCharset [0]	= KCHARSET_JISX0201_1976 ;
		break ;
	case	'I':
		/*
		 *	���ɋC�ɓ���Ȃ�����ǂ��A96 �����W���̓��̔�������
		 *	�Ăэ��ށB������āACharset ���ĂƂ��납�猩��Ɖ��Ȃ�
		 *	�Ȃ����H
		 */
		pState->m_iCharset [0]	= KCHARSET_JISX0201_1976_KATAKANA ;
		break ;
	default:
		break ;
	}
	return	iso2022jpEscapeSequenceDefault (pState, iChara) ;
}

/*
 *	�G�X�P�[�v�V�[�P���X�̏����B
 *(��)
 */
int
iso2022jpEscapeSequenceState4 (
	register PISO2022STATE	pState,
	register int			iChara)
{
	if (iChara == 'A'){
		/*	G2 �� ISO8859-1 �����蓖�Ă�B*/
		pState->m_iCharset [2]	= KCHARSET_ISO8859_1 ;
	} else if (iChara == 'F'){
		/*	G2 �� ISO8859-7 �����蓖�Ă�B*/
		pState->m_iCharset [2]	= KCHARSET_ISO8859_7 ;
	}
	return	iso2022jpEscapeSequenceDefault (pState, iChara) ;
}

/*
 *	�G�X�P�[�v�V�[�P���X�̏����B
 *(��)
 */
int	
iso2022jpEscapeSequenceState5 (PISO2022STATE pState, int iChara)
{
	/* Single-Shift-Char */
	pState->m_iLeadChara	= '\0' ;
	pState->m_fSingleShift	= TRUE ;
	pState->m_iGR [1]		= pState->m_iGR [0] ;
	pState->m_iGR [0]		= 2 ;
	return	iso2022jpEscapeSequenceDefault (pState, iChara) ;
}

int
iso2022jpEscapeSequenceDefault (PISO2022STATE pState, int iChara)
{
	pState->m_iEscapeState		= ISO2022JPSTATE_ESCAPE ;
	pState->m_fEscapeSequence	= FALSE ;
	return	FALSE ;

	UNREFERENCED_PARAMETER (iChara) ;
}

/*
 *
 */
int
rtransferIso2022JpStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register Char				cc,
	register char*				pOutput)
{
	register PISO2022STATE	pState ;
	register char*			pOutputTop ;
	register const char*	pEscSeq ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	pState		= &pKSM->m_state.m_iso2022 ;
	pOutputTop	= pOutput ;

	/*
	 *	�O��\������Ă��������������͌��\�d�v�ł���B
	 */
	switch (Char_Charset (cc)) {
#if KCHARSET_JISX0208_1978 != KCHARSET_JISX0213_2004_PLANE1
	case	KCHARSET_JISX0208_1978:
		pEscSeq	= "\033$@" ;
		goto	state_2byte_char ;
#endif
#if KCHARSET_JISX0208_1983 != KCHARSET_JISX0213_2004_PLANE1
	case	KCHARSET_JISX0208_1983:
		pEscSeq	= "\033$B" ;
		goto	state_2byte_char ;
#endif
#if KCHARSET_JISX0212_1990 != KCHARSET_JISX0213_2000_PLANE2
	case	KCHARSET_JISX0212_1990:
		pEscSeq	= "\033$(D" ;
		goto	state_2byte_char ;
#endif
#if KCHARSET_JISX0213_2000_PLANE1 != KCHARSET_JISX0213_2004_PLANE1
	case	KCHARSET_JISX0213_2000_PLANE1:
		pEscSeq	= "\033$(O" ;
		goto	state_2byte_char ;
#endif
	case	KCHARSET_JISX0213_2004_PLANE1:
		pEscSeq	= "\033$(Q" ;
		goto	state_2byte_char ;

	case	KCHARSET_JISX0213_2000_PLANE2:
		pEscSeq	= "\033$(P" ;
		goto	state_2byte_char ;

	case	KCHARSET_GB2312_1980:
		pEscSeq	= "\033$A" ;
		goto	state_2byte_char ;

	case	KCHARSET_KSC5601_1987:
		pEscSeq	= "\033$(C" ;

	state_2byte_char:
		/*
		 *	G0 �����W���������𒲂ׂ�B
		 *	GL <= G0 �͌Œ�B
		 */
		if (pState->m_iCharset [0] != (int)Char_Charset (cc)) {
			while (*pEscSeq)
				*pOutput ++	= *pEscSeq ++ ;
			pState->m_iCharset [0]	= Char_Charset (cc) ;
		}
		*pOutput ++	= (char)(Char_Code (cc) >> 8) ;
		*pOutput ++	= (char)(Char_Code (cc) >> 0) ;
		break ;

	case	KCHARSET_JISX0201_1976:
		/*
		 *	JISX0201-ROMAN �� ASCII �Ƃ͈������Ⴄ�炵���B
		 *	�����ꏊ�ɐU���Ă��܂�Ȃ��悤�ɒ��ӂ���B
		 */
		if (Char_Code (cc) < 0x20) {
			*pOutput ++ = (char)Char_Code (cc) ;
			break ;
		}
		if (Char_Code (cc) < 0x80) {
			if (pState->m_iCharset [0] != KCHARSET_JISX0201_1976) {
				*pOutput ++	= 0x1b ;
				*pOutput ++	= '(' ;
				*pOutput ++	= 'J' ;
				pState->m_iCharset [0] = KCHARSET_JISX0201_1976 ;
			}
		} else {
			if (pState->m_iCharset [0] != KCHARSET_JISX0201_1976_KATAKANA) {
				*pOutput ++	= 0x1b ;
				*pOutput ++	= '(' ;
				*pOutput ++	= 'I' ;
				pState->m_iCharset [0] = KCHARSET_JISX0201_1976_KATAKANA ;
			}
		}
		*pOutput ++ = (char)(Char_Code (cc) & 0x7F) ;
		break ;

	case	KCHARSET_ISO8859_1:
		if (Char_IsAscii (cc))
			goto	state_ascii ;

		pEscSeq	= "\033.A" ;
		goto	state_96charset ;

	case	KCHARSET_ISO8859_7:
		if (Char_IsAscii (cc))
			goto	state_ascii ;

		pEscSeq	= "\033.F" ;

	state_96charset:
		if (pState->m_iCharset [2] != (int)Char_Charset (cc)) {
			while (*pEscSeq)
				*pOutput ++	= *pEscSeq ++ ;
			pState->m_iCharset [2]	= Char_Charset (cc) ;
		}
		*pOutput ++	= 0x1b ;
		*pOutput ++	= 'N' ;
		*pOutput ++ = (char)(Char_Code (cc) & 0x7F) ;
		break ;

	default:
		/*
		 *	ASCII �łȂ���΂����\���͕s�\�B
		 */
		if (!Char_IsAscii (cc)) 
			break ;

	state_ascii:
		if (pState->m_iCharset [0] != KCHARSET_ASCII) {
			*pOutput ++	= 0x1b ;
			*pOutput ++	= '(' ;
			*pOutput ++	= 'B' ;
			pState->m_iCharset [0]	= KCHARSET_ASCII ;
		}
		*pOutput ++ = (char)Char_Code (cc) ;
		break ;
	}
	return	(pOutput - pOutputTop) ;
}

/*========================================================================*
 *	ShiftJis �̏����Ɋւ���֐��̒�`�B
 *========================================================================*/

int
restartShiftJisStateMachine (
	register PKANJISTATEMACHINE	pKSM)
{
	register PSHIFTJISSTATE	pState ;

	assert (pKSM != NULL) ;

	pState					= &pKSM->m_state.m_shiftjis ;
	pState->m_iLeadChara	= '\0' ;
	return	TRUE ;
}

int
transferShiftJisStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register int				iChara,
	register Char*				pOutput)
{
	register PSHIFTJISSTATE	pState ;
	register int			sh, sl, jh, jl ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	if (iChara == -1) {
		return	0 ;
	}

	pState	= &pKSM->m_state.m_shiftjis ;

	if (pState->m_iLeadChara){
		if (IS_SHIFTJIS_2BYTE_CODE2 (iChara)){
			sh	= pState->m_iLeadChara & 0xFF ;
			sl	= iChara & 0xFF ;
			jh	= ((sh - ((sh >= 0xa0)? 0xc1: 0x81)) << 1)+0x21;
			if (sl >= 0x9f) {
				jh	++;
				jl	= sl - 0x7e ;
			} else {
				jl	= sl - ((sl <= 0x7e) ? 0x1f : 0x20) ;
			}
			*pOutput	= Char_Make (KCHARSET_JISX0208_1983, (jh << 8) | jl) ;
			pState->m_iLeadChara	= '\0' ;
			return	1 ;
		} else {
			/*
			 *	��̕����B
			 */
			pState->m_iLeadChara	= '\0' ;
			return	-1 ;
		}
	}

	if (!IS_SHIFTJIS_2BYTE_CODE1 (iChara)){
		if (IS_SHIFTJIS_JISX201_KATAKANA (iChara)){
			/*
			 *	JISX0201-1976�B
			 */
			*pOutput	= Char_Make (KCHARSET_JISX0201_1976, iChara & 0xFF) ;
			return	1 ;
		} else {
			/*
			 *	���̕����� ASCII �������Ǝv���B
			 */
			*pOutput	= Char_MakeAscii ((char)(iChara & 0x007F)) ;
			return	1 ;
		}
	}
	pState->m_iLeadChara	= iChara ;
	return	0 ;
}

/*
 *
 */
int
rtransferShiftJisStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register Char				cc,
	register char*				pOutput)
{
	register int	jh, jl, sh, sl ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	switch (Char_Charset (cc)) {
#if KCHARSET_JISX0208_1978 != KCHARSET_KCHARSET_JISX0213_2004_PLANE1JISX0208_1983
	case	KCHARSET_JISX0208_1978:
#endif
#if KCHARSET_JISX0208_1983 != KCHARSET_JISX0213_2004_PLANE1
	case	KCHARSET_JISX0208_1983:
#endif
#if KCHARSET_JISX0213_2000_PLANE1 != KCHARSET_JISX0213_2004_PLANE1
	case	KCHARSET_JISX0213_2000_PLANE1:
#endif
	case	KCHARSET_JISX0213_2004_PLANE1:
		jh	= (Char_Code (cc) >> 8) & 0x00FF ;
		jl	= (Char_Code (cc) >> 0) & 0x00FF ;
		sh	= ((jh - 0x21) >> 1) + 0x81 ;
		if (sh > 0x9f)
			sh	+= 0x40 ;
		if (jh & 1) {
			sl	= jl + 0x1f ;
			if (jl > 0x5f)
				sl	++ ;
		} else {
			sl	= jl + 0x7e ;
		}
		*pOutput ++	= (char) sh ;
		*pOutput ++	= (char) sl ;
		return	2 ;

	case	KCHARSET_JISX0201_1976:
		*pOutput ++	= (char)Char_Code (cc) ;
		return	1 ;

	default:
		if (Char_IsAscii (cc)) {
			*pOutput ++	= (char)Char_Code (cc) ;
			return	1 ;
		}
		break ;
	}
	return	0 ;
	UNREFERENCED_PARAMETER (pKSM) ;
}

/*========================================================================*
 *	CompoundText �̏����Ɋւ���֐��̒�`�B
 *========================================================================*/
int
restartCompoundTextStateMachine (
	register PKANJISTATEMACHINE	pKSM)
{
	register PCTEXTSTATE	pState ;

	assert (pKSM != NULL) ;
	pState						= &pKSM->m_state.m_ctext ;
	pState->m_fEscapeSequence	= FALSE ;
	pState->m_iEscapeState		= CTEXTSTATE_ESCAPE ;
	pState->m_iLeadChara		= '\0' ;
	pState->m_fSingleShift		= FALSE ;
	pState->m_nGL 				= KCHARSET_ASCII ;
	pState->m_nGR 				= KCHARSET_ISO8859_1 ;
	return	TRUE ;
}

int
transferCompoundTextStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register int				nChara,
	register Char*				pOutput)
{
	static	int (*apCTextEscapeSeqHandlerTable [])(PCTEXTSTATE, int)	= {
		ctextEscapeSequenceState0,
		ctextEscapeSequenceState1,
		ctextEscapeSequenceState2,
		ctextEscapeSequenceState3,
		ctextEscapeSequenceState4,
		ctextEscapeSequenceState5,
		ctextEscapeSequenceState6,
	} ;
	register PCTEXTSTATE	pState ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	if (nChara == -1)
		return	0 ;

	pState	= &pKSM->m_state.m_ctext ;
	if (pState->m_fEscapeSequence) {
		return	(apCTextEscapeSeqHandlerTable [pState->m_iEscapeState])(pState, nChara) ;
	}
	if (nChara <= 0x20) {
		if (nChara == 0x1b) {
			pState->m_fEscapeSequence	= TRUE ;
			pState->m_iEscapeState		= CTEXTSTATE_ESCAPE ;
			return	0 ;
		} else {
			*pOutput	= Char_MakeAscii ((char)nChara) ;
			return	1 ;
		}
	} else if (nChara < 0x80) {
		switch (pState->m_nGL) {
		case	KCHARSET_ASCII:
			if (pState->m_iLeadChara){
				pState->m_iLeadChara	= '\0' ;
				return	-1 ;
			}
			*pOutput	= Char_Make (pState->m_nGL, nChara & 0x00FF) ;
			return	1 ;

		case	KCHARSET_JISX0201_1976_KATAKANA:
			if (pState->m_iLeadChara){
				pState->m_iLeadChara	= '\0' ;
				return	-1 ;
			}
			*pOutput	= Char_Make (KCHARSET_JISX0201_1976, (nChara & 0x00FF) | 0x80) ;
			return	1 ;

#if KCHARSET_JISX0208_1978 != KCHARSET_JISX0208_1983
		case	KCHARSET_JISX0208_1978:
			if (pState->m_iLeadChara){
				*pOutput				= Char_Make (KCHARSET_JISX0208_1983, (pState->m_iLeadChara << 8) | nChara) ;
				pState->m_iLeadChara	= '\0' ;
				return	1 ;
			} else {
				pState->m_iLeadChara	= nChara & 0x00FF ;
				return	0 ;
			}
#endif
		case	KCHARSET_JISX0208_1983:
		case	KCHARSET_JISX0212_1990:
		case	KCHARSET_GB2312_1980:
		case	KCHARSET_KSC5601_1987:
			if (pState->m_iLeadChara){
				*pOutput				= Char_Make (pState->m_nGL, (pState->m_iLeadChara << 8) | nChara) ;
				pState->m_iLeadChara	= '\0' ;
				return	1 ;
			} else {
				pState->m_iLeadChara	= nChara & 0x00FF ;
				return	0 ;
			}
		}
	}
	if (pState->m_iLeadChara){
		pState->m_iLeadChara	= '\0' ;
		return	-1 ;
	}
	*pOutput	= Char_Make (pState->m_nGR, nChara) ;
	return	1 ;
}

int
ctextEscapeSequenceState0 (
	register PCTEXTSTATE	pState,
	register int			nChara)
{
	switch (nChara){
	case	0x24:	/* 94^N charset? */
		pState->m_iEscapeState	= CTEXTSTATE_94NCHARSET ;
		break ;
	case	0x28:	/* 94 charset */
		pState->m_iEscapeState	= CTEXTSTATE_GL_94CHARSET ;
		break ;
	case	0x29:	/* 94 charset */
		pState->m_iEscapeState	= CTEXTSTATE_GR_94CHARSET ;
		break ;
	case	0x2D:	/* 96 charset */
		pState->m_iEscapeState	= CTEXTSTATE_GR_96CHARSET ;
		break ;
	default:
		/*	�m��Ȃ��G�X�P�[�v�V�[�P���X�������ꍇ�̏����B*/
		pState->m_iEscapeState		= CTEXTSTATE_ESCAPE ;
		pState->m_fEscapeSequence	= FALSE ;
		break ;
	}
	return	FALSE ;
}

int
ctextEscapeSequenceState1 (
	register PCTEXTSTATE	pState,
	register int			nChara)
{
	switch (nChara) {
	case	0x42:	/* 7-bit ASCII graphics */
	case	0x4A:	/* Left half of JISX0201-1976 */
		pState->m_nGL	= KCHARSET_ASCII ;
		break ;
	case	0x49:	/* Right half of JISX0201-1976 */
		pState->m_nGL	= KCHARSET_JISX0201_1976_KATAKANA ;
		break ;
	default:
		break ;
	}
	return	ctextEscapeSequenceDefault (pState, nChara) ;
}

int
ctextEscapeSequenceState2 (
	register PCTEXTSTATE	pState,
	register int			nChara)
{
	switch (nChara) {
	case	0x28:
		pState->m_iEscapeState	= CTEXTSTATE_GL_94NCHARSET ;
		break ;
	case	0x29:
		pState->m_iEscapeState	= CTEXTSTATE_GR_94CHARSET ;
		break ;
	default:
		return	ctextEscapeSequenceDefault (pState, nChara) ;
	}
	return	FALSE ;
}

int
ctextEscapeSequenceState3 (
	register PCTEXTSTATE	pState,
	register int			nChara)
{
	static	int		sr94_2_CharsetTbl []	= {
		KCHARSET_GB2312_1980,	KCHARSET_JISX0208_1983,
		KCHARSET_KSC5601_1987,
	} ;
	if (0x41 <= nChara && nChara <= 0x43) 
		pState->m_nGL	= sr94_2_CharsetTbl [nChara - 0x41] ;
	return	ctextEscapeSequenceDefault (pState, nChara) ;
}

int
ctextEscapeSequenceState4 (
	register PCTEXTSTATE	pState,
	register int			nChara)
{
	static	int		sr94_2_CharsetTbl []	= {
		KCHARSET_GB2312_1980,	KCHARSET_JISX0208_1983,
		KCHARSET_KSC5601_1987,
	} ;
	if (0x41 <= nChara && nChara <= 0x43) 
		pState->m_nGR	= sr94_2_CharsetTbl [nChara - 0x41] ;
	return	ctextEscapeSequenceDefault (pState, nChara) ;
}

int
ctextEscapeSequenceState5 (
	register PCTEXTSTATE	pState,
	register int			nChara)
{
	switch (nChara) {
	case	0x42:	/* 7-bit ASCII graphics */
	case	0x4A:	/* Left half of JISX0201-1976 */
		pState->m_nGR	= KCHARSET_ASCII ;
		break ;
	case	0x49:	/* Right half of JISX0201-1976 */
		pState->m_nGR	= KCHARSET_JISX0201_1976_KATAKANA ;
		break ;
	default:
		break ;
	}
	return	ctextEscapeSequenceDefault (pState, nChara) ;
}

int
ctextEscapeSequenceState6 (
	register PCTEXTSTATE	pState,
	register int			nChara)
{
	static	int		sr96CharsetTbl []	= {
		KCHARSET_ISO8859_1,			KCHARSET_ISO8859_2,
		KCHARSET_ISO8859_3,			KCHARSET_ISO8859_4,
		KCHARSET_NOTHING,			KCHARSET_ISO8859_7,
		KCHARSET_ISO8859_6,			KCHARSET_ISO8859_8,
		KCHARSET_NOTHING,			KCHARSET_NOTHING,
		KCHARSET_NOTHING,			KCHARSET_ISO8859_5,
		KCHARSET_ISO8859_9,
	} ;
	if (0x41 <= nChara && nChara <= 0x4D &&
		sr96CharsetTbl [nChara - 0x41] != KCHARSET_NOTHING) {
		pState->m_nGR	= sr96CharsetTbl [nChara - 0x41] ;
	}
	return	ctextEscapeSequenceDefault (pState, nChara) ;
}

int
ctextEscapeSequenceDefault (
	register PCTEXTSTATE 	pState,
	register int 			nChara)
{
	pState->m_iEscapeState		= CTEXTSTATE_ESCAPE ;
	pState->m_fEscapeSequence	= FALSE ;
	return	FALSE ;

	UNREFERENCED_PARAMETER (nChara) ;
}


int
rtransferCompoundTextStateMachine (
	register PKANJISTATEMACHINE	pKSM,
	register Char				cc,
	register char*				pOutput)
{
	register PCTEXTSTATE	pState ;
	register char*			pOutputTop ;
	register const char*	pEscSeq ;
	static   const char*	prEscSeqTbl []	= {
		"\033(B",	"\033-A",	"\033-B",	"\033-C",	"\033-D",
		"\033-L",	"\033-G",	"\033-F",	"\033-H",	"\033-M",
		NULL,		NULL,		NULL,		"\033$(B",	"\033$(B",
		NULL,		"\033$(A",	NULL,		NULL,		NULL,
		NULL,		NULL,		"\033$(C",	NULL,
	} ;
	register int			nCharset ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	pState		= &pKSM->m_state.m_ctext ;
	pOutputTop	= pOutput ;

	/*	�O��\������Ă��������������͌��\�d�v�ł���B*/
	nCharset	= (int)Char_Charset (cc) ;
	switch (nCharset) {
#if KCHARSET_JISX0208_1978 != KCHARSET_JISX0208_1983
	case	KCHARSET_JISX0208_1978:
#endif
	case	KCHARSET_JISX0208_1983:
	case	KCHARSET_GB2312_1980:
	case	KCHARSET_KSC5601_1987:
		if (pState->m_nGL != nCharset) {
			pEscSeq	= prEscSeqTbl [nCharset] ;
			while (*pEscSeq)
				*pOutput ++	= *pEscSeq ++ ;
			pState->m_nGL	= Char_Charset (cc) ;
		}
		*pOutput ++	= (char)(Char_Code (cc) >> 8) ;
		*pOutput ++	= (char)(Char_Code (cc) >> 0) ;
		break ;

	case	KCHARSET_JISX0201_1976:
		if (Char_Code (cc) < 0x20) {
			*pOutput ++ = (char)Char_Code (cc) ;
			break ;
		}
		pEscSeq	= "" ;
		if (Char_Code (cc) < 0x80) {
			if (pState->m_nGL != KCHARSET_JISX0201_1976) {
				pEscSeq	= "\033(J" ;
				pState->m_nGL = KCHARSET_JISX0201_1976 ;
			}
		} else {
			if (pState->m_nGR != KCHARSET_JISX0201_1976_KATAKANA) {
				pEscSeq	= "\033)I" ;
				pState->m_nGR = KCHARSET_JISX0201_1976_KATAKANA ;
			}
		}
		while (*pEscSeq)
			*pOutput ++	= *pEscSeq ++ ;
		*pOutput ++ = (char)Char_Code (cc) ;
		break ;

	case	KCHARSET_ISO8859_1:
	case	KCHARSET_ISO8859_2:
	case	KCHARSET_ISO8859_3:
	case	KCHARSET_ISO8859_4:
	case	KCHARSET_ISO8859_5:
	case	KCHARSET_ISO8859_6:
	case	KCHARSET_ISO8859_7:
	case	KCHARSET_ISO8859_8:
	case	KCHARSET_ISO8859_9:
		if (Char_IsAscii (cc))
			goto	state_ascii ;

		if (pState->m_nGR != (int)Char_Charset (cc)) {
			pEscSeq	= prEscSeqTbl [nCharset] ;
			while (*pEscSeq)
				*pOutput ++	= *pEscSeq ++ ;
			pState->m_nGR	= Char_Charset (cc) ;
		}
		*pOutput ++ = (char)Char_Code (cc) ;
		break ;

	default:
		/*	ASCII �łȂ���΂����\���͕s�\�B*/
		if (!Char_IsAscii (cc)) 
			break ;

	state_ascii:
		if (pState->m_nGL != KCHARSET_ASCII) {
			pEscSeq	= prEscSeqTbl [KCHARSET_ASCII] ;
			while (*pEscSeq)
				*pOutput ++	= *pEscSeq ++ ;
			pState->m_nGL	= KCHARSET_ASCII ;
		}
		*pOutput ++ = (char)Char_Code (cc) ;
		break ;
	}
	return	(pOutput - pOutputTop) ;
}


int
checkShiftJisCodingSystem (
	register char*		pchBuffer,
	register int*		piUsage,
	register int		iChara)
{
	register int		fRetvalue ;
	register int		iUsage ;

	assert (pchBuffer != NULL) ;
	assert (piUsage != NULL) ;
			
	/*
	 *	��芸������ ShiftJIS �炵���Ƃ������Ƃɂ��Ă����܂��B
	 */
	fRetvalue	= TRUE ;

	iUsage		= *piUsage ;
	if (iUsage <= 0){
		if (!IS_SHIFTJIS_2BYTE_CODE1 (iChara)){
			if (!IS_SHIFTJIS_JISX201_KATAKANA (iChara) && iChara >= 0x80)
				fRetvalue	= FALSE ;
		} else {
			*(pchBuffer + iUsage)	= (char) iChara ;
			iUsage	++ ;
		}
	} else {
		if (!IS_SHIFTJIS_2BYTE_CODE2 (iChara))
			fRetvalue	= FALSE ;
		iUsage	= 0 ;
	}
	*piUsage	= iUsage ;

	return	fRetvalue ;
}

int
checkEucJpCodingSystem (
	register char*		pchBuffer, 
	register int*		piUsage,
	register int		iChara)
{
	register int		fRetvalue ;
	register int		iUsage ;

	assert (pchBuffer != NULL) ;
	assert (piUsage != NULL) ;
			
	fRetvalue	= TRUE ;
	iUsage		= *piUsage ;

	if (iUsage <= 0){
		if (iChara == 0x8E ||
			iChara == 0x8F ||
			(0xA1 <= iChara && iChara <= 0xFE)){
			*(pchBuffer + iUsage ++)	= (char) iChara ;
		} else if (iChara >= 0x80){
			fRetvalue	= FALSE ;
		}
	} else {
		if (0xA1 <= iChara && iChara <= 0xFE){
			switch ((unsigned char)*pchBuffer){
			case 0x8F:
				if (iUsage < 2){
					*(pchBuffer + iUsage ++)	= (char) iChara ;
				} else {
					iUsage	= 0 ;
				}
				break ;
			case 0x8E:
			default:
				if (iUsage >= 2)
					fRetvalue	= FALSE ;
				iUsage	= 0 ;
				break ;
			}
		} else {
			fRetvalue	= FALSE ;
			iUsage		= 0 ;
		}
	}
	return	fRetvalue ;
}

int
checkIso2022Jp2CodingSystem (
	register char*	pchBuffer,
	register int*	piUsage,
	register int	iChara)
{
	register int		fRetvalue ;
	register int		i ;
	register int		iUsage ;
	/*
	 *	iso-2022-jp-2 �ɋ�����Ă���G�X�P�[�v�V�[�P���X�B
	 */
	const char*				iso2022jpEscapeSequences [] = {
		"\x1b$@",	"\x1b$B",	"\x1b$(@",	"\x1b$(B",	"\x1b(B",	"\x1b(J",
		"\x1b(I",	"\x1b$A",	"\x1b$(C",	"\x1b$(D",	"\x1b.A",	"\x1b.F",
		NULL,
	} ;

	assert (pchBuffer != NULL) ;
	assert (piUsage != NULL) ;

	fRetvalue	= TRUE ;
	iUsage		= *piUsage ;

	if (iUsage <= 0){
		if (iChara == 0x1b){
			*(pchBuffer + iUsage ++)	= (char) iChara ;
		} else if (iChara >= 0x80){
			fRetvalue	= FALSE ;
		}
	} else {
		/*	������ Escape Sequence �Ȃ̂��H*/
		*(pchBuffer + iUsage ++)	= (char) iChara ;
		for (i = 0 ; iso2022jpEscapeSequences [i] != NULL ; i ++){
			if (strncmp (pchBuffer, iso2022jpEscapeSequences [i], iUsage) == 0){
				if (!(iso2022jpEscapeSequences [i])[iUsage]){
					/*
					 *	�G�X�P�[�v�V�[�P���X�����t�����ꍇ�ɂ͎������
					 *	�D��x�̍��� Coding System �͂��蓾�Ȃ��Ƃ���B
					 */
					fRetvalue	= KCODING_SYSTEM_CHECK_TRUE_EXCLUSIVE ;
					iUsage		= 0 ;
				}
				break ;
			}
		}
		/*
		 *	�m��Ȃ��G�X�P�[�v�V�[�P���X�������ꍇ�ɂ́A
		 *	ISO2022-JP-2 �̉\���͂Ȃ��B
		 */
		if (!iso2022jpEscapeSequences [i]){
			fRetvalue	= FALSE ;
			iUsage		= 0 ;
		}
	}
	*piUsage	= iUsage ;
	return	fRetvalue ;
}

BOOL
checkNewline (
	register Char			cc,
	register NEWLINEINFO*	pNewlineInfo)
{
	assert (pNewlineInfo != NULL) ;

	switch (cc) {
	case	0x0D:
		pNewlineInfo->m_nCarriageReturn	++ ;
		pNewlineInfo->m_fPostCR	= TRUE ;
		break ;
		
	case	0x0A:
		if (pNewlineInfo->m_fPostCR) {
			pNewlineInfo->m_nCRLF	++ ;
		} else {
			pNewlineInfo->m_nLineFeed	++ ;
		}
		pNewlineInfo->m_fPostCR	= FALSE ;
		break ;
		
	default:
		pNewlineInfo->m_fPostCR	= FALSE ;
		break ;
	}
	return	TRUE ;
}

/*========================================================================
 */
int
restartUnicodeStateMachine (
	register PKANJISTATEMACHINE	pKSM)
{
	register PUNICODESTATE	pState ;

	pState	= &pKSM->m_state.m_unicode ;
	pState->m_wFirstChara			= 0 ;
	pState->m_fSecondByte			= FALSE ;
	pState->m_wchSurrogate			= 0 ;
	pState->m_nConvertBufferUsage	= 0 ;
	return	TRUE ;
}

int
transferUnicodeStateMachine (
	PKANJISTATEMACHINE	pKSM,
	int					nChara,
	Char*				pOutput)
{
	register PUNICODESTATE	pState ;
	DWORD					dw ;
	WCHAR					wch ;

	assert (pKSM != NULL) ;
	assert (pOutput != NULL) ;

	pState					= &pKSM->m_state.m_unicode ;

	if (nChara == -1) {
		Char			buf [4] ;
		Char*			pDest		= buf ;
		const Char*		pDestEnd	= buf + ARRAYSIZE (buf) ;
		int				n ;

		if (pState->m_nConvertBufferUsage <= 0)
			return	0 ;

		pState->m_nConvertBufferUsage	= iLookupUnicodeInverseMap (pState->m_bufConvert, pState->m_nConvertBufferUsage, &pDest, pDestEnd, TRUE) ;
		n	= pDest - buf ;
		memcpy (pOutput, buf, n * sizeof (Char)) ;
		return	n ;
	} 
	
	if (! pState->m_fSecondByte) {
		pState->m_wFirstChara	= nChara & 0xFF ;
		pState->m_fSecondByte	= TRUE ;
		return	0 ;
	}
	pState->m_fSecondByte	= FALSE ;

	wch	= (pState->m_bBigEndian)? MAKE_WORD(pState->m_wFirstChara, nChara) : MAKE_WORD(nChara, pState->m_wFirstChara) ;
	if (wch == 0xFFFE || wch == 0xFEFF) {
		return	0 ;
	}

	/*
	if (wbuf [0] < 0x80) {
		*pOutput	= Char_Make (KCHARSET_ASCII, wbuf [0]) ;
		return	TRUE ;
	}
	wbuf [1]	= L'\0' ;
	*/
	/*	Surrogate Pair �̏����B
	 */
	if (pState->m_wchSurrogate != 0) {
		pState->m_wchSurrogate	= 0 ;

		if (IS_SURROGATE_PAIR (pState->m_wchSurrogate, wch)) {
			dw		= SURROGATE_PAIR_TO_U32 (pState->m_wchSurrogate, wch) ;
		} else {
			//	error
			return	0 ;
		}
	} else {
		if (IS_HIGH_SURROGATE (wch)) {
			pState->m_wchSurrogate	= wch ;
			return	FALSE ;
		} else {
			dw		= (DWORD) wch ;
		}
	}

	/*	UNICODE �Q��������P�����Ƃ����ϊ������݂�����̂ŁA�ň��Q�����ڂ܂�
	 *	���Ȃ���΁A�o�͂ł��Ȃ��B���̎��AMAX�Q�������o�͂����\��������B
	 */
	{
		DWORD*			pdwBuffer ;
		const DWORD*	pdwBufferEnd ;
		DWORD*			pdwCurPtr ;
		Char			buf [4] ;
		Char*			pDest		= buf ;
		const Char*		pDestEnd	= buf + ARRAYSIZE (buf) ;
		int				n ;

		pdwBuffer		= pState->m_bufConvert ;
		pdwBufferEnd	= pdwBuffer + ARRAYSIZE (pState->m_bufConvert) ;
		pdwCurPtr		= pdwBuffer + pState->m_nConvertBufferUsage ;
		if (pdwCurPtr >= pdwBufferEnd) {
			DWORD	dwOutput	= *pdwBuffer ;
			(void) iLookupUnicodeInverseMap (&dwOutput, 1, &pDest, pDestEnd, TRUE) ;
			memmove (pdwBuffer, pdwBuffer+1, sizeof (DWORD) * (ARRAYSIZE(pState->m_bufConvert)-1)) ;
			pdwBuffer [ARRAYSIZE(pState->m_bufConvert)-1]	= dw ;
		} else {
			*pdwCurPtr ++	= dw ;
		}

		pState->m_nConvertBufferUsage	= iLookupUnicodeInverseMap (pdwBuffer, pdwCurPtr - pdwBuffer, &pDest, pDestEnd, FALSE) ;
		n	= pDest - buf ;
		memcpy (pOutput, buf, n * sizeof (Char)) ;
		return	n ;
	}
}

/*	unicode �ɒ����B
 */
int
rtransferUnicodeStateMachine (
	PKANJISTATEMACHINE	pKSM,
	Char				cc,
	char*				pOutput)
{
	if (Char_IsAscii (cc)) {
		*pOutput ++	= (char) cc ;
		*pOutput 	= 0x00 ;
		return	2 ;
	} else if (Char_Charset (cc) == KCHARSET_UNICODE) {
		DWORD	dwCode	= Char_Code (cc) ;

		if (dwCode & 0xFF0000) {
			DWORD	dwHighSurrogate, dwLowSurrogate ;

			dwHighSurrogate	= GET_HIGHSURROGATE_FROM_U32 (dwCode) ;
			dwLowSurrogate	= GET_LOWSURROGATE_FROM_U32  (dwCode) ;
			*pOutput ++	= (dwHighSurrogate >> 0) & 0xFF ;
			*pOutput ++	= (dwHighSurrogate >> 8) & 0xFF ;
			*pOutput ++	= (dwLowSurrogate  >> 0) & 0xFF ;
			*pOutput	= (dwLowSurrogate  >> 8) & 0xFF ;
			return	4 ;
		} else {
			*pOutput ++	= (dwCode >> 0) & 0xFF ;
			*pOutput	= (dwCode >> 8) & 0xFF ;
			return	2 ;
		}
	} else {
		WCHAR	buf [128] ;
		LPCWSTR	pSrc ;
		LPCWSTR	pSrcEnd ;
		int		n ;

		n	= internal2wstr (buf, sizeof (buf), &cc, 1) ;
		pSrc	= buf ;
		pSrcEnd	= pSrc + n ;
		while (pSrc < pSrcEnd) {
			*pOutput ++	= (*pSrc >> 0) & 0xFF ;
			*pOutput ++	= (*pSrc >> 8) & 0xFF ;
			pSrc ++ ;
		}
		return	n * 2 ;
	}
	UNREFERENCED_PARAMETER (pKSM) ;
}



