#include "local.h"
// #include <assert.h>
// #include "Char.h"
#include "kstring.h"

/*
#if defined (DEBUG) || defined (_DEBUG)
#define	ASSERT(expr)	assert((expr))
#else
#define	ASSERT(expr)
#endif
*/

#define data_8859_7					((DWORD)KCHARSET_ISO8859_7 << 24)
#define data_8859_6					((DWORD)KCHARSET_ISO8859_6 << 24)
#define data_8859_5					((DWORD)KCHARSET_ISO8859_5 << 24)
#define data_8859_4					((DWORD)KCHARSET_ISO8859_4 << 24)
#define data_8859_3					((DWORD)KCHARSET_ISO8859_3 << 24)
#define data_8859_2					((DWORD)KCHARSET_ISO8859_2 << 24)
#define data_8859_1					((DWORD)KCHARSET_ISO8859_1 << 24)
#define data_JISX0201_1976_STD		((DWORD)KCHARSET_JISX0201_1976 << 24)
#define data_JISX0213_2004_STD_4	((DWORD)KCHARSET_JISX0213_2000_PLANE2 << 24)
#define data_JISX0213_2004_STD_3	((DWORD)KCHARSET_JISX0213_2004_PLANE1 << 24)
#define data_ASCII					((DWORD)KCHARSET_ASCII << 24)

#include "jis_table/inverse_table.h"

static	int	iLookup (
	DWORD*			pdwBuffer,
	int				iBufferUsage,
	Char**			ppDest,
	const Char*		pDestEnd,
	BOOL			bLast)
{
	Char*			pDest	= *ppDest ;
	const DWORD*	pSrc	= pdwBuffer ;
	const DWORD*	pSrcEnd	= pdwBuffer + iBufferUsage ;

	ASSERT (ppDest != NULL) ;
	ASSERT (pdwBuffer != NULL) ;

	while (pSrc < pSrcEnd) {
		int	i ;

		/*	2�����ȏ�̒���(���̂Ƃ���2���������Ȃ���)�� Unicode ����ϊ������
		 *	���̂ɂ��āB
		 */
		for (i = 0 ; i < ARRAYSIZE(multi_table) ; i ++) {
			const DWORD*	pSrc2	= multi_table [i] ;

			if (*pdwBuffer == *pSrc2) {
				const DWORD*	pSrc1		= pSrc ;
				const DWORD*	pSrc2End	= pSrc2 + ARRAYSIZE(multi_table[0])-1 ;

				while (pSrc1 < pSrcEnd && pSrc2 < pSrc2End && *pSrc2 != 0) {
					if (*pSrc1 != *pSrc2)
						break ;
					pSrc1	++ ;
					pSrc2	++ ;
				}
				if (pSrc2 == pSrc2End || *pSrc2 == 0) {
					/* �q�b�g������ԁB*/
					pSrc	= pSrc1 ;
					if (pDest < pDestEnd) 
						*pDest	++	= multi_table [i][ARRAYSIZE(multi_table[0])-1] ;
					goto	next_loop ;
				}
				if (! bLast && pSrc1 == pSrcEnd && pSrc2 > multi_table [i]) {
					/*	���̈ꕶ�����Ȃ��ƌ���ł��Ȃ���Ԃɂ���B
					 *	�䂦�Ɉꕶ���c���ĕԂ��B
					 */
					memmove (pdwBuffer, pSrc, (pSrcEnd - pSrc) * sizeof (DWORD)) ;
					*ppDest	= pDest ;
					return	(pSrcEnd - pSrc) ;
				}
			}
		}
		{
			DWORD	dwUnicode ;
			Char	ch ;

			/*	����1��Unicode����ϊ��������̂ɂ��āB
			 */
			dwUnicode	= *pSrc ++ ;
			if (dwUnicode != 0) {
				const DWORD**	ppTable ;
				const DWORD*	pTable ;
				DWORD	dwPlane, dwCode ;

				dwPlane		= (dwUnicode >> 16) ;
				dwCode		= dwUnicode & 0xFFFF ;
				switch (dwPlane) {
				case	0:
					ppTable	= table_table00 ;
					break ;
				case	2:
					ppTable	= table_table02 ;
					break ;
				default:
					ppTable	= NULL ;
					break ;
				}

				pTable	= (ppTable != NULL)? ppTable [dwCode >> INVERSE_TABLE_SIZE_NBIT] : NULL ;
				ch		= (pTable != NULL)? pTable [dwCode & INVERSE_TABLE_SIZE_MASK] : 0 ;
				if (ch == 0) {
					// �ϊ��ł��Ȃ��ꍇ�ɂ� Unicode �����̂܂܎g�������Ȃ��c
					ch	= (KCHARSET_UNICODE << 24) | (dwUnicode & 0x00FFFFFFUL) ;
				}
			} else {
				ch	= 0 ;
			}
			if (pDest < pDestEnd) 
				*pDest ++	= ch ;
		}
next_loop:
		;
	}
	*ppDest	= pDest ;
	return	0 ;
}

int
iLookupUnicodeInverseMap(
	DWORD*			pdwBuffer,
	int				iBufferUsage,
	Char**			ppDest,
	const Char*		pDestEnd,
	BOOL			bLast)
{
	return	iLookup (pdwBuffer, iBufferUsage, ppDest, pDestEnd, bLast) ;
}

int
wstr2internal (
	Char*		pDest,
	int			nDest,
	LPCWSTR		pSource,
	int			nSource)
{
	LPCWSTR		ptr ;
	LPCWSTR		ptrEnd ;
	LPCWSTR		ptrEnd_1 ;
	DWORD		buf [8] ;
	const Char*	pDestBak	= pDest ;
	const Char*	pDestEnd	= pDest + nDest ;
	int			iLength ;

	ptr			= pSource ;
	ptrEnd		= pSource + nSource ;
	ptrEnd_1	= pSource + nSource - 1 ;
	iLength		= 0 ;
	while (ptr < ptrEnd_1) {
		DWORD	dw ;

		if (IS_SURROGATE_PAIR (*ptr, *(ptr+1))) {
			dw		= SURROGATE_PAIR_TO_U32 (*ptr, *(ptr+1)) ;
			ptr		+= 2 ;
		} else {
			dw		= *ptr ;
			ptr		++ ;
		}
		buf [iLength ++]	= dw ;
		iLength	= iLookup (buf, iLength, &pDest, pDestEnd, FALSE) ;
	}
	if (ptr < ptrEnd) {
		buf [iLength ++]	= *ptr ;
		iLength	= iLookup (buf, iLength, &pDest, pDestEnd, FALSE) ;
	}
	if (iLength > 0) {
		(void) iLookup (buf, iLength, &pDest, pDestEnd, TRUE) ;
	}
	return	pDest - pDestBak ;
}

#ifdef UNIT_TEST
int
_tmain (void)
{
	Char	buf [32] ;
	int		iCount = 0, i, n ;
	LPCWSTR	wstr	= L"����������aiueo" ;

	n	= wstr2internal (buf, ARRAYSIZE (buf), wstr, lstrlenW (wstr)) ;

	for (i = 0 ; i < n ; i ++)
		_ftprintf (stderr, TEXT ("C+%02X:0x%06X\n"), (buf [i] >> 24) & 0xFF, buf [i] & 0x00FFFFFF) ;
	return	0 ;
}
#endif


