/* # skkinput (Simple Kana-Kanji Input)
 *
 * This file is part of skkinput.
 * Copyright (C) 2002
 * Takashi SAKAMOTO (PXG01715@nifty.ne.jp)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with skkinput; see the file COPYING.  If not, write to
 * the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "lmachinep.h"
#include "../cstring.h"
/*
#include "local.h"
//#include <stdio.h>
#include <stddef.h>
#include "lmachinep.h"
#include "cstring.h"
*/

static	void		lispMachine_quitFlagToSignal	(TLispMachine*) ;

static void
lispMachine_quitFlagToSignal (
	register TLispMachine*	pLM)
{
	register TLispManager*		pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*		pEntQuitFlag ;
	register TLispEntity*		pEntInhibitQuit ;
	register TLispEntity*		pEntQuit ;
	register TLispEntity*		pEntT ;
	register TLispEntity*		pEntNil ;
	TLispEntity*	pEntValIQ ;
	TLispEntity*	pEntValQF ;

	/*	quit-flag �� nil �Ȃ牽�����Ȃ��B*/
	pEntQuitFlag	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_QUIT_FLAG) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntQuitFlag,    &pEntValQF)) ||
		TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntValQF)))
		return ;

	/*	inhibit-quit �� non-nil �Ȃ牽�����Ȃ��B*/
	pEntInhibitQuit	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_INHIBIT_QUIT) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntInhibitQuit, &pEntValIQ)) ||
		TFAILED (lispEntity_Nullp (pLispMgr, pEntValIQ)))
		return ;
	
	/*	(signal 'quit nil) �����s����B*/
	pEntQuit		= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_QUIT) ;
	pEntT			= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_T) ;
	pEntNil			= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_NIL) ;
	lispMachineCode_SetSignal (pLM, pEntQuit, pEntT) ;
	lispMachine_SetCurrentSymbolValue (pLM, pEntQuitFlag,    pEntNil) ;
	lispMachine_SetCurrentSymbolValue (pLM, pEntInhibitQuit, pEntNil) ;
	return ;
}


/*
 *	�����������B
 */
BOOL
TLispMachine_Create (
	register TLispManager*	pLispMgr,
	register TLispMachine*	pMacParent,
	register TLispMachine** const ppLM)
{
	register TLispMachine*	pLM ;
	register int			i ;
	TLispEntity*			pEntBuffer ;

	ASSERT (pLispMgr != NULL) ;
	ASSERT (ppLM != NULL) ;

	pLM	= MALLOC (sizeof (TLispMachine)) ;
	if (pLM == NULL)
		return	FALSE ;

	pLM->m_pLispMgr				= pLispMgr ;
	pLM->m_pTarget				= NULL ;
	pLM->m_pEntException		= NULL ;
	pLM->m_pEntExceptionValue	= NULL ;
	pLM->m_pEntSignal			= NULL ;
	pLM->m_pEntSignalValue		= NULL ;
	pLM->m_uStatusFlag			= 0 ;
	if (TFAILED (Vstack_Initialize (&pLM->m_vstLispObj,    sizeof (TLispEntity *))) ||
		TFAILED (Vstack_Initialize (&pLM->m_vstNonLispObj, sizeof (TNotLispValue)))) {
		FREE (pLM) ;
		return	FALSE ;
	}
	for (i = 0 ; i < MAX_LISPOBJ_REGS ; i ++)
		pLM->m_apLREGS [i]	= NULL ;
	for (i = 0 ; i < MAX_NONLISPOBJ_REGS ; i ++)
		pLM->m_alVREGS [i].m_lValue	= 0 ;
	for (i = 0 ; i < ARRAYSIZE (pLM->m_apVariableTable) ; i ++) 
		pLM->m_apVariableTable [i]	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (pLM->m_apFunctionTable) ; i ++) 
		pLM->m_apFunctionTable [i]	= NULL ;
	for (i = 0 ; i < ARRAYSIZE (pLM->m_apPropertyTable) ; i ++) 
		pLM->m_apPropertyTable [i]	= NULL ;
	pLM->m_pState		= NULL ;
	pLM->m_lstBuffer	= NULL ;
	pLM->m_pCurBuffer	= NULL ;
	pLM->m_pEntRegMatch	= NULL ;
	pLM->m_fInteractive	= FALSE ;
	pLM->m_pMacParent	= pMacParent ;
	*ppLM				= pLM ;
	lispMachineCode_ResetSignal    (pLM) ;
	lispMachineCode_ResetException (pLM) ;
	lispMachineCode_ClearQuitFlag  (pLM) ;

	if (TFAILED (lispMgr_CreateBuffer (pLispMgr, &pEntBuffer)) ||
		TFAILED (lispMachine_InsertBuffer (pLM, pEntBuffer)))
		return	FALSE ;
	lispMachineCode_SetCurrentBuffer (pLM, pEntBuffer) ;
	return	TRUE ;
}

BOOL
TLispMachine_Destroy (
	TLispMachine*	pLM)
{
	TLispManager*	pLispMgr ;
	TLispEntity*	pEntity ;
	int				i ;
	static int				srEntityOffsets []	= {
		offsetof (TLispMachine, m_pEntRegMatch),
		offsetof (TLispMachine, m_pEntSignal),
		offsetof (TLispMachine, m_pEntSignalValue),
		offsetof (TLispMachine, m_pEntException),
		offsetof (TLispMachine, m_pEntExceptionValue),
	} ;

	ASSERT (pLM != NULL) ;

	pLispMgr		= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;
	for (i = 0 ; i < MAX_LISPOBJ_REGS ; i ++) {
		if (pLM->m_apLREGS [i] != NULL) { 
			lispEntity_Release (pLispMgr, pLM->m_apLREGS [i]) ;
			pLM->m_apLREGS [i]	= NULL ;
		}
	}
	for (i = 0 ; i < ARRAYSIZE (srEntityOffsets) ; i ++) {
		register TLispEntity**	ppEntity ;
		ppEntity	= (TLispEntity **)((unsigned char*)pLM + srEntityOffsets [i]) ;
		if (*ppEntity != NULL) {
			lispEntity_Release (pLispMgr, *ppEntity) ;
			*ppEntity	= NULL ;
		}
	}
	if (pLM->m_lstBuffer != NULL) {
		register BOOL	fExit	= FALSE ;
		TLispEntity*		pNextBuffer	;

		pEntity	= pLM->m_lstBuffer ;
		do {
			lispBuffer_GetNext (pEntity, &pNextBuffer) ;
			if (pEntity == pNextBuffer)
				fExit	= TRUE ;
#if defined (DEBUG) || 0
			fprintf (stderr, "RemoveBuffer: ") ;
			lispEntity_Print (pLispMgr, pEntity) ;
			fprintf (stderr, "\n") ;
#endif
			lispMachine_RemoveBuffer (pLM, pEntity) ;
			pEntity	= pNextBuffer ;
		}	while (!fExit) ;

		pLM->m_lstBuffer	= NULL ;
	}

	lispBindTable_Destroy (pLispMgr, pLM->m_apVariableTable, SIZE_LISP_BIND_TABLE) ;
	lispBindTable_Destroy (pLispMgr, pLM->m_apFunctionTable, SIZE_LISP_BIND_TABLE) ;
	lispBindTable_Destroy (pLispMgr, pLM->m_apPropertyTable, SIZE_LISP_BIND_TABLE) ;
	Vstack_Uninitialize (&pLM->m_vstLispObj) ;
	Vstack_Uninitialize (&pLM->m_vstNonLispObj) ;
	FREE (pLM) ;
	return	TRUE ;
}

BOOL
TLispMachine_Test (
	register TLispMachine*	pLM,
	register TLispEntity*	pTarget,
	register TVarbuffer*	pvbuf)
{
	register TLMRESULT	(*pState)(TLispMachine*) ;
	register TLMRESULT	res ;
	register int		nMaxTimeout	= 3000 ;
	TLispEntity*		pValue ;
	const Char*			strResult ;
	int					nResult ;
	int				nStackUsage, nCurStackUsage ;

	if (pLM == NULL || pTarget == NULL || pvbuf == NULL)
		return	FALSE ;

	pState				= pLM->m_pState ;
	lispMachineCode_ResetSignal    (pLM) ;
	lispMachineCode_ResetException (pLM) ;
	lispMachineCode_ClearQuitFlag  (pLM) ;
	nStackUsage			= Vstack_GetUsage (&pLM->m_vstNonLispObj) ;
	lispMachineCode_Evaln (pLM, pTarget, &lispMachineState_Done) ;
	do {
		res	= lispMachine_ExecuteLoop (pLM) ; 
	}	while (res == LMR_TICK && nMaxTimeout -- > 0) ;

	nCurStackUsage		= Vstack_GetUsage (&pLM->m_vstNonLispObj) ;
	if (nStackUsage < nCurStackUsage)
		Vstack_DropN (&pLM->m_vstNonLispObj, (nCurStackUsage - nStackUsage)) ;
	pLM->m_pState		= pState ;

	if (res != LMR_DONE) {
		return	FALSE ;
	}

	if (LISPMACHINE_SIGNALP (pLM)) {
		return	FALSE ;
	}

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pValue) ;
	if (TFAILED (lispEntity_GetStringValue (pLM->m_pLispMgr, pValue, &strResult, &nResult))) {
		return	FALSE ;
	}
	if (TFAILED (TVarbuffer_Add (pvbuf, strResult, nResult)))
		return	FALSE ;
	return	TRUE ;
}

BOOL
TLispMachine_TestEx (
	TLispMachine*	pLM,
	TLispEntity*	pTarget,
	TLispEntity**	ppResult)
{
	TLMRESULT	(*pState)(TLispMachine*) ;
	TLMRESULT	res ;
	int		nMaxTimeout	= 3000 ;
	TLispEntity*		pValue ;
	int				nStackUsage, nCurStackUsage ;

	if (pLM == NULL || pTarget == NULL)
		return	FALSE ;

	pState				= pLM->m_pState ;
	lispMachineCode_ResetSignal    (pLM) ;
	lispMachineCode_ResetException (pLM) ;
	lispMachineCode_ClearQuitFlag  (pLM) ;
	nStackUsage			= Vstack_GetUsage (&pLM->m_vstNonLispObj) ;
	lispMachineCode_Evaln (pLM, pTarget, &lispMachineState_Done) ;
	do {
		res	= lispMachine_ExecuteLoop (pLM) ; 
	}	while (res == LMR_TICK && nMaxTimeout -- > 0) ;

	nCurStackUsage		= Vstack_GetUsage (&pLM->m_vstNonLispObj) ;
	if (nStackUsage < nCurStackUsage)
		Vstack_DropN (&pLM->m_vstNonLispObj, (nCurStackUsage - nStackUsage)) ;
	pLM->m_pState		= pState ;

	if (res != LMR_DONE) {
		return	FALSE ;
	}

	if (LISPMACHINE_SIGNALP (pLM)) {
		return	FALSE ;
	}

	lispMachineCode_GetLReg (pLM, LM_LREG_ACC, &pValue) ;
	if (ppResult != NULL)
		*ppResult	= pValue ;
	return	TRUE ;
}

BOOL
TLispMachine_LoadFile (
	TLispMachine*	pLM,
	const Char*		pFileName,
	int				nFileNameLen)
{
	TLMRESULT		(*pState)(TLispMachine*) ;
	TLispManager*	pLispMgr ;
	TLispEntity*	pRetval ;
	TLMRESULT		res ;
	int				nMaxTimeout	= 3000 ;
	int				nStackUsage, nCurStackUsage ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	if (pLM == NULL || pFileName == NULL || nFileNameLen <= 0)
		return	FALSE ;

	if (TFAILED (lispMgr_Load (pLispMgr, pFileName, nFileNameLen, &pRetval))) {
		return	FALSE ;
	}
	lispMachineCode_SetLReg (pLM, LM_LREG_ACC, pRetval) ;
	lispEntity_Release (pLispMgr, pRetval) ;

	pState				= pLM->m_pState ;
	lispMachineCode_ResetSignal    (pLM) ;
	lispMachineCode_ResetException (pLM) ;
	lispMachineCode_ClearQuitFlag  (pLM) ;

	nStackUsage			= Vstack_GetUsage (&pLM->m_vstNonLispObj) ;
	lispMachineCode_PushState (pLM, lispMachineState_Done) ;
	lispMachineCode_SetState  (pLM, lispMachineState_Progn) ;
	do {
		res	= lispMachine_ExecuteLoop (pLM) ; 
	}	while (res == LMR_TICK && nMaxTimeout -- > 0) ;

	nCurStackUsage		= Vstack_GetUsage (&pLM->m_vstNonLispObj) ;
	if (nStackUsage < nCurStackUsage)
		Vstack_DropN (&pLM->m_vstNonLispObj, (nCurStackUsage - nStackUsage)) ;
	pLM->m_pState		= pState ;

	if (res != LMR_DONE) {
		return	FALSE ;
	}
	if (LISPMACHINE_SIGNALP (pLM)) {
		return	FALSE ;
	}
	return	TRUE ;
}

TLispManager*
TLispMachine_GetLispManager (
	register TLispMachine*	pLM)
{
	ASSERT (pLM != NULL) ;
	return	pLM->m_pLispMgr ;
}

#define	MAX_TICK	(6000)

/*
 */
TLMRESULT
lispMachine_ExecuteLoop (
	register TLispMachine*	pLM)
{
	register int		nCount	= MAX_TICK ;
	register TLMRESULT	res ;

	ASSERT (pLM != NULL) ;
	ASSERT (pLM->m_pLispMgr != NULL) ;
	ASSERT (pLM->m_pState   != NULL) ;

	while (nCount -- > 0) {
		res	= (pLM->m_pState) (pLM) ;
		switch (res) {
		case	LMR_RETURN:
			lispMachineCode_PopState (pLM) ;
			/*	fall-down */
		case	LMR_CONTINUE:
			break ;
		case	LMR_TICK:
			nCount	= 0 ;
			break ;
		case	LMR_SUSPEND:
		case	LMR_ERROR:
		case	LMR_DONE:
		default:
			return	res ;
		}
		lispMachine_quitFlagToSignal (pLM) ;
	}
	return	LMR_TICK ;
}

BOOL
lispMachine_CheckArgument (
	register TLispMachine*		pLM,
	register TLispEntity*		pArglist,
	register LMCMDINFO const *	pProcInfo,
	register int*				pnArg)
{
	register BOOL	fRetval ;
	int		nArg ;
	
	if (TFAILED (lispEntity_CountArgument (pLM->m_pLispMgr, pArglist, &nArg)))
		return	FALSE ;
	switch (pProcInfo->m_iArgtype) {
		/*	����A�����̐ݒ肪����ꍇ�B*/
	case	LISPCMD_ARGTYPE_NORMAL:
		fRetval	= (pProcInfo->m_nMinArgNum <= nArg &&
				   nArg <= pProcInfo->m_nMaxArgNum)? TRUE : FALSE ;
		break ;

		/*	����������ꍇ�B*/
	case	LISPCMD_ARGTYPE_LOWER:
		fRetval	= (0 <= nArg && pProcInfo->m_nMinArgNum <= nArg)? TRUE : FALSE ;
		break ;

		/*	���������ꍇ�B*/
	case	LISPCMD_ARGTYPE_UPPER:
		fRetval	= (0 <= nArg && nArg <= pProcInfo->m_nMaxArgNum)? TRUE : FALSE ;
		break ;

		/*	���ɐ����������Ȃ��ꍇ�B*/
	case	LISPCMD_ARGTYPE_NOBOUND:
	case	LISPCMD_ARGTYPE_CDR:
		fRetval	= (nArg >= 0)? TRUE : FALSE ;
		break ;

	case	LISPCMD_ARGTYPE_SPECIAL:
	case	LISPCMD_ARGTYPE_LAMBDA:
	case	LISPCMD_ARGTYPE_MACRO:
		fRetval	= TRUE ;
		break ;

	default:
		fRetval	= FALSE ;
		break ;
	}
	if (pnArg != NULL)
		*pnArg	= nArg ;
	
	return	fRetval ;
}

/*
 *	Buffer �� lispmachine �̊Ǘ����ɒǉ�����BBuffer �͎Q�Ƃ��Ă��� SYMBOL 
 *	���Ȃ��Ă������ GC �ɂ���ď������肵�Ȃ��B�܂�́A�Ǝ��ɎQ�Ƃ����
 *	����킯�Łc�B
 */
BOOL
lispMachine_InsertBuffer (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntBuffer)
{
	ASSERT (pLM != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;

	if (pLM->m_lstBuffer == NULL) {
		pLM->m_lstBuffer	= pEntBuffer ;
		lispBuffer_SetPrevious (pEntBuffer, pEntBuffer) ;
		lispBuffer_SetNext     (pEntBuffer, pEntBuffer) ;
	} else {
		TLispEntity*	pPrevBuffer ;

		lispBuffer_GetPrevious (pLM->m_lstBuffer,	&pPrevBuffer) ;
		ASSERT (pPrevBuffer != NULL) ;
		lispBuffer_SetPrevious (pEntBuffer,			pPrevBuffer) ;
		lispBuffer_SetNext     (pEntBuffer,			pLM->m_lstBuffer) ;
		lispBuffer_SetPrevious (pLM->m_lstBuffer,	pEntBuffer) ;
		lispBuffer_SetNext     (pPrevBuffer,		pEntBuffer) ;
	}
	lispEntity_AddRef (pLM->m_pLispMgr, pEntBuffer) ;
	return	TRUE ;
}	

BOOL
lispMachine_RemoveBuffer (
	register TLispMachine*	pLM,
	register TLispEntity*	pEntBuffer)
{
	TLispEntity*	pPrevBuffer ;
	TLispEntity*	pNextBuffer ;
	ASSERT (pLM != NULL) ;
	ASSERT (pLM->m_lstBuffer != NULL) ;
	ASSERT (pEntBuffer != NULL) ;
	ASSERT (pEntBuffer->m_iType == LISPENTITY_BUFFER) ;

#if defined (DEBUG_LV99)
	if (pLM->m_lstBuffer != NULL) {
		TLispEntity*	pNode	= pLM->m_lstBuffer ;
		do {
			if (pNode == pEntBuffer)
				break ;
			lispBuffer_GetNext (pNode, &pNode) ;
		}	while (pNode != pLM->m_lstBuffer) ;

		ASSERT (pNode == pEntBuffer) ;
	}
#endif
	lispBuffer_GetPrevious (pEntBuffer, &pPrevBuffer) ;
	ASSERT (pPrevBuffer != NULL) ;
	lispBuffer_GetNext     (pEntBuffer, &pNextBuffer) ;
	ASSERT (pNextBuffer != NULL) ;
	if (pPrevBuffer == pEntBuffer && pNextBuffer == pEntBuffer) {
		ASSERT (pLM->m_lstBuffer == pEntBuffer) ;
		pLM->m_lstBuffer	= NULL ;
	} else {
		lispBuffer_SetNext     (pPrevBuffer, pNextBuffer) ;
		lispBuffer_SetPrevious (pNextBuffer, pPrevBuffer) ;
		if (pLM->m_lstBuffer == pEntBuffer) 
			pLM->m_lstBuffer	= pNextBuffer ;
	}
	lispEntity_Release (pLM->m_pLispMgr, pEntBuffer) ;
	return	TRUE ;
}

/*	�o�b�t�@���𗘗p���ăo�b�t�@����������B
 */
BOOL
lispMachine_GetBuffer (
	register TLispMachine*	pLM,
	register const Char*	pStrName,
	register int			nStrName,
	register TLispEntity**	ppEntRetval)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntTopBuffer ;
	register TLispEntity*	pEntBuffer ;
	TLispEntity*	pEntNextBuffer ;
	TLispEntity*	pEntBufName ;
	const Char*		pBufName ;
	int				nBufName ;

	while (pLM != NULL && pLM->m_pCurBuffer != NULL) {
		pEntTopBuffer	= pLM->m_pCurBuffer ;
		pEntBuffer		= pEntTopBuffer ;
		do {
			lispBuffer_GetName (pLispMgr, pEntBuffer, &pEntBufName) ;
#if defined (DEBUG)
			if (pEntBufName != NULL) {
				fprintf (stderr, "lispMachine_GetBuffer () => ") ;
				lispEntity_Print (pLispMgr, pEntBufName) ;
				fprintf (stderr, "\n") ;
			}
#endif
			if (pEntBufName != NULL && 
				TSUCCEEDED (lispEntity_GetStringValue (pLispMgr, pEntBufName, &pBufName, &nBufName)) &&
				nStrName == nBufName &&
				!Cstrncmp (pStrName, pBufName, nStrName)) {
				*ppEntRetval	= pEntBuffer ;
				return	TRUE ;
			}
			lispBuffer_GetNext (pEntBuffer, &pEntNextBuffer) ;
			pEntBuffer	= pEntNextBuffer ;
		}	while (pEntBuffer != pEntTopBuffer) ;

		pLM	= pLM->m_pMacParent ;
	}

	return	FALSE ;
}

/*	�o�b�t�@�Ɋ��蓖�Ă�ꂽ�t�@�C�����𗘗p���ăo�b�t�@����������B
 *(��)
 *	���Ƀo�b�t�@�Ɋ��蓖�Ă�ꂽ�t�@�C�������瑼�̃o�b�t�@�Ɋ��蓖�Ă���ʖڂȂ�
 *	�̐��������ǂ��Ƃ�̂��̖�肪���邪�c�B
 *	���̊֐����̂� buffer-local-variable �ł���Ƃ����(�K�� buffer-local-variable
 *	�Ƃ��đ��݂���) buffer-file-name �̒l�������ɗ^����ꂽ�t�@�C�����Ɣ�r���Ă�
 *	�邾���ł���B
 */
BOOL
lispMachine_GetFileBuffer (
	register TLispMachine*	pLM,
	register const Char*	pFileName,
	register int			nFileName,
	register TLispEntity**	ppEntRetval)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	register TLispEntity*	pEntBufFileName ;
	register TLispEntity*	pEntTopBuffer ;
	register TLispEntity*	pEntBuffer ;
	register BOOL			fRetval ;
	TLispEntity*	pEntNextBuffer ;
	TLispEntity*	pEntValue ;
	const Char*		pBufFileName ;
	int				nBufFileName ;

	pEntBufFileName	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_BUFFER_FILE_NAME) ;
	while (pLM != NULL && pLM->m_pCurBuffer != NULL) {
		pEntTopBuffer	= pLM->m_pCurBuffer ;
		pEntBuffer		= pEntTopBuffer ;
		do {
			fRetval	= lispBuffer_GetSymbolValue (pLispMgr, pEntBuffer, pEntBufFileName, &pEntValue) ;
#if defined (DEBUG)
			if (TSUCCEEDED (fRetval)) {
				lispEntity_Print (pLispMgr, pEntBufFileName) ;
				fprintf (stderr, "(%p) = ", pEntBuffer) ;
				lispEntity_Print (pLispMgr, pEntValue) ;
				fprintf (stderr, "\n") ;
			}
#endif
			if (TSUCCEEDED (fRetval) &&
				TSUCCEEDED (lispEntity_GetStringValue (pLispMgr, pEntValue, &pBufFileName, &nBufFileName)) &&
				nBufFileName == nFileName &&
				!Cstrncmp (pFileName, pBufFileName, nFileName)) {
				*ppEntRetval	= pEntBuffer ;
				return	TRUE ;
			}
			lispBuffer_GetNext (pEntBuffer, &pEntNextBuffer) ;
			pEntBuffer	= pEntNextBuffer ;
		}	while (pEntBuffer != pEntTopBuffer) ;

		pLM	= pLM->m_pMacParent ;
	}

	return	FALSE ;
}

BOOL
lispMachine_GenerateNewBufferName (
	register TLispMachine*	pLM,
	register const Char*	pStrNAME,
	register int			nStrNAME,
	register TLispEntity**	ppEntRetval)
{
	register TLispManager*	pLispMgr	= pLM->m_pLispMgr ;
	TVarbuffer		vbufNAME ;
	TLispEntity*	pEntBuffer ;
	TCHAR			achBuffer [35] ;	/* 35 �� magic-number�B�K���ɂ����B*/
	register Char*	pBufName ;
	register LPTSTR	pSrc ;
	register Char*	pDest ;
	register Char*	pModify ;
	unsigned int	nNumber ;
	register BOOL	fRetval ;

	ASSERT (pLM != NULL) ;
	ASSERT (pStrNAME != NULL && nStrNAME > 0) ;
	ASSERT (ppEntRetval != NULL) ;

	if (TFAILED (TVarbuffer_Initialize (&vbufNAME, sizeof (Char))))
		return	FALSE ;
	if (TFAILED (TVarbuffer_Add (&vbufNAME, pStrNAME, nStrNAME)) ||
		TFAILED (TVarbuffer_Require (&vbufNAME, ARRAYSIZE (achBuffer))))
		return	FALSE ;

	pBufName	= TVarbuffer_GetBuffer (&vbufNAME) ;
	pModify		= pBufName + nStrNAME ;
	nNumber		= 2 ;
	while (TSUCCEEDED (lispMachine_GetBuffer (pLM, pBufName, nStrNAME, &pEntBuffer)) &&
		   nNumber != 0) {
#if __STDC_WANT_SECURE_LIB__
		_sntprintf_s (achBuffer, ARRAYSIZE (achBuffer) - 1, _TRUNCATE, TEXT ("<%d>"), nNumber) ;
#else
		_sntprintf (achBuffer, ARRAYSIZE (achBuffer) - 1, TEXT ("<%d>"), nNumber) ;
#endif
		achBuffer [ARRAYSIZE (achBuffer) - 1]	= TEXT ('\0') ;
		nNumber		++ ;
		pSrc		= achBuffer ;
		pDest		= pModify ;
		while (*pSrc != TEXT ('\0'))
			*pDest ++	= *pSrc ++ ;
		nStrNAME	= pDest - pModify ;
	}
	fRetval	= lispMgr_CreateString (pLispMgr, pBufName, nStrNAME, ppEntRetval) ;
	TVarbuffer_Uninitialize (&vbufNAME) ;
	return	fRetval ;
}

BOOL
lispMachine_keyboardSignal (
	register TLispMachine*	pLM)
{
	register TLispManager*		pLispMgr ;
	register TLispEntity*		pEntQuitFlag ;
	register TLispEntity*		pEntInhibitQuit ;
	register TLispEntity*		pEntT ;
	TLispEntity*	pEntValue ;

	ASSERT (pLM != NULL) ;
	pLispMgr	= pLM->m_pLispMgr ;
	ASSERT (pLispMgr != NULL) ;

	/*	command-loop �ɂ���ꍇ�ɂ́A�������Ȃ��B
	 */
	pEntInhibitQuit	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_INHIBIT_QUIT) ;
	pEntQuitFlag	= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_QUIT_FLAG) ;
	pEntT			= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_T) ;

	lispMachine_SetCurrentSymbolValue (pLM, pEntQuitFlag, pEntT) ;
	if (TFAILED (lispMachine_GetCurrentSymbolValue (pLM, pEntInhibitQuit, &pEntValue)) ||
		TSUCCEEDED (lispEntity_Nullp (pLispMgr, pEntValue))) {
		register TLispEntity*	pEntQuit ;
		pEntQuit		= lispMgr_GetReservedEntity (pLispMgr, LISPMGR_INDEX_QUIT) ;
		lispMachineCode_SetSignal (pLM, pEntQuit, pEntT) ;
	}
	return	TRUE ;
}

/*	for debugging
 */
#if defined (DEBUG)
BOOL
lispMachine_ShowRegisterValue (TLispMachine* pLM)
{
	const char*	apName [MAX_LISPOBJ_REGS]	= {
		"ACC",  "REG1", "REG2", "REG3", "REG4",
		"REG5", "REG6", "REG7", "REG8",
	} ;
	int		i ;
	TLispEntity*	pReg ;
	
	for (i = LM_LREG_ACC ; i < MAX_LISPOBJ_REGS ; i ++) {
		lispMachineCode_GetLReg (pLM, i, &pReg) ;
		fprintf (stderr, "%s = ", apName [i - LM_LREG_ACC]) ;
		if (pReg != NULL) {
			lispEntity_Print (pLM->m_pLispMgr, pReg) ;
		} else {
			fprintf (stderr, "(null)") ;
		}
		fprintf (stderr, "\n") ;
	}
	return	TRUE ;
}
#endif

