#include "local.h"
#include "varbuffer.h"

BOOL
TVarbuffer_Initialize (
	register TVarbuffer*	pVarbuf,
	register int			nWidth)
{
	assert (pVarbuf != NULL) ;
	assert (nWidth  > 0) ;
	
	pVarbuf->m_nSize	= VARBUF_DEFAULTSIZE / nWidth ;
	assert (pVarbuf->m_nSize > 0) ;
	pVarbuf->m_nUsage	= 0 ;
	pVarbuf->m_nWidth	= nWidth ;
	pVarbuf->m_pBuffer	= pVarbuf->m_achInternal ;
	return	TRUE ;
}

BOOL
TVarbuffer_Uninitialize (
	register TVarbuffer*	pVarbuf)
{
	assert (pVarbuf != NULL) ;
	
	if (pVarbuf->m_pBuffer != pVarbuf->m_achInternal) {
		FREE (pVarbuf->m_pBuffer) ;
		pVarbuf->m_pBuffer	= pVarbuf->m_achInternal ;
	}
	pVarbuf->m_nUsage	= 0 ;
	pVarbuf->m_nWidth	= 1 ;
	pVarbuf->m_nSize	= VARBUF_DEFAULTSIZE ;
	return	TRUE ;
}

BOOL
TVarbuffer_Clear (
	register TVarbuffer*	pVarbuf)
{
	assert (pVarbuf != NULL) ;

	pVarbuf->m_nUsage	= 0 ;
	return	TRUE ;
}

BOOL
TVarbuffer_Sub (
	register TVarbuffer*	pVarbuf,
	register int			nData)
{
	assert (pVarbuf != NULL) ;

	pVarbuf->m_nUsage	-= nData ;
	if (pVarbuf->m_nUsage < 0) {
		pVarbuf->m_nUsage	= 0 ;
		return	FALSE ;
	}
	return	TRUE ;
}

BOOL
TVarbuffer_Require (
	register TVarbuffer*	pVarbuf,
	register int			nData)
{
	register int		nUsage, nPos ;

	if (nData < 0) 
		return	TVarbuffer_Sub (pVarbuf, - nData) ;

	nUsage	= pVarbuf->m_nUsage + nData ;
	nPos	= pVarbuf->m_nUsage * pVarbuf->m_nWidth ;

	if (nUsage >= pVarbuf->m_nSize) {
		void*	pNewBuffer ;
		int		nNewSize ;

		nNewSize	= (nUsage + VARBUF_DEFAULTSIZE) ;
		nNewSize	= nNewSize - nNewSize % VARBUF_DEFAULTSIZE ;
		assert (nNewSize >= nUsage) ;

		pNewBuffer	= MALLOC (pVarbuf->m_nWidth * nNewSize) ;
		if (pNewBuffer == NULL) 
			return	FALSE ;

		memcpy (pNewBuffer, pVarbuf->m_pBuffer, nPos) ;
		if (pVarbuf->m_pBuffer != pVarbuf->m_achInternal) 
			FREE (pVarbuf->m_pBuffer) ;
		pVarbuf->m_pBuffer	= pNewBuffer ;
		pVarbuf->m_nSize	= nNewSize ;
	}
	pVarbuf->m_nUsage	= nUsage ;
	return	TRUE ;
}

BOOL
TVarbuffer_Add (
	register TVarbuffer*	pVarbuf,
	register const void*	pData,
	register int			nData)
{
	register int	nPos ;

	assert (pVarbuf != NULL) ;

	nPos	= pVarbuf->m_nUsage * pVarbuf->m_nWidth ;
	if (TFAILED (TVarbuffer_Require (pVarbuf, nData)))
		return	FALSE ;
	memcpy ((unsigned char *)pVarbuf->m_pBuffer + nPos, pData, nData * pVarbuf->m_nWidth) ;
	return	TRUE ;
}

void*
TVarbuffer_GetBuffer (
	register TVarbuffer*	pVarbuf)
{
	assert (pVarbuf != NULL) ;
	
	return	pVarbuf->m_pBuffer ;
}

int
TVarbuffer_GetUsage (
	register TVarbuffer*	pVarbuf)
{
	assert (pVarbuf != NULL) ;

	return	pVarbuf->m_nUsage ;
}


