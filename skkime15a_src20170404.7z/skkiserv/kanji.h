#if !defined (kanji_h)
#define	kanji_h

// #include "local.h"
// #include "charset.h"
// #include "Char.h"

/*========================================================================*
 *	�L���萔�B
 *========================================================================*/
/*
 *	�R�[�f�B���O�V�X�e���B
 */
enum {
	KCODING_SYSTEM_UNKNOWN		= -1,
	KCODING_SYSTEM_EUCJP		= 0,
	KCODING_SYSTEM_ISO2022JP2,
	KCODING_SYSTEM_SHIFTJIS,
	KCODING_SYSTEM_COMPOUND_TEXT,
	KCODING_SYSTEM_UNICODE,
	KCODING_SYSTEM_UNICODE_BIG,
	KCODING_SYSTEM_BINARY,
	MAX_KCODING_SYSTEM,
} ;

/*
 *	���s�R�[�h�B
 */
enum {
	KNEWLINE_UNKNOWN	= -1,
	KNEWLINE_UNIX		= 0,	/* 0x0A */
	KNEWLINE_MSDOS,				/* 0x0D 0x0A */
	KNEWLINE_MAC,				/* 0x0D */
} ;

/*========================================================================*
 *	�}�N���̒�`�B
 *========================================================================*/

#define IS_SHIFTJIS_2BYTE_CODE1(c)		(((((unsigned char)c) >= 0x81 && ((unsigned char)c) <= 0x9F) || (((unsigned char)c) >= 0xE0 && ((unsigned char)c) <= 0xEF))? TRUE : FALSE)
#define IS_SHIFTJIS_2BYTE_CODE2(c)		(((((unsigned char)c) >= 0x40 && ((unsigned char)c) <= 0x7E) || (((unsigned char)c) >= 0x80 && ((unsigned char)c) <= 0xFC))? TRUE : FALSE)
#define IS_SHIFTJIS_JISX201_KATAKANA(c)	((((unsigned char)c) >= 0xA1 && ((unsigned char)c) <= 0xDF)? TRUE : FALSE)

#define	KANJICODE_CODINGSYSTEM(kcode)	((short)(kcode & 0x0000FFFFl))
#define	KANJICODE_NEWLINETYPE(kcode)	(((short)(kcode >> 16) & 0x0000FFFFl))
#define	KANJICODE_MAKE(iCS,iNT)			((KANJICODE)((((unsigned long)iCS) & 0x0000FFFFl) | ((((unsigned long)iNT) & 0x0000FFFFl) << 16)))


/*========================================================================*
 *	�^��`�B
 *========================================================================*/

/*========================================================================*
 *	�\���́B
 *========================================================================*/
/*
 *	ISO2022 ��͏�ԑJ�ڋ@�B�́u��ԁv
 */
typedef struct tagISO2022STATE {
	BOOL		m_fEscapeSequence ;
	int			m_iEscapeState ;
	BOOL		m_fSingleShift ;
	int			m_iLeadChara ;
	int			m_iCharset [4] ;
	int			m_iGL [2] ;
	int			m_iGR [2] ;
}	ISO2022STATE, *PISO2022STATE ;

/*
 *	Microsoft �����R�[�h��͏�ԋ@�B�́u��ԁv
 */
typedef struct tagSHIFTJISSTATE {
	int			m_iLeadChara ;
}	SHIFTJISSTATE, *PSHIFTJISSTATE ;

/*
 *	CompoundText ��͏�ԑJ�ڋ@�B�́u��ԁv
 */
typedef struct tagCTEXTSTATE {
	BOOL		m_fEscapeSequence ;
	int			m_iEscapeState ;
	BOOL		m_fSingleShift ;
	int			m_iLeadChara ;
	int			m_nGL ;
	int			m_nGR ;
}	CTEXTSTATE, *PCTEXTSTATE ;

typedef struct tagUNICODESTATE {
	WCHAR		m_wFirstChara ;
	BOOL		m_fSecondByte ;
	BOOL		m_bBigEndian ;
	WCHAR		m_wchSurrogate ;
	DWORD		m_bufConvert [8] ;
	int			m_nConvertBufferUsage ;
}	UNICODESTATE, *PUNICODESTATE ;

/*
 *	�����R�[�h��͂̂��߂̏�ԑJ�ڋ@�B�B
 */
typedef struct tagKANJISTATEMACHINE {
	/*	�ď������B���s�ɂ���čď�������������ꍇ�Ɏg���B*/
	int			(*m_pRestartFunc)(struct tagKANJISTATEMACHINE*) ;

	/*	�����R�[�h�ɕϊ����鎞�Ɏg���u�J�ځv�֐��B*/
	int			(*m_pTransferFunc)(struct tagKANJISTATEMACHINE*, int iChara, Char* pOutput) ;

	/*	�����R�[�h����ϊ����鎞�Ɏg���u�J�ځv�֐��B*/
	int			(*m_pRtransferFunc)(struct tagKANJISTATEMACHINE*, Char cc, char* pOutput) ;

	/*	����ԁB��Ƃ��ē����R�[�h�ɕϊ����鎞�ɗp����B*/
	union {
		ISO2022STATE	m_iso2022 ;
		SHIFTJISSTATE	m_shiftjis ;
		CTEXTSTATE		m_ctext ;
		UNICODESTATE	m_unicode ;
	}	m_state ;

}	KANJISTATEMACHINE, *PKANJISTATEMACHINE ;

/*========================================================================*
 *	�v���g�^�C�v�錾�B
 *========================================================================*/
int		DetectKanjiCodingSystem				(const char* pBytes, int nBytes, int* pNewlineType) ;
int		InitializeKanjiFiniteStateMachine 	(PKANJISTATEMACHINE pKSM, int iCodingSystem) ;
int		RestartKanjiFiniteStateMachine		(PKANJISTATEMACHINE pKSM) ;
int		TransferKanjiFiniteStateMachine		(PKANJISTATEMACHINE pKSM, int iChara, Char* pOutput) ;
int		RtransferKanjiFiniteStateMachine	(PKANJISTATEMACHINE pKSM, Char cc, char* pOutput) ;

#endif

