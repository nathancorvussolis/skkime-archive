#pragma once

class	CSkkImeTextService ;
class	CImeDoc ;
class	CSkkImeToolTipUIElement ;
struct	TEXTREGION ;

class CSkkImeCandidateListUIElement :
#if defined (__ITfCandidateListUIElementBehavior_INTERFACE_DEFINED__)
	public ITfCandidateListUIElementBehavior
#else
	public IUnknown
#endif
{
public:
	enum {
		MAX_ANNOTATION				= 32,
		NBUFFER_ANNOTATION_TEXT		= 1024,
		UI_CURSORWIDTH				= 2,
		SKKIME_DEFAULT_HOVERTIME	= 400,
		TIMEEV_SHOWANNOTATION		= 0,
		DEFAULT_MINIBUF_CHARWIDTH	= 80,
	} ;
	struct MYTOOLTIPINFO {
		int			m_nCount ;
		POINT		m_ptLastPos ;
		RECT		m_rrcHitArea	[MAX_ANNOTATION] ;
		int			m_rnOffsets		[MAX_ANNOTATION] ;
		int			m_rnLengths		[MAX_ANNOTATION] ;
		WCHAR		m_bufText		[NBUFFER_ANNOTATION_TEXT] ;
	} ;
public:
	CSkkImeCandidateListUIElement (CSkkImeTextService* pTSF) ;
	virtual				~CSkkImeCandidateListUIElement () ;

	/* IUnknown Interface */
	STDMETHODIMP			QueryInterface (REFIID riid, void **ppvObj) ;
	STDMETHODIMP_(ULONG)	AddRef () ;
	STDMETHODIMP_(ULONG)	Release () ;

	/* ITfUIElement Interface */
	STDMETHODIMP		GetDescription (BSTR* pbstrDescription) ;
	STDMETHODIMP		GetGUID (GUID* pguid) ;
	STDMETHODIMP		Show (BOOL bShow) ;
	STDMETHODIMP		IsShown (BOOL* pbShow) ;

	/* ITfCandidateListUIElement Interface */
	STDMETHODIMP		GetUpdatedFlags (DWORD* pdwFlags) ;
	STDMETHODIMP		GetDocumentMgr (ITfDocumentMgr** ppdim) ;
	STDMETHODIMP		GetCount (UINT* puCount) ;
	STDMETHODIMP		GetSelection (UINT* puIndex) ;
	STDMETHODIMP		GetString (UINT uIndex, BSTR* pstr) ;
	STDMETHODIMP		GetPageIndex (UINT* pIndex, UINT uSize, UINT* puPageCnt) ;
	STDMETHODIMP		SetPageIndex (UINT* pIndex, UINT uPageCnt) ;
	STDMETHODIMP		GetCurrentPage (UINT* pPage) ;

	/* ITfCandidateListUIElementBehavior Interface */
	STDMETHODIMP		SetSelection (UINT nIndex) ;
	STDMETHODIMP		Finalize () ;
	STDMETHODIMP		Abort () ;

public:
#ifndef WINDOW_CLASS_AUX
	static BOOL			_Register();
#endif	// WINDOW_CLASS_AUX
	BOOL				_Init (BOOL bConsole) ;
	void				_Uninit () ;

	BOOL				_Open (DWORD dwId, BOOL bShow) ;
	BOOL				_Update () ;
	void				_Close () ;
	BOOL				_IsActivep (BOOL* pbShown) const ;
	DWORD				_GetUIElementId () const ;

	BOOL				_MoveWindow (int iX, int iY, int iWidth, int iHeight) ;
	void				_Popup (BOOL bFocus) ;

private:
	HRESULT				_GetDocumentMgr (ITfDocumentMgr** ppdim) ;
	HRESULT				_GetDocument (CImeDoc** ppDoc) ;
	HRESULT				_GetToolTipUI (CSkkImeToolTipUIElement** ppToolTipUI) ;
	HRESULT				_SendCommandToContext (WPARAM wParam, LPARAM lParam) ;
	void				_UpdateText () ;
	int					_GetMinibufferText (LPWSTR pwText, int iTextSize, const IMECANDIDATES* pMyCand) ;

	LRESULT				_OnSetCursor	(WPARAM wParam, LPARAM lParam) ;
	LRESULT				_OnMouseMove	(WPARAM wParam, LPARAM lParam) ;
	LRESULT				_OnButtonDown	(UINT uMessage, WPARAM wParam, LPARAM lParam) ;
	LRESULT				_OnButtonUp		(UINT uMessage, WPARAM wParam, LPARAM lParam) ;
	LRESULT				_OnTimer		(WPARAM wParam, LPARAM lParam) ;
	void				_OnPaint		(HDC hDC) ;

	BOOL				_PaintCandidateList (HDC hDC, LPRECT prcDraw) ;
	BOOL				_PaintCodeList (HDC hDC, LPRECT prcDraw) ;
	BOOL				_PaintMinibufferText (HDC hDC, LPRECT prcDraw) ;
	BOOL				_GetTextPosition (const POINT* pPoint, int* piCursorPos) ;
	void				_HitTestAnnotation (const POINT* pPT) ;
	BOOL				_ConfigureAnnotation (const TEXTREGION* pRegion, int iNumRegion) ;
	BOOL				_HandleMinibufferContextMenu () ;
	int					_PopupMinibufferContextMenu () ;
	HMENU				_CreateClipboardMenu () ;
	void				_HideToolTip () ;
	HFONT				_GetDefaultFont (HDC hDC) ;

private:
	static	LRESULT	CALLBACK	_WndProc (HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;

private:
	CSkkImeTextService*	m_pTSF ;
	DWORD				m_dwElementId ;
	BOOL				m_bOpen ;
	BOOL				m_bShow ;
	BOOL				m_bConsole ;

	HWND				m_hWnd ;
	RECT				m_rcWnd ;

	int					m_iStyle ;
	DWORD				m_dwUpdateFlags ;

	WCHAR				m_wszText [1024] ;
	int					m_nTextLen ;
	TEXTREGION*			m_bufAnnotation ;
	int					m_iNumAnnotation ;
	MYTOOLTIPINFO		m_ToolTipInfo ;

	/* for minibuffer text */
	BOOL				m_bButtonPressed ;
	int					m_iCursorPos ;
	int					m_bRegionSelected ;
	int					m_iRegionStart, m_iRegionEnd ;

	LONG				m_cRef ;
	static	const GUID	m_guidSkkImeCandidateListUIElement ;
	static	TCHAR		m_szWndClass [] ;
} ;
