#pragma once

#include "IME/dchar.h"

class	CSkkImeTextService ;

class	CSkkImeToolTipUIElement :
#if defined (__ITfToolTipUIElement_INTERFACE_DEFINED__)
	public ITfToolTipUIElement
#else
	public IUnknown
#endif
{
private:
	enum {
		MAX_TOOLTIPTEXT	= 256,
	} ;
public:
	/* IUnknown Interface */
	STDMETHODIMP			QueryInterface (REFIID riid, void **ppvObj) ;
	STDMETHODIMP_(ULONG)	AddRef () ;
	STDMETHODIMP_(ULONG)	Release () ;

	/* ITfUIElement Interface */
	STDMETHODIMP		GetDescription (BSTR* pbstrDescription) ;
	STDMETHODIMP		GetGUID (GUID* pguid) ;
	STDMETHODIMP		Show (BOOL bShow) ;
	STDMETHODIMP		IsShown (BOOL* pbShow) ;

	/* ITfToolTipUIElement Interface */
	STDMETHODIMP		GetString (BSTR* pstr) ;

public:
	CSkkImeToolTipUIElement (CSkkImeTextService* pTSF) ;
	virtual				~CSkkImeToolTipUIElement () ;

#ifndef WINDOW_CLASS_AUX
	static BOOL			_Register();
#endif	// WINDOW_CLASS_AUX
	BOOL				_Init (BOOL bConsole) ;
	void				_Uninit () ;

	void				_SetText (LPCDSTR dstrText) ;
	void				_SetText (LPCDSTR dstrText, UINT nTextLen) ;
	void				_SetText (LPCWSTR wstrText) ;
	void				_SetText (LPCWSTR wstrText, UINT nTextLen) ;
	void				_Clear () ;

	BOOL				_Open (DWORD dwId, BOOL bShow) ;
	void				_Update () ;
	void				_Close () ;
	BOOL				_IsActivep (BOOL* pbShown) const ;
	DWORD				_GetUIElementId () const ;

	BOOL				_MoveWindow (int iX, int iY, int iWidth, int iHeight) ;
	void				_Popup (BOOL bFocus) ;

private:
	BOOL				_AdjustWindowRect (RECT* prcDest) ;

private:
	static	LRESULT	CALLBACK	_WndProc (HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam) ;
	void				_OnPaint (HDC hDC) ;
	LRESULT				_OnSetCursor (WPARAM wParam, LPARAM lParam) ;

private:
	CSkkImeTextService*	m_pTSF ;
	WCHAR				m_wszText [MAX_TOOLTIPTEXT] ;
	BOOL				m_bShown ;
	DWORD				m_dwElementId ;
	BOOL				m_bOpen ;
	HWND				m_hWnd ;
	POINT				m_ptWnd ;
	BOOL				m_bConsole ;
	POINT				m_ptLastCursor ;

	LONG				m_cRef ;
	static	const GUID	m_guidSkkImeToolTipUIElement ;
	static	LPCWSTR		m_wstrDescription ;
	static	TCHAR		m_szClassName [] ;
} ;
