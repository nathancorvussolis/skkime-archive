#pragma once

class	CTPacket ;

class CTCommunicateSession {
protected:
	static WCHAR					m_rszSkkImePipeName [] ;
	
public:
	CTCommunicateSession () {
		return ;
	}
	virtual			~CTCommunicateSession () {
		return ;
	}

	static BOOL		bInitPipeName () ;

protected:
	static	HANDLE	_hOpenServer () ;
	static	BOOL	_bSend (HANDLE hPipe, CTPacket* pPacket) ;
	static	BOOL	_bRecv (HANDLE hPipe, CTPacket* pPacket) ;
	static	BOOL	_bStartServer () ;
} ;

