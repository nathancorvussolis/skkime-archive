// #if !defined (UNITTEST)
#include "globals.h"
// #else
// #include "StdAfx.h"
// #endif

#include "ImeDoc.h"
#include "ImeBuffer.h"
// #include "TMarker.h"	// ImeBuffer.h �ƘA��
// #include "../../common/keymap.h"	// ImeBuffer.h �ƘA��

/*======================================================================== mouse-drag-region
 */
int
CImeDoc::LM_bMouseDragRegion	(
	CImeDoc*		pThis)
{
	CImeBuffer*	pCurBuffer ;
	CTMarker*		pmkPoint ;
	CTMarker*		pmkEnd ;
	CTMarker*		pmkTop ;
	CTMarker*		pmkMark	= NULL ;
	const struct TMSG*	pEvent ;
	int					nPosition, nLastCmd, nBufferTop, nBufferEnd, nPoint ;

	/*	signal ���ݒ肳��Ă���Γ��삵�Ȃ��B
	 *	�Ƃ������A���̔���𖈉�Ă΂ꂽ���ɏ����̂͂Ȃ��c�B
	 */
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;

	/*	WM_LM_COMMAND only.
	 */
	pEvent	= pThis->pGetLastCommandEvent () ;
	if (pEvent == NULL || pEvent->m_nMessage != WM_LM_COMMAND) {
		pThis->vSetSignalError () ;
		goto	exit_func ;
	}
	nPosition	= (int)pEvent->m_lParam ;

	/*	�擪�́u�I�v��ǂݔ�΂��Ȃ��Ƃ����Ȃ��̂ŁB�ށA�ł��A���ꂾ�Ɓc�߂�Ȃ��ꏊ��
	 *	�������獢��Ȃ����ȁH
	if (pThis->bRecursiveEditp () && pThis->bHaveMessagep ())
		nPosition	-- ;
	 */

	/*	�J�[�\�����w�肳�ꂽ�ʒu�ւƈړ�������B*/
	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= pmkTop->iGetPosition () ;
	} else {
		nBufferTop	= 0 ;
	}
	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_MARK, &pmkMark))
		pmkMark	= NULL ;

	/* buffertop ���O�ɖ߂邱�Ƃ͂ł��Ȃ��B*/
	nBufferEnd		= pmkEnd->iGetPosition () ;
	if (nPosition > nBufferEnd) 
		nPosition	= nBufferEnd ;
	if (nPosition < nBufferTop)
		nPosition	= nBufferTop ;

	nPoint			= pmkPoint->iGetPosition () ;
	pmkPoint->bForward (nPosition - nPoint) ;

	nLastCmd	= pThis->iGetLastCommand () ;
	if (nLastCmd != NFUNC_MOUSE_DRAG_REGION || pmkMark == NULL) {
		/*	�}�[�N���J�[�\���ʒu�ɐݒ肷��B*/
		if (! pCurBuffer->bSetMarker (&pmkMark, CImeBuffer::MARKER_MARK, pmkPoint)) {
			pThis->vSetSignalError () ;
			goto	exit_func ;
		}
	}
exit_func:
	pThis->vSetRegNil (LMREGARG_RETVAL) ;
	return	LMR_RETURN ;
}

/*======================================================================== mouse-drag-region-end
 */
int
CImeDoc::LM_bMouseDragRegionEnd (
	CImeDoc*		pThis)
{
	if (! pThis->bCall (CImeDoc::LM_bMouseDragRegion, CImeDoc::LM_bMouseDragRegionEnd_Exit))
		return	LMR_ERROR ;
	return	LMR_CONTINUE ;
}

int
CImeDoc::LM_bMouseDragRegionEnd_Exit (
	CImeDoc*		pThis)
{
	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pThis->bSetThisCommand (NFUNC_MOUSE_DRAG_REGION_END) ;
	return	LMR_RETURN ;
}

/*======================================================================== mouse-copy
 */
int
CImeDoc::LM_bMouseCopy (
	CImeDoc*		pThis)
{
	pThis->vJump (CImeDoc::LM_bKillRingSave) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== mouse-cut
 */
int
CImeDoc::LM_bMouseCut (
	CImeDoc*		pThis)
{
	pThis->vJump (CImeDoc::LM_bKillRegion) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== mouse-paste
 */
int
CImeDoc::LM_bMousePaste (
	CImeDoc*		pThis)
{
	pThis->vJump (CImeDoc::LM_bYank) ;
	return	LMR_CONTINUE ;
}

/*======================================================================== mouse-delete
 */
int	
CImeDoc::LM_bMouseDelete (
	CImeDoc*		pThis)
{
	/*	Delete-Region �̂݁BCutBuffer �ɂ͐G��Ȃ��B
	 */
	CImeBuffer*	pCurBuffer ;
	CTMarker*	pmkPoint ;
	CTMarker*	pmkEnd ;
	CTMarker*	pmkTop ;
	CTMarker*	pmkMark ;
	int			nStart, nEnd, nBufferTop, nBufferEnd ;

	if (pThis->bSignalp ())
		return	LMR_RETURN ;

	pCurBuffer	= pThis->pGetCurrentBuffer () ;
	if (pCurBuffer == NULL)
		return	LMR_ERROR ;	

	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_POINT,     &pmkPoint) || pmkPoint == NULL ||
		! pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFEREND, &pmkEnd)   || pmkEnd   == NULL) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pCurBuffer->bGetMarker (CImeBuffer::MARKER_MARK, &pmkMark)   || pmkMark   == NULL) {
		pThis->bSetMessage (L"The mark is not set now") ;
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (pCurBuffer->bGetMarker (CImeBuffer::MARKER_BUFFERTOP, &pmkTop) && pmkTop != NULL) {
		nBufferTop	= pmkTop->iGetPosition () ;
	} else {
		nBufferTop	= 0 ;
	}

	nStart	= pmkPoint->iGetPosition () ;
	nEnd	= pmkMark->iGetPosition () ;
	if (nStart > nEnd) {
		int	nTmp ;
		nTmp	= nStart ;
		nStart	= nEnd ;
		nEnd	= nTmp ;
	}
	if (nStart == nEnd) 
		goto	exit_func ;

	nBufferEnd	= pmkEnd->iGetPosition () ;
	if (nStart < nBufferTop || nEnd > nBufferEnd) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
	if (! pCurBuffer->bDeleteRegion (nStart, nEnd)) {
		pThis->vSetSignalError () ;
		return	LMR_RETURN ;
	}
exit_func:
	pThis->bSetThisCommand (NFUNC_KILL_REGION) ;
	return	LMR_RETURN ;
}
