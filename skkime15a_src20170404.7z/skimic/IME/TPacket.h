#pragma once

#include "TProtocol.h"
#include "dchar.h"

#define	MSGBUFSIZE		(2048)

#define	PACKET_ALIGN	(4)
#define	PADNUM(x)		((PACKET_ALIGN - ((x) & (PACKET_ALIGN - 1))) & (PACKET_ALIGN - 1))

class CTPacket {
private:
	BYTE			m_rbyBuffer [MSGBUFSIZE] ;
	int				m_nUsage ;

public:
	CTPacket () : m_nUsage (0) {
		return ;
	}
	virtual			~CTPacket () {
		return ;
	}
	virtual	BOOL	bSetHeader (int nMajor, int nMinor) {
		m_rbyBuffer [0]	= (BYTE) nMajor ;
		m_rbyBuffer [1]	= (BYTE) nMinor ;
		m_rbyBuffer [2]	= 0 ;
		m_rbyBuffer [3]	= 0 ;
		m_nUsage			= 4 ;
		return	TRUE ;
	}
	virtual BOOL	bAddPad () {
		register int	nPad	= PADNUM (m_nUsage) ;

		if ((m_nUsage + nPad) > MSGBUFSIZE)
			return	FALSE ;
		m_nUsage	+= nPad ;
		return	TRUE ;
	}
	virtual	BOOL	bAddCard32 (DWORD dwData) {
		register LPBYTE	pDest ;

		if ((m_nUsage + 4) > MSGBUFSIZE)
			return	FALSE ;

		pDest		= m_rbyBuffer + m_nUsage ;
		*pDest ++	= (BYTE)(dwData >>  0) ;	m_nUsage ++ ;
		*pDest ++	= (BYTE)(dwData >>  8) ;	m_nUsage ++ ;
		*pDest ++	= (BYTE)(dwData >> 16) ;	m_nUsage ++ ;
		*pDest ++	= (BYTE)(dwData >> 24) ;	m_nUsage ++ ;
		return	TRUE ;
	}
	virtual BOOL	bAddCard16 (WORD woData) {
		register LPBYTE	pDest ;

		if ((m_nUsage + 2) > MSGBUFSIZE)
			return	FALSE ;

		pDest		= m_rbyBuffer + m_nUsage ;
		*pDest ++	= (BYTE)(woData >>  0) ;	m_nUsage ++ ;
		*pDest ++	= (BYTE)(woData >>  8) ;	m_nUsage ++ ;
		return	TRUE ;
	}
	virtual BOOL	bAddCard8 (BYTE byData) {
		if ((m_nUsage + 1) > MSGBUFSIZE)
			return	FALSE ;

		m_rbyBuffer [m_nUsage ++]	= byData ;
		return	TRUE ;
	}
	virtual	BOOL	bSetLength () {
		register LPBYTE	pDest ;

		if (m_nUsage < SKKISERV_PROTO_HEADER_SIZE || m_nUsage > MSGBUFSIZE)
			return	FALSE ;

		pDest		= m_rbyBuffer + 2 ;
		*pDest ++	= (BYTE) (m_nUsage >> 0) ;
		*pDest ++	= (BYTE) (m_nUsage >> 8) ;
		return	TRUE ;
	}
	virtual BOOL	bSetCard16 (int nPosition, WORD woValue) {
		register LPBYTE	pDest ;

		if (nPosition < 0 || (nPosition + 2) > m_nUsage)
			return	FALSE ;

		pDest		= m_rbyBuffer + nPosition ;
		*pDest ++	= (BYTE) (woValue >> 0) ;
		*pDest ++	= (BYTE) (woValue >> 8) ;
		return	TRUE ;
	}
	virtual BOOL	bGetCard16 (int nPosition, WORD* pwResult) {
		register WORD		woValue ;
		register const BYTE*	pSrc ;

		ASSERT (pwResult != NULL) ;

		if (nPosition < 0 || (nPosition + 2) > m_nUsage)
			return	FALSE ;

		pSrc		= m_rbyBuffer + nPosition ;
		woValue		= (WORD) *pSrc ++ ;
		woValue		= woValue | ((WORD)*pSrc << 8) ;
		*pwResult	= woValue ;
		return	TRUE ;
	}

	virtual BOOL	bAddString (LPCWSTR wstring, int nstring) {
		register int	nPos, nPad, nStringByteLen, nResultLength ;

		nPos			= m_nUsage ;
		nStringByteLen	= nstring * sizeof (WCHAR) ;
		nPad			= PADNUM(nPos + 2 + nStringByteLen) ;
		nResultLength	= nPos + 2 + nStringByteLen + nPad ;
		if (nResultLength > MSGBUFSIZE)
			return	FALSE ;
		
		if (nstring > 0)
			memcpy (m_rbyBuffer + nPos + 2, wstring, nStringByteLen) ;
		
		m_nUsage			= nResultLength ;
		return	bSetCard16 (nPos, (WORD)nstring) ;
	}

	virtual BOOL	bAddDString (LPCDSTR dstring, int ndstring) {
		int		nPos, nPad, nStringByteLen, nResultLength ;
		int		nstring ;

		nstring			= dcstowcs (NULL, 0, dstring, ndstring) ;
		nPos			= m_nUsage ;
		nStringByteLen	= nstring * sizeof (WCHAR) ;
		nPad			= PADNUM(nPos + 2 + nStringByteLen) ;
		nResultLength	= nPos + 2 + nStringByteLen + nPad ;
		if (nResultLength > MSGBUFSIZE)
			return	FALSE ;
		
		if (nstring > 0) {
			(void) dcstowcs ((LPWSTR)(m_rbyBuffer + nPos + 2), nstring, dstring, ndstring) ;
//			memcpy (m_rbyBuffer + nPos + 2, wstring, nStringByteLen) ;
		}
		m_nUsage			= nResultLength ;
		return	bSetCard16 (nPos, (WORD)nstring) ;
	}

	virtual	BOOL	bAddByte (const BYTE* pByte, int nByte) {
		ASSERT (nByte >= 0) ;
		if ((m_nUsage + nByte) > MSGBUFSIZE)
			return	FALSE ;
		memcpy (m_rbyBuffer + m_nUsage, pByte, nByte) ;
		m_nUsage	+= nByte ;
		return	TRUE ;
	}
	virtual	BOOL	bGetHeader (int* pnMajor, int* pnMinor, int* pnSize) {
		if (m_nUsage < SKKISERV_PROTO_HEADER_SIZE)
			return	FALSE ;
		if (pnMajor != NULL)
			*pnMajor	= m_rbyBuffer [0] ;
		if (pnMinor != NULL)
			*pnMinor	= m_rbyBuffer [1] ;
		if (pnSize != NULL) {
			register WORD		woSIZE ;
			woSIZE		= m_rbyBuffer [3] ;
			woSIZE		= (woSIZE << 8) | (WORD)m_rbyBuffer [2] ;
			*pnSize		= (int) woSIZE ;
		}
		return	TRUE ;
	}
	virtual const BYTE*		pGetBody () const {
		return	m_rbyBuffer + SKKISERV_PROTO_HEADER_SIZE ;
	}
	virtual LPBYTE		pGetData () {
		return	m_rbyBuffer ;
	}
	virtual const BYTE*		pGetData () const {
		return	m_rbyBuffer ;
	}
	virtual int			iGetDataSize () const {
		return	m_nUsage ;
	}
	virtual void		vSetDataSize (int nSize) {
		m_nUsage	= nSize ;
		return ;
	}
	virtual void	vClear () {
		m_nUsage		= 0 ;
		return ;
	}
} ;

