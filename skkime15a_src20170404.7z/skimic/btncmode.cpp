/*	langbar.cpp
 *
 *	Language bar ui code
 */
#include "globals.h"
#include "skimic.h"
#include "resource.h"
#include "skkimmgr.h"
#include "IME/ImeDoc.h"

#define LANGBAR_ITEM_DESC	L"���̓��[�h"	// max 32 chars! �ށA�ő�32�����������B

typedef struct {
	const WCHAR*	pchDesc ;
	int				nMode ;
	void			(*pfnHandler)(CSkkImeTextService* _this) ;
}	TSFLBMENUINFO ;

static	const TSFLBMENUINFO	c_rgMenuItems []	= {
	{ L"�Ђ炪��",			IMECMODE_HIRAGANA,		CSkkImeTextService::_Menu_ToHiragana },
	{ L"�S�p�J�^�J�i",		IMECMODE_KATAKANA,		CSkkImeTextService::_Menu_ToZenkata },
	{ L"�S�p�p��",			IMECMODE_ZENKAKU,		CSkkImeTextService::_Menu_ToZenei },
	{ L"���p�J�^�J�i",		IMECMODE_HANKANA,		CSkkImeTextService::_Menu_ToJisx0201 },
	{ L"���p�p��(���p�J�i)",IMECMODE_HANKANA_ROMAN,	CSkkImeTextService::_Menu_ToJisx0201Roman },
	{ L"���p�p��",			IMECMODE_ASCII,			CSkkImeTextService::_Menu_ToHanei },
	{ L"���ړ���",			IMECMODE_OFF,			CSkkImeTextService::_Menu_ToDirect },
	{ NULL,					-1,						NULL },
	{ L"�L�����Z��",		-1,						NULL }
} ;

/*	IME ���̓��̓��[�h�{�^��(����o�[)�� GUID
 */
static	const GUID	c_guidImeItemButtonCMode	= {
	0x5d97b50b, 0x1b86, 0x4577, { 0xaa, 0xf6, 0xbd, 0x76, 0xe5, 0xb, 0x18, 0xec }
} ;

#ifdef MICROSOFT_METRO
/// ���̓C���W�P�[�^��GUID
const GUID GUID_LBI_INPUTMODE =
	{ 0x2C77A81E, 0x41CC, 0x4178, { 0xA3, 0xA7, 0x5F, 0x8A, 0x98, 0x75, 0x68, 0xE6 } };
#endif	// MICROSOFT_METRO

#define	SKKIME_LANGBARITEMSINK_COOKIE	0x0fab0fab

enum {
	MENU_ITEM_INDEX_CANCEL		= -1,
	MENU_ITEM_INDEX_HIRAGANA	= 0,
	MENU_ITEM_INDEX_KATAKANA,
	MENU_ITEM_INDEX_ZENEI,
	MENU_ITEM_INDEX_HANKANA,
	MENU_ITEM_INDEX_HANKANA_ROMAN,
	MENU_ITEM_INDEX_ASCII,
	MENU_ITEM_INDEX_DIRECT
} ;

/*	CLangBarItemCModeButton: Conversion Mode Language Bar Item Button
 */
class	CLangBarItemCModeButton : public ITfLangBarItemButton,
								  public ITfSource
{
public:
	CLangBarItemCModeButton(CSkkImeTextService* pSkkIme, REFGUID rguid);
	~CLangBarItemCModeButton () ;

	// IUnknown
	STDMETHODIMP	QueryInterface (REFIID riid, void **ppvObj) ;
	STDMETHODIMP_(ULONG)	AddRef (void) ;
	STDMETHODIMP_(ULONG)	Release (void) ;

	// ITfLangBarItem
	STDMETHODIMP	GetInfo (TF_LANGBARITEMINFO *pInfo) ;
	STDMETHODIMP	GetStatus (DWORD *pdwStatus) ;
	STDMETHODIMP	Show (BOOL fShow) ;
	STDMETHODIMP	GetTooltipString (BSTR *pbstrToolTip) ;

	// ITfLangBarItemButton
	STDMETHODIMP	OnClick (TfLBIClick click, POINT pt, const RECT *prcArea) ;
	STDMETHODIMP	InitMenu (ITfMenu *pMenu) ;
	STDMETHODIMP	OnMenuSelect (UINT wID) ;
	STDMETHODIMP	GetIcon (HICON *phIcon) ;
	STDMETHODIMP	GetText (BSTR *pbstrText) ;

	// ITfSource
	STDMETHODIMP	AdviseSink(REFIID riid, IUnknown *punk, DWORD *pdwCookie);
	STDMETHODIMP	UnadviseSink(DWORD dwCookie);

	STDMETHODIMP	Update () ;

private:
	CSkkImeTextService*		m_pSkkIme ;
	ITfLangBarItemSink*		_pLangBarItemSink ;
	TF_LANGBARITEMINFO		_tfLangBarItemInfo ;
	LONG					_cRef ;
} ;

/// �R���X�g���N�^
CLangBarItemCModeButton::CLangBarItemCModeButton(CSkkImeTextService* pSkkIme, REFGUID rguid)
{
	DllAddRef () ;

	_tfLangBarItemInfo.clsidService	= c_clsidSkkImeTextService ;
	_tfLangBarItemInfo.guidItem		= rguid;
	_tfLangBarItemInfo.dwStyle		= TF_LBI_STYLE_BTN_MENU | TF_LBI_STYLE_SHOWNINTRAY;		// TF_LBI_STYLE_TEXTCOLORICON
	_tfLangBarItemInfo.ulSort		= 0;
	SafeStringCopy (_tfLangBarItemInfo.szDescription, MYARRAYSIZE (_tfLangBarItemInfo.szDescription), LANGBAR_ITEM_DESC) ;

	m_pSkkIme			= pSkkIme ;
	m_pSkkIme->AddRef () ;
	_pLangBarItemSink	= NULL ;
	_cRef				= 1 ;
	return ;
}

CLangBarItemCModeButton::~CLangBarItemCModeButton ()
{
	DllRelease () ;
	m_pSkkIme->Release () ;
	return ;
}

STDAPI
CLangBarItemCModeButton::QueryInterface (
	REFIID			riid,
	void**			ppvObj)
{
	if (ppvObj == NULL)
		return	E_INVALIDARG ;

	*ppvObj	= NULL ;
	if (IsEqualIID (riid, IID_IUnknown) ||
		IsEqualIID (riid, IID_ITfLangBarItem) ||
		IsEqualIID (riid, IID_ITfLangBarItemButton)) {
		*ppvObj	= (ITfLangBarItemButton *)this ;
	} else if (IsEqualIID (riid, IID_ITfSource)) {
		*ppvObj	= (ITfSource *)this ;
	}
	if (*ppvObj != NULL) {
		AddRef () ;
		return	S_OK ;
	}
	return	E_NOINTERFACE ;
}

STDAPI_(ULONG)
CLangBarItemCModeButton::AddRef ()
{
	return	++ _cRef ;
}

STDAPI_(ULONG)
CLangBarItemCModeButton::Release ()
{
	LONG	cr	= -- _cRef ;

	if (_cRef == 0) {
		delete	this ;
	}
	return	cr ;
}

STDAPI
CLangBarItemCModeButton::GetInfo (
	TF_LANGBARITEMINFO*		pInfo)
{
	if (pInfo == NULL)
		return	E_INVALIDARG ;

	*pInfo	= _tfLangBarItemInfo ;
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::Show (
	BOOL					fShow)
{
	return	E_NOTIMPL ;
	UNREFERENCED_PARAMETER (fShow) ;
}

STDAPI
CLangBarItemCModeButton::GetStatus (
	DWORD*					pdwStatus)
{
	if (pdwStatus == NULL)
		return	E_INVALIDARG ;

	DEBUGPRINTF ((TEXT ("CLangBarItemCModeButton::GetStatus ()\n"))) ;
	*pdwStatus	= (m_pSkkIme->_IsKeyboardDisabled ())? TF_LBI_STATUS_DISABLED : 0 ;
	return	S_OK ;
}

/*	Button �� tooltip ��Ԃ��B�Ԃ��l�� SysAllocString �ɂ����
 *	�m�ۂ����̈�ɏ������K�v������B����� SysFreeString ��
 *	��̂́A�Ăяo�������̐ӔC�ł���B
 */
STDAPI
CLangBarItemCModeButton::GetTooltipString (
	BSTR*					pbstrToolTip)
{
	if (pbstrToolTip == NULL)
		return	E_INVALIDARG ;

	*pbstrToolTip	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrToolTip == NULL)? E_OUTOFMEMORY : S_OK ;
}

/*	ITfLangBarItemButton::OnClick
 *
 *	���� method �̓��[�U������o�[�� TF_LBI_STYLE_BTN_BUTTON �܂�
 *	�� TF_LBI_STYLE_BTN_TOGGLE �X�^�C���������Ă���{�^���̏�Ń}
 *	�E�X���N���b�N�������ɌĂяo�����B
 *	�����{�^�� item �� TF_LBI_STYLE_BTN_BUTTON �X�^�C���������Ȃ�
 *	�̂Ȃ�A���� method �g���Ȃ��B
 *(*)
 *	���̏󋵂ł͓��ɉ�������K�v�͂Ȃ��̂ŁAS_OK �𑦕Ԃ��B
 */
STDAPI
CLangBarItemCModeButton::OnClick (
	TfLBIClick				click,
	POINT					pt,
	const RECT*				prcArea)
{
	return	S_OK ;
	UNREFERENCED_PARAMETER (click) ;
	UNREFERENCED_PARAMETER (pt) ;
	UNREFERENCED_PARAMETER (prcArea) ;
}

/*	ITfLangBarItemButton::InitMenu
 *
 *	���� method �� TF_LBI_STYLE_BTN_MENU �X�^�C��������������o�[�̃{�^��
 *	������o�[���{�^���ɑ΂��ĕ\������ menu item ��ǉ����ėL���ɂ��邽��
 *	�ɌĂяo�����B
 */
STDAPI
CLangBarItemCModeButton::InitMenu (
	ITfMenu*				pMenu)
{
	register CSkkImeMgr*	pImeMgr ;
	register CImeDoc*		pDoc ;
	register int		i, nCMode ;
	register DWORD		dwFlag ;
	register LPCWSTR	wstrDesc ;
	register ULONG		nstrDesc ;

	if (pMenu == NULL)
		return	E_INVALIDARG ;

	pImeMgr	= m_pSkkIme->_GetCurrentIME () ;
	if (pImeMgr == NULL)
		return	E_FAIL ;

	if (! m_pSkkIme->_IsKeyboardOpen ()) {
		nCMode	= IMECMODE_OFF ;
	} else {
		pDoc	= pImeMgr->GetDocument () ;
		if (pDoc == NULL)
			return	E_FAIL ;

		nCMode	= pDoc->iGetConversionMode () ;
	}
	for (i = 0 ; i < MYARRAYSIZE (c_rgMenuItems) ; i ++) {
		wstrDesc		= c_rgMenuItems [i].pchDesc ;
		if (wstrDesc != NULL) {
			nstrDesc	= wcslen (wstrDesc) ;
			dwFlag		= (c_rgMenuItems [i].nMode == nCMode)? TF_LBMENUF_CHECKED : 0 ;
		} else {
			nstrDesc	= 0 ;
			dwFlag		= TF_LBMENUF_SEPARATOR ;
		}
		pMenu->AddMenuItem (i, dwFlag, NULL, NULL, wstrDesc, nstrDesc, NULL) ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::OnMenuSelect (
	UINT					wID)
{
	if (wID >= MYARRAYSIZE (c_rgMenuItems))
		return	E_FAIL ;

	/*	NULL �̏ꍇ�� Cancel ���Ǝv�����Ƃɂ���B*/
	if (c_rgMenuItems [wID].pfnHandler != NULL) {
		c_rgMenuItems [wID].pfnHandler (m_pSkkIme) ;
		if (_pLangBarItemSink != NULL)
			_pLangBarItemSink->OnUpdate (TF_LBI_ICON) ;
	}
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::GetIcon (
	HICON*					phIcon)
{
	CSkkImeMgr*	pImeMgr ;
	CImeDoc*	pDoc ;

	DEBUGPRINTF ((TEXT ("CLangBarItemCModeButton::GetIcon ()\n"))) ;

	if (phIcon == NULL)
		return	E_INVALIDARG ;

	pImeMgr	= m_pSkkIme->_GetCurrentIME () ;
	if (pImeMgr == NULL)
		return	E_FAIL ;

	size_t n;
	if (m_pSkkIme->_IsKeyboardDisabled ()) {
		n = IMECMODE_HIRAGANA;
	} else if (! m_pSkkIme->_IsKeyboardOpen ()) {
		n = IMECMODE_OFF;
	} else {
		pDoc	= pImeMgr->GetDocument () ;
		if (pDoc == NULL)
			return	E_FAIL ;
		n = pDoc->iGetConversionMode();
		if (n > IMECMODE_OFF)
			n = IMECMODE_OFF;
	}

	*phIcon = (HICON)LoadImage (g_hInst, MAKEINTRESOURCE(IDI_CMODE_HIRAGANA + n), IMAGE_ICON, 16, 16, LR_SHARED) ;
	return (*phIcon != NULL) ? S_OK : E_FAIL ;
}

STDAPI
CLangBarItemCModeButton::GetText (
	BSTR*			pbstrText)
{
	if (pbstrText == NULL)
		return	E_INVALIDARG ;

	*pbstrText	= SysAllocString (LANGBAR_ITEM_DESC) ;
	return	(*pbstrText == NULL)? E_OUTOFMEMORY : S_OK ;
}

STDAPI
CLangBarItemCModeButton::AdviseSink (
	REFIID			riid,
	IUnknown*		punk,
	DWORD*			pdwCookie)
{
	if (!IsEqualIID (IID_ITfLangBarItemSink, riid))
		return	CONNECT_E_CANNOTCONNECT ;

	if (_pLangBarItemSink != NULL)
		return	CONNECT_E_ADVISELIMIT ;

	if (punk->QueryInterface (IID_ITfLangBarItemSink, (void **)&_pLangBarItemSink) != S_OK) {
		_pLangBarItemSink	= NULL ;
		return	E_NOINTERFACE ;
	}

	*pdwCookie	= SKKIME_LANGBARITEMSINK_COOKIE ;
	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::UnadviseSink (
	DWORD			dwCookie)
{
	if (dwCookie != SKKIME_LANGBARITEMSINK_COOKIE)
		return	CONNECT_E_NOCONNECTION ;

	if (_pLangBarItemSink == NULL)
		return	CONNECT_E_NOCONNECTION ;

	_pLangBarItemSink->Release () ;
	_pLangBarItemSink	= NULL ;

	return	S_OK ;
}

STDAPI
CLangBarItemCModeButton::Update ()
{
	if (_pLangBarItemSink == NULL)
		return	CONNECT_E_NOCONNECTION ;

	_pLangBarItemSink->OnUpdate (TF_LBI_ICON | TF_LBI_STATUS) ;
	return	S_OK ;
}

/*========================================================================*
 *	public function interface
 */
BOOL
CSkkImeTextService::_InitCModeLangBarItem ()
{
	ITfLangBarItemMgr*	pLangBarItemMgr	= NULL ;
	BOOL				bRet ;
	HRESULT				hr ;

	if (! _IsShowLangBarItem (REGKEY_SHOWINPUTMODEICON))
		return	TRUE ;
	if (m_pThreadMgr == NULL)
		return	FALSE ;
	if (m_pThreadMgr->QueryInterface (IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) != S_OK)
		return	FALSE ;

#if WINVER < 0x0600
	ITfLangBarItem*		pItem			= NULL ;
	/*	IME ���̃{�^���폜����B(IE �� IME �� TSF �̗������Ă΂�Ă��܂��̂ŁAIME ���̃{�^����
	 *	����o�[�Ɏc���Ă��܂����Ƃ����邽��)
	 */
	if (SUCCEEDED (pLangBarItemMgr->GetItem (c_guidImeItemButtonCMode, &pItem)) && pItem != NULL) {
		DEBUGPRINTF ((TEXT ("[tsf] RemoveItem: IME-ButtonCMode\n"))) ;
		pLangBarItemMgr->RemoveItem (pItem) ;
		pItem->Release () ;
	}
#endif	// WINVER < 0x0600

	/* TSF ���̃{�^����ǉ�����B*/
	bRet			= FALSE ;
	m_pCModeLangBarItem = new CLangBarItemCModeButton(this, c_guidConversionModeItemButton);
	if (m_pCModeLangBarItem == NULL)
		goto Exit ;

	hr = pLangBarItemMgr->AddItem(m_pCModeLangBarItem);
	if (FAILED(hr))
		goto Exit ;

#ifdef MICROSOFT_METRO
	if (_byteswap_ushort((WORD)::GetVersion()) >= 0x0602) {	// ���̋��E�l��MS�̖��\�ǂ��ɕ���
		m_pCModeLangBarItemEx = new CLangBarItemCModeButton(this, GUID_LBI_INPUTMODE);
		if (m_pCModeLangBarItemEx == NULL)
			goto Exit;

		hr = pLangBarItemMgr->AddItem(m_pCModeLangBarItemEx);
		if (FAILED(hr))
			goto Exit;
	}
#endif	// MICROSOFT_METRO

	DEBUGPRINTF ((TEXT ("[tsf] AddItem: TSF-ButtonCMode\n"))) ;
	bRet	= TRUE ;
Exit:
	pLangBarItemMgr->Release () ;
	return	bRet ;
}

void
CSkkImeTextService::_UninitCModeLangBarItem ()
{
	ITfLangBarItemMgr*	pLangBarItemMgr ;

	if (m_pThreadMgr != NULL) {
		if (m_pThreadMgr->QueryInterface (IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) == S_OK) {
			DEBUGPRINTF ((TEXT ("[tsf] RemoveItem: IME-ButtonCMode\n"))) ;
			if (m_pCModeLangBarItem)
				pLangBarItemMgr->RemoveItem(m_pCModeLangBarItem);
#ifdef MICROSOFT_METRO
			if (m_pCModeLangBarItemEx)
				pLangBarItemMgr->RemoveItem(m_pCModeLangBarItemEx);
#endif	// MICROSOFT_METRO
			pLangBarItemMgr->Release () ;
		}
	}
	if (m_pCModeLangBarItem) {
		m_pCModeLangBarItem->Release();
		m_pCModeLangBarItem = NULL;
	}
#ifdef MICROSOFT_METRO
	if (m_pCModeLangBarItemEx) {
		m_pCModeLangBarItemEx->Release();
		m_pCModeLangBarItemEx = NULL;
	}
#endif	// MICROSOFT_METRO
	return ;
}

void
CSkkImeTextService::_UpdateCModeLangBarItem ()
{
	ITfLangBarItemMgr*	pLangBarItemMgr ;

	if (m_pThreadMgr == NULL)
		return ;
	if (m_pThreadMgr->QueryInterface (IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) != S_OK)
		return ;
	if (_IsShowLangBarItem(REGKEY_SHOWINPUTMODEICON)) {
		if (m_pCModeLangBarItem)
			m_pCModeLangBarItem->Update();
#ifdef MICROSOFT_METRO
		if (m_pCModeLangBarItemEx)
			m_pCModeLangBarItemEx->Update();
#endif	// MICROSOFT_METRO
	}
	DEBUGPRINTF ((TEXT ("[tsf] UpdateItem: IME-ButtonCMode\n"))) ;
	pLangBarItemMgr->Release () ;
	return ;
}
